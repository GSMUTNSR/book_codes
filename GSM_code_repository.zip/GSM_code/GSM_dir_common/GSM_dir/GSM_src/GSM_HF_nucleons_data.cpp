#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// See HF_nucleons_data.h for definitions


HF_nucleons_data::HF_nucleons_data () :
  particle (NO_PARTICLE) , 
  H_potential (NO_POTENTIAL) , 
  is_it_OCM_basis (false), 
  is_it_OCM_HO_core (false), 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  nmax (0) ,
  lmax (0) , 
  nucleon_mass_for_calc (0.0) , 
  N_nlj_res (0) ,
  N_nlj (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0.0) ,
  step_bef_R_uniform (0.0) ,
  R_real_max (0.0) ,
  R_charge (0.0) ,
  nucleus_mass_basis (0.0) ,
  A_basis (0) ,
  N_valence_nucleons_basis (0) , 
  Z_charge_basis_potential (0) , 
  is_it_uniform_filling_approximation (false) , 
  single_particle (false) , 
  Nshells_occ (0)
{}

HF_nucleons_data::HF_nucleons_data (
				    const class input_data_str &input_data , 
				    const class baryons_data &particles_data) :
  particle (NO_PARTICLE) , 
  H_potential (NO_POTENTIAL) , 
  is_it_OCM_basis (false), 
  is_it_OCM_HO_core (false), 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  nmax (0) ,
  lmax (0) , 
  nucleon_mass_for_calc (0.0) , 
  N_nlj_res (0) ,
  N_nlj (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0.0) ,
  step_bef_R_uniform (0.0) ,
  R_real_max (0.0) ,
  R_charge (0.0) ,
  nucleus_mass_basis (0.0) ,
  A_basis (0) ,
  N_valence_nucleons_basis (0) , 
  Z_charge_basis_potential (0) , 
  is_it_uniform_filling_approximation (false) , 
  single_particle (false) , 
  Nshells_occ (0)
{
  allocate (input_data , particles_data);
}

HF_nucleons_data::HF_nucleons_data (const class HF_nucleons_data &X) :
  particle (NO_PARTICLE) , 
  H_potential (NO_POTENTIAL) , 
  is_it_OCM_basis (false), 
  is_it_OCM_HO_core (false), 
  R_cut_function (0.0) , 
  d_cut_function (0.0) , 
  Ueq_regularizor (0.0) , 
  nmax (0) ,
  lmax (0) , 
  nucleon_mass_for_calc (0.0) , 
  N_nlj_res (0) ,
  N_nlj (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) , 
  R (0.0) ,
  step_bef_R_uniform (0.0) ,
  R_real_max (0.0) ,
  R_charge (0.0) ,
  nucleus_mass_basis (0.0) ,
  A_basis (0) ,
  N_valence_nucleons_basis (0) , 
  Z_charge_basis_potential (0) , 
  is_it_uniform_filling_approximation (false) , 
  single_particle (false) , 
  Nshells_occ (0)
{
  allocate_fill (X);
}



void HF_nucleons_data::allocate (
				 const class input_data_str &input_data , 
				 const class baryons_data &particles_data)
{
  if (is_it_filled ()) error_message_print_abort ("HF_nucleons_data cannot be allocated twice in HF_nucleons_data::allocate");

  particle = particles_data.get_nucleonic_particle (); 

  is_it_OCM_basis = is_it_COSM_determine (input_data.get_inter ()) && (input_data.get_basis_potential () != MSDHF) && (input_data.get_basis_potential () != HF);

  H_potential = input_data.get_H_potential (); 

  is_it_OCM_HO_core = particles_data.get_is_it_OCM_HO_core (); 

  R_cut_function = input_data.get_R_cut_function (); 
  d_cut_function = input_data.get_d_cut_function (); 

  Ueq_regularizor = input_data.get_Ueq_regularizor (); 

  nmax = particles_data.get_nmax ();
  lmax = particles_data.get_lmax (); 

  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class array<double> &effective_masses_for_calc = particles_data.get_effective_masses_for_calc ();
            
  nucleon_mass_for_calc = effective_masses_for_calc(particle_index);
  
  N_nlj_res = particles_data.get_N_nlj_res_baryon (); 
  N_nlj     = particles_data.get_N_nlj_baryon (); 
  
  N_bef_R_GL = particles_data.get_N_bef_R_GL (); 
  N_aft_R_GL = particles_data.get_N_aft_R_GL (); 

  N_bef_R_uniform = particles_data.get_N_bef_R_uniform (); 
  N_aft_R_uniform = particles_data.get_N_aft_R_uniform (); 

  R = particles_data.get_R (); 

  step_bef_R_uniform = particles_data.get_step_bef_R_uniform (); 

  R_real_max = particles_data.get_R_real_max (); 

  R_charge = particles_data.get_R_charge (); 

  nucleus_mass_basis = particles_data.get_nucleus_mass_basis (); 

  A_basis = particles_data.get_A_basis (); 

  N_valence_nucleons_basis = particles_data.get_N_valence_nucleons_basis (); 

  Z_charge_basis_potential = particles_data.get_ZY_charge_basis_potential_pos (); 

  is_it_uniform_filling_approximation = false; 

  single_particle = false; 

  Nshells_occ = 0;

  if ((input_data.get_basis_potential () != MSDHF) && (input_data.get_basis_potential () != HF) && !is_it_OCM_basis) return;
  
  const double b_lab = input_data.get_b_lab_basis ();
    
  const class array<int> &nmax_HO_lab_tab = input_data.get_nmax_HO_lab_tab ();
  
  const int nmax_HO = nmax_HO_lab_tab.max ();
  
  const int lmax_plus_one = lmax + 1;

  const int nmax_HO_plus_one = nmax_HO + 1;  
  
  class array<double> r_tab_uniform(N_bef_R_uniform);

  class array<double> r_tab_GL(N_bef_R_GL);
  class array<double> w_tab_GL(N_bef_R_GL);

  HO_wfs_uniform.allocate (nmax_HO_plus_one , lmax_plus_one , N_bef_R_uniform);

  HO_wfs_GL.allocate (nmax_HO_plus_one , lmax_plus_one , N_bef_R_GL);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_tab_uniform(i) = i*step_bef_R_uniform;

  HO_wave_functions::HO_3D::u_r_tables_calc (b_lab , r_tab_uniform , HO_wfs_uniform);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab_GL , w_tab_GL);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_lab , r_tab_GL , HO_wfs_GL);
  
  d_tab.allocate_fill   (particles_data.get_d_basis_core_potential_tab ());
  R0_tab.allocate_fill  (particles_data.get_R0_basis_core_potential_tab ());
  Vo_tab.allocate_fill  (particles_data.get_Vo_basis_core_potential_tab ());
  Vso_tab.allocate_fill (particles_data.get_Vso_basis_core_potential_tab ());

  d_basis_tab.allocate_fill   (particles_data.get_d_basis_tab ());
  R0_basis_tab.allocate_fill  (particles_data.get_R0_basis_tab ());
  Vo_basis_tab.allocate_fill  (particles_data.get_Vo_basis_tab ());
  Vso_basis_tab.allocate_fill (particles_data.get_Vso_basis_tab ());
  
  V0_KKNN_tab.allocate_fill     (particles_data.get_V0_KKNN_tab ());  
  rho_KKNN_tab.allocate_fill    (particles_data.get_rho_KKNN_tab ());
  Vls_KKNN_tab.allocate_fill    (particles_data.get_Vls_KKNN_tab ());			      
  rho_ls_KKNN_tab.allocate_fill (particles_data.get_rho_ls_KKNN_tab ());
  
  V0_KKNN_basis_core_potential_tab.allocate_fill     (particles_data.get_V0_KKNN_basis_core_potential_tab ());  
  rho_KKNN_basis_core_potential_tab.allocate_fill    (particles_data.get_rho_KKNN_basis_core_potential_tab ());
  Vls_KKNN_basis_core_potential_tab.allocate_fill    (particles_data.get_Vls_KKNN_basis_core_potential_tab ());  
  rho_ls_KKNN_basis_core_potential_tab.allocate_fill (particles_data.get_rho_ls_KKNN_basis_core_potential_tab ());
				 
  if (N_nlj > 0) 
    {
      const int lmax_for_basis_interaction = input_data.get_lmax_for_basis_interaction ();
	
      nmin_lj_valence_tab.allocate (0.5 , lmax);

      nmin_lj_valence_tab = 0;

      shells_quantum_numbers.allocate_fill (particles_data.get_shells_quantum_numbers ());

      shells_quantum_numbers_res.allocate (N_nlj_res);

      const class lj_table<class correlated_state_str> &basis_PSI_quantum_numbers_tab = particles_data.get_basis_PSI_quantum_numbers_tab ();

      for (unsigned int i = 0 ; i < N_nlj ; i++) 
	{
	  class nlj_struct &shell_qn = shells_quantum_numbers(i);

	  const enum particle_type particle = shell_qn.get_particle ();

	  const int strangeness = particle_strangeness_determine (particle);

	  if (strangeness != 0) continue;
      
	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();
	  
	  const class correlated_state_str &basis_PSI_qn = basis_PSI_quantum_numbers_tab(l , j);

	  if (S_matrix_pole && basis_PSI_qn.get_is_it_filled ())
	    shell_qn.initialize (
				 S_matrix_pole ,
				 shell_qn.get_core_state () ,
				 shell_qn.get_frozen_state () ,
				 shell_qn.get_hole_state () ,
				 shell_qn.get_OCM_valence_state () ,
				 false ,
				 shell_qn.get_is_it_for_HF_gs () ,
				 shell_qn.get_is_it_natural_orbital () ,
				 shell_qn.get_particle () ,
				 shell_qn.get_e_trunc () ,
				 shell_qn.get_n () ,
				 l ,
				 j ,
				 shell_qn.get_segment () ,
				 shell_qn.get_k () ,
				 shell_qn.get_w () ,
				 shell_qn.get_C0 () ,
				 shell_qn.get_Cplus () ,
				 shell_qn.get_k_plus () ,
				 shell_qn.get_C0_plus () ,
				 shell_qn.get_k_minus () ,
				 shell_qn.get_C0_minus ());
	}

      for (unsigned int i = 0 ; i < N_nlj_res ; i++) shells_quantum_numbers_res(i) = shells_quantum_numbers(i);

      N_valence_nucleons_in_shell_tab.allocate (0.5 , nmax , lmax);

      k_bef_tab.allocate (0.5 , nmax , lmax);

      Ueq_finite_range_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_averaged_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_averaged_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_res_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_res_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_res_averaged_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_res_averaged_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_plus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_plus_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_plus_averaged_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_plus_averaged_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_minus_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_minus_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_minus_averaged_tab_uniform.allocate (0.5 , nmax , lmax , N_bef_R_uniform);
      source_minus_averaged_tab_uniform.allocate           (0.5 , nmax , lmax , N_bef_R_uniform);

      Ueq_finite_range_tab_uniform       = 0.0 , source_tab_uniform       = 0.0 , Ueq_finite_range_averaged_tab_uniform       = 0.0 , source_averaged_tab_uniform       = 0.0;
      Ueq_finite_range_res_tab_uniform   = 0.0 , source_res_tab_uniform   = 0.0 , Ueq_finite_range_res_averaged_tab_uniform   = 0.0 , source_res_averaged_tab_uniform   = 0.0;
      Ueq_finite_range_plus_tab_uniform  = 0.0 , source_plus_tab_uniform  = 0.0 , Ueq_finite_range_plus_averaged_tab_uniform  = 0.0 , source_plus_averaged_tab_uniform  = 0.0;
      Ueq_finite_range_minus_tab_uniform = 0.0 , source_minus_tab_uniform = 0.0 , Ueq_finite_range_minus_averaged_tab_uniform = 0.0 , source_minus_averaged_tab_uniform = 0.0;

      Ueq_finite_range_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_averaged_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_averaged_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_res_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_res_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_res_averaged_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_res_averaged_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_plus_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_plus_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_plus_averaged_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_plus_averaged_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_minus_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_minus_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_minus_averaged_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
      source_minus_averaged_tab_GL.allocate           (0.5 , nmax , lmax , N_bef_R_GL);

      Ueq_finite_range_tab_GL       = 0.0 , source_tab_GL       = 0.0 , Ueq_finite_range_averaged_tab_GL       = 0.0 , source_averaged_tab_GL       = 0.0;
      Ueq_finite_range_res_tab_GL   = 0.0 , source_res_tab_GL   = 0.0 , Ueq_finite_range_res_averaged_tab_GL   = 0.0 , source_res_averaged_tab_GL   = 0.0;
      Ueq_finite_range_plus_tab_GL  = 0.0 , source_plus_tab_GL  = 0.0 , Ueq_finite_range_plus_averaged_tab_GL  = 0.0 , source_plus_averaged_tab_GL  = 0.0;
      Ueq_finite_range_minus_tab_GL = 0.0 , source_minus_tab_GL = 0.0 , Ueq_finite_range_minus_averaged_tab_GL = 0.0 , source_minus_averaged_tab_GL = 0.0;

      const enum interaction_type inter = input_data.get_inter ();

      if (is_it_SGI_MSGI_determine (inter))
	{
	  Ueq_SGI_MSGI_tab_GL.allocate    (0.5 , nmax , lmax , N_bef_R_GL);
	  source_SGI_MSGI_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);

	  Ueq_SGI_MSGI_res_tab_GL.allocate    (0.5 , nmax , lmax , N_bef_R_GL);
	  source_SGI_MSGI_res_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);

	  Ueq_SGI_MSGI_plus_tab_GL.allocate    (0.5 , nmax , lmax , N_bef_R_GL);
	  source_SGI_MSGI_plus_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL); 

	  Ueq_SGI_MSGI_minus_tab_GL.allocate    (0.5 , nmax , lmax , N_bef_R_GL);
	  source_SGI_MSGI_minus_tab_GL.allocate (0.5 , nmax , lmax , N_bef_R_GL);
	}

      HO_overlaps.allocate       (N_nlj);
      HO_overlaps_Fermi.allocate (N_nlj);

      HO_overlaps_res.allocate       (N_nlj_res);
      HO_overlaps_Fermi_res.allocate (N_nlj_res);

      HO_overlaps_plus.allocate       (N_nlj);
      HO_overlaps_Fermi_plus.allocate (N_nlj);

      HO_overlaps_minus.allocate       (N_nlj);
      HO_overlaps_Fermi_minus.allocate (N_nlj);	

      for (unsigned int i = 0 ; i < N_nlj ; i++) 
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(i);
	  
	  const int l = shell_qn.get_l ();

	  const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);

	  const int nmax_HO_l_plus_one = nmax_HO_l + 1;  
	  
	  HO_overlaps(i).allocate       (nmax_HO_l_plus_one);
	  HO_overlaps_Fermi(i).allocate (nmax_HO_l_plus_one);

	  HO_overlaps_plus(i).allocate       (nmax_HO_l_plus_one);
	  HO_overlaps_Fermi_plus(i).allocate (nmax_HO_l_plus_one);

	  HO_overlaps_minus(i).allocate       (nmax_HO_l_plus_one);
	  HO_overlaps_Fermi_minus(i).allocate (nmax_HO_l_plus_one);
	}

      for (unsigned int i = 0 ; i < N_nlj_res ; i++) 
	{
	  const class nlj_struct &shell_qn_res = shells_quantum_numbers_res(i);
	  
	  const int l = shell_qn_res.get_l ();

	  const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);

	  const int nmax_HO_l_plus_one = nmax_HO_l + 1;
	  
	  HO_overlaps_res(i).allocate (nmax_HO_l_plus_one);
	  
	  HO_overlaps_Fermi_res(i).allocate (nmax_HO_l_plus_one);
	}
      
      U_finite_range_HF_HO_basis_HO_expansion_part.allocate (0.5 , lmax);

      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int nmax_HO_l = (l <= lmax_for_basis_interaction) ? (nmax_HO_lab_tab(l)) : (0);
	    
	    U_finite_range_HF_HO_basis_HO_expansion_part(l , j).allocate (nmax_HO_l + 1);
	    U_finite_range_HF_HO_basis_HO_expansion_part(l , j) = 0.0;
	  }

      shells_res.allocate   (N_nlj_res);
      
      shells.allocate       (N_nlj); 
      shells_plus.allocate  (N_nlj);
      shells_minus.allocate (N_nlj);

      const int nmax_plus_one = nmax + 1;

      const bool is_it_SGI  = is_it_SGI_determine  (inter);
      const bool is_it_MSGI = is_it_MSGI_determine (inter);

      if (is_it_SGI || is_it_MSGI) OBMEs_HF_SGI_MSGI.allocate (0.5 , lmax , nmax_plus_one , nmax_plus_one);

      const class array<class lj_table<enum potential_type> > &basis_potential_partial_waves_tab = particles_data.get_basis_potential_partial_waves_tab ();

      is_partial_wave_optimized_HF_MSDHF_tab.allocate (0.5 , lmax);
      
      is_partial_wave_optimized_HF_MSDHF_tab = false;

      for (unsigned int s = 0 ; s < N_nlj ; s++)
	{
	  const class nlj_struct &shell_qn = shells_quantum_numbers(s);
	  
	  const enum particle_type particle = shell_qn.get_particle ();

	  const int strangeness = particle_strangeness_determine (particle);

	  if (strangeness != 0) continue;
      
	  const unsigned int particle_index = charge_baryon_index_determine (particle);
      
	  const class lj_table<enum potential_type> &basis_potential_partial_waves = basis_potential_partial_waves_tab(particle_index);
      
	  const int l = shell_qn.get_l ();

	  const double j = shell_qn.get_j ();

	  const enum potential_type basis_potential = basis_potential_partial_waves(l , j);

	  is_partial_wave_optimized_HF_MSDHF_tab(l , j) = ((basis_potential == HF) || (basis_potential == MSDHF));
	}

      highest_occupied_n_tab.allocate (0.5 , lmax);

      if (N_valence_nucleons_basis <= 2) occupied_pairs.allocate (0.5 , lmax);

      dimensions_GS.allocate (0.5 , lmax);
      U_HF_normalizing_sums.allocate (0.5 , lmax);

      configurations_to_diagonalize.allocate (0.5 , lmax);
      
      SDp_tab_GS.allocate          (0.5 , lmax);
      SDn_tab_GS.allocate          (0.5 , lmax);
      SDs_GS_coefficients.allocate (0.5 , lmax);
      
      SDs_1h.allocate               (0.5 , lmax);
      SDs_1h_coefficients.allocate  (0.5 , lmax);
      SDs_1h_existence_tab.allocate (0.5 , lmax);

      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  configurations_to_diagonalize(l , j).allocate (N_valence_nucleons_basis);

      const class array<class lj_table<double> > &b_lab_partial_waves_tab = particles_data.get_b_partial_waves_tab ();
  
      const class lj_table<double> &b_lab_partial_waves_nucleon = b_lab_partial_waves_tab(particle_index);
        
      b_lab_partial_waves.allocate_fill (b_lab_partial_waves_nucleon);

      for (unsigned int s = 0; s < N_nlj_res ; s++)
	{
	  const class nlj_struct &shell_qn_res = shells_quantum_numbers_res(s);
	  
	  const bool core_state = shell_qn_res.get_core_state ();

	  if (core_state)
	    {	      
	      const int n = shell_qn_res.get_n ();
	      const int l = shell_qn_res.get_l ();
	      
	      const double j = shell_qn_res.get_j ();

	      const int n_plus_one = n + 1;
	      
	      nmin_lj_valence_tab(l , j) = max (nmin_lj_valence_tab(l , j) , n_plus_one);
	    }
	}

      shells_OCM_core_states_overlaps.allocate (0.5 , lmax , nmax_plus_one , N_nlj_res);
      
      shells_OCM_core_states_overlaps = 0.0;

      const class array<class lj_table<int> > &nmax_lj_tabs = particles_data.get_nmax_lj_tabs ();
      
      const class lj_table<int> &nmax_lj_tab_nucleon = nmax_lj_tabs(particle_index);

      php_matrices.allocate (0.5 , lmax);

      for (int l = 0 ; l <= lmax ; l++)
	for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {
	    const int nmax_lj = nmax_lj_tab_nucleon(l , j);

	    php_matrices(l,j).allocate (nmax_lj + 1);
	  }
    }
}








void HF_nucleons_data::allocate_fill (const class HF_nucleons_data &X)
{
  if (is_it_filled ()) error_message_print_abort ("HF_nucleons_data cannot be allocated twice in HF_nucleons_data::allocate_fill");

  particle = X.particle;
  
  H_potential = X.H_potential; 

  is_it_OCM_basis = X.is_it_OCM_basis;
  
  is_it_OCM_HO_core = X.is_it_OCM_HO_core; 

  R_cut_function = X.R_cut_function; 
  d_cut_function = X.d_cut_function; 

  Ueq_regularizor = X.Ueq_regularizor; 

  nmax = X.nmax; 
  lmax = X.lmax; 

  nucleon_mass_for_calc= X.nucleon_mass_for_calc; 

  N_nlj_res = X.N_nlj_res; 
  N_nlj     = X.N_nlj; 

  N_bef_R_GL = X.N_bef_R_GL; 
  N_aft_R_GL = X.N_aft_R_GL; 

  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform; 

  R = X.R; 

  step_bef_R_uniform = X.step_bef_R_uniform;

  R_real_max = X.R_real_max; 

  R_charge = X.R_charge; 

  nucleus_mass_basis = X.nucleus_mass_basis; 

  A_basis = X.A_basis; 

  N_valence_nucleons_basis = X.N_valence_nucleons_basis; 

  Z_charge_basis_potential = X.Z_charge_basis_potential; 

  is_it_uniform_filling_approximation = X.is_it_uniform_filling_approximation; 

  single_particle = X.single_particle; 

  Nshells_occ = X.Nshells_occ;

  V0_KKNN_tab.allocate_fill (X.V0_KKNN_tab); 
  rho_KKNN_tab.allocate_fill (X.rho_KKNN_tab);
  Vls_KKNN_tab.allocate_fill (X.Vls_KKNN_tab);
  rho_ls_KKNN_tab.allocate_fill (X.rho_ls_KKNN_tab);  
  V0_KKNN_basis_core_potential_tab.allocate_fill (X.V0_KKNN_basis_core_potential_tab);
  rho_KKNN_basis_core_potential_tab.allocate_fill (X.rho_KKNN_basis_core_potential_tab);
  Vls_KKNN_basis_core_potential_tab.allocate_fill (X.Vls_KKNN_basis_core_potential_tab);
  rho_ls_KKNN_basis_core_potential_tab.allocate_fill (X.rho_ls_KKNN_basis_core_potential_tab);
  HO_wfs_uniform.allocate_fill (X.HO_wfs_uniform);
  HO_wfs_GL.allocate_fill (X.HO_wfs_GL);
  d_tab.allocate_fill (X.d_tab);
  R0_tab.allocate_fill (X.R0_tab);
  Vo_tab.allocate_fill (X.Vo_tab);
  Vso_tab.allocate_fill (X.Vso_tab); 
  d_basis_tab.allocate_fill (X.d_basis_tab);
  R0_basis_tab.allocate_fill (X.R0_basis_tab);
  Vo_basis_tab.allocate_fill (X.Vo_basis_tab);
  Vso_basis_tab.allocate_fill (X.Vso_basis_tab);
  shells_quantum_numbers.allocate_fill (X.shells_quantum_numbers);
  shells_quantum_numbers_res.allocate_fill (X.shells_quantum_numbers_res);
  N_valence_nucleons_in_shell_tab.allocate_fill (X.N_valence_nucleons_in_shell_tab);  
  k_bef_tab.allocate_fill (X.k_bef_tab);
  U_finite_range_HF_HO_basis_HO_expansion_part.allocate_fill (X.U_finite_range_HF_HO_basis_HO_expansion_part);
  Ueq_finite_range_tab_uniform.allocate_fill (X.Ueq_finite_range_tab_uniform); 
  Ueq_finite_range_averaged_tab_uniform.allocate_fill (X.Ueq_finite_range_averaged_tab_uniform);
  source_tab_uniform.allocate_fill (X.source_tab_uniform); 
  source_averaged_tab_uniform.allocate_fill (X.source_averaged_tab_uniform);
  Ueq_finite_range_res_tab_uniform.allocate_fill (X.Ueq_finite_range_res_tab_uniform); 
  Ueq_finite_range_res_averaged_tab_uniform.allocate_fill (X.Ueq_finite_range_res_averaged_tab_uniform);
  source_res_tab_uniform.allocate_fill (X.source_res_tab_uniform); 
  source_res_averaged_tab_uniform.allocate_fill (X.source_res_averaged_tab_uniform);
  Ueq_finite_range_plus_tab_uniform.allocate_fill (X.Ueq_finite_range_plus_tab_uniform); 
  Ueq_finite_range_plus_averaged_tab_uniform.allocate_fill (X.Ueq_finite_range_plus_averaged_tab_uniform);
  source_plus_tab_uniform.allocate_fill (X.source_plus_tab_uniform); 
  source_plus_averaged_tab_uniform.allocate_fill (X.source_plus_averaged_tab_uniform);
  Ueq_finite_range_minus_tab_uniform.allocate_fill (X.Ueq_finite_range_minus_tab_uniform); 
  Ueq_finite_range_minus_averaged_tab_uniform.allocate_fill (X.Ueq_finite_range_minus_averaged_tab_uniform);
  source_minus_tab_uniform.allocate_fill (X.source_minus_tab_uniform); 
  source_minus_averaged_tab_uniform.allocate_fill (X.source_minus_averaged_tab_uniform);
  Ueq_finite_range_tab_GL.allocate_fill (X.Ueq_finite_range_tab_GL); 
  Ueq_finite_range_averaged_tab_GL.allocate_fill (X.Ueq_finite_range_averaged_tab_GL);
  source_tab_GL.allocate_fill (X.source_tab_GL); 
  source_averaged_tab_GL.allocate_fill (X.source_averaged_tab_GL);
  Ueq_finite_range_res_tab_GL.allocate_fill (X.Ueq_finite_range_res_tab_GL); 
  Ueq_finite_range_res_averaged_tab_GL.allocate_fill (X.Ueq_finite_range_res_averaged_tab_GL);
  source_res_tab_GL.allocate_fill (X.source_res_tab_GL); 
  source_res_averaged_tab_GL.allocate_fill (X.source_res_averaged_tab_GL);
  Ueq_finite_range_plus_tab_GL.allocate_fill (X.Ueq_finite_range_plus_tab_GL); 
  Ueq_finite_range_plus_averaged_tab_GL.allocate_fill (X.Ueq_finite_range_plus_averaged_tab_GL);
  source_plus_tab_GL.allocate_fill (X.source_plus_tab_GL); 
  source_plus_averaged_tab_GL.allocate_fill (X.source_plus_averaged_tab_GL);
  Ueq_finite_range_minus_tab_GL.allocate_fill (X.Ueq_finite_range_minus_tab_GL); 
  Ueq_finite_range_minus_averaged_tab_GL.allocate_fill (X.Ueq_finite_range_minus_averaged_tab_GL);
  source_minus_tab_GL.allocate_fill (X.source_minus_tab_GL); 
  source_minus_averaged_tab_GL.allocate_fill (X.source_minus_averaged_tab_GL);
  Ueq_SGI_MSGI_tab_GL.allocate_fill (X.Ueq_SGI_MSGI_tab_GL); 
  Ueq_SGI_MSGI_res_tab_GL.allocate_fill (X.Ueq_SGI_MSGI_res_tab_GL); 
  source_SGI_MSGI_tab_GL.allocate_fill (X.source_SGI_MSGI_tab_GL);
  source_SGI_MSGI_res_tab_GL.allocate_fill (X.source_SGI_MSGI_res_tab_GL);
  Ueq_SGI_MSGI_plus_tab_GL.allocate_fill (X.Ueq_SGI_MSGI_plus_tab_GL); 
  Ueq_SGI_MSGI_minus_tab_GL.allocate_fill (X.Ueq_SGI_MSGI_minus_tab_GL); 
  source_SGI_MSGI_plus_tab_GL.allocate_fill (X.source_SGI_MSGI_plus_tab_GL);
  source_SGI_MSGI_minus_tab_GL.allocate_fill (X.source_SGI_MSGI_minus_tab_GL);
  HO_overlaps.allocate_fill (X.HO_overlaps); 
  HO_overlaps_res.allocate_fill (X.HO_overlaps_res); 
  HO_overlaps_plus.allocate_fill (X.HO_overlaps_plus); 
  HO_overlaps_minus.allocate_fill (X.HO_overlaps_minus);
  HO_overlaps_Fermi.allocate_fill (X.HO_overlaps_Fermi); 
  HO_overlaps_Fermi_res.allocate_fill (X.HO_overlaps_Fermi_res); 
  HO_overlaps_Fermi_plus.allocate_fill (X.HO_overlaps_Fermi_plus); 
  HO_overlaps_Fermi_minus.allocate_fill (X.HO_overlaps_Fermi_minus);
  shells.allocate_fill (X.shells); 
  shells_res.allocate_fill (X.shells_res); 
  shells_plus.allocate_fill (X.shells_plus); 
  shells_minus.allocate_fill (X.shells_minus);
  is_partial_wave_optimized_HF_MSDHF_tab.allocate_fill (X.is_partial_wave_optimized_HF_MSDHF_tab);  
  highest_occupied_n_tab.allocate_fill (X.highest_occupied_n_tab);
  occupied_pairs.allocate_fill (X.occupied_pairs);
  configurations_to_diagonalize.allocate_fill (X.configurations_to_diagonalize);
  dimensions_GS.allocate_fill (X.dimensions_GS);  
  SDp_tab_GS.allocate_fill (X.SDp_tab_GS);
  SDn_tab_GS.allocate_fill (X.SDn_tab_GS);
  SDs_GS_coefficients.allocate_fill (X.SDs_GS_coefficients);
  SDs_1h.allocate_fill (X.SDs_1h);
  SDs_1h_coefficients.allocate_fill (X.SDs_1h_coefficients);
  SDs_1h_existence_tab.allocate_fill (X.SDs_1h_existence_tab);
  U_HF_normalizing_sums.allocate_fill (X.U_HF_normalizing_sums);
  OBMEs_HF_SGI_MSGI.allocate_fill (X.OBMEs_HF_SGI_MSGI);  
  b_lab_partial_waves.allocate_fill (X.b_lab_partial_waves);  
  nmin_lj_valence_tab.allocate_fill (X.nmin_lj_valence_tab);
  shells_OCM_core_states_overlaps.allocate_fill (X.shells_OCM_core_states_overlaps);  
  php_matrices.allocate_fill (X.php_matrices);
}




void HF_nucleons_data::deallocate ()
{
  V0_KKNN_tab.deallocate (); 
  rho_KKNN_tab.deallocate ();
  Vls_KKNN_tab.deallocate ();
  rho_ls_KKNN_tab.deallocate ();  
  V0_KKNN_basis_core_potential_tab.deallocate ();
  rho_KKNN_basis_core_potential_tab.deallocate ();
  Vls_KKNN_basis_core_potential_tab.deallocate ();
  rho_ls_KKNN_basis_core_potential_tab.deallocate ();
  HO_wfs_uniform.deallocate ();
  HO_wfs_GL.deallocate ();
  d_tab.deallocate ();
  R0_tab.deallocate ();
  Vo_tab.deallocate ();
  Vso_tab.deallocate (); 
  d_basis_tab.deallocate ();
  R0_basis_tab.deallocate ();
  Vo_basis_tab.deallocate ();
  Vso_basis_tab.deallocate ();
  shells_quantum_numbers.deallocate ();
  shells_quantum_numbers_res.deallocate ();
  N_valence_nucleons_in_shell_tab.deallocate ();  
  k_bef_tab.deallocate ();
  U_finite_range_HF_HO_basis_HO_expansion_part.deallocate ();
  Ueq_finite_range_tab_uniform.deallocate (); 
  Ueq_finite_range_averaged_tab_uniform.deallocate ();
  source_tab_uniform.deallocate (); 
  source_averaged_tab_uniform.deallocate ();
  Ueq_finite_range_res_tab_uniform.deallocate (); 
  Ueq_finite_range_res_averaged_tab_uniform.deallocate ();
  source_res_tab_uniform.deallocate (); 
  source_res_averaged_tab_uniform.deallocate ();
  Ueq_finite_range_plus_tab_uniform.deallocate (); 
  Ueq_finite_range_plus_averaged_tab_uniform.deallocate ();
  source_plus_tab_uniform.deallocate (); 
  source_plus_averaged_tab_uniform.deallocate ();
  Ueq_finite_range_minus_tab_uniform.deallocate (); 
  Ueq_finite_range_minus_averaged_tab_uniform.deallocate ();
  source_minus_tab_uniform.deallocate (); 
  source_minus_averaged_tab_uniform.deallocate ();
  Ueq_finite_range_tab_GL.deallocate (); 
  Ueq_finite_range_averaged_tab_GL.deallocate ();
  source_tab_GL.deallocate (); 
  source_averaged_tab_GL.deallocate ();
  Ueq_finite_range_res_tab_GL.deallocate (); 
  Ueq_finite_range_res_averaged_tab_GL.deallocate ();
  source_res_tab_GL.deallocate (); 
  source_res_averaged_tab_GL.deallocate ();
  Ueq_finite_range_plus_tab_GL.deallocate (); 
  Ueq_finite_range_plus_averaged_tab_GL.deallocate ();
  source_plus_tab_GL.deallocate (); 
  source_plus_averaged_tab_GL.deallocate ();
  Ueq_finite_range_minus_tab_GL.deallocate (); 
  Ueq_finite_range_minus_averaged_tab_GL.deallocate ();
  source_minus_tab_GL.deallocate (); 
  source_minus_averaged_tab_GL.deallocate ();
  Ueq_SGI_MSGI_tab_GL.deallocate (); 
  Ueq_SGI_MSGI_res_tab_GL.deallocate (); 
  source_SGI_MSGI_tab_GL.deallocate ();
  source_SGI_MSGI_res_tab_GL.deallocate ();
  Ueq_SGI_MSGI_plus_tab_GL.deallocate (); 
  Ueq_SGI_MSGI_minus_tab_GL.deallocate (); 
  source_SGI_MSGI_plus_tab_GL.deallocate ();
  source_SGI_MSGI_minus_tab_GL.deallocate ();
  HO_overlaps.deallocate (); 
  HO_overlaps_res.deallocate (); 
  HO_overlaps_plus.deallocate (); 
  HO_overlaps_minus.deallocate ();
  HO_overlaps_Fermi.deallocate (); 
  HO_overlaps_Fermi_res.deallocate (); 
  HO_overlaps_Fermi_plus.deallocate (); 
  HO_overlaps_Fermi_minus.deallocate ();
  shells.deallocate (); 
  shells_res.deallocate (); 
  shells_plus.deallocate (); 
  shells_minus.deallocate ();
  is_partial_wave_optimized_HF_MSDHF_tab.deallocate ();  
  highest_occupied_n_tab.deallocate ();
  occupied_pairs.deallocate ();
  configurations_to_diagonalize.deallocate ();
  dimensions_GS.deallocate ();  
  SDp_tab_GS.deallocate ();
  SDn_tab_GS.deallocate ();
  SDs_GS_coefficients.deallocate ();
  SDs_1h.deallocate ();
  SDs_1h_coefficients.deallocate ();
  SDs_1h_existence_tab.deallocate ();
  U_HF_normalizing_sums.deallocate ();
  OBMEs_HF_SGI_MSGI.deallocate ();  
  b_lab_partial_waves.deallocate ();  
  nmin_lj_valence_tab.deallocate ();
  shells_OCM_core_states_overlaps.deallocate ();  
  php_matrices.deallocate ();
  
  particle = NO_PARTICLE; 

  H_potential = NO_POTENTIAL; 

  is_it_OCM_basis = false;

  is_it_OCM_HO_core = false;

  R_cut_function = 0.0; 
  d_cut_function = 0.0; 

  Ueq_regularizor = 0.0; 

  nmax = 0;
  lmax = 0; 

  nucleon_mass_for_calc = 0.0; 

  N_nlj_res = 0;
  N_nlj     = 0; 

  N_bef_R_GL = 0; 
  N_aft_R_GL = 0; 

  N_bef_R_uniform = 0; 
  N_aft_R_uniform = 0; 

  R = 0.0;

  step_bef_R_uniform = 0.0;

  R_real_max = 0.0;

  R_charge = 0.0;

  nucleus_mass_basis = 0.0;

  A_basis = 0;

  N_valence_nucleons_basis = 0; 

  Z_charge_basis_potential = 0; 

  is_it_uniform_filling_approximation = false; 

  single_particle = false; 

  Nshells_occ = 0;
}






// Copy shell arrays from another HF_nucleons_data class and allocates arrays if necessary
// ---------------------------------------------------------------------------------------

void HF_nucleons_data::copy_data_shells_alloc_calc (
						    const enum potential_type basis_potential , 
						    const class HF_nucleons_data &X)
{
  if (N_nlj == 0) return;

  is_it_uniform_filling_approximation = X.is_it_uniform_filling_approximation;
  
  Nshells_occ = X.Nshells_occ;

  N_valence_nucleons_in_shell_tab = X.N_valence_nucleons_in_shell_tab;

  is_partial_wave_optimized_HF_MSDHF_tab = X.is_partial_wave_optimized_HF_MSDHF_tab;

  highest_occupied_n_tab = X.highest_occupied_n_tab;

  nmin_lj_valence_tab = X.nmin_lj_valence_tab;

  for (int l = 0; l <= lmax; l++)
    for (double j = (l == 0) ? (0.5) : (l - 0.5); rint (j - l - 0.5) <= 0.0; j++)
      configurations_to_diagonalize(l , j) = X.configurations_to_diagonalize(l , j);

  const class array<class nlj_struct> &X_shells_qn_res = X.shells_quantum_numbers_res;

  for (unsigned int s = 0; s < N_nlj_res ; s++)
    {
      class nlj_struct &shell_qn_res = shells_quantum_numbers_res(s);
  
      const enum particle_type particle = shell_qn_res.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
	  
      shell_qn_res = X_shells_qn_res(s);

      const class spherical_state &X_shell_res = X.shells_res(s);
      
      class spherical_state &shell_res = shells_res(s);

      shell_res.deallocate ();

      if (X_shell_res.is_it_filled ())
	shell_res.allocate_fill (X_shell_res);
      else
	{
	  const bool S_matrix_pole = shell_qn_res.get_S_matrix_pole ();

	  const int nc = shell_qn_res.get_n ();
	  const int lc = shell_qn_res.get_l ();

	  const double jc = shell_qn_res.get_j ();
	  
	  const double R0 = R0_tab(0 , lc);

	  const complex<double> kc = shell_qn_res.get_k ();

	  shell_res.allocate (false , true , basis_potential , A_basis , Z_charge_basis_potential , nucleus_mass_basis , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
			      R , NADA , R0 , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , nc , NADA , lc , jc , false , kc , nucleon_mass_for_calc , 1.0 , 1.0);	 
	}

      const bool core_state = shell_qn_res.get_core_state ();

      if (core_state)
	{
	  const int n = shell_qn_res.get_n ();
	  const int l = shell_qn_res.get_l ();

	  const double j = shell_qn_res.get_j ();

	  if (Ueq_SGI_MSGI_tab_GL.is_it_filled ())     for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_SGI_MSGI_tab_GL    (n , l , j , i) = X.Ueq_SGI_MSGI_tab_GL    (n , l , j , i);	  
	  if (source_SGI_MSGI_tab_GL.is_it_filled ())  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_SGI_MSGI_tab_GL (n , l , j , i) = X.source_SGI_MSGI_tab_GL (n , l , j , i);
	  if (Ueq_finite_range_tab_GL.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_finite_range_tab_GL(n , l , j , i) = X.Ueq_finite_range_tab_GL(n , l , j , i);

	  if (source_tab_GL.is_it_filled ())                    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_tab_GL                   (n , l , j , i) = X.source_tab_GL                   (n , l , j , i);
	  if (Ueq_finite_range_averaged_tab_GL.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_finite_range_averaged_tab_GL(n , l , j , i) = X.Ueq_finite_range_averaged_tab_GL(n , l , j , i);
	  if (source_averaged_tab_GL.is_it_filled ())           for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_averaged_tab_GL          (n , l , j , i) = X.source_averaged_tab_GL          (n , l , j , i);

	  if (Ueq_finite_range_tab_uniform.is_it_filled ())          for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) Ueq_finite_range_tab_uniform         (n , l , j , i) = X.Ueq_finite_range_tab_uniform         (n , l , j , i);
	  if (source_tab_uniform.is_it_filled ())                    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_tab_uniform                   (n , l , j , i) = X.source_tab_uniform                   (n , l , j , i);
	  if (Ueq_finite_range_averaged_tab_uniform.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) Ueq_finite_range_averaged_tab_uniform(n , l , j , i) = X.Ueq_finite_range_averaged_tab_uniform(n , l , j , i);
	  if (source_averaged_tab_uniform.is_it_filled ())           for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_averaged_tab_uniform          (n , l , j , i) = X.source_averaged_tab_uniform          (n , l , j , i);
	}
    }
  
  for (unsigned int s = 0; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);
      
      const enum particle_type particle = shell_qn.get_particle ();

      const int strangeness = particle_strangeness_determine (particle);

      if (strangeness != 0) continue;
      
      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();
      
      const int nc = shell_qn.get_n ();
      const int lc = shell_qn.get_l ();
      
      const double jc = shell_qn.get_j ();
      
      const double R0 = R0_tab(0 , lc);
      
      const complex<double> kc = shell_qn.get_k ();

      class spherical_state &shell = shells(s);

      shell.allocate (false , true , basis_potential , A_basis , Z_charge_basis_potential , nucleus_mass_basis , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 , 
		      R , NADA , R0 , R_real_max , 0.0 , 0.0 , S_matrix_pole , particle , nc , NADA , lc , jc , false , kc , nucleon_mass_for_calc , 1.0 , 1.0);	 
	
      if (is_partial_wave_optimized_HF_MSDHF_tab(lc , jc) || is_it_OCM_basis)
	{
	  const int nc_min = nmin_lj_valence_tab(lc , jc);

	  if (Ueq_SGI_MSGI_tab_GL.is_it_filled ())     for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_SGI_MSGI_tab_GL    (nc , lc , jc , i) = Ueq_SGI_MSGI_tab_GL    (nc_min , lc , jc , i);	  
	  if (source_SGI_MSGI_tab_GL.is_it_filled ())  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_SGI_MSGI_tab_GL (nc , lc , jc , i) = source_SGI_MSGI_tab_GL (nc_min , lc , jc , i);
	  if (Ueq_finite_range_tab_GL.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_finite_range_tab_GL(nc , lc , jc , i) = Ueq_finite_range_tab_GL(nc_min , lc , jc , i);

	  if (source_tab_GL.is_it_filled ())                    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_tab_GL                   (nc , lc , jc , i) = source_tab_GL                   (nc_min , lc , jc , i);
	  if (Ueq_finite_range_averaged_tab_GL.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Ueq_finite_range_averaged_tab_GL(nc , lc , jc , i) = Ueq_finite_range_averaged_tab_GL(nc_min , lc , jc , i);
	  if (source_averaged_tab_GL.is_it_filled ())           for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) source_averaged_tab_GL          (nc , lc , jc , i) = source_averaged_tab_GL          (nc_min , lc , jc , i);

	  if (Ueq_finite_range_tab_uniform.is_it_filled ())          for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) Ueq_finite_range_tab_uniform         (nc , lc , jc , i) = Ueq_finite_range_tab_uniform         (nc_min , lc , jc , i);
	  if (source_tab_uniform.is_it_filled ())                    for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_tab_uniform                   (nc , lc , jc , i) = source_tab_uniform                   (nc_min , lc , jc , i);
	  if (Ueq_finite_range_averaged_tab_uniform.is_it_filled ()) for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) Ueq_finite_range_averaged_tab_uniform(nc , lc , jc , i) = Ueq_finite_range_averaged_tab_uniform(nc_min , lc , jc , i);
	  if (source_averaged_tab_uniform.is_it_filled ())           for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_averaged_tab_uniform          (nc , lc , jc , i) = source_averaged_tab_uniform          (nc_min , lc , jc , i);	  
	}
    }
}







// Check if the core and basis potentials are equal
// ------------------------------------------------
// The WS potentials used for the core and basis potentials are checked if they are equal or not.
// If they are equal, one-body basis wave functions are orthogonal to core wave functions and the OCM potential is not needed.
// Otherwise, one must add the OCM potential to the basis-generating potential so that one-body basis wave functions are orthogonal to core wave functions.
// A boolean associated to the check is returned.

bool are_core_basis_potentials_equal (
				      const int l ,
				      const class HF_nucleons_data &HF_data)
{
  const bool is_it_OCM_HO_core = HF_data.get_is_it_OCM_HO_core ();
  
  if (is_it_OCM_HO_core) return false;

  const class array<double> &d_tab   = HF_data.get_d_tab ();
  const class array<double> &R0_tab  = HF_data.get_R0_tab ();
  const class array<double> &Vo_tab  = HF_data.get_Vo_tab ();
  const class array<double> &Vso_tab = HF_data.get_Vso_tab ();

  const class array<double> &d_basis_tab   = HF_data.get_d_basis_tab ();
  const class array<double> &R0_basis_tab  = HF_data.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab  = HF_data.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab = HF_data.get_Vso_basis_tab ();

  const double d   = d_tab  (0 , l);
  const double R0  = R0_tab (0 , l);
  const double Vo  = Vo_tab (0 , l);
  const double Vso = Vso_tab(0 , l);

  const double d_basis   = d_basis_tab  (0 , l);
  const double R0_basis  = R0_basis_tab (0 , l);
  const double Vo_basis  = Vo_basis_tab (0 , l);
  const double Vso_basis = Vso_basis_tab(0 , l);

  if (abs (d   - d_basis)   > precision) return false;
  if (abs (R0  - R0_basis)  > precision) return false;
  if (abs (Vo  - Vo_basis)  > precision) return false;
  if (abs (Vso - Vso_basis) > precision) return false;

  return true;
}




double used_memory_calc (const class HF_nucleons_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.V0_KKNN_tab) 
    + used_memory_calc (T.rho_KKNN_tab)
    + used_memory_calc (T.Vls_KKNN_tab)
    + used_memory_calc (T.rho_ls_KKNN_tab)  
    + used_memory_calc (T.V0_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.rho_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.Vls_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.rho_ls_KKNN_basis_core_potential_tab)
    + used_memory_calc (T.HO_wfs_uniform)
    + used_memory_calc (T.HO_wfs_GL)
    + used_memory_calc (T.d_tab)
    + used_memory_calc (T.R0_tab)
    + used_memory_calc (T.Vo_tab)
    + used_memory_calc (T.Vso_tab) 
    + used_memory_calc (T.d_basis_tab)
    + used_memory_calc (T.R0_basis_tab)
    + used_memory_calc (T.Vo_basis_tab)
    + used_memory_calc (T.Vso_basis_tab)
    + used_memory_calc (T.shells_quantum_numbers)
    + used_memory_calc (T.shells_quantum_numbers_res)
    + used_memory_calc (T.N_valence_nucleons_in_shell_tab)  
    + used_memory_calc (T.k_bef_tab)
    + used_memory_calc (T.U_finite_range_HF_HO_basis_HO_expansion_part)
    + used_memory_calc (T.Ueq_finite_range_tab_uniform) 
    + used_memory_calc (T.Ueq_finite_range_averaged_tab_uniform)
    + used_memory_calc (T.source_tab_uniform) 
    + used_memory_calc (T.source_averaged_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_res_tab_uniform) 
    + used_memory_calc (T.Ueq_finite_range_res_averaged_tab_uniform)
    + used_memory_calc (T.source_res_tab_uniform) 
    + used_memory_calc (T.source_res_averaged_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_plus_tab_uniform) 
    + used_memory_calc (T.Ueq_finite_range_plus_averaged_tab_uniform)
    + used_memory_calc (T.source_plus_tab_uniform) 
    + used_memory_calc (T.source_plus_averaged_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_minus_tab_uniform) 
    + used_memory_calc (T.Ueq_finite_range_minus_averaged_tab_uniform)
    + used_memory_calc (T.source_minus_tab_uniform) 
    + used_memory_calc (T.source_minus_averaged_tab_uniform)
    + used_memory_calc (T.Ueq_finite_range_tab_GL) 
    + used_memory_calc (T.Ueq_finite_range_averaged_tab_GL)
    + used_memory_calc (T.source_tab_GL) 
    + used_memory_calc (T.source_averaged_tab_GL)
    + used_memory_calc (T.Ueq_finite_range_res_tab_GL) 
    + used_memory_calc (T.Ueq_finite_range_res_averaged_tab_GL)
    + used_memory_calc (T.source_res_tab_GL) 
    + used_memory_calc (T.source_res_averaged_tab_GL)
    + used_memory_calc (T.Ueq_finite_range_plus_tab_GL) 
    + used_memory_calc (T.Ueq_finite_range_plus_averaged_tab_GL)
    + used_memory_calc (T.source_plus_tab_GL) 
    + used_memory_calc (T.source_plus_averaged_tab_GL)
    + used_memory_calc (T.Ueq_finite_range_minus_tab_GL) 
    + used_memory_calc (T.Ueq_finite_range_minus_averaged_tab_GL)
    + used_memory_calc (T.source_minus_tab_GL) 
    + used_memory_calc (T.source_minus_averaged_tab_GL)
    + used_memory_calc (T.Ueq_SGI_MSGI_tab_GL) 
    + used_memory_calc (T.Ueq_SGI_MSGI_res_tab_GL) 
    + used_memory_calc (T.source_SGI_MSGI_tab_GL)
    + used_memory_calc (T.source_SGI_MSGI_res_tab_GL)
    + used_memory_calc (T.Ueq_SGI_MSGI_plus_tab_GL) 
    + used_memory_calc (T.Ueq_SGI_MSGI_minus_tab_GL) 
    + used_memory_calc (T.source_SGI_MSGI_plus_tab_GL)
    + used_memory_calc (T.source_SGI_MSGI_minus_tab_GL)
    + used_memory_calc (T.HO_overlaps) 
    + used_memory_calc (T.HO_overlaps_res) 
    + used_memory_calc (T.HO_overlaps_plus) 
    + used_memory_calc (T.HO_overlaps_minus)
    + used_memory_calc (T.HO_overlaps_Fermi) 
    + used_memory_calc (T.HO_overlaps_Fermi_res) 
    + used_memory_calc (T.HO_overlaps_Fermi_plus) 
    + used_memory_calc (T.HO_overlaps_Fermi_minus)
    + used_memory_calc (T.shells) 
    + used_memory_calc (T.shells_res) 
    + used_memory_calc (T.shells_plus) 
    + used_memory_calc (T.shells_minus)
    + used_memory_calc (T.is_partial_wave_optimized_HF_MSDHF_tab)  
    + used_memory_calc (T.highest_occupied_n_tab)
    + used_memory_calc (T.occupied_pairs)
    + used_memory_calc (T.configurations_to_diagonalize)
    + used_memory_calc (T.dimensions_GS)  
    + used_memory_calc (T.SDp_tab_GS)
    + used_memory_calc (T.SDn_tab_GS)
    + used_memory_calc (T.SDs_GS_coefficients)
    + used_memory_calc (T.SDs_1h)
    + used_memory_calc (T.SDs_1h_coefficients)
    + used_memory_calc (T.SDs_1h_existence_tab)
    + used_memory_calc (T.U_HF_normalizing_sums)
    + used_memory_calc (T.OBMEs_HF_SGI_MSGI)  
    + used_memory_calc (T.b_lab_partial_waves)  
    + used_memory_calc (T.nmin_lj_valence_tab)
    + used_memory_calc (T.shells_OCM_core_states_overlaps)  
    + used_memory_calc (T.php_matrices)
    - (sizeof (T.V0_KKNN_tab) 
       + sizeof (T.rho_KKNN_tab)
       + sizeof (T.Vls_KKNN_tab)
       + sizeof (T.rho_ls_KKNN_tab)  
       + sizeof (T.V0_KKNN_basis_core_potential_tab)
       + sizeof (T.rho_KKNN_basis_core_potential_tab)
       + sizeof (T.Vls_KKNN_basis_core_potential_tab)
       + sizeof (T.rho_ls_KKNN_basis_core_potential_tab)
       + sizeof (T.HO_wfs_uniform)
       + sizeof (T.HO_wfs_GL)
       + sizeof (T.d_tab)
       + sizeof (T.R0_tab)
       + sizeof (T.Vo_tab)
       + sizeof (T.Vso_tab) 
       + sizeof (T.d_basis_tab)
       + sizeof (T.R0_basis_tab)
       + sizeof (T.Vo_basis_tab)
       + sizeof (T.Vso_basis_tab)
       + sizeof (T.shells_quantum_numbers)
       + sizeof (T.shells_quantum_numbers_res)
       + sizeof (T.N_valence_nucleons_in_shell_tab)  
       + sizeof (T.k_bef_tab)
       + sizeof (T.U_finite_range_HF_HO_basis_HO_expansion_part)
       + sizeof (T.Ueq_finite_range_tab_uniform) 
       + sizeof (T.Ueq_finite_range_averaged_tab_uniform)
       + sizeof (T.source_tab_uniform) 
       + sizeof (T.source_averaged_tab_uniform)
       + sizeof (T.Ueq_finite_range_res_tab_uniform) 
       + sizeof (T.Ueq_finite_range_res_averaged_tab_uniform)
       + sizeof (T.source_res_tab_uniform) 
       + sizeof (T.source_res_averaged_tab_uniform)
       + sizeof (T.Ueq_finite_range_plus_tab_uniform) 
       + sizeof (T.Ueq_finite_range_plus_averaged_tab_uniform)
       + sizeof (T.source_plus_tab_uniform) 
       + sizeof (T.source_plus_averaged_tab_uniform)
       + sizeof (T.Ueq_finite_range_minus_tab_uniform) 
       + sizeof (T.Ueq_finite_range_minus_averaged_tab_uniform)
       + sizeof (T.source_minus_tab_uniform) 
       + sizeof (T.source_minus_averaged_tab_uniform)
       + sizeof (T.Ueq_finite_range_tab_GL) 
       + sizeof (T.Ueq_finite_range_averaged_tab_GL)
       + sizeof (T.source_tab_GL) 
       + sizeof (T.source_averaged_tab_GL)
       + sizeof (T.Ueq_finite_range_res_tab_GL) 
       + sizeof (T.Ueq_finite_range_res_averaged_tab_GL)
       + sizeof (T.source_res_tab_GL) 
       + sizeof (T.source_res_averaged_tab_GL)
       + sizeof (T.Ueq_finite_range_plus_tab_GL) 
       + sizeof (T.Ueq_finite_range_plus_averaged_tab_GL)
       + sizeof (T.source_plus_tab_GL) 
       + sizeof (T.source_plus_averaged_tab_GL)
       + sizeof (T.Ueq_finite_range_minus_tab_GL) 
       + sizeof (T.Ueq_finite_range_minus_averaged_tab_GL)
       + sizeof (T.source_minus_tab_GL) 
       + sizeof (T.source_minus_averaged_tab_GL)
       + sizeof (T.Ueq_SGI_MSGI_tab_GL) 
       + sizeof (T.Ueq_SGI_MSGI_res_tab_GL) 
       + sizeof (T.source_SGI_MSGI_tab_GL)
       + sizeof (T.source_SGI_MSGI_res_tab_GL)
       + sizeof (T.Ueq_SGI_MSGI_plus_tab_GL) 
       + sizeof (T.Ueq_SGI_MSGI_minus_tab_GL) 
       + sizeof (T.source_SGI_MSGI_plus_tab_GL)
       + sizeof (T.source_SGI_MSGI_minus_tab_GL)
       + sizeof (T.HO_overlaps) 
       + sizeof (T.HO_overlaps_res) 
       + sizeof (T.HO_overlaps_plus) 
       + sizeof (T.HO_overlaps_minus)
       + sizeof (T.HO_overlaps_Fermi) 
       + sizeof (T.HO_overlaps_Fermi_res) 
       + sizeof (T.HO_overlaps_Fermi_plus) 
       + sizeof (T.HO_overlaps_Fermi_minus)
       + sizeof (T.shells) 
       + sizeof (T.shells_res) 
       + sizeof (T.shells_plus) 
       + sizeof (T.shells_minus)
       + sizeof (T.is_partial_wave_optimized_HF_MSDHF_tab)  
       + sizeof (T.highest_occupied_n_tab)
       + sizeof (T.occupied_pairs)
       + sizeof (T.configurations_to_diagonalize)
       + sizeof (T.dimensions_GS)  
       + sizeof (T.SDp_tab_GS)
       + sizeof (T.SDn_tab_GS)
       + sizeof (T.SDs_GS_coefficients)
       + sizeof (T.SDs_1h)
       + sizeof (T.SDs_1h_coefficients)
       + sizeof (T.SDs_1h_existence_tab)
       + sizeof (T.U_HF_normalizing_sums)
       + sizeof (T.OBMEs_HF_SGI_MSGI)  
       + sizeof (T.b_lab_partial_waves)  
       + sizeof (T.nmin_lj_valence_tab)
       + sizeof (T.shells_OCM_core_states_overlaps)  
       + sizeof (T.php_matrices))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;    
}
