#include "../GSM_include/GSM_include_def_common.h"

using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace complex_scaling_radial_OBMEs;

// TYPE is double or complex
// -------------------------

// H_CM_OBMEs means that one calculates here one-body matrix elements associated to the Hamiltonian and center of mass operators


// Calculation of Coulomb potential matrix element with complex scaling
// --------------------------------------------------------------------
// One uses the method of N. Michel, Phys. Rev. C 83, 034325 (2011)
//
// The initial Coulomb potential Vc(inter) = Vc + Vc_HO is separated in two parts,
// Vc_HO being expanded with the HO basis and Vc being an analytical infinite-range Coulomb potential (see GSM_Coulomb_potential.cpp).
// The Vc_HO is treated with matrix methods using the HO expansion of the in and out shells and hence is standard.
// <wf_in | Vc | wf_out> have to belong the same partial wave otherwise it is zero.
//
// If one state in <wf_in | Vc | wf_out> is a pole or if wf_in and wf_out are different, 
// one can apply complex scaling directly as one can always find angles so that integrals converge (see GSM_complex_scaling_radial_OBMEs.cpp).
//
// If one calculates <wf | Vc | wf> with wf scattering, 
// it diverges if one applies complex scaling directly as the integral of Vc(r) diverges as log (r) for one the integrals entering complex scaling (see GSM_complex_scaling_radial_OBMEs.cpp).
// Hence, one replaces <wf | Vc | wf> by <wf+ | Vc | wf->, for which k become k+ = k + w/(4 Pi) and k- = k - w/(4 Pi), where w is the Gauss-Legendre weight associated to k.
// One can apply complex scaling directly to <wf+ | Vc | wf->. The efficiency of the method is demonstrated in  N. Michel, Phys. Rev. C 83, 034325 (2011).

TYPE H_CM_OBMEs::OBME_H_Coulomb_part_calc (
					   const unsigned int s_in , 
					   const unsigned int s_out , 
					   const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab ,
					   const class baryons_data &data)
{  
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling in H_CM_OBMEs::OBME_H_Coulomb_part_calc");

  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);

  if (!same_lj_particle (wf_in , wf_out)) return 0.0;
  
  const enum particle_type B_in = wf_in.get_particle ();
  const enum particle_type B_out = wf_out.get_particle ();
  
  if (B_in != B_out) return 0.0;
	
  const enum particle_type particle = B_in;

  const int particle_charge = particle_charge_determine (particle);
  
  if (particle_charge == 0) return 0.0;
  
  const bool good_isospin_basis_potential = data.get_good_isospin_basis_potential ();
  
  const int ZY_charge_pos = data.get_ZY_charge_pos () , ZY_charge_basis_potential_pos = data.get_ZY_charge_basis_potential_pos ();
  const int ZY_charge_neg = data.get_ZY_charge_neg () , ZY_charge_basis_potential_neg = data.get_ZY_charge_basis_potential_neg ();
  
  const int ZY_charge = (particle_charge > 0) ? (ZY_charge_pos) : (ZY_charge_neg);
  
  const int ZY_charge_basis_potential = (particle_charge > 0) ? (ZY_charge_basis_potential_pos) : (ZY_charge_basis_potential_neg);
  
  const int ZY_charge_to_consider = (good_isospin_basis_potential) ? (ZY_charge) : (ZY_charge_basis_potential);
  
  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis = V_Coulomb_HO_basis_tab(particle_index);
        
  const class array<class spherical_state> &shells_plus = data.get_shells_plus ();
  const class array<class spherical_state> &shells_minus = data.get_shells_minus ();

  const int l = wf_in.get_l ();

  const int n_in = wf_in.get_n ();
  const int n_out = wf_out.get_n ();

  const double j = wf_in.get_j ();
      
  const double R_charge = data.get_R_charge ();

  const bool S_matrix_pole_in  = wf_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = wf_out.get_S_matrix_pole ();

  const class spherical_state &wf_plus  = (S_matrix_pole_in) ? (wf_in) : (shells_plus(s_in));
  const class spherical_state &wf_minus = (S_matrix_pole_in) ? (wf_in) : (shells_minus(s_in));
		
  const complex<double> OBME_ZY_charge_to_consider = (S_matrix_pole_in || S_matrix_pole_out || (n_in != n_out)) 
    ? (radial_integral_calc (ONE_BODY_COULOMB_RADIAL , ZY_charge_to_consider , R_charge , wf_in   , wf_out)) 
    : (radial_integral_calc (ONE_BODY_COULOMB_RADIAL , ZY_charge_to_consider , R_charge , wf_plus , wf_minus));

  const class array<class vector_class<complex<double> > > &HO_overlaps_basis = data.get_HO_overlaps_basis ();
      
  const class vector_class<complex<double> > &HO_overlaps_basis_in  = HO_overlaps_basis(s_in);
  const class vector_class<complex<double> > &HO_overlaps_basis_out = HO_overlaps_basis(s_out);
      
  const class matrix<complex<double> > &V_Coulomb_HO_basis_lj = V_Coulomb_HO_basis(l , j);
      
  const complex<double> V_Coulomb_HO_ZYval_charge_basis_OBME = HO_overlaps_basis_out*(V_Coulomb_HO_basis_lj*HO_overlaps_basis_in);

  const complex<double> OBME_Coulomb_potential = OBME_ZY_charge_to_consider - V_Coulomb_HO_ZYval_charge_basis_OBME;
      
#ifdef TYPEisDOUBLECOMPLEX
  return OBME_Coulomb_potential;
#endif
      
#ifdef TYPEisDOUBLE
  return real (OBME_Coulomb_potential);
#endif
}





// Calculation of Coulomb potential matrix element for bound states
// ----------------------------------------------------------------
// The initial Coulomb potential Vc(inter) = Vc + Vc_HO is separated in two parts,
// Vc_HO being expanded with the HO basis and Vc being an analytical infinite-range Coulomb potential (see GSM_Coulomb_potential.cpp).
// The Vc_HO is treated with matrix methods using the HO expansion of the in and out shells and hence is standard.
// <wf_in | Vc | wf_out> have to belong to the same partial wave otherwise it is zero.
// <wf_in | Vc | wf_out> is calculated by direct integration on the real axis as it always converges due to the use of bound states.

TYPE H_CM_OBMEs::OBME_H_Coulomb_part_bound_calc (
						 const unsigned int s_in , 
						 const unsigned int s_out , 
						 const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab ,
						 const class baryons_data &data) 
{
  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);
    
  if (!same_lj_particle (wf_in , wf_out)) return 0.0;
  
  const enum particle_type particle = wf_in.get_particle ();

  const int particle_charge = particle_charge_determine (particle);
  
  if (particle_charge == 0) return 0.0;
  
  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis = V_Coulomb_HO_basis_tab(particle_index);
  
  const bool good_isospin_basis_potential = data.get_good_isospin_basis_potential ();
  
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  const int ZY_charge_pos = data.get_ZY_charge_pos () , ZY_charge_basis_potential_pos = data.get_ZY_charge_basis_potential_pos ();
  const int ZY_charge_neg = data.get_ZY_charge_neg () , ZY_charge_basis_potential_neg = data.get_ZY_charge_basis_potential_neg ();

  const int ZY_charge = (particle_charge > 0) ? (ZY_charge_pos) : (ZY_charge_neg);
  
  const int ZY_charge_basis_potential = (particle_charge > 0) ? (ZY_charge_basis_potential_pos) : (ZY_charge_basis_potential_neg);
  
  const int ZY_charge_to_consider = (good_isospin_basis_potential) ? (ZY_charge) : (ZY_charge_basis_potential);
      
  const int l = wf_in.get_l ();

  const double j = wf_in.get_j ();

  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();
  
  const double R_charge = data.get_R_charge ();
  
  const complex<double> exp_I_theta_H_complex_scaled = data.get_exp_I_theta_H_complex_scaled ();
      
  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL () , &r_aft_R_tab_GL = wf_in.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL () , &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL_real ();

  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL ()  , &wf_in_aft_R_tab_GL  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL () , &wf_out_aft_R_tab_GL = wf_out.get_wf_aft_R_tab_GL_real ();

  const class Coulomb_potential_class Coulomb_potential(false , particle , ZY_charge_to_consider , R_charge);
  
  complex<double> OBME_Coulomb_potential = 0.0;
      
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);
	    
      const complex<double> Vc_r = (is_Hamiltonian_complex_scaled) ? (Coulomb_potential.analytic_potential_calc (r*exp_I_theta_H_complex_scaled)) : (Coulomb_potential.analytic_potential_calc (r));

      const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

      OBME_Coulomb_potential += wf_in_r*Vc_r*wf_out_r*w;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double r = r_aft_R_tab_GL(i);
      const double w = w_aft_R_tab_GL(i);

      const complex<double> Vc_r = (is_Hamiltonian_complex_scaled) ? (Coulomb_potential.analytic_potential_calc (r*exp_I_theta_H_complex_scaled)) : (Coulomb_potential.analytic_potential_calc (r));

      const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

      OBME_Coulomb_potential += wf_in_r*Vc_r*wf_out_r*w;
    }
  
  const class array<class vector_class<complex<double> > > &HO_overlaps_basis = data.get_HO_overlaps_basis ();
  
  const class vector_class<complex<double> > &HO_overlaps_basis_in  = HO_overlaps_basis(s_in);
  const class vector_class<complex<double> > &HO_overlaps_basis_out = HO_overlaps_basis(s_out); 

  const class matrix<complex<double> > &V_Coulomb_HO_basis_lj = V_Coulomb_HO_basis(l , j);

  OBME_Coulomb_potential -= HO_overlaps_basis_out*(V_Coulomb_HO_basis_lj*HO_overlaps_basis_in);
  
#ifdef TYPEisDOUBLECOMPLEX
  return OBME_Coulomb_potential;
#endif
      
#ifdef TYPEisDOUBLE
  return real (OBME_Coulomb_potential);
#endif
}





















// Calculation of one one-body matrix element of the HO center of mass Hamiltonian Hcm
// -----------------------------------------------------------------------------------
// One uses the exact value equal to (2n + l).hbar omega.(m/M) for identical HO states for the in and out states. It is zero otherwise.
// One multiplies by m/M, with m the mass of a nucleon and M the mass of the nucleus as hbar omega is that of nucleon and hbar omega.(m/M) is that of the center of mass.
// Otherwise, one uses HO expansion of the Hcm operator using that previous value for each HO component.
// The matrix element is put to zero if one has only one nucleon or if the partial waves of the in and out states are different.

TYPE H_CM_OBMEs::OBME_Hcm_calc (
				const unsigned int s_in , 
				const unsigned int s_out , 
				const class interaction_class &inter_data_basis , 
				const class baryons_data &data)
{ 
  const int A = data.get_A ();

  if (A == 1) return 0.0;
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
  
  const class nlj_struct &shell_qn_in = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);
  
  if (!same_lj_particle (shell_qn_in , shell_qn_out)) return 0.0;

  const bool is_it_HO = shell_qn_in.get_is_it_HO ();

  const int l = shell_qn_in.get_l ();

  const double j = shell_qn_in.get_j ();

  const int n_in  = shell_qn_in.get_n ();
  const int n_out = shell_qn_out.get_n ();
  
  const enum particle_type particle = shell_qn_in.get_particle ();

  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class array<class lj_table<double> > &b_lab_partial_waves_tab = data.get_b_partial_waves_tab ();  
  
  const class lj_table<double> &b_lab_partial_waves = b_lab_partial_waves_tab(particle_index);
  
  const double m = effective_masses_for_calc (particle_index);

  const double M = data.get_nucleus_mass ();

  if (is_it_HO)
    {
      const double b_lab = b_lab_partial_waves(l , j);
      
      const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , m , b_lab);
      
      const double hbar_omega_m_over_M = hbar_omega*m/M;
      
      const TYPE OBME_Hcm = (n_in == n_out) ? ((2*n_in + l)*hbar_omega_m_over_M) : (0.0);

      return OBME_Hcm;
    }
  else
    {
      const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
      if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling with other states as HO states in H_CM_OBMEs::OBME_Hcm_calc");

      const int lmax_for_basis_interaction = inter_data_basis.get_lmax_for_interaction ();

      if (l > lmax_for_basis_interaction) return 0.0;

      const double b_lab = inter_data_basis.get_b_lab ();
      
      const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , m , b_lab);
      
      const double hbar_omega_m_over_M = hbar_omega*m/M;
      
      const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();
      
      const int nmax_HO_l = nmax_HO_lab_tab(l);

      const class array<class vector_class<complex<double> > > &HO_overlaps_basis = data.get_HO_overlaps_basis ();
      
      const class vector_class<complex<double> > &HO_overlaps_basis_in  = HO_overlaps_basis(s_in);
      const class vector_class<complex<double> > &HO_overlaps_basis_out = HO_overlaps_basis(s_out);
      
      complex<double> OBME_Hcm = 0.0;

      for (int n = 0 ; n <= nmax_HO_l ; n++) OBME_Hcm += HO_overlaps_basis_in(n)*HO_overlaps_basis_out(n)*(2*n + l);

      OBME_Hcm *= hbar_omega_m_over_M;
      
#ifdef TYPEisDOUBLECOMPLEX
      return OBME_Hcm;
#endif
      
#ifdef TYPEisDOUBLE
      return real (OBME_Hcm);
#endif
    }
}






// Calculation of one one-body matrix element of the rms radius operator
// ---------------------------------------------------------------------
// The one-body matrix elements of the rms radius operator are of the form rms_radius_one_body_factor x r^2 (see observables_basic_functions.cpp).
// They are calculated here using the direct formula, hence for bound states in practice, or using the HO expansion method.

TYPE H_CM_OBMEs::OBME_rms_radius_not_normed_calc (
						  const bool is_it_only_basis , 
						  const bool is_it_HO_expansion , 
						  const unsigned int s_in , 
						  const unsigned int s_out , 
						  const class interaction_class &inter_data_basis , 
						  const class array<TYPE> &r2_HO_tab , 
						  const class baryons_data &data)
{ 
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class nlj_table<unsigned int> &shells_HO_indices = inter_data_basis.get_shells_HO_indices ();
  
  const class array<class vector_class<complex<double> > > &HO_overlaps = (is_it_only_basis) ? (data.get_HO_overlaps_basis ()) : (data.get_HO_overlaps ());
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class array<class spherical_state> &shells = data.get_shells ();

  const class nlj_struct &shell_qn_in  = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);

  if (!same_lj_particle (shell_qn_in , shell_qn_out)) return 0.0;
  
  const int lmax_for_interaction = inter_data_basis.get_lmax_for_interaction ();

  const int l = shell_qn_in.get_l ();

  if (l > lmax_for_interaction) return 0.0;
  
  const double j = shell_qn_in.get_j ();
  
  if (is_it_HO_expansion)
    {
      const class vector_class<complex<double> > &HO_overlaps_in = HO_overlaps(s_in);
      const class vector_class<complex<double> > &HO_overlaps_out = HO_overlaps(s_out);

      const int nmax_HO_l = nmax_HO_lab_tab(l);
	  
      complex<double> OBME = 0.0;
	  
      for (int na = 0 ; na <= nmax_HO_l ; na++)
	for (int nb = 0 ; nb <= nmax_HO_l ; nb++)
	  {
	    const unsigned int sa = shells_HO_indices(na , l , j);
	    const unsigned int sb = shells_HO_indices(nb , l , j);

	    const complex<double> HO_overlaps_product = HO_overlaps_in(na)*HO_overlaps_out(nb);
	    
	    const complex<double> r2_HO_ME = r2_HO_tab(sa , sb);
		
	    OBME += HO_overlaps_product*r2_HO_ME;
	  }
      
#ifdef TYPEisDOUBLECOMPLEX
      return OBME;
#endif
      
#ifdef TYPEisDOUBLE
      return real (OBME);
#endif
    }
  else
    {  
      const class spherical_state &wf_in  = shells(s_in);
      const class spherical_state &wf_out = shells(s_out);

      const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

      const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
      const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();

      const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL (); 
      const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();

      complex<double> OBME = 0.0;

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i);

	  const double r2 = r*r;

	  OBME += w*r2*wf_out_bef_R_tab_GL(i)*wf_in_bef_R_tab_GL(i);
	}
      
#ifdef TYPEisDOUBLECOMPLEX
      return OBME;
#endif
      
#ifdef TYPEisDOUBLE
      return real (OBME);
#endif
    }
}






// Calculation of one reduced one-body matrix element of the HO center of mass orbital angular momentum component L+, L- or Lz
// ---------------------------------------------------------------------------------------------------------------------------
// One uses the exact value equal to <j_out || l || j_in> (m/M) for HO states of same radial and orbital angular parts for the in and out states. They must bear the same HO length. It is zero otherwise.
// One multiplies by m/M, with m the mass of a nucleon and M the mass of the nucleus as as one considers a center of mass operator.
// Otherwise, one uses HO expansion of the L+, L- or Lz operator using that previous value for each HO component.
// The matrix element is put to zero if one has only one nucleon or if the orbital angular momenta of the in and out states are different.
// Even though the radial operator is an overlap, HO expansion is necessary as in and out states can belong to different bases, so that their total angular momentum can be different.
// Complex sclaing cannot be used with different partial waves in the general case, as basis-generating potentials can be different.
// Moreover, it makes no difference as HO expansion is necessary for the two-body part of L+, L- or Lz operators when the Berggren basis is used.

TYPE H_CM_OBMEs::reduced_OBME_L_CM_calc (
					 const unsigned int s_in , 
					 const unsigned int s_out , 
					 const class baryons_data &data)
{
  const int A = data.get_A ();

  if (A == 1) return 0.0;
		
  const double nucleus_mass = data.get_nucleus_mass (); 

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
  
  const class nlj_struct &shell_qn_in  = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);

  const enum particle_type B_in = shell_qn_in.get_particle ();
  const enum particle_type B_out = shell_qn_out.get_particle ();
  
  if (B_in != B_out) return 0.0;
	    
  const int l_in  = shell_qn_in.get_l ();
  const int l_out = shell_qn_out.get_l ();

  if (l_in != l_out) return 0.0;
    
  const unsigned int B_index = charge_baryon_index_determine (B_in);
  
  const double j_in  = shell_qn_in.get_j ();
  const double j_out = shell_qn_out.get_j ();

  const double baryon_mass_for_calc = effective_masses_for_calc (B_index);
  
  const double mass_ratio = baryon_mass_for_calc/nucleus_mass;

  const double OBME_angular_part = OBME_l_reduced_in_j (l_in , j_in , l_out , j_out);

  const bool is_it_HO_in  = shell_qn_in.get_is_it_HO ();
  const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();
  
  const class array<class lj_table<double> > &b_lab_partial_waves_tab = data.get_b_partial_waves_tab ();

  const class lj_table<double> &b_lab_partial_waves = b_lab_partial_waves_tab(B_index);
  
  const double b_lab_in  = b_lab_partial_waves(l_in , j_in);
  const double b_lab_out = b_lab_partial_waves(l_out , j_out);
  
  if (same_lj_particle (shell_qn_in , shell_qn_out) || (is_it_HO_in && is_it_HO_out && (abs (b_lab_in - b_lab_out) < precision)))
    {
      const int n_in  = shell_qn_in.get_n ();
      const int n_out = shell_qn_out.get_n ();
      
      const double overlap = (n_in == n_out) ? (1.0) : (0.0);
      
      const double reduced_OBME = OBME_angular_part*overlap*mass_ratio;

      return reduced_OBME;
    }
  else
    {
      const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
      if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling with other states as HO states or with different HO lengths in H_CM_OBMEs::reduced_OBME_L_CM_calc");

      const class array<class vector_class<complex<double> > > &HO_overlaps = data.get_HO_overlaps ();
      
      const class vector_class<complex<double> > &HO_overlaps_in  = HO_overlaps(s_in);
      const class vector_class<complex<double> > &HO_overlaps_out = HO_overlaps(s_out);
      
      const complex<double> OBME_radial_part = HO_overlaps_in*HO_overlaps_out;
      
      const complex<double> reduced_OBME = OBME_angular_part*OBME_radial_part*mass_ratio;
      
#ifdef TYPEisDOUBLECOMPLEX
      return reduced_OBME;
#endif
      
#ifdef TYPEisDOUBLE
      return real (reduced_OBME);
#endif
    }
}






// Calculation of one reduced one-body matrix element of the quantum creation-annihilation center of mass components A+[CM-HO][+1], A+[CM-HO][-1] or A+[CM-HO][0] given as spherical components
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One has A+[CM-HO] = sqrt (M omega/(2 hbar)) (R - i.P/(M omega))
// Matrix elements are then equal to 1/sqrt (2) . (<b || r || a>/(b/sqrt (nucleon_mass/nucleus_mass)) - <b || grad || a> . (b/sqrt (nucleon_mass/nucleus_mass))) .
// Matrix elements <b || r || a>/(b/sqrt (nucleon_mass/nucleus_mass)) and <b || grad || a> . (b/sqrt (nucleon_mass/nucleus_mass)) have been already calculated.
// They are the same for all A+[CM-HO][+1], A+[CM-HO][-1] or A+[CM-HO][0] spherical components, so that the routine is called once for the A+[CM-HO] vector operator, even though the latter is not called.

TYPE H_CM_OBMEs::reduced_OBME_A_dagger_CM_HO_calc (
						   const unsigned int s_in , 
						   const unsigned int s_out , 
						   const class baryons_data &data)
{
  const class OBMEs_CM_set_str &reduced_grad_set = data.get_reduced_grad_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_r_set    = data.get_reduced_r_HO_expansion_set ();
  
  const class array<TYPE> &reduced_grad_A_dagger_CM_HO = reduced_grad_set(A_DAGGER_CM_HO_REDUCED_TENSOR);
  const class array<TYPE> &reduced_r_A_dagger_CM_HO    = reduced_r_set   (A_DAGGER_CM_HO_REDUCED_TENSOR);

  const TYPE reduced_grad_A_dagger_CM_HO_OBME = reduced_grad_A_dagger_CM_HO(s_in , s_out);
  const TYPE reduced_r_A_dagger_CM_HO_OBME    = reduced_r_A_dagger_CM_HO   (s_in , s_out);
  
  const TYPE OBME = M_SQRT1_2*(reduced_r_A_dagger_CM_HO_OBME - reduced_grad_A_dagger_CM_HO_OBME);

  return OBME;
}







// Calculation of one one-body matrix element of the kinetic one-body operator
// ---------------------------------------------------------------------------
// One calculates the matrix element of p^2/2m. 
// It is zero unless the in and out states belong to the same partial wave.
// One uses its exact value for HO states (see HO_wave_functions.cpp).
// If one has a core potential, as is the case except for two-body interactions given on file (FIT and FIT-COSM) and realistic interactions,
// one uses the matrix element of the core p^2/2m + U_core, coded in OBME_core_Hcm_calc, from which one removes the matrix element of the core part U_core, which is finite-ranged and hence does not need complex scaling.
// If one uses realistic interations, with which there is no core, OBME_core_Hcm_calc provides directly with p^2/2m, which is the returned value.
// If one uses two-body interactions given on file (FIT and FIT-COSM), one uses the HO expansion.

TYPE H_CM_OBMEs::OBME_kinetic_calc (
				    const class interaction_class &inter_data_basis , 
				    const unsigned int s_in , 
				    const unsigned int s_out , 
				    const class baryons_data &neut_Y_data_like , 
				    const class baryons_data &data)
{     
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling in H_CM_OBMEs::OBME_kinetic_calc");

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab = inter_data_basis.get_V_Coulomb_HO_basis_tab ();

  if (TBME_inter == FIT)
    {           
      const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
  
      const class array<class spherical_state> &shells = data.get_shells ();
  
      const class spherical_state &wf_in  = shells(s_in);
      const class spherical_state &wf_out = shells(s_out);

      if (!same_lj_particle (wf_in , wf_out)) return 0.0;
  
      const int l = wf_in.get_l ();

      const double j = wf_in.get_j ();
      
      const int n_in = wf_in.get_n ();

      const int n_out = wf_out.get_n ();
      
      const enum particle_type particle = wf_in.get_particle ();

      const unsigned int particle_index = charge_baryon_index_determine (particle);
  
      const class array<class lj_table<double> > &b_lab_partial_waves_tab = data.get_b_partial_waves_tab ();  
  
      const class lj_table<double> &b_lab_partial_waves = b_lab_partial_waves_tab(particle_index);
  
      const double nucleus_mass_basis = data.get_nucleus_mass_basis ();
  
      const double b_lj = b_lab_partial_waves(l , j);

      const double mass_modif = (!is_it_COSM) ? (-nucleus_mass_basis) : (nucleus_mass_basis);

      const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);
  
      const double hbar_omega_lj = HO_wave_functions::hbar_omega_calc (false , mass_modif , baryon_mass_for_calc , b_lj);
            
      const class array<class vector_class<complex<double> > > &HO_overlaps_basis = data.get_HO_overlaps_basis ();
      
      const class vector_class<complex<double> > &HO_overlaps_basis_in  = HO_overlaps_basis(s_in);
      const class vector_class<complex<double> > &HO_overlaps_basis_out = HO_overlaps_basis(s_out);

      const unsigned int nmax_HO_lj = HO_overlaps_basis_in.get_dimension () - 1;
      
      const unsigned int nmax_HO_lj_plus_one = nmax_HO_lj + 1;
      
      const class matrix<complex<double> > kinetic_HO_basis_lj(nmax_HO_lj_plus_one);

      for (unsigned int n_HO_in = 0 ; n_HO_in <= nmax_HO_lj ; n_HO_in++)
	for (unsigned int n_HO_out = 0 ; n_HO_out <= nmax_HO_lj ; n_HO_out++)
	  kinetic_HO_basis_lj(n_HO_in , n_HO_out) = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n_in , n_out , hbar_omega_lj);
      
      const complex<double> OBME = HO_overlaps_basis_out*(kinetic_HO_basis_lj*HO_overlaps_basis_in);
      
#ifdef TYPEisDOUBLECOMPLEX
      return OBME;
#endif
      
#ifdef TYPEisDOUBLE
      return real (OBME);
#endif
    }
  else
    {
      const TYPE OBME_core = OBME_core_Hcm_calc (is_it_COSM , neut_Y_data_like , 0.0 , s_in , s_out , inter_data_basis , data);

      const enum potential_type H_potential = data.get_H_potential ();
      
      const TYPE OBME_nuclear_potential_H = OBME_nuclear_potential_calc (false , false , H_potential , s_in , s_out , data , data);
      
      const TYPE OBME_Coulomb_potential_H = OBME_H_Coulomb_part_calc (s_in , s_out , V_Coulomb_HO_basis_tab , data);
      
      const TYPE OBME_potential_H = OBME_nuclear_potential_H + OBME_Coulomb_potential_H;
      
      const TYPE OBME = OBME_core - OBME_potential_H; 
      
      return OBME;
    }
}






// Calculation of one one-body matrix element of the kinetic one-body operator for bound states
// --------------------------------------------------------------------------------------------
// One calculates the matrix element of p^2/2m for bound states.
// It is zero unless the in and out states belong to the same partial wave.
// One uses its exact value for HO states (see HO_wave_functions.cpp).
// The A=1 case is considered meaningful only with the HO basis and realistic interations and if the number of nucleons of the nucleus in basis and Hamiltonian is the same if this routine is used.
// Otherwise, one uses the direct formula as p^2 = -d^2/dr^2 + l(l+1)/r^2. 
// The matrix element is symmetrized to avoid non-symmetric matrix elements due to numerical precision and the use of d/^2dr^2.

TYPE H_CM_OBMEs::OBME_kinetic_bound_calc (
					  const class interaction_class &inter_data_basis , 
					  const unsigned int s_in , 
					  const unsigned int s_out , 
					  const class baryons_data &neut_Y_data_like ,
					  const class baryons_data &data)
{
  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
      
  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);
  
  if (!same_lj_particle (wf_in , wf_out)) return 0.0;
      
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
      
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
      
  const enum particle_type particle = wf_in.get_particle ();

  const int particle_charge = particle_charge_determine (particle);

  const bool is_it_charged = (particle_charge != 0);
      
  const unsigned int particle_index = charge_baryon_index_determine (particle);
      
  const int A = data.get_A ();
  
  const int A_basis = data.get_A_basis ();

  const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);
  
  const int l = wf_in.get_l ();
  
  const double j = wf_in.get_j ();
  
  if (A == 1)
    {    
      const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
      
      const class nlj_struct &shell_qn_in  = shells_qn(s_in);
      const class nlj_struct &shell_qn_out = shells_qn(s_out);

      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
      const bool is_it_HO_in  = shell_qn_in.get_is_it_HO ();
      const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();

      if (!is_it_HO_in || !is_it_HO_out || (A_basis != 1) || !is_it_realistic_interaction (TBME_inter))
	error_message_print_abort ("One-nucleon nuclei are meaningful only with realistic interactions, non-complex scaled Hamiltonians, HO basis and A_basis equal to 1 in H_CM_OBMEs::OBME_kinetic_bound_calc");

      const class array<class lj_table<double> > &b_lab_partial_waves_tab = data.get_b_partial_waves_tab ();  
  
      const class lj_table<double> &b_lab_partial_waves = b_lab_partial_waves_tab(particle_index);
  
      const int n_in = wf_in.get_n ();	
      const int n_out = wf_out.get_n ();
	    
      const double b_lab = b_lab_partial_waves(l , j);
	
      const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , baryon_mass_for_calc , b_lab);

      TYPE OBME_kinetic = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n_in , n_out , hbar_omega) - 0.75*hbar_omega; // One removes 3/4 hbar omega for the intrinsic energy of 0s1/2 to be zero
      
      if (is_Hamiltonian_complex_scaled)
	{
	  const TYPE exp_minus_two_I_theta_H_complex_scaled = data.get_exp_minus_two_I_theta_H_complex_scaled ();
	  
	  OBME_kinetic *= exp_minus_two_I_theta_H_complex_scaled;
	}

      return OBME_kinetic;
    }
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const bool good_isospin_basis_potential = data.get_good_isospin_basis_potential ();
        
  const double nucleus_mass_for_recoil       = data.get_nucleus_mass ();
  const double nucleus_mass_for_recoil_basis = data.get_nucleus_mass_basis ();

  const double initial_baryon_mass_for_calc_inv = 1.0/baryon_mass_for_calc;
    
  const enum particle_type uncharged_particle = uncharged_baryon_multiplet_determine (particle);
  
  const unsigned int uncharged_particle_index = charge_baryon_index_determine (uncharged_particle);
  
  const class array<double> &effective_masses_for_calc_n = neut_Y_data_like.get_effective_masses_for_calc ();
  
  const double uncharged_particle_mass_for_calc = effective_masses_for_calc_n(uncharged_particle_index);

  const double uncharged_particle_mass_for_calc_inv = 1.0/uncharged_particle_mass_for_calc;
    
  const double baryon_mass_for_calc_inv = (is_it_charged) ? (initial_baryon_mass_for_calc_inv) : (uncharged_particle_mass_for_calc_inv);
  
  const double baryon_mass_basis_for_calc_inv = (good_isospin_basis_potential) ? (uncharged_particle_mass_for_calc_inv) : (initial_baryon_mass_for_calc_inv);

  const double nucleus_mass_inv_recoil       = (nucleus_mass_for_recoil       != 0.0) ? (1.0/nucleus_mass_for_recoil)       : (0.0);
  const double nucleus_mass_inv_basis_recoil = (nucleus_mass_for_recoil_basis != 0.0) ? (1.0/nucleus_mass_for_recoil_basis) : (0.0);

  const double mass_ratio_real_inter = (baryon_mass_for_calc_inv - nucleus_mass_inv_recoil)/(baryon_mass_basis_for_calc_inv - nucleus_mass_inv_basis_recoil);
  
  const double mass_ratio_COSM = (baryon_mass_for_calc_inv + nucleus_mass_inv_recoil)/(baryon_mass_basis_for_calc_inv + nucleus_mass_inv_basis_recoil);

  const double mass_ratio = (!is_it_COSM) ? (mass_ratio_real_inter) : (mass_ratio_COSM);

  const double kinetic_factor = wf_in.get_kinetic_factor ();
  
  const int ll_plus_one = l*(l + 1);

  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();
    
  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL () , &r_aft_R_tab_GL = wf_in.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL () , &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL_real ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL  () , &wf_in_aft_R_tab_GL  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL () , &wf_out_aft_R_tab_GL = wf_out.get_wf_aft_R_tab_GL_real ();
  
  const class array<complex<double> > &d2wf_in_bef_R_tab_GL  = wf_in.get_d2wf_bef_R_tab_GL  () , &d2wf_in_aft_R_tab_GL  = wf_in.get_d2wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &d2wf_out_bef_R_tab_GL = wf_out.get_d2wf_bef_R_tab_GL () , &d2wf_out_aft_R_tab_GL = wf_out.get_d2wf_aft_R_tab_GL_real ();
  
  complex<double> OBME_kinetic = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double r2 = r*r;
      
      const double half_w = 0.5*w;

      const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i)  , d2wf_in_r  = d2wf_in_bef_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i) , d2wf_out_r = d2wf_out_bef_R_tab_GL(i);

      OBME_kinetic += wf_out_r*(-d2wf_in_r  + ll_plus_one*wf_in_r /r2)*half_w;
      OBME_kinetic += wf_in_r *(-d2wf_out_r + ll_plus_one*wf_out_r/r2)*half_w;
    }
  
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double r = r_aft_R_tab_GL(i);
      const double w = w_aft_R_tab_GL(i);

      const double r2 = r*r;

      const double half_w = 0.5*w;
      
      const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i)  , d2wf_in_r  = d2wf_in_aft_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i) , d2wf_out_r = d2wf_out_aft_R_tab_GL(i);

      OBME_kinetic += wf_out_r*(-d2wf_in_r  + ll_plus_one*wf_in_r /r2)*half_w;
      OBME_kinetic += wf_in_r *(-d2wf_out_r + ll_plus_one*wf_out_r/r2)*half_w;
    }
  
  OBME_kinetic *= mass_ratio/kinetic_factor;

  if (is_Hamiltonian_complex_scaled)
    {
      const TYPE exp_minus_two_I_theta_H_complex_scaled = data.get_exp_minus_two_I_theta_H_complex_scaled ();

      OBME_kinetic *= exp_minus_two_I_theta_H_complex_scaled;
    }
  
#ifdef TYPEisDOUBLECOMPLEX
  return OBME_kinetic;
#endif
      
#ifdef TYPEisDOUBLE
  return real (OBME_kinetic);
#endif
}








// Calculation of one one-body matrix element of the kinetic center of mass operator for the general case and bound state case
// ---------------------------------------------------------------------------------------------------------------------------
// The center of mass kinetic operator is the standard definition P^2/2M = \sum_i (p_i^2/2M + \sum_{i<j} {(pi.pj)/M) if does not use COSM, with M the mass of the nucleus.
// Its one-body matrix elements are then those of p^2/2M, calculated from OBME_kinetic_calc or OBME_kinetic_bound_calc and then replacing the nucleon mass by the nucleus mass. 
// If one uses COSM, one defines the center of mass kinetic operator as being the COSM recoil term, equal to \sum_{i<j} (pi.pj)/M_core . Its one-body matrix elements are then equal to zero.
// The A=1 case is considered meaningful only if the number of nucleons of the nucleus in basis and Hamiltonian is the same if this routine is used, in which case zero is returned.

TYPE H_CM_OBMEs::OBME_CM_kinetic_calc (
				       const class interaction_class &inter_data_basis , 
				       const unsigned int s_in , 
				       const unsigned int s_out , 
				       const class baryons_data &neut_Y_data_like , 
				       const class baryons_data &data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  if (!is_it_COSM)
    {
      const int A = data.get_A ();
      
      if (A == 1) return 0.0;

      const int A_basis = data.get_A_basis ();
  
      if (A_basis == 1) error_message_print_abort ("One cannot generate a basis with from a nucleus having one nucleon for a nucleus having several nucleons in H_CM_OBMEs::OBME_CM_kinetic_calc");
  
      const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();

      const TYPE exp_two_I_theta_H_complex_scaled = data.get_exp_two_I_theta_H_complex_scaled ();

      const TYPE OBME_kinetic = OBME_kinetic_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data);

      const TYPE OBME_CM_kinetic = (is_Hamiltonian_complex_scaled) ? (OBME_kinetic*exp_two_I_theta_H_complex_scaled) : (OBME_kinetic);

      const double nucleus_mass_basis = data.get_nucleus_mass_basis ();
      const double nucleus_mass       = data.get_nucleus_mass ();
      
      const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
      
      const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
      const class nlj_struct &shell_qn_in = shells_qn(s_in);
  
      const enum particle_type particle = shell_qn_in.get_particle ();

      const unsigned int particle_index = charge_baryon_index_determine (particle);
  
      const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);
      
      const double mass_modif = nucleus_mass*(1.0/baryon_mass_for_calc - 1.0/nucleus_mass_basis);
            
      const TYPE OBME = OBME_CM_kinetic/mass_modif;

      return OBME;
    }
  else
    return 0.0;
}




TYPE H_CM_OBMEs::OBME_CM_kinetic_bound_calc (
					     const class interaction_class &inter_data_basis , 
					     const unsigned int s_in , 
					     const unsigned int s_out , 
					     const class baryons_data &neut_Y_data_like ,
					     const class baryons_data &data)
{
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  if (!is_it_COSM)
    {
      const int A = data.get_A ();
      
      if (A == 1) return 0.0;

      const int A_basis = data.get_A_basis ();
  
      if (A_basis == 1) error_message_print_abort ("One cannot generate a basis with from a nucleus having one nucleon for a nucleus having several nucleons in H_CM_OBMEs::OBME_CM_kinetic_bound_calc");
      
      const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();

      const TYPE exp_two_I_theta_H_complex_scaled = data.get_exp_two_I_theta_H_complex_scaled ();

      const TYPE OBME_kinetic = OBME_kinetic_bound_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data);

      const TYPE OBME_CM_kinetic = (is_Hamiltonian_complex_scaled) ? (OBME_kinetic*exp_two_I_theta_H_complex_scaled) : (OBME_kinetic);

      const double nucleus_mass_basis = data.get_nucleus_mass_basis ();
      const double nucleus_mass       = data.get_nucleus_mass ();
      
      const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
      
      const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
      const class nlj_struct &shell_qn_in = shells_qn(s_in);
  
      const enum particle_type particle = shell_qn_in.get_particle ();

      const unsigned int particle_index = charge_baryon_index_determine (particle);
  
      const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);
      
      const double mass_modif = nucleus_mass*(1.0/baryon_mass_for_calc - 1.0/nucleus_mass_basis);
      
      const TYPE OBME = OBME_CM_kinetic/mass_modif;

      return OBME;
    }
  else
    return 0.0;
}











// Calculation of one one-body matrix element of the core, or kinetic energy without a core, and HO center of mass Hamiltonian Hcm if the Lawson method is used
// ------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates the matrix element of p^2/2m + U[core] for interactions with a core and p^2/2m + lambda_Hcm.Hcm(one body part) for realistic interactions (one considers U[core] = 0 then).
// It is zero unless the in and out states belong to the same partial wave.
// For this, one writes p^2/2m + U[core] = (p^2/2m + U[basis]) + (U[core] - U[basis]), as <out | p^2/2m + U[basis] | in> = e_in delta(in,out).
// Indeed, one cannot integrate it directly as a Dirac delta function enter it, which has to be handled analytically in the delta(in,out) expression above. 
// The part depending on Hcm is handled with the OBME_Hcm_calc routine, multiplied by lambda_Hcm afterwards and added to the matrix element.
// The mass of the nucleon in basis and Hamiltonian p^2/2m can be different. The resulting ratio is taken into account.
//
// Neutrons
// --------
// U[basis] and U[core] are finite-ranged.
// Thus, their matrix elements can be calculated with either integration in coordinate space, with a WS potential for example, or with HO expansion if they are non-local, as with HF/MSDHF or OCM potential.
//
// If one uses the HF/MSDHF potential, one separates U[core] - U[basis] in (U[basis-core] - U[basis]) + U[core] - U[basis-core].
// U[basis-core] is the core potential used for HF purposes only. Indeed, the Hamiltonian generating the HF/MSDHF potential is independent of the diagonalized Hamiltonian.
// U[basis-core] - U[basis] has been stored in U_finite_range_HF_HO_basis_HO_expansion_part with HO expansion during the HF procedure, and its matrix element is calculated with matrix methods.
// One has to calculate the matrix elements <out | U[core] | in> and < out | U[basis-core] | in>. It is done with direct integration in OBME_nuclear_potential_calc as it is always local.
// The resulting matrix element is returned if one uses the HF/MSDHF potential.
//
// If one does not use the HF/MSDHF potential, the OCM potential is stored in U_finite_range_HF_HO_basis_HO_expansion_part with HO expansion as well, whose matrix element is calculated with matrix methods. 
// The neutron potential used in U[basis] and that used in U[core] can be different. Thus, the former is subtracted and the latter added.
// The resulting matrix element is then returned.
// 
//
// Protons
// -------
// One considers in this small paragraph that the potential for neutrons is used for protons as well.
// One first takes the matrix element calculated for neutrons. The Coulomb potential part of the Hamiltonian is added as it is absent from the neutron potential matrix element.
// If one uses the HF/MSDHF potential, one has to add the matrix element <out | U[core](proton) - U[basis-core](neutron) | in>,
// which is done with direct integration in OBME_nuclear_potential_calc as it is always local.
// U[basis-core] is the core potential used for HF purposes only. Indeed, the Hamiltonian generating the HF/MSDHF potential is independent of the diagonalized Hamiltonian.
// If one does not use the HF/MSDHF potential, the parameters of the neutron potential in the initial matrix element are those of the neutron basis potential as given in the input file.
// Thus, one removes the neutron basis potential matrix element and one adds the core proton potential matrix element instead.
// The resulting matrix element is returned.

// One considers in this small paragraph that the proton potential is used for protons only.
// One first calculates the matrix element calculated as for neutrons, but using proton arrays instead of neutron arrays for the nuclear part.
// If one uses the HF/MSDHF potential, one removes from it the part of the Coulomb potential present in <out | U[core] - U[basis] | in>, as it has not been done in the neutron matrix element formula.
// It has been stored in V_Coulomb_HO_basis_lj with HO expansion during the HF procedure, and its matrix element is calculated with matrix methods.
// It is finite-ranged as it was calculated int he context of the two-body Coulomb interaction, always expressed in a basis of HO states.
// It is also consistent woth the fact that one wants the proton basis to bear the Coulomb asymptote generated by the charge of the basis-generating potential.
// There is nothing to do for the nuclear part as it was taken care of in the neutron matrix element formula. 
// The resulting matrix element is returned.
// If one does not use the HF/MSDHF potential, the nuclear proton potential used in U[basis] and that used in U[core] can be different. Thus, the former is subtracted and the latter added.

TYPE H_CM_OBMEs::OBME_core_Hcm_calc (
				     const bool is_it_COSM , 
				     const class baryons_data &neut_Y_data_like , 
				     const double lambda_Hcm , 
				     const unsigned int s_in , 
				     const unsigned int s_out , 
				     const class interaction_class &inter_data_basis , 
				     const class baryons_data &data)
{
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling in H_CM_OBMEs::OBME_core_Hcm_calc");

  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
      
  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);

  if (!same_lj_particle (wf_in , wf_out)) return 0.0;

  const int l = wf_in.get_l ();

  const double j = wf_in.get_j ();
  
  const int n_in  = wf_in.get_n ();
  const int n_out = wf_out.get_n ();
  
  const enum particle_type particle = wf_in.get_particle ();

  const int particle_charge = particle_charge_determine (particle);

  const bool is_it_charged = (particle_charge != 0);

  const int s = particle_strangeness_determine (particle);
  
  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const class array<class nlj_table<TYPE> > &h_basis_tab = data.get_h_basis_tab ();
  
  const class nlj_table<TYPE> &h_basis = h_basis_tab(particle_index);

  const TYPE h_basis_value = (n_in == n_out) ? (h_basis(n_in , l , j)) : (0.0);

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool good_isospin_basis_potential = data.get_good_isospin_basis_potential ();
  
  const class array<class lj_table<enum potential_type> > &basis_potential_partial_waves_tab = data.get_basis_potential_partial_waves_tab ();

  const class lj_table<enum potential_type> &basis_potential_partial_waves = basis_potential_partial_waves_tab(particle_index);
  
  const bool are_core_basis_potentials_equal_l = are_core_basis_potentials_equal (l , data);
  
  const enum potential_type H_potential = data.get_H_potential ();
  
  const enum potential_type H_basis_core_potential = data.get_H_basis_core_potential ();

  const enum potential_type basis_potential = basis_potential_partial_waves(l , j);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const bool is_it_HF_MSDHF = ((s == 0) && ((basis_potential == HF) || (basis_potential == MSDHF)));
  
  const bool is_it_OCM = (is_it_COSM && !are_core_basis_potentials_equal_l);
  
  const bool is_it_HO_expansion = (is_it_HF_MSDHF || is_it_OCM);
  
  const double nucleus_mass_for_recoil       = data.get_nucleus_mass ();
  const double nucleus_mass_for_recoil_basis = data.get_nucleus_mass_basis ();

  const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);
    
  const double initial_baryon_mass_for_calc_inv = 1.0/baryon_mass_for_calc;
    
  const enum particle_type uncharged_particle = uncharged_baryon_multiplet_determine (particle);
  
  const unsigned int uncharged_particle_index = charge_baryon_index_determine (uncharged_particle);
  
  const class array<double> &effective_masses_for_calc_n = neut_Y_data_like.get_effective_masses_for_calc ();
  
  const double uncharged_particle_mass_for_calc = effective_masses_for_calc_n(uncharged_particle_index);

  const double uncharged_particle_mass_for_calc_inv = 1.0/uncharged_particle_mass_for_calc;
    
  const double baryon_mass_for_calc_inv = (is_it_charged) ? (initial_baryon_mass_for_calc_inv) : (uncharged_particle_mass_for_calc_inv);
  
  const double baryon_mass_basis_for_calc_inv = (good_isospin_basis_potential) ? (uncharged_particle_mass_for_calc_inv) : (initial_baryon_mass_for_calc_inv);

  const double nucleus_mass_inv_recoil       = (nucleus_mass_for_recoil       != 0.0) ? (1.0/nucleus_mass_for_recoil)       : (0.0);
  const double nucleus_mass_inv_basis_recoil = (nucleus_mass_for_recoil_basis != 0.0) ? (1.0/nucleus_mass_for_recoil_basis) : (0.0);

  const double mass_ratio_real_inter = (baryon_mass_for_calc_inv - nucleus_mass_inv_recoil)/(baryon_mass_basis_for_calc_inv - nucleus_mass_inv_basis_recoil);
  const double mass_ratio_COSM       = (baryon_mass_for_calc_inv + nucleus_mass_inv_recoil)/(baryon_mass_basis_for_calc_inv + nucleus_mass_inv_basis_recoil);

  const double mass_ratio = (!is_it_COSM) ? (mass_ratio_real_inter) : (mass_ratio_COSM);
  
  const class lj_table<complex<double> > &OBMEs_HF_SGI_MSGI = data.get_OBMEs_HF_SGI_MSGI ();
  
  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = data.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  const class matrix<complex<double> > dummy_matrix;
  
  const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = (is_it_HO_expansion) ? (U_finite_range_HF_HO_basis_HO_expansion_part(l , j)) : (dummy_matrix);
  
  const class array<class vector_class<complex<double> > > &HO_overlaps_basis       = data.get_HO_overlaps_basis ();
  const class array<class vector_class<complex<double> > > &HO_overlaps_basis_Fermi = data.get_HO_overlaps_basis_Fermi ();
  
  const class vector_class<complex<double> > &HO_overlaps_basis_in  = HO_overlaps_basis(s_in);
  const class vector_class<complex<double> > &HO_overlaps_basis_out = HO_overlaps_basis(s_out);
  
  const class vector_class<complex<double> > &HO_overlaps_basis_Fermi_in  = HO_overlaps_basis_Fermi(s_in);
  const class vector_class<complex<double> > &HO_overlaps_basis_Fermi_out = HO_overlaps_basis_Fermi(s_out);

  const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab  = inter_data_basis.get_V_Coulomb_HO_basis_tab ();
  
  const class lj_table<class matrix<complex<double> > > &V_Coulomb_HO_basis  = V_Coulomb_HO_basis_tab(particle_index);

  const class baryons_data &data_for_potential = (good_isospin_basis_potential) ? (neut_Y_data_like) : (data);
  
  const TYPE OBME_core_potential_HF       = (is_it_HF_MSDHF) ? (OBME_nuclear_potential_calc (false , false ,            H_potential , s_in , s_out , data_for_potential , data)) : (0.0);
  const TYPE OBME_basis_core_potential_HF = (is_it_HF_MSDHF) ? (OBME_nuclear_potential_calc (true  , false , H_basis_core_potential , s_in , s_out , data_for_potential , data)) : (0.0);
    
#ifdef TYPEisDOUBLECOMPLEX
  const TYPE U_finite_range_HF_HO_expansion_part_OBME = (is_it_HO_expansion) ? (HO_overlaps_basis_Fermi_out*(U_finite_range_HF_HO_basis_HO_expansion_part_lj*HO_overlaps_basis_Fermi_in)) : (0.0);

  const TYPE OBME_HF_SGI_MSGI = (is_it_HF_MSDHF && is_it_SGI_MSGI) ? (OBMEs_HF_SGI_MSGI(l , j , n_in , n_out)) : (0.0);
#endif
      
#ifdef TYPEisDOUBLE
  const TYPE U_finite_range_HF_HO_expansion_part_OBME = (is_it_HO_expansion) ? (real (HO_overlaps_basis_Fermi_out*(U_finite_range_HF_HO_basis_HO_expansion_part_lj*HO_overlaps_basis_Fermi_in))) : (0.0);
  
  const TYPE OBME_HF_SGI_MSGI = (is_it_HF_MSDHF && is_it_SGI_MSGI) ? (real (OBMEs_HF_SGI_MSGI(l , j , n_in , n_out))) : (0.0);
#endif
    
  const TYPE OBME_Hcm = (!is_it_COSM) ? (OBME_Hcm_calc (s_in , s_out , inter_data_basis , data)) : (0.0);
  
  const TYPE OBME_basis_core_Hcm_ZY_charge_basis = mass_ratio*(h_basis_value - OBME_basis_core_potential_HF - OBME_HF_SGI_MSGI - U_finite_range_HF_HO_expansion_part_OBME + OBME_core_potential_HF) + lambda_Hcm*OBME_Hcm;
  
  if (particle == NEUTRON)
    {
      if (is_it_HF_MSDHF)
	return OBME_basis_core_Hcm_ZY_charge_basis;
      else
	{
	  const TYPE OBME_neut_nuclear_potential_basis = OBME_nuclear_potential_calc (false , true  , basis_potential , s_in , s_out , data , data);	  
	  const TYPE OBME_neut_nuclear_potential_H     = OBME_nuclear_potential_calc (false , false ,     H_potential , s_in , s_out , data , data);

	  const TYPE kinetic_OBME_Hcm = OBME_basis_core_Hcm_ZY_charge_basis - mass_ratio*OBME_neut_nuclear_potential_basis;

	  const TYPE OBME_core_Hcm = kinetic_OBME_Hcm + OBME_neut_nuclear_potential_H;

	  return OBME_core_Hcm;	  
	}
    }

  if (particle == PROTON)
    {	
      if (good_isospin_basis_potential)
	{
	  const TYPE OBME_neut_nuclear_potential_basis = (is_it_HF_MSDHF)
	    ? (OBME_nuclear_potential_calc (true  , false , H_basis_core_potential , s_in , s_out , data_for_potential , data))
	    : (OBME_nuclear_potential_calc (false , true  ,        basis_potential , s_in , s_out , data_for_potential , data));
	  
	  const TYPE OBME_prot_nuclear_potential_H = OBME_nuclear_potential_calc (false , false , H_potential , s_in , s_out , data , data);

	  const TYPE OBME_Coulomb_potential = OBME_H_Coulomb_part_calc (s_in , s_out , V_Coulomb_HO_basis_tab , data);

	  const TYPE kinetic_OBME_Hcm = OBME_basis_core_Hcm_ZY_charge_basis - mass_ratio*OBME_neut_nuclear_potential_basis;

	  const TYPE OBME_core_Hcm = kinetic_OBME_Hcm + OBME_prot_nuclear_potential_H + OBME_Coulomb_potential;
	  
	  return OBME_core_Hcm;
	}
      else
	{
	  const class matrix<complex<double> > &V_Coulomb_HO_basis_lj = V_Coulomb_HO_basis(l , j);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  const TYPE V_Coulomb_HO_ZYval_charge_basis_OBME = HO_overlaps_basis_out*(V_Coulomb_HO_basis_lj*HO_overlaps_basis_in);
#endif
      
#ifdef TYPEisDOUBLE
	  const TYPE V_Coulomb_HO_ZYval_charge_basis_OBME = real (HO_overlaps_basis_out*(V_Coulomb_HO_basis_lj*HO_overlaps_basis_in));
#endif
 
	  const TYPE OBME_basis_core_Hcm_Zcore_charge = OBME_basis_core_Hcm_ZY_charge_basis - mass_ratio*V_Coulomb_HO_ZYval_charge_basis_OBME;
	  
	  if (is_it_HF_MSDHF)
	    return OBME_basis_core_Hcm_Zcore_charge;
	  else
	    {
	      const TYPE OBME_prot_nuclear_potential_basis = OBME_nuclear_potential_calc (false , true , basis_potential , s_in , s_out , data , data);
	      
	      const TYPE OBME_prot_nuclear_potential_H = OBME_nuclear_potential_calc (false , false , H_potential , s_in , s_out , data , data);
	      
	      const TYPE kinetic_Coulomb_OBME_Hcm = OBME_basis_core_Hcm_Zcore_charge - mass_ratio*OBME_prot_nuclear_potential_basis;

	      const TYPE OBME_core_Hcm = kinetic_Coulomb_OBME_Hcm + OBME_prot_nuclear_potential_H;
  
	      return OBME_core_Hcm;
	    }
	}
    }

  return NADA;
}











// Calculation of one one-body matrix element of the core, or kinetic energy without a core, and HO center of mass Hamiltonian Hcm if the Lawson method is used for bound states
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates the matrix element of p^2/2m + U[core] for interactions with a core and p^2/2m + lambda_Hcm.Hcm(one body part) for realistic interactions (one considers U[core] = 0 then).
// It is zero unless the in and out states belong to the same partial wave.
// One considers bound states only here.
// One considers separately the one-body matrix elements of p^2/2m, of the Coulomb and nuclear parts of U[core] and of Hcm(one body part), and one sums them.

TYPE H_CM_OBMEs::OBME_core_Hcm_bound_calc (
					   const unsigned int s_in , 
					   const unsigned int s_out , 
					   const class interaction_class &inter_data_basis , 
					   const double lambda_Hcm , 
					   const class baryons_data &neut_Y_data_like ,
					   const class baryons_data &data)
{
  const enum potential_type H_potential = data.get_H_potential ();
  
  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);
  
  if (!same_lj_particle (wf_in , wf_out)) return 0.0;
  
  const int A = data.get_A ();
  
  const int S = data.get_hypernucleus_strangeness ();
  
  const double total_nucleus_mass = data.get_total_nucleus_mass ();
  
  const class array<double> &effective_masses_for_calc = data.get_effective_masses_for_calc ();
  
  const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab = inter_data_basis.get_V_Coulomb_HO_basis_tab ();
  
  const enum particle_type particle = wf_in.get_particle ();
  
  const unsigned int particle_index = charge_baryon_index_determine (particle);
	    
  const double baryon_mass_for_calc = effective_masses_for_calc (particle_index);

  const TYPE OBME_Hcm = OBME_Hcm_calc (s_in , s_out , inter_data_basis , data);

  const TYPE OBME_kinetic = OBME_kinetic_bound_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data);
  
  const TYPE OBME_nuclear_potential = OBME_nuclear_potential_calc (false , false , H_potential , s_in , s_out , data , data);
  
  const TYPE OBME_Coulomb_potential = OBME_H_Coulomb_part_bound_calc (s_in , s_out , V_Coulomb_HO_basis_tab , data); 
  
  const double mass_term = ((S != 0) && (s_in == s_out)) ? (baryon_mass_for_calc - total_nucleus_mass/A) : (0.0);
	    
  const TYPE OBME = OBME_kinetic + OBME_nuclear_potential + OBME_Coulomb_potential + lambda_Hcm*OBME_Hcm + mass_term;

  return OBME;
}









// Calculation of one one-body matrix element of a nuclear potential
// -----------------------------------------------------------------
// One calculates the one-body matrix element <out | U_nuclear | in>. 
// It is zero unless the in and out states belong to the same partial wave.
// As U_nuclear is finite-ranged, it can be done by direct integration on the real axis.
// The nuclear potential can be WS (with Coulomb uniformly charged sphere potential), WS_ANALYTIC (with Coulomb Gaussian charged sphere potential) or KKNN.
// One uses the parameters of the basis WS or KKNN potential as given in the input file if is_it_basis_potential is put to true.
// If is_it_basis_potential is put to false, one considers the parameters of the basis core potential used with the HF/MSDHF potential if is_it_basis_core_potential is put to true.
// If is_it_basis_potential and is_it_basis_core_potential are put to false, one uses the parameters of the core potential used in the Hamiltonian.

TYPE H_CM_OBMEs::OBME_nuclear_potential_calc (
					      const bool is_it_basis_core_potential , 
					      const bool is_it_basis_potential , 
					      const enum potential_type nuclear_potential , 
					      const unsigned int s_in , 
					      const unsigned int s_out , 
					      const class baryons_data &data_for_potential , 
					      const class baryons_data &data) 
{
  if (is_it_basis_potential && is_it_basis_core_potential) error_message_print_abort ("It cannot be basis.potential and basis.core.potential at the same time.");

  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);
  
  if (!same_lj_particle (wf_in , wf_out)) return 0.0;
    
  const enum particle_type nucleonic_particle_for_potential = data_for_potential.get_nucleonic_particle ();
  
  const bool is_it_charged_potential = (nucleonic_particle_for_potential == PROTON);
  
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  if (is_Hamiltonian_complex_scaled && is_it_WS_potential_determine (nuclear_potential)) error_message_print_abort ("WS potentials cannot be used with complex-scaled Hamiltonian in H_CM_OBMEs::OBME_nuclear_potential_calc");
  
  const enum particle_type particle = wf_in.get_particle ();
  
  const enum particle_type uncharged_particle = uncharged_baryon_multiplet_determine (particle);
    
  const unsigned int particle_index_for_potential = (is_it_charged_potential) ? (charge_baryon_index_determine (particle)) : (charge_baryon_index_determine (uncharged_particle));
  
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();
  
  const int l = wf_out.get_l ();
  
  const double j = wf_out.get_j ();

  const complex<double> exp_I_theta_H_complex_scaled = data_for_potential.get_exp_I_theta_H_complex_scaled ();
	
  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL = wf_in.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL_real ();
  
  const class array<complex<double> > &wf_in_aft_R_tab_GL  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_aft_R_tab_GL = wf_out.get_wf_aft_R_tab_GL_real ();

  const class array<double> &d_core_potential_tab_for_potential        = data_for_potential.get_d_core_potential_tab ();
  const class array<double> &R0_core_potential_tab_for_potential       = data_for_potential.get_R0_core_potential_tab ();
  const class array<double> &Vo_core_potential_tab_for_potential       = data_for_potential.get_Vo_core_potential_tab ();
  const class array<double> &Vso_core_potential_tab_for_potential      = data_for_potential.get_Vso_core_potential_tab ();
  const class array<double> &Im_Vo_core_potential_tab_for_potential    = data_for_potential.get_Im_Vo_core_potential_tab ();
  const class array<double> &Im_Vso_core_potential_tab_for_potential   = data_for_potential.get_Im_Vso_core_potential_tab ();
  const class array<double> &Im_Vsurf_core_potential_tab_for_potential = data_for_potential.get_Im_Vsurf_core_potential_tab ();

  const class array<double> &d_basis_core_potential_tab_for_potential        = data_for_potential.get_d_basis_core_potential_tab ();
  const class array<double> &R0_basis_core_potential_tab_for_potential       = data_for_potential.get_R0_basis_core_potential_tab ();
  const class array<double> &Vo_basis_core_potential_tab_for_potential       = data_for_potential.get_Vo_basis_core_potential_tab ();
  const class array<double> &Vso_basis_core_potential_tab_for_potential      = data_for_potential.get_Vso_basis_core_potential_tab ();
  const class array<double> &Im_Vo_basis_core_potential_tab_for_potential    = data_for_potential.get_Im_Vo_basis_core_potential_tab ();
  const class array<double> &Im_Vso_basis_core_potential_tab_for_potential   = data_for_potential.get_Im_Vso_basis_core_potential_tab ();
  const class array<double> &Im_Vsurf_basis_core_potential_tab_for_potential = data_for_potential.get_Im_Vsurf_basis_core_potential_tab ();

  const class array<double> &d_basis_tab_for_potential        = data_for_potential.get_d_basis_tab ();
  const class array<double> &R0_basis_tab_for_potential       = data_for_potential.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab_for_potential       = data_for_potential.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab_for_potential      = data_for_potential.get_Vso_basis_tab ();
  const class array<double> &Im_Vo_basis_tab_for_potential    = data_for_potential.get_Im_Vo_basis_tab ();
  const class array<double> &Im_Vso_basis_tab_for_potential   = data_for_potential.get_Im_Vso_basis_tab ();
  const class array<double> &Im_Vsurf_basis_tab_for_potential = data_for_potential.get_Im_Vsurf_basis_tab ();

  const class array<double> &d_core_tab_for_potential        = (is_it_basis_core_potential) ? (d_basis_core_potential_tab_for_potential)        : (d_core_potential_tab_for_potential);
  const class array<double> &R0_core_tab_for_potential       = (is_it_basis_core_potential) ? (R0_basis_core_potential_tab_for_potential)       : (R0_core_potential_tab_for_potential);
  const class array<double> &Vo_core_tab_for_potential       = (is_it_basis_core_potential) ? (Vo_basis_core_potential_tab_for_potential)       : (Vo_core_potential_tab_for_potential);
  const class array<double> &Vso_core_tab_for_potential      = (is_it_basis_core_potential) ? (Vso_basis_core_potential_tab_for_potential)      : (Vso_core_potential_tab_for_potential);
  const class array<double> &Im_Vo_core_tab_for_potential    = (is_it_basis_core_potential) ? (Im_Vo_basis_core_potential_tab_for_potential)    : (Im_Vo_core_potential_tab_for_potential);
  const class array<double> &Im_Vso_core_tab_for_potential   = (is_it_basis_core_potential) ? (Im_Vso_basis_core_potential_tab_for_potential)   : (Im_Vso_core_potential_tab_for_potential);
  const class array<double> &Im_Vsurf_core_tab_for_potential = (is_it_basis_core_potential) ? (Im_Vsurf_basis_core_potential_tab_for_potential) : (Im_Vsurf_core_potential_tab_for_potential);

  const class array<double> &d_tab        = (is_it_basis_potential) ? (d_basis_tab_for_potential)        : (d_core_tab_for_potential);
  const class array<double> &R0_tab       = (is_it_basis_potential) ? (R0_basis_tab_for_potential)       : (R0_core_tab_for_potential);
  const class array<double> &Vo_tab       = (is_it_basis_potential) ? (Vo_basis_tab_for_potential)       : (Vo_core_tab_for_potential);
  const class array<double> &Vso_tab      = (is_it_basis_potential) ? (Vso_basis_tab_for_potential)      : (Vso_core_tab_for_potential);
  const class array<double> &Im_Vo_tab    = (is_it_basis_potential) ? (Im_Vo_basis_tab_for_potential)    : (Im_Vo_core_tab_for_potential);
  const class array<double> &Im_Vso_tab   = (is_it_basis_potential) ? (Im_Vso_basis_tab_for_potential)   : (Im_Vso_core_tab_for_potential);
  const class array<double> &Im_Vsurf_tab = (is_it_basis_potential) ? (Im_Vsurf_basis_tab_for_potential) : (Im_Vsurf_core_tab_for_potential);
  
  const class array<double> &V0_KKNN_tab     = (is_it_basis_core_potential) ? (data_for_potential.get_V0_KKNN_basis_core_potential_tab     ()) : (data_for_potential.get_V0_KKNN_tab ());  
  const class array<double> &rho_KKNN_tab    = (is_it_basis_core_potential) ? (data_for_potential.get_rho_KKNN_basis_core_potential_tab    ()) : (data_for_potential.get_rho_KKNN_tab ());
  const class array<double> &Vls_KKNN_tab    = (is_it_basis_core_potential) ? (data_for_potential.get_Vls_KKNN_basis_core_potential_tab    ()) : (data_for_potential.get_Vls_KKNN_tab ());
  const class array<double> &rho_ls_KKNN_tab = (is_it_basis_core_potential) ? (data_for_potential.get_rho_ls_KKNN_basis_core_potential_tab ()) : (data_for_potential.get_rho_ls_KKNN_tab ());
  
  const double V0_KKNN[5] = {
    V0_KKNN_tab(particle_index_for_potential , 0) ,
    V0_KKNN_tab(particle_index_for_potential , 1) ,
    V0_KKNN_tab(particle_index_for_potential , 2) ,
    V0_KKNN_tab(particle_index_for_potential , 3) ,
    V0_KKNN_tab(particle_index_for_potential , 4)};
  
  const double rho_KKNN[5] = {
    rho_KKNN_tab(particle_index_for_potential , 0) ,
    rho_KKNN_tab(particle_index_for_potential , 1) ,
    rho_KKNN_tab(particle_index_for_potential , 2) ,
    rho_KKNN_tab(particle_index_for_potential , 3) ,
    rho_KKNN_tab(particle_index_for_potential , 4)};

  const double Vls_KKNN[3] = {
    Vls_KKNN_tab(particle_index_for_potential , 0) ,
    Vls_KKNN_tab(particle_index_for_potential , 1) ,
    Vls_KKNN_tab(particle_index_for_potential , 2)};
  
  const double rho_ls_KKNN[3] = {
    rho_ls_KKNN_tab(particle_index_for_potential , 0) ,
    rho_ls_KKNN_tab(particle_index_for_potential , 1) ,
    rho_ls_KKNN_tab(particle_index_for_potential , 2)};
  
  complex<double> OBME = 0.0;
  
  switch (nuclear_potential)
    {
    case WS:
      {
	const double d   = d_tab  (particle_index_for_potential , l);
	const double R0  = R0_tab (particle_index_for_potential , l);
	const double Vo  = Vo_tab (particle_index_for_potential , l);
	const double Vso = Vso_tab(particle_index_for_potential , l);

	const class WS_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }
      } break;

    case WS_ANALYTIC:
      {
	const double d   = d_tab  (particle_index_for_potential , l);
	const double R0  = R0_tab (particle_index_for_potential , l);
	const double Vo  = Vo_tab (particle_index_for_potential , l);
	const double Vso = Vso_tab(particle_index_for_potential , l);
	
	const class WS_analytic_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }
      } break;

    case COMPLEX_WS:
      {  
	const double d         = d_tab       (particle_index_for_potential , l);
	const double R0        = R0_tab      (particle_index_for_potential , l);
	const double Vo        = Vo_tab      (particle_index_for_potential , l);
	const double Vso       = Vso_tab     (particle_index_for_potential , l);
	const double Im_Vo     = Im_Vo_tab   (particle_index_for_potential , l);
	const double Im_Vso    = Im_Vso_tab  (particle_index_for_potential , l);
	const double Im_Vsurf  = Im_Vsurf_tab(particle_index_for_potential , l);
	
	const complex<double> Vo_complex (Vo  , Im_Vo);
	const complex<double> Vso_complex(Vso , Im_Vso);
		    
	const class WS_complex_class WS_complex_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

	    OBME += wf_in_r*WS_complex_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

	    OBME += wf_in_r*WS_complex_potential_r*wf_out_r*w;
	  }
      } break;

    case COMPLEX_WS_ANALYTIC:
      {  
	const double d         = d_tab       (particle_index_for_potential , l);
	const double R0        = R0_tab      (particle_index_for_potential , l);
	const double Vo        = Vo_tab      (particle_index_for_potential , l);
	const double Vso       = Vso_tab     (particle_index_for_potential , l);
	const double Im_Vo     = Im_Vo_tab   (particle_index_for_potential , l);
	const double Im_Vso    = Im_Vso_tab  (particle_index_for_potential , l);
	const double Im_Vsurf  = Im_Vsurf_tab(particle_index_for_potential , l);
		
	const complex<double> Vo_complex (Vo  , Im_Vo);
	const complex<double> Vso_complex(Vso , Im_Vso);
		    
	const class WS_analytic_complex_class WS_complex_potential(false , d , R0 , Vo_complex , Vso_complex , Im_Vsurf , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

	    OBME += wf_in_r*WS_complex_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const complex<double> WS_complex_potential_r = WS_complex_potential(r);

	    const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

	    OBME += wf_in_r*WS_complex_potential_r*wf_out_r*w;
	  }
      } break;

    case KKNN:
      {
	const class KKNN_class KKNN_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , l , j);
	
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> KKNN_potential_r = (is_Hamiltonian_complex_scaled) ? (KKNN_potential(r*exp_I_theta_H_complex_scaled)) : (KKNN_potential(r));
      
	    const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

	    OBME += wf_in_r*KKNN_potential_r*wf_out_r*w;
	  }
	
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const complex<double> KKNN_potential_r = (is_Hamiltonian_complex_scaled) ? (KKNN_potential(r*exp_I_theta_H_complex_scaled)) : (KKNN_potential(r));

	    const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
	    const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

	    OBME += wf_in_r*KKNN_potential_r*wf_out_r*w;
	  }
	
      } break;

    case NO_POTENTIAL: return 0.0;
      
    default: abort_all ();
    }
  
#ifdef TYPEisDOUBLECOMPLEX
  return OBME;
#endif
      
#ifdef TYPEisDOUBLE
  return real (OBME);
#endif
}





// Calculation of one one-body matrix element of the partial derivative of a WS potential with respect to d, R0, Vo, Vso or R_charge
// ---------------------------------------------------------------------------------------------------------------------------------
// One calculates the one-body matrix element <out | dWS/dx | in>, with x = d, R0, Vo, Vso or R_charge.
// It is zero unless the in and out states belong to the same partial wave.
// As the WS potential is finite-ranged, it can be done by direct integration on the real axis.
// One uses the parameters of the Hamiltonian core only, as this routine is used to fit the core WS potential with experimental phase shifts.

TYPE H_CM_OBMEs::OBME_WS_derivative_calc (
					  const enum FHT_EFT_parameter_type FHT_EFT_parameter , 
					  const bool is_there_l_dependence , 
					  const int l_WS , 
					  const double A_dependent_factor_core_potential ,
					  const unsigned int s_in , 
					  const unsigned int s_out , 
					  const class baryons_data &data) 
{
  const bool is_Hamiltonian_complex_scaled = data.get_is_Hamiltonian_complex_scaled ();
  
  if (is_Hamiltonian_complex_scaled) error_message_print_abort ("One cannot use Hamiltonian complex scaling in H_CM_OBMEs::H_CM_OBMEs::OBME_core_Hcm_calc");

  const class array<class spherical_state> &shells = data.get_shells ();

  const class spherical_state &wf_in  = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);

  if (!same_lj_particle (wf_in , wf_out)) return 0.0;

  const int l = wf_out.get_l ();

  if (is_there_l_dependence && (l != l_WS)) return 0.0;

  const double j = wf_out.get_j ();
  
  const enum particle_type particle = wf_in.get_particle ();

  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();
  
  const int ZY_charge = wf_in.get_ZY_charge ();
    
  const double R_charge = data.get_R_charge ();

  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL = wf_in.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL_real ();
  
  const class array<complex<double> > &wf_in_aft_R_tab_GL  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_aft_R_tab_GL = wf_out.get_wf_aft_R_tab_GL_real ();

  const class array<double> &d_tab   = data.get_d_core_potential_tab ();
  const class array<double> &R0_tab  = data.get_R0_core_potential_tab ();
  const class array<double> &Vo_tab  = data.get_Vo_core_potential_tab ();
  const class array<double> &Vso_tab = data.get_Vso_core_potential_tab ();

  const double d   = d_tab  (particle_index , l);
  const double R0  = R0_tab (particle_index , l);
  const double Vo  = Vo_tab (particle_index , l);
  const double Vso = Vso_tab(particle_index , l);
  
  const class WS_analytic_class WS_potential(false , d , R0 , Vo , Vso , particle , ZY_charge , R_charge , l , j);

  complex<double> OBME_WS_derivative = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double WS_derivative_r = WS_potential.derivative_calc (FHT_EFT_parameter , r);

      const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

      OBME_WS_derivative += wf_in_r*WS_derivative_r*wf_out_r*w;
    }	

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double r = r_aft_R_tab_GL(i);
      const double w = w_aft_R_tab_GL(i);

      const double WS_derivative_r = WS_potential.derivative_calc (FHT_EFT_parameter , r);

      const complex<double> wf_in_r  = wf_in_aft_R_tab_GL(i);
      const complex<double> wf_out_r = wf_out_aft_R_tab_GL(i);

      OBME_WS_derivative += wf_in_r*WS_derivative_r*wf_out_r*w;
    }

  if (is_it_FHT_EFT_core_Vo_determine (FHT_EFT_parameter)) OBME_WS_derivative *= A_dependent_factor_core_potential;

#ifdef TYPEisDOUBLECOMPLEX
  return OBME_WS_derivative;
#endif
      
#ifdef TYPEisDOUBLE
  return real (OBME_WS_derivative);
#endif
}








// Calculation of one one-body matrix element coupled to j of a given one-body operator associated to a Hamiltonian
// ----------------------------------------------------------------------------------------------------------------
// One calculates <out | Op_inter | in> for the operator Op_inter being p^2/2m, Vc(inter) (see OBME_H_Coulomb_part_calc, OBME_H_Coulomb_part_bound_calc),
// a nuclear potential (see OBME_nuclear_potential_calc), 
// or the one-body core/kinetic part of the Hamiltonian (see OBME_core_Hcm_calc, OBME_core_Hcm_bound_calc). One can add lambda_Hcm.Hcm(one body part) for realistic interactions as well.
// If one considers the Hamiltonian core as operator, and one that one has a core state and a valence state as in and out state,
// zero is returned as there is no coupling between core and valence parts.

TYPE H_CM_OBMEs::coupled_OBME_inter_calc (
					  const enum interaction_type Op_inter , 
					  const class interaction_class &inter_data_basis , 
					  const double lambda_Hcm , 
					  const unsigned int s_in , 
					  const unsigned int s_out , 
					  const class baryons_data &neut_Y_data_like , 
					  const class baryons_data &data)
{
  const bool is_it_COSM = is_it_COSM_determine (Op_inter);

  const enum potential_type H_potential = data.get_H_potential ();

  const bool is_it_Op_inter_core_Hamiltonian = is_it_core_Hamiltonian_inter_determine (Op_inter);

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class nlj_struct &shell_qn_in = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);
  
  const enum particle_type B_in = shell_qn_in.get_particle ();
  const enum particle_type B_out = shell_qn_out.get_particle ();
  
  if (B_in != B_out) return 0.0;
  
  const bool core_state_in  = shell_qn_in.get_core_state ();
  const bool core_state_out = shell_qn_out.get_core_state ();
  
  const bool is_there_core_state = (core_state_in || core_state_out);
  
  if (is_it_Op_inter_core_Hamiltonian && is_there_core_state && (s_in != s_out)) return 0.0;

  const class array<class lj_table<class matrix<complex<double> > > > &V_Coulomb_HO_basis_tab  = inter_data_basis.get_V_Coulomb_HO_basis_tab ();
  
  const bool is_it_HO_in  = shell_qn_in.get_is_it_HO ();
  const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();
  
  const bool is_it_bound_integral = (is_it_HO_in || is_it_HO_out);

  switch (Op_inter)
    {
    case ONE_BODY_KINETIC:
      {
	return (is_it_bound_integral) ? (OBME_kinetic_bound_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data)) : (OBME_kinetic_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data));
      }
       
    case ONE_BODY_COULOMB:
      {
	return (is_it_bound_integral) ? (OBME_H_Coulomb_part_bound_calc (s_in , s_out , V_Coulomb_HO_basis_tab , data)) : (OBME_H_Coulomb_part_calc (s_in , s_out , V_Coulomb_HO_basis_tab , data));
      }
      
    case ONE_BODY_NUCLEAR:
      {	
	return OBME_nuclear_potential_calc (false , false , H_potential , s_in , s_out , data , data);
      }
      
    case REALISTIC_INTERACTION:
      {
	return (is_it_bound_integral) ? (OBME_core_Hcm_bound_calc (s_in , s_out , inter_data_basis , lambda_Hcm , neut_Y_data_like , data)) : (OBME_core_Hcm_calc (is_it_COSM , neut_Y_data_like , lambda_Hcm , s_in , s_out , inter_data_basis , data));	
      }
      
    case REALISTIC_INTERACTION_COMPLEX_SCALED:
      {
	return (is_it_bound_integral) ? (OBME_core_Hcm_bound_calc (s_in , s_out , inter_data_basis , lambda_Hcm , neut_Y_data_like , data)) : (OBME_core_Hcm_calc (is_it_COSM , neut_Y_data_like , lambda_Hcm , s_in , s_out , inter_data_basis , data));	
      }
      
    default:
      {
	if (is_it_Op_inter_core_Hamiltonian)
	  { 	
	    return (is_it_bound_integral) ? (OBME_core_Hcm_bound_calc (s_in , s_out , inter_data_basis , lambda_Hcm , neut_Y_data_like , data)) : (OBME_core_Hcm_calc (is_it_COSM , neut_Y_data_like , lambda_Hcm , s_in , s_out , inter_data_basis , data));
	  }
	else 
	  abort_all ();
      }
    }

  return NADA;
}













// Calculation of one one-body matrix element coupled to j of a given one-body operator not associated to a Hamiltonian
// --------------------------------------------------------------------------------------------------------------------
// One calculates <out | Op | in> for the operator Op being L[CM], L+, L-, Lz, Hcm, P^2/2M, rms radii for protons and neutrons and A+[CM-HO].

TYPE H_CM_OBMEs::coupled_OBME_operator_calc (
					     const bool is_it_only_basis ,
					     const enum operator_type Op , 
					     const bool is_it_HO_expansion , 
					     const class interaction_class &inter_data_basis , 
					     const unsigned int s_in , 
					     const unsigned int s_out , 
					     const class baryons_data &neut_Y_data_like , 
					     const class array<TYPE> &r2_HO_tab , 
					     const class baryons_data &data)
{
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class nlj_struct &shell_qn_in  = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);

  const enum particle_type B_in = shell_qn_in.get_particle ();
  const enum particle_type B_out = shell_qn_out.get_particle ();
  
  if (B_in != B_out) return 0.0;
  
  const bool is_it_HO_in  = shell_qn_in.get_is_it_HO ();
  const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();
  
  const bool is_it_bound_integral = (is_it_HO_in || is_it_HO_out);
  
  switch (Op)
    {
    case L_REDUCED_TENSOR              : return reduced_OBME_L_CM_calc (s_in , s_out , data);
    case LPLUS                         : return reduced_OBME_L_CM_calc (s_in , s_out , data);
    case LMINUS                        : return reduced_OBME_L_CM_calc (s_in , s_out , data);
    case LZ                            : return reduced_OBME_L_CM_calc (s_in , s_out , data);

    case HCM                           : return OBME_Hcm_calc (s_in , s_out , inter_data_basis , data);

    case CM_KINETIC 	               : return (is_it_bound_integral) ? (OBME_CM_kinetic_bound_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data)) : (OBME_CM_kinetic_calc (inter_data_basis , s_in , s_out , neut_Y_data_like , data));
      
    case RMS_RADIUS                    : return OBME_rms_radius_not_normed_calc (is_it_only_basis , is_it_HO_expansion , s_in , s_out , inter_data_basis , r2_HO_tab , data);

    case A_DAGGER_CM_HO_REDUCED_TENSOR : return reduced_OBME_A_dagger_CM_HO_calc (s_in , s_out , data);

    default                            : abort_all ();
    }

  return NADA;
}







