#include "../GSM_include/GSM_include_def_common.h"


using namespace Wigner_signs;

// TYPE is double or complex
// -------------------------

// TBME is for two-body matrix element
// -----------------------------------

// This namespace is for the calculation of the TBMEs of the HO center of mass Hamiltonian Hcm and the center of kinetic operator P^2/2M
// -------------------------------------------------------------------------------------------------------------------------------------

// All TBMEs are not antisymmetrized unless explicitly stated.
// -----------------------------------------------------------

// Double and complex version are available for operators.
// -------------------------------------------------------








// Calculation of the non-antisymmetrized TBME coupled to J of Hcm
// ---------------------------------------------------------------
// The TBME < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s0 s1 >_J is that of the HO center of mass Hamiltonian Hcm = P^2/2M  + (1/2) M omega^2 R^2.
// It is coupled to J but not antisymmetrized.
// One uses the Wigner Eckhart theorem for scalar operators (see Wigner_signs.cpp) to calculate pi.pj and ri.rj TBMEs.

TYPE TBME_CM_operator::Hcm::TBME_J (
				    const int J , 
				    const class array<TYPE> &reduced_grad_Hcm_tab_02 , 
				    const class array<TYPE> &reduced_grad_Hcm_tab_13 , 
				    const class array<TYPE> &reduced_r_Hcm_tab_02 , 
				    const class array<TYPE> &reduced_r_Hcm_tab_13 , 
				    const unsigned int s0 , 
				    const unsigned int s1 , 
				    const unsigned int s2 , 
				    const unsigned int s3 , 
				    const class array<class nlj_struct> &shells_qn_02 , 
				    const class array<class nlj_struct> &shells_qn_13)
{
  const class nlj_struct &shell_qn_s0 = shells_qn_02(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn_13(s1);
  
  const class nlj_struct &shell_qn_s2 = shells_qn_02(s2);
  const class nlj_struct &shell_qn_s3 = shells_qn_13(s3);

  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  const double j2 = shell_qn_s2.get_j ();
  const double j3 = shell_qn_s3.get_j ();

  const TYPE reduced_grad_Hcm_02 = reduced_grad_Hcm_tab_02(s0 , s2);
  const TYPE reduced_grad_Hcm_13 = reduced_grad_Hcm_tab_13(s1 , s3);
  
  const TYPE reduced_r_Hcm_02 = reduced_r_Hcm_tab_02(s0 , s2);
  const TYPE reduced_r_Hcm_13 = reduced_r_Hcm_tab_13(s1 , s3);

  const TYPE pi_pj_TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_Hcm_02 , reduced_grad_Hcm_13);
  const TYPE ri_rj_TBME =  Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_r_Hcm_02    , reduced_r_Hcm_13);

  const TYPE TBME = pi_pj_TBME + ri_rj_TBME;

  return TBME;
}











// Calculation of the antisymmetrized TBME coupled to J of Hcm for protons only or neutrons only and proton-neutron TBME coupled to J of Hcm
// -----------------------------------------------------------------------------------------------------------------------------------------
// The TBME is antisymmetrized for protons only or neutrons only.
//
// The TBME < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s0 s1 >_(J antisymmetrized) is that of the HO center of mass Hamiltonian Hcm = P^2/2M  + (1/2) M omega^2 R^2.
//
// If s0 != s1 and s2 != s3, the antisymmetrized TBME is equal to TBME_direct - (-1)^(j0 + j1 - J) TBME_exchange, with
// its direct and exchange parts TBME_direct and TBME_exchange equal to < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s0 s1 >_J and < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s1 s0 >_J.

// If s0 = s1 or s2 = s3 or both, one checks if J + T is odd (here T=1). If it is even, zero is returned.
// If not, the antisymmetrized TBME is equal to 2 . (1/sqrt(1 + delta_s0_s1)) . (1/sqrt(1 + delta_s2_s3)) < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s0 s1 >_J, which is returned.
//
// The proton-neutron TBME coupled to J of Hcm is not antisymmetrized and is equal to its direct part.

TYPE TBME_CM_operator::Hcm::TBME_J_pp_nn_antisymmetrized (
							  const int J , 
							  const unsigned int s0 , 
							  const unsigned int s1 , 
							  const unsigned int s2 , 
							  const unsigned int s3 , 
							  const class array<class nlj_struct> &shells_qn , 
							  const class array<TYPE> &reduced_grad_Hcm_tab , 
							  const class array<TYPE> &reduced_r_Hcm_tab)
{
  const int T = 1;

  if (s2 == s3)
    {
      if ((J + T)%2 == 0) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;

      const double antisymmetry_norm_out = (s0 == s1) ? (M_SQRT1_2) : (1.0);

      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const TYPE TBME = antisymmetry_norm*TBME_J (J , reduced_grad_Hcm_tab , reduced_grad_Hcm_tab ,
						  reduced_r_Hcm_tab , reduced_r_Hcm_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);
      
      return TBME;
    }

  if (s0 == s1)
    {
      if ((J + T)%2 == 0) return 0.0;

      const TYPE TBME = M_SQRT2*TBME_J (J , reduced_grad_Hcm_tab , reduced_grad_Hcm_tab , reduced_r_Hcm_tab , reduced_r_Hcm_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);

      return TBME;
    }

  const TYPE TBME_direct   = TBME_J (J , reduced_grad_Hcm_tab , reduced_grad_Hcm_tab , reduced_r_Hcm_tab , reduced_r_Hcm_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);
  const TYPE TBME_exchange = TBME_J (J , reduced_grad_Hcm_tab , reduced_grad_Hcm_tab , reduced_r_Hcm_tab , reduced_r_Hcm_tab , s1 , s0 , s2 , s3 , shells_qn , shells_qn);

  const class nlj_struct &shell_qn_s0 = shells_qn(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn(s1);
  
  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  
  const TYPE TBME = TBME_direct - minus_one_pow (j0 + j1 - J)*TBME_exchange;

  return TBME;
}

TYPE TBME_CM_operator::Hcm::TBME_J_pn (
				       const int J , 
				       const unsigned int s0 ,
				       const unsigned int s1 ,
				       const unsigned int s2 ,
				       const unsigned int s3 , 
				       const class array<class nlj_struct> &shells_qn_prot , 
				       const class array<class nlj_struct> &shells_qn_neut , 
				       const class array<TYPE> &reduced_grad_Hcm_tab_prot , 
				       const class array<TYPE> &reduced_grad_Hcm_tab_neut , 
				       const class array<TYPE> &reduced_r_Hcm_tab_prot , 
				       const class array<TYPE> &reduced_r_Hcm_tab_neut)
{
  const TYPE TBME = TBME_J (J , reduced_grad_Hcm_tab_prot , reduced_grad_Hcm_tab_neut , reduced_r_Hcm_tab_prot , reduced_r_Hcm_tab_neut , 
			    s0 , s1 , s2 , s3 , shells_qn_prot , shells_qn_neut);

  return TBME;
}












// Calculation of the non-antisymmetrized TBME coupled to J of P^2/2M
// ------------------------------------------------------------------
// The TBME < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J is that of the kinetic Hamiltonian P^2/2M
// It is coupled to J but not antisymmetrized.
// It is equal to zero if s0 and s2 have same parity, so that one first checks this case and zero is returned then.
// One uses the Wigner Eckhart theorem for scalar operators (see Wigner_signs.cpp) to calculate pi.pj TBMEs.
// There is a minus sign in the returned value as p = -i.hbar.grad .

double TBME_CM_operator::P2_over_2M::TBME_J (
					     const int J , 
					     const class array<double> &reduced_grad_P2_02_tab , 
					     const class array<double> &reduced_grad_P2_13_tab , 
					     const unsigned int s0 , 
					     const unsigned int s1 , 
					     const unsigned int s2 , 
					     const unsigned int s3 , 
					     const class array<class nlj_struct> &shells_qn_02 , 
					     const class array<class nlj_struct> &shells_qn_13)
{
  const class nlj_struct &shell_qn_s0 = shells_qn_02(s0);  
  const class nlj_struct &shell_qn_s2 = shells_qn_02(s2);

  const int l0 = shell_qn_s0.get_l ();
  const int l2 = shell_qn_s2.get_l ();

  if ((l0 + l2)%2 == 0) return 0.0;

  const class nlj_struct &shell_qn_s1 = shells_qn_13(s1);
  const class nlj_struct &shell_qn_s3 = shells_qn_13(s3);
  
  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  const double j2 = shell_qn_s2.get_j ();
  const double j3 = shell_qn_s3.get_j ();

  const double reduced_grad_P2_02 = reduced_grad_P2_02_tab(s0 , s2);
  const double reduced_grad_P2_13 = reduced_grad_P2_13_tab(s1 , s3);
  
  const double TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_P2_02 , reduced_grad_P2_13);

  return TBME;
}


complex<double> TBME_CM_operator::P2_over_2M::TBME_J (
						      const int J , 
						      const class array<complex<double> > &reduced_grad_P2_02_tab , 
						      const class array<complex<double> > &reduced_grad_P2_13_tab , 
						      const unsigned int s0 , 
						      const unsigned int s1 , 
						      const unsigned int s2 , 
						      const unsigned int s3 , 
						      const class array<class nlj_struct> &shells_qn_02 , 
						      const class array<class nlj_struct> &shells_qn_13)
{
  const class nlj_struct &shell_qn_s0 = shells_qn_02(s0);  
  const class nlj_struct &shell_qn_s2 = shells_qn_02(s2);

  const int l0 = shell_qn_s0.get_l ();
  const int l2 = shell_qn_s2.get_l ();

  if ((l0 + l2)%2 == 0) return 0.0;

  const class nlj_struct &shell_qn_s1 = shells_qn_13(s1);
  const class nlj_struct &shell_qn_s3 = shells_qn_13(s3);
  
  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  const double j2 = shell_qn_s2.get_j ();
  const double j3 = shell_qn_s3.get_j ();

  const complex<double> reduced_grad_P2_02 = reduced_grad_P2_02_tab(s0 , s2);
  const complex<double> reduced_grad_P2_13 = reduced_grad_P2_13_tab(s1 , s3);

  const complex<double> TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_P2_02 , reduced_grad_P2_13);

  return TBME;
}





// Calculation of the antisymmetrized TBME coupled to J of P^2/2M for protons and neutrons and proton-neutron TBME coupled to J of P^2/2M
// --------------------------------------------------------------------------------------------------------------------------------------
// The TBME is antisymmetrized for protons only or neutrons only.
//
// The TBME < s2 s3 | pi.pj (hbar^2 / M) + ri.rj (hbar^2 / M)/b^4 | s0 s1 >_(J antisymmetrized) is that of P^2/2M.
// It is equal to zero if (a,c) have the same parity and (b,c) have the same parity. 
// Indeed, both direct and exchange have to cancel for the antisymmetrized TBME to be equal to zero.
//
// If s0 != s1 and s2 != s3, the antisymmetrized TBME is equal to TBME_direct - (-1)^(j0 + j1 - J) TBME_exchange, with
// its direct and exchange parts TBME_direct and TBME_exchange equal to < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J and < s2 s3 | pi.pj (hbar^2 / M) | s1 s0 >_J.
//
// If s0 = s1 or s2 = s3 or both, one checks if J + T is odd (here T=1). If it is even, zero is returned.
// If not, the antisymmetrized TBME is equal to 2 . (1/sqrt(1 + delta_s0_s1)) . (1/sqrt(1 + delta_s2_s3)) < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J, which is returned.
//
// The proton-neutron TBME coupled to J of P^2/2M is not antisymmetrized and is equal to its direct part.

double TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (
								   const int J , 
								   const unsigned int s0 , 
								   const unsigned int s1 , 
								   const unsigned int s2 , 
								   const unsigned int s3 , 
								   const class array<class nlj_struct> &shells_qn , 
								   const class array<double> &reduced_grad_P2_tab)
{  
  const class nlj_struct &shell_qn_s0 = shells_qn(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn(s1);
  const class nlj_struct &shell_qn_s2 = shells_qn(s2);

  const int l0 = shell_qn_s0.get_l ();
  const int l1 = shell_qn_s1.get_l ();
  const int l2 = shell_qn_s2.get_l ();
  
  const unsigned int bp_s0 = binary_parity_from_orbital_angular_momentum (l0);
  const unsigned int bp_s1 = binary_parity_from_orbital_angular_momentum (l1);
  const unsigned int bp_s2 = binary_parity_from_orbital_angular_momentum (l2);
  
  if ((bp_s0 == bp_s2) && (bp_s1 == bp_s2)) return 0.0;

  const int T = 1;

  if (s2 == s3)
    {
      if ((J + T)%2 == 0) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;

      const double antisymmetry_norm_out = (s0 == s1) ? (M_SQRT1_2) : (1.0);

      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const double TBME = antisymmetry_norm*TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);

      return TBME;
    }

  if (s0 == s1)
    {
      if ((J + T)%2 == 0) return 0.0; 

      const double TBME = M_SQRT2*TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);

      return TBME;
    }

  const double TBME_direct   = TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);
  const double TBME_exchange = TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s1 , s0 , s2 , s3 , shells_qn , shells_qn);

  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  
  const double TBME = TBME_direct - minus_one_pow (j0 + j1 - J)*TBME_exchange;

  return TBME;
}

complex<double> TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (
									    const int J , 
									    const unsigned int s0 , 
									    const unsigned int s1 , 
									    const unsigned int s2 , 
									    const unsigned int s3 , 
									    const class array<class nlj_struct> &shells_qn , 
									    const class array<complex<double> > &reduced_grad_P2_tab)
{
  const class nlj_struct &shell_qn_s0 = shells_qn(s0);
  const class nlj_struct &shell_qn_s1 = shells_qn(s1);
  const class nlj_struct &shell_qn_s2 = shells_qn(s2);

  const int l0 = shell_qn_s0.get_l ();
  const int l1 = shell_qn_s1.get_l ();
  const int l2 = shell_qn_s2.get_l ();
  
  const unsigned int bp_s0 = binary_parity_from_orbital_angular_momentum (l0);
  const unsigned int bp_s1 = binary_parity_from_orbital_angular_momentum (l1);
  const unsigned int bp_s2 = binary_parity_from_orbital_angular_momentum (l2);
  
  if ((bp_s0 == bp_s2) && (bp_s1 == bp_s2)) return 0.0;

  const int T = 1;

  if (s2 == s3)
    {
      if ((J + T)%2 == 0) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;

      const double antisymmetry_norm_out = (s0 == s1) ? (M_SQRT1_2) : (1.0);

      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const complex<double> TBME = antisymmetry_norm*TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);

      return TBME;
    }

  if (s0 == s1)
    {
      if ((J + T)%2 == 0) return 0.0; 

      const complex<double> TBME = M_SQRT2*TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);

      return TBME;
    }

  const complex<double> TBME_direct   = TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s0 , s1 , s2 , s3 , shells_qn , shells_qn);
  const complex<double> TBME_exchange = TBME_J (J , reduced_grad_P2_tab , reduced_grad_P2_tab , s1 , s0 , s2 , s3 , shells_qn , shells_qn);

  const double j0 = shell_qn_s0.get_j ();
  const double j1 = shell_qn_s1.get_j ();
  
  const complex<double> TBME = TBME_direct - minus_one_pow (j0 + j1 - J)*TBME_exchange;

  return TBME;
}

double TBME_CM_operator::P2_over_2M::TBME_J_pn (
						const int J , 
						const unsigned int s0 , 
						const unsigned int s1 , 
						const unsigned int s2 , 
						const unsigned int s3 , 
						const class array<class nlj_struct> &shells_qn_prot , 
						const class array<class nlj_struct> &shells_qn_neut , 
						const class array<double> &reduced_grad_P2_prot_tab , 
						const class array<double> &reduced_grad_P2_neut_tab)
{
  const double TBME = TBME_J (J , reduced_grad_P2_prot_tab , reduced_grad_P2_neut_tab , s0 , s1 , s2 , s3 , shells_qn_prot , shells_qn_neut);

  return TBME;
}

complex<double> TBME_CM_operator::P2_over_2M::TBME_J_pn (
							 const int J , 
							 const unsigned int s0 , 
							 const unsigned int s1 , 
							 const unsigned int s2 , 
							 const unsigned int s3 , 
							 const class array<class nlj_struct> &shells_qn_prot , 
							 const class array<class nlj_struct> &shells_qn_neut , 
							 const class array<complex<double> > &reduced_grad_P2_prot_tab , 
							 const class array<complex<double> > &reduced_grad_P2_neut_tab)
{
  const complex<double> TBME = TBME_J (J , reduced_grad_P2_prot_tab , reduced_grad_P2_neut_tab , s0 , s1 , s2 , s3 , shells_qn_prot , shells_qn_neut);

  return TBME;
}




