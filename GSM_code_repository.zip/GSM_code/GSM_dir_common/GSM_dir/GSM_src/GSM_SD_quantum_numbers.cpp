#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------


// Class SD_quantum_numbers
// ---------------------
// Class SD_quantum_numbers stores the quantum numbers necessary to fully determine a given Slater determinant, made of protons only or neutrons only. 
// Indeed, a SD index only depends on its configuration, so that other quantum numbers must be given.
// It contains its binary parity (see observables_basic_functions.cpp for definition), its number of particles in the continuum, the index of its configuration, 
// its angular momentum projection + M_max, with M_max = N_valence_nucleons . m_max, so that it is an integer
// and the SD index which depends on its configuration




SD_quantum_numbers::SD_quantum_numbers () :
  BP (0) , 
  n_scat (0) ,
  iC (0) , 
  iM (0) , 
  SD_index (0) 
{}

SD_quantum_numbers::SD_quantum_numbers (
					const unsigned char BP_c , 
					const unsigned char n_scat_c ,
					const unsigned int iC_c , 
					const unsigned short int iM_c ,
					const unsigned int SD_index_c)
{
  initialize (BP_c , n_scat_c , iC_c , iM_c , SD_index_c);
}

void SD_quantum_numbers::initialize (
				     const unsigned char BP_c , 
				     const unsigned char n_scat_c ,
				     const unsigned int iC_c , 
				     const unsigned short int iM_c , 
				     const unsigned int SD_index_c)
{
  BP = BP_c;
  
  n_scat = n_scat_c;

  iC = iC_c;

  iM = iM_c;

  SD_index = SD_index_c;
}
  
void SD_quantum_numbers::initialize (const class SD_quantum_numbers &X)
{
  BP = X.BP;

  n_scat = X.n_scat;

  iC = X.iC;

  iM = X.iM;

  SD_index = X.SD_index;
}



bool operator == (const class SD_quantum_numbers &A , const class SD_quantum_numbers &B)
{
  if ((A.get_BP () != B.get_BP ()) || (A.get_n_scat () != B.get_n_scat ()) || (A.get_iC () != B.get_iC ()) || (A.get_iM () != B.get_iM ()) || (A.get_SD_index () != B.get_SD_index ())) return false;

  return true;
}



bool operator != (const class SD_quantum_numbers &A , const class SD_quantum_numbers &B)
{
  return !(A == B);
}




double used_memory_calc (const class SD_quantum_numbers &T)
{
  return sizeof (T)/1000000.0;
}

