#include "../GSM_include/GSM_include_def_common.h"

using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace beta_transitions_radial_OBMEs;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// FFBD means first-forbidden beta decay
// -------------------------------------





// Calculation of the reduced beta transition matrix elements for a given suboperator for all one-body basis states
// ----------------------------------------------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// One loops over all one-body basis states and one calculates all associated one-body matrix elements of the considered suboperator.
// Radial integrals are calculated first. Angular parts are considered afterwards.
// Radial integrals can be calculated from a direct radial integration of one-body basis states or using a HO expansion of the considered suboperator, 
// in which case radial overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The reduced matrix element is directly put to zero if parity is not conserved.

void beta_transitions_common::beta_suboperator_OBMEs_reduced_calc (
								   const bool is_it_HO_expansion , 
								   const enum radial_operator_type radial_operator , 
								   const enum beta_suboperator_type beta_suboperator , 
								   const class interaction_class &inter_data , 
								   const class nucleons_data &data_in , 
								   const class nucleons_data &data_out , 
								   class array<TYPE> &OBMEs)
{
  const unsigned int BP_Op = BP_beta_suboperator_determine (beta_suboperator);

  const unsigned int N_nlj_in = data_in.get_N_nlj ();
  const unsigned int N_nlj_out = data_out.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn_in = data_in.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_out = data_out.get_shells_quantum_numbers ();

  class array<TYPE> radial_OBMEs(N_nlj_in , N_nlj_out);

  radial_OBMEs_calc (is_it_HO_expansion , radial_operator , inter_data , data_in , data_out , radial_OBMEs);
    
  for (unsigned int s_in = 0 ; s_in < N_nlj_in ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj_out ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn_in(s_in);
	const class nlj_struct &shell_qn_out = shells_qn_out(s_out);
	
	const int l_in = shell_qn_in.get_l ();
	const int l_out = shell_qn_out.get_l ();

	if (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op)
	  {
	    const double j_in = shell_qn_in.get_j ();
	    const double j_out = shell_qn_out.get_j ();

	    const TYPE radial_OBME = radial_OBMEs(s_in , s_out);

	    const TYPE OBME = beta_suboperator_OBME_reduced_calc (beta_suboperator , radial_OBME , l_in , j_in , l_out , j_out);

	    OBMEs(s_in , s_out) = OBME;
	  }
      }
}









// Determination of used class nucleons_data
// -------------------------------------------------------------------------
// According to the use of beta+ or beta- decay, the in and out spaces are proton or neutron spaces.
// This selection is done here.

const class nucleons_data & beta_transitions_common::data_in_determine (
									const enum beta_pm_type beta_pm , 
									const class nucleons_data &prot_data , 
									const class nucleons_data &neut_data)
{
  switch (beta_pm)
    {
    case BETA_PLUS:  return prot_data;
    case BETA_MINUS: return neut_data;

    default: abort_all ();
    }

  return neut_data;
}


const class nucleons_data & beta_transitions_common::data_out_determine (
									 const enum beta_pm_type beta_pm , 
									 const class nucleons_data &prot_data , 
									 const class nucleons_data &neut_data)
{
  switch (beta_pm)
    {
    case BETA_PLUS:  return neut_data;
    case BETA_MINUS: return prot_data;

    default: abort_all ();
    }

  return neut_data;
}




// Calculation and print on screen of allowed beta decays
// ------------------------------------------------------
// Allowed beta decays are calculated and printed on screen from the values of the matrix elements of beta suboperators.
// Standard formulas are used.

void beta_transitions_common::allowed_calc_print (
						  const enum beta_pm_type beta_pm , 
						  const int A , 
						  const int Z_daughter , 
						  const double W0 , 
						  const double J_IN , 
						  const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::allowed_calc_print");

  const double reduction_constant = 1.0/hat (J_IN);
  
  const unsigned int FERMI_ALLOWED_index        = beta_suboperator_type_index_determine (FERMI_ALLOWED);
  const unsigned int GAMOW_TELLER_ALLOWED_index = beta_suboperator_type_index_determine (GAMOW_TELLER_ALLOWED);

  const TYPE Fermi_NBME        = beta_suboperators_tab(FERMI_ALLOWED_index);
  const TYPE Gamow_Teller_NBME = beta_suboperators_tab(GAMOW_TELLER_ALLOWED_index);

  const double Fermi_relativity_constant        = relativity_constant_beta_suboperator_determine (beta_pm , FERMI_ALLOWED);
  const double Gamow_Teller_relativity_constant = relativity_constant_beta_suboperator_determine (beta_pm , GAMOW_TELLER_ALLOWED);

  const TYPE relativity_constant_Fermi_NBME = Fermi_NBME*Fermi_relativity_constant*reduction_constant;

  const TYPE relativity_constant_Gamow_Teller_NBME = Gamow_Teller_NBME*Gamow_Teller_relativity_constant*reduction_constant;

  const TYPE form_factor_Fermi = relativity_constant_Fermi_NBME*relativity_constant_Fermi_NBME;

  const TYPE form_factor_Gamow_Teller = relativity_constant_Gamow_Teller_NBME*relativity_constant_Gamow_Teller_NBME;
  
  const TYPE form_factor = form_factor_Fermi + form_factor_Gamow_Teller;

  const TYPE fA = beta_transitions_f_allowed_calc (beta_pm , A , Z_daughter , W0);

  const TYPE f = form_factor*fA;

  const TYPE log_ft = log10 (6170.0/form_factor);

  if (inf_norm (Fermi_NBME)        > precision) cout << "Fermi                  : " << Fermi_NBME << endl;
  if (inf_norm (Gamow_Teller_NBME) > precision) cout << "Gamow-Teller           : " << Gamow_Teller_NBME << endl;

  cout << "beta form factor       : " << form_factor << endl;
  cout << "f[without form factor] : " << fA          << endl;
  cout << "f[with    form factor] : " << f           << endl;
  cout << "log (ft)               : " << log_ft      << endl << endl;
}





// Calculation and print on screen of first-forbidden beta decays
// --------------------------------------------------------------
// First-forbidden beta decays are calculated and printed on screen from the values of the matrix elements of beta suboperators.
// Standard formulas are used.
// See M. T. Mustonen, M. Aunola, J. Suhonen, PRC 73, 054301 (2006) for the definition of log (ft).


void beta_transitions_common::first_forbidden_calc_print (
							  const enum beta_pm_type beta_pm , 
							  const int A , 
							  const int Z_daughter ,  
							  const double W0 , 
							  const double J_IN , 
							  const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::first_forbidden_calc_print");

  const double reduction_constant = 1.0/hat (J_IN);

  const double w_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , W_FFBD);
  const double u_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , U_FFBD);
  const double z_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , Z_FFBD);
  const double x_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , X_FFBD);

  const double xi_prime_v_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , XI_PRIME_V_FFBD);
  const double xi_prime_y_constant_relativity = relativity_constant_beta_suboperator_determine (beta_pm , XI_PRIME_Y_FFBD);

  const unsigned int W_FFBD_index = beta_suboperator_type_index_determine (W_FFBD);
  const unsigned int U_FFBD_index = beta_suboperator_type_index_determine (U_FFBD);
  const unsigned int Z_FFBD_index = beta_suboperator_type_index_determine (Z_FFBD);
  const unsigned int X_FFBD_index = beta_suboperator_type_index_determine (X_FFBD);

  const unsigned int W_COULOMB_index = beta_suboperator_type_index_determine (W_FFBD_COULOMB);
  const unsigned int U_COULOMB_index = beta_suboperator_type_index_determine (U_FFBD_COULOMB);
  const unsigned int X_COULOMB_index = beta_suboperator_type_index_determine (X_FFBD_COULOMB);

  const unsigned int XI_PRIME_V_FFBD_index = beta_suboperator_type_index_determine (XI_PRIME_V_FFBD);
  const unsigned int XI_PRIME_Y_FFBD_index = beta_suboperator_type_index_determine (XI_PRIME_Y_FFBD);

  const TYPE w = beta_suboperators_tab(W_FFBD_index)*reduction_constant*w_constant_relativity;
  const TYPE u = beta_suboperators_tab(U_FFBD_index)*reduction_constant*u_constant_relativity;
  const TYPE z = beta_suboperators_tab(Z_FFBD_index)*reduction_constant*z_constant_relativity;
  const TYPE x = beta_suboperators_tab(X_FFBD_index)*reduction_constant*x_constant_relativity;

  const TYPE w_prime = beta_suboperators_tab(W_COULOMB_index)*reduction_constant*w_constant_relativity;
  const TYPE u_prime = beta_suboperators_tab(U_COULOMB_index)*reduction_constant*u_constant_relativity;
  const TYPE x_prime = beta_suboperators_tab(X_COULOMB_index)*reduction_constant*x_constant_relativity;

  const TYPE xi_prime_v = beta_suboperators_tab(XI_PRIME_V_FFBD_index)*reduction_constant*xi_prime_v_constant_relativity;
  const TYPE xi_prime_y = beta_suboperators_tab(XI_PRIME_Y_FFBD_index)*reduction_constant*xi_prime_y_constant_relativity;

  const TYPE k  = beta_transitions_k_calc  (A , Z_daughter , W0 , w , w_prime , x , x_prime , u , u_prime , z , xi_prime_v , xi_prime_y);
  const TYPE ka = beta_transitions_ka_calc (A , Z_daughter , W0 ,               x , x_prime , u , u_prime , z ,              xi_prime_y); 
  const TYPE kb = beta_transitions_kb_calc (A , Z_daughter , W0 , w , w_prime , x , x_prime , u , u_prime     , xi_prime_v , xi_prime_y);
  const TYPE kc = beta_transitions_kc_calc (x , u , z);

  const TYPE fA = beta_transitions_f_first_forbidden_calc (beta_pm , A , Z_daughter , W0 , 1.0 , 0.0 , 0.0 , 0.0);
  const TYPE f  = beta_transitions_f_first_forbidden_calc (beta_pm , A , Z_daughter , W0 , k   , ka   , kb , kc);
  
  const TYPE log_ft = log10 (fA*6170.0/f);

  if (inf_norm (w) > precision) cout << "w               : " << w << endl;
  if (inf_norm (x) > precision) cout << "x               : " << x << endl;
  if (inf_norm (u) > precision) cout << "u               : " << u << endl;
  if (inf_norm (z) > precision) cout << "z               : " << z << endl;
 
  if (inf_norm (w_prime) > precision) cout << "w'              : " << w_prime << endl;
  if (inf_norm (x_prime) > precision) cout << "x'              : " << x_prime << endl;
  if (inf_norm (u_prime) > precision) cout << "u'              : " << u_prime << endl;
  
  if (inf_norm (xi_prime_v) > precision) cout << "xi'v            : " << xi_prime_v << endl;
  if (inf_norm (xi_prime_y) > precision) cout << "xi'y            : " << xi_prime_y << endl;
  
  cout << "f[no structure] : " << fA     << endl;
  cout << "f               : " << f      << endl;
  cout << "log (ft)        : " << log_ft << endl << endl;
}






// Calculation and print on screen of beta decays
// ----------------------------------------------
// First-forbidden or allowed beta decays are calculated and printed on screen from the values of the matrix elements of beta suboperators.
// Standard formulas are used.

void beta_transitions_common::calc_print (
					  const enum beta_type beta , 
					  const enum beta_pm_type beta_pm , 
					  const int A , 
					  const int Z_daughter ,  
					  const double W0 ,  
					  const double J_IN , 
					  const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::calc_print");

  switch (beta)
    {
    case ALLOWED:                 allowed_calc_print (beta_pm , A , Z_daughter , W0 , J_IN , beta_suboperators_tab); break;
    case FIRST_FORBIDDEN: first_forbidden_calc_print (beta_pm , A , Z_daughter , W0 , J_IN , beta_suboperators_tab); break;

    default: error_message_print_abort ("No beta transition recognized in beta_transitions_common::calc_print"); break;
    }
}






// Calculation and print on file of allowed beta decays for an array of given radii
// --------------------------------------------------------------------------------
// Allowed beta decays form factors are calculated and printed on file from the values of the matrix elements of beta suboperators.
// The radial part is considered for all radii and there is no integration over r.
// Standard formulas are used but no relativistic corrections are considered.



void beta_transitions_common::strength::allowed_calc_store (
							    const class array<double> &r_bef_R_tab , 
							    const string &beta_strength_string , 
							    const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::strength::allowed_calc_store");

  const unsigned int Nr = r_bef_R_tab.dimension (0);

  const unsigned int FERMI_ALLOWED_index = beta_suboperator_type_index_determine (FERMI_ALLOWED);

  const unsigned int GAMOW_TELLER_ALLOWED_index = beta_suboperator_type_index_determine (GAMOW_TELLER_ALLOWED);

  ofstream beta_strength_file(beta_strength_string.c_str ());

  beta_strength_file.precision (15);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const double r = r_bef_R_tab(i);

      const TYPE Fermi_NBME = beta_suboperators_tab(FERMI_ALLOWED_index , i);

      const TYPE Gamow_Teller_NBME = beta_suboperators_tab(GAMOW_TELLER_ALLOWED_index , i);

      beta_strength_file << r << " " << Fermi_NBME << " " << Gamow_Teller_NBME << endl;
    }
}








// Calculation and print on file of first-forbidden beta decays for an array of given radii
// ----------------------------------------------------------------------------------------
// First-forbidden beta decays are calculated and printed on file from the values of the matrix elements of beta suboperators.
// The radial part is considered for all radii and there is no integration over r.
// Standard formulas are used but no relativistic corrections are considered.


void beta_transitions_common::strength::first_forbidden_calc_store (
								    const class array<double> &r_bef_R_tab , 
								    const string &beta_strength_string , 
								    const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::strength::first_forbidden_calc_store");

  const unsigned int Nr = r_bef_R_tab.dimension (0);

  const unsigned int W_FFBD_index = beta_suboperator_type_index_determine (W_FFBD);
  const unsigned int U_FFBD_index = beta_suboperator_type_index_determine (U_FFBD);
  const unsigned int Z_FFBD_index = beta_suboperator_type_index_determine (Z_FFBD);
  const unsigned int X_FFBD_index = beta_suboperator_type_index_determine (X_FFBD);

  const unsigned int W_FFBD_COULOMB_index = beta_suboperator_type_index_determine (W_FFBD_COULOMB);
  const unsigned int U_FFBD_COULOMB_index = beta_suboperator_type_index_determine (U_FFBD_COULOMB);
  const unsigned int X_FFBD_COULOMB_index = beta_suboperator_type_index_determine (X_FFBD_COULOMB);

  const unsigned int XI_PRIME_V_FFBD_index = beta_suboperator_type_index_determine (XI_PRIME_V_FFBD);
  const unsigned int XI_PRIME_Y_FFBD_index = beta_suboperator_type_index_determine (XI_PRIME_Y_FFBD);

  ofstream beta_strength_file(beta_strength_string.c_str ());

  beta_strength_file.precision (15);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const double r = r_bef_R_tab(i);

      const TYPE w_beta_suboperator = beta_suboperators_tab(W_FFBD_index , i);
      const TYPE u_beta_suboperator = beta_suboperators_tab(U_FFBD_index , i);
      const TYPE z_beta_suboperator = beta_suboperators_tab(Z_FFBD_index , i);
      const TYPE x_beta_suboperator = beta_suboperators_tab(X_FFBD_index , i);

      const TYPE w_prime_beta_suboperator = beta_suboperators_tab(W_FFBD_COULOMB_index , i);
      const TYPE u_prime_beta_suboperator = beta_suboperators_tab(U_FFBD_COULOMB_index , i);
      const TYPE x_prime_beta_suboperator = beta_suboperators_tab(X_FFBD_COULOMB_index , i);

      const TYPE xi_prime_v_beta_suboperator = beta_suboperators_tab(XI_PRIME_V_FFBD_index , i);
      const TYPE xi_prime_y_beta_suboperator = beta_suboperators_tab(XI_PRIME_Y_FFBD_index , i);

      beta_strength_file << r << " " 
			 << w_beta_suboperator << " " 
			 << w_prime_beta_suboperator << " " 
			 << x_beta_suboperator << " "
			 << x_prime_beta_suboperator << " " 
			 << u_beta_suboperator << " " 
			 << u_prime_beta_suboperator << " "
			 << z_beta_suboperator << " " 
			 << xi_prime_v_beta_suboperator << " " 
			 << xi_prime_y_beta_suboperator << endl;
    }
}




// Calculation and print on file of beta decays
// --------------------------------------------
// First-forbidden or allowed beta decays are calculated and printed on file from the values of the matrix elements of beta suboperators.
// The radial part is considered for all radii and there is no integration over r.
// Standard formulas are used but no relativistic corrections are considered.

void beta_transitions_common::strength::calc_store (
						    const enum beta_type beta ,
						    const class array<double> &r_bef_R_tab ,  
						    const string &beta_strength_string , 
						    const class array<TYPE> &beta_suboperators_tab)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in beta_transitions_common::strength::calc_store");

  switch (beta)
    {
    case ALLOWED:
      {
	allowed_calc_store (r_bef_R_tab , beta_strength_string , beta_suboperators_tab);
      } break;

    case FIRST_FORBIDDEN:
      {
	first_forbidden_calc_store (r_bef_R_tab , beta_strength_string , beta_suboperators_tab);
      } break;

    default: error_message_print_abort ("No beta transition recognized in beta_transitions_common::strength::calc_store");
    }
}



