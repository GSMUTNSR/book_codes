#include "../GSM_include/GSM_include_def_common.h"

using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// Calculation of the radial or momentum array of wave function products over r^2
// ------------------------------------------------------------------------------
// One calculates here the radial functions u_a(r) u_b(r) / r^2 or u_a(k) u_b(k) / k^2 entering correlation density matrix elements.
//
// rk is r or k.

void correlation_density_TBMEs::radial_OBMEs_calc (
						   const bool is_it_radial ,
						   const bool is_it_Gauss_Legendre ,
						   const class baryons_data &data ,
						   class array<TYPE> &OBMEs_shells)
{
  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_nlj = OBMEs_shells.dimension (0);
  
  const unsigned int N_RKmax = OBMEs_shells.dimension (2);

  OBMEs_shells = 0.0;
  
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {	
	const class spherical_state &shell_in  = shells(s_in);
	const class spherical_state &shell_out = shells(s_out);
	
	const enum particle_type B_in = shell_in.get_particle ();
	const enum particle_type B_out = shell_out.get_particle ();
	 
	if (B_in == B_out)
	  {
	    const int strangeness = particle_strangeness_determine (B_in);

	    if (strangeness == 0)
	      {
		const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_in.get_r_bef_R_tab_GL ()) : (shell_in.get_r_bef_R_tab_uniform ());
	
		const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (shell_in.get_k_tab_GL ()) : (shell_in.get_k_tab_uniform ());
	
		const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);

		const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_bef_R_tab_GL ())  : (shell_in.get_wf_bef_R_tab_uniform ());
		const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_bef_R_tab_GL ()) : (shell_out.get_wf_bef_R_tab_uniform ());

		const class array<complex<double> > &dwf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_bef_R_tab_GL ())  : (shell_in.get_dwf_bef_R_tab_uniform ());
		const class array<complex<double> > &dwf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_bef_R_tab_GL ()) : (shell_out.get_dwf_bef_R_tab_uniform ());

		const class array<complex<double> > &wf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_momentum_tab_GL ())  : (shell_in.get_wf_momentum_tab_uniform ());
		const class array<complex<double> > &wf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_momentum_tab_GL ()) : (shell_out.get_wf_momentum_tab_uniform ());

		const class array<complex<double> > &dwf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_momentum_tab_GL ())  : (shell_in.get_dwf_momentum_tab_uniform ());
		const class array<complex<double> > &dwf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_momentum_tab_GL ()) : (shell_out.get_dwf_momentum_tab_uniform ());

		const class array<complex<double> > &wf_in_rk_tab  = (is_it_radial) ?  (wf_in_bef_R_tab) :  (wf_in_momentum_tab);
		const class array<complex<double> > &dwf_in_rk_tab = (is_it_radial) ? (dwf_in_bef_R_tab) : (dwf_in_momentum_tab);
	
		const class array<complex<double> > &wf_out_rk_tab  = (is_it_radial) ?  (wf_out_bef_R_tab) :  (wf_out_momentum_tab);
		const class array<complex<double> > &dwf_out_rk_tab = (is_it_radial) ? (dwf_out_bef_R_tab) : (dwf_out_momentum_tab);
	
		if (N_RKmax > 0)
		  {
		    const double rk0 = rk_tab(0);
		    const double rk0_2 = rk0*rk0;
	    
		    const complex<double>  wf_in_rk0 =  wf_in_rk_tab(0);
		    const complex<double> dwf_in_rk0 = dwf_in_rk_tab(0);
	    
		    const complex<double>  wf_out_rk0 =  wf_out_rk_tab(0);	    
		    const complex<double> dwf_out_rk0 = dwf_out_rk_tab(0);
	    
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (wf_in_rk0*wf_out_rk0/rk0_2) : (dwf_in_rk0*dwf_out_rk0);
#endif

#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (real (wf_in_rk0)*real (wf_out_rk0)/rk0_2) : (real (dwf_in_rk0)*real (dwf_out_rk0));
#endif
		  }
	
		for (unsigned int i = 1 ; i < N_RKmax ; i++)
		  {
		    const double rk = rk_tab(i);
	    
		    const double rk2 = rk*rk;
	    
		    const complex<double> wf_in_rk  = wf_in_rk_tab(i);
		    const complex<double> wf_out_rk = wf_out_rk_tab(i);
	    
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , i) = wf_in_rk*wf_out_rk/rk2;
#endif
		
#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , i) = real (wf_in_rk)*real (wf_out_rk)/rk2;
#endif
		  }
	      }
	  }
      }
}

// Calculation of the theta dependent part of the two-body matrix elements of correlation density
// ----------------------------------------------------------------------------------------------
// One has \delta (theta - theta_12) = 2 Pi sin(theta) \sum_l Pl(cos (theta)) Pl(cos (theta_12)) in the two-body matrix element of correlation density.
// The theta angle is fixed and theta_12 depends on the in and out states in the two-body matrix element and will be integrated in the two-body matrix element.
// As the in and out states cannot couple to more than 2.lmax for their orbital part, the infinite sum of the Dirac delta reduces to a finite sum with l <= 2.lmax .
// Hence, one stores here 2 Pi sin(theta) Pl(cos (theta) for all l <= 2.lmax .

void correlation_density_TBMEs::theta12_Dirac_multipolar_calc (
							       const class array<double> &theta_tab ,
							       class array<double> &theta12_Dirac_multipolar_tab)
{
  const double two_Pi = 6.2831853071795865;

  const int two_lmax = theta12_Dirac_multipolar_tab.dimension (0) - 1;

  const unsigned int theta_number = theta_tab.dimension (0);

  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double theta = theta_tab(it);

      const double cos_theta = cos (theta);
      const double sin_theta = sin (theta);
      
      const double two_Pi_sin_theta = two_Pi*sin_theta;

      for (int l = 0 ; l <= two_lmax ; l++) 
	{
	  const double Pl_cos_theta = spherical_harmonics::Plm (l , 0 , cos_theta);

	  theta12_Dirac_multipolar_tab(l , it) = Pl_cos_theta*two_Pi_sin_theta;
	}
    }

}




// Calculation of the radial/momentum overlap integrals entering integrated correlation density with the HO states of interaction class
// ---------------------------------------------------------------------------------------------------------------------------
// A direct calculation of the integral on the real axis is used. 
// One uses the HO one-body states of the interaction class, as these ones are used to define the HO expansion of operators, such as interaction two-body matrix elements.

double correlation_density_TBMEs::rk_overlap_HO_states_calc (
							     const class interaction_class &inter_data , 
							     const unsigned int a , 
							     const unsigned int b)
{
  const class array<double> &w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();
  const class array<double> &w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();

  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data.get_HO_wfs_aft_R_tab_GL ();

  const unsigned int N_bef_R_GL = w_bef_R_tab_GL.dimension(0);
  const unsigned int N_aft_R_GL = w_aft_R_tab_GL.dimension(0);

  const class array<class nlj_struct> &shells_HO_qn = inter_data.get_shells_HO_qn ();

  const class nlj_struct &sa = shells_HO_qn(a);
  const class nlj_struct &sb = shells_HO_qn(b);

  const int na = sa.get_n ();
  const int la = sa.get_l ();
  
  const int nb = sb.get_n ();
  const int lb = sb.get_l ();

  double radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i); 

      radial_integral += w*HO_wfs_bef_R_tab_GL(na , la , i)*HO_wfs_bef_R_tab_GL(nb , lb , i);
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL(i);

      radial_integral += w*HO_wfs_aft_R_tab_GL(na , la , i)*HO_wfs_aft_R_tab_GL(nb , lb , i);
    }

  return radial_integral;
}






// Calculation of the radial/momentum overlap integrals entering integrated correlation density with HO states
// -----------------------------------------------------------------------------------------------------------
// A direct calculation of the integral on the real axis is used.
// The HO radial/momentum wave functions are supposed to be stored in input data here.

double correlation_density_TBMEs::rk_overlap_HO_states_calc (
							     const class spherical_state &wf_in , 
							     const class spherical_state &wf_out)
{
  const enum particle_type B_in = wf_in.get_particle ();
  const enum particle_type B_out = wf_out.get_particle ();
	 
  if (B_in != B_out) return 0.0;
    
  const int strangeness = particle_strangeness_determine (B_in);
	    
  if (strangeness != 0) return 0.0;
	      
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  const class array<double> &w_aft_R_tab_GL_real = wf_in.get_w_aft_R_tab_GL_real ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_aft_R_tab_GL_real  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_aft_R_tab_GL_real = wf_out.get_wf_aft_R_tab_GL_real ();

  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();

  double radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i); 

      radial_integral += w*real (wf_in_bef_R_tab_GL(i))*real (wf_out_bef_R_tab_GL(i));
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL_real(i);

      radial_integral += w*real (wf_in_aft_R_tab_GL_real(i))*real (wf_out_aft_R_tab_GL_real(i));
    }

  return radial_integral;
}




// Calculation of the radial/momentum overlap integral entering integrated correlation density with the HO expansion
// -----------------------------------------------------------------------------------------------------------------
// The radial integral is calculated from a HO expansion, where radial/momentum overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The HO expansion in the interaction class is used up to lmax_for_interaction, which can be smaller than the maximal orbital angular momentum used in the one-body basis.
// They can be different if one considers N hbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
// for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
// Indeed, high-l configurations are just there to have an exact separation of intrinsic and center of mass parts. 
// All radial/momentum overlaps involving states with l > lmax_for_interaction with the HO expansion are then put to zero.
// Direct radial integration is always done for HO one-body basis states.

TYPE correlation_density_TBMEs::rk_overlap_HO_expansion_calc (
							      const class interaction_class &inter_data , 
							      const class baryons_data &data , 
							      const unsigned int s_in , 
							      const unsigned int s_out) 
{
  const class array<class spherical_state> &shells = data.get_shells ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const class nlj_struct &shell_qn_in = shells_qn(s_in);
  const class nlj_struct &shell_qn_out = shells_qn(s_out);

  const enum particle_type B_in = shell_qn_in.get_particle ();
  const enum particle_type B_out = shell_qn_out.get_particle ();
	 
  if (B_in != B_out) return 0.0;
  
  const int strangeness = particle_strangeness_determine (B_in);
	    
  if (strangeness != 0) return 0.0;
  
  const class spherical_state &wf_in = shells(s_in);
  const class spherical_state &wf_out = shells(s_out);

  const bool is_it_HO_in = shell_qn_in.get_is_it_HO ();
  const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();

  if (is_it_HO_in || is_it_HO_out)
    return rk_overlap_HO_states_calc (wf_in , wf_out);
  else
    {
      const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

      const bool is_it_charged = (nucleonic_particle == PROTON);
      
      const class array<vector_class<complex<double> > > &HO_overlaps = data.get_HO_overlaps ();
      
      const class array<class nlj_table<unsigned int> > &shells_HO_indices_p_tab = inter_data.get_shells_HO_indices_p_tab ();
      const class array<class nlj_table<unsigned int> > &shells_HO_indices_n_tab = inter_data.get_shells_HO_indices_n_tab ();

      const class array<class nlj_table<unsigned int> > &shells_HO_indices_tab = (is_it_charged)  ? (shells_HO_indices_p_tab) : (shells_HO_indices_n_tab);

      const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();

      const class vector_class<complex<double> > &HO_overlaps_s_in = HO_overlaps(s_in);
      const class vector_class<complex<double> > &HO_overlaps_s_out = HO_overlaps(s_out);

      const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();

      const int l_in = wf_in.get_l ();
      const int l_out = wf_out.get_l ();

      if (l_in  > lmax_for_interaction) return 0.0;
      if (l_out > lmax_for_interaction) return 0.0;
      
      const enum particle_type particle_in  = shell_qn_in.get_particle ();
      const enum particle_type particle_out = shell_qn_out.get_particle ();

      const unsigned int particle_index_in  = charge_baryon_index_determine (particle_in);
      const unsigned int particle_index_out = charge_baryon_index_determine (particle_out);
			
      const class nlj_table<unsigned int> &shells_HO_indices_shell_in  = shells_HO_indices_tab(particle_index_in);
      const class nlj_table<unsigned int> &shells_HO_indices_shell_out = shells_HO_indices_tab(particle_index_out);
			
      const double j_in = wf_in.get_j ();
      const double j_out = wf_out.get_j ();

      const int nmax_HO_l_in = nmax_HO_lab_tab(l_in);
      const int nmax_HO_l_out = nmax_HO_lab_tab(l_out);

      TYPE rk_OBME = 0.0;

      for (int n_HO_in = 0 ; n_HO_in <= nmax_HO_l_in ; n_HO_in++) 
	for (int n_HO_out = 0 ; n_HO_out <= nmax_HO_l_out ; n_HO_out++)
	  {
	    const unsigned int HO_index_in  = shells_HO_indices_shell_in (n_HO_in  , l_in , j_in);
	    const unsigned int HO_index_out = shells_HO_indices_shell_out(n_HO_out , l_out , j_out);

#ifdef TYPEisDOUBLECOMPLEX
	    const TYPE HO_overlap_product = HO_overlaps_s_in(n_HO_in)*HO_overlaps_s_out(n_HO_out);
#endif
	    
#ifdef TYPEisDOUBLE
	    const TYPE HO_overlap_product = real (HO_overlaps_s_in(n_HO_in))*real (HO_overlaps_s_out(n_HO_out));
#endif
	    
	    rk_OBME += HO_overlap_product*rk_overlap_HO_states_calc(inter_data , HO_index_in , HO_index_out);
	  }

      return rk_OBME;
    }
}




// Calculation of the radial/momentum overlap integral entering integrated correlation density with a truncated integral in R, with R the rotation point
// -----------------------------------------------------------------------------------------------------------------------------------------------------
// The radial/momentum overlap is calculated with R cut, i.e. one truncates the integral to [0:R], with R the rotation point.

TYPE correlation_density_TBMEs::rk_overlap_R_cut_calc (
						       const class baryons_data &data ,
						       const unsigned int s_in ,
						       const unsigned int s_out)
{
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();

  const class array<class spherical_state> &shells = data.get_shells ();

  const class spherical_state &shell_in  = shells(s_in);
  const class spherical_state &shell_out = shells(s_out);

  const enum particle_type B_in = shell_in.get_particle ();
  const enum particle_type B_out = shell_out.get_particle ();
	 
  if (B_in != B_out) return 0.0;
  
  const int strangeness = particle_strangeness_determine (B_in);
	    
  if (strangeness != 0) return 0.0;
  
  const class array<double> &w_bef_R_tab_GL = shell_in.get_w_bef_R_tab_GL ();

  const class array<complex<double> > &wf_in_bef_R_tab_GL  = shell_in.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = shell_out.get_wf_bef_R_tab_GL ();

  TYPE rk_overlap = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i);

      const complex<double> wf_in_r = wf_in_bef_R_tab_GL(i);

      const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);

#ifdef TYPEisDOUBLECOMPLEX
      rk_overlap += wf_in_r*wf_out_r*w;
#endif
	    
#ifdef TYPEisDOUBLE
      rk_overlap += real (wf_in_r)*real (wf_out_r)*w;
#endif

    }

  return rk_overlap;
}
	 





// Calculation of the radial/momentum overlap integral entering integrated correlation density with a HO expansion or with a truncated integral in R, with R the rotation point
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calls one of the two functions above.

TYPE correlation_density_TBMEs::rk_overlap_calc (
						 const bool is_it_HO_expansion , 
						 const class interaction_class &inter_data , 
						 const class baryons_data &data , 
						 const unsigned int s_in , 
						 const unsigned int s_out)
{
  if (is_it_HO_expansion)
    return rk_overlap_HO_expansion_calc (inter_data , data , s_in , s_out);
  else
    return rk_overlap_R_cut_calc (data , s_in , s_out);
}





// Calculation of the angular part of the two-body matrix element of correlation density including spin projection
// ---------------------------------------------------------------------------------------------------------------
// One calculates here <j2 j3 | \delta (\theta - \theta_{12}) P(S=0 or 1) | j0 j1>^J or <j2 m2 j3 m3 | \delta (\theta - \theta_{12}) Psigma(S=0 or 1) | j0 m0 j1 m1>
// with the multipolar expansion of the Dirac delta with spin projection on S=0 or 1 (see theta12_Dirac_multipolar_calc).
// The multipolar expansion formula (but not the result) is indeed independent of the coupled or uncoupled character of the two-body matrix element.

double correlation_density_TBMEs::angular_delta_PS_ME_calc (
							    const class array<double> &theta12_Dirac_multipolar_tab , 
							    const int lmin_parity , 
							    const int lmax_parity , 
							    const class array<double> &Yl1_Yl2_PS_MEs , 
							    const int S , 
							    const unsigned int it)
{
  double angular_delta_PS_ME = 0.0; 

  for (int l = lmin_parity ; l <= lmax_parity ; l += 2)
    {
      const double two_Pi_sin_theta_Pl_cos_theta = theta12_Dirac_multipolar_tab(l , it);
      
      const double Yl1_Yl2_PS_ME = Yl1_Yl2_PS_MEs(S , l);

      angular_delta_PS_ME += Yl1_Yl2_PS_ME*two_Pi_sin_theta_Pl_cos_theta;
    }

  return angular_delta_PS_ME;
}





// Calculation of the angular part of the coupled two-body matrix element of correlation density including spin exchange
// ---------------------------------------------------------------------------------------------------------------------
// One calculates here <jc jd | [Yl(1) . Yl(2)] Psigma | ja jb>_J [4 Pi/(2l+1)]. One inserts a completeness relation of |ja_inter jb_inter>_J states between [Yl(1) . Yl(2)] and Psigma to calculate the matrix element.

double correlation_density_TBMEs::multipolar_expansion_Psigma_ME_calc (
								       const class multipolar_expansion_str &multipolar_expansion , 
								       const class Psigma_str &Psigma_MEs , 
								       const int la , const double ja , 
								       const int lb , const double jb , 
								       const int lc , const double jc , 
								       const int ld , const double jd , 
								       const int l ,
								       const int J)
{
  const double ja_inter_min_Psigma = abs (la - 0.5) , ja_inter_max_Psigma = la + 0.5 , ja_inter_min_Yl = abs (jc - l) , ja_inter_max_Yl = jc + l;
  const double jb_inter_min_Psigma = abs (lb - 0.5) , jb_inter_max_Psigma = lb + 0.5 , jb_inter_min_Yl = abs (jd - l) , jb_inter_max_Yl = jd + l;

  const double ja_inter_min = max (ja_inter_min_Psigma , ja_inter_min_Yl) , ja_inter_max = min (ja_inter_max_Psigma , ja_inter_max_Yl);
  const double jb_inter_min = max (jb_inter_min_Psigma , jb_inter_min_Yl) , jb_inter_max = min (jb_inter_max_Psigma , jb_inter_max_Yl);

  const int ja_inter_number = make_int (ja_inter_max - ja_inter_min) + 1;
  const int jb_inter_number = make_int (jb_inter_max - jb_inter_min) + 1;

  double multipolar_expansion_Psigma_J_ME = 0.0;

  for (int ja_inter_index = 0 ; ja_inter_index < ja_inter_number ; ja_inter_index++)
    {
      const double ja_inter = ja_inter_index + ja_inter_min;

      for (int jb_inter_index = 0 ; jb_inter_index < jb_inter_number ; jb_inter_index++)
	{
	  const double jb_inter = jb_inter_index + jb_inter_min;

	  if (abs (make_int (ja_inter - jb_inter)) > J) continue;

	  if (make_int (ja_inter + jb_inter) < J) continue;

	  const double Psigma_J_ME = Psigma_MEs(la , ja , lb , jb , la , ja_inter , lb , jb_inter , J);

	  const double multipolar_expansion_J_ME = multipolar_expansion(la , ja_inter , lb , jb_inter , lc , jc , ld , jd , l , J);

	  multipolar_expansion_Psigma_J_ME += multipolar_expansion_J_ME*Psigma_J_ME;
	}
    }

  return multipolar_expansion_Psigma_J_ME;
}





// Calculation of the angular part of the uncoupled two-body matrix element of correlation density without spin exchange
// ---------------------------------------------------------------------------------------------------------------------
// One calculates here <j2 m2 j3 m3 | Yl(1) . Yl(2) | j0 m0 j1 m1>. 
// Using the definition of the scalar product of Yl(1) . Yl(2) as a sum on ml, only one term remains.
// It is <j2 m2 j3 m3 | (-1)^(ml) Yl_ml(1) . Yl_ml(2) | j0 m0 j1 m1> = (-1)^ml <j2 m2 | Yl_ml | j0 m0> <j3 m3 | Yl_ml | j1 m1>, with ml = m2 - m0 = m3 - m1.

double correlation_density_TBMEs::uncoupled_Yl1_Yl2_ME_calc (
							     const class nljm_struct &phi0 , 
							     const class nljm_struct &phi1 , 
							     const class nljm_struct &phi2 , 
							     const class nljm_struct &phi3 , 
							     const int l , 
							     const class ljm_table<unsigned int> &ljm_indices , 
							     const class array<double> &Ylm_table_coupled_to_j)
{
  const int    l0 = phi0.get_l () , l1 = phi1.get_l () , l2 = phi2.get_l () , l3 = phi3.get_l ();
  const double j0 = phi0.get_j () , j1 = phi1.get_j () , j2 = phi2.get_j () , j3 = phi3.get_j ();
  const double m0 = phi0.get_m () , m1 = phi1.get_m () , m2 = phi2.get_m () , m3 = phi3.get_m ();

  const unsigned int ljm_s0 = ljm_indices(l0 , j0 , m0) , ljm_s1 = ljm_indices(l1 , j1 , m1);
  const unsigned int ljm_s2 = ljm_indices(l2 , j2 , m2) , ljm_s3 = ljm_indices(l3 , j3 , m3);

  const double Yl1_ME = Ylm_table_coupled_to_j(l , ljm_s0 , ljm_s2);
  const double Yl2_ME = Ylm_table_coupled_to_j(l , ljm_s1 , ljm_s3);

  const int ml = make_int (m2 - m0);

  const double Yl1_Yl2_ME = minus_one_pow (ml)*Yl1_ME*Yl2_ME;

  return Yl1_Yl2_ME;
}






// Calculation of the angular part of the uncoupled two-body matrix element of correlation density including spin exchange
// -----------------------------------------------------------------------------------------------------------------------
// One calculates here <j2 m2 j3 m3 | [Yl(1) . Yl(2)] Psigma | j0 m0 j1 m1>.
// One decouples |j m> states with |l ml> |s ms> states using Clebsch-Gordan coefficients. 
// Psigma is then straightforward to apply: Psigma |s1 ms1> |s2 ms2> = |s2 ms2> |s1 ms1> . It then generates spin overlaps immediate to calculate.
// After doing so, using the definition of the scalar product of Yl(1) . Yl(2) as a sum on ml, only one term remains per |l ml> |s ms> basis states.
// It is <l2 ml2 l3 ml3 | (-1)^(ml) Yl_ml(1) . Yl_ml(2) | l0 ml0 l1 l1> = (-1)^ml <l2 ml2 | Yl_ml | l0 ml0> <l3 ml3 | Yl_ml | l1 ml1>, with ml = ml2 - ml0 = ml3 - ml1.

double correlation_density_TBMEs::uncoupled_Yl1_Yl2_Psigma_ME_calc (
								    const class nljm_struct &phi0 , 
								    const class nljm_struct &phi1 , 
								    const class nljm_struct &phi2 , 
								    const class nljm_struct &phi3 , 
								    const int l , 
								    const class lm_table<unsigned int> &lm_indices , 
								    const class ljm_table<unsigned int> &ljm_indices , 
								    const class array<double> &Ylm_table_coupled_to_l , 
								    const class array<double> &CGs)
{
  const double s = ljm_indices.get_s ();
  
  const int s_number = make_int (2*s + 1);

  const int    l0 = phi0.get_l () , l1 = phi1.get_l () , l2 = phi2.get_l () , l3 = phi3.get_l ();
  const double j0 = phi0.get_j () , j1 = phi1.get_j () , j2 = phi2.get_j () , j3 = phi3.get_j ();
  const double m0 = phi0.get_m () , m1 = phi1.get_m () , m2 = phi2.get_m () , m3 = phi3.get_m ();

  const unsigned int ljm_s0 = ljm_indices(l0 , j0 , m0) , ljm_s1 = ljm_indices(l1 , j1 , m1);
  const unsigned int ljm_s2 = ljm_indices(l2 , j2 , m2) , ljm_s3 = ljm_indices(l3 , j3 , m3);

  double Yl1_Yl2_Psigma_ME = 0.0;

  for (int i_ms0 = 0 ; i_ms0 < s_number ; i_ms0++)
    {
      const double ms0 = i_ms0 - s;
      
      const double ms3 = ms0;

      const int ml0 = make_int (m0 - ms0);
      
      if (abs (ml0) > l0) continue;

      const int ml3 = make_int (m3 - ms3);
      
      if (abs (ml3) > l3) continue;

      const int i_ms3 = i_ms0;

      const unsigned int lm_s0 = lm_indices(l0 , ml0);
      const unsigned int lm_s3 = lm_indices(l3 , ml3);

      const double CG_s0 = CGs(lm_s0 , i_ms0 , ljm_s0);
      const double CG_s3 = CGs(lm_s3 , i_ms3 , ljm_s3);

      const double CG_s0_s3_product = CG_s0*CG_s3;

      for (int i_ms1 = 0 ; i_ms1 < s_number ; i_ms1++)
	{
	  const double ms1 = i_ms1 - s;

	  const double ms2 = ms1;

	  const int ml1 = make_int (m1 - ms1);
	  
	  if (abs (ml1) > l1) continue;

	  const int ml2 = make_int (m2 - ms2);
	  
	  if (abs (ml2) > l2) continue;

	  const int i_ms2 = i_ms1;

	  const unsigned int lm_s1 = lm_indices(l1 , ml1);
	  const unsigned int lm_s2 = lm_indices(l2 , ml2);

	  const double CG_s1 = CGs(lm_s1 , i_ms1 , ljm_s1);
	  const double CG_s2 = CGs(lm_s2 , i_ms2 , ljm_s2);

	  const double CG_s1_s2_product = CG_s1*CG_s2;

	  const int ml = ml2 - ml0;

	  const double Yl1_ME = Ylm_table_coupled_to_l(l , lm_s0 , lm_s2);
	  const double Yl2_ME = Ylm_table_coupled_to_l(l , lm_s1 , lm_s3);

	  const double phase_Yl1_Yl2_MEs_product = minus_one_pow (ml)*Yl1_ME*Yl2_ME;

	  Yl1_Yl2_Psigma_ME += CG_s0_s3_product*CG_s1_s2_product*phase_Yl1_Yl2_MEs_product;
	}
    }

  return Yl1_Yl2_Psigma_ME;
}

















// Calculation of coupled two-body matrix elements of correlation density including spin exchange integrated or not over r for given in and out protons or neutrons (plus a few hyperons if any) two-body states
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc jd | \delta (theta - theta_12) | ja jb>_J and <jc jd | \delta (theta - theta_12) \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.
// The radial/momentum overlaps entering <jc jd | \delta (theta - theta_12) | ja jb>_J are calculated in this routine with either HO expansion or truncated radial integrals (R cut).
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering correlation density are given as input.
// Radii come from Gauss-Legendre or uniform grids.
// The correlation density integrated over r is separated in S=0 and S=1 parts.
// Correlation density is summed over its S=0 and S=1 parts. 

void correlation_density_TBMEs::coupled_TBMEs_pp_nn_calc (
							  const bool is_it_HO_expansion , 
							  const int J , 
							  const class interaction_class &inter_data , 
							  const class baryons_data &data , 
							  const class array<TYPE> &rk_OBMEs , 
							  const class pair_str &pair_in , 
							  const class pair_str &pair_out , 
							  const class array<double> &theta12_Dirac_multipolar_tab , 
							  const class multipolar_expansion_str &multipolar_expansion , 
							  const class Psigma_str &Psigma_MEs , 
							  class array<TYPE> &angular_densities_TBMEs , 
							  class array<TYPE> &density_TBMEs)
{	
  const double four_Pi = 12.566370614359173;

  const unsigned int N_RKmax = density_TBMEs.dimension (0);
  
  const unsigned int theta_number = density_TBMEs.dimension (1);

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const unsigned int s0 = pair_in.get_left ()  , s1 = pair_in.get_right ();  //bra
  const unsigned int s2 = pair_out.get_left () , s3 = pair_out.get_right (); //ket

  const class nlj_struct &wf0 = shells_qn(s0) , &wf1 = shells_qn(s1);
  const class nlj_struct &wf2 = shells_qn(s2) , &wf3 = shells_qn(s3);

  const int l0 = wf0.get_l () , l1 = wf1.get_l ();
  const int l2 = wf2.get_l () , l3 = wf3.get_l ();
  
  const double j0 = wf0.get_j () , j1 = wf1.get_j ();
  const double j2 = wf2.get_j () , j3 = wf3.get_j ();

  const int lmin_02 = abs (l0 - l2) , lmin_13 = abs (l1 - l3) , lmin_dir = max (lmin_02 , lmin_13);
  const int lmax_02 =      l0 + l2  , lmax_13 =      l1 + l3  , lmax_dir = min (lmax_02 , lmax_13);

  const int lmin_dir_parity = ((lmin_dir + lmax_02)%2 == 0) ? (lmin_dir) : (lmin_dir+1);
  const int lmax_dir_parity = ((lmax_dir + lmax_02)%2 == 0) ? (lmax_dir) : (lmax_dir-1);

  const int lmin_12 = abs (l1 - l2) , lmin_03 = abs (l0 - l3) , lmin_exc = max (lmin_12 , lmin_03);
  const int lmax_12 =      l1 + l2  , lmax_03 =      l0 + l3  , lmax_exc = min (lmax_12 , lmax_03);

  const int lmin_exc_parity = ((lmin_exc + lmax_12)%2 == 0) ? (lmin_exc) : (lmin_exc+1);
  const int lmax_exc_parity = ((lmax_exc + lmax_12)%2 == 0) ? (lmax_exc) : (lmax_exc-1);

  const double antisymmetry_in  = (same_nlj_particle (wf0 , wf1)) ? (M_SQRT1_2) : (1.0);
  const double antisymmetry_out = (same_nlj_particle (wf2 , wf3)) ? (M_SQRT1_2) : (1.0);
  
  const double antisymmetry_product = antisymmetry_in*antisymmetry_out;

  const TYPE rk_overlap_02 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , s0 , s2);
  const TYPE rk_overlap_13 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , s1 , s3);

  const TYPE rk_overlap_12 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , s1 , s2);
  const TYPE rk_overlap_03 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , s0 , s3);

  const TYPE rk_overlap_dir = rk_overlap_02*rk_overlap_13;
  const TYPE rk_overlap_exc = rk_overlap_12*rk_overlap_03;

  class array<TYPE> rk_OBMEs_product_table(N_RKmax);

  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs(s0 , s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs(s1 , s3 , i);

      rk_OBMEs_product_table(i) = rk_OBME_02*rk_OBME_13;
    }

  const int phase_exc = minus_one_pow (j0 + j1 - J);

  class array<double> Yl1_Yl2_PS_dir_MEs(2 , lmax_dir_parity + 1);  
  class array<double> Yl1_Yl2_PS_exc_MEs(2 , lmax_exc_parity + 1);

  for (int l = lmin_dir_parity ; l <= lmax_dir_parity ; l += 2)
    {
      const double half_Yl1_Yl2_norm = (l + 0.5)/four_Pi;

      const double multipolar_expansion_dir_ME = multipolar_expansion(l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , l , J);
      
      const double multipolar_expansion_Psigma_dir_ME = multipolar_expansion_Psigma_ME_calc (multipolar_expansion , Psigma_MEs , l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , l , J);

      Yl1_Yl2_PS_dir_MEs(0 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_dir_ME - multipolar_expansion_Psigma_dir_ME);
      Yl1_Yl2_PS_dir_MEs(1 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_dir_ME + multipolar_expansion_Psigma_dir_ME);
    }

  for (int l = lmin_exc_parity ; l <= lmax_exc_parity ; l += 2) 
    {
      const double half_Yl1_Yl2_norm = (l + 0.5)/four_Pi;

      const double multipolar_expansion_exc_ME = multipolar_expansion(l1 , j1 , l0 , j0 , l2 , j2 , l3 , j3 , l , J);
      
      const double multipolar_expansion_Psigma_exc_ME = multipolar_expansion_Psigma_ME_calc (multipolar_expansion , Psigma_MEs , l1 , j1 , l0 , j0 , l2 , j2 , l3 , j3 , l , J);

      Yl1_Yl2_PS_exc_MEs(0 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_exc_ME - multipolar_expansion_Psigma_exc_ME);
      Yl1_Yl2_PS_exc_MEs(1 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_exc_ME + multipolar_expansion_Psigma_exc_ME);
    }

  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double antisymmetry_product_angular_TBME_S0_dir = antisymmetry_product*angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_dir_parity , lmax_dir_parity , Yl1_Yl2_PS_dir_MEs , 0 , it);
      const double antisymmetry_product_angular_TBME_S1_dir = antisymmetry_product*angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_dir_parity , lmax_dir_parity , Yl1_Yl2_PS_dir_MEs , 1 , it);

      const double antisymmetry_product_angular_TBME_S0_exc = antisymmetry_product*angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_exc_parity , lmax_exc_parity , Yl1_Yl2_PS_exc_MEs , 0 , it);
      const double antisymmetry_product_angular_TBME_S1_exc = antisymmetry_product*angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_exc_parity , lmax_exc_parity , Yl1_Yl2_PS_exc_MEs , 1 , it);

      const double antisymmetry_product_angular_TBME_dir = antisymmetry_product_angular_TBME_S0_dir + antisymmetry_product_angular_TBME_S1_dir;
      const double antisymmetry_product_angular_TBME_exc = antisymmetry_product_angular_TBME_S0_exc + antisymmetry_product_angular_TBME_S1_exc;

      const TYPE antisymmetry_product_TBME_S0_dir = antisymmetry_product_angular_TBME_S0_dir*rk_overlap_dir;
      const TYPE antisymmetry_product_TBME_S1_dir = antisymmetry_product_angular_TBME_S1_dir*rk_overlap_dir;

      const TYPE antisymmetry_product_TBME_S0_exc = antisymmetry_product_angular_TBME_S0_exc*rk_overlap_exc;
      const TYPE antisymmetry_product_TBME_S1_exc = antisymmetry_product_angular_TBME_S1_exc*rk_overlap_exc;

      angular_densities_TBMEs(0 , it) = antisymmetry_product_TBME_S0_dir - phase_exc*antisymmetry_product_TBME_S0_exc;
      angular_densities_TBMEs(1 , it) = antisymmetry_product_TBME_S1_dir - phase_exc*antisymmetry_product_TBME_S1_exc;

      for (unsigned int i = 0 ; i < N_RKmax ; i++)
	{
	  const TYPE rk_OBMEs_product = rk_OBMEs_product_table(i);

	  const TYPE antisymmetry_product_TBME_dir = rk_OBMEs_product*antisymmetry_product_angular_TBME_dir;
	  const TYPE antisymmetry_product_TBME_exc = rk_OBMEs_product*antisymmetry_product_angular_TBME_exc;

	  density_TBMEs(i , it) = antisymmetry_product_TBME_dir - phase_exc*antisymmetry_product_TBME_exc;
	}
    }
}



// Calculation of coupled two-body matrix elements of correlation density including spin exchange integrated or not over r for given in and out proton-neutron two-body states
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc jd | \delta (theta - theta_12) | ja jb>_J and <jc jd | \delta (theta - theta_12) \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.
// (a,c) are protons, (b,d) are neutrons.
// The radial/momentum overlaps entering <jc jd | \delta (theta - theta_12) | ja jb>_J are calculated in this routine with either HO expansion or truncated radial integrals (R cut).
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering correlation density are given as input.
// Radii come from Gauss-Legendre or uniform grids.
// The correlation density integrated over r is separated in S=0 and S=1 parts.
// Correlation density is summed over its S=0 and S=1 parts.

void correlation_density_TBMEs::coupled_TBMEs_pn_calc (
						       const bool is_it_HO_expansion , 
						       const int J , 
						       const class interaction_class &inter_data , 
						       const class baryons_data &prot_Y_data , 
						       const class baryons_data &neut_Y_data , 
						       const class array<TYPE> &rk_OBMEs_p , 
						       const class array<TYPE> &rk_OBMEs_n , 
						       const class pair_str &pair_in , 
						       const class pair_str &pair_out , 
						       const class array<double> &theta12_Dirac_multipolar_tab , 
						       const class multipolar_expansion_str &multipolar_expansion , 
						       const class Psigma_str &Psigma_MEs , 
						       class array<TYPE> &angular_densities_TBMEs , 
						       class array<TYPE> &density_TBMEs)
{	
  const double four_Pi = 12.566370614359173;

  const unsigned int N_RKmax = density_TBMEs.dimension (0);
  
  const unsigned int theta_number = density_TBMEs.dimension (1);

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const unsigned int s0 = pair_in.get_left ()  , s1 = pair_in.get_right ();  //bra
  const unsigned int s2 = pair_out.get_left () , s3 = pair_out.get_right (); //ket

  const class nlj_struct &wf0 = shells_qn_p(s0) , &wf1 = shells_qn_n(s1);
  const class nlj_struct &wf2 = shells_qn_p(s2) , &wf3 = shells_qn_n(s3);

  const int l0 = wf0.get_l () , l1 = wf1.get_l ();
  const int l2 = wf2.get_l () , l3 = wf3.get_l ();  

  const double j0 = wf0.get_j () , j1 = wf1.get_j ();
  const double j2 = wf2.get_j () , j3 = wf3.get_j ();

  const int lmin_02 = abs (l0 - l2) , lmin_13 = abs (l1 - l3) , lmin = max (lmin_02 , lmin_13);
  const int lmax_02 =      l0 + l2  , lmax_13 =      l1 + l3  , lmax = min (lmax_02 , lmax_13);

  const int lmin_parity = ((lmin + lmax_02)%2 == 0) ? (lmin) : (lmin+1);
  const int lmax_parity = ((lmax + lmax_02)%2 == 0) ? (lmax) : (lmax-1);

  const TYPE rk_overlap_02 = rk_overlap_calc (is_it_HO_expansion , inter_data , prot_Y_data , s0 , s2);
  const TYPE rk_overlap_13 = rk_overlap_calc (is_it_HO_expansion , inter_data , neut_Y_data , s1 , s3);

  const TYPE rk_overlap = rk_overlap_02*rk_overlap_13;

  class array<TYPE> rk_OBMEs_product_table(N_RKmax);

  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs_p(s0 , s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs_n(s1 , s3 , i);

      rk_OBMEs_product_table(i) = rk_OBME_02*rk_OBME_13;
    }

  class array<double> Yl1_Yl2_PS_MEs(2 , lmax_parity + 1);

  for (int l = lmin_parity ; l <= lmax_parity ; l += 2)
    {
      const double half_Yl1_Yl2_norm = (l + 0.5)/four_Pi;

      const double multipolar_expansion_ME = multipolar_expansion (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , l , J);
      
      const double multipolar_expansion_Psigma_ME = multipolar_expansion_Psigma_ME_calc (multipolar_expansion , Psigma_MEs , l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , l , J);

      Yl1_Yl2_PS_MEs(0 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_ME - multipolar_expansion_Psigma_ME);
      Yl1_Yl2_PS_MEs(1 , l) = half_Yl1_Yl2_norm*(multipolar_expansion_ME + multipolar_expansion_Psigma_ME);
    }

  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double angular_TBME_S0 = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_parity , lmax_parity , Yl1_Yl2_PS_MEs , 0 , it);
      const double angular_TBME_S1 = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_parity , lmax_parity , Yl1_Yl2_PS_MEs , 1 , it);

      const double angular_TBME = angular_TBME_S0 + angular_TBME_S1;

      const TYPE TBME_S0 = angular_TBME_S0*rk_overlap;
      const TYPE TBME_S1 = angular_TBME_S1*rk_overlap;

      angular_densities_TBMEs(0 , it) = TBME_S0;
      angular_densities_TBMEs(1 , it) = TBME_S1;

      for (unsigned int i = 0 ; i < N_RKmax ; i++)
	{
	  const TYPE rk_OBMEs_product = rk_OBMEs_product_table(i);

	  const TYPE TBME = rk_OBMEs_product*angular_TBME;

	  density_TBMEs(i , it) = TBME;
	}
    }
}






// Calculation of coupled two-body matrix elements of correlation density including spin exchange integrated or not over r for given in and out protons, neutrons or proton-neutron two-body states
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calls here routines calculating <jc jd | \delta (theta - theta_12) | ja jb>_J and <jc jd | \delta (theta - theta_12) \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.

void correlation_density_TBMEs::coupled_TBMEs_calc ( 
						    const bool is_it_HO_expansion , 
						    const enum space_type space , 
						    const int J , 
						    const class interaction_class &inter_data ,
						    const class baryons_data &prot_Y_data , 
						    const class baryons_data &neut_Y_data , 
						    const class array<TYPE> &rk_OBMEs_p , 
						    const class array<TYPE> &rk_OBMEs_n , 
						    const class pair_str &pair_in , 
						    const class pair_str &pair_out , 
						    const class array<double> &theta12_Dirac_multipolar_tab , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class Psigma_str &Psigma_MEs , 
						    class array<TYPE> &angular_densities_TBMEs , 
						    class array<TYPE> &density_TBMEs)
{
  angular_densities_TBMEs = 0.0;

  density_TBMEs = 0.0;

  switch (space)
    {
    case PROT_Y_ONLY: coupled_TBMEs_pp_nn_calc (is_it_HO_expansion , J , inter_data , prot_Y_data , rk_OBMEs_p , pair_in , pair_out , theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma_MEs , angular_densities_TBMEs , density_TBMEs); break;
    case NEUT_Y_ONLY: coupled_TBMEs_pp_nn_calc (is_it_HO_expansion , J , inter_data , neut_Y_data , rk_OBMEs_n , pair_in , pair_out , theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma_MEs , angular_densities_TBMEs , density_TBMEs); break;

    case PROT_NEUT_Y: coupled_TBMEs_pn_calc (is_it_HO_expansion , J , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , pair_in , pair_out ,
					     theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma_MEs , angular_densities_TBMEs , density_TBMEs); break;

    case PROT_NEUT_UNMIXED_Y:
      {
	const enum particle_type particle_in  = pair_in.get_particle_left ();
	const enum particle_type particle_out = pair_out.get_particle_left ();

	if (particle_in != particle_out) return;

	const int particle_charge = particle_charge_determine (particle_in);

	if (particle_charge != 0)
	  coupled_TBMEs_pp_nn_calc (is_it_HO_expansion , J , inter_data , prot_Y_data , rk_OBMEs_p , pair_in , pair_out , theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma_MEs , angular_densities_TBMEs , density_TBMEs);
	else
	  coupled_TBMEs_pp_nn_calc (is_it_HO_expansion , J , inter_data , neut_Y_data , rk_OBMEs_n , pair_in , pair_out , theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma_MEs , angular_densities_TBMEs , density_TBMEs);
	  	
      } break;
      
    default: abort_all ();
    }
}








// Calculation of uncoupled two-body matrix elements of correlation density including spin exchange integrated or not over r for given in and out protons or neutrons (plus a few hyperons if any) two-body states
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc mc jd md | \delta (theta - theta_12) | ja ma jb mb> and <jc mc jd md | \delta (theta - theta_12) \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja ma jb mb> for all radii/momenta and a,b,c,d fixed.
// The radial/momentum overlaps entering <jc mc jd md | \delta (theta - theta_12) | ja ma jb mb> are calculated in this routine with either HO expansion or truncated radial integrals (R cut).
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering correlation density are given as input.
// Radii come from Gauss-Legendre or uniform grids.
// The correlation density integrated over r is separated in S=0 and S=1 parts.
// Correlation density is summed over its S=0 and S=1 parts. 

void correlation_density_TBMEs::uncoupled_TBMEs_pp_nn_calc (
							    const bool is_it_HO_expansion , 
							    const class interaction_class &inter_data , 
							    const class baryons_data &data , 
							    const class array<TYPE> &rk_OBMEs , 
							    const unsigned int s0 , 
							    const unsigned int s1 , 
							    const unsigned int s2 , 
							    const unsigned int s3 , 
							    const class array<double> &theta12_Dirac_multipolar_tab , 
							    const class lm_table<unsigned int> &lm_indices , 
							    const class ljm_table<unsigned int> &ljm_indices , 
							    const class array<double> &Ylm_table_coupled_to_l , 
							    const class array<double> &Ylm_table_coupled_to_j , 
							    const class array<double> &CGs , 
							    class array<TYPE> &angular_densities_TBMEs , 
							    class array<TYPE> &density_TBMEs)
{	
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const unsigned int theta_number = density_TBMEs.dimension (1);

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table(s0) , &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2) , &phi3 = phi_table(s3);

  const unsigned int shell_index_s0 = phi0.get_shell_index () , shell_index_s1 = phi1.get_shell_index ();
  const unsigned int shell_index_s2 = phi2.get_shell_index () , shell_index_s3 = phi3.get_shell_index (); 

  const int l0 = phi0.get_l () , l1 = phi1.get_l ();
  const int l2 = phi2.get_l () , l3 = phi3.get_l ();

  const int lmin_02 = abs (l0 - l2) , lmin_13 = abs (l1 - l3) , lmin_dir = max (lmin_02 , lmin_13);
  const int lmax_02 =      l0 + l2  , lmax_13 =      l1 + l3  , lmax_dir = min (lmax_02 , lmax_13);

  const int lmin_dir_parity = ((lmin_dir + lmax_02)%2 == 0) ? (lmin_dir) : (lmin_dir+1);
  const int lmax_dir_parity = ((lmax_dir + lmax_02)%2 == 0) ? (lmax_dir) : (lmax_dir-1);

  const int lmin_12 = abs (l1 - l2) , lmin_03 = abs (l0 - l3) , lmin_exc = max (lmin_12 , lmin_03);
  const int lmax_12 =      l1 + l2  , lmax_03 =      l0 + l3  , lmax_exc = min (lmax_12 , lmax_03);

  const int lmin_exc_parity = ((lmin_exc + lmax_12)%2 == 0) ? (lmin_exc) : (lmin_exc + 1);
  const int lmax_exc_parity = ((lmax_exc + lmax_12)%2 == 0) ? (lmax_exc) : (lmax_exc - 1);

  const TYPE rk_overlap_02 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , shell_index_s0 , shell_index_s2);
  const TYPE rk_overlap_13 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , shell_index_s1 , shell_index_s3);

  const TYPE rk_overlap_12 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , shell_index_s1 , shell_index_s2);
  const TYPE rk_overlap_03 = rk_overlap_calc (is_it_HO_expansion , inter_data , data , shell_index_s0 , shell_index_s3);

  const TYPE rk_overlap_dir = rk_overlap_02*rk_overlap_13;
  const TYPE rk_overlap_exc = rk_overlap_12*rk_overlap_03;

  class array<TYPE> rk_OBMEs_product_table(N_RKmax);
  
  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs(shell_index_s0 , shell_index_s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs(shell_index_s1 , shell_index_s3 , i);

      rk_OBMEs_product_table(i) = rk_OBME_02*rk_OBME_13;
    }

  class array<double> Yl1_Yl2_PS_dir_MEs(2 , lmax_dir_parity + 1);
  
  class array<double> Yl1_Yl2_PS_exc_MEs(2 , lmax_exc_parity + 1);

  for (int l = lmin_dir_parity ; l <= lmax_dir_parity ; l += 2)
    {
      const double Yl1_Yl2_ME_dir     = uncoupled_Yl1_Yl2_ME_calc        (phi0 , phi1 , phi2 , phi3 , l , ljm_indices               , Ylm_table_coupled_to_j);
      const double Yl1_Yl2_Psigma_dir = uncoupled_Yl1_Yl2_Psigma_ME_calc (phi0 , phi1 , phi2 , phi3 , l , lm_indices  , ljm_indices , Ylm_table_coupled_to_l , CGs);

      Yl1_Yl2_PS_dir_MEs(0 , l) = 0.5*(Yl1_Yl2_ME_dir - Yl1_Yl2_Psigma_dir);
      Yl1_Yl2_PS_dir_MEs(1 , l) = 0.5*(Yl1_Yl2_ME_dir + Yl1_Yl2_Psigma_dir);
    }

  for (int l = lmin_exc_parity ; l <= lmax_exc_parity ; l += 2)
    {
      const double Yl1_Yl2_ME_exc     = uncoupled_Yl1_Yl2_ME_calc        (phi1 , phi0 , phi2 , phi3 , l , ljm_indices               , Ylm_table_coupled_to_j);
      const double Yl1_Yl2_Psigma_exc = uncoupled_Yl1_Yl2_Psigma_ME_calc (phi1 , phi0 , phi2 , phi3 , l , lm_indices  , ljm_indices , Ylm_table_coupled_to_l , CGs);

      Yl1_Yl2_PS_exc_MEs(0 , l) = 0.5*(Yl1_Yl2_ME_exc - Yl1_Yl2_Psigma_exc);
      Yl1_Yl2_PS_exc_MEs(1 , l) = 0.5*(Yl1_Yl2_ME_exc + Yl1_Yl2_Psigma_exc);
    }

  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double angular_TBME_S0_dir = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_dir_parity , lmax_dir_parity , Yl1_Yl2_PS_dir_MEs , 0 , it);
      const double angular_TBME_S1_dir = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_dir_parity , lmax_dir_parity , Yl1_Yl2_PS_dir_MEs , 1 , it);

      const double angular_TBME_S1_exc = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_exc_parity , lmax_exc_parity , Yl1_Yl2_PS_exc_MEs , 1 , it);
      const double angular_TBME_S0_exc = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_exc_parity , lmax_exc_parity , Yl1_Yl2_PS_exc_MEs , 0 , it);

      const double angular_TBME_dir = angular_TBME_S0_dir + angular_TBME_S1_dir;
      const double angular_TBME_exc = angular_TBME_S0_exc + angular_TBME_S1_exc;

      const TYPE TBME_S0_dir = angular_TBME_S0_dir*rk_overlap_dir , TBME_S0_exc = angular_TBME_S0_exc*rk_overlap_exc;
      const TYPE TBME_S1_dir = angular_TBME_S1_dir*rk_overlap_dir , TBME_S1_exc = angular_TBME_S1_exc*rk_overlap_exc;

      angular_densities_TBMEs(0 , it) = TBME_S0_dir - TBME_S0_exc;
      angular_densities_TBMEs(1 , it) = TBME_S1_dir - TBME_S1_exc;

      for (unsigned int i = 0 ; i < N_RKmax ; i++)
	{
	  const TYPE rk_OBMEs_product = rk_OBMEs_product_table(i);

	  const TYPE TBME_dir = rk_OBMEs_product*angular_TBME_dir;
	  const TYPE TBME_exc = rk_OBMEs_product*angular_TBME_exc;

	  density_TBMEs(i , it) = TBME_dir - TBME_exc;
	}
    }
}








// Calculation of uncoupled two-body matrix elements of correlation density including spin exchange integrated or not over r for given in and out proton-neutron two-body states
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc mc jd md | \delta (theta - theta_12) | ja ma jb mb> and <jc mc jd md | \delta (theta - theta_12) \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja ma jb mb> for all radii/momenta and a,b,c,d fixed.
// (a,c) are protons, (b,d) are neutrons.
// The radial/momentum overlaps entering <jc mc jd md | \delta (theta - theta_12) | ja ma jb mb> are calculated in this routine with either HO expansion or truncated radial integrals (R cut).
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering correlation density are given as input.
// Radii come from Gauss-Legendre or uniform grids.
// The correlation density integrated over r is separated in S=0 and S=1 parts.
// Correlation density is summed over its S=0 and S=1 parts.

void correlation_density_TBMEs::uncoupled_TBMEs_pn_calc (
							 const bool is_it_HO_expansion , 
							 const class interaction_class &inter_data , 
							 const class baryons_data &prot_Y_data , 
							 const class baryons_data &neut_Y_data , 
							 const class array<TYPE> &rk_OBMEs_p , 
							 const class array<TYPE> &rk_OBMEs_n , 
							 const unsigned int s0 , 
							 const unsigned int s1 , 
							 const unsigned int s2 , 
							 const unsigned int s3 , 
							 const class array<double> &theta12_Dirac_multipolar_tab , 
							 const class lm_table<unsigned int> &lm_indices , 
							 const class ljm_table<unsigned int> &ljm_indices , 
							 const class array<double> &Ylm_table_coupled_to_l , 
							 const class array<double> &Ylm_table_coupled_to_j , 
							 const class array<double> &CGs , 
							 class array<TYPE> &angular_densities_TBMEs , 
							 class array<TYPE> &density_TBMEs)
{
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const unsigned int theta_number = density_TBMEs.dimension (1);

  const class array<class nljm_struct> &phi_table_p = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_table_n = neut_Y_data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table_p(s0) , &phi1 = phi_table_n(s1); //ket
  const class nljm_struct &phi2 = phi_table_p(s2) , &phi3 = phi_table_n(s3); //ket

  const unsigned int shell_index_s0 = phi0.get_shell_index () , shell_index_s1 = phi1.get_shell_index ();
  const unsigned int shell_index_s2 = phi2.get_shell_index () , shell_index_s3 = phi3.get_shell_index (); 

  const int l0 = phi0.get_l () , l1 = phi1.get_l ();
  const int l2 = phi2.get_l () , l3 = phi3.get_l ();

  const int lmin_02 = abs (l0 - l2) , lmin_13 = abs (l1 - l3) , lmin = max (lmin_02 , lmin_13);
  const int lmax_02 =      l0 + l2  , lmax_13 =      l1 + l3  , lmax = min (lmax_02 , lmax_13);

  const int lmin_parity = ((lmin + lmax_02)%2 == 0) ? (lmin) : (lmin+1);
  const int lmax_parity = ((lmax + lmax_02)%2 == 0) ? (lmax) : (lmax-1);

  const TYPE rk_overlap_02 = rk_overlap_calc (is_it_HO_expansion , inter_data , prot_Y_data , shell_index_s0 , shell_index_s2);
  const TYPE rk_overlap_13 = rk_overlap_calc (is_it_HO_expansion , inter_data , neut_Y_data , shell_index_s1 , shell_index_s3);

  const TYPE rk_overlap = rk_overlap_02*rk_overlap_13;

  class array<TYPE> rk_OBMEs_product_table(N_RKmax);

  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs_p(shell_index_s0 , shell_index_s2 , i); // bra unchanged
      const TYPE rk_OBME_13 = rk_OBMEs_n(shell_index_s1 , shell_index_s3 , i); // ket unchanged

      rk_OBMEs_product_table(i) = rk_OBME_02*rk_OBME_13;
    }

  class array<double> Yl1_Yl2_PS_MEs(2 , lmax_parity + 1);

  for (int l = lmin_parity ; l <= lmax_parity ; l += 2)
    {
      const double Yl1_Yl2_ME     = uncoupled_Yl1_Yl2_ME_calc        (phi0 , phi1 , phi2 , phi3 , l , ljm_indices               , Ylm_table_coupled_to_j);
      const double Yl1_Yl2_Psigma = uncoupled_Yl1_Yl2_Psigma_ME_calc (phi0 , phi1 , phi2 , phi3 , l , lm_indices  , ljm_indices , Ylm_table_coupled_to_l , CGs);

      Yl1_Yl2_PS_MEs(0 , l) = 0.5*(Yl1_Yl2_ME - Yl1_Yl2_Psigma);
      Yl1_Yl2_PS_MEs(1 , l) = 0.5*(Yl1_Yl2_ME + Yl1_Yl2_Psigma);
    }

  for (unsigned int it = 0 ; it < theta_number ; it++)
    {
      const double angular_TBME_S0 = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_parity , lmax_parity , Yl1_Yl2_PS_MEs , 0 , it);
      const double angular_TBME_S1 = angular_delta_PS_ME_calc (theta12_Dirac_multipolar_tab , lmin_parity , lmax_parity , Yl1_Yl2_PS_MEs , 1 , it);

      const double angular_TBME = angular_TBME_S0 + angular_TBME_S1;

      const TYPE TBME_S0 = angular_TBME_S0*rk_overlap;
      const TYPE TBME_S1 = angular_TBME_S1*rk_overlap;

      angular_densities_TBMEs(0 , it) = TBME_S0;
      angular_densities_TBMEs(1 , it) = TBME_S1;

      for (unsigned int i = 0 ; i < N_RKmax ; i++)
	{
	  const TYPE rk_OBMEs_product = rk_OBMEs_product_table(i);

	  const TYPE TBME = rk_OBMEs_product*angular_TBME;

	  density_TBMEs(i , it) = TBME;
	}
    }
}





