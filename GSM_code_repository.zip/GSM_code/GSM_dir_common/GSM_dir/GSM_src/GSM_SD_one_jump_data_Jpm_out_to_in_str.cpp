#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Array class type to store an array of class SD_one_jump_data_Jpm_out_to_in_str
// -------------------------------------------------------------------------------------
// class SD_one_jump_data_Jpm_out_to_in_str stores information related to the SD inSD obtained after the action of a+_{alpha} a_{beta} on a Slater determinant outSD to generate inSD for the action of J+/J- only.
// Indeed, one needs to go from outSD to inSD with creation/annihilation operators in some matrix-vector operations.
// It contains the shell index for this jump, as the shell is fixed during a jump when J+/J- only is considered,
// the coded difference of M quantum numbers, equal to 0 for J+ and 1 for J-, from which M_in = M_out -/+ 1 can be recovered as M_in is fixed, 
// the index of inSD in a fixed configuration, and the binary phase related to a+_{alpha} a_{beta}.
// M_in and m_in can be recovered from shifted M-values as M_out is fixed.


SD_one_jump_data_Jpm_out_to_in_str::SD_one_jump_data_Jpm_out_to_in_str () :
  shell_index (0) ,
  im_in (0) ,
  Delta_iM_in (0) ,
  inSD_index (0) ,
  bin_phase (0)
{}

SD_one_jump_data_Jpm_out_to_in_str::SD_one_jump_data_Jpm_out_to_in_str (
									const unsigned int shell_index_c , 
									const unsigned int im_in_c , 
									const unsigned int Delta_iM_in_c , 
									const unsigned int inSD_index_c , 
									const unsigned int bin_phase_c)
{
  initialize (shell_index_c , im_in_c , Delta_iM_in_c , inSD_index_c , bin_phase_c);
}

void SD_one_jump_data_Jpm_out_to_in_str::initialize (
						     const unsigned int shell_index_c , 
						     const unsigned int im_in_c , 
						     const unsigned int Delta_iM_in_c , 
						     const unsigned int inSD_index_c , 
						     const unsigned int bin_phase_c)
{
  shell_index = shell_index_c;  

  im_in = im_in_c;  

  Delta_iM_in = Delta_iM_in_c; 

  inSD_index = inSD_index_c; 

  bin_phase = bin_phase_c;
}

void SD_one_jump_data_Jpm_out_to_in_str::initialize (const class SD_one_jump_data_Jpm_out_to_in_str &X)
{
  shell_index = X.shell_index;  

  im_in = X.im_in;  

  Delta_iM_in = X.Delta_iM_in; 

  inSD_index = X.inSD_index;  

  bin_phase = X.bin_phase; 
}

void SD_one_jump_data_Jpm_out_to_in_str::allocate_fill (const class SD_one_jump_data_Jpm_out_to_in_str &X)
{
  initialize (X);
}


double used_memory_calc (const class SD_one_jump_data_Jpm_out_to_in_str &T)
{
  return sizeof (T)/1000000.0;
}

