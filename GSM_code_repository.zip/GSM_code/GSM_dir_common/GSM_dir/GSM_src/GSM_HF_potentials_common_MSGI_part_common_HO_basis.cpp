#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------


// Calculation of the radial one-body matrix element associated to the real or imaginary part of the Gaussian form factor between the in and out states with the HO basis 
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates <n_HO_out l_out j_out | F_Gaussian | n_HO_in l_in j_in> where F_Gaussian is the Gaussian form factor of the MSGI interaction (see GSM_TBME_MSGI.cpp).

double HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::HO_basis::radial_integral_calc (
												     const class array<double> &Gaussian_table_GL , 
												     const class interaction_class &inter_data_basis , 
												     const int l , 
												     const int n_HO_in , 
												     const int n_HO_out)
{
  const class array<double> &w_bef_R_tab_GL = inter_data_basis.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data_basis.get_HO_wfs_bef_R_tab_GL_SGI_MSGI ();

  const unsigned int N_bef_R_GL = w_bef_R_tab_GL.dimension (0);

  double radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral += HO_wfs_bef_R_tab_GL(n_HO_in , l , i)*HO_wfs_bef_R_tab_GL(n_HO_out , l , i)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  return radial_integral;
}


// Calculation of the radial one-body matrix element associated to the real or imaginary part of the Gaussian form factor for a HO state and an occupied state
// -----------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates the real or imaginary part of <n_HO l j | F_Gaussian | wf_occ> where F_Gaussian is the Gaussian form factor of the MSGI interaction (see GSM_TBME_MSGI.cpp).

double HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::HO_basis::radial_OBME_calc (
												 const class array<double> &Gaussian_table_GL , 
												 const class interaction_class &inter_data_basis , 
												 const int l , 
												 const int n_HO , 
												 const class spherical_state &wf_occ , 
												 const bool is_it_real_part)
{
  const class array<double> &w_bef_R_tab_GL = inter_data_basis.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data_basis.get_HO_wfs_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wf_occ_bef_R_tab_GL = wf_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const unsigned int N_bef_R_GL = w_bef_R_tab_GL.dimension (0);

  double radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double wf_occ_part = (is_it_real_part) ? (real (wf_occ_bef_R_tab_GL(i))) : (imag (wf_occ_bef_R_tab_GL(i)));

      radial_integral += HO_wfs_bef_R_tab_GL(n_HO , l , i)*wf_occ_part*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);
    }

  return radial_integral;
}




// Calculation of the one-body matrix element associated to the real or imaginary part of the MSGI interaction in the HO basis
// ---------------------------------------------------------------------------------------------------------------------------
// One calculates <wf_out wf_occ | V_MSGI |  wf_in wf_occ> from the real and imaginary parts of its direct and exchange parts, where |wf_in> = |n_HO_in l_in j_in> and |wf_out> = |n_HO_out l_out j_out>.

double HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::HO_basis::total_OBME_calc (
												const class interaction_class &inter_data_basis , 
												const int l , 
												const int n_HO_in , 
												const int n_HO_out , 
												const class array<double> &Gaussian_table_GL , 
												const complex<double> &OBME_factor_direct , 
												const complex<double> &OBME_factor_exchange , 
												const class spherical_state &wf_occ)
{
  const double radial_direct_wf_in_wf_out = radial_integral_calc (Gaussian_table_GL , inter_data_basis , l , n_HO_in , n_HO_out);
  
  const complex<double> radial_direct_occ = MSGI_part_common::radial_integral_calc (Gaussian_table_GL , wf_occ , wf_occ);
  
  const double radial_exchange_wf_in_occ_re  = radial_OBME_calc (Gaussian_table_GL , inter_data_basis , l , n_HO_in  , wf_occ , true);
  const double radial_exchange_wf_out_occ_re = radial_OBME_calc (Gaussian_table_GL , inter_data_basis , l , n_HO_out , wf_occ , true);
  const double radial_exchange_wf_in_occ_im  = radial_OBME_calc (Gaussian_table_GL , inter_data_basis , l , n_HO_in  , wf_occ , false);
  const double radial_exchange_wf_out_occ_im = radial_OBME_calc (Gaussian_table_GL , inter_data_basis , l , n_HO_out , wf_occ , false);

  const double OBME_direct_re_part = real (OBME_factor_direct)*real (radial_direct_occ)*radial_direct_wf_in_wf_out;
  const double OBME_direct_im_part = imag (OBME_factor_direct)*imag (radial_direct_occ)*radial_direct_wf_in_wf_out;

  const double OBME_exchange_re_part = real (OBME_factor_exchange)*(radial_exchange_wf_in_occ_re*radial_exchange_wf_out_occ_re - radial_exchange_wf_in_occ_im*radial_exchange_wf_out_occ_im);
  const double OBME_exchange_im_part = imag (OBME_factor_exchange)*(radial_exchange_wf_in_occ_im*radial_exchange_wf_out_occ_re + radial_exchange_wf_in_occ_re*radial_exchange_wf_out_occ_im);

  const double OBME_direct   = OBME_direct_re_part   - OBME_direct_im_part;
  const double OBME_exchange = OBME_exchange_re_part - OBME_exchange_im_part;

  const double OBME = OBME_direct - OBME_exchange;

  return OBME;
}



