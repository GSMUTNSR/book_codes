#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class SD_one_jump_data_in_to_out_str storing data about a+_{alpha} a_{beta} jumps on a Slater determinant inSD to generate outSD
// --------------------------------------------------------------------------------------------------------------------------------
// class SD_one_jump_data_in_to_out_str stores information related to the SD outSD obtained after the action of a+_{alpha} a_{beta} on a Slater determinant inSD to generate outSD.
// It contains the equivalent configuration index for this jump, containing information on configurations and shells only,
// (see GSM_configuration_one_jump_construction_set_in_to_out.cpp for the definition of the equivalent configuration for jumps),
// the shifted difference of M quantum numbers M_out - M_in + 2 m_max, from which M_out can be recovered as M_in is fixed, 
// the index of outSD in a fixed configuration, the shifted index of m quantum m_out + 2 m_max and the binary phase related to a+_{alpha} a_{beta}.
// M_out and m_out can be recovered from shifted M-values as M_in is fixed.






SD_one_jump_data_in_to_out_str::SD_one_jump_data_in_to_out_str ()
  : C_eq_one_jump_index (0) ,
    Delta_iM_out (0) , 
    outSD_index (0) ,  
    im_out (0) ,  
    bin_phase (0)
{}

SD_one_jump_data_in_to_out_str::SD_one_jump_data_in_to_out_str (
								const unsigned int C_eq_one_jump_index_c , 
								const unsigned int Delta_iM_out_c , 
								const unsigned int outSD_index_c , 
								const unsigned int im_out_c , 
								const unsigned int bin_phase_c)
{
  initialize (C_eq_one_jump_index_c , Delta_iM_out_c , outSD_index_c , im_out_c , bin_phase_c);
}

void SD_one_jump_data_in_to_out_str::initialize (
						 const unsigned int C_eq_one_jump_index_c , 
						 const unsigned int Delta_iM_out_c , 
						 const unsigned int outSD_index_c , 
						 const unsigned int im_out_c , 
						 const unsigned int bin_phase_c)
{
  C_eq_one_jump_index = C_eq_one_jump_index_c;
  
  Delta_iM_out = Delta_iM_out_c; 

  outSD_index = outSD_index_c;  

  im_out = im_out_c;

  bin_phase = bin_phase_c;
}

void SD_one_jump_data_in_to_out_str::initialize (const class SD_one_jump_data_in_to_out_str &X)
{
  C_eq_one_jump_index = X.C_eq_one_jump_index;

  Delta_iM_out = X.Delta_iM_out; 

  outSD_index = X.outSD_index;  

  im_out = X.im_out;

  bin_phase = X.bin_phase; 
}

void SD_one_jump_data_in_to_out_str::allocate_fill (const class SD_one_jump_data_in_to_out_str &X)
{
  initialize (X);
}

double used_memory_calc (const class SD_one_jump_data_in_to_out_str &T)
{
  return sizeof (T)/1000000.0;
}
