#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Classes defined only so that the HO codes compile with routines meant to be used only with Berggren basis codes
// ---------------------------------------------------------------------------------------------------------------

ODE_integration::ODE_integration () {}

ODE_integration::ODE_integration (const void * , complex<double> (*)  (const void * , const complex<double> & , const complex<double> &)) {}

ODE_integration::~ODE_integration () {}

Coulomb_wave_functions::Coulomb_wave_functions () {}

Coulomb_wave_functions::Coulomb_wave_functions (const bool , const complex<double> & , const complex<double> &) {}

Coulomb_wave_functions::~Coulomb_wave_functions () {}

void Coulomb_wave_functions::F_dF (const complex<double> & , complex<double> & , complex<double> &) {}

double used_memory_calc (const class spherical_state &T)
{
  return sizeof (T)/1000000.0;
}

