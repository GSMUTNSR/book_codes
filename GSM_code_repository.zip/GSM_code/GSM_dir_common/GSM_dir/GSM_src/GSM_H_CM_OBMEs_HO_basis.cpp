#include "../GSM_include/GSM_include_def_common.h"

using namespace angular_matrix_elements;

// TYPE is double or complex
// -------------------------


// H_CM_OBMEs::HO_basis means that one calculates here one-body matrix elements associated to the Hamiltonian and center of mass operators using HO basis states.


// Calculation of one one-body matrix element of the rms radius operator with HO states
// ------------------------------------------------------------------------------------
// The one-body matrix elements of the rms radius operator are of the form rms_radius_one_body_factor x r^2 (see observables_basic_functions.cpp).
// One uses its exact value (see HO_wave_functions.cpp).

double H_CM_OBMEs::HO_basis::OBME_rms_radius_calc (
						   const class input_data_str &input_data , 
						   const unsigned int s_in , 
						   const unsigned int s_out , 
						   const enum operator_type rms_radius_op , 
						   const class nucleons_data &data)
{
  const int Z = input_data.get_Z ();
  const int N = input_data.get_N ();

  const double mp = input_data.get_prot_mass_for_calc ();
  const double mn = input_data.get_neut_mass_for_calc ();
  
  const enum particle_type particle = data.get_particle ();
  
  const class array<class spherical_state> &shells = data.get_shells ();

  const class spherical_state &wf_in = shells(s_in);
  
  const class spherical_state &wf_out = shells(s_out);
	
  if (!same_lj (wf_in , wf_out)) return 0.0;

  const class lj_table<double> &b_lab_partial_waves = data.get_b_partial_waves ();
	
  const int l = wf_in.get_l ();

  const double j = wf_in.get_j ();
  
  const int n_in = wf_in.get_n ();
  
  const int n_out = wf_out.get_n ();
  
  const double b_lab = b_lab_partial_waves(l , j);
	
  const double factor = rms_radius_one_body_factor_calc (rms_radius_op , particle , mp , mn , Z , N);
	
  const double OBME_r2 = HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n_in , n_out , b_lab);

  const double OBME = OBME_r2*factor;

  return OBME;
}




// Calculation of one one-body matrix element of the kinetic one-body operator for HO states
// -----------------------------------------------------------------------------------------
// One calculates the matrix element of p^2/2m for HO states.
// The effective mass changes according to the use of lab or COSM coordinates.
// It is zero unless the in and out states belong to the same partial wave.
// One uses its exact value (see HO_wave_functions.cpp).

double H_CM_OBMEs::HO_basis::OBME_kinetic_calc (
						const unsigned int s_in , 
						const unsigned int s_out , 
						const enum interaction_type TBME_inter ,
						const class nucleons_data &data)
{  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const class array<class spherical_state> &shells = data.get_shells ();

  const class spherical_state &wf_in = shells(s_in);
  
  const class spherical_state &wf_out = shells(s_out);

  if (!same_lj (wf_in , wf_out)) return 0.0;

  const class lj_table<double> &b_lab_partial_waves = data.get_b_partial_waves ();

  const int l = wf_in.get_l ();
  
  const double j = wf_in.get_j ();
  
  const int n_in = wf_in.get_n ();
  
  const int n_out = wf_out.get_n ();
  
  const double nucleon_mass_for_calc = data.get_effective_mass_for_calc ();
  
  const double nucleus_mass = data.get_nucleus_mass ();
  
  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);

  const double b_lab = b_lab_partial_waves(l , j);

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , mass_modif , nucleon_mass_for_calc , b_lab);

  const double OBME = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n_in , n_out , hbar_omega);

  return OBME;
}





// Calculation of one one-body matrix element of the kinetic center of mass operator for the general case and bound state case
// ---------------------------------------------------------------------------------------------------------------------------
// The center of mass kinetic operator is the standard definition P^2/2M = \sum_i (p_i^2/2M + \sum_{i<j} {(pi.pj)/M) if does not use COSM, with M the mass of the nucleus.
// Its one-body matrix elements are then those of p^2/2M, calculated from OBME_kinetic_calc or OBME_kinetic_bound_calc and then replacing the nucleon mass by the nucleus mass. 
// If one uses COSM, one defines the center of mass kinetic operator as being the COSM recoil term, equal to \sum_{i<j} (pi.pj)/M_core . Its one-body matrix elements are then equal to zero.
// The A=1 case is considered meaningful only if the number of nucleons of the nucleus in basis and Hamiltonian is the same if this routine is used, in which case zero is returned.

double H_CM_OBMEs::HO_basis::OBME_CM_kinetic_calc (
						   const unsigned int s_in , 
						   const unsigned int s_out , 
						   const enum interaction_type TBME_inter , 
						   const class nucleons_data &data)
{
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  if (!is_it_COSM)
    {
      const int A = data.get_A ();

      if (A == 1) return 0.0;

      const double OBME_kinetic = OBME_kinetic_calc (s_in , s_out , TBME_inter , data);

      const double nucleus_mass = data.get_nucleus_mass ();

      const double nucleon_mass_for_calc = data.get_effective_mass_for_calc ();

      const double mass_modif = nucleus_mass/nucleon_mass_for_calc - 1.0;

      const double OBME = OBME_kinetic/mass_modif;

      return OBME;
    }
  else
    return 0.0;
}
















// Calculation of Coulomb potential matrix element for HO states
// -------------------------------------------------------------
// The matrix element of one-body Coulomb potential Vc generated by Gaussian charged sphere defined with charge Z_charge is calculated by direct integration .
// One does not use the HO wave functions of inter_data as (n_in, l_in) and (n_out, l_out) states might not belong to the HO expansion.

double H_CM_OBMEs::HO_basis::OBME_Coulomb_potential_calc (
							  const int Z_charge ,
							  const int l , 
							  const double j , 
							  const int n_in , 
							  const int n_out , 
							  const class interaction_class &inter_data , 
							  const class nucleons_data &data)
{  
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();

  const enum particle_type particle = data.get_particle ();
  
  if (particle == NEUTRON) return 0.0;

  if (Z_charge == 0) return 0.0;

  const double R_charge = data.get_R_charge ();
 
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();
  
  const class array<double> &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL ();
  const class array<double> &w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();

  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge , R_charge);
  
  const class lj_table<double> &b_lab_partial_waves = data.get_b_partial_waves ();
  
  const double b = b_lab_partial_waves(l , j);
  
  double OBME_Coulomb_potential = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);
      
      const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
      const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

      const double Vc_r = Coulomb_potential.analytic_potential_calc (r);

      OBME_Coulomb_potential += wf_in_r*Vc_r*wf_out_r*w;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double r = r_aft_R_tab_GL(i);
      const double w = w_aft_R_tab_GL(i);

      const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
      const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

      const double Vc_r = Coulomb_potential.point_potential_calc (r);

      OBME_Coulomb_potential += wf_in_r*Vc_r*wf_out_r*w;
    }

  return OBME_Coulomb_potential;
}










// Calculation of one one-body matrix element of a nuclear potential with HO states
// --------------------------------------------------------------------------------
// One calculates the one-body matrix element <out | U_nuclear | in>. 
// It is zero unless the in and out states belong to the same partial wave.
// As U_nuclear is finite-ranged, it can be done by direct integration on the real axis.
// The nuclear potential can be WS (with Coulomb uniformly charged sphere potential), WS_ANALYTIC (with Coulomb Gaussian charged sphere potential) or KKNN.
// One uses the parameters of the basis WS or KKNN potential as given in the input file if is_it_basis_potential is put to true.
// If is_it_basis_potential is put to false, one uses the parameters of the core potential used in the Hamiltonian.
// One does not use the HO wave functions of inter_data as (n_in, l_in) and (n_out, l_out) states might not belong to the HO expansion.

double H_CM_OBMEs::HO_basis::OBME_nuclear_potential_calc (
							  const bool is_it_basis_potential , 
							  const potential_type nuclear_potential ,
							  const int l , 
							  const double j , 
							  const int n_in , 
							  const int n_out , 
							  const class interaction_class &inter_data , 
							  const class nucleons_data &data_for_potential)
{  
  const unsigned int N_bef_R_GL = data_for_potential.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data_for_potential.get_N_aft_R_GL ();
  
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL () , &w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL ();
  const class array<double> &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL () , &w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();

  const class array<double> &d_core_tab_for_potential   = data_for_potential.get_d_core_potential_tab ();
  const class array<double> &R0_core_tab_for_potential  = data_for_potential.get_R0_core_potential_tab ();
  const class array<double> &Vo_core_tab_for_potential  = data_for_potential.get_Vo_core_potential_tab ();
  const class array<double> &Vso_core_tab_for_potential = data_for_potential.get_Vso_core_potential_tab ();

  const class array<double> &d_basis_tab_for_potential   = data_for_potential.get_d_basis_tab ();
  const class array<double> &R0_basis_tab_for_potential  = data_for_potential.get_R0_basis_tab ();
  const class array<double> &Vo_basis_tab_for_potential  = data_for_potential.get_Vo_basis_tab ();
  const class array<double> &Vso_basis_tab_for_potential = data_for_potential.get_Vso_basis_tab ();

  const class array<double> &d_tab   = (is_it_basis_potential) ? (d_basis_tab_for_potential)   : (d_core_tab_for_potential);
  const class array<double> &R0_tab  = (is_it_basis_potential) ? (R0_basis_tab_for_potential)  : (R0_core_tab_for_potential);
  const class array<double> &Vo_tab  = (is_it_basis_potential) ? (Vo_basis_tab_for_potential)  : (Vo_core_tab_for_potential);
  const class array<double> &Vso_tab = (is_it_basis_potential) ? (Vso_basis_tab_for_potential) : (Vso_core_tab_for_potential);

  const double V0_KKNN[5] = {data_for_potential.get_V0_KKNN(0) , data_for_potential.get_V0_KKNN(1) , data_for_potential.get_V0_KKNN(2) , data_for_potential.get_V0_KKNN(3) , data_for_potential.get_V0_KKNN(4)};
  
  const double rho_KKNN[5] = {data_for_potential.get_rho_KKNN(0) , data_for_potential.get_rho_KKNN(1) , data_for_potential.get_rho_KKNN(2) , data_for_potential.get_rho_KKNN(3) , data_for_potential.get_rho_KKNN(4)};
  
  const double Vls_KKNN[3] = {data_for_potential.get_Vls_KKNN(0) , data_for_potential.get_Vls_KKNN(1) , data_for_potential.get_Vls_KKNN(2)};
  
  const double rho_ls_KKNN[3] = {data_for_potential.get_rho_ls_KKNN(0) , data_for_potential.get_rho_ls_KKNN(1) , data_for_potential.get_rho_ls_KKNN(2)};
  
  const class lj_table<double> &b_lab_partial_waves = data_for_potential.get_b_partial_waves ();
  
  const double b = b_lab_partial_waves(l , j);
	
  double OBME = 0.0;

  switch (nuclear_potential)
    {
    case WS:
      {
	const double d   = d_tab(l);
	const double R0  = R0_tab(l);
	const double Vo  = Vo_tab(l);
	const double Vso = Vso_tab(l);

	const class WS_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }
      } break;

    case WS_ANALYTIC:
      {
	const double d   = d_tab(l);
	const double R0  = R0_tab(l);
	const double Vo  = Vo_tab(l);
	const double Vso = Vso_tab(l);
	
	const class WS_analytic_class WS_potential(false , d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const double WS_potential_r = WS_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*WS_potential_r*wf_out_r*w;
	  }
      } break;

    case KKNN:
      {
	const class KKNN_class KKNN_potential(false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , NEUTRON , NADA , NADA , l , j);

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const double KKNN_potential_r = KKNN_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*KKNN_potential_r*wf_out_r*w;
	  }

	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	  {
	    const double r = r_aft_R_tab_GL(i);
	    const double w = w_aft_R_tab_GL(i);

	    const double KKNN_potential_r = KKNN_potential(r);

	    const double wf_in_r  = HO_wave_functions::HO_3D::u (b , n_in  , l , r);
	    const double wf_out_r = HO_wave_functions::HO_3D::u (b , n_out , l , r);

	    OBME += wf_in_r*KKNN_potential_r*wf_out_r*w;
	  }
      } break;

    default: break;
    }

  return OBME;
}




