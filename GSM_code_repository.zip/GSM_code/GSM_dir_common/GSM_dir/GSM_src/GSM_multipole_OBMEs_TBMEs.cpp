#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------


// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------


// Routines are straightforward so that they are not detailed. Only general explanations are given.
// ------------------------------------------------------------------------------------------------



// get functions to obtain the array of OBMEs of the considered multipole operator
// -------------------------------------------------------------------------------
// OBMEs are either used with HO expansion or R cut. 
//
// With HO expansion <a | Op | b> = \sum_{HO_a , HO_b} <HO_a | Op | HO_b>  <a|HO_a> <b|HO_b>, with a,b Berggren basis states and HO_a,HO_b HO states.
// With R cut, the radial integral in <a | Op | b> is calculated on [0:R] only. 
// The proper array is obtained here.
// multipole square is for operators of the form  <a | (r^L YL)^2 | b> and multipole reduced for operators of the form  <a || r^L YL || b>.

const class OBMEs_multipole_square_str & GSM_multipole_OBMEs_TBMEs::OBMEs_multipole_square_determine (
												      const bool is_it_HO_expansion ,
												      const class nucleons_data &data)
{
  const class OBMEs_multipole_square_str &OBMEs_multipole_square_HO_expansion = data.get_OBMEs_multipole_square_HO_expansion ();

  const class OBMEs_multipole_square_str &OBMEs_multipole_square_R_cut = data.get_OBMEs_multipole_square_R_cut ();

  const class OBMEs_multipole_square_str &OBMEs_multipole_square = (is_it_HO_expansion) ? (OBMEs_multipole_square_HO_expansion) : (OBMEs_multipole_square_R_cut);
  
  return OBMEs_multipole_square;
}

const class OBMEs_multipole_reduced_str & GSM_multipole_OBMEs_TBMEs::OBMEs_multipole_reduced_determine (
													const bool is_it_HO_expansion ,
													const class nucleons_data &data)
{
 
  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_HO_expansion = data.get_OBMEs_multipole_reduced_HO_expansion ();

  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_R_cut = data.get_OBMEs_multipole_reduced_R_cut ();

  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced = (is_it_HO_expansion) ? (OBMEs_multipole_reduced_HO_expansion) : (OBMEs_multipole_reduced_R_cut);
  
  return OBMEs_multipole_reduced;
}
  
TYPE GSM_multipole_OBMEs_TBMEs::uncoupled_OBME (
						const int L ,
						const bool is_it_HO_expansion ,
						const class nucleons_data &data ,
						const unsigned int s_in ,
						const unsigned int s_out )
{
  const class OBMEs_multipole_square_str &OBMEs_multipole = OBMEs_multipole_square_determine (is_it_HO_expansion , data);

  const TYPE OBME = OBMEs_multipole.uncoupled_OBME (L , s_in , s_out);

  return OBME;
}


TYPE GSM_multipole_OBMEs_TBMEs::coupled_OBME (
					      const int L ,
					      const bool is_it_HO_expansion ,
					      const class nucleons_data &data ,
					      const unsigned int s_in ,
					      const unsigned int s_out )
{
  const class OBMEs_multipole_square_str &OBMEs_multipole = OBMEs_multipole_square_determine (is_it_HO_expansion ,  data);

  const TYPE OBME = OBMEs_multipole.coupled_OBME (L , s_in , s_out);

  return OBME;
}








// Check if TBMEs are trivial zeros
// --------------------------------
// TBMEs are of the form <ab | Oi . Oj | cd>.
// a,b,c,d are denoted as s0,s1,s2,s3 in the routine.
//
// pp, nn TBMEs
// ------------
// TBMEs are equal to zero if (a,c) and (a,d) have a different parity from L (direct and exchange parts), as the parity of YL is (-1)^L.
// It is also the case if |ma - mc| > L and |ma - md| > L (direct and exchange parts), or if |ja - jc| > L or |jb - jd| > L (direct part) and |ja - jd| > L or |jb - jc| > L (exchange part).
//
// pn TBMEs
// --------
// The situation here is simpler as there is no antisymmetry. 
// Conditions on parity and m are already taken into account (see two_jumps_pn_part_pn_N_valence_larger_calc and two_jumps_pn_part_pn_Z_valence_larger_calc).
// Hence, the TBME is trivially zero if |ja - jc| > L or |jb - jd| > L.
//
// Coupled and uncoupled TBMEs are considered.

bool GSM_multipole_OBMEs_TBMEs::is_uncoupled_TBME_pp_nn_trivial_zero_determine (
										const int L ,
										const class array<class nljm_struct> &phi_table ,
										const unsigned int s0 , 
										const unsigned int s1 , 
										const unsigned int s2 , 
										const unsigned int s3)
{
  const class nljm_struct &phi0 = phi_table(s0);
  const class nljm_struct &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2);
  const class nljm_struct &phi3 = phi_table(s3);

  const int l0 = phi0.get_l ();
  const int l2 = phi2.get_l ();
  const int l3 = phi3.get_l ();

  const bool direct_parity_condition   = ((l0 + l2 + L)%2 == 0);
  const bool exchange_parity_condition = ((l0 + l3 + L)%2 == 0);

  if (!direct_parity_condition && !exchange_parity_condition) return true;

  const int im0 = phi0.get_im ();
  const int im2 = phi2.get_im ();
  const int im3 = phi3.get_im ();

  const bool direct_projection_condition   = (abs (im0 - im2) <= L);
  const bool exchange_projection_condition = (abs (im0 - im3) <= L);

  if (!direct_projection_condition && !exchange_projection_condition) return true;
  
  const int ij0 = phi0.get_ij ();
  const int ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij ();
  const int ij3 = phi3.get_ij ();

  const bool phi0_phi2_coupling_condition = (abs (ij0 - ij2) <= L);
  const bool phi1_phi3_coupling_condition = (abs (ij1 - ij3) <= L);
  const bool phi0_phi3_coupling_condition = (abs (ij0 - ij3) <= L);
  const bool phi1_phi2_coupling_condition = (abs (ij1 - ij2) <= L);

  const bool direct_coupling_condition   = (phi0_phi2_coupling_condition && phi1_phi3_coupling_condition);
  const bool exchange_coupling_condition = (phi0_phi3_coupling_condition && phi1_phi2_coupling_condition);

  if (!direct_coupling_condition && !exchange_coupling_condition) return true;

  return false;
}

bool GSM_multipole_OBMEs_TBMEs::is_uncoupled_TBME_pn_trivial_zero_determine_coupling_only (
											   const int L ,
											   const class array<class nljm_struct> &phi_table ,
											   const unsigned int s_in , 
											   const unsigned int s_out)
{
  const class nljm_struct &phi_in  = phi_table(s_in);
  const class nljm_struct &phi_out = phi_table(s_out);

  const int ij_in  = phi_in.get_ij ();
  const int ij_out = phi_out.get_ij ();

  const bool coupling_condition = (abs (ij_in - ij_out) <= L);

  return (!coupling_condition);
}









bool GSM_multipole_OBMEs_TBMEs::is_coupled_TBME_pp_nn_trivial_zero_determine (
									      const int L ,
									      const class array<class nlj_struct> &shells_qn ,
									      const unsigned int s0 , 
									      const unsigned int s1 , 
									      const unsigned int s2 , 
									      const unsigned int s3)
{
  const class nlj_struct &wf0 = shells_qn(s0);
  const class nlj_struct &wf2 = shells_qn(s2);
  const class nlj_struct &wf3 = shells_qn(s3);

  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();
  const int l3 = wf3.get_l ();
  
  const bool direct_parity_condition   = ((l0 + l2 + L)%2 == 0);
  const bool exchange_parity_condition = ((l0 + l3 + L)%2 == 0);
  
  if (!direct_parity_condition && !exchange_parity_condition) return true;

  const class nlj_struct &wf1 = shells_qn(s1);

  const int ij0 = wf0.get_ij ();
  const int ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij ();
  const int ij3 = wf3.get_ij ();

  const bool wf0_wf2_coupling_condition = (abs (ij0 - ij2) <= L);
  const bool wf1_wf3_coupling_condition = (abs (ij1 - ij3) <= L);
  const bool wf0_wf3_coupling_condition = (abs (ij0 - ij3) <= L);
  const bool wf1_wf2_coupling_condition = (abs (ij1 - ij2) <= L);

  const bool direct_coupling_condition   = (wf0_wf2_coupling_condition && wf1_wf3_coupling_condition);
  const bool exchange_coupling_condition = (wf0_wf3_coupling_condition && wf1_wf2_coupling_condition);

  if (!direct_coupling_condition && !exchange_coupling_condition) return true;

  return false;
}












bool GSM_multipole_OBMEs_TBMEs::is_coupled_TBME_pn_trivial_zero_determine (
									   const int L ,
									   const class array<class nlj_struct> &shells_qn_prot , 
									   const class array<class nlj_struct> &shells_qn_neut ,
									   const unsigned int s0 , 
									   const unsigned int s1 , 
									   const unsigned int s2 , 
									   const unsigned int s3)
{
  const class nlj_struct &wf0 = shells_qn_prot(s0);
  const class nlj_struct &wf2 = shells_qn_prot(s2);

  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();

  const bool parity_condition = ((l0 + l2 + L)%2 == 0);

  if (!parity_condition) return true; 

  const class nlj_struct &wf1 = shells_qn_neut(s1);
  const class nlj_struct &wf3 = shells_qn_neut(s3);

  const int ij0 = wf0.get_ij ();
  const int ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij ();
  const int ij3 = wf3.get_ij ();

  const bool wf0_wf2_coupling_condition = (abs (ij0 - ij2) <= L);
  const bool wf1_wf3_coupling_condition = (abs (ij1 - ij3) <= L);

  const bool coupling_condition = (wf0_wf2_coupling_condition && wf1_wf3_coupling_condition);

  if (!coupling_condition) return true;

  return false;
}









// Calculation of TBMEs according to the considered multipole operator
// ------------------------------------------------------------
// a,b,c,d are denoted as s0,s1,s2,s3 in the routines.
// They are shell indices (n,l,j) in the next two routines and state indices (n,l,j,m) in the following routines.
//
// Angular TBMEs are calculated in a multipole_TBMEs_angular_table_str class using stored Clebsch-Gordan coefficients (see GSM_multipole_TBMEs_angular_table_str.cpp).
// Hence, leaving out antisymmetry, <ab | Oi . Oj | cd> is a product of stored const.<a || Oi || c>, const.<b || Oj || d>, TBME_angular(a,b,c,d).
// One obtains the full pp or nn TBME by considering both direct and exchange parts.
// They are considered to be equal to zero if their infinite norms are smaller than 10^(-13).
//
// Coupled and uncoupled TBMEs are considered.




TYPE GSM_multipole_OBMEs_TBMEs::TBME_pp_nn_calc (
						 const int L ,
						 const unsigned int s0 , 
						 const unsigned int s1 , 
						 const unsigned int s2 , 
						 const unsigned int s3 , 
						 const double angular_TBME_direct , 
						 const double angular_TBME_exchange , 
						 const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced)
{
  const TYPE OBMEs_product_direct   = OBMEs_multipole_reduced.reduced_OBME (L , s0 , s2)*OBMEs_multipole_reduced.reduced_OBME (L , s1 , s3);
  const TYPE OBMEs_product_exchange = OBMEs_multipole_reduced.reduced_OBME (L , s1 , s2)*OBMEs_multipole_reduced.reduced_OBME (L , s0 , s3);

  const TYPE TBME_numerical = angular_TBME_direct*OBMEs_product_direct - angular_TBME_exchange*OBMEs_product_exchange;

  const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
	
  return TBME;
}




TYPE GSM_multipole_OBMEs_TBMEs::TBME_pn_calc (
					      const int L ,
					      const unsigned int s0 , 
					      const unsigned int s1 , 
					      const unsigned int s2 , 
					      const unsigned int s3 , 
					      const double angular_TBME , 
					      const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_prot ,
					      const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_neut)
{ 
  const TYPE OBMEs_product = OBMEs_multipole_reduced_prot.reduced_OBME (L , s0 , s2)*OBMEs_multipole_reduced_neut.reduced_OBME (L , s1 , s3);
  
  const TYPE TBME_numerical = angular_TBME*OBMEs_product;
  
  const TYPE TBME = ((inf_norm (TBME_numerical) > 1E-13) ? (TBME_numerical) : (0.0));
  
  return TBME;
}




TYPE GSM_multipole_OBMEs_TBMEs::uncoupled_TBME_pp_nn_calc (
							   const int L ,
							   const bool is_it_HO_expansion ,
							   const class nucleons_data &data ,
							   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
							   const unsigned int s0 , 
							   const unsigned int s1 , 
							   const unsigned int s2 , 
							   const unsigned int s3)
{ 
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const class nljm_struct &phi0 = phi_table(s0);
  const class nljm_struct &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2);
  const class nljm_struct &phi3 = phi_table(s3);

  const int ij0 = phi0.get_ij ();
  const int ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij ();
  const int ij3 = phi3.get_ij ();
  
  const int im0 = phi0.get_im ();
  const int im1 = phi1.get_im ();
  const int im2 = phi2.get_im ();
  const int im3 = phi3.get_im ();
  
  const double angular_TBME_direct   = TBMEs_angular_table(ij0 , im0 , ij1 , im1 , ij2 , im2 , ij3 , im3);
  const double angular_TBME_exchange = TBMEs_angular_table(ij1 , im1 , ij0 , im0 , ij2 , im2 , ij3 , im3);
     
  const unsigned int shell_s0_index = phi0.get_shell_index ();
  const unsigned int shell_s1_index = phi1.get_shell_index ();
  const unsigned int shell_s2_index = phi2.get_shell_index ();
  const unsigned int shell_s3_index = phi3.get_shell_index ();

  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced = OBMEs_multipole_reduced_determine (is_it_HO_expansion , data);
          
  const TYPE TBME_pp_nn = TBME_pp_nn_calc (L , shell_s0_index , shell_s1_index , shell_s2_index , shell_s3_index , angular_TBME_direct , angular_TBME_exchange , OBMEs_multipole_reduced);

  return TBME_pp_nn;
}




TYPE GSM_multipole_OBMEs_TBMEs::uncoupled_TBME_pn_calc (
							const int L ,
							const bool is_it_HO_expansion ,
							const class nucleons_data &prot_data ,
							const class nucleons_data &neut_data ,
							const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
							const unsigned int s0 , 
							const unsigned int s1 , 
							const unsigned int s2 , 
							const unsigned int s3)
{
  const class array<class nljm_struct> &phi_table_prot = prot_data.get_phi_table ();
  const class array<class nljm_struct> &phi_table_neut = neut_data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table_prot(s0) , &phi1 = phi_table_neut(s1);
  const class nljm_struct &phi2 = phi_table_prot(s2) , &phi3 = phi_table_neut(s3);

  const int ij0 = phi0.get_ij ();
  const int ij1 = phi1.get_ij ();
  const int ij2 = phi2.get_ij ();
  const int ij3 = phi3.get_ij ();
  
  const int im0 = phi0.get_im ();
  const int im1 = phi1.get_im ();
  const int im2 = phi2.get_im ();
  const int im3 = phi3.get_im ();

  const double angular_TBME = TBMEs_angular_table(ij0 , im0 , ij1 , im1 , ij2 , im2 , ij3 , im3);
  
  const unsigned int shell_s0_index = phi0.get_shell_index ();
  const unsigned int shell_s1_index = phi1.get_shell_index ();
  const unsigned int shell_s2_index = phi2.get_shell_index ();
  const unsigned int shell_s3_index = phi3.get_shell_index ();

  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_prot = OBMEs_multipole_reduced_determine (is_it_HO_expansion , prot_data);
  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_neut = OBMEs_multipole_reduced_determine (is_it_HO_expansion , neut_data);
  
  const TYPE TBME_pn = TBME_pn_calc (L , shell_s0_index , shell_s1_index , shell_s2_index , shell_s3_index , angular_TBME , OBMEs_multipole_reduced_prot , OBMEs_multipole_reduced_neut);
  
  return TBME_pn;
}






TYPE GSM_multipole_OBMEs_TBMEs::coupled_TBME_pp_nn_calc (
							 const int L ,
							 const bool is_it_HO_expansion ,
							 const class nucleons_data &data ,
							 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
							 const unsigned int s0 , 
							 const unsigned int s1 , 
							 const unsigned int s2 , 
							 const unsigned int s3)
{  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
    
  const int J = TBMEs_angular_table.get_J ();
		      
  const class nlj_struct &wf0 = shells_qn(s0);
  const class nlj_struct &wf1 = shells_qn(s1);
  const class nlj_struct &wf2 = shells_qn(s2);
  const class nlj_struct &wf3 = shells_qn(s3);
  
  const int ij0 = wf0.get_ij ();
  const int ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij ();
  const int ij3 = wf3.get_ij ();
  
  const double phase = minus_one_pow (ij0 + ij1 + 1 - J);

  const double antisymmetry_inv_norm_in  = (s0 == s1) ? (M_SQRT1_2) : (1.0);
  const double antisymmetry_inv_norm_out = (s2 == s3) ? (M_SQRT1_2) : (1.0);

  const double antisymmetry_inv_norm = antisymmetry_inv_norm_in*antisymmetry_inv_norm_out;

  const double angular_TBME_direct = TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);

  const double angular_TBME_exchange = (phase == 1) ? (TBMEs_angular_table(ij1 , ij0 , ij2 , ij3)) : (-TBMEs_angular_table(ij1 , ij0 , ij2 , ij3));
     
  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced = OBMEs_multipole_reduced_determine (is_it_HO_expansion , data);
    
  const TYPE TBME_pp_nn_not_normalized = TBME_pp_nn_calc (L , s0 , s1 , s2 , s3 , angular_TBME_direct , angular_TBME_exchange , OBMEs_multipole_reduced);

  const TYPE TBME_pp_nn = antisymmetry_inv_norm*TBME_pp_nn_not_normalized;
  
  return TBME_pp_nn;
}

















TYPE GSM_multipole_OBMEs_TBMEs::coupled_TBME_pn_calc (
						      const int L ,
						      const bool is_it_HO_expansion ,
						      const class nucleons_data &prot_data ,
						      const class nucleons_data &neut_data ,
						      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						      const unsigned int s0 , 
						      const unsigned int s1 , 
						      const unsigned int s2 , 
						      const unsigned int s3)
{
  const class array<class nlj_struct> &shells_qn_prot = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_neut = neut_data.get_shells_quantum_numbers ();
    
  const class nlj_struct &wf0 = shells_qn_prot(s0);
  const class nlj_struct &wf1 = shells_qn_neut(s1);
  const class nlj_struct &wf2 = shells_qn_prot(s2);
  const class nlj_struct &wf3 = shells_qn_neut(s3);

  const int ij0 = wf0.get_ij ();
  const int ij1 = wf1.get_ij ();
  const int ij2 = wf2.get_ij ();
  const int ij3 = wf3.get_ij ();

  const double angular_TBME = TBMEs_angular_table(ij0 , ij1 , ij2 , ij3);

  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_prot = OBMEs_multipole_reduced_determine (is_it_HO_expansion , prot_data);
  const class OBMEs_multipole_reduced_str &OBMEs_multipole_reduced_neut = OBMEs_multipole_reduced_determine (is_it_HO_expansion , neut_data);
  
  const TYPE TBME_pn = TBME_pn_calc (L , s0 , s1 , s2 , s3 , angular_TBME , OBMEs_multipole_reduced_prot , OBMEs_multipole_reduced_neut);
  
  return TBME_pn;
}


