#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class configuration_one_jump_data_in_to_out_str storing data about a+_{alpha} a_{beta} jumps on an in configuration to generate an out configuration
// ----------------------------------------------------------------------------------------------------------------------------------------------------
// class configuration_one_jump_data_in_to_out_str stores information related to the out configuration obtained after the action of a+_{alpha} a_{beta} on an in configuration to generate the out configuration.
// It contains the number of particles in the continuum of the out configuration,
// the equivalent configuration index for this jump (see GSM_configuration_one_jump_construction_set_in_to_out.cpp for the definition of the equivalent configuration for jumps),
// the indices of the in shell (beta) and of the out shell (alpha) and the index of the out configuration.



configuration_one_jump_data_in_to_out_str::configuration_one_jump_data_in_to_out_str ()
  : n_holes_out (0) ,
    n_scat_out (0) , 
    C_eq_one_jump_index (0) ,
    C_in_shell (0) , 
    C_out_shell (0) ,  
    iC_out (0)
{}

configuration_one_jump_data_in_to_out_str::configuration_one_jump_data_in_to_out_str (
										      const unsigned int n_holes_out_c , 
										      const unsigned int n_scat_out_c , 
										      const unsigned int iC_out_c , 
										      const unsigned int C_eq_one_jump_index_c , 
										      const unsigned int C_in_shell_c , 
										      const unsigned int C_out_shell_c)
{
  initialize (n_holes_out_c , n_scat_out_c , iC_out_c , C_eq_one_jump_index_c , C_out_shell_c , C_in_shell_c);
}

void configuration_one_jump_data_in_to_out_str::initialize (
							    const unsigned int n_holes_out_c , 
							    const unsigned int n_scat_out_c ,
							    const unsigned int iC_out_c , 
							    const unsigned int C_eq_one_jump_index_c ,
							    const unsigned int C_in_shell_c , 
							    const unsigned int C_out_shell_c)
{
  n_holes_out = n_holes_out_c;
  
  n_scat_out = n_scat_out_c; 

  C_eq_one_jump_index = C_eq_one_jump_index_c;

  C_in_shell = C_in_shell_c; 

  C_out_shell = C_out_shell_c;  

  iC_out = iC_out_c;
}

void configuration_one_jump_data_in_to_out_str::initialize (const class configuration_one_jump_data_in_to_out_str &X)
{
  n_holes_out = X.n_holes_out;
  
  n_scat_out = X.n_scat_out; 

  C_eq_one_jump_index = X.C_eq_one_jump_index;  

  C_in_shell = X.C_in_shell; 

  C_out_shell = X.C_out_shell;

  iC_out = X.iC_out;
}
   

double used_memory_calc (const class configuration_one_jump_data_in_to_out_str &T)
{
  return (sizeof (T)/1000000.0);
}
