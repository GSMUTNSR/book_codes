#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// Calculation of the radial or momentum array of wave function products over 4 Pi r^2 entering density for all one-body states
// ----------------------------------------------------------------------------------------------------------------------------
// One calculates here the radial functions <b | \delta (r - r_1)/r^2 | a > = u_a(r) u_b(r) / (4 Pi r^2) for a fixed type of particle.
// or momentum functions <b | \delta (k - k_1)/k^2 | a > = u_a(k) u_b(k) / (4 Pi k^2) entering density matrix elements.
// The array of radii is either of Gauss-Legendre type or is uniformly distributed.
//
// rk is r or k.

void density_OBMEs::OBMEs_shells_calc (
				       const enum particle_type density_particle ,
				       const bool is_it_radial ,
				       const bool is_it_Gauss_Legendre ,
				       const class baryons_data &data ,
				       class array<TYPE> &OBMEs_shells)
{
  OBMEs_shells = 0.0;
      
  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const int charge_density_particle = particle_charge_determine (density_particle);

  const bool is_density_particle_charged = (charge_density_particle != 0);
  
  if (is_it_charged != is_density_particle_charged) return;
  
  const double four_Pi = 12.566370614359173;

  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_nlj = OBMEs_shells.dimension (0);
  
  const unsigned int Nrk = OBMEs_shells.dimension (2);
  
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {	
	const class spherical_state &shell_in  = shells(s_in);
	const class spherical_state &shell_out = shells(s_out);
	
	const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_in.get_r_bef_R_tab_GL ()) : (shell_in.get_r_bef_R_tab_uniform ());
	
	const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (shell_in.get_k_tab_GL ()) : (shell_in.get_k_tab_uniform ());
	
	const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);

	const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_bef_R_tab_GL ())  : (shell_in.get_wf_bef_R_tab_uniform ());
	const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_bef_R_tab_GL ()) : (shell_out.get_wf_bef_R_tab_uniform ());

	const class array<complex<double> > &dwf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_bef_R_tab_GL ())  : (shell_in.get_dwf_bef_R_tab_uniform ());
	const class array<complex<double> > &dwf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_bef_R_tab_GL ()) : (shell_out.get_dwf_bef_R_tab_uniform ());

	const class array<complex<double> > &wf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_momentum_tab_GL ())  : (shell_in.get_wf_momentum_tab_uniform ());
	const class array<complex<double> > &wf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_momentum_tab_GL ()) : (shell_out.get_wf_momentum_tab_uniform ());

	const class array<complex<double> > &dwf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_momentum_tab_GL ())  : (shell_in.get_dwf_momentum_tab_uniform ());
	const class array<complex<double> > &dwf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_momentum_tab_GL ()) : (shell_out.get_dwf_momentum_tab_uniform ());

	const class array<complex<double> > &wf_in_rk_tab  = (is_it_radial) ? (wf_in_bef_R_tab)  : (wf_in_momentum_tab);
	const class array<complex<double> > &dwf_in_rk_tab = (is_it_radial) ? (dwf_in_bef_R_tab) : (dwf_in_momentum_tab);
	
	const class array<complex<double> > &wf_out_rk_tab  = (is_it_radial) ? (wf_out_bef_R_tab)  : (wf_out_momentum_tab);
	const class array<complex<double> > &dwf_out_rk_tab = (is_it_radial) ? (dwf_out_bef_R_tab) : (dwf_out_momentum_tab);
	
	if (same_lj_particle (shell_in , shell_out))
	  {	    
	    const enum particle_type particle = shell_in.get_particle ();

	    if (particle == density_particle)
	      {
		if (Nrk > 0)
		  {
		    const double rk0 = rk_tab(0);
		    const double rk0_2 = rk0*rk0;
	    
		    const complex<double> wf_in_rk0  = wf_in_rk_tab(0);
		    const complex<double> dwf_in_rk0 = dwf_in_rk_tab(0);
	    
		    const complex<double> wf_out_rk0  = wf_out_rk_tab(0);	    
		    const complex<double> dwf_out_rk0 = dwf_out_rk_tab(0);
		
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (wf_in_rk0*wf_out_rk0/rk0_2) : (dwf_in_rk0*dwf_out_rk0);
#endif

#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (real (wf_in_rk0)*real (wf_out_rk0)/rk0_2) : (real (dwf_in_rk0)*real (dwf_out_rk0));
#endif
		  }
	
		for (unsigned int i = 1 ; i < Nrk ; i++)
		  {
		    const double rk = rk_tab(i);
		
		    const double rk2 = rk*rk;
	    
		    const complex<double> wf_in_rk  = wf_in_rk_tab(i);
		    const complex<double> wf_out_rk = wf_out_rk_tab(i);
		
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , i) = wf_in_rk*wf_out_rk/rk2;
#endif
		
#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , i) = real (wf_in_rk)*real (wf_out_rk)/rk2;
#endif
		  }
	      }
	  }
      }
  
  OBMEs_shells /= four_Pi;
}



// Calculation of the array of one-body matrix elements of density for all one-body states
// ---------------------------------------------------------------------------------------
// One calculates here the radial functions <out | \delta (r - r_1)/r^2 | in > entering density matrix elements including its angular part and stores them in an array.

void density_OBMEs::OBMEs_calc (
				const enum particle_type density_particle ,
				const bool is_it_radial ,
				const bool is_it_Gauss_Legendre ,
				const class baryons_data &data ,
				class array<TYPE> &OBMEs)
{
  OBMEs = 0.0;
      
  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const int charge_density_particle = particle_charge_determine (density_particle);

  const bool is_density_particle_charged = (charge_density_particle != 0);
  
  if (is_it_charged != is_density_particle_charged) return;
  
  const class array<class nljm_struct> &phi_table = data.get_phi_table ();
  
  const unsigned int N_nljm = data.get_N_nljm_baryon ();

  const unsigned int N_nlj = data.get_N_nlj_baryon ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL = data.get_Nk_momentum_GL ();
  
  const unsigned int Nk_momentum_uniform = data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);

  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  class array<TYPE> OBMEs_shells(N_nlj , N_nlj , Nrk);

  OBMEs_shells_calc (density_particle , is_it_radial , is_it_Gauss_Legendre , data , OBMEs_shells);
  
  for (unsigned int in = 0 ; in < N_nljm ; in++)
    for (unsigned int out = 0 ; out < N_nljm ; out++) 
      {
	const class nljm_struct &phi_in  = phi_table(in);
	const class nljm_struct &phi_out = phi_table(out);
	
	if (same_Yljm_particle (phi_in , phi_out))
	  {	
	    const unsigned int s_in  = phi_in.get_shell_index ();
	    const unsigned int s_out = phi_out.get_shell_index ();
	
	    for (unsigned int i = 0 ; i < Nrk ; i++) OBMEs(in , out , i) = OBMEs_shells(s_in , s_out , i);
	  }
      }
}

