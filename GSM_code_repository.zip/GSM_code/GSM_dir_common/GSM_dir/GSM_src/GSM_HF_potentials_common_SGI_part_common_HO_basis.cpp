#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Calculation of the non-antisymmetrized (nas) HF potential one-body matrix element of the SGI interaction taking into account one occupied state for one multipole for the direct or exchange part with the HO basis
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here \int wf_HO_in(r) wf_HO_out(r) wf_occ(r)^2 Vl_SGI(r) dr for the direct part or  \int wf_HO_in(r) wf_HO_out(2.R0 - r) wf_occ(r) wf_occ(2.R0 - r) Vl_SGI(r) dr for the exchange part.
// This matrix element is used to calculate the full HF potential one-body matrix element of the SGI interaction between the in and out HO states.

complex<double> HF_potentials_common::SGI_MSGI_part_common::SGI_part_common::HO_basis::OBME_nas_fixed_multipole_calc (
														      const class interaction_class &inter_data_basis , 
														      const int ll , 
														      const bool is_it_direct , 
														      const complex<double> &angular_part_weight , 
														      const class spherical_state &wf_occ , 
														      const int l , 
														      const int n_HO_in , 
														      const int n_HO_out)
{
  const class array<double> &w_bef_R_tab_GL = inter_data_basis.get_w_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data_basis.get_HO_wfs_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wf_occ_bef_R_tab_GL = wf_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<double> &Vl_SGI_tab_GL = inter_data_basis.get_Vl_SGI_tab_GL ();

  const unsigned int N_bef_R_GL = w_bef_R_tab_GL.dimension (0);

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;


  complex<double> OBME = 0.0;

  if (is_it_direct)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const unsigned int i_opp = N_bef_R_GL_minus_one - i;
	  
	  OBME += HO_wfs_bef_R_tab_GL(n_HO_in , l , i)*HO_wfs_bef_R_tab_GL(n_HO_out , l , i)*(real (wf_occ_bef_R_tab_GL(i_opp)*wf_occ_bef_R_tab_GL(i_opp))*Vl_SGI_tab_GL(ll , i)*w_bef_R_tab_GL(i));
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const unsigned int i_opp = N_bef_R_GL_minus_one - i;
	  
	  OBME += HO_wfs_bef_R_tab_GL(n_HO_in , l , i_opp)*HO_wfs_bef_R_tab_GL(n_HO_out , l , i)*(real (wf_occ_bef_R_tab_GL(i)*wf_occ_bef_R_tab_GL(i_opp))*Vl_SGI_tab_GL(ll , i)*w_bef_R_tab_GL(i));
	}
    }

  OBME *= angular_part_weight;

  return OBME;
}

