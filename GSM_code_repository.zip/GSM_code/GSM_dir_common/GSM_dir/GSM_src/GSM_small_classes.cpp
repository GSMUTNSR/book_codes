#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace angular_matrix_elements;
using namespace Wigner_signs;

// TYPE is double or complex
// -------------------------


// Prints are not detailed. They are of the form 0p3/2, or 0p3/2(3/2) if the total angular momentum projection is included
//------------------------------------------------------------------------------------------------------------------------

// Ordering is lexicographic in the (n,l,j,m) quantum numbers and is not detailed in general 
// -----------------------------------------------------------------------------------------









// Structure for orbital angular states. It contains l,ml quantum number as integers
// ---------------------------------------------------------------------------------

lm_struct::lm_struct () :
  l (0) ,
  ml (0)
{}

lm_struct::lm_struct (const int l_c , const int ml_c)
{
  initialize (l_c , ml_c);
}

void lm_struct::initialize (const int l_c , const int ml_c)
{
  l = l_c;
  ml = ml_c;
}



#ifdef UseMPI

MPI_Datatype MPI_Datatype_lm_struct_create ()
{
  const unsigned int N_members = 2;

  const MPI_Datatype MPI_int = MPI_helper::MPI_equivalent_type<int> ();

  MPI_Datatype types[N_members] = {MPI_int , MPI_int};

  int block_lengths[N_members] = {1 , 1};

  class lm_struct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0] = MPI_helper::Get_address (&A.l)  - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.ml) - A_address;

  const MPI_Datatype MPI_lm_struct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_lm_struct;
}

#endif

double used_memory_calc (const class lm_struct &T)
{
  return sizeof (T)/1000000.0;
}



bool operator == (const class lm_struct &a , const class lm_struct &b)
{
  if ((a.get_l () != b.get_l ()) || (a.get_ml () != b.get_ml ())) return false;

  return true;
}

bool operator != (const class lm_struct &a , const class lm_struct &b)
{
  return !(a == b);
}

ostream & operator << (ostream &os , const class lm_struct &s)
{
  return os << s.get_l () << "(" << s.get_ml () << ")";
}




// Structure for angular states. It contains l,j,m quantum numbers and associated indices
// --------------------------------------------------------------------------------------
// l,j,m: orbital, total angular momenta and total angular momentum of the state
// im, m_max: integer index for the m projection. It is m + m_max, with m_max the maximal total angular projection of all the states of same type (proton or neutron)


ljm_struct::ljm_struct () {}

ljm_struct::ljm_struct (const int l_c , const double j_c , const double m_c , const double m_max) 
{
  initialize (l_c , j_c , m_c , m_max);
}

void ljm_struct::initialize (const int l_c , const double j_c , const double m_c , const double m_max) 
{
  l = l_c;
  j = j_c;
  m = m_c;
  
  ij = make_int (j - 0.5);

  im = make_int (m + m_max);
}


#ifdef UseMPI

MPI_Datatype MPI_Datatype_ljm_struct_create ()
{
  const unsigned int N_members = 5;

  const MPI_Datatype MPI_int    = MPI_helper::MPI_equivalent_type<int> ();
  const MPI_Datatype MPI_double = MPI_helper::MPI_equivalent_type<double> ();

  MPI_Datatype types[N_members] = {MPI_int ,
				   MPI_double , MPI_double ,
				   MPI_int , MPI_int};

  int block_lengths[N_members] = {1 , 1 , 1 , 1 , 1};

  class ljm_struct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0] = MPI_helper::Get_address (&A.l)  - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.j)  - A_address;
  address_displacements[2] = MPI_helper::Get_address (&A.m)  - A_address;
  address_displacements[3] = MPI_helper::Get_address (&A.ij) - A_address;
  address_displacements[4] = MPI_helper::Get_address (&A.im) - A_address;

  const MPI_Datatype MPI_ljm_struct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_ljm_struct;
}

#endif

double used_memory_calc (const class ljm_struct &T)
{
  return sizeof (T)/1000000.0;
}





bool operator == (const class ljm_struct &a , const class ljm_struct &b)
{
  if ((a.get_l () != b.get_l ()) || (a.get_ij () != b.get_ij ()) || (a.get_im () != b.get_im ())) return false;

  return true;
}

bool operator != (const class ljm_struct &a , const class ljm_struct &b)
{
  return !(a == b);
}


ostream & operator << (ostream &os , const class ljm_struct &s)
{
  return os << angular_state (s.get_l () , s.get_j ()) << "(" << make_int (2.0*s.get_m ())<< "/2)";
}




// Structure for (n,l,j) shells
// ----------------------------
// This structure contain information concerning a (n,l,j) shell:
//
// S_matrix_pole, core_state, frozen_state, hole_state, OCM valence_state: 
// true if it is a pole state, core state, core frozen state, core hole state (i.e. it is in the core and is used in Slater determinants)), OCM valence state (i.e. it must be orthogonal to core states) false if not
//
// is_it_HO, is_it_for_HF_gs, is_it_natural_orbital: true it is a HO state, a state which is allowed to be occupied in the HF ground state (gs), a natural orbital, false if not
// e_trunc: truncation energy in hbar omega unit. It does not have to be equal to 2n + l, it can be an arbitrary integer.
// n,l,j: principal quantum number, orbital and total angular momenta of the shell
// ij: index of j, equal to j-1/2
// segment_int: integer value of the enumeration segment_type, giving the type of segment one is on a Berggren basis contour (from k=0 to k_peak, from k_peak to k_middle, from k_middle to kmax) if the state is a scattering state. 
//              One uses an integer internally so that MPI transfer is done simply. The enumeration segment_type is returned otherwise.
// Re/Im_k,w,C0,Cplus,k_plus,CO_plus,k_minus,C0_minus: real and imaginary parts of k,w,C0,Cplus,k_plus,CO_plus,k_minus,C0_minus. 
//                                                     One uses real and imaginary parts as MPI transfer of complex numbers from a user-defined MPI structure can make the code crash.
//
// k, k_plus, k_minus: initial linear momentum of the considered shell, as well as the values k +/- w/(4 Pi) (see below), with w the Gauss-Legendre weight of the considered shell
// w: Gauss-Legendre weight of the considered shell on a discretized Berggren basis contour; meaningful for Berggren scattering states only
//
// C0, C0_plus, C0_minus, Cplus: values of the C0 constants (u(r) ~ C0 r^(l+1) for r ~ 0) in shells calculated with k and k +/- w/(4 Pi) (see below), with w the Gauss-Legendre weight of the considered shell,
//                               and of the C+ constant for the shell calculated with k. 
//                               They are necessary for non-local potentials, as the equivalent potential method with a source is not homogeneous, so that C0 r^(l+1) as a starting value is not equivalent to r^(l+1) as a starting value.
//                               It is the case for local potentials, so that they are put to one therein. 
//                               C+ is used only with pole shells, and states calculated with k +/- w/(4 Pi) (see below), 
//                               with w the Gauss-Legendre weight of the considered shell, are always scattering, so that one does not need C+ in this case.
//
// If one has a scattering proton, in the latter case, the shells with k +/- w/(4 Pi), with w the Gauss-Legendre weight of the considered shell,
// are calculated to be able to use the off-diagonal method for matrix elements of the Coulomb infinite range (see N. Michel, Phys. Rev. C 83, 034325 (2011)).

nlj_struct::nlj_struct () :
  S_matrix_pole (false) ,
  core_state (false) ,
  frozen_state (false) , 
  hole_state (false) , 
  OCM_valence_state (false) , 
  is_it_HO (false) , 
  is_it_for_HF_gs (false) , 
  is_it_natural_orbital (false) ,
  e_trunc (0) , 
  n (0) , 
  l (0) ,
  ij (0) ,
  segment_int (0) ,
  j (0.0) ,
  Re_k (0.0) , 
  Re_w (0.0) , 
  Re_C0 (0.0) ,
  Re_Cplus (0.0) ,
  Re_k_plus (0.0) , 
  Re_C0_plus (0.0) ,
  Re_k_minus (0.0) ,
  Re_C0_minus (0.0) ,
  Im_k (0.0) , 
  Im_w (0.0) , 
  Im_C0 (0.0) ,
  Im_Cplus (0.0) ,
  Im_k_plus (0.0) , 
  Im_C0_plus (0.0) ,
  Im_k_minus (0.0) ,
  Im_C0_minus (0.0)
{}

nlj_struct::nlj_struct (
			const bool S_matrix_pole_c , 
			const bool core_state_c , 
			const bool frozen_state_c , 
			const bool hole_state_c , 
			const bool OCM_valence_state_c , 
			const bool is_it_HO_c , 
			const bool is_it_for_HF_gs_c , 
			const bool is_it_natural_orbital_c , 
			const int e_trunc_c , 
			const int n_c , 
			const int l_c , 
			const double j_c , 
			const enum segment_type segment_c , 
			const complex<double> &k_c , 
			const complex<double> &w_c , 
			const complex<double> &C0_c , 
			const complex<double> &Cplus_c , 
			const complex<double> &k_plus_c , 
			const complex<double> &C0_plus_c , 
			const complex<double> &k_minus_c , 
			const complex<double> &C0_minus_c)
{
  initialize (S_matrix_pole_c , core_state_c , frozen_state_c , hole_state_c , OCM_valence_state_c , is_it_HO_c , is_it_for_HF_gs_c , is_it_natural_orbital_c ,
	      e_trunc_c , n_c , l_c , j_c , segment_c , k_c , w_c , C0_c , Cplus_c , k_plus_c , C0_plus_c , k_minus_c , C0_minus_c);
}

void nlj_struct::initialize (
			     const bool S_matrix_pole_c , 
			     const bool core_state_c , 
			     const bool frozen_state_c , 
			     const bool hole_state_c , 
			     const bool OCM_valence_state_c , 
			     const bool is_it_HO_c , 
			     const bool is_it_for_HF_gs_c , 
			     const bool is_it_natural_orbital_c , 
			     const int e_trunc_c , 
			     const int n_c , 
			     const int l_c , 
			     const double j_c , 
			     const enum segment_type segment , 
			     const complex<double> &k_c , 
			     const complex<double> &w_c , 
			     const complex<double> &C0_c , 
			     const complex<double> &Cplus_c , 
			     const complex<double> &k_plus_c , 
			     const complex<double> &C0_plus_c , 
			     const complex<double> &k_minus_c , 
			     const complex<double> &C0_minus_c)
{
  S_matrix_pole = S_matrix_pole_c; 

  core_state = core_state_c; 

  frozen_state = frozen_state_c; 

  hole_state = hole_state_c; 

  OCM_valence_state = OCM_valence_state_c; 

  is_it_HO = is_it_HO_c; 

  is_it_for_HF_gs = is_it_for_HF_gs_c; 

  is_it_natural_orbital = is_it_natural_orbital_c; 

  e_trunc = e_trunc_c;
  
  n = n_c; 
  l = l_c; 
  j = j_c;

  segment_int = make_int (segment);

  Re_k       = real (k_c); 
  Re_k_plus  = real (k_plus_c); 
  Re_k_minus = real (k_minus_c);
  
  Re_w = real (w_c);
  
  Re_C0       = real (C0_c);
  Re_C0_plus  = real (C0_plus_c); 
  Re_C0_minus = real (C0_minus_c);
  
  Re_Cplus = real (Cplus_c); 
 
  Im_k       = imag (k_c); 
  Im_k_plus  = imag (k_plus_c); 
  Im_k_minus = imag (k_minus_c);
  
  Im_w = imag (w_c); 

  Im_C0       = imag (C0_c);
  Im_C0_plus  = imag (C0_plus_c); 
  Im_C0_minus = imag (C0_minus_c);
  
  Im_Cplus = imag (Cplus_c); 

  ij = (is_it_integer (j)) ? (make_int (j)) : (make_int (j - 0.5));
}

// It is the number of states on the shell. It is 2j + 1, calculated only with integers
// ------------------------------------------------------------------------------------

int nlj_struct::m_number_determine () const
{
  const int m_number = 2*ij + 2;

  return m_number;
}




#ifdef UseMPI

MPI_Datatype MPI_Datatype_nlj_struct_create ()
{
  const unsigned int N_members = 30;

  const MPI_Datatype MPI_bool   = MPI_helper::MPI_equivalent_type<bool> ();
  const MPI_Datatype MPI_int    = MPI_helper::MPI_equivalent_type<int> ();
  const MPI_Datatype MPI_double = MPI_helper::MPI_equivalent_type<double> ();

  MPI_Datatype types[N_members] = {MPI_bool , MPI_bool , MPI_bool , MPI_bool , MPI_bool , MPI_bool , MPI_bool , MPI_bool ,
				   MPI_int , MPI_int , MPI_int , MPI_int , MPI_int ,
				   MPI_double ,
				   MPI_double , MPI_double , MPI_double , MPI_double ,
				   MPI_double , MPI_double , MPI_double , MPI_double ,
				   MPI_double , MPI_double , MPI_double , MPI_double ,
				   MPI_double , MPI_double , MPI_double , MPI_double};

  int block_lengths[N_members] = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};

  class nlj_struct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0]  = MPI_helper::Get_address (&A.S_matrix_pole)         - A_address;
  address_displacements[1]  = MPI_helper::Get_address (&A.core_state)            - A_address;
  address_displacements[2]  = MPI_helper::Get_address (&A.frozen_state)          - A_address;
  address_displacements[3]  = MPI_helper::Get_address (&A.hole_state)            - A_address;
  address_displacements[4]  = MPI_helper::Get_address (&A.OCM_valence_state)     - A_address;
  address_displacements[5]  = MPI_helper::Get_address (&A.is_it_HO)              - A_address;
  address_displacements[6]  = MPI_helper::Get_address (&A.is_it_for_HF_gs)       - A_address;
  address_displacements[7]  = MPI_helper::Get_address (&A.is_it_natural_orbital) - A_address;
  address_displacements[8]  = MPI_helper::Get_address (&A.e_trunc)               - A_address;
  address_displacements[9]  = MPI_helper::Get_address (&A.n)                     - A_address;
  address_displacements[10] = MPI_helper::Get_address (&A.l)                     - A_address;
  address_displacements[11] = MPI_helper::Get_address (&A.ij)                    - A_address;
  address_displacements[12] = MPI_helper::Get_address (&A.segment_int)           - A_address;
  address_displacements[13] = MPI_helper::Get_address (&A.j)                     - A_address;
  address_displacements[14] = MPI_helper::Get_address (&A.Re_k)                  - A_address;
  address_displacements[15] = MPI_helper::Get_address (&A.Re_w)                  - A_address;
  address_displacements[16] = MPI_helper::Get_address (&A.Re_C0)                 - A_address;
  address_displacements[17] = MPI_helper::Get_address (&A.Re_Cplus)              - A_address;
  address_displacements[18] = MPI_helper::Get_address (&A.Re_k_plus)             - A_address;
  address_displacements[19] = MPI_helper::Get_address (&A.Re_C0_plus)            - A_address;
  address_displacements[20] = MPI_helper::Get_address (&A.Re_k_minus)            - A_address;
  address_displacements[21] = MPI_helper::Get_address (&A.Re_C0_minus)           - A_address;
  address_displacements[22] = MPI_helper::Get_address (&A.Im_k)                  - A_address;
  address_displacements[23] = MPI_helper::Get_address (&A.Im_w)                  - A_address;
  address_displacements[24] = MPI_helper::Get_address (&A.Im_C0)                 - A_address;
  address_displacements[25] = MPI_helper::Get_address (&A.Im_Cplus)              - A_address;
  address_displacements[26] = MPI_helper::Get_address (&A.Im_k_plus)             - A_address;
  address_displacements[27] = MPI_helper::Get_address (&A.Im_C0_plus)            - A_address;
  address_displacements[28] = MPI_helper::Get_address (&A.Im_k_minus)            - A_address;
  address_displacements[29] = MPI_helper::Get_address (&A.Im_C0_minus)           - A_address;

  const MPI_Datatype MPI_nlj_struct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_nlj_struct;
}

#endif

double used_memory_calc (const class nlj_struct &T)
{
  return sizeof (T)/1000000.0;
}




bool operator == (const class nlj_struct &a , const class nlj_struct &b)
{
  if (a.get_S_matrix_pole () != b.get_S_matrix_pole()) return false;
  if (a.get_core_state ()    != b.get_core_state())    return false;
  if (a.get_frozen_state ()  != b.get_frozen_state())  return false;
  if (a.get_hole_state ()    != b.get_hole_state())    return false;

  if (a.get_is_it_HO ()              != b.get_is_it_HO())              return false;
  if (a.get_is_it_for_HF_gs ()       != b.get_is_it_for_HF_gs())       return false;
  if (a.get_is_it_natural_orbital () != b.get_is_it_natural_orbital()) return false;
  if (a.get_OCM_valence_state ()     != b.get_OCM_valence_state())     return false;

  if ((a.get_n () != b.get_n()) || (a.get_l () != b.get_l()) || (a.get_ij () != b.get_ij()) || (a.get_e_trunc () != b.get_e_trunc())) return false;

  if (inf_norm (a.get_k ()      - b.get_k())       > precision) return false;
  if (inf_norm (a.get_k_plus () - b.get_k_plus())  > precision) return false;
  if (inf_norm (a.get_k_minus ()- b.get_k_minus()) > precision) return false;
  
  if (inf_norm (a.get_w ()     - b.get_w())     > precision) return false;
  if (inf_norm (a.get_C0 ()    - b.get_C0())    > precision) return false;
  if (inf_norm (a.get_Cplus () - b.get_Cplus()) > precision) return false;

  if (inf_norm (a.get_C0_plus ()  - b.get_C0_plus())  > precision) return false;
  if (inf_norm (a.get_C0_minus () - b.get_C0_minus()) > precision) return false;

  return true;
}



bool operator != (const class nlj_struct &a , const class nlj_struct &b)
{
  return !(a == b);
}


// General comment
// ---------------
// Ordering of one-body states:
//
// 1) Frozen states
// 2) Hole but not frozen states
// 3) S matrix poles (not frozen, not holes)
// 4) Scattering states
//
// Then: among states of same character (frozen , hole , pole , scattering): ordering according to truncation energy 
// Then: among states of same truncation energy: ordering with respect to orbital angular momentum 
// Then: among states of same orbital angular momentum: ordering with respect to total angular momentum in reverse order (p3/2 , p1/2) , (d5/2 , d3/2) , ...
// Then: ordering with respect to the principal quantum number n

bool operator > (const class nlj_struct &a , const class nlj_struct &b)
{
  if (!a.get_frozen_state () && b.get_frozen_state ())
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (!a.get_hole_state () && b.get_hole_state ()))
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (a.get_hole_state () == b.get_hole_state ()) && (!a.get_S_matrix_pole () && b.get_S_matrix_pole ()))
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (a.get_hole_state () == b.get_hole_state ()) && (a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_e_trunc () > b.get_e_trunc ()))
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (a.get_hole_state () == b.get_hole_state ()) && (a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_e_trunc () == b.get_e_trunc ()) &&
      (a.get_l () > b.get_l ()))
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (a.get_hole_state () == b.get_hole_state ()) && (a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_e_trunc () == b.get_e_trunc ()) &&
      (a.get_l () == b.get_l ()) && (a.get_ij () < b.get_ij ()))
    return true;

  if ((a.get_frozen_state () == b.get_frozen_state ()) && (a.get_hole_state () == b.get_hole_state ()) && (a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_e_trunc () == b.get_e_trunc ()) &&
      (a.get_l () == b.get_l ()) && (a.get_ij () == b.get_ij ()) && (a.get_n () > b.get_n ()))
    return true;

  return false;
}



bool operator >= (const class nlj_struct &a , const class nlj_struct &b)
{
  return ((a > b) || (a == b));
}



bool operator < (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b > a);
}

bool operator <= (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b >= a);
}




ostream & operator << (ostream &os , const class nlj_struct &s)
{
  return os << s.get_n () << angular_state (s.get_l () , s.get_j ());
}






// Structure for (n,l,j,m) states
// ------------------------------
// This structure contain information concerning a (n,l,j,m) state.
// The (l,j,m) angular part is stored in an ljm_str structure (see above).
//
// S_matrix_pole: true if it is a pole state, false if not
// n,l,j,m: principal quantum number, orbital, total angular momenta and total angular momentum of the state
// bp: binary parity of the state (see observables_basic_functions.cpp for definition).
// shell_index: one-dimensional index of the nlj_struct shell of (n,l,j) quantum numbers in the array of nlj_struct shells_quantum_numbers of nucleons_data
// e_trunc: truncation energy in hbar omega unit. It does not have to be equal to 2n + l, it can be an arbitrary integer.
// m_max: maximal total angular projection of all the states of same type (proton or neutron), used to calculate integer indices for m


nljm_struct::nljm_struct () :
  S_matrix_pole (false) , 
  core_state (false) , 
  frozen_state (false) , 
  n (0) ,
  e_trunc (0) ,
  shell_index (OUT_OF_RANGE) ,
  bp (0) ,
  bin_phase_jm (0)
{}

nljm_struct::nljm_struct (
			  const int n_c , 
			  const int l_c , 
			  const double j_c , 
			  const double m_c , 
			  const bool S_matrix_pole_c , 
			  const bool core_state_c , 
			  const bool frozen_state_c , 
			  const int e_trunc_c , 
			  const unsigned short int shell_index_c , 
			  const double m_max)
{
  initialize (n_c , l_c , j_c , m_c , S_matrix_pole_c , core_state_c , frozen_state_c , e_trunc_c , shell_index_c , m_max);
}

void nljm_struct::initialize (
			      const int n_c , 
			      const int l_c , 
			      const double j_c , 
			      const double m_c , 
			      const bool S_matrix_pole_c , 
			      const bool core_state_c , 
			      const bool frozen_state_c , 
			      const int e_trunc_c , 
			      const unsigned short int shell_index_c , 
			      const double m_max)
{
  const int l = l_c;

  const double j = j_c;
  const double m = m_c;

  ljm_part.initialize (l , j , m , m_max);

  n = n_c;

  S_matrix_pole = S_matrix_pole_c;
  
  core_state = core_state_c;

  frozen_state = frozen_state_c;
  
  shell_index = shell_index_c;

  bp = binary_parity_from_orbital_angular_momentum (l);

  bin_phase_jm = make_uns_int (j - m) % 2;  

  e_trunc = e_trunc_c;
}






#ifdef UseMPI

MPI_Datatype MPI_Datatype_nljm_struct_create ()
{
  const unsigned int N_members = 9;

  const MPI_Datatype MPI_int           = MPI_helper::MPI_equivalent_type<int> ();
  const MPI_Datatype MPI_bool          = MPI_helper::MPI_equivalent_type<bool> ();
  const MPI_Datatype MPI_uns_short_int = MPI_helper::MPI_equivalent_type<unsigned short int> ();

  const MPI_Datatype MPI_ljm_struct = MPI_Datatype_ljm_struct_create ();

  MPI_Datatype types[N_members] = {MPI_ljm_struct ,
				   MPI_bool , MPI_bool , MPI_bool ,
				   MPI_int , MPI_int ,
				   MPI_uns_short_int ,  MPI_uns_short_int , MPI_uns_short_int};

  int block_lengths[N_members] = {1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1};

  class nljm_struct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0] = MPI_helper::Get_address (&A.ljm_part)      - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.S_matrix_pole) - A_address;
  address_displacements[2] = MPI_helper::Get_address (&A.core_state)    - A_address;
  address_displacements[3] = MPI_helper::Get_address (&A.frozen_state)  - A_address;
  address_displacements[4] = MPI_helper::Get_address (&A.n)             - A_address;
  address_displacements[5] = MPI_helper::Get_address (&A.e_trunc)       - A_address;
  address_displacements[6] = MPI_helper::Get_address (&A.shell_index)   - A_address;
  address_displacements[7] = MPI_helper::Get_address (&A.bp)            - A_address;
  address_displacements[8] = MPI_helper::Get_address (&A.bin_phase_jm)  - A_address;

  const MPI_Datatype MPI_nljm_struct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_nljm_struct;
}

#endif


double used_memory_calc (const class nljm_struct &T)
{
  return sizeof (T)/1000000.0;
}


// booleans checking if the angular part, i.e. a spin-coupled spherical harmonics Yljm is identical in two states given by structures above
// ----------------------------------------------------------------------------------------------------------------------------------------
// Integer indices are used for j and m.

bool same_Yljm (
		const class nljm_struct &phi0 , 
		const class nljm_struct &phi1)
{
  return ((phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()) && (phi0.get_im () == phi1.get_im ()));
}

bool same_Yljm (
		const class nljm_struct &phi0 , 
		const class ljm_struct &phi1)
{
  return ((phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()) && (phi0.get_im () == phi1.get_im ()));
}

bool same_Yljm (
		const class ljm_struct &phi0 , 
		const class nljm_struct &phi1)
{
  return ((phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()) && (phi0.get_im () == phi1.get_im ()));
}



// booleans checking if some or all quantum numbers (n,l,j) are the same in two states or shells given by structures above
// -----------------------------------------------------------------------------------------------------------------------
// Integer indices are used for j and m.

bool same_nlj (
	       const class nlj_struct &phi0 , 
	       const class nlj_struct &phi1)
{
  return ((phi0.get_n () == phi1.get_n ()) && (phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()));
}


bool same_lj (
	      const class nlj_struct &phi0 , 
	      const class nlj_struct &phi1)
{
  return ((phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()));
}



bool same_lj (
	      const class nljm_struct &phi0 , 
	      const class nljm_struct &phi1)
{
  return ((phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()));
}

bool same_nlj (
	       const class nljm_struct &phi0 , 
	       const class nljm_struct &phi1)
{
  return ((phi0.get_n () == phi1.get_n ()) && (phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()));
}

bool same_nljm (
		const class nljm_struct &phi0 , 
		const class nljm_struct &phi1)
{
  return ((phi0.get_n () == phi1.get_n ()) && (phi0.get_l () == phi1.get_l ()) && (phi0.get_ij () == phi1.get_ij ()) && (phi0.get_im () == phi1.get_im ()));
}


bool same_lj (
	      const class nljm_struct &phi , 
	      const class nlj_struct &shell)
{
  return ((phi.get_l () == shell.get_l ()) && (phi.get_ij () == shell.get_ij ()));
}


bool same_lj (
	      const class nlj_struct &shell , 
	      const class nljm_struct &phi)
{
  return ((phi.get_l () == shell.get_l ()) && (phi.get_ij () == shell.get_ij ()));
}

bool same_nlj (
	       const class nljm_struct &phi , 
	       const class nlj_struct &shell)
{
  return ((phi.get_n () == shell.get_n ()) && (phi.get_l () == shell.get_l ()) && (phi.get_ij () == shell.get_ij ()));
}


bool same_nlj (
	       const class nlj_struct &shell , 
	       const class nljm_struct &phi)
{
  return ((phi.get_n () == shell.get_n ()) && (phi.get_l () == shell.get_l ()) && (phi.get_ij () == shell.get_ij ()));
}


// 

ostream & operator << (ostream &os , const class nljm_struct &phi)
{
  return os << phi.get_n () << angular_state (phi.get_l () , phi.get_j ()) << "(" << make_int (2*phi.get_m ()) << "/2)";
}     



bool operator == (const class nljm_struct &a , const class nljm_struct &b)
{
  if ((a.get_l () != b.get_l ()) || (a.get_ij () != b.get_ij ()) || (a.get_im () != b.get_im ()) || (a.get_n () != b.get_n ())) return false;

  return true;
}

bool operator != (const class nljm_struct &a , const class nljm_struct &b)
{
  return !(a == b);
}

bool operator > (const class nljm_struct &a , const class nljm_struct &b)
{
  if (a.get_l () > b.get_l ())
    return true;
  else if ((a.get_l () == b.get_l ()) && (a.get_ij () < b.get_ij ()))
    return true;
  else if ((a.get_l () == b.get_l ()) && (a.get_ij () == b.get_ij ()) && (a.get_im () > b.get_im ()))
    return true;
  else if ((a.get_l () == b.get_l ()) && (a.get_ij () == b.get_ij ()) && (a.get_im () == b.get_im ()) && (a.get_n () > b.get_n ()))
    return true;
  else
    return false;
}

bool operator >= (const class nljm_struct &a , const class nljm_struct &b)
{
  return ((a > b) || (a == b));
}

bool operator < (const class nljm_struct &a , const class nljm_struct &b)
{
  return (b > a);
}

bool operator <= (const class nljm_struct &a , const class nljm_struct &b)
{
  return (b >= a);
}








// Structure for the surface delta interaction, of the form Vo . (a + b Psigma) \delta (r - R0) \delta (\vec{r} - \vec{r'})
// ------------------------------------------------------------------------------------------------------------------------
// Psigma is spin-exchange and R0 is the radius of the interaction.

delta_force::delta_force () :
  a (0.0) ,
  b (0.0) ,
  R0 (0.0) ,
  Vo (0.0)
{}

delta_force::delta_force (const double a_c ,  const double b_c ,  const double R0_c , const double Vo_c)
{
  initialize (a_c , b_c , R0_c , Vo_c);
}

void delta_force::initialize (const double a_c ,  const double b_c ,  const double R0_c , const double Vo_c)
{
  a = a_c;
  b = b_c;
  R0 = R0_c;
  Vo = Vo_c;
}

double used_memory_calc (const class delta_force &T)
{
  return sizeof (T)/1000000.0;
}




// Structure to store Clebsch-Gordan coefficients
// ----------------------------------------------
// All Clebsch-Gordan coefficients of the form <j0 m0 j1 m1 | J M> are stored, with j,|m| <= m_max, for j,m half integers.
// One does not store Clebsch-Gordan coefficients for which M != m0 + m1, as they are trivially equal to zero. For simplicity, however, no other restriction is made.
// One checks if one has a trivial zero in operator (). If it is not the case, one looks for the stored Clebsch-Gordan coefficient in the stored array.
// The array of Clebsch-Gordan coefficients is of the form T(ij0 , im0 , ij1 , im1 , J), with ij = j - 1/2 and im = m - m_max, consistenty with the nljm_str structure above. 
//
// One can also calculate Clebsch-Gordan coefficients of the form <j m Jab Mab | J M> , where j,m,J,M are half-integers and Jab, Mab are integers if all values are smaller than m_max in absolute value.

CG_str::CG_str () :
  m_max (0.0)
{}

CG_str::CG_str (const double m_max_c) :
  m_max (0.0)
{
  allocate_calc (m_max_c);
}

CG_str::CG_str (const class CG_str &X) :
  m_max (0.0)
{
  allocate_fill (X);
}

void CG_str::allocate_calc (const double m_max_c)
{
  m_max = m_max_c;

  if (make_int (2.0*m_max)%2 == 0) error_message_print_abort ("m_max has to be half-integer in CG_str::allocate_calc");
      
  const int Nj = make_int (m_max + 0.5);

  const int Nm = make_int (2.0*m_max) + 1;

  const int NJ = 2*Nj;

  CG_table.allocate (Nj , Nm , Nj , Nm , NJ);

  for (int ij0 = 0 ; ij0 < Nj ; ij0++)
    for (int im0 = 0 ; im0 < Nm ; im0++)
      for (int ij1 = 0 ; ij1 < Nj ; ij1++)
	for (int im1 = 0 ; im1 < Nm ; im1++)
	  for (int J = 0 ; J < NJ ; J++)
	    {
	      const double j0 = ij0 + 0.5 , m0 = im0 - m_max;
	      const double j1 = ij1 + 0.5 , m1 = im1 - m_max;
	      
	      const double M = m0 + m1;

	      CG_table(ij0 , im0 , ij1 , im1 , J) = Clebsch_Gordan (j0 , m0 , j1 , m1 , J , M);
	    }
}

void CG_str::allocate_fill (const class CG_str &X)
{
  m_max = X.m_max;

  CG_table.allocate_fill (X.CG_table);
}

void CG_str::deallocate ()
{
  CG_table.deallocate ();

  m_max = 0.0;
}


double CG_str::operator() (
			   const double j0 , 
			   const double m0 , 
			   const double j1 , 
			   const double m1 , 
			   const double J , 
			   const double M) const
{
  const int delta_m = make_int (m0 + m1 - M);
  
  if (delta_m != 0) return 0.0;
      
  if (make_int (j0 - abs (m0)) < 0) return 0.0;
  if (make_int (j1 - abs (m1)) < 0) return 0.0;
  if (make_int (J  - abs (M))  < 0) return 0.0;
      
  const int two_j0 = make_int (2*j0);
  const int two_j1 = make_int (2*j1);
  const int two_J  = make_int (2*J);

  const bool is_j0_half_integer = (two_j0%2 == 1);
  const bool is_j1_half_integer = (two_j1%2 == 1);
  const bool is_J_half_integer  = (two_J%2  == 1);
  
  if (is_j0_half_integer && is_j1_half_integer && !is_J_half_integer)
    {
      if ((abs (make_int (abs (m0) - m_max) > 0)) || (abs (make_int (abs (m1) - m_max) > 0)))
	error_message_print_abort ("m0 and m1 have to be smaller or equal to m_max in CG_str::operator()");
  
      const int ij0 = make_int (j0 - 0.5);
      const int ij1 = make_int (j1 - 0.5);
  
      const int im0 = make_int (m0 + m_max);
      const int im1 = make_int (m1 + m_max);
      
      const int J_int = make_int (J);

      const double CG = CG_table(ij0 , im0 , ij1 , im1 , J_int);
  
      return CG;
    }
  else if (is_j0_half_integer && !is_j1_half_integer && is_J_half_integer)
    {
      if ((abs (make_int (abs (m0) - m_max) > 0)) || (abs (make_int (abs (M) - m_max) > 0)))
	error_message_print_abort ("m0 and M have to be smaller or equal to m_max in CG_str::operator()");
      
      const int ij0 = make_int (j0 - 0.5);
      const int iJ  = make_int (J  - 0.5);
  
      const int im0_minus = make_int (-m0 + m_max);
      const int iM        = make_int ( M  + m_max);
      
      const int j1_int = make_int (j1);

      const double CG0 = CG_table(ij0 , im0_minus , iJ , iM , j1_int);
      
      const double CG = CG0*minus_one_pow (j1 + J + m0)*hat (J)/hat (j1);
      
      return CG;
    }
  else if (!is_j0_half_integer && is_j1_half_integer && is_J_half_integer)
    {
      if ((abs (make_int (abs (m1) - m_max) > 0)) || (abs (make_int (abs (M) - m_max) > 0)))
	error_message_print_abort ("m1 and M have to be smaller or equal to m_max in CG_str::operator()");
      
      const int ij1 = make_int (j1 - 0.5);
      const int iJ  = make_int (J  - 0.5);
  
      const int im1_minus = make_int (-m1 + m_max);
      const int iM        = make_int ( M  + m_max);
      
      const int j0_int = make_int (j0);

      const double CG0 = CG_table(ij1 , im1_minus , iJ , iM , j0_int);
      
      const double CG = -CG0*minus_one_pow (j1 - m1)*hat (J)/hat (j0);
      
      return CG;
    }
  else
    error_message_print_abort ("One cannot handle more than one integer angular momentum in general in CG_str::operator()");

  return NADA;
}

double used_memory_calc (const class CG_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.CG_table) - sizeof (T.CG_table)/1000000.0);
}



// Structure providing with the one-dimensional indices of an (n,l,j,m) state
// --------------------------------------------------------------------------
// The one-dimensional index of an (n,l,j,m) state can be obtained from operator (n,l,j,m) or operator (s,im), with s the index of the shell (n,l,j) and im = m - m_max.
// The array in which one-dimensional indices are stored used in operator (n,l,j,m) is an nljm_table (see GSM_nljm_indices_tables.hpp).
// It is a class array for operator (s,im).
// operator (n,l,j,m) takes much more time than operator (s,im), as the former makes uses of doubles and the latter of integers only.
//
// n,l,j,m: principal quantum number, orbital, total angular momenta and total angular momentum of the state
// m_max: maximal total angular projection of all the states of same type (proton or neutron), used to calculate integer indices for m

one_body_indices_str::one_body_indices_str () {}

one_body_indices_str::one_body_indices_str (
					    const int nmax ,
					    const int lmax ,
					    const unsigned int N_nlj ,
					    const double m_max)
{
  allocate (nmax , lmax , N_nlj , m_max);
}

one_body_indices_str::one_body_indices_str (const class one_body_indices_str &X)
{
  allocate_fill (X);
}

void one_body_indices_str::allocate (
				     const int nmax ,
				     const int lmax , 
				     const unsigned int N_nlj ,
				     const double m_max) 
{
  if (N_nlj == 0) return;

  const unsigned int Nm = make_uns_int (2.0*m_max + 1.0);

  states_indices_from_nljm.allocate (0.5 , nmax , lmax , m_max);
  
  states_indices_from_shell.allocate (N_nlj , Nm);

  states_indices_from_nljm  = OUT_OF_RANGE;
  states_indices_from_shell = OUT_OF_RANGE;
}



void one_body_indices_str::allocate_fill (const class one_body_indices_str &X) 
{
  states_indices_from_nljm.allocate_fill (X.states_indices_from_nljm);
  
  states_indices_from_shell.allocate_fill (X.states_indices_from_shell);
}



void one_body_indices_str::deallocate ()
{
  states_indices_from_nljm.deallocate ();
  
  states_indices_from_shell.deallocate ();
}





unsigned short int & one_body_indices_str::operator () (
							const unsigned int n , 
							const unsigned int l , 
							const double j , 
							const double m) const
{
  return states_indices_from_nljm(n , l , j , m);
} 



unsigned short int & one_body_indices_str::operator () (const unsigned int s , const int im) const
{
  return states_indices_from_shell(s , im);
} 

double used_memory_calc (const class one_body_indices_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.states_indices_from_nljm) + used_memory_calc (T.states_indices_from_shell) - (sizeof (T.states_indices_from_nljm) + sizeof (T.states_indices_from_shell))/1000000.0);
}





// Structure containing the quantum_numbers associated to a two-body matrix element and the value of two-body matrix element itself
// --------------------------------------------------------------------------------------------------------------------------------
// J, T: total angular momentum, total isospin, (pp/nn/pn) character of the two-body states
// TBME_space_int: integer value of the enumeration space_type giving (pp/nn/pn) character of the two-body states
//                 One uses an integer internally so that MPI transfer is done simply. The enumeration space_type is returned otherwise.
// n,l,j: arrays of principal quantum number, orbital and total angular momentum of the four considered shells


JT_coupled_TBME::JT_coupled_TBME () :
  TBME_space_int (0) ,
  J (0.0) ,
  T (0.0) ,
  Re_Vabcd (0.0) ,
  Im_Vabcd (0.0)
{
  for (unsigned int i = 0; i < 4 ; i++)
    {
      n[i] = 0;
      l[i] = 0;
      j[i] = 0.0;
    }
}

JT_coupled_TBME::JT_coupled_TBME (
				  const enum space_type TBME_space_c ,
				  const int J_c ,
				  const int T_c ,
				  const TYPE Vabcd_c ,
				  const int n_c[] ,
				  const int l_c[] ,
				  const double j_c[])
{
  initialize (TBME_space_c , J_c , T_c , Vabcd_c , n_c , l_c , j_c);
}

void JT_coupled_TBME::initialize (
				  const enum space_type TBME_space ,
				  const int J_c ,
				  const int T_c ,
				  const TYPE Vabcd_c , 
				  const int n_c[] ,
				  const int l_c[] ,
				  const double j_c[])
{
  TBME_space_int = make_int (TBME_space);

  J = J_c;
  T = T_c;
  
  Re_Vabcd = real_dc (Vabcd_c);
  Im_Vabcd = imag_dc (Vabcd_c);

  for (unsigned int i = 0; i < 4 ; i++)
    {
      n[i] = n_c[i];
      l[i] = l_c[i];
      j[i] = j_c[i];
    }
}

istream & operator >> (istream &is , class JT_coupled_TBME &s)
{
  double J = 0.0;
  double T = 0.0;

  int n[4];
  int l[4];

  double j[4];

  enum space_type TBME_space = NO_SPACE;

  TYPE Vabcd = 0.0;

  is >> J >> T;

  for (unsigned int i = 0 ; i < 4 ; i++)
    {
      string nlj_string;

      is >> nlj_string;

      n[i] = determine_n (nlj_string);
      l[i] = determine_l (nlj_string);
      j[i] = determine_j (nlj_string);

      check_partial_wave (NEUTRON , l[i] , j[i]);
    }

  is >> TBME_space;

  is >> Vabcd;

  s.initialize (TBME_space , J , T , Vabcd , n , l , j);

  return is;
}



#ifdef UseMPI

MPI_Datatype MPI_Datatype_JT_coupled_TBME_create ()
{
  const unsigned int N_members = 8;

  const MPI_Datatype MPI_int    = MPI_helper::MPI_equivalent_type<int> ();
  const MPI_Datatype MPI_double = MPI_helper::MPI_equivalent_type<double> ();

  MPI_Datatype types[N_members] = {MPI_int , MPI_int , MPI_int , MPI_double , MPI_double , MPI_int , MPI_int , MPI_double};

  int block_lengths[N_members] = {1 , 1 , 1 , 1 , 1 , 4 , 4 , 4};

  class JT_coupled_TBME A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0] = MPI_helper::Get_address (&A.TBME_space_int) - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.J)              - A_address;
  address_displacements[2] = MPI_helper::Get_address (&A.T)              - A_address;
  address_displacements[3] = MPI_helper::Get_address (&A.Re_Vabcd)       - A_address;
  address_displacements[4] = MPI_helper::Get_address (&A.Im_Vabcd)       - A_address;
  address_displacements[5] = MPI_helper::Get_address (&A.n)              - A_address;
  address_displacements[6] = MPI_helper::Get_address (&A.l)              - A_address;
  address_displacements[7] = MPI_helper::Get_address (&A.j)              - A_address;

  const MPI_Datatype MPI_JT_coupled_TBME = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_JT_coupled_TBME;
}

#endif


double used_memory_calc (const class JT_coupled_TBME &T)
{
  return sizeof (T)/1000000.0;
}





// Structure storing OBMEs of a given interaction (nuclear, kinetic, Coulomb)
// --------------------------------------------------------------------------
// One stores <out | inter | in> OBMEs for inter being nuclear, kinetic or Coulomb.
//
// OBMEs <out |inter | in> are non zero only if m_out = m_out. 
//
// coupled_OBME returns the <out |inter | in> OBME independently of the m quantum numbers of in and out. It takes as input the interaction type and shell indices (m is not taken into account).
//
// uncoupled_OBME takes into account m_in and m_out and returns zero if m_in != m_out. Otherwise, it returns <out | inter | in>, where m is absent. 
// It takes as input the interaction type and state indices (m is taken into account). Shell indices (stored) are determined from state indices for non-zero OBMEs.
// 
// The structure can be read from disk, copied to disk and transfered with MPI.

OBMEs_inter_set_str::OBMEs_inter_set_str () {}

OBMEs_inter_set_str::OBMEs_inter_set_str (const unsigned int N_nlj)
{
  allocate (N_nlj);
}

OBMEs_inter_set_str::OBMEs_inter_set_str (
					  const unsigned int N_nlj ,
					  const class array<class nljm_struct> &phi_table)
{
  allocate (N_nlj , phi_table);
}

OBMEs_inter_set_str::OBMEs_inter_set_str (const class OBMEs_inter_set_str &X)
{
  allocate_fill (X);
}

void OBMEs_inter_set_str::allocate (const unsigned int N_nlj)
{
  if (N_nlj == 0) return;

  inter_tab.allocate (N_nlj , N_nlj);
  
  nuclear_tab.allocate (N_nlj , N_nlj);
  kinetic_tab.allocate (N_nlj , N_nlj);
  Coulomb_tab.allocate (N_nlj , N_nlj);
  WS_grad_tab.allocate (N_nlj , N_nlj);
  hole_dc_tab.allocate (N_nlj , N_nlj);
}

void OBMEs_inter_set_str::allocate (
				    const unsigned int N_nlj ,
				    const class array<class nljm_struct> &phi_table)
{
  if (N_nlj == 0) return;

  const unsigned int N_nljm = phi_table.dimension (0);

  im_table.allocate (N_nljm);
  
  shells_indices.allocate (N_nljm);

  for (unsigned int state = 0 ; state < N_nljm ; state++)
    {
      const class nljm_struct &phi = phi_table(state);

      im_table(state) = phi.get_im ();
      
      shells_indices(state) = phi.get_shell_index ();
    }

  inter_tab.allocate (N_nlj , N_nlj);
  
  nuclear_tab.allocate (N_nlj , N_nlj);
  kinetic_tab.allocate (N_nlj , N_nlj);
  Coulomb_tab.allocate (N_nlj , N_nlj);
  WS_grad_tab.allocate (N_nlj , N_nlj);
  hole_dc_tab.allocate (N_nlj , N_nlj);
}



void OBMEs_inter_set_str::allocate_fill (const class OBMEs_inter_set_str &X)
{
  im_table.allocate_fill (X.im_table);
  
  shells_indices.allocate_fill (X.shells_indices);

  inter_tab.allocate_fill (X.inter_tab);

  nuclear_tab.allocate_fill (X.nuclear_tab);
  kinetic_tab.allocate_fill (X.kinetic_tab);
  Coulomb_tab.allocate_fill (X.Coulomb_tab);
  WS_grad_tab.allocate_fill (X.WS_grad_tab);
  hole_dc_tab.allocate_fill (X.hole_dc_tab);
}



void OBMEs_inter_set_str::deallocate ()
{
  im_table.deallocate ();
  
  shells_indices.deallocate ();

  inter_tab.deallocate ();

  nuclear_tab.deallocate ();
  kinetic_tab.deallocate ();
  Coulomb_tab.deallocate ();
  WS_grad_tab.deallocate ();
  hole_dc_tab.deallocate ();
}


class array<TYPE> & OBMEs_inter_set_str::operator () (const enum interaction_type Op_inter)
{
  switch (Op_inter)
    {
    case ONE_BODY_NUCLEAR    : return nuclear_tab;
    case ONE_BODY_KINETIC    : return kinetic_tab;
    case ONE_BODY_COULOMB    : return Coulomb_tab;     
    case WS_DERIVATIVE       : return WS_grad_tab;   
    case HOLE_DOUBLE_COUNTING: return hole_dc_tab;

    default:
      {
	const bool is_it_SU3 = (Op_inter == SU3_INTERACTION);
	
	const bool is_it_SDI = is_it_SDI_determine (Op_inter);

	const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (Op_inter);

	const bool is_it_Minnesota = is_it_Minnesota_determine (Op_inter);
		
	const bool is_it_fit = (Op_inter == FIT);

	const bool is_it_FHT = is_it_FHT_determine (Op_inter);
	const bool is_it_EFT = is_it_EFT_determine (Op_inter);	
	
	const bool is_Op_inter_Hamiltonian = (is_it_SU3 || is_it_SGI_MSGI || is_it_fit || is_it_FHT || is_it_EFT || is_it_Minnesota || is_it_SDI || (Op_inter == REALISTIC_INTERACTION));

	if (is_Op_inter_Hamiltonian)
	  return inter_tab;
	else
	  error_message_print_abort ("Interaction not recognized in OBMEs_inter_set_str::operator() (no const)");
      }
    }

  return inter_tab;
}

const class array<TYPE> & OBMEs_inter_set_str::operator () (const enum interaction_type Op_inter) const
{
  switch (Op_inter)
    {
    case ONE_BODY_NUCLEAR    : return nuclear_tab;
    case ONE_BODY_KINETIC    : return kinetic_tab;
    case ONE_BODY_COULOMB    : return Coulomb_tab;
    case WS_DERIVATIVE       : return WS_grad_tab; 
    case HOLE_DOUBLE_COUNTING: return hole_dc_tab;

    default:
      {
	const bool is_it_SU3 = (Op_inter == SU3_INTERACTION);
	
	const bool is_it_SDI = is_it_SDI_determine (Op_inter);

	const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (Op_inter);

	const bool is_it_Minnesota = is_it_Minnesota_determine (Op_inter);
		
	const bool is_it_fit = (Op_inter == FIT);

	const bool is_it_FHT = is_it_FHT_determine (Op_inter);
	const bool is_it_EFT = is_it_EFT_determine (Op_inter);
	
	const bool is_Op_inter_Hamiltonian = (is_it_SU3 || is_it_SGI_MSGI || is_it_fit || is_it_FHT || is_it_EFT || is_it_Minnesota || is_it_SDI || (Op_inter == REALISTIC_INTERACTION));

	if (is_Op_inter_Hamiltonian)
	  return inter_tab;
	else
	  error_message_print_abort ("Interaction not recognized in OBMEs_inter_set_str::operator() (const)");
      }
    }

  return inter_tab;
}




TYPE OBMEs_inter_set_str::coupled_OBME (
					const enum interaction_type Op_inter ,
					const unsigned int s_in ,
					const unsigned int s_out) const
{
  const class OBMEs_inter_set_str &OBMEs_inter_set = *this;  

  const class array<TYPE> &coupled_OBMEs = OBMEs_inter_set(Op_inter);

  const TYPE coupled_OBME_value = coupled_OBMEs(s_in , s_out);
  
  return coupled_OBME_value;
}




TYPE OBMEs_inter_set_str::uncoupled_OBME (
					  const enum interaction_type Op_inter ,
					  const unsigned int state_in ,
					  const unsigned int state_out) const
{
  const int im_in  = im_table(state_in);
  const int im_out = im_table(state_out);

  if (im_in != im_out) return 0.0;

  const class OBMEs_inter_set_str &OBMEs_inter_set = *this;
  
  const class array<TYPE> &coupled_OBMEs = OBMEs_inter_set(Op_inter);

  const unsigned int s_in  = shells_indices(state_in);
  const unsigned int s_out = shells_indices(state_out);

  const TYPE coupled_OBME_value = coupled_OBMEs(s_in , s_out);
  
  return coupled_OBME_value;
}





void OBMEs_inter_set_str::read_disk (const enum interaction_type inter , const string &debut_file_name)
{
  inter_tab.read_disk   (debut_file_name + "_" + make_string<enum interaction_type > (inter)                + ".dat");
  nuclear_tab.read_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_NUCLEAR)     + ".dat");
  kinetic_tab.read_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_KINETIC)     + ".dat");
  Coulomb_tab.read_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_COULOMB)     + ".dat");  
  WS_grad_tab.read_disk (debut_file_name + "_" + make_string<enum interaction_type > (WS_DERIVATIVE)        + ".dat");  
  hole_dc_tab.read_disk (debut_file_name + "_" + make_string<enum interaction_type > (HOLE_DOUBLE_COUNTING) + ".dat");
}

void OBMEs_inter_set_str::copy_disk (const enum interaction_type inter , const string &debut_file_name) const
{
  inter_tab.copy_disk   (debut_file_name + "_" + make_string<enum interaction_type > (inter)                + ".dat");
  nuclear_tab.copy_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_NUCLEAR)     + ".dat");
  kinetic_tab.copy_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_KINETIC)     + ".dat");
  Coulomb_tab.copy_disk (debut_file_name + "_" + make_string<enum interaction_type > (ONE_BODY_COULOMB)     + ".dat");  
  WS_grad_tab.copy_disk (debut_file_name + "_" + make_string<enum interaction_type > (WS_DERIVATIVE)        + ".dat");  
  hole_dc_tab.copy_disk (debut_file_name + "_" + make_string<enum interaction_type > (HOLE_DOUBLE_COUNTING) + ".dat");
}


#ifdef UseMPI

void OBMEs_inter_set_str::MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Send    (Recv_process , tag     , MPI_C);
  nuclear_tab.MPI_Send  (Recv_process , tag + 1 , MPI_C);
  kinetic_tab.MPI_Send  (Recv_process , tag + 2 , MPI_C);
  Coulomb_tab.MPI_Send  (Recv_process , tag + 3 , MPI_C);
  WS_grad_tab.MPI_Send  (Recv_process , tag + 4 , MPI_C);
  hole_dc_tab.MPI_Send  (Recv_process , tag + 5 , MPI_C);
}

void OBMEs_inter_set_str::MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Recv    (Send_process , tag     , MPI_C);
  nuclear_tab.MPI_Recv  (Send_process , tag + 1 , MPI_C);
  kinetic_tab.MPI_Recv  (Send_process , tag + 2 , MPI_C);
  Coulomb_tab.MPI_Recv  (Send_process , tag + 3 , MPI_C);
  WS_grad_tab.MPI_Recv  (Send_process , tag + 4 , MPI_C);
  hole_dc_tab.MPI_Recv  (Send_process , tag + 5 , MPI_C);
}

void OBMEs_inter_set_str::MPI_Sendrecv_replace  (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Sendrecv_replace    (Send_process , Recv_process , Send_tag     , Recv_tag     , MPI_C);
  nuclear_tab.MPI_Sendrecv_replace  (Send_process , Recv_process , Send_tag + 1 , Recv_tag + 1 , MPI_C);
  kinetic_tab.MPI_Sendrecv_replace  (Send_process , Recv_process , Send_tag + 2 , Recv_tag + 2 , MPI_C);
  Coulomb_tab.MPI_Sendrecv_replace  (Send_process , Recv_process , Send_tag + 3 , Recv_tag + 3 , MPI_C);
  WS_grad_tab.MPI_Sendrecv_replace  (Send_process , Recv_process , Send_tag + 4 , Recv_tag + 4 , MPI_C);
  hole_dc_tab.MPI_Sendrecv_replace  (Send_process , Recv_process , Send_tag + 5 , Recv_tag + 5 , MPI_C);
}

void OBMEs_inter_set_str::MPI_Bcast  (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Bcast    (Send_process , MPI_C);
  nuclear_tab.MPI_Bcast  (Send_process , MPI_C);
  kinetic_tab.MPI_Bcast  (Send_process , MPI_C);
  Coulomb_tab.MPI_Bcast  (Send_process , MPI_C);
  WS_grad_tab.MPI_Bcast  (Send_process , MPI_C);
  hole_dc_tab.MPI_Bcast  (Send_process , MPI_C);
}

void OBMEs_inter_set_str::MPI_Allgatherv  (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Allgatherv    (group_processes_number , MPI_C);
  nuclear_tab.MPI_Allgatherv  (group_processes_number , MPI_C);
  kinetic_tab.MPI_Allgatherv  (group_processes_number , MPI_C);
  Coulomb_tab.MPI_Allgatherv  (group_processes_number , MPI_C);
  WS_grad_tab.MPI_Allgatherv  (group_processes_number , MPI_C);
  hole_dc_tab.MPI_Allgatherv  (group_processes_number , MPI_C);
}

void OBMEs_inter_set_str::MPI_Reduce  (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Reduce    (op , Recv_process , process , MPI_C);
  nuclear_tab.MPI_Reduce  (op , Recv_process , process , MPI_C);
  kinetic_tab.MPI_Reduce  (op , Recv_process , process , MPI_C);
  Coulomb_tab.MPI_Reduce  (op , Recv_process , process , MPI_C);
  WS_grad_tab.MPI_Reduce  (op , Recv_process , process , MPI_C);
  hole_dc_tab.MPI_Reduce  (op , Recv_process , process , MPI_C);
}

void OBMEs_inter_set_str::MPI_Allreduce  (MPI_Op op , const MPI_Comm MPI_C)
{
  inter_tab.MPI_Allreduce    (op , MPI_C);
  nuclear_tab.MPI_Allreduce  (op , MPI_C);
  kinetic_tab.MPI_Allreduce  (op , MPI_C);
  Coulomb_tab.MPI_Allreduce  (op , MPI_C);
  WS_grad_tab.MPI_Allreduce  (op , MPI_C);
  hole_dc_tab.MPI_Allreduce  (op , MPI_C);
}

#endif


double used_memory_calc (const class OBMEs_inter_set_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.im_table) + used_memory_calc (T.shells_indices) + used_memory_calc (T.inter_tab) + used_memory_calc (T.nuclear_tab) + used_memory_calc (T.kinetic_tab) + used_memory_calc (T.Coulomb_tab) + used_memory_calc (T.WS_grad_tab) + used_memory_calc (T.hole_dc_tab) - (sizeof (T.im_table) + sizeof (T.shells_indices) + sizeof (T.inter_tab) + sizeof (T.nuclear_tab) + sizeof (T.kinetic_tab) + sizeof (T.Coulomb_tab) + sizeof (T.WS_grad_tab) + sizeof (T.hole_dc_tab))/1000000.0);
}









// Structure storing OBMEs of a given squared multipole ((r^L YL)^2, ...)
// ----------------------------------------------------------------------
// One stores OBMEs of the form  <out | Op | in>, with Op = (r^L . YL)^2 . 
//
// OBMEs <out |Op | in> are non zero only if m_out = m_out. 
//
// coupled_OBME returns the <out |inter | in> OBME independently of the m quantum numbers of in and out. It takes as input the interaction type and shell indices (m is not taken into account).
//
// uncoupled_OBME takes into account m_in and m_out and returns zero if m_in != m_out. Otherwise, it returns <out | inter | in>, where m is absent. 
// It takes as input the interaction type and state indices (m is taken into account). Shell indices (stored) are determined from state indices for non-zero OBMEs.
// 
// The structure can be read from disk, copied to disk and transfered with MPI.
//
// The arrays are stored as T(L , s_in , s_out). s_in and s_out are shells indices.

OBMEs_multipole_square_str::OBMEs_multipole_square_str () {}

OBMEs_multipole_square_str::OBMEs_multipole_square_str (const int lmax , const unsigned int N_nlj)
{
  allocate (lmax , N_nlj);
}

OBMEs_multipole_square_str::OBMEs_multipole_square_str (
							const int lmax ,
							const unsigned int N_nlj ,
							const class array<class nljm_struct> &phi_table)
{
  allocate (lmax , N_nlj , phi_table);
}

OBMEs_multipole_square_str::OBMEs_multipole_square_str (const class OBMEs_multipole_square_str &X)
{
  allocate_fill (X);
}

void OBMEs_multipole_square_str::allocate (const int lmax , const unsigned int N_nlj)
{
  if (N_nlj == 0) return;

  const int Lmax_global = 2*lmax + 1;

  rL_YL_square_tab.allocate (Lmax_global , N_nlj , N_nlj);
}

void OBMEs_multipole_square_str::allocate (
					   const int lmax ,
					   const unsigned int N_nlj ,
					   const class array<class nljm_struct> &phi_table)
{
  if (N_nlj == 0) return;

  const unsigned int N_nljm = phi_table.dimension (0);

  im_table.allocate (N_nljm);
  
  shells_indices.allocate (N_nljm);

  for (unsigned int state = 0 ; state < N_nljm ; state++)
    {
      const class nljm_struct &phi = phi_table(state);

      im_table(state) = phi.get_im ();
      
      shells_indices(state) = phi.get_shell_index ();
    }

  const int Lmax_global = 2*lmax + 1;

  rL_YL_square_tab.allocate (Lmax_global , N_nlj , N_nlj);
}



void OBMEs_multipole_square_str::allocate_fill (const class OBMEs_multipole_square_str &X)
{
  im_table.allocate_fill (X.im_table);
  
  shells_indices.allocate_fill (X.shells_indices);

  rL_YL_square_tab.allocate_fill (X.rL_YL_square_tab);
}



void OBMEs_multipole_square_str::deallocate ()
{
  im_table.deallocate ();
  
  shells_indices.deallocate ();

  rL_YL_square_tab.deallocate ();
}

void OBMEs_multipole_square_str::zero ()
{
  rL_YL_square_tab = 0.0;
}

void OBMEs_multipole_square_str::coupled_OBME_fill (
						    const int L ,
						    const unsigned int s_in ,
						    const unsigned int s_out ,
						    const TYPE coupled_OBME_value)
{
  rL_YL_square_tab(L , s_in , s_out) = coupled_OBME_value;
}


TYPE OBMEs_multipole_square_str::coupled_OBME (
					       const int L ,
					       const unsigned int s_in ,
					       const unsigned int s_out) const
{
  const TYPE coupled_OBME_value = rL_YL_square_tab(L , s_in , s_out);
      
  return coupled_OBME_value;  
}



TYPE OBMEs_multipole_square_str::uncoupled_OBME (
						 const int L ,
						 const unsigned int state_in ,
						 const unsigned int state_out) const
{    
  const int im_in  = im_table(state_in);
  const int im_out = im_table(state_out);

  if (im_in != im_out) return 0.0;
    
  const unsigned int s_in  = shells_indices(state_in);
  const unsigned int s_out = shells_indices(state_out);
  
  const TYPE coupled_OBME_value = rL_YL_square_tab(L , s_in , s_out);
      
  return coupled_OBME_value;
}





void OBMEs_multipole_square_str::read_disk (const string &debut_file_name)
{
  rL_YL_square_tab.read_disk (debut_file_name + "_" + make_string<enum operator_type > (MULTIPOLE_RL_YL) + ".dat");
}

void OBMEs_multipole_square_str::copy_disk (const string &debut_file_name) const
{
  rL_YL_square_tab.copy_disk (debut_file_name + "_" + make_string<enum operator_type > (MULTIPOLE_RL_YL) + ".dat");
}


#ifdef UseMPI

void OBMEs_multipole_square_str::MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Send (Recv_process , tag , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Recv (Send_process , tag , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Sendrecv_replace  (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Bcast  (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Bcast (Send_process , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Allgatherv  (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Allgatherv (group_processes_number , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Reduce  (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  rL_YL_square_tab.MPI_Reduce (op , Recv_process , process , MPI_C);
}

void OBMEs_multipole_square_str::MPI_Allreduce  (MPI_Op op , const MPI_Comm MPI_C)
{ 
  rL_YL_square_tab.MPI_Allreduce (op , MPI_C);
}

#endif


double used_memory_calc (const class OBMEs_multipole_square_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.im_table) + used_memory_calc (T.shells_indices) + used_memory_calc (T.rL_YL_square_tab) - (sizeof (T.im_table) + sizeof (T.shells_indices) + sizeof (T.rL_YL_square_tab))/1000000.0);
}






// Structure storing OBMEs of CM operators
// ---------------------------------------
// One stores <out | Op | in> OBMEs (rank 0) or <out || Op || in> OBMEs (rank 1) for the operator Op being L[CM], L+, L-, Lz, Hcm, P^2/2M, rms radii for protons and neutrons and A+[CM-HO].
//
// OBMEs <out | Op | in> are non zero only if m_out = m_in + M_rank(Op) and j_in, j_out can couple to rank(Op).
//
// coupled_OBME returns the <out | Op | in> OBME (rank 0) or <out || Op || in> OBME (rank 1) independently of the m quantum numbers of in and out. It takes as input the operator type and shell indices (m is not taken into account).
//
// uncoupled_OBME takes into account m_in and m_out and returns zero if m_out != m_in + M_rank(Op) or if j_in, j_out cannot couple to rank(Op).
// It takes as input the interaction type and state indices (m is taken into account).
// Shell indices (stored) are determined from state indices for non-zero OBMEs.
// Otherwise, for rank 0, it returns <out | inter | in>, where m is absent.
// For rank 1, <out || Op || in> is dereduced by multiplying it by a factor depending on a 3j and by a constant transforming an operator to its spherical tensor component (see observables_basic_functions.cpp), both being stored.
// 
// The structure can be read from disk, copied to disk and transfered with MPI.

OBMEs_CM_set_str::OBMEs_CM_set_str () {}

OBMEs_CM_set_str::OBMEs_CM_set_str (const unsigned int N_nlj)
{
  allocate (N_nlj);
}

OBMEs_CM_set_str::OBMEs_CM_set_str (
				    const unsigned int N_nlj ,
				    const class array<class nljm_struct> &phi_table)
{
  allocate (N_nlj , phi_table);
}

OBMEs_CM_set_str::OBMEs_CM_set_str (const class OBMEs_CM_set_str &X)
{
  allocate_fill (X);
}


void OBMEs_CM_set_str::allocate (const unsigned int N_nlj)
{
  if (N_nlj == 0) return;

  Hcm_tab.allocate (N_nlj , N_nlj);
  
  CM_kinetic_tab.allocate (N_nlj , N_nlj);

  L_reduced_tensor_tab.allocate (N_nlj , N_nlj);  

  A_dagger_CM_HO_reduced_tensor_tab.allocate (N_nlj , N_nlj);

  rms_radius_prot_tab.allocate (N_nlj , N_nlj);
  rms_radius_neut_tab.allocate (N_nlj , N_nlj);
}




void OBMEs_CM_set_str::allocate (
				 const unsigned int N_nlj ,
				 const class array<class nljm_struct> &phi_table)
{
  if (N_nlj == 0) return;

  const unsigned int N_nljm = phi_table.dimension (0);

  if (N_nljm > 0)
    {
      ij_table.allocate (N_nljm);
      im_table.allocate (N_nljm);
      
      shells_indices.allocate (N_nljm);

      class array<double> j_table(N_nljm);
      class array<double> m_table(N_nljm);

      for (unsigned int state = 0 ; state < N_nljm ; state++)
	{
	  const class nljm_struct &phi = phi_table(state);

	  j_table(state) = phi.get_j ();
	  m_table(state) = phi.get_m ();
	  
	  ij_table(state) = phi.get_ij ();
	  im_table(state) = phi.get_im ();

	  shells_indices(state) = phi.get_shell_index ();
	}

      const double j_max = j_table.max ();
      const double m_max = m_table.max ();

      const int j_number = make_uns_int (j_max + 0.5);

      const int m_number = 2*j_number;

      ME_dereducing_factors.allocate (3 , j_number , m_number , 3);
      
      ME_dereducing_factors = 0.0;

      for (int i_mu = 0 ; i_mu < 3 ; i_mu++)
	{
	  const int mu = i_mu - 1;

	  if (abs (mu) <= 1)
	    {
	      for (int ij_in = 0 ; ij_in < j_number ; ij_in++)
		{
		  const double j_in = ij_in + 0.5;

		  for (int im_in = 0 ; im_in < m_number ; im_in++)
		    {
		      const double m_in = im_in - m_max;
		      
		      const double m_out = m_in + mu;

		      if (rint (abs (m_in) - j_in) <= 0.0)
			{
			  for (int i_delta_j = 0 ; i_delta_j < 3 ; i_delta_j++)
			    {
			      const int delta_j = i_delta_j - 1;
			      
			      const double j_out = j_in + delta_j;

			      if ((rint (j_out - 0.5) >= 0.0) && (rint (abs (m_out) - j_out) <= 0.0))
				ME_dereducing_factors(i_mu , ij_in , im_in , i_delta_j) = ME_dereduced (1.0 , 1 , mu , j_in , m_in , j_out , m_out);
			    }}}}}}
    }

  Hcm_tab.allocate (N_nlj , N_nlj);
  
  CM_kinetic_tab.allocate (N_nlj , N_nlj);

  L_reduced_tensor_tab.allocate (N_nlj , N_nlj);  

  A_dagger_CM_HO_reduced_tensor_tab.allocate (N_nlj , N_nlj);

  rms_radius_prot_tab.allocate (N_nlj , N_nlj);
  rms_radius_neut_tab.allocate (N_nlj , N_nlj);
}



void OBMEs_CM_set_str::allocate_fill (const class OBMEs_CM_set_str &X)
{
  ij_table.allocate_fill (X.ij_table);
  im_table.allocate_fill (X.im_table);
  
  shells_indices.allocate_fill (X.shells_indices);

  ME_dereducing_factors.allocate_fill (X.ME_dereducing_factors);

  Hcm_tab.allocate_fill (X.Hcm_tab);

  CM_kinetic_tab.allocate_fill (X.CM_kinetic_tab);

  L_reduced_tensor_tab.allocate_fill (X.L_reduced_tensor_tab);

  A_dagger_CM_HO_reduced_tensor_tab.allocate_fill (X.A_dagger_CM_HO_reduced_tensor_tab);

  rms_radius_prot_tab.allocate_fill (X.rms_radius_prot_tab);
  rms_radius_neut_tab.allocate_fill (X.rms_radius_neut_tab);
}



void OBMEs_CM_set_str::deallocate ()
{
  ij_table.deallocate ();
  im_table.deallocate ();
  shells_indices.deallocate ();

  ME_dereducing_factors.deallocate ();

  Hcm_tab.deallocate ();
  CM_kinetic_tab.deallocate ();

  L_reduced_tensor_tab.deallocate ();
  A_dagger_CM_HO_reduced_tensor_tab.deallocate ();

  rms_radius_prot_tab.deallocate ();
  rms_radius_neut_tab.deallocate ();
}


class array<TYPE> & OBMEs_CM_set_str::operator () (const enum operator_type CM_op_inter)
{
  switch (CM_op_inter)
    {
    case HCM                          : return Hcm_tab;
    case CM_KINETIC                   : return CM_kinetic_tab;
    case L_REDUCED_TENSOR             : return L_reduced_tensor_tab;
    case A_DAGGER_CM_HO_REDUCED_TENSOR: return A_dagger_CM_HO_reduced_tensor_tab;
    case RMS_RADIUS_PROTON            : return rms_radius_prot_tab;
    case RMS_RADIUS_NEUTRON           : return rms_radius_neut_tab;
    default: abort_all ();
    }

  return Hcm_tab;
}

const class array<TYPE> & OBMEs_CM_set_str::operator () (const enum operator_type CM_op_inter) const
{
  switch (CM_op_inter)
    {
    case HCM                          : return Hcm_tab;
    case CM_KINETIC                   : return CM_kinetic_tab;
    case L_REDUCED_TENSOR             : return L_reduced_tensor_tab;
    case LPLUS                        : return L_reduced_tensor_tab;
    case LMINUS                       : return L_reduced_tensor_tab;
    case LZ                           : return L_reduced_tensor_tab;
    case A_DAGGER_CM_HO_REDUCED_TENSOR: return A_dagger_CM_HO_reduced_tensor_tab;
    case A_DAGGER_CM_HO_PLUS_ONE      : return A_dagger_CM_HO_reduced_tensor_tab;
    case A_DAGGER_CM_HO_MINUS_ONE     : return A_dagger_CM_HO_reduced_tensor_tab;
    case A_DAGGER_CM_HO_ZERO          : return A_dagger_CM_HO_reduced_tensor_tab;
    case RMS_RADIUS_PROTON            : return rms_radius_prot_tab;
    case RMS_RADIUS_NEUTRON           : return rms_radius_neut_tab;
    default: abort_all ();
    }

  return Hcm_tab;
}





TYPE OBMEs_CM_set_str::coupled_OBME (
				     const enum operator_type CM_op_inter ,
				     const unsigned int s_in ,
				     const unsigned int s_out) const
{
  const class OBMEs_CM_set_str &OBMEs_CM_set = *this;
  
  const class array<TYPE> &coupled_OBMEs = OBMEs_CM_set(CM_op_inter);

  const TYPE coupled_OBME_value = coupled_OBMEs(s_in , s_out); 
  
  return coupled_OBME_value;
}






TYPE OBMEs_CM_set_str::uncoupled_OBME (
				       const enum operator_type CM_op_inter ,
				       const unsigned int state_in ,
				       const unsigned int state_out) const
{
  const int mu = Op_standard_coordinate_determine (CM_op_inter);

  const int im_in  = im_table(state_in);
  const int im_out = im_table(state_out);

  if (im_in + mu != im_out) return 0.0;

  const int rank = Op_rank_determine (CM_op_inter);

  const int ij_in  = ij_table(state_in);
  const int ij_out = ij_table(state_out);

  const int delta_j = ij_out - ij_in;

  if (abs (delta_j) > rank) return 0.0;

  const class OBMEs_CM_set_str &OBMEs_CM_set = *this;
  
  const class array<TYPE> &coupled_OBMEs = OBMEs_CM_set(CM_op_inter);

  const unsigned int s_in  = shells_indices(state_in);
  const unsigned int s_out = shells_indices(state_out);
  
  const TYPE coupled_OBME = coupled_OBMEs(s_in , s_out);
  
  if (rank == 0)
    return coupled_OBME;
  else if (rank == 1)
    {
      const unsigned int i_mu = make_uns_int (mu + 1);

      const unsigned int i_delta_j = make_uns_int (delta_j + 1);

      const double Op_spherical_tensor_constant = Op_spherical_tensor_constant_determine (CM_op_inter);

      const double ME_dereducing_factor = ME_dereducing_factors(i_mu , ij_in , im_in , i_delta_j);

      const TYPE OBME_dereduced = Op_spherical_tensor_constant*ME_dereducing_factor*coupled_OBME;

      return OBME_dereduced;
    }
  else
    error_message_print_abort ("Rank of CM operator is 0 or 1 in OBMEs_CM_set_str::uncoupled_OBME");

  return NADA;
}






void OBMEs_CM_set_str::read_disk (const bool is_it_HO_expansion , const string &debut_file_name)
{
  const string CM_string = (is_it_HO_expansion) ? ("_HO_expansion") : ("_R_cut");

  Hcm_tab.read_disk                           (debut_file_name + "_" + make_string<enum operator_type > (HCM)                           + CM_string + ".dat");
  CM_kinetic_tab.read_disk                    (debut_file_name + "_" + make_string<enum operator_type > (CM_KINETIC)                    + CM_string + ".dat");
  L_reduced_tensor_tab.read_disk              (debut_file_name + "_" + make_string<enum operator_type > (L_REDUCED_TENSOR)              + CM_string + ".dat");
  A_dagger_CM_HO_reduced_tensor_tab.read_disk (debut_file_name + "_" + make_string<enum operator_type > (A_DAGGER_CM_HO_REDUCED_TENSOR) + CM_string + ".dat");
  rms_radius_prot_tab.read_disk               (debut_file_name + "_" + make_string<enum operator_type > (RMS_RADIUS_PROTON)             + CM_string + ".dat");
  rms_radius_neut_tab.read_disk               (debut_file_name + "_" + make_string<enum operator_type > (RMS_RADIUS_NEUTRON)            + CM_string + ".dat");
}

void OBMEs_CM_set_str::copy_disk (const bool is_it_HO_expansion , const string &debut_file_name) const
{
  const string CM_string = (is_it_HO_expansion) ? ("_HO_expansion") : ("_R_cut");

  Hcm_tab.copy_disk                           (debut_file_name + "_" + make_string<enum operator_type > (HCM)                           + CM_string + ".dat");
  CM_kinetic_tab.copy_disk                    (debut_file_name + "_" + make_string<enum operator_type > (CM_KINETIC)                    + CM_string + ".dat");
  L_reduced_tensor_tab.copy_disk              (debut_file_name + "_" + make_string<enum operator_type > (L_REDUCED_TENSOR)              + CM_string + ".dat");
  A_dagger_CM_HO_reduced_tensor_tab.copy_disk (debut_file_name + "_" + make_string<enum operator_type > (A_DAGGER_CM_HO_REDUCED_TENSOR) + CM_string + ".dat");
  rms_radius_prot_tab.copy_disk               (debut_file_name + "_" + make_string<enum operator_type > (RMS_RADIUS_PROTON)             + CM_string + ".dat");
  rms_radius_neut_tab.copy_disk               (debut_file_name + "_" + make_string<enum operator_type > (RMS_RADIUS_NEUTRON)            + CM_string + ".dat");
}

#ifdef UseMPI

void OBMEs_CM_set_str::MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Send                           (Recv_process , tag     , MPI_C);
  CM_kinetic_tab.MPI_Send                    (Recv_process , tag + 1 , MPI_C);
  L_reduced_tensor_tab.MPI_Send              (Recv_process , tag + 2 , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Send (Recv_process , tag + 3 , MPI_C);
  rms_radius_prot_tab.MPI_Send               (Recv_process , tag + 4 , MPI_C);
  rms_radius_neut_tab.MPI_Send               (Recv_process , tag + 5 , MPI_C);
}

void OBMEs_CM_set_str::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Sendrecv_replace                           (Send_process , Recv_process , Send_tag     , Recv_tag     , MPI_C);
  CM_kinetic_tab.MPI_Sendrecv_replace                    (Send_process , Recv_process , Send_tag + 1 , Recv_tag + 1 , MPI_C);
  L_reduced_tensor_tab.MPI_Sendrecv_replace              (Send_process , Recv_process , Send_tag + 2 , Recv_tag + 2 , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag + 3 , Recv_tag + 3 , MPI_C);
  rms_radius_prot_tab.MPI_Sendrecv_replace               (Send_process , Recv_process , Send_tag + 4 , Recv_tag + 4 , MPI_C);
  rms_radius_neut_tab.MPI_Sendrecv_replace               (Send_process , Recv_process , Send_tag + 5 , Recv_tag + 5 , MPI_C);
}

void OBMEs_CM_set_str::MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Recv                           (Send_process , tag     , MPI_C);
  CM_kinetic_tab.MPI_Recv                    (Send_process , tag + 1 , MPI_C);
  L_reduced_tensor_tab.MPI_Recv              (Send_process , tag + 2 , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Recv (Send_process , tag + 3 , MPI_C);
  rms_radius_prot_tab.MPI_Recv               (Send_process , tag + 4 , MPI_C);
  rms_radius_neut_tab.MPI_Recv               (Send_process , tag + 5 , MPI_C);
}

void OBMEs_CM_set_str::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Bcast                           (Send_process , MPI_C);
  CM_kinetic_tab.MPI_Bcast                    (Send_process , MPI_C);
  L_reduced_tensor_tab.MPI_Bcast              (Send_process , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Bcast (Send_process , MPI_C);
  rms_radius_prot_tab.MPI_Bcast               (Send_process , MPI_C);
  rms_radius_neut_tab.MPI_Bcast               (Send_process , MPI_C);
}

void OBMEs_CM_set_str::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Allgatherv                           (group_processes_number , MPI_C);
  CM_kinetic_tab.MPI_Allgatherv                    (group_processes_number , MPI_C);
  L_reduced_tensor_tab.MPI_Allgatherv              (group_processes_number , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Allgatherv (group_processes_number , MPI_C);
  rms_radius_prot_tab.MPI_Allgatherv               (group_processes_number , MPI_C);
  rms_radius_neut_tab.MPI_Allgatherv               (group_processes_number , MPI_C);
}

void OBMEs_CM_set_str::MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Reduce                           (op , Recv_process , process , MPI_C);
  CM_kinetic_tab.MPI_Reduce                    (op , Recv_process , process , MPI_C);
  L_reduced_tensor_tab.MPI_Reduce              (op , Recv_process , process , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Reduce (op , Recv_process , process , MPI_C);
  rms_radius_prot_tab.MPI_Reduce               (op , Recv_process , process , MPI_C);
  rms_radius_neut_tab.MPI_Reduce               (op , Recv_process , process , MPI_C);
}

void OBMEs_CM_set_str::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  Hcm_tab.MPI_Allreduce                           (op , MPI_C);
  CM_kinetic_tab.MPI_Allreduce                    (op , MPI_C);
  L_reduced_tensor_tab.MPI_Allreduce              (op , MPI_C);
  A_dagger_CM_HO_reduced_tensor_tab.MPI_Allreduce (op , MPI_C);
  rms_radius_prot_tab.MPI_Allreduce               (op , MPI_C);
  rms_radius_neut_tab.MPI_Allreduce               (op , MPI_C);
}

#endif


double used_memory_calc (const class OBMEs_CM_set_str &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;
  
  const double used_memory_allocated_arrays = used_memory_calc (T.im_table) + used_memory_calc (T.ij_table) + used_memory_calc (T.ME_dereducing_factors) + used_memory_calc (T.Hcm_tab) + used_memory_calc (T.CM_kinetic_tab) + used_memory_calc (T.L_reduced_tensor_tab) + used_memory_calc (T.A_dagger_CM_HO_reduced_tensor_tab) + used_memory_calc (T.rms_radius_prot_tab) + used_memory_calc (T.rms_radius_neut_tab) - (sizeof (T.im_table) + sizeof (T.ij_table) + sizeof (T.ME_dereducing_factors) + sizeof (T.Hcm_tab) + sizeof (T.CM_kinetic_tab) + sizeof (T.L_reduced_tensor_tab) + sizeof (T.A_dagger_CM_HO_reduced_tensor_tab) + sizeof (T.rms_radius_prot_tab) + sizeof (T.rms_radius_neut_tab))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
  
  return used_memory;
}
















// Structure storing reduced OBMEs of a multipole operator
// -------------------------------------------------------
// One stores <out || Op || in> OBMEs (rank L'), with Op = r^L . YL .
//
// coupled_OBME returns <out || Op || in> OBME (rank 1) independently of the m quantum numbers of in and out. It takes as input the operator type and shell indices (m is not taken into account).
//
// uncoupled_OBME takes into account m_in and m_out and returns zero if m_out != m_in + M_rank(Op) or if j_in, j_out cannot couple to rank(Op).
// It takes as input the operator type and state indices (m is taken into account).
// Shell indices (stored) are determined from state indices for non-zero OBMEs.
// <out || Op || in> is dereduced by multiplying it by a factor depending on a 3j (see Wigner_signs.cpp), being stored.
// 
// The structure can be read from disk, copied to disk and transfered with MPI.

OBMEs_multipole_reduced_str::OBMEs_multipole_reduced_str () {}

OBMEs_multipole_reduced_str::OBMEs_multipole_reduced_str (const int lmax , const unsigned int N_nlj)
{
  allocate (lmax , N_nlj);
}

OBMEs_multipole_reduced_str::OBMEs_multipole_reduced_str (const class OBMEs_multipole_reduced_str &X)
{
  allocate_fill (X);
}

void OBMEs_multipole_reduced_str::allocate (const int lmax , const unsigned int N_nlj)
{
  if (N_nlj == 0) return;

  const int Lmax_global = 2*lmax + 1;

  rL_YL_reduced_tab.allocate (Lmax_global , N_nlj , N_nlj);
}




void OBMEs_multipole_reduced_str::allocate_fill (const class OBMEs_multipole_reduced_str &X)
{
  rL_YL_reduced_tab.allocate_fill (X.rL_YL_reduced_tab);
}



void OBMEs_multipole_reduced_str::deallocate ()
{
  rL_YL_reduced_tab.deallocate ();
}


void OBMEs_multipole_reduced_str::zero ()
{
  rL_YL_reduced_tab = 0.0;
}


void OBMEs_multipole_reduced_str::reduced_OBME_fill (
						     const int L ,
						     const unsigned int s_in ,
						     const unsigned int s_out ,
						     const TYPE reduced_OBME_value)
{
  rL_YL_reduced_tab(L , s_in , s_out) = reduced_OBME_value;
}

TYPE OBMEs_multipole_reduced_str::reduced_OBME (
						const int L ,
						const unsigned int s_in ,
						const unsigned int s_out) const
{
  const TYPE reduced_OBME_value = rL_YL_reduced_tab(L , s_in , s_out);
      
  return reduced_OBME_value;
}


void OBMEs_multipole_reduced_str::read_disk (const string &debut_file_name)
{
  rL_YL_reduced_tab.read_disk (debut_file_name + "_" + make_string<enum operator_type > (MULTIPOLE_RL_YL) + ".dat");
}

void OBMEs_multipole_reduced_str::copy_disk (const string &debut_file_name) const
{
  rL_YL_reduced_tab.copy_disk (debut_file_name + "_" + make_string<enum operator_type > (MULTIPOLE_RL_YL) + ".dat");
}


#ifdef UseMPI

void OBMEs_multipole_reduced_str::MPI_Send  (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Send (Recv_process , tag , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Recv  (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Recv (Send_process , tag , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Sendrecv_replace  (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Bcast  (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Bcast (Send_process , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Allgatherv  (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Allgatherv (group_processes_number , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Reduce  (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  rL_YL_reduced_tab.MPI_Reduce (op , Recv_process , process , MPI_C);
}

void OBMEs_multipole_reduced_str::MPI_Allreduce  (MPI_Op op , const MPI_Comm MPI_C)
{ 
  rL_YL_reduced_tab.MPI_Allreduce (op , MPI_C);
}

#endif


double used_memory_calc (const class OBMEs_multipole_reduced_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.rL_YL_reduced_tab) - sizeof (T.rL_YL_reduced_tab)/1000000.0);
}










// Structure storing the two-body matrix elements (TBMEs) of a multipolar expansion
// --------------------------------------------------------------------------------
// TBMEs stored are equal to (4 Pi)/(2l + 1) <c d | Yl(1).Yl(2) | a b>_J, for j <= jmax and J <= 2 jmax, with jmax half-integer.
// They are not antisymmetrized.
// They are stored as angular_table(ij0 , ij1 , ij2 , ij3 , ll , J), with ij = j - 1/2, with ll <= 2 jmax.
// One does not check for trival zero values for storage but one does in operator ().
// Indeed, one must return 0 if ll > 2 jmax. One also checks for parity conservation  in operator (). Zero is returned if it is not conserved.

multipolar_expansion_str::multipolar_expansion_str () :
  jmax (0.0) , 
  two_jmax (0.0)
{}

multipolar_expansion_str::multipolar_expansion_str (const double jmax_c) :
  jmax (0.0) , 
  two_jmax (0.0)
{
  allocate_calc (jmax_c);
}

multipolar_expansion_str::multipolar_expansion_str (const class multipolar_expansion_str &X) :
  jmax (0.0) , 
  two_jmax (0.0)
{
  allocate_fill (X);
}

void multipolar_expansion_str::allocate_calc (const double jmax_c)
{
  jmax = jmax_c;

  two_jmax = make_int (2.0*jmax);

  const int Nj = make_int (jmax + 0.5);

  const int Nll = make_int (2.0*jmax) + 1;

  const int NJ = make_int (2.0*jmax) + 1;

  angular_table.allocate (Nj , Nj , Nj , Nj , Nll , NJ);

  angular_table = 0.0;

  for (int ij0 = 0 ; ij0 < Nj ; ij0++)
    {
      const double j0 = ij0 + 0.5;
      
      const int l0 = make_int (j0 + 0.5);

      for (int ij1 = 0 ; ij1 < Nj ; ij1++)
	{
	  const double j1 = ij1 + 0.5;
	  
	  const int l1 = make_int (j1 + 0.5);

	  const int Jmin_01 = abs (make_int (j0 - j1));
	  const int Jmax_01 = make_int (j0 + j1);

	  for (int ij2 = 0 ; ij2 < Nj ; ij2++)
	    {
	      const double j2 = ij2 + 0.5;
	      
	      const int l2_min = make_int (j2 - 0.5);
	      const int l2_max = make_int (j2 + 0.5);
	      
	      const int lmin_multipole_expansion_02 = abs (make_int (j0 - j2));
	      const int lmax_multipole_expansion_02 = make_int (j0 + j2);

	      for (int ij3 = 0 ; ij3 < Nj ; ij3++)
		{
		  const double j3 = ij3 + 0.5;
		  
		  const int l3_min = make_int (j3 - 0.5);
		  const int l3_max = make_int (j3 + 0.5);

		  const int Jmin_23 = abs (make_int (j2 - j3));
		  const int Jmax_23 = make_int (j2 + j3);
		  
		  const int Jmin = max (Jmin_01 , Jmin_23);
		  const int Jmax = min (Jmax_01 , Jmax_23);

		  const int lmin_multipole_expansion_13 = abs (make_int (j1 - j3));
		  const int lmax_multipole_expansion_13 = make_int (j1 + j3);
		  
		  const int lmin_multipole_expansion = max (lmin_multipole_expansion_02 , lmin_multipole_expansion_13);
		  const int lmax_multipole_expansion = min (lmax_multipole_expansion_02 , lmax_multipole_expansion_13);

		  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
		    {
		      const int l2 = ((l0 + l2_min + ll)%2 == 0) ? (l2_min) : (l2_max);
		      const int l3 = ((l1 + l3_min + ll)%2 == 0) ? (l3_min) : (l3_max);

		      for (int J = Jmin ; J <= Jmax ; J++) angular_table(ij0 , ij1 , ij2 , ij3 , ll , J) = TBME_Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , ll , J);
		    }
		}
	    }
	}
    }
}



void multipolar_expansion_str::allocate_fill (const class multipolar_expansion_str &X)
{
  jmax = X.jmax;
  
  two_jmax = X.two_jmax;

  angular_table.allocate_fill (X.angular_table);
}


void multipolar_expansion_str::deallocate ()
{
  angular_table.deallocate ();

  jmax = 0.0;
  
  two_jmax = 0.0;
}



double multipolar_expansion_str::operator() (
					     const int l0 , const double j0 , 
					     const int l1 , const double j1 , 
					     const int l2 , const double j2 , 
					     const int l3 , const double j3 , 
					     const int ll , 
					     const int J) const
{
  if (((l0 + ll + l2) % 2 != 0) || ((l1 + ll + l3) % 2 != 0)) return 0.0;
  
  if (ll > two_jmax) return 0.0;

  const int ij0 = make_int (j0 - 0.5) , ij1 = make_int (j1 - 0.5);
  const int ij2 = make_int (j2 - 0.5) , ij3 = make_int (j3 - 0.5);

  const double angular_ME = angular_table(ij0 , ij1 , ij2 , ij3 , ll , J);
  
  return angular_ME;
}





// Multipolar TBME in the MSGI interaction
// ---------------------------------------
// One sums over all multipoles in the MSGI interaction as the radial form factor for all multipoles is the same
// The summed angular TBME is calculated here.

double multipolar_expansion_str::angular_TBME_MSGI_J (
						      const int l0 , const double j0 , 
						      const int l1 , const double j1 , 
						      const int l2 , const double j2 , 
						      const int l3 , const double j3 , 
						      const int J) const
{
  const int lmin_multipole_expansion = max (abs (l0 - l2) , abs (l1 - l3));

  const int lmax_multipole_expansion = min (l0 + l2 , l1 + l3); 

  const class multipolar_expansion_str &multipolar_expansion = *this;

  double TBME = 0.0;

  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (((l0 + ll + l2) % 2 == 0) && ((l1 + ll + l3) % 2 == 0)) TBME += multipolar_expansion (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , ll , J);
    }

  return TBME;
}

double used_memory_calc (const class multipolar_expansion_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.angular_table) - sizeof (T.angular_table)/1000000.0);
}
















// Structure storing the two-body matrix elements (TBMEs) of the spin exchange Psigma
// ----------------------------------------------------------------------------------
// TBMEs stored are equal to <c d | Psigma | a b>_J, for j <= jmax and J <= 2 jmax, with jmax half-integer.
// They are not antisymmetrized.
// They are stored as angular_table(l0 , l1 , ij0 , ij1 , ij2 , ij3 , ll , J), with ij = 0,1 for j=l-1/2,l+1/2
// One does not check for trival zero values (besides l0=l2 and l1=l3) for storage but one does in operator ().
// Indeed, one must return 0 if l0 != l2 or l1 != l3., or f l0,j0 , l1,j2 , l2,j2 , l3,j3 do not couple to spin 1/2.
// One also checks for parity conservation in operator (). Zero is returned if it is not conserved.

Psigma_str::Psigma_str () :
  lmax (0) ,
  jmax (0.0)
{}


Psigma_str::Psigma_str (const int lmax_c) :
  lmax (0) ,
  jmax (0.0)
{
  allocate_calc (lmax_c);
}

Psigma_str::Psigma_str (const class Psigma_str &X) :
  lmax (0) ,
  jmax (0.0)
{
  allocate_fill (X);
}

void Psigma_str::allocate_calc (const int lmax_c)
{
  lmax = lmax_c;
  jmax = lmax + 0.5;

  const int NJ = make_int (2.0*jmax) + 1;

  angular_table.allocate (lmax + 1 , lmax + 1 , 2 , 2 , 2 , 2 , NJ);

  angular_table = 0.0;

  for (int l0 = 0 ; l0 <= lmax ; l0++)
    for (double j0 = (l0 == 0) ? (0.5) : (l0 - 0.5) ; rint (j0 - l0 - 0.5) <= 0.0 ; j0++)
      {
	const unsigned int ij0 = (l0 < j0) ? (0) : (1);

	const int l2 = l0;

	for (int l1 = 0 ; l1 <= lmax ; l1++)
	  for (double j1 = (l1 == 0) ? (0.5) : (l1 - 0.5) ; rint (j1 - l1 - 0.5) <= 0.0 ; j1++)
	    {
	      const unsigned int ij1 = (l1 < j1) ? (0) : (1);
	      
	      const int l3 = l1;

	      const int Jmin_01 = abs (make_int (j0 - j1));
	      const int Jmax_01 = make_int (j0 + j1);

	      for (double j2 = (l2 == 0) ? (0.5) : (l2 - 0.5) ; rint (j2 - l2 - 0.5) <= 0.0 ; j2++)
		{
		  const unsigned int ij2 = (l2 < j2) ? (0) : (1);

		  for (double j3 = (l3 == 0) ? (0.5) : (l3 - 0.5) ; rint (j3 - l3 - 0.5) <= 0.0 ; j3++)
		    {
		      const unsigned int ij3 = (l3 < j3) ? (0) : (1);

		      const int Jmin_23 = abs (make_int (j2 - j3));
		      const int Jmax_23 = make_int (j2 + j3);

		      const int Jmin = max (Jmin_01 , Jmin_23);
		      const int Jmax = min (Jmax_01 , Jmax_23);

		      for (int J = Jmin ; J <= Jmax ; J++)
			angular_table(l0 , l1 , ij0 , ij1 , ij2 , ij3 , J) = TBME_Psigma (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , J);
		    }
		}
	    }
      }
}



void Psigma_str::allocate_fill (const class Psigma_str &X)
{
  lmax = X.lmax;
  
  jmax = X.jmax;

  angular_table.allocate_fill (X.angular_table);
}



void Psigma_str::deallocate ()
{
  angular_table.deallocate ();

  lmax = 0;
  
  jmax = 0.0;
}



double Psigma_str::operator() (
			       const int l0 , const double j0 , 
			       const int l1 , const double j1 , 
			       const int l2 , const double j2 , 
			       const int l3 , const double j3 , 
			       const int J) const
{
  if ((l0 != l2) || (l1 != l3)) return 0.0;

  if ((make_int (j0 - abs (l0 - 0.5)) < 0) || (make_int (j0 - l0 - 0.5) > 0)) return 0.0;
  if ((make_int (j1 - abs (l1 - 0.5)) < 0) || (make_int (j1 - l1 - 0.5) > 0)) return 0.0;
  if ((make_int (j2 - abs (l2 - 0.5)) < 0) || (make_int (j2 - l2 - 0.5) > 0)) return 0.0;
  if ((make_int (j3 - abs (l3 - 0.5)) < 0) || (make_int (j3 - l3 - 0.5) > 0)) return 0.0;

  const unsigned int ij0 = (l0 < j0) ? (0) : (1) , ij1 = (l1 < j1) ? (0) : (1);
  const unsigned int ij2 = (l2 < j2) ? (0) : (1) , ij3 = (l3 < j3) ? (0) : (1);

  const double angular_ME = angular_table(l0 , l1 , ij0 , ij1 , ij2 , ij3 , J);
  
  return angular_ME;
}


double used_memory_calc (const class Psigma_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.angular_table) - sizeof (T.angular_table)/1000000.0);
}



// Structure storing the radial integrals occurring in the two-body matrix elements (TBMEs) of the SGI interaction
// ---------------------------------------------------------------------------------------------------------------
// There is one array for direct TBMEs and one array for exchange TBMEs.
// They are used for the calculation of HF/MSDHF potentials when the SGI interaction is used (see GSM_HF_potentials_common_SGI_part_common.cpp)

SGI_radial_tabs_str::SGI_radial_tabs_str () {}

SGI_radial_tabs_str::SGI_radial_tabs_str (
					  const class interaction_class &inter_data , 
					  const unsigned int N_nlj_res , 
					  const unsigned int N_bef_R_GL)
{
  allocate (inter_data , N_nlj_res , N_bef_R_GL);
}

SGI_radial_tabs_str::SGI_radial_tabs_str (const class SGI_radial_tabs_str &X)
{
  allocate_fill (X);
}  


void SGI_radial_tabs_str::allocate (
				    const class interaction_class &inter_data , 
				    const unsigned int N_nlj_res , 
				    const unsigned int N_bef_R_GL)
{
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  if (!is_it_SGI_determine (TBME_inter)) return;

  if (N_nlj_res != 0)
    {
      const int lmax_multipole_expansion = inter_data.get_lmax_multipole_expansion ();
      
      const int lmax_multipole_expansion_plus_one = lmax_multipole_expansion + 1;

      direct_tab.allocate   (lmax_multipole_expansion_plus_one , N_nlj_res , N_bef_R_GL);
      exchange_tab.allocate (lmax_multipole_expansion_plus_one , N_nlj_res , N_bef_R_GL);
    }
}

void SGI_radial_tabs_str::allocate_fill (const class SGI_radial_tabs_str &X)
{
  direct_tab.allocate_fill (X.direct_tab);
  
  exchange_tab.allocate_fill (X.exchange_tab);
}  


void SGI_radial_tabs_str::deallocate ()
{
  direct_tab.deallocate ();
  exchange_tab.deallocate ();
}



double used_memory_calc (const class SGI_radial_tabs_str &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.direct_tab) + used_memory_calc (T.exchange_tab) - (sizeof (T.direct_tab) + sizeof (T.exchange_tab))/1000000.0);
}
