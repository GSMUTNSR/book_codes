#include "../GSM_include/GSM_include_def_common.h"
		
// TYPE is double or complex
// -------------------------

// Array class type to store an array of class SD_1ph_data_str
// -----------------------------------------------------------
// class SD_1ph_data_str stores information related to the obtained Slater determinant after the action of a+_{alpha} (1p) or a_{alpha} (1h) on a Slater determinant.
// It contains the index of its associated class configuration_1ph_data_str, containing information on configurations and shells only, the integer index of the m projection of alpha,
// the index of the obtained Slater determinant for fixed M, parity, number of particles in the continuum, and M projection, and the phase coming out of the action of a+_{alpha} or a_{alpha}.
//
// In this array class type, one uniquely stores the existing class SD_1ph_data_str by knowing their number for each Slater determinant and summing dimensions.
// One adds "_c" to input variables in constructors and allocators if they copied to class members afterwards.
// The method is the following to allocate the array of class SD_1ph_data_str:
// _ one loops over all Slater determinants
// _ one loops over the intermediate parity BP_inter of the class SD_1ph_data_str
// _ one adds the number of class SD_1ph_data_str to the total number of SD_1ph_data_str
// _ one does the same for the array of sums of dimensions
// _ one allocates the array of class SD_1ph_data_str with its calculated dimension
//
// The internal index of the table storing all classes SD_1ph_data_str is a one-dimensional index ,
// calculated from the local index SD_1ph_index, where Slater determinant quantum numbers are fixed, to which a sum of dimensions is added.
// This is done in index_determine.
//
// One can access the table with operator (), where one puts all Slater determinant quantum numbers and the local index SD_1ph_index,
// or with operator [], where one puts directly the internal one-dimensional index of the stored array.
	       
array_of_SD_1ph_data::array_of_SD_1ph_data () {}
  
array_of_SD_1ph_data::array_of_SD_1ph_data (
					    const int n_scat_max , 
					    const class array<unsigned int> &dimensions_configuration_set , 
					    const int iM_max , 
					    const unsigned long int dimension_SD_total , 
					    const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set , 
					    const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
					    const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_1ph_data_table)
{
  allocate (n_scat_max , dimensions_configuration_set , iM_max , dimension_SD_total , dimensions_SD_set , sum_dimensions_SD_set , dimensions_SD_1ph_data_table);
}

array_of_SD_1ph_data::array_of_SD_1ph_data (const class array_of_SD_1ph_data &X)
{
  allocate_fill (X);
}

void array_of_SD_1ph_data::allocate (
				     const int n_scat_max , 
				     const class array<unsigned int> &dimensions_configuration_set , 
				     const int iM_max , 
				     const unsigned long int dimension_SD_total , 
				     const class array_BP_Nscat_iC<unsigned int> &dimensions_SD_set , 
				     const class array_BP_Nscat_iC<unsigned long int> &sum_dimensions_SD_set , 
				     const class array_BP_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_1ph_data_table)
{
  sum_dimensions_tab.allocate (dimension_SD_total , sum_dimensions_SD_set);

  unsigned int dimension_table = 0;
  
  unsigned int sum_dimensions_bef = 0;
  
  unsigned int dimension_bef = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int n_scat = 0 ; n_scat <= n_scat_max ; n_scat++)
      {
	const unsigned int dimensions_configuration_set_BP_n_scat = dimensions_configuration_set(BP , n_scat);

	for (unsigned int iC = 0 ; iC < dimensions_configuration_set_BP_n_scat ; iC++)
	  {	
	    const unsigned int dimension_SD_set_zero_index = dimensions_SD_set.index_determine (BP , n_scat , iC , 0);

	    for (int iM = 0 ; iM <= iM_max ; iM++)
	      {
		const unsigned int dimension_SD_set_index = dimension_SD_set_zero_index + iM;
		
		const unsigned int dimension_SD_set_BP_n_scat_iC_iM = dimensions_SD_set[dimension_SD_set_index];

		const unsigned long int dimensions_SD_1ph_data_debut_index = dimensions_SD_1ph_data_table.index_determine (BP , n_scat , iC , iM , 0);

		const unsigned long int sum_dimensions_debut_index = sum_dimensions_tab.index_determine (BP , n_scat , iC , iM , 0);

		for (unsigned int iSD = 0 ; iSD < dimension_SD_set_BP_n_scat_iC_iM ; iSD++)
		  {
		    const unsigned long int dimensions_SD_1ph_data_index = dimensions_SD_1ph_data_debut_index + iSD ;

		    const unsigned long int sum_dimensions_index = sum_dimensions_debut_index + iSD;

		    const unsigned int dimension = dimensions_SD_1ph_data_table[dimensions_SD_1ph_data_index];

		    unsigned int &sum_dimensions = sum_dimensions_tab[sum_dimensions_index];

		    dimension_table += dimension;

		    sum_dimensions = sum_dimensions_bef + dimension_bef;

		    dimension_bef = dimension;

		    sum_dimensions_bef = sum_dimensions;
		  }
	      }
	  }
      }

  table.allocate (dimension_table);
}






void array_of_SD_1ph_data::allocate_fill (const class array_of_SD_1ph_data &X)
{
  sum_dimensions_tab.allocate_fill (X.sum_dimensions_tab);

  table.allocate_fill (X.table);
}


void array_of_SD_1ph_data::deallocate ()
{
  sum_dimensions_tab.deallocate ();

  table.deallocate ();
}


bool array_of_SD_1ph_data::is_it_filled () const
{
  return table.is_it_filled ();
}





unsigned int array_of_SD_1ph_data::index_determine (
						    const unsigned int BP_out , 
						    const int n_scat_out , 
						    const unsigned int iC_out , 
						    const int iM_out , 
						    const unsigned int outSD_index , 
						    const unsigned int SD_1ph_data_index) const
{
  const unsigned int index = SD_1ph_data_index + sum_dimensions_tab(BP_out , n_scat_out , iC_out , iM_out , outSD_index);

  return index;
}





class SD_1ph_data_str & array_of_SD_1ph_data::operator () (
							   const unsigned int BP_out , 
							   const int n_scat_out , 
							   const unsigned int iC_out , 
							   const int iM_out , 
							   const unsigned int outSD_index , 
							   const unsigned int SD_1ph_data_index) const
{							 
  const unsigned int index = index_determine (BP_out , n_scat_out , iC_out , iM_out , outSD_index , SD_1ph_data_index);

  return table(index);
}



class SD_1ph_data_str & array_of_SD_1ph_data::operator [] (const unsigned int index) const
{
  return table(index);
}



unsigned long int array_of_SD_1ph_data::debut_index_good_im_determine (
								       const int im , 
								       const unsigned int dimension_SD_1ph_subtable , 
								       const unsigned long int SD_1ph_zero_index) const
{
  const class array_of_SD_1ph_data &SD_1ph_table = *this;

  const unsigned int dimension_SD_1ph_subtable_minus_one = dimension_SD_1ph_subtable - 1;

  const unsigned long int last_SD_1ph_index = SD_1ph_zero_index + dimension_SD_1ph_subtable_minus_one;
  
  unsigned long int SD_1ph_debut_index = SD_1ph_zero_index , SD_1ph_end_index = last_SD_1ph_index;

  const class SD_1ph_data_str &SD_1ph_debut = SD_1ph_table[SD_1ph_debut_index];
  
  const int im_debut = SD_1ph_debut.get_im ();
  
  if (im_debut == im) return SD_1ph_debut_index;

  while (SD_1ph_end_index - SD_1ph_debut_index > 1)
    {
      const unsigned long int SD_1ph_middle_index = SD_1ph_debut_index + (SD_1ph_end_index - SD_1ph_debut_index)/2;
      
      const class SD_1ph_data_str &SD_1ph_middle = SD_1ph_table[SD_1ph_middle_index];
      
      const int im_middle = SD_1ph_middle.get_im ();

      if (im <= im_middle)
	SD_1ph_end_index = SD_1ph_middle_index;
      else 
	SD_1ph_debut_index = SD_1ph_middle_index;
    }

  return SD_1ph_end_index;
}



unsigned long int array_of_SD_1ph_data::end_index_good_im_determine (
								     const int im , 
								     const unsigned int dimension_SD_1ph_subtable , 
								     const unsigned long int SD_1ph_zero_index) const
{
  const class array_of_SD_1ph_data &SD_1ph_table = *this;

  const unsigned int dimension_SD_1ph_subtable_minus_one = dimension_SD_1ph_subtable - 1;
  
  const unsigned long int last_SD_1ph_index = SD_1ph_zero_index + dimension_SD_1ph_subtable_minus_one;
  
  unsigned long int SD_1ph_debut_index = SD_1ph_zero_index ,  SD_1ph_end_index = last_SD_1ph_index;

  const class SD_1ph_data_str &SD_1ph_end = SD_1ph_table[SD_1ph_end_index];
  
  const int im_end = SD_1ph_end.get_im ();
  
  if (im_end == im) return SD_1ph_end_index;

  while (SD_1ph_end_index - SD_1ph_debut_index > 1)
    {
      const unsigned long int SD_1ph_middle_index = SD_1ph_debut_index + (SD_1ph_end_index - SD_1ph_debut_index)/2;
      
      const class SD_1ph_data_str &SD_1ph_middle = SD_1ph_table[SD_1ph_middle_index];
      
      const int im_middle = SD_1ph_middle.get_im ();

      if (im >= im_middle)
	SD_1ph_debut_index = SD_1ph_middle_index;
      else 
	SD_1ph_end_index = SD_1ph_middle_index;
    }

  return SD_1ph_debut_index;
}



double used_memory_calc (const class array_of_SD_1ph_data &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.sum_dimensions_tab) + used_memory_calc (T.table));
}
