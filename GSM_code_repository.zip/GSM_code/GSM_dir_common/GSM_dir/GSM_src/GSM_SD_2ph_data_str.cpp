#include "../GSM_include/GSM_include_def_common.h"


// TYPE is double or complex
// -------------------------

// Class SD_2ph_data_str
// ---------------------
// Class SD_2ph_data_str stores information related to the obtained SD after the action of a+_{alpha} a+_{beta} (2p) or a_{alpha} a_{beta} (2h) on a Slater determinant for fixed in and out configurations.
// It contains the index of 2p-2h configuration jump, i.e. the index of an array providing with information about the shells and configurations involved (no angular momentum projection)
// the angular momentum projections of alpha and beta + m_max so that they are integers, the index of SD after the jump and binary phase induced by a+/a operators.

SD_2ph_data_str::SD_2ph_data_str ()
  : C_2ph_table_index (0) ,
    im_left (0) ,  
    im_right (0) ,  
    SD_index (0) , 
    bin_phase (0)
{}

SD_2ph_data_str::SD_2ph_data_str (
				  const unsigned int C_2ph_table_index_c , 
				  const unsigned int im_left_c , 
				  const unsigned int im_right_c , 
				  const unsigned int SD_index_c , 
				  const unsigned int bin_phase_c)
{
  initialize (C_2ph_table_index_c , im_left_c , im_right_c , SD_index_c , bin_phase_c);
}

void SD_2ph_data_str::initialize (
				  const unsigned int C_2ph_table_index_c , 
				  const unsigned int im_left_c , 
				  const unsigned int im_right_c , 
				  const unsigned int SD_index_c , 
				  const unsigned int bin_phase_c)
{
  C_2ph_table_index = C_2ph_table_index_c;
  
  im_left = im_left_c;

  im_right = im_right_c;

  SD_index = SD_index_c;  

  bin_phase = bin_phase_c;
}

void SD_2ph_data_str::initialize (const class SD_2ph_data_str &X)
{
  C_2ph_table_index = X.C_2ph_table_index;

  im_left = X.im_left;

  im_right = X.im_right;

  SD_index = X.SD_index;  

  bin_phase = X.bin_phase; 
}

void SD_2ph_data_str::allocate_fill (const class SD_2ph_data_str &X)
{
  initialize (X);
}



double used_memory_calc (const class SD_2ph_data_str &T)
{
  return sizeof (T)/1000000.0;
}


