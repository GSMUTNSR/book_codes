#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Equivalent potentials calculated from splines
// ---------------------------------------------
// The non-local potential U(r,r') applied a wave function is written Ueq(r).u(r) + S(r), where Ueq(r) is the equivalent potential and S(r) the source.
//
// Ueq(r) = [1 - F(r)] \int U(r,r') u(r') dr' / u(r) and S(r) = F(r) \int U(r,r') u(r') dr', with F(r) a regularizing factor preventing from Ueq(r) to diverge if u(r) = 0, which is numerically non-zero only close to the zeroes of u(r).
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
//                  Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
//                  The ratio |u(r)|^2/|u'(r)|^2 prevents F(r) to be non zero when r -> +oo.
//                  Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The equivalent potential and source are calculated on the [0:2.R0] radial grid (before R), with R0 the radius of the SGI/MSGI interaction.
// They are splined to be calculated on the [0:R] radial grid with Gauss-Legendre and uniformly spaced radii.

void HF_potentials_common::SGI_MSGI_part_common::trivially_equivalent_potential_splines_calc (
											      const class spherical_state &shell , 
											      const class nlj_table<complex<double> > &Ueq_SGI_MSGI_tab_GL , 
											      const class nlj_table<complex<double> > &source_SGI_MSGI_tab_GL , 
											      class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform , 
											      class nlj_table<complex<double> > &source_tab_uniform , 
											      class nlj_table<complex<double> > &Ueq_finite_range_tab_GL , 
											      class nlj_table<complex<double> > &source_tab_GL)
{	
  const unsigned int N_bef_R_GL = shell.get_N_bef_R_GL ();
  
  class array<complex<double> > Ueq_finite_range_SGI_MSGI_tab_GL_copy(N_bef_R_GL);

  class array<complex<double> > source_SGI_MSGI_tab_GL_copy(N_bef_R_GL);

  const unsigned int N_bef_R_uniform = shell.get_N_bef_R_uniform ();
  
  const int n = shell.get_n ();
  const int l = shell.get_l ();
  
  const double j = shell.get_j ();

  const double R0 = shell.get_R0 ();

  const double two_R0 = 2.0*R0;

  const unsigned int zero_index_uniform = Ueq_finite_range_tab_uniform.index_determine (n , l , j , 0);
  
  const unsigned int zero_index_GL = Ueq_SGI_MSGI_tab_GL.index_determine (n , l , j , 0);

  const class array<double> &r_bef_R_tab_uniform = shell.get_r_bef_R_tab_uniform ();
  
  const class array<double> &r_bef_R_tab_GL  = shell.get_r_bef_R_tab_GL ();

  const class array<double> &r_bef_R_tab_GL_SGI_MSGI = shell.get_r_bef_R_tab_GL_SGI_MSGI ();
      
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int index_GL = zero_index_GL + i;

      Ueq_finite_range_SGI_MSGI_tab_GL_copy(i) = Ueq_SGI_MSGI_tab_GL[index_GL];
      
      source_SGI_MSGI_tab_GL_copy(i) = source_SGI_MSGI_tab_GL[index_GL];
    }

  const class splines_class<complex<double> > potential_splines(r_bef_R_tab_GL_SGI_MSGI , Ueq_finite_range_SGI_MSGI_tab_GL_copy , 0.0 , 0.0);
  const class splines_class<complex<double> > source_splines   (r_bef_R_tab_GL_SGI_MSGI , source_SGI_MSGI_tab_GL_copy           , 0.0 , 0.0);

  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++) 
    {
      const double r = r_bef_R_tab_uniform(i);

      if (r <= two_R0) 
	{
	  const unsigned int index_uniform = zero_index_uniform + i;

	  Ueq_finite_range_tab_uniform[index_uniform] += potential_splines(r);
	  
	  source_tab_uniform[index_uniform] += source_splines(r);
	}
    }

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);

      if (r <= two_R0) 
	{
	  const unsigned int index_GL = zero_index_GL + i;

	  Ueq_finite_range_tab_GL[index_GL] += potential_splines(r);

	  source_tab_GL[index_GL] += source_splines(r);
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::trivially_equivalent_potentials_splines_calc (const bool HO_diag , class HF_nucleons_data &HF_data)
{	
  const unsigned int N_nlj     = HF_data.get_N_nlj ();
  const unsigned int N_nlj_res = HF_data.get_N_nlj_res ();

  const class array<class spherical_state> &shells     = HF_data.get_shells ();
  const class array<class spherical_state> &shells_res = HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_qn = HF_data.get_shells_quantum_numbers ();

  const class nlj_table<complex<double> > &Ueq_SGI_MSGI_tab_GL     = HF_data.get_Ueq_SGI_MSGI_tab_GL ();
  const class nlj_table<complex<double> > &Ueq_SGI_MSGI_res_tab_GL = HF_data.get_Ueq_SGI_MSGI_res_tab_GL ();

  class nlj_table<complex<double> > &Ueq_finite_range_tab_uniform = HF_data.get_Ueq_finite_range_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_tab_GL  = HF_data.get_Ueq_finite_range_tab_GL ();

  class nlj_table<complex<double> > &Ueq_finite_range_res_tab_uniform = HF_data.get_Ueq_finite_range_res_tab_uniform ();
  class nlj_table<complex<double> > &Ueq_finite_range_res_tab_GL  = HF_data.get_Ueq_finite_range_res_tab_GL ();

  const class nlj_table<complex<double> > &source_SGI_MSGI_tab_GL = HF_data.get_source_SGI_MSGI_tab_GL ();
  const class nlj_table<complex<double> > &source_SGI_MSGI_res_tab_GL = HF_data.get_source_SGI_MSGI_res_tab_GL ();

  class nlj_table<complex<double> > &source_tab_uniform = HF_data.get_source_tab_uniform ();
  class nlj_table<complex<double> > &source_tab_GL  = HF_data.get_source_tab_GL ();

  class nlj_table<complex<double> > &source_res_tab_uniform = HF_data.get_source_res_tab_uniform ();
  class nlj_table<complex<double> > &source_res_tab_GL  = HF_data.get_source_res_tab_GL ();

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int s = 0 ; s < N_nlj_res ; s++)
    {
      const class spherical_state &shell_res = shells_res(s);
      
      if (shell_res.is_it_filled ())
	trivially_equivalent_potential_splines_calc (shell_res , Ueq_SGI_MSGI_res_tab_GL , source_SGI_MSGI_res_tab_GL , Ueq_finite_range_res_tab_uniform , source_res_tab_uniform , Ueq_finite_range_res_tab_GL , source_res_tab_GL);
    }

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class spherical_state &shell = shells(s);

      if (shell.is_it_filled ())
	{
	  const class nlj_struct &shell_qn = shells_qn(s);
	  
	  const bool is_it_HO = shell_qn.get_is_it_HO ();

	  const bool no_HO = (!is_it_HO) && (!HO_diag);
	  
	  const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

	  if (S_matrix_pole || ((s >= first_state) && (s <= last_state)))
	    {
	      if (S_matrix_pole || no_HO) trivially_equivalent_potential_splines_calc (shell , Ueq_SGI_MSGI_tab_GL , source_SGI_MSGI_tab_GL , Ueq_finite_range_tab_uniform , source_tab_uniform , Ueq_finite_range_tab_GL , source_tab_GL);
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::trivially_equivalent_potentials_splines_pm_calc (
												  const int pm ,
												  class HF_nucleons_data &HF_data)
{
  const unsigned int N_nlj = HF_data.get_N_nlj ();

  const class array<class spherical_state> &shells_pm = (pm == 1) ? (HF_data.get_shells_plus ()) : (HF_data.get_shells_minus ());

  const class nlj_table<complex<double> > &Ueq_SGI_MSGI_pm_tab_GL    = (pm == 1) ? (HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
  
  const class nlj_table<complex<double> > &source_SGI_MSGI_pm_tab_GL = (pm == 1) ? (HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (HF_data.get_source_SGI_MSGI_minus_tab_GL ());

  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_uniform = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_uniform ()) : (HF_data.get_Ueq_finite_range_minus_tab_uniform ());
  
  class nlj_table<complex<double> > &Ueq_finite_range_pm_tab_GL  = (pm == 1) ? (HF_data.get_Ueq_finite_range_plus_tab_GL ()) : (HF_data.get_Ueq_finite_range_minus_tab_GL ());
  
  class nlj_table<complex<double> > &source_pm_tab_uniform = (pm == 1) ? (HF_data.get_source_plus_tab_uniform ()) : (HF_data.get_source_minus_tab_uniform ());

  class nlj_table<complex<double> > &source_pm_tab_GL  = (pm == 1) ? (HF_data.get_source_plus_tab_GL ()) : (HF_data.get_source_minus_tab_GL ());

  const unsigned int first_state = basic_first_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int last_state = basic_last_index_determine_for_MPI (N_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class spherical_state &shell_pm = shells_pm(s);

      if (shell_pm.is_it_filled ())
	{
	  if ((s >= first_state) && (s <= last_state))
	    trivially_equivalent_potential_splines_calc (shell_pm , Ueq_SGI_MSGI_pm_tab_GL , source_SGI_MSGI_pm_tab_GL , Ueq_finite_range_pm_tab_uniform , source_pm_tab_uniform , Ueq_finite_range_pm_tab_GL , source_pm_tab_GL);
	}
    }
}







// Calculation of the direct and exchange parts of the HF potential
// ----------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation.
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction.
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp).
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// This routine loops over all proton and neutron states and occupied states and calls routines of the namespaces SGI_part_common and MSGI_part_common.

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_pp_part_calc (
												    const bool HO_diag , 
												    const class CG_str &CGs , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class interaction_class &inter_data_basis , 
												    const class SGI_radial_tabs_str &prot_radial_tabs , 
												    class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();
  
  const bool single_particle = prot_HF_data.get_single_particle ();
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot     = prot_HF_data.get_shells ();
  const class array<class spherical_state> &shells_res_prot = prot_HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_prot_qn     = prot_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_res_prot_qn = prot_HF_data.get_shells_quantum_numbers_res ();
  
  const class nlj_table<unsigned int> &Zval_nucleons_in_shell_tab = prot_HF_data.get_N_valence_nucleons_in_shell_tab ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot = shells_res_prot(sp_HF);
      
      if (shell_prot.is_it_filled ())
	{
	  const double jp = shell_prot.get_j ();
	  
	  const int lp = shell_prot.get_l ();

	  for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
	    {
	      const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);
	      
	      const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
	      const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

	      if (core_state_p_occ || hole_state_p_occ) continue;

	      const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);

	      const int np_occ = shell_prot_occ.get_n ();
	      const int lp_occ = shell_prot_occ.get_l ();

	      const double jp_occ = shell_prot_occ.get_j ();

	      const bool same_lj_all_protons = same_lj (lp , jp , lp_occ , jp_occ);
				
	      const unsigned int Zval_nucleons_in_shell_tab_occ = Zval_nucleons_in_shell_tab(np_occ , lp_occ , jp_occ);
	      
	      if (single_particle && same_lj_all_protons && (Zval_nucleons_in_shell_tab_occ == 1)) continue;
				
	      if (is_it_SGI) SGI_part_common::Up_pp_part_calc (true , false , NADA , sp_occ , shell_prot , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
	      
	      if (is_it_MSGI) MSGI_part_common::Up_pp_part_calc (true , false , NADA , shell_prot , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn_HF = shells_prot_qn(sp_HF);
      
      const bool is_it_HO = shell_prot_qn_HF.get_is_it_HO ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);
      
      const bool S_matrix_pole = shell_prot_qn_HF.get_S_matrix_pole ();

      const class spherical_state &shell_prot = shells_prot(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_prot.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      const double jp = shell_prot.get_j ();
	      
	      const int lp = shell_prot.get_l ();

	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);

		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);
		  
		  const int np_occ = shell_prot_occ.get_n ();
		  const int lp_occ = shell_prot_occ.get_l ();

		  const double jp_occ = shell_prot_occ.get_j ();

		  const bool same_lj_all_protons = same_lj (lp , jp , lp_occ , jp_occ);

		  const unsigned int Zval_nucleons_in_shell_tab_occ = Zval_nucleons_in_shell_tab(np_occ , lp_occ , jp_occ);
		  
		  if (single_particle && same_lj_all_protons && (Zval_nucleons_in_shell_tab_occ == 1)) continue;

		  if (is_it_SGI) SGI_part_common::Up_pp_part_calc (false , false , NADA , sp_occ , shell_prot , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
		  
		  if (is_it_MSGI) MSGI_part_common::Up_pp_part_calc (false , false , NADA , shell_prot , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_pn_part_calc (
												    const bool HO_diag , 
												    const class CG_str &CGs , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class interaction_class &inter_data_basis , 
												    const class SGI_radial_tabs_str &neut_radial_tabs , 
												    const class HF_nucleons_data &neut_HF_data , 
												    class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj     = prot_HF_data.get_N_nlj ();
  const unsigned int Np_nlj_res = prot_HF_data.get_N_nlj_res ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_prot = prot_HF_data.get_shells ();

  const class array<class spherical_state> &shells_res_prot = prot_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_res_neut = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_prot_qn     = prot_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_res_neut_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj_res ; sp_HF++)
    {
      const class spherical_state &shell_prot = shells_res_prot(sp_HF);
      
      if (shell_prot.is_it_filled ())
	{
	  for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
	    {
	      const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);
	      
	      const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
	      const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

	      if (core_state_n_occ || hole_state_n_occ) continue;

	      const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);

	      if (is_it_SGI) SGI_part_common::Up_pn_part_calc (true , false , NADA , sn_occ , shell_prot , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);
	      
	      if (is_it_MSGI) MSGI_part_common::Up_pn_part_calc (true , false , NADA , shell_prot , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data , prot_HF_data);
	    }
	}
    }

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class nlj_struct &shell_prot_qn_HF = shells_prot_qn(sp_HF);
      
      const bool is_it_HO = shell_prot_qn_HF.get_is_it_HO ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);
      
      const bool S_matrix_pole = shell_prot_qn_HF.get_S_matrix_pole ();

      const class spherical_state &shell_prot = shells_prot(sp_HF);

      if ((S_matrix_pole || no_HO) && shell_prot.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);
		  
		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);

		  if (is_it_SGI) SGI_part_common::Up_pn_part_calc (false , false , NADA , sn_occ , shell_prot , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);
		  
		  if (is_it_MSGI) MSGI_part_common::Up_pn_part_calc (false , false , NADA , shell_prot , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data , prot_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_nn_part_calc (
												    const bool HO_diag , 
												    const class CG_str &CGs , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class interaction_class &inter_data_basis , 
												    const class SGI_radial_tabs_str &neut_radial_tabs , 
												    class HF_nucleons_data &neut_HF_data)
{ 
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const bool single_particle = neut_HF_data.get_single_particle ();
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_neut     = neut_HF_data.get_shells ();
  const class array<class spherical_state> &shells_res_neut = neut_HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_neut_qn     = neut_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_res_neut_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  const class nlj_table<unsigned int> &Nval_nucleons_in_shell_tab = neut_HF_data.get_N_valence_nucleons_in_shell_tab ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut_res = shells_res_neut(sn_HF);
      
      if (shell_neut_res.is_it_filled ())
	{
	  const double jn = shell_neut_res.get_j ();
	  
	  const int ln = shell_neut_res.get_l ();
			
	  for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
	    {
	      const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);
	      
	      const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
	      const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

	      if (core_state_n_occ || hole_state_n_occ) continue;

	      const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);
	      
	      const int nn_occ = shell_neut_occ.get_n ();
	      const int ln_occ = shell_neut_occ.get_l ();

	      const double jn_occ = shell_neut_occ.get_j ();

	      const bool same_lj_all_neutrons = same_lj (ln , jn , ln_occ , jn_occ);

	      const unsigned int Nval_nucleons_in_shell_tab_occ = Nval_nucleons_in_shell_tab(nn_occ , ln_occ , jn_occ);

	      if (single_particle && same_lj_all_neutrons && (Nval_nucleons_in_shell_tab_occ == 1)) continue;

	      if (is_it_SGI) SGI_part_common::Un_nn_part_calc (true , false , NADA , sn_occ , shell_neut_res , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);
	      
	      if (is_it_MSGI) MSGI_part_common::Un_nn_part_calc (true , false , NADA , shell_neut_res , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn_HF = shells_neut_qn(sn_HF);
      
      const bool is_it_HO = shell_neut_qn_HF.get_is_it_HO ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);
      
      const bool S_matrix_pole = shell_neut_qn_HF.get_S_matrix_pole ();

      const class spherical_state &shell_neut = shells_neut(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_neut.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      const double jn = shell_neut.get_j ();
	      
	      const int ln = shell_neut.get_l ();

	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);
		  
		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);
		  
		  const int nn_occ = shell_neut_occ.get_n ();
		  const int ln_occ = shell_neut_occ.get_l ();

		  const double jn_occ = shell_neut_occ.get_j ();

		  const bool same_lj_all_neutrons = same_lj (ln , jn , ln_occ , jn_occ);

		  const unsigned int Nval_nucleons_in_shell_tab_occ = Nval_nucleons_in_shell_tab(nn_occ , ln_occ , jn_occ);
		  
		  if (single_particle && same_lj_all_neutrons && (Nval_nucleons_in_shell_tab_occ == 1)) continue;

		  if (is_it_SGI) SGI_part_common::Un_nn_part_calc (false , false , NADA , sn_occ , shell_neut , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

		  if (is_it_MSGI) MSGI_part_common::Un_nn_part_calc (false , false , NADA , shell_neut , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_pn_part_calc (
												    const bool HO_diag , 
												    const class CG_str &CGs , 
												    const class array<double> &Gaussian_table_GL , 
												    const class multipolar_expansion_str &multipolar_expansion , 
												    const class interaction_class &inter_data_basis , 
												    const class SGI_radial_tabs_str &prot_radial_tabs , 
												    const class HF_nucleons_data &prot_HF_data , 
												    class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj     = neut_HF_data.get_N_nlj ();
  const unsigned int Nn_nlj_res = neut_HF_data.get_N_nlj_res ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_neut = neut_HF_data.get_shells ();
  
  const class array<class spherical_state> &shells_res_prot = prot_HF_data.get_shells_res ();
  const class array<class spherical_state> &shells_res_neut = neut_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_neut_qn     = neut_HF_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_res_prot_qn = prot_HF_data.get_shells_quantum_numbers_res ();

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj_res ; sn_HF++)
    {
      const class spherical_state &shell_neut = shells_res_neut(sn_HF);
      
      if (shell_neut.is_it_filled ())
	{
	  for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
	    {
	      const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);
	      
	      const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
	      const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

	      if (core_state_p_occ || hole_state_p_occ) continue;

	      const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);

	      if (is_it_SGI) SGI_part_common::Un_pn_part_calc (true , false , NADA , sp_occ , shell_neut , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);
	      
	      if (is_it_MSGI) MSGI_part_common::Un_pn_part_calc (true , false , NADA , shell_neut , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data , neut_HF_data);
	    }
	}
    }

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class nlj_struct &shell_neut_qn_HF = shells_neut_qn(sn_HF);
      
      const bool is_it_HO = shell_neut_qn_HF.get_is_it_HO ();

      const bool no_HO = (!is_it_HO) && (!HO_diag);
      
      const bool S_matrix_pole = shell_neut_qn_HF.get_S_matrix_pole ();

      const class spherical_state &shell_neut = shells_neut(sn_HF);

      if ((S_matrix_pole || no_HO) && shell_neut.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);
		  
		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);

		  if (is_it_SGI) SGI_part_common::Un_pn_part_calc (false , false , NADA , sp_occ , shell_neut , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);
		  
		  if (is_it_MSGI) MSGI_part_common::Un_pn_part_calc (false , false , NADA , shell_neut , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data , neut_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
													      const int pm , 
													      const class CG_str &CGs , 
													      const class array<double> &Gaussian_table_GL , 
													      const class multipolar_expansion_str &multipolar_expansion , 
													      const class interaction_class &inter_data_basis , 
													      const class SGI_radial_tabs_str &prot_radial_tabs , 
													      class HF_nucleons_data &prot_HF_data)
{
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();

  const bool single_particle = prot_HF_data.get_single_particle ();
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_pm_prot = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());
  
  const class array<class spherical_state> &shells_res_prot = prot_HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_res_prot_qn = prot_HF_data.get_shells_quantum_numbers_res ();
  
  const class nlj_table<unsigned int> &Zval_nucleons_in_shell_tab = prot_HF_data.get_N_valence_nucleons_in_shell_tab ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_pm_prot = shells_pm_prot(sp_HF);
      
      if (shell_pm_prot.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      const double jp = shell_pm_prot.get_j ();
	      
	      const int lp = shell_pm_prot.get_l ();

	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);
		  
		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);
		  
		  const int np_occ = shell_prot_occ.get_n ();
		  const int lp_occ = shell_prot_occ.get_l ();

		  const double jp_occ = shell_prot_occ.get_j ();

		  const bool same_lj_all_protons = same_lj (lp , jp , lp_occ , jp_occ);

		  const unsigned int Zval_nucleons_in_shell_tab_occ = Zval_nucleons_in_shell_tab(np_occ , lp_occ , jp_occ);
		  
		  if (single_particle && same_lj_all_protons && (Zval_nucleons_in_shell_tab_occ == 1)) continue;

		  if (is_it_SGI) SGI_part_common::Up_pp_part_calc (false , true , pm , sp_occ , shell_pm_prot , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);

		  if (is_it_MSGI) MSGI_part_common::Up_pp_part_calc (false , true , pm , shell_pm_prot , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
													      const int pm , 
													      const class CG_str &CGs , 
													      const class array<double> &Gaussian_table_GL , 
													      const class multipolar_expansion_str &multipolar_expansion , 
													      const class interaction_class &inter_data_basis , 
													      const class SGI_radial_tabs_str &neut_radial_tabs , 
													      const class HF_nucleons_data &neut_HF_data , 
													      class HF_nucleons_data &prot_HF_data)
{ 
  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_pm_prot = (pm == 1) ? (prot_HF_data.get_shells_plus ()) : (prot_HF_data.get_shells_minus ());
  
  const class array<class spherical_state> &shells_res_neut = neut_HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_res_neut_qn = neut_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sp_HF_first = basic_first_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sp_HF_last = basic_last_index_determine_for_MPI (Np_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sp_HF = 0 ; sp_HF < Np_nlj ; sp_HF++)
    {
      const class spherical_state &shell_pm_prot = shells_pm_prot(sp_HF);
      
      if (shell_pm_prot.is_it_filled ())
	{
	  if ((sp_HF >= sp_HF_first) && (sp_HF <= sp_HF_last))
	    {
	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);
		  
		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();

		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);

		  if (is_it_SGI) SGI_part_common::Up_pn_part_calc (false , true , pm , sn_occ , shell_pm_prot , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);
		  
		  if (is_it_MSGI) MSGI_part_common::Up_pn_part_calc (false , true , pm , shell_pm_prot , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data , prot_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
													      const int pm , 
													      const class CG_str &CGs , 
													      const class array<double> &Gaussian_table_GL , 
													      const class multipolar_expansion_str &multipolar_expansion , 
													      const class interaction_class &inter_data_basis , 
													      const class SGI_radial_tabs_str &neut_radial_tabs , 
													      class HF_nucleons_data &neut_HF_data)
{ 
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const unsigned int Nn_shells_occ = neut_HF_data.get_Nshells_occ ();
  
  const bool single_particle = neut_HF_data.get_single_particle ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_pm_neut = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());
  
  const class array<class spherical_state> &shells_res_neut = neut_HF_data.get_shells_res ();
  
  const class array<class nlj_struct> &shells_res_neut_qn = neut_HF_data.get_shells_quantum_numbers_res ();
  
  const class nlj_table<unsigned int> &Nval_nucleons_in_shell_tab = neut_HF_data.get_N_valence_nucleons_in_shell_tab ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_pm_neut = shells_pm_neut(sn_HF);
      
      if (shell_pm_neut.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      const double jn = shell_pm_neut.get_j ();

	      const int ln = shell_pm_neut.get_l ();

	      for (unsigned int sn_occ = 0 ; sn_occ < Nn_shells_occ ; sn_occ++)
		{
		  const class nlj_struct &shell_qn_neut_occ = shells_res_neut_qn(sn_occ);

		  const bool core_state_n_occ = shell_qn_neut_occ.get_core_state ();
		  const bool hole_state_n_occ = shell_qn_neut_occ.get_hole_state ();
		  
		  if (core_state_n_occ || hole_state_n_occ) continue;

		  const class spherical_state &shell_neut_occ = shells_res_neut(sn_occ);
		  
		  const int nn_occ = shell_neut_occ.get_n ();
		  const int ln_occ = shell_neut_occ.get_l ();

		  const double jn_occ = shell_neut_occ.get_j ();

		  const bool same_lj_all_neutrons = same_lj (ln , jn , ln_occ , jn_occ);

		  const unsigned int Nval_nucleons_in_shell_tab_occ = Nval_nucleons_in_shell_tab(nn_occ , ln_occ , jn_occ);
		  
		  if (single_particle && same_lj_all_neutrons && (Nval_nucleons_in_shell_tab_occ == 1)) continue;

		  if (is_it_SGI) SGI_part_common::Un_nn_part_calc (false , true , pm , sn_occ , shell_pm_neut , shell_neut_occ , CGs , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

		  if (is_it_MSGI) MSGI_part_common::Un_nn_part_calc (false , true , pm , shell_pm_neut , shell_neut_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_HF_data);
		}
	    }
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
													      const int pm , 
													      const class CG_str &CGs , 
													      const class array<double> &Gaussian_table_GL , 
													      const class multipolar_expansion_str &multipolar_expansion , 
													      const class interaction_class &inter_data_basis , 
													      const class SGI_radial_tabs_str &prot_radial_tabs , 
													      const class HF_nucleons_data &prot_HF_data , 
													      class HF_nucleons_data &neut_HF_data)
{
  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  const unsigned int Np_shells_occ = prot_HF_data.get_Nshells_occ ();

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_SGI  = is_it_SGI_determine  (TBME_inter);
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);

  const class array<class spherical_state> &shells_pm_neut = (pm == 1) ? (neut_HF_data.get_shells_plus ()) : (neut_HF_data.get_shells_minus ());

  const class array<class spherical_state> &shells_res_prot = prot_HF_data.get_shells_res ();

  const class array<class nlj_struct> &shells_res_prot_qn = prot_HF_data.get_shells_quantum_numbers_res ();

  const unsigned int sn_HF_first = basic_first_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int sn_HF_last = basic_last_index_determine_for_MPI (Nn_nlj , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int sn_HF = 0 ; sn_HF < Nn_nlj ; sn_HF++)
    {
      const class spherical_state &shell_pm_neut = shells_pm_neut(sn_HF);
      
      if (shell_pm_neut.is_it_filled ())
	{
	  if ((sn_HF >= sn_HF_first) && (sn_HF <= sn_HF_last))
	    {
	      for (unsigned int sp_occ = 0 ; sp_occ < Np_shells_occ ; sp_occ++)
		{
		  const class nlj_struct &shell_qn_prot_occ = shells_res_prot_qn(sp_occ);
		  
		  const bool core_state_p_occ = shell_qn_prot_occ.get_core_state ();
		  const bool hole_state_p_occ = shell_qn_prot_occ.get_hole_state ();

		  if (core_state_p_occ || hole_state_p_occ) continue;

		  const class spherical_state &shell_prot_occ = shells_res_prot(sp_occ);

		  if (is_it_SGI) SGI_part_common::Un_pn_part_calc (false , true , pm , sp_occ , shell_pm_neut , shell_prot_occ , CGs , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);
		  
		  if (is_it_MSGI) MSGI_part_common::Un_pn_part_calc (false , true , pm , shell_pm_neut , shell_prot_occ , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_HF_data , neut_HF_data);
		}
	    }
	}
    }
}








// Calculation of the all HF equivalent potentials and sources
// -----------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for MSGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | \sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, for SGI, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . Vl'_SGI(r , 2R0-r) . u_occ^2(2R0-r)
// U_HF(exc)(r) = \sum_{J, s_occ ,l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ, l'} coupling_constant(Pi,J) . weight . <l j l_occ j_occ | 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . Vl'_SGI(r , 2R0-r) . u_occ(r) . u(2R0-r) u_occ(2R0-r) . F(r)
//
// weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation.
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction.
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see GSM_TBME_MSGI.cpp).
// Vl'_SGI(r) is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// R0 is the radius of the SGI/MSGI interaction.
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// One sums over all Vpp, Vnn or Vpn interaction two-body matrix elements, according to the number of valence protons and neutrons. 
// HF equivalent potentials and sources are then splined to be calculated on the [0:R] radial grid with Gauss-Legendre and uniformly spaced radii, with R the cimplex scaling rotation point,
// as they are initially calculated in the [0:2.R0] radial grid, with R0 the radius of the SGI/MSGI interaction.

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_calc (
											    const bool HO_diag , 
											    const class CG_str &CGs , 
											    const class array<double> &Gaussian_table_GL , 
											    const class multipolar_expansion_str &multipolar_expansion , 
											    const class interaction_class &inter_data_basis , 
											    const class SGI_radial_tabs_str &prot_radial_tabs , 
											    const class SGI_radial_tabs_str &neut_radial_tabs , 
											    const class HF_nucleons_data &neut_HF_data , 
											    class HF_nucleons_data &prot_HF_data)
{
  const enum particle_type particle = prot_HF_data.get_particle ();
  
  if (particle != PROTON) abort_all ();

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if (Zval >= 2) prot_trivially_equivalent_potentials_pp_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);

  if ((Zval >= 1) && (Nval >= 1)) prot_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);

  trivially_equivalent_potentials_splines_calc (HO_diag , prot_HF_data);
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_calc (
											    const bool HO_diag , 
											    const class CG_str &CGs , 
											    const class array<double> &Gaussian_table_GL , 
											    const class multipolar_expansion_str &multipolar_expansion , 
											    const class interaction_class &inter_data_basis , 
											    const class SGI_radial_tabs_str &prot_radial_tabs , 
											    const class SGI_radial_tabs_str &neut_radial_tabs , 
											    const class HF_nucleons_data &prot_HF_data , 
											    class HF_nucleons_data &neut_HF_data)
{
  const enum particle_type particle = neut_HF_data.get_particle ();
  
  if (particle != NEUTRON) abort_all ();

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if (Nval >= 2) neut_trivially_equivalent_potentials_nn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

  if ((Zval >= 1) && (Nval >= 1)) neut_trivially_equivalent_potentials_pn_part_calc (HO_diag , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);

  trivially_equivalent_potentials_splines_calc (HO_diag , neut_HF_data);
}

void HF_potentials_common::SGI_MSGI_part_common::prot_trivially_equivalent_potentials_shells_pm_calc (
												      const int pm , 
												      const class CG_str &CGs , 
												      const class array<double> &Gaussian_table_GL , 
												      const class multipolar_expansion_str &multipolar_expansion , 
												      const class interaction_class &inter_data_basis , 
												      const class SGI_radial_tabs_str &prot_radial_tabs , 
												      const class SGI_radial_tabs_str &neut_radial_tabs , 
												      const class HF_nucleons_data &neut_HF_data , 
												      class HF_nucleons_data &prot_HF_data)
{
  const enum particle_type particle = prot_HF_data.get_particle ();
  
  if (particle != PROTON) return;

  const unsigned int Np_nlj = prot_HF_data.get_N_nlj ();

  if (Np_nlj == 0) return;

  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if (Zval >= 2) prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data);
  
  if ((Zval >= 1) && (Nval >= 1)) prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data , prot_HF_data);

  trivially_equivalent_potentials_splines_pm_calc (pm , prot_HF_data);
}

void HF_potentials_common::SGI_MSGI_part_common::neut_trivially_equivalent_potentials_shells_pm_calc (
												      const int pm ,
												      const class CG_str &CGs , 
												      const class array<double> &Gaussian_table_GL , 
												      const class multipolar_expansion_str &multipolar_expansion , 
												      const class interaction_class &inter_data_basis , 
												      const class SGI_radial_tabs_str &prot_radial_tabs , 
												      const class SGI_radial_tabs_str &neut_radial_tabs , 
												      const class HF_nucleons_data &prot_HF_data , 
												      class HF_nucleons_data &neut_HF_data)
{
  const enum particle_type particle = neut_HF_data.get_particle ();

  if (particle != NEUTRON) return;

  const unsigned int Nn_nlj = neut_HF_data.get_N_nlj ();

  if (Nn_nlj == 0) return;

  const int Zval = prot_HF_data.get_N_valence_nucleons_basis ();
  const int Nval = neut_HF_data.get_N_valence_nucleons_basis ();

  if (Nval >= 2) neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , neut_radial_tabs , neut_HF_data);

  if ((Zval >= 1) && (Nval >= 1)) neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (pm , CGs , Gaussian_table_GL , multipolar_expansion , inter_data_basis , prot_radial_tabs , prot_HF_data , neut_HF_data);

  trivially_equivalent_potentials_splines_pm_calc (pm , neut_HF_data);
}





