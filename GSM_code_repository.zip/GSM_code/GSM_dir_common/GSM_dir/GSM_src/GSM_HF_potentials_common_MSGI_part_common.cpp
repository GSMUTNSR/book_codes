#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------


// Calculation of the Gaussian form factor entering the MSGI interaction
// ---------------------------------------------------------------------
// The MSGI interaction is a separable interaction which reads exp (-(r/mu)^2) . F(2.R0 - r , r), with mu its interaction length, R0 its radius and F(r) a Fermi function.
// It is calculated here for the HF potential.

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Gaussian_table_GL_calc (
											   const class interaction_class &inter_data_basis , 
											   class array<double> &Gaussian_table_GL)
{
  const unsigned int N_bef_R_GL = Gaussian_table_GL.dimension (0);
  
  const double R0 = inter_data_basis.get_R0 ();

  const double two_R0 = 2.0*R0;

  const double mu = inter_data_basis.get_mu ();

  const double two_R0_minus_one = two_R0 - 1.0;
  
  class array<double> r_bef_R_tab(N_bef_R_GL);
  class array<double> w_bef_R_tab(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , two_R0 , r_bef_R_tab , w_bef_R_tab);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double r = r_bef_R_tab(i);

      const double r_minus_R0_over_mu = (r - R0)/mu;

      Gaussian_table_GL(i) = exp (-r_minus_R0_over_mu*r_minus_R0_over_mu)*Fermi_like_function (two_R0_minus_one , 0.25 , r);
    }
}








// Calculation of the direct and exchange parts of the HF potential taking into account one occupied state for the proton-proton, neutron-neutron and proton-neutron parts of the interaction
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction,
//
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see Gaussian_table_GL_calc),
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.
// 
// Real and imaginary parts of intermediate products entering the HF potential are separated to simplify calculations.

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_dir_pp_part_calc (
											const int J , 
											const class spherical_state &shell_p , 
											const class spherical_state &shell_p_occ , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL)
{
  const double jp = shell_p.get_j ();
  const double jp_occ = shell_p_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  const class array<double> &w_bef_R_tab_GL = shell_p.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfp_occ_bef_R_tab_GL = shell_p_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  double radial_integral_weight = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_weight += real (wfp_occ_bef_R_tab_GL(i)*wfp_occ_bef_R_tab_GL(i)*weight)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (lp , jp , lp_occ , jp_occ , lp , jp , lp_occ , jp_occ , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  const double coupling_constant_angular_TBME_radial_integral_weight = coupling_constant*angular_TBME*radial_integral_weight;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Up_eq_MSGI_tab_GL(np , lp , jp , i) += coupling_constant_angular_TBME_radial_integral_weight*Gaussian_table_GL(i);
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_dir_pn_part_calc (
											const int J , 
											const class spherical_state &shell_p , 
											const class spherical_state &shell_n_occ , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL)
{
  const double jp = shell_p.get_j ();
  
  const double jn_occ = shell_n_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  const class array<double> &w_bef_R_tab_GL = shell_p.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfn_occ_bef_R_tab_GL = shell_n_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  double radial_integral_weight = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_weight += real (wfn_occ_bef_R_tab_GL(i)*wfn_occ_bef_R_tab_GL(i)*weight)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (lp , jp , ln_occ , jn_occ , lp , jp , ln_occ , jn_occ , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , true , false);

  const double coupling_constant_angular_TBME_radial_integral_weight = coupling_constant*angular_TBME*radial_integral_weight;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Up_eq_MSGI_tab_GL(np , lp , jp , i) += coupling_constant_angular_TBME_radial_integral_weight*Gaussian_table_GL(i);
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_dir_nn_part_calc (
											const int J , 
											const class spherical_state &shell_n , 
											const class spherical_state &shell_n_occ , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL)
{
  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();

  const class array<double> &w_bef_R_tab_GL = shell_n.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfn_occ_bef_R_tab_GL = shell_n_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  double radial_integral_weight = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_weight += real (wfn_occ_bef_R_tab_GL(i)*wfn_occ_bef_R_tab_GL(i)*weight)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J(ln , jn , ln_occ , jn_occ , ln , jn , ln_occ , jn_occ , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  const double coupling_constant_angular_TBME_radial_integral_weight = coupling_constant*angular_TBME*radial_integral_weight;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Un_eq_MSGI_tab_GL(nn , ln , jn , i) += coupling_constant_angular_TBME_radial_integral_weight*Gaussian_table_GL(i);
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_dir_pn_part_calc (
											const int J , 
											const class spherical_state &shell_n , 
											const class spherical_state &shell_p_occ , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL)
{
  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();
  
  const class array<double> &w_bef_R_tab_GL = shell_n.get_w_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfp_occ_bef_R_tab_GL = shell_p_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  double radial_integral_weight = 0.0;
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral_weight += real (wfp_occ_bef_R_tab_GL(i)*wfp_occ_bef_R_tab_GL(i)*weight)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (ln , jn , lp_occ , jp_occ , ln , jn , lp_occ , jp_occ , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , true , false);

  const double coupling_constant_angular_TBME_radial_integral_weight = coupling_constant*angular_TBME*radial_integral_weight;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Un_eq_MSGI_tab_GL(nn , ln , jn , i) += coupling_constant_angular_TBME_radial_integral_weight*Gaussian_table_GL(i);
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_exc_pp_part_calc (
											const int J , 
											const class spherical_state &shell_p , 
											const class spherical_state &shell_p_occ , 
											const double Ueq_regularizor , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL , 
											class nlj_table<complex<double> > &source_p_tab_GL)
{ 
  const double jp = shell_p.get_j ();
  const double jp_occ = shell_p_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  const class array<double> &r_bef_R_tab_GL = shell_p.get_r_bef_R_tab_GL_SGI_MSGI ();
  const class array<double> &w_bef_R_tab_GL = shell_p.get_w_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_p = shell_p.get_C0 ();

  const class array<complex<double> > &wfp_occ_bef_R_tab_GL = shell_p_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfp_bef_R_tab_GL = shell_p.get_wf_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<complex<double> > &dwfp_bef_R_tab_GL = shell_p.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral_weight_re = 0.0;
  complex<double> radial_integral_weight_im = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> product_Op_weight_wfp = (Gaussian_table_GL(i)*w_bef_R_tab_GL(i))*wfp_bef_R_tab_GL(i);

      const complex<double> wfp_occ_weight = wfp_occ_bef_R_tab_GL(i)*weight;

      radial_integral_weight_re += product_Op_weight_wfp*real (wfp_occ_weight);
      radial_integral_weight_im += product_Op_weight_wfp*imag (wfp_occ_weight);
    }

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + lp_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (lp , jp , lp_occ , jp_occ , lp_occ , jp_occ , lp , jp , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  const double strength_angular_TBME = coupling_constant*angular_TBME;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> wfp_occ_r = wfp_occ_bef_R_tab_GL(i);

      const double Re_wfp_occ_r = real (wfp_occ_r);
      const double Im_wfp_occ_r = imag (wfp_occ_r);

      const complex<double> I_exc_r = strength_angular_TBME*Gaussian_table_GL(i)*(radial_integral_weight_re*Re_wfp_occ_r - radial_integral_weight_im*Im_wfp_occ_r);

      const double r = r_bef_R_tab_GL(i);
      
      const complex<double> C0_p_pow_r_lp_plus_one = C0_p*pow (r , lp+1);

      const complex<double> wfp_r = wfp_bef_R_tab_GL(i);

      const complex<double> dwfp_r = dwfp_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfp_r)/norm (dwfp_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_p_pow_r_lp_plus_one/wfp_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Up_eq_MSGI_tab_GL(np , lp , jp , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfp_r;
      
      source_p_tab_GL(np , lp , jp , i) -= I_exc_r_pole_removal_factor;
    }
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_exc_pn_part_calc (
											const int J ,
											const class spherical_state &shell_p , 
											const class spherical_state &shell_n_occ , 
											const double Ueq_regularizor , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL , 
											class nlj_table<complex<double> > &source_p_tab_GL)
{ 
  const double jp = shell_p.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int np = shell_p.get_n ();
  const int lp = shell_p.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_p.get_N_bef_R_GL ();
  
  const class array<double> &r_bef_R_tab_GL = shell_p.get_r_bef_R_tab_GL_SGI_MSGI ();
  const class array<double> &w_bef_R_tab_GL = shell_p.get_w_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_p = shell_p.get_C0 ();

  const class array<complex<double> > &wfn_occ_bef_R_tab_GL = shell_n_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfp_bef_R_tab_GL = shell_p.get_wf_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<complex<double> > &dwfp_bef_R_tab_GL = shell_p.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral_weight_re = 0.0;
  complex<double> radial_integral_weight_im = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> product_Op_weight_wfp = (Gaussian_table_GL(i)*w_bef_R_tab_GL(i))*wfp_bef_R_tab_GL(i);

      const complex<double> wfn_occ_weight = wfn_occ_bef_R_tab_GL(i)*weight;

      radial_integral_weight_re += product_Op_weight_wfp*real (wfn_occ_weight);
      radial_integral_weight_im += product_Op_weight_wfp*imag (wfn_occ_weight);
    }

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (lp + ln_occ);
  
  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (lp , jp , ln_occ , jn_occ , ln_occ , jn_occ , lp , jp , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

  const double strength_angular_TBME = coupling_constant*angular_TBME;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> wfn_occ_r = wfn_occ_bef_R_tab_GL(i);

      const double Re_wfn_occ_r = real (wfn_occ_r);
      const double Im_wfn_occ_r = imag (wfn_occ_r);

      const complex<double> I_exc_r = strength_angular_TBME*Gaussian_table_GL(i)*(radial_integral_weight_re*Re_wfn_occ_r - radial_integral_weight_im*Im_wfn_occ_r);

      const double r = r_bef_R_tab_GL(i);
      
      const complex<double> C0_p_pow_r_lp_plus_one = C0_p*pow (r , lp + 1);
      
      const complex<double> wfp_r = wfp_bef_R_tab_GL(i);

      const complex<double> dwfp_r = dwfp_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfp_r)/norm (dwfp_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_p_pow_r_lp_plus_one/wfp_r - 1.0))));
      
      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Up_eq_MSGI_tab_GL(np , lp , jp , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfp_r;

      source_p_tab_GL(np , lp , jp , i) -= I_exc_r_pole_removal_factor;
    }
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_exc_nn_part_calc (
											const int J , 
											const class spherical_state &shell_n , 
											const class spherical_state &shell_n_occ , 
											const double Ueq_regularizor , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL , 
											class nlj_table<complex<double> > &source_n_tab_GL)
{ 
  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();

  const class array<double> &r_bef_R_tab_GL = shell_n.get_r_bef_R_tab_GL_SGI_MSGI ();
  const class array<double> &w_bef_R_tab_GL = shell_n.get_w_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_n = shell_n.get_C0 ();

  const class array<complex<double> > &wfn_occ_bef_R_tab_GL = shell_n_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfn_bef_R_tab_GL = shell_n.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &dwfn_bef_R_tab_GL = shell_n.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral_weight_re = 0.0;
  complex<double> radial_integral_weight_im = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> product_Op_weight_wfn = (Gaussian_table_GL(i)*w_bef_R_tab_GL(i))*wfn_bef_R_tab_GL(i);

      const complex<double> wfn_occ_weight = wfn_occ_bef_R_tab_GL(i)*weight;

      radial_integral_weight_re += product_Op_weight_wfn*real (wfn_occ_weight);
      radial_integral_weight_im += product_Op_weight_wfn*imag (wfn_occ_weight);
    }

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + ln_occ);
  
  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (ln , jn , ln_occ , jn_occ , ln_occ , jn_occ , ln , jn , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , false);

  const double strength_angular_TBME = coupling_constant*angular_TBME;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> wfn_occ_r = wfn_occ_bef_R_tab_GL(i);
      
      const double Re_wfn_occ_r = real (wfn_occ_r);
      const double Im_wfn_occ_r = imag (wfn_occ_r);

      const complex<double> I_exc_r = strength_angular_TBME*Gaussian_table_GL(i)*(radial_integral_weight_re*Re_wfn_occ_r - radial_integral_weight_im*Im_wfn_occ_r);

      const double r = r_bef_R_tab_GL(i);
      
      const complex<double> C0_n_pow_r_ln_plus_one = C0_n*pow (r , ln+1);

      const complex<double> wfn_r = wfn_bef_R_tab_GL(i);

      const complex<double> dwfn_r = dwfn_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfn_r)/norm (dwfn_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_n_pow_r_ln_plus_one/wfn_r - 1.0))));

      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Un_eq_MSGI_tab_GL(nn , ln , jn , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfn_r;

      source_n_tab_GL(nn , ln , jn , i) -= I_exc_r_pole_removal_factor;
    }	
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_exc_pn_part_calc (
											const int J , 
											const class spherical_state &shell_n , 
											const class spherical_state &shell_p_occ , 
											const double Ueq_regularizor , 
											const class interaction_class &inter_data_basis , 
											const complex<double> &weight , 
											const class array<double> &Gaussian_table_GL , 
											const class multipolar_expansion_str &multipolar_expansion , 
											class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL , 
											class nlj_table<complex<double> > &source_n_tab_GL)
{ 
  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const int nn = shell_n.get_n ();
  const int ln = shell_n.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const unsigned int N_bef_R_GL = shell_n.get_N_bef_R_GL ();

  const class array<double> &r_bef_R_tab_GL = shell_n.get_r_bef_R_tab_GL_SGI_MSGI ();
  const class array<double> &w_bef_R_tab_GL = shell_n.get_w_bef_R_tab_GL_SGI_MSGI ();

  const complex<double> C0_n = shell_n.get_C0 ();

  const class array<complex<double> > &wfp_occ_bef_R_tab_GL = shell_p_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wfn_bef_R_tab_GL = shell_n.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &dwfn_bef_R_tab_GL = shell_n.get_dwf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral_weight_re = 0.0;
  complex<double> radial_integral_weight_im = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> product_Op_weight_wfn = (Gaussian_table_GL(i)*w_bef_R_tab_GL(i))*wfn_bef_R_tab_GL(i);

      const complex<double> wfp_occ_weight = wfp_occ_bef_R_tab_GL(i)*weight;

      radial_integral_weight_re += product_Op_weight_wfn*real (wfp_occ_weight);
      radial_integral_weight_im += product_Op_weight_wfn*imag (wfp_occ_weight);
    }

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (ln + lp_occ);

  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (ln , jn , lp_occ , jp_occ , lp_occ , jp_occ , ln , jn , J);

  const double coupling_constant = inter_data_basis.Gaussian_coupling_constant (bp , J , false , true);

  const double strength_angular_TBME = coupling_constant*angular_TBME;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> wfp_occ_r = wfp_occ_bef_R_tab_GL(i);
      
      const double Re_wfp_occ_r = real (wfp_occ_r);
      const double Im_wfp_occ_r = imag (wfp_occ_r);

      const complex<double> I_exc_r = strength_angular_TBME*Gaussian_table_GL(i)*(radial_integral_weight_re*Re_wfp_occ_r - radial_integral_weight_im*Im_wfp_occ_r);

      const double r = r_bef_R_tab_GL(i);
      
      const complex<double> C0_n_pow_r_ln_plus_one = C0_n*pow (r , ln + 1);

      const complex<double> wfn_r = wfn_bef_R_tab_GL(i);
      
      const complex<double> dwfn_r = dwfn_bef_R_tab_GL(i);

      const double pole_removal_factor = exp (-Ueq_regularizor*(norm (wfn_r)/norm (dwfn_r)))*(1.0 - exp (-Ueq_regularizor*(norm (C0_n_pow_r_ln_plus_one/wfn_r - 1.0))));
      
      const complex<double> I_exc_r_pole_removal_factor = I_exc_r*pole_removal_factor;

      Un_eq_MSGI_tab_GL(nn , ln , jn , i) -= (I_exc_r - I_exc_r_pole_removal_factor)/wfn_r;

      source_n_tab_GL(nn , ln , jn , i) -= I_exc_r_pole_removal_factor;
    }
}



















// Calculation of the radial one-body matrix element associated to the real or imaginary part of the Gaussian form factor for the state whose HF potential is calculated and an occupied state
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates the real or imaginary part of <wf | F_Gaussian | wf_occ>  where F_Gaussian is the Gaussian form factor of the MSGI interaction (see GSM_TBME_MSGI.cpp).

complex<double> HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::radial_OBME_calc (
												const class array<double> &Gaussian_table_GL , 
												const class spherical_state &wf , 
												const class spherical_state &wf_occ , 
												const bool is_it_real_part)
{
  const class array<double> &w_bef_R_tab_GL = wf.get_w_bef_R_tab_GL_SGI_MSGI ();
  
  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();

  const class array<complex<double> > &wf_bef_R_tab_GL = wf.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wf_occ_bef_R_tab_GL = wf_occ.get_wf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double wf_occ_r_part = (is_it_real_part) ? (real (wf_occ_bef_R_tab_GL(i))) : (imag (wf_occ_bef_R_tab_GL(i)));

      radial_integral += wf_bef_R_tab_GL(i)*(wf_occ_r_part*Gaussian_table_GL(i)*w_bef_R_tab_GL(i));
    }

  return radial_integral;
}










// Calculation of the radial one-body matrix element associated to the real or imaginary part of the Gaussian form factor between the in and out states
// ----------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates <wf_out | F_Gaussian | wf_in>  where F_Gaussian is the Gaussian form factor of the MSGI interaction (see GSM_TBME_MSGI.cpp).

complex<double> HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::radial_integral_calc (
												    const class array<double> &Gaussian_table_GL , 
												    const class spherical_state &wf_in , 
												    const class spherical_state &wf_out)
{
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL_SGI_MSGI ();
  
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

  const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral += wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*Gaussian_table_GL(i)*w_bef_R_tab_GL(i);

  return radial_integral;
}









// Calculation of the one-body matrix element associated to the real or imaginary part of the MSGI interaction
// -----------------------------------------------------------------------------------------------------------
// One calculates <wf_out wf_occ | MSGI | wf_in wf_occ> from the real and imaginary parts of its direct and exchange parts.

complex<double> HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::total_OBME_calc (
											       const class spherical_state &wf_in , 
											       const class spherical_state &wf_out , 
											       const class array<double> &Gaussian_table_GL , 
											       const complex<double> &OBME_factor_direct , 
											       const complex<double> &OBME_factor_exchange , 
											       const class spherical_state &wf_occ)
{  
  const complex<double> radial_dir_wf_in_wf_out    = MSGI_part_common::radial_integral_calc (Gaussian_table_GL , wf_in , wf_out);
  const complex<double> radial_dir_wf_occ          = MSGI_part_common::radial_integral_calc (Gaussian_table_GL , wf_occ , wf_occ);
  
  const complex<double> radial_exc_wf_in_occ_re  = MSGI_part_common::radial_OBME_calc (Gaussian_table_GL , wf_in  , wf_occ , true);
  const complex<double> radial_exc_wf_out_occ_re = MSGI_part_common::radial_OBME_calc (Gaussian_table_GL , wf_out , wf_occ , true);
  const complex<double> radial_exc_wf_in_occ_im  = MSGI_part_common::radial_OBME_calc (Gaussian_table_GL , wf_in  , wf_occ , false);
  const complex<double> radial_exc_wf_out_occ_im = MSGI_part_common::radial_OBME_calc (Gaussian_table_GL , wf_out , wf_occ , false);

  const complex<double> OBME_dir_re_part = real (OBME_factor_direct)*real (radial_dir_wf_occ)*radial_dir_wf_in_wf_out;
  const complex<double> OBME_dir_im_part = imag (OBME_factor_direct)*imag (radial_dir_wf_occ)*radial_dir_wf_in_wf_out;

  const complex<double> OBME_exc_re_part = real (OBME_factor_exchange)*(radial_exc_wf_in_occ_re*radial_exc_wf_out_occ_re - radial_exc_wf_in_occ_im*radial_exc_wf_out_occ_im);
  const complex<double> OBME_exc_im_part = imag (OBME_factor_exchange)*(radial_exc_wf_in_occ_im*radial_exc_wf_out_occ_re + radial_exc_wf_in_occ_re*radial_exc_wf_out_occ_im);

  const complex<double> OBME_direct   = OBME_dir_re_part   - OBME_dir_im_part;
  const complex<double> OBME_exchange = OBME_exc_re_part - OBME_exc_im_part;

  const complex<double> OBME = OBME_direct - OBME_exchange;

  return OBME;
}









// Calculation of the direct and exchange parts of the HF potential taking into account one occupied state for the proton-proton, neutron-neutron and proton-neutron parts of the interaction
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// The equivalent HF potential U_HF = U_HF(direct) - U_HF(exchange) writes, along with its source:
//
// U_HF(dir)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l j l_occ j_occ> . F_Gaussian(r) . \int u_occ^2(r') F_Gaussian(r') dr'
// U_HF(exc)(r) = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' / u(r) . [1 - F(r)]
// S(r)         = \sum_{J, s_occ} coupling_constant(Pi,J) . weight . <l j l_occ j_occ |\sum_l' 4Pi/(2l'+1) Yl'1.Yl'2 |l_occ j_occ l j> . F_Gaussian(r) . u_occ(r) \int u(r') u_occ(r') F_Gaussian(r') dr' . F(r)
//
// where weight is function of Clebsch-Gordan coefficients and angular momenta and come from the use of uniform filling approximation,
// coupling_constant(Pi,J) is the Pi-J-dependent coupling constant of the MSGI interaction,
//
// F_Gaussian(r) is the Gaussian form factor entering the MSGI interaction (see Gaussian_table_GL_calc),
//
// The function F(r) is equal to exp (-Ueq_regularizor . (|u(r)|^2/|u'(r)|^2)) . (1 - exp (-Ueq_regularizor . |C0 r^(l+1) - 1|^2)).
// Its first term prevents Ueq(r) to diverge if u(r) = 0 for r != 0, and its second term provides with F(r) = 0 numerically in r=0 and the equivalent potential has to be non-zero and is well behaved there.
// The ratio |u(r)|^2/|u'(r)|^2) prevents F(r) to be non zero when r -> +oo.
// Ueq_regularizor is in [10:100] typically and makes F(r) vanish quickly except close to the zeroes of u(r).
//
// The real part of the equivalent HF potential is considered for the HF potential when it is complex.
//
// These routines call previous routines if the considered state is general, or only bound or resonant (res), or if it a proton scattering state for which k +/- w/(4 Pi) for Coulomb complex scaling (see H_CM_OBMEs.cpp).

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_pp_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const class spherical_state &shell_p , 
										    const class spherical_state &shell_p_occ , 
										    const class CG_str &CGs , 
										    const class array<double> &Gaussian_table_GL , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    class HF_nucleons_data &prot_HF_data)
{
  const int lp = shell_p.get_l ();

  const int lp_occ = shell_p_occ.get_l ();
  
  const double jp = shell_p.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_pp = inter_data_basis.get_Jmin_global_pp ();
  const int Jmax_global_pp = inter_data_basis.get_Jmax_global_pp ();

  const int Jmin_sp_sp_occ = abs (make_int (jp - jp_occ));
  const int Jmax_sp_sp_occ = make_int (jp + jp_occ);
  
  const int Jmin = max (Jmin_sp_sp_occ , Jmin_global_pp);
  const int Jmax = min (Jmax_sp_sp_occ , Jmax_global_pp);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

	  Up_dir_pp_part_calc (J , shell_p , shell_p_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);
	  
	  Up_exc_pp_part_calc (J , shell_p , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , source_p_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , lp_occ , jp_occ , J , CGs , prot_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jp - J);

	  Up_dir_pp_part_calc (J , shell_p , shell_p_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);
	  
	  Up_exc_pp_part_calc (J , shell_p , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , source_p_MSGI_tab_GL);
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Up_pn_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const class spherical_state &shell_p , 
										    const class spherical_state &shell_n_occ , 
										    const class CG_str &CGs , 
										    const class array<double> &Gaussian_table_GL , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    const class HF_nucleons_data &neut_HF_data , 
										    class HF_nucleons_data &prot_HF_data)
{
  const int lp = shell_p.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const double jp = shell_p.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const double Ueq_regularizor = prot_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int Jmin_sp_sn_occ = abs (make_int (jp - jn_occ));
  const int Jmax_sp_sn_occ = make_int (jp + jn_occ);

  const int Jmin = max (Jmin_sp_sn_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sp_sn_occ , Jmax_global_pn);
					
  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_MSGI_pm_tab_GL = (pm == 1) ? (prot_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_dir_pn_part_calc (J , shell_p , shell_n_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL);

	  Up_exc_pn_part_calc (J , shell_p , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_pm_tab_GL , source_p_MSGI_pm_tab_GL);
	}	
    }
  else
    {
      class nlj_table<complex<double> > &Up_eq_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_p_MSGI_tab_GL = (is_it_res) ? (prot_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (prot_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (lp , jp , ln_occ , jn_occ , J , CGs , prot_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jp - J);

	  Up_dir_pn_part_calc (J , shell_p , shell_n_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL);

	  Up_exc_pn_part_calc (J , shell_p , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Up_eq_MSGI_tab_GL , source_p_MSGI_tab_GL);
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_nn_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const class spherical_state &shell_n , 
										    const class spherical_state &shell_n_occ , 
										    const class CG_str &CGs , 
										    const class array<double> &Gaussian_table_GL , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    class HF_nucleons_data &neut_HF_data)
{
  const int ln = shell_n.get_l ();

  const int ln_occ = shell_n_occ.get_l ();

  const double jn = shell_n.get_j ();

  const double jn_occ = shell_n_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_nn = inter_data_basis.get_Jmin_global_nn ();
  const int Jmax_global_nn = inter_data_basis.get_Jmax_global_nn ();

  const int Jmin_sn_sn_occ = abs (make_int (jn - jn_occ));
  const int Jmax_sn_sn_occ = make_int (jn + jn_occ);

  const int Jmin = max (Jmin_sn_sn_occ , Jmin_global_nn);
  const int Jmax = min (Jmax_sn_sn_occ , Jmax_global_nn);

  if (is_it_pm)
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);
			
	  Un_dir_nn_part_calc (J , shell_n , shell_n_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);
	  
	  Un_exc_nn_part_calc (J , shell_n , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , source_n_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , ln_occ , jn_occ , J , CGs , neut_HF_data , neut_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jn_occ + jn - J);

	  Un_dir_nn_part_calc (J , shell_n , shell_n_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	  Un_exc_nn_part_calc (J , shell_n , shell_n_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , source_n_MSGI_tab_GL);
	}
    }
}

void HF_potentials_common::SGI_MSGI_part_common::MSGI_part_common::Un_pn_part_calc (
										    const bool is_it_res , 
										    const bool is_it_pm , 
										    const int pm , 
										    const class spherical_state &shell_n , 
										    const class spherical_state &shell_p_occ , 
										    const class CG_str &CGs , 
										    const class array<double> &Gaussian_table_GL , 
										    const class multipolar_expansion_str &multipolar_expansion , 
										    const class interaction_class &inter_data_basis , 
										    const class HF_nucleons_data &prot_HF_data , 
										    class HF_nucleons_data &neut_HF_data)
{
  const int ln = shell_n.get_l ();

  const int lp_occ = shell_p_occ.get_l ();

  const double jn = shell_n.get_j ();

  const double jp_occ = shell_p_occ.get_j ();

  const double Ueq_regularizor = neut_HF_data.get_Ueq_regularizor ();

  const int Jmin_global_pn = inter_data_basis.get_Jmin_global_pn ();
  const int Jmax_global_pn = inter_data_basis.get_Jmax_global_pn ();

  const int Jmin_sn_sp_occ = abs (make_int (jn - jp_occ));
  const int Jmax_sn_sp_occ = make_int (jn + jp_occ);

  const int Jmin = max (Jmin_sn_sp_occ , Jmin_global_pn);
  const int Jmax = min (Jmax_sn_sp_occ , Jmax_global_pn);

  if (is_it_pm)
    {	
      class nlj_table<complex<double> > &Un_eq_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_Ueq_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_minus_tab_GL ());

      class nlj_table<complex<double> > &source_n_MSGI_pm_tab_GL = (pm == 1) ? (neut_HF_data.get_source_SGI_MSGI_plus_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_minus_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_dir_pn_part_calc (J , shell_n , shell_p_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL);
	  
	  Un_exc_pn_part_calc (J , shell_n , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_pm_tab_GL , source_n_MSGI_pm_tab_GL);
	}
    }
  else
    {
      class nlj_table<complex<double> > &Un_eq_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_Ueq_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_Ueq_SGI_MSGI_tab_GL ());
      
      class nlj_table<complex<double> > &source_n_MSGI_tab_GL = (is_it_res) ? (neut_HF_data.get_source_SGI_MSGI_res_tab_GL ()) : (neut_HF_data.get_source_SGI_MSGI_tab_GL ());

      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const double J_coefficient_direct = uniform_filling_approximation::J_coefficient_calc (ln , jn , lp_occ , jp_occ , J , CGs , neut_HF_data , prot_HF_data);

	  const double J_coefficient_exchange = J_coefficient_direct*minus_one_pow (jp_occ + jn - J);

	  Un_dir_pn_part_calc (J , shell_n , shell_p_occ , inter_data_basis , J_coefficient_direct , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL);

	  Un_exc_pn_part_calc (J , shell_n , shell_p_occ , Ueq_regularizor , inter_data_basis , J_coefficient_exchange , Gaussian_table_GL , multipolar_expansion , Un_eq_MSGI_tab_GL , source_n_MSGI_tab_GL);
	}
    }
}




