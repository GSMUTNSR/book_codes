#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// One has here simple routines calculating the number of HO shells (N_nlj), or the maximal principal quantum number (nmax) defined by an array of l-dependent maximal principal quantum numbers (nmax_tab).  
// lmax_all is the maximal orbital quantum number for all proton and neutron states and l is the current orbital quantum number.
// Versions with class array or basic pointer arrays are implemented.
//
// NCM_HO_max_tab_calc calculates the L-dependent maximal principal quantum numbers of center of mass (CM) states from the HO energy formula E_CM_HO = 2.NCM + L. 
// Hence, max(all E_CM_HO) = 2.NCM_max(L) + L for fixed L.
// One provides with the maximal HO energy E_CM_HO_max = max(all E_CM_HO), so that NCM_max(L) = (E_CM_HO_max - L)/2.

unsigned int N_nlj_calc (const class array<int> &nmax_tab)
{ 
  const int lmax_all = nmax_tab.dimension(0) - 1;

  unsigned int N_nlj = 0;

  for (int l = 0 ; l <= lmax_all ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      N_nlj += nmax_tab(l) + 1;

  return N_nlj;
}

int nmax_calc (const class array<int> &nmax_tab)
{
  const int lmax_all = nmax_tab.dimension(0) - 1;

  int nmax = 0;

  for (int l = 0 ; l <= lmax_all ; l++) nmax = max (nmax_tab(l) , nmax);

  return nmax;
}

unsigned int N_nlj_calc (
			 const int lmax_all , 
			 const int nmax_tab[])
{ 
  unsigned int N_nlj = 0;

  for (int l = 0 ; l <= lmax_all ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      N_nlj += nmax_tab[l] + 1;

  return N_nlj;
}

int nmax_calc (
	       const int lmax_all , 
	       const int nmax_tab[])
{
  int nmax = 0;

  for (int l = 0 ; l <= lmax_all ; l++) nmax = max (nmax_tab[l] , nmax);

  return nmax;
}

void NCM_HO_max_tab_calc (
			  const int E_CM_HO_max , 
			  class array<int> &NCM_HO_max_tab)
{
  
  const int Lmax = NCM_HO_max_tab.dimension (0) - 1;

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const int NCM_max_E_CM_HO = (E_CM_HO_max - L)/2;

      NCM_HO_max_tab(L) = NCM_max_E_CM_HO;
    }
}
