#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------
// One has here a simple routine calculating the maximal principal quantum number (nmax) in partial waves of fixed orbital quantum number l in an array of l-dependent maximal principal quantum numbers (nmax_tab).  
// lmax is the maximal orbital quantum number for all states (nucleons or hyperons) and s is the spin of nucleons or hyperons.
//
// NCM_HO_max_tab_calc calculates the L-dependent maximal principal quantum numbers of center of mass (CM) states from the HO energy formula E_CM_HO = 2.NCM + L. 
// Hence, max(all E_CM_HO) = 2.NCM_max(L) + L for fixed L.
// One provides with the maximal HO energy E_CM_HO_max = max(all E_CM_HO), so that NCM_max(L) = (E_CM_HO_max - L)/2.

int nmax_l_calc (
		 const int l ,		 
		 const class lj_table<int> &nmax_tab)
{
  const int lmax = nmax_tab.get_lmax ();
  
  if (l > lmax) return -1;
  
  const double s = nmax_tab.get_s ();

  int nmax_l = -1;
  
  for (double j = abs (l - s) ; rint (j - l - s) <= 0.0 ; j++) nmax_l = max (nmax_l , nmax_tab(l , j));

  return nmax_l;
}


void NCM_HO_max_tab_calc (
			  const int E_CM_HO_max , 
			  class array<int> &NCM_HO_max_tab)
{
  
  const int Lmax = NCM_HO_max_tab.dimension (0) - 1;

  for (int L = 0 ; L <= Lmax ; L++)
    {
      const int NCM_max_E_CM_HO = (E_CM_HO_max - L)/2;

      NCM_HO_max_tab(L) = NCM_max_E_CM_HO;
    }
}
