#include "../GSM_include/GSM_include_def_common.h"


using namespace string_routines;
using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// Calculation of a JT coupled two-body matrix element from interaction files
// --------------------------------------------------------------------------
// The two-body matrix element <s2 s3 | V | s0 s1>_JT is calculated from the different instances coming from read interaction files in the standard shell model code with fitted interaction matrix elements.
// For this, one first checks if s0, s1, s2, s3 are not frozen states of the core. If one of them is, zero is returned.
// If s0 = s1 or s2 = s3 and J+T is not even, <s2 s3 | V | s0 s1>_JT = 0 and zero is returned.
// After this, one loops over all interaction files, to which an array of structures of two-body matrix elements with quantum numbers is associated.
// One then does a sequential search of the quantum numbers J and (n,l,j) of s0, s1, s2, s3  on the structures of the considered array of structures.
// Once one is found, it is added to the value of <s2 s3 | V | s0 s1>_JT to calculate. This value is then returned.

TYPE coupled_TBMEs::standard_HO_SM::JT_TBME_calc (
						  const int J , 
						  const int T , 
						  const enum space_type TBME_space , 
						  const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
						  const class nlj_struct four_shells[])
{
  const unsigned int files_number = JT_TBME_tables.dimension (0);

  for (unsigned int i = 0 ; i < 4 ; i++)
    {
      const class nlj_struct &shell = four_shells[i];
      
      const bool frozen_state = shell.get_frozen_state ();
      
      if (frozen_state) return 0.0;
    }

  const unsigned int is_J_plus_T_even = ((J + T)%2 == 0);
  
  if (is_J_plus_T_even && (same_nlj (four_shells[0] , four_shells[1]))) return 0.0;
  if (is_J_plus_T_even && (same_nlj (four_shells[2] , four_shells[3]))) return 0.0;

  TYPE TBME_new = 0;
  
  for (unsigned int file = 0 ; file < files_number ; file++)
    {
      const class array<class JT_coupled_TBME> &JT_TBME_table = JT_TBME_tables(file);
      
      const unsigned int TBMEs_number = JT_TBME_table.dimension (0);

      unsigned int index = 0;

      while ((index < TBMEs_number) && (!JT_TBME_table(index).are_shells_JT_proper_determine (J , T , TBME_space , four_shells))) index++;

      if (index < TBMEs_number) TBME_new += JT_TBME_table(index).get_Vabcd ();
    }
  
  return TBME_new;
}





// Calculation of a new structure containing the quantum_numbers associated to a two-body matrix element and the value of two-body matrix element for a combination of s0, s1, s2, s3 shells in <s2 s3 | V | s0 s1>_JT
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In interaction files of the standard shell model code with fitted interaction matrix elements, one has s0 <= s1 and s2 <= s3, and (s0,s1) <= (s2,s3), in <s2 s3 | V | s0 s1>_JT two-body matrix elements. 
// However, one need all combinations in the code, so that combinations such as <s3 s2 | V | s0 s1>_JT  are stored.
// The new two-body matrix elements are equal to the first one up to a phase.
// Hence, the new structure containing these new combinations of shells and new two-body matrix element is calculated here and returned.
// For example, for <s3 s2 | V | s0 s1>_JT, s0, s1, s2, s3 becomes s0, s1, s3, s2 and <s3 s2 | V | s0 s1>_JT = (-1)^(j2 + j3 - J - T) <s2 s3 | V | s0 s1>_JT

class JT_coupled_TBME coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (
											  const class JT_coupled_TBME &JT_TBME , 
											  const unsigned int s0 , 
											  const unsigned int s1 , 
											  const unsigned int s2 , 
											  const unsigned int s3 , 
											  const int phase)
{
  const enum space_type TBME_space = JT_TBME.get_TBME_space ();

  const double J = JT_TBME.get_J ();
  const double T = JT_TBME.get_T ();

  const unsigned int s[4] = {s0 , s1 , s2 , s3};

  int n_new[4];
  int l_new[4];
  
  double j_new[4];

  for (unsigned int i = 0 ; i < 4 ; i++)
    {
      const unsigned int si = s[i];

      n_new[i] = JT_TBME.get_n (si);
      l_new[i] = JT_TBME.get_l (si);
      j_new[i] = JT_TBME.get_j (si);
    }

  const TYPE Vabcd_new = (phase == 1) ? (JT_TBME.get_Vabcd ()) : (-JT_TBME.get_Vabcd ());

  return JT_coupled_TBME (TBME_space , J , T , Vabcd_new , n_new , l_new , j_new);
}




// Calculation of all new structures containing the quantum_numbers associated to a two-body matrix element and the value of two-body matrix element for a combination of s0, s1, s2, s3 shells in <s2 s3 | V | s0 s1>_JT
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In interaction files of the standard shell model code with fitted interaction matrix elements, one has s0 <= s1 and s2 <= s3, and (s0,s1) <= (s2,s3), in <s2 s3 | V | s0 s1>_JT two-body matrix elements. 
// However, one need all combinations in the code, so that combinations such as <s3 s2 | V | s0 s1>_JT are stored.
// They are all calculated here. There are 8 combinations per initial two-body matrix element:
// <s2 s3 | V | s0 s1>_JT, <s3 s2 | V | s0 s1>_JT, <s2 s3 | V | s1 s0>_JT, <s3 s2 | V | s1 s0>_JT, <s0 s1 | V | cd>_JT, <s0 s1 | V | s3 s2>_JT, <s1 s0 | V | cd>_JT, <s1 s0 | V | s3 s2>_JT.
// s0 <-> s1 induces a (-1)^(j0 + j1 - J -T) phase, and s2 <-> s3 induces a (-1)^(j2 + j3 - J - T) phase.
// The initial array of structures is deallocated and replaced by the new array containing all possible s0, s1, s2, s3 combinations.

void coupled_TBMEs::standard_HO_SM::JT_TBME_tables_realloc_all_combinations_fill (class array<class JT_coupled_TBME> &JT_TBME_table)
{
  const unsigned int TBMEs_number = JT_TBME_table.dimension (0);
  
  const unsigned int TBMEs_number_new = 8*TBMEs_number;
  
  class array<class JT_coupled_TBME> JT_TBME_table_new(TBMEs_number_new);

  for (unsigned int index = 0 ; index < TBMEs_number ; index++)
    {
      const unsigned int eight_times_index = 8*index;
      
      const int J = JT_TBME_table(index).get_J ();
      const int T = JT_TBME_table(index).get_T ();
      
      const double j0 = JT_TBME_table(index).get_j (0);
      const double j1 = JT_TBME_table(index).get_j (1);
      const double j2 = JT_TBME_table(index).get_j (2);
      const double j3 = JT_TBME_table(index).get_j (3);

      const int phase_01 = minus_one_pow (j0 + j1 - J - T);
      const int phase_23 = minus_one_pow (j2 + j3 - J - T);
      
      const int phase_0123 = phase_01*phase_23;
	
      JT_TBME_table_new(eight_times_index)     = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 0 , 1 , 2 , 3 , 1);
      JT_TBME_table_new(eight_times_index + 1) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 2 , 3 , 0 , 1 , 1);
      
      JT_TBME_table_new(eight_times_index + 2) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 1 , 0 , 2 , 3 , phase_01);
      JT_TBME_table_new(eight_times_index + 3) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 2 , 3 , 1 , 0 , phase_01);
      
      JT_TBME_table_new(eight_times_index + 4) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 0 , 1 , 3 , 2 , phase_23);
      JT_TBME_table_new(eight_times_index + 5) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 3 , 2 , 0 , 1 , phase_23);
      
      JT_TBME_table_new(eight_times_index + 6) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 1 , 0 , 3 , 2 , phase_0123);
      JT_TBME_table_new(eight_times_index + 7) = coupled_TBMEs::standard_HO_SM::swap_nlj_Vabcd_phase_multiplication (JT_TBME_table(index) , 3 , 2 , 1 , 0 , phase_0123);
    }

  JT_TBME_table.deallocate ();
  
  JT_TBME_table.allocate_fill (JT_TBME_table_new);
}







// Calculation of all protons or neutrons (plus a few hyperons if any) two-body matrix elements in the standard shell model code with fitted interaction matrix elements
// ----------------------------------------------------------------------------------------------------------------------------------------
// Initial <s2 s3 | V | s0 s1>_J for each interaction file are stored in the initial array of structures containing the quantum_numbers associated to a two-body matrix element and the value of two-body matrix element itself, as T=1 here.
// One then loops over all s0, s1, s2, s3 shells and total angular momentum J.
// One adds the two-body matrix element associated to the Lawson method if it is used and the new two-body matrix element is stored in the two-body matrix element class of protons or neutrons (plus a few hyperons if any) data.
// The total two-body matrix element is equal to the sum of <s2 s3 | V | s0 s1>_J two-body matrix element for each interaction file, to which is added lambda_Hcm . <s2 s3 | Hcm | s0 s1>_J if the Lawson method if is used.
// The time taken to calculate two-body matrix elements is then written on screen.
// No MPI/OpenMP parallelization is done here as there are no lengthy calculations so that they are very fast even done sequentially.

void coupled_TBMEs::standard_HO_SM::TBMEs_pp_nn_calc (
						      const class input_data_str &input_data , 
						      const bool is_there_Hcm , 
						      const class array <class array<class JT_coupled_TBME> > &JT_TBME_tables , 
						      class baryons_data &particles_data)
{
  const unsigned int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  if (N_valence_baryons <= 1) return;

  const double reference_time = (THIS_PROCESS == MASTER_PROCESS) ? (absolute_time_determine ()) : (NADA);
    
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();
  
  const enum space_type TBME_space = (nucleonic_particle == PROTON) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);

  const enum interaction_type inter = input_data.get_inter ();

  const double lambda_Hcm = (is_there_Hcm) ? (input_data.get_lambda_Hcm ()) : (0.0);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  const unsigned int N_nlj = particles_data.get_N_nlj_baryon ();
  
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_set = particles_data.get_reduced_grad_HO_expansion_set ();
  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_set = particles_data.get_reduced_r_HO_expansion_set ();
  
  const class array<TYPE> &reduced_grad_HO_expansion_set_Hcm = reduced_grad_HO_expansion_set(HCM);
  
  const class array<TYPE> &reduced_r_HO_expansion_set_Hcm = reduced_r_HO_expansion_set(HCM);

  const int n_scat_max = particles_data.get_n_scat_max ();
  
  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
  
  class TBMEs_class &TBMEs = particles_data.get_TBMEs ();
  
  const unsigned int BPmin_global = TBMEs.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs.get_BPmax_global ();
  
  const int Jmin_global = TBMEs.get_Jmin_global ();
  const int Jmax_global = TBMEs.get_Jmax_global ();
  
  for (unsigned int s3 = 0 ; s3 < N_nlj ; s3++)
    for (unsigned int s2 = 0 ; s2 <= s3 ; s2++)
      {
	const class pair_str pair_out(nucleonic_particle , s2 , nucleonic_particle , s3);

	const int n_scat_out = pair_out.n_scat_determine (shells_qn , shells_qn);

	if (n_scat_out <= n_scat_max)
	  {
	    const unsigned int bp_out = pair_out.bp_determine (shells_qn , shells_qn);

	    if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global))
	      {
		const int Jmin_out = pair_out.Jmin_determine (shells_qn , shells_qn);
		const int Jmax_out = pair_out.Jmax_determine (shells_qn , shells_qn);

		for (unsigned int s1 = 0 ; s1 < N_nlj ; s1++)
		  for (unsigned int s0 = 0 ; s0 <= s1 ; s0++)
		    {
		      const class pair_str pair_in(nucleonic_particle , s0 , nucleonic_particle , s1);

		      if (pair_in <= pair_out)
			{
			  const int n_scat_in = pair_in.n_scat_determine (shells_qn , shells_qn); 

			  if (n_scat_in <= n_scat_max)
			    {
			      const unsigned int bp_in = pair_in.bp_determine (shells_qn , shells_qn);

			      if (bp_in == bp_out)
				{
				  const int Jmin_in = pair_in.Jmin_determine (shells_qn , shells_qn);
				  const int Jmax_in = pair_in.Jmax_determine (shells_qn , shells_qn);
				  
				  const int Jmin_local = max (Jmin_in , Jmin_out);
				  const int Jmax_local = min (Jmax_in , Jmax_out);
				  
				  const int Jmin = max (Jmin_local , Jmin_global);
				  const int Jmax = min (Jmax_local , Jmax_global);
				  
				  if (Jmin <= Jmax)
				    {
				      const class nlj_struct four_shells[] = {shells_qn(s0) , shells_qn(s1) , shells_qn(s2) , shells_qn(s3)};

				      for (int J = Jmin ; J <= Jmax ; J++)
					{
					  if (inter == SU3_INTERACTION)
					    {
					      const int n0 = four_shells[0].get_n () , l0 = four_shells[0].get_l ();
					      const int n1 = four_shells[1].get_n () , l1 = four_shells[1].get_l ();
					      const int n2 = four_shells[2].get_n () , l2 = four_shells[2].get_l ();
					      const int n3 = four_shells[3].get_n () , l3 = four_shells[3].get_l ();
					      
					      const double j0 = four_shells[0].get_j ();
					      const double j1 = four_shells[1].get_j ();
					      const double j2 = four_shells[2].get_j ();
					      const double j3 = four_shells[3].get_j ();
      
					      const TYPE TBME_q1_scalar_q2_HO_antisymmetrized = HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_antisymmetrized_calc (n0 , l0 , j0 , n1 , l1 , j1 , n2 , l2 , j2 , n3 , l3 , j3 , J);
					      
					      TBMEs(J , s0 , s1 , s2 , s3) = -2.0*TBME_q1_scalar_q2_HO_antisymmetrized;					      
					    }
					  else
					    {
					      const TYPE TBME_value = JT_TBME_calc (J , 1 , TBME_space , JT_TBME_tables , four_shells)*TBME_A_dependent_factor;
					  
					      const TYPE TBME_Hcm = TBME_CM_operator::Hcm::TBME_J_pp_nn_antisymmetrized (J , s0 , s1 , s2 , s3 , shells_qn , reduced_grad_HO_expansion_set_Hcm , reduced_r_HO_expansion_set_Hcm);
					      
					      TBMEs(J , s0 , s1 , s2 , s3) = TBME_value + lambda_Hcm*TBME_Hcm;					 
	      
					      //if (TBMEs(J , s0 , s1 , s2 , s3) != 0)
					      //cout << THIS_PROCESS << " " << TBME_space << " " << four_shells[0] << " " << four_shells[1] << " "
					      //<< four_shells[2] << " " << four_shells[3] << " J:" << J << " " << TBMEs(J , s0 , s1 , s2 , s3) << endl;
					    }}}}}}}}}}
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << "Coupled HO TBMEs " << TBME_space << " calculated. time:" << relative_time << " s" << endl << endl;
    }	
}









// Calculation of all proton-neutron (plus a few hyperons if any) two-body matrix elements in the standard shell model code with fitted interaction matrix elements
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------
// Initial <s2 s3 | V | s0 s1>_JT for each interaction file are stored in the initial array of structures containing the quantum_numbers associated to a two-body matrix element and the value of two-body matrix element itself for T=0 and T=1.
// One then loops over all s0, s1, s2, s3 shells and total angular momentum J.
// To obtain the <s2 s3 | V | s0 s1>_J matrix element in proton-neutron formalism, one uses the formula:
// <s2 s3 | V | s0 s1>_J = sqrt (1 + delta_ab) . sqrt (1 + delta_cd) . (<s2 s3 | V | s0 s1>_J=0 + <s2 s3 | V | s0 s1>_J=1)/2, where isospin quantum numbers are ignored in delta_ab and delta_cd.
// One adds the two-body matrix element associated to the Lawson method if it is used and the new two-body matrix element is stored in the two-body matrix element class of protons or neutrons (plus a few hyperons if any) data.
// The total two-body matrix element is equal to the sum of <s2 s3 | V | s0 s1>_J two-body matrix element for each interaction file, to which is added lambda_Hcm . <s2 s3 | Hcm | s0 s1>_J if the Lawson method if is used.
// The time taken to calculate two-body matrix elements is then written on screen.
// No MPI/OpenMP parallelization is done here as there are no lengthy calculations so that they are very fast even done sequentially.

void coupled_TBMEs::standard_HO_SM::TBMEs_pn_calc (
						   const class input_data_str &input_data , 
						   const class baryons_data &prot_Y_data , 
						   const class baryons_data &neut_Y_data , 
						   const bool is_there_Hcm , 
						   const class array<class array<class JT_coupled_TBME> > &JT_TBME_tables , 
						   class TBMEs_class &TBMEs)
{	
  const double reference_time = (THIS_PROCESS == MASTER_PROCESS) ? (absolute_time_determine ()) : (NADA);
 
  const enum interaction_type inter = input_data.get_inter ();

  const int n_scat_max = input_data.get_n_scat_max ();

  const double lambda_Hcm = (is_there_Hcm) ? (input_data.get_lambda_Hcm ()) : (0.0);
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_p_set = prot_Y_data.get_reduced_grad_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_n_set = neut_Y_data.get_reduced_grad_HO_expansion_set ();
  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_p_set = prot_Y_data.get_reduced_r_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_n_set = neut_Y_data.get_reduced_r_HO_expansion_set ();

  const class array<TYPE> &reduced_grad_HO_expansion_p_set_Hcm = reduced_grad_HO_expansion_p_set(HCM);
  const class array<TYPE> &reduced_grad_HO_expansion_n_set_Hcm = reduced_grad_HO_expansion_n_set(HCM);
  
  const class array<TYPE> &reduced_r_HO_expansion_p_set_Hcm = reduced_r_HO_expansion_p_set(HCM);  
  const class array<TYPE> &reduced_r_HO_expansion_n_set_Hcm = reduced_r_HO_expansion_n_set(HCM);

  const unsigned int BPmin_global = TBMEs.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs.get_BPmax_global ();
  
  const int Jmin_global = TBMEs.get_Jmin_global ();
  const int Jmax_global = TBMEs.get_Jmax_global ();

  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
  
  for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
    for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
      {
	const class pair_str pair_out(PROTON , s2 , NEUTRON , s3);
	
	const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

	if (n_scat_out <= n_scat_max)
	  {
	    const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

	    if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global))
	      {
		const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
		const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

		for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
		  for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
		    {
		      const class pair_str pair_in(PROTON , s0 , NEUTRON , s1);

		      if (pair_in <= pair_out)
			{
			  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

			  if (n_scat_in <= n_scat_max)
			    { 
			      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);  

			      if (bp_in == bp_out)
				{
				  const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
				  const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);
				  
				  const int Jmin_local = max (Jmin_in , Jmin_out);
				  const int Jmax_local = min (Jmax_in , Jmax_out);
				  
				  const int Jmin = max (Jmin_local , Jmin_global);
				  const int Jmax = min (Jmax_local , Jmax_global);

				  if (Jmin <= Jmax)
				    {
				      const class nlj_struct four_shells[] = {shells_qn_p(s0) , shells_qn_n(s1) , shells_qn_p(s2) , shells_qn_n(s3)};

				      for (int J = Jmin ; J <= Jmax ; J++)
					{
					  if (inter == SU3_INTERACTION)
					    {
					      const int n0 = four_shells[0].get_n () , l0 = four_shells[0].get_l ();
					      const int n1 = four_shells[1].get_n () , l1 = four_shells[1].get_l ();
					      const int n2 = four_shells[2].get_n () , l2 = four_shells[2].get_l ();
					      const int n3 = four_shells[3].get_n () , l3 = four_shells[3].get_l ();
					      
					      const double j0 = four_shells[0].get_j () , j1 = four_shells[1].get_j ();
					      const double j2 = four_shells[2].get_j () , j3 = four_shells[3].get_j ();
      
					      const TYPE TBME_q1_scalar_q2_HO = HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_calc (n0 , l0 , j0 , n1 , l1 , j1 , n2 , l2 , j2 , n3 , l3 , j3 , J);
					      
					      TBMEs(J , s0 , s1 , s2 , s3) = -2.0*TBME_q1_scalar_q2_HO;					      
					    }
					  else
					    {
					      const double inv_antisymmetry_delta_in  = (same_nlj (four_shells[0] , four_shells[1])) ? (M_SQRT2) : (1.0);
					      const double inv_antisymmetry_delta_out = (same_nlj (four_shells[2] , four_shells[3])) ? (M_SQRT2) : (1.0);
					  
					      const TYPE J_TBME_T0 = JT_TBME_calc (J , 0 , PROT_NEUT_Y , JT_TBME_tables , four_shells);
					      const TYPE J_TBME_T1 = JT_TBME_calc (J , 1 , PROT_NEUT_Y , JT_TBME_tables , four_shells);
					  
					      const TYPE TBME_value = 0.5*inv_antisymmetry_delta_in*inv_antisymmetry_delta_out*(J_TBME_T0 + J_TBME_T1)*TBME_A_dependent_factor;

					      const TYPE TBME_Hcm = TBME_CM_operator::Hcm::TBME_J_pn (J , s0 , s1 , s2 , s3 , shells_qn_p , shells_qn_n ,
												      reduced_grad_HO_expansion_p_set_Hcm , reduced_grad_HO_expansion_n_set_Hcm ,
												      reduced_r_HO_expansion_p_set_Hcm , reduced_r_HO_expansion_n_set_Hcm);

					      TBMEs(J , s0 , s1 , s2 , s3) = TBME_value + lambda_Hcm*TBME_Hcm;
					  
					      //if (TBMEs(J , s0 , s1 , s2 , s3) != 0)
					      //cout << PROT_NEUT_Y << " " << four_shells[0] << " " << four_shells[1] << " "
					      //<< four_shells[2] << " " << four_shells[3] << " J:" << J << " " << TBMEs(J , s0 , s1 , s2 , s3) << endl;
					    }}}}}}}}}}

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << "Coupled HO TBMEs pn calculated. time:" << relative_time << " s" << endl << endl;
    }	
}












// Calculation of the proton or neutron (plus a few hyperons if any) two-body matrix element <s2 s3 | V | s0 s1>_J for fixed s0, s1, s2, s3 shells with the Berggren basis for a given interaction
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One sums coupled matrix elements to J of nuclear interaction, Coulomb interaction and center of mass Hamiltonian if one uses the Lawson method.
// Available nuclear interaction are: Minnesota, FHT , EFT, fit (i.e. two-body matrix elements stored on file), SGI, MSGI, with or without COSM (i.e. with or without recoil),
//                                    realistic interactions, center of mass Hamiltonian Hcm, center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM)
//
// Interaction expansion means that the one-body basis used to expand the interaction is not the same as that of GSM and is of HO or GHF character.
// HO expansion is always used for Minnesota, FHT , EFT, realistic interactions, center of mass Hamiltonian Hcm,
// center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM) and Coulomb interaction.
// GHF expansion is used with the Qbox method only.
//
// The class interaction_class inter_data stores TBMEs and other data related to Hamiltonian or Coulomb interaction.
// But one calculates TBMEs of oter interactions, such as one and two body operators, center of mass operators, ...
// Hence, TBME_inter, that demanded, and inter, that of inter_data or input_data, are different in general.

TYPE coupled_TBMEs::Berggren::TBME_pp_nn (
					  const bool is_Coulomb_to_be_added ,
					  const int J ,
					  const enum interaction_type TBME_inter ,
					  const enum interaction_read_type inter_read ,
					  const class array<TYPE> &radial_SGI_TBMEs_dir , 
					  const class array<TYPE> &radial_SGI_TBMEs_exc , 
					  const class array<TYPE> &radial_MSGI_OBMEs , 
					  const class baryons_data &particles_data , 
					  const class TBMEs_class &J_TBMEs_mixed_inter , 
					  const class interaction_class &inter_data , 
					  const class multipolar_expansion_str &multipolar_expansion , 
					  const unsigned int s0 , 
					  const unsigned int s1 , 
					  const unsigned int s2 , 
					  const unsigned int s3 , 
					  const double lambda_Hcm)
{   
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const enum space_type TBME_space = (is_it_charged) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);
  
  const class array<class spherical_state> &shells = particles_data.get_shells ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_set = particles_data.get_reduced_grad_HO_expansion_set ();
  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_set = particles_data.get_reduced_r_HO_expansion_set ();
  
  const class array<class vector_class<complex<double> > > &overlaps = (inter_read != LAB_BERGGREN_TBMES_READ) ? (particles_data.get_HO_overlaps ()) : (particles_data.get_GHF_overlaps ());
  
  switch (TBME_inter)
    {
    case MINNESOTA:      return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case MINNESOTA_COSM: return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case FHT:            return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case FHT_COSM:       return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case EFT:            return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case EFT_COSM:       return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
    case FIT:            return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);

    case REALISTIC_INTERACTION:
      {	
	if (lambda_Hcm != 0.0)
	  {
	    const TYPE TBME_inter_expansion = TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
	    
	    const TYPE TBME_Hcm = TBME_CM_operator::Hcm::TBME_J_pp_nn_antisymmetrized (J , s0 , s1 , s2 , s3 , shells_qn , reduced_grad_HO_expansion_set(HCM) , reduced_r_HO_expansion_set(HCM));
	    
	    const TYPE TBME = TBME_inter_expansion + lambda_Hcm*TBME_Hcm;
	
	    return TBME;
	  }
	else
	  return TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter);
      }

    case SGI: 
      {
	const TYPE TBME_SGI = TBME_SGI_set::TBME_J_pp_nn_antisymmetrized (false , J , s0 , s1 , s2 , s3 , shells , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc ,
									  reduced_grad_HO_expansion_set(CM_KINETIC) , inter_data , multipolar_expansion);
	
	const TYPE TBME_Coulomb = (is_it_charged) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_SGI + TBME_Coulomb;

	return TBME;
      }

    case SGI_COSM: 
      {
	const TYPE TBME_SGI = TBME_SGI_set::TBME_J_pp_nn_antisymmetrized (true , J , s0 , s1 , s2 , s3 , shells , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc ,
									  reduced_grad_HO_expansion_set(CM_KINETIC) , inter_data , multipolar_expansion);
	
	const TYPE TBME_Coulomb = ((is_it_charged) && is_Coulomb_to_be_added) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_SGI + TBME_Coulomb;

	return TBME;
      }

    case MSGI: 
      {
	const TYPE TBME_MSGI = TBME_MSGI_set::TBME_J_pp_nn_antisymmetrized (false , J , s0 , s1 , s2 , s3 , shells , radial_MSGI_OBMEs , reduced_grad_HO_expansion_set(CM_KINETIC) , inter_data , multipolar_expansion);
	
	const TYPE TBME_Coulomb = ((is_it_charged) && is_Coulomb_to_be_added) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_MSGI + TBME_Coulomb;

	return TBME;
      }

    case MSGI_COSM: 
      {
	const TYPE TBME_MSGI = TBME_MSGI_set::TBME_J_pp_nn_antisymmetrized (true , J , s0 , s1 , s2 , s3 , shells , radial_MSGI_OBMEs , reduced_grad_HO_expansion_set(CM_KINETIC) , inter_data , multipolar_expansion);
	
	const TYPE TBME_Coulomb = ((is_it_charged) && is_Coulomb_to_be_added) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_MSGI + TBME_Coulomb;

	return TBME;
      }

    case CM_KINETIC_INTERACTION: return TBME_CM_operator::P2_over_2M::TBME_J_pp_nn_antisymmetrized (J , s0 , s1 , s2 , s3 , shells_qn , reduced_grad_HO_expansion_set(CM_KINETIC));
      
    case HCM_INTERACTION: return TBME_CM_operator::Hcm::TBME_J_pp_nn_antisymmetrized (J , s0 , s1 , s2 , s3 , shells_qn , reduced_grad_HO_expansion_set(HCM) , reduced_r_HO_expansion_set(HCM));

    case SDI: 
      {
	const TYPE TBME_SDI = TBME_SDI_set::TBME_J_pp_nn_antisymmetrized (false , J , inter_data , s0 , s1 , s2 , s3 , reduced_grad_HO_expansion_set(CM_KINETIC) , shells);
	
	const TYPE TBME_Coulomb = ((is_it_charged) && is_Coulomb_to_be_added) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_SDI + TBME_Coulomb;

	return TBME;
      }

    case SDI_COSM: 
      {
	const TYPE TBME_SDI = TBME_SDI_set::TBME_J_pp_nn_antisymmetrized (true  , J , inter_data , s0 , s1 , s2 , s3 , reduced_grad_HO_expansion_set(CM_KINETIC) , shells);
	
	const TYPE TBME_Coulomb = ((is_it_charged) && is_Coulomb_to_be_added) ? (TBME_inter_expansion_set::TBME_J_pp_nn_antisymmetrized (TBME_space , J , s0 , s1 , s2 , s3 , overlaps , shells_qn , inter_data , J_TBMEs_mixed_inter)) : (0.0);
	
	const TYPE TBME = TBME_SDI + TBME_Coulomb;

	return TBME;
      }
      
    default: abort_all ();
    }

  return NADA;
}









// Calculation of all protons or neutrons (plus a few hyperons if any) two-body matrix elements with the Berggren basis for a given interaction
// --------------------------------------------------------------------------------------------------------------------------------------------
// If one reads two-body matrix elements from a file, it is done by the master process, which distributes data to all nodes, and one leaves the routine.
// Otherwise, initial <s2 s3 | V | s0 s1>_J in the HO or GHF basis have been calculated and stored in the interaction class with the HO or GHF expansion method.
// One then loops over all s0, s1, s2, s3 shells and total angular momentum J and one calculates directly the matrix element or one uses the <s2 s3 | V | s0 s1>_J two-body matrix elements in the HO or GHF basis with the HO or GHF expansion method.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each, which are then distributed to all nodes at the end.
// The time taken to calculate two-body matrix elements is then written on screen.
// Two-body matrix elements are copied to a file if it was demanded in the input file.
//
// Interaction expansion means that the one-body basis used to expand the interaction is not the same as that of GSM and is of HO or GHF character.
// HO expansion is always used for Minnesota, FHT , EFT, realistic interactions, center of mass Hamiltonian Hcm,
// center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM) and Coulomb interaction.
// GHF expansion is used with the Qbox method only.
//
// The class interaction_class inter_data stores TBMEs and other data related to Hamiltonian or Coulomb interaction.
// But one calculates TBMEs of oter interactions, such as one and two body operators, center of mass operators, ...
// Hence, TBME_inter, that demanded, and inter, that of inter_data or input_data, are different in general.

void coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (
						const bool is_there_cout , 
						const enum interaction_type TBME_inter ,
						const class input_data_str &input_data , 
						const bool is_there_Hcm , 
						const class interaction_class &inter_data , 
						class baryons_data &particles_data)
{
  const unsigned int N_valence_baryons = particles_data.get_N_valence_baryons ();
  
  if (N_valence_baryons <= 1) return; 

  const bool is_Coulomb_to_be_added = input_data.get_is_Coulomb_to_be_added ();
      
  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
    
  const enum particle_type nucleonic_particle = particles_data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const enum space_type TBME_space = (is_it_charged) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);

  const enum interaction_type inter = input_data.get_inter ();
  
  const enum interaction_read_type inter_read = (TBME_inter == inter) ? (input_data.get_inter_read ()) : (NO_TBMES_READ);
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (particles_data.get_n_scat_max ()) : (0);

  class TBMEs_class &TBMEs = particles_data.get_TBMEs ();
  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers (); 

  const class array<class nlj_struct> &shells_inter_qn = inter_data.get_shells_inter_qn ();
  
  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_tab = (is_it_charged) ? (inter_data.get_shells_inter_indices_from_nlj_indices_p_tab ()) : (inter_data.get_shells_inter_indices_from_nlj_indices_n_tab ());
  
  const unsigned int N_nlj = particles_data.get_N_nlj_baryon ();
  
  const double jmax = particles_data.get_jmax ();
  
  const double lambda_Hcm = (is_there_Hcm) ? (input_data.get_lambda_Hcm ()) : (0.0); 
  
  const int lmax_multipole_expansion = inter_data.get_lmax_multipole_expansion ();

  const int lmax_multipole_expansion_plus_one = lmax_multipole_expansion + 1;
   
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);
  
  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const bool is_it_mixed = is_it_mixed_determine (is_it_charged , TBME_inter);
  
  const bool is_it_copied = input_data.get_copy_J_OBMEs_TBMEs ();
   
  const unsigned int BPmin_global = TBMEs.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs.get_BPmax_global ();
  
  const int strangeness_min_global = TBMEs.get_strangeness_min_global ();
  const int strangeness_max_global = TBMEs.get_strangeness_max_global ();
  
  const unsigned int i_charge_min_global = TBMEs.get_i_charge_min_global ();
  const unsigned int i_charge_max_global = TBMEs.get_i_charge_max_global ();
  
  const int Jmin_global = TBMEs.get_Jmin_global ();
  const int Jmax_global = TBMEs.get_Jmax_global ();
  
  class array<TYPE> radial_MSGI_OBMEs;

  class TBMEs_class J_TBMEs_mixed_inter;
  
  class multipolar_expansion_str multipolar_expansion;

  if (is_it_SGI_MSGI) multipolar_expansion.allocate_calc (jmax);

  if (is_it_mixed) 
    {
      J_TBMEs_mixed_inter.allocate (is_there_cout , false , input_data , particles_data , TBME_inter , shells_inter_qn , shells_inter_indices_from_nlj_indices_tab);      

      TBME_inter_expansion_set::J_TBMEs_mixed_inter_pp_nn_calc (is_there_cout , inter_read , TBME_space , is_it_cluster_CM_HO_basis_calculation , particles_data , inter_data , J_TBMEs_mixed_inter);
    }

  if (is_it_MSGI)
    {
      radial_MSGI_OBMEs.allocate (N_nlj , N_nlj);

      TBME_MSGI_set::pp_nn_radial_integral_calc (particles_data , inter_data , radial_MSGI_OBMEs);
    }

  const unsigned int first_index = TBMEs.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = TBMEs.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s3 = 0 ; s3 < N_nlj ; s3++)
    {
      class array<TYPE> radial_SGI_TBMEs_dir;
      class array<TYPE> radial_SGI_TBMEs_exc;

      if (is_it_SGI)
	{
	  radial_SGI_TBMEs_dir.allocate (lmax_multipole_expansion_plus_one);
	  radial_SGI_TBMEs_exc.allocate (lmax_multipole_expansion_plus_one);
      	}

      for (unsigned int s2 = 0 ; s2 <= s3 ; s2++)
	{
	  const class nlj_struct &shell_qn_s2 = shells_qn(s2);
	  const class nlj_struct &shell_qn_s3 = shells_qn(s3);

	  const enum particle_type particle_s2 = shell_qn_s2.get_particle ();	
	  const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
		  
	  const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);
	  
	  const int n_scat_out = pair_out.n_scat_determine (shells_qn , shells_qn);

	  const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn , shells_qn);
	  const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn , shells_qn);
	  
	  const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn , shells_qn);
	  
	  const bool are_there_spectator_states_out = pair_out.are_there_spectator_states_determine ();	  	  	  

	  const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn , shells_qn);

	  if (n_scat_out <= n_scat_max)
	    {
	      const unsigned int bp_out = pair_out.bp_determine (shells_qn , shells_qn);

	      const int strangeness_out = pair_out.strangeness_determine ();
	
	      const unsigned int i_charge_out = pair_out.charge_index_determine ();
	
	      if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global) && (i_charge_out >= i_charge_min_global) && (i_charge_out <= i_charge_max_global) && (strangeness_out >= strangeness_min_global) && (strangeness_out <= strangeness_max_global))
		{
		  const int Jmin_out = pair_out.Jmin_determine (shells_qn , shells_qn);
		  const int Jmax_out = pair_out.Jmax_determine (shells_qn , shells_qn);

		  for (unsigned int s1 = 0 ; s1 < N_nlj ; s1++)
		    for (unsigned int s0 = 0 ; s0 <= s1 ; s0++)
		      {			 
			const class nlj_struct &shell_qn_s0 = shells_qn(s0);
			const class nlj_struct &shell_qn_s1 = shells_qn(s1);

			const enum particle_type particle_s0 = shell_qn_s0.get_particle ();	
			const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
		  
			const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);

			if (pair_in <= pair_out)
			  {			      
			    const int n_scat_in = pair_in.n_scat_determine (shells_qn , shells_qn); 

			    if (n_scat_in <= n_scat_max)
			      {
				const unsigned int bp_in = pair_in.bp_determine (shells_qn , shells_qn);

				const int strangeness_in = pair_in.strangeness_determine ();
	
				const unsigned int i_charge_in = pair_in.charge_index_determine ();
	      
				if ((bp_in == bp_out) && (strangeness_in == strangeness_out) && (i_charge_in == i_charge_out))
				  {
				    const int Jmin_in = pair_in.Jmin_determine (shells_qn , shells_qn);
				    const int Jmax_in = pair_in.Jmax_determine (shells_qn , shells_qn);
				      
				    const int Jmin_local = max (Jmin_in , Jmin_out);
				    const int Jmax_local = min (Jmax_in , Jmax_out);
				      
				    const int Jmin = max (Jmin_local , Jmin_global);
				    const int Jmax = min (Jmax_local , Jmax_global);

				    if (Jmin <= Jmax)
				      {
					const bool is_it_diagonal = (pair_in == pair_out);
			      
					const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn , shells_qn);
					const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn , shells_qn);
					  
					const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn , shells_qn);
					  
					const bool are_there_spectator_states_in = pair_in.are_there_spectator_states_determine ();

					const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn , shells_qn);

					const bool are_there_core_states = (are_there_core_states_out || are_there_core_states_in);

					const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					  
					const bool are_there_spectator_states = (are_there_spectator_states_out || are_there_spectator_states_in);

					const bool are_there_hole_states = (are_there_hole_states_out || are_there_hole_states_in);

					const bool only_hole_states = (only_hole_states_out && only_hole_states_in);
			      
					if (are_there_frozen_states || are_there_spectator_states) continue;
					  
					for (int J = Jmin ; J <= Jmax ; J++) TBMEs(J , s0 , s1 , s2 , s3) = 0.0;
					  
					if (is_hole_double_counting_suppressed && is_it_diagonal && only_hole_states) continue;

					if (are_there_core_states && !are_there_hole_states) continue;

					if (is_it_SGI) TBME_SGI_set::pp_nn_radial_integrals_calc (particles_data , inter_data , s0 , s1 , s2 , s3 , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc);

					for (int J = Jmin ; J <= Jmax ; J++)
					  {
					    const unsigned int index = TBMEs.index_determine (J , s0 , s1 , s2 , s3);
					      
					    if ((index >= first_index) && (index <= last_index))
					      {
						TBMEs(J , s0 , s1 , s2 , s3) = TBME_pp_nn (is_Coulomb_to_be_added , J , TBME_inter , inter_read , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc , radial_MSGI_OBMEs , 
											   particles_data , J_TBMEs_mixed_inter , inter_data , multipolar_expansion , s0 , s1 , s2 , s3 , lambda_Hcm); 

						//#pragma omp critical
						//cout << "id:" << THIS_PROCESS << " " << particles_data.get_nucleonic_particle () << " "
						//<< shells_qn(s0) << " " << shells_qn(s1) << " " << shells_qn(s2) << " " << shells_qn(s3) << " J:" << J << " " << TBMEs(J , s0 , s1 , s2 , s3) << endl;
					      }}}}}}}}}}}

#ifdef UseMPI
  if (is_it_MPI_parallelized) TBMEs.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) 
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << "Coupled TBMEs " << physical_space_determine (TBME_space , strangeness_max_global) << " calculated. time:" << relative_time << " s" << endl << endl;
    }

  if (is_it_copied && (THIS_PROCESS == MASTER_PROCESS)) TBMEs.copy_TBMEs_to_file (is_there_cout , n_scat_max , TBME_inter , particles_data , particles_data);
}












// Calculation of the proton-neutron (plus a few hyperons if any) two-body matrix element <s2 s3 | V | s0 s1>_J for fixed s0, s1, s2, s3 shells with the Berggren basis for a given interaction
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One sums coupled matrix elements to J of nuclear interaction and center of mass Hamiltonian if one uses the Lawson method.
// Available nuclear interaction are: Minnesota, FHT , EFT, fit (i.e. two-body matrix elements stored on file), SGI, MSGI, with or without COSM (i.e. with or without recoil),
//                                    realistic interactions, center of mass Hamiltonian Hcm, center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM)
//
// Interaction expansion means that the one-body basis used to expand the interaction is not the same as that of GSM and is of HO or GHF character.
// HO expansion is always used for Minnesota, FHT , EFT, realistic interactions, center of mass Hamiltonian Hcm,
// center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM) and Coulomb interaction.
// GHF expansion is used with the Qbox method only.
//
// The class interaction_class inter_data stores TBMEs and other data related to Hamiltonian or Coulomb interaction.
// But one calculates TBMEs of oter interactions, such as one and two body operators, center of mass operators, ...
// Hence, TBME_inter, that demanded, and inter, that of inter_data or input_data, are different in general.

TYPE coupled_TBMEs::Berggren::TBME_pn (
				       const int J ,
				       const enum interaction_type TBME_inter ,
				       const enum interaction_read_type inter_read ,
				       const class array<TYPE> &radial_SGI_TBMEs_dir , 
				       const class array<TYPE> &radial_SGI_TBMEs_exc , 
				       const class array<TYPE> &radial_MSGI_OBMEs_pp , 
				       const class array<TYPE> &radial_MSGI_OBMEs_nn , 
				       const class array<TYPE> &radial_MSGI_OBMEs_pn , 
				       const class baryons_data &prot_Y_data , 
				       const class baryons_data &neut_Y_data , 
				       const class TBMEs_class &J_TBMEs_mixed_inter , 
				       const class interaction_class &inter_data , 
				       const class multipolar_expansion_str &multipolar_expansion , 
				       const unsigned int s0 ,
				       const unsigned int s1 ,
				       const unsigned int s2 ,
				       const unsigned int s3 , 
				       const double lambda_Hcm)
{
  const class array<class spherical_state> &shells_p = prot_Y_data.get_shells ();
  const class array<class spherical_state> &shells_n = neut_Y_data.get_shells ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_prot_set = prot_Y_data.get_reduced_grad_HO_expansion_set ();
  const class OBMEs_CM_set_str &reduced_grad_HO_expansion_neut_set = neut_Y_data.get_reduced_grad_HO_expansion_set ();
  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_prot_set = prot_Y_data.get_reduced_r_HO_expansion_set ();  
  const class OBMEs_CM_set_str &reduced_r_HO_expansion_neut_set = neut_Y_data.get_reduced_r_HO_expansion_set ();

  const class array<class vector_class<complex<double> > > &overlaps_p = (inter_read != LAB_BERGGREN_TBMES_READ) ? (prot_Y_data.get_HO_overlaps ()) : (prot_Y_data.get_GHF_overlaps ());
  const class array<class vector_class<complex<double> > > &overlaps_n = (inter_read != LAB_BERGGREN_TBMES_READ) ? (neut_Y_data.get_HO_overlaps ()) : (neut_Y_data.get_GHF_overlaps ());

  switch (TBME_inter)
    {
    case MINNESOTA:      return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case MINNESOTA_COSM: return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case FHT:            return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case FHT_COSM:       return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case EFT:            return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case EFT_COSM:       return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
    case FIT:            return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);

    case REALISTIC_INTERACTION:
      {
	if (lambda_Hcm != 0.0)
	  {
	    const TYPE TBME_inter_expansion = TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);

	    const TYPE TBME_Hcm = TBME_CM_operator::Hcm::TBME_J_pn (J , s0 , s1 , s2 , s3 , shells_qn_p , shells_qn_n , 
								    reduced_grad_HO_expansion_prot_set(HCM) , reduced_grad_HO_expansion_neut_set(HCM) ,
								    reduced_r_HO_expansion_prot_set(HCM) , reduced_r_HO_expansion_neut_set(HCM));

	    const TYPE TBME = TBME_inter_expansion + lambda_Hcm*TBME_Hcm;
	    
	    return TBME;
	  }
	else
	  return TBME_inter_expansion_set::TBME_J_pn (J , s0 , s1 , s2 , s3 , overlaps_p , overlaps_n , shells_qn_p , shells_qn_n , inter_data , J_TBMEs_mixed_inter);
      }

    case SGI: return TBME_SGI_set::TBME_J_pn (false , J , s0 , s1 , s2 , s3 , shells_p , shells_n , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc , 
					      reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , inter_data , multipolar_expansion);

    case SGI_COSM: return TBME_SGI_set::TBME_J_pn (true , J , s0 , s1 , s2 , s3 , shells_p , shells_n , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc , 
						   reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , inter_data , multipolar_expansion);

    case MSGI: return TBME_MSGI_set::TBME_J_pn (false , J , s0 , s1 , s2 , s3 , shells_p , shells_n , radial_MSGI_OBMEs_pp , radial_MSGI_OBMEs_nn , radial_MSGI_OBMEs_pn , 
						reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , inter_data , multipolar_expansion);

    case MSGI_COSM: return TBME_MSGI_set::TBME_J_pn (true , J , s0 , s1 , s2 , s3 , shells_p , shells_n , radial_MSGI_OBMEs_pp , radial_MSGI_OBMEs_nn , radial_MSGI_OBMEs_pn , 
						     reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , inter_data , multipolar_expansion);

    case CM_KINETIC_INTERACTION: return TBME_CM_operator::P2_over_2M::TBME_J_pn (J , s0 , s1 , s2 , s3 , shells_qn_p , shells_qn_n , reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC));

    case HCM_INTERACTION: return TBME_CM_operator::Hcm::TBME_J_pn (J , s0 , s1 , s2 , s3 , shells_qn_p , shells_qn_n , 
								   reduced_grad_HO_expansion_prot_set(HCM) , reduced_grad_HO_expansion_neut_set(HCM) , reduced_r_HO_expansion_prot_set(HCM) , reduced_r_HO_expansion_neut_set(HCM));

    case SDI: return TBME_SDI_set::TBME_J_pn (false , J , inter_data , s0 , s1 , s2 , s3 , reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , shells_p , shells_n);
      
    case SDI_COSM: return TBME_SDI_set::TBME_J_pn (true , J , inter_data , s0 , s1 , s2 , s3 , reduced_grad_HO_expansion_prot_set(CM_KINETIC) , reduced_grad_HO_expansion_neut_set(CM_KINETIC) , shells_p , shells_n);

    default: abort_all ();
    }

  return NADA;
}















// Calculation of all proton-neutron (plus a few hyperons if any) two-body matrix elements with the Berggren basis for a given interaction
// ---------------------------------------------------------------------------------------------------------------------------------------
// If one reads two-body matrix elements from a file, it is done by the master process, which distributes data to all nodes, and one leaves the routine.
// Otherwise, initial <s2 s3 | V | s0 s1>_J in the HO/GHF basis have been calculated and stored in the interaction class with the HO/GHF expansion method.
// One then loops over all s0, s1, s2, s3 shells and total angular momentum J and one calculates directly the matrix element or one uses the <s2 s3 | V | s0 s1>_J two-body matrix elements in the HO/GHF basis with the HO/GHF expansion method.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each, which are then distributed to all nodes at the end.
// The time taken to calculate two-body matrix elements is then written on screen.
// Two-body matrix elements are copied to a file if it was demanded in the input file.
//
// Interaction expansion means that the one-body basis used to expand the interaction is not the same as that of GSM and is of HO or GHF character.
// HO expansion is always used for Minnesota, FHT , EFT, realistic interactions, center of mass Hamiltonian Hcm,
// center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM) and Coulomb interaction.
// GHF expansion is used with the Qbox method only.
//
// The class interaction_class inter_data stores TBMEs and other data related to Hamiltonian or Coulomb interaction.
// But one calculates TBMEs of other interactions, such as one and two body operators, center of mass operators, ...
// Hence, TBME_inter, that demanded, and inter, that of inter_data or input_data, are different in general.

void coupled_TBMEs::Berggren::TBMEs_pn_calc (
					     const bool is_there_cout , 
					     const bool is_it_only_basis , 
					     const enum interaction_type TBME_inter ,
					     const class input_data_str &input_data , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const bool is_there_Hcm , 
					     const class interaction_class &inter_data , 
					     class TBMEs_class &TBMEs_pn)
{
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
  
  const bool is_it_cluster_CM_HO_basis_calculation = input_data.get_is_it_cluster_CM_HO_basis_calculation ();

  const int n_scat_max = (!is_it_cluster_CM_HO_basis_calculation) ? (input_data.get_n_scat_max ()) : (0);
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const enum interaction_read_type inter_read = (TBME_inter == inter) ? (input_data.get_inter_read ()) : (NO_TBMES_READ);

  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const double jp_max = prot_Y_data.get_jmax ();
  const double jn_max = neut_Y_data.get_jmax ();
  
  const double jmax = max (jp_max , jn_max);
  
  const double lambda_Hcm = (is_there_Hcm) ? (input_data.get_lambda_Hcm ()) : (0.0);
  
  const unsigned int BPmin_global = TBMEs_pn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pn.get_BPmax_global ();
    
  const int strangeness_min_global = TBMEs_pn.get_strangeness_min_global ();
  const int strangeness_max_global = TBMEs_pn.get_strangeness_max_global ();
  
  const unsigned int i_charge_min_global = TBMEs_pn.get_i_charge_min_global ();
  const unsigned int i_charge_max_global = TBMEs_pn.get_i_charge_max_global ();
  
  const int Jmin_global = TBMEs_pn.get_Jmin_global ();
  const int Jmax_global = TBMEs_pn.get_Jmax_global ();
   
  const int lmax_multipole_expansion = inter_data.get_lmax_multipole_expansion ();
  
  const int lmax_multipole_expansion_plus_one = lmax_multipole_expansion + 1;

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab = inter_data.get_shells_inter_indices_from_nlj_indices_p_tab ();
  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_n_tab = inter_data.get_shells_inter_indices_from_nlj_indices_n_tab ();
  
  const class array<class nlj_struct> &shells_inter_qn_p = inter_data.get_shells_inter_qn ();
  const class array<class nlj_struct> &shells_inter_qn_n = inter_data.get_shells_inter_qn ();
  
  const bool is_it_mixed = is_it_baryonic_mixed_determine (TBME_inter);
  
  const bool is_it_SGI = is_it_SGI_determine (TBME_inter);

  const bool is_it_MSGI = is_it_MSGI_determine (TBME_inter);
  
  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);
  
  const bool is_it_copied = input_data.get_copy_J_OBMEs_TBMEs ();
  
  class array<TYPE> radial_MSGI_OBMEs_pp;
  class array<TYPE> radial_MSGI_OBMEs_nn;
  class array<TYPE> radial_MSGI_OBMEs_pn;

  class TBMEs_class J_TBMEs_mixed_inter;

  class multipolar_expansion_str multipolar_expansion;

  if (is_it_SGI_MSGI) multipolar_expansion.allocate_calc (jmax);

  if (is_it_mixed) 
    {
      J_TBMEs_mixed_inter.allocate (is_there_cout , is_it_only_basis , input_data , prot_Y_data , neut_Y_data , TBME_inter , shells_inter_qn_p , shells_inter_qn_n , shells_inter_indices_from_nlj_indices_p_tab , shells_inter_indices_from_nlj_indices_n_tab );

      TBME_inter_expansion_set::J_TBMEs_mixed_inter_pn_calc (is_there_cout , inter_read , prot_Y_data , neut_Y_data , n_scat_max , inter_data , J_TBMEs_mixed_inter);
    }

  if (is_it_MSGI)
    {
      radial_MSGI_OBMEs_pp.allocate (Np_nlj , Np_nlj);
      radial_MSGI_OBMEs_nn.allocate (Nn_nlj , Nn_nlj);
      radial_MSGI_OBMEs_pn.allocate (Np_nlj , Nn_nlj);

      TBME_MSGI_set::pp_nn_radial_integral_calc (prot_Y_data , inter_data , radial_MSGI_OBMEs_pp);
      TBME_MSGI_set::pp_nn_radial_integral_calc (neut_Y_data , inter_data , radial_MSGI_OBMEs_nn);
      
      TBME_MSGI_set::pn_radial_integral_calc (prot_Y_data , neut_Y_data , inter_data , radial_MSGI_OBMEs_pn);
    }

  const unsigned int first_index = TBMEs_pn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = TBMEs_pn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
    {
      class array<TYPE> radial_SGI_TBMEs_dir;
      class array<TYPE> radial_SGI_TBMEs_exc;

      if (is_it_SGI)
	{
	  radial_SGI_TBMEs_dir.allocate (lmax_multipole_expansion_plus_one);
	  radial_SGI_TBMEs_exc.allocate (lmax_multipole_expansion_plus_one);
	}

      for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
	{
	  const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);
	  const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);

	  const enum particle_type particle_s2 = shell_qn_s2.get_particle ();	
	  const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
	  
	  const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);

	  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

	  const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_n);
	  const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
	  
	  const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
	  
	  const bool are_there_spectator_states_out = pair_out.are_there_spectator_states_determine ();
	  
	  const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_n);

	  if (n_scat_out <= n_scat_max)
	    {
	      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

	      const int strangeness_out = pair_out.strangeness_determine ();
	
	      const unsigned int i_charge_out = pair_out.charge_index_determine ();
	      
	      if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global) && (i_charge_out >= i_charge_min_global) && (i_charge_out <= i_charge_max_global) && (strangeness_out >= strangeness_min_global) && (strangeness_out <= strangeness_max_global))
		{
		  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
		  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

		  for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
		    for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
		      {
			const class nlj_struct &shell_qn_s0 = shells_qn_p(s0);
			const class nlj_struct &shell_qn_s1 = shells_qn_n(s1);

			const enum particle_type particle_s0 = shell_qn_s0.get_particle ();	
			const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
		  
			const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);

			if (pair_in <= pair_out)
			  {
			    const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

			    if (n_scat_in <= n_scat_max)
			      { 
				const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);  

				const int strangeness_in = pair_in.strangeness_determine ();
	
				const unsigned int i_charge_in = pair_in.charge_index_determine ();
	      
				if ((bp_in == bp_out) && (strangeness_in == strangeness_out) && (i_charge_in == i_charge_out))
				  {
				    const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
				    const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);
				      
				    const int Jmin_local = max (Jmin_in , Jmin_out);
				    const int Jmax_local = min (Jmax_in , Jmax_out);
				      
				    const int Jmin = max (Jmin_local , Jmin_global);
				    const int Jmax = min (Jmax_local , Jmax_global);

				    if (Jmin <= Jmax)
				      {
					const bool is_it_diagonal = (pair_in == pair_out);
			      
					const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_n);
					const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
					  
					const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
					  
					const bool are_there_spectator_states_in = pair_in.are_there_spectator_states_determine ();
					  
					const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_n);

					const bool are_there_core_states = (are_there_core_states_out || are_there_core_states_in);
					const bool are_there_hole_states = (are_there_hole_states_out || are_there_hole_states_in);
					  
					const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					  
					const bool are_there_spectator_states = (are_there_spectator_states_out || are_there_spectator_states_in);
					  
					const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

					if (are_there_frozen_states || are_there_spectator_states) continue;
			      
					for (int J = Jmin ; J <= Jmax ; J++) TBMEs_pn(J , s0 , s1 , s2 , s3) = 0.0;
					  					  
					if (is_hole_double_counting_suppressed && is_it_diagonal && only_hole_states) continue;
					  
					if (are_there_core_states && !are_there_hole_states) continue;
					  
					if (is_it_SGI) TBME_SGI_set::pn_radial_integrals_calc (prot_Y_data , neut_Y_data , inter_data , s0 , s1 , s2 , s3 , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc);

					for (int J = Jmin ; J <= Jmax ; J++)
					  {
					    const unsigned int index = TBMEs_pn.index_determine (J , s0 , s1 , s2 , s3);
					      
					    if ((index >= first_index) && (index <= last_index))
					      {
						TBMEs_pn(J , s0 , s1 , s2 , s3) = TBME_pn (J , TBME_inter , inter_read , radial_SGI_TBMEs_dir , radial_SGI_TBMEs_exc , radial_MSGI_OBMEs_pp , radial_MSGI_OBMEs_nn , radial_MSGI_OBMEs_pn , 
											   prot_Y_data , neut_Y_data , J_TBMEs_mixed_inter , inter_data , multipolar_expansion , s0 , s1 , s2 , s3 , lambda_Hcm);

						//cout << "pn " << shells_qn_p(s0) << " " << shells_qn_n(s1) << " " << shells_qn_p(s2) << " " << shells_qn_n(s3) << " J:" << J << " " << TBMEs_pn(J , s0 , s1 , s2 , s3) << endl;
					      }}}}}}}}}}}

#ifdef UseMPI
  if (is_it_MPI_parallelized) TBMEs_pn.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) 
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << "Coupled TBMEs " << physical_space_determine (PROT_NEUT_Y , strangeness_max_global) << " calculated. time:" << relative_time << " s" << endl << endl;
    }

  if (is_it_copied && (THIS_PROCESS == MASTER_PROCESS)) TBMEs_pn.copy_TBMEs_to_file (is_there_cout , n_scat_max , TBME_inter , prot_Y_data , neut_Y_data);
}









// Calculation of all pp-nn conversion two-body matrix elements with the Berggren basis for a given interaction
// ------------------------------------------------------------------------------------------------------------
// pp-nn conversion TBMEs consist of TBMEs where baryons can be converted : proton/Xi- to Lambda/Lambda for example. 
// If one reads two-body matrix elements from a file, it is done by the master process, which distributes data to all nodes, and one leaves the routine.
// Otherwise, initial <s2 s3 | V | s0 s1>_J in the HO/GHF basis have been calculated and stored in the interaction class with the HO/GHF expansion method.
// One then loops over all s0, s1, s2, s3 shells and total angular momentum J and one calculates directly the matrix element or one uses the <s2 s3 | V | s0 s1>_J two-body matrix elements in the HO/GHF basis with the HO/GHF expansion method.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each, which are then distributed to all nodes at the end.
// The time taken to calculate two-body matrix elements is then written on screen.
// Two-body matrix elements are copied to a file if it was demanded in the input file.
//
// Interaction expansion means that the one-body basis used to expand the interaction is not the same as that of GSM and is of HO or GHF character.
// HO expansion is always used for Minnesota, FHT , EFT, realistic interactions, center of mass Hamiltonian Hcm,
// center of mass kinetic Hamiltonian P^2/2M (realistic) or pi.pj/2Mcore (COSM) and Coulomb interaction.
// GHF expansion is used with the Qbox method only.
//
// The class interaction_class inter_data stores TBMEs and other data related to Hamiltonian or Coulomb interaction.
// But one calculates TBMEs of other interactions, such as one and two body operators, center of mass operators, ...
// Hence, TBME_inter, that demanded, and inter, that of inter_data or input_data, are different in general.

void coupled_TBMEs::Berggren::TBMEs_cv_calc (
					     const bool is_there_cout , 
					     const enum interaction_type TBME_inter ,
					     const class input_data_str &input_data , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data ,
					     const class interaction_class &inter_data , 
					     class TBMEs_class &TBMEs_cv)
{
  const bool is_cv_possible = input_data.get_is_cv_possible ();

  if (!is_cv_possible) return;
  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) ? (absolute_time_determine ()) : (NADA);

  const bool is_hole_double_counting_suppressed = input_data.get_is_hole_double_counting_suppressed ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const enum interaction_read_type inter_read = (TBME_inter == inter) ? (input_data.get_inter_read ()) : (NO_TBMES_READ);

  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
      
  const unsigned int BPmin_global = TBMEs_cv.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_cv.get_BPmax_global ();
    
  const int strangeness_min_global = TBMEs_cv.get_strangeness_min_global ();
  const int strangeness_max_global = TBMEs_cv.get_strangeness_max_global ();

  if (strangeness_max_global == 0) return;
  
  const unsigned int i_charge_min_global = TBMEs_cv.get_i_charge_min_global ();
  const unsigned int i_charge_max_global = TBMEs_cv.get_i_charge_max_global ();
  
  const int Jmin_global = TBMEs_cv.get_Jmin_global ();
  const int Jmax_global = TBMEs_cv.get_Jmax_global ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array<class array<unsigned int> > &shells_inter_indices_from_nlj_indices_p_tab = inter_data.get_shells_inter_indices_from_nlj_indices_p_tab ();
  
  const class array<class nlj_struct> &shells_inter_qn_p = inter_data.get_shells_inter_qn ();
  
  const bool is_it_mixed = is_it_baryonic_mixed_determine (TBME_inter);

  if (!is_it_mixed) return;

  const bool is_it_copied = input_data.get_copy_J_OBMEs_TBMEs ();
  
  const class array<class vector_class<complex<double> > > &overlaps_p = (inter_read != LAB_BERGGREN_TBMES_READ) ? (prot_Y_data.get_HO_overlaps ()) : (prot_Y_data.get_GHF_overlaps ());
  
  class TBMEs_class J_TBMEs_mixed_inter(is_there_cout , true , input_data , neut_Y_data , TBME_inter , shells_inter_qn_p , shells_inter_indices_from_nlj_indices_p_tab);

  TBME_inter_expansion_set::J_TBMEs_mixed_inter_pn_calc (is_there_cout , inter_read , prot_Y_data , neut_Y_data , n_scat_max , inter_data , J_TBMEs_mixed_inter);

  const unsigned int first_index = TBMEs_cv.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = TBMEs_cv.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s2 = 0 ; s2 < Nn_nlj ; s2++)
    for (unsigned int s3 = 0 ; s2 <= s3 ; s3++)
      {
	const class nlj_struct &shell_qn_s2 = shells_qn_n(s2);
	const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);

	const enum particle_type particle_s2 = shell_qn_s2.get_particle ();	
	const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
	  
	const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);

	const int n_scat_out = pair_out.n_scat_determine (shells_qn_n , shells_qn_n);

	const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_n , shells_qn_n);
	const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_n , shells_qn_n);
	  
	const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_n , shells_qn_n);
	
	const bool are_there_spectator_states_out = pair_out.are_there_spectator_states_determine ();
	  
	const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_n , shells_qn_n);

	if (n_scat_out <= n_scat_max)
	  {
	    const unsigned int bp_out = pair_out.bp_determine (shells_qn_n , shells_qn_n);

	    const int strangeness_out = pair_out.strangeness_determine ();
	
	    const unsigned int i_charge_out = pair_out.charge_index_determine ();
	      
	    if ((bp_out >= BPmin_global) && (bp_out <= BPmax_global) && (i_charge_out >= i_charge_min_global) && (i_charge_out <= i_charge_max_global) && (strangeness_out >= strangeness_min_global) && (strangeness_out <= strangeness_max_global))
	      {
		const int Jmin_out = pair_out.Jmin_determine (shells_qn_n , shells_qn_n);
		const int Jmax_out = pair_out.Jmax_determine (shells_qn_n , shells_qn_n);

		for (unsigned int s1 = 0 ; s1 < Np_nlj ; s1++)
		  for (unsigned int s0 = 0 ; s0 <= s1 ; s0++)
		    {
		      const class nlj_struct &shell_qn_s0 = shells_qn_p(s0);
		      const class nlj_struct &shell_qn_s1 = shells_qn_p(s1);

		      const enum particle_type particle_s0 = shell_qn_s0.get_particle ();	
		      const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
		  
		      const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);

		      const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_p);

		      if (n_scat_in <= n_scat_max)
			{ 
			  const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_p);  

			  const int strangeness_in = pair_in.strangeness_determine ();
	
			  const unsigned int i_charge_in = pair_in.charge_index_determine ();
	      
			  if ((bp_in == bp_out) && (strangeness_in == strangeness_out) && (i_charge_in == i_charge_out))
			    {
			      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_p);
			      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_p);
				      
			      const int Jmin_local = max (Jmin_in , Jmin_out);
			      const int Jmax_local = min (Jmax_in , Jmax_out);
				      
			      const int Jmin = max (Jmin_local , Jmin_global);
			      const int Jmax = min (Jmax_local , Jmax_global);

			      if (Jmin <= Jmax)
				{
				  const bool is_it_diagonal = (pair_in == pair_out);
			      
				  const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_p);
				  const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_p);
					  
				  const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_p);
					  
				  const bool are_there_spectator_states_in = pair_in.are_there_spectator_states_determine ();
					  
				  const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_p);

				  const bool are_there_core_states = (are_there_core_states_out || are_there_core_states_in);
				  const bool are_there_hole_states = (are_there_hole_states_out || are_there_hole_states_in);
					  
				  const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					  
				  const bool are_there_spectator_states = (are_there_spectator_states_out || are_there_spectator_states_in);
					  
				  const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

				  if (are_there_frozen_states || are_there_spectator_states) continue;
			      
				  for (int J = Jmin ; J <= Jmax ; J++) TBMEs_cv(J , s0 , s1 , s2 , s3) = 0.0;
					  					  
				  if (is_hole_double_counting_suppressed && is_it_diagonal && only_hole_states) continue;
					  
				  if (are_there_core_states && !are_there_hole_states) continue;

				  for (int J = Jmin ; J <= Jmax ; J++)
				    {
				      const unsigned int index = TBMEs_cv.index_determine (J , s0 , s1 , s2 , s3);
					      
				      if ((index >= first_index) && (index <= last_index))
					{
					  TBMEs_cv(J , s0 , s1 , s2 , s3) = TBME_inter_expansion_set::TBME_J_cv (J , s0 , s1 , s2 , s3 , overlaps_p , shells_qn_p , inter_data , J_TBMEs_mixed_inter);

					  //cout << "cv " << shells_qn_n(s0) << " " << shells_qn_n(s1) << " " << shells_qn_p(s2) << " " << shells_qn_p(s3) << " J:" << J << " " << TBMEs_cv(J , s0 , s1 , s2 , s3) << endl;
					}}}}}}}}}
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) TBMEs_cv.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout) 
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << "Coupled TBMEs " << PROT_NEUT_UNMIXED_Y << " calculated. time:" << relative_time << " s" << endl << endl;
    }

  if (is_it_copied && (THIS_PROCESS == MASTER_PROCESS)) TBMEs_cv.copy_TBMEs_to_file (is_there_cout , n_scat_max , TBME_inter , prot_Y_data , neut_Y_data);
}






