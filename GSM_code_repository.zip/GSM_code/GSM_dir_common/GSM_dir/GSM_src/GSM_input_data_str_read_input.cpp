#include "../GSM_include/GSM_include_def_common.h"

using namespace string_routines;
using namespace inputs_misc;

extern enum called_code_type called_code;

// TYPE is double or complex
// -------------------------

// The data of the input file are read in these routines.
//-------------------------------------------------------

// As they are associated with explaining strings in the input file, no detailed comments are written here. See input_data_str.h for information about its data.
// -------------------------------------------------------------------------------------------------------------------------------------------------------------





void input_data_str::core_data_read_calc ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::core_data_read_calc");	

  switch (inter)
    {
    case REALISTIC_INTERACTION:
      {
	A_core = Z_core = N_core = 0;

	frozen_core_mass = 0.0;
      } break;

    default:
      {
	cin >> frozen_core_mass;
	word_check_print<double> ("amu(frozen.core.mass)" , frozen_core_mass);

	if (frozen_core_mass <= 0) error_message_print_abort ("Frozen core mass must be positive");	
	
	cin >> A_core;
	word_check_print<int> ("(A.core)" , A_core);
	
	cin >> Z_core;
	word_check_print<int> ("(Z.core)" , Z_core);

	N_core = A_core - Z_core;

	nucleus_mass_basis = nucleus_mass = frozen_core_mass;
	
	if (A_core <= 0) error_message_print_abort ("A[core] must be positive");
	
	if (Z_core < 0) error_message_print_abort ("Z[core] must be positive or zero");
	if (N_core < 0) error_message_print_abort ("N[core] must be positive or zero");
	
      } break;    
    }

  cout << endl;
}







void input_data_str::particles_number_charges_masses_alloc_read_calc ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::particles_number_charges_masses_alloc_read_calc");	
      
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  double &prot_mass_for_calc = effective_masses_for_calc_p(prot_index);
  double &neut_mass_for_calc = effective_masses_for_calc_n(neut_index);
      
  if (!only_dimensions && !non_zero_NBMEs_proportion_only)
    {	  
      if ((basis_space != NEUT_Y_ONLY) && (basis_space != NEUT_ONLY))
	{
	  cin >> prot_mass_for_calc;
	  
	  word_check_print<double> ("amu(proton.mass)" , prot_mass_for_calc);

	  if (proton_mass <= 0) error_message_print_abort ("proton.mass must be positive");
 
	  cout << "h^2/2m[p]:" << 1.0/two_amu_over_hbar_square/proton_mass << " MeV fm^2" << endl;
	}

      if ((basis_space != PROT_Y_ONLY) && (basis_space != PROT_ONLY))
	{
	  cin >> neut_mass_for_calc;
	  
	  word_check_print<double> ("amu(neutron.mass)" , neut_mass_for_calc);

	  if (neut_mass_for_calc <= 0) error_message_print_abort ("neutron.mass must be positive");
      
	  cout << "h^2/2m[n]:" << 1.0/two_amu_over_hbar_square/neut_mass_for_calc << " MeV fm^2" << endl;
	}
      
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);

	  const string hyperon_str = make_string<enum particle_type> (hyperon);
	  
	  const unsigned int hyperon_index = charge_baryon_index_determine (hyperon);
      
	  const int Y_charge = particle_charge_determine (hyperon);

	  double &hyperon_mass = (Y_charge != 0) ? (effective_masses_for_calc_p(hyperon_index)) : (effective_masses_for_calc_n(hyperon_index));

	  cin >> hyperon_mass;
	  
	  word_check_print<double> ("amu(" + hyperon_str + ".mass)" , hyperon_mass);
      
	  cout << "h^2/2m[" + hyperon_str + "]:" << 1.0/two_amu_over_hbar_square/hyperon_mass << " MeV fm^2" << endl;	  
	}
      
      if ((basis_space == PROT_Y_ONLY) || (basis_space == PROT_ONLY)) effective_masses_for_calc_n = prot_mass_for_calc;
      if ((basis_space == NEUT_Y_ONLY) || (basis_space == NEUT_ONLY)) effective_masses_for_calc_p = neut_mass_for_calc;
    }
  
  ZY_charge_pos = 0;
  ZY_charge_neg = 0;

  ZY_charge_basis_potential_pos = 0;
  ZY_charge_basis_potential_neg = 0;
  
  Z = Z_core + Zval;
  N = N_core + Nval;

  A = Z_core + N_core + ZYval + NYval;

  Z_basis = Z_core + Zval_basis;
  N_basis = N_core + Nval_basis;

  A_basis = Z_basis + N_basis;

  if (are_there_hyperons)
    {
      cin >> total_nucleus_mass;
      
      word_check_print<double> ("amu(hypernucleus.reference.mass)" , total_nucleus_mass);
    }
  else
    total_nucleus_mass = N*neut_mass_for_calc + Z*prot_mass_for_calc;    
      
  if (inter == REALISTIC_INTERACTION)
    {
      nucleus_mass = total_nucleus_mass;

      if (is_Coulomb_Hamiltonian_here)
	{
	  ZY_charge_pos = Z - 1;
	  ZY_charge_neg = Z + 1;
	  
	  ZY_charge_basis_potential_pos = (Z_basis > 0) ? (Z_basis - 1) : (0);
	  ZY_charge_basis_potential_neg = (Z_basis > 0) ? (Z_basis + 1) : (0);	  
	}

      nucleus_mass_basis = Nval_basis*neut_mass_for_calc + Zval_basis*prot_mass_for_calc;
    }
  else
    {
      const bool is_it_COSM = is_it_COSM_determine (inter);

      if (is_Coulomb_Hamiltonian_here)
	{
	  ZY_charge_pos = (Zval > 0) ? (Z_core + Zval - 1) : (Z_core);
	  ZY_charge_neg = (Zval > 0) ? (Z_core + Zval + 1) : (Z_core);
	  
	  ZY_charge_basis_potential_pos = (Zval_basis > 0) ? (Z_core + Zval_basis - 1) : (Z_core);
	  ZY_charge_basis_potential_neg = (Zval_basis > 0) ? (Z_core + Zval_basis + 1) : (Z_core);
	}

      if (is_it_COSM)
	nucleus_mass_basis = nucleus_mass = frozen_core_mass;
      else
	{
	  nucleus_mass = total_nucleus_mass;

	  const int Z_basis = Z_core + Zval_basis;
	  const int N_basis = N_core + Nval_basis;
	  
	  nucleus_mass_basis = N_basis*neut_mass_for_calc + Z_basis*prot_mass_for_calc;
	}
    }

  cout << endl;
}


void input_data_str::radial_data_read_calc ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::radial_data_read_calc");		
  
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && (basis_potential != HO_POTENTIAL))
    {
      //--// collecting of several parameters to delimitate the integration limits 
      cin >> R;
      word_check_print<double> ("fm(rotation-point)" , R);

      if (R <= 0) error_message_print_abort ("R must be positive");
      
      cin >> R_real_max;
      word_check_print<double> ("fm(real.maximal.radius)" , R_real_max);

      if (R_real_max <= R) error_message_print_abort ("real.maximal.radius must be larger than R");
      
      cin >> N_bef_R_GL;
      word_check_print<unsigned int> ("points.before.R(Gauss.Legendre)" , N_bef_R_GL);

      if (N_bef_R_GL == 0) error_message_print_abort ("The number of Gauss-Legendre points before R cannot be equal to zero");
      
      cin >> N_aft_R_GL;
      word_check_print<unsigned int> ("points.after.R(Gauss.Legendre)" , N_aft_R_GL);

      if (N_aft_R_GL == 0) error_message_print_abort ("The number of Gauss-Legendre points after R cannot be equal to zero");
      
      cin >> N_bef_R_uniform;
      word_check_print<unsigned int> ("points.before.R(uniform)" , N_bef_R_uniform);

      if (N_bef_R_uniform == 0) error_message_print_abort ("The number of uniformly distributed points before R cannot be equal to zero");
      
      cin >> N_aft_R_uniform;
      word_check_print<unsigned int> ("points.after.R(uniform)" , N_aft_R_uniform);
      
      if (N_aft_R_uniform == 0) error_message_print_abort ("The number of uniformly distributed points after R cannot be equal to zero");
    }
  else
    {
      R = 20;      

      R_real_max = 100.0;

      N_bef_R_GL = N_aft_R_GL = 100;

      N_bef_R_uniform = N_aft_R_uniform = 500;
    }
      
  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);

  const bool are_there_protons = ((basis_space != NEUT_Y_ONLY) || (space != NEUT_Y_ONLY));
  
  const bool is_it_deuteron_relative = ((called_code == TWO_PARTICLE_RELATIVE_CODE) && (ZYval == 1) && (NYval == 1));

  const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
  
  if (are_there_protons && !only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3 && !is_it_deuteron_relative && ((basis_potential != HO_POTENTIAL) || (inter != REALISTIC_INTERACTION)) )
    {
      //--// Reads the charge radius defining the Coulomb potential of the core
      cin >> R_charge;
      word_check_print<double> ("fm(charge.radius)" , R_charge);
      
      if (R_charge <= 0) error_message_print_abort ("The charge radius must be positive");	
    }

  if (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3)
    {
      //--// Parameters for the Fermi function
      cin >> R_cut_function;
      word_check_print<double> ("fm(cut.function.radius)" , R_cut_function);
  
      if (R_cut_function > R) error_message_print_abort ("cut.function.radius must be smaller than R");
  
      cin >> d_cut_function;
      word_check_print<double> ("fm(cut.function.diffuseness)" , d_cut_function);
  
      if (d_cut_function <= 0) error_message_print_abort ("cut.function.diffuseness must be positive");
    }
   
  cout << endl;
}



void input_data_str::momentum_data_read_calc ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::momentum_data_read_calc");		
  
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && (basis_potential != HO_POTENTIAL))
    {
      cin >> kmax_momentum;      
      word_check_print<double> ("fm^(-1)(k.max.momentum.space)" , kmax_momentum);
      
      if (kmax_momentum <= 0) error_message_print_abort ("k.max.momentum.space must be positive");
      
      cin >> R_Fermi_momentum;      
      word_check_print<double> ("fm(R.Fermi.function.momentum.space)" , R_Fermi_momentum);
	  
      if (R_Fermi_momentum <= 0) error_message_print_abort ("R.Fermi.function.momentum.space must be positive");
	  
      cin >> Nk_momentum_GL;
      word_check_print<unsigned int> ("points.before.k.max.momentum.space(Gauss.Legendre)" , Nk_momentum_GL);
      
      if (Nk_momentum_GL == 0) error_message_print_abort ("The number of Gauss-Legendre points in momentum space must be positive");
      
      cin >> Nk_momentum_uniform;
      word_check_print<unsigned int> ("points.before.k.max.momentum.space(uniform)" , Nk_momentum_uniform);
	  
      if (Nk_momentum_uniform == 0) error_message_print_abort ("The number of uniformly distributed points in momentum space must be positive");
    }
  else
    {
      kmax_momentum = 5.0;
      
      R_Fermi_momentum = R;

      Nk_momentum_GL = 100;

      Nk_momentum_uniform = 500;
    }
      
  step_momentum_uniform = kmax_momentum/static_cast<double> (Nk_momentum_uniform - 1);

  cout << endl;
}







void input_data_str::basis_interaction_parameters_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::basis_interaction_parameters_alloc_read");
  
  if ((called_code == OPTIMIZATION_CODE) || (Np_nlj_baryon_tab.max () > 0) || (Nn_nlj_baryon_tab.max () > 0))
    {
      const int lmax_all = max (lmax_p , lmax_n);
      
      cin >> lmax_for_basis_interaction;
      
      if (lmax_for_basis_interaction < 0) error_message_print_abort ("lmax.for.interaction (basis) must be positive or zero");
	  
      if (lmax_for_basis_interaction > lmax_all) error_message_print_abort ("lmax.for.interaction (basis) cannot be larger than lmax");
      
      word_check_print<int> ("(lmax.for.interaction)" , lmax_for_basis_interaction);
    }
  else
    lmax_for_basis_interaction = 0;

  const int Jmin = Jmin_global_determine (true);
  const int Jmax = Jmax_global_determine (true);
  
  const int Jmin_opp = Jmin_global_opp_determine (true);
  const int Jmax_opp = Jmax_global_opp_determine (true);

  const int Jmax_plus_one = Jmax + 1;
  
  V_Gaussian_consts_basis.allocate (2 , Jmax_plus_one , 2);
  
  V_Gaussian_consts_basis = 1.0;

  cout << endl;

  R0_inter_basis = 1.27*cbrt (A); // default value
    
  switch (inter)
    {
    case SDI:      SDI_data_read (a_basis , b_basis , R0_inter_basis , V_SDI_basis); break;
    case SDI_COSM: SDI_data_read (a_basis , b_basis , R0_inter_basis , V_SDI_basis); break;

    case REALISTIC_INTERACTION: break;
      
    case SGI:       SGI_MSGI_data_read (basis_space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter_basis , mu_basis , V_Gaussian_consts_basis); break;
    case SGI_COSM:  SGI_MSGI_data_read (basis_space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter_basis , mu_basis , V_Gaussian_consts_basis); break;
    case MSGI:      SGI_MSGI_data_read (basis_space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter_basis , mu_basis , V_Gaussian_consts_basis); break;
    case MSGI_COSM: SGI_MSGI_data_read (basis_space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter_basis , mu_basis , V_Gaussian_consts_basis); break;
      
    case MINNESOTA:      Minnesota_data_read (basis_space , V0_Minnesota_basis , rho_Minnesota_basis , u_Minnesota_basis , nu_three_body_like_basis , V_three_body_like_basis , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts_basis); break;
    case MINNESOTA_COSM: Minnesota_data_read (basis_space , V0_Minnesota_basis , rho_Minnesota_basis , u_Minnesota_basis , nu_three_body_like_basis , V_three_body_like_basis , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts_basis); break;

    case FHT: FHT_read (basis_space ,
			are_there_hyperons ,
			V0_ctr_ot_basis ,
			V0_ctr_et_basis ,
			V0_ctr_os_basis ,
			V0_ctr_es_basis ,
			V0_so_ot_basis ,
			V0_so_et_basis ,
			V0_t_ot_basis ,
			V0_t_et_basis ,
			V0_ALS_basis ,
			V8a_SU3f_basis ,
			V8s_SU3f_basis ,
			V10_SU3f_basis ,
			V1_SU3f_basis , 
			Jmin ,
			Jmax ,
			Jmin_opp ,
			Jmax_opp ,
			V_Gaussian_consts_basis); break;
      
    case FHT_COSM: FHT_read (basis_space ,
			     are_there_hyperons ,
			     V0_ctr_ot_basis ,
			     V0_ctr_et_basis ,
			     V0_ctr_os_basis ,
			     V0_ctr_es_basis ,
			     V0_so_ot_basis ,
			     V0_so_et_basis ,
			     V0_t_ot_basis ,
			     V0_t_et_basis ,
			     V0_ALS_basis ,
			     V8a_SU3f_basis ,
			     V8s_SU3f_basis ,
			     V10_SU3f_basis ,
			     V1_SU3f_basis , 
			     Jmin ,
			     Jmax ,
			     Jmin_opp ,
			     Jmax_opp ,
			     V_Gaussian_consts_basis); break;
      
    case EFT: EFT_read (basis_space ,
			are_there_hyperons ,
			VS_const_LO_T0_basis ,
			VS_const_LO_T1_basis ,
			VT_sigma_product_LO_T0_basis ,
			VT_sigma_product_LO_T1_basis ,
			V1_q2_NLO_basis ,
			V2_k2_NLO_basis ,
			V3_q2_sigma_product_NLO_basis ,
			V4_k2_sigma_product_NLO_basis ,
			V5_sigma_q_vector_k_NLO_basis ,
			V6_sigma_q_product_NLO_basis ,
			V7_sigma_k_product_NLO_basis ,
			V8_sigma_q_vector_k_NLO_basis ,
			V8a_SU3f_basis ,
			V8s_SU3f_basis ,
			V10_SU3f_basis ,
			V1_SU3f_basis); break;
	
    case EFT_COSM: EFT_read (basis_space ,
			     are_there_hyperons ,
			     VS_const_LO_T0_basis ,
			     VS_const_LO_T1_basis ,
			     VT_sigma_product_LO_T0_basis ,
			     VT_sigma_product_LO_T1_basis ,
			     V1_q2_NLO_basis ,
			     V2_k2_NLO_basis ,
			     V3_q2_sigma_product_NLO_basis ,
			     V4_k2_sigma_product_NLO_basis ,
			     V5_sigma_q_vector_k_NLO_basis ,
			     V6_sigma_q_product_NLO_basis ,
			     V7_sigma_k_product_NLO_basis ,
			     V8_sigma_q_vector_k_NLO_basis ,
			     V8a_SU3f_basis ,
			     V8s_SU3f_basis ,
			     V10_SU3f_basis ,
			     V1_SU3f_basis); break;
            
    default: break;
    }
  
  are_R0_values_consistent (true);
  
  cout << endl;
}








void input_data_str::interaction_parameters_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::interaction_parameters_alloc_read");
  
  if ((called_code == OPTIMIZATION_CODE) || (Np_nlj_baryon_tab.max () > 0) || (Nn_nlj_baryon_tab.max () > 0))
    {
      const int lmax_all = max (lmax_p , lmax_n);
  
      cin >> lmax_for_interaction;

      if (lmax_for_interaction < 0) error_message_print_abort ("lmax.for.interaction must be positive or zero");
            
      if (lmax_for_interaction > lmax_all) error_message_print_abort ("lmax.for.interaction cannot be larger than lmax");
            
      word_check_print<int> ("(lmax.for.interaction)" , lmax_for_interaction);
    }
  else
    lmax_for_interaction = 0;

  const int Jmin = Jmin_global_determine (false);
  const int Jmax = Jmax_global_determine (false);
  
  const int Jmin_opp = Jmin_global_opp_determine (false);
  const int Jmax_opp = Jmax_global_opp_determine (false);

  const int Jmax_plus_one = Jmax + 1;
  
  V_Gaussian_consts.allocate (2 , Jmax_plus_one , 2);
  
  V_Gaussian_consts = 1.0;

  cout << endl;
  
  R0_inter = 1.27*cbrt (A); // default value
  
  switch (inter)
    {
    case SDI:      SDI_data_read (a , b , R0_inter , V_SDI); break;
    case SDI_COSM: SDI_data_read (a , b , R0_inter , V_SDI); break;

    case REALISTIC_INTERACTION: break;
      
    case SGI:       SGI_MSGI_data_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter , mu , V_Gaussian_consts); break;
    case SGI_COSM:  SGI_MSGI_data_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter , mu , V_Gaussian_consts); break;
    case MSGI:      SGI_MSGI_data_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter , mu , V_Gaussian_consts); break;
    case MSGI_COSM: SGI_MSGI_data_read (space , Jmin , Jmax , Jmin_opp , Jmax_opp , R0_inter , mu , V_Gaussian_consts); break;

    case MINNESOTA:      Minnesota_data_read (space , V0_Minnesota , rho_Minnesota , u_Minnesota , nu_three_body_like , V_three_body_like , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts); break;
    case MINNESOTA_COSM: Minnesota_data_read (space , V0_Minnesota , rho_Minnesota , u_Minnesota , nu_three_body_like , V_three_body_like , Jmin , Jmax , Jmin_opp , Jmax_opp , V_Gaussian_consts); break;

    case FHT: FHT_read (space ,
			are_there_hyperons ,
			V0_ctr_ot ,
			V0_ctr_et ,
			V0_ctr_os ,
			V0_ctr_es ,
			V0_so_ot ,
			V0_so_et ,
			V0_t_ot ,
			V0_t_et ,
			V0_ALS ,
			V8a_SU3f ,
			V8s_SU3f ,
			V10_SU3f ,
			V1_SU3f , 
			Jmin ,
			Jmax ,
			Jmin_opp ,
			Jmax_opp ,
			V_Gaussian_consts); break;
      
    case FHT_COSM: FHT_read (space ,
			     are_there_hyperons ,
			     V0_ctr_ot ,
			     V0_ctr_et ,
			     V0_ctr_os ,
			     V0_ctr_es ,
			     V0_so_ot ,
			     V0_so_et ,
			     V0_t_ot ,
			     V0_t_et ,
			     V0_ALS,
			     V8a_SU3f ,
			     V8s_SU3f ,
			     V10_SU3f ,
			     V1_SU3f , 
			     Jmin ,
			     Jmax ,
			     Jmin_opp ,
			     Jmax_opp ,
			     V_Gaussian_consts ); break;
      
    case EFT: EFT_read (space ,
			are_there_hyperons ,
			VS_const_LO_T0 ,
			VS_const_LO_T1 ,
			VT_sigma_product_LO_T0 ,
			VT_sigma_product_LO_T1 ,
			V1_q2_NLO ,
			V2_k2_NLO ,
			V3_q2_sigma_product_NLO ,
			V4_k2_sigma_product_NLO ,
			V5_sigma_q_vector_k_NLO ,
			V6_sigma_q_product_NLO ,
			V7_sigma_k_product_NLO ,
			V8_sigma_q_vector_k_NLO ,
			V8a_SU3f ,
			V8s_SU3f ,
			V10_SU3f ,
			V1_SU3f); break;
	
    case EFT_COSM: EFT_read (space ,
			     are_there_hyperons ,
			     VS_const_LO_T0 ,
			     VS_const_LO_T1 ,
			     VT_sigma_product_LO_T0 ,
			     VT_sigma_product_LO_T1 ,
			     V1_q2_NLO ,
			     V2_k2_NLO ,
			     V3_q2_sigma_product_NLO ,
			     V4_k2_sigma_product_NLO ,
			     V5_sigma_q_vector_k_NLO ,
			     V6_sigma_q_product_NLO ,
			     V7_sigma_k_product_NLO ,
			     V8_sigma_q_vector_k_NLO ,
			     V8a_SU3f ,
			     V8s_SU3f ,
			     V10_SU3f ,
			     V1_SU3f); break;
            
    default: break;
    }

  are_R0_values_consistent (false);
}








void input_data_str::HO_GHF_expansion_parameters_alloc_read ()
{
  const int lmax_all = max (lmax_p , lmax_n);
  
  const int lmax_all_plus_one = lmax_all + 1;
  
  nmax_HO_lab_tab.allocate (lmax_all_plus_one);

  nmax_HO_lab_tab = 0;
  
  word_check ("HO.expansion");
  
  cin >> b_lab;
  
  word_check_print<double> ("fm(b.HO)" , b_lab);

  if ((called_code == OPTIMIZATION_CODE) || (Np_nlj_baryon_tab.max () > 0) || (Nn_nlj_baryon_tab.max () > 0))
    {
      word_check ("l");
      word_check ("n.max.HO");

      cout << "l   n.max.HO" << endl;

      int l_check;

      for (int l = 0 ; l <= lmax_all ; l++)
	{ 
	  cin >> l_check >> nmax_HO_lab_tab(l);

	  if (nmax_HO_lab_tab(l) < 0) error_message_print_abort ("n.max.HO must be positive or zero for l=" + make_string<int> (l));
      
	  if (l_check != l) error_message_print_abort ("l[HO] is not correct: read:" + make_string<int> (l_check) + ", correct:" + make_string<int> (l));
            
	  cout << l << "   " << nmax_HO_lab_tab(l) << endl; 
	}

      cout << endl;
    }

  nmax_GHF_lab_tab.allocate (lmax_all_plus_one);

  nmax_GHF_lab_tab = 0;
  
  if (inter_read == LAB_BERGGREN_TBMES_READ)
    {
      word_check ("GHF.expansion");
  
      word_check ("l");
      word_check ("n.max.GHF");

      cout << "l   n.max.GHF" << endl;

      int l_check;

      for (int l = 0 ; l <= lmax_all ; l++)
	{ 
	  cin >> l_check >> nmax_GHF_lab_tab(l);
      
	  if (nmax_GHF_lab_tab(l) < 0) error_message_print_abort ("n.max.GHF must be positive or zero for l=" + make_string<int> (l));
      
	  if (l_check != l) error_message_print_abort ("l[GHF] is not correct: read:" + make_string<int> (l_check) + ", correct:" + make_string<int> (l));
      
	  cout << l << "   " << nmax_GHF_lab_tab(l) << endl; 
	}

      cout << endl;
    }
  else
    {
      const bool is_it_HF_MSDHF_basis = ((basis_potential == HF) || (basis_potential == MSDHF));
      
      const int Aval_basis = Zval_basis + Nval_basis;
  
      const int Aval = ZYval + NYval;
  
      if (called_code == TWO_PARTICLE_RELATIVE_CODE)
	{
	  int J_relative_max;
	  
	  cin >> J_relative_max;
	  word_check_print<double> ("(J.relative.max.interaction)" , J_relative_max);
	  
	  if (J_relative_max < 0) error_message_print_abort ("J.relative.max.interaction must be positive or zero");

	  Jn_relative_max = J_relative_max;

	  if (is_Coulomb_to_be_added && ((ZYval >= 2) || (Zval_basis >= 2))) Jc_relative_max = J_relative_max;
	}  
      else if ((Aval >= 2) || ((Aval_basis >= 2) && is_it_HF_MSDHF_basis))
	{
	  if (!is_it_EFT_determine (inter))
	    {
	      cin >> Jn_relative_max;
	      word_check_print<double> ("(J.relative.max.nuclear.interaction)" , Jn_relative_max);
	  
	      if (Jn_relative_max < 0) error_message_print_abort ("J.relative.max.nuclear.interaction must be positive or zero");
	    }
      
	  if (is_Coulomb_to_be_added && ((ZYval >= 2) || (Zval_basis >= 2)))
	    {
	      cin >> Jc_relative_max;
	      word_check_print<double> ("(J.relative.max.Coulomb.interaction)" , Jc_relative_max);
	  
	      if (Jc_relative_max < 0) error_message_print_abort ("J.relative.max.Coulomb.interaction must be positive or zero");
	    }
	}
    }
  
  cout << endl;

  if (called_code == TWO_PARTICLE_RELATIVE_CODE)
    {
      const int ln_relative_max = Jn_relative_max + 1;

      if (lmax_relative > ln_relative_max) error_message_print_abort ("The basis lmax relative cannot be larger than the lmax_relative of interaction");
    }
}















void input_data_str::core_potential_data_alloc_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::core_potential_data_read");		

  core_potential_data_default_alloc_fill ();

  if (basis_potential == QBOX_POTENTIAL) return;
  
  const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
      
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3)
    {
      if ((inter != REALISTIC_INTERACTION) && !OBMEs_inter_read)
	{
	  word_check ("core.potential");
	  
	  cin >> H_potential;
	  cout << "Hamiltonian potential for core: " << H_potential << endl;

	  if ((H_potential == WS) || (H_potential == WS_ANALYTIC))
	    WS_nucleus_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , lmax_common_baryon_p_tab , lmax_common_baryon_n_tab , hyperon_types ,
				     dp_core_potential_tab , R0_p_core_potential_tab , Vo_p_core_potential_tab , Vso_p_core_potential_tab ,
				     dn_core_potential_tab , R0_n_core_potential_tab , Vo_n_core_potential_tab , Vso_n_core_potential_tab);
	  else if (H_potential == KKNN)
	    KKNN_potential_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , hyperon_types ,
					 V0_KKNN_p_tab , rho_KKNN_p_tab , Vls_KKNN_p_tab , rho_ls_KKNN_p_tab ,
					 V0_KKNN_n_tab , rho_KKNN_n_tab , Vls_KKNN_n_tab , rho_ls_KKNN_n_tab);
	  else 
	    error_message_print_abort ("Hamiltonian core potential " + make_string<enum potential_type> (H_potential) + " not available");
	}
      else if ((inter == REALISTIC_INTERACTION) && (called_code != TWO_PARTICLE_RELATIVE_CODE))
	{
	  const bool is_there_auxiliary_potential = bool_determination ("auxiliary.potential");

	  if (is_there_auxiliary_potential)
	    {
	      cin >> H_potential;
	      cout << "Hamiltonian auxiliary potential: " << H_potential << endl;
      
	      if ((H_potential == WS) || (H_potential == WS_ANALYTIC))
		WS_nucleus_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , lmax_common_baryon_p_tab , lmax_common_baryon_n_tab , hyperon_types ,
					 dp_core_potential_tab , R0_p_core_potential_tab , Vo_p_core_potential_tab , Vso_p_core_potential_tab ,
					 dn_core_potential_tab , R0_n_core_potential_tab , Vo_n_core_potential_tab , Vso_n_core_potential_tab);
	      else if (H_potential == KKNN)
		KKNN_potential_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , hyperon_types ,
					     V0_KKNN_p_tab , rho_KKNN_p_tab , Vls_KKNN_p_tab , rho_ls_KKNN_p_tab ,
					     V0_KKNN_n_tab , rho_KKNN_n_tab , Vls_KKNN_n_tab , rho_ls_KKNN_n_tab);
	      else 
		error_message_print_abort ("Hamiltonian auxiliary potential " + make_string<enum potential_type> (H_potential) + " not available");
	    }
	  else
	    H_potential = NO_POTENTIAL;
	}
      else
	H_potential = NO_POTENTIAL;
    }
  else
    H_potential = HO_POTENTIAL;

  if (called_code == OPTIMIZATION_CODE) same_partial_wave_values_check ();
  
  H_basis_core_potential = H_potential;
  
  cout << endl;
}





void input_data_str::basis_core_potential_data_alloc_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::basis_core_potential_data_read");		

  basis_core_potential_data_default_alloc_fill ();

  if ((basis_potential == HF) || (basis_potential == MSDHF))
    {  
      if ((called_code != TWO_PARTICLE_RELATIVE_CODE) && (called_code != RDM_CODE))
	{
	  if (inter == REALISTIC_INTERACTION)
	    {
	      word_check ("WS.potential.added.to.HF");

	      WS_nucleus_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , lmax_common_baryon_p_tab , lmax_common_baryon_n_tab , hyperon_types , 
				       dp_basis_core_potential_tab , R0_p_basis_core_potential_tab , Vo_p_basis_core_potential_tab , Vso_p_basis_core_potential_tab ,
				       dn_basis_core_potential_tab , R0_n_basis_core_potential_tab , Vo_n_basis_core_potential_tab , Vso_n_basis_core_potential_tab);
	    }
	  else
	    { 
	      word_check ("basis.core.potential");

	      cin >> H_basis_core_potential;
	      cout << "Hamiltonian basis potential for core: " << H_basis_core_potential << endl;

	      if ((H_basis_core_potential == WS) || (H_basis_core_potential == WS_ANALYTIC))
		WS_nucleus_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , lmax_common_baryon_p_tab , lmax_common_baryon_n_tab , hyperon_types ,
					 dp_basis_core_potential_tab , R0_p_basis_core_potential_tab , Vo_p_basis_core_potential_tab , Vso_p_basis_core_potential_tab ,
					 dn_basis_core_potential_tab , R0_n_basis_core_potential_tab , Vo_n_basis_core_potential_tab , Vso_n_basis_core_potential_tab);
	      else if (H_basis_core_potential == KKNN)
		KKNN_potential_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , hyperon_types ,
					     V0_KKNN_basis_core_potential_p_tab , rho_KKNN_basis_core_potential_p_tab , Vls_KKNN_basis_core_potential_p_tab , rho_ls_KKNN_basis_core_potential_p_tab ,
					     V0_KKNN_basis_core_potential_n_tab , rho_KKNN_basis_core_potential_n_tab , Vls_KKNN_basis_core_potential_n_tab , rho_ls_KKNN_basis_core_potential_n_tab);
	      else 
		error_message_print_abort ("Hamiltonian potential not available for interactions other than realistic");
	    }
	}
    }
  else
    {
      dp_basis_core_potential_tab = dp_core_potential_tab;
      dn_basis_core_potential_tab = dn_core_potential_tab;
      
      R0_p_basis_core_potential_tab = R0_p_core_potential_tab;
      R0_n_basis_core_potential_tab = R0_n_core_potential_tab;
      
      Vo_p_basis_core_potential_tab = Vo_p_core_potential_tab;
      Vo_n_basis_core_potential_tab = Vo_n_core_potential_tab;
      
      Vso_p_basis_core_potential_tab = Vso_p_core_potential_tab;
      Vso_n_basis_core_potential_tab = Vso_n_core_potential_tab;
    }

  cout << endl;
}







void input_data_str::basis_potential_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::basis_potential_data_read");		

  basis_potential_data_default_alloc_fill ();
 
  if (inter_read == LAB_BERGGREN_TBMES_READ) return;
  
  cout << "Basis potential: " << basis_potential << endl;

  const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
  
  if (are_there_hyperons && (basis_potential == HO_POTENTIAL) && is_it_fit_or_SU3) error_message_print_abort ("One cannot consider hypernuclei with either HO fit or SU(3) interactions");
  
  if ((basis_potential != HO_POTENTIAL) && is_it_fit_or_SU3) error_message_print_abort ("Fitted interactions stored on files or SU(3) interaction are only defined with a HO or Qbox basis potential");
    
  if ((basis_potential == MSDHF) && (called_code == HF_OCM_BASIS_ONLY_CODE)) error_message_print_abort ("No MSDHF potential with HF/OCM basis code");
        
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3)
    {
      const bool is_it_COSM = is_it_COSM_determine (inter);
      
      const bool is_it_HF_MSDHF_basis = ((basis_potential == HF) || (basis_potential == MSDHF));

      const bool is_it_OCM_basis = (is_it_COSM && !is_it_HF_MSDHF_basis);
      
      const unsigned int prot_index = charge_baryon_index_determine (PROTON);
      const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
      class array<class nlj_struct> &prot_shells_quantum_numbers = shells_quantum_numbers_p_tab(prot_index);
      class array<class nlj_struct> &neut_shells_quantum_numbers = shells_quantum_numbers_n_tab(neut_index);
      
      const bool are_there_OCM_valence_states_to_integrate = (are_there_OCM_valence_states_to_integrate_determine (prot_shells_quantum_numbers) ||
							      are_there_OCM_valence_states_to_integrate_determine (neut_shells_quantum_numbers));

      if (!is_it_HF_MSDHF_basis && (basis_potential != HO_POTENTIAL) && (basis_potential != WS_ANALYTIC) && (basis_potential != H_potential) && (basis_potential != QBOX_POTENTIAL))
	error_message_print_abort ("Basis potential is HO potential, HF/MSDHF, WS-analytic, one-body Hamiltonian potential or Qbox potential");

      if ((called_code == TWO_PARTICLE_RELATIVE_CODE) && (basis_potential != HO_POTENTIAL) && (basis_potential != WS_ANALYTIC)) error_message_print_abort ("HO or WS-analytic potentials only with the two-body relative code");
      
      if ((called_code == CC_CODE) && (basis_potential == HO_POTENTIAL)) error_message_print_abort ("One cannot use a basis HO potential with GSM-CC");

      if ((basis_potential != HO_POTENTIAL) && (basis_potential != KKNN) && (((basis_potential != HF) && (basis_potential != MSDHF)) || (H_potential != KKNN)))
	{
	  word_check ("Basis.WS.parameters");

	  if (called_code == TWO_PARTICLE_RELATIVE_CODE)
	    WS_nucleus_data_read (space , are_there_hyperons , relative_cluster , lmax_relative , d_basis_relative_tab , R0_basis_relative_tab , Vo_basis_relative_tab , Vso_basis_relative_tab);	
	  else
	    WS_nucleus_data_pn_read (basis_space , are_there_hyperons , Zval_basis , Nval_basis , lmax_baryon_p_tab , lmax_baryon_n_tab , hyperon_types ,
				     dp_basis_tab , R0_p_basis_tab , Vo_p_basis_tab , Vso_p_basis_tab ,
				     dn_basis_tab , R0_n_basis_tab , Vo_n_basis_tab , Vso_n_basis_tab);
	}
      else
	{ 
	  if (dp_basis_core_potential_tab.is_it_filled ()) dp_basis_tab = dp_core_potential_tab;
	  if (dn_basis_core_potential_tab.is_it_filled ()) dn_basis_tab = dn_core_potential_tab;
      
	  if (R0_p_basis_core_potential_tab.is_it_filled ()) R0_p_basis_tab = R0_p_core_potential_tab;
	  if (R0_n_basis_core_potential_tab.is_it_filled ()) R0_n_basis_tab = R0_n_core_potential_tab;
      
	  if (Vo_p_basis_core_potential_tab.is_it_filled ()) Vo_p_basis_tab = Vo_p_core_potential_tab;
	  if (Vo_n_basis_core_potential_tab.is_it_filled ()) Vo_n_basis_tab = Vo_n_core_potential_tab;
      
	  if (Vso_p_basis_core_potential_tab.is_it_filled ()) Vso_p_basis_tab = Vso_p_core_potential_tab;
	  if (Vso_n_basis_core_potential_tab.is_it_filled ()) Vso_n_basis_tab = Vso_n_core_potential_tab;
	}

      if (inter_read == LAB_BERGGREN_TBMES_READ) return; 
         
      if ((called_code != RDM_CODE) && (called_code != TWO_PARTICLE_RELATIVE_CODE) && (is_it_HF_MSDHF_basis || (is_it_OCM_basis && are_there_OCM_valence_states_to_integrate)))
	{
	  //--// Parameters for the HF equivalent potential (see HF files and input_data_str.h)
	  cin >> Ueq_regularizor;
	  word_check_print<double> ("(equivalent.potential.regularizor)" , Ueq_regularizor);
  
	  cin >> HF_max_iterations_number;
	  word_check_print<unsigned int> ("(HF/MSDHF/OCM.iterations.maximal.number)" , HF_max_iterations_number);

	  if (HF_max_iterations_number <= 0) error_message_print_abort ("HF/MSDHF/OCM iterations maximal number must be positive");
	  
	  cin >> HF_precision;
	  word_check_print<double> ("(HF/MSDHF/OCM.potential.precision)" , HF_precision);
	  
	  if (HF_precision <= 0) error_message_print_abort ("HF/MSDHF/OCM potential precision must be positive");
	}
    }
  
  cout << endl;
}








void input_data_str::BP_J_min_max_global_two_particles_read ()
{  
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::BP_J_min_max_global_two_particles_read");		

  unsigned int BPmin_global = 0;
  unsigned int BPmax_global = 0;

  int Jmin_global = 0;
  int Jmax_global = 0;

  string BP_str;

  cin >> BP_str;
  
  word_check_print<string> ("(Parities)" , BP_str);

  if (BP_str == "+")
    {
      BPmin_global = 0;
      BPmax_global = 0;
    }
  else if (BP_str == "-")
    {
      BPmin_global = 1;
      BPmax_global = 1;
    }
  else if (BP_str == "+/-")
    {
      BPmin_global = 0;
      BPmax_global = 1;
    }
  else
    error_message_print_abort ("Parities undefined"); 
  
  cin >> Jmin_global;

  word_check_print<int> ("(Jmin)" , Jmin_global);

  if (Jmin_global < 0) error_message_print_abort ("Jmin must be positive or zero");
	  
  cin >> Jmax_global;

  word_check_print<int> ("(Jmax)" , Jmax_global);

  if (Jmax_global < 0) error_message_print_abort ("Jmax must be positive or zero");
  
  switch (basis_space)
    {
    case PROT_Y_ONLY:
      {
	BPmin_global_pp_basis = max (BPmin_global , BPmin_global_pp_basis);
	BPmax_global_pp_basis = min (BPmax_global , BPmax_global_pp_basis);

	const bool is_there_negative_parity = (BPmax_global_pp_basis == 1);
  
	Jmin_global_pp_basis = max (Jmin_global , Jmin_global_pp_basis);
	Jmax_global_pp_basis = min (Jmax_global , Jmax_global_pp_basis);

	Jmin_global_pp_opp_basis = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_pp_opp_basis)) : (INFINITE_J);
	Jmax_global_pp_opp_basis = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_pp_opp_basis)) : (0);
      } break;
      
    case NEUT_Y_ONLY:
      {
	BPmin_global_nn_basis = max (BPmin_global , BPmin_global_nn_basis);
	BPmax_global_nn_basis = min (BPmax_global , BPmax_global_nn_basis);

	const bool is_there_negative_parity = (BPmax_global_nn_basis == 1);

	Jmin_global_nn_basis = max (Jmin_global , Jmin_global_nn_basis);
	Jmax_global_nn_basis = min (Jmax_global , Jmax_global_nn_basis);
	
	Jmin_global_nn_opp_basis = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_nn_opp_basis)) : (INFINITE_J);
	Jmax_global_nn_opp_basis = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_nn_opp_basis)) : (0);
      } break;

    case PROT_NEUT_Y:
      {
	BPmin_global_pn_basis = max (BPmin_global , BPmin_global_pn_basis);
	BPmax_global_pn_basis = min (BPmax_global , BPmax_global_pn_basis);

	const bool is_there_negative_parity = (BPmax_global_pn_basis == 1);
  
	Jmin_global_pn_basis = max (Jmin_global , Jmin_global_pn_basis);
	Jmax_global_pn_basis = min (Jmax_global , Jmax_global_pn_basis);

	Jmin_global_pn_opp_basis = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_pn_opp_basis)) : (INFINITE_J);
	Jmax_global_pn_opp_basis = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_pn_opp_basis)) : (0);
      } break;
       
    default: abort_all ();
    }
    
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	BPmin_global_pp = max (BPmin_global , BPmin_global_pp);
	BPmax_global_pp = min (BPmax_global , BPmax_global_pp);

	const bool is_there_negative_parity = (BPmax_global_pp == 1);
  
	Jmin_global_pp = max (Jmin_global , Jmin_global_pp);
	Jmax_global_pp = min (Jmax_global , Jmax_global_pp);

	Jmin_global_pp_opp = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_pp_opp)) : (INFINITE_J);
	Jmax_global_pp_opp = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_pp_opp)) : (0);
      } break;
      
    case NEUT_Y_ONLY:
      {
	BPmin_global_nn = max (BPmin_global , BPmin_global_nn);
	BPmax_global_nn = min (BPmax_global , BPmax_global_nn);

	const bool is_there_negative_parity = (BPmax_global_nn == 1);

	Jmin_global_nn = max (Jmin_global , Jmin_global_nn);
	Jmax_global_nn = min (Jmax_global , Jmax_global_nn);
	
	Jmin_global_nn_opp = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_nn_opp)) : (INFINITE_J);
	Jmax_global_nn_opp = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_nn_opp)) : (0);
      } break;

    case PROT_NEUT_Y:
      {
	BPmin_global_pn = max (BPmin_global , BPmin_global_pn);
	BPmax_global_pn = min (BPmax_global , BPmax_global_pn);

	const bool is_there_negative_parity = (BPmax_global_pn == 1);
  
	Jmin_global_pn = max (Jmin_global , Jmin_global_pn);
	Jmax_global_pn = min (Jmax_global , Jmax_global_pn);

	Jmin_global_pn_opp = (is_there_negative_parity) ? (max (Jmin_global , Jmin_global_pn_opp)) : (INFINITE_J);
	Jmax_global_pn_opp = (is_there_negative_parity) ? (min (Jmax_global , Jmax_global_pn_opp)) : (0);
      } break;
       
    default: abort_all ();
    }
    
  cout << endl;
}






void input_data_str::eigenvectors_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::eigenvectors_data_alloc_read");
  
  const int Aval = ZYval + NYval;

  const int S = hypernucleus_strangeness;
  
  eigenset_vectors_number_max = 0;

  cin >> eigensets_number;
  
  if (eigensets_number == 0) error_message_print_abort ("Eigenset number cannot be equal to zero"); 
  
  if (!J_projected && (eigensets_number > 2)) error_message_print_abort ("Eigenset number cannot be larger than two without J-projection: only parity can change"); 
  
  word_check_print<unsigned int> ("eigenset(s)" , eigensets_number);

  BP_eigenset_tab.allocate (eigensets_number);

  J_eigenset_tab.allocate (eigensets_number);
  
  eigenset_vectors_number_tab.allocate (eigensets_number);
  
  BP_eigenset_tab = 0;

  J_eigenset_tab = 0;
  
  eigenset_vectors_number_tab = 0;

  class array<class array<class correlated_state_str> > PSI_qn_from_file_tab_local;

  PSI_qn_from_file_tab_local.allocate (eigensets_number);

  if (!J_projected)
    word_check ("eigenset(J[min])");
  else
    word_check ("eigenset");
  
  if (!all_states_calculated && !non_zero_NBMEs_proportion_only)
    {
      word_check ("eigenvectors.number");
      word_check ("eigenvectors.indices");
      
      if (!J_projected)
	cout << "eigenset(J[min])   eigenvectors.number   eigenvectors.indices";
      else
	cout << "eigenset   eigenvectors.number   eigenvectors.indices";
    
      if (called_code == OPTIMIZATION_CODE)
	{
	  word_check ("experimental.energies(MeV)");
	  word_check ("energy.errors(MeV)");
	  word_check ("state.weights");
      
	  if (!binding_energies_fitted) word_check ("reference.state(yes/no)");
      
	  if (binding_energies_fitted)  cout << "   experimental.energies(MeV)   energy.errors(MeV)   state.weights";
	  if (!binding_energies_fitted) cout << "   experimental.energies(MeV)   energy.errors(MeV)   state.weights   reference.state(yes/no)";
	}
  
      cout << endl;
  
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{    
	  string eigenstate; 

	  unsigned int eigenset_vectors_number = 1;

	  cin >> eigenstate;

	  // If J is not projected, the "double J" below is the minimal angular momentum Jmin that is considered in the calculation. One always takes M = Jmin if J is not projected.
	  // The eigenvector indices below are those related to Jmin, which will be reindexed at the end of the calculation to be the same as those occurring with J projection.
	  // Let us take as an example the calculation of three states with Jmin = 0, of indices 0,1,2, respectively.
	  // If these states have angular momenta equal to J=0,2,2, respectively, the new eigenvector indices will become 0,0,1, respectively.
	  	  
	  cin >> eigenset_vectors_number;
      
	  if (eigenset_vectors_number == 0) error_message_print_abort ("Eigenset vectors number cannot be equal to zero");
  
	  if (binding_energies_fitted && (eigenstate == "reference.state(yes/no)")) error_message_print_abort ("No reference state statements when binding energies are fitted");
      
	  cout << eigenstate << "   " << eigenset_vectors_number << "   ";
      
	  class array<class correlated_state_str> &PSI_qn_from_file_tab_local_eigenset_index = PSI_qn_from_file_tab_local(eigenset_index);
	  
	  PSI_qn_from_file_tab_local_eigenset_index.allocate (eigenset_vectors_number);

	  eigenset_vectors_number_max = max (eigenset_vectors_number_max , eigenset_vectors_number);
	  
	  const double J = determine_J (eigenstate);
      
	  const unsigned int BP = determine_Binary_Parity (eigenstate);

	  const int two_J = make_int (2.0*J);

	  if (abs (Aval)%2 != two_J%2) error_message_print_abort ("J is integer for A even and half-integer for A odd for J.Pi=" + J_Pi_string (BP , J));

	  if (called_code == TWO_PARTICLE_CODE)
	    {
	      switch (space)
		{
		case PROT_Y_ONLY:
		  {
		    if ((BP < BPmin_global_pp) || (BP > BPmax_global_pp) || (make_int (J) < Jmin_global_pp) || (make_int (J) > Jmax_global_pp))
		      {
			const int Parity_min_global_pp = parity_from_binary_parity (BPmin_global_pp);
			const int Parity_max_global_pp = parity_from_binary_parity (BPmax_global_pp);
	      
			const string Parity_string = "Parity[min]:" + make_string<int> (Parity_min_global_pp) + " Parity[max]:" + make_string<int> (Parity_max_global_pp);

			const string J_string = "J[min]:" + make_string<int> (Jmin_global_pp) + " J[max]:" + make_string<int> (Jmax_global_pp);

			error_message_print_abort ("J.Pi=" + J_Pi_string (BP , J) + " outside J-Pi bounds (pp): " + Parity_string + " " + J_string);
		      }
		  } break;

		case NEUT_Y_ONLY:
		  {
		    if ((BP < BPmin_global_nn) || (BP > BPmax_global_nn) || (make_int (J) < Jmin_global_nn) || (make_int (J) > Jmax_global_nn))
		      {
			const int Parity_min_global_nn = parity_from_binary_parity (BPmin_global_nn);
			const int Parity_max_global_nn = parity_from_binary_parity (BPmax_global_nn);
	      
			const string Parity_string = "Parity[min]:" + make_string<int> (Parity_min_global_nn) + " Parity[max]:" + make_string<int> (Parity_max_global_nn);

			const string J_string = "J[min]:" + make_string<int> (Jmin_global_nn) + " J[max]:" + make_string<int> (Jmax_global_nn);

			error_message_print_abort ("J.Pi=" + J_Pi_string (BP , J) + " outside J-Pi bounds (nn): " + Parity_string + " " + J_string);
		      }
		  } break;

		case PROT_NEUT_Y:
		  {
		    if ((BP < BPmin_global_pn) || (BP > BPmax_global_pn) || (make_int (J) < Jmin_global_pn) || (make_int (J) > Jmax_global_pn))
		      {
			const int Parity_min_global_pn = parity_from_binary_parity (BPmin_global_pn);
			const int Parity_max_global_pn = parity_from_binary_parity (BPmax_global_pn);
	      
			const string Parity_string = "Parity[min]:" + make_string<int> (Parity_min_global_pn) + " Parity[max]:" + make_string<int> (Parity_max_global_pn);

			const string J_string = "J[min]:" + make_string<int> (Jmin_global_pn) + " J[max]:" + make_string<int> (Jmax_global_pn);

			error_message_print_abort ("J.Pi=" + J_Pi_string (BP , J) + " outside J-Pi bounds (pn): " + Parity_string + " " + J_string);
		      }
		  } break;

		default: abort_all ();
		}
	    }
      
	  class array<unsigned int> vector_indices(eigenset_vectors_number);
	  
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cin >> vector_indices(i);
      
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cout << vector_indices(i) << " ";
	  cout << "  ";
      
	  class array<double> experimental_energies(eigenset_vectors_number);
	  class array<double> energy_errors(eigenset_vectors_number);
	  class array<double> state_weights(eigenset_vectors_number);

	  class array<bool> is_it_optimization_reference_state(eigenset_vectors_number);
      
	  experimental_energies = 0.0;
	  energy_errors = 0.0;
	  state_weights = 0.0;
      
	  is_it_optimization_reference_state = false;
      
	  if (called_code == OPTIMIZATION_CODE)
	    {	  
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cin >> experimental_energies(i);
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cin >> energy_errors(i);
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cin >> state_weights(i);
	   
	      if (!binding_energies_fitted)
		{
		  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) is_it_optimization_reference_state(i) = bool_determination_no_print ("reference.state");
		}
	  
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
		{
		  if (!is_it_optimization_reference_state(i))
		    {
		      if (energy_errors(i) <= 0.0) error_message_print_abort ("Energy errors cannot be negative or zero for the optimization code");

		      if (state_weights(i) < 0.0) error_message_print_abort ("Weights cannot be negative in the optimization code");
		    }
		}
	      
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cout << experimental_energies(i) << " ";
	      cout << "  ";
      
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cout << energy_errors(i) << " ";
	      cout << "  ";
      
	      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++) cout << state_weights(i) << " ";
	      cout << "  ";
	  
	      if (!binding_energies_fitted)
		{
		  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
		    {
		      if (is_it_optimization_reference_state(i))
			cout << "reference.state(yes) ";
		      else
			cout << "reference.state(no) ";		
		    }
	      
		  cout << "  ";
		}
	    }

	  cout << endl;
      
	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    PSI_qn_from_file_tab_local_eigenset_index(i).initialize (Z , N , BP , S , J , vector_indices(i) , 0.0 , state_weights(i) , experimental_energies(i) , energy_errors(i) , is_it_optimization_reference_state(i));
	  
	  BP_eigenset_tab(eigenset_index) = BP;

	  J_eigenset_tab(eigenset_index) = J;
      
	  eigenset_vectors_number_tab(eigenset_index) = eigenset_vectors_number;
	}    
    }
  else
    {
      cout << "eigenset" << endl;
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{    
	  string eigenstate;
	  
	  cin >> eigenstate;
	  
	  cout << eigenstate << endl;
	  
	  const double J = determine_J (eigenstate);
      
	  const unsigned int BP = determine_Binary_Parity (eigenstate);

	  const int two_J = make_int (2.0*J);

	  if (abs (Aval)%2 != two_J%2) error_message_print_abort ("J is integer for A even and half-integer for A odd for J.Pi=" + J_Pi_string (BP , J) + " when all states are calculated");
	  
	  BP_eigenset_tab(eigenset_index) = BP;

	  J_eigenset_tab(eigenset_index) = J;

	  // The number of eigenvectors is the total dimension of the J-Pi space and will considered afterwards.
	}
    }
  
  for (unsigned int i = 0 ; i < eigensets_number ; i++)
    for (unsigned int ii = 0 ; ii < i ; ii++)
      {
	if ((BP_eigenset_tab(i) == BP_eigenset_tab(ii)) && (rint (J_eigenset_tab(i) - J_eigenset_tab(ii)) == 0.0))
	  {
	    const unsigned int BP = BP_eigenset_tab(i);

	    const double J = J_eigenset_tab(i);

	    error_message_print_abort ("J Pi cannot be the same for two different eigenset indices: J Pi:" + J_Pi_string (BP , J) + ", indices:" + make_string<unsigned int > (i) + "," +  make_string<unsigned int > (ii));
	  }
      }

  PSI_qn_from_file_tab.allocate (eigensets_number , eigenset_vectors_number_max);
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {
      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	PSI_qn_from_file_tab(eigenset_index , i) = PSI_qn_from_file_tab_local(eigenset_index)(i);
    }
  
  cout << endl;
}




void input_data_str::get_CC_CM_angles ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::get_CC_CM_angles");

  const double degree_to_radian = M_PI/180.0;		

  CC_CM_angles.allocate (CC_N_CM_angles);
  
  for (unsigned int i = 0 ; i < CC_N_CM_angles ; i++)
    {
      cin >> CC_CM_angles(i);

      if (CC_CM_angles(i) <= 0) error_message_print_abort ("The angle (in degrees and in the center of mass frame) in position " + make_string<int> (i) + " must be positive");
	
      CC_CM_angles(i) *= degree_to_radian;
    }
}




void input_data_str::CC_corrective_factors_TBMEs_alloc_composite_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_corrective_factors_alloc_composite_read");		

  cin >> CC_corrective_factors_TBMEs_composite_number; 
  word_check_print<unsigned int> ("CC.interaction.corrective.factor.composite(s)" , CC_corrective_factors_TBMEs_composite_number);

  CC_corrective_factors_TBMEs_BP_A_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number);
  CC_corrective_factors_TBMEs_J_A_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number);
  CC_corrective_factors_TBMEs_composite_tab.allocate (CC_corrective_factors_TBMEs_composite_number);

  for (unsigned int i = 0 ; i < CC_corrective_factors_TBMEs_composite_number ; i++)
    {
      string composite;

      cin >> composite;

      CC_corrective_factors_TBMEs_J_A_composite_tab(i) = determine_J (composite);

      CC_corrective_factors_TBMEs_BP_A_composite_tab(i) = determine_Binary_Parity (composite);

      cin >> CC_corrective_factors_TBMEs_composite_tab(i);
            
      cout << composite << " " << CC_corrective_factors_TBMEs_composite_tab(i) << endl;
    }

  cout << endl;
}







void input_data_str::CC_scattering_composite_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_scattering_composite_data_alloc_read");		

  cin >> CC_N_JPi_A_composite;
  
  word_check_print<unsigned int> ("composite.state(s)" , CC_N_JPi_A_composite);

  CC_BP_A_composite_tab.allocate (CC_N_JPi_A_composite);

  CC_J_A_composite_tab.allocate (CC_N_JPi_A_composite);

  CC_vector_index_A_composite_tab.allocate (CC_N_JPi_A_composite);

  CC_vector_index_A_composite_tab = NADA;
  
  const bool is_it_pole_calculation = (CC_reaction_calculation == POLES);
  
  // read and fill tables
  CC_composite_data_read (CC_BP_A_composite_tab , CC_vector_index_A_composite_tab , CC_J_A_composite_tab , is_it_pole_calculation);

  cout << endl;
}








void input_data_str::CC_radiative_capture_in_composite_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_radiative_capture_in_composite_data_alloc_read");		

  cin >> CC_N_JPi_A_in_composite; 

  word_check_print<unsigned int> ("Incoming.composite.state(s)" , CC_N_JPi_A_in_composite);

  CC_BP_A_in_composite_tab.allocate (CC_N_JPi_A_in_composite);
  
  CC_J_A_in_composite_tab.allocate (CC_N_JPi_A_in_composite);

  class array<unsigned int> dummy_array;

  // read and fill tables
  CC_composite_data_read (CC_BP_A_in_composite_tab , dummy_array , CC_J_A_in_composite_tab , false);

  cout << endl;
}







// read all data from the input for the radiative capture calculations
void input_data_str::CC_radiative_capture_out_composite_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_radiative_capture_out_composite_data_alloc_read");		

  cin >> CC_N_JPi_A_out_composite; 

  word_check_print<unsigned int> ("Outgoing.composite.state(s)" , CC_N_JPi_A_out_composite);

  CC_BP_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);
  
  CC_J_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);

  CC_vector_index_A_out_composite_tab.allocate (CC_N_JPi_A_out_composite);

  CC_composite_data_read (CC_BP_A_out_composite_tab , CC_vector_index_A_out_composite_tab , CC_J_A_out_composite_tab , true);

  cout << endl;
}






void input_data_str::CC_target_projectile_data_alloc_read (
							   class array<class array<int> > &CC_partial_wave_L_cluster_projectile_tab_local ,
							   class array<class array<double> > &CC_partial_wave_J_cluster_projectile_tab_local)
{     
  unsigned int N_entrance_channels = 0;

  unsigned int iT = 0;

  CC_N_partial_waves_max = 0;

  CC_partial_wave_L_cluster_projectile_tab_local.allocate (CC_N_target_projectile_states);
  CC_partial_wave_J_cluster_projectile_tab_local.allocate (CC_N_target_projectile_states);
  
  word_check ("pole.target(yes/no)");
  word_check ("target.state");
  word_check ("projectile.type");
  word_check ("entrance.channel(yes/no)");
  word_check ("projectile.partial.wave.number");
  word_check ("projectile.partial.wave(s)");

  cout << "pole.target(yes/no)   target.state   projectile.type    entrance.channel(yes/no)   projectile.partial.wave.number   projectile.partial.wave(s)" << endl;
   
  CC_Gamma_target_tab = 0.0;

  CC_Gamma_intrinsic_projectile_tab = 0.0;
  
  while (iT < CC_N_target_projectile_states)
    {
      CC_is_it_pole_target_tab(iT) = bool_determination_no_print ("pole.target");

      cout << CC_is_it_pole_target_tab(iT) << "   ";

      const bool is_it_pole_target = CC_is_it_pole_target_tab(iT);

      // Target quantum numbers
      string target;

      cin >> target;

      CC_J_target_tab(iT) = determine_J (target);

      CC_BP_target_tab(iT) = determine_Binary_Parity (target);

      int S_T = 0;

      if (are_there_hyperons)
	{
	  cin >> S_T;

	  if (S_T > 0) error_message_print_abort ("Target strangeness must be zero or negative");

	  S_T = -S_T;
	}
      
      unsigned int vector_index_min = 0;
      unsigned int vector_index_max = 0;

      if (is_it_pole_target)
	{
	  cin >> CC_vector_index_target_tab(iT);

	  cout << target << " ";
	  
	  if (are_there_hyperons) cout << -S_T << " ";
	  
	  cout << CC_vector_index_target_tab(iT) << "   ";
	}
      else
	{
	  string to_str;

	  cin >> vector_index_min >> to_str >> vector_index_max;

	  if (to_str != "to") error_message_print_abort ("Scattering target vector indices must be written: [index_min] to [index_max]");

	  cout << target << " ";
	  
	  if (are_there_hyperons) cout << -S_T << " ";
	  
	  cout << vector_index_min << " to " << vector_index_max << "   ";
	  
	  CC_vector_index_target_tab(iT) = vector_index_min;
	}

      cin >> CC_projectile_tab(iT);

      const enum particle_type projectile = CC_projectile_tab(iT);

      cout << projectile << "   ";

      const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

      const int A_projectile = A_cluster_determine (projectile);
      
      const int S_intrinsic_projectile = particle_strangeness_determine (projectile);

      if (A_projectile >= 2)
	{
	  const int Z_projectile = Z_cluster_determine (projectile);
	  const int N_projectile = N_cluster_determine (projectile);

	  const unsigned int BP_intrinsic_projectile = BP_intrinsic_cluster_determine (projectile);

	  const unsigned int vector_index_intrinsic_projectile = vector_index_intrinsic_cluster_determine (projectile);

	  const class correlated_state_str PSI_intrinsic_qn(Z_projectile , N_projectile , BP_intrinsic_projectile , S_intrinsic_projectile , J_intrinsic_projectile , vector_index_intrinsic_projectile , NADA , NADA , NADA , NADA , false);

	  const complex<double> E_intrinsic_projectile_tilde = CC_get_energy_from_file (PSI_intrinsic_qn);

	  const double E_intrinsic_projectile = real_dc (E_intrinsic_projectile_tilde);

	  CC_real_E_intrinsic_projectile_tab(iT) = E_intrinsic_projectile;	  

#ifdef TYPEisDOUBLECOMPLEX

	  const double Gamma_intrinsic_projectile = 0.0;//-2000.0*imag (E_intrinsic_projectile_tilde);
	  
	  CC_Gamma_intrinsic_projectile_tab(iT) = Gamma_intrinsic_projectile;
#endif
	}
      else
	CC_real_E_intrinsic_projectile_tab(iT) = CC_Gamma_intrinsic_projectile_tab(iT) = 0.0;

      const int A_target = A - A_projectile;

      const int ZT = Z_target_determine (Z , projectile);
      const int NT = N_target_determine (N , projectile);

      const int ZT_val = ZT - Z_core + prot_hole_states_number;
      const int NT_val = NT - N_core + neut_hole_states_number;

      const bool has_target_valence_nucleons = ((ZT_val > 0) || (NT_val > 0));

      const unsigned int BP_T = CC_BP_target_tab(iT);

      const unsigned int vector_index_T = CC_vector_index_target_tab(iT);

      const double J_T = CC_J_target_tab(iT);

      const int two_J_T = make_int (2.0*J_T);
            
      if (abs (A_target)%2 != two_J_T%2) error_message_print_abort ("J[target] is integer for A[target] even and half-integer for A[target] odd for J.Pi[target]=" + J_Pi_string (BP_T , J_T));
      
      const class correlated_state_str T_qn(ZT , NT , BP_T , S_T , J_T , vector_index_T , NADA , NADA , NADA , NADA , false);
	  
      const complex<double> ET_tilde = (has_target_valence_nucleons) ? (CC_get_energy_from_file (T_qn)) : (0.0);
      
      const complex<double> average_n_scat_T = (has_target_valence_nucleons) ? (CC_get_average_n_scat_from_file (T_qn)) : (0.0);

      const double ET = real_dc (ET_tilde);

      CC_real_E_target_tab(iT) = ET;

#ifdef TYPEisDOUBLECOMPLEX

      const double Gamma_T = 0.0;//-2000.0*imag (ET_tilde);
      
      CC_Gamma_target_tab(iT) = Gamma_T;
      
#endif

      CC_average_n_scat_target_tab(iT) = average_n_scat_T;

      const bool is_it_entrance_channel = bool_determination_no_print ("entrance.channel");

      const string is_it_entrance_channel_string = (is_it_entrance_channel) ? ("entrance.channel(yes)") : ("entrance.channel(no)  ");
      
      cout << is_it_entrance_channel_string << "   ";
      	
      if (is_it_entrance_channel && (CC_reaction_calculation == POLES)) error_message_print_abort ("No entrance channel for pole target states");
      
      if (is_it_entrance_channel && !is_it_pole_target) error_message_print_abort ("No entrance channel among scattering target states");

      if (is_it_entrance_channel && (N_entrance_channels++ == 1)) error_message_print_abort ("There cannot be two entrance channels");

      CC_is_it_entrance_tab(iT) = is_it_entrance_channel;

      // Number of partial waves for each composite state

      cin >> CC_N_partial_waves_tab(iT);

      cout << CC_N_partial_waves_tab(iT) << "   ";
  
      const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

      CC_N_partial_waves_max = max (CC_N_partial_waves_max , N_partial_waves);

      class array<int> &CC_partial_wave_L_cluster_T_tab = CC_partial_wave_L_cluster_projectile_tab_local(iT);
      
      class array<double> &CC_partial_wave_J_cluster_T_tab = CC_partial_wave_J_cluster_projectile_tab_local(iT);

      CC_partial_wave_L_cluster_T_tab.allocate (N_partial_waves);
      CC_partial_wave_J_cluster_T_tab.allocate (N_partial_waves);

      for (unsigned int ilj_T = 0 ; ilj_T < N_partial_waves ; ilj_T++)
	{
	  string projectile_partial_wave;

	  cin >> projectile_partial_wave;

	  cout << projectile_partial_wave << "   ";

	  CC_partial_wave_L_cluster_T_tab(ilj_T) = determine_L_cluster (projectile , projectile_partial_wave);

	  CC_partial_wave_J_cluster_T_tab(ilj_T) = (J_intrinsic_projectile != 0.0) ? (determine_J_cluster (projectile_partial_wave)) : (CC_partial_wave_L_cluster_T_tab(ilj_T));

	  check_partial_wave (projectile , CC_partial_wave_L_cluster_T_tab(ilj_T) , CC_partial_wave_J_cluster_T_tab(ilj_T));
	}

      if (!is_it_pole_target)
	{
	  if (vector_index_max >= CC_N_target_projectile_states) error_message_print_abort ("\nIndices of scattering target-projectile states are too large for the demanded number of target-projectile states");
	  
	  CC_remaining_scattering_target_projectile_data_fill (S_T , vector_index_min , vector_index_max , CC_partial_wave_L_cluster_projectile_tab_local , CC_partial_wave_J_cluster_projectile_tab_local , iT);
	}
      
      cout << endl;
            
      if (iT++ > CC_N_target_projectile_states) error_message_print_abort ("Too many target projectile channels");      
    }

  cout << endl;

  shells_consistency_tests_GSM_CC ();
}




void input_data_str::CC_target_projectile_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_target_projectile_data_alloc_read");		

  if (truncation_ph)
    {
      cin >> CC_average_n_scat_target_projectile_max_composite_number; 
      word_check_print<unsigned int> ("maximal.scattering.states.average.numbers" , CC_average_n_scat_target_projectile_max_composite_number);

      CC_average_n_scat_target_projectile_max_BP_A_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number);
      CC_average_n_scat_target_projectile_max_J_A_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number);
      CC_average_n_scat_target_projectile_max_composite_tab.allocate (CC_average_n_scat_target_projectile_max_composite_number);

      for (unsigned int i = 0 ; i < CC_average_n_scat_target_projectile_max_composite_number ; i++)
	{
	  string composite;

	  cin >> composite;

	  CC_average_n_scat_target_projectile_max_J_A_composite_tab(i) = determine_J (composite);

	  CC_average_n_scat_target_projectile_max_BP_A_composite_tab(i) = determine_Binary_Parity (composite);

	  cin >> CC_average_n_scat_target_projectile_max_composite_tab(i);
            
	  cout << composite << " " << CC_average_n_scat_target_projectile_max_composite_tab(i) << endl;
	}
      
      cout << endl;
    }
      
  cin >> CC_N_target_projectile_states;

  word_check_print<unsigned int> ("target.projectile.state(s)" , CC_N_target_projectile_states);

  CC_BP_target_tab.allocate (CC_N_target_projectile_states);

  CC_J_target_tab.allocate (CC_N_target_projectile_states);

  CC_vector_index_target_tab.allocate (CC_N_target_projectile_states);

  CC_projectile_tab.allocate (CC_N_target_projectile_states);

  CC_N_partial_waves_tab.allocate (CC_N_target_projectile_states);

  CC_real_E_intrinsic_projectile_tab.allocate (CC_N_target_projectile_states);

  CC_Gamma_intrinsic_projectile_tab.allocate (CC_N_target_projectile_states);

  CC_real_E_target_tab.allocate (CC_N_target_projectile_states);

  CC_Gamma_target_tab.allocate (CC_N_target_projectile_states);

  CC_average_n_scat_target_tab.allocate (CC_N_target_projectile_states);

  CC_is_it_entrance_tab.allocate (CC_N_target_projectile_states);

  CC_is_it_pole_target_tab.allocate (CC_N_target_projectile_states);

  class array<class array<int> > CC_partial_wave_L_cluster_projectile_tab_local;
  
  class array<class array<double> > CC_partial_wave_J_cluster_projectile_tab_local;

  // read and fill tables
  CC_target_projectile_data_alloc_read (CC_partial_wave_L_cluster_projectile_tab_local , CC_partial_wave_J_cluster_projectile_tab_local);

  CC_partial_wave_L_cluster_projectile_tab.allocate (CC_N_target_projectile_states , CC_N_partial_waves_max);
  CC_partial_wave_J_cluster_projectile_tab.allocate (CC_N_target_projectile_states , CC_N_partial_waves_max);

  CC_partial_wave_L_cluster_projectile_tab = 0.0;
  CC_partial_wave_J_cluster_projectile_tab = 0.0;

  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);

      for (unsigned int ilj_T = 0 ; ilj_T < N_partial_waves ; ilj_T++)
	{
	  CC_partial_wave_L_cluster_projectile_tab(iT , ilj_T) = CC_partial_wave_L_cluster_projectile_tab_local(iT)(ilj_T);
	  CC_partial_wave_J_cluster_projectile_tab(iT , ilj_T) = CC_partial_wave_J_cluster_projectile_tab_local(iT)(ilj_T);
	}
    }

  cout << endl;
}





void input_data_str::MPI_processes_OpenMP_threads_workspace_name_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::MPI_processes_OpenMP_threads_workspace_name_read");		

  cin >> number_of_MPI_processes;

  word_check_print<unsigned int> ("MPI.processes" , number_of_MPI_processes);

  if (number_of_MPI_processes == 0) error_message_print_abort ("The number of MPI processes must be at least equal to one");

  cin >> number_of_OpenMP_threads;

  word_check_print<unsigned int> ("OpenMP.threads" , number_of_OpenMP_threads);

  if (number_of_OpenMP_threads == 0) error_message_print_abort ("The number of OpenMP threads must be at least equal to one");

  //--// test if the storage directory exists.
  cin >> STORAGE_DIR;

  STORAGE_DIR += "/";

  if (access (STORAGE_DIR.c_str () , F_OK) != 0) error_message_print_abort (STORAGE_DIR + " does not exist");

  cout << "STORAGE_DIR: " << STORAGE_DIR << endl;

  //--// check numbers of processes
#ifdef UseMPI
  
  if (number_of_MPI_processes != NUMBER_OF_PROCESSES) 
    error_message_print_abort ("Number of MPI processes:" + make_string<unsigned int> (NUMBER_OF_PROCESSES) + " different from that of the input file:" + make_string<unsigned int> (number_of_MPI_processes));

#else

  if (number_of_MPI_processes >= 2) error_message_print_abort ("MPI library must be included to use more than one MPI node");

#endif

#ifndef UseOpenMP

  //--// check if OpenMP thread number is one as UseOpenMP is deactivated here
  if (number_of_OpenMP_threads >= 2) error_message_print_abort ("OpenMP library must be included to use more than one OpenMP thread");

#endif

  cout << endl;
}






void input_data_str::use_options_interaction_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::use_options_read");		

  const bool is_it_GSM_structure_many_body_code = ((called_code == GSM_CODE) || (called_code == HF_OCM_BASIS_ONLY_CODE) || (called_code == OBMES_TBMES_CODE) || (called_code == H_EIGENVECTORS_CODE) || (called_code == OBSERVABLES_CODE));
  
  const bool is_it_GSM_many_body_code = ((called_code != TWO_PARTICLE_RELATIVE_CODE) && (called_code != RDM_CODE));
  
  print_detailed_information = bool_determination ("print.detailed.information");
  
  if (is_it_GSM_structure_many_body_code)
    {
      only_dimensions = bool_determination ("dimensions.only");
      
      if (!only_dimensions) non_zero_NBMEs_proportion_only = bool_determination ("non.zero.NBMEs.proportion.only");
    }
  else
    only_dimensions = non_zero_NBMEs_proportion_only = copy_J_OBMEs_TBMEs = false;
    
  //--// the type of the interaction
  if ((called_code != TWO_PARTICLE_RELATIVE_CODE) && !only_dimensions && !non_zero_NBMEs_proportion_only)
    {
      cin >> inter;
      
      cout << "interaction : " << inter <<  endl;      
    }

  if (is_it_GSM_structure_many_body_code && !only_dimensions && !non_zero_NBMEs_proportion_only && (inter != FIT) && (inter != SU3_INTERACTION))
    copy_J_OBMEs_TBMEs = bool_determination ("coupled.OBMEs.TBMEs.copied");
  else
    copy_J_OBMEs_TBMEs = false;

  initial_pivot_from_file = (!only_dimensions && !non_zero_NBMEs_proportion_only && is_it_GSM_many_body_code) ? (bool_determination ("pivot.from.file")) : (false);
             
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && (called_code != TWO_PARTICLE_CODE) && (called_code != TWO_PARTICLE_RELATIVE_CODE) && (called_code != RDM_CODE))
    full_common_vectors_used_in_file = bool_determination ("full.common.vectors.used.in.file");
  
  if (called_code == TWO_PARTICLE_RELATIVE_CODE) inter = REALISTIC_INTERACTION;

  if (only_dimensions || non_zero_NBMEs_proportion_only)
    {
      inter = NO_INTERACTION;

      word_check ("basis.potential(Berggren.basis)");
      
      cin >> basis_potential;
      
      cout << "basis potential(Berggren basis): " << basis_potential << endl;
    }
  else if (inter == SU3_INTERACTION)
    basis_potential = HO_POTENTIAL;
  else
    {
      word_check ("basis.potential(Berggren.basis)");
      
      cin >> basis_potential;
      
      cout << "basis potential(Berggren basis): " << basis_potential << endl;
    }
    
  cout << endl;
}





void input_data_str::space_particles_number_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::space_particles_number_data_read");			

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  if (called_code == OPTIMIZATION_CODE)
    {
      cin >> basis_space;
      
      word_check_print<enum space_type> ("(largest.basis.space)" , basis_space);
  
      cin >> space;
  
      word_check_print<enum space_type> ("(largest.space)" , space);
      
      //--// test if the largest basis space is OK
      if ((basis_space != PROT_NEUT) && (basis_space != PROT_NEUT_Y) && (basis_space != PROT_NEUT_UNMIXED) && (basis_space != PROT_NEUT_UNMIXED_Y) && (basis_space != space))
	error_message_print_abort ("Largest basis space is protons-neutrons, protons-neutrons-hyperons, protons-neutrons-unmixed, protons-neutrons-unmixed-hyperons or the same as the largest GSM space");
      
      if ((basis_space != NEUT_ONLY) || (space != NEUT_ONLY))
	{
	  is_Coulomb_Hamiltonian_here = bool_determination ("Coulomb.Hamiltonian");

	  is_Coulomb_to_be_added = (is_Coulomb_Hamiltonian_here) ? (bool_determination ("Coulomb.interaction.to.be.added")) : (false);	      
	}
      
      A_dependence_read_calc ();
    }
  else
    {	
      const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
      
      const bool is_it_fit_or_SU3_or_HO = (is_it_fit_or_SU3 || (basis_potential == HO_POTENTIAL));
  
      if (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3_or_HO)
	{
	  cin >> basis_space;
	  
	  word_check_print<enum space_type> ("(basis.space)" , basis_space);

	  if ((basis_space == PROT_NEUT_UNMIXED) || (basis_space == PROT_NEUT_UNMIXED_Y)) error_message_print_abort ("Basis space cannot be protons-neutrons-unmixed or protons-neutrons-unmixed-hyperons");
	}

      cin >> space;
      
      word_check_print<enum space_type> ("(space)" , space);

      if ((space == PROT_NEUT_UNMIXED) || (space == PROT_NEUT_UNMIXED_Y)) error_message_print_abort ("GSM space cannot be protons-neutrons-unmixed or protons-neutrons-unmixed-hyperons");
      
      if (only_dimensions || non_zero_NBMEs_proportion_only || is_it_fit_or_SU3_or_HO) basis_space = space;
      
      //--// test if the basis space is ok
      if ((basis_space != PROT_NEUT) && (basis_space != PROT_NEUT_Y) && (basis_space != space)) error_message_print_abort ("Basis space is protons-neutrons, protons-neutrons-hyperons or the same as GSM space");
      
      //--// collect the number of protons and neutrons in each basis. Hyperons data are dummy here.
      if (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3_or_HO)
	{
	  int dummy_strangeness;
      
	  unsigned int dummy_N_hyperon_types;
	  
	  class array<enum particle_type> dummy_hyperon_types;
	  
	  valence_particle_number_baryons_read (true , basis_space , H_potential , Zval_basis , Nval_basis , dummy_strangeness , dummy_N_hyperon_types , dummy_hyperon_types);
	}
      
      valence_particle_number_baryons_read (false , space , H_potential , Zval , Nval , hypernucleus_strangeness , N_hyperon_types , hyperon_types);
  
      const bool is_it_FHT = is_it_FHT_determine (inter);
	  
      const bool is_it_EFT = is_it_EFT_determine (inter);
      
      if ((hypernucleus_strangeness > 0) && (inter != REALISTIC_INTERACTION) && !is_it_FHT && !is_it_EFT) error_message_print_abort ("Only FHT, EFT or realistic interactions can be used with hyperons");
      
      if (is_it_fit_or_SU3_or_HO && (N_hyperon_types > 0)) error_message_print_abort ("One cannot use the SU(3) interaction or HO potential + fit interaction with hypernuclei");
            
      const bool is_it_SDI = is_it_SDI_determine (inter);
	  
      const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);
	  
      const bool is_it_SDI_SGI_MSGI = (is_it_SDI || is_it_SGI_MSGI);
  
      if (is_it_SDI_SGI_MSGI && (N_hyperon_types > 0)) error_message_print_abort ("One cannot use the SDI, SGI and MSGI interactions with hypernuclei");
      
      if (only_dimensions || non_zero_NBMEs_proportion_only || is_it_fit_or_SU3_or_HO)
	{
	  Zval_basis = Zval;
	  Nval_basis = Nval;
	}
      
      ZYval = Zval;
      NYval = Nval;
      
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);
      
	  const int Y_charge = particle_charge_determine (hyperon);
      
	  if (Y_charge == 0) NYval++;
	  if (Y_charge != 0) ZYval++;
	}
            	
      //--// test if the previous numbers of p and n are coherent
      if ((Zval != Zval_basis) && (Nval != Nval_basis) && is_it_SDI_determine (inter))
	error_message_print_abort ("Hamiltonian potential and basis potential valence protons must have the same value when using the SDI interaction");
      
      //--// the Coulomb Hamiltonian
      is_Coulomb_Hamiltonian_here = (!only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3 && ((basis_space != NEUT_Y_ONLY) || (space != NEUT_Y_ONLY)) && ((basis_space != NEUT_ONLY) || (space != NEUT_ONLY)))
	? (bool_determination ("Coulomb.Hamiltonian"))
	: (false);
    }
  
  const bool are_there_hyperons_in_basis_space = ((basis_space == PROT_Y_ONLY) || (basis_space == NEUT_Y_ONLY) || (basis_space == PROT_NEUT_UNMIXED_Y) || (basis_space == PROT_NEUT_Y));

  if (are_there_hyperons_in_basis_space) error_message_print_abort ("One cannot have hyperons in basis space");
  
  are_there_hyperons = ((space == PROT_Y_ONLY) || (space == NEUT_Y_ONLY) || (space == PROT_NEUT_UNMIXED_Y) || (space == PROT_NEUT_Y));
  
  basis_space = space_type_reset (basis_space , hyperon_types);
  space       = space_type_reset (      space , hyperon_types);

  is_cv_possible = is_cv_possible_determine (Zval , Nval , hypernucleus_strangeness , hyperon_types);
  
  effective_masses_for_calc_p.allocate (Np_baryon_type);
  effective_masses_for_calc_n.allocate (Nn_baryon_type);

  effective_masses_for_calc_p = 1.0;
  effective_masses_for_calc_n = 1.0;
  
  //--// collect several parameters on p and n (mass , ...)
  if (called_code != OPTIMIZATION_CODE) particles_number_charges_masses_alloc_read_calc ();
    
  if (only_dimensions || non_zero_NBMEs_proportion_only || (inter == SU3_INTERACTION))
    good_isospin_basis_potential = false; // arbitrary
  else if (are_there_hyperons)
    good_isospin_basis_potential = (called_code != TWO_PARTICLE_RELATIVE_CODE) ? (bool_determination ("uncharged.baryon.basis.potential")) : (false);
  else
    good_isospin_basis_potential = (called_code != TWO_PARTICLE_RELATIVE_CODE) ? (bool_determination ("neutron.basis.potential")) : (false);
      
  if (good_isospin_basis_potential) ZY_charge_basis_potential_pos = ZY_charge_basis_potential_neg = 0;
	  
  cout << endl;
}









void input_data_str::interaction_format_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::interaction_format_read");			      
  
  if ((inter == REALISTIC_INTERACTION) && (called_code != TWO_PARTICLE_RELATIVE_CODE) && (called_code != CC_CODE)) 
    {
      cin >> lambda_Hcm;

      if (lambda_Hcm < 0) error_message_print_abort ("Hcm.coefficient must be positive or zero");
	
      word_check_print<double> ("(Hcm.coefficient)" , lambda_Hcm);
    }
  else
    lambda_Hcm = 0.0;
        
  if ((called_code == OPTIMIZATION_CODE) && !is_it_FHT_determine (inter) && !is_it_EFT_determine (inter)) error_message_print_abort ("One can only optimize the parameters of the FHT or EFT interaction");
  
  if ((called_code == TWO_PARTICLE_RELATIVE_CODE) && (inter != REALISTIC_INTERACTION)) error_message_print_abort ("Realistic interaction only with relative two-body systems");

  if ((called_code != TWO_PARTICLE_RELATIVE_CODE) && (inter != SU3_INTERACTION))
    {
      //--// OBMEs of the interaction read or not
      OBMEs_inter_read = bool_determination ("OBMEs.interaction.read");
    }

  if (inter != SU3_INTERACTION)
    {
      //--// the interaction is expressed in the labo or relative or ... coordinates
      cin >> inter_read;
      
      cout << inter_read << endl;
    }
  
  if (is_it_EFT_determine (inter) && (inter_read != LAB_HO_TBMES_READ)) error_message_print_abort ("Laboratory HO matrix elements read only with EFT interactions");
      
  if ((inter_read == LAB_BERGGREN_TBMES_READ) && (basis_potential != QBOX_POTENTIAL)) error_message_print_abort ("Qbox potential only with laboratory Berggren matrix elements read");
  
  if (!OBMEs_inter_read && (inter == FIT)) error_message_print_abort ("OBMEs must be read with fitted interaction from a file");
      
  if ((inter_read != LAB_BERGGREN_TBMES_READ) && (inter_read != LAB_HO_TBMES_READ) && (inter == FIT)) error_message_print_abort ("Laboratory Berggren or HO matrix elements read with fitted interactions stored on files");
      
  if ((basis_potential != QBOX_POTENTIAL) && (basis_potential != HO_POTENTIAL) && (inter == FIT)) error_message_print_abort ("Qbox or HO potential only read with fitted interactions stored on files");

  if ((basis_potential == HO_POTENTIAL) && (inter == FIT)) OBMEs_inter_read = false; // File format is done so that I have put this value to false here. But asking it to be false in the input file is contradictory as one uses OBMEs read from a file.
  
  cout << endl;
}












void input_data_str::pole_shells_to_consider (
					      const enum particle_type particle ,
					      const bool is_it_CC_Berggren , 
					      class array<class nlj_struct> &shells_quantum_numbers_pole)
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::pole_shells_to_consider");

  const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
  
  const bool is_it_HF_MSDHF_basis = ((basis_potential == HF) || (basis_potential == MSDHF));
  
  const bool is_it_COSM = is_it_COSM_determine (inter);

  const unsigned int N_nlj_pole  = shells_quantum_numbers_pole.dimension (0);
  	  
  bool is_it_OCM_HO_core = false;

  bool only_frozen_states = true;

  //--// for each shell
  for (unsigned int s = 0 ; s < N_nlj_pole ; s++)
    {
      string nlj_string = "";

      string word = "";
      
      bool core_state = false;

      bool frozen_state = false;

      bool hole_state = false;

      bool is_it_HO = false;

      bool is_it_natural_orbital = false;
	  
      class nlj_struct &shell_qn = shells_quantum_numbers_pole(s);
      
      //--// example: 0p3/2 S.matrix.pole
	  
      cin >> nlj_string;
	  
      const int n = determine_n (nlj_string);	  
      const int l = determine_l (nlj_string);
	  
      const double j = determine_j (nlj_string);
	  
      if (is_it_two_nucleon_ST_cluster_determine (particle))
	check_relative_partial_wave (l , make_int (j));
      else
	check_partial_wave (particle , l , j);
      
      int e_trunc = 2*n + l;
	  
      if (!is_it_CC_Berggren)
	{
	  cin >> word;
 
	  if      (word == "S.matrix.pole(core.frozen)")    core_state = true  , frozen_state = true  , hole_state = false , is_it_HO = false , is_it_natural_orbital = false;
	  else if (word == "S.matrix.pole(core.hole)")      core_state = true  , frozen_state = false , hole_state = true  , is_it_HO = false , is_it_natural_orbital = false;
	  else if (word == "S.matrix.pole")                 core_state = false , frozen_state = false , hole_state = false , is_it_HO = false , is_it_natural_orbital = false;
	  else if (word == "HO.state(core.frozen)")         core_state = true  , frozen_state = true  , hole_state = false , is_it_HO = true  , is_it_natural_orbital = false;
	  else if (word == "HO.state(core.hole)")           core_state = true  , frozen_state = false , hole_state = true  , is_it_HO = true  , is_it_natural_orbital = false;
	  else if (word == "HO.state(pole.like)")           core_state = false , frozen_state = false , hole_state = false , is_it_HO = true  , is_it_natural_orbital = false;
	  else if (word == "HO.natural.orbital(core.hole)") core_state = true  , frozen_state = false , hole_state = true  , is_it_HO = true  , is_it_natural_orbital = true;
	  else if (word == "natural.orbital(core.hole)")    core_state = true  , frozen_state = false , hole_state = true  , is_it_HO = false , is_it_natural_orbital = true;
	  else if (word == "natural.orbital(pole.like)")    core_state = false , frozen_state = false , hole_state = false , is_it_HO = false , is_it_natural_orbital = true;
	  else error_message_print_abort ("Error with " + nlj_string + " in string " + word + " from input file (GSM Berggren basis)");
  
	  cout << nlj_string << " " << word << " ";

	  if (!frozen_state)
	    {
	      cin >> e_trunc >> word;
  
	      if (word != "hw(truncation.energy)") error_message_print_abort ("hw(truncation.energy) should be read here.");

	      cout << " " << e_trunc << " " << word << " ";
	    }  
	}
      else
	{
	  cin >> word;
 
	  if      (word == "S.matrix.pole(core.frozen)") core_state = true  , frozen_state = true  , hole_state = false , is_it_HO = false , is_it_natural_orbital = false;
	  else if (word == "HO.state(core.frozen)")      core_state = true  , frozen_state = true  , hole_state = false , is_it_HO = true  , is_it_natural_orbital = false;
	  else if (word == "HO.state(core.hole)")        core_state = true  , frozen_state = false , hole_state = true  , is_it_HO = true  , is_it_natural_orbital = false;
	  else if (word == "S.matrix.pole")              core_state = false , frozen_state = false , hole_state = false , is_it_HO = false , is_it_natural_orbital = false;
	  else error_message_print_abort ("Error with " + nlj_string + " in string " + word + " from input file (GSM-CC Berggren basis)");

	  e_trunc = 0;
  
	  cout << nlj_string << " " << word << " ";
	}

      const complex<double> k_default = (is_it_HO) ? (sqrt (two_amu_over_hbar_square*(2*n + l))) : (0.0);
      
      shell_qn.initialize (true , core_state , frozen_state , hole_state , false , is_it_HO , false , is_it_natural_orbital , particle , e_trunc , n , l , j , NO_SEGMENT , k_default , 0.0 , 1.0 , 1.0 , 0.0 , 1.0 , 0.0 , 1.0);
      
      //--// some temporary constants

      bool is_it_for_HF_gs = false;

      if (is_it_HF_MSDHF_basis)
	{
	  if (is_it_natural_orbital)
	    error_message_print_abort ("Natural orbital cannot be used with HF/MSDHF potential");      
	  else if (core_state && frozen_state)
	    {
	      is_it_for_HF_gs = false;
	    
	      cout << endl;
	    }
	  else if (core_state && hole_state)
	    {
	      is_it_for_HF_gs = true;
	    
	      cout << endl;
	    }
	  else if (!core_state)
	    is_it_for_HF_gs = bool_determination ("HF.ground.state");
	}
      else
	cout << endl;
      
      shell_qn.set_is_it_for_HF_gs (is_it_for_HF_gs);
	
      //--// alias of "shells_quantum_numbers_pole(s)" of "nlj_struct" type
      //--// in clear: it is the shell "shells_quantum_numbers_pole(s)"

      if ((basis_potential == HO_POTENTIAL) && !is_it_HO) error_message_print_abort ("Basis states must be all HO if one uses a HO basis potential");
      
      if (!only_dimensions && !non_zero_NBMEs_proportion_only && is_it_fit_or_SU3 && (core_state || hole_state || is_it_natural_orbital))
	error_message_print_abort ("No core/hole/natural orbital allowed with fitted interactions stored on files or SU(3) interaction");      
      
      if ((only_dimensions || non_zero_NBMEs_proportion_only) && is_it_fit_or_SU3 && is_it_natural_orbital)
	error_message_print_abort ("No natural orbital allowed with only dimensions or non zero NBMEs_proportion calculated ");      
      
      if (core_state && is_it_HO) is_it_OCM_HO_core = true;
      
      if (core_state && !is_it_HO && is_it_OCM_HO_core) error_message_print_abort ("Core states must be all HO or none of them can be");

      if (!frozen_state) only_frozen_states = false;
            
      min_max_one_body_quantum_numbers_N_nlj_nljm_res_update (particle , shell_qn);
    }

  if (only_frozen_states) error_message_print_abort ("One cannot have only core frozen states for " + make_string<enum particle_type> (particle));

  for (unsigned int s = 0 ; s < N_nlj_pole ; s++)
    {
      class nlj_struct &shell_qn = shells_quantum_numbers_pole(s);

      const bool core_state = shell_qn.get_core_state ();

      const bool frozen_state = shell_qn.get_frozen_state ();

      const bool hole_state = shell_qn.get_hole_state ();

      const bool is_it_HO = shell_qn.get_is_it_HO ();

      const bool is_it_for_HF_gs = shell_qn.get_is_it_for_HF_gs ();

      const bool is_it_natural_orbital = shell_qn.get_is_it_natural_orbital ();

      const int e_trunc = shell_qn.get_e_trunc ();

      const int n = shell_qn.get_n ();
      const int l = shell_qn.get_l ();

      const double j = shell_qn.get_j ();

      const enum segment_type segment = shell_qn.get_segment ();

      const complex<double> k       = shell_qn.get_k ();
      const complex<double> k_plus  = shell_qn.get_k_plus ();
      const complex<double> k_minus = shell_qn.get_k_minus ();
      
      const complex<double> C0       = shell_qn.get_C0 ();
      const complex<double> C0_plus  = shell_qn.get_C0_plus ();
      const complex<double> C0_minus = shell_qn.get_C0_minus ();
      
      const complex<double> w = shell_qn.get_w ();
      
      const complex<double> Cplus = shell_qn.get_Cplus ();
      
      const bool OCM_valence_state = OCM_valence_state_determine (shells_quantum_numbers_pole , is_it_COSM , core_state , is_it_HO , is_it_natural_orbital , particle , l , j);
      
      shell_qn.initialize (true , core_state , frozen_state , hole_state , OCM_valence_state , is_it_HO , is_it_for_HF_gs , is_it_natural_orbital ,
			   particle , e_trunc , n , l , j , segment , k , w , C0 , Cplus , k_plus , C0_plus , k_minus , C0_minus);
    }

  if (N_nlj_pole > 0) shells_quantum_numbers_pole.quick_sort (0 , N_nlj_pole - 1);
  
  cout << endl;
}




void input_data_str::scattering_like_shells_to_consider (
							 const enum particle_type particle , 
							 const class array<class nlj_struct> &shells_quantum_numbers_pole ,
							 class array<class array<class nlj_struct> > &shells_quantum_numbers_scattering_like_tab)
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::scattering_like_shells_to_consider");

  const unsigned int N_partial_waves_scattering_like = shells_quantum_numbers_scattering_like_tab.dimension (0);
  
  const bool is_it_COSM = is_it_COSM_determine (inter);

  const string particle_string = make_string<enum particle_type> (particle);

  word_check ("partial.wave");
  word_check ("partial.wave.type");
  word_check ("n.min");
  word_check ("n.max");
  word_check ("truncation.energies(hw)");
  
  cout << "partial.wave   partial.wave.type   n.min n.max   truncation.energies(hw)" << endl;
  
  //--// for each shell
  for (unsigned int i = 0 ; i < N_partial_waves_scattering_like ; i++)
    {
      string partial_wave;
      string partial_wave_bef;
      string partial_wave_type;

      int n_min_partial_wave;
      int n_max_partial_wave;
  
      cin >> partial_wave >> partial_wave_type >> n_min_partial_wave >> n_max_partial_wave;

      if ((i > 0) && (partial_wave_bef == partial_wave)) error_message_print_abort ("Problem with scattering-like shells");
      
      const unsigned int N_scattering_like_states_partial_wave = make_uns_int (n_max_partial_wave - n_min_partial_wave) + 1;
      
      class array<int> e_trunc_tab(N_scattering_like_states_partial_wave);
      
      for (int n = n_min_partial_wave ; n <= n_max_partial_wave ; n++)
	{
	  cin >> e_trunc_tab(n - n_min_partial_wave);

	  if (e_trunc_tab(n - n_min_partial_wave) < 0) error_message_print_abort ("truncation.energy(hw) in position n=" + make_string<int> (n) + " must be positive or zero");
	}
      
      cout << partial_wave << " " << partial_wave_type << " " << n_min_partial_wave << " " << n_max_partial_wave << "   ";

      for (int n = n_min_partial_wave ; n <= n_max_partial_wave ; n++) cout << e_trunc_tab(n - n_min_partial_wave) << " ";
      
      cout << endl;
	     
      const int l = determine_l (partial_wave);
      
      const double j = determine_j (partial_wave);
      
      if (is_it_two_nucleon_ST_cluster_determine (particle))
	check_relative_partial_wave (l , make_int (j));
      else
        check_partial_wave (particle , l , j);
 
      const bool is_it_HO = (partial_wave_type == "HO.state");

      const bool is_it_natural_orbital = (partial_wave_type == "natural.orbital");

      if (!is_it_HO && !is_it_natural_orbital) error_message_print_abort ("One has to have HO or natural orbital for scattering like states for " + particle_string + " " + partial_wave);
      
      class array<class nlj_struct> &shells_quantum_numbers_partial_wave_scattering_like = shells_quantum_numbers_scattering_like_tab(i);

      shells_quantum_numbers_partial_wave_scattering_like.allocate (N_scattering_like_states_partial_wave);
      
      for (int n = n_min_partial_wave ; n <= n_max_partial_wave ; n++)
	{
	  const unsigned int s = make_uns_int (n - n_min_partial_wave);

	  const int e_trunc = e_trunc_tab(s);
	  
	  const bool OCM_valence_state = OCM_valence_state_determine (shells_quantum_numbers_pole , is_it_COSM , false , is_it_HO , is_it_natural_orbital , particle , l , j);
	  
	  class nlj_struct &shell_qn = shells_quantum_numbers_partial_wave_scattering_like(s);
  
	  shell_qn.initialize (false , false , false , false , OCM_valence_state , is_it_HO , false , is_it_natural_orbital ,
			       particle , e_trunc , n , l , j , NO_SEGMENT , NADA , NADA , NADA , NADA , NADA , NADA , NADA , NADA);

	  min_max_one_body_quantum_numbers_N_nlj_nljm_res_update (particle , shell_qn);	    
	}

      partial_wave_bef = partial_wave;
    }

  cout << endl;
}




void input_data_str::contours_tables_Qbox_fill (
					        const enum particle_type particle , 
						unsigned int &N_nlj_paths , 
						class array<int> &l_array , 
						class array<double> &j_array , 
						class array<unsigned int> &N_k_peak_tab , 
						class array<unsigned int> &N_k_middle_tab , 
						class array<unsigned int> &N_k_max_tab , 
						class array<int> &scat_e_trunc_tab) const
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::contours_tables_Qbox_fill");

  const unsigned int N_paths = l_array.dimension (0);

  //--// tab to store temporary the parameters of the complex contour

  N_nlj_paths = 0;

  word_check ("partial.wave");
  word_check ("N.k.peak");
  word_check ("N.k.middle");
  word_check ("N.k.max");
  word_check ("hw(truncation.energy)");

  cout << "partial.wave   N.k.peak N.k.middle N.k.max   hw(truncation.energy)" << endl;
    
  //--// for each complex contour
  for (unsigned int p = 0 ; p < N_paths ; p++)
    {      
      //--// scat state considered (example: p3/2)
      
      //--// parameters of the complex contour
      string path;

      string path_bef;
  
      cin >> path >> N_k_peak_tab(p) >> N_k_middle_tab(p) >> N_k_max_tab(p) >> scat_e_trunc_tab(p);

      if ((p > 0) && (path_bef == path)) error_message_print_abort ("Problem with scattering-like shells (Qbox)");
      
      if (scat_e_trunc_tab(p) < 0) error_message_print_abort ("truncation.energy(hw) in " + make_string<enum particle_type> (particle) + " " + path + " contour must be positive or zero (Qbox)");
     
      cout << path << "    " << N_k_peak_tab(p) << " " << N_k_middle_tab(p) << " " << N_k_max_tab(p) << "   " << scat_e_trunc_tab(p) << endl;

      l_array(p) = determine_l (path);
      j_array(p) = determine_j (path);

      if (is_it_two_nucleon_ST_cluster_determine (particle))
	check_relative_partial_wave (l_array(p) , make_int (j_array(p)));
      else
	check_partial_wave (particle , l_array(p) , j_array(p));
      
      //--// number of scat states
      const unsigned int N_scat = N_k_peak_tab(p) + N_k_middle_tab(p) + N_k_max_tab(p);

      //--// number of complex contours
      N_nlj_paths += N_scat;

      path_bef = path;
    }

  cout << endl;
}




void input_data_str::contours_tables_fill (
					   const enum particle_type particle ,
					   const bool is_it_CC_Berggren ,   
					   unsigned int &N_nlj_paths , 
					   class array<int> &l_array , 
					   class array<double> &j_array , 
					   class array<complex<double> > &k_peak_tab , 
					   class array<complex<double> > &k_middle_tab , 
					   class array<complex<double> > &k_max_tab , 
					   class array<unsigned int> &N_k_peak_tab , 
					   class array<unsigned int> &N_k_middle_tab , 
					   class array<unsigned int> &N_k_max_tab , 
					   class array<int> &scat_e_trunc_tab) const
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::contours_tables_fill");

  const unsigned int N_paths = l_array.dimension (0);

  //--// tab to store temporary the parameters of the complex contour

  N_nlj_paths = 0;

  word_check ("partial.wave");
  word_check ("k.peak(fm^(-1))");
  word_check ("k.middle(fm^(-1))");
  word_check ("k.max(fm^(-1))");
  word_check ("N.k.peak");
  word_check ("N.k.middle");
  word_check ("N.k.max");

  if (!is_it_CC_Berggren)
    {
      word_check ("hw(truncation.energy)");

      cout << "partial.wave   k.peak(fm^(-1)) k.middle(fm^(-1)) k.max(fm^(-1))   N.k.peak N.k.middle N.k.max   hw(truncation.energy)" << endl;
    }
  else
    cout << "partial.wave   k.peak(fm^(-1)) k.middle(fm^(-1)) k.max(fm^(-1))   N.k.peak N.k.middle N.k.max" << endl;

  scat_e_trunc_tab = 0;
  
  //--// for each complex contour
  for (unsigned int p = 0 ; p < N_paths ; p++)
    {      
      //--// scat state considered (example: p3/2)
      
      //--// parameters of the complex contour
      string path;

      string path_bef;
      
      if (!is_it_CC_Berggren)
	cin >> path >> k_peak_tab(p) >> k_middle_tab(p) >> k_max_tab(p) >> N_k_peak_tab(p) >> N_k_middle_tab(p) >> N_k_max_tab(p) >> scat_e_trunc_tab(p);
      else
	cin >> path >> k_peak_tab(p) >> k_middle_tab(p) >> k_max_tab(p) >> N_k_peak_tab(p) >> N_k_middle_tab(p) >> N_k_max_tab(p);

      if (scat_e_trunc_tab(p) < 0) error_message_print_abort ("truncation.energy(hw) in " + make_string<enum particle_type> (particle) + " " + path + " contour must be positive or zero");
      
      if ((p > 0) && (path_bef == path)) error_message_print_abort ("Problem with scattering shells");
    
      if (!is_it_CC_Berggren)
	cout << path << "    "
	     <<   k_peak_tab(p) << " " <<   k_middle_tab(p) << " " <<   k_max_tab(p) << "   "
	     << N_k_peak_tab(p) << " " << N_k_middle_tab(p) << " " << N_k_max_tab(p) << "   " << scat_e_trunc_tab(p) << endl;
      else
	cout << path << "    "
	     <<   k_peak_tab(p) << " " <<   k_middle_tab(p) << " " <<   k_max_tab(p) << "   "
	     << N_k_peak_tab(p) << " " << N_k_middle_tab(p) << " " << N_k_max_tab(p) << endl;
  
      l_array(p) = determine_l (path);
      j_array(p) = determine_j (path);

      if (is_it_two_nucleon_ST_cluster_determine (particle))
	check_relative_partial_wave (l_array(p) , make_int (j_array(p)));
      else
	check_partial_wave (particle , l_array(p) , j_array(p));
       
      //--// number of scat states
      const unsigned int N_scat = N_k_peak_tab(p) + N_k_middle_tab(p) + N_k_max_tab(p);

      //--// number of complex contours
      N_nlj_paths += N_scat;

      path_bef = path;
    }

  cout << endl;
}




void input_data_str::shells_to_consider (
					 const enum particle_type particle , 
					 const bool is_it_CC_Berggren)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::shells_to_consider");

  if (is_it_CC_Berggren && (particle_strangeness_determine (particle) > 0)) error_message_print_abort ("One cannot have hyperons in the GSM-CC Berggren basis");

  const int strangeness = particle_strangeness_determine (particle);
  
  const int charge = particle_charge_determine (particle);  
    
  unsigned int N_nlj_particle_pole = 0;

  unsigned int N_partial_waves_scattering_like = 0;
  
  //--// number of particles (protons, neutrons, plus a few hyperons if any) pole like states to consider
  //--// example: 1 neutron.pole.like.state(s)

  cin >> N_nlj_particle_pole;

  if (!is_it_CC_Berggren)
    word_check_print<unsigned int> (make_string<enum particle_type> (particle) + ".pole.state(s)" , N_nlj_particle_pole);
  else
    word_check_print<unsigned int> ("CC.Berggren.basis." + make_string<enum particle_type> (particle) + ".pole.state(s)" , N_nlj_particle_pole);
    
  class array<class nlj_struct> shells_quantum_numbers_pole (N_nlj_particle_pole);

  if (N_nlj_particle_pole > 0) pole_shells_to_consider (particle , is_it_CC_Berggren , shells_quantum_numbers_pole);
  
  //--// number of particles (protons, neutrons, hyperons) scattering-like partial waves to consider
  // example: 3 neutron.scattering.like.partial.wave(s)

  if (!is_it_CC_Berggren)
    {  
      cin >> N_partial_waves_scattering_like;

      word_check_print<unsigned int> (make_string<enum particle_type> (particle) + ".scattering.like.partial.wave(s)" , N_partial_waves_scattering_like);
    }
  else
    N_partial_waves_scattering_like = 0;
  
  class array<class array<class nlj_struct> > shells_quantum_numbers_scattering_like_tab (N_partial_waves_scattering_like);
      
  if (N_partial_waves_scattering_like > 0) scattering_like_shells_to_consider (particle , shells_quantum_numbers_pole , shells_quantum_numbers_scattering_like_tab);  

  const unsigned int N_nlj_particle_discrete = N_nlj_particle_discrete_calc (N_nlj_particle_pole , shells_quantum_numbers_scattering_like_tab);
    
  //--// tab to store temporary all the shells considered
  //--// example: 0p3/2 S.matrix.pole (yes)
  class array<class nlj_struct> shells_quantum_numbers_discrete (N_nlj_particle_discrete);

  unsigned int index_discrete = 0;
  
  for (unsigned int i = 0 ; i < N_nlj_particle_pole ; i++) shells_quantum_numbers_discrete(index_discrete++) = shells_quantum_numbers_pole(i);
  
  for (unsigned int i = 0 ; i < N_partial_waves_scattering_like ; i++)
    {
      const class array<class nlj_struct> &shells_quantum_numbers_partial_wave_scattering_like = shells_quantum_numbers_scattering_like_tab(i);

      const unsigned int N_scattering_like_states_partial_wave = shells_quantum_numbers_partial_wave_scattering_like.dimension (0);
      
      for (unsigned int ii = 0 ; ii < N_scattering_like_states_partial_wave ; ii++)
	shells_quantum_numbers_discrete(index_discrete++) = shells_quantum_numbers_partial_wave_scattering_like(ii);
    }

  unsigned int N_paths = 0;
  
  if (basis_potential != HO_POTENTIAL)
    {
      //--// number of contours in the complex plane
      //--// example: 1 neutron.contour(s)
      
      cin >> N_paths;
      
      if (!is_it_CC_Berggren)
	word_check_print<unsigned int> (make_string<enum particle_type> (particle) + ".contour(s)" , N_paths);
      else
	word_check_print<unsigned int> ("CC.Berggren.basis." + make_string<enum particle_type> (particle) + ".contour(s)" , N_paths);
    }
  
  class array<int> l_array(N_paths);
  
  class array<double> j_array(N_paths);

  class array<complex<double> > k_peak_tab(N_paths);
  class array<complex<double> > k_middle_tab(N_paths);
  class array<complex<double> > k_max_tab(N_paths);

  class array<unsigned int> N_k_peak_tab(N_paths);
  class array<unsigned int> N_k_middle_tab(N_paths);
  class array<unsigned int> N_k_max_tab(N_paths);

  class array<int> scat_e_trunc_tab(N_paths);
      
  unsigned int N_nlj_particle_paths = 0;
  
  if (N_paths > 0)
    {
      if (!is_it_CC_Berggren && (basis_potential == QBOX_POTENTIAL))
	{
	  k_peak_tab   = NADA;
	  k_middle_tab = NADA;
	  k_max_tab    = NADA;
	    
	  contours_tables_Qbox_fill (particle , N_nlj_particle_paths , l_array , j_array , N_k_peak_tab , N_k_middle_tab , N_k_max_tab , scat_e_trunc_tab);
	}
      else
	contours_tables_fill (particle , is_it_CC_Berggren , N_nlj_particle_paths , l_array , j_array , k_peak_tab , k_middle_tab , k_max_tab , N_k_peak_tab , N_k_middle_tab , N_k_max_tab , scat_e_trunc_tab);
    }

  const unsigned int N_nlj_particle = N_nlj_particle_discrete + N_nlj_particle_paths;
  
  class array<class nlj_struct> &shells_quantum_numbers = shells_quantum_numbers_determine (particle);

  if (is_it_two_nucleon_ST_cluster_determine (particle))
    N_nlj_relative = N_nlj_particle;
  else
    {
      const unsigned int particle_index = charge_baryon_index_determine (particle);
      
      if (charge != 0)
	Np_nlj_baryon_tab(particle_index) = N_nlj_particle;
      else if (charge == 0)
	Nn_nlj_baryon_tab(particle_index) = N_nlj_particle;
    }
    
  shells_quantum_numbers.allocate (N_nlj_particle);
    
  for (unsigned int s = 0 ; s < N_nlj_particle_discrete ; s++) shells_quantum_numbers(s) = shells_quantum_numbers_discrete(s);
  
  if (basis_potential != HO_POTENTIAL)
    shells_quantum_numbers_contours_data_fill (particle , shells_quantum_numbers_discrete , l_array , j_array , k_peak_tab , k_middle_tab , k_max_tab , N_k_peak_tab , N_k_middle_tab , N_k_max_tab , scat_e_trunc_tab);
  
  //--// for each shell

  int available_pole_states = 0;
      
  if (strangeness == 0)
    {
      if (particle == PROTON)  prot_hole_states_number = 0;
      if (particle == NEUTRON) neut_hole_states_number = 0;
    }

  for (unsigned int s = 0 ; s < N_nlj_particle ; s++)
    {
      //--// alias of "shells_quantum_numbers[s]" of type "nlj_struct"
      const class nlj_struct &shell_qn = shells_quantum_numbers(s);

      const bool S_matrix_pole = shell_qn.get_S_matrix_pole ();

      if (S_matrix_pole) available_pole_states += shell_qn.m_number_determine ();

      if (strangeness == 0)
	{
	  const bool core_state = shell_qn.get_core_state ();
	  const bool hole_state = shell_qn.get_hole_state ();

	  if (core_state && hole_state)
	    {
	      const int hole_states_number = shell_qn.m_number_determine ();
    
	      if (particle == PROTON)  prot_hole_states_number += hole_states_number;
	      if (particle == NEUTRON) neut_hole_states_number += hole_states_number;
	    }
	}
    }
  
  if (!is_it_CC_Berggren && (strangeness == 0))
    {
      if (particle == PROTON)  Zval += prot_hole_states_number , Zval_basis += prot_hole_states_number , ZYval += prot_hole_states_number;
      if (particle == NEUTRON) Nval += neut_hole_states_number , Nval_basis += neut_hole_states_number , NYval += neut_hole_states_number;
    }

  particle_number_consistency_tests (particle , available_pole_states);
 
  if (!is_it_two_nucleon_ST_cluster_determine (particle)) max_angular_momentum_projection_data_determine (particle);
  
  cout << endl;
}






 
void input_data_str::one_body_relative_basis_core_potential_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::one_body_relative_basis_core_potential_data_alloc_read");

  //--// collect several parameters to determine shells in the basis space

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
      
  lmax_baryon_p_tab.allocate (Np_baryon_type);
  lmax_baryon_n_tab.allocate (Nn_baryon_type);
      
  lmax_common_baryon_p_tab.allocate (Np_baryon_type);
  lmax_common_baryon_n_tab.allocate (Nn_baryon_type);

  Np_nlj_baryon_tab.allocate (Np_baryon_type);
  Nn_nlj_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nlj_res_baryon_tab.allocate (Np_baryon_type);
  Nn_nlj_res_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nljm_baryon_tab.allocate (Np_baryon_type);
  Nn_nljm_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nljm_res_baryon_tab.allocate (Np_baryon_type);
  Nn_nljm_res_baryon_tab.allocate (Nn_baryon_type);
            
  shells_quantum_numbers_p_tab.allocate (Np_baryon_type);
  shells_quantum_numbers_n_tab.allocate (Nn_baryon_type);
	  
  are_there_basis_natural_orbitals_p_tab.allocate (Np_baryon_type);
  are_there_basis_natural_orbitals_n_tab.allocate (Nn_baryon_type);
	    
  lmax_baryon_p_tab = 0;
  lmax_baryon_n_tab = 0;
      
  lmax_common_baryon_p_tab = 0;
  lmax_common_baryon_n_tab = 0;
      
  Np_nlj_baryon_tab = 0;
  Nn_nlj_baryon_tab = 0;
      
  Np_nlj_res_baryon_tab = 0;
  Nn_nlj_res_baryon_tab = 0;
      
  Np_nljm_baryon_tab = 0;
  Nn_nljm_baryon_tab = 0;
      
  Np_nljm_res_baryon_tab = 0;
  Nn_nljm_res_baryon_tab = 0;
        
  are_there_basis_natural_orbitals_p_tab = false;
  are_there_basis_natural_orbitals_n_tab = false;
  
  if (called_code != OPTIMIZATION_CODE)
    {
      const unsigned int prot_index = charge_baryon_index_determine (PROTON);
      const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
      class array<class nlj_struct> &prot_shells_quantum_numbers = shells_quantum_numbers_p_tab(prot_index);
      class array<class nlj_struct> &neut_shells_quantum_numbers = shells_quantum_numbers_n_tab(neut_index);
      
      if (basis_space != NEUT_Y_ONLY)
	{  
	  shells_to_consider (PROTON , false);
	  
	  shells_consistency_tests (prot_shells_quantum_numbers);
	}
      
      if (basis_space != PROT_Y_ONLY)
	{  
	  shells_to_consider (NEUTRON , false);
	  
	  shells_consistency_tests (neut_shells_quantum_numbers);
	}
          
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);
	  
	  class array<class nlj_struct> &hyperon_shells_quantum_numbers = shells_quantum_numbers_determine(hyperon);
	  
	  shells_to_consider (hyperon , false);
	  
	  shells_consistency_tests (hyperon_shells_quantum_numbers);
	}
      
      if (called_code == TWO_PARTICLE_RELATIVE_CODE) 
	{
	  cin >> relative_cluster;

	  const int Z_relative_cluster = Z_cluster_determine (relative_cluster);
	  const int N_relative_cluster = N_cluster_determine (relative_cluster);

	  if ((Z_relative_cluster != Z) || (N_relative_cluster != N)) error_message_print_abort ("Wrong two-body cluster for Z=" + make_string<int> (Z) + " , N=" + make_string<int> (N) + ": " + make_string<enum particle_type> (relative_cluster));

	  cout << relative_cluster << endl << endl;

	  shells_to_consider (relative_cluster , false);
	  
	  shells_consistency_tests (shells_quantum_numbers_relative);	  
	}
      
      lmax_common_p = lmax_p;
      lmax_common_n = lmax_n;
      
      lmax_common_baryon_p_tab = lmax_baryon_p_tab;
      lmax_common_baryon_n_tab = lmax_baryon_n_tab;
      
      //--// collect several parameters for the core and basis potentials
      core_potential_data_alloc_read ();

      basis_core_potential_data_alloc_read ();

      basis_potential_data_alloc_read ();
    }
  
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && ((called_code == OPTIMIZATION_CODE) || (prot_hole_states_number > 0) || (neut_hole_states_number > 0)))
    is_hole_double_counting_suppressed = bool_determination ("hole.double.counting.suppressed");
  else
    is_hole_double_counting_suppressed = false;
  
  cout << endl;
}










void input_data_str::truncation_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::truncation_data_read");
    
  truncation_hw = bool_determination ("truncation.hw");

  if (truncation_hw)
    {
      cin >> E_relative_max_hw_pole_approximation;
      
      word_check_print<int> ("hw[maximal.truncation.energy.pole.approximation/ground.state]" , E_relative_max_hw_pole_approximation);

      cin >> E_relative_max_hw;

      word_check_print<int> ("hw[maximal.truncation.energy/ground.state]" , E_relative_max_hw);

      if (E_relative_max_hw_pole_approximation < 0)
	error_message_print_abort ("maximal.truncation.energy.pole.approximation must be positive");
      
      if (E_relative_max_hw_pole_approximation > E_relative_max_hw)
	error_message_print_abort ("One must have maximal.truncation.energy.pole.approximation <= SD.maximal.truncation.energy");
    }
  else
    E_relative_max_hw_pole_approximation = E_relative_max_hw = NADA;

  truncation_ph = bool_determination ("truncation.particle.hole");

  if (truncation_ph)
    {
      if (((called_code == OPTIMIZATION_CODE) || (prot_hole_states_number > 0) || (neut_hole_states_number > 0)))
	{
	  all_n_holes_max_read (true  , space , n_holes_max_pole_approximation , n_holes_max_p_pole_approximation , n_holes_max_n_pole_approximation);      
	  all_n_holes_max_read (false , space , n_holes_max                    , n_holes_max_p                    , n_holes_max_n);
	}

      if (called_code != OPTIMIZATION_CODE) holes_consistency_tests ();
        
      if (n_holes_max_p_pole_approximation > n_holes_max_p) error_message_print_abort ("One must have proton.hole.states.pole.approximation.max <= proton.hole.states.max");
      if (n_holes_max_n_pole_approximation > n_holes_max_n) error_message_print_abort ("One must have neutron.hole.states.pole.approximation.max <= neutron.hole.states.max");
      if (n_holes_max_pole_approximation   > n_holes_max)   error_message_print_abort ("One must have total.hole.states.pole.approximation <= total.hole.states");
  
      all_n_scat_read (space , n_scat_max , n_scat_max_p , n_scat_max_n);
    }
  else
    {
      n_holes_max_p_pole_approximation = n_holes_max_p = 10000;
      n_holes_max_n_pole_approximation = n_holes_max_n = 10000;
      n_holes_max_pole_approximation   = n_holes_max   = 10000;
    }
  
  if (called_code != OPTIMIZATION_CODE) all_E_max_hw_calc ();

  cout << endl;
}









void input_data_str::storage_diagonalization_RDM_linear_system_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::storage_diagonalization_RDM_linear_system_data_read");
    
  if (called_code == RDM_CODE)
    {
      string method;

      cin >> method;

      cout << method << endl;

      if (method == "BiCG") 
	RDM_is_it_BiCG = true;
      else if (method == "LU.Cholesky.decomposition") 
	RDM_is_it_BiCG = false;      
      else 
	error_message_print_abort ("Method to solve the Hessian linear systems undefined : " + method);
	  
      if (RDM_is_it_BiCG)
	{      
	  cin >> test_vector_solution;

	  word_check_print<double> ("(linear.system.solution.precision)" , test_vector_solution);

	  if (test_vector_solution <= 0) error_message_print_abort ("linear.system.solution.precision must be positive");
	}
    }
  else
    {
      const bool is_it_simple_diagonalization_code = ((called_code != CC_CODE) && (called_code != OPTIMIZATION_CODE));
      
      //--// H and J+/J-, as well as uncoupled TBMEs and a+ a proton-neutron matrix elements (one jumps proton neutron) stored as matrix (FULL_STORAGE), both as matrix and on the fly (PARTIAL_STORAGE), or on the fly (ON_THE_FLY)
      
      if (!non_zero_NBMEs_proportion_only)
	{
	  if (called_code != TWO_PARTICLE_CODE)
	    {
	      cin >> Hamiltonian_storage;
	  
	      word_check ("(Hamiltonian)");
	  
	      cout << Hamiltonian_storage << " (Hamiltonian)" << endl;
	  
	      switch (Hamiltonian_storage)
		{
		case FULL_STORAGE: M_TBMEs_storage = one_jumps_pn_two_jumps_cv_storage = ON_THE_FLY; break; // One chooses the least amount of memory to store besides Hamiltonian. It is used only during Hamiltonian construction. 

		case PARTIAL_STORAGE:
		  {
		    M_TBMEs_storage = FULL_STORAGE; // It is necessary to store all uncoupled TBMEs with partial storage.

		    one_jumps_pn_two_jumps_cv_storage = ON_THE_FLY; // One chooses the least amount of memory to store besides Hamiltonian and uncoupled TBMEs. It is used only during Hamiltonian construction. 
		  } break;

		case ON_THE_FLY:
		  {
		    cin >> M_TBMEs_storage;
		
		    word_check ("(uncoupled.TBMEs)");
		
		    if ((space != PROT_NEUT_Y) && (M_TBMEs_storage == PARTIAL_STORAGE)) error_message_print_abort ("Partial storage for uncoupled TBMEs is impossible with valence protons only or valence neutrons only");
		
		    cout << M_TBMEs_storage << " (uncoupled.TBMEs)" << endl;
		
		    if (space == PROT_NEUT_Y)
		      {
			cin >> one_jumps_pn_two_jumps_cv_storage;

			if (are_there_hyperons)
			  {
			    word_check ("(one.jumps.pn.two.jumps.pp.nn.conversions)");
		    
			    cout << one_jumps_pn_two_jumps_cv_storage << " (one.jumps.pn.two.jumps.pp.nn.conversions)" << endl;
			  }
			else
			  {
			    word_check ("(one.jumps.proton.neutron)");
		    
			    cout << one_jumps_pn_two_jumps_cv_storage << " (one.jumps.proton.neutron)" << endl;
			  }
		      }
		  } break;
	      
		default: abort_all ();
		}	  
	    }
	  else
	    Hamiltonian_storage = FULL_STORAGE;
      
	  if (is_it_simple_diagonalization_code)
	    {
	      is_it_Lanczos = false;

	      string method;
	  
	      cin >> method;

	      cout << method << endl;

	      if (method == "Lanczos") 
		is_it_Lanczos = true;
	      else if (method == "Davidson") 
		is_it_Lanczos = false;
	      else 
		error_message_print_abort ("Method to find eigenvectors undefined : " + method);

	      if (is_it_Lanczos)
		{	  
		  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
		    {
		      const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

		      for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
			{			  
			  if (PSI_qn_from_file_tab(eigenset_index , i).get_vector_index () != i)
			    error_message_print_abort ("All eigenvectors from the ground state to the last considered excited state must be present sequentially in a given eigenset with the Lanczos method (diagonalization codes)");
			}
		    }
		}
          
	      cin >> N_restarts;
	  
	      word_check_print<unsigned int> ("Lanczos/Davidson.restarts" , N_restarts);
	    }
	}
      else
	{
	  Hamiltonian_storage = FULL_STORAGE;

	  M_TBMEs_storage = one_jumps_pn_two_jumps_cv_storage = ON_THE_FLY;
	}
      
      if ((called_code != CC_CODE) && ((called_code != OPTIMIZATION_CODE) || ((called_code == OPTIMIZATION_CODE) && print_detailed_information)))
	{
	  if (!non_zero_NBMEs_proportion_only)
	    {
	      are_configuration_probabilities_printed = bool_determination ("configuration.probabilities.printed");
	  
	      if (are_configuration_probabilities_printed)
		{
		  are_scattering_configuration_probabilities_printed = bool_determination ("scattering.configuration.probabilities.printed");
	      
		  cin >> configuration_precision;
	      
		  if (configuration_precision < 0) error_message_print_abort ("configuration.minimal.probability.printed must be positive or zero");
	      
		  word_check_print<double> ("(configuration.minimal.probability.printed)" , configuration_precision);
		} 
	    }	  
	}
      
      all_states_calculated = (!non_zero_NBMEs_proportion_only && is_it_Lanczos && (called_code != CC_CODE) && (called_code != OPTIMIZATION_CODE)) ? (bool_determination ("all.states.calculated")) : (false);
      
      if (!non_zero_NBMEs_proportion_only)
	{
	  if (called_code != CC_CODE)
	    {
	      are_GSM_vectors_stored_on_disk = (called_code != TWO_PARTICLE_CODE) ? (bool_determination ("vectors.stored.on.disk")) : (false);

	      cin >> workspace_max_dimension;
	  
	      word_check_print<unsigned int> ("vectors" , workspace_max_dimension);

	      cin >> test_vector_solution;

	      if (test_vector_solution <= 0) error_message_print_abort ("eigenvector.precision must be positive");
	  
	      word_check_print<double> ("(eigenvector.precision)" , test_vector_solution);
	    }
	  
	  if (called_code != TWO_PARTICLE_CODE)
	    {
	      J_projected = (is_it_Lanczos && !all_states_calculated && (called_code != OPTIMIZATION_CODE)) ? (bool_determination ("J.projected")) : (true);

	      if (J_projected)
		{
		  string J_projection_str;
		  
		  cin >> J_projection_str;

		  cout << J_projection_str << endl;
		  
		  if (J_projection_str == "Lowdin.J.projection")
		    is_it_Lowdin = true;
		  else if (J_projection_str == "Lanczos.J.projection")
		    is_it_Lowdin = false;
		  else
		    error_message_print_abort ("J-projection method not recognized : " + J_projection_str);
		}
	    }
	  else
	    J_projected = true;
	      
	  if ((called_code != CC_CODE) && ((called_code != OPTIMIZATION_CODE) || ((called_code == OPTIMIZATION_CODE) && print_detailed_information))) T2_CM_operators_calculated = bool_determination ("T2.CM.operators.calculated");
	}
      else
	J_projected = true;

      if (called_code != CC_CODE)
	{
	  M_equal_J_imposed_in_GSM_vectors = ((called_code != TWO_PARTICLE_CODE) && J_projected) ? (bool_determination ("M=J.imposed.in.GSM.vectors")) : (true);
	  
	  // If J is not projected, what is denoted J in "M=J" is the minimal angular momentum Jmin that is considered in the calculation. Thus, one always takes M = Jmin if J is not projected.
      
	  if (!non_zero_NBMEs_proportion_only && (called_code != TWO_PARTICLE_CODE) && (called_code != OPTIMIZATION_CODE))
	    is_there_disk_storage_eigenvectors_all_M = bool_determination ("eigenvectors.all.M.projections.disk.storage");
	  else
	    is_there_disk_storage_eigenvectors_all_M = false;
	}
      else
	{
	  M_equal_J_imposed_in_GSM_vectors = false;
	  
	  is_there_disk_storage_eigenvectors_all_M = true;
	}
    }
  
  cout << endl;
}







// A dependence is applied in interaction_class if the optimization code is not used. If it is used, A-dependence is applied on FHT_EFT_parameters directly.

void input_data_str::A_dependence_read_calc ()
{
  const bool is_there_A_dependence = bool_determination ("A.dependence");
  
  if (is_there_A_dependence)
    {      
      if (inter_read == LAB_BERGGREN_TBMES_READ) error_message_print_abort ("No A dependence allowed with laboratory Berggren matrix elements read from file");

      cin >> A_dependence_alpha_core_potential;

      word_check_print<double> ("(A.dependence.alpha.core.potential)" , A_dependence_alpha_core_potential);
      
      cin >> A_dependence_exponent;
      
      word_check_print<double> ("(A.dependence.exponent)" , A_dependence_exponent);

      if ((A_dependence_exponent != 0.0) && is_Coulomb_Hamiltonian_here && !is_Coulomb_to_be_added && (inter_read == LAB_HO_TBMES_READ))
	error_message_print_abort ("No TBME A-dependence if the Coulomb interaction is already included in HO TBMEs read from file. Put zero if A.dependence.alpha.core.potential != 0.");
    }
  else
    A_dependence_alpha_core_potential = A_dependence_exponent = 0.0;
  
  cout << endl;
}







void input_data_str::core_parameters_fit_choice_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::core_parameters_fit_choice_data_read");

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);

  core_parameters_fit_choice_default_alloc_fill ();
      
  if (space != NEUT_Y_ONLY)
    {  
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
	{
	  const enum particle_type baryon = baryon_from_charge_index_determine (true , i);
	  
	  const string baryon_string = make_string<enum particle_type> (baryon);
      
	  if ((space == PROT_NEUT_Y) || (space == PROT_NEUT_UNMIXED_Y)) word_check (baryon_string);

	  is_dp_fitted_tab(i) = bool_determination ("diffuseness.fitted");

	  same_dp_all_lj_tab(i) = bool_determination ("same.diffuseness.for.all.partial.waves");

	  is_R0_p_fitted_tab(i) = bool_determination ("R0.fitted");

	  same_R0_p_all_lj_tab(i) = bool_determination ("same.R0.for.all.partial.waves");

	  is_Vo_p_fitted_tab(i) = bool_determination ("Vo.fitted");

	  same_Vo_p_all_lj_tab(i) = bool_determination ("same.Vo.for.all.partial.waves");

	  is_Vso_p_fitted_tab(i) = bool_determination ("Vso.fitted");

	  same_Vso_p_all_lj_tab(i) = bool_determination ("same.Vso.for.all.partial.waves");
	}
      
      is_R_charge_fitted = bool_determination ("R.charge.fitted");
    }

  if (space != PROT_Y_ONLY)
    {  
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
	{
	  const enum particle_type baryon = baryon_from_charge_index_determine (false , i);
	  
	  const string baryon_string = make_string<enum particle_type> (baryon);
      
	  if ((space == PROT_NEUT_Y) || (space == PROT_NEUT_UNMIXED_Y)) word_check (baryon_string);

	  is_dn_fitted_tab(i) = bool_determination ("diffuseness.fitted");

	  same_dn_all_lj_tab(i) = bool_determination ("same.diffuseness.for.all.partial.waves");

	  is_R0_n_fitted_tab(i) = bool_determination ("R0.fitted");

	  same_R0_n_all_lj_tab(i) = bool_determination ("same.R0.for.all.partial.waves");

	  is_Vo_n_fitted_tab(i) = bool_determination ("Vo.fitted");

	  same_Vo_n_all_lj_tab(i) = bool_determination ("same.Vo.for.all.partial.waves");

	  is_Vso_n_fitted_tab(i) = bool_determination ("Vso.fitted");

	  same_Vso_n_all_lj_tab(i) = bool_determination ("same.Vso.for.all.partial.waves");
	}
    }

  cout << endl;
}







void input_data_str::interaction_parameters_fit_choice_data_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::interaction_parameters_fit_choice_data_read");
  
  if (is_it_FHT_determine (inter))
    {
      is_V0_ctr_ot_S1_T1_fitted =                           bool_determination ("V0.central.odd.triplet.fitted(S=1,T=1)");
      is_V0_ctr_et_S1_T0_fitted = (space == PROT_NEUT_Y) ? (bool_determination ("V0.central.even.triplet.fitted(S=1,T=0)")) : (false);
      is_V0_ctr_os_S0_T0_fitted = (space == PROT_NEUT_Y) ? (bool_determination ("V0.central.odd.singlet.fitted(S=0,T=0)")) : (false);
      is_V0_ctr_es_S0_T1_fitted =                           bool_determination ("V0.central.even.singlet.fitted(S=0,T=1)");
      is_V0_so_ot_S1_T1_fitted  =                           bool_determination ("V0.spin.orbit.odd.triplet.fitted(S=1,T=1)");
      is_V0_so_et_S1_T0_fitted  = (space == PROT_NEUT_Y) ? (bool_determination ("V0.spin.orbit.even.triplet.fitted(S=1,T=0)")) : (false);
      is_V0_t_ot_S1_T1_fitted   =                           bool_determination ("V0.tensor.odd.triplet.fitted(S=1,T=1)");
      is_V0_t_et_S1_T0_fitted   = (space == PROT_NEUT_Y) ? (bool_determination ("V0.tensor.even.triplet.fitted(S=1,T=0)")) : (false);
      is_V0_ALS_fitted          = (are_there_hyperons)   ? (bool_determination ("V0.antisymmetric.spin.orbit.fitted")) : (false);
    }
  else
    is_V0_ctr_ot_S1_T1_fitted = is_V0_ctr_et_S1_T0_fitted = is_V0_ctr_os_S0_T0_fitted = is_V0_ctr_es_S0_T1_fitted = is_V0_so_ot_S1_T1_fitted = is_V0_so_et_S1_T0_fitted = is_V0_t_ot_S1_T1_fitted = is_V0_t_et_S1_T0_fitted = is_V0_ALS_fitted = false; 
  
  if (is_it_EFT_determine (inter))
    {
      is_VS_const_LO_T0_fitted          = (space == PROT_NEUT_Y) ? (bool_determination ("VS.LO.fitted(T=0)")) : (false);
      is_VS_const_LO_T1_fitted          =                           bool_determination ("VS.LO.fitted(T=1)");
      is_VT_sigma_product_LO_T0_fitted  = (space == PROT_NEUT_Y) ? (bool_determination ("VT.sigma.product.LO.fitted(T=0)")) : (false);
      is_VT_sigma_product_LO_T1_fitted  =                           bool_determination ("VT.sigma.product.LO.fitted(T=1)");
      is_V1_q2_NLO_fitted               =                           bool_determination ("V1.q.square.NLO.fitted");
      is_V2_k2_NLO_fitted               =                           bool_determination ("V2.k.square.NLO.fitted");
      is_V3_q2_sigma_product_NLO_fitted =                           bool_determination ("V3.q.square.sigma.product.NLO.fitted");
      is_V4_k2_sigma_product_NLO_fitted =                           bool_determination ("V4.k.square.sigma.product.NLO.fitted");
      is_V5_sigma_q_vector_k_NLO_fitted =                           bool_determination ("V5.sigma.q.vector.k.NLO.fitted");
      is_V6_sigma_q_product_NLO_fitted  =                           bool_determination ("V6.sigma.q.product.NLO.fitted");
      is_V7_sigma_k_product_NLO_fitted  =                           bool_determination ("V7.sigma.k.product.NLO.fitted");
      is_V8_sigma_q_vector_k_NLO_fitted = (are_there_hyperons)   ? (bool_determination ("V8.sigma.q.vector.k.NLO.fitted")) : (false);
    }
  else
    {
      is_VS_const_LO_T0_fitted = is_VS_const_LO_T1_fitted = is_VT_sigma_product_LO_T0_fitted = is_VT_sigma_product_LO_T1_fitted = false;
    
      is_V1_q2_NLO_fitted = is_V2_k2_NLO_fitted = is_V3_q2_sigma_product_NLO_fitted = is_V4_k2_sigma_product_NLO_fitted = false;
    
      is_V5_sigma_q_vector_k_NLO_fitted = is_V6_sigma_q_product_NLO_fitted = is_V7_sigma_k_product_NLO_fitted = is_V8_sigma_q_vector_k_NLO_fitted = false;
    }
  
  if (are_there_hyperons)
    {
      is_V8a_SU3f_fitted = bool_determination ("V8a.SU3f.fitted");
      is_V8s_SU3f_fitted = bool_determination ("V8s.SU3f.fitted");
      is_V10_SU3f_fitted = bool_determination ("V10.SU3f.fitted");
      is_V1_SU3f_fitted  = bool_determination  ("V1.SU3f.fitted");
    }
  else
    is_V8a_SU3f_fitted = is_V8s_SU3f_fitted = is_V10_SU3f_fitted = is_V1_SU3f_fitted = false;

  const bool are_nucleon_parameters_fitted = (is_V0_ctr_ot_S1_T1_fitted         ||
					      is_V0_ctr_et_S1_T0_fitted         ||
					      is_V0_ctr_os_S0_T0_fitted         ||
					      is_V0_ctr_es_S0_T1_fitted         ||
					      is_V0_so_ot_S1_T1_fitted          ||
					      is_V0_so_et_S1_T0_fitted          ||
					      is_V0_t_ot_S1_T1_fitted           ||
					      is_V0_t_et_S1_T0_fitted           ||
					      is_VS_const_LO_T0_fitted          ||
					      is_VS_const_LO_T1_fitted          ||
					      is_VT_sigma_product_LO_T0_fitted  ||
					      is_VT_sigma_product_LO_T1_fitted  ||
					      is_V1_q2_NLO_fitted               ||
					      is_V2_k2_NLO_fitted               ||
					      is_V3_q2_sigma_product_NLO_fitted ||
					      is_V4_k2_sigma_product_NLO_fitted ||
					      is_V5_sigma_q_vector_k_NLO_fitted ||
					      is_V6_sigma_q_product_NLO_fitted  ||
					      is_V7_sigma_k_product_NLO_fitted);

  const bool are_SU3f_ALS_parameters_fitted = (is_V0_ALS_fitted || is_V8_sigma_q_vector_k_NLO_fitted || is_V8a_SU3f_fitted || is_V8s_SU3f_fitted || is_V10_SU3f_fitted || is_V1_SU3f_fitted);

  if (are_nucleon_parameters_fitted && are_SU3f_ALS_parameters_fitted) error_message_print_abort ("One cannot fit nucleon-nucleon interaction parameters along with antisymmetric spin-orbit and SU(3)f parameters");	
  
  cout << endl;
}





void input_data_str::optimization_misc_parameters_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::optimization_misc_parameters_read");

  cin >> Newton_precision;
  
  word_check_print<double> ("(Newton.precision)" , Newton_precision);

  if (Newton_precision <= 0) error_message_print_abort ("Newton.precision must be positive");
  
  is_it_fixed_relative_SVD_precision = bool_determination ("fixed.relative.SVD.precision");

  if (is_it_fixed_relative_SVD_precision)
    {
      cin >> relative_SVD_precision;
      
      word_check_print<double> ("(relative.SVD.precision)" , relative_SVD_precision);

      if (relative_SVD_precision <= 0) error_message_print_abort ("relative.SVD.precision must be positive");
      
      relative_SVD_precision *= relative_SVD_precision; // The relative SVD precision is given relatively to singular values, which are the square roots of the J^T J matrix. Hence, it is squared to be used with the J^+ J matrix afterwards.
    }
  else
    {
      cin >> rejected_singular_values_number;

      word_check_print<unsigned int> ("rejected.singular.value(s)" , rejected_singular_values_number);
    }
  
  binding_energies_fitted = bool_determination ("binding.energies.fitted");
  
  is_cost_function_Hessian_matrix_calculated = bool_determination ("cost.function.Hessian.matrix.calculated");

  cin >> N_nuclei_to_consider;
  
  word_check_print<unsigned int> ("nucleus/nuclei.to.consider" , N_nuclei_to_consider);
  
  cout << endl;
}








void input_data_str::interactions_parameters_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::interactions_parameters_read");
  
  const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && ((inter == FIT) || (inter == SU3_INTERACTION)));
  
  const bool is_it_HF_MSDHF_basis = ((basis_potential == HF) || (basis_potential == MSDHF));

  const int lmax_all = max (lmax_p , lmax_n);

  const int Jmax = Jmax_global_determine (false);
        
  const int Jmax_plus_one = Jmax + 1;

  const int lmax_all_plus_one = lmax_all + 1;

  const int Aval_basis = Zval_basis + Nval_basis;
  
  const int Aval = ZYval + NYval;
      
  if (!only_dimensions && !non_zero_NBMEs_proportion_only && (called_code != OPTIMIZATION_CODE))
    {      
      is_Coulomb_to_be_added = (is_Coulomb_Hamiltonian_here && ((ZYval >= 2) || (is_it_HF_MSDHF_basis && (Zval_basis >= 2)))) ? (bool_determination ("Coulomb.interaction.to.be.added")) : (false);
	      
      if (called_code != TWO_PARTICLE_RELATIVE_CODE) A_dependence_read_calc ();
    }
  
  if (is_it_HF_MSDHF_basis && (Aval_basis == 1)) error_message_print_abort ("HF/MSDHF basis potential cannot be used with only one valence nucleon");
    
  if (is_it_HF_MSDHF_basis && (Aval_basis >= 2))
    {
      word_check ("Basis.interaction");
      
      basis_interaction_parameters_alloc_read ();
    }
  
  if (Aval_basis == 1) lmax_for_basis_interaction = lmax_all;

  if (is_it_HO_fit_or_SU3 && !only_dimensions && !non_zero_NBMEs_proportion_only)
    {
      cin >> b_lab;
      
      word_check_print<double> ("fm(b.HO)" , b_lab);
    }
  
  if (is_it_HO_fit_or_SU3 || only_dimensions || non_zero_NBMEs_proportion_only)
    {    
      lmax_for_interaction = lmax_all;

      nmax_HO_lab_tab.allocate (lmax_all_plus_one);

      nmax_GHF_lab_tab.allocate (lmax_all_plus_one);
        
      nmax_HO_lab_tab = 0;
      
      nmax_GHF_lab_tab = 0;
    }
  else if (Aval >= 2)
    {      
      word_check ("Hamiltonian.interaction");
	
      interaction_parameters_alloc_read ();
    }
  else
    lmax_for_interaction = lmax_all;

  if (is_it_HO_fit_or_SU3 || (Aval == 1) || only_dimensions || non_zero_NBMEs_proportion_only)
    {
      V_Gaussian_consts.allocate (2 , Jmax_plus_one , 2);
      
      V_Gaussian_consts = 1.0;
    }
  
  if (!is_it_HO_fit_or_SU3 && !only_dimensions && !non_zero_NBMEs_proportion_only) HO_GHF_expansion_parameters_alloc_read ();
    
  if (is_it_HF_MSDHF_basis)
    {  
      Jn_relative_max_basis = Jn_relative_max;
      Jc_relative_max_basis = Jc_relative_max;
      
      b_lab_basis = b_lab;
    }
  else
    basis_interaction_parameters_alloc_copy_from_Hamiltonian ();
  
  cout << endl;
}





void input_data_str::b_lab_partial_waves_alloc_read (const enum particle_type particle)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::b_lab_partial_waves_alloc_read");

  const string particle_string = make_string<enum particle_type> (particle);
      
  const int charge = particle_charge_determine (particle);

  const bool is_it_charged = (charge != 0);

  const unsigned int particle_index = charge_baryon_index_determine (particle);
      
  const int lmax_baryon = (is_it_charged) ? (lmax_baryon_p_tab(particle_index)) : (lmax_baryon_n_tab(particle_index));
	  
  class lj_table<double> &b_lab_partial_waves = (is_it_charged) ? (b_lab_partial_waves_p_tab(particle_index)) : (b_lab_partial_waves_n_tab(particle_index));
  	  
  unsigned int b_lab_partial_waves_number = 0;
  
  cin >> b_lab_partial_waves_number;

  word_check_print<unsigned int> (particle_string + ".partial.wave.b.HO(s)" , b_lab_partial_waves_number);
      
  if (b_lab_partial_waves_number > 0)
    {
      word_check ("partial.wave");
      word_check ("b.HO(fm)");
      
      cout << "partial.wave   b.HO(fm)" << endl;
      
      for (unsigned int i = 0 ; i < b_lab_partial_waves_number ; i++)
	{
	  string partial_wave;
	  
	  double b;
	  
	  cin >> partial_wave >> b;
	  
	  cout << partial_wave << "   " << b << endl;
	  
	  const string particle_partial_wave_string = particle_string + " " + partial_wave;
      
	  const int l = determine_l (partial_wave);
	      
	  if (l > lmax_baryon) error_message_print_abort ("Oscillator length of " + particle_partial_wave_string + " partial wave has orbital angular momentum larger than lmax");
	      
	  const double j = determine_j (partial_wave);
	      
	  check_partial_wave (particle , l , j);
	      
	  if (b <= 0) error_message_print_abort ("b[HO] in " + particle_partial_wave_string + " must be positive");
	  
	  b_lab_partial_waves(l , j) = b;	 
	}
      
      cout << endl;
    }
}








void input_data_str::b_lab_partial_waves_tab_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::b_lab_partial_waves_p_tabn_alloc_read");

  b_lab_partial_waves_default_alloc_fill ();

  if (Zval_basis > 0)
    {
      b_lab_partial_waves_alloc_read (PROTON);
      
      const unsigned int prot_index = charge_baryon_index_determine (PROTON);
	  
      const class array<class nlj_struct> &prot_shells_quantum_numbers = shells_quantum_numbers_p_tab(prot_index);
      
      const class lj_table<double> &b_lab_partial_waves_p = b_lab_partial_waves_p_tab(prot_index);      
      
      HO_length_partial_wave_presence_check (prot_shells_quantum_numbers , b_lab_partial_waves_p);
    }
  
  if (Nval_basis > 0)
    {
      b_lab_partial_waves_alloc_read (NEUTRON);
      
      const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
      const class array<class nlj_struct> &neut_shells_quantum_numbers = shells_quantum_numbers_n_tab(neut_index);
            
      const class lj_table<double> &b_lab_partial_waves_n = b_lab_partial_waves_n_tab(neut_index);
            
      HO_length_partial_wave_presence_check (neut_shells_quantum_numbers , b_lab_partial_waves_n);
    }
  
  for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
    {      
      const enum particle_type hyperon = hyperon_types(i);
      
      b_lab_partial_waves_alloc_read (hyperon);
      
      const unsigned int hyperon_index = charge_baryon_index_determine (hyperon);
	  
      const int charge = particle_charge_determine (hyperon);

      const bool is_it_charged = (charge != 0);
  
      const class array<class nlj_struct> &hyperon_shells_quantum_numbers = shells_quantum_numbers_determine(hyperon);
	  
      const class lj_table<double> &hyperon_b_lab_partial_waves = (is_it_charged) ? (b_lab_partial_waves_p_tab(hyperon_index)) : (b_lab_partial_waves_n_tab(hyperon_index));  
      
      HO_length_partial_wave_presence_check (hyperon_shells_quantum_numbers , hyperon_b_lab_partial_waves);
    }
  
  cout << endl;
}









void input_data_str::natural_orbitals_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::natural_orbitals_data_alloc_read");

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);

  are_there_new_natural_orbitals_p_tab.allocate (Np_baryon_type);
  are_there_new_natural_orbitals_n_tab.allocate (Nn_baryon_type);
					 
  are_there_new_natural_orbitals_p_tab = false;
  are_there_new_natural_orbitals_n_tab = false;
  
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
        
  if ((called_code != CC_CODE) && (called_code != RDM_CODE))
    {
      if (space != NEUT_Y_ONLY) are_there_new_natural_orbitals_p_tab(prot_index) = bool_determination ("are.there.new.proton.natural.orbitals");
      if (space != PROT_Y_ONLY) are_there_new_natural_orbitals_n_tab(neut_index) = bool_determination ("are.there.new.neutron.natural.orbitals");
      
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);
	  
	  const unsigned int hyperon_index = charge_baryon_index_determine (hyperon);
	  
	  const int Y_charge = particle_charge_determine (hyperon);
      
	  if (Y_charge == 0) are_there_new_natural_orbitals_p_tab(hyperon_index) = bool_determination ("are.there.new." + make_string<enum particle_type> (hyperon) + ".natural.orbitals");
	  if (Y_charge != 0) are_there_new_natural_orbitals_n_tab(hyperon_index) = bool_determination ("are.there.new." + make_string<enum particle_type> (hyperon) + ".natural.orbitals");
	}
    }
  
  are_there_new_natural_orbitals_p = false;
  are_there_new_natural_orbitals_n = false;
  
  for (unsigned int i = 0 ; ((i < Np_baryon_type) && !are_there_new_natural_orbitals_p) ; i++) are_there_new_natural_orbitals_p = are_there_new_natural_orbitals_p_tab(i);
  for (unsigned int i = 0 ; ((i < Nn_baryon_type) && !are_there_new_natural_orbitals_n) ; i++) are_there_new_natural_orbitals_n = are_there_new_natural_orbitals_n_tab(i);
  
  if (are_there_new_natural_orbitals_p || are_there_new_natural_orbitals_n)
    {
      cout << endl;
      
      if (space != NEUT_Y_ONLY) natural_orbitals_consistency_tests (PROTON);
      if (space != PROT_Y_ONLY) natural_orbitals_consistency_tests (NEUTRON);
      
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++) natural_orbitals_consistency_tests (hyperon_types(i));
    }
  
  are_there_basis_natural_orbitals_p = false;
  are_there_basis_natural_orbitals_n = false;
  
  for (unsigned int i = 0 ; ((i < Np_baryon_type) && !are_there_basis_natural_orbitals_p) ; i++) are_there_basis_natural_orbitals_p = are_there_basis_natural_orbitals_p_tab(i);
  for (unsigned int i = 0 ; ((i < Nn_baryon_type) && !are_there_basis_natural_orbitals_n) ; i++) are_there_basis_natural_orbitals_n = are_there_basis_natural_orbitals_n_tab(i);
  
  if (are_there_basis_natural_orbitals_p || are_there_basis_natural_orbitals_n || are_there_new_natural_orbitals_p || are_there_new_natural_orbitals_n)
    {
      cin >> natural_orbitals_reference_states_number;

      word_check_print<unsigned int> ("(natural.orbitals.reference.state.number)" , natural_orbitals_reference_states_number);

      natural_orbitals_reference_states_BP_tab.allocate (natural_orbitals_reference_states_number);
      
      natural_orbitals_reference_states_vector_index_tab.allocate (natural_orbitals_reference_states_number);

      natural_orbitals_reference_states_J_tab.allocate (natural_orbitals_reference_states_number);

      for (unsigned int i = 0 ; i < natural_orbitals_reference_states_number ; i++)
	{
	  quantum_numbers_read (natural_orbitals_reference_states_BP_tab(i) , natural_orbitals_reference_states_J_tab(i) , natural_orbitals_reference_states_vector_index_tab(i));

	  cout << "Natural orbitals reference state: " << J_Pi_vector_index_string (natural_orbitals_reference_states_BP_tab(i) , natural_orbitals_reference_states_J_tab(i) , natural_orbitals_reference_states_vector_index_tab(i)) << endl;
	}
    }

  cout << endl;
}





void input_data_str::optimized_partial_waves_basis_potentials_data_alloc_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::optimized_partial_waves_basis_potentials_data_alloc_read");

  const bool is_it_HF_basis = (basis_potential == HF);
  
  const bool is_it_MSDHF_basis = (basis_potential == MSDHF);

  const bool is_it_HF_MSDHF_basis = (is_it_HF_basis || is_it_MSDHF_basis);
  
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
  
  optimized_partial_waves_basis_potential_partial_waves_default_alloc_fill ();

  class lj_table<enum potential_type> &prot_basis_potential_partial_waves = basis_potential_partial_waves_p_tab(prot_index);  
  class lj_table<enum potential_type> &neut_basis_potential_partial_waves = basis_potential_partial_waves_n_tab(neut_index);

  prot_basis_potential_partial_waves = (is_it_HF_MSDHF_basis) ? (H_basis_core_potential) : (basis_potential);
  neut_basis_potential_partial_waves = (is_it_HF_MSDHF_basis) ? (H_basis_core_potential) : (basis_potential);

  if (!is_it_HF_MSDHF_basis) return;
  
  unsigned int N_lj_optimized;
   
  if (basis_space != NEUT_Y_ONLY)
    {      
      cin >> N_lj_optimized;
      
      word_check_print<unsigned int> ("optimized.proton.partial.wave(s)" , N_lj_optimized);

      if (N_lj_optimized > 0)
	{
	  word_check ("partial.wave");

	  if (is_it_MSDHF_basis) word_check ("optimized.GSM.state");

	  if (is_it_HF_basis) cout << "partial.wave" << endl;
	  
	  if (is_it_MSDHF_basis) cout << "partial.wave    optimized.GSM.state" << endl;
      
	  for (unsigned int i = 0 ; i < N_lj_optimized ; i++)
	    {
	      string partial_wave;
	      
	      string eigenstate;

	      cin >> partial_wave;

	      if (partial_wave == "optimized.GSM.state") error_message_print_abort ("Optimized GSM state only with MSDHF");

	      if (is_it_MSDHF_basis) cin >> eigenstate;

	      if (is_it_HF_basis) cout << partial_wave << endl;
	      
	      if (is_it_MSDHF_basis) cout << partial_wave << "   " << eigenstate << endl;
	  
	      const int l = determine_l (partial_wave);
	      
	      const double j = determine_j (partial_wave);

	      check_partial_wave (PROTON , l , j);
      
	      if (l > lmax_p) error_message_print_abort ("Optimized potential " + partial_wave + " partial wave has orbital angular momentum larger than lmax");

	      if (is_it_MSDHF_basis)
		{
		  prot_basis_BP_tab(l , j) = determine_Binary_Parity (eigenstate);
		  
		  prot_basis_J_tab(l , j) = determine_J (eigenstate);
		}
	      
	      prot_basis_potential_partial_waves(l , j) = basis_potential;
	    }
      
	  cout << endl;
	}
    }
  
  if (basis_space != PROT_Y_ONLY)
    {
      cin >> N_lj_optimized;
      
      word_check_print<unsigned int> ("optimized.neutron.partial.wave(s)" , N_lj_optimized);

      if (N_lj_optimized > 0)
	{
	  word_check ("partial.wave");

	  if (is_it_MSDHF_basis) word_check ("optimized.GSM.state");

	  if (is_it_HF_basis) cout << "partial.wave" << endl;
	  
	  if (is_it_MSDHF_basis) cout << "partial.wave    optimized.GSM.state" << endl;
      
	  for (unsigned int i = 0 ; i < N_lj_optimized ; i++)
	    {
	      string partial_wave;
	      
	      string eigenstate;

	      cin >> partial_wave;

	      if (is_it_MSDHF_basis) cin >> eigenstate;

	      if (is_it_HF_basis) cout << partial_wave << endl;

	      if (is_it_MSDHF_basis) cout << partial_wave << "   " << eigenstate << endl;
	  	  
	      const int l = determine_l (partial_wave);
	      
	      const double j = determine_j (partial_wave);

	      check_partial_wave (NEUTRON , l , j);
      
	      if (l > lmax_n) error_message_print_abort ("Optimized potential " + partial_wave + " partial wave has orbital angular momentum larger than lmax");

	      if (is_it_MSDHF_basis)
		{
		  neut_basis_BP_tab(l,j) = determine_Binary_Parity (eigenstate);
		  
		  neut_basis_J_tab(l,j) = determine_J (eigenstate);
		}
	      
	      neut_basis_potential_partial_waves(l , j) = basis_potential;	  
	    }
      
	  cout << endl;
	}
    }
    
  cout << endl;
}








void input_data_str::beta_transitions_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::beta_transitions_data_read");
  
  cin >> beta_transitions_number;
  
  word_check_print<unsigned int> ("(beta.transitions.number)" , beta_transitions_number);

  beta_tab.allocate (beta_transitions_number);

  beta_pm_tab.allocate (beta_transitions_number);

  beta_BP_IN_tab.allocate (beta_transitions_number);
  beta_J_IN_tab.allocate (beta_transitions_number);
  beta_vector_index_IN_tab.allocate (beta_transitions_number);

  beta_BP_OUT_tab.allocate (beta_transitions_number);
  beta_J_OUT_tab.allocate (beta_transitions_number);
  beta_vector_index_OUT_tab.allocate (beta_transitions_number);

  beta_is_it_HO_expansion_tab.allocate (beta_transitions_number);

  beta_W0_tab.allocate (beta_transitions_number);

  word_check ("beta.type");
  word_check ("beta(+/-)");
  word_check ("HO.expansion(yes/no)");
  word_check ("Q[beta](MeV)");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");

  cout << "beta.type   beta(+/-)   HO.expansion(yes/no)   Q[beta](MeV)   quantum.numbers.in    quantum.numbers.out" << endl;
  
  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_number ; beta_index++)
    {
      string beta_string;
      
      string beta_pm_string;

      double Qbeta = 0.0;
  
      cin >> beta_string >> beta_pm_string;
  
      beta_tab(beta_index) = beta_type_determine (beta_string);
      
      beta_pm_tab(beta_index) = beta_pm_type_determine (beta_pm_string);

      beta_is_it_HO_expansion_tab(beta_index) = bool_determination_no_print ("HO.expansion");

      cin >> Qbeta;

      if (Qbeta <= 0) error_message_print_abort ("Q[beta] in position " + make_string<unsigned int> (beta_index) + " must be positive");
	      
      beta_W0_tab(beta_index) = Qbeta/electron_mass + 1.0; // Change of units from Q[beta] to W0: W runs from 1 to Q[beta]/electron_mass + 1, which is in electron mass units.
 
      quantum_numbers_read (beta_BP_IN_tab(beta_index)  , beta_J_IN_tab(beta_index)  , beta_vector_index_IN_tab(beta_index));
      quantum_numbers_read (beta_BP_OUT_tab(beta_index) , beta_J_OUT_tab(beta_index) , beta_vector_index_OUT_tab(beta_index));

      const string beta_is_it_HO_expansion_string = (beta_is_it_HO_expansion_tab(beta_index)) ? ("HO.expansion(yes)") : ("HO.expansion(no)");
      
      cout << beta_string << "    " <<  beta_pm_string << "   " << beta_is_it_HO_expansion_string << "   " << Qbeta << "   "
	   << J_Pi_vector_index_string (beta_BP_IN_tab(beta_index)  , beta_J_IN_tab(beta_index)  , beta_vector_index_IN_tab(beta_index)) << "    "
	   << J_Pi_vector_index_string (beta_BP_OUT_tab(beta_index) , beta_J_OUT_tab(beta_index) , beta_vector_index_OUT_tab(beta_index)) << endl;
    }

  cout << endl;
}










void input_data_str::beta_transitions_strength_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::beta_transitions_strength_data_read");

  unsigned int beta_transitions_strength_number;
  
  cin >> beta_transitions_strength_number;
  
  word_check_print<unsigned int> ("(beta.transitions.strength.number)" , beta_transitions_strength_number);

  beta_strength_tab.allocate (beta_transitions_strength_number);

  beta_strength_pm_tab.allocate (beta_transitions_strength_number);

  beta_strength_is_it_Gauss_Legendre_tab.allocate (beta_transitions_strength_number);

  beta_strength_BP_IN_tab.allocate (beta_transitions_strength_number);

  beta_strength_J_IN_tab.allocate (beta_transitions_strength_number);

  beta_strength_vector_index_IN_tab.allocate (beta_transitions_strength_number);

  beta_strength_BP_OUT_tab.allocate (beta_transitions_strength_number);

  beta_strength_J_OUT_tab.allocate (beta_transitions_strength_number);

  beta_strength_vector_index_OUT_tab.allocate (beta_transitions_strength_number);

  word_check ("beta.type");
  word_check ("beta(+/-)");
  word_check ("Gauss.Legendre(yes/no)");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");

  cout << "beta.type   beta(+/-)   Gauss.Legendre(yes/no)   quantum.numbers.in   quantum.numbers.out" << endl;
  
  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_strength_number ; beta_index++)
    {
      string beta_string;
      
      string beta_pm_string;

      cin >> beta_string >> beta_pm_string;
  
      beta_strength_tab(beta_index) = beta_type_determine (beta_string);
      
      beta_strength_pm_tab(beta_index) = beta_pm_type_determine (beta_pm_string);
      
      beta_strength_is_it_Gauss_Legendre_tab(beta_index) = bool_determination_no_print ("Gauss.Legendre");
      
      quantum_numbers_read (beta_strength_BP_IN_tab(beta_index)  , beta_strength_J_IN_tab(beta_index)  , beta_strength_vector_index_IN_tab(beta_index));
      quantum_numbers_read (beta_strength_BP_OUT_tab(beta_index) , beta_strength_J_OUT_tab(beta_index) , beta_strength_vector_index_OUT_tab(beta_index));
      
      const string beta_strength_is_it_Gauss_Legendre_string = (beta_strength_is_it_Gauss_Legendre_tab(beta_index)) ? ("HO.expansion(yes)") : ("HO.expansion(no)");
      
      cout << beta_string << "    " <<  beta_pm_string << "   " << beta_strength_is_it_Gauss_Legendre_string << "   "
	   << J_Pi_vector_index_string (beta_strength_BP_IN_tab(beta_index)  , beta_strength_J_IN_tab(beta_index)  , beta_strength_vector_index_IN_tab(beta_index)) << "   "
	   << J_Pi_vector_index_string (beta_strength_BP_OUT_tab(beta_index) , beta_strength_J_OUT_tab(beta_index) , beta_strength_vector_index_OUT_tab(beta_index)) << endl;
    }
  
  cout << endl;
}


void input_data_str::correlation_density_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::correlation_density_data_read");  

  cin >> correlation_density_number;
  
  word_check_print<unsigned int> ("(correlation.density.number)" , correlation_density_number);

  correlation_density_BP_tab.allocate (correlation_density_number);

  correlation_density_J_tab.allocate (correlation_density_number);
  
  correlation_density_RKmax_tab.allocate (correlation_density_number);

  correlation_density_vector_index_tab.allocate (correlation_density_number);

  correlation_density_is_it_radial_tab.allocate (correlation_density_number);
  
  correlation_density_is_it_Gauss_Legendre_tab.allocate (correlation_density_number);
  
  correlation_density_is_it_HO_expansion_tab.allocate (correlation_density_number);
        
  is_correlation_density_theta_value_imposed = bool_determination_no_print ("fixed.theta.value");

  if (is_correlation_density_theta_value_imposed)
    {
      correlation_density_theta_number = 1;

      cin >> correlation_density_imposed_theta_value;
      
      word_check_print<double> ("degree(theta.value)" , correlation_density_imposed_theta_value);

      correlation_density_imposed_theta_value *= M_PI/180.0;
    }
  else
    {
      cin >> correlation_density_theta_number;
      
      word_check_print<unsigned int> ("(theta.points)" , correlation_density_theta_number);
    }
        
  word_check ("radial/momentum");
  word_check ("maximal.radius(fm)/momentum(fm^(-1))");
  word_check ("HO.expansion(yes/no)");
  word_check ("Gauss.Legendre(yes/no)");
  word_check ("quantum.numbers");

  cout << "radial/momentum    maximal.radius(fm)/momentum(fm^(-1))    HO.expansion(yes/no)   Gauss.Legendre(yes/no)   quantum.numbers" << endl;

  for (unsigned int correlation_density_index = 0 ; correlation_density_index < correlation_density_number ; correlation_density_index++)
    {
      string radial_momentum_str;
      
      cin >> radial_momentum_str;

      if (radial_momentum_str == "radial")
	correlation_density_is_it_radial_tab(correlation_density_index) = true;
      else if (radial_momentum_str == "momentum")
	correlation_density_is_it_radial_tab(correlation_density_index) = false;
      else
	error_message_print_abort ("Correlation density is calculated either in radial or momentum space");
      
      cin >> correlation_density_RKmax_tab(correlation_density_index);

      if ((radial_momentum_str == "radial")   && (correlation_density_RKmax_tab(correlation_density_index) <= 0)) error_message_print_abort ("maximal radius in position "   + make_string<unsigned int> (correlation_density_index) + " must be positive");
      if ((radial_momentum_str == "momentum") && (correlation_density_RKmax_tab(correlation_density_index) <= 0)) error_message_print_abort ("maximal momentum in position " + make_string<unsigned int> (correlation_density_index) + " must be positive");
			
      correlation_density_is_it_HO_expansion_tab(correlation_density_index) = bool_determination_no_print ("HO.expansion");
      
      correlation_density_is_it_Gauss_Legendre_tab(correlation_density_index) = bool_determination_no_print ("Gauss.Legendre");

      if (!is_correlation_density_theta_value_imposed && (correlation_density_theta_number == 1) && !correlation_density_is_it_Gauss_Legendre_tab(correlation_density_index))
	error_message_print_abort ("One has to have more than one theta point without Gauss-Legendre and if one does not fix the value of theta");
      
      quantum_numbers_read (correlation_density_BP_tab(correlation_density_index) , correlation_density_J_tab(correlation_density_index) , correlation_density_vector_index_tab(correlation_density_index));
      
      const string correlation_density_is_it_HO_expansion_string = (correlation_density_is_it_HO_expansion_tab(correlation_density_index)) ? ("HO.expansion(yes)") : ("HO_expansion(no)");

      const string correlation_density_is_it_Gauss_Legendre_string = (correlation_density_is_it_Gauss_Legendre_tab(correlation_density_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");

      if (!correlation_density_is_it_radial_tab(correlation_density_index) && !correlation_density_is_it_HO_expansion_tab(correlation_density_index))
	error_message_print_abort ("HO expansion is necessary for momentum space correlation density");
      
      cout << radial_momentum_str << "  " << correlation_density_RKmax_tab(correlation_density_index) << "  " << correlation_density_is_it_HO_expansion_string << "  " << correlation_density_is_it_Gauss_Legendre_string << "  "
	   << J_Pi_vector_index_string (correlation_density_BP_tab(correlation_density_index) , correlation_density_J_tab(correlation_density_index) , correlation_density_vector_index_tab(correlation_density_index)) << endl;
    }

  cout << endl;
}

void input_data_str::density_data_read ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::density_data_read");   

  cin >> density_number;
  
  word_check_print<unsigned int> ("(density.number)" , density_number);

  density_BP_tab.allocate (density_number);
  
  density_J_tab.allocate (density_number);

  density_vector_index_tab.allocate (density_number);

  density_is_it_radial_tab.allocate (density_number);
  
  density_is_it_Gauss_Legendre_tab.allocate (density_number);

  word_check ("radial/momentum");
  word_check ("Gauss.Legendre(yes/no)");
  word_check ("quantum.numbers");

  cout << "radial/momentum   Gauss.Legendre(yes/no)   quantum.numbers" << endl;
  
  for (unsigned int density_index = 0 ; density_index < density_number ; density_index++)
    {
      string radial_momentum_str;
      
      cin >> radial_momentum_str;

      if (radial_momentum_str == "radial")
	density_is_it_radial_tab(density_index) = true;
      else if (radial_momentum_str == "momentum")
	density_is_it_radial_tab(density_index) = false;
      else
	error_message_print_abort ("Density is calculated either in radial or momentum space");
      
      density_is_it_Gauss_Legendre_tab(density_index) = bool_determination_no_print ("Gauss.Legendre");

      quantum_numbers_read (density_BP_tab(density_index) , density_J_tab(density_index) , density_vector_index_tab(density_index));
      
      const string density_is_it_Gauss_Legendre_string = (density_is_it_Gauss_Legendre_tab(density_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");
      
      cout << radial_momentum_str << "  " << density_is_it_Gauss_Legendre_string << "  "
	   << J_Pi_vector_index_string (density_BP_tab(density_index) , density_J_tab(density_index) , density_vector_index_tab(density_index)) << endl;
    }

  cout << endl;
}




void input_data_str::pair_density_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::pair_density_data_read");  

  cin >> pair_density_number;
  
  word_check_print<unsigned int> ("(pair.density.number)" , pair_density_number);

  pair_density_BP_tab.allocate (pair_density_number);

  pair_density_J_tab.allocate (pair_density_number);
  
  pair_density_RKmax_tab.allocate (pair_density_number);

  pair_density_vector_index_tab.allocate (pair_density_number);

  pair_density_is_it_radial_tab.allocate (pair_density_number);
  
  pair_density_is_it_Gauss_Legendre_tab.allocate (pair_density_number);
          
  word_check ("radial/momentum");
  word_check ("maximal.radius(fm)/momentum(fm^(-1))");
  word_check ("Gauss.Legendre(yes/no)");
  word_check ("quantum.numbers");

  cout << "radial/momentum    maximal.radius(fm)/momentum(fm^(-1))    Gauss.Legendre(yes/no)   quantum.numbers" << endl;

  for (unsigned int pair_density_index = 0 ; pair_density_index < pair_density_number ; pair_density_index++)
    {
      string radial_momentum_str;
      
      cin >> radial_momentum_str;

      if (radial_momentum_str == "radial")
	pair_density_is_it_radial_tab(pair_density_index) = true;
      else if (radial_momentum_str == "momentum")
	pair_density_is_it_radial_tab(pair_density_index) = false;
      else
	error_message_print_abort ("Pair density is calculated either in radial or momentum space");
      
      cin >> pair_density_RKmax_tab(pair_density_index);

      if ((radial_momentum_str == "radial")   && (pair_density_RKmax_tab(pair_density_index) <= 0)) error_message_print_abort ("maximal radius in position "   + make_string<unsigned int> (pair_density_index) + " must be positive");
      if ((radial_momentum_str == "momentum") && (pair_density_RKmax_tab(pair_density_index) <= 0)) error_message_print_abort ("maximal momentum in position " + make_string<unsigned int> (pair_density_index) + " must be positive");
      
      pair_density_is_it_Gauss_Legendre_tab(pair_density_index) = bool_determination_no_print ("Gauss.Legendre");
      
      quantum_numbers_read (pair_density_BP_tab(pair_density_index) , pair_density_J_tab(pair_density_index) , pair_density_vector_index_tab(pair_density_index));
      
      const string pair_density_is_it_Gauss_Legendre_string = (pair_density_is_it_Gauss_Legendre_tab(pair_density_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");
      
      cout << radial_momentum_str << "  " << pair_density_RKmax_tab(pair_density_index) << "  " << pair_density_is_it_Gauss_Legendre_string << "  "
	   << J_Pi_vector_index_string (pair_density_BP_tab(pair_density_index) , pair_density_J_tab(pair_density_index) , pair_density_vector_index_tab(pair_density_index)) << endl;
    }

  cout << endl;
}




void input_data_str::GSM_multipoles_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::GSM_multipoles_data_read");   

  cin >> GSM_multipoles_number;
  
  word_check_print<unsigned int> ("(GSM.multipoles.number)" , GSM_multipoles_number);

  GSM_multipoles_L_tab.allocate (GSM_multipoles_number);
  
  GSM_multipoles_BP_tab.allocate (GSM_multipoles_number);

  GSM_multipoles_J_tab.allocate (GSM_multipoles_number);

  GSM_multipoles_vector_index_tab.allocate (GSM_multipoles_number);

  GSM_multipoles_is_it_HO_expansion_tab.allocate (GSM_multipoles_number);

  word_check ("L");
  word_check ("quantum.numbers");
  word_check ("HO.expansion(yes/no)");

  cout << "L   quantum.numbers   HO.expansion(yes/no)" << endl;

  for (unsigned int GSM_multipoles_index = 0 ; GSM_multipoles_index < GSM_multipoles_number ; GSM_multipoles_index++)
    {
      cin >> GSM_multipoles_L_tab(GSM_multipoles_index);

      if (GSM_multipoles_L_tab(GSM_multipoles_index) < 0) error_message_print_abort ("L in position "   + make_string<unsigned int> (GSM_multipoles_index) + " must be positive or zero");
      
      if ((space != NEUT_Y_ONLY) && (GSM_multipoles_L_tab(GSM_multipoles_index) > 2*lmax_p)) error_message_print_abort ("One cannot have L > 2.lmax[proton] for GSM multipoles");
      if ((space != PROT_Y_ONLY) && (GSM_multipoles_L_tab(GSM_multipoles_index) > 2*lmax_n)) error_message_print_abort ("One cannot have L > 2.lmax[neutron] for GSM multipoles");
       
      quantum_numbers_read (GSM_multipoles_BP_tab(GSM_multipoles_index) , GSM_multipoles_J_tab(GSM_multipoles_index) , GSM_multipoles_vector_index_tab(GSM_multipoles_index));

      GSM_multipoles_is_it_HO_expansion_tab(GSM_multipoles_index) = bool_determination_no_print ("HO.expansion");
       
      const string GSM_multipoles_is_it_HO_expansion_string = (GSM_multipoles_is_it_HO_expansion_tab(GSM_multipoles_index)) ? ("HO.expansion(yes)") : ("HO.expansion(no)");
      
      cout << GSM_multipoles_L_tab(GSM_multipoles_index) << "    "
	   << J_Pi_vector_index_string (GSM_multipoles_BP_tab(GSM_multipoles_index) , GSM_multipoles_J_tab(GSM_multipoles_index) , GSM_multipoles_vector_index_tab(GSM_multipoles_index)) << "   "
	   << GSM_multipoles_is_it_HO_expansion_string << endl;
    }

  cout << endl;
}






void input_data_str::EM_transitions_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::EM_transitions_data_read");   

  cin >> EM_transitions_number;
  
  word_check_print<unsigned int> ("(EM.transitions.number)" , EM_transitions_number);

  EM_tab.allocate (EM_transitions_number);

  EM_L_tab.allocate (EM_transitions_number);

  EM_BP_IN_tab.allocate (EM_transitions_number);

  EM_J_IN_tab.allocate (EM_transitions_number);

  EM_vector_index_IN_tab.allocate (EM_transitions_number);

  EM_BP_OUT_tab.allocate (EM_transitions_number);

  EM_J_OUT_tab.allocate (EM_transitions_number);

  EM_vector_index_OUT_tab.allocate (EM_transitions_number);

  EM_is_it_longwavelength_approximation_tab.allocate (EM_transitions_number);

  EM_is_it_HO_expansion_tab.allocate (EM_transitions_number);

  word_check ("EM.type");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");
  word_check ("long.wavelength.approximation(yes/no)");
  word_check ("HO.expansion(yes/no)");

  cout << "EM.type   quantum.numbers.in   quantum.numbers.out   long.wavelength.approximation(yes/no)   HO.expansion(yes/no)" << endl;

  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_number ; EM_index++)
    {
      string EM_string;

      string L_of_EM;

      cin >> EM_string;

      EM_tab(EM_index) = EM_determine (EM_string);

      EM_string += '\n';

      for (unsigned int ii = 1 ; EM_string[ii] != '\n' ; ii++) L_of_EM += EM_string[ii];

      EM_L_tab(EM_index) = atoi (L_of_EM.c_str ());

      quantum_numbers_read (EM_BP_IN_tab(EM_index)  , EM_J_IN_tab(EM_index)  , EM_vector_index_IN_tab(EM_index));
      quantum_numbers_read (EM_BP_OUT_tab(EM_index) , EM_J_OUT_tab(EM_index) , EM_vector_index_OUT_tab(EM_index));

      EM_is_it_longwavelength_approximation_tab(EM_index) = bool_determination_no_print ("long.wavelength.approximation");

      EM_is_it_HO_expansion_tab(EM_index) = bool_determination_no_print ("HO.expansion");
       
      const string EM_is_it_longwavelength_approximation_string = (EM_is_it_longwavelength_approximation_tab(EM_index)) ? ("long.wavelength.approximation(yes)") : ("long.wavelength.approximation(no)");

      const string EM_is_it_HO_expansion_string = (EM_is_it_HO_expansion_tab(EM_index)) ? ("HO.expansion(yes)") : ("HO.expansion(no)");
      
      cout << EM_tab(EM_index) << EM_L_tab(EM_index) << "    "
	   << J_Pi_vector_index_string (EM_BP_IN_tab(EM_index)  , EM_J_IN_tab(EM_index)  , EM_vector_index_IN_tab(EM_index)) << "   "
	   << J_Pi_vector_index_string (EM_BP_OUT_tab(EM_index) , EM_J_OUT_tab(EM_index) , EM_vector_index_OUT_tab(EM_index)) << "   "
	   << EM_is_it_longwavelength_approximation_string  << "   " << EM_is_it_HO_expansion_string << endl;
    }

  cout << endl;
}




void input_data_str::EM_transitions_strength_data_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::EM_transitions_strength_data_read");   

  cin >> EM_transitions_strength_number;

  word_check_print<unsigned int> ("(EM.transitions.strength.number)" , EM_transitions_strength_number);

  EM_strength_tab.allocate (EM_transitions_strength_number);

  EM_strength_L_tab.allocate (EM_transitions_strength_number);

  EM_strength_is_it_Gauss_Legendre_tab.allocate (EM_transitions_strength_number);

  EM_strength_BP_IN_tab.allocate (EM_transitions_strength_number);

  EM_strength_J_IN_tab.allocate (EM_transitions_strength_number);

  EM_strength_vector_index_IN_tab.allocate (EM_transitions_strength_number);

  EM_strength_BP_OUT_tab.allocate (EM_transitions_strength_number);

  EM_strength_J_OUT_tab.allocate (EM_transitions_strength_number);

  EM_strength_vector_index_OUT_tab.allocate (EM_transitions_strength_number);

  EM_strength_is_it_longwavelength_approximation_tab.allocate (EM_transitions_strength_number);

  word_check ("EM.type");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");
  word_check ("long.wavelength.approximation(yes/no)");
  word_check ("Gauss.Legendre(yes/no)");

  cout << "EM.type   quantum.numbers.in   quantum.numbers.out   long.wavelength.approximation(yes/no)   Gauss.Legendre(yes/no)" << endl;

  for (unsigned int EM_index = 0 ; EM_index < EM_transitions_strength_number ; EM_index++)
    {
      string EM_string;

      string L_of_EM;

      cin >> EM_string;

      EM_strength_tab(EM_index) = EM_determine (EM_string);

      EM_string += '\n';

      for (unsigned int ii = 1 ; EM_string[ii] != '\n' ; ii++) L_of_EM += EM_string[ii];

      EM_strength_L_tab(EM_index) = atoi (L_of_EM.c_str ());

      quantum_numbers_read (EM_strength_BP_IN_tab(EM_index)  , EM_strength_J_IN_tab(EM_index)  , EM_strength_vector_index_IN_tab(EM_index));
      quantum_numbers_read (EM_strength_BP_OUT_tab(EM_index) , EM_strength_J_OUT_tab(EM_index) , EM_strength_vector_index_OUT_tab(EM_index));

      EM_strength_is_it_longwavelength_approximation_tab(EM_index) = bool_determination_no_print ("long.wavelength.approximation");
      
      EM_strength_is_it_Gauss_Legendre_tab(EM_index) = bool_determination_no_print ("Gauss.Legendre");

      const string EM_strength_is_it_longwavelength_approximation_string = (EM_strength_is_it_longwavelength_approximation_tab(EM_index)) ? ("long.wavelength.approximation(yes)") : ("long.wavelength.approximation(no)");

      const string EM_strength_is_it_Gauss_Legendre_string = (EM_strength_is_it_Gauss_Legendre_tab(EM_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");
   
      cout << EM_strength_tab(EM_index) << EM_strength_L_tab(EM_index) << "    "
	   << J_Pi_vector_index_string (EM_strength_BP_IN_tab(EM_index)  , EM_strength_J_IN_tab(EM_index)  , EM_strength_vector_index_IN_tab(EM_index)) << "   "
	   << J_Pi_vector_index_string (EM_strength_BP_OUT_tab(EM_index) , EM_strength_J_OUT_tab(EM_index) , EM_strength_vector_index_OUT_tab(EM_index)) << "   "
	   << EM_strength_is_it_longwavelength_approximation_string << "   " << EM_strength_is_it_Gauss_Legendre_string << endl;
    }

  cout << endl;
}



void input_data_str::Hamiltonian_parts_data_read ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::Hamiltonian_parts_data_read");    

  cin >> Hamiltonian_parts_eigenstates_number;
  
  word_check_print<unsigned int> ("(eigenstates.number)" , Hamiltonian_parts_eigenstates_number);

  Hamiltonian_parts_BP_tab.allocate (Hamiltonian_parts_eigenstates_number);

  Hamiltonian_parts_J_tab.allocate (Hamiltonian_parts_eigenstates_number);

  Hamiltonian_parts_vector_index_tab.allocate (Hamiltonian_parts_eigenstates_number);

  for (unsigned int eigenstates_index = 0 ; eigenstates_index < Hamiltonian_parts_eigenstates_number ; eigenstates_index++)
    {
      quantum_numbers_read (Hamiltonian_parts_BP_tab(eigenstates_index) , Hamiltonian_parts_J_tab(eigenstates_index) , Hamiltonian_parts_vector_index_tab(eigenstates_index));

      cout << J_Pi_vector_index_string (Hamiltonian_parts_BP_tab(eigenstates_index) , Hamiltonian_parts_J_tab(eigenstates_index) , Hamiltonian_parts_vector_index_tab(eigenstates_index)) << endl;
    }
}








void input_data_str::overlap_function_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::overlap_function_data_read");    

  cin >> overlap_function_number;
  
  word_check_print<unsigned int> ("(overlap.function.number)" , overlap_function_number);  

  overlap_function_type_tab.allocate (overlap_function_number);

  overlap_function_nucleus_projectile_tab.allocate (overlap_function_number);

  overlap_function_is_it_Gauss_Legendre_tab.allocate (overlap_function_number);

  overlap_function_cluster_projectile_tab.allocate (overlap_function_number);

  overlap_function_Z_projectile_tab.allocate (overlap_function_number);
  overlap_function_N_projectile_tab.allocate (overlap_function_number);

  overlap_function_LCM_projectile_tab.allocate (overlap_function_number);

  overlap_function_NCM_HO_max_projectile_tab.allocate (overlap_function_number);

  overlap_function_BP_IN_tab.allocate (overlap_function_number);
  overlap_function_BP_OUT_tab.allocate (overlap_function_number);

  overlap_function_BP_projectile_tab.allocate (overlap_function_number);

  overlap_function_J_IN_tab.allocate  (overlap_function_number);
  overlap_function_J_OUT_tab.allocate (overlap_function_number);

  overlap_function_J_projectile_tab.allocate (overlap_function_number);

  overlap_function_vector_index_IN_tab.allocate  (overlap_function_number);
  overlap_function_vector_index_OUT_tab.allocate (overlap_function_number);

  overlap_function_vector_index_projectile_tab.allocate (overlap_function_number);

  word_check ("overlap.function.type");
  word_check ("Gauss.Legendre(yes/no)");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");
  word_check ("nucleus.type");
  word_check ("nucleon.type/cluster.type");
  word_check ("nucleon.partial.wave/cluster.partial.wave");
  word_check ("--/N.CM.HO.maximal");

  cout << "overlap.function.type   Gauss.Legendre(yes/no)   quantum.numbers.in   quantum.numbers.out   nucleus.type   nucleon.type/cluster.type   nucleon.partial.wave/cluster.partial.wave   --/N.CM.HO.maximal" << endl;
 
  for (unsigned int overlap_index = 0 ; overlap_index < overlap_function_number ; overlap_index++)
    {
      string overlap_function_string;
      
      string nucleus_string;

      string cluster_partial_wave;

      cin >> overlap_function_string;

      overlap_function_type_tab(overlap_index) = spectroscopic_factor_type_determine (overlap_function_string);

      if ((called_code == CC_CODE) && (overlap_function_type_tab(overlap_index) != STRIPPING)) error_message_print_abort ("Stripping only for overlap function with GSM-CC");	

      overlap_function_is_it_Gauss_Legendre_tab(overlap_index) = bool_determination_no_print ("Gauss.Legendre");

      quantum_numbers_read (overlap_function_BP_IN_tab(overlap_index)  , overlap_function_J_IN_tab(overlap_index)  , overlap_function_vector_index_IN_tab(overlap_index));
      quantum_numbers_read (overlap_function_BP_OUT_tab(overlap_index) , overlap_function_J_OUT_tab(overlap_index) , overlap_function_vector_index_OUT_tab(overlap_index));

      cin >> nucleus_string;

      overlap_function_nucleus_projectile_tab(overlap_index) = nucleus_type_determine (nucleus_string);

      switch (overlap_function_nucleus_projectile_tab(overlap_index))
	{
	case ONE_NUCLEON:
	  {
	    cin >> overlap_function_cluster_projectile_tab(overlap_index);
	    
	    const enum particle_type particle = overlap_function_cluster_projectile_tab(overlap_index);

	    if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Nucleon is proton or neutron for overlap function");

	    cin >> cluster_partial_wave;

	    overlap_function_LCM_projectile_tab(overlap_index) = determine_l (cluster_partial_wave);

	    overlap_function_J_projectile_tab(overlap_index) = determine_j (cluster_partial_wave);

	    check_partial_wave (particle , overlap_function_LCM_projectile_tab(overlap_index) , overlap_function_J_projectile_tab(overlap_index));      
	    
	    overlap_function_Z_projectile_tab(overlap_index) = Z_cluster_determine (particle);
	    overlap_function_N_projectile_tab(overlap_index) = N_cluster_determine (particle);

	    overlap_function_BP_projectile_tab(overlap_index) = binary_parity_product (BP_intrinsic_cluster_determine (particle) , binary_parity_from_orbital_angular_momentum (overlap_function_LCM_projectile_tab(overlap_index)));

	    overlap_function_vector_index_projectile_tab(overlap_index) = 0;

	  } break;

	case ONE_HYPERON:
	  {
	    cin >> overlap_function_cluster_projectile_tab(overlap_index);
	    
	    const enum particle_type particle = overlap_function_cluster_projectile_tab(overlap_index);

	    if (particle_strangeness_determine (particle)) error_message_print_abort (make_string<enum particle_type> (particle) + " is not a hyperon for overlap function");

	    cin >> cluster_partial_wave;

	    overlap_function_LCM_projectile_tab(overlap_index) = determine_l (cluster_partial_wave);

	    overlap_function_J_projectile_tab(overlap_index) = determine_j (cluster_partial_wave);

	    check_partial_wave (particle , overlap_function_LCM_projectile_tab(overlap_index) , overlap_function_J_projectile_tab(overlap_index));      
	    
	    overlap_function_Z_projectile_tab(overlap_index) = Z_cluster_determine (particle);
	    overlap_function_N_projectile_tab(overlap_index) = N_cluster_determine (particle);

	    overlap_function_BP_projectile_tab(overlap_index) = binary_parity_product (BP_intrinsic_cluster_determine (particle) , binary_parity_from_orbital_angular_momentum (overlap_function_LCM_projectile_tab(overlap_index)));

	    overlap_function_vector_index_projectile_tab(overlap_index) = 0;

	  } break;

	case CLUSTER:
	  {
	    cin >> overlap_function_cluster_projectile_tab(overlap_index) >> cluster_partial_wave >> overlap_function_NCM_HO_max_projectile_tab(overlap_index);

	    const enum particle_type cluster = overlap_function_cluster_projectile_tab(overlap_index);

	    overlap_function_LCM_projectile_tab(overlap_index) = determine_L_cluster (cluster , cluster_partial_wave);

	    overlap_function_J_projectile_tab(overlap_index) = determine_J_cluster (cluster_partial_wave);

	    check_partial_wave (cluster , overlap_function_LCM_projectile_tab(overlap_index) , overlap_function_J_projectile_tab(overlap_index));
	    
	    overlap_function_Z_projectile_tab(overlap_index) = Z_cluster_determine (cluster);
	    overlap_function_N_projectile_tab(overlap_index) = N_cluster_determine (cluster);

	    const int A_projectile = overlap_function_Z_projectile_tab(overlap_index) + overlap_function_N_projectile_tab(overlap_index);
	    
	    if (A_projectile == 1) error_message_print_abort ("No cluster with one nucleon with the cluster option for overlap function : use nucleon instead");
	    
	    overlap_function_BP_projectile_tab(overlap_index) = binary_parity_product (BP_intrinsic_cluster_determine (cluster) , binary_parity_from_orbital_angular_momentum (overlap_function_LCM_projectile_tab(overlap_index)));

	    overlap_function_vector_index_projectile_tab(overlap_index) = 0;

	  } break;

	default: error_message_print_abort ("Only nucleon or cluster options for overlap function : " + make_string<enum nucleus_type> (overlap_function_nucleus_projectile_tab(overlap_index)));
	}
            
      const string overlap_function_is_it_Gauss_Legendre_string = (overlap_function_is_it_Gauss_Legendre_tab(overlap_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");
      
      cout << overlap_function_string << "    " << overlap_function_is_it_Gauss_Legendre_string << "   "
	   << J_Pi_vector_index_string (overlap_function_BP_IN_tab(overlap_index)  , overlap_function_J_IN_tab(overlap_index)  , overlap_function_vector_index_IN_tab(overlap_index)) << "   "
	   << J_Pi_vector_index_string (overlap_function_BP_OUT_tab(overlap_index) , overlap_function_J_OUT_tab(overlap_index) , overlap_function_vector_index_OUT_tab(overlap_index)) << "   "
	   << nucleus_string << "   " << overlap_function_cluster_projectile_tab(overlap_index) << "   " << cluster_partial_wave << endl;
      
      if (!is_it_triangle (overlap_function_J_IN_tab(overlap_index) , overlap_function_J_projectile_tab(overlap_index) , overlap_function_J_OUT_tab(overlap_index)))
	error_message_print_abort ("Coupling impossible for overlap function : J[in] = " + J_Pi_string (overlap_function_BP_IN_tab(overlap_index) , overlap_function_J_IN_tab(overlap_index))
				   + " , J[proj] = " + J_Pi_string (overlap_function_BP_projectile_tab(overlap_index) , overlap_function_J_projectile_tab(overlap_index))
				   + " , J[out] = " + J_Pi_string (overlap_function_BP_OUT_tab(overlap_index) , overlap_function_J_OUT_tab(overlap_index)));
    }

  cout << endl;
}





void input_data_str::rms_radius_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::rms_radius_data_read"); 
  
  if ((inter == REALISTIC_INTERACTION) && (A == 1)) error_message_print_abort ("Rms radius cannot be used with only one nucleon and no-core GSM"); 
    
  cin >> rms_radius_number;
  
  word_check_print<unsigned int> ("(rms.radii.number)" , rms_radius_number);  

  rms_radius_is_it_HO_expansion_tab.allocate (rms_radius_number);

  rms_radius_BP_tab.allocate (rms_radius_number);

  rms_radius_J_tab.allocate (rms_radius_number);

  rms_radius_vector_index_tab.allocate (rms_radius_number);

  rms_radius_particle_tab.allocate (rms_radius_number);

  rms_radius_frozen_core_tab.allocate (rms_radius_number);

  word_check ("HO.expansion(yes/no)");
  word_check ("nucleon.type");
  word_check ("quantum.numbers");
  
  if (inter != REALISTIC_INTERACTION)
    {
      word_check ("rms.nucleon.radius.frozen.core(fm)");

      cout << "HO.expansion(yes/no)   nucleon.type   quantum.numbers   rms.nucleon.radius.frozen.core(fm)" << endl;
    }
  else
    cout << "HO.expansion(yes/no)   nucleon.type   quantum.numbers" << endl;
    
  for (unsigned int rms_radius_index = 0 ; rms_radius_index < rms_radius_number ; rms_radius_index++)
    {
      rms_radius_is_it_HO_expansion_tab(rms_radius_index) = bool_determination_no_print ("HO.expansion");

      cin >> rms_radius_particle_tab(rms_radius_index);

      if ((rms_radius_particle_tab(rms_radius_index) != PROTON) && (rms_radius_particle_tab(rms_radius_index) != NEUTRON))
	error_message_print_abort ("Proton or neutron only in rms radius");

      quantum_numbers_read (rms_radius_BP_tab(rms_radius_index) , rms_radius_J_tab(rms_radius_index) , rms_radius_vector_index_tab(rms_radius_index));
      
      if (inter != REALISTIC_INTERACTION)
	{
	  cin >> rms_radius_frozen_core_tab(rms_radius_index);
	  
	  if (rms_radius_frozen_core_tab(rms_radius_index) <= 0) error_message_print_abort ("rms.nucleon.radius.frozen.core in position " + make_string<unsigned int> (rms_radius_index) + " must be positive or zero");
	}
      else
	rms_radius_frozen_core_tab(rms_radius_index) = 0.0;
  
      const string rms_radius_is_it_HO_expansion_string = (rms_radius_is_it_HO_expansion_tab(rms_radius_index)) ? ("HO.expansion(yes)") : ("HO.expansion(no)");
      
      if (inter != REALISTIC_INTERACTION)
	cout << rms_radius_is_it_HO_expansion_string << "   " << rms_radius_particle_tab(rms_radius_index) << "   "
	     << J_Pi_vector_index_string (rms_radius_BP_tab(rms_radius_index) , rms_radius_J_tab(rms_radius_index) , rms_radius_vector_index_tab(rms_radius_index)) << "   "
	     << rms_radius_frozen_core_tab(rms_radius_index) << endl;
      else
	cout << rms_radius_is_it_HO_expansion_string << "   " << rms_radius_particle_tab(rms_radius_index) << "   "
	     << J_Pi_vector_index_string (rms_radius_BP_tab(rms_radius_index) , rms_radius_J_tab(rms_radius_index) , rms_radius_vector_index_tab(rms_radius_index)) << endl;
    }
  
  cout << endl;
}



void input_data_str::rms_radius_one_body_strength_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::rms_radius_one_body_strength_data_read");      
  
  if ((inter == REALISTIC_INTERACTION) && (A == 1)) error_message_print_abort ("Rms radius one-body strength cannot be calculated with only one nucleon and no-core GSM"); 
  
  cin >> rms_radius_one_body_strength_number;
  
  word_check_print<unsigned int> ("(rms.radius.one.body.strength.number)" , rms_radius_one_body_strength_number);  

  rms_radius_one_body_strength_BP_tab.allocate (rms_radius_one_body_strength_number);

  rms_radius_one_body_strength_J_tab.allocate (rms_radius_one_body_strength_number);

  rms_radius_one_body_strength_vector_index_tab.allocate (rms_radius_one_body_strength_number);

  rms_radius_one_body_strength_particle_tab.allocate (rms_radius_one_body_strength_number);

  rms_radius_one_body_strength_is_it_Gauss_Legendre_tab.allocate (rms_radius_one_body_strength_number);

  word_check ("Gauss.Legendre(yes/no)");
  word_check ("nucleon.type");
  word_check ("quantum.numbers");

  cout << "Gauss.Legendre(yes/no)   nucleon.type   quantum.numbers" << endl;
  
  for (unsigned int rms_radius_strength_index = 0 ; rms_radius_strength_index < rms_radius_one_body_strength_number ; rms_radius_strength_index++)
    {
      rms_radius_one_body_strength_is_it_Gauss_Legendre_tab(rms_radius_strength_index) = bool_determination_no_print ("Gauss.Legendre");

      cin >> rms_radius_one_body_strength_particle_tab(rms_radius_strength_index);

      if ((rms_radius_one_body_strength_particle_tab(rms_radius_strength_index) != PROTON) && (rms_radius_one_body_strength_particle_tab(rms_radius_strength_index) != NEUTRON))
	error_message_print_abort ("Proton or neutron only in rms radius one-body strength");
      
      quantum_numbers_read (rms_radius_one_body_strength_BP_tab(rms_radius_strength_index) , rms_radius_one_body_strength_J_tab(rms_radius_strength_index) , 
			    rms_radius_one_body_strength_vector_index_tab(rms_radius_strength_index));

      const string rms_radius_one_body_strength_is_it_Gauss_Legendre_string = (rms_radius_one_body_strength_is_it_Gauss_Legendre_tab(rms_radius_strength_index)) ? ("Gauss.Legendre(yes)") : ("Gauss.Legendre(no)");
      
      cout << rms_radius_one_body_strength_is_it_Gauss_Legendre_string << "   " << rms_radius_one_body_strength_particle_tab(rms_radius_strength_index) << "   "
	   << J_Pi_vector_index_string (rms_radius_one_body_strength_BP_tab(rms_radius_strength_index) , rms_radius_one_body_strength_J_tab(rms_radius_strength_index) , rms_radius_one_body_strength_vector_index_tab(rms_radius_strength_index)) << endl;
    }
  
  cout << endl;
}







void input_data_str::dagger_tilde_operators_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::dagger_tilde_operators_data_read");      

  cin >> dagger_tilde_operators_number;
  
  word_check_print<unsigned int> ("(dagger.tilde.operator.number)" , dagger_tilde_operators_number);

  dagger_tilde_operators_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_BP_IN_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_J_IN_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_vector_index_IN_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_BP_OUT_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_J_OUT_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_vector_index_OUT_tab.allocate (dagger_tilde_operators_number);

  dagger_tilde_operators_S_IN_tab.allocate (dagger_tilde_operators_number);
  
  word_check ("dagger.tilde.operator");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");

  cout << "dagger.tilde.operator   quantum.numbers.in    quantum.numbers.out" << endl;
  
  for (unsigned int dagger_tilde_operators_index = 0 ; dagger_tilde_operators_index < dagger_tilde_operators_number ; dagger_tilde_operators_index++)
    {
      cin >> dagger_tilde_operators_tab(dagger_tilde_operators_index);

      if ((dagger_tilde_operator_space_determine (dagger_tilde_operators_tab(dagger_tilde_operators_index)) == PROT_NEUT_Y) && (space != PROT_NEUT_Y))
	error_message_print_abort ("Dagger tilde operators acting on protons and neutrons cannot be used with protons only or neutrons only");
      
      if ((dagger_tilde_operator_space_determine (dagger_tilde_operators_tab(dagger_tilde_operators_index)) == PROT_Y_ONLY) && (space == NEUT_Y_ONLY))
	error_message_print_abort ("Dagger tilde operators acting on protons only cannot be used with neutrons only");
      
      if ((dagger_tilde_operator_space_determine (dagger_tilde_operators_tab(dagger_tilde_operators_index)) == NEUT_Y_ONLY) && (space == PROT_Y_ONLY))
	error_message_print_abort ("Dagger tilde operators acting on neutrons only cannot be used with protons only");
	  
      quantum_numbers_read (
			    dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index) ,
			    dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index) ,
			    dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index));

      if (are_there_hyperons)
	{
	  cin >> dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index);
	  
	  if (dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index) > 0) error_message_print_abort ("Strangeness for dagger tilde operators must be zero or negative");
	  
	  dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index) = -dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index);
	}
      else
	dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index) = 0;
      
      quantum_numbers_read (
			    dagger_tilde_operators_BP_OUT_tab(dagger_tilde_operators_index) ,
			    dagger_tilde_operators_J_OUT_tab(dagger_tilde_operators_index) ,
			    dagger_tilde_operators_vector_index_OUT_tab(dagger_tilde_operators_index));

      if (is_it_RDM_determine (dagger_tilde_operators_tab(dagger_tilde_operators_index)))
	{
	  if ((dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index) != dagger_tilde_operators_BP_OUT_tab(dagger_tilde_operators_index)) ||
	      (make_int (dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index) - dagger_tilde_operators_J_OUT_tab(dagger_tilde_operators_index)) != 0) ||
	      (dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index) != dagger_tilde_operators_vector_index_OUT_tab(dagger_tilde_operators_index)) ||
	      (dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index) != hypernucleus_strangeness))
	    error_message_print_abort ("In and out eigenstates must be equal if RDM operators are used");
	}

      cout << dagger_tilde_operators_tab(dagger_tilde_operators_index)
	   << "   "
	   << J_Pi_vector_index_string (
					dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index) ,
					dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index) ,
					dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index));

      if (are_there_hyperons) cout << " " << -dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index);
      
      cout << "   "
	   << J_Pi_vector_index_string (
					dagger_tilde_operators_BP_OUT_tab(dagger_tilde_operators_index) ,
					dagger_tilde_operators_J_OUT_tab(dagger_tilde_operators_index) ,
					dagger_tilde_operators_vector_index_OUT_tab(dagger_tilde_operators_index))
	   << endl;
    }
  
  cout << endl;
}



void input_data_str::Coulomb_isospin_mixture_data_read ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::Coulomb_isospin_mixture_data_read");   

  cin >> Coulomb_isospin_mixture_number;
  
  word_check_print<unsigned int> ("(Coulomb.isospin.mixture.number)" , Coulomb_isospin_mixture_number);

  Coulomb_isospin_mixture_BP_tab.allocate (Coulomb_isospin_mixture_number);
  
  Coulomb_isospin_mixture_J_tab.allocate (Coulomb_isospin_mixture_number);

  Coulomb_isospin_mixture_vector_index_tab.allocate (Coulomb_isospin_mixture_number);
  
  for (unsigned int Coulomb_isospin_mixture_index = 0 ; Coulomb_isospin_mixture_index < Coulomb_isospin_mixture_number ; Coulomb_isospin_mixture_index++)
    {      
      quantum_numbers_read (Coulomb_isospin_mixture_BP_tab(Coulomb_isospin_mixture_index) , Coulomb_isospin_mixture_J_tab(Coulomb_isospin_mixture_index) , Coulomb_isospin_mixture_vector_index_tab(Coulomb_isospin_mixture_index));
            
      cout << J_Pi_vector_index_string (Coulomb_isospin_mixture_BP_tab(Coulomb_isospin_mixture_index) , Coulomb_isospin_mixture_J_tab(Coulomb_isospin_mixture_index) , Coulomb_isospin_mixture_vector_index_tab(Coulomb_isospin_mixture_index)) << endl;
    }

  cout << endl;
}

void input_data_str::spectroscopic_factor_data_read ()
{	
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::spectroscopic_factor_data_read");      

  cin >> spectroscopic_factor_number;
  
  word_check_print<unsigned int> ("(spectroscopic.factor.number)" , spectroscopic_factor_number);  

  spectroscopic_factor_type_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_nucleus_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_cluster_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_Z_projectile_tab.allocate (spectroscopic_factor_number);
  spectroscopic_factor_N_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_LCM_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_NCM_HO_max_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_BP_IN_tab.allocate  (spectroscopic_factor_number);
  spectroscopic_factor_BP_OUT_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_BP_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_J_IN_tab.allocate  (spectroscopic_factor_number);
  spectroscopic_factor_J_OUT_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_J_projectile_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_vector_index_IN_tab.allocate  (spectroscopic_factor_number);
  spectroscopic_factor_vector_index_OUT_tab.allocate (spectroscopic_factor_number);

  spectroscopic_factor_vector_index_projectile_tab.allocate (spectroscopic_factor_number);

  word_check ("spectroscopic.factor.type");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");
  word_check ("nucleus.type");
  word_check ("nucleon.type/cluster.type/--");
  word_check ("nucleon.partial.wave/cluster.partial.wave/nucleus.partial.wave");
  word_check ("--/N.CM.HO.maximal/projectile.Z.N.quantum.numbers");

  cout << "spectroscopic.factor.type   quantum.numbers.in   quantum.numbers.out   nucleus.type ";
  cout << "nucleon.type/cluster.type/--   nucleon.partial.wave/cluster.partial.wave/nucleus.partial.wave   --/N.CM.HO.maximal/projectile.Z.N.quantum.numbers" << endl;
   
  for (unsigned int factor_index = 0 ; factor_index < spectroscopic_factor_number ; factor_index++)
    {
      string spectroscopic_factor_string;
      
      string nucleus_string; 

      string cluster_partial_wave;

      cin >> spectroscopic_factor_string;

      quantum_numbers_read (spectroscopic_factor_BP_IN_tab(factor_index)  , spectroscopic_factor_J_IN_tab(factor_index)  , spectroscopic_factor_vector_index_IN_tab(factor_index));
      quantum_numbers_read (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index) , spectroscopic_factor_vector_index_OUT_tab(factor_index));

      cin >> nucleus_string;

      spectroscopic_factor_type_tab(factor_index) = spectroscopic_factor_type_determine (spectroscopic_factor_string);

      if ((called_code == CC_CODE) && (spectroscopic_factor_type_tab(factor_index) != STRIPPING)) error_message_print_abort ("Stripping only for spectroscopic factor with GSM-CC");
      
      spectroscopic_factor_nucleus_projectile_tab(factor_index) = nucleus_type_determine (nucleus_string);

      switch (spectroscopic_factor_nucleus_projectile_tab(factor_index))
	{
	case ONE_NUCLEON:
	  {
	    cin >> spectroscopic_factor_cluster_projectile_tab(factor_index) >> cluster_partial_wave;
	    
	    const enum particle_type particle = spectroscopic_factor_cluster_projectile_tab(factor_index);

	    if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Nucleon is proton or neutron for spectroscopic factor");

	    spectroscopic_factor_LCM_projectile_tab(factor_index) = determine_l (cluster_partial_wave);

	    spectroscopic_factor_J_projectile_tab(factor_index) = determine_j (cluster_partial_wave);

	    check_partial_wave (particle , spectroscopic_factor_LCM_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index));
	    
	    spectroscopic_factor_Z_projectile_tab(factor_index) = Z_cluster_determine (particle);
	    spectroscopic_factor_N_projectile_tab(factor_index) = N_cluster_determine (particle);
	    
	    spectroscopic_factor_BP_projectile_tab(factor_index) = binary_parity_product (BP_intrinsic_cluster_determine (particle) ,
											  binary_parity_from_orbital_angular_momentum (spectroscopic_factor_LCM_projectile_tab(factor_index)));
	    spectroscopic_factor_vector_index_projectile_tab(factor_index) = 0;

	    cout << spectroscopic_factor_string << "    "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_IN_tab(factor_index)  , spectroscopic_factor_J_IN_tab(factor_index)  , spectroscopic_factor_vector_index_IN_tab(factor_index)) << "   "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index) , spectroscopic_factor_vector_index_OUT_tab(factor_index)) << "   "
		 << nucleus_string << "   " << spectroscopic_factor_cluster_projectile_tab(factor_index) << "   " << cluster_partial_wave << endl;
      
	  } break;

	case ONE_HYPERON:
	  {
	    cin >> spectroscopic_factor_cluster_projectile_tab(factor_index) >> cluster_partial_wave;
	    
	    const enum particle_type particle = spectroscopic_factor_cluster_projectile_tab(factor_index);

	    if (particle_strangeness_determine (particle)) error_message_print_abort (make_string<enum particle_type> (particle) + " is not a hyperon for spectroscopic factor");

	    spectroscopic_factor_LCM_projectile_tab(factor_index) = determine_l (cluster_partial_wave);

	    spectroscopic_factor_J_projectile_tab(factor_index) = determine_j (cluster_partial_wave);

	    check_partial_wave (particle , spectroscopic_factor_LCM_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index));
	    
	    spectroscopic_factor_Z_projectile_tab(factor_index) = Z_cluster_determine (particle);
	    spectroscopic_factor_N_projectile_tab(factor_index) = N_cluster_determine (particle);
	    
	    spectroscopic_factor_BP_projectile_tab(factor_index) = binary_parity_product (BP_intrinsic_cluster_determine (particle) ,
											  binary_parity_from_orbital_angular_momentum (spectroscopic_factor_LCM_projectile_tab(factor_index)));
	    spectroscopic_factor_vector_index_projectile_tab(factor_index) = 0;

	    cout << spectroscopic_factor_string << "    "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_IN_tab(factor_index)  , spectroscopic_factor_J_IN_tab(factor_index)  , spectroscopic_factor_vector_index_IN_tab(factor_index)) << "   "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index) , spectroscopic_factor_vector_index_OUT_tab(factor_index)) << "   "
		 << nucleus_string << "   " << spectroscopic_factor_cluster_projectile_tab(factor_index) << "   " << cluster_partial_wave << endl;
      
	  } break;

	case CLUSTER:
	  {
	    cin >> spectroscopic_factor_cluster_projectile_tab(factor_index) >> cluster_partial_wave >> spectroscopic_factor_NCM_HO_max_projectile_tab(factor_index);

	    const enum particle_type cluster = spectroscopic_factor_cluster_projectile_tab(factor_index);

	    spectroscopic_factor_LCM_projectile_tab(factor_index) = determine_L_cluster (cluster , cluster_partial_wave);

	    spectroscopic_factor_J_projectile_tab(factor_index) = determine_J_cluster (cluster_partial_wave);

	    check_partial_wave (cluster , spectroscopic_factor_LCM_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index));
	    
	    spectroscopic_factor_Z_projectile_tab(factor_index) = Z_cluster_determine (cluster);
	    spectroscopic_factor_N_projectile_tab(factor_index) = N_cluster_determine (cluster);
	    	    
	    const int A_projectile = spectroscopic_factor_Z_projectile_tab(factor_index) + spectroscopic_factor_N_projectile_tab(factor_index);

	    if (A_projectile == 1) error_message_print_abort ("No cluster with one nucleon with the cluster option for spectroscopic factor : use nucleon instead");
	    
	    if (spectroscopic_factor_Z_projectile_tab(factor_index) < 0) error_message_print_abort ("One must have Z[projectile] >= 0 with the cluster option for spectroscopic factor");
	    if (spectroscopic_factor_N_projectile_tab(factor_index) < 0) error_message_print_abort ("One must have N[projectile] >= 0 with the cluster option for spectroscopic factor");

	    spectroscopic_factor_BP_projectile_tab(factor_index) = binary_parity_product (BP_intrinsic_cluster_determine (cluster) , binary_parity_from_orbital_angular_momentum (spectroscopic_factor_LCM_projectile_tab(factor_index)));
	    
	    spectroscopic_factor_vector_index_projectile_tab(factor_index) = 0;

	    cout << spectroscopic_factor_string << "    "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_IN_tab(factor_index)  , spectroscopic_factor_J_IN_tab(factor_index)  , spectroscopic_factor_vector_index_IN_tab(factor_index)) << "   "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index) , spectroscopic_factor_vector_index_OUT_tab(factor_index)) << "   "
		 << nucleus_string << "   " << spectroscopic_factor_cluster_projectile_tab(factor_index) << "   " << cluster_partial_wave << "   " << spectroscopic_factor_NCM_HO_max_projectile_tab(factor_index) << endl;
      
	  } break;

	case NUCLEUS:
	  {
	    if (A_core > 0) error_message_print_abort ("The nucleus option can only be used in no-core calculations");
	    
	    if (called_code == CC_CODE) error_message_print_abort ("One cannot use the nucleus option for spectroscopic factor with GSM-CC");

	    quantum_numbers_read (spectroscopic_factor_BP_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index) , spectroscopic_factor_vector_index_projectile_tab(factor_index));
	    
	    cin >> spectroscopic_factor_Z_projectile_tab(factor_index) >> spectroscopic_factor_N_projectile_tab(factor_index);

	    if (spectroscopic_factor_Z_projectile_tab(factor_index) < 0) error_message_print_abort ("One must have Z[projectile] >= 0 with the nucleus option for spectroscopic factor");
	    if (spectroscopic_factor_N_projectile_tab(factor_index) < 0) error_message_print_abort ("One must have N[projectile] >= 0 with the nucleus option for spectroscopic factor");

	    const int A_projectile = spectroscopic_factor_Z_projectile_tab(factor_index) + spectroscopic_factor_N_projectile_tab(factor_index);

	    if (A_projectile == 0) error_message_print_abort ("No nucleus with zero nucleon with the nucleus option for spectroscopic factor");
	    if (A_projectile == 1) error_message_print_abort ("No nucleus with one nucleon with the nucleus option for spectroscopic factor : use nucleon instead");

	    cout << spectroscopic_factor_string << "    " 
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_IN_tab(factor_index)  , spectroscopic_factor_J_IN_tab(factor_index)  , spectroscopic_factor_vector_index_IN_tab(factor_index)) << "   "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index) , spectroscopic_factor_vector_index_OUT_tab(factor_index)) << "   "
		 << J_Pi_vector_index_string (spectroscopic_factor_BP_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index) , spectroscopic_factor_vector_index_projectile_tab(factor_index)) << "   "
		 << nucleus_string << "   Z[projectile] : " << spectroscopic_factor_Z_projectile_tab(factor_index) << "   N[projectile] : " << spectroscopic_factor_N_projectile_tab(factor_index) << endl;
      
	  } break;

	default: error_message_print_abort ("No nucleus recognized in input_data_str::spectroscopic_factor_data_read: " + make_string<enum nucleus_type> (spectroscopic_factor_nucleus_projectile_tab(factor_index)));
	}
	    
      if (!is_it_triangle (spectroscopic_factor_J_IN_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index)))
	error_message_print_abort ("Coupling impossible for spectroscopic factor : J[in] = " + J_Pi_string (spectroscopic_factor_BP_IN_tab(factor_index) , spectroscopic_factor_J_IN_tab(factor_index))
				   + " , J[proj] = " + J_Pi_string (spectroscopic_factor_BP_projectile_tab(factor_index) , spectroscopic_factor_J_projectile_tab(factor_index))
				   + " , J[out] = " + J_Pi_string (spectroscopic_factor_BP_OUT_tab(factor_index) , spectroscopic_factor_J_OUT_tab(factor_index)));
    }
  
  cout << endl;
}





void input_data_str::observables_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::observables_data_read");
      
  const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));
  
  if (called_code != OPTIMIZATION_CODE)
    {          
      are_there_GSM_multipoles = bool_determination ("GSM.multipoles");
	  
      if (are_there_GSM_multipoles) GSM_multipoles_data_read ();

      if (called_code != RDM_CODE)
	{
	  are_there_EM_transitions = bool_determination ("EM.transitions");
	  
	  if (are_there_EM_transitions) EM_transitions_data_read ();

	  are_there_EM_transitions_strength = bool_determination ("EM.transitions.strength");
	  
	  if (are_there_EM_transitions_strength) EM_transitions_strength_data_read ();

	  are_there_beta_transitions = (hypernucleus_strangeness == 0) ? (bool_determination ("beta.transitions")) : (false);
	    
	  if (are_there_beta_transitions) beta_transitions_data_read ();

	  are_there_beta_transitions_strength = (hypernucleus_strangeness == 0) ? (bool_determination ("beta.transitions.strength")) : (false);
	  
	  if (are_there_beta_transitions_strength) beta_transitions_strength_data_read ();
	}
      
      are_there_densities = bool_determination ("density");
      
      if (are_there_densities) density_data_read ();
      
      if (called_code != CC_CODE)
	{
	  are_there_correlation_densities = bool_determination ("correlation.density");
	  
	  if (are_there_correlation_densities) correlation_density_data_read ();
	  
	  are_there_pair_densities = bool_determination ("pair.density");
	  
	  if (are_there_pair_densities) pair_density_data_read ();
	}

      if (called_code != RDM_CODE)
	{
	  are_there_spectroscopic_factors = bool_determination ("spectroscopic.factor");
	  
	  if (are_there_spectroscopic_factors) spectroscopic_factor_data_read ();

	  are_there_overlap_functions = bool_determination ("overlap.function");
	  
	  if (are_there_overlap_functions) overlap_function_data_read ();
	}
      
      are_there_rms_radii = bool_determination ("rms.radius");
	  
      if (are_there_rms_radii) rms_radius_data_read ();

      are_there_rms_radius_one_body_strengths = bool_determination ("rms.radius.one.body.strength");
	  
      if (are_there_rms_radius_one_body_strengths) rms_radius_one_body_strength_data_read ();

      if ((called_code != CC_CODE) && !only_dimensions && !non_zero_NBMEs_proportion_only && !is_it_fit_or_SU3)
	{
	  are_there_Hamiltonian_parts = bool_determination ("Hamiltonian.parts");
	      
	  if (are_there_Hamiltonian_parts)
	    {
	      if (basis_potential == QBOX_POTENTIAL) error_message_print_abort ("Calculation of Hamiltonian parts cannot be done with Qbox method");
		  
	      Hamiltonian_parts_data_read ();
	    }
	}

      if ((called_code != CC_CODE) && (called_code != RDM_CODE) && (called_code != TWO_PARTICLE_CODE))
	{
	  are_there_dagger_tilde_operators = bool_determination ("dagger.tilde.operators");
	  
	  if (are_there_dagger_tilde_operators) dagger_tilde_operators_data_read ();
	}
  
      if ((called_code != TWO_PARTICLE_CODE) && (called_code != RDM_CODE) && !M_equal_J_imposed_in_GSM_vectors && !is_there_disk_storage_eigenvectors_all_M)
	{
	  if (are_there_GSM_multipoles                ||
	      are_there_EM_transitions                ||
	      are_there_EM_transitions_strength       ||
	      are_there_beta_transitions              ||
	      are_there_beta_transitions_strength     ||
	      are_there_densities                     ||
	      are_there_correlation_densities         ||
	      are_there_pair_densities                ||
	      are_there_spectroscopic_factors         ||
	      are_there_overlap_functions             ||
	      are_there_rms_radii                     ||
	      are_there_rms_radius_one_body_strengths ||
	      are_there_Hamiltonian_parts             ||
	      are_there_dagger_tilde_operators        ||
	      are_there_new_natural_orbitals_p        ||
	      are_there_new_natural_orbitals_n)
	    error_message_print_abort ("One must store eigenvectors with all M-projections on disk if M can be different from J and observables/natural orbitals are calculated");
	}

      const bool are_there_basis_natural_orbitals = (are_there_basis_natural_orbitals_p || are_there_basis_natural_orbitals_n);
      
      are_there_Coulomb_isospin_mixtures = (good_isospin_basis_potential && is_Coulomb_Hamiltonian_here && !are_there_basis_natural_orbitals && (called_code != RDM_CODE) && (called_code != CC_CODE))
	? (bool_determination ("Coulomb.isospin.mixture"))
	: (false);
      
      if (are_there_Coulomb_isospin_mixtures) Coulomb_isospin_mixture_data_read ();

      cout << endl;
    }  
}




void input_data_str::eigensets_data_alloc_read_for_relative_calculation ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::eigensets_data_alloc_read_for_relative_calculation");

  is_there_effective_range_expansion = bool_determination ("effective.range.expansion");

  if (is_there_effective_range_expansion || ((Np_nlj_baryon_tab.max () == 0) && (Nn_nlj_baryon_tab.max () == 0)))
    CC_Lmax_all = 0;
  else
    {
      cin >> CC_Lmax_all;

      if (CC_Lmax_all < 0) error_message_print_abort ("LCM.max must be positive or zero");
      
      word_check_print<int> ("(LCM.max)" , CC_Lmax_all);
    }

  cin >> E_CM_HO_max;

  if (E_CM_HO_max < 0) error_message_print_abort ("E.CM.HO.max must be positive or zero");
      
  word_check_print<double> ("(E.CM.HO.max)" , E_CM_HO_max);

  cin >> eigensets_number; 

  CC_cluster_projectile_number = eigensets_number;

  word_check_print<unsigned int> ("eigenset(s)" , eigensets_number);

  CC_cluster_projectile_tab.allocate (eigensets_number);

  BP_eigenset_tab.allocate (eigensets_number);

  J_eigenset_tab.allocate (eigensets_number);

  eigenset_vectors_number_tab.allocate (eigensets_number);
  
  CC_Lmax_cluster_projectile_CM_tab.allocate (eigensets_number);

  CC_Lmax_cluster_projectile_CM_tab = 0;

  CC_corrective_factors_cluster_composite_numbers.allocate (eigensets_number);

  CC_corrective_factors_cluster_composite_numbers = 1.0;
  
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {    
      string eigenstate; 

      cin >> eigenstate;
      
      cout << eigenstate << endl;
      
      const unsigned int BP = determine_Binary_Parity (eigenstate);

      const double J = determine_J (eigenstate);
      
      BP_eigenset_tab(eigenset_index) = BP;

      J_eigenset_tab(eigenset_index) = J;

      eigenset_vectors_number_tab(eigenset_index) = 1;
  
      CC_cluster_projectile_tab(eigenset_index) = cluster_determine (relative_cluster , BP , J);

      if (CC_cluster_projectile_tab(eigenset_index) == NO_PARTICLE) error_message_print_abort ("Cluster cannot be identified");
    }
}



void input_data_str::cluster_data_read_for_CC_calculation ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::cluster_data_read_for_CC_calculation");

  word_check ("CC.cluster.Berggren.basis");
	
  cout << "CC.cluster.Berggren.basis" << endl;
      
  const int lmax_all = max (lmax_p , lmax_n);

  CC_J_number_max_all = 0;

  cin >> E_CM_HO_max;

  word_check_print<double> ("(E.CM.HO.max)" , E_CM_HO_max);

  if (E_CM_HO_max < 0) error_message_print_abort ("E.CM.HO.max must be positive or zero (cluster)");
  
  cin >> CC_cluster_projectile_number;

  word_check_print<unsigned int> ("cluster(s)" , CC_cluster_projectile_number);

  class array<bool> is_projectile_found_in_cluster_list_tab(CC_N_target_projectile_states);
  
  class array<class array<unsigned int> > CC_corrective_factors_cluster_BP_A_composite_tab_local(CC_cluster_projectile_number);

  class array<class array<double> > CC_corrective_factors_cluster_J_A_composite_tab_local(CC_cluster_projectile_number);

  class array<class array<double> > CC_corrective_factors_cluster_composite_tab_local(CC_cluster_projectile_number);
  
  CC_cluster_projectile_tab.allocate (CC_cluster_projectile_number);

  CC_Lmax_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number);

  CC_corrective_factors_cluster_composite_numbers.allocate (CC_cluster_projectile_number);
  
  CC_Lmax_cluster_projectile_CM_tab = 0;

  CC_corrective_factors_cluster_composite_numbers = 0;
    
  is_projectile_found_in_cluster_list_tab = false;
  
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {      
      enum particle_type cluster;
      
      cin >> cluster;
      
      cout << cluster << endl;

      CC_cluster_projectile_tab(ic) = cluster;
      
      for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
	{
	  const enum particle_type projectile_T = CC_projectile_tab(iT);

	  if (cluster == projectile_T)
	    {	      
	      const unsigned int N_partial_waves = CC_N_partial_waves_tab(iT);
	            
	      for (unsigned int ilj_T = 0 ; ilj_T < N_partial_waves ; ilj_T++) CC_Lmax_cluster_projectile_CM_tab(ic) = max (CC_Lmax_cluster_projectile_CM_tab(ic) , CC_partial_wave_L_cluster_projectile_tab(iT , ilj_T));
	      
	      is_projectile_found_in_cluster_list_tab(iT) = true;
	    }
	}

      if (A_cluster_determine (cluster) >= 2)
	{
	  unsigned int CC_corrective_factors_cluster_composite_number_ic; 
	  
	  cin >> CC_corrective_factors_cluster_composite_number_ic;
	  word_check_print<unsigned int> ("CC.corrective.factor." + make_string<enum particle_type> (cluster) + ".composite(s)" , CC_corrective_factors_cluster_composite_number_ic);

	  CC_corrective_factors_cluster_composite_numbers(ic) = CC_corrective_factors_cluster_composite_number_ic;
	  
	  class array<unsigned int> &CC_corrective_factors_cluster_BP_A_composite_ic_tab_local = CC_corrective_factors_cluster_BP_A_composite_tab_local(ic);
	  
	  class array<double> &CC_corrective_factors_cluster_J_A_composite_ic_tab_local = CC_corrective_factors_cluster_J_A_composite_tab_local(ic);

	  class array<double> &CC_corrective_factors_cluster_composite_ic_tab_local = CC_corrective_factors_cluster_composite_tab_local(ic);
	  
	  CC_corrective_factors_cluster_BP_A_composite_ic_tab_local.allocate (CC_corrective_factors_cluster_composite_number_ic);
	  CC_corrective_factors_cluster_J_A_composite_ic_tab_local.allocate (CC_corrective_factors_cluster_composite_number_ic);
	  CC_corrective_factors_cluster_composite_ic_tab_local.allocate (CC_corrective_factors_cluster_composite_number_ic);
	  
	  for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_number_ic ; i++)
	    {
	      string composite;
	  
	      cin >> composite;
	  
	      CC_corrective_factors_cluster_J_A_composite_ic_tab_local(i) = determine_J (composite);
	  
	      CC_corrective_factors_cluster_BP_A_composite_ic_tab_local(i) = determine_Binary_Parity (composite);
	  
	      cin >> CC_corrective_factors_cluster_composite_ic_tab_local(i);
	  
	      cout << composite << " " << CC_corrective_factors_cluster_composite_ic_tab_local(i) << endl;
	    }
	}
      
      cout << endl;
    }
  
  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
    {
      if (!is_projectile_found_in_cluster_list_tab(iT))
	error_message_print_abort ("projectile " + make_string<enum particle_type> (CC_projectile_tab(iT)) + " not found in cluster list");
    }
  	        
  CC_corrective_factors_cluster_composite_numbers_max = CC_corrective_factors_cluster_composite_numbers.max ();

  CC_corrective_factors_cluster_BP_A_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max);

  CC_corrective_factors_cluster_J_A_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max);

  CC_corrective_factors_cluster_composite_tab.allocate (CC_cluster_projectile_number , CC_corrective_factors_cluster_composite_numbers_max);
  
  CC_corrective_factors_cluster_BP_A_composite_tab = 0;

  CC_corrective_factors_cluster_J_A_composite_tab = 0.0;

  CC_corrective_factors_cluster_composite_tab = 1.0;
  
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      const unsigned int CC_corrective_factors_cluster_composite_number_ic = CC_corrective_factors_cluster_composite_numbers(ic);
	  
      const class array<unsigned int> &CC_corrective_factors_cluster_BP_A_composite_ic_tab_local = CC_corrective_factors_cluster_BP_A_composite_tab_local(ic);
	  
      const class array<double> &CC_corrective_factors_cluster_J_A_composite_ic_tab_local = CC_corrective_factors_cluster_J_A_composite_tab_local(ic);

      const class array<double> &CC_corrective_factors_cluster_composite_ic_tab_local = CC_corrective_factors_cluster_composite_tab_local(ic);
	  
      for (unsigned int i = 0 ; i < CC_corrective_factors_cluster_composite_number_ic ; i++)
	{
	  CC_corrective_factors_cluster_BP_A_composite_tab(ic , i) = CC_corrective_factors_cluster_BP_A_composite_ic_tab_local(i);
	
	  CC_corrective_factors_cluster_J_A_composite_tab(ic , i) = CC_corrective_factors_cluster_J_A_composite_ic_tab_local(i);
	
	  CC_corrective_factors_cluster_composite_tab(ic , i) = CC_corrective_factors_cluster_composite_ic_tab_local(i);
	}
    }
  
  cout << endl;
  
  word_check ("cluster.type");
  word_check ("cluster.partial.wave");
  word_check ("cluster.CM.pole.state.number");
  word_check ("N.min.PCM.cluster");
  word_check ("K.CM.peak(fm^(-1))");
  word_check ("K.CM.middle(fm^(-1))");
  word_check ("K.CM.max(fm^(-1))");
  word_check ("N.K.CM.peak");
  word_check ("N.K.CM.middle");
  word_check ("N.K.CM.max");
  
  cout << "cluster.type   cluster.partial.wave   cluster.CM.pole.state.number   N.min.PCM.cluster   K.CM.peak(fm^(-1)) K.CM.middle(fm^(-1)) K.CM.max(fm^(-1))   N.K.CM.peak N.K.CM.middle N.K.CM.max" << endl << endl;

  class array<class array<class array<int> > > CC_Nmin_PCM_cluster_projectile_tab_local;
  
  class array<class array<class array<unsigned int> > > CC_N_poles_cluster_projectile_CM_tab_local;

  class array<class array<class array<complex<double> > > > CC_K_peak_cluster_projectile_CM_tab_local;
  class array<class array<class array<complex<double> > > > CC_K_middle_cluster_projectile_CM_tab_local;
  class array<class array<class array<complex<double> > > > CC_K_max_cluster_projectile_CM_tab_local;

  class array<class array<class array<unsigned int> > > CC_N_K_peak_cluster_projectile_CM_tab_local;
  class array<class array<class array<unsigned int> > > CC_N_K_middle_cluster_projectile_CM_tab_local;
  class array<class array<class array<unsigned int> > > CC_N_K_max_cluster_projectile_CM_tab_local;

  CC_Nmin_PCM_cluster_projectile_tab_local.allocate (CC_cluster_projectile_number);

  CC_N_poles_cluster_projectile_CM_tab_local.allocate (CC_cluster_projectile_number);

  CC_K_peak_cluster_projectile_CM_tab_local.allocate   (CC_cluster_projectile_number);  
  CC_K_middle_cluster_projectile_CM_tab_local.allocate (CC_cluster_projectile_number);
  CC_K_max_cluster_projectile_CM_tab_local.allocate    (CC_cluster_projectile_number);

  CC_N_K_peak_cluster_projectile_CM_tab_local.allocate   (CC_cluster_projectile_number);
  CC_N_K_middle_cluster_projectile_CM_tab_local.allocate (CC_cluster_projectile_number);
  CC_N_K_max_cluster_projectile_CM_tab_local.allocate    (CC_cluster_projectile_number);
    
  bool are_there_two_body_clusters = false;

  enum particle_type cluster_check;
  
  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {      
      const int CC_Lmax = CC_Lmax_cluster_projectile_CM_tab(ic);

      const int CC_Lmax_L_plus_one = CC_Lmax + 1;

      const enum particle_type cluster = CC_cluster_projectile_tab(ic);

      if (!are_there_two_body_clusters && (A_cluster_determine (cluster) == 2)) are_there_two_body_clusters = true;

      const double J_intrinsic = J_intrinsic_cluster_determine (cluster);

      if (CC_Lmax > lmax_all) error_message_print_abort ("Lmax[CM] = " + make_string<int> (CC_Lmax) + " cannot be larger than lmax[one-nucleon] = " + make_string<int> (lmax_all));

      class array<class array<int> > &CC_Nmin_PCM_cluster_ic_tab_local = CC_Nmin_PCM_cluster_projectile_tab_local(ic);

      class array<class array<unsigned int> > &CC_N_poles_cluster_CM_ic_tab_local = CC_N_poles_cluster_projectile_CM_tab_local(ic);

      class array<class array<complex<double> > > &CC_K_peak_cluster_CM_ic_tab_local = CC_K_peak_cluster_projectile_CM_tab_local(ic);
      
      class array<class array<complex<double> > > &CC_K_middle_cluster_CM_ic_tab_local = CC_K_middle_cluster_projectile_CM_tab_local(ic);

      class array<class array<complex<double> > > &CC_K_max_cluster_CM_ic_tab_local = CC_K_max_cluster_projectile_CM_tab_local(ic);

      class array<class array<unsigned int> > &CC_N_K_peak_cluster_CM_ic_tab_local = CC_N_K_peak_cluster_projectile_CM_tab_local(ic);

      class array<class array<unsigned int> > &CC_N_K_middle_cluster_CM_ic_tab_local = CC_N_K_middle_cluster_projectile_CM_tab_local(ic);

      class array<class array<unsigned int> > &CC_N_K_max_cluster_CM_ic_tab_local = CC_N_K_max_cluster_projectile_CM_tab_local(ic);

      CC_Nmin_PCM_cluster_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_N_poles_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_K_peak_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);
      
      CC_K_middle_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_K_max_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_N_K_peak_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_N_K_middle_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      CC_N_K_max_cluster_CM_ic_tab_local.allocate (CC_Lmax_L_plus_one);

      for (int L = 0 ; L <= CC_Lmax ; L++)
	{
	  const double Jmin = abs (J_intrinsic - L);
	  const double Jmax =      J_intrinsic + L;

	  const unsigned int J_number = make_uns_int (Jmax - Jmin) + 1;

	  CC_J_number_max_all = max (CC_J_number_max_all , J_number);

	  class array<int> &CC_Nmin_PCM_cluster_ic_L_tab_local = CC_Nmin_PCM_cluster_ic_tab_local(L);

	  class array<unsigned int> &CC_N_poles_cluster_CM_ic_L_tab_local = CC_N_poles_cluster_CM_ic_tab_local(L);

	  class array<complex<double> > &CC_K_peak_cluster_CM_ic_L_tab_local = CC_K_peak_cluster_CM_ic_tab_local(L);

	  class array<complex<double> > &CC_K_middle_cluster_CM_ic_L_tab_local = CC_K_middle_cluster_CM_ic_tab_local(L);

	  class array<complex<double> > &CC_K_max_cluster_CM_ic_L_tab_local = CC_K_max_cluster_CM_ic_tab_local(L);

	  class array<unsigned int> &CC_N_K_peak_cluster_CM_ic_L_tab_local = CC_N_K_peak_cluster_CM_ic_tab_local(L);

	  class array<unsigned int> &CC_N_K_middle_cluster_CM_ic_L_tab_local = CC_N_K_middle_cluster_CM_ic_tab_local(L);

	  class array<unsigned int> &CC_N_K_max_cluster_CM_ic_L_tab_local = CC_N_K_max_cluster_CM_ic_tab_local(L);

	  CC_Nmin_PCM_cluster_ic_L_tab_local.allocate (J_number);

	  CC_N_poles_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_K_peak_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_K_middle_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_K_max_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_N_K_peak_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_N_K_middle_cluster_CM_ic_L_tab_local.allocate (J_number);

	  CC_N_K_max_cluster_CM_ic_L_tab_local.allocate (J_number);

	  for (unsigned int J_index = 0 ; J_index < J_number ; J_index++)
	    {
	      const double J = Jmin + J_index;

	      if (!is_there_cluster_partial_wave_determine (cluster , L , J)) continue;

	      cin >> cluster_check;
	  
	      if (cluster_check != CC_cluster_projectile_tab(ic))
		{
		  const string error_check_string = "read cluster:" + make_string<enum particle_type> (cluster_check) + ", correct cluster:" + make_string<enum particle_type> (CC_cluster_projectile_tab(ic));
		  
		  error_message_print_abort ("Wrong cluster in input_data_str::cluster_data_read_for_CC_calculation " + error_check_string);
		}
	      
	      word_check (angular_state_cluster (cluster , L , J));
  
	      cin >> CC_N_poles_cluster_CM_ic_L_tab_local(J_index) >> CC_Nmin_PCM_cluster_ic_L_tab_local(J_index);
	      
	      //--// parameters of the complex contour
	      cin >> CC_K_peak_cluster_CM_ic_L_tab_local(J_index) >> CC_K_middle_cluster_CM_ic_L_tab_local(J_index) >> CC_K_max_cluster_CM_ic_L_tab_local(J_index);	      
	      cin >> CC_N_K_peak_cluster_CM_ic_L_tab_local(J_index) >> CC_N_K_middle_cluster_CM_ic_L_tab_local(J_index) >> CC_N_K_max_cluster_CM_ic_L_tab_local(J_index);
      
	      cout << CC_cluster_projectile_tab(ic) << "   " << angular_state_cluster (cluster , L , J) << "   " << CC_N_poles_cluster_CM_ic_L_tab_local(J_index) << "   " << CC_Nmin_PCM_cluster_ic_L_tab_local(J_index) << "   ";
	      cout << CC_K_peak_cluster_CM_ic_L_tab_local(J_index) << " " << CC_K_middle_cluster_CM_ic_L_tab_local(J_index) << " " << CC_K_max_cluster_CM_ic_L_tab_local(J_index) << "   ";     
	      cout << CC_N_K_peak_cluster_CM_ic_L_tab_local(J_index) << " " << CC_N_K_middle_cluster_CM_ic_L_tab_local(J_index) << " " << CC_N_K_max_cluster_CM_ic_L_tab_local(J_index) << endl;
	    }
	}  
    }

  CC_Lmax_all = CC_Lmax_cluster_projectile_CM_tab.max ();
  
  const unsigned int CC_Lmax_all_plus_one = CC_Lmax_all + 1;

  CC_Nmin_PCM_cluster_projectile_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_Nmin_PCM_cluster_projectile_tab = 0;

  CC_N_poles_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_poles_cluster_projectile_CM_tab = 0;

  CC_K_peak_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_K_peak_cluster_projectile_CM_tab = 0.0;

  CC_K_middle_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_K_middle_cluster_projectile_CM_tab = 0.0;

  CC_K_max_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_K_max_cluster_projectile_CM_tab = 0.0;

  CC_N_K_peak_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_peak_cluster_projectile_CM_tab = 0;

  CC_N_K_middle_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_middle_cluster_projectile_CM_tab = 0;

  CC_N_K_max_cluster_projectile_CM_tab.allocate (CC_cluster_projectile_number , CC_Lmax_all_plus_one , CC_J_number_max_all);
  CC_N_K_max_cluster_projectile_CM_tab = 0;

  for (unsigned int ic = 0 ; ic < CC_cluster_projectile_number ; ic++)
    {
      const int CC_Lmax = CC_Lmax_cluster_projectile_CM_tab(ic);

      const enum particle_type cluster = CC_cluster_projectile_tab(ic);

      const double J_intrinsic = J_intrinsic_cluster_determine (cluster);

      for (int L = 0 ; L <= CC_Lmax ; L++)
	{
	  const double Jmin = abs (J_intrinsic - L);
	  const double Jmax =      J_intrinsic + L;
	  
	  const unsigned int J_number = make_uns_int (Jmax - Jmin) + 1;

	  for (unsigned int J_index = 0 ; J_index < J_number ; J_index++)
	    {
	      const double J = Jmin + J_index;

	      if (is_there_cluster_partial_wave_determine (cluster , L , J))
		{
		  CC_Nmin_PCM_cluster_projectile_tab     (ic , L , J_index) = CC_Nmin_PCM_cluster_projectile_tab_local     (ic)(L)(J_index);
		  CC_N_poles_cluster_projectile_CM_tab   (ic , L , J_index) = CC_N_poles_cluster_projectile_CM_tab_local   (ic)(L)(J_index);
		  CC_K_peak_cluster_projectile_CM_tab    (ic , L , J_index) = CC_K_peak_cluster_projectile_CM_tab_local    (ic)(L)(J_index);
		  CC_K_middle_cluster_projectile_CM_tab  (ic , L , J_index) = CC_K_middle_cluster_projectile_CM_tab_local  (ic)(L)(J_index);
		  CC_K_max_cluster_projectile_CM_tab     (ic , L , J_index) = CC_K_max_cluster_projectile_CM_tab_local     (ic)(L)(J_index);
		  CC_N_K_peak_cluster_projectile_CM_tab  (ic , L , J_index) = CC_N_K_peak_cluster_projectile_CM_tab_local  (ic)(L)(J_index);
		  CC_N_K_middle_cluster_projectile_CM_tab(ic , L , J_index) = CC_N_K_middle_cluster_projectile_CM_tab_local(ic)(L)(J_index);
		  CC_N_K_max_cluster_projectile_CM_tab   (ic , L , J_index) = CC_N_K_max_cluster_projectile_CM_tab_local   (ic)(L)(J_index);
		}
	    }
	}
    }

  cout << endl;

  if (are_there_two_body_clusters)
    {
      are_two_body_clusters_stored_in_J_scheme = bool_determination_no_print ("two.body.clusters.stored.in.J.scheme");

      const string are_two_body_clusters_stored_in_J_scheme_string = (are_two_body_clusters_stored_in_J_scheme) ? ("two.body.clusters.stored.in.J.scheme(yes)") : ("two.body.clusters.stored.in.J.scheme(no)  ");

      cout << are_two_body_clusters_stored_in_J_scheme_string << endl;

      cout << endl;
    }
}


void input_data_str::cluster_data_read_for_cluster_CM_HO_calculation ()
{ 
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::cluster_data_read_for_cluster_CM_HO_calculation");

  is_it_cluster_CM_HO_basis_calculation = bool_determination ("cluster.CM.HO.basis.calculation");

  if (is_it_cluster_CM_HO_basis_calculation)
    {
      cin >> CC_Lmax_all;

      if (CC_Lmax_all <= 0) error_message_print_abort ("LCM.max must be larger or equal to one (cluster CM-HO)");
      
      word_check_print<int> ("(LCM.max)" , CC_Lmax_all);

      cin >> E_CM_HO_max;

      if (E_CM_HO_max < 0) error_message_print_abort ("E.CM.HO.max must be positive or zero (cluster CM-HO)");
      
      word_check_print<double> ("(E.CM.HO.max)" , E_CM_HO_max);
    }
  
  const int Aval_basis = Zval_basis + Nval_basis;
  
  const int Aval = ZYval + NYval;
      
  const int lmax_all = max (lmax_p , lmax_n);

  if (!is_it_cluster_CM_HO_basis_calculation && ((Aval >= 2) || (Aval_basis >= 2)) && (lmax_for_basis_interaction != lmax_all) && (lmax_for_interaction != lmax_all))
    error_message_print_abort ("When is_it_cluster_CM_HO_basis_calculation is false, lmax_for_basis_interaction and lmax_for_interaction must be equal to lmax_all in input_data_str::cluster_data_read_for_cluster_CM_HO_calculation");

  cout << endl;
}




void input_data_str::optimization_fixed_nucleus_alloc_read (const class input_data_str &input_data_common)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::optimization_fixed_nucleus_alloc_read");

  print_detailed_information = input_data_common.print_detailed_information;

  only_dimensions = input_data_common.only_dimensions;

  is_Coulomb_Hamiltonian_here = input_data_common.is_Coulomb_Hamiltonian_here;
 
  non_zero_NBMEs_proportion_only = input_data_common.non_zero_NBMEs_proportion_only;

  copy_J_OBMEs_TBMEs = input_data_common.copy_J_OBMEs_TBMEs;

  lambda_Hcm = input_data_common.lambda_Hcm;

  initial_pivot_from_file = input_data_common.initial_pivot_from_file;

  full_common_vectors_used_in_file = input_data_common.full_common_vectors_used_in_file;

  inter = input_data_common.inter;

  is_Coulomb_to_be_added = input_data_common.is_Coulomb_to_be_added;

  R = input_data_common.R;

  step_bef_R_uniform = input_data_common.step_bef_R_uniform;

  R_real_max = input_data_common.R_real_max;

  kmax_momentum = input_data_common.kmax_momentum;

  R_Fermi_momentum = input_data_common.R_Fermi_momentum;
  
  step_momentum_uniform = input_data_common.step_momentum_uniform;
  
  Nk_momentum_GL = input_data_common.Nk_momentum_GL;
  
  Nk_momentum_uniform = input_data_common.Nk_momentum_uniform;
  
  R_cut_function = input_data_common.R_cut_function;

  d_cut_function = input_data_common.d_cut_function;

  Ueq_regularizor = input_data_common.Ueq_regularizor;

  N_bef_R_GL = input_data_common.N_bef_R_GL;
  N_aft_R_GL = input_data_common.N_aft_R_GL;

  N_bef_R_uniform = input_data_common.N_bef_R_uniform;
  N_aft_R_uniform = input_data_common.N_aft_R_uniform;

  good_isospin_basis_potential = input_data_common.good_isospin_basis_potential;

  basis_potential = input_data_common.basis_potential;

  R_charge = input_data_common.R_charge;

  H_potential = input_data_common.H_potential;
  
  H_basis_core_potential = input_data_common.H_basis_core_potential;
  
  A_core = input_data_common.A_core;
  Z_core = input_data_common.Z_core;
  N_core = input_data_common.N_core;

  frozen_core_mass = input_data_common.frozen_core_mass;

  nucleus_mass_basis = input_data_common.nucleus_mass;
  nucleus_mass       = input_data_common.nucleus_mass;
  total_nucleus_mass = input_data_common.total_nucleus_mass;
	
  truncation_hw = input_data_common.truncation_hw;
  truncation_ph = input_data_common.truncation_ph;

  E_relative_max_hw                    = input_data_common.E_relative_max_hw;
  E_relative_max_hw_pole_approximation = input_data_common.E_relative_max_hw_pole_approximation;

  n_holes_max_pole_approximation   = input_data_common.n_holes_max_pole_approximation;
  n_holes_max_p_pole_approximation = input_data_common.n_holes_max_p_pole_approximation;
  n_holes_max_n_pole_approximation = input_data_common.n_holes_max_n_pole_approximation;
  
  n_holes_max   = input_data_common.n_holes_max;
  n_holes_max_p = input_data_common.n_holes_max_p;
  n_holes_max_n = input_data_common.n_holes_max_n;

  n_scat_max   = input_data_common.n_scat_max;
  n_scat_max_p = input_data_common.n_scat_max_p;
  n_scat_max_n = input_data_common.n_scat_max_n;

  binding_energies_fitted = input_data_common.binding_energies_fitted;
  
  are_natural_orbitals_calculated_every_iteration = input_data_common.are_natural_orbitals_calculated_every_iteration;

  configuration_precision = input_data_common.configuration_precision;

  workspace_max_dimension = input_data_common.workspace_max_dimension;

  test_vector_solution = input_data_common.test_vector_solution;

  b_lab_basis = input_data_common.b_lab_basis;
  b_lab       = input_data_common.b_lab;
  
  N_nuclei_to_consider = input_data_common.N_nuclei_to_consider;

  J_projected = input_data_common.J_projected;

  is_it_Lowdin = input_data_common.is_it_Lowdin;
  
  T2_CM_operators_calculated = input_data_common.T2_CM_operators_calculated;

  Newton_precision = input_data_common.Newton_precision;
  
  is_it_fixed_relative_SVD_precision = input_data_common.is_it_fixed_relative_SVD_precision;
  
  relative_SVD_precision = input_data_common.relative_SVD_precision;

  rejected_singular_values_number = input_data_common.rejected_singular_values_number;
  
  binding_energies_fitted = input_data_common.binding_energies_fitted;
  
  are_natural_orbitals_calculated_every_iteration = input_data_common.are_natural_orbitals_calculated_every_iteration;

  is_cost_function_Hessian_matrix_calculated = input_data_common.is_cost_function_Hessian_matrix_calculated;
  
  OBMEs_inter_read = input_data_common.OBMEs_inter_read;

  is_it_cluster_CM_HO_basis_calculation = input_data_common.is_it_cluster_CM_HO_basis_calculation; 

  inter_read = input_data_common.inter_read;

  Hamiltonian_storage = input_data_common.Hamiltonian_storage;

  M_TBMEs_storage = input_data_common.M_TBMEs_storage;
  
  one_jumps_pn_two_jumps_cv_storage = input_data_common.one_jumps_pn_two_jumps_cv_storage;

  is_hole_double_counting_suppressed = input_data_common.is_hole_double_counting_suppressed;
      
  are_configuration_probabilities_printed = input_data_common.are_configuration_probabilities_printed;
  
  are_scattering_configuration_probabilities_printed = input_data_common.are_scattering_configuration_probabilities_printed;
  
  are_GSM_vectors_stored_on_disk = input_data_common.are_GSM_vectors_stored_on_disk;

  A_dependence_alpha_core_potential = input_data_common.A_dependence_alpha_core_potential;
  
  A_dependence_exponent = input_data_common.A_dependence_exponent;
  
  is_R_charge_fitted = input_data_common.is_R_charge_fitted;
  
  same_dp_all_lj_tab.allocate_fill (input_data_common.same_dp_all_lj_tab);
  same_dn_all_lj_tab.allocate_fill (input_data_common.same_dn_all_lj_tab);
  
  same_R0_p_all_lj_tab.allocate_fill (input_data_common.same_R0_p_all_lj_tab);
  same_R0_n_all_lj_tab.allocate_fill (input_data_common.same_R0_n_all_lj_tab);
  
  same_Vo_p_all_lj_tab.allocate_fill (input_data_common.same_Vo_p_all_lj_tab);
  same_Vo_n_all_lj_tab.allocate_fill (input_data_common.same_Vo_n_all_lj_tab);

  same_Vso_p_all_lj_tab.allocate_fill (input_data_common.same_Vso_p_all_lj_tab);
  same_Vso_n_all_lj_tab.allocate_fill (input_data_common.same_Vso_n_all_lj_tab);

  is_dp_fitted_tab.allocate_fill (input_data_common.is_dp_fitted_tab);
  is_dn_fitted_tab.allocate_fill (input_data_common.is_dn_fitted_tab);
  
  is_R0_p_fitted_tab.allocate_fill (input_data_common.is_R0_p_fitted_tab);
  is_R0_n_fitted_tab.allocate_fill (input_data_common.is_R0_n_fitted_tab);
  
  is_Vo_p_fitted_tab.allocate_fill (input_data_common.is_Vo_p_fitted_tab);
  is_Vo_n_fitted_tab.allocate_fill (input_data_common.is_Vo_n_fitted_tab);
  
  is_Vso_p_fitted_tab.allocate_fill (input_data_common.is_Vso_p_fitted_tab);
  is_Vso_n_fitted_tab.allocate_fill (input_data_common.is_Vso_n_fitted_tab);

  is_V0_ctr_ot_S1_T1_fitted = input_data_common.is_V0_ctr_ot_S1_T1_fitted;
  is_V0_ctr_et_S1_T0_fitted = input_data_common.is_V0_ctr_et_S1_T0_fitted;
  is_V0_ctr_os_S0_T0_fitted = input_data_common.is_V0_ctr_os_S0_T0_fitted;
  is_V0_ctr_es_S0_T1_fitted = input_data_common.is_V0_ctr_es_S0_T1_fitted;
  is_V0_so_ot_S1_T1_fitted  = input_data_common.is_V0_so_ot_S1_T1_fitted;
  is_V0_so_et_S1_T0_fitted  = input_data_common.is_V0_so_et_S1_T0_fitted;
  is_V0_t_ot_S1_T1_fitted   = input_data_common.is_V0_t_ot_S1_T1_fitted;
  is_V0_t_et_S1_T0_fitted   = input_data_common.is_V0_t_et_S1_T0_fitted;
  is_V0_ALS_fitted          = input_data_common.is_V0_ALS_fitted;

  is_VS_const_LO_T0_fitted          = input_data_common.is_VS_const_LO_T0_fitted;
  is_VS_const_LO_T1_fitted          = input_data_common.is_VS_const_LO_T1_fitted;
  is_VT_sigma_product_LO_T0_fitted  = input_data_common.is_VT_sigma_product_LO_T0_fitted;
  is_VT_sigma_product_LO_T1_fitted  = input_data_common.is_VT_sigma_product_LO_T1_fitted;
  is_V1_q2_NLO_fitted               = input_data_common.is_V1_q2_NLO_fitted;
  is_V2_k2_NLO_fitted               = input_data_common.is_V2_k2_NLO_fitted;
  is_V3_q2_sigma_product_NLO_fitted = input_data_common.is_V3_q2_sigma_product_NLO_fitted;
  is_V4_k2_sigma_product_NLO_fitted = input_data_common.is_V4_k2_sigma_product_NLO_fitted;
  is_V5_sigma_q_vector_k_NLO_fitted = input_data_common.is_V5_sigma_q_vector_k_NLO_fitted;
  is_V6_sigma_q_product_NLO_fitted  = input_data_common.is_V6_sigma_q_product_NLO_fitted;
  is_V7_sigma_k_product_NLO_fitted  = input_data_common.is_V7_sigma_k_product_NLO_fitted;
  is_V8_sigma_q_vector_k_NLO_fitted = input_data_common.is_V8_sigma_q_vector_k_NLO_fitted;
  
  is_V8a_SU3f_fitted = input_data_common.is_V8a_SU3f_fitted;
  is_V8s_SU3f_fitted = input_data_common.is_V8s_SU3f_fitted;
  is_V10_SU3f_fitted = input_data_common.is_V10_SU3f_fitted;
  is_V1_SU3f_fitted  = input_data_common.is_V1_SU3f_fitted;

  //types valence nucleon? (neutron , proton , both)

  cin >> basis_space; 

  word_check_print<enum space_type> ("(basis.space)" , basis_space);

  cin >> space;

  word_check_print<enum space_type> ("(space)" , space);

  if ((space == PROT_NEUT_UNMIXED) || (space == PROT_NEUT_UNMIXED_Y)) error_message_print_abort ("GSM space cannot be protons-neutrons-unmixed or protons-neutrons-unmixed-hyperons (fixed nucleus for GSM optimization)");
  
  if (((basis_space != PROT_NEUT) || (basis_space != PROT_NEUT_Y)) && (basis_space != space)) error_message_print_abort ("Basis space is protons-neutrons, protons-neutrons-hyperons or the same as GSM space (fixed nucleus for GSM optimization)");
  
  // reads core mass and core charge
  if (basis_potential != HO_POTENTIAL)
    {
      int dummy_strangeness;
      
      unsigned int dummy_N_hyperon_types;
	  
      class array<enum particle_type> dummy_hyperon_types;
	  
      valence_particle_number_baryons_read (true , basis_space , H_potential , Zval_basis , Nval_basis , dummy_strangeness , dummy_N_hyperon_types , dummy_hyperon_types);
    }
      
  valence_particle_number_baryons_read (false , space , H_potential , Zval , Nval , hypernucleus_strangeness , N_hyperon_types , hyperon_types);
      
  const bool are_there_hyperons_in_basis_space = ((basis_space == PROT_Y_ONLY) || (basis_space == NEUT_Y_ONLY) || (basis_space == PROT_NEUT_UNMIXED_Y) || (basis_space == PROT_NEUT_Y));

  if (are_there_hyperons_in_basis_space) error_message_print_abort ("One cannot have hyperons in basis space (fixed nucleus for GSM optimization)");
  
  are_there_hyperons = ((space == PROT_Y_ONLY) || (space == NEUT_Y_ONLY) || (space == PROT_NEUT_UNMIXED_Y) || (space == PROT_NEUT_Y));

  basis_space = space_type_reset (basis_space , hyperon_types);
  space       = space_type_reset (      space , hyperon_types);

  is_cv_possible = is_cv_possible_determine (Zval , Nval , hypernucleus_strangeness , hyperon_types);
    
  if (basis_potential == HO_POTENTIAL)
    {
      Zval_basis = Zval;
      Nval_basis = Nval;
    }
      
  ZYval = Zval;
  NYval = Nval;
      
  for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
    {
      const enum particle_type hyperon = hyperon_types(i);
      
      const int Y_charge = particle_charge_determine (hyperon);
	  
      if (Y_charge == 0) NYval++;
      if (Y_charge != 0) ZYval++;
    }

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
        
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
  
  effective_masses_for_calc_p.allocate (Np_baryon_type);
  effective_masses_for_calc_n.allocate (Nn_baryon_type);

  effective_masses_for_calc_p = 1.0;
  effective_masses_for_calc_n = 1.0;
  
  particles_number_charges_masses_alloc_read_calc ();

  eigenvectors_data_alloc_read ();
  
  lmax_baryon_p_tab.allocate (Np_baryon_type);
  lmax_baryon_n_tab.allocate (Nn_baryon_type);

  lmax_common_baryon_p_tab.allocate (Np_baryon_type);
  lmax_common_baryon_n_tab.allocate (Nn_baryon_type);    
      
  Np_nlj_baryon_tab.allocate (Np_baryon_type);
  Nn_nlj_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nlj_res_baryon_tab.allocate (Np_baryon_type);
  Nn_nlj_res_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nljm_baryon_tab.allocate (Np_baryon_type);
  Nn_nljm_baryon_tab.allocate (Nn_baryon_type);
      
  Np_nljm_res_baryon_tab.allocate (Np_baryon_type);
  Nn_nljm_res_baryon_tab.allocate (Nn_baryon_type);
            
  shells_quantum_numbers_p_tab.allocate (Np_baryon_type);
  shells_quantum_numbers_n_tab.allocate (Nn_baryon_type);
      
  are_there_basis_natural_orbitals_p_tab.allocate (Np_baryon_type);
  are_there_basis_natural_orbitals_n_tab.allocate (Nn_baryon_type);
      
  class array<class nlj_struct> &prot_shells_quantum_numbers = shells_quantum_numbers_p_tab(prot_index);
  class array<class nlj_struct> &neut_shells_quantum_numbers = shells_quantum_numbers_n_tab(neut_index);
  
  lmax_baryon_p_tab = 0;
  lmax_baryon_n_tab = 0;
  
  lmax_common_baryon_p_tab = 0;
  lmax_common_baryon_n_tab = 0;
  
  Np_nlj_baryon_tab = 0;
  Nn_nlj_baryon_tab = 0;
      
  Np_nlj_res_baryon_tab = 0;
  Nn_nlj_res_baryon_tab = 0;
      
  Np_nljm_baryon_tab = 0;
  Nn_nljm_baryon_tab = 0;
      
  Np_nljm_res_baryon_tab = 0;
  Nn_nljm_res_baryon_tab = 0;
      
  are_there_basis_natural_orbitals_p_tab = false;
  are_there_basis_natural_orbitals_n_tab = false;
      
  if (basis_space != NEUT_Y_ONLY)
    {  
      shells_to_consider (PROTON , false);
	  
      shells_consistency_tests (prot_shells_quantum_numbers);
    }
      
  if (basis_space != PROT_Y_ONLY)
    {  
      shells_to_consider (NEUTRON , false);
	  
      shells_consistency_tests (neut_shells_quantum_numbers);
    }

  for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
    {
      const enum particle_type hyperon = hyperon_types(i);
	  	  
      class array<class nlj_struct> &hyperon_shells_quantum_numbers = shells_quantum_numbers_determine(hyperon);
	  
      shells_to_consider (hyperon , false);
      	  
      shells_consistency_tests (hyperon_shells_quantum_numbers);
    }
      
  all_E_max_hw_calc ();
      
  BP_J_strangeness_i_charge_min_max_global_from_partial_waves (); 

  same_partial_waves_isospin_multiplets_check ();
	
  basis_potential_data_alloc_read ();
  
  optimized_partial_waves_basis_potentials_data_alloc_read ();

  b_lab_partial_waves_tab_alloc_read ();

  natural_orbitals_data_alloc_read ();

  string method;

  cin >> method;

  cout << method << endl;

  if (method == "Lanczos") 
    is_it_Lanczos = true;
  else if (method == "Davidson") 
    is_it_Lanczos = false;
  else 
    error_message_print_abort ("Method to find eigenvectors undefined : " + method);

  if (is_it_Lanczos)
    {	  
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      if (PSI_qn_from_file_tab(eigenset_index , i).get_vector_index () != i)
		error_message_print_abort ("All eigenvectors from the ground state to the last considered excited state must be present sequentially in a given eigenset with the Lanczos method (optimization code)");	
	    }
	}
    }
      
  cin >> N_restarts;

  word_check_print<unsigned int> ("Lanczos/Davidson.restarts" , N_restarts);
  cout << endl;
}





void input_data_str::CC_reaction_Davidson_cross_section_diagonalization_starting_points_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_reaction_Davidson_cross_section_diagonalization_starting_points_data_read");

  // reaction type
  cin >> CC_reaction;

  word_check_print<enum CC_reaction_type> ("(reaction.type)" , CC_reaction);

  cin >> CC_Davidson_N_restarts;

  word_check_print<unsigned int> ("(Davidson.restarts.number)" , CC_Davidson_N_restarts);

  cin >> CC_Davidson_max_dimension;

  word_check_print<unsigned int> ("(Davidson.maximal.dimension)" , CC_Davidson_max_dimension);

  cin >> CC_Davidson_eigenvector_precision;

  if (CC_Davidson_eigenvector_precision <= 0) error_message_print_abort ("Davidson.eigenvector.precision must be positive (GSM-CC)");
      
  word_check_print<double> ("(Davidson.eigenvector.precision)" , CC_Davidson_eigenvector_precision);

  cin >> CC_relative_SVD_precision;

  if (CC_relative_SVD_precision <= 0) error_message_print_abort ("relative.SVD.precision must be positive (GSM-CC)");
  
  word_check_print<double> ("(relative.SVD.precision)" , CC_relative_SVD_precision);

  cin >> CC_forbidden_channel_precision;

  if (CC_forbidden_channel_precision <= 0) error_message_print_abort ("forbidden.channel.precision must be positive (GSM-CC)");
  
  word_check_print<double> ("(forbidden.channel.precision)" , CC_forbidden_channel_precision);

  CC_are_GSM_a_dagger_vectors_calculated = bool_determination ("GSM.a+.vector.calculations");

  // reaction calculation type
  cin >> CC_reaction_calculation;
  cout << "Reaction calculation type: " << CC_reaction_calculation << endl;

  if ((CC_reaction_calculation == POLES) && (CC_reaction != SCATTERING)) error_message_print_abort ("Pole calculations is done with scattering reaction type only");
  
  if ((CC_reaction_calculation == TOTAL_CROSS_SECTION) && (CC_reaction == SCATTERING)) CC_reaction_calculation = EXCITATION_FUNCTION;
}









void input_data_str::CC_data_composite_states_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_data_composite_states_read");

  // allocate memory for the composite states
  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      CC_radiative_capture_in_composite_data_alloc_read ();
      
      CC_radiative_capture_out_composite_data_alloc_read ();
    }

  if (CC_reaction == SCATTERING) CC_scattering_composite_data_alloc_read ();
  
  cout << endl;
}



void input_data_str::CC_radiative_capture_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_radiative_capture_data_read");

  if (CC_reaction != RADIATIVE_CAPTURE) return;

  //--// get the electromagnetic type like in "E2 2+ 1 --> 0+ 1"

  string EM_string;
      
  cin >> EM_string;

  word_check ("(CC.radiative.capture.EM.for.radiative.capture.cross.section)");
      
  CC_EM_for_radiative_capture_cross_section = EM_determine (EM_string);
      
  //--// get the number after E/M (example: E1 , M3)
  EM_string += '\n';
      
  string L_of_EM;
      
  for (unsigned int ii = 1 ; EM_string[ii] != '\n' ; ii++) L_of_EM += EM_string[ii];
      
  CC_L_for_radiative_capture_cross_section = atoi (L_of_EM.c_str ());

  //--// check something like "long.wavelength.approximation (no) and HO.expansion (yes)"
  CC_is_it_longwavelength_approximation = bool_determination ("long.wavelength.approximation.for.CC.radiative.capture");

  CC_is_it_HO_expansion = bool_determination ("HO.expansion.for.CC.radiative.capture");

  cout << endl;
}







void input_data_str::CC_cross_section_E_kinetic_total_system_CM_angles_values_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::CC_cross_section_E_kinetic_total_system_CM_angles_values_read");
  
  if ((CC_reaction_calculation == EXCITATION_FUNCTION) || (CC_reaction_calculation == PHASE_SHIFTS) || ((CC_reaction == RADIATIVE_CAPTURE) && (CC_reaction_calculation != DIFFERENTIAL_CROSS_SECTION)))
    {
      cin >> CC_N_energies;
      
      word_check_print<unsigned int> ("(energy.discretization)" , CC_N_energies);

      cin >> CC_E_kinetic_total_system_CM_start;

      word_check_print<double> ("MeV(E.kinetic.total.system.CM.start)" , CC_E_kinetic_total_system_CM_start);

      cin >> CC_E_kinetic_total_system_CM_end;

      word_check_print<double> ("MeV(E.kinetic.total.system.CM.end)" , CC_E_kinetic_total_system_CM_end);
			
      if (CC_N_energies <= 1) error_message_print_abort ("One must have N[energies] >= 2 with GSM-CC");

      if (CC_E_kinetic_total_system_CM_start <= 0.0) error_message_print_abort ("One must have E.kinetic.total.system.CM.start > 0");
      
      if ((CC_E_kinetic_total_system_CM_end - CC_E_kinetic_total_system_CM_start) < -precision) error_message_print_abort ("E.kinetic.total.system.CM.end must be larger than E.kinetic.total.system.CM.start");
    }

  if (CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION)
    {	
      cin >> CC_E_kinetic_total_system_CM_start;
      
      word_check_print<double> ("MeV(E.kinetic.total.system.CM)" , CC_E_kinetic_total_system_CM_start);

      CC_E_kinetic_total_system_CM_end = CC_E_kinetic_total_system_CM_start;

      CC_N_energies = 1;
    }
  
  if (CC_reaction == RADIATIVE_CAPTURE)
    {
      cin >> CC_N_theta_gamma;
      
      word_check_print<unsigned int> ("(theta.angles.number)" , CC_N_theta_gamma);

      cin >> CC_N_phi_gamma;

      word_check_print<unsigned int> ("(phi.angles.number)" , CC_N_phi_gamma);
    }

  if ((CC_reaction == SCATTERING) && ((CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION) || (CC_reaction_calculation == EXCITATION_FUNCTION)))
    {
      cin >> CC_N_CM_angles;

      word_check_print<unsigned int> ("angles(degrees)(center.of.mass.frame)" , CC_N_CM_angles);

      get_CC_CM_angles ();
    }
    
  if (CC_reaction_calculation == POLES) CC_N_energies = 1;
  
  cout << endl;
}


void input_data_str::effective_charges_alloc_read ()
{
  //--// check something like "1.5 (proton.effective.charge)"

  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::effective_charges_read");
  
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  effective_charges_p.allocate (Np_baryon_type);
  effective_charges_n.allocate (Nn_baryon_type);
  
  if (are_there_EM_transitions || are_there_EM_transitions_strength || (CC_reaction == RADIATIVE_CAPTURE))
    {
      if (space != NEUT_Y_ONLY)
	{
	  cin >> effective_charges_p(prot_index);
	  
	  word_check_print<double> ("(proton.effective.charge)" , effective_charges_p(prot_index)); 
	}
      
      if (space != PROT_Y_ONLY)
	{
	  cin >> effective_charges_n(neut_index);
	    
	  word_check_print<double> ("(neutron.effective.charge)" , effective_charges_n(neut_index)); 
	}
      
      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
	{
	  const enum particle_type hyperon = hyperon_types(i);
      
	  const unsigned int hyperon_index = charge_baryon_index_determine (hyperon);
  
	  const int Y_charge = particle_charge_determine (hyperon);
	  
	  if (Y_charge != 0) word_check_print<double> ("(" + make_string<enum particle_type> (hyperon) + ".effective.charge)" , effective_charges_p(hyperon_index));
	  if (Y_charge == 0) word_check_print<double> ("(" + make_string<enum particle_type> (hyperon) + ".effective.charge)" , effective_charges_n(hyperon_index));
	}
    }
}




void input_data_str::copy_input_data_CC_Berggren_basis_alloc_read (const class input_data_str &input_data)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data::copy_input_data_CC_Berggren_basis_alloc_read");

  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);
      
  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
      
  class input_data_str &input_data_CC_Berggren = *this;

  const enum space_type basis_space_input_data = input_data.get_basis_space ();

  input_data_CC_Berggren.allocate_fill (input_data);
  
  if (input_data_CC_Berggren.basis_potential == QBOX_POTENTIAL)
    {
      input_data_CC_Berggren.basis_potential = WS_ANALYTIC;

      input_data_CC_Berggren.H_potential = WS_ANALYTIC;
      
      input_data_CC_Berggren.H_basis_core_potential = WS_ANALYTIC;
   
      for (unsigned int i = 0 ; i < Np_baryon_type ; i++) input_data_CC_Berggren.basis_potential_partial_waves_p_tab(i) = WS_ANALYTIC;
      for (unsigned int i = 0 ; i < Nn_baryon_type ; i++) input_data_CC_Berggren.basis_potential_partial_waves_n_tab(i) = WS_ANALYTIC;
    }

  const bool is_it_one_baryon_COSM_case = input_data_CC_Berggren.is_it_one_baryon_COSM_case_CC_determine ();

  if (!is_it_one_baryon_COSM_case && ((basis_potential == HF) || (basis_potential == MSDHF))) error_message_print_abort ("HF/MSDHF potentials cannot be used with clusters or realistic interactions in GSM-CC");
  
  if (is_it_one_baryon_COSM_case)
    {
      const unsigned int prot_index = charge_baryon_index_determine (PROTON);
      const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
      bool are_there_prot_projectiles = false;      
      bool are_there_neut_projectiles = false;
      
      for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
	{      
	  const enum particle_type projectile = CC_projectile_tab(iT);
	  
	  if (projectile == PROTON)  are_there_prot_projectiles = true;
	  if (projectile == NEUTRON) are_there_neut_projectiles = true;
	}      

      if (are_there_prot_projectiles || are_there_neut_projectiles)
	{
	  word_check ("CC.nucleon.Berggren.basis");
	  
	  cout << "CC.nucleon.Berggren.basis" << endl;
	}
      	    
      input_data_CC_Berggren.shells_quantum_numbers_p_tab.deallocate ();
      input_data_CC_Berggren.shells_quantum_numbers_n_tab.deallocate ();
      
      input_data_CC_Berggren.lmax_baryon_p_tab = 0;
      input_data_CC_Berggren.lmax_baryon_n_tab = 0;
      
      input_data_CC_Berggren.lmax_common_baryon_p_tab = 0;
      input_data_CC_Berggren.lmax_common_baryon_n_tab = 0;
      
      input_data_CC_Berggren.Np_nlj_baryon_tab = 0;
      input_data_CC_Berggren.Nn_nlj_baryon_tab = 0;
      
      input_data_CC_Berggren.Np_nlj_res_baryon_tab = 0;
      input_data_CC_Berggren.Nn_nlj_res_baryon_tab = 0;
      
      input_data_CC_Berggren.Np_nljm_baryon_tab = 0;
      input_data_CC_Berggren.Nn_nljm_baryon_tab = 0;
      
      input_data_CC_Berggren.Np_nljm_res_baryon_tab = 0;
      input_data_CC_Berggren.Nn_nljm_res_baryon_tab = 0;
        
      input_data_CC_Berggren.are_there_basis_natural_orbitals_p_tab = false;
      input_data_CC_Berggren.are_there_basis_natural_orbitals_n_tab = false;
        
      input_data_CC_Berggren.shells_quantum_numbers_p_tab.allocate (Np_baryon_type);
      input_data_CC_Berggren.shells_quantum_numbers_n_tab.allocate (Nn_baryon_type);
	  
      if (are_there_prot_projectiles)
	{
	  if (basis_space_input_data == NEUT_Y_ONLY) error_message_print_abort ("One cannot have proton projectiles with only valence neutrons");
      	  
      	  input_data_CC_Berggren.shells_to_consider (PROTON , true);
	  
	  input_data_CC_Berggren.shells_consistency_tests (input_data_CC_Berggren.shells_quantum_numbers_p_tab(prot_index));
	  	  
	  input_data_CC_Berggren.CC_partial_wave_presence_check (PROTON  , input_data.shells_quantum_numbers_p_tab(prot_index) , input_data_CC_Berggren.shells_quantum_numbers_p_tab(prot_index));
	}
      
      if (are_there_neut_projectiles)
	{
	  if (basis_space_input_data == PROT_Y_ONLY) error_message_print_abort ("One cannot have neutron projectiles with only valence protons");
      	        
	  input_data_CC_Berggren.shells_to_consider (NEUTRON , true);

	  input_data_CC_Berggren.shells_consistency_tests (input_data_CC_Berggren.shells_quantum_numbers_n_tab(neut_index));
	  
	  input_data_CC_Berggren.CC_partial_wave_presence_check (NEUTRON , input_data.shells_quantum_numbers_n_tab(neut_index) , input_data_CC_Berggren.shells_quantum_numbers_n_tab(neut_index));
	}

      if (are_there_hyperons)
	{
	  bool are_there_hyperon_projectiles = false;
      
	  for (unsigned int iT = 0 ; iT < CC_N_target_projectile_states ; iT++)
	    {      
	      const enum particle_type projectile = CC_projectile_tab(iT);
	  
	      if (particle_strangeness_determine (projectile) != 0) are_there_hyperon_projectiles = true;
	    }
      
	  if (are_there_hyperon_projectiles)
	    {
	      word_check ("CC.hyperon.Berggren.basis");
	
	      cout << "CC.hyperon.Berggren.basis" << endl;
	      
	      for (unsigned int i = 0 ; i < N_hyperon_types ; i++)
		{
		  const enum particle_type hyperon = input_data_CC_Berggren.hyperon_types(i);
	  	  
		  class array<class nlj_struct> &hyperon_shells_quantum_numbers = input_data_CC_Berggren.shells_quantum_numbers_determine(hyperon);
		  
		  input_data_CC_Berggren.shells_to_consider (hyperon , false);
		  
		  input_data_CC_Berggren.shells_consistency_tests (hyperon_shells_quantum_numbers);
		}
	    }
	}
      
      if (input_data_CC_Berggren.are_there_OCM_valence_states_to_integrate_determine (input_data_CC_Berggren.shells_quantum_numbers_p_tab(prot_index)) ||
	  input_data_CC_Berggren.are_there_OCM_valence_states_to_integrate_determine (input_data_CC_Berggren.shells_quantum_numbers_n_tab(neut_index)))
	{		  
	  const bool is_it_GSM_COSM = is_it_COSM_determine (input_data.inter);
      
	  const bool is_it_GSM_HF_MSDHF_basis = ((input_data.basis_potential == HF) || (input_data.basis_potential == MSDHF));

	  const bool is_it_GSM_OCM_basis = (is_it_GSM_COSM && !is_it_GSM_HF_MSDHF_basis);

	  const bool are_there_GSM_OCM_valence_states_to_integrate = (input_data.are_there_OCM_valence_states_to_integrate_determine (input_data.shells_quantum_numbers_p_tab(prot_index)) ||
								      input_data.are_there_OCM_valence_states_to_integrate_determine (input_data.shells_quantum_numbers_n_tab(neut_index)));
      
	  //--// Parameters for the HF equivalent potential are demanded here as one has none for the GSM basis (HO basis for example).
	  
	  if (!is_it_GSM_HF_MSDHF_basis && (!is_it_GSM_OCM_basis || !are_there_GSM_OCM_valence_states_to_integrate))
	    {
	      cin >> Ueq_regularizor;
	      word_check_print<double> ("(CC.Berggren.basis.equivalent.potential.regularizor)" , Ueq_regularizor);
  
	      cin >> HF_max_iterations_number;
	      word_check_print<unsigned int> ("(HF/MSDHF/OCM.CC.Berggren.basis.iterations.maximal.number)" , HF_max_iterations_number);

	      if (HF_max_iterations_number <= 0) error_message_print_abort ("HF/MSDHF/OCM GSM-CC Berggren basis iterations maximal number must be positive");
	  
	      cin >> HF_precision;
	      word_check_print<double> ("(HF/MSDHF/OCM.CC.Berggren.basis.potential.precision)" , HF_precision);
	  
	      if (HF_precision <= 0) error_message_print_abort ("HF/MSDHF/OCM GSM-CC Berggren basis potential precision must be positive");
	    }
	}
    }
        
  input_data_CC_Berggren.Zval_basis = input_data.Zval_basis;
  input_data_CC_Berggren.Nval_basis = input_data.Nval_basis;

  input_data_CC_Berggren.ZYval = input_data.ZYval;
  input_data_CC_Berggren.NYval = input_data.NYval;
}








void input_data_str::RDM_data_read ()
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in input_data_str::RDM_data_read");
  
  if (called_code != RDM_CODE) error_message_print_abort ("Only RDM code in input_data_str::RDM_data_read");
  
  if (are_there_hyperons) error_message_print_abort ("One cannot consider hypernuclei in the RDM code in input_data_str::RDM_data_read");
    
  string RDM_matrix_constraint_string;

  cin >> RDM_matrix_constraint_string;

  cout << RDM_matrix_constraint_string << endl << endl;

  RDM_matrix_constraint = RDM_matrix_constraint_type_determine (RDM_matrix_constraint_string);
  
  RDM_are_there_J_constraints = bool_determination ("are.there.one.body.J.constraints");
  
  RDM_is_there_CM_correction = bool_determination ("is.there.center.of.mass.correction");
  
  RDM_is_there_isospin_constraint = bool_determination ("is.there.isospin.constraint");
  
  RDM_Gamma_init_from_file = bool_determination ("initial.v2RDM.matrices.from.file");
	  
  cin >> RDM_E_minimization_precision;

  if (RDM_E_minimization_precision <= 0) error_message_print_abort ("energy.minimization.precision must be positive (RDM)");
  
  word_check_print<double> ("MeV(energy.minimization.precision)" , RDM_E_minimization_precision);
  
  cin >> RDM_sigma_init;

  if (RDM_sigma_init <= 0) error_message_print_abort ("initial.sigma must be positive (RDM)");
  
  word_check_print<double> ("(initial.sigma)" , RDM_sigma_init);
    
  cin >> RDM_multiplicative_sigma_step;

  if (RDM_multiplicative_sigma_step <= 1.0) error_message_print_abort ("One must have sigma.multiplicative.step > 1 for the augmented Lagrangian method (RDM)");
    
  word_check_print<double> ("(sigma.multiplicative.step)" , RDM_multiplicative_sigma_step);
  
  cin >> RDM_smallness_factor;

  word_check_print<double> ("(smallness.factor.step)" , RDM_smallness_factor);

  string RDM_eigenstate;
  
  cin >> RDM_eigenstate >> RDM_vector_index;
  
  cout << RDM_eigenstate << " " << RDM_vector_index << endl;
      
  RDM_BP = determine_Binary_Parity (RDM_eigenstate);
  
  RDM_J = determine_J (RDM_eigenstate);
              
  RDM_is_there_E_reference = bool_determination ("is.there.reference.energy");

  if (RDM_is_there_E_reference)
    {
      cin >> RDM_E_reference;
  
      word_check_print<double> ("MeV(reference.energy)" , RDM_E_reference);
    }

  cin >> RDM_Hamiltonian_renormalization_factor;

  word_check_print<double> ("(Hamiltonian.RDM.renormalization.factor)" , RDM_Hamiltonian_renormalization_factor);
  
  const int two_RDM_J = make_int(2.0*RDM_J);    
    
  const int Aval = ZYval + NYval;

  if (abs (Aval)%2 != two_RDM_J%2) error_message_print_abort ("J is integer for A even and half-integer for A odd for J=" + J_string (RDM_J) + " (RDM)");

  cout << endl;
}





void input_data_str::GSM_optimization_are_natural_orbitals_calculated_every_iteration_determine (const class array<class input_data_str> &input_data_tab_for_optimization)
{      
  bool are_there_new_natural_orbitals_in_spaces = false;
	
  for (unsigned int nucleus_index = 0 ; !are_there_new_natural_orbitals_in_spaces && (nucleus_index < N_nuclei_to_consider) ; nucleus_index++)
    {
      const class input_data_str &input_data_for_optimization = input_data_tab_for_optimization(nucleus_index);

      const bool input_data_for_optimization_are_there_new_natural_orbitals_p = input_data_for_optimization.get_are_there_new_natural_orbitals_p ();
      const bool input_data_for_optimization_are_there_new_natural_orbitals_n = input_data_for_optimization.get_are_there_new_natural_orbitals_n ();

      if (input_data_for_optimization_are_there_new_natural_orbitals_p || input_data_for_optimization_are_there_new_natural_orbitals_n) are_there_new_natural_orbitals_in_spaces = true;
    }

  are_natural_orbitals_calculated_every_iteration = (are_there_new_natural_orbitals_in_spaces) ? (bool_determination ("are.natural.orbitals.calculated.every.iteration")) : (false); 
}


