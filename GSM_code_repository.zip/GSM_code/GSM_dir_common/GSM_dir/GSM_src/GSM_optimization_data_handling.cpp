#include "../GSM_include/GSM_include_def_common.h"


using namespace inputs_misc;
using namespace string_routines;


// TYPE is double or complex
// -------------------------



// The GSM optimization code allows to fit a Hamiltonian of the form H = T + U_core + V, where U_core is a WS potential and V is an FHT interaction
// ------------------------------------------------------------------------------------------------------------------------------------------------










// Simple functions related to eigensets of eigenvectors whose energy is fitted in the GSM optimization code
// ---------------------------------------------------------------------------------------------------------
// One loops over the eigensets of eigenvectors whose energy is fitted and/or eigenvectors themselves.
// An eigenset is a set of eigenvectors of same parity and total angular momentum.
//
// parameters_fitted_or_no_weights_check
// -------------------------------------
// One has to fit at least one parameter GSM optimization or put all weights to zero.
//
//
// are_all_weights_zero_fixed_eigenset_determine, are_all_weights_zero_all_eigensets_determine
// -------------------------------------------------------------------------------------------
// Check if all weights are equal to zero. If it is the case, the GSM optimization code is used only to calculate all energies, not to fit them. 
// The first routine checks for one eigenset only, the second one checks for all eigensets.
//
// is_there_reference_state_fixed_eigenset_determine
// -------------------------------------------------
// Check if there is a reference state in the eigenset for the fit of separation energies.
// Indeed, even if its weight is equal to zero, its gradient energy vector must be calculated.
//
// reference_state_energy_determine, reference_state_E_grad_determine
// ------------------------------------------------------------------
// Find the energy and the gradient energy vector in the arrays where all nuclear states data are stored for the fit of separation energies.
// The energy and gradient energy vector are put to zero if binding energies are stored.
//
// N_states_to_fit_calc
// --------------------
// Calculation of the number of eigenvectors states whose energy is fitted considering all nuclei. 
// One sum all the numbers of eigenvectors whose energy is fitted for each fitted nucleus and eigenset.
// If the weight of the considered state is zero, the state is not fitted and hence not considered in this number.
//
// state_indices_calc
// ------------------
// Calculation of the eigenvectors state indices of all fitted nuclei used in the Jacobian matrix. 
// They are increased one by one looping over eigensets and eigenvectors in all fitted nuclei.
// If the weight of the considered state is zero, the state is not fitted and hence not considered in this number.
//
// weights_sum
// -----------
// sum of the weights entering the cost function.
// 
// weights_normalization
// ---------------------
// Normalization of the weights of fitted energies. The weight of all energies is renormalized so that the sum of weights is equal to a fixed number.
// In pratice, this number is either one, so that one has a cost function of the order of one, or the Birge factor, so that the correlation matrix is properly normalized.
//
// eigensets_number_max_determine, eigenset_vectors_number_max_determine
// ---------------------------------------------------------------------
// Calculation of the maximal number of eigensets (first routine) and eigenvectors in an eigenset (second routine) considering all nuclei. 
// They are used in arrays to fix dimensions.




void optimization_data_handling::parameters_fitted_or_no_weights_check (const class input_data_str &input_data , const class array<class input_data_str> &input_data_tab_for_optimization)
{
  if (optimization_data_handling::are_all_weights_zero_all_eigensets_determine (input_data_tab_for_optimization)) return;

  if (input_data.N_parameters_to_fit_calc () == 0) error_message_print_abort ("One must fit at least one parameter if weights are not all equal to zero");
}



bool optimization_data_handling::are_all_weights_zero_fixed_eigenset_determine (
										const class input_data_str &input_data , 
										const unsigned int eigenset_index)
{
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
  
  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);  
      
  const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();
      
  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
    {
      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
      
      const double weight = PSI_qn.get_weight ();
      
      if (weight != 0.0) return false;
    }

  return true;
}

bool optimization_data_handling::are_all_weights_zero_all_eigensets_determine (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_consider = input_data_tab.dimension (0);
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      const class input_data_str &input_data = input_data_tab(nucleus_index);
	
      const unsigned int eigensets_number = input_data.get_eigensets_number ();
            
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const bool are_all_weights_zero_fixed_eigenset = are_all_weights_zero_fixed_eigenset_determine (input_data , eigenset_index);

	  if (!are_all_weights_zero_fixed_eigenset) return false;
	}
    }

  return true;
}

unsigned int optimization_data_handling::N_states_to_fit_calc (const class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_consider = input_data_tab.dimension (0);

  unsigned int N_states_to_fit = 0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();
  
      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	      	      
	      const double weight = PSI_qn.get_weight ();
	      
	      if (weight != 0.0) N_states_to_fit++;
	    }
	}
    }

  return N_states_to_fit;
}

void optimization_data_handling::state_indices_calc (
						     const class array<class input_data_str> &input_data_tab , 
						     class array<unsigned int> &state_indices)
{
  const unsigned int N_nuclei_to_consider = input_data_tab.dimension (0);

  state_indices = N_states_to_fit_calc (input_data_tab);

  unsigned int state_index = 0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();
      
      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	      	      
	      const double weight = PSI_qn.get_weight ();
	      
	      if (weight != 0.0) state_indices(nucleus_index , eigenset_index , i) = state_index++;
	    }
	}
    }
}




double optimization_data_handling::weights_sum_calc (const class array<class input_data_str> &input_data_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  double weight_sum = 0.0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab (); 

      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {			
	      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	      	      
	      weight_sum += PSI_qn.get_weight ();
	    }
	}
    }

  return weight_sum;
}

void optimization_data_handling::weights_normalization (
							const double factor ,
							class array<class input_data_str> &input_data_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();
  
  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab (); 

      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {			
	      class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
	      
	      PSI_qn.initialize (
				 PSI_qn.get_Z () ,
				 PSI_qn.get_N () ,
				 PSI_qn.get_BP () ,
				 PSI_qn.get_S () ,
				 PSI_qn.get_J () ,
				 PSI_qn.get_vector_index () ,
				 PSI_qn.get_E () ,
				 PSI_qn.get_weight ()*factor ,
				 PSI_qn.get_experimental_energy () ,
				 PSI_qn.get_energy_error () ,
				 PSI_qn.get_is_it_optimization_reference_state ());
	    }
	}
    }  
}

unsigned int optimization_data_handling::eigensets_number_max_determine (const class array<class input_data_str> &input_data_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  unsigned int eigensets_number_max = 0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      eigensets_number_max = max (eigensets_number , eigensets_number_max);
    }

  return eigensets_number_max;
}

unsigned int optimization_data_handling::eigenset_vectors_number_max_determine (const class array<class input_data_str> &input_data_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  unsigned int eigenset_vectors_number_max = 0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();
      
      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  eigenset_vectors_number_max = max (eigenset_vectors_number , eigenset_vectors_number_max);
	}
    }

  return eigenset_vectors_number_max;
}


bool optimization_data_handling::is_there_reference_state_fixed_eigenset_determine (
										    const class input_data_str &input_data , 
										    const unsigned int eigenset_index)
{
  const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
  
  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);  
      
  const class array<class correlated_state_str> &PSI_qn_from_file_tab = input_data.get_PSI_qn_from_file_tab ();
      
  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
    {
      const class correlated_state_str &PSI_qn = PSI_qn_from_file_tab(eigenset_index , i);
      
      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();
      
      if (is_it_optimization_reference_state) return true;
    }

  return false;
}



TYPE optimization_data_handling::reference_state_energy_determine (
								   const class array<class input_data_str> &input_data_tab , 
								   const class array<class correlated_state_str> &PSI_qn_tab)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const bool binding_energies_fitted = input_data_zero.get_binding_energies_fitted ();

  if (binding_energies_fitted) return 0.0;
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);

	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();

	      if (is_it_optimization_reference_state)
		{
		  const complex<double> E = PSI_qn.get_E ();
		  
#ifdef TYPEisDOUBLECOMPLEX
		  return E;
#endif
		  
#ifdef TYPEisDOUBLE
		  return real (E);
#endif
		}
	    }
	}
    }

  error_message_print_abort ("No reference state found for separation energies in optimization_data_handling::reference_state_energy_determine");

  return NADA;
}



class vector_class<TYPE> optimization_data_handling::reference_state_E_grad_determine (
										       const unsigned int N_parameters_to_fit ,
										       const class array<class input_data_str> &input_data_tab , 
										       const class array<class correlated_state_str> &PSI_qn_tab , 
										       const class array<class vector_class<TYPE> > &E_grad_all_states)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const bool binding_energies_fitted = input_data_zero.get_binding_energies_fitted ();

  class vector_class<TYPE> E_grad_reference_state(N_parameters_to_fit);

  E_grad_reference_state = 0.0;
  
  if (binding_energies_fitted) return E_grad_reference_state;
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();
      
      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);

	      const bool is_it_optimization_reference_state = PSI_qn.get_is_it_optimization_reference_state ();

	      if (is_it_optimization_reference_state)
		{
		  E_grad_reference_state = E_grad_all_states(nucleus_index , eigenset_index , i);

		  return E_grad_reference_state;
		}
	    }
	}
    }

  error_message_print_abort ("No reference state found for separation energies in optimization_data_handling::reference_state_E_grad_determine");

  return E_grad_reference_state;
}





// Simple routines printing information about fitted parameters or copying data from one array to the other, or calculating the scaled Jacobian matrix
// ---------------------------------------------------------------------------------------------------------------------------------------------------
//
// is_it_one_body_only_determine
// -----------------------------
// true if one fits only the one-body part, false if not. One has fewer configuration and SD data arrays to calculate if one fits only the one-body part.
//
//
// interaction_parameter_str
// -------------------------
// Print of the description of one parameter from its enumeration index
//
// FHT_EFT_parameters_from_input
// -----------------------------
// Copy of the values of interaction parameters to a vector, used with the Jacobian matrix inversion
// 
// FHT_EFT_parameters_information_print
// ------------------------------------
// Print of the number of parameters and states to fit, of the description of all parameters.
// Calculation of the Jacobian (G) and SVD matrix (tG.G) and diagonalization of the SVD matrix.
// Print of all singular values, singular vectors and statistical correlations and errors on parameters
//
// print_all_parameters
// --------------------
// Print of all fitted parameters with their description
//
// copy_common_data_to_input_data_tab
// ----------------------------------
// Call of routines copying data of the initial class of type input_data_str input_data_common, which contain common data to all nuclei, to other classes of type input_data_str, one for each different fitted nucleus.
// MPI distribution of data from the master process to all other nodes.
// Print if MPI data transfer has been done for each nucleus from the master process to all other nodes.
//
// scaled_G_calc
// -------------
// The scaled Jacobian matrix scaled_G is calculated and returned. One has: scaled_G(i,j) = FHT_EFT_parameters_fit_indices(j).G(i,j), with G the Jacobian matrix. 
// Thus, the associated linear system to solve (see delta_FHT_EFT_parameters_fit_indices_scaled_calc) provides with a vector whose components are relative with respect to FHT parameters.
// This linear system is more stable than the initial one as all delta_FHT_EFT_parameter values are of the same order of magnitude.
//
// fit_results_file_init
// ---------------------
// The output file fit_results_file is opened, and set to that scientific precision is 15 digits and booleans are printed as true, false.
//
// FHT_EFT_parameters_fit_indices_fill, delta_FHT_EFT_parameters_original_indices_fill
// -----------------------------------------------------------------------------------
// The vector of fitted parameters only is built here from vector containing all the parameters of the core and FHT interaction, optimized or not and returned.
// One loops over all fitted parameters and one checks if they depend on the orbital quantum number (WS core potential parameters only). 
// If it is the case, one loops over the orbital quantum number to copy parameters to the new vector.
// Otherwise, one just copies the parameter to the new vector.
// It is the same for the vector of differences of fitted parameters issued from the Newton linear system to solve (see delta_FHT_EFT_parameters_fit_indices_scaled_calc).
//
// delta_FHT_EFT_parameters_fit_indices_unscale
// --------------------------------------------
// The Newton linear system to solve (see delta_FHT_EFT_parameters_fit_indices_scaled_calc) provided with a vector whose components are relative with respect to FHT parameters.
// The initial unscaled vector is calculated here. One just has to multiply each of the components of delta_FHT_EFT_parameters_fit_indices_scaled by its associated FHT parameter.
//
// delta_E_vector_deltas_norm_precision_print
// ------------------------------------------
// Print of the infinite norms of the vector of weighted energy differences sqrt (wi) . (Ei - Ei_exp)/Ei_err, with wi the weight, Ei the calculated and Ei_exp the experimental energy, and Ei_err the energy fit error
// and of the vector of parameter differences issued from the Newton method. The squared norm of the vector of energy differences is also printed.
//
// deltas_print
// ------------
// The corrections induced by the Newton method are printed on screen with related information therein.
//
// relative_SVD_precision_calc
// ---------------------------
// If one uses a fixed relative SVD precision, it is returned.
// If one rejects the first rejected_singular_values_number singular values instead, one calculates the relative SVD precision so that they are rejected with it.
// For this, one first calculates singular values ans one takes the relative SVD precision equal to the middle of the last rejected singular values and last accepted singular value.

bool optimization_data_handling::is_it_one_body_only_determine (const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index)
{
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);
  
  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
      
      const bool is_it_prot_grad = ((FHT_EFT_parameter == CORE_D_PROTON)  || (FHT_EFT_parameter == CORE_R0_PROTON)  || (FHT_EFT_parameter == CORE_VO_PROTON)  || (FHT_EFT_parameter == CORE_VSO_PROTON) || (FHT_EFT_parameter == CORE_R_CHARGE));
      const bool is_it_neut_grad = ((FHT_EFT_parameter == CORE_D_NEUTRON) || (FHT_EFT_parameter == CORE_R0_NEUTRON) || (FHT_EFT_parameter == CORE_VO_NEUTRON) || (FHT_EFT_parameter == CORE_VSO_NEUTRON));

      if (!is_it_prot_grad && !is_it_neut_grad) return false;      
    }

  return true;
}
								

string optimization_data_handling::interaction_parameter_str (
							      const int global_lmax ,
							      const enum FHT_EFT_parameter_type FHT_EFT_parameter)
{
  switch (FHT_EFT_parameter)
    {
    case V0_CTR_OT_S1_T1         : return "V0.central.odd.triplet(S=1,T=1)";
    case V0_CTR_ET_S1_T0         : return "V0.central.even.triplet(S=1,T=0)";
    case V0_CTR_OS_S0_T0         : return "V0.central.odd.singlet(S=0,T=0)";
    case V0_CTR_ES_S0_T1         : return "V0.central.even.singlet(S=0,T=1)";
    case V0_SO_OT_S1_T1          : return "V0.spin.orbit.odd.triplet(S=1,T=1)";
    case V0_SO_ET_S1_T0          : return "V0.spin.orbit.even.triplet(S=1,T=0)";
    case V0_T_OT_S1_T1           : return "V0.tensor.odd.triplet(S=1,T=1)";
    case V0_T_ET_S1_T0           : return "V0.tensor.even.triplet(S=1,T=0)";
    case V0_ALS_FHT              : return "V0.antisymmetric.spin.orbit";
    case VS_LO_T0                : return "VS.LO(T=0)";
    case VS_LO_T1                : return "VS.LO(T=1)";
    case VT_SIGMA_PRODUCT_LO_T0  : return "VT.sigma.product.LO(T=0)";
    case VT_SIGMA_PRODUCT_LO_T1  : return "VT.sigma.product.LO(T=1)";
    case V1_Q2_NLO               : return "V1.q.square.NLO";
    case V2_K2_NLO               : return "V2.k.square.NLO";
    case V3_Q2_SIGMA_PRODUCT_NLO : return "V3.q.square.sigma.product.NLO";
    case V4_K2_SIGMA_PRODUCT_NLO : return "V4.k.square.sigma.product.NLO";
    case V5_SIGMA_Q_VECTOR_K_NLO : return "V5.sigma.q.vector.k.NLO";
    case V6_SIGMA_Q_PRODUCT_NLO  : return "V6.sigma.q.product.NLO";
    case V7_SIGMA_K_PRODUCT_NLO  : return "V7.sigma.k.product.NLO";
    case V8_SIGMA_Q_VECTOR_K_NLO : return "V8.sigma.q.vector.k.NLO";
    case V8A_SU3F                : return "V8a.SU3.f";
    case V8S_SU3F                : return "V8s.SU3.f";
    case V10_SU3F                : return "V10.SU3.f";
    case V1_SU3F                 : return "V1.SU3.f";      
    case CORE_R_CHARGE           : return "R.charge";
      
    default: 
      {
	for (int l = 0 ; l <= global_lmax ; l++)
	  {
	    if (FHT_EFT_parameter == CORE_D_PROTON)   return ("proton l=" + make_string<int> (l) + " d");
	    if (FHT_EFT_parameter == CORE_R0_PROTON)  return ("proton l=" + make_string<int> (l) + " R0");
	    if (FHT_EFT_parameter == CORE_VO_PROTON)  return ("proton l=" + make_string<int> (l) + " Vo");
	    if (FHT_EFT_parameter == CORE_VSO_PROTON) return ("proton l=" + make_string<int> (l) + " Vso");

	    if (FHT_EFT_parameter == CORE_D_NEUTRON)   return ("neutron l=" + make_string<int> (l) + " d");
	    if (FHT_EFT_parameter == CORE_R0_NEUTRON)  return ("neutron l=" + make_string<int> (l) + " R0");
	    if (FHT_EFT_parameter == CORE_VO_NEUTRON)  return ("neutron l=" + make_string<int> (l) + " Vo");
	    if (FHT_EFT_parameter == CORE_VSO_NEUTRON) return ("neutron l=" + make_string<int> (l) + " Vso");
	  }

	return "";
      }
    }
}

void optimization_data_handling::FHT_EFT_parameters_from_input (
								const class input_data_str &input_data_common , 
								class vector_class<double> &FHT_EFT_parameters)
{
  const int hypernucleus_strangeness = input_data_common.get_hypernucleus_strangeness ();
  
  const unsigned int Np_baryon_type = N_charged_baryon_type_determine (hypernucleus_strangeness);

  const unsigned int Nn_baryon_type = N_uncharged_baryon_type_determine (hypernucleus_strangeness);
  
  const int global_lmax_p = input_data_common.get_lmax_p ();
  const int global_lmax_n = input_data_common.get_lmax_n ();

  const int global_lmax = max (global_lmax_p , global_lmax_n);

  const unsigned int V0_ctr_ot_index = FHT_EFT_parameter_index_determine (V0_CTR_OT_S1_T1 , NADA , NADA);
  const unsigned int V0_ctr_et_index = FHT_EFT_parameter_index_determine (V0_CTR_ET_S1_T0 , NADA , NADA);
  const unsigned int V0_ctr_os_index = FHT_EFT_parameter_index_determine (V0_CTR_OS_S0_T0 , NADA , NADA);
  const unsigned int V0_ctr_es_index = FHT_EFT_parameter_index_determine (V0_CTR_ES_S0_T1 , NADA , NADA);
  const unsigned int V0_so_ot_index  = FHT_EFT_parameter_index_determine (V0_SO_OT_S1_T1  , NADA , NADA);
  const unsigned int V0_so_et_index  = FHT_EFT_parameter_index_determine (V0_SO_ET_S1_T0  , NADA , NADA);
  const unsigned int V0_t_ot_index   = FHT_EFT_parameter_index_determine (V0_T_OT_S1_T1   , NADA , NADA);
  const unsigned int V0_t_et_index   = FHT_EFT_parameter_index_determine (V0_T_ET_S1_T0   , NADA , NADA);
  const unsigned int V0_ALS_index    = FHT_EFT_parameter_index_determine (V0_ALS_FHT      , NADA , NADA);
  
  const unsigned int VS_const_LO_T0_index          = FHT_EFT_parameter_index_determine (VS_LO_T0                , NADA , NADA);
  const unsigned int VS_const_LO_T1_index          = FHT_EFT_parameter_index_determine (VS_LO_T1                , NADA , NADA);
  const unsigned int VT_sigma_product_LO_T0_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T0  , NADA , NADA);
  const unsigned int VT_sigma_product_LO_T1_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T1  , NADA , NADA);
  const unsigned int V1_q2_NLO_index               = FHT_EFT_parameter_index_determine (V1_Q2_NLO               , NADA , NADA);
  const unsigned int V2_k2_NLO_index               = FHT_EFT_parameter_index_determine (V2_K2_NLO               , NADA , NADA);  
  const unsigned int V3_q2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V3_Q2_SIGMA_PRODUCT_NLO , NADA , NADA);
  const unsigned int V4_k2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V4_K2_SIGMA_PRODUCT_NLO , NADA , NADA);
  const unsigned int V5_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V5_SIGMA_Q_VECTOR_K_NLO , NADA , NADA);  
  const unsigned int V6_sigma_q_product_NLO_index  = FHT_EFT_parameter_index_determine (V6_SIGMA_Q_PRODUCT_NLO  , NADA , NADA);
  const unsigned int V7_sigma_k_product_NLO_index  = FHT_EFT_parameter_index_determine (V7_SIGMA_K_PRODUCT_NLO  , NADA , NADA);
  const unsigned int V8_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V8_SIGMA_Q_VECTOR_K_NLO , NADA , NADA);
  
  const unsigned int V8a_SU3f_index = FHT_EFT_parameter_index_determine (V8A_SU3F , NADA , NADA);
  const unsigned int V8s_SU3f_index = FHT_EFT_parameter_index_determine (V8S_SU3F , NADA , NADA);
  const unsigned int V10_SU3f_index = FHT_EFT_parameter_index_determine (V10_SU3F , NADA , NADA);
  const unsigned int  V1_SU3f_index = FHT_EFT_parameter_index_determine ( V1_SU3F , NADA , NADA);
      
  const unsigned int R_charge_index = FHT_EFT_parameter_index_determine (CORE_R_CHARGE , NADA , NADA);

  const class array<double> &dp_core_potential_tab    = input_data_common.get_dp_core_potential_tab ();
  const class array<double> &R0_p_core_potential_tab  = input_data_common.get_R0_p_core_potential_tab ();
  const class array<double> &Vo_p_core_potential_tab  = input_data_common.get_Vo_p_core_potential_tab ();
  const class array<double> &Vso_p_core_potential_tab = input_data_common.get_Vso_p_core_potential_tab ();

  const class array<double> &dn_core_potential_tab    = input_data_common.get_dn_core_potential_tab ();
  const class array<double> &R0_n_core_potential_tab  = input_data_common.get_R0_n_core_potential_tab ();
  const class array<double> &Vo_n_core_potential_tab  = input_data_common.get_Vo_n_core_potential_tab ();
  const class array<double> &Vso_n_core_potential_tab = input_data_common.get_Vso_n_core_potential_tab ();

  FHT_EFT_parameters = 0.0;

  FHT_EFT_parameters(V0_ctr_ot_index) = input_data_common.get_V0_ctr_ot ();
  FHT_EFT_parameters(V0_ctr_et_index) = input_data_common.get_V0_ctr_et ();
  FHT_EFT_parameters(V0_ctr_os_index) = input_data_common.get_V0_ctr_os ();
  FHT_EFT_parameters(V0_ctr_es_index) = input_data_common.get_V0_ctr_es ();  
  FHT_EFT_parameters(V0_so_ot_index)  = input_data_common.get_V0_so_ot ();
  FHT_EFT_parameters(V0_so_et_index)  = input_data_common.get_V0_so_et ();  
  FHT_EFT_parameters(V0_t_ot_index)   = input_data_common.get_V0_t_ot ();
  FHT_EFT_parameters(V0_t_et_index)   = input_data_common.get_V0_t_et ();
  FHT_EFT_parameters(V0_ALS_index)    = input_data_common.get_V0_ALS ();

  FHT_EFT_parameters(VS_const_LO_T0_index)          = input_data_common.get_VS_const_LO_T0 ();
  FHT_EFT_parameters(VS_const_LO_T1_index)          = input_data_common.get_VS_const_LO_T1 ();
  FHT_EFT_parameters(VT_sigma_product_LO_T0_index)  = input_data_common.get_VT_sigma_product_LO_T0 (); 
  FHT_EFT_parameters(VT_sigma_product_LO_T1_index)  = input_data_common.get_VT_sigma_product_LO_T1 ();   
  FHT_EFT_parameters(V1_q2_NLO_index)               = input_data_common.get_V1_q2_NLO ();
  FHT_EFT_parameters(V2_k2_NLO_index)               = input_data_common.get_V2_k2_NLO ();  
  FHT_EFT_parameters(V3_q2_sigma_product_NLO_index) = input_data_common.get_V3_q2_sigma_product_NLO ();
  FHT_EFT_parameters(V4_k2_sigma_product_NLO_index) = input_data_common.get_V4_k2_sigma_product_NLO ();
  FHT_EFT_parameters(V5_sigma_q_vector_k_NLO_index) = input_data_common.get_V5_sigma_q_vector_k_NLO ();
  FHT_EFT_parameters(V6_sigma_q_product_NLO_index)  = input_data_common.get_V6_sigma_q_product_NLO ();
  FHT_EFT_parameters(V7_sigma_k_product_NLO_index)  = input_data_common.get_V7_sigma_k_product_NLO ();
  FHT_EFT_parameters(V8_sigma_q_vector_k_NLO_index) = input_data_common.get_V8_sigma_q_vector_k_NLO ();
  
  FHT_EFT_parameters(V8a_SU3f_index) = input_data_common.get_V8a_SU3f ();
  FHT_EFT_parameters(V8s_SU3f_index) = input_data_common.get_V8s_SU3f ();
  FHT_EFT_parameters(V10_SU3f_index) = input_data_common.get_V10_SU3f ();
  FHT_EFT_parameters (V1_SU3f_index) = input_data_common.get_V1_SU3f ();
  
  FHT_EFT_parameters(R_charge_index) = input_data_common.get_R_charge ();

  for (unsigned int i = 0 ; i < Np_baryon_type ; i++)
    {      
      const enum particle_type particle = baryon_from_charge_index_determine (true , i);
      
      const enum FHT_EFT_parameter_type core_d_particle   = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , D_WS);
      const enum FHT_EFT_parameter_type core_R0_particle  = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , R0_WS);
      const enum FHT_EFT_parameter_type core_Vo_particle  = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , VO_WS);
      const enum FHT_EFT_parameter_type core_Vso_particle = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , VSO_WS);
      
      for (int l = 0 ; l <= global_lmax_p ; l++)
	{
	  const unsigned int particle_index_from_WS_d   = FHT_EFT_parameter_index_determine (core_d_particle   , global_lmax , l);
	  const unsigned int particle_index_from_WS_R0  = FHT_EFT_parameter_index_determine (core_R0_particle  , global_lmax , l);
	  const unsigned int particle_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (core_Vo_particle  , global_lmax , l);
	  const unsigned int particle_index_from_WS_Vso = FHT_EFT_parameter_index_determine (core_Vso_particle , global_lmax , l);

	  FHT_EFT_parameters(particle_index_from_WS_d)   = dp_core_potential_tab   (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_R0)  = R0_p_core_potential_tab (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_Vo)  = Vo_p_core_potential_tab (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_Vso) = Vso_p_core_potential_tab(i , l);
	}
    }

  for (unsigned int i = 0 ; i < Nn_baryon_type ; i++)
    {      
      const enum particle_type particle = baryon_from_charge_index_determine (false , i);
      
      const enum FHT_EFT_parameter_type core_d_particle   = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , D_WS);
      const enum FHT_EFT_parameter_type core_R0_particle  = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , R0_WS);
      const enum FHT_EFT_parameter_type core_Vo_particle  = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , VO_WS);
      const enum FHT_EFT_parameter_type core_Vso_particle = FHT_EFT_WS_parameter_determine_from_WS_parameter_particle (particle , VSO_WS);
      
      for (int l = 0 ; l <= global_lmax_n ; l++)
	{
	  const unsigned int particle_index_from_WS_d   = FHT_EFT_parameter_index_determine (core_d_particle   , global_lmax , l);
	  const unsigned int particle_index_from_WS_R0  = FHT_EFT_parameter_index_determine (core_R0_particle  , global_lmax , l);
	  const unsigned int particle_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (core_Vo_particle  , global_lmax , l);
	  const unsigned int particle_index_from_WS_Vso = FHT_EFT_parameter_index_determine (core_Vso_particle , global_lmax , l);

	  FHT_EFT_parameters(particle_index_from_WS_d)   = dn_core_potential_tab   (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_R0)  = R0_n_core_potential_tab (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_Vo)  = Vo_n_core_potential_tab (i , l); 
	  FHT_EFT_parameters(particle_index_from_WS_Vso) = Vso_n_core_potential_tab(i , l); 	
	}
    }
}

void optimization_data_handling::FHT_EFT_parameters_information_print (
								       const bool is_it_fixed_relative_SVD_precision ,
								       const double fixed_relative_SVD_precision ,
								       const unsigned int rejected_singular_values_number ,
								       const unsigned int N_states_to_fit , 
								       const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
								       const class array<bool> &is_there_l_dependence_from_fit_index , 
								       const class array<int> &l_from_fit_index ,
								       const class matrix<double> &G , 
								       ofstream &fit_results_file)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

      const unsigned int N_for_statistics = min (N_parameters_to_fit , N_states_to_fit);
      
      fit_results_file << "Number of parameters to fit : " << N_parameters_to_fit << endl;
      fit_results_file << "Number of states to fit : " << N_states_to_fit << endl << endl;

      cout << "Number of parameters to fit : " << N_parameters_to_fit << endl;
      cout << "Number of states to fit : " << N_states_to_fit << endl << endl;

      for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	{
	  const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
	  
	  const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);

	  const int l = l_from_fit_index(fit_index);

	  fit_results_file << "Parameter to fit " << fit_index << " : " << FHT_EFT_parameter;

	  if (is_there_l_dependence)
	    fit_results_file << " , angular momentum dependence : l=" << l << endl;
	  else
	    fit_results_file << endl;

	  cout << "Parameter to fit " << fit_index << " : " << FHT_EFT_parameter;

	  if (is_there_l_dependence)
	    cout << " , angular momentum dependence : l=" << l << endl;
	  else
	    cout << endl;
	}

      if (G.infinite_norm () > 0.0)
	{
	  cout << endl;

	  fit_results_file << endl;

	  cout.precision (6);

	  fit_results_file.precision (6);
	  
	  const class matrix<double> G_transpose = transpose (G);
	  
	  const class matrix<double> SVD_matrix = (N_parameters_to_fit < N_states_to_fit) ? (G_transpose*G) : (G*G_transpose);

	  class matrix<double> SVD_transform = SVD_matrix;

	  class array<double> SVD_values(N_for_statistics);
	  
	  total_diagonalization::symmetric::all_eigenpairs (SVD_transform , SVD_values);
	  
	  for (unsigned int i = 0 ; i < N_for_statistics ; i++) SVD_values(i) = sqrt (abs (SVD_values(i)));
	        
	  for (unsigned int i = 0 ; i < N_for_statistics ; i++)
	    {
	      cout << "i:" << i << " singular value:" << SVD_values(i) << "  singular vector:"<< SVD_transform.eigenvector (i) << endl;
	      
	      fit_results_file << "i:" << i << " singular value:" << SVD_values(i) <<"  singular vector:"<< SVD_transform.eigenvector (i) << endl;	      
	    }
	      
	  class matrix<double> correlation_matrix = SVD_matrix;

	  const double relative_SVD_precision = relative_SVD_precision_calc (is_it_fixed_relative_SVD_precision , fixed_relative_SVD_precision , rejected_singular_values_number , SVD_matrix);
	  
	  pseudo_inverse (correlation_matrix , relative_SVD_precision);
	  
	  cout << endl << "Statistical errors and correlations" << endl << endl;

	  fit_results_file << endl << "Statistical errors and correlations" << endl << endl;

	  for (unsigned int i = 0 ; i < N_for_statistics ; i++)
	    {
	      if (correlation_matrix(i,i) != 0.0)
		{
		  cout << "i:" << i << " " << sqrt (abs (correlation_matrix(i,i))) << "     ";
	      
		  fit_results_file << "i:" << i << " " << sqrt (abs (correlation_matrix(i,i))) << "     ";

		  for (unsigned int j = 0 ; j < i ; j++)
		    {
		      if (correlation_matrix(j,j) != 0.0)
			{
			  cout << "j:" << j << " " << correlation_matrix(i,j)/sqrt (abs (correlation_matrix(i,i)*correlation_matrix(j,j))) << " ";
	
			  fit_results_file << "j:" << j << " " << correlation_matrix(i,j)/sqrt (abs (correlation_matrix(i,i)*correlation_matrix(j,j))) << " ";
			}
		    }
		  
		  cout << endl;

		  fit_results_file << endl;
		} 
	    }
	  
	  cout << endl;
	  
	  fit_results_file << endl;
	  
	  cout.precision (15);

	  fit_results_file.precision (15);
	}
    }		
}

void optimization_data_handling::print_all_parameters (
						       const class input_data_str &input_data_common ,
						       const class vector_class<double> &FHT_EFT_parameters , 
						       ofstream &fit_results_file)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const enum interaction_type inter = input_data_common.get_inter ();
            
      fit_results_file << endl;
      
      cout << endl;

      const enum space_type global_space = input_data_common.get_space ();

      const bool are_there_hyperons = input_data_common.get_are_there_hyperons ();

      const int global_lmax_p = input_data_common.get_lmax_p ();
      const int global_lmax_n = input_data_common.get_lmax_n ();

      const int global_lmax = max (global_lmax_p , global_lmax_n);

      const unsigned int V0_ctr_ot_index = FHT_EFT_parameter_index_determine (V0_CTR_OT_S1_T1 , NADA , NADA);
      const unsigned int V0_ctr_et_index = FHT_EFT_parameter_index_determine (V0_CTR_ET_S1_T0 , NADA , NADA);
      const unsigned int V0_ctr_os_index = FHT_EFT_parameter_index_determine (V0_CTR_OS_S0_T0 , NADA , NADA);
      const unsigned int V0_ctr_es_index = FHT_EFT_parameter_index_determine (V0_CTR_ES_S0_T1 , NADA , NADA);
      const unsigned int V0_so_ot_index  = FHT_EFT_parameter_index_determine (V0_SO_OT_S1_T1  , NADA , NADA);
      const unsigned int V0_so_et_index  = FHT_EFT_parameter_index_determine (V0_SO_ET_S1_T0  , NADA , NADA);
      const unsigned int V0_t_ot_index   = FHT_EFT_parameter_index_determine (V0_T_OT_S1_T1   , NADA , NADA);
      const unsigned int V0_t_et_index   = FHT_EFT_parameter_index_determine (V0_T_ET_S1_T0   , NADA , NADA);
      const unsigned int V0_ALS_index    = FHT_EFT_parameter_index_determine (V0_ALS_FHT      , NADA , NADA);

      const unsigned int VS_const_LO_T0_index          = FHT_EFT_parameter_index_determine (VS_LO_T0                , NADA , NADA);
      const unsigned int VS_const_LO_T1_index          = FHT_EFT_parameter_index_determine (VS_LO_T1                , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T0_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T0  , NADA , NADA);
      const unsigned int VT_sigma_product_LO_T1_index  = FHT_EFT_parameter_index_determine (VT_SIGMA_PRODUCT_LO_T1  , NADA , NADA);
      const unsigned int V1_q2_NLO_index               = FHT_EFT_parameter_index_determine (V1_Q2_NLO               , NADA , NADA);
      const unsigned int V2_k2_NLO_index               = FHT_EFT_parameter_index_determine (V2_K2_NLO               , NADA , NADA);  
      const unsigned int V3_q2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V3_Q2_SIGMA_PRODUCT_NLO , NADA , NADA);
      const unsigned int V4_k2_sigma_product_NLO_index = FHT_EFT_parameter_index_determine (V4_K2_SIGMA_PRODUCT_NLO , NADA , NADA);
      const unsigned int V5_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V5_SIGMA_Q_VECTOR_K_NLO , NADA , NADA);  
      const unsigned int V6_sigma_q_product_NLO_index  = FHT_EFT_parameter_index_determine (V6_SIGMA_Q_PRODUCT_NLO  , NADA , NADA);
      const unsigned int V7_sigma_k_product_NLO_index  = FHT_EFT_parameter_index_determine (V7_SIGMA_K_PRODUCT_NLO  , NADA , NADA);
      const unsigned int V8_sigma_q_vector_k_NLO_index = FHT_EFT_parameter_index_determine (V8_SIGMA_Q_VECTOR_K_NLO , NADA , NADA);
  
      const unsigned int V8a_SU3f_index = FHT_EFT_parameter_index_determine (V8A_SU3F , NADA , NADA);
      const unsigned int V8s_SU3f_index = FHT_EFT_parameter_index_determine (V8S_SU3F , NADA , NADA);
      const unsigned int V10_SU3f_index = FHT_EFT_parameter_index_determine (V10_SU3F , NADA , NADA);
      const unsigned int  V1_SU3f_index = FHT_EFT_parameter_index_determine ( V1_SU3F , NADA , NADA);
  
      const double V0_ctr_ot = FHT_EFT_parameters(V0_ctr_ot_index);
      const double V0_ctr_et = FHT_EFT_parameters(V0_ctr_et_index);
      const double V0_ctr_os = FHT_EFT_parameters(V0_ctr_os_index);
      const double V0_ctr_es = FHT_EFT_parameters(V0_ctr_es_index);
      const double V0_so_ot  = FHT_EFT_parameters(V0_so_ot_index);
      const double V0_so_et  = FHT_EFT_parameters(V0_so_et_index);
      const double V0_t_ot   = FHT_EFT_parameters(V0_t_ot_index);
      const double V0_t_et   = FHT_EFT_parameters(V0_t_et_index);
      const double V0_ALS    = FHT_EFT_parameters(V0_ALS_index);

      const double VS_const_LO_T0          = FHT_EFT_parameters(VS_const_LO_T0_index);
      const double VS_const_LO_T1          = FHT_EFT_parameters(VS_const_LO_T1_index);
      const double VT_sigma_product_LO_T0  = FHT_EFT_parameters(VT_sigma_product_LO_T0_index);  
      const double VT_sigma_product_LO_T1  = FHT_EFT_parameters(VT_sigma_product_LO_T1_index);      
      const double V1_q2_NLO               = FHT_EFT_parameters(V1_q2_NLO_index);
      const double V2_k2_NLO               = FHT_EFT_parameters(V2_k2_NLO_index);
      const double V3_q2_sigma_product_NLO = FHT_EFT_parameters(V3_q2_sigma_product_NLO_index);
      const double V4_k2_sigma_product_NLO = FHT_EFT_parameters(V4_k2_sigma_product_NLO_index);
      const double V5_sigma_q_vector_k_NLO = FHT_EFT_parameters(V5_sigma_q_vector_k_NLO_index);  
      const double V6_sigma_q_product_NLO  = FHT_EFT_parameters(V6_sigma_q_product_NLO_index);
      const double V7_sigma_k_product_NLO  = FHT_EFT_parameters(V7_sigma_k_product_NLO_index);
      const double V8_sigma_q_vector_k_NLO = FHT_EFT_parameters(V8_sigma_q_vector_k_NLO_index);  

      const double V8a_SU3f = FHT_EFT_parameters(V8a_SU3f_index);
      const double V8s_SU3f = FHT_EFT_parameters(V8s_SU3f_index);
      const double V10_SU3f = FHT_EFT_parameters(V10_SU3f_index);
      const double  V1_SU3f = FHT_EFT_parameters (V1_SU3f_index);
  
      if (global_space != NEUT_Y_ONLY)
	{
	  const unsigned int prot_index_from_WS_R_charge = FHT_EFT_parameter_index_determine (CORE_R_CHARGE , NADA , NADA);
		
	  fit_results_file << FHT_EFT_parameters (prot_index_from_WS_R_charge) << " fm(R.charge)"<< endl << endl;	  
	  cout             << FHT_EFT_parameters (prot_index_from_WS_R_charge) << " fm(R.charge)"<< endl << endl;

	  fit_results_file << "proton" << endl;
	  cout             << "proton" << endl;
	  
	  fit_results_file << "l   d(fm)   R0(fm)   Vo(MeV)   Vso(MeV)" << endl;
	  cout             << "l   d(fm)   R0(fm)   Vo(MeV)   Vso(MeV)" << endl;
      
	  for (int l = 0 ; l <= global_lmax_p ; l++)
	    {
	      const unsigned int prot_index_from_WS_d   = FHT_EFT_parameter_index_determine (CORE_D_PROTON   , global_lmax , l);
	      const unsigned int prot_index_from_WS_R0  = FHT_EFT_parameter_index_determine (CORE_R0_PROTON  , global_lmax , l);
	      const unsigned int prot_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (CORE_VO_PROTON  , global_lmax , l);
	      const unsigned int prot_index_from_WS_Vso = FHT_EFT_parameter_index_determine (CORE_VSO_PROTON , global_lmax , l);

	      fit_results_file << l << "   "
			       << FHT_EFT_parameters(prot_index_from_WS_d)  << "   " << FHT_EFT_parameters(prot_index_from_WS_R0) << "   "
			       << FHT_EFT_parameters(prot_index_from_WS_Vo) << "   " << FHT_EFT_parameters(prot_index_from_WS_Vso) << endl;

	      cout << l << "   "
		   << FHT_EFT_parameters(prot_index_from_WS_d)  << "   " << FHT_EFT_parameters(prot_index_from_WS_R0) << "   "
		   << FHT_EFT_parameters(prot_index_from_WS_Vo) << "   " << FHT_EFT_parameters(prot_index_from_WS_Vso) << endl;
	    }

	  fit_results_file << endl;
	  cout             << endl;
     	}
      
      if (global_space != PROT_Y_ONLY)
	{
	  fit_results_file << "neutron" << endl;
	  cout             << "neutron" << endl;
	  
	  fit_results_file << "l   d(fm)   R0(fm)   Vo(MeV)   Vso(MeV)" << endl;
      	  cout             << "l   d(fm)   R0(fm)   Vo(MeV)   Vso(MeV)" << endl;
      
	  for (int l = 0 ; l <= global_lmax_n ; l++)
	    {
	      const unsigned int neut_index_from_WS_d   = FHT_EFT_parameter_index_determine (CORE_D_NEUTRON   , global_lmax , l);
	      const unsigned int neut_index_from_WS_R0  = FHT_EFT_parameter_index_determine (CORE_R0_NEUTRON  , global_lmax , l);
	      const unsigned int neut_index_from_WS_Vo  = FHT_EFT_parameter_index_determine (CORE_VO_NEUTRON  , global_lmax , l);
	      const unsigned int neut_index_from_WS_Vso = FHT_EFT_parameter_index_determine (CORE_VSO_NEUTRON , global_lmax , l);

	      fit_results_file << l << "   "
			       << FHT_EFT_parameters(neut_index_from_WS_d)  << "   " << FHT_EFT_parameters(neut_index_from_WS_R0) << "   "
			       << FHT_EFT_parameters(neut_index_from_WS_Vo) << "   " << FHT_EFT_parameters(neut_index_from_WS_Vso) << endl;

	      cout << l << "   "
		   << FHT_EFT_parameters(neut_index_from_WS_d)  << "   " << FHT_EFT_parameters(neut_index_from_WS_R0) << "   "
		   << FHT_EFT_parameters(neut_index_from_WS_Vo) << "   " << FHT_EFT_parameters(neut_index_from_WS_Vso) << endl;
	    }
	}
      
      fit_results_file << endl << endl;      
      cout             << endl << endl;

      if (is_it_FHT_determine (inter))
	{
	  fit_results_file << V0_ctr_ot << " (" << V0_CTR_OT_S1_T1 << ")" << endl;

	  if (global_space == PROT_NEUT_Y) fit_results_file << V0_ctr_et << " (" << V0_CTR_ET_S1_T0 << ")" << endl;
	  if (global_space == PROT_NEUT_Y) fit_results_file << V0_ctr_os << " (" << V0_CTR_OS_S0_T0 << ")" << endl;

	  fit_results_file << V0_ctr_es << " (" << V0_CTR_ES_S0_T1 << ")" << endl;

	  fit_results_file << V0_so_ot << " (" << V0_SO_OT_S1_T1 << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) fit_results_file << V0_so_et << " (" << V0_SO_ET_S1_T0 << ")" << endl;

	  fit_results_file << V0_t_ot << " (" << V0_T_OT_S1_T1 << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) fit_results_file << V0_t_et << " (" << V0_T_ET_S1_T0 << ")" << endl;

	  if (are_there_hyperons) fit_results_file << V0_ALS << " (" << V0_ALS_FHT << ")" << endl;
	  
	  cout << V0_ctr_ot << " (" << V0_CTR_OT_S1_T1 << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) cout << V0_ctr_et << " (" << V0_CTR_ET_S1_T0 << ")" << endl;
	  if (global_space == PROT_NEUT_Y) cout << V0_ctr_os << " (" << V0_CTR_OS_S0_T0 << ")" << endl;

	  cout << V0_ctr_es << " (" << V0_CTR_ES_S0_T1 << ")" << endl;

	  cout << V0_so_ot << " (" << V0_SO_OT_S1_T1 << ")" << endl;

	  if (global_space == PROT_NEUT_Y) cout << V0_so_et << " (" << V0_SO_ET_S1_T0 << ")" << endl;

	  cout << V0_t_ot << " (" << V0_T_OT_S1_T1 << ")" << endl;

	  if (global_space == PROT_NEUT_Y) cout << V0_t_et << " (" << V0_T_ET_S1_T0 << ")" << endl;

	  if (are_there_hyperons) cout << V0_ALS << " (" << V0_ALS_FHT << ")" << endl;
	}

      if (is_it_EFT_determine (inter))
	{
	  if (global_space == PROT_NEUT_Y) fit_results_file << VS_const_LO_T0 << " (" << VS_LO_T0 << ")" << endl;
	  
	  fit_results_file << VS_const_LO_T1 << " (" << VS_LO_T1 << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) fit_results_file << VT_sigma_product_LO_T0 << " (" << VT_SIGMA_PRODUCT_LO_T0 << ")" << endl;
	  
	  fit_results_file << VT_sigma_product_LO_T1 << " (" << VT_SIGMA_PRODUCT_LO_T1 << ")" << endl;
	  
	  fit_results_file << V1_q2_NLO << " (" << V1_Q2_NLO << ")" << endl;
	  fit_results_file << V2_k2_NLO << " (" << V2_K2_NLO << ")" << endl;
	  
	  fit_results_file << V3_q2_sigma_product_NLO << " (" << V3_Q2_SIGMA_PRODUCT_NLO << ")" << endl;
	  fit_results_file << V4_k2_sigma_product_NLO << " (" << V4_K2_SIGMA_PRODUCT_NLO << ")" << endl;
	  
	  fit_results_file << V5_sigma_q_vector_k_NLO << " (" << V5_SIGMA_Q_VECTOR_K_NLO << ")" << endl;
	 	  
	  fit_results_file << V6_sigma_q_product_NLO << " (" << V6_SIGMA_Q_PRODUCT_NLO << ")" << endl;
	  fit_results_file << V7_sigma_k_product_NLO << " (" << V7_SIGMA_K_PRODUCT_NLO << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) cout << VS_const_LO_T0 << " (" << VS_LO_T0 << ")" << endl;
	  
	  if (are_there_hyperons) fit_results_file << V8_sigma_q_vector_k_NLO << " (" << V8_SIGMA_Q_VECTOR_K_NLO << ")" << endl;
	  
	  cout << VS_const_LO_T1 << " (" << VS_LO_T1 << ")" << endl;
	  
	  if (global_space == PROT_NEUT_Y) cout << VT_sigma_product_LO_T0 << " (" << VT_SIGMA_PRODUCT_LO_T0 << ")" << endl;
	  
	  cout << VT_sigma_product_LO_T1 << " (" << VT_SIGMA_PRODUCT_LO_T1 << ")" << endl;
	  
	  cout << V1_q2_NLO << " (" << V1_Q2_NLO << ")" << endl;
	  cout << V2_k2_NLO << " (" << V2_K2_NLO << ")" << endl;
	  
	  cout << V3_q2_sigma_product_NLO << " (" << V3_Q2_SIGMA_PRODUCT_NLO << ")" << endl;
	  cout << V4_k2_sigma_product_NLO << " (" << V4_K2_SIGMA_PRODUCT_NLO << ")" << endl;
	  
	  cout << V5_sigma_q_vector_k_NLO << " (" << V5_SIGMA_Q_VECTOR_K_NLO << ")" << endl;
	 	  
	  cout << V6_sigma_q_product_NLO << " (" << V6_SIGMA_Q_PRODUCT_NLO << ")" << endl;
	  cout << V7_sigma_k_product_NLO << " (" << V7_SIGMA_K_PRODUCT_NLO << ")" << endl;
	  
	  if (are_there_hyperons) cout << V8_sigma_q_vector_k_NLO << " (" << V8_SIGMA_Q_VECTOR_K_NLO << ")" << endl;
	}
      
      if (are_there_hyperons)
	{	  
	  fit_results_file << V8a_SU3f << " (" << V8A_SU3F << ")" << endl;
	  fit_results_file << V8s_SU3f << " (" << V8S_SU3F << ")" << endl;
	  fit_results_file << V10_SU3f << " (" << V10_SU3F << ")" << endl;
	  fit_results_file <<  V1_SU3f << " (" <<  V1_SU3F << ")" << endl;
	  
	  cout << V8a_SU3f << " (" << V8A_SU3F << ")" << endl;
	  cout << V8s_SU3f << " (" << V8S_SU3F << ")" << endl;
	  cout << V10_SU3f << " (" << V10_SU3F << ")" << endl;
	  cout <<  V1_SU3f << " (" <<  V1_SU3F << ")" << endl;
	}
	  
      fit_results_file << endl;
      cout             << endl;
    }
}

void optimization_data_handling::copy_common_data_to_input_data_tab (
								     const class input_data_str &input_data_common , 
								     class array<class input_data_str> &input_data_tab)
{
  const unsigned int N_nuclei_to_consider = input_data_common.get_N_nuclei_to_consider ();
  
  if (THIS_PROCESS == MASTER_PROCESS)
    { 
      for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
	{
	  class input_data_str &input_data = input_data_tab(nucleus_index);

	  input_data.optimization_common_data_alloc_copy (input_data_common);
	}
    }
  
#ifdef UseMPI

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      class input_data_str &input_data = input_data_tab(nucleus_index);

      if (THIS_PROCESS == MASTER_PROCESS) 
	{
	  const unsigned int ip1 = nucleus_index + 1;

	  const unsigned int ip1_unit = ip1%10;

	  const unsigned int ip1_ten_unit =  ip1%100;

	  switch (ip1_unit)
	    {
	    case 1: (ip1_ten_unit == 11) ? (cout << "input_data transfer for " << ip1 << "th nucleus" << endl) : (cout << "input_data transfer for " << ip1 << "st nucleus" << endl); break;
	    case 2: (ip1_ten_unit == 12) ? (cout << "input_data transfer for " << ip1 << "th nucleus" << endl) : (cout << "input_data transfer for " << ip1 << "nd nucleus" << endl); break;
	    case 3: (ip1_ten_unit == 13) ? (cout << "input_data transfer for " << ip1 << "th nucleus" << endl) : (cout << "input_data transfer for " << ip1 << "rd nucleus" << endl); break;

	    default: cout << "input_data transfer for " << ip1 << "th nucleus" << endl; break;	      
	    }
	} 

      input_data.MPI_Bcast_constants_alloc_tables ();
    }

#endif
}

class matrix<double> optimization_data_handling::scaled_G_calc (
								const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
								const class matrix<double> &G)
{
  const unsigned int N_states_to_fit = G.get_dimension_row ();

  const unsigned int N_parameters_to_fit = G.get_dimension_column ();

  class matrix<double> scaled_G = G;
  
  for(unsigned int j = 0 ; j < N_parameters_to_fit ; j++) 
    {
      const double FHT_EFT_parameter = FHT_EFT_parameters_fit_indices(j);

      if (FHT_EFT_parameter != 0.0) 
	{
	  for(unsigned int i = 0 ; i < N_states_to_fit ; i++) scaled_G(i , j) *= FHT_EFT_parameter;
	}
    }

  return scaled_G;
}

void optimization_data_handling::fit_results_file_init (ofstream &fit_results_file)
{
  if (THIS_PROCESS == MASTER_PROCESS) 
    {
      fit_results_file.open ("GSM_optimization_results.dat");
      
      fit_results_file.precision (15);

      fit_results_file << boolalpha;
    }
}

class vector_class<double> optimization_data_handling::FHT_EFT_parameters_fit_indices_fill (
											    const int global_lmax , 
											    const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
											    const class array<bool> &is_there_l_dependence_from_fit_index , 
											    const class array<int> &l_from_fit_index , 
											    const class vector_class<double> &FHT_EFT_parameters)
{
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  class vector_class<double> FHT_EFT_parameters_fit_indices(N_parameters_to_fit);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
      
      const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);

      if (is_there_l_dependence || (FHT_EFT_parameter == CORE_R_CHARGE))
	{
	  const int l = l_from_fit_index(fit_index);
	  
	  const unsigned int FHT_EFT_parameter_index = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , global_lmax , l);

	  FHT_EFT_parameters_fit_indices(fit_index) = FHT_EFT_parameters(FHT_EFT_parameter_index);
	}
      else
	{
	  const int lmin = ((FHT_EFT_parameter == CORE_VSO_PROTON) || (FHT_EFT_parameter == CORE_VSO_NEUTRON)) ? (1) : (0);

	  for (int l = lmin ; l <= global_lmax ; l++)
	    {
	      const unsigned int FHT_EFT_parameter_index = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , global_lmax , l);

	      FHT_EFT_parameters_fit_indices(fit_index) = FHT_EFT_parameters(FHT_EFT_parameter_index);
	    }
	}
    }

  return FHT_EFT_parameters_fit_indices;
}

class vector_class<double> optimization_data_handling::delta_FHT_EFT_parameters_original_indices_fill (
												       const unsigned int N_parameters , 
												       const int global_lmax , 
												       const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
												       const class array<bool> &is_there_l_dependence_from_fit_index , 
												       const class array<int> &l_from_fit_index , 
												       const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices)
{	
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  class vector_class<double> delta_FHT_EFT_parameters(N_parameters);

  delta_FHT_EFT_parameters = 0.0;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
      
      const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);

      const double delta_FHT_EFT_parameter = delta_FHT_EFT_parameters_fit_indices(fit_index);
 
      if (is_there_l_dependence || (FHT_EFT_parameter == CORE_R_CHARGE))
	{
	  const int l = l_from_fit_index(fit_index);

	  const unsigned int FHT_EFT_parameter_index = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , global_lmax , l);
      
	  delta_FHT_EFT_parameters(FHT_EFT_parameter_index) = delta_FHT_EFT_parameter;
	}
      else
	{	
	  const int lmin = ((FHT_EFT_parameter == CORE_VSO_PROTON) || (FHT_EFT_parameter == CORE_VSO_NEUTRON)) ? (1) : (0);

	  for (int l = lmin ; l <= global_lmax ; l++)
	    {
	      const unsigned int FHT_EFT_parameter_index = FHT_EFT_parameter_index_determine (FHT_EFT_parameter , global_lmax , l);

	      delta_FHT_EFT_parameters(FHT_EFT_parameter_index) = delta_FHT_EFT_parameter;
	    }
	}
    }
  
  return delta_FHT_EFT_parameters;
}

class vector_class<double> optimization_data_handling::delta_FHT_EFT_parameters_fit_indices_unscale (
												     const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
												     const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices_scaled)
{
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_fit_indices.get_dimension ();

  class vector_class<double> delta_FHT_EFT_parameters_fit_indices = delta_FHT_EFT_parameters_fit_indices_scaled;

  for(unsigned int j = 0; j < N_parameters_to_fit ; j++) 
    {
      const double FHT_EFT_parameter = FHT_EFT_parameters_fit_indices(j);

      if (FHT_EFT_parameter != 0.0) delta_FHT_EFT_parameters_fit_indices(j) *= FHT_EFT_parameter;
    }

  return delta_FHT_EFT_parameters_fit_indices;
}

void optimization_data_handling::delta_E_vector_deltas_norm_precision_print (
									     const class vector_class<double> &delta_E_vector , 
									     const class vector_class<double> &delta_FHT_EFT_parameters , 
									     const class vector_class<double> &delta_FHT_EFT_parameters_scaled , 
									     ofstream &fit_results_file)	
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in optimization_data_handling::delta_E_vector_deltas_norm_precision_print");

  const double delta_E_vector_norm = delta_E_vector*delta_E_vector;

  fit_results_file << endl << "----------------------------------------------------------" << endl;

  fit_results_file << "||delta.E.vector||oo : " << delta_E_vector.infinite_norm () << endl;

  fit_results_file << "||delta.E.vector|| : " << delta_E_vector_norm << endl;

  fit_results_file << "||delta.parameters||oo : " << delta_FHT_EFT_parameters.infinite_norm () << endl;

  fit_results_file << "||delta.parameters.scaled||oo : " << delta_FHT_EFT_parameters_scaled.infinite_norm () << endl;

  fit_results_file << "----------------------------------------------------------" << endl;

  fit_results_file << endl;
  
  cout << endl << "------------------------------------------------------------------------" << endl;

  cout << "||delta.E.vector||oo : " << delta_E_vector.infinite_norm () << endl;

  cout << "||delta.E.vector|| : " << delta_E_vector_norm << endl;

  cout << "||delta.parameters||oo : " << delta_FHT_EFT_parameters.infinite_norm () << endl;

  cout << "||delta.parameters.scaled||oo : " << delta_FHT_EFT_parameters_scaled.infinite_norm () << endl;      

  cout << "------------------------------------------------------------------------" << endl;

  cout << endl;
}

void optimization_data_handling::deltas_print (
					       const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					       const class array<bool> &is_there_l_dependence_from_fit_index , 
					       const class array<int> &l_from_fit_index , 
					       const class vector_class<double> &delta_FHT_EFT_parameters_fit_indices , 
					       ofstream &fit_results_file)	
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in optimization_data_handling::deltas_print");

  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
      
      const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);

      const double delta_FHT_EFT_parameter = delta_FHT_EFT_parameters_fit_indices(fit_index);

      if (is_there_l_dependence)
	{
	  const int l = l_from_fit_index(fit_index);

	  fit_results_file << FHT_EFT_parameter << " l=" << l << " delta : " << delta_FHT_EFT_parameter << endl;
	  
	  cout << FHT_EFT_parameter << " l=" << l << " delta : " << delta_FHT_EFT_parameter << endl;
	}
      else
	{	
	  fit_results_file << FHT_EFT_parameter << " delta : " << delta_FHT_EFT_parameter << endl;

	  cout << FHT_EFT_parameter << " delta : " << delta_FHT_EFT_parameter << endl;
	}
    }
}


double optimization_data_handling::relative_SVD_precision_calc (
								const bool is_it_fixed_relative_SVD_precision ,
								const double fixed_relative_SVD_precision ,
								const unsigned int rejected_singular_values_number ,
								const class matrix<double> &SVD_matrix)
{
  if (is_it_fixed_relative_SVD_precision) return fixed_relative_SVD_precision;
  
  if (rejected_singular_values_number == 0) return 0.0;

  const unsigned int N = SVD_matrix.get_dimension ();

  if (N <= rejected_singular_values_number) error_message_print_abort ("rejected_singular_values_number must be strictly smaller than the number of singular values in optimization_data_handling::relative_SVD_precision_calc");
  
  class matrix<double> SVD_work_matrix = SVD_matrix;

  class array<double> SVD_values(N);
    
  total_diagonalization::symmetric::all_eigenvalues_Householder (SVD_work_matrix , SVD_values);

  const double max_SVD_value = abs (SVD_values(N - 1));
  
  const double relative_SVD_precision = 0.5*(abs (SVD_values(rejected_singular_values_number - 1)) + abs (SVD_values(rejected_singular_values_number)))/max_SVD_value;
  
  return relative_SVD_precision;
}






// Calculation of the unit interactions defining the FHT interaction in the GSM optimization code
// ----------------------------------------------------------------------------------------------
// In the GSM optimization code, one writes the full interaction as V = \sum_i a_i V_i, where a_i are the parameters to fit and V_i are unit interactions, of central, spin-orbit, tensor type.
// Hence, one recalculates the refitted interaction from the parameters a_i and unit interactions V_i, which is much faster than to recalculate the interaction matrix elements from the beginning.
// The V_i unit interactions are calculated here.

void optimization_data_handling::unit_interactions_alloc_calc (
							       const class input_data_str &input_data_common ,
							       class array<class interaction_class> &inter_data_units)
{
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

  const enum space_type global_space = input_data_common.get_space ();

  const int global_lmax_p = input_data_common.get_lmax_p ();
  const int global_lmax_n = input_data_common.get_lmax_n ();

  const int global_lmax = max (global_lmax_p , global_lmax_n);
    
  const int Jn_relative_max = input_data_common.get_Jn_relative_max ();
    
  const unsigned int dimension_inter_data_units = inter_data_units.dimension (0);
 
  const enum interaction_type inter = input_data_common.get_inter ();
	
  const bool are_there_hyperons = input_data_common.get_are_there_hyperons ();
  
  const bool is_it_FHT = is_it_FHT_determine (inter);
  const bool is_it_EFT = is_it_EFT_determine (inter);

  for (unsigned int s = 0 ; s < dimension_inter_data_units ; s++) 
    {
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameter_determine_from_index(s , NADA);

      const bool is_it_FHT_EFT_parameter_ALS_SU3f = is_it_FHT_EFT_parameter_ALS_SU3f_determine (FHT_EFT_parameter);

      if (are_there_hyperons || !is_it_FHT_EFT_parameter_ALS_SU3f)
	{
	  const bool is_it_FHT_parameter_to_consider = (is_it_FHT && is_it_FHT_parameter_determine (FHT_EFT_parameter));
	  const bool is_it_EFT_parameter_to_consider = (is_it_EFT && is_it_EFT_parameter_determine (FHT_EFT_parameter));

	  if (is_it_FHT_parameter_to_consider || is_it_EFT_parameter_to_consider)
	    {
	      const bool is_it_FHT_EFT_parameter_pp_nn = is_it_FHT_EFT_parameter_pp_nn_determine (FHT_EFT_parameter);

	      if ((global_space == PROT_NEUT_Y) || is_it_FHT_EFT_parameter_pp_nn)
		{
		  class interaction_class &inter_data_unit = inter_data_units(s);
	  
		  inter_data_unit.allocate (false , false , false , input_data_common);

		  inter_data_unit.calculate_unit (Jn_relative_max , FHT_EFT_parameter);

		  const string interaction_parameter_s = interaction_parameter_str (global_lmax , FHT_EFT_parameter);

		  if (THIS_PROCESS == MASTER_PROCESS) cout << "Unit interaction for parameter " << interaction_parameter_s << " calculated" << endl;
		}
	    }
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}





// Calculation of the solution of the linear system entering the Newton method with the Moore-Penrose pseudo-inverse
// -----------------------------------------------------------------------------------------------------------------
// The initial linear system entering the Newton method to solve is G . delta_FHT_EFT_parameters = delta_E_vector, 
// with G the Jacobian matrix and delta_E_vector the vector of weighted energy differences sqrt (wi) . (Ei - Ei_exp)/Ei_err, with wi the weight, Ei the calculated and Ei_exp the experimental energy, and Ei_err the energy fit error
// The G matrix is firstly replaced by a scaled G matrix for stability (see above).
//
// However, as the number of parameters and the number of fitted energies is usually different, one cannot directly solve the initial linear system. 
// It is replaced by equivalent linear systems.
//
//
// Overdetermined case (number of parameters larger than number of fitted energies)
// ---------------------------------------------------------------------------------
// One looks for the vector solution of the initial linear system of minimal norm.
// It is: delta_FHT_EFT_parameters_fit_indices_scaled = transpose (scaled_G) . S, with S the solution of the linear system: (scaled_G . transpose (scaled_G)) . S = delta_E_vector.
//
// Underdetermined case (number of fitted energies larger than number of parameters)
// ---------------------------------------------------------------------------------
// One looks for the vector which is as close as possible to the solution of the initial linear system for the scalar product norm.
// It is the solution of the linear system: (transpose (scaled_G) . scaled_G) . delta_FHT_EFT_parameters_fit_indices_scaled = transpose (scaled_G) . delta_E_vector.
// One also uses the method of the underdetermined case if the number of fitted energies and the number of parameters are equal.
//
//
// There is an additional problem to solve. The matrices scaled_G . transpose (scaled_G) and transpose (scaled_G) . scaled_G can have a very small determinant.
// This comes from a large correlation between parameters. In this case, the Newton method will be unstable.
// Thus, one solves the previous linear systems with the Moore-Penrose pseudo-inverse method, based on singular value decomposition (SVD) (see matrices_add.hpp).
// Indeed, the singular values of the scaled_G matrix are the square roots of the eigenvalues of scaled_G . transpose (scaled_G) or transpose (scaled_G) . scaled_G.
// One diagonalizes the matrix of the linear system to solve (it is real symmetric).
// Its smallest eigenvalues are responsible for the instability of the Newton method.
// They are suppressed if they are smaller in modulus than fixed_relative_SVD_precision.
// The linear system is then solved approximately from the diagonal representation of the matrix inverse by replacing its largest eigenvalues by zero.
// This makes the method stable, but at the price of slightly changing the optimum solution of the optimization problem.
 
class vector_class<double> optimization_data_handling::delta_FHT_EFT_parameters_fit_indices_scaled_calc (
													 const bool is_it_fixed_relative_SVD_precision ,
													 const double fixed_relative_SVD_precision ,
													 const unsigned int rejected_singular_values_number ,
													 const class vector_class<double> &FHT_EFT_parameters_fit_indices , 
													 const class vector_class<double> &delta_E_vector , 
													 const class matrix<double> &G)
{
  const unsigned int N_states_to_fit = G.get_dimension_row ();

  const unsigned int N_parameters_to_fit = G.get_dimension_column ();

  const class matrix<double> scaled_G = scaled_G_calc (FHT_EFT_parameters_fit_indices , G);

  const class matrix<double> scaled_tG = transpose (scaled_G);

  if (N_states_to_fit < N_parameters_to_fit)
    {
      class matrix<double> scaled_G_tG = scaled_G*scaled_tG;
	
      scaled_G_tG.symmetrize ();

      const double relative_SVD_precision = relative_SVD_precision_calc (is_it_fixed_relative_SVD_precision , fixed_relative_SVD_precision , rejected_singular_values_number , scaled_G_tG);
      
      class vector_class<double> scaled_G_tG_inv_delta_E_vector(N_states_to_fit);
      
      linear_system_SVD_solution_calc (scaled_G_tG , delta_E_vector , relative_SVD_precision , scaled_G_tG_inv_delta_E_vector);
      
      const class vector_class<double> delta_FHT_EFT_parameters_fit_indices_scaled = scaled_tG*scaled_G_tG_inv_delta_E_vector;

      return delta_FHT_EFT_parameters_fit_indices_scaled;
    }
  else
    {	
      const class vector_class<double> scaled_tG_delta_E_vector = scaled_tG*delta_E_vector;
      
      class matrix<double> scaled_tG_G = scaled_tG*scaled_G;
      
      scaled_tG_G.symmetrize ();
      
      const double relative_SVD_precision = relative_SVD_precision_calc (is_it_fixed_relative_SVD_precision , fixed_relative_SVD_precision , rejected_singular_values_number , scaled_tG_G);
            
      class vector_class<double> delta_FHT_EFT_parameters_fit_indices_scaled(N_parameters_to_fit);
            
      linear_system_SVD_solution_calc (scaled_tG_G , scaled_tG_delta_E_vector , relative_SVD_precision , delta_FHT_EFT_parameters_fit_indices_scaled);

      return delta_FHT_EFT_parameters_fit_indices_scaled;
    }
}











// Calculation and print of the Jacobian matrix, vector of weighted energy differences, of the chi^2 cost function, of its gradient, of the Hessian matrix, exact and with linear regression approximation
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One loop over all eigenvectors of all fitted nuclei.
//
// matrix_vector_calc_from_energies_gradients
// ------------------------------------------
// One calculates the associated Jacobian matrix row vectors.
// They are the gradient vectors sqrt (wi)/Ei_err . d(Ei - Ei_exp)/dx, with x a parameter to fit, and the associated weighted energy differences sqrt (wi) . (Ei - Ei_exp)/Ei_err,
// with wi the weight, Ei the calculated energy, Ei_exp the experimental energy and Ei_err the energy fit error.
// They form the Jacobian matrix and vector of weighted energy differences sqrt (wi) . (Ei - Ei_exp)/Ei_err used in the Newton method.
// They are printed on screen.
//
// cost_function_calc_from_energies_gradients
// ------------------------------------------
// The chi^2 cost function is \sum_i wi (Ei - Ei_exp)^2/Ei_err^2 is calculated and returned and its parts for each i nucleus printed.
//
// cost_function_grad_calc_from_energies_gradients
// ------------------------------------------------
// The chi^2 cost function gradient equal to \sum_i 2 wi (Ei - Ei_exp)/Ei_err^2 . d(Ei - Ei_exp)/dx is calculated and stored and its parts for each i nucleus printed.
//
// cost_function_Hessian_matrix_element_calc, cost_function_Hessian_matrix_element_linear_regression_calc
// ------------------------------------------------------------------------------------------------------
// Calculation of a matrix element, exact or with linear regression approximation of the Hessian matrix.
// The Hessian matrix of the cost function is d (chi^2)/(dx dy), with x,y parameters to fit.
// The exact matrix element is equal to \sum_i 2 wi/Ei_err^2 (d(Ei - Ei_exp)/dx) . (d(Ei - Ei_exp)/dy) + \sum_i 2 wi (Ei - Ei_exp)/Ei_err^2  (d^2(Ei - Ei_exp)/(dx dy))
// One neglects the second term in the linear regression approximation of the Hessian matrix.
//
// cost_function_Hessian_matrix_calc_print_from_all_states
// -------------------------------------------------------
// The Hessian matrix of the cost function is printed taking into account all fitted states.
// Both exact and linear regression approximation of the Hessian matrix are printed on screen.

void optimization_data_handling::matrix_vector_calc_from_energies_gradients (
									     const class array<class input_data_str> &input_data_tab , 
									     const class array<unsigned int> &state_indices , 
									     const class array<class correlated_state_str> &PSI_qn_tab , 
									     const class array<class vector_class<TYPE> > &E_grad_all_states , 
									     ofstream &fit_results_file , 
									     class vector_class<double> &delta_E_vector , 
									     class matrix<double> &G)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  delta_E_vector = 0.0;

  G = 0.0;	

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const unsigned int BP = PSI_qn.get_BP ();
	      
	      const double J = PSI_qn.get_J ();

	      const complex<double> E = PSI_qn.get_E ();

	      const double weight = PSI_qn.get_weight ();

	      const double experimental_energy = PSI_qn.get_experimental_energy ();

	      const double energy_error = PSI_qn.get_energy_error ();
	      
	      const double energy = real (E);

	      const double energy_difference = energy - experimental_energy;
	      
	      const unsigned int state_index = state_indices(nucleus_index , eigenset_index , i);
	      
	      if (weight != 0.0)
		{
		  const double delta_E_vector_component = sqrt (weight) * energy_difference/energy_error;
	      
		  const class vector_class<TYPE> &E_grad = E_grad_all_states(nucleus_index , eigenset_index , i);
		  
#ifdef TYPEisDOUBLECOMPLEX
		  const class vector_class<double> delta_E_vector_component_grad = real<double ,  complex<double> > (E_grad)*sqrt (weight)/energy_error;
#endif
		  
#ifdef TYPEisDOUBLE
		  const class vector_class<double> delta_E_vector_component_grad = E_grad*sqrt (weight)/energy_error;
#endif
		  
		  delta_E_vector(state_index) = delta_E_vector_component;
	      
		  G.row_vector(state_index) = delta_E_vector_component_grad;
		  
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      fit_results_file.precision (6);
		      
		      cout.precision (6);
			
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]=" << experimental_energy << " MeV" << endl;

		      fit_results_file << "delta.E.vector.component.grad=" << delta_E_vector_component_grad << endl << endl;

		      cout << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]=" << experimental_energy << " MeV" << endl;

		      cout << "delta.E.vector.component.grad=" << delta_E_vector_component_grad << endl << endl;
		      
		      fit_results_file.precision (15);

		      cout.precision (15);
		    }
		}
	      else
		{
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      fit_results_file.precision (6);

		      cout.precision (6);
		      
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl << endl; 
		      cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV" << endl << endl;
		      
		      fit_results_file.precision (15);

		      cout.precision (15);
		    }
		}
	    }
	}
    }
}

double optimization_data_handling::cost_function_calc_from_energies_gradients (
									       const class array<class input_data_str> &input_data_tab , 
									       const class array<class correlated_state_str> &PSI_qn_tab , 
									       ofstream &fit_results_file)
{
  cout.precision (6);
  
  fit_results_file.precision (6);
  
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  double cost_function = 0.0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      const int Z = input_data.get_Z ();
      const int N = input_data.get_N ();

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {	
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const unsigned int BP = PSI_qn.get_BP ();
	      
	      const double J = PSI_qn.get_J ();

	      const complex<double> E = PSI_qn.get_E ();

	      const double weight = PSI_qn.get_weight ();
	      
	      const double experimental_energy = PSI_qn.get_experimental_energy ();

	      const double energy_error = PSI_qn.get_energy_error ();

	      const double energy = real (E);

	      const double energy_error_square = energy_error*energy_error;

	      const double energy_difference = energy - experimental_energy;

	      const double energy_difference_square = energy_difference*energy_difference;

	      const double cost_function_part = (weight != 0.0) ? (weight * energy_difference_square/energy_error_square) : (0.0);

	      cost_function += cost_function_part;

	      if (THIS_PROCESS == MASTER_PROCESS)
		{
		  if (weight != 0.0)
		    {
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]="
				       << experimental_energy << " MeV cost.function.part=" << cost_function_part << endl;
		  
		      cout << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]="
			   << experimental_energy << " MeV cost.function.part=" << cost_function_part << endl;
		    }
		  else
		    {
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << endl;		  
		      cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << endl;
		    }
		}
	    }
	}
    }

  cout.precision (15);
  
  fit_results_file.precision (15);
  
  return cost_function;
}

void optimization_data_handling::cost_function_grad_calc_from_energies_gradients (
										  const class array<class input_data_str> &input_data_tab , 
										  const class array<class correlated_state_str> &PSI_qn_tab , 
										  const class array<class vector_class<TYPE> > &E_grad_all_states , 
										  double &cost_function , 
										  class vector_class<double> &cost_function_grad , 
										  ofstream &fit_results_file)
{
  cout.precision (6);

  fit_results_file.precision (6);
	  
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  cost_function = 0.0;

  cost_function_grad = 0.0;

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {    
      class input_data_str &input_data = input_data_tab(nucleus_index);

      const int Z = input_data.get_Z ();

      const int N = input_data.get_N ();

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);

	      const unsigned int BP = PSI_qn.get_BP ();

	      const double J = PSI_qn.get_J ();

	      const complex<double> E = PSI_qn.get_E ();

	      const double weight = PSI_qn.get_weight ();
	      	      
	      const double experimental_energy = PSI_qn.get_experimental_energy ();

	      const double energy_error = PSI_qn.get_energy_error ();	      

	      const double energy_error_square = energy_error*energy_error;
	      
	      const double energy = real (E);

	      const double energy_difference = energy - experimental_energy;	      

	      const double energy_difference_square = energy_difference*energy_difference;	

	      if (weight != 0.0)
		{
		  const double cost_function_part = weight * energy_difference_square/energy_error_square;	      
	      
		  const class vector_class<TYPE> &E_grad = E_grad_all_states(nucleus_index , eigenset_index , i);

		  const class vector_class<double> energy_grad = real <double , TYPE> (E_grad);

		  const class vector_class<double> cost_function_grad_part = (2.0*weight*energy_difference/energy_error_square)*energy_grad;

		  cost_function += cost_function_part;
		  
		  cost_function_grad += cost_function_grad_part;
	      
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]=" << experimental_energy << " MeV" << endl;

		      fit_results_file << "cost.function.part=" << cost_function_part << endl << "cost.function.grad.part=" << cost_function_grad_part << endl << endl;

		      cout << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << " keV E[exp]=" << experimental_energy << " MeV" << endl;

		      cout << "cost.function.part=" << cost_function_part << endl << "cost.function.grad.part=" << cost_function_grad_part << endl << endl;
		    }
		}
	      else
		{
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      fit_results_file << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << endl << endl;
		      cout             << J_Pi_string (BP , J) << " Z=" << Z << " N=" << N << " E[not.fitted]=" << energy << " MeV Gamma=" << -2000.0*imag (E) << endl << endl;
		    }
		}
	    }
	}	
    }

  cout.precision (15);
  
  fit_results_file.precision (15);
}

double optimization_data_handling::cost_function_Hessian_matrix_element_calc (
									      const class array<class input_data_str> &input_data_tab ,
									      const class array<class correlated_state_str> &PSI_qn_tab , 
									      const class array<class vector_class<TYPE> > &E_grad_all_states ,
									      const class array<class matrix<TYPE> > &E_Hessian_matrices_all_states ,
									      const unsigned int fit_index , 
									      const unsigned int fit_index_prime)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  double cost_function_Hessian_matrix_element = 0.0;	

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const complex<double> E = PSI_qn.get_E ();

	      const double weight = PSI_qn.get_weight ();
	      
	      if (weight == 0.0) continue;
	      
	      const double experimental_energy = PSI_qn.get_experimental_energy ();
	      
	      const double energy_error = PSI_qn.get_energy_error ();
	      
	      const double energy = real (E);

	      const double energy_difference = energy - experimental_energy;
	      
	      const class vector_class<TYPE> &E_grad = E_grad_all_states(nucleus_index , eigenset_index , i);

	      const class matrix<TYPE> &E_Hessian_matrix = E_Hessian_matrices_all_states(nucleus_index , eigenset_index , i);	      

	      const double sqrt_weight_over_energy_error = sqrt (weight)/energy_error;

	      const double delta_E_vector_component = energy_difference*sqrt_weight_over_energy_error;

	      const double delta_E_vector_component_grad_fit_index       = real_dc (E_grad(fit_index))      *sqrt_weight_over_energy_error;
	      const double delta_E_vector_component_grad_fit_index_prime = real_dc (E_grad(fit_index_prime))*sqrt_weight_over_energy_error;

	      const double E_Hessian_matrix_element_fit_indices = real_dc (E_Hessian_matrix(fit_index , fit_index_prime))*sqrt_weight_over_energy_error;

	      cost_function_Hessian_matrix_element += delta_E_vector_component_grad_fit_index*delta_E_vector_component_grad_fit_index_prime + delta_E_vector_component*E_Hessian_matrix_element_fit_indices;
	    }
	}
    }

  cost_function_Hessian_matrix_element *= 2.0;

  return cost_function_Hessian_matrix_element;
}

double optimization_data_handling::cost_function_Hessian_matrix_element_linear_regression_calc (
												const class array<class input_data_str> &input_data_tab ,
												const class array<class correlated_state_str> &PSI_qn_tab , 
												const class array<class vector_class<TYPE> > &E_grad_all_states ,
												const unsigned int fit_index , 
												const unsigned int fit_index_prime)
{
  const class input_data_str &input_data_zero = input_data_tab(0);
  
  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  double cost_function_Hessian_matrix_element = 0.0;	

  for (unsigned int nucleus_index = 0 ; nucleus_index < N_nuclei_to_consider ; nucleus_index++)
    {
      const class input_data_str &input_data = input_data_tab(nucleus_index);

      const unsigned int eigensets_number = input_data.get_eigensets_number ();

      const class array<unsigned int> &eigenset_vectors_number_tab = input_data.get_eigenset_vectors_number_tab ();

      for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
	{
	  const unsigned int eigenset_vectors_number = eigenset_vectors_number_tab(eigenset_index);

	  for (unsigned int i = 0 ; i < eigenset_vectors_number ; i++)
	    {
	      const class correlated_state_str &PSI_qn = PSI_qn_tab(nucleus_index , eigenset_index , i);
	      
	      const double weight = PSI_qn.get_weight ();
	      
	      const double energy_error = PSI_qn.get_energy_error ();
	      	      
	      if (weight == 0.0) continue;
	      
	      const class vector_class<TYPE> &E_grad = E_grad_all_states(nucleus_index , eigenset_index , i);
	      
	      const double sqrt_weight_over_energy_error = sqrt (weight)/energy_error;
	      
	      const double delta_E_vector_component_grad_fit_index       = real_dc (E_grad(fit_index))      *sqrt_weight_over_energy_error;
	      const double delta_E_vector_component_grad_fit_index_prime = real_dc (E_grad(fit_index_prime))*sqrt_weight_over_energy_error;
	      
	      cost_function_Hessian_matrix_element += delta_E_vector_component_grad_fit_index*delta_E_vector_component_grad_fit_index_prime;
	    }
	}
    }

  cost_function_Hessian_matrix_element *= 2.0;

  return cost_function_Hessian_matrix_element;
}

void optimization_data_handling::cost_function_Hessian_matrix_calc_print_from_all_states (
											  const class array<class input_data_str> &input_data_tab , 
											  const class array<class correlated_state_str> &PSI_qn_tab , 
											  const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
											  const class array<bool> &is_there_l_dependence_from_fit_index , 
											  const class array<int> &l_from_fit_index , 
											  const class array<class vector_class<TYPE> > &E_grad_all_states ,
											  const class array<class matrix<TYPE> > &E_Hessian_matrices_all_states ,
											  ofstream &fit_results_file)
{
  if (THIS_PROCESS != MASTER_PROCESS)
    error_message_print_abort ("Master process only in optimization_data_handling::cost_function_Hessian_matrix_calc_print_from_all_states");

  fit_results_file << endl << "--------------------------------" << endl;
  fit_results_file         << "Hessian matrix results " << endl;
  fit_results_file         << "--------------------------------" << endl << endl;
  
  cout << endl << "--------------------------------" << endl;
  cout         << "Hessian matrix results " << endl;
  cout         << "--------------------------------" << endl << endl;

  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const enum FHT_EFT_parameter_type FHT_EFT_parameter = FHT_EFT_parameters_from_fit_index(fit_index);
      
      const bool is_there_l_dependence = is_there_l_dependence_from_fit_index(fit_index);

      fit_results_file << "i=" << fit_index << "    ";
      cout             << "i=" << fit_index << "    ";

      if (is_there_l_dependence)
	{
	  const int l = l_from_fit_index(fit_index);

	  fit_results_file << FHT_EFT_parameter << " l=" << l << endl;
	  
	  cout << FHT_EFT_parameter << " l=" << l << endl;
	}
      else
	{	
	  fit_results_file << FHT_EFT_parameter<< endl;

	  cout << FHT_EFT_parameter << endl;
	}
    }

  fit_results_file << endl;

  cout << endl;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    for (unsigned int fit_index_prime = 0 ; fit_index_prime <= fit_index ; fit_index_prime++)
      { 
	const double Hessian_matrix_element = cost_function_Hessian_matrix_element_calc (input_data_tab , PSI_qn_tab , E_grad_all_states , E_Hessian_matrices_all_states , fit_index , fit_index_prime);

	const double Hessian_matrix_element_linear_regression = cost_function_Hessian_matrix_element_linear_regression_calc (input_data_tab , PSI_qn_tab , E_grad_all_states , fit_index , fit_index_prime);

	fit_results_file << "i=" << fit_index << "    j=" << fit_index_prime << "    H(i,j)=" << Hessian_matrix_element << "    H[linear regression](i,j)=" << Hessian_matrix_element_linear_regression << endl;
	cout             << "i=" << fit_index << "    j=" << fit_index_prime << "    H(i,j)=" << Hessian_matrix_element << "    H[linear regression](i,j)=" << Hessian_matrix_element_linear_regression << endl;
      }
}



