#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Class defined only so that the HO codes compile with routines meant to be used only with Berggren basis codes
// -------------------------------------------------------------------------------------------------------------
// Input variables are used with cout only in order to avoid warnings.

spherical_state::spherical_state () {}

spherical_state::spherical_state (
				  const bool , 
				  const bool , 
				  const enum potential_type , 
				  const int , 
				  const int , 
				  const double , 
				  const unsigned int , 
				  const unsigned int , 
				  const unsigned int , 
				  const unsigned int , 
				  const unsigned int , 
				  const unsigned int , 
				  const unsigned int , 
				  const double , 
				  const double , 
				  const double , 
				  const double , 
				  const double , 
				  const double , 
				  const bool , 
				  const enum particle_type , 
				  const int , 
				  const double , 
				  const int , 
				  const double , 
				  const bool , 
				  const complex<double> & , 
				  const double , 
				  const complex<double> & , 
				  const complex<double> &)
{}

spherical_state::spherical_state (const class spherical_state &) {}

spherical_state::~spherical_state () {}

void spherical_state::allocate (
				const bool , 
				const bool , 
				const enum potential_type , 
				const int , 
				const int , 
				const double , 
				const unsigned int , 
				const unsigned int , 
				const unsigned int , 
				const unsigned int , 
				const unsigned int ,
				const unsigned int , 
				const unsigned int ,  
				const double , 
				const double , 
				const double , 
				const double , 
				const double , 
				const double , 
				const bool , 
				const enum particle_type , 
				const int , 
				const double , 
				const int , 
				const double , 
				const bool , 
				const complex<double> & , 
				const double , 
				const complex<double> & , 
				const complex<double> &)
{}

void spherical_state::allocate_fill (const class spherical_state &) {}

void spherical_state::deallocate () {}

void spherical_state::HO_wave_function (const double) {}

void spherical_state::k_search (class potentials_effective_mass & , const bool , const bool) {}

void spherical_state::wave_calculation (const bool , class potentials_effective_mass & , const bool) {}

void spherical_state::copy_to_file (const string &) const {}

void spherical_state::copy_to_file_no_scaled_wfs (const string &) const {}

void spherical_state::get_from_file (const string &) {}

void spherical_state::get_from_file_no_scaled_wfs (const string &) {}

ostream & operator << (ostream &os , const class spherical_state &) 
{
  return os;
}

bool same_nlj (const class spherical_state & , const class spherical_state &)
{
  return false;
}

bool same_lj (const class spherical_state & , const class spherical_state &)
{
  return false;
}

#ifdef UseMPI

void spherical_state::MPI_Bcast (const unsigned int , const MPI_Comm) {}

#endif

