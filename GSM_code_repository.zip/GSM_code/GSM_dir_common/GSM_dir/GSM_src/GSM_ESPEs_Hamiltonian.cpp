#include "../GSM_include/GSM_include_def_common.h"

using namespace lj_matrix_common;

// TYPE is double or complex
// -------------------------

// ESPE means effective single-particle energies. One calculates here the Hamiltonian providing with effective single-particle energies.
// It is defined for all one-body partial waves (l,j) for protons and neutrons.
//
// One writes the Hamiltonian as H = hp + hn + Vpp + Vnn + Vpn.
// One calculates then <c | hp(ESPE) a>, for which (la,ja) = (lc,jc) and (a,c) are both protons or neutrons (plus a few hyperons if any).
// Une uses the scalar density matrix of the eigenvector |Psi>, for which H |Psi> = E |Psi>.
// hp(ESPE) and hn(ESPE) are the generalization of the spherical Hartree-Fock potential for |Psi>.
//
// Protons (plus charged hyperons if any)
// -------------==-----------------------
// <c | hp(ESPE) a> = <c | hp | a> + \sum_{bd,J} <cd | Vpp | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . ZYval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd)
//                                 + \sum_{bd,J} <cd | Vpn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . NYval . (2J+1)/((2ja + 1).(2jb + 1))
//
// Neutrons (plus uncharged hyperons if any)
// -----------------------------------------
// <c | hn(ESPE) a> = <c | hn | a> + \sum_{bd,J} <cd | Vnn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . NYval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd)
//                                 + \sum_{bd,J} <dc | Vpn | ba>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . ZYval . (2J+1)/((2ja + 1).(2jb + 1))




// Calculation of the proton (plus charged hyperons if any) part of the Hamiltonian providing with effective single-particle energies
// ----------------------------------------------------------------------------------------------------------------------------------
// It is <c | hp | a> + \sum_{bd,J} <cd | Vpp | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . ZYval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd) . 
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hp(ESPE) | a> and not <a | hp(ESPE) | c>. 
// It is done by demanding nc <= na. Consequently, (a,b) and (c,d) are not necessarily ordered in <cd | Vpp | ab>_J and reordering phases must be considered.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::OBMEs_TBMEs_pp_part_p_calc ( 
						    const class input_data_str &input_data ,
						    class baryons_data &prot_Y_data)
{	
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();

  if (ZYval == 0) return;

  const class array<enum particle_type> &baryon_types = prot_Y_data.get_baryon_types ();
  
  const unsigned int Np_baryon_type = baryon_types.dimension (0);
  
  const int lp_max = prot_Y_data.get_lmax ();
  
  const class array<class lj_table<int> > &nmin_lj_valence_p_tabs = prot_Y_data.get_nmin_lj_valence_tabs ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const class array<class nlj_table<unsigned int> > &shells_p_indices_tab = prot_Y_data.get_shells_indices_tab ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_p_set = prot_Y_data.get_OBMEs_inter_set ();

  const class array<TYPE> &OBMEs_inter_p = OBMEs_inter_p_set(inter);
  
  class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_p_tab = prot_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (unsigned int ip = 0 ; ip < Np_baryon_type ; ip++)
	{
	  const enum particle_type particle = baryon_types(ip);
        
	  if (particle == NO_PARTICLE) continue;
      
	  const class lj_table<int> &nmin_lj_valence_p_tab = nmin_lj_valence_p_tabs(ip);
  
	  const class nlj_table<unsigned int> &shells_p_indices = shells_p_indices_tab(ip);
	  
	  class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_p = ESPEs_Hamiltonian_matrices_p_tab(ip);
  
	  for (int l = 0 ; l <= lp_max ; l++)
	    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {	
		const class matrix<TYPE> &ESPEs_Hamiltonian_matrix_p = ESPEs_Hamiltonian_matrices_p(l , j);

		const int nmin_lj = nmin_lj_valence_p_tab(l , j);
	
		const int nmax_lj = ESPEs_Hamiltonian_matrix_p.get_dimension () - 1;

		for (int n = nmin_lj ; n <= nmax_lj ; n++)
		  for (int np = nmin_lj ; np <= n ; np++)
		    {
		      const unsigned int s  = shells_p_indices(n  , l , j);		  
		      const unsigned int sp = shells_p_indices(np , l , j);

		      ESPEs_Hamiltonian_matrix_p(n , np) = OBMEs_inter_p(s , sp);
		    }
	      }
	}
    }
  
  if (ZYval == 1) return;

  const class TBMEs_class &TBMEs_pp = prot_Y_data.get_TBMEs ();
    
  const unsigned int BPmin_global = TBMEs_pp.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pp.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pp.get_Jmin_global ();
  const int Jmax_global = TBMEs_pp.get_Jmax_global ();
  
  const unsigned int first_index = TBMEs_pp.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pp.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab = prot_Y_data.get_scalar_density_matrices_tab ();
  
  class array<class array<class lj_table<class matrix<TYPE> > > > ESPEs_Hamiltonian_matrices_p_pp_part_tabs(NUMBER_OF_THREADS);

  lj_matrices_parts_tabs_allocate_initialize (prot_Y_data , ESPEs_Hamiltonian_matrices_p_pp_part_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_p_pp_part_tab = ESPEs_Hamiltonian_matrices_p_pp_part_tabs(i_thread);
      
      for (unsigned int s1 = 0 ; s1 < Np_nlj ; s1++)
	{
	  const class nlj_struct &shell_qn_s0 = shells_qn_p(s0);
	  const class nlj_struct &shell_qn_s1 = shells_qn_p(s1);
	
	  const enum particle_type particle_s0 = shell_qn_s0.get_particle ();
	  const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
	      
	  const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);
	
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_p); 

	  if (n_scat_in <= n_scat_max_p)
	    {	      
	      const unsigned int particle_index_s0 = charge_baryon_index_determine (particle_s0);
	      const unsigned int particle_index_s1 = charge_baryon_index_determine (particle_s1);
			
	      const int n0 = shell_qn_s0.get_n () , n1 = shell_qn_s1.get_n ();
	      const int l0 = shell_qn_s0.get_l () , l1 = shell_qn_s1.get_l ();

	      const double j0 = shell_qn_s0.get_j ();
	      const double j1 = shell_qn_s1.get_j ();
		
	      const unsigned int s01_min = min (s0 , s1);
	      const unsigned int s01_max = max (s0 , s1);
	      
	      const int minus_one_pow_j0_plus_j1_minus_one = minus_one_pow (j0 + j1 - 1);
	      
	      const double inv_antisymmetry_delta_01 = (s0 == s1) ? (M_SQRT2) : (1.0);
	
	      const double inv_antisymmetry_delta_01_square_hat_js_ZYval = (inv_antisymmetry_delta_01*ZYval)/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	      
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_p);

	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_p);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_p);
			
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_p);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_p);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_p);
	      	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_p);

	      const class lj_table<class matrix<TYPE> > &scalar_density_matrices_p_s1 = scalar_density_matrices_p_tab(particle_index_s1);
	    
	      const class matrix<TYPE> &scalar_density_matrix_p_13 = scalar_density_matrices_p_s1(l1 , j1);
	    
	      class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_p_pp_part_s0 = ESPEs_Hamiltonian_matrices_p_pp_part_tab(particle_index_s0);
	      
	      class matrix<TYPE> &ESPEs_Hamiltonian_matrix_p_pp_part_02 = ESPEs_Hamiltonian_matrices_p_pp_part_s0(l0 , j0);
					  
	      for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
		{
		  const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);

		  if (same_lj_particle (shell_qn_s0 , shell_qn_s2))
		    {
		      const int n2 = shell_qn_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &ESPEs_Hamiltonian_p_pp_ME_part_02 = ESPEs_Hamiltonian_matrix_p_pp_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Np_nlj ; s3++)
			    {
			      const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);
			      const class nlj_struct &shell_qn_s3 = shells_qn_p(s3);
			      
			      const enum particle_type particle_s2 = shell_qn_s2.get_particle ();
			      const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
	  
			      const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_p);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_p);

				  if (n_scat_out <= n_scat_max_p)
				    {
				      const class nlj_struct &shell_qn_s3 = shells_qn_p(s3);
			  
				      if (same_lj_particle (shell_qn_s1 , shell_qn_s3))
					{
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_p);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_p);
				    
					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {				      
					      const bool is_it_diagonal = (pair_in == pair_out);
			  
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_p);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_p);					      
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_p);

					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_p);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);
			  
					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;
					
					      const int n3 = shell_qn_s3.get_n ();
					  
					      const unsigned int s23_min = min (s2 , s3);
					      const unsigned int s23_max = max (s2 , s3);
					  
					      const double inv_antisymmetry_delta_23 = (s2 == s3) ? (M_SQRT2) : (1.0);
				      
					      const TYPE scalar_density_ME_p_13 = scalar_density_matrix_p_13(n1 , n3);
					  
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pp.index_determine (J , s01_min , s01_max , s23_min , s23_max);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const int minus_one_pow_J = (J%2 == 0) ? (1) : (-1);

						      const int minus_one_pow_j0_plus_j1_minus_one_minus_J = minus_one_pow_j0_plus_j1_minus_one*minus_one_pow_J;
						      
						      const int phase_01 = (s1 < s0) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      const int phase_23 = (s3 < s2) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      
						      const int phase = phase_01*phase_23;

						      const double inv_antisymmetry_deltas_square_hat_js_J_ZYval = inv_antisymmetry_delta_01_square_hat_js_ZYval*inv_antisymmetry_delta_23*(2.0*J + 1.0);
						      
						      const TYPE TBME_pp = phase*TBMEs_pp(J , s01_min , s01_max , s23_min , s23_max);
						  
						      ESPEs_Hamiltonian_p_pp_ME_part_02 += TBME_pp*scalar_density_ME_p_13*inv_antisymmetry_deltas_square_hat_js_J_ZYval;
						    }}}}}}}}}}}}}
  
  add_parts (ESPEs_Hamiltonian_matrices_p_pp_part_tabs , ESPEs_Hamiltonian_matrices_p_tab);
}









// Calculation of the proton-neutron (plus hyperons if any) part of the Hamiltonian providing with proton effective single-particle energies
// -----------------------------------------------------------------------------------------------------------------------------------------
// It is \sum_{bd,J} <cd | Vpn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . NYval . (2J+1)/((2ja + 1).(2jb + 1)) for fixed (a,c).
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hp(ESPE) | a> and not <a | hp(ESPE) | c>. It is done by demanding nc <= na.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::TBMEs_pn_part_p_calc (
					      const class input_data_str &input_data ,
					      const class TBMEs_class &TBMEs_pn ,  
					      const class baryons_data &neut_Y_data , 
					      class baryons_data &prot_Y_data)
{
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();

  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
    
  const unsigned int BPmin_global = TBMEs_pn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pn.get_Jmin_global ();
  const int Jmax_global = TBMEs_pn.get_Jmax_global ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const unsigned int first_index = TBMEs_pn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab = neut_Y_data.get_scalar_density_matrices_tab ();
  
  class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_p_tab = prot_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();
  
  class array<class array<class lj_table<class matrix<TYPE> > > > ESPEs_Hamiltonian_matrices_p_pn_part_tabs(NUMBER_OF_THREADS);
  
  lj_matrices_parts_tabs_allocate_initialize (prot_Y_data , ESPEs_Hamiltonian_matrices_p_pn_part_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_p_pn_part_tab = ESPEs_Hamiltonian_matrices_p_pn_part_tabs(i_thread);

      for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
	{
	  const class nlj_struct &shell_qn_s0 = shells_qn_p(s0);
	  const class nlj_struct &shell_qn_s1 = shells_qn_n(s1);
	  
	  const enum particle_type particle_s0 = shell_qn_s0.get_particle ();
	  const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
	      
	  const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);
		      
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

	  if (n_scat_in <= n_scat_max)
	    { 	      
	      const unsigned int particle_index_s0 = charge_baryon_index_determine (particle_s0);
	      const unsigned int particle_index_s1 = charge_baryon_index_determine (particle_s1);
			
	      const int n0 = shell_qn_s0.get_n () , n1 = shell_qn_s1.get_n ();
	      const int l0 = shell_qn_s0.get_l () , l1 = shell_qn_s1.get_l ();

	      const double j0 = shell_qn_s0.get_j ();
	      const double j1 = shell_qn_s1.get_j ();
		
	      const double inv_square_hat_js_NYval = NYval/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);
	
	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);			  
	      
	      const bool are_there_core_states_in  = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_n);
	      const bool are_there_hole_states_in  = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_n);

	      const class lj_table<class matrix<TYPE> > &scalar_density_matrices_n_s1 = scalar_density_matrices_n_tab(particle_index_s1);
	    
	      const class matrix<TYPE> &scalar_density_matrix_n_13 = scalar_density_matrices_n_s1(l1 , j1);
	    
	      class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_p_pn_part_s0 = ESPEs_Hamiltonian_matrices_p_pn_part_tab(particle_index_s0);
	      
	      class matrix<TYPE> &ESPEs_Hamiltonian_matrix_p_pn_part_02 = ESPEs_Hamiltonian_matrices_p_pn_part_s0(l0 , j0);
	      
	      for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
		{
		  const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);

		  if (same_lj_particle (shell_qn_s0 , shell_qn_s2))
		    {
		      const int n2 = shell_qn_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &ESPEs_Hamiltonian_p_pn_ME_part_02 = ESPEs_Hamiltonian_matrix_p_pn_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
			    {
			      const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);
			      const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);
			      
			      const enum particle_type particle_s2 = shell_qn_s2.get_particle ();
			      const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
			      
			      const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

				  if (n_scat_out <= n_scat_max)
				    {
				      const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);
			  
				      if (same_lj_particle (shell_qn_s1 , shell_qn_s3))
					{			  
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {
					      const bool is_it_diagonal = (pair_in == pair_out);
		      
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;
					      
					      if (are_there_core_states && !are_there_hole_states) continue;

					      const int n3 = shell_qn_s3.get_n ();
					      
					      const TYPE scalar_density_ME_n_13 = scalar_density_matrix_n_13(n1 , n3);						    
					    
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pn.index_determine (J , s0 , s1 , s2 , s3);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const TYPE TBME_pn = TBMEs_pn(J , s0 , s1 , s2 , s3);

						      const double inv_square_hat_js_J_NYval = inv_square_hat_js_NYval*(2.0*J + 1.0);
						  
						      ESPEs_Hamiltonian_p_pn_ME_part_02 += TBME_pn*scalar_density_ME_n_13*inv_square_hat_js_J_NYval;
						    }}}}}}}}}}}}
    }
  
  add_parts (ESPEs_Hamiltonian_matrices_p_pn_part_tabs , ESPEs_Hamiltonian_matrices_p_tab);
}










// Calculation of the neutron (plus uncharged hyperons if any) part of the Hamiltonian providing with effective single-particle energies
// -------------------------------------------------------------------------------------------------------------------------------------
// It is <c | hn | a> + \sum_{bd,J} <cd | Vnn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . NYval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd) . 
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hn(ESPE) | a> and not <a | hn(ESPE) | c>. 
// It is done by demanding nc <= na. Consequently, (a,b) and (c,d) are not necessarily ordered in <cd | Vnn | ab>_J and reordering phases must be considered.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::OBMEs_TBMEs_nn_part_n_calc ( 
						    const class input_data_str &input_data ,
						    class baryons_data &neut_Y_data)
{	
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();

  if (NYval == 0) return;

  const class array<enum particle_type> &baryon_types = neut_Y_data.get_baryon_types ();
  
  const unsigned int Nn_baryon_type = baryon_types.dimension (0);
  
  const int ln_max = neut_Y_data.get_lmax ();
  
  const class array<class lj_table<int> > &nmin_lj_valence_n_tabs = neut_Y_data.get_nmin_lj_valence_tabs ();
  
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const class array<class nlj_table<unsigned int> > &shells_n_indices_tab = neut_Y_data.get_shells_indices_tab ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_n_set = neut_Y_data.get_OBMEs_inter_set ();

  const class array<TYPE> &OBMEs_inter_n = OBMEs_inter_n_set(inter);
  
  class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_n_tab = neut_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (unsigned int in = 0 ; in < Nn_baryon_type ; in++)
	{
	  const enum particle_type particle = baryon_types(in);
        
	  if (particle == NO_PARTICLE) continue;
      
	  const class lj_table<int> &nmin_lj_valence_n_tab = nmin_lj_valence_n_tabs(in);
  
	  const class nlj_table<unsigned int> &shells_n_indices = shells_n_indices_tab(in);
	  
	  class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_n = ESPEs_Hamiltonian_matrices_n_tab(in);
  
	  for (int l = 0 ; l <= ln_max ; l++)
	    for (double j = abs (l - 0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {	
		const class matrix<TYPE> &ESPEs_Hamiltonian_matrix_n = ESPEs_Hamiltonian_matrices_n(l , j);

		const int nmin_lj = nmin_lj_valence_n_tab(l , j);
	
		const int nmax_lj = ESPEs_Hamiltonian_matrix_n.get_dimension () - 1;

		for (int n = nmin_lj ; n <= nmax_lj ; n++)
		  for (int np = nmin_lj ; np <= n ; np++)
		    {
		      const unsigned int s  = shells_n_indices(n  , l , j);		  
		      const unsigned int sp = shells_n_indices(np , l , j);

		      ESPEs_Hamiltonian_matrix_n(n , np) = OBMEs_inter_n(s , sp);
		    }
	      }
	}
    }
  
  if (NYval == 1) return;

  const class TBMEs_class &TBMEs_nn = neut_Y_data.get_TBMEs ();
    
  const unsigned int BPmin_global = TBMEs_nn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_nn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_nn.get_Jmin_global ();
  const int Jmax_global = TBMEs_nn.get_Jmax_global ();
  
  const unsigned int first_index = TBMEs_nn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_nn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_n_tab = neut_Y_data.get_scalar_density_matrices_tab ();
  
  class array<class array<class lj_table<class matrix<TYPE> > > > ESPEs_Hamiltonian_matrices_n_nn_part_tabs(NUMBER_OF_THREADS);

  lj_matrices_parts_tabs_allocate_initialize (neut_Y_data , ESPEs_Hamiltonian_matrices_n_nn_part_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Nn_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_n_nn_part_tab = ESPEs_Hamiltonian_matrices_n_nn_part_tabs(i_thread);
      
      for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
	{
	  const class nlj_struct &shell_qn_s0 = shells_qn_n(s0);
	  const class nlj_struct &shell_qn_s1 = shells_qn_n(s1);
	
	  const enum particle_type particle_s0 = shell_qn_s0.get_particle ();
	  const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
	      
	  const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);
	
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_n , shells_qn_n); 

	  if (n_scat_in <= n_scat_max_n)
	    {	      
	      const unsigned int particle_index_s0 = charge_baryon_index_determine (particle_s0);
	      const unsigned int particle_index_s1 = charge_baryon_index_determine (particle_s1);
			
	      const int n0 = shell_qn_s0.get_n () , n1 = shell_qn_s1.get_n ();
	      const int l0 = shell_qn_s0.get_l () , l1 = shell_qn_s1.get_l ();

	      const double j0 = shell_qn_s0.get_j ();
	      const double j1 = shell_qn_s1.get_j ();
		
	      const unsigned int s01_min = min (s0 , s1);
	      const unsigned int s01_max = max (s0 , s1);
	      
	      const int minus_one_pow_j0_plus_j1_minus_one = minus_one_pow (j0 + j1 - 1);
	      
	      const double inv_antisymmetry_delta_01 = (s0 == s1) ? (M_SQRT2) : (1.0);
	
	      const double inv_antisymmetry_delta_01_square_hat_js_NYval = (inv_antisymmetry_delta_01*NYval)/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	      
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_n , shells_qn_n);

	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_n , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_n , shells_qn_n);
			
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_n , shells_qn_n);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_n , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_n , shells_qn_n);
	      	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_n , shells_qn_n);

	      const class lj_table<class matrix<TYPE> > &scalar_density_matrices_n_s1 = scalar_density_matrices_n_tab(particle_index_s1);
	    
	      const class matrix<TYPE> &scalar_density_matrix_n_13 = scalar_density_matrices_n_s1(l1 , j1);
	    
	      class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_n_nn_part_s0 = ESPEs_Hamiltonian_matrices_n_nn_part_tab(particle_index_s0);
	      
	      class matrix<TYPE> &ESPEs_Hamiltonian_matrix_n_nn_part_02 = ESPEs_Hamiltonian_matrices_n_nn_part_s0(l0 , j0);
					  
	      for (unsigned int s2 = 0 ; s2 < Nn_nlj ; s2++)
		{
		  const class nlj_struct &shell_qn_s2 = shells_qn_n(s2);

		  if (same_lj_particle (shell_qn_s0 , shell_qn_s2))
		    {
		      const int n2 = shell_qn_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &ESPEs_Hamiltonian_n_nn_ME_part_02 = ESPEs_Hamiltonian_matrix_n_nn_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
			    {
			      const class nlj_struct &shell_qn_s2 = shells_qn_n(s2);
			      const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);
			      
			      const enum particle_type particle_s2 = shell_qn_s2.get_particle ();
			      const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
			      
			      const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_n , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_n , shells_qn_n);

				  if (n_scat_out <= n_scat_max_n)
				    {
				      const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);
			  
				      if (same_lj_particle (shell_qn_s1 , shell_qn_s3))
					{
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_n , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_n , shells_qn_n);
				    
					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {				      
					      const bool is_it_diagonal = (pair_in == pair_out);
			  
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_n , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_n , shells_qn_n);					      
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_n , shells_qn_n);

					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_n , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);
			  
					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;
					
					      const int n3 = shell_qn_s3.get_n ();
					  
					      const unsigned int s23_min = min (s2 , s3);
					      const unsigned int s23_max = max (s2 , s3);
					  
					      const double inv_antisymmetry_delta_23 = (s2 == s3) ? (M_SQRT2) : (1.0);
				      
					      const TYPE scalar_density_ME_n_13 = scalar_density_matrix_n_13(n1 , n3);
					  
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_nn.index_determine (J , s01_min , s01_max , s23_min , s23_max);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const int minus_one_pow_J = (J%2 == 0) ? (1) : (-1);

						      const int minus_one_pow_j0_plus_j1_minus_one_minus_J = minus_one_pow_j0_plus_j1_minus_one*minus_one_pow_J;
						      
						      const int phase_01 = (s1 < s0) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      const int phase_23 = (s3 < s2) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      
						      const int phase = phase_01*phase_23;

						      const double inv_antisymmetry_deltas_square_hat_js_J_NYval = inv_antisymmetry_delta_01_square_hat_js_NYval*inv_antisymmetry_delta_23*(2.0*J + 1.0);
						      
						      const TYPE TBME_nn = phase*TBMEs_nn(J , s01_min , s01_max , s23_min , s23_max);
						  
						      ESPEs_Hamiltonian_n_nn_ME_part_02 += TBME_nn*scalar_density_ME_n_13*inv_antisymmetry_deltas_square_hat_js_J_NYval;
						    }}}}}}}}}}}}}
  
  add_parts (ESPEs_Hamiltonian_matrices_n_nn_part_tabs , ESPEs_Hamiltonian_matrices_n_tab);
}










// Calculation of the proton-neutron (plus hyperons if any) part of the Hamiltonian providing with neutron effective single-particle energies
// ------------------------------------------------------------------------------------------------------------------------------------------
// It is \sum_{bd,J} <dc | Vpn | ba>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . ZYval . (2J+1)/((2ja + 1).(2jb + 1)) for fixed (a,c).
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hn(ESPE) | a> and not <a | hn(ESPE) | c>. It is done by demanding nc <= na.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::TBMEs_pn_part_n_calc (
					      const class input_data_str &input_data ,
					      const class TBMEs_class &TBMEs_pn ,  
					      const class baryons_data &prot_Y_data , 
					      class baryons_data &neut_Y_data)
{
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
    
  const unsigned int BPmin_global = TBMEs_pn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pn.get_Jmin_global ();
  const int Jmax_global = TBMEs_pn.get_Jmax_global ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const unsigned int first_index = TBMEs_pn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const class array<class lj_table<class matrix<TYPE> > > &scalar_density_matrices_p_tab = prot_Y_data.get_scalar_density_matrices_tab ();
  
  class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_n_tab = neut_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();

  class array<class array<class lj_table<class matrix<TYPE> > > > ESPEs_Hamiltonian_matrices_n_pn_part_tabs(NUMBER_OF_THREADS);

  lj_matrices_parts_tabs_allocate_initialize (neut_Y_data , ESPEs_Hamiltonian_matrices_n_pn_part_tabs);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_n_pn_part_tab = ESPEs_Hamiltonian_matrices_n_pn_part_tabs(i_thread);

      for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
	{
	  const class nlj_struct &shell_qn_s0 = shells_qn_p(s0);
	  const class nlj_struct &shell_qn_s1 = shells_qn_n(s1);
	
	  const enum particle_type particle_s0 = shell_qn_s0.get_particle ();
	  const enum particle_type particle_s1 = shell_qn_s1.get_particle ();
	      
	  const class pair_str pair_in(particle_s0 , s0 , particle_s1 , s1);
		      
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

	  if (n_scat_in <= n_scat_max)
	    { 	      
	      const unsigned int particle_index_s0 = charge_baryon_index_determine (particle_s0);
	      const unsigned int particle_index_s1 = charge_baryon_index_determine (particle_s1);
			
	      const int n0 = shell_qn_s0.get_n () , n1 = shell_qn_s1.get_n ();
	      const int l0 = shell_qn_s0.get_l () , l1 = shell_qn_s1.get_l ();

	      const double j0 = shell_qn_s0.get_j ();
	      const double j1 = shell_qn_s1.get_j ();
		
	      const double inv_square_hat_js_ZYval = ZYval/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);
	
	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);			  
	      
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_n);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_n);
	    
	      const class lj_table<class matrix<TYPE> > &scalar_density_matrices_p_s0 = scalar_density_matrices_p_tab(particle_index_s0);
	    
	      const class matrix<TYPE> &scalar_density_matrix_p_02 = scalar_density_matrices_p_s0(l0 , j0);
	    
	      class lj_table<class matrix<TYPE> > &ESPEs_Hamiltonian_matrices_n_pn_part_s1 = ESPEs_Hamiltonian_matrices_n_pn_part_tab(particle_index_s1);
	      
	      class matrix<TYPE> &ESPEs_Hamiltonian_matrix_n_pn_part_13 = ESPEs_Hamiltonian_matrices_n_pn_part_s1(l1 , j1);
	      
	      for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
		{
		  const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);

		  if (same_lj_particle (shell_qn_s1 , shell_qn_s3))
		    {
		      const int n3 = shell_qn_s3.get_n ();

		      if (n3 <= n1)
			{						    
			  TYPE &ESPEs_Hamiltonian_n_pn_ME_part_13 = ESPEs_Hamiltonian_matrix_n_pn_part_13(n1 , n3);
		      
			  for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
			    {
			      const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);
			      const class nlj_struct &shell_qn_s3 = shells_qn_n(s3);
			      
			      const enum particle_type particle_s2 = shell_qn_s2.get_particle ();
			      const enum particle_type particle_s3 = shell_qn_s3.get_particle ();
			      
			      const class pair_str pair_out(particle_s2 , s2 , particle_s3 , s3);
			  
			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

				  if (n_scat_out <= n_scat_max)
				    {
				      const class nlj_struct &shell_qn_s2 = shells_qn_p(s2);
			  
				      if (same_lj_particle (shell_qn_s0 , shell_qn_s2))
					{			  
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {
					      const bool is_it_diagonal = (pair_in == pair_out);
		      
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;

					      const int n2 = shell_qn_s2.get_n ();
				      
					      const TYPE scalar_density_ME_p_02 = scalar_density_matrix_p_02(n0 , n2);
					    
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pn.index_determine (J , s0 , s1 , s2 , s3);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const TYPE TBME_pn = TBMEs_pn(J , s0 , s1 , s2 , s3);

						      const double inv_square_hat_js_J_ZYval = inv_square_hat_js_ZYval*(2.0*J + 1.0);
						  
						      ESPEs_Hamiltonian_n_pn_ME_part_13 += TBME_pn*scalar_density_ME_p_02*inv_square_hat_js_J_ZYval;
						    }}}}}}}}}}}}
    }
  
  add_parts (ESPEs_Hamiltonian_matrices_n_pn_part_tabs , ESPEs_Hamiltonian_matrices_n_tab);
}












// Calculation of the proton and neutron (to which hyperons are added if any) Hamiltonian matrices providing with effective single-particle energies
// -------------------------------------------------------------------------------------------------------------------------------------------------
// Protons and neutrons routines for proton, neutron and proton-neutron (plus hyperons if any) parts are called.
// All matrices of Hamiltonians providing with effective single-particle energies are summed and reduced after calculation of the proton, neutron and proton-neutron parts (to which hyperons are added if any).
// As symmetry was used before, only the lower parts of matrices of Hamiltonians providing with effective single-particle energies were calculated.
// Their upper part is filled as well after calculation.

void ESPEs_Hamiltonian::pn_alloc_calc (
				       const class input_data_str &input_data ,
				       const class TBMEs_class &TBMEs_pn ,  
				       class baryons_data &prot_Y_data , 
				       class baryons_data &neut_Y_data)
{
  const enum space_type space = input_data.get_space ();

  if (space != NEUT_Y_ONLY)
    {      
      ESPEs_Hamiltonian_matrices_tab_allocate_initialize (prot_Y_data);
      
      OBMEs_TBMEs_pp_part_p_calc (input_data , prot_Y_data);

      if (space == PROT_NEUT_Y) TBMEs_pn_part_p_calc (input_data , TBMEs_pn , neut_Y_data , prot_Y_data);
	 
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_p_tab = prot_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();
      
#ifdef UseMPI
	
      if (is_it_MPI_parallelized)
	{
	  MPI_helper::Barrier ();

	  lj_matrices_tab_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , ESPEs_Hamiltonian_matrices_p_tab);
	}
  
#endif
  
      fill_upper_part (ESPEs_Hamiltonian_matrices_p_tab);

      lj_matrices_tab_core_states_handling (prot_Y_data , ESPEs_Hamiltonian_matrices_p_tab);
    }

  if (space != PROT_Y_ONLY)
    {      
      ESPEs_Hamiltonian_matrices_tab_allocate_initialize (neut_Y_data);

      OBMEs_TBMEs_nn_part_n_calc (input_data , neut_Y_data);
      
      if (space == PROT_NEUT_Y) TBMEs_pn_part_n_calc (input_data , TBMEs_pn , prot_Y_data , neut_Y_data);
  
      class array<class lj_table<class matrix<TYPE> > > &ESPEs_Hamiltonian_matrices_n_tab = neut_Y_data.get_ESPEs_Hamiltonian_matrices_tab ();
  
#ifdef UseMPI
	
      if (is_it_MPI_parallelized)
	{
	  MPI_helper::Barrier ();

	  lj_matrices_tab_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , ESPEs_Hamiltonian_matrices_n_tab);
	}
  
#endif
  
      fill_upper_part (ESPEs_Hamiltonian_matrices_n_tab);
      
      lj_matrices_tab_core_states_handling (neut_Y_data , ESPEs_Hamiltonian_matrices_n_tab);
    }
}




