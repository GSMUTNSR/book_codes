#include "../GSM_include/GSM_include_def_common.h"

using namespace lj_matrix_common;

// TYPE is double or complex
// -------------------------

// ESPE means effective single-particle energies. One calculates here the Hamiltonian providing with effective single-particle energies.
// It is defined for all one-body partial waves (l,j) for protons and neutrons.
//
// One writes the Hamiltonian as H = hp + hn + Vpp + Vnn + Vpn.
// One calculates then <c | hp(ESPE) a>, for which (la,ja) = (lc,jc) and (a,c) are both protons or neutrons.
// Une uses the scalar density matrix of the eigenvector |Psi>, for which H |Psi> = E |Psi>.
// hp(ESPE) and hn(ESPE) are the generalization of the spherical Hartree-Fock potential for |Psi>.
//
// Protons
// -------
// <c | hp(ESPE) a> = <c | hp | a> + \sum_{bd,J} <cd | Vpp | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Zval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd)
//                                 + \sum_{bd,J} <cd | Vpn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Nval . (2J+1)/((2ja + 1).(2jb + 1))
// Neutrons
// --------
// <c | hn(ESPE) a> = <c | hn | a> + \sum_{bd,J} <cd | Vnn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Nval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd)
//                                 + \sum_{bd,J} <dc | Vpn | ba>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Zval . (2J+1)/((2ja + 1).(2jb + 1))




// Calculation of the proton part of the Hamiltonian providing with effective single-particle energies
// ---------------------------------------------------------------------------------------------------
// It is <c | hp | a> + \sum_{bd,J} <cd | Vpp | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Zval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd) . 
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hp(ESPE) | a> and not <a | hp(ESPE) | c>. 
// It is done by demanding nc <= na. Consequently, (a,b) and (c,d) are not necessarily ordered in <cd | Vpp | ab>_J and reordering phases must be considered.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::OBMEs_TBMEs_pp_part_prot_calc ( 
						       const class input_data_str &input_data ,
						       class nucleons_data &prot_data)
{	
  const unsigned int Zval = prot_data.get_N_valence_nucleons ();

  if (Zval == 0) return;

  const int lp_max = prot_data.get_lmax ();
  
  const class lj_table<int> &nmin_lj_valence_prot_tab = prot_data.get_nmin_lj_valence_tab ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_data.get_shells_quantum_numbers ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const int n_scat_max_p = prot_data.get_n_scat_max ();
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const class nlj_table<unsigned int> &shells_prot_indices = prot_data.get_shells_indices ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_prot_set = prot_data.get_OBMEs_inter_set ();

  const class array<TYPE> &OBMEs_inter_prot = OBMEs_inter_prot_set(inter);
  
  class lj_table<class matrix<TYPE> > &prot_ESPEs_Hamiltonian_matrices = prot_data.get_ESPEs_Hamiltonian_matrices ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int l = 0 ; l <= lp_max ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {	
	    const class matrix<TYPE> &prot_ESPEs_Hamiltonian_matrix = prot_ESPEs_Hamiltonian_matrices(l , j);

	    const int nmin_lj = nmin_lj_valence_prot_tab(l , j);
	
	    const int nmax_lj = prot_ESPEs_Hamiltonian_matrix.get_dimension () - 1;

	    for (int n = nmin_lj ; n <= nmax_lj ; n++)
	      for (int np = nmin_lj ; np <= n ; np++)
		{
		  const unsigned int s = shells_prot_indices(n , l , j);
		  
		  const unsigned int sp = shells_prot_indices(np , l , j);

		  prot_ESPEs_Hamiltonian_matrix(n , np) = OBMEs_inter_prot(s , sp);
		}
	  }
    }
  
  if (Zval == 1) return;

  const class TBMEs_class &TBMEs_pp = prot_data.get_TBMEs ();
    
  const unsigned int BPmin_global = TBMEs_pp.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pp.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pp.get_Jmin_global ();
  const int Jmax_global = TBMEs_pp.get_Jmax_global ();
  
  const unsigned int first_index = TBMEs_pp.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pp.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices = prot_data.get_scalar_density_matrices ();
  
  class array<class lj_table<class matrix<TYPE> > > prot_ESPEs_Hamiltonian_matrices_pp_part_tab(NUMBER_OF_THREADS);

  lj_matrices_parts_tab_allocate_initialize (prot_data , prot_ESPEs_Hamiltonian_matrices_pp_part_tab);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class lj_table<class matrix<TYPE> > &prot_ESPEs_Hamiltonian_matrices_pp_part = prot_ESPEs_Hamiltonian_matrices_pp_part_tab(i_thread);
      
      for (unsigned int s1 = 0 ; s1 < Np_nlj ; s1++)
	{
	  const class pair_str pair_in(s0 , s1);
	
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_p); 

	  if (n_scat_in <= n_scat_max_p)
	    {
	      const class nlj_struct &shell_s0 = shells_qn_p(s0);
	      const class nlj_struct &shell_s1 = shells_qn_p(s1);
	
	      const int n0 = shell_s0.get_n ();
	      const int l0 = shell_s0.get_l ();
	      
	      const int n1 = shell_s1.get_n ();
	      const int l1 = shell_s1.get_l ();

	      const double j0 = shell_s0.get_j ();
	      const double j1 = shell_s1.get_j ();
		
	      const unsigned int s01_min = min (s0 , s1);
	      const unsigned int s01_max = max (s0 , s1);
	      
	      const int minus_one_pow_j0_plus_j1_minus_one = minus_one_pow (j0 + j1 - 1);
	      
	      const double inv_antisymmetry_delta_01 = (s0 == s1) ? (M_SQRT2) : (1.0);
	
	      const double inv_antisymmetry_delta_01_square_hat_js_Zval = (inv_antisymmetry_delta_01*Zval)/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	      
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_p);

	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_p);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_p);
			
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_p);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_p);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_p);
	      	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_p);

	      const class matrix<TYPE> &prot_scalar_density_matrix_13 = prot_scalar_density_matrices(l1 , j1);
	    
	      class matrix<TYPE> &prot_ESPEs_Hamiltonian_matrix_pp_part_02 = prot_ESPEs_Hamiltonian_matrices_pp_part(l0 , j0);
					  
	      for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
		{
		  const class nlj_struct &shell_s2 = shells_qn_p(s2);

		  if (same_lj (shell_s0 , shell_s2))
		    {
		      const int n2 = shell_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &prot_ESPEs_Hamiltonian_matrix_element_pp_part_02 = prot_ESPEs_Hamiltonian_matrix_pp_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Np_nlj ; s3++)
			    {
			      const class pair_str pair_out(s2 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_p);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_p);

				  if (n_scat_out <= n_scat_max_p)
				    {
				      const class nlj_struct &shell_s3 = shells_qn_p(s3);
			  
				      if (same_lj (shell_s1 , shell_s3))
					{
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_p);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_p);
				    
					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {				      
					      const bool is_it_diagonal = (pair_in == pair_out);
			  
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_p);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_p);					      
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_p);

					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_p);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);
			  
					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;
					
					      const int n3 = shell_s3.get_n ();
					  
					      const unsigned int s23_min = min (s2 , s3);
					      const unsigned int s23_max = max (s2 , s3);
					  
					      const double inv_antisymmetry_delta_23 = (s2 == s3) ? (M_SQRT2) : (1.0);
				      
					      const TYPE prot_scalar_density_matrix_element_13 = prot_scalar_density_matrix_13(n1 , n3);
					  
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pp.index_determine (J , s01_min , s01_max , s23_min , s23_max);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const int minus_one_pow_J = (J%2 == 0) ? (1) : (-1);

						      const int minus_one_pow_j0_plus_j1_minus_one_minus_J = minus_one_pow_j0_plus_j1_minus_one*minus_one_pow_J;
						      
						      const int phase_01 = (s1 < s0) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      const int phase_23 = (s3 < s2) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      
						      const int phase = phase_01*phase_23;

						      const double inv_antisymmetry_deltas_square_hat_js_J_Zval = inv_antisymmetry_delta_01_square_hat_js_Zval*inv_antisymmetry_delta_23*(2.0*J + 1.0);
						      
						      const TYPE TBME_pp = phase*TBMEs_pp(J , s01_min , s01_max , s23_min , s23_max);
						  
						      prot_ESPEs_Hamiltonian_matrix_element_pp_part_02 += TBME_pp*prot_scalar_density_matrix_element_13*inv_antisymmetry_deltas_square_hat_js_J_Zval;
						    }}}}}}}}}}}}}
  
  add_parts (prot_ESPEs_Hamiltonian_matrices_pp_part_tab , prot_ESPEs_Hamiltonian_matrices);
}









// Calculation of the proton-neutron part of the Hamiltonian providing with proton effective single-particle energies
// ------------------------------------------------------------------------------------------------------------------
// It is \sum_{bd,J} <cd | Vpn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Nval . (2J+1)/((2ja + 1).(2jb + 1)) for fixed (a,c).
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hp(ESPE) | a> and not <a | hp(ESPE) | c>. It is done by demanding nc <= na.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::TBMEs_pn_part_prot_calc (
						 const class input_data_str &input_data ,
						 const class TBMEs_class &TBMEs_pn ,  
						 const class nucleons_data &neut_data , 
						 class nucleons_data &prot_data)
{
  const unsigned int Nval = neut_data.get_N_valence_nucleons ();

  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const unsigned int BPmin_global = TBMEs_pn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pn.get_Jmin_global ();
  const int Jmax_global = TBMEs_pn.get_Jmax_global ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_data.get_shells_quantum_numbers ();

  const unsigned int first_index = TBMEs_pn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices = neut_data.get_scalar_density_matrices ();
  
  class lj_table<class matrix<TYPE> > &prot_ESPEs_Hamiltonian_matrices = prot_data.get_ESPEs_Hamiltonian_matrices ();

  class array<class lj_table<class matrix<TYPE> > > prot_ESPEs_Hamiltonian_matrices_pn_part_tab(NUMBER_OF_THREADS);
  
  lj_matrices_parts_tab_allocate_initialize (prot_data , prot_ESPEs_Hamiltonian_matrices_pn_part_tab);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class lj_table<class matrix<TYPE> > &prot_ESPEs_Hamiltonian_matrices_pn_part = prot_ESPEs_Hamiltonian_matrices_pn_part_tab(i_thread);

      for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
	{
	  const class pair_str pair_in(s0 , s1);
		      
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

	  if (n_scat_in <= n_scat_max)
	    { 
	      const class nlj_struct &shell_s0 = shells_qn_p(s0);
	      const class nlj_struct &shell_s1 = shells_qn_n(s1);
	
	      const int n0 = shell_s0.get_n ();
	      const int l0 = shell_s0.get_l ();

	      const int n1 = shell_s1.get_n ();
	      const int l1 = shell_s1.get_l ();

	      const double j0 = shell_s0.get_j ();
	      const double j1 = shell_s1.get_j ();
		
	      const double inv_square_hat_js_Nval = Nval/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);
	
	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);			  
	      
	      const bool are_there_core_states_in  = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_n);
	      const bool are_there_hole_states_in  = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_n);
	    
	      const class matrix<TYPE> &neut_scalar_density_matrix_13 = neut_scalar_density_matrices(l1 , j1);
	    
	      class matrix<TYPE> &prot_ESPEs_Hamiltonian_matrix_pn_part_02 = prot_ESPEs_Hamiltonian_matrices_pn_part(l0 , j0);
	      
	      for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
		{
		  const class nlj_struct &shell_s2 = shells_qn_p(s2);

		  if (same_lj (shell_s0 , shell_s2))
		    {
		      const int n2 = shell_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &prot_ESPEs_Hamiltonian_matrix_element_pn_part_02 = prot_ESPEs_Hamiltonian_matrix_pn_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
			    {
			      const class pair_str pair_out(s2 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

				  if (n_scat_out <= n_scat_max)
				    {
				      const class nlj_struct &shell_s3 = shells_qn_n(s3);
			  
				      if (same_lj (shell_s1 , shell_s3))
					{			  
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {
					      const bool is_it_diagonal = (pair_in == pair_out);
		      
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;
					      
					      if (are_there_core_states && !are_there_hole_states) continue;

					      const int n3 = shell_s3.get_n ();
							      
					      const TYPE neut_scalar_density_matrix_element_13 = neut_scalar_density_matrix_13(n1 , n3);						    
					    
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pn.index_determine (J , s0 , s1 , s2 , s3);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const TYPE TBME_pn = TBMEs_pn(J , s0 , s1 , s2 , s3);

						      const double inv_square_hat_js_J_Nval = inv_square_hat_js_Nval*(2.0*J + 1.0);
						  
						      prot_ESPEs_Hamiltonian_matrix_element_pn_part_02 += TBME_pn*neut_scalar_density_matrix_element_13*inv_square_hat_js_J_Nval;
						    }}}}}}}}}}}}
    }
  
  add_parts (prot_ESPEs_Hamiltonian_matrices_pn_part_tab , prot_ESPEs_Hamiltonian_matrices);
}










// Calculation of the neutron part of the Hamiltonian providing with effective single-particle energies
// ----------------------------------------------------------------------------------------------------
// It is <c | hn | a> + \sum_{bd,J} <cd | Vnn | ab>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Nval . (2J+1)/((2ja + 1).(2jb + 1)) . sqrt(1 + delta_ab) . sqrt(1 + delta_cd) . 
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hn(ESPE) | a> and not <a | hn(ESPE) | c>. 
// It is done by demanding nc <= na. Consequently, (a,b) and (c,d) are not necessarily ordered in <cd | Vnn | ab>_J and reordering phases must be considered.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::OBMEs_TBMEs_nn_part_neut_calc ( 
						       const class input_data_str &input_data ,
						       class nucleons_data &neut_data)
{	
  const unsigned int Nval = neut_data.get_N_valence_nucleons ();

  if (Nval == 0) return;

  const int ln_max = neut_data.get_lmax ();
  
  const class lj_table<int> &nmin_lj_valence_neut_tab = neut_data.get_nmin_lj_valence_tab ();
  
  const class array<class nlj_struct> &shells_qn_n = neut_data.get_shells_quantum_numbers ();
  
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const int n_scat_max_n = neut_data.get_n_scat_max ();
  
  const enum interaction_type inter = input_data.get_inter ();
  
  const class nlj_table<unsigned int> &shells_neut_indices = neut_data.get_shells_indices ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_neut_set = neut_data.get_OBMEs_inter_set ();

  const class array<TYPE> &OBMEs_inter_neut = OBMEs_inter_neut_set(inter);
  
  class lj_table<class matrix<TYPE> > &neut_ESPEs_Hamiltonian_matrices = neut_data.get_ESPEs_Hamiltonian_matrices ();
 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int l = 0 ; l <= ln_max ; l++)
	for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	  {	
	    const class matrix<TYPE> &neut_ESPEs_Hamiltonian_matrix = neut_ESPEs_Hamiltonian_matrices(l , j);
    
	    const int nmin_lj = nmin_lj_valence_neut_tab(l , j);
  
	    const int nmax_lj = neut_ESPEs_Hamiltonian_matrix.get_dimension () - 1;

	    for (int n = nmin_lj ; n <= nmax_lj ; n++)
	      for (int np = nmin_lj ; np <= n ; np++)
		{
		  const unsigned int s = shells_neut_indices(n , l , j);
		  
		  const unsigned int sp = shells_neut_indices(np , l , j);

		  neut_ESPEs_Hamiltonian_matrix(n , np) = OBMEs_inter_neut(s , sp);
		}
	  }
    }

  if (Nval == 1) return;
  
  const class TBMEs_class &TBMEs_nn = neut_data.get_TBMEs ();
    
  const unsigned int BPmin_global = TBMEs_nn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_nn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_nn.get_Jmin_global ();
  const int Jmax_global = TBMEs_nn.get_Jmax_global ();
  
  const unsigned int first_index = TBMEs_nn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_nn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices = neut_data.get_scalar_density_matrices ();
  
  class array<class lj_table<class matrix<TYPE> > > neut_ESPEs_Hamiltonian_matrices_nn_part_tab(NUMBER_OF_THREADS);
  
  lj_matrices_parts_tab_allocate_initialize (neut_data , neut_ESPEs_Hamiltonian_matrices_nn_part_tab);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s0 = 0 ; s0 < Nn_nlj ; s0++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class lj_table<class matrix<TYPE> > &neut_ESPEs_Hamiltonian_matrices_nn_part = neut_ESPEs_Hamiltonian_matrices_nn_part_tab(i_thread);
      
      for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
	{
	  const class pair_str pair_in(s0 , s1);
	
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_n , shells_qn_n); 

	  if (n_scat_in <= n_scat_max_n)
	    {
	      const class nlj_struct &shell_s0 = shells_qn_n(s0);
	      const class nlj_struct &shell_s1 = shells_qn_n(s1);
	
	      const int n0 = shell_s0.get_n ();
	      const int l0 = shell_s0.get_l ();
	      
	      const int n1 = shell_s1.get_n ();
	      const int l1 = shell_s1.get_l ();

	      const double j0 = shell_s0.get_j ();
	      const double j1 = shell_s1.get_j ();

	      const unsigned int s01_min = min (s0 , s1);
	      const unsigned int s01_max = max (s0 , s1);
	      
	      const int minus_one_pow_j0_plus_j1_minus_one = minus_one_pow (j0 + j1 - 1);
	      
	      const double inv_antisymmetry_delta_01 = (s0 == s1) ? (M_SQRT2) : (1.0);
	
	      const double inv_antisymmetry_delta_01_square_hat_js_Nval = (inv_antisymmetry_delta_01*Nval)/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	      
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_n , shells_qn_n);

	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_n , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_n , shells_qn_n);
			
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_n , shells_qn_n);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_n , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_n , shells_qn_n);
	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_n , shells_qn_n);

	      const class matrix<TYPE> &neut_scalar_density_matrix_13 = neut_scalar_density_matrices(l1 , j1);
	    
	      class matrix<TYPE> &neut_ESPEs_Hamiltonian_matrix_nn_part_02 = neut_ESPEs_Hamiltonian_matrices_nn_part(l0 , j0);
					  
	      for (unsigned int s2 = 0 ; s2 < Nn_nlj ; s2++)
		{
		  const class nlj_struct &shell_s2 = shells_qn_n(s2);

		  if (same_lj (shell_s0 , shell_s2))
		    {
		      const int n2 = shell_s2.get_n ();

		      if (n2 <= n0)
			{
			  TYPE &neut_ESPEs_Hamiltonian_matrix_element_nn_part_02 = neut_ESPEs_Hamiltonian_matrix_nn_part_02(n0 , n2);
		      
			  for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
			    {
			      const class pair_str pair_out(s2 , s3);

			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_n , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_n , shells_qn_n);

				  if (n_scat_out <= n_scat_max_n)
				    {
				      const class nlj_struct &shell_s3 = shells_qn_n(s3);
			  
				      if (same_lj (shell_s1 , shell_s3))
					{
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_n , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_n , shells_qn_n);
				    
					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);
					  
					  if (Jmin <= Jmax)
					    {				      
					      const bool is_it_diagonal = (pair_in == pair_out);
			  
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_n , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_n , shells_qn_n);
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_n , shells_qn_n);
					      
					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_n , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);
			  
					      if (are_there_frozen_states) continue;

					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;

					      const int n3 = shell_s3.get_n ();
					  
					      const unsigned int s23_min = min (s2 , s3);
					      const unsigned int s23_max = max (s2 , s3);
					  
					      const double inv_antisymmetry_delta_23 = (s2 == s3) ? (M_SQRT2) : (1.0);
				      	
					      const TYPE neut_scalar_density_matrix_element_13 = neut_scalar_density_matrix_13(n1 , n3);
					      
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_nn.index_determine (J , s01_min , s01_max , s23_min , s23_max);
						  
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const int minus_one_pow_J = (J%2 == 0) ? (1) : (-1);

						      const int minus_one_pow_j0_plus_j1_minus_one_minus_J = minus_one_pow_j0_plus_j1_minus_one*minus_one_pow_J;
						      
						      const int phase_01 = (s1 < s0) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      const int phase_23 = (s3 < s2) ? (minus_one_pow_j0_plus_j1_minus_one_minus_J) : (1);
						      
						      const int phase = phase_01*phase_23;
					  
						      const double inv_antisymmetry_deltas_square_hat_js_J_Nval = inv_antisymmetry_delta_01_square_hat_js_Nval*inv_antisymmetry_delta_23*(2.0*J + 1.0);
						      
						      const TYPE TBME_nn = phase*TBMEs_nn(J , s01_min , s01_max , s23_min , s23_max);
						      
						      neut_ESPEs_Hamiltonian_matrix_element_nn_part_02 += TBME_nn*neut_scalar_density_matrix_element_13*inv_antisymmetry_deltas_square_hat_js_J_Nval;
						    }}}}}}}}}}}}
    }
  
  add_parts (neut_ESPEs_Hamiltonian_matrices_nn_part_tab , neut_ESPEs_Hamiltonian_matrices);
}


















// Calculation of the proton-neutron part of the Hamiltonian providing with neutron effective single-particle energies
// -------------------------------------------------------------------------------------------------------------------
// It is \sum_{bd,J} <dc | Vpn | ba>_J . <Psi | [a+(d) a~(b)]^0 | Psi> . Zval . (2J+1)/((2ja + 1).(2jb + 1)) for fixed (a,c).
// One has to pay attention to the core or valence character of (c,d) in the sum, as they must be removed for the one-body part and some of them as well for the two-body part.
// One uses symmetry, so that one calculates <c | hn(ESPE) | a> and not <a | hn(ESPE) | c>. It is done by demanding nc <= na.
// MPI/OpenMP parallelization is done here. Nodes calculate a few two-body matrix elements each. Reduction to the master process is done when all routines have been called.

void ESPEs_Hamiltonian::TBMEs_pn_part_neut_calc (
						 const class input_data_str &input_data ,
						 const class TBMEs_class &TBMEs_pn ,  
						 const class nucleons_data &prot_data , 
						 class nucleons_data &neut_data)
{
  const unsigned int Zval = prot_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const unsigned int BPmin_global = TBMEs_pn.get_BPmin_global ();
  const unsigned int BPmax_global = TBMEs_pn.get_BPmax_global ();
  
  const int Jmin_global = TBMEs_pn.get_Jmin_global ();
  const int Jmax_global = TBMEs_pn.get_Jmax_global ();
  
  const int n_scat_max = input_data.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_data.get_shells_quantum_numbers ();

  const unsigned int first_index = TBMEs_pn.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = TBMEs_pn.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices = prot_data.get_scalar_density_matrices ();
  
  class lj_table<class matrix<TYPE> > &neut_ESPEs_Hamiltonian_matrices = neut_data.get_ESPEs_Hamiltonian_matrices ();

  class array<class lj_table<class matrix<TYPE> > > neut_ESPEs_Hamiltonian_matrices_pn_part_tab(NUMBER_OF_THREADS);

  lj_matrices_parts_tab_allocate_initialize (neut_data , neut_ESPEs_Hamiltonian_matrices_pn_part_tab);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s1 = 0 ; s1 < Nn_nlj ; s1++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	
      class lj_table<class matrix<TYPE> > &neut_ESPEs_Hamiltonian_matrices_pn_part = neut_ESPEs_Hamiltonian_matrices_pn_part_tab(i_thread);

      for (unsigned int s0 = 0 ; s0 < Np_nlj ; s0++)
	{
	  const class pair_str pair_in(s0 , s1);
		      
	  const int n_scat_in = pair_in.n_scat_determine (shells_qn_p , shells_qn_n);

	  if (n_scat_in <= n_scat_max)
	    { 
	      const class nlj_struct &shell_s0 = shells_qn_p(s0);
	      const class nlj_struct &shell_s1 = shells_qn_n(s1);
	
	      const int n0 = shell_s0.get_n ();
	      const int l0 = shell_s0.get_l ();
	      
	      const int n1 = shell_s1.get_n ();
	      const int l1 = shell_s1.get_l ();

	      const double j0 = shell_s0.get_j ();
	      const double j1 = shell_s1.get_j ();
		
	      const double inv_square_hat_js_Zval = Zval/((2.0*j0 + 1.0)*(2.0*j1 + 1.0));
	
	      const unsigned int bp_in = pair_in.bp_determine (shells_qn_p , shells_qn_n);
	
	      const int Jmin_in = pair_in.Jmin_determine (shells_qn_p , shells_qn_n);
	      const int Jmax_in = pair_in.Jmax_determine (shells_qn_p , shells_qn_n);			  
	      
	      const bool are_there_core_states_in = pair_in.are_there_core_states_determine (shells_qn_p , shells_qn_n);
	      const bool are_there_hole_states_in = pair_in.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool are_there_frozen_states_in = pair_in.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
	      
	      const bool only_hole_states_in = pair_in.only_hole_states_determine (shells_qn_p , shells_qn_n);
	    
	      const class matrix<TYPE> &prot_scalar_density_matrix_02 = prot_scalar_density_matrices(l0 , j0);
	    
	      class matrix<TYPE> &neut_ESPEs_Hamiltonian_matrix_pn_part_13 = neut_ESPEs_Hamiltonian_matrices_pn_part(l1 , j1);
	      
	      for (unsigned int s3 = 0 ; s3 < Nn_nlj ; s3++)
		{
		  const class nlj_struct &shell_s3 = shells_qn_n(s3);

		  if (same_lj (shell_s1 , shell_s3))
		    {
		      const int n3 = shell_s3.get_n ();

		      if (n3 <= n1)
			{						    
			  TYPE &neut_ESPEs_Hamiltonian_matrix_element_pn_part_13 = neut_ESPEs_Hamiltonian_matrix_pn_part_13(n1 , n3);
		      
			  for (unsigned int s2 = 0 ; s2 < Np_nlj ; s2++)
			    {
			      const class pair_str pair_out(s2 , s3);
			  
			      const unsigned int bp_out = pair_out.bp_determine (shells_qn_p , shells_qn_n);

			      if ((bp_in == bp_out) && (bp_out >= BPmin_global) && (bp_out <= BPmax_global))
				{
				  const int n_scat_out = pair_out.n_scat_determine (shells_qn_p , shells_qn_n);

				  if (n_scat_out <= n_scat_max)
				    {
				      const class nlj_struct &shell_s2 = shells_qn_p(s2);
			  
				      if (same_lj (shell_s0 , shell_s2))
					{			  
					  const int Jmin_out = pair_out.Jmin_determine (shells_qn_p , shells_qn_n);
					  const int Jmax_out = pair_out.Jmax_determine (shells_qn_p , shells_qn_n);

					  const int Jmin_local = max (Jmin_in , Jmin_out);
					  const int Jmax_local = min (Jmax_in , Jmax_out);
				    
					  const int Jmin = max (Jmin_local , Jmin_global);
					  const int Jmax = min (Jmax_local , Jmax_global);

					  if (Jmin <= Jmax)
					    {
					      const bool is_it_diagonal = (pair_in == pair_out);
		      
					      const bool are_there_core_states_out = pair_out.are_there_core_states_determine (shells_qn_p , shells_qn_n);
					      const bool are_there_hole_states_out = pair_out.are_there_hole_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool are_there_frozen_states_out = pair_out.are_there_frozen_states_determine (shells_qn_p , shells_qn_n);
					      
					      const bool only_hole_states_out = pair_out.only_hole_states_determine (shells_qn_p , shells_qn_n);

					      const bool are_there_core_states   = (are_there_core_states_out   || are_there_core_states_in);
					      const bool are_there_hole_states   = (are_there_hole_states_out   || are_there_hole_states_in);
					      const bool are_there_frozen_states = (are_there_frozen_states_out || are_there_frozen_states_in);
					      
					      const bool only_hole_states = (only_hole_states_out && only_hole_states_in);

					      if (are_there_frozen_states) continue;
					      
					      if (is_it_diagonal && only_hole_states) continue;

					      if (are_there_core_states && !are_there_hole_states) continue;

					      const int n2 = shell_s2.get_n ();
				      
					      const TYPE prot_scalar_density_matrix_element_02 = prot_scalar_density_matrix_02(n0 , n2);
					    
					      for (int J = Jmin ; J <= Jmax ; J++)
						{
						  const unsigned int index = TBMEs_pn.index_determine (J , s0 , s1 , s2 , s3);
					      
						  if ((index >= first_index) && (index <= last_index))
						    {
						      const TYPE TBME_pn = TBMEs_pn(J , s0 , s1 , s2 , s3);

						      const double inv_square_hat_js_J_Zval = inv_square_hat_js_Zval*(2.0*J + 1.0);
						  
						      neut_ESPEs_Hamiltonian_matrix_element_pn_part_13 += TBME_pn*prot_scalar_density_matrix_element_02*inv_square_hat_js_J_Zval;
						    }}}}}}}}}}}}
    }
  
  add_parts (neut_ESPEs_Hamiltonian_matrices_pn_part_tab , neut_ESPEs_Hamiltonian_matrices);
}












// Calculation of the proton and neutron Hamiltonian matrices providing with effective single-particle energies
// ------------------------------------------------------------------------------------------------------------
// Protons and neutrons routines for proton, neutron and proton-neutron parts are called.
// All matrices of Hamiltonians providing with effective single-particle energies are summed and reduced after calculation of the proton, neutron and proton-neutron parts .
// As symmetry was used before, only the lower parts of matrices of Hamiltonians providing with effective single-particle energies were calculated.
// Their upper part is filled as well after calculation.

void ESPEs_Hamiltonian::prot_neut_alloc_calc (
					      const class input_data_str &input_data ,
					      const class TBMEs_class &TBMEs_pn ,  
					      class nucleons_data &prot_data , 
					      class nucleons_data &neut_data)
{
  const enum space_type space = input_data.get_space ();

  if (space != NEUTRONS_ONLY)
    {      
      ESPEs_Hamiltonian_matrices_allocate_initialize (prot_data);
      
      OBMEs_TBMEs_pp_part_prot_calc (input_data , prot_data);

      if (space == PROTONS_NEUTRONS) TBMEs_pn_part_prot_calc (input_data , TBMEs_pn , neut_data , prot_data);
	 
      class lj_table<class matrix<TYPE> > &prot_ESPEs_Hamiltonian_matrices = prot_data.get_ESPEs_Hamiltonian_matrices ();
      
#ifdef UseMPI
	
      if (is_it_MPI_parallelized)
	{
	  MPI_helper::Barrier ();

	  lj_matrices_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , prot_ESPEs_Hamiltonian_matrices);
	}
  
#endif
  
      fill_upper_part (prot_ESPEs_Hamiltonian_matrices);

      lj_matrices_core_states_handling (prot_data , prot_ESPEs_Hamiltonian_matrices);
    }

  if (space != PROTONS_ONLY)
    {      
      ESPEs_Hamiltonian_matrices_allocate_initialize (neut_data);

      OBMEs_TBMEs_nn_part_neut_calc (input_data , neut_data);
      
      if (space == PROTONS_NEUTRONS) TBMEs_pn_part_neut_calc (input_data , TBMEs_pn , prot_data , neut_data);
  
      class lj_table<class matrix<TYPE> > &neut_ESPEs_Hamiltonian_matrices = neut_data.get_ESPEs_Hamiltonian_matrices ();
  
#ifdef UseMPI
	
      if (is_it_MPI_parallelized)
	{
	  MPI_helper::Barrier ();

	  lj_matrices_MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD , neut_ESPEs_Hamiltonian_matrices);
	}
  
#endif
  
      fill_upper_part (neut_ESPEs_Hamiltonian_matrices);
      
      lj_matrices_core_states_handling (neut_data , neut_ESPEs_Hamiltonian_matrices);
    }
}




