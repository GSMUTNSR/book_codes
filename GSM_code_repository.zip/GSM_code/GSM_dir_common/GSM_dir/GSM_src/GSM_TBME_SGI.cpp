#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;

// TYPE is double or complex
// -------------------------

// TBME is for two-body matrix element
// -----------------------------------

// SGI is for Surface Gaussian Interaction
// ---------------------------------------



// Calculation of the radial one-body matrix element associated to the multipolar expansion radial form factor Vl_SGI
// ------------------------------------------------------------------------------------------------------------------
// One calculates <wf0 wf1 | Vl_SGI | wf2 wf3> where Vl_SGI is multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp).
// It is calculated in radial_integral_calc  for fixed l and in pp_nn_radial_integrals_calc, pn_radial_integrals_calc for all l.
//
// One has: <wf0 wf1 | Vl_SGI | wf2 wf3> = \int Vl_SGI(r , 2R0 - r) . wf0(r) wf1(2R0 - r) wf2(r) wf3(2R0 - r) dr, with R0 the radius of the SGI interaction.

TYPE TBME_SGI_set::radial_integral_calc (
					 const class interaction_class &inter_data , 
					 const int ll , 
					 const class spherical_state &wf0 , 
					 const class spherical_state &wf1 , 
					 const class spherical_state &wf2 , 
					 const class spherical_state &wf3)
{
  const class array<double> &w_bef_R_tab_GL = wf0.get_w_bef_R_tab_GL_SGI_MSGI ();
  
  const unsigned int N_bef_R_GL = wf0.get_N_bef_R_GL ();

  const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

  const class array<complex<double> > &wf0_bef_R_tab_GL = wf0.get_wf_bef_R_tab_GL_SGI_MSGI () , &wf1_bef_R_tab_GL = wf1.get_wf_bef_R_tab_GL_SGI_MSGI ();
  const class array<complex<double> > &wf2_bef_R_tab_GL = wf2.get_wf_bef_R_tab_GL_SGI_MSGI () , &wf3_bef_R_tab_GL = wf3.get_wf_bef_R_tab_GL_SGI_MSGI ();

  const class array<double> &Vl_SGI_tab_GL = inter_data.get_Vl_SGI_tab_GL ();

  complex<double> radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const unsigned int i_opp = N_bef_R_GL_minus_one - i;
      
      radial_integral += wf0_bef_R_tab_GL(i)*wf1_bef_R_tab_GL(i_opp)*wf2_bef_R_tab_GL(i)*wf3_bef_R_tab_GL(i_opp)*(Vl_SGI_tab_GL(ll , i)*w_bef_R_tab_GL(i));
    }
	      
#ifdef TYPEisDOUBLECOMPLEX  
  return radial_integral;
#endif
  
#ifdef TYPEisDOUBLE
  return real (radial_integral);
#endif
}

void TBME_SGI_set::pp_nn_radial_integrals_calc (
						const class baryons_data &particles_data , 
						const class interaction_class &inter_data , 
						const unsigned int s0 , 
						const unsigned int s1 , 
						const unsigned int s2 , 
						const unsigned int s3 , 
						class array<TYPE> &radial_dir_tab , 
						class array<TYPE> &radial_exc_tab)
{
  if (particles_data.get_N_valence_baryons () == 1) return;

  const class array<class spherical_state> &shells = particles_data.get_shells ();

  const class spherical_state &wf0 = shells(s0) , &wf1 = shells(s1);
  const class spherical_state &wf2 = shells(s2) , &wf3 = shells(s3);

  const int l0 = wf0.get_l () , l1 = wf1.get_l ();
  const int l2 = wf2.get_l () , l3 = wf3.get_l ();

  const int lmin_multipole_expansion_dir = max (abs (l0 - l2) , abs (l1 - l3)) , lmax_multipole_expansion_dir = min (l0 + l2 , l1 + l3);
  const int lmin_multipole_expansion_exc = max (abs (l1 - l2) , abs (l0 - l3)) , lmax_multipole_expansion_exc = min (l1 + l2 , l0 + l3);

  for (int ll = lmin_multipole_expansion_dir ; ll <= lmax_multipole_expansion_dir ; ll++)
    {
      if (((l0 + ll + l2) % 2 == 0) && ((l1 + ll + l3) % 2 == 0)) radial_dir_tab(ll) = radial_integral_calc (inter_data , ll , wf0 , wf1 , wf2 , wf3);
    }
  
  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
    {
      if (((l1 + ll + l2) % 2 == 0) && ((l0 + ll + l3) % 2 == 0)) radial_exc_tab(ll) = radial_integral_calc (inter_data , ll , wf1 , wf0 , wf2 , wf3);
    }
}

void TBME_SGI_set::pn_radial_integrals_calc (
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const class interaction_class &inter_data , 
					     const unsigned int s0 , 
					     const unsigned int s1 , 
					     const unsigned int s2 , 
					     const unsigned int s3 , 
					     class array<TYPE> &radial_dir_tab , 
					     class array<TYPE> &radial_exc_tab)
{
  const class array<class spherical_state> &shells_p = prot_Y_data.get_shells ();
  const class array<class spherical_state> &shells_n = neut_Y_data.get_shells ();

  const class spherical_state &wf0 = shells_p(s0) , &wf1 = shells_n(s1);
  const class spherical_state &wf2 = shells_p(s2) , &wf3 = shells_n(s3);

  const int l0 = wf0.get_l () , l1 = wf1.get_l ();
  const int l2 = wf2.get_l () , l3 = wf3.get_l ();

  const int lmin_multipole_expansion_dir = max (abs (l0 - l2) , abs (l1 - l3)) , lmax_multipole_expansion_dir = min (l0 + l2 , l1 + l3);  
  const int lmin_multipole_expansion_exc = max (abs (l1 - l2) , abs (l0 - l3)) , lmax_multipole_expansion_exc = min (l1 + l2 , l0 + l3);

  for (int ll = lmin_multipole_expansion_dir ; ll <= lmax_multipole_expansion_dir ; ll++)
    {
      if (((l0 + ll + l2) % 2 == 0) && ((l1 + ll + l3) % 2 == 0)) radial_dir_tab(ll) = radial_integral_calc (inter_data , ll , wf0 , wf1 , wf2 , wf3);
    }
  
  for (int ll = lmin_multipole_expansion_exc ; ll <= lmax_multipole_expansion_exc ; ll++)
    {
      if (((l1 + ll + l2) % 2 == 0) && ((l0 + ll + l3) % 2 == 0)) radial_exc_tab(ll) = radial_integral_calc (inter_data , ll , wf1 , wf0 , wf2 , wf3);
    }
}


















// Calculation of the non-antisymmetrized HO TBME coupled to J of recoil
// ---------------------------------------------------------------------
// The TBME < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J is that of the kinetic Hamiltonian coming from recoil in COSM, i.e. \sum_{i<j} pi.pj/M_core .
// It is coupled to J but not antisymmetrized.
// It is equal to zero if s0 and s2 have same parity, so that one first checks this case and zero is returned then.
// One uses the Wigner Eckhart theorem for scalar operators (see Wigner_signs.cpp) to calculate pi.pj TBMEs.
// There is a minus sign in the returned value as p = -i.hbar.grad .

TYPE TBME_SGI_set::TBME_pi_pj_J (
				 const int J , 
				 const class array<TYPE> &reduced_grad_02_tab , 
				 const class array<TYPE> &reduced_grad_13_tab , 
				 const unsigned int s0 , 
				 const unsigned int s1 , 
				 const unsigned int s2 , 
				 const unsigned int s3 , 
				 const class spherical_state &wf0 , 
				 const class spherical_state &wf1 , 
				 const class spherical_state &wf2 , 
				 const class spherical_state &wf3)
{
  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();
  
  if ((l0 + l2)%2 == 0) return 0.0;

  const TYPE reduced_grad_02 = reduced_grad_02_tab(s0 , s2);
  const TYPE reduced_grad_13 = reduced_grad_13_tab(s1 , s3);

  const double j0 = wf0.get_j () , j1 = wf1.get_j ();
  const double j2 = wf2.get_j () , j3 = wf3.get_j ();
  
  const TYPE TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_02 , reduced_grad_13);

  return TBME;
}






// Calculation of the non-antisymmetrized TBME coupled to J of SGI
// ---------------------------------------------------------------
// One has V_SGI(\vec{r},\vec{r'}) = V0_SGI(Pi,J) \sum_l (4Pi/(2l+1)) (Yl(1) . Yl(2)) Vl_SGI(r,r')
// where Vl_SGI is the multipolar expansion of the SGI interaction (see GSM_interaction_class.cpp)
// and where V0_SGI(BP,J) is a coupling constant depending on parity, the total angular momentum of the two nucleons and their isospin.
//
// One calculates here either the direct or exchange part of the TBME of V_SGI(\vec{r},\vec{r'}) for either protons only, neutrons only or proton-neutron <s2 s3 | V_MSGI | s0 s1>, summing over all multipoles.
// The recoil term induced by the COSM formalism <s2 s3 | (pi.pj)/M_core | s0 s1> is also added at the end if demanded.

TYPE TBME_SGI_set::TBME_J (
			   const bool is_there_recoil ,
			   const int J , 
			   const class interaction_class &inter_data , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class array<TYPE> &radial_TBMEs , 
			   const class array<TYPE> &reduced_grad_02_tab , 
			   const class array<TYPE> &reduced_grad_13_tab , 
			   const unsigned int s0 , 
			   const unsigned int s1 , 
			   const unsigned int s2 , 
			   const unsigned int s3 , 
			   const class spherical_state &wf0 , 
			   const class spherical_state &wf1 , 
			   const class spherical_state &wf2 , 
			   const class spherical_state &wf3)
{  

  const double j0 = wf0.get_j () , j1 = wf1.get_j ();
  const double j2 = wf2.get_j () , j3 = wf3.get_j ();

  const int l0 = wf0.get_l () , l1 = wf1.get_l ();
  const int l2 = wf2.get_l () , l3 = wf3.get_l ();

  const int lmin_multipole_expansion = max (abs (l0 - l2) , abs (l1 - l3));
  
  const int lmax_multipole_expansion = min (l0 + l2 , l1 + l3); 

  TYPE SGI_result = 0.0;
  
  for (int ll = lmin_multipole_expansion ; ll <= lmax_multipole_expansion ; ll++)
    {
      if (((l0 + ll + l2) % 2 == 0) && ((l1 + ll + l3) % 2 == 0)) SGI_result += radial_TBMEs(ll)*multipolar_expansion (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , ll , J);
    }
  
  const enum particle_type particle_0 = wf0.get_particle () , particle_1 = wf1.get_particle ();
  const enum particle_type particle_2 = wf2.get_particle () , particle_3 = wf3.get_particle ();
  
  const enum particle_type particle_0_isospin_basis = baryon_isospin_basis_determine (particle_0) , particle_1_isospin_basis = baryon_isospin_basis_determine (particle_1);
  const enum particle_type particle_2_isospin_basis = baryon_isospin_basis_determine (particle_2) , particle_3_isospin_basis = baryon_isospin_basis_determine (particle_3);

  if ((particle_0_isospin_basis != NUCLEON) || (particle_1_isospin_basis != NUCLEON) || (particle_2_isospin_basis != NUCLEON) || (particle_3_isospin_basis != NUCLEON))
    error_message_print_abort ("Only nucleons can be considered with the SGI interaction in TBME_SGI_set::TBME_J");
  
  const bool is_it_pn_dir = ((particle_0 == PROTON)  && (particle_1 == NEUTRON));
  const bool is_it_pn_exc = ((particle_0 == NEUTRON) && (particle_1 == PROTON));
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l0 + l1);
  
  SGI_result *= inter_data.Gaussian_coupling_constant (bp , J , is_it_pn_dir , is_it_pn_exc);

  if (is_there_recoil && !is_it_pn_exc) SGI_result += TBME_pi_pj_J (J , reduced_grad_02_tab , reduced_grad_13_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);

  return SGI_result;
} 





// Calculation of the antisymmetrized TBME coupled to J of SGI for protons and neutrons and proton-neutron TBME coupled to J of SGI
// ---------------------------------------------------------------------------------------------------------------------------------
// The TBME is antisymmetrized for protons only or neutrons only.
//
// If s0 != s1 and s2 != s3, the antisymmetrized TBME is equal to TBME_dir - (-1)^(j0 + j1 - J) TBME_exc, with
// its direct and exchange parts TBME_dir and TBME_exc equal to < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J and < s2 s3 | pi.pj (hbar^2 / M) | s1 s0 >_J.

// If s0 = s1 or s2 = s3 or both, one checks if J is even. If it is odd, zero is returned.
// If not, the antisymmetrized TBME is equal to 2 . (1/sqrt(1 + delta_s0_s1)) . (1/sqrt(1 + delta_s2_s3)) < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J, which is returned.
//
// The proton-neutron TBME coupled to J is not antisymmetrized but is calculated with a direct and exchange part, as one can have isospin exchange.
// Hence, it is first calculated in isospin formalism, where it is antisymmetrized, and is then considered in proton-neutron formalism, where it is not antisymmetrized.

TYPE TBME_SGI_set::TBME_J_pp_nn_antisymmetrized (
						 const bool is_there_recoil , 
						 const int J , 
						 const unsigned int s0 , 
						 const unsigned int s1 , 
						 const unsigned int s2 , 
						 const unsigned int s3 , 
						 const class array<class spherical_state> &shells , 
						 const class array<TYPE> &radial_TBMEs_dir , 
						 const class array<TYPE> &radial_TBMEs_exc , 
						 const class array<TYPE> &reduced_grad_tab , 
						 const class interaction_class &inter_data , 
						 const class multipolar_expansion_str &multipolar_expansion)
{
  const class spherical_state &wf0 = shells(s0) , &wf1 = shells(s1);
  const class spherical_state &wf2 = shells(s2) , &wf3 = shells(s3);

  if (s2 == s3)
    { 
      if (J%2 == 1) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;
      
      const double antisymmetry_norm_out = (s0 == s1) ? (M_SQRT1_2) : (1.0);
      
      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const TYPE TBME = antisymmetry_norm*TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_dir , reduced_grad_tab , reduced_grad_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);
      
      return TBME;
    }

  if (s0 == s1)
    { 
      if (J%2 == 1) return 0.0;

      const TYPE TBME = M_SQRT2*TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_dir , reduced_grad_tab , reduced_grad_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);

      return TBME;
    }

  const TYPE TBME_dir = TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_dir , reduced_grad_tab , reduced_grad_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);
  const TYPE TBME_exc = TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_exc , reduced_grad_tab , reduced_grad_tab , s1 , s0 , s2 , s3 , wf1 , wf0 , wf2 , wf3);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();
  
  const TYPE TBME = TBME_dir - minus_one_pow (j0 + j1 - J)*TBME_exc;

  return TBME;
}

TYPE TBME_SGI_set::TBME_J_pn (
			      const bool is_there_recoil , 
			      const int J , 
			      const unsigned int s0 , 
			      const unsigned int s1 , 
			      const unsigned int s2 , 
			      const unsigned int s3 , 
			      const class array<class spherical_state> &shells_p , 
			      const class array<class spherical_state> &shells_n , 
			      const class array<TYPE> &radial_TBMEs_dir , 
			      const class array<TYPE> &radial_TBMEs_exc , 
			      const class array<TYPE> &reduced_grad_p_tab , 
			      const class array<TYPE> &reduced_grad_n_tab , 
			      const class interaction_class &inter_data , 
			      const class multipolar_expansion_str &multipolar_expansion)
{
  const class spherical_state &wf0 = shells_p(s0) , &wf1 = shells_n(s1);
  const class spherical_state &wf2 = shells_p(s2) , &wf3 = shells_n(s3);

  const TYPE TBME_dir = TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_dir , reduced_grad_p_tab , reduced_grad_n_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3);
  const TYPE TBME_exc = TBME_J (is_there_recoil , J , inter_data , multipolar_expansion , radial_TBMEs_exc , reduced_grad_p_tab , reduced_grad_n_tab , s1 , s0 , s2 , s3 , wf1 , wf0 , wf2 , wf3);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();
  
  const TYPE TBME = TBME_dir - minus_one_pow (j0 + j1 - J)*TBME_exc;

  return TBME;
}


