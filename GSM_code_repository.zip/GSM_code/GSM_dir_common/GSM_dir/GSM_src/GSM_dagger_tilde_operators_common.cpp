#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// Determination of the number of protons or neutrons from the out state for operators function of a+ a~
// -----------------------------------------------------------------------------------------------------
// One counts the number of a+ a~ for protons and neutrons (for example, A_DAGGER_A_DAGGER_A_TILDE_NNP adds two neutrons and removes one proton).
// For this one can infer the number of protons and neutron in the in state from that of the out state
// See enum_struct_definitions.h and enum_struct_definitions.cpp for details and notations.
// Antisymmetrization is not done in the routines calculating partially coupled tables. It is done with the calculation of the fully coupled tables.

int dagger_tilde_operators_common::Z_IN_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int Z)
{
  switch (dagger_tilde_operator)
    {
    case A_DAGGER_A_TILDE_PP: return Z;
    case A_DAGGER_A_TILDE_NN: return Z;
    case A_DAGGER_A_TILDE_NP: return Z+1;
    case A_DAGGER_A_TILDE_PN: return Z-1;

    case A_DAGGER_A_DAGGER_PP: return Z-2; 
    case A_DAGGER_A_DAGGER_NN: return Z; 
    case A_DAGGER_A_DAGGER_PN: return Z-1;
      
    case A_TILDE_A_TILDE_PP: return Z+2; 
    case A_TILDE_A_TILDE_NN: return Z; 
    case A_TILDE_A_TILDE_PN: return Z+1; 
      
    case A_DAGGER_A_DAGGER_A_TILDE_PPP: return Z-1;
    case A_DAGGER_A_DAGGER_A_TILDE_NNN: return Z; 
    case A_DAGGER_A_DAGGER_A_TILDE_PPN: return Z-2; 
    case A_DAGGER_A_DAGGER_A_TILDE_PNN: return Z-1; 
    case A_DAGGER_A_DAGGER_A_TILDE_PNP: return Z; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNP: return Z+1;
      
    case A_DAGGER_A_TILDE_A_TILDE_PPP: return Z+1;
    case A_DAGGER_A_TILDE_A_TILDE_NNN: return Z;  
    case A_DAGGER_A_TILDE_A_TILDE_PNN: return Z-1;
    case A_DAGGER_A_TILDE_A_TILDE_NPP: return Z+2; 
    case A_DAGGER_A_TILDE_A_TILDE_PPN: return Z;       
    case A_DAGGER_A_TILDE_A_TILDE_NPN: return Z+1;

    case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return Z-3; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return Z; 
    case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return Z-2; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return Z-1;
      
    case A_TILDE_A_TILDE_A_TILDE_PPP: return Z+3; 
    case A_TILDE_A_TILDE_A_TILDE_NNN: return Z; 
    case A_TILDE_A_TILDE_A_TILDE_PPN: return Z+2; 
    case A_TILDE_A_TILDE_A_TILDE_NNP: return Z+1;
  
    case P_RDM_PP: return Z+2;
    case P_RDM_NN: return Z;
    case P_RDM_PN: return Z+1;

    case Q_RDM_PP: return Z-2;
    case Q_RDM_NN: return Z;
    case Q_RDM_PN: return Z-1;

    case G_RDM_PP: return Z;
    case G_RDM_NN: return Z;
    case G_RDM_PN: return Z+1;
    case G_RDM_NP: return Z-1;
  
    case T1_1_RDM_PPP: return Z+3;
    case T1_1_RDM_NNN: return Z;
    case T1_1_RDM_PPN: return Z+2;
    case T1_1_RDM_NNP: return Z+1;
      
    case T1_2_RDM_PPP: return Z-3;
    case T1_2_RDM_NNN: return Z;
    case T1_2_RDM_PPN: return Z-2;
    case T1_2_RDM_NNP: return Z-1;
  
    case T2_1_RDM_PPP: return Z+1;
    case T2_1_RDM_NNN: return Z;
    case T2_1_RDM_PPN: return Z+2;
    case T2_1_RDM_NNP: return Z-1;
    case T2_1_RDM_PNN: return Z+1;
    case T2_1_RDM_PNP: return Z;
      
    case T2_2_RDM_PPP: return Z-1;
    case T2_2_RDM_NNN: return Z;
    case T2_2_RDM_PPN: return Z-2;
    case T2_2_RDM_NNP: return Z+1;
    case T2_2_RDM_PNN: return Z-1;
    case T2_2_RDM_PNP: return Z;
      
    default: error_message_print_abort ("No operator recognized or only used externally in dagger_tilde_operators_common::Z_IN_calc");
    }

  return NADA;
}


int dagger_tilde_operators_common::N_IN_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int N)
{
  switch (dagger_tilde_operator)
    {
    case A_DAGGER_A_TILDE_PP: return N;
    case A_DAGGER_A_TILDE_NN: return N;
    case A_DAGGER_A_TILDE_NP: return N-1;
    case A_DAGGER_A_TILDE_PN: return N+1;

    case A_TILDE_A_TILDE_PP: return N; 
    case A_TILDE_A_TILDE_NN: return N+2; 
    case A_TILDE_A_TILDE_PN: return N+1; 

    case A_DAGGER_A_DAGGER_PP: return N; 
    case A_DAGGER_A_DAGGER_NN: return N-2; 
    case A_DAGGER_A_DAGGER_PN: return N-1; 

    case A_DAGGER_A_DAGGER_A_TILDE_PPP: return N; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNN: return N-1;
    case A_DAGGER_A_DAGGER_A_TILDE_PPN: return N+1;  
    case A_DAGGER_A_DAGGER_A_TILDE_PNN: return N;
    case A_DAGGER_A_DAGGER_A_TILDE_PNP: return N-1; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNP: return N-2;
      
    case A_DAGGER_A_TILDE_A_TILDE_PPP: return N;
    case A_DAGGER_A_TILDE_A_TILDE_NNN: return N+1;
    case A_DAGGER_A_TILDE_A_TILDE_PNN: return N+2;  
    case A_DAGGER_A_TILDE_A_TILDE_NPP: return N-1; 
    case A_DAGGER_A_TILDE_A_TILDE_PPN: return N+1;
    case A_DAGGER_A_TILDE_A_TILDE_NPN: return N;

    case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return N; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return N-3; 
    case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return N-1; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return N-2;
      
    case A_TILDE_A_TILDE_A_TILDE_PPP: return N; 
    case A_TILDE_A_TILDE_A_TILDE_NNN: return N+3; 
    case A_TILDE_A_TILDE_A_TILDE_PPN: return N+1; 
    case A_TILDE_A_TILDE_A_TILDE_NNP: return N+2;
  
    case P_RDM_PP: return N;
    case P_RDM_NN: return N+2;
    case P_RDM_PN: return N+1;

    case Q_RDM_PP: return N;
    case Q_RDM_NN: return N-2;
    case Q_RDM_PN: return N-1;

    case G_RDM_PP: return N;
    case G_RDM_NN: return N;
    case G_RDM_PN: return N-1;
    case G_RDM_NP: return N+1;
  
    case T1_1_RDM_PPP: return N;
    case T1_1_RDM_NNN: return N+3;
    case T1_1_RDM_PPN: return N+1;
    case T1_1_RDM_NNP: return N+2;
      
    case T1_2_RDM_PPP: return N;
    case T1_2_RDM_NNN: return N-3;
    case T1_2_RDM_PPN: return N-1;
    case T1_2_RDM_NNP: return N-2;
  
    case T2_1_RDM_PPP: return N;
    case T2_1_RDM_NNN: return N+1;
    case T2_1_RDM_PPN: return N-1;
    case T2_1_RDM_NNP: return N+2;
    case T2_1_RDM_PNN: return N;
    case T2_1_RDM_PNP: return N+1;
      
    case T2_2_RDM_PPP: return N;
    case T2_2_RDM_NNN: return N-1;
    case T2_2_RDM_PPN: return N+1;
    case T2_2_RDM_NNP: return N-2;
    case T2_2_RDM_PNN: return N;
    case T2_2_RDM_PNP: return N-1;
      
    default: error_message_print_abort ("No operator recognized or only used externally in dagger_tilde_operators_common::N_IN_calc");
    }

  return NADA;
}




int dagger_tilde_operators_common::Z_OUT_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int Z)
{
  switch (dagger_tilde_operator)
    {
    case A_DAGGER_A_TILDE_PP: return Z;
    case A_DAGGER_A_TILDE_NN: return Z;
    case A_DAGGER_A_TILDE_NP: return Z+1;
    case A_DAGGER_A_TILDE_PN: return Z+1;

    case A_DAGGER_A_DAGGER_PP: return Z+2; 
    case A_DAGGER_A_DAGGER_NN: return Z; 
    case A_DAGGER_A_DAGGER_PN: return Z+1;
      
    case A_TILDE_A_TILDE_PP: return Z-2; 
    case A_TILDE_A_TILDE_NN: return Z; 
    case A_TILDE_A_TILDE_PN: return Z-1; 
      
    case A_DAGGER_A_DAGGER_A_TILDE_PPP: return Z+1;
    case A_DAGGER_A_DAGGER_A_TILDE_NNN: return Z; 
    case A_DAGGER_A_DAGGER_A_TILDE_PPN: return Z+2; 
    case A_DAGGER_A_DAGGER_A_TILDE_PNN: return Z+1; 
    case A_DAGGER_A_DAGGER_A_TILDE_PNP: return Z; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNP: return Z-1;
      
    case A_DAGGER_A_TILDE_A_TILDE_PPP: return Z-1;
    case A_DAGGER_A_TILDE_A_TILDE_NNN: return Z;  
    case A_DAGGER_A_TILDE_A_TILDE_PNN: return Z+1;
    case A_DAGGER_A_TILDE_A_TILDE_NPP: return Z-2; 
    case A_DAGGER_A_TILDE_A_TILDE_PPN: return Z;       
    case A_DAGGER_A_TILDE_A_TILDE_NPN: return Z-1;

    case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return Z+3; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return Z; 
    case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return Z+2; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return Z+1;
      
    case A_TILDE_A_TILDE_A_TILDE_PPP: return Z-3; 
    case A_TILDE_A_TILDE_A_TILDE_NNN: return Z; 
    case A_TILDE_A_TILDE_A_TILDE_PPN: return Z-2; 
    case A_TILDE_A_TILDE_A_TILDE_NNP: return Z-1;
  
    case P_RDM_PP: return Z-2;
    case P_RDM_NN: return Z;
    case P_RDM_PN: return Z-1;

    case Q_RDM_PP: return Z+2;
    case Q_RDM_NN: return Z;
    case Q_RDM_PN: return Z+1;

    case G_RDM_PP: return Z;
    case G_RDM_NN: return Z;
    case G_RDM_PN: return Z-1;
    case G_RDM_NP: return Z+1;
  
    case T1_1_RDM_PPP: return Z-3;
    case T1_1_RDM_NNN: return Z;
    case T1_1_RDM_PPN: return Z-2;
    case T1_1_RDM_NNP: return Z-1;
      
    case T1_2_RDM_PPP: return Z+3;
    case T1_2_RDM_NNN: return Z;
    case T1_2_RDM_PPN: return Z+2;
    case T1_2_RDM_NNP: return Z+1;
  
    case T2_1_RDM_PPP: return Z-1;
    case T2_1_RDM_NNN: return Z;
    case T2_1_RDM_PPN: return Z-2;
    case T2_1_RDM_NNP: return Z+1;
    case T2_1_RDM_PNN: return Z-1;
    case T2_1_RDM_PNP: return Z;
      
    case T2_2_RDM_PPP: return Z+1;
    case T2_2_RDM_NNN: return Z;
    case T2_2_RDM_PPN: return Z+2;
    case T2_2_RDM_NNP: return Z-1;
    case T2_2_RDM_PNN: return Z+1;
    case T2_2_RDM_PNP: return Z;
      
    default: error_message_print_abort ("No operator recognized or only used externally in dagger_tilde_operators_common::Z_OUT_calc");
    }

  return NADA;
}


int dagger_tilde_operators_common::N_OUT_calc (const enum dagger_tilde_operator_type dagger_tilde_operator , const int N)
{
  switch (dagger_tilde_operator)
    {
    case A_DAGGER_A_TILDE_PP: return N;
    case A_DAGGER_A_TILDE_NN: return N;
    case A_DAGGER_A_TILDE_NP: return N+1;
    case A_DAGGER_A_TILDE_PN: return N-1;

    case A_TILDE_A_TILDE_PP: return N; 
    case A_TILDE_A_TILDE_NN: return N-2; 
    case A_TILDE_A_TILDE_PN: return N-1; 

    case A_DAGGER_A_DAGGER_PP: return N; 
    case A_DAGGER_A_DAGGER_NN: return N+2; 
    case A_DAGGER_A_DAGGER_PN: return N+1; 

    case A_DAGGER_A_DAGGER_A_TILDE_PPP: return N; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNN: return N+1;
    case A_DAGGER_A_DAGGER_A_TILDE_PPN: return N-1;  
    case A_DAGGER_A_DAGGER_A_TILDE_PNN: return N;
    case A_DAGGER_A_DAGGER_A_TILDE_PNP: return N+1; 
    case A_DAGGER_A_DAGGER_A_TILDE_NNP: return N+2;
      
    case A_DAGGER_A_TILDE_A_TILDE_PPP: return N;
    case A_DAGGER_A_TILDE_A_TILDE_NNN: return N-1;
    case A_DAGGER_A_TILDE_A_TILDE_PNN: return N-2;  
    case A_DAGGER_A_TILDE_A_TILDE_NPP: return N+1; 
    case A_DAGGER_A_TILDE_A_TILDE_PPN: return N-1;
    case A_DAGGER_A_TILDE_A_TILDE_NPN: return N;

    case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return N; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return N+3; 
    case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return N+1; 
    case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return N+2;
      
    case A_TILDE_A_TILDE_A_TILDE_PPP: return N; 
    case A_TILDE_A_TILDE_A_TILDE_NNN: return N-3; 
    case A_TILDE_A_TILDE_A_TILDE_PPN: return N-1; 
    case A_TILDE_A_TILDE_A_TILDE_NNP: return N-2;
  
    case P_RDM_PP: return N;
    case P_RDM_NN: return N-2;
    case P_RDM_PN: return N-1;

    case Q_RDM_PP: return N;
    case Q_RDM_NN: return N+2;
    case Q_RDM_PN: return N+1;

    case G_RDM_PP: return N;
    case G_RDM_NN: return N;
    case G_RDM_PN: return N+1;
    case G_RDM_NP: return N-1;
  
    case T1_1_RDM_PPP: return N;
    case T1_1_RDM_NNN: return N-3;
    case T1_1_RDM_PPN: return N-1;
    case T1_1_RDM_NNP: return N-2;
      
    case T1_2_RDM_PPP: return N;
    case T1_2_RDM_NNN: return N+3;
    case T1_2_RDM_PPN: return N+1;
    case T1_2_RDM_NNP: return N+2;
  
    case T2_1_RDM_PPP: return N;
    case T2_1_RDM_NNN: return N-1;
    case T2_1_RDM_PPN: return N+1;
    case T2_1_RDM_NNP: return N-2;
    case T2_1_RDM_PNN: return N;
    case T2_1_RDM_PNP: return N-1;
      
    case T2_2_RDM_PPP: return N;
    case T2_2_RDM_NNN: return N+1;
    case T2_2_RDM_PPN: return N-1;
    case T2_2_RDM_NNP: return N+2;
    case T2_2_RDM_PNN: return N;
    case T2_2_RDM_PNP: return N+1;
      
    default: error_message_print_abort ("No operator recognized or only used externally in dagger_tilde_operators_common::N_OUT_calc");
    }

  return NADA;
}








// Determination of the proton or neutron class associated to a+/~(a,b,c)
// ----------------------------------------------------------------------
// For example, A_DAGGER_A_DAGGER_A_TILDE_NNP gives neut_data for a+(a), a+(b) and prot_data for a(c).
// See enum_struct_definitions.h and enum_struct_definitions.cpp for details and notations.

const class nucleons_data & dagger_tilde_operators_common::data_find (
								      const enum dagger_tilde_operator_type dagger_tilde_operator ,
								      const unsigned int place_index , 
								      const class nucleons_data &prot_data , 
								      const class nucleons_data &neut_data)
{
  switch (place_index)
    {
    case 0:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_TILDE_PP: return prot_data;
	  case A_DAGGER_A_TILDE_NN: return neut_data;
	  case A_DAGGER_A_TILDE_NP: return neut_data;
	  case A_DAGGER_A_TILDE_PN: return prot_data;

	  case A_DAGGER_A_DAGGER_PP: return prot_data; 
	  case A_DAGGER_A_DAGGER_NN: return neut_data; 
	  case A_DAGGER_A_DAGGER_PN: return prot_data; 

	  case A_TILDE_A_TILDE_PP: return prot_data; 
	  case A_TILDE_A_TILDE_NN: return neut_data; 
	  case A_TILDE_A_TILDE_PN: return prot_data; 
      
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return neut_data; 
      
	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return prot_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return neut_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return prot_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return neut_data;

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return neut_data; 

	  case A_TILDE_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return prot_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return neut_data;
  
	  case P_RDM_PP: return prot_data;
	  case P_RDM_NN: return neut_data;
	  case P_RDM_PN: return prot_data;
	    
	  case Q_RDM_PP: return prot_data;
	  case Q_RDM_NN: return neut_data;
	  case Q_RDM_PN: return prot_data;
	    
	  case G_RDM_PP: return prot_data;
	  case G_RDM_NN: return neut_data;
	  case G_RDM_PN: return prot_data;
	  case G_RDM_NP: return neut_data;
    
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return prot_data;
	  case T1_1_RDM_NNP: return neut_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return neut_data;
	  case T1_2_RDM_NNP: return prot_data;
	    
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return prot_data;
	  case T2_1_RDM_NNP: return neut_data;
	  case T2_1_RDM_PNN: return prot_data;
	  case T2_1_RDM_PNP: return prot_data;
            
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return neut_data;
	  case T2_2_RDM_NNP: return prot_data;
	  case T2_2_RDM_PNN: return neut_data;
	  case T2_2_RDM_PNP: return prot_data;
    
	  default: break;
	  }
      } break;

    case 1:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_TILDE_PP: return prot_data;
	  case A_DAGGER_A_TILDE_NN: return neut_data;
	  case A_DAGGER_A_TILDE_NP: return prot_data;
	  case A_DAGGER_A_TILDE_PN: return neut_data;

	  case A_DAGGER_A_DAGGER_PP: return prot_data; 
	  case A_DAGGER_A_DAGGER_NN: return neut_data; 
	  case A_DAGGER_A_DAGGER_PN: return neut_data; 

	  case A_TILDE_A_TILDE_PP: return prot_data; 
	  case A_TILDE_A_TILDE_NN: return neut_data; 
	  case A_TILDE_A_TILDE_PN: return neut_data;
      
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return neut_data;
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return prot_data;  
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return neut_data;
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return neut_data; 

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return neut_data;

	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return prot_data;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return prot_data;
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return neut_data;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return prot_data;

	  case A_TILDE_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return prot_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return neut_data;

	  case P_RDM_PP: return prot_data;
	  case P_RDM_NN: return neut_data;
	  case P_RDM_PN: return neut_data;
	    
	  case Q_RDM_PP: return prot_data;
	  case Q_RDM_NN: return neut_data;
	  case Q_RDM_PN: return neut_data;
	    
	  case G_RDM_PP: return prot_data;
	  case G_RDM_NN: return neut_data;
	  case G_RDM_PN: return neut_data;
	  case G_RDM_NP: return prot_data;
                
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return prot_data;
	  case T1_1_RDM_NNP: return neut_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return prot_data;
	  case T1_2_RDM_NNP: return neut_data;
	    
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return prot_data;
	  case T2_1_RDM_NNP: return neut_data;
	  case T2_1_RDM_PNN: return neut_data;
	  case T2_1_RDM_PNP: return neut_data;
      
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return prot_data;
	  case T2_2_RDM_NNP: return neut_data;
	  case T2_2_RDM_PNN: return neut_data;
	  case T2_2_RDM_PNP: return neut_data;
                  
	  default: break;
	  }
      } break;
      
    case 2:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return neut_data;
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return neut_data;  
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return neut_data;
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return prot_data;
      
	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return neut_data;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return prot_data;
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return neut_data;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return neut_data;

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return prot_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return neut_data; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return prot_data;
      
	  case A_TILDE_A_TILDE_A_TILDE_PPP: return prot_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return neut_data; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return neut_data; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return prot_data;
        
	  case P_RDM_PP: return prot_data;
	  case P_RDM_NN: return neut_data;
	  case P_RDM_PN: return neut_data;
	    
	  case Q_RDM_PP: return prot_data;
	  case Q_RDM_NN: return neut_data;
	  case Q_RDM_PN: return neut_data;
	    
	  case G_RDM_PP: return prot_data;
	  case G_RDM_NN: return neut_data;
	  case G_RDM_PN: return neut_data;
	  case G_RDM_NP: return prot_data;
	                  
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return neut_data;
	  case T1_1_RDM_NNP: return prot_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return prot_data;
	  case T1_2_RDM_NNP: return neut_data;
	    
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return neut_data;
	  case T2_1_RDM_NNP: return prot_data;
	  case T2_1_RDM_PNN: return neut_data;
	  case T2_1_RDM_PNP: return prot_data;
      
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return prot_data;
	  case T2_2_RDM_NNP: return neut_data;
	  case T2_2_RDM_PNN: return prot_data;
	  case T2_2_RDM_PNP: return prot_data;
                        
	  default: break;
	  }
      } break;
      
    case 3:
      {
	switch (dagger_tilde_operator)
	  {
	  case P_RDM_PP: return prot_data;
	  case P_RDM_NN: return neut_data;
	  case P_RDM_PN: return prot_data;
	    
	  case Q_RDM_PP: return prot_data;
	  case Q_RDM_NN: return neut_data;
	  case Q_RDM_PN: return prot_data;
	    
	  case G_RDM_PP: return prot_data;
	  case G_RDM_NN: return neut_data;
	  case G_RDM_PN: return prot_data;
	  case G_RDM_NP: return neut_data;
  
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return neut_data;
	  case T1_1_RDM_NNP: return prot_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return prot_data;
	  case T1_2_RDM_NNP: return neut_data;
  
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return neut_data;
	  case T2_1_RDM_NNP: return prot_data;
	  case T2_1_RDM_PNN: return neut_data;
	  case T2_1_RDM_PNP: return prot_data;
            
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return prot_data;
	  case T2_2_RDM_NNP: return neut_data;
	  case T2_2_RDM_PNN: return prot_data;
	  case T2_2_RDM_PNP: return prot_data;
    
	  default: break;
	  }
      } break;

    case 4:
      {
	switch (dagger_tilde_operator)
	  {              
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return prot_data;
	  case T1_1_RDM_NNP: return neut_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return prot_data;
	  case T1_2_RDM_NNP: return neut_data;
	    
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return prot_data;
	  case T2_1_RDM_NNP: return neut_data;
	  case T2_1_RDM_PNN: return neut_data;
	  case T2_1_RDM_PNP: return neut_data;
      
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return prot_data;
	  case T2_2_RDM_NNP: return neut_data;
	  case T2_2_RDM_PNN: return neut_data;
	  case T2_2_RDM_PNP: return neut_data;
                  
	  default: break;
	  }
      } break;
      
    case 5:
      {
	switch (dagger_tilde_operator)
	  {              
	  case T1_1_RDM_PPP: return prot_data;
	  case T1_1_RDM_NNN: return neut_data;
	  case T1_1_RDM_PPN: return prot_data;
	  case T1_1_RDM_NNP: return neut_data;
      
	  case T1_2_RDM_PPP: return prot_data;
	  case T1_2_RDM_NNN: return neut_data;
	  case T1_2_RDM_PPN: return neut_data;
	  case T1_2_RDM_NNP: return prot_data;
	    
	  case T2_1_RDM_PPP: return prot_data;
	  case T2_1_RDM_NNN: return neut_data;
	  case T2_1_RDM_PPN: return prot_data;
	  case T2_1_RDM_NNP: return neut_data;
	  case T2_1_RDM_PNN: return prot_data;
	  case T2_1_RDM_PNP: return prot_data;
      
	  case T2_2_RDM_PPP: return prot_data;
	  case T2_2_RDM_NNN: return neut_data;
	  case T2_2_RDM_PPN: return neut_data;
	  case T2_2_RDM_NNP: return prot_data;
	  case T2_2_RDM_PNN: return neut_data;
	  case T2_2_RDM_PNP: return prot_data;
                        
	  default: break;
	  }
      } break;
      
    default: break;
    }
            
  return neut_data;
}




// Determination of the Slater determinant SDp or SDn associated to a+/~(a,b,c)
// ----------------------------------------------------------------------------
// For example, A_DAGGER_A_DAGGER_A_TILDE_NNP gives SDn for a+(a), a+(b) and SDp for a(c).
// See enum_struct_definitions.h and enum_struct_definitions.cpp for details and notations.

const class Slater_determinant & dagger_tilde_operators_common::SD_find (
									 const enum dagger_tilde_operator_type dagger_tilde_operator ,
									 const unsigned int place_index , 
									 const class Slater_determinant &SDp , 
									 const class Slater_determinant &SDn)
{
  switch (place_index)
    {
    case 0:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_TILDE_PP: return SDp;
	  case A_DAGGER_A_TILDE_NN: return SDn;
	  case A_DAGGER_A_TILDE_NP: return SDn;
	  case A_DAGGER_A_TILDE_PN: return SDp;

	  case A_DAGGER_A_DAGGER_PP: return SDp; 
	  case A_DAGGER_A_DAGGER_NN: return SDn; 
	  case A_DAGGER_A_DAGGER_PN: return SDp; 

	  case A_TILDE_A_TILDE_PP: return SDp; 
	  case A_TILDE_A_TILDE_NN: return SDn; 
	  case A_TILDE_A_TILDE_PN: return SDp; 
      
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return SDn; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return SDn; 
      
	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return SDp; 
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return SDn; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return SDp; 
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return SDn;

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return SDn; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return SDp; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return SDn; 

	  case A_TILDE_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return SDp; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return SDn;
  
	  case P_RDM_PP: return SDp;
	  case P_RDM_NN: return SDn;
	  case P_RDM_PN: return SDp;
	    
	  case Q_RDM_PP: return SDp;
	  case Q_RDM_NN: return SDn;
	  case Q_RDM_PN: return SDp;
	    
	  case G_RDM_PP: return SDp;
	  case G_RDM_NN: return SDn;
	  case G_RDM_PN: return SDp;
	  case G_RDM_NP: return SDn;
    
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDp;
	  case T1_1_RDM_NNP: return SDn;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDn;
	  case T1_2_RDM_NNP: return SDp;
	    
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDp;
	  case T2_1_RDM_NNP: return SDn;
	  case T2_1_RDM_PNN: return SDp;
	  case T2_1_RDM_PNP: return SDp;
            
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDn;
	  case T2_2_RDM_NNP: return SDp;
	  case T2_2_RDM_PNN: return SDn;
	  case T2_2_RDM_PNP: return SDp;
    
	  default: break;
	  }
      } break;

    case 1:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_TILDE_PP: return SDp;
	  case A_DAGGER_A_TILDE_NN: return SDn;
	  case A_DAGGER_A_TILDE_NP: return SDp;
	  case A_DAGGER_A_TILDE_PN: return SDn;

	  case A_DAGGER_A_DAGGER_PP: return SDp; 
	  case A_DAGGER_A_DAGGER_NN: return SDn; 
	  case A_DAGGER_A_DAGGER_PN: return SDn; 

	  case A_TILDE_A_TILDE_PP: return SDp; 
	  case A_TILDE_A_TILDE_NN: return SDn; 
	  case A_TILDE_A_TILDE_PN: return SDn;
      
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return SDn;
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return SDp;  
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return SDn;
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return SDn; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return SDn; 

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return SDn; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return SDp; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return SDn;

	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return SDp;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return SDp;
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return SDn;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return SDp;

	  case A_TILDE_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return SDp; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return SDn;

	  case P_RDM_PP: return SDp;
	  case P_RDM_NN: return SDn;
	  case P_RDM_PN: return SDn;
	    
	  case Q_RDM_PP: return SDp;
	  case Q_RDM_NN: return SDn;
	  case Q_RDM_PN: return SDn;
	    
	  case G_RDM_PP: return SDp;
	  case G_RDM_NN: return SDn;
	  case G_RDM_PN: return SDn;
	  case G_RDM_NP: return SDp;
                
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDp;
	  case T1_1_RDM_NNP: return SDn;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDp;
	  case T1_2_RDM_NNP: return SDn;
	    
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDp;
	  case T2_1_RDM_NNP: return SDn;
	  case T2_1_RDM_PNN: return SDn;
	  case T2_1_RDM_PNP: return SDn;
      
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDp;
	  case T2_2_RDM_NNP: return SDn;
	  case T2_2_RDM_PNN: return SDn;
	  case T2_2_RDM_PNP: return SDn;
                  
	  default: break;
	  }
      } break;
      
    case 2:
      {
	switch (dagger_tilde_operator)
	  {
	  case A_DAGGER_A_DAGGER_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNN: return SDn;
	  case A_DAGGER_A_DAGGER_A_TILDE_PPN: return SDn;  
	  case A_DAGGER_A_DAGGER_A_TILDE_PNN: return SDn;
	  case A_DAGGER_A_DAGGER_A_TILDE_PNP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_TILDE_NNP: return SDp;
      
	  case A_DAGGER_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_DAGGER_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_DAGGER_A_TILDE_A_TILDE_PPN: return SDn;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPP: return SDp;
	  case A_DAGGER_A_TILDE_A_TILDE_PNN: return SDn;  
	  case A_DAGGER_A_TILDE_A_TILDE_NPN: return SDn;

	  case A_DAGGER_A_DAGGER_A_DAGGER_PPP: return SDp; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNN: return SDn; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_PPN: return SDn; 
	  case A_DAGGER_A_DAGGER_A_DAGGER_NNP: return SDp;
      
	  case A_TILDE_A_TILDE_A_TILDE_PPP: return SDp; 
	  case A_TILDE_A_TILDE_A_TILDE_NNN: return SDn; 
	  case A_TILDE_A_TILDE_A_TILDE_PPN: return SDn; 
	  case A_TILDE_A_TILDE_A_TILDE_NNP: return SDp;
        
	  case P_RDM_PP: return SDp;
	  case P_RDM_NN: return SDn;
	  case P_RDM_PN: return SDn;
	    
	  case Q_RDM_PP: return SDp;
	  case Q_RDM_NN: return SDn;
	  case Q_RDM_PN: return SDn;
	    
	  case G_RDM_PP: return SDp;
	  case G_RDM_NN: return SDn;
	  case G_RDM_PN: return SDn;
	  case G_RDM_NP: return SDp;
	                  
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDn;
	  case T1_1_RDM_NNP: return SDn;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDp;
	  case T1_2_RDM_NNP: return SDn;
	    
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDn;
	  case T2_1_RDM_NNP: return SDp;
	  case T2_1_RDM_PNN: return SDn;
	  case T2_1_RDM_PNP: return SDp;
      
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDp;
	  case T2_2_RDM_NNP: return SDn;
	  case T2_2_RDM_PNN: return SDp;
	  case T2_2_RDM_PNP: return SDp;
                        
	  default: break;
	  }
      } break;
      
    case 3:
      {
	switch (dagger_tilde_operator)
	  {
	  case P_RDM_PP: return SDp;
	  case P_RDM_NN: return SDn;
	  case P_RDM_PN: return SDp;
	    
	  case Q_RDM_PP: return SDp;
	  case Q_RDM_NN: return SDn;
	  case Q_RDM_PN: return SDp;
	    
	  case G_RDM_PP: return SDp;
	  case G_RDM_NN: return SDn;
	  case G_RDM_PN: return SDp;
	  case G_RDM_NP: return SDn;
  
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDn;
	  case T1_1_RDM_NNP: return SDp;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDp;
	  case T1_2_RDM_NNP: return SDn;
  
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDn;
	  case T2_1_RDM_NNP: return SDp;
	  case T2_1_RDM_PNN: return SDn;
	  case T2_1_RDM_PNP: return SDp;
            
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDp;
	  case T2_2_RDM_NNP: return SDn;
	  case T2_2_RDM_PNN: return SDp;
	  case T2_2_RDM_PNP: return SDp;
    
	  default: break;
	  }
      } break;

    case 4:
      {
	switch (dagger_tilde_operator)
	  {              
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDp;
	  case T1_1_RDM_NNP: return SDn;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDp;
	  case T1_2_RDM_NNP: return SDn;
	    
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDp;
	  case T2_1_RDM_NNP: return SDn;
	  case T2_1_RDM_PNN: return SDn;
	  case T2_1_RDM_PNP: return SDn;
      
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDp;
	  case T2_2_RDM_NNP: return SDn;
	  case T2_2_RDM_PNN: return SDn;
	  case T2_2_RDM_PNP: return SDn;
                  
	  default: break;
	  }
      } break;
      
    case 5:
      {
	switch (dagger_tilde_operator)
	  {              
	  case T1_1_RDM_PPP: return SDp;
	  case T1_1_RDM_NNN: return SDn;
	  case T1_1_RDM_PPN: return SDp;
	  case T1_1_RDM_NNP: return SDn;
      
	  case T1_2_RDM_PPP: return SDp;
	  case T1_2_RDM_NNN: return SDn;
	  case T1_2_RDM_PPN: return SDn;
	  case T1_2_RDM_NNP: return SDp;
	    
	  case T2_1_RDM_PPP: return SDp;
	  case T2_1_RDM_NNN: return SDn;
	  case T2_1_RDM_PPN: return SDp;
	  case T2_1_RDM_NNP: return SDn;
	  case T2_1_RDM_PNN: return SDp;
	  case T2_1_RDM_PNP: return SDp;
      
	  case T2_2_RDM_PPP: return SDp;
	  case T2_2_RDM_NNN: return SDn;
	  case T2_2_RDM_PPN: return SDn;
	  case T2_2_RDM_NNP: return SDp;
	  case T2_2_RDM_PNN: return SDn;
	  case T2_2_RDM_PNP: return SDp;
                        
	  default: break;
	  }
      } break;
      
    default: break;
    }
  
  return SDn;
}













// Calculation of reducing terms for the operator function of coupled a+ a~ operators
// ----------------------------------------------------------------------------------
// The a+ a~ operators are coupled to K and MK. To reduce unreduced matrix elements, one divides them by (-1)^(J_OUT - M_OUT) . Wigner_3j (J_OUT , K , J_IN , -M_OUT , MK , M_IN)
// The inverse of the coefficients are calculated here.

void dagger_tilde_operators_common::K_reducing_terms_calc (
							   const double J_IN , 
							   const double J_OUT , 
							   const double M_IN , 
							   const double M_OUT ,
							   class array<double> &K_reducing_terms)
{
  const int K_number_PSI = K_reducing_terms.dimension (0);

  const double Kmin_PSI = abs (J_IN - J_OUT);

  const double MK = M_OUT - M_IN;

  const int reducing_phase = minus_one_pow (J_OUT - M_OUT);

  for (int iK_PSI = 0 ; iK_PSI < K_number_PSI ; iK_PSI++)
    {
      const double K = iK_PSI + Kmin_PSI;
      
      K_reducing_terms(iK_PSI) = reducing_phase/Wigner_3j (J_OUT , K , J_IN , -M_OUT , MK , M_IN);
    }
}






// Calculation of reduced matrix elements for the operator function of coupled a+ a~ operators from uncoupled a+ a~ operator matrix elements
// -----------------------------------------------------------------------------------------------------------------------------------------
// One first calculates uncoupled a+ a~ operator matrix elements. They are coupled and reduced with Clebsch-Gordan coefficients and reducing terms (see above).
// One has [a+ a~]^K or [[a+ a~+]^L a~]^K types of couplings, i.e. two dagger and two tilde operators are coupled to L and the rest is coupled to K.
// Delta factors of the form sqrt(1 + delta_ab) are considered at the end of the calculation.
// 
// For RDM operators, dagger/tilde in routines relate to the last coupled operators, for example they relate to [a~[a] a~[b]]^K if one considers [[a+[a'] a+[b']]^K [a~[a] a~[b]]^K]^{00}
// For example, G[pn] = <PSI | a+(p) a~(n) a+(n) a~(p) | PSI>. Then, one considers  a+(n) a~(p) | PSI>, so that the a particle is dagger and the b particle is tilde.
// One must then understand cd as ab and def as abc in the following routines (see definition of dagger_tilde_operator_type).

void dagger_tilde_operators_common::two_body_K_table_from_MK_table_calc (
									 const double J_IN , 
									 const double J_OUT , 
									 const double M_IN , 
									 const double M_OUT , 
									 const class CG_str &CGs ,
									 const class array<double> &K_reducing_terms ,
									 const class uncoupled_dagger_tilde_table<TYPE> &two_body_MK_table , 
									 class coupled_dagger_tilde_table<TYPE> &two_body_K_table)
{
  const enum dagger_tilde_operator_type dagger_tilde_operator = two_body_K_table.get_dagger_tilde_operator ();
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  
  const double ja = two_body_MK_table.get_ja ();
  const double jb = two_body_MK_table.get_jb ();

  const int Kmin_PSI = abs (make_int (J_IN - J_OUT));
  
  const int Kmax_PSI = make_int (J_IN + J_OUT);
  
  const int MK = make_int (M_OUT - M_IN);

  const int Kmin_j = make_int (two_body_K_table.get_Kmin ());
  const int Kmax_j = make_int (two_body_K_table.get_Kmax ());
  
  const int Kmin = max (Kmin_j , Kmin_PSI);
  const int Kmax = min (Kmax_j , Kmax_PSI);
  
  const int ma_number = make_int (2.0*ja) + 1;
  
  for (int K = Kmin ; K <= Kmax ; K++)
    {
      TYPE two_body_K_MK = 0.0;

      for (int im_a = 0 ; im_a < ma_number ; im_a++)
	{
	  const double ma = im_a - ja;
	  
	  const double mb = MK - ma;

	  if (rint (abs (mb) - jb) <= 0.0)
	    {
	      const double CG = CGs (ja , ma , jb , mb , K , MK);
		
	      const int tilde_phase_a = (!is_it_dagger_a) ? (minus_one_pow (ja + ma)) : (1);
	      const int tilde_phase_b = (!is_it_dagger_b) ? (minus_one_pow (jb + mb)) : (1);
	      
	      (tilde_phase_a == tilde_phase_b) ? (two_body_K_MK += CG*two_body_MK_table(ma , mb)) : (two_body_K_MK -= CG*two_body_MK_table(ma , mb));
	    }
	}

      const int iK_PSI = make_int (K - Kmin_PSI);

      const double K_reducing_term = K_reducing_terms(iK_PSI);
      
      two_body_K_table(K) = two_body_K_MK*K_reducing_term;
    }
}









void dagger_tilde_operators_common::three_body_L_K_table_from_MK_table_calc (
									     const double J_IN , 
									     const double J_OUT , 
									     const double M_IN , 
									     const double M_OUT , 
									     const class CG_str &CGs ,
									     const class array<double> &K_reducing_terms ,
									     const class uncoupled_dagger_tilde_table<TYPE> &three_body_MK_table , 
									     class coupled_dagger_tilde_table<TYPE> &three_body_L_K_table)
{
  const enum dagger_tilde_operator_type dagger_tilde_operator = three_body_L_K_table.get_dagger_tilde_operator ();
    
  const double ja = three_body_MK_table.get_ja ();
  const double jb = three_body_MK_table.get_jb ();
  const double jc = three_body_MK_table.get_jc ();
    
  const int Lmin = three_body_L_K_table.get_Lmin ();
  const int Lmax = three_body_L_K_table.get_Lmax ();
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
  
  const bool is_it_a_dagger_a_dagger_a_tilde  = (is_it_dagger_a && is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_a_dagger = (is_it_dagger_a && is_it_dagger_b &&  is_it_dagger_c);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_tilde || is_it_a_dagger_a_dagger_a_dagger);
  
  const double MK = M_OUT - M_IN;
    
  const double Kmin_PSI = abs (J_IN - J_OUT);

  const double Kmax_PSI = J_IN + J_OUT;
      
  const int ma_number = make_int (2.0*ja) + 1;
  const int mb_number = make_int (2.0*jb) + 1;
  
  for (int L = Lmin ; L <= Lmax ; L++)
    {
      const double Kmin_j = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
      
      const double Kmax_j = (are_ab_coupled_first) ? (jc + L) : (ja + L);
		  
      const double Kmin = max (Kmin_PSI , Kmin_j);
      const double Kmax = min (Kmax_PSI , Kmax_j);
  
      const int K_number = make_int (Kmax - Kmin) + 1;
  
      for (int iK = 0 ; iK < K_number ; iK++)
	{
	  const double K = iK + Kmin;
			  
	  TYPE three_body_L_K_MK = 0.0;
	
	  for (int im_a = 0 ; im_a < ma_number ; im_a++)
	    {
	      const double ma = im_a - ja;
	  
	      const int tilde_phase_a = (!is_it_dagger_a) ? (minus_one_pow (ja + ma)) : (1);
	      
	      for (int im_b = 0 ; im_b < mb_number ; im_b++)
		{
		  const double mb = im_b - jb;
		      
		  const int Mab = make_int (ma + mb);
		  
		  const double mc = MK - Mab;
		  
		  if (rint (abs (mc) - jc) <= 0.0)
		    {
		      const int ML = (are_ab_coupled_first) ? (Mab) : (make_int (mb + mc));

		      const double CG_L = (are_ab_coupled_first) ? (CGs (ja , ma , jb , mb , L , ML)) : (CGs (jb , mb , jc , mc , L , ML));
		      
		      const double CG_K = (are_ab_coupled_first) ? (CGs (L , ML , jc , mc , K , MK)) : (CGs (ja , ma , L , ML , K , MK));
		      
		      const int tilde_phase_b = (!is_it_dagger_b) ? (minus_one_pow (jb + mb)) : (1);
		      const int tilde_phase_c = (!is_it_dagger_c) ? (minus_one_pow (jc + mc)) : (1);
		      
		      const int tilde_phase_ab = (tilde_phase_a == tilde_phase_b) ? (1) : (-1);
		      		      
		      (tilde_phase_ab == tilde_phase_c) ? (three_body_L_K_MK += CG_K*CG_L*three_body_MK_table(ma , mb , mc)) : (three_body_L_K_MK -= CG_K*CG_L*three_body_MK_table(ma , mb , mc));
		    }
		}
	    }

	  const int iK_PSI = make_int (K - Kmin_PSI);
      
	  const double K_reducing_term = K_reducing_terms(iK_PSI);
      
	  three_body_L_K_table(L , K) = three_body_L_K_MK*K_reducing_term;
	}
    }
}






void dagger_tilde_operators_common::PQG_CG_table_calc ( 
						       const class array<class nljm_struct> &phi_table_a ,
						       const class array<class nljm_struct> &phi_table_b , 
						       const class CG_str &CGs , 
						       class array<double> &CG_table)
{
  const unsigned int N_nljm_a = CG_table.dimension (0);
  const unsigned int N_nljm_b = CG_table.dimension (1);
    
  CG_table = 0.0;
  
  for (unsigned int phi_a_index = 0 ; phi_a_index < N_nljm_a ; phi_a_index++)
    for (unsigned int phi_b_index = 0 ; phi_b_index < N_nljm_b ; phi_b_index++)
      {
	const class nljm_struct &phi_a = phi_table_a(phi_a_index);
	const class nljm_struct &phi_b = phi_table_b(phi_b_index);
		
	const double ja = phi_a.get_j ();
	const double ma = phi_a.get_m ();
	
	const double jb = phi_b.get_j ();	
	const double mb = phi_b.get_m ();

	const int Kmin_ab = abs (make_int (ja - jb));
	    
	const int Kmax_ab = make_int (ja + jb);

	const int MK = make_int (ma + mb);

	for (int K = Kmin_ab ; K <= Kmax_ab ; K++) CG_table(phi_a_index , phi_b_index , K) = CGs (ja , ma , jb , mb , K , MK);
      }
}







void dagger_tilde_operators_common::PQG_partially_coupled_MEs_table_calc (
									  const enum dagger_tilde_operator_type dagger_tilde_operator ,
									  const class nucleons_data &prot_data ,
									  const class nucleons_data &neut_data ,
									  const class array<TYPE> &PQG_uncoupled_MEs_table ,
									  class array<TYPE> &PQG_partially_coupled_MEs_table)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in dagger_tilde_operators_common::PQG_partially_coupled_MEs_table_calc");
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 3);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 2);
  
  const bool is_it_a_dagger_a_dagger_ab = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde_ab   = (!is_it_dagger_a && !is_it_dagger_b);
  
  const bool is_it_a_dagger_a_dagger_dc = ( is_it_dagger_d &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_dc   = (!is_it_dagger_d && !is_it_dagger_c);
            
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_d = data_d.get_N_nlj ();
  
  const unsigned int N_nljm_a = data_a.get_N_nljm ();
  const unsigned int N_nljm_b = data_b.get_N_nljm ();
  const unsigned int N_nljm_c = data_c.get_N_nljm ();
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_d_qn = data_d.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table ();
  const class array<class nljm_struct> &phi_table_b = data_b.get_phi_table ();
  const class array<class nljm_struct> &phi_table_c = data_c.get_phi_table ();
  
  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_d_indices = data_d.get_one_body_indices ();
  
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_cd_different = (particle_c != particle_d);
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();
  const double mc_max = data_c.get_m_max ();
  const double md_max = data_d.get_m_max ();
  
  const int ma_max_minus_half = data_a.get_m_max_minus_half ();
  const int mb_max_minus_half = data_b.get_m_max_minus_half ();
  const int md_max_minus_half = data_d.get_m_max_minus_half ();
    
  const int ma_max_plus_mb_max = make_int (ma_max + mb_max);
  const int mc_max_plus_md_max = make_int (mc_max + md_max);
  
  const double m_max_ab = max (ma_max , mb_max);

  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  
  const int Kmax_all_plus_one_ab = make_int (ja_max + jb_max) + 1;
    
  const class CG_str CGs(m_max_ab);

  class array<double> CG_table_ab(N_nljm_a , N_nljm_b , Kmax_all_plus_one_ab);
 
  PQG_CG_table_calc (phi_table_a , phi_table_b , CGs , CG_table_ab);
   
  PQG_partially_coupled_MEs_table = 0.0;
  
  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      {
	const bool ab_ordered = (particles_ab_different || (sa <= sb));

	if (is_it_a_dagger_a_dagger_ab && !ab_ordered) continue;
	if (is_it_a_tilde_a_tilde_ab   && !ab_ordered) continue;
	  
	const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_b_qn(sb);

	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    
	if (!frozen_state_a && !frozen_state_b)
	  {		  
	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();

	    const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
	    
	    const int ija = shell_sa_qn.get_ij ();
	    const int ijb = shell_sb_qn.get_ij ();

	    const int im_a_min = -ija + ma_max_minus_half;
	    const int im_a_max =  ija + ma_max_minus_half + 1;
	    
	    const int im_b_min = -ijb + mb_max_minus_half;
	    const int im_b_max =  ijb + mb_max_minus_half + 1;
  
	    const int Kmin_ab = abs (ija - ijb);
	    
	    const int Kmax_ab = ija + ijb + 1;
	    
	    for (unsigned int phi_c_index = 0 ; phi_c_index < N_nljm_c ; phi_c_index++)
	      for (unsigned int sd = 0 ; sd < N_nlj_d ; sd++)
		{
		  const class nljm_struct &phi_c = phi_table_c(phi_c_index);
		  
		  const class nlj_struct &shell_sd_qn = shells_d_qn(sd);
	
		  const int lc = phi_c.get_l ();
			
		  const int ld = shell_sd_qn.get_l ();
			
		  const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);

		  if (bp_ab == bp_cd)
		    {					      
		      const int ijc = phi_c.get_ij ();
		      
		      const int ijd = shell_sd_qn.get_ij ();

		      const unsigned int sc = phi_c.get_shell_index ();
		      				
		      const bool cd_ordered = (particles_cd_different || (sc <= sd));
		      
		      if (is_it_a_dagger_a_dagger_dc && !cd_ordered) continue;
		      if (is_it_a_tilde_a_tilde_dc   && !cd_ordered) continue;
				
		      const int im_d_min = -ijd + md_max_minus_half;
		      const int im_d_max =  ijd + md_max_minus_half + 1;
	    
		      const int im_c = phi_c.get_im ();
		      				    
		      const int Kmin_cd = abs (ijc - ijd);
		      
		      const int Kmax_cd = ijc + ijd + 1;

		      const int Kmin = max (Kmin_ab , Kmin_cd);
		      const int Kmax = min (Kmax_ab , Kmax_cd);
	    
		      for (int K = Kmin ; K <= Kmax ; K++)
			for (int MK = -K ; MK <= K ; MK++)
			  {			  
			    const int im_d = -MK - im_c + mc_max_plus_md_max;

			    if ((im_d >= im_d_min) && (im_d <= im_d_max))
			      {		      
				const unsigned int phi_d_index = one_body_d_indices(sd , im_d);

				TYPE PQG_partially_coupled_ME = 0.0;
			    
				for (int im_a = im_a_min ; im_a <= im_a_max ; im_a++)
				  {				    
				    const unsigned int phi_a_index = one_body_a_indices(sa , im_a);
				   				   	      
				    const unsigned int binary_tilde_phase_a = (!is_it_dagger_a) ? ((ija + im_a - ma_max_minus_half)%2) : (0);
				    					
				    const int im_b = MK - im_a + ma_max_plus_mb_max;
						      
				    if ((im_b >= im_b_min) && (im_b <= im_b_max))  	
				      {				    
					const unsigned int phi_b_index = one_body_b_indices(sb , im_b);	

					const double CG = CG_table_ab(phi_a_index , phi_b_index , K);
		
					const unsigned int binary_tilde_phase_b = (!is_it_dagger_b) ? ((ijb + im_b - mb_max_minus_half)%2) : (0);
			      
					(binary_tilde_phase_a == binary_tilde_phase_b)
					  ? (PQG_partially_coupled_ME += CG*PQG_uncoupled_MEs_table(phi_a_index , phi_b_index , phi_c_index , sd))
					  : (PQG_partially_coupled_ME -= CG*PQG_uncoupled_MEs_table(phi_a_index , phi_b_index , phi_c_index , sd));
				      }
				  }
  
				PQG_partially_coupled_MEs_table(sa , sb , phi_c_index , phi_d_index , K) = PQG_partially_coupled_ME;
				
			      }}}}}}
}













void dagger_tilde_operators_common::PQG_test_dimensions_indices_calc (
								      const enum dagger_tilde_operator_type dagger_tilde_operator ,
								      const class nucleons_data &prot_data ,
								      const class nucleons_data &neut_data ,
								      class array<unsigned int> &PQG_test_dimensions ,
								      class array<unsigned int> &PQG_test_indices)
{
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  
  const bool is_it_a_dagger_a_dagger_ab = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde_ab   = (!is_it_dagger_a && !is_it_dagger_b);
  
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  
  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();

  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
    
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  
  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  
  const int Kmax_all_plus_one_ab = make_int (ja_max + jb_max) + 1;
  
  PQG_test_dimensions = 0;
  
  PQG_test_indices = N_nlj_a*N_nlj_b*Kmax_all_plus_one_ab;

  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      {
	const bool ab_ordered = (particles_ab_different || (sa <= sb));

	if (is_it_a_dagger_a_dagger_ab && !ab_ordered) continue;
	if (is_it_a_tilde_a_tilde_ab   && !ab_ordered) continue;
	  
	const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_b_qn(sb);

	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    	    
	if (!frozen_state_a && !frozen_state_b)
	  {	
	    const int ija = shell_sa_qn.get_ij ();
	    const int ijb = shell_sb_qn.get_ij ();

	    const int Kmin_ab = abs (ija - ijb);
	    
	    const int Kmax_ab = ija + ijb + 1;
	    
	    for (int K = Kmin_ab ; K <= Kmax_ab ; K++) PQG_test_indices(sa , sb , K) = PQG_test_dimensions(K)++;
	  }
      }  
}







void dagger_tilde_operators_common::PQG_coupled_MEs_table_calc (
								const enum dagger_tilde_operator_type dagger_tilde_operator ,
								const class nucleons_data &prot_data ,
								const class nucleons_data &neut_data ,
								const class array<TYPE> &PQG_partially_coupled_MEs_table ,
								class array<TYPE> &PQG_coupled_MEs_table)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in dagger_tilde_operators_common::PQG_coupled_MEs_table_calc");
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 3);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 2);
  
  const bool is_it_a_dagger_a_dagger_ab = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde_ab   = (!is_it_dagger_a && !is_it_dagger_b);
  
  const bool is_it_a_dagger_a_tilde_dc  = ( is_it_dagger_d && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_dc = ( is_it_dagger_d &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_dc   = (!is_it_dagger_d && !is_it_dagger_c);

  const bool is_there_antisymmetry_delta_ab = (is_it_a_dagger_a_dagger_ab || is_it_a_tilde_a_tilde_ab);
  const bool is_there_antisymmetry_delta_dc = (is_it_a_dagger_a_dagger_dc || is_it_a_tilde_a_tilde_dc);
  
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_c = data_c.get_N_nlj ();
  const unsigned int N_nlj_d = data_d.get_N_nlj ();
  
  const unsigned int N_nljm_c = data_c.get_N_nljm ();
  const unsigned int N_nljm_d = data_d.get_N_nljm ();

  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_d_qn = data_d.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table_c = data_c.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table ();
  
  const class one_body_indices_str &one_body_c_indices = data_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_d_indices = data_d.get_one_body_indices ();
  
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_cd_different = (particle_c != particle_d);
  
  const double mc_max = data_c.get_m_max ();
  const double md_max = data_d.get_m_max ();
  
  const int ma_max_minus_half = data_a.get_m_max_minus_half ();
  const int mb_max_minus_half = data_b.get_m_max_minus_half ();
  const int mc_max_minus_half = data_c.get_m_max_minus_half ();
  const int md_max_minus_half = data_d.get_m_max_minus_half ();
    
  const int mc_max_plus_md_max = make_int (mc_max + md_max);
  
  const double m_max_cd = max (mc_max , md_max);
  
  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  const double jc_max = data_c.get_jmax ();
  const double jd_max = data_d.get_jmax ();
  
  const int Kmax_all_ab = make_int (ja_max + jb_max);
  
  const int Kmax_all_plus_one_ab = Kmax_all_ab + 1;
  
  const int Kmax_all_plus_one_cd = make_int (jc_max + jd_max) + 1;
  
  const class CG_str CGs(m_max_cd);

  class array<double> CG_table_cd(N_nljm_c , N_nljm_d , Kmax_all_plus_one_cd);
 
  PQG_CG_table_calc (phi_table_c , phi_table_d , CGs , CG_table_cd);
   
  PQG_coupled_MEs_table = 0.0;

  class array<unsigned int> PQG_test_dimensions(Kmax_all_plus_one_ab);
  
  class array<unsigned int> PQG_test_indices(N_nlj_a , N_nlj_b , Kmax_all_plus_one_ab);
  									
  PQG_test_dimensions_indices_calc (dagger_tilde_operator , prot_data , neut_data , PQG_test_dimensions , PQG_test_indices);

  class array<class matrix<TYPE> > PQG_test_matrices(Kmax_all_plus_one_ab);

  for (int K = 0 ; K <= Kmax_all_ab ; K++)
    {
      const unsigned int PQG_test_dimension = PQG_test_dimensions(K);

      class matrix<TYPE> &PQG_test_matrix = PQG_test_matrices(K);
      
      PQG_test_matrix.allocate (PQG_test_dimension);
      
      PQG_test_matrix = 0.0;
    }
  
  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      {
	const bool ab_ordered = (particles_ab_different || (sa <= sb));

	if (is_it_a_dagger_a_dagger_ab && !ab_ordered) continue;
	if (is_it_a_tilde_a_tilde_ab   && !ab_ordered) continue;
	  
	const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_b_qn(sb);

	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    
	const bool are_sa_sb_equal = (!particles_ab_different && (sa == sb));
	    
	if (!frozen_state_a && !frozen_state_b)
	  {	
	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();

	    const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);

	    const int ija = shell_sa_qn.get_ij ();
	    const int ijb = shell_sb_qn.get_ij ();

	    const int Kmin_ab = abs (ija - ijb);
	    
	    const int Kmax_ab = ija + ijb + 1;
	    
	    for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
	      for (unsigned int sd = 0 ; sd < N_nlj_d ; sd++)
		{
		  const bool cd_ordered = (particles_cd_different || (sc <= sd));

		  if (is_it_a_dagger_a_dagger_dc && !cd_ordered) continue;
		  if (is_it_a_tilde_a_tilde_dc   && !cd_ordered) continue;
	  
		  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);
		  const class nlj_struct &shell_sd_qn = shells_d_qn(sd);

		  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();
		  const bool frozen_state_d = shell_sd_qn.get_frozen_state ();
		    
		  if (!frozen_state_c && !frozen_state_d)
		    {	
		      const int lc = shell_sc_qn.get_l ();
		      const int ld = shell_sd_qn.get_l ();

		      const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);

		      if (bp_ab == bp_cd)
			{
			  const bool are_sc_sd_equal = (!particles_cd_different && (sc == sd));
		      
			  const int ijc = shell_sc_qn.get_ij ();
			  const int ijd = shell_sd_qn.get_ij ();

			  const int im_c_min = -ijc + ma_max_minus_half;
			  const int im_c_max =  ijc + ma_max_minus_half + 1;
	    
			  const int im_d_min = -ijd + mb_max_minus_half;
			  const int im_d_max =  ijd + mb_max_minus_half + 1;
  	    
			  const int Kmin_cd = abs (ijc - ijd);
	    
			  const int Kmax_cd = ijc + ijd + 1;
			      
			  const int Kmin = max (Kmin_ab , Kmin_cd);
			  const int Kmax = min (Kmax_ab , Kmax_cd);
		      
			  for (int K = Kmin ; K <= Kmax ; K++)
			    {
			      class matrix<TYPE> &PQG_test_matrix = PQG_test_matrices(K);
      
			      TYPE PQG_coupled_ME = 0.0;
			    
			      for (int im_c = im_c_min ; im_c <= im_c_max ; im_c++)
				{
				  const unsigned int binary_tilde_phase_c = (!is_it_dagger_c) ? ((ijc + im_c - mc_max_minus_half)%2) : (0);
			  
				  const unsigned int phi_c_index = one_body_c_indices(sc , im_c);

				  for (int im_d = im_d_min ; im_d <= im_d_max ; im_d++)
				    {
				      const int MK = mc_max_plus_md_max - im_c - im_d;

				      if (abs (MK) <= K)
					{				
					  const unsigned int binary_tilde_phase_d = (!is_it_dagger_d) ? ((ijd + im_d - md_max_minus_half)%2) : (0);
				
					  const unsigned int phi_d_index = one_body_d_indices(sd , im_d);

					  const double CG = CG_table_cd (phi_c_index , phi_d_index , K);

					  const double CG_phase_K_MK = ((K - MK)%2 == 0) ? (CG) : (-CG);
					  
					  (binary_tilde_phase_c == binary_tilde_phase_d)
					    ? (PQG_coupled_ME += CG_phase_K_MK*PQG_partially_coupled_MEs_table(sa , sb , phi_c_index , phi_d_index , K))
					    : (PQG_coupled_ME -= CG_phase_K_MK*PQG_partially_coupled_MEs_table(sa , sb , phi_c_index , phi_d_index , K));
					}
				    }
				}
			      				
			      PQG_coupled_ME /= 2*K + 1;

			      if (is_it_a_dagger_a_tilde_dc) PQG_coupled_ME = -PQG_coupled_ME;
				
			      if (is_there_antisymmetry_delta_ab && are_sa_sb_equal) PQG_coupled_ME *= M_SQRT1_2;
			      if (is_there_antisymmetry_delta_dc && are_sc_sd_equal) PQG_coupled_ME *= M_SQRT1_2;
			      
			      PQG_coupled_MEs_table(sa , sb , sc , sd , K) = PQG_coupled_ME;
			      
			      PQG_test_matrix(PQG_test_indices(sa , sb , K) , PQG_test_indices(sc , sd , K)) = PQG_coupled_ME;
			      
			    }}}}}}

  for (int K = 0 ; K <= Kmax_all_ab ; K++)
    {
      const unsigned int PQG_test_dimension = PQG_test_dimensions(K);

      if (PQG_test_dimension > 0)
	{
	  class matrix<TYPE> &PQG_test_matrix = PQG_test_matrices(K);
	  
	  class array<TYPE> eigenvalues(PQG_test_dimension);
  
	  PQG_test_matrix.symmetrize ();
  
	  total_diagonalization::all_eigenvalues_Householder (PQG_test_matrix , eigenvalues);

	  const class array<double> Re_eigenvalues = real<double , TYPE> (eigenvalues);
	  
	  const double smallest_Re_eigenvalue = Re_eigenvalues.min ();
	  const double largest_Re_eigenvalue  = Re_eigenvalues.max ();
      
	  const double smallest_Re_eigenvalue_precision = (abs (smallest_Re_eigenvalue) < precision) ? (0.0) : (smallest_Re_eigenvalue);
	  const double largest_Re_eigenvalue_precision  = (abs (largest_Re_eigenvalue) < precision)  ? (0.0) : (largest_Re_eigenvalue);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      if (K <= 9) cout << dagger_tilde_operator << "   K : " << K << "    ";
	      if (K > 9)  cout << dagger_tilde_operator << "   K : " << K << "   ";
	      
	      if (smallest_Re_eigenvalue_precision == 0.0) cout << "smallest.Re.eigenvalue : 0.00000000000000000   ";
	      if (smallest_Re_eigenvalue_precision != 0.0) cout << "smallest.Re.eigenvalue : " << smallest_Re_eigenvalue <<  "   ";
	      
	      if (largest_Re_eigenvalue_precision == 0.0) cout << "largest.Re.eigenvalue : 0.00000000000000000" << endl;
	      if (largest_Re_eigenvalue_precision != 0.0) cout << "largest.Re.eigenvalue : " <<  largest_Re_eigenvalue_precision << endl;
	    }
	}
    }
}



void dagger_tilde_operators_common::T1_T2_CGs_table_calc (
							  const bool are_ab_coupled_first ,
							  const class array<class nljm_struct> &phi_table_p ,
							  const class array<class nljm_struct> &phi_table_q ,
							  const class array<class nljm_struct> &phi_table_r ,
							  const class CG_str &CGs , 
							  class array<double> &CG_L_table , 
							  class array<double> &CG_K_table)
{
  const unsigned int N_nljm_p = phi_table_p.dimension (0);
  const unsigned int N_nljm_q = phi_table_q.dimension (0);
  const unsigned int N_nljm_r = phi_table_r.dimension (0);

  const int Lmax_all = CG_K_table.dimension (1) - 1; 
  
  CG_L_table = 0.0;
  CG_K_table = 0.0;
  
  for (unsigned int phi_p_index = 0 ; phi_p_index < N_nljm_p ; phi_p_index++)
    for (unsigned int phi_q_index = 0 ; phi_q_index < N_nljm_q ; phi_q_index++)
      {	
	const class nljm_struct &phi_p = phi_table_p(phi_p_index);
	const class nljm_struct &phi_q = phi_table_q(phi_q_index);
	
	const double jp = phi_p.get_j ();
	const double mp = phi_p.get_m ();
	
	const double jq = phi_q.get_j ();
	const double mq = phi_q.get_m ();

	const int Lmin = abs (make_int (jp - jq));
	    
	const int Lmax = make_int (jp + jq);

	const int ML = make_int (mp + mq);
	
	for (int L = Lmin ; L <= Lmax ; L++) CG_L_table(phi_p_index , phi_q_index , L) = CGs (jp , mp , jq , mq , L , ML);
      }
  
  for (unsigned int phi_r_index = 0 ; phi_r_index < N_nljm_r ; phi_r_index++)
    for (int L = 0 ; L <= Lmax_all ; L++)
      for (int ML = -L ; ML <= L ; ML++)
	{
	  const int iML = L + ML;
	  
	  const class nljm_struct &phi_r = phi_table_r(phi_r_index);
	
	  const double jr = phi_r.get_j ();
	  const double mr = phi_r.get_m ();

	  const double Kmin = abs (jr - L);
	    
	  const double Kmax = jr + L;

	  const int K_number = make_int (Kmax - Kmin) + 1;
				  
	  const double MK = ML + mr;
	
	  for (int iK = 0 ; iK < K_number ; iK++)
	    {
	      const double K = iK + Kmin;

	      const int iK_total = make_int (K - 0.5);
	      
	      CG_K_table(phi_r_index , L , iML , iK_total) = (are_ab_coupled_first) ? (CGs (L , ML , jr , mr , K , MK)) : (CGs (jr , mr , L , ML , K , MK));
	    }
	}
}







void dagger_tilde_operators_common::T1_J_states_components_ppp_nnn_same_shell_calc (
										    const class nucleons_data &particles_data ,
										    class array<unsigned int> &alpha_number_same_shell_tab ,
										    class array<double> &J_states_components_same_shell)
										    
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  alpha_number_same_shell_tab = 0;
  
  J_states_components_same_shell = 0.0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {      
      const class nlj_struct &shell_qn = shells_qn(s);

      const double j = shell_qn.get_j ();

      const int Jmax_two_shells = make_int (2.0*j);
                  
      const double Jmax = Jmax_two_shells + j;

      const int J_number_max = make_int (Jmax - 0.5) + 1;

      class array<double> Wigner_6j_table(J_number_max);
      
      for (int iJ = 0 ; iJ < J_number_max ; iJ++)
	{
	  const double J = iJ + 0.5;

	  const int Jab_min_no_parity = abs (make_int (J - j));
	  
	  const int Jab_max_J_no_parity = make_int (J + j);
	  
	  const int Jab_max_no_parity = min (Jab_max_J_no_parity , Jmax_two_shells);
	  
	  const int Jab_min = (Jab_min_no_parity%2 == 0) ? (Jab_min_no_parity) : (Jab_min_no_parity + 1);
	  const int Jab_max = (Jab_max_no_parity%2 == 0) ? (Jab_max_no_parity) : (Jab_max_no_parity - 1);
	 			  
	  if (Jab_max >= Jab_min)
	    {
	      const int Jab_min_over_two = Jab_min/2;
	      const int Jab_max_over_two = Jab_max/2;
	  
	      const int Jab_number = Jab_max_over_two - Jab_min_over_two + 1;
      
	      class matrix<double> overlap_nas_matrix(Jab_number);

	      class array<double> overlap_nas_matrix_eigenvalues(Jab_number);
	  
	      for (int Jab_index = 0 ; Jab_index < Jab_number ; Jab_index++)
		{
		  const int Jab = 2*Jab_index + Jab_min;

		  const int Jab_index_Wigner_6j_table = Jab - Jab_min_no_parity;
		      
		  const double hat_Jab = hat (Jab);
	      
		  Wigner_signs::Wigner_6j_tab_calc (j , j , Jab , j , J , Wigner_6j_table);
		  
		  overlap_nas_matrix(Jab_index , Jab_index) = 0.5 + (2*Jab + 1)*Wigner_6j_table(Jab_index_Wigner_6j_table);
		  
		  for (int Jab_prime_index = 0 ; Jab_prime_index < Jab_index ; Jab_prime_index++)
		    {
		      const int Jab_prime = 2*Jab_prime_index + Jab_min;
		      
		      const int Jab_prime_index_Wigner_6j_table = Jab_prime - Jab_min_no_parity;
		      
		      overlap_nas_matrix(Jab_index , Jab_prime_index) = overlap_nas_matrix(Jab_prime_index , Jab_index) = hat_Jab*hat (Jab_prime)*Wigner_6j_table(Jab_prime_index_Wigner_6j_table);
		    }
		}
	  
	      total_diagonalization::all_eigenpairs (overlap_nas_matrix , overlap_nas_matrix_eigenvalues);
	      		      
	      unsigned int &alpha_index = alpha_number_same_shell_tab(s , iJ);

	      for (int overlap_nas_eigenvalue_index = 0 ; overlap_nas_eigenvalue_index < Jab_number ; overlap_nas_eigenvalue_index++)
		{
		  const double overlap = overlap_nas_matrix_eigenvalues(overlap_nas_eigenvalue_index);
		  
		  if (abs (overlap) > precision)
		    {
		      const double normalization_factor = sqrt (1.0/overlap);
		  
		      const class vector_class<double> &overlap_nas_matrix_eigenvector = overlap_nas_matrix.eigenvector (overlap_nas_eigenvalue_index);
 		  
		      for (int Jab_over_two = Jab_min_over_two ; Jab_over_two <= Jab_max_over_two ; Jab_over_two++)
			{
			  const int Jab_index = Jab_over_two - Jab_min_over_two;
			  	      
			  J_states_components_same_shell(s , iJ , alpha_index , Jab_over_two) = overlap_nas_matrix_eigenvector(Jab_index)*normalization_factor;
			}
			
		      alpha_index++;
		    }
		}
	    }
	}
    }
}







double dagger_tilde_operators_common::Kmin_calc (
						 const double Kmin_abc ,
						 const double j ,
						 const int Lmin_p ,
						 const int Lmax_p)
{
  double Kmin_def = j + Lmax_p;
  
  for (int Lp = Lmin_p ; Lp <= Lmax_p ; Lp++)
    {
      const double Kmin_def_Lp = abs (j - Lp);

      Kmin_def = min (Kmin_def , Kmin_def_Lp);
    }
  
  const double Kmin = max (Kmin_abc , Kmin_def);
  
  return Kmin;
}



double dagger_tilde_operators_common::Kmax_calc (
						 const double Kmax_abc ,
						 const double j ,
						 const int Lmin_p ,
						 const int Lmax_p)
{
  double Kmax_def = 0.5;
			      				  
  for (int Lp = Lmin_p ; Lp <= Lmax_p ; Lp++)
    {				  
      const double Kmax_def_Lp = j + Lp;

      Kmax_def = max (Kmax_def , Kmax_def_Lp);
    }

  const double Kmax = min (Kmax_abc , Kmax_def);
  
  return Kmax;
}




void dagger_tilde_operators_common::T1_T2_partially_coupled_MEs_table_calc (
									    const enum dagger_tilde_operator_type dagger_tilde_operator ,
									    const class nucleons_data &prot_data ,
									    const class nucleons_data &neut_data ,
									    const class array<TYPE> &T1_T2_uncoupled_MEs_table ,
									    class array<TYPE> &T1_T2_partially_coupled_MEs_table)									    
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in dagger_tilde_operators_common::T1_T2_partially_coupled_MEs_table_calc");
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 5);
  const bool is_it_dagger_e = is_it_dagger_determine (dagger_tilde_operator , 4);
  const bool is_it_dagger_f = is_it_dagger_determine (dagger_tilde_operator , 3);
    
  const bool is_it_a_dagger_a_dagger_a_dagger_abc = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c); 
  const bool is_it_a_dagger_a_dagger_a_tilde_abc  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
  
  const bool is_it_a_dagger_a_tilde_a_tilde_fed   = ( is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_tilde_a_tilde_a_tilde_fed    = (!is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_dagger_abc || is_it_a_dagger_a_dagger_a_tilde_abc);

  const bool are_ed_coupled_first = (is_it_a_tilde_a_tilde_a_tilde_fed || is_it_a_dagger_a_tilde_a_tilde_fed);
          
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
  const class nucleons_data &data_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data);
  const class nucleons_data &data_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_c = data_c.get_N_nlj ();
  const unsigned int N_nlj_f = data_f.get_N_nlj ();
  
  const unsigned int N_nljm_a = data_a.get_N_nljm ();
  const unsigned int N_nljm_b = data_b.get_N_nljm ();
  const unsigned int N_nljm_c = data_c.get_N_nljm ();
  const unsigned int N_nljm_d = data_d.get_N_nljm ();
  const unsigned int N_nljm_e = data_e.get_N_nljm ();

  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_f_qn = data_f.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table ();
  const class array<class nljm_struct> &phi_table_b = data_b.get_phi_table ();
  const class array<class nljm_struct> &phi_table_c = data_c.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table ();
  const class array<class nljm_struct> &phi_table_e = data_e.get_phi_table ();
  
  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_c_indices = data_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_f_indices = data_f.get_one_body_indices ();
  
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  const enum particle_type particle_e = data_e.get_particle ();
  const enum particle_type particle_f = data_f.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_bc_different = (particle_b != particle_c);
  const bool particles_de_different = (particle_d != particle_e);
  const bool particles_ef_different = (particle_e != particle_f);
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();
  const double mc_max = data_c.get_m_max ();
  const double md_max = data_d.get_m_max ();
  const double me_max = data_e.get_m_max ();
  const double mf_max = data_f.get_m_max ();
  
  const int ma_max_minus_half = data_a.get_m_max_minus_half ();
  const int mb_max_minus_half = data_b.get_m_max_minus_half ();
  const int mc_max_minus_half = data_c.get_m_max_minus_half ();
  const int mf_max_minus_half = data_f.get_m_max_minus_half ();
  
  const int two_mf_max = data_f.get_two_m_max ();
  
  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  const double jc_max = data_c.get_jmax ();

  const int ma_max_plus_mb_max = make_int (ma_max + mb_max);
  const int mb_max_plus_mc_max = make_int (mb_max + mc_max);
  const int md_max_plus_me_max = make_int (md_max + me_max);
  
  const double m_max_ab = max (ma_max , mb_max);
  
  const double m_max_abc = max (m_max_ab , mc_max);
    
  const double three_m_max_abc = 3.0*m_max_abc;

  const int Lmax_all_abc = (are_ab_coupled_first) ? (make_int (ja_max + jb_max)) : (make_int (jb_max + jc_max));
  
  const int Lmax_all_plus_one_abc = Lmax_all_abc + 1;
  
  const int ML_number_max_plus_one_abc = 2*Lmax_all_abc + 2;
  
  const unsigned int N_nljm_p_abc = (are_ab_coupled_first) ? (N_nljm_a) : (N_nljm_b);
  const unsigned int N_nljm_q_abc = (are_ab_coupled_first) ? (N_nljm_b) : (N_nljm_c);
  const unsigned int N_nljm_r_abc = (are_ab_coupled_first) ? (N_nljm_c) : (N_nljm_a);

  const class array<class nljm_struct> &phi_table_p_abc = (are_ab_coupled_first) ? (phi_table_a) : (phi_table_b);
  const class array<class nljm_struct> &phi_table_q_abc = (are_ab_coupled_first) ? (phi_table_b) : (phi_table_c);
  const class array<class nljm_struct> &phi_table_r_abc = (are_ab_coupled_first) ? (phi_table_c) : (phi_table_a);
   
  const double Kmax_all_abc = ja_max + jb_max + jc_max;

  const unsigned int K_number_max_abc = make_int (Kmax_all_abc - 0.5) + 1;

  const class CG_str CGs(three_m_max_abc);
  
  class array<double> CG_L_table_abc(N_nljm_p_abc , N_nljm_q_abc , Lmax_all_plus_one_abc);
    
  class array<double> CG_K_table_abc(N_nljm_r_abc , Lmax_all_plus_one_abc , ML_number_max_plus_one_abc , K_number_max_abc);
    
  T1_T2_CGs_table_calc (are_ab_coupled_first , phi_table_p_abc , phi_table_q_abc , phi_table_r_abc , CGs , CG_L_table_abc , CG_K_table_abc);
    
  T1_T2_partially_coupled_MEs_table = 0.0;
    
  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
	{	  
	  const bool ab_ordered = (particles_ab_different || (sa <= sb));
	  const bool cb_ordered = (particles_bc_different || (sc <= sb));
	  
	  if ( are_ab_coupled_first && !ab_ordered) continue;
	  if (!are_ab_coupled_first && !cb_ordered) continue;
	  
	  const bool are_sa_sb_equal = (!particles_ab_different && (sa == sb));
	  const bool are_sb_sc_equal = (!particles_bc_different && (sb == sc));
	  
	  const bool are_coupled_shells_in_abc_equal = ((!are_ab_coupled_first && are_sb_sc_equal) || (are_ab_coupled_first && are_sa_sb_equal));
	
	  const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	  const class nlj_struct &shell_sb_qn = shells_b_qn(sb);
	  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);

	  const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	  const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();
	  
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c)
	    {	
	      const int la = shell_sa_qn.get_l ();
	      const int lb = shell_sb_qn.get_l ();
	      const int lc = shell_sc_qn.get_l ();

	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);

	      const double ja = shell_sa_qn.get_j ();
	      const double jc = shell_sc_qn.get_j ();
	      
	      const int ija = shell_sa_qn.get_ij ();
	      const int ijb = shell_sb_qn.get_ij ();
	      const int ijc = shell_sc_qn.get_ij ();
	    
	      const int im_a_min = -ija + ma_max_minus_half;
	      const int im_a_max =  ija + ma_max_minus_half + 1;
	    
	      const int im_b_min = -ijb + mb_max_minus_half;
	      const int im_b_max =  ijb + mb_max_minus_half + 1;
	        
	      const int im_c_min = -ijc + mc_max_minus_half;
	      const int im_c_max =  ijc + mc_max_minus_half + 1;
	        
	      const int Lmin = (are_ab_coupled_first) ? (abs (ija - ijb)) : (abs (ijb - ijc));
	      
	      const int Lmax = (are_ab_coupled_first) ? (ija + ijb + 1) : (ijb + ijc + 1);

	      for (int L = Lmin ; L <= Lmax ; L++)
		{
		  if (are_coupled_shells_in_abc_equal && (L%2 == 1)) continue;

		  const double Kmin_abc = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
		  
		  const double Kmax_abc = (are_ab_coupled_first) ? (jc + L) : (ja + L);
  
		  for (unsigned int phi_d_index = 0 ; phi_d_index < N_nljm_d ; phi_d_index++)
		    for (unsigned int phi_e_index = 0 ; phi_e_index < N_nljm_e ; phi_e_index++)
		      for (unsigned int sf = 0 ; sf < N_nlj_f ; sf++)
			{
			  const class nljm_struct &phi_d = phi_table_d(phi_d_index);
			  const class nljm_struct &phi_e = phi_table_e(phi_e_index);
			  
			  const unsigned int sd = phi_d.get_shell_index (); 
			  const unsigned int se = phi_e.get_shell_index ();
		  
			  const bool de_ordered = (particles_de_different || (sd <= se));	  
			  const bool fe_ordered = (particles_ef_different || (sf <= se));

			  if ( are_ed_coupled_first && !de_ordered) continue;
			  if (!are_ed_coupled_first && !fe_ordered) continue;
	  
			  const class nlj_struct &shell_sf_qn = shells_f_qn(sf);
			
			  const int ld = phi_d.get_l ();
			  const int le = phi_e.get_l ();
			  
			  const int lf = shell_sf_qn.get_l ();
			
			  const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);

			  if (bp_abc == bp_def)
			    {			
			      const double jd = phi_d.get_j ();
			      
			      const double jf = shell_sf_qn.get_j ();
			      
			      const int ijd = phi_d.get_ij ();
			      const int ije = phi_e.get_ij ();
			      
			      const int ijf = shell_sf_qn.get_ij ();
			      
			      const int im_f_min = -ijf + mf_max_minus_half;
			      const int im_f_max =  ijf + mf_max_minus_half + 1;
	      
			      const int im_d = phi_d.get_im ();
			      const int im_e = phi_e.get_im ();

			      const int Mde = im_d + im_e - md_max_plus_me_max; 			      

			      const int Lmin_p = (are_ed_coupled_first) ? (abs (ije - ijd)) : (abs (ijf - ije));
	      
			      const int Lmax_p = (are_ed_coupled_first) ? (ije + ijd + 1) : (ijf + ije + 1);

			      const double Kmin = (are_ed_coupled_first) ? (Kmin_calc (Kmin_abc , jf , Lmin_p , Lmax_p)) : (Kmin_calc (Kmin_abc , jd , Lmin_p , Lmax_p));
			      const double Kmax = (are_ed_coupled_first) ? (Kmax_calc (Kmax_abc , jf , Lmin_p , Lmax_p)) : (Kmax_calc (Kmax_abc , jd , Lmin_p , Lmax_p));
			      				  
			      const int Kmin_minus_mc_max = make_int (Kmin - mc_max);
			      const int Kmin_minus_mf_max = make_int (Kmin - mf_max);
			      
			      const int Kmin_plus_mf_max = make_int (Kmin + mf_max);
				  
			      const int K_number = make_int (Kmax - Kmin) + 1;
							  
			      for (int iK = 0 ; iK < K_number ; iK++)
				{
				  const int K_minus_mc_max = iK + Kmin_minus_mc_max;
				  const int K_minus_mf_max = iK + Kmin_minus_mf_max;
				  
				  const int K_plus_mf_max = iK + Kmin_plus_mf_max; 

				  const int MK_number = 2*K_minus_mf_max + two_mf_max + 1;
	    		  			  
				  const int iK_total = K_minus_mf_max + mf_max_minus_half;

				  for (int iMK = 0 ; iMK < MK_number ; iMK++)
				    {
				      const int MK_plus_mc_max = iMK - K_minus_mc_max; 

				      const int MK_minus_mf_max = iMK - K_plus_mf_max; 
				      					  
				      const int im_f = -MK_minus_mf_max - Mde;
						  
				      if ((im_f >= im_f_min) && (im_f <= im_f_max))
					{
					  const unsigned int phi_f_index = one_body_f_indices(sf , im_f);
		  
					  TYPE T1_T2_partially_coupled_ME = 0.0;
			    
					  for (int im_a = im_a_min ; im_a <= im_a_max ; im_a++)
					    {	
					      const unsigned int phi_a_index = one_body_a_indices(sa , im_a);
						  
					      const unsigned int binary_tilde_phase_a = (!is_it_dagger_a) ? ((ija + im_a - ma_max_minus_half)%2) : (0);
						  
					      for (int im_b = im_b_min ; im_b <= im_b_max ; im_b++)
						{
						  const unsigned int phi_b_index = one_body_b_indices(sb , im_b);
						      
						  const unsigned int binary_tilde_phase_b = (!is_it_dagger_b) ? ((ijb + im_b - mb_max_minus_half)%2) : (0);
						      
						  const unsigned int binary_tilde_phase_ab = binary_parity_product (binary_tilde_phase_a , binary_tilde_phase_b);
						      
						  const int Mab = im_a + im_b - ma_max_plus_mb_max;
							  		
						  const int im_c = MK_plus_mc_max - Mab;
						      
						  if ((im_c >= im_c_min) && (im_c <= im_c_max))
						    {
						      const unsigned int phi_c_index = one_body_c_indices(sc , im_c);
							  
						      const int ML = (are_ab_coupled_first) ? (Mab) : (im_b + im_c - mb_max_plus_mc_max);

						      if (abs (ML) <= L)
							{
							  const int iML = L + ML;
							  
							  const double CG_L = (are_ab_coupled_first) ? (CG_L_table_abc(phi_a_index , phi_b_index , L)) : (CG_L_table_abc(phi_b_index , phi_c_index , L));

							  const double CG_K = (are_ab_coupled_first) ? (CG_K_table_abc(phi_c_index , L , iML , iK_total)) : (CG_K_table_abc(phi_a_index , L , iML , iK_total));
		
							  const double CGs_product = CG_L*CG_K;
							      
							  const unsigned int binary_tilde_phase_c = (!is_it_dagger_c) ? ((ijc + im_c - mc_max_minus_half)%2) : (0);
								
							  (binary_tilde_phase_ab == binary_tilde_phase_c)
							    ? (T1_T2_partially_coupled_ME += CGs_product*T1_T2_uncoupled_MEs_table(phi_a_index , phi_b_index , phi_c_index , phi_d_index , phi_e_index , sf))
							    : (T1_T2_partially_coupled_ME -= CGs_product*T1_T2_uncoupled_MEs_table(phi_a_index , phi_b_index , phi_c_index , phi_d_index , phi_e_index , sf));
							  							      							      
							}}}}
							
					  T1_T2_partially_coupled_MEs_table(sa , sb , sc , L , phi_d_index , phi_e_index , phi_f_index , iK_total) = T1_T2_partially_coupled_ME;
					  		      
					}}}}}}}}
}













void dagger_tilde_operators_common::T1_T2_test_dimensions_indices_calc (
									const enum dagger_tilde_operator_type dagger_tilde_operator ,
									const class nucleons_data &prot_data ,
									const class nucleons_data &neut_data ,
									const class array<unsigned int> &alpha_number_same_shell_tab ,  
									class array<unsigned int> &T1_T2_test_dimensions ,
									class array<unsigned int> &T1_T2_test_indices)
{
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
    
  const bool is_it_a_dagger_a_dagger_a_dagger_abc = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c); 
  const bool is_it_a_dagger_a_dagger_a_tilde_abc  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_dagger_abc || is_it_a_dagger_a_dagger_a_tilde_abc);
          
  const bool is_it_T1 = is_it_T1_determine (dagger_tilde_operator);
  
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_c = data_c.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
    
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_bc_different = (particle_b != particle_c);

  const double mc_max = data_c.get_m_max ();
  
  const int mc_max_minus_half = data_c.get_m_max_minus_half ();
  
  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  const double jc_max = data_c.get_jmax ();

  const int Lmax_all_abc = (are_ab_coupled_first) ? (make_int (ja_max + jb_max)) : (make_int (jb_max + jc_max));
  
  const int Lmax_all_plus_one_abc = Lmax_all_abc + 1;
   
  const double Kmax_all_abc = ja_max + jb_max + jc_max;
  
  const unsigned int K_number_max_abc = make_int (Kmax_all_abc - 0.5) + 1;
               
  T1_T2_test_dimensions = 0;
  
  T1_T2_test_indices = N_nlj_a*N_nlj_b*N_nlj_c*Lmax_all_plus_one_abc*K_number_max_abc;
  
  if (is_it_T1 && !particles_ab_different && !particles_bc_different)
    {
      for (unsigned int s = 0 ; s < N_nlj_a ; s++)
	{
	  const class nlj_struct &shell_qn = shells_a_qn(s);	      

	  const bool frozen_state = shell_qn.get_frozen_state ();
	  
	  if (!frozen_state)
	    {	      
	      const double j = shell_qn.get_j ();
	      
	      const double Kmin_abc = 0.5;
		  
	      const double Kmax_abc = 3.0*j;
		  
	      const int Kmin_abc_plus_mc_max = make_int (Kmin_abc + mc_max);
		  
	      const int K_number = make_int (Kmax_abc - Kmin_abc) + 1;
	         
	      for (int iK = 0 ; iK < K_number ; iK++)
		{
		  const int K_plus_mc_max = iK + Kmin_abc_plus_mc_max;
		      
		  const int iK_total = K_plus_mc_max - mc_max_minus_half - 1;
		      
		  const unsigned int alpha_indices_number = alpha_number_same_shell_tab(s , iK);
		  
		  for (unsigned int alpha_index = 0 ; alpha_index < alpha_indices_number ; alpha_index++) T1_T2_test_indices(s , s , s , alpha_index , iK_total) = T1_T2_test_dimensions(iK_total)++;
		}
	    }
	}
    }

  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
	{
	  const bool ab_ordered = (particles_ab_different || (sa <= sb));	  
	  const bool cb_ordered = (particles_bc_different || (sc <= sb));
	  
	  if ( are_ab_coupled_first && !ab_ordered) continue;
	  if (!are_ab_coupled_first && !cb_ordered) continue;
	  	  	  
	  const bool are_sa_sb_equal = (!particles_ab_different && (sa == sb));
	  const bool are_sb_sc_equal = (!particles_bc_different && (sb == sc));

	  if (is_it_T1 && are_sa_sb_equal && are_sb_sc_equal) continue;
	  
	  const bool are_coupled_shells_in_abc_equal = ((!are_ab_coupled_first && are_sb_sc_equal) || (are_ab_coupled_first && are_sa_sb_equal));
	  	  
	  const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	  const class nlj_struct &shell_sb_qn = shells_b_qn(sb);
	  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);

	  const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	  const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();

	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c)
	    {	
	      const double ja = shell_sa_qn.get_j ();
	      const double jc = shell_sc_qn.get_j ();
	      
	      const int ija = shell_sa_qn.get_ij ();
	      const int ijb = shell_sb_qn.get_ij ();
	      const int ijc = shell_sc_qn.get_ij ();
	        
	      const int Lmin = (are_ab_coupled_first) ? (abs (ija - ijb)) : (abs (ijb - ijc));
	      
	      const int Lmax = (are_ab_coupled_first) ? (ija + ijb + 1) : (ijb + ijc + 1);

	      for (int L = Lmin ; L <= Lmax ; L++)
		{
		  if (are_coupled_shells_in_abc_equal && (L%2 == 1)) continue;
		  
		  const double Kmin_abc = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
		  
		  const double Kmax_abc = (are_ab_coupled_first) ? (jc + L) : (ja + L);

		  const int Kmin_abc_plus_mc_max = make_int (Kmin_abc + mc_max);
		  
		  const int K_number = make_int (Kmax_abc - Kmin_abc) + 1;
				      
		  for (int iK = 0 ; iK < K_number ; iK++)
		    {
		      const int K_plus_mc_max = iK + Kmin_abc_plus_mc_max;
		      
		      const int iK_total = K_plus_mc_max - mc_max_minus_half - 1;
		      
		      T1_T2_test_indices(sa , sb , sc , L , iK_total) = T1_T2_test_dimensions(iK_total)++;
		    }
		}
	    }  
	}
}







void dagger_tilde_operators_common::T1_T2_coupled_MEs_table_calc (
								  const enum dagger_tilde_operator_type dagger_tilde_operator ,
								  const class nucleons_data &prot_data ,
								  const class nucleons_data &neut_data ,
								  const class array<TYPE> &T1_T2_partially_coupled_MEs_table ,
								  class array<TYPE> &T1_T2_coupled_MEs_table)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in dagger_tilde_operators_common::T1_T2_coupled_MEs_table_calc");
  
  const bool is_it_dagger_a = is_it_dagger_determine (dagger_tilde_operator , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (dagger_tilde_operator , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (dagger_tilde_operator , 2);
  const bool is_it_dagger_d = is_it_dagger_determine (dagger_tilde_operator , 5);
  const bool is_it_dagger_e = is_it_dagger_determine (dagger_tilde_operator , 4);
  const bool is_it_dagger_f = is_it_dagger_determine (dagger_tilde_operator , 3);
  
  const bool is_it_a_dagger_a_dagger_a_dagger_abc = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c); 
  const bool is_it_a_dagger_a_dagger_a_tilde_abc  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_a_tilde_abc    = (!is_it_dagger_a && !is_it_dagger_b && !is_it_dagger_c); 

  const bool is_it_a_dagger_a_tilde_a_tilde_fed   = ( is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_tilde_a_tilde_a_tilde_fed    = (!is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_dagger_abc || is_it_a_dagger_a_dagger_a_tilde_abc);

  const bool are_ed_coupled_first = (is_it_a_tilde_a_tilde_a_tilde_fed || is_it_a_dagger_a_tilde_a_tilde_fed);
  
  const bool is_it_T1 = is_it_T1_determine (dagger_tilde_operator);
    
  const class nucleons_data &data_a = data_find (dagger_tilde_operator , 0 , prot_data , neut_data);
  const class nucleons_data &data_b = data_find (dagger_tilde_operator , 1 , prot_data , neut_data);
  const class nucleons_data &data_c = data_find (dagger_tilde_operator , 2 , prot_data , neut_data);
  const class nucleons_data &data_d = data_find (dagger_tilde_operator , 5 , prot_data , neut_data);
  const class nucleons_data &data_e = data_find (dagger_tilde_operator , 4 , prot_data , neut_data);
  const class nucleons_data &data_f = data_find (dagger_tilde_operator , 3 , prot_data , neut_data);

  const unsigned int N_nlj_a = data_a.get_N_nlj ();
  const unsigned int N_nlj_b = data_b.get_N_nlj ();
  const unsigned int N_nlj_c = data_c.get_N_nlj ();
  const unsigned int N_nlj_d = data_d.get_N_nlj ();
  const unsigned int N_nlj_e = data_e.get_N_nlj ();
  const unsigned int N_nlj_f = data_f.get_N_nlj ();
  
  const unsigned int N_nljm_d = data_d.get_N_nljm ();
  const unsigned int N_nljm_e = data_e.get_N_nljm ();
  const unsigned int N_nljm_f = data_f.get_N_nljm ();

  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_d_qn = data_d.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_e_qn = data_e.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_f_qn = data_f.get_shells_quantum_numbers ();

  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table ();
  const class array<class nljm_struct> &phi_table_e = data_e.get_phi_table ();
  const class array<class nljm_struct> &phi_table_f = data_f.get_phi_table ();
  
  const class one_body_indices_str &one_body_d_indices = data_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_e_indices = data_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_f_indices = data_f.get_one_body_indices ();
  
  const enum particle_type particle_a = data_a.get_particle ();
  const enum particle_type particle_b = data_b.get_particle ();
  const enum particle_type particle_c = data_c.get_particle ();
  const enum particle_type particle_d = data_d.get_particle ();
  const enum particle_type particle_e = data_e.get_particle ();
  const enum particle_type particle_f = data_f.get_particle ();
  
  const bool particles_ab_different = (particle_a != particle_b);
  const bool particles_bc_different = (particle_b != particle_c);
  const bool particles_de_different = (particle_d != particle_e);
  const bool particles_ef_different = (particle_e != particle_f);
  
  const double md_max = data_d.get_m_max ();
  const double me_max = data_e.get_m_max ();
  const double mf_max = data_f.get_m_max ();
  
  const int md_max_minus_half = data_d.get_m_max_minus_half ();
  const int me_max_minus_half = data_e.get_m_max_minus_half ();
  const int mf_max_minus_half = data_f.get_m_max_minus_half ();
    
  const int two_mf_max = data_f.get_two_m_max ();
  
  const double ja_max = data_a.get_jmax ();
  const double jb_max = data_b.get_jmax ();
  const double jc_max = data_c.get_jmax ();
  const double jd_max = data_d.get_jmax ();
  const double je_max = data_e.get_jmax ();
  const double jf_max = data_f.get_jmax ();

  const int md_max_plus_me_max = make_int (md_max + me_max);
  const int me_max_plus_mf_max = make_int (me_max + mf_max);
  
  const double m_max_de = max (md_max , me_max);
  
  const double m_max_def = max (m_max_de , mf_max);
    
  const double three_m_max_def = 3.0*m_max_def;

  const int Lmax_all_abc = (are_ab_coupled_first) ? (make_int (ja_max + jb_max)) : (make_int (jb_max + jc_max));
  const int Lmax_all_def = (are_ed_coupled_first) ? (make_int (jd_max + je_max)) : (make_int (je_max + jf_max));
  
  const int Lmax_all_plus_one_abc = Lmax_all_abc + 1;
  const int Lmax_all_plus_one_def = Lmax_all_def + 1;
  
  const int Lmax_all_over_two_plus_one = Lmax_all_abc/2 + 1;
      
  const int ML_number_max_plus_one_def = 2*Lmax_all_def + 2;
  
  const unsigned int N_nljm_p_def = (are_ed_coupled_first) ? (N_nljm_d) : (N_nljm_e);
  const unsigned int N_nljm_q_def = (are_ed_coupled_first) ? (N_nljm_e) : (N_nljm_f);
  const unsigned int N_nljm_r_def = (are_ed_coupled_first) ? (N_nljm_f) : (N_nljm_d);
  
  const class array<class nljm_struct> &phi_table_p_def = (are_ed_coupled_first) ? (phi_table_d) : (phi_table_e);
  const class array<class nljm_struct> &phi_table_q_def = (are_ed_coupled_first) ? (phi_table_e) : (phi_table_f);
  const class array<class nljm_struct> &phi_table_r_def = (are_ed_coupled_first) ? (phi_table_f) : (phi_table_d);
 
  const double Kmax_all_abc = ja_max + jb_max + jc_max;
  const double Kmax_all_def = jd_max + je_max + jf_max;

  const int K_number_max_abc = make_int (Kmax_all_abc - 0.5) + 1;
  const int K_number_max_def = make_int (Kmax_all_def - 0.5) + 1;

  const class CG_str CGs(three_m_max_def);

  class array<double> CG_L_table_def(N_nljm_p_def , N_nljm_q_def , Lmax_all_plus_one_def);

  class array<double> CG_K_table_def(N_nljm_r_def , Lmax_all_plus_one_def , ML_number_max_plus_one_def , K_number_max_def);

  T1_T2_CGs_table_calc (are_ed_coupled_first , phi_table_p_def , phi_table_q_def , phi_table_r_def , CGs , CG_L_table_def , CG_K_table_def);
        
  class array<unsigned int> alpha_number_same_shell_tab(N_nlj_a , K_number_max_abc);
  alpha_number_same_shell_tab = NADA;
  
  class array<double> J_states_components_same_shell(N_nlj_a , K_number_max_abc , Lmax_all_over_two_plus_one , Lmax_all_over_two_plus_one);
  J_states_components_same_shell = NADA;
  
  if (is_it_T1 && !particles_ab_different && !particles_bc_different) T1_J_states_components_ppp_nnn_same_shell_calc (data_a , alpha_number_same_shell_tab , J_states_components_same_shell);	
  
  T1_T2_coupled_MEs_table = 0.0;
  
  class array<unsigned int> T1_T2_test_dimensions(K_number_max_abc);
  
  class array<unsigned int> T1_T2_test_indices(N_nlj_a , N_nlj_b , N_nlj_c , Lmax_all_plus_one_abc , K_number_max_abc);
  									
  T1_T2_test_dimensions_indices_calc (dagger_tilde_operator , prot_data , neut_data , alpha_number_same_shell_tab , T1_T2_test_dimensions , T1_T2_test_indices);
  
  class array<class matrix<TYPE> > T1_T2_test_matrices(K_number_max_abc);

  for (int iK_total = 0 ; iK_total < K_number_max_abc ; iK_total++)
    {
      const unsigned int T1_T2_test_dimension = T1_T2_test_dimensions(iK_total);

      class matrix<TYPE> &T1_T2_test_matrix = T1_T2_test_matrices(iK_total);
      
      T1_T2_test_matrix.allocate (T1_T2_test_dimension);
      
      T1_T2_test_matrix = 0.0;
    }
    
  for (unsigned int sa = 0 ; sa < N_nlj_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_c ; sc++)
	{	  
	  const bool ab_ordered = (particles_ab_different || (sa <= sb));	  
	  const bool cb_ordered = (particles_bc_different || (sc <= sb));
	  
	  if ( are_ab_coupled_first && !ab_ordered) continue;
	  if (!are_ab_coupled_first && !cb_ordered) continue;
	  	  	  
	  const bool are_sa_sb_equal = (!particles_ab_different && (sa == sb));
	  const bool are_sb_sc_equal = (!particles_bc_different && (sb == sc));
	  
	  const bool is_it_two_same_shell_case_ab = ( are_ab_coupled_first && are_sa_sb_equal);	  	  
	  const bool is_it_two_same_shell_case_bc = (!are_ab_coupled_first && are_sb_sc_equal);
	  
	  const bool are_coupled_shells_in_abc_equal = ((!are_ab_coupled_first && are_sb_sc_equal) || (are_ab_coupled_first && are_sa_sb_equal));
	  
	  const bool same_abc_shells_T1 = (is_it_T1 && are_sa_sb_equal && are_sb_sc_equal);
	  
	  const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	  const class nlj_struct &shell_sb_qn = shells_b_qn(sb);
	  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);

	  const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	  const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();

	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c)
	    {	
	      const int la = shell_sa_qn.get_l ();
	      const int lb = shell_sb_qn.get_l ();
	      const int lc = shell_sc_qn.get_l ();

	      const int ija = shell_sa_qn.get_ij ();
	      const int ijb = shell_sb_qn.get_ij ();
	      const int ijc = shell_sc_qn.get_ij ();
	      
	      const double ja = shell_sa_qn.get_j ();
	      const double jc = shell_sc_qn.get_j ();
	      
	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);
  
	      const int Lmin = (are_ab_coupled_first) ? (abs (ija - ijb)) : (abs (ijb - ijc));
	      
	      const int Lmax = (are_ab_coupled_first) ? (ija + ijb + 1) : (ijb + ijc + 1);

	      for (int L = Lmin ; L <= Lmax ; L++)
		{
		  if (are_coupled_shells_in_abc_equal && (L%2 == 1)) continue;
		  
		  const int L_over_two = L/2;
				      
		  const double Kmin_abc = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
		  
		  const double Kmax_abc = (are_ab_coupled_first) ? (jc + L) : (ja + L);
		  
		  for (unsigned int sd = 0 ; sd < N_nlj_d ; sd++)
		    for (unsigned int se = 0 ; se < N_nlj_e ; se++)
		      for (unsigned int sf = 0 ; sf < N_nlj_f ; sf++)
			{
			  const bool de_ordered = (particles_de_different || (sd <= se));
			  const bool fe_ordered = (particles_ef_different || (sf <= se));
			  
			  if ( are_ed_coupled_first && !de_ordered) continue;
			  if (!are_ed_coupled_first && !fe_ordered) continue;
	  			  
			  const bool are_sd_se_equal = (!particles_de_different && (sd == se));
			  const bool are_se_sf_equal = (!particles_ef_different && (se == sf));
	  
			  const bool is_it_two_same_shell_case_de = ( are_ed_coupled_first && are_sd_se_equal);
			  const bool is_it_two_same_shell_case_ef = (!are_ed_coupled_first && are_se_sf_equal);
	  				  
			  const bool are_coupled_shells_in_def_equal = ((!are_ed_coupled_first && are_se_sf_equal) || (are_ed_coupled_first && are_sd_se_equal));
				  
			  const bool same_def_shells_T1 = (is_it_T1 && are_sd_se_equal && are_se_sf_equal);

			  const class nlj_struct &shell_sd_qn = shells_d_qn(sd);
			  const class nlj_struct &shell_se_qn = shells_e_qn(se);
			  const class nlj_struct &shell_sf_qn = shells_f_qn(sf);

			  const bool frozen_state_d = shell_sd_qn.get_frozen_state ();
			  const bool frozen_state_e = shell_se_qn.get_frozen_state ();
			  const bool frozen_state_f = shell_sf_qn.get_frozen_state ();

			  if (!frozen_state_d && !frozen_state_e && !frozen_state_f)
			    {	
			      const int ld = shell_sd_qn.get_l ();
			      const int le = shell_se_qn.get_l ();
			      const int lf = shell_sf_qn.get_l ();

			      const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);

			      if (bp_abc == bp_def)
				{			
				  const double jd = shell_sd_qn.get_j ();
				  const double jf = shell_sf_qn.get_j ();
  
				  const int ijd = shell_sd_qn.get_ij ();
				  const int ije = shell_se_qn.get_ij ();
				  const int ijf = shell_sf_qn.get_ij ();
	      
				  const int im_d_min = -ijd + md_max_minus_half;
				  const int im_d_max =  ijd + md_max_minus_half + 1;
	    
				  const int im_e_min = -ije + me_max_minus_half;
				  const int im_e_max =  ije + me_max_minus_half + 1;
	    
				  const int im_f_min = -ijf + mf_max_minus_half;
				  const int im_f_max =  ijf + mf_max_minus_half + 1;
	      	      
				  const int Lmin_p = (are_ed_coupled_first) ? (abs (ije - ijd)) : (abs (ije - ijf));

				  const int Lmax_p = (are_ed_coupled_first) ? (ije + ijd + 1) : (ije + ijf + 1);

				  for (int Lp = Lmin_p ; Lp <= Lmax_p ; Lp++)
				    {
				      if (are_coupled_shells_in_def_equal && (Lp%2 == 1)) continue;
		  
				      const int Lp_over_two = Lp/2;
		  
				      const double Kmin_def = (are_ed_coupled_first) ? (abs (jf - Lp)) : (abs (jd - Lp));
				      
				      const double Kmax_def = (are_ed_coupled_first) ? (jf + Lp) : (jd + Lp);

				      const double Kmin = max (Kmin_abc , Kmin_def);
				      const double Kmax = min (Kmax_abc , Kmax_def);
				  
				      const int K_number = make_int (Kmax - Kmin) + 1;
  
				      const int Kmin_plus_mf_max = make_int (Kmin + mf_max);
				      				      
				      for (int iK = 0 ; iK < K_number ; iK++)
					{
					  const int K_plus_mf_max = iK + Kmin_plus_mf_max;
					  
					  const int iK_total = K_plus_mf_max - mf_max_minus_half - 1;
					  
					  class matrix<TYPE> &T1_T2_test_matrix = T1_T2_test_matrices(iK_total);
      
					  TYPE T1_T2_coupled_ME = 0.0;
			    
					  for (int im_d = im_d_min ; im_d <= im_d_max ; im_d++)
					    {	      
					      const unsigned int phi_d_index = one_body_d_indices(sd , im_d);
					      
					      const unsigned int binary_tilde_phase_d = (!is_it_dagger_d) ? ((ijd + im_d - md_max_minus_half)%2) : (0);
					      
					      for (int im_e = im_e_min ; im_e <= im_e_max ; im_e++)
						{
						  const unsigned int phi_e_index = one_body_e_indices(se , im_e);
						      
						  const unsigned int binary_tilde_phase_e = (!is_it_dagger_e) ? ((ije + im_e - me_max_minus_half)%2) : (0);
							  
						  const unsigned int binary_tilde_phase_de = binary_parity_product (binary_tilde_phase_d , binary_tilde_phase_e);
							  
						  const int Mde = im_d + im_e - md_max_plus_me_max;
						  
						  for (int im_f = im_f_min ; im_f <= im_f_max ; im_f++)
						    {
						      const int MK_plus_mf_max = two_mf_max - Mde - im_f;
		  
						      if (abs (MK_plus_mf_max) <= K_plus_mf_max)
							{
							  const int MLp = (are_ed_coupled_first) ? (Mde) : (im_e + im_f - me_max_plus_mf_max);

							  if (abs (MLp) <= Lp)
							    {				      
							      const int iMLp = MLp + Lp;
								  
							      const unsigned int phi_f_index = one_body_f_indices(sf , im_f);
					      
							      const double CG_Lp = (are_ed_coupled_first) ? (CG_L_table_def(phi_d_index , phi_e_index , Lp)) : (CG_L_table_def(phi_e_index , phi_f_index , Lp));

							      const double CG_K = (are_ed_coupled_first) ? (CG_K_table_def(phi_f_index , Lp , iMLp , iK_total)) : (CG_K_table_def(phi_d_index , Lp , iMLp , iK_total));
								
							      const double CGs_product = CG_Lp*CG_K;
							      
							      const double CGs_product_phase_K_MK = ((K_plus_mf_max - MK_plus_mf_max)%2 == 0) ? (CGs_product) : (-CGs_product);
					  
							      const unsigned int binary_tilde_phase_f = (!is_it_dagger_f) ? ((ijf + im_f - mf_max_minus_half)%2) : (0);
							      
							      (binary_tilde_phase_de == binary_tilde_phase_f)
								? (T1_T2_coupled_ME += CGs_product_phase_K_MK*T1_T2_partially_coupled_MEs_table(sa , sb , sc , L , phi_d_index , phi_e_index , phi_f_index , iK_total))
								: (T1_T2_coupled_ME -= CGs_product_phase_K_MK*T1_T2_partially_coupled_MEs_table(sa , sb , sc , L , phi_d_index , phi_e_index , phi_f_index , iK_total));
							      						  
							    }}}}}
					  
					  T1_T2_coupled_ME /= 2*K_plus_mf_max - two_mf_max + 1;

					  if (is_it_a_tilde_a_tilde_a_tilde_abc || is_it_a_dagger_a_dagger_a_tilde_abc) T1_T2_coupled_ME = -T1_T2_coupled_ME;

					  if (is_it_two_same_shell_case_ab) T1_T2_coupled_ME *= M_SQRT1_2;
					  if (is_it_two_same_shell_case_bc) T1_T2_coupled_ME *= M_SQRT1_2;
					  
					  if (is_it_two_same_shell_case_de) T1_T2_coupled_ME *= M_SQRT1_2;
					  if (is_it_two_same_shell_case_ef) T1_T2_coupled_ME *= M_SQRT1_2;
					  					  
					  if (same_abc_shells_T1 && same_def_shells_T1)
					    {
					      const unsigned int alpha_number_same_abc_shell = alpha_number_same_shell_tab(sa , iK_total);
					      const unsigned int alpha_number_same_def_shell = alpha_number_same_shell_tab(sd , iK_total);
					      
					      for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_number_same_abc_shell ; alpha_index_abc++)
						{
						  const double J_states_component_alpha_abc = J_states_components_same_shell(sa , iK_total , alpha_index_abc , L_over_two);
						  
						  const TYPE T1_T2_coupled_ME_J_states_component_alpha_abc = T1_T2_coupled_ME*J_states_component_alpha_abc;
							  
						  for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_number_same_def_shell ; alpha_index_def++)
						    {
						      const double J_states_component_alpha_def = J_states_components_same_shell(sd , iK_total , alpha_index_def , Lp_over_two);

						      const TYPE T1_T2_coupled_ME_J_states_component_alpha_abcdef = T1_T2_coupled_ME_J_states_component_alpha_abc*J_states_component_alpha_def;
									
						      T1_T2_coupled_MEs_table(sa , sb , sc , alpha_index_abc , sd , se , sf , alpha_index_def , iK_total) += T1_T2_coupled_ME_J_states_component_alpha_abcdef;
						      
						      T1_T2_test_matrix(T1_T2_test_indices(sa , sb , sc , alpha_index_abc , iK_total) , T1_T2_test_indices(sd , se , sf , alpha_index_def , iK_total)) += T1_T2_coupled_ME_J_states_component_alpha_abcdef;
						    }
						}
					    }
					  
					  if (!same_abc_shells_T1 && same_def_shells_T1)
					    {
					      const unsigned int alpha_number_same_def_shell = alpha_number_same_shell_tab(sd , iK_total);
					      
					      for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_number_same_def_shell ; alpha_index_def++)
						{
						  const double J_states_component_alpha_def = J_states_components_same_shell(sd , iK_total , alpha_index_def , Lp_over_two);

						  const TYPE T1_T2_coupled_ME_J_states_component_alpha_def = T1_T2_coupled_ME*J_states_component_alpha_def;
						  
						  T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , alpha_index_def , iK_total) += T1_T2_coupled_ME_J_states_component_alpha_def;
						  
						  T1_T2_test_matrix(T1_T2_test_indices(sa , sb , sc , L , iK_total) , T1_T2_test_indices(sd , se , sf , alpha_index_def , iK_total)) += T1_T2_coupled_ME_J_states_component_alpha_def;
						}
					    }
				      
					  if (same_abc_shells_T1 && !same_def_shells_T1)
					    {	
					      const unsigned int alpha_number_same_abc_shell = alpha_number_same_shell_tab(sa , iK_total);
					  
					      for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_number_same_abc_shell ; alpha_index_abc++)
						{
						  const double J_states_component_alpha_abc = J_states_components_same_shell(sa , iK_total , alpha_index_abc , L_over_two);

						  const TYPE T1_T2_coupled_ME_J_states_component_alpha_abc = T1_T2_coupled_ME*J_states_component_alpha_abc;
						  
						  T1_T2_coupled_MEs_table(sa , sb , sc , alpha_index_abc , sd , se , sf , Lp , iK_total) += T1_T2_coupled_ME_J_states_component_alpha_abc;
						  
						  T1_T2_test_matrix(T1_T2_test_indices(sa , sb , sc , alpha_index_abc , iK_total) , T1_T2_test_indices(sd , se , sf , Lp , iK_total)) += T1_T2_coupled_ME_J_states_component_alpha_abc;
						}
					    }
				      
					  if (!same_abc_shells_T1 && !same_def_shells_T1)
					    {
					      T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , Lp , iK_total) = T1_T2_coupled_ME;

					      T1_T2_test_matrix(T1_T2_test_indices(sa , sb , sc , L , iK_total) , T1_T2_test_indices(sd , se , sf , Lp , iK_total)) = T1_T2_coupled_ME;
					    }
					  					  
					}}}}}}}}
  
  for (int iK_total = 0 ; iK_total < K_number_max_abc ; iK_total++)
    {            
      const unsigned int T1_T2_test_dimension = T1_T2_test_dimensions(iK_total);
      
      if (T1_T2_test_dimension > 0)
	{
	  const double K = iK_total + 0.5;
      
	  class matrix<TYPE> &T1_T2_test_matrix = T1_T2_test_matrices(iK_total);
      
	  class array<TYPE> eigenvalues(T1_T2_test_dimension);
  
	  T1_T2_test_matrix.symmetrize ();
  
	  total_diagonalization::all_eigenvalues_Householder (T1_T2_test_matrix , eigenvalues);
	  
	  const class array<double> Re_eigenvalues = real<double , TYPE> (eigenvalues);
	  
	  const double smallest_Re_eigenvalue = Re_eigenvalues.min ();
	  const double largest_Re_eigenvalue  = Re_eigenvalues.max ();
      
	  const double smallest_Re_eigenvalue_precision = (abs (smallest_Re_eigenvalue) < precision) ? (0.0) : (smallest_Re_eigenvalue);
	  const double largest_Re_eigenvalue_precision  = (abs (largest_Re_eigenvalue) < precision)  ? (0.0) : (largest_Re_eigenvalue);

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      if (iK_total <= 4) cout << dagger_tilde_operator << "   K : " << J_string (K) << "    ";
	      if (iK_total >  4) cout << dagger_tilde_operator << "   K : " << J_string (K) << "   ";
	      
	      if (smallest_Re_eigenvalue_precision == 0.0) cout << "smallest.Re.eigenvalue : 0.00000000000000000   ";
	      if (smallest_Re_eigenvalue_precision != 0.0) cout << "smallest.Re.eigenvalue : " << smallest_Re_eigenvalue <<  "   ";
	      
	      if (largest_Re_eigenvalue_precision == 0.0) cout << "largest.Re.eigenvalue : 0.00000000000000000" << endl;
	      if (largest_Re_eigenvalue_precision != 0.0) cout << "largest.Re.eigenvalue : " <<  largest_Re_eigenvalue_precision << endl;
	    }
	}
    }
}
