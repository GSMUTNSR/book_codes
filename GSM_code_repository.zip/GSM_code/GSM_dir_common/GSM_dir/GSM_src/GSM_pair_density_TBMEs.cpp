#include "../GSM_include/GSM_include_def_common.h"

using namespace inputs_misc;

// TYPE is double or complex
// -------------------------

// Calculation of the radial or momentum array of wave function products over r^2
// ------------------------------------------------------------------------------
// One calculates here the radial functions u_a(r) u_b(r) / r^2 or u_a(k) u_b(k) / k^2 entering pair density matrix elements.
//
// rk is r or k.

void pair_density_TBMEs::radial_OBMEs_calc (
					    const bool is_it_radial ,
					    const bool is_it_Gauss_Legendre ,
					    const class baryons_data &data ,
					    class array<TYPE> &OBMEs_shells)
{
  const double four_Pi_square = 9.8696044010893586;
  
  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_nlj = OBMEs_shells.dimension (0);
  
  const unsigned int N_RKmax = OBMEs_shells.dimension (2);

  OBMEs_shells = 0.0;
  
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {	
	const class spherical_state &shell_in  = shells(s_in);
	const class spherical_state &shell_out = shells(s_out);
	
	const enum particle_type B_in = shell_in.get_particle ();
	const enum particle_type B_out = shell_out.get_particle ();
	 
	if (B_in == B_out)
	  {
	    const int strangeness = particle_strangeness_determine (B_in);

	    if (strangeness == 0)
	      {
		const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_in.get_r_bef_R_tab_GL ()) : (shell_in.get_r_bef_R_tab_uniform ());
	
		const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (shell_in.get_k_tab_GL ()) : (shell_in.get_k_tab_uniform ());
	
		const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);

		const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_bef_R_tab_GL ())  : (shell_in.get_wf_bef_R_tab_uniform ());
		const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_bef_R_tab_GL ()) : (shell_out.get_wf_bef_R_tab_uniform ());

		const class array<complex<double> > &dwf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_bef_R_tab_GL ())  : (shell_in.get_dwf_bef_R_tab_uniform ());
		const class array<complex<double> > &dwf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_bef_R_tab_GL ()) : (shell_out.get_dwf_bef_R_tab_uniform ());

		const class array<complex<double> > &wf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_wf_momentum_tab_GL ())  : (shell_in.get_wf_momentum_tab_uniform ());
		const class array<complex<double> > &wf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_wf_momentum_tab_GL ()) : (shell_out.get_wf_momentum_tab_uniform ());

		const class array<complex<double> > &dwf_in_momentum_tab  = (is_it_Gauss_Legendre) ? (shell_in.get_dwf_momentum_tab_GL ())  : (shell_in.get_dwf_momentum_tab_uniform ());
		const class array<complex<double> > &dwf_out_momentum_tab = (is_it_Gauss_Legendre) ? (shell_out.get_dwf_momentum_tab_GL ()) : (shell_out.get_dwf_momentum_tab_uniform ());

		const class array<complex<double> > &wf_in_rk_tab  = (is_it_radial) ? (wf_in_bef_R_tab)  : (wf_in_momentum_tab);
		const class array<complex<double> > &dwf_in_rk_tab = (is_it_radial) ? (dwf_in_bef_R_tab) : (dwf_in_momentum_tab);
	
		const class array<complex<double> > &wf_out_rk_tab  = (is_it_radial) ? (wf_out_bef_R_tab)  : (wf_out_momentum_tab);
		const class array<complex<double> > &dwf_out_rk_tab = (is_it_radial) ? (dwf_out_bef_R_tab) : (dwf_out_momentum_tab);
	
		if (N_RKmax > 0)
		  {
		    const double rk0 = rk_tab(0);
		    const double rk0_2 = rk0*rk0;
	    
		    const complex<double> wf_in_rk0  = wf_in_rk_tab(0);
		    const complex<double> dwf_in_rk0 = dwf_in_rk_tab(0);
	    
		    const complex<double> wf_out_rk0  = wf_out_rk_tab(0);	    
		    const complex<double> dwf_out_rk0 = dwf_out_rk_tab(0);
	    
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (wf_in_rk0*wf_out_rk0/rk0_2) : (dwf_in_rk0*dwf_out_rk0);
#endif

#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , 0) = (rk0 > 0) ? (real (wf_in_rk0)*real (wf_out_rk0)/rk0_2) : (real (dwf_in_rk0)*real (dwf_out_rk0));
#endif
		  }
	
		for (unsigned int i = 1 ; i < N_RKmax ; i++)
		  {
		    const double rk = rk_tab(i);
	    
		    const double rk2 = rk*rk;
	    
		    const complex<double> wf_in_rk  = wf_in_rk_tab(i);
		    const complex<double> wf_out_rk = wf_out_rk_tab(i);
	    
#ifdef TYPEisDOUBLECOMPLEX
		    OBMEs_shells(s_in , s_out , i) = wf_in_rk*wf_out_rk/rk2;
#endif
		
#ifdef TYPEisDOUBLE
		    OBMEs_shells(s_in , s_out , i) = real (wf_in_rk)*real (wf_out_rk)/rk2;
#endif
		  }
	      }
	  }
      }
  
  OBMEs_shells /= four_Pi_square;
}



// Calculation of coupled two-body matrix elements of pair density over r for given in and out protons or neutrons (or hyperons if any) two-body states
// ----------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc jd | \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering pair density are given as input.
// Radii come from Gauss-Legendre or uniform grids.

void pair_density_TBMEs::coupled_TBMEs_pp_nn_calc (
						   const int J , 
						   const class baryons_data &data , 
						   const class array<TYPE> &rk_OBMEs , 
						   const class pair_str &pair_in , 
						   const class pair_str &pair_out , 
						   class array<TYPE> &density_TBMEs)
{	
  density_TBMEs = 0.0;
  
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const unsigned int s0 = pair_in.get_left ()  , s1 = pair_in.get_right ();  //bra
  const unsigned int s2 = pair_out.get_left () , s3 = pair_out.get_right (); //ket

  const class nlj_struct &wf0 = shells_qn(s0) , &wf1 = shells_qn(s1);
  const class nlj_struct &wf2 = shells_qn(s2) , &wf3 = shells_qn(s3);
  
  const int angular_part_dir = (same_lj_particle (wf0 , wf2) && same_lj_particle (wf1 , wf3)) ? (1) : (0);
  const int angular_part_exc = (same_lj_particle (wf1 , wf2) && same_lj_particle (wf0 , wf3)) ? (1) : (0);
  
  if ((angular_part_dir == 0) && (angular_part_exc == 0)) return;
  
  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();

  const int phase_angular_part_exc = angular_part_exc*minus_one_pow (j0 + j1 - J);

  if (angular_part_dir == phase_angular_part_exc) return;
  
  const double antisymmetry_in  = (same_nlj_particle (wf0 , wf1)) ? (M_SQRT1_2) : (1.0);
  const double antisymmetry_out = (same_nlj_particle (wf2 , wf3)) ? (M_SQRT1_2) : (1.0);
  
  const double antisymmetry_product = antisymmetry_in*antisymmetry_out;

  const double angular_TBME = (angular_part_dir - phase_angular_part_exc)*antisymmetry_product;

  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs(s0 , s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs(s1 , s3 , i);

      const TYPE rk_OBMEs_product = rk_OBME_02*rk_OBME_13;

      density_TBMEs(i) = angular_TBME*rk_OBMEs_product;
    }
}



// Calculation of coupled two-body matrix elements of pair density over r for given in and out proton-neutron (or hyperons if any) two-body states
// -----------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc jd | \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.
// (a,c) are protons, (b,d) are neutrons (plus a few hyperons if any).
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering pair density are given as input.
// Radii come from Gauss-Legendre or uniform grids.

void pair_density_TBMEs::coupled_TBMEs_pn_calc (
						const class baryons_data &prot_Y_data , 
						const class baryons_data &neut_Y_data , 
						const class array<TYPE> &rk_OBMEs_p , 
						const class array<TYPE> &rk_OBMEs_n , 
						const class pair_str &pair_in , 
						const class pair_str &pair_out , 
						class array<TYPE> &density_TBMEs)
{	
  density_TBMEs = 0.0;
  
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const unsigned int s0 = pair_in.get_left ()  , s1 = pair_in.get_right ();  //bra
  const unsigned int s2 = pair_out.get_left () , s3 = pair_out.get_right (); //ket

  const class nlj_struct &wf0 = shells_qn_p(s0) , &wf1 = shells_qn_n(s1);
  const class nlj_struct &wf2 = shells_qn_p(s2) , &wf3 = shells_qn_n(s3);
    
  if (!same_lj_particle (wf0 , wf2) || !same_lj_particle (wf1 , wf3)) return;
  
  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    { 
      const TYPE rk_OBME_02 = rk_OBMEs_p(s0 , s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs_n(s1 , s3 , i);

      const TYPE rk_OBMEs_product = rk_OBME_02*rk_OBME_13;
      
      density_TBMEs(i) = rk_OBMEs_product;
    }
}






// Calculation of coupled two-body matrix elements of pair density over r for given in and out protons, neutrons or proton-neutron (plus a few hyperons if any) two-body statse
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One calls here routines calculating <jc jd | \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja jb>_J for all radii/momenta and a,b,c,d and J fixed.

void pair_density_TBMEs::coupled_TBMEs_calc ( 
					     const enum space_type space , 
					     const int J , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const class array<TYPE> &rk_OBMEs_p , 
					     const class array<TYPE> &rk_OBMEs_n , 
					     const class pair_str &pair_in , 
					     const class pair_str &pair_out , 
					     class array<TYPE> &density_TBMEs)
{
  density_TBMEs = 0.0;

  switch (space)
    {
    case PROT_Y_ONLY: coupled_TBMEs_pp_nn_calc (J , prot_Y_data , rk_OBMEs_p , pair_in , pair_out , density_TBMEs); break;
    case NEUT_Y_ONLY: coupled_TBMEs_pp_nn_calc (J , neut_Y_data , rk_OBMEs_n , pair_in , pair_out , density_TBMEs); break;
      
    case PROT_NEUT_Y: coupled_TBMEs_pn_calc (prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , pair_in , pair_out , density_TBMEs); break;

    default: abort_all ();
    }
}








// Calculation of uncoupled two-body matrix elements of pair density over r for given in and out protons or neutrons (or hyperons if any) two-body states
// ------------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc mc jd md | \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja ma jb mb> for all radii/momenta and a,b,c,d fixed.
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering pair density are given as input.
// Radii come from Gauss-Legendre or uniform grids.

void pair_density_TBMEs::uncoupled_TBMEs_pp_nn_calc (
						     const class baryons_data &data , 
						     const class array<TYPE> &rk_OBMEs , 
						     const unsigned int s0 , 
						     const unsigned int s1 , 
						     const unsigned int s2 , 
						     const unsigned int s3 , 
						     class array<TYPE> &density_TBMEs)
{	
  density_TBMEs = 0.0;
  
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const class array<class nljm_struct> &phi_table = data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table(s0) , &phi1 = phi_table(s1);
  const class nljm_struct &phi2 = phi_table(s2) , &phi3 = phi_table(s3);

  const int angular_part_dir = (same_Yljm_particle (phi0 , phi2) && same_Yljm_particle (phi1 , phi3)) ? (1) : (0);
  const int angular_part_exc = (same_Yljm_particle (phi1 , phi2) && same_Yljm_particle (phi0 , phi3)) ? (1) : (0);

  const int angular_TBME = angular_part_dir - angular_part_exc;
  
  if (angular_TBME == 0) return;
  
  const unsigned int shell_index_s0 = phi0.get_shell_index () , shell_index_s1 = phi1.get_shell_index ();
  const unsigned int shell_index_s2 = phi2.get_shell_index () , shell_index_s3 = phi3.get_shell_index ();
  
  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    {
      const TYPE rk_OBME_02 = rk_OBMEs(shell_index_s0 , shell_index_s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs(shell_index_s1 , shell_index_s3 , i);

      const TYPE rk_OBMEs_product = rk_OBME_02*rk_OBME_13;

      density_TBMEs(i) = rk_OBMEs_product*angular_TBME;
    }
}








// Calculation of uncoupled two-body matrix elements of pair density over r for given in and out proton-neutron (or hyperons if any) two-body states
// -------------------------------------------------------------------------------------------------------------------------------------------------
// One calculates here <jc mc jd md | \delta (r - r_1) \delta (r - r_2) / r^2/k^2 | ja ma jb mb> for all radii/momenta and a,b,c,d fixed.
// (a,c) are protons, (b,d) are neutrons.
// Radial functions equal to <beta | \delta (r - r_1)/r^2/k^2 | alpha > = u_alpha(r/k) u_beta(r/k) / r^2/k^2 entering pair density are given as input.
// Radii come from Gauss-Legendre or uniform grids.

void pair_density_TBMEs::uncoupled_TBMEs_pn_calc (
						  const class baryons_data &prot_Y_data , 
						  const class baryons_data &neut_Y_data , 
						  const class array<TYPE> &rk_OBMEs_p , 
						  const class array<TYPE> &rk_OBMEs_n , 
						  const unsigned int s0 , 
						  const unsigned int s1 , 
						  const unsigned int s2 , 
						  const unsigned int s3 , 
						  class array<TYPE> &density_TBMEs)
{
  density_TBMEs = 0.0;
  
  const unsigned int N_RKmax = density_TBMEs.dimension (0);

  const class array<class nljm_struct> &phi_table_p = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_table_n = neut_Y_data.get_phi_table ();

  const class nljm_struct &phi0 = phi_table_p(s0) , &phi1 = phi_table_n(s1);
  const class nljm_struct &phi2 = phi_table_p(s2) , &phi3 = phi_table_n(s3);
    
  if (!same_Yljm_particle (phi0 , phi2) || !same_Yljm_particle (phi1 , phi3)) return;

  const unsigned int shell_index_s0 = phi0.get_shell_index () , shell_index_s1 = phi1.get_shell_index ();
  const unsigned int shell_index_s2 = phi2.get_shell_index () , shell_index_s3 = phi3.get_shell_index ();
  
  for (unsigned int i = 0 ; i < N_RKmax ; i++)
    {
      const TYPE rk_OBME_02 = rk_OBMEs_p(shell_index_s0 , shell_index_s2 , i);
      const TYPE rk_OBME_13 = rk_OBMEs_n(shell_index_s1 , shell_index_s3 , i);

      const TYPE rk_OBMEs_product = rk_OBME_02*rk_OBME_13;

      density_TBMEs(i) = rk_OBMEs_product;
    }
}





