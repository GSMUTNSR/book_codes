#include "../GSM_include/GSM_include_def_common.h"

// TYPE is double or complex
// -------------------------

// class virtual configuration containing information about the occupied shells in a configuration for protons or neutrons (plus a few hyperons if any)
// ----------------------------------------------------------------------------------------------------------------------------------------------------
// A virtual configuration only contains the table of integers T where all configuration shells are listed and a start index i, so that T(i) ... T(i+5) = 0 0 1 1 1 2 if the configuration has 6 nucleons and 0 0 1 1 1 2 for shell indices.
// T is the only object where configurations are stored in the configuration_set structure of baryons_data (see GSM_baryons_data.h and GSM_array_of_configuration.h).
// The interest of a virtual class is that it is automatically copied to a configuration class with a constructor or operator = (see GSM_configuration.cpp),
// and that T can be modified with a statement of the type configuration_set(BP, n_scat, iC) = C, with C a class configuration.
// See GSM_configuration.cpp for details about the configuration class.
// T is table and i is index in the class.

virtual_configuration::virtual_configuration (
					      const class array<unsigned short int> &table_c ,
					      const unsigned int index_c) :
  table (table_c) ,
  index (index_c) {}

virtual_configuration::~virtual_configuration () {}


const class virtual_configuration & virtual_configuration::operator = (const class configuration &X) 
{
  const unsigned int N_valence_baryons = get_N_valence_baryons ();

  class virtual_configuration &C = *this;  

  for (unsigned int i = 0 ; i < N_valence_baryons ; i++)
    C[i] = X[i];

  return *this;
}




