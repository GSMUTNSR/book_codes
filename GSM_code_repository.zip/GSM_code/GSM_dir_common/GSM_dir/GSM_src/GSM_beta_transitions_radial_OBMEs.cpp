#include "../GSM_include/GSM_include_def_common.h"

using namespace angular_matrix_elements;
using namespace beta_transitions_common;
using namespace inputs_misc;


// TYPE is double or complex
// -------------------------




// Calculation of the radial integral of the beta transition
// ------------------------------------------------------------
// One uses the radial operator issued from beta_transitions_common::radial_operator_r if it has no derivative, or its direct expression if it does, in the case of reduced gradient.
// A direct calculation of the integral on the real axis is used. One just calculates a truncated overlap on [0:R], with R the rotation point unless one uses HO one-body states using the HO expansion method as well.
// Indeed, if one does not use the HO expansion method, one has to truncate overlaps on [0:R] even with HO states for consistency with the full Berggren basis.
// Complex scaling cannot be used as one cannot regularize all matrix elements as they diverge faster than a Dirac delta for some of them due to their strongly infinite range.

TYPE beta_transitions_radial_OBMEs::radial_integral_calc (
							  const bool is_it_HO_expansion , 
							  const enum radial_operator_type radial_operator , 
							  const double R_charge , 
							  const bool is_Hamiltonian_complex_scaled ,
							  const TYPE exp_I_theta_H_complex_scaled ,
							  const TYPE exp_minus_I_theta_H_complex_scaled ,
							  const class spherical_state &wf_in , 
							  const class spherical_state &wf_out)
{ 
  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL () , &r_aft_R_tab_GL_real = wf_in.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL () , &w_aft_R_tab_GL_real = wf_in.get_w_aft_R_tab_GL_real ();

  const class array<complex<double> > &wf_in_bef_R_tab_GL  = wf_in.get_wf_bef_R_tab_GL  () , &wf_in_aft_R_tab_GL_real  = wf_in.get_wf_aft_R_tab_GL_real  ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL () , &wf_out_aft_R_tab_GL_real = wf_out.get_wf_aft_R_tab_GL_real ();

  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();

  TYPE radial_integral = 0.0;

  if (radial_operator == REDUCED_GRADIENT)
    {
      const class array<complex<double> > &dwf_in_bef_R_tab_GL      = wf_in.get_dwf_bef_R_tab_GL ();
      const class array<complex<double> > &dwf_in_aft_R_tab_GL_real = wf_in.get_dwf_aft_R_tab_GL_real ();

      const int l_in = wf_in.get_l ();      
      const int l_out = wf_out.get_l ();
      
      const double l_factor = 0.5*(l_in*(l_in + 1) - l_out*(l_out + 1));

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i);
	  
	  const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);       
	  const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);
      
	  const complex<double> dwf_in_r  = dwf_in_bef_R_tab_GL(i);  
	  
#ifdef TYPEisDOUBLECOMPLEX
	  radial_integral += wf_out_r*(dwf_in_r + l_factor*wf_in_r/r)*w;
#endif
      
#ifdef TYPEisDOUBLE
	  radial_integral += real (wf_out_r)*(real (dwf_in_r) + l_factor*real (wf_in_r)/r)*w;
#endif
	}

      if (is_it_HO_expansion)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);
	      const double w = w_aft_R_tab_GL_real(i);

	      const complex<double> wf_in_r  = wf_in_aft_R_tab_GL_real(i);       
	      const complex<double> wf_out_r = wf_out_aft_R_tab_GL_real(i);
	  
	      const complex<double> dwf_in_r  = dwf_in_aft_R_tab_GL_real(i);   
	      
#ifdef TYPEisDOUBLECOMPLEX
	      radial_integral += wf_out_r*(dwf_in_r + l_factor*wf_in_r/r)*w;
#endif
      
#ifdef TYPEisDOUBLE
	      radial_integral += real (wf_out_r)*(real (dwf_in_r) + l_factor*real (wf_in_r)/r)*w;
#endif
	    }
	}

      if (is_Hamiltonian_complex_scaled) radial_integral *= exp_minus_I_theta_H_complex_scaled;
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i);
	  
	  const TYPE z = (is_Hamiltonian_complex_scaled) ? (r*exp_I_theta_H_complex_scaled) : (r);

	  const TYPE Oz = beta_transitions_radial_operator (radial_operator , R_charge , z);

	  const complex<double> wf_in_r  = wf_in_bef_R_tab_GL(i);       
	  const complex<double> wf_out_r = wf_out_bef_R_tab_GL(i);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  radial_integral += wf_in_r*wf_out_r*Oz*w;
#endif
      
#ifdef TYPEisDOUBLE
	  radial_integral += real (wf_in_r)*real (wf_out_r)*Oz*w;
#endif
	}

      if (is_it_HO_expansion)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);
	      const double w = w_aft_R_tab_GL_real(i);
	      
	      const TYPE z = (is_Hamiltonian_complex_scaled) ? (r*exp_I_theta_H_complex_scaled) : (r);

	      const TYPE Oz = beta_transitions_radial_operator (radial_operator , R_charge , z);

	      const complex<double> wf_in_r  = wf_in_aft_R_tab_GL_real(i);       
	      const complex<double> wf_out_r = wf_out_aft_R_tab_GL_real(i);
	      
#ifdef TYPEisDOUBLECOMPLEX
	      radial_integral += wf_in_r*wf_out_r*Oz*w;
#endif
      
#ifdef TYPEisDOUBLE
	      radial_integral += real (wf_in_r)*real (wf_out_r)*Oz*w;
#endif
	    }
	}
    }

  return radial_integral;
}










// Calculation of the radial integral of the beta transition with the HO states used in the interaction class
// -----------------------------------------------------------------------------------------------------------
// One uses the radial operator issued from beta_transitions_common::radial_operator_r if it has no derivative, or its direct expression if it does, in the case of reduced gradient.
// A direct calculation of the integral on the real axis is used. 
// One uses the HO one-body states of the interaction class, as these ones are used to define the HO expansion of operators, such as interaction two-body matrix elements.

TYPE beta_transitions_radial_OBMEs::radial_integral_HO_calc (
							     const enum radial_operator_type radial_operator , 
							     const class interaction_class &inter_data , 
							     const double R_charge , 
							     const unsigned int a , 
							     const unsigned int b)
{
  const class array<double> &r_bef_R_tab_GL = inter_data.get_r_bef_R_tab_GL () , &r_aft_R_tab_GL = inter_data.get_r_aft_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = inter_data.get_w_bef_R_tab_GL () , &w_aft_R_tab_GL = inter_data.get_w_aft_R_tab_GL ();
  
  const class array<double> &HO_wfs_bef_R_tab_GL = inter_data.get_HO_wfs_bef_R_tab_GL () , &HO_dwfs_bef_R_tab_GL = inter_data.get_HO_dwfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = inter_data.get_HO_wfs_aft_R_tab_GL () , &HO_dwfs_aft_R_tab_GL = inter_data.get_HO_dwfs_aft_R_tab_GL ();

  const unsigned int N_bef_R_GL = r_bef_R_tab_GL.dimension(0);
  const unsigned int N_aft_R_GL = r_aft_R_tab_GL.dimension(0);

  const class array<class nlj_struct> &shells_HO_qn = inter_data.get_shells_HO_qn ();

  const class nlj_struct &sa = shells_HO_qn(a);
  const class nlj_struct &sb = shells_HO_qn(b);
  
  const int na = sa.get_n () , la = sa.get_l ();  
  const int nb = sb.get_n () , lb = sb.get_l ();
  
  TYPE radial_integral = 0.0;

  if (radial_operator == REDUCED_GRADIENT)
    {
      const double l_factor = 0.5*(la*(la + 1) - lb*(lb + 1));

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i);

	  radial_integral += HO_wfs_bef_R_tab_GL(nb , lb , i)*(HO_dwfs_bef_R_tab_GL(na , la , i) + l_factor*HO_wfs_bef_R_tab_GL(na , la , i)/r)*w;
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL(i);
	  const double w = w_aft_R_tab_GL(i);

	  radial_integral += HO_wfs_aft_R_tab_GL(nb , lb , i)*(HO_dwfs_aft_R_tab_GL(na , la , i) + l_factor*HO_wfs_aft_R_tab_GL(na , la , i)/r)*w;
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  const double w = w_bef_R_tab_GL(i);
	  
	  const TYPE Or = beta_transitions_radial_operator (radial_operator , R_charge , r);

	  radial_integral += HO_wfs_bef_R_tab_GL(na , la , i)*HO_wfs_bef_R_tab_GL(nb , lb , i)*Or*w;
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL(i);
	  const double w = w_aft_R_tab_GL(i);
	  
	  const TYPE Or = beta_transitions_radial_operator (radial_operator , R_charge , r);

	  radial_integral += HO_wfs_aft_R_tab_GL(na , la , i)*HO_wfs_aft_R_tab_GL(nb , lb , i)*Or*w;
	}
    }

  return radial_integral;
}









// Calculation of the beta transition radial matrix elements for a given radial operator for all one-body basis states
// -------------------------------------------------------------------------------------------------------------------
// The radial operator can be overlap, r, r times Coulomb correction or reduced gradient for allowed and first-forbidden beta transitions.
//
// Radial integrals can be calculated from a direct radial integration of one-body basis states or using a HO expansion of the considered suboperator, 
// in which case radial overlaps of HO states and one-body basis states enter radial integrals along with a projection of one-body basis states on a HO basis.
// The HO expansion in the interaction class is used up to lmax_for_interaction, which can be smaller than the maximal orbital angular momentum used in the one-body basis.
// They can be different if one considers N hbar omega spaces to generate |NCM-HO LCM intrinsic> states for GSM-CC, 
// for which large orbital angular momenta are needed but no interaction matrix elements for these orbital angular momenta are used.
// All beta transition radial matrix elements involving states with l > lmax_for_interaction with the HO expansion are then put to zero.
// Direct radial integration is always done for HO one-body basis states.
// OpenMP distribution is used therein.
//
// If Hamiltonian is complex-scaled, theta-dependence is included explicitly in OBMEs.

void beta_transitions_radial_OBMEs::radial_OBMEs_calc (
						       const bool is_it_HO_expansion , 
						       const enum radial_operator_type radial_operator , 
						       const class interaction_class &inter_data , 
						       const class baryons_data &data_in , 
						       const class baryons_data &data_out , 
						       class array<TYPE> &radial_OBMEs)
{
  const unsigned int N_nlj_in = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();

  const unsigned int N_nlj_HO = inter_data.get_N_nlj_HO ();
  					
  const bool is_Hamiltonian_complex_scaled = data_in.get_is_Hamiltonian_complex_scaled ();

  const TYPE exp_I_theta_H_complex_scaled = data_in.get_exp_I_theta_H_complex_scaled ();

  const TYPE exp_minus_I_theta_H_complex_scaled = data_in.get_exp_minus_I_theta_H_complex_scaled ();
					  
  const class array<class nlj_struct> &shells_qn_in  = data_in.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_out = data_out.get_shells_quantum_numbers ();
  
  const class array<class spherical_state> &shells_in  = data_in.get_shells ();
  const class array<class spherical_state> &shells_out = data_out.get_shells ();

  const int A = data_in.get_A ();
  
  const double R_charge = R_charge_beta_calc (A);

  const int lmax_for_interaction = inter_data.get_lmax_for_interaction ();
		
  if (is_it_HO_expansion)
    {
      const enum particle_type nucleonic_particle_in = data_in.get_nucleonic_particle ();
      const enum particle_type nucleonic_particle_out = data_out.get_nucleonic_particle ();

      const bool is_it_charged_in  = (nucleonic_particle_in  == PROTON);
      const bool is_it_charged_out = (nucleonic_particle_out == PROTON);
  
      const class array<class vector_class<complex<double> > > &HO_overlaps_in  = data_in.get_HO_overlaps ();      
      const class array<class vector_class<complex<double> > > &HO_overlaps_out = data_out.get_HO_overlaps ();
      
      const class array<class nlj_table<unsigned int> > &shells_HO_indices_p_tab = inter_data.get_shells_HO_indices_p_tab ();
      const class array<class nlj_table<unsigned int> > &shells_HO_indices_n_tab = inter_data.get_shells_HO_indices_n_tab ();

      const class array<class nlj_table<unsigned int> > &shells_HO_indices_in_tab  = (is_it_charged_in)  ? (shells_HO_indices_p_tab) : (shells_HO_indices_n_tab);
      const class array<class nlj_table<unsigned int> > &shells_HO_indices_out_tab = (is_it_charged_out) ? (shells_HO_indices_p_tab) : (shells_HO_indices_n_tab);
      
      const class array<int> &nmax_HO_lab_tab = inter_data.get_nmax_HO_lab_tab ();

      class array<TYPE> radial_OBMEs_HO;

      if (!is_Hamiltonian_complex_scaled)
	{
	  radial_OBMEs_HO.allocate (N_nlj_HO , N_nlj_HO);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	  for (unsigned int a = 0 ; a < N_nlj_HO ; a++)
	    for (unsigned int b = 0 ; b < N_nlj_HO ; b++)
	      radial_OBMEs_HO(a , b) = radial_integral_HO_calc (radial_operator , inter_data , R_charge , a , b);
	}

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif 
      for (unsigned int s_in = 0 ; s_in < N_nlj_in ; s_in++)
	for (unsigned int s_out = 0 ; s_out < N_nlj_out ; s_out++)
	  {
	    const class nlj_struct &shell_qn_in = shells_qn_in(s_in);

	    const class nlj_struct &shell_qn_out = shells_qn_out(s_out);
	    
	    const class spherical_state &wf_in = shells_in(s_in);

	    const class spherical_state &wf_out = shells_out(s_out);

	    const bool is_it_HO_in = shell_qn_in.get_is_it_HO ();

	    const bool is_it_HO_out = shell_qn_out.get_is_it_HO ();
	    
	    if (is_it_HO_in || is_it_HO_out)
	      radial_OBMEs(s_in , s_out) = radial_integral_calc (is_it_HO_expansion , radial_operator , R_charge , 
								 is_Hamiltonian_complex_scaled , exp_I_theta_H_complex_scaled , exp_minus_I_theta_H_complex_scaled ,
								 wf_in , wf_out);
	    else
	      {
		if (is_Hamiltonian_complex_scaled) error_message_print_abort ("Hamiltonian must not be complex-scaled if does not use HO states in beta_transitions_radial_OBMEs::radial_OBMEs_calc");

		const class vector_class<complex<double> > &HO_overlaps_state_in = HO_overlaps_in(s_in);
		
		const class vector_class<complex<double> > &HO_overlaps_state_out = HO_overlaps_out(s_out);
		
		const int l_in = wf_in.get_l ();

		const int l_out = wf_out.get_l ();

		if (l_in  > lmax_for_interaction) continue;
		if (l_out > lmax_for_interaction) continue;
		
		const enum particle_type particle_in  = shell_qn_in.get_particle ();
		const enum particle_type particle_out = shell_qn_out.get_particle ();

		const unsigned int particle_index_in  = charge_baryon_index_determine (particle_in);
		const unsigned int particle_index_out = charge_baryon_index_determine (particle_out);

		const class nlj_table<unsigned int> &shells_HO_indices_shell_in  = shells_HO_indices_in_tab(particle_index_in);
		const class nlj_table<unsigned int> &shells_HO_indices_shell_out = shells_HO_indices_out_tab(particle_index_out);
      
		const int nmax_HO_l_in = nmax_HO_lab_tab(l_in);

		const int nmax_HO_l_out = nmax_HO_lab_tab(l_out);
		
		const double j_in = wf_in.get_j ();

		const double j_out = wf_out.get_j ();

		radial_OBMEs(s_in , s_out) = 0.0;

		for (int n_HO_in = 0 ; n_HO_in <= nmax_HO_l_in ; n_HO_in++) 
		  for (int n_HO_out = 0 ; n_HO_out <= nmax_HO_l_out ; n_HO_out++)
		    {
		      const unsigned int HO_index_in  = shells_HO_indices_shell_in (n_HO_in  , l_in  , j_in);
		      const unsigned int HO_index_out = shells_HO_indices_shell_out(n_HO_out , l_out , j_out);
		  
#ifdef TYPEisDOUBLECOMPLEX
		      const TYPE HO_overlaps_product = HO_overlaps_state_in(n_HO_in)*HO_overlaps_state_out(n_HO_out);
#endif
      
#ifdef TYPEisDOUBLE
		      const TYPE HO_overlaps_product = real (HO_overlaps_state_in(n_HO_in))*real (HO_overlaps_state_out(n_HO_out));
#endif

		      radial_OBMEs(s_in , s_out) += HO_overlaps_product*radial_OBMEs_HO(HO_index_in , HO_index_out);
		    }
	      }
	  }
    }
  else
    {
      if (is_Hamiltonian_complex_scaled) error_message_print_abort ("Hamiltonian must not be complex-scaled if does not use HO expansion in beta_transitions_radial_OBMEs::radial_OBMEs_calc");

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int s_in = 0 ; s_in < N_nlj_in ; s_in++)
	for (unsigned int s_out = 0 ; s_out < N_nlj_in ; s_out++)
	  {
	    const class spherical_state &wf_in = shells_in(s_in);

	    const class spherical_state &wf_out = shells_out(s_out);
	    
	    radial_OBMEs(s_in , s_out) = radial_integral_calc (is_it_HO_expansion , radial_operator , R_charge , 
							       is_Hamiltonian_complex_scaled , exp_I_theta_H_complex_scaled , exp_minus_I_theta_H_complex_scaled ,
							       wf_in , wf_out);
	  }
    }
}






