#include "../GSM_include/GSM_include_def_common.h"

using namespace EM_transitions_common;
using namespace EM_transitions_radial_OBMEs;
using namespace inputs_misc;
using namespace Wigner_signs;



// EM means electromagnetic
// ------------------------




// Calculation of the radial array of the beta transition strength
// ---------------------------------------------------------------
// One uses the radial operator issued from EM_transitions_radial_operator.

void EM_transitions_strength_OBMEs::radial_OBMEs_states_fixed_calc ( 
								    const enum radial_operator_type radial_operator ,
								    const TYPE &q , 
								    const int L , 
								    const bool is_it_longwavelength_approximation ,
								    const bool is_it_Gauss_Legendre , 
								    const class spherical_state &wf_in , 
								    const class spherical_state &wf_out , 
								    class array<TYPE> &radial_OBMEs_states_fixed)
{
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = wf_in.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_in.get_r_bef_R_tab_GL ()) : (wf_in.get_r_bef_R_tab_uniform ());

  const class array<complex<double> > &wf_in_bef_R_tab  = (is_it_Gauss_Legendre) ? (wf_in.get_wf_bef_R_tab_GL ())  : (wf_in.get_wf_bef_R_tab_uniform ());
  const class array<complex<double> > &wf_out_bef_R_tab = (is_it_Gauss_Legendre) ? (wf_out.get_wf_bef_R_tab_GL ()) : (wf_out.get_wf_bef_R_tab_uniform ());

  const TYPE factor = double_factorial (2*L+1)/(L+1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);
  
  if (Nr > 0)
    {
      const double r0 = r_bef_R_tab(0);
	    
      const TYPE O_r0 = (r0 > 0) ? (EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , r0)) : (0.0);
      
      const complex<double> wf_in_r0  = wf_in_bef_R_tab(0);	    
      const complex<double> wf_out_r0 = wf_out_bef_R_tab(0);
      
#ifdef TYPEisDOUBLECOMPLEX
      radial_OBMEs_states_fixed(0) = (r0 > 0) ? (wf_in_r0*wf_out_r0*O_r0) : (0.0);
#endif
      
#ifdef TYPEisDOUBLE
      radial_OBMEs_states_fixed(0) = (r0 > 0) ? (real (wf_in_r0)*real (wf_out_r0)*O_r0) : (0.0);
#endif
    }
 
  for (unsigned int i = 1 ; i < Nr ; i++)
    {
      const double r = r_bef_R_tab(i);

      const TYPE Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , r);
      
      const complex<double> wf_in_r  = wf_in_bef_R_tab(i);
      const complex<double> wf_out_r = wf_out_bef_R_tab(i);
      
#ifdef TYPEisDOUBLECOMPLEX
      const TYPE radial_OBME = wf_in_r*wf_out_r*Or;
#endif
      
#ifdef TYPEisDOUBLE
      const TYPE radial_OBME = real (wf_in_r)*real (wf_out_r)*Or;
#endif

      radial_OBMEs_states_fixed(i) = radial_OBME;
    }
}





// Calculation of the radial array of the electromagnetic transition strength for a given radial operator for all one-body basis states
// ------------------------------------------------------------------------------------------------------------------------------------
// One uses the radial operator issued from EM_transitions_radial_operator.
// OpenMP distribution is used therein.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_strength_OBMEs::radial_OBMEs_calc ( 
						       const enum radial_operator_type radial_operator ,
						       const TYPE &q , 
						       const int L , 
						       const bool is_it_longwavelength_approximation ,
						       const bool is_it_Gauss_Legendre ,  	
						       const unsigned int BP_Op , 
						       const class nucleons_data &data , 
						       class array<TYPE> &radial_OBMEs)
{
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int N_nlj = data.get_N_nlj ();
  
  const class array<class spherical_state> &shells = data.get_shells ();

  class array<class array<TYPE> > radial_OBMEs_states_fixed_work(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) radial_OBMEs_states_fixed_work(i).allocate (Nr);
  
  radial_OBMEs = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class spherical_state &wf_in  = shells(s_in);
	const class spherical_state &wf_out = shells(s_out);

	const int l_in  = wf_in.get_l ();
	const int l_out = wf_out.get_l ();

	if (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op)
	  {
	    const unsigned int i_thread = OpenMP_thread_number_determine ();
	    
	    class array<TYPE> &radial_OBMEs_states_fixed = radial_OBMEs_states_fixed_work(i_thread);

	    radial_OBMEs_states_fixed_calc (radial_operator , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre ,  wf_in , wf_out , radial_OBMEs_states_fixed);

	    for (unsigned int i = 0 ; i < Nr ; i++) radial_OBMEs(s_in , s_out , i) = radial_OBMEs_states_fixed(i);
	  }
      }
}






// Calculation of the electric transition strength reduced matrix elements for all one-body basis states
// -----------------------------------------------------------------------------------------------------
// Electric transitions are considered here, with electric charge and current parts.
// One loops over all one-body basis states and one calculates all associated one-body matrix elements.
// Radial parts (not integrated) are calculated first. Angular parts are considered afterwards.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_strength_OBMEs::electric::OBMEs_reduced_calc (
								  const TYPE &q , 
								  const int L , 
								  const int Lc , 
								  const bool is_it_longwavelength_approximation , 
								  const bool is_it_Gauss_Legendre , 
								  const class nucleons_data &data , 
								  class array<TYPE> &electric_OBMEs)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);

  const double effective_charge = data.get_effective_charge ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int N_nlj = data.get_N_nlj ();
  
  const enum particle_type particle = data.get_particle ();
  
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class array<TYPE> ECH_radial_OBMEs(N_nlj , N_nlj , Nr);
  class array<TYPE> EC_radial_OBMEs (N_nlj , N_nlj , Nr);
  
  radial_OBMEs_calc (ELECTRIC_CHARGE_RADIAL  , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , ECH_radial_OBMEs);
  radial_OBMEs_calc (ELECTRIC_CURRENT_RADIAL , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , EC_radial_OBMEs);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const class nlj_struct &shell_qn_in = shells_qn(s_in);
	  const class nlj_struct &shell_qn_out = shells_qn(s_out);

	  const int l_in  = shell_qn_in.get_l ();
	  const int l_out = shell_qn_out.get_l ();
	  
	  const double j_in  = shell_qn_in.get_j ();
	  const double j_out = shell_qn_out.get_j ();

	  const TYPE ECH_radial_OBME = ECH_radial_OBMEs(s_in , s_out , i);
	  const TYPE EC_radial_OBME  = EC_radial_OBMEs (s_in , s_out , i);
				
	  const TYPE ECH_OBME = EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , Lc , particle , effective_charge , ECH_radial_OBME , l_in , j_in , l_out , j_out);
	  const TYPE EC_OBME  = EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , Lc , particle , effective_charge ,  EC_radial_OBME , l_in , j_in , l_out , j_out);

	  const TYPE electric_OBME = ECH_OBME + EC_OBME;

	  electric_OBMEs(s_in , s_out , i) = electric_OBME;
	}
}



// Calculation of the magnetic transition strength reduced matrix elements for all one-body basis states
// -----------------------------------------------------------------------------------------------------
// Magnetic transitions are considered here, with magnetic orbital and spin parts.
// One loops over all one-body basis states and one calculates all associated one-body matrix elements.
// Radial parts (not integrated) are calculated first. Angular parts are considered afterwards.
// The matrix element is directly put to zero if parity is not conserved.

void EM_transitions_strength_OBMEs::magnetic::OBMEs_reduced_calc (
								  const TYPE &q , 
								  const int L , 
								  const int Lc , 
								  const bool is_it_longwavelength_approximation , 
								  const bool is_it_Gauss_Legendre , 
								  const class nucleons_data &data , 
								  class array<TYPE> &magnetic_OBMEs)
{
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int N_nlj = data.get_N_nlj ();
  
  const enum particle_type particle = data.get_particle ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class array<TYPE> MOLP1_radial_OBMEs(N_nlj , N_nlj , Nr);
  class array<TYPE> MOLM1_radial_OBMEs(N_nlj , N_nlj , Nr);
  class array<TYPE> MSLP1_radial_OBMEs(N_nlj , N_nlj , Nr);
  class array<TYPE> MSLM1_radial_OBMEs(N_nlj , N_nlj , Nr);
  class array<TYPE> MSSCE_radial_OBMEs(N_nlj , N_nlj , Nr);

  radial_OBMEs_calc (GRADIENT_BESSEL_LP1                    , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , MOLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_BESSEL_LM1                    , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , MOLM1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1 , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , MSLP1_radial_OBMEs);
  radial_OBMEs_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1 , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , MSLM1_radial_OBMEs);
  radial_OBMEs_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL        , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , MSSCE_radial_OBMEs);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const class nlj_struct &shell_qn_in  = shells_qn(s_in);
	  const class nlj_struct &shell_qn_out = shells_qn(s_out);

	  const int l_in  = shell_qn_in.get_l ();
	  const int l_out = shell_qn_out.get_l ();
	  
	  const double j_in  = shell_qn_in.get_j ();
	  const double j_out = shell_qn_out.get_j ();

	  const TYPE MOLP1_radial_OBME = MOLP1_radial_OBMEs(s_in , s_out , i);
	  const TYPE MOLM1_radial_OBME = MOLM1_radial_OBMEs(s_in , s_out , i);
	  const TYPE MSLP1_radial_OBME = MSLP1_radial_OBMEs(s_in , s_out , i);
	  const TYPE MSLM1_radial_OBME = MSLM1_radial_OBMEs(s_in , s_out , i);
	  const TYPE MSSCE_radial_OBME = MSSCE_radial_OBMEs(s_in , s_out , i);

	  const TYPE MOLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1                 , L , Lc , particle , NADA , MOLP1_radial_OBME , l_in , j_in , l_out , j_out);
	  const TYPE MOLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1                 , L , Lc , particle , NADA , MOLM1_radial_OBME , l_in , j_in , l_out , j_out);
	  const TYPE MSLP1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1 , L , Lc , particle , NADA , MSLP1_radial_OBME , l_in , j_in , l_out , j_out);
	  const TYPE MSLM1_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1 , L , Lc , particle , NADA , MSLM1_radial_OBME , l_in , j_in , l_out , j_out);
	  const TYPE MSSCE_OBME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E                             , L , Lc , particle , NADA , MSSCE_radial_OBME , l_in , j_in , l_out , j_out);

	  const TYPE magnetic_OBME = MOLP1_OBME + MOLM1_OBME + MSLP1_OBME + MSLM1_OBME + MSSCE_OBME;

	  magnetic_OBMEs(s_in , s_out , i) = magnetic_OBME;
	}
}









// Calculation of the array of reduced matrix elements of the electromagnetic transition strength for a given suboperator and radial operator for all one-body basis states
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One uses the radial operator issued from EM_transitions_radial_operator.
// One consider a single operator here, such as electric charge, current, or magnetic orbital or spin part with [Y(L +/- 1) x l or s]^L .
// Matrix elements are reduced here.

void EM_transitions_strength_OBMEs::EM_suboperator_OBMEs_reduced_calc ( 
								       const enum EM_suboperator_type EM_suboperator , 
								       const enum radial_operator_type radial_operator ,
								       const TYPE &q , 
								       const int L , 
								       const int Lc , 
								       const bool is_it_longwavelength_approximation , 
								       const bool is_it_Gauss_Legendre , 
								       const class nucleons_data &data , 
								       class array<TYPE> &OBMEs)
{
  const unsigned int BP_Op = BP_EM_suboperator_determine (EM_suboperator , L);
  
  const double effective_charge = data.get_effective_charge (); 

  const enum particle_type particle = data.get_particle ();

  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int N_nlj = data.get_N_nlj ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class array<TYPE> radial_OBMEs(N_nlj , N_nlj , Nr);
  
  radial_OBMEs_calc (radial_operator , q , L , is_it_longwavelength_approximation , is_it_Gauss_Legendre , BP_Op , data , radial_OBMEs);

  OBMEs = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class nlj_struct &shell_qn_in = shells_qn(s_in);
	const class nlj_struct &shell_qn_out = shells_qn(s_out);

	const int l_in  = shell_qn_in.get_l ();
	const int l_out = shell_qn_out.get_l ();
	  
	const double j_in  = shell_qn_in.get_j ();
	const double j_out = shell_qn_out.get_j ();
	
	if (binary_parity_from_orbital_angular_momentum (l_in + l_out) == BP_Op)
	  {
	    for (unsigned int i = 0 ; i < Nr ; i++)
	      {
		const TYPE radial_OBME = radial_OBMEs(s_in , s_out , i);

		OBMEs(s_in , s_out , i) = EM_suboperator_OBME_reduced_calc (EM_suboperator , L , Lc , particle , effective_charge , radial_OBME , l_in , j_in , l_out , j_out);
	      }
	  }
      }
}








// Calculation of electric or magnetic transition strength reduced matrix elements for all one-body basis states
// -------------------------------------------------------------------------------------------------------------
// The routine for electric or magnetic transition strength reduced matrix elements is called.

void EM_transitions_strength_OBMEs::OBMEs_reduced_calc (
							const enum EM_type EM , 
							const TYPE &q , 
							const int L , 
							const int Lc , 
							const bool is_it_longwavelength_approximation , 
							const bool is_it_Gauss_Legendre , 
							const class nucleons_data &data , 
							class array<TYPE> &OBMEs)
{
  switch(EM)
    {
    case ELECTRIC: electric::OBMEs_reduced_calc (q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs); break;
    case MAGNETIC: magnetic::OBMEs_reduced_calc (q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs); break;

    default: abort_all ();
    }
}








// Calculation of the array of matrix elements of the electromagnetic transition strength for a given suboperator and radial operator for all one-body basis states
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------
// The routine for electromagnetic transition strength reduced matrix elements is called.
// Matrix elements are not reduced here. Reduced matrix elements are calculated first and reduced afterwards.

void EM_transitions_strength_OBMEs::OBMEs_calc (
						const enum EM_type EM , 
						const TYPE &q , 
						const int L ,
						const int ML , 
						const int Lc , 
						const bool is_it_longwavelength_approximation , 
						const bool is_it_Gauss_Legendre ,
						const class nucleons_data &data , 
						class array<TYPE> &OBMEs)
{  
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int N_nlj = data.get_N_nlj ();
  
  class array<TYPE> OBMEs_reduced(N_nlj , N_nlj , Nr);

  OBMEs_reduced_calc (EM , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs_reduced);

  OBMEs_dereduced_strength_calc<TYPE> (L , ML , data , data , OBMEs_reduced , OBMEs);
}








// Calculation of the array of matrix elements of the electromagnetic transition strength for a given suboperator and radial operator for all one-body basis states
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------
// One uses the radial operator issued from EM_transitions_radial_operator.
// One consider a single operator here, such as electric charge, current, or magnetic orbital or spin part with [Y(L +/- 1) x l or s]^L .
// Matrix elements are not reduced here. Reduced matrix elements are calculated first and reduced afterwards.

void EM_transitions_strength_OBMEs::EM_suboperator_OBMEs_calc (
							       const enum EM_suboperator_type EM_suboperator , 
							       const enum radial_operator_type radial_operator , 
							       const TYPE &q ,
							       const int L ,
							       const int ML , 
							       const int Lc , 
							       const bool is_it_longwavelength_approximation , 
							       const bool is_it_Gauss_Legendre ,
							       const class nucleons_data &data , 
							       class array<TYPE> &OBMEs)
{
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int N_nlj = data.get_N_nlj ();

  class array<TYPE> OBMEs_reduced(N_nlj , N_nlj , Nr);

  EM_suboperator_OBMEs_reduced_calc (EM_suboperator , radial_operator , q , L , Lc , is_it_longwavelength_approximation , is_it_Gauss_Legendre , data , OBMEs_reduced);

  OBMEs_dereduced_strength_calc<TYPE> (L , ML , data , data , OBMEs_reduced , OBMEs);
}
