#include "CC_rotor_include/CC_rotor_include.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    print_array_vector_test_status<int> ();

    cout << "====================================================================================================" << endl;
    cout << "========================== Start of the execution of the CC rotor code =============================" << endl;
    cout << "====================================================================================================" << endl << endl;

    const double reference_time = absolute_time_determine ();
  
    class CC_rotor_all_data_class CC_rotor_all_data;

    CC_rotor_all_data.check_and_read_input_file ();

    const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

    const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();
  
    if (calc_type == NUCLEAR_EM_TRANSITION)
      CC_rotor_EM_transitions::CC_states_IN_OUT_EM_transition_calc (CC_rotor_all_data);
    else if (calc_type == NUCLEAR_E_RMS_RADIUS_PLOT)
      CC_rotor_E_rms_radius_plot::E_rms_radius_plot_calc_store (CC_rotor_all_data);
    else if ((calc_type == MOLECULAR) || (calc_type == NUCLEAR_ONE_STATE))    
      { 
	CC_rotor_all_data.build_channels ();
	CC_rotor_all_data.build_potential ();
	CC_rotor_all_data.build_data_for_solvers ();

	class CC_rotor_states_class CC_states (CC_rotor_all_data);
            
	CC_states.solve_CC_equations (CC_rotor_all_data);
      }
    else
      error_message_print_abort ("main: bad calc type");
    

    cout << endl;
    cout << "=============================================================================" << endl;
    cout << "========================== End of the execution =============================" << endl;
    cout << "=============================================================================" << endl << endl;

    const double now = absolute_time_determine () , relative_time = now - reference_time;

    cout << "Elapsed time:" << relative_time << " s" << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }




