#ifndef BASISSTATES_H
#define BASISSTATES_H



/*----------------------------------
  CC_basis_states.H

  Definition of:
  _ CC_fwd_basis_state (class):
  _ CC_bwd_basis_state (class):
  ------------------------------------*/


class CC_fwd_basis_state
{
public:

  CC_fwd_basis_state ();
  
  CC_fwd_basis_state (
		      const bool S_matrix_pole_c , 
		      const unsigned int N_channels_c ,
		      const unsigned int ib_c , 
		      const class array<class CC_rotor_channel_class> &channels_tab_c ,
		      const unsigned int N_bef_R_uniform_c , 
		      const unsigned int N_bef_s_GL_c , 
		      const unsigned int N_bef_R0_GL_c ,
		      const double R_c , 
		      const double s_radial_c , 
		      const double R0_c , 
		      const double R_real_max_c);

  CC_fwd_basis_state (const class CC_fwd_basis_state &X);
  
  void allocate (
		 const bool S_matrix_pole_c , 
		 const unsigned int N_channels_c ,
		 const unsigned int ib_c , 
		 const class array<class CC_rotor_channel_class> &channels_tab_c ,
		 const unsigned int N_bef_R_uniform_c , 
		 const unsigned int N_bef_s_GL_c , 
		 const unsigned int N_bef_R0_GL_c ,
		 const double R_c , 
		 const double s_radial_c , 
		 const double R0_c , 
		 const double R_real_max_c);

  void allocate_fill (const class CC_fwd_basis_state &X);
  
  void deallocate ();

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_ib () const
  {
    return ib;
  }

  double get_R () const
  {
    return R;
  }

  double get_s_radial () const
  {
    return s_radial;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_bef_s_GL () const
  {
    return N_bef_s_GL;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_bef_R0_uniform () const
  {
    return N_bef_R0_uniform;
  }

  const class array<class CC_rotor_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<complex<double> > & get_CC_fwd_basis_wf_bef_R0_tab_uniform () const
  {
    return CC_fwd_basis_wf_bef_R0_tab_uniform;
  }

  const class array<complex<double> > & get_CC_fwd_basis_dwf_bef_R0_tab_uniform () const
  {
    return CC_fwd_basis_dwf_bef_R0_tab_uniform;
  }

  const class array<complex<double> > & get_CC_fwd_basis_wf_bef_s_tab_GL () const
  {
    return CC_fwd_basis_wf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_CC_fwd_basis_dwf_bef_s_tab_GL () const
  {
    return CC_fwd_basis_dwf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_CC_fwd_basis_wf_bef_R0_tab_GL () const
  {
    return CC_fwd_basis_wf_bef_R0_tab_GL;
  }

  const class array<complex<double> > & get_CC_fwd_basis_dwf_bef_R0_tab_GL () const
  {
    return CC_fwd_basis_dwf_bef_R0_tab_GL;
  }

  const class array<complex<double> > & get_CC_fwd_basis_wf_R0_tab () const
  {
    return CC_fwd_basis_wf_R0_tab;
  }

  const class array<complex<double> > & get_CC_fwd_basis_dwf_R0_tab () const
  {
    return CC_fwd_basis_dwf_R0_tab;
  }

  void CC_wf_dwf_d2wf_zero ();

  void forward_integration_before_R (
				     const complex<double> &C0,
				     const class CC_rotor_potential_class &potential ,
				     class CC_rotor_system_integration &SI);

  void change_channels (const complex<double> &E);
  
  friend double used_memory_calc (const class CC_fwd_basis_state &T);
  
private:
  
  bool S_matrix_pole; // true if one calculates a resonant particle-rotor state, false if not
  
  unsigned int N_channels; // number of channels of the coupled-channel equations

  unsigned int ib; // index of the basis channel
  
  double R;  // rotation point of complex scaling

  double s_radial; // s radius in molecular potentials

  double R0; // matching point of wave functions for direct integration

  double R_max; // maximal radius considered on the real-axis. All HO states must be negligible therein.
  
  double step_bef_R_uniform; // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  
  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid  [0 or s:R] (before R) (see spherical_state.cpp)
  
  unsigned int N_bef_s_GL;                               // number of Gauss-Legendre points on ]0:s[ (electron) (see spherical_state.cpp)
  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on [0 or s:R] (before R) (see spherical_state.cpp)
  
  unsigned int N_bef_R0_uniform;                          // number of points on the uniform grid [0:R0] (before R0) for forward integration (see spherical_state.cpp)
    
  class array<class CC_rotor_channel_class> channels_tab; // arrays of the channels entering the coupled-channel equations of the particle-rotor model

  class array<double> r_bef_R_tab_uniform; // Uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]
  
  class array<double> r_bef_s_tab_GL; // Gaussian abscissas before R : r in ]0:s[ (electron)
  class array<double> r_bef_R_tab_GL; // Gaussian abscissas before R : r in ]0:R[ (nucleon) or ]s_radial:R[ (electron).
  
  class array<complex<double> > CC_fwd_basis_wf_bef_R0_tab_uniform;   // basis coupled-channel wave functions for forward integration on the uniform grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  class array<complex<double> > CC_fwd_basis_dwf_bef_R0_tab_uniform;  // basis coupled-channel wave function derivatives after R0 for forward integration on the uniform grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  
  class array<complex<double> > CC_fwd_basis_wf_bef_s_tab_GL;   // basis coupled-channel wave functions after R0 for forward integration on the Gauss-Legendre grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  class array<complex<double> > CC_fwd_basis_dwf_bef_s_tab_GL;  // basis coupled-channel wave function derivatives after R0 for forward integration on the Gauss-Legendre grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  
  class array<complex<double> > CC_fwd_basis_wf_bef_R0_tab_GL;   // basis coupled-channel wave functions after R0 for forward integration on the Gauss-Legendre grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  class array<complex<double> > CC_fwd_basis_dwf_bef_R0_tab_GL;  // basis coupled-channel wave function derivatives after R0 for forward integration on the Gauss-Legendre grid ]0:R[ (nucleon) or ]s_radial:R[ (electron)
  
  class array<complex<double> > CC_fwd_basis_wf_R0_tab;   // basis coupled-channel wave functions on R0 for forward integration
  class array<complex<double> > CC_fwd_basis_dwf_R0_tab;  // basis coupled-channel wave function derivatives on R0 for forward integration

  void init_conditions_calc (
			     const complex<double> &C0,
			     const class CC_rotor_potential_class &potential ,
			     const double r0 ,
			     class vector_class<complex<double> > &U0 ,
			     class vector_class<complex<double> > &dU0) const;
};





class CC_bwd_basis_state
{
public:

  CC_bwd_basis_state ();
  
  CC_bwd_basis_state (
		      const bool S_matrix_pole_c , 
		      const unsigned int N_channels_c , 
		      const unsigned ic_entrance_c ,
		      const unsigned int ib_c , 
		      const class array<class CC_rotor_channel_class> &channels_tab_c ,
		      const unsigned int N_bef_R_uniform_c , 
		      const unsigned int N_aft_R_uniform_c ,
		      const unsigned int N_bef_R_GL_c , 
		      const unsigned int N_aft_R_GL_c ,
		      const double R_c , 
		      const double s_radial_c , 
		      const double R0_c , 
		      const double R_real_max_c);

  CC_bwd_basis_state (const class CC_bwd_basis_state &X);
  
  void allocate (
		 const bool S_matrix_pole_c , 
		 const unsigned int N_channels_c , 
		 const unsigned ic_entrance_c ,
		 const unsigned int ib_c , 
		 const class array<class CC_rotor_channel_class> &channels_tab_c ,
		 const unsigned int N_bef_R_uniform_c , 
		 const unsigned int N_aft_R_uniform_c ,
		 const unsigned int N_bef_R_GL_c , 
		 const unsigned int N_aft_R_GL_c ,
		 const double R_c , 
		 const double s_radial_c , 
		 const double R0_c , 
		 const double R_real_max_c);

  void allocate_fill (const class CC_bwd_basis_state &X);
  
  void deallocate ();

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }
  
  unsigned int get_ib () const
  {
    return ib;
  }

  double get_R () const
  {
    return R;
  }

  double get_s_radial () const
  {
    return s_radial;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_max () const
  {
    return R_max;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R0_uniform () const
  {
    return N_bef_R0_uniform;
  }
  
  unsigned int get_N_aft_R0_uniform () const
  {
    return N_aft_R0_uniform;
  }
  
  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_step_aft_R_real_uniform () const
  {
    return step_aft_R_real_uniform;
  }

  const class array<class CC_rotor_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  const class array<double> & get_u_aft_R_tab_GL () const
  {
    return u_aft_R_tab_GL;
  }

  const class array<double> & get_r_aft_R_real_tab_GL () const
  {
    return r_aft_R_real_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_basis_wf_aft_R0_tab_uniform () const
  {
    return CC_bwd_basis_wf_aft_R0_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_basis_dwf_aft_R0_tab_uniform () const
  {
    return CC_bwd_basis_dwf_aft_R0_tab_uniform;
  }

  const class array<complex<double> > & get_CC_bwd_basis_wf_aft_R0_tab_GL () const
  {
    return CC_bwd_basis_wf_aft_R0_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_basis_dwf_aft_R0_tab_GL () const
  {
    return CC_bwd_basis_dwf_aft_R0_tab_GL;
  }

  const class array<complex<double> > & get_CC_bwd_basis_wf_R0_tab () const
  {
    return CC_bwd_basis_wf_R0_tab;
  }

  const class array<complex<double> > & get_CC_bwd_basis_dwf_R0_tab () const
  {
    return CC_bwd_basis_dwf_R0_tab;
  }

  void CC_wf_dwf_d2wf_zero ();

  void backward_integration_before_R (
				      complex<double> &Cplus_b ,
				      const enum potential_type potential ,
				      const bool is_it_Uminus ,
				      const class array<complex<double> > &l_eff_tab ,
				      const class matrix<complex<double> > &asymptotic_channels ,
				      class CC_rotor_system_integration &SI);

  void change_channels (const complex<double> &E);

  void asymptotic_wave_functions_calc (
				       const complex<double> &Cplus_b ,
				       const bool is_it_Uminus ,
				       const class CC_rotor_potential_class &potential ,
				       const class array<complex<double> > &l_eff_tab ,
				       const class matrix<complex<double> > &asymptotic_channels ,
				       const bool are_wfs_calculated ,
				       const bool is_it_real_axis ,
				       class vector_class <complex<double> > &UR ,
				       class vector_class <complex<double> > &dUR ,
				       class array<complex<double> > &CCb_wf_aft_R_GL ,
				       class array<complex<double> > &CCb_dwf_aft_R_GL ,
				       class array<complex<double> > &CCb_d2wf_aft_R_GL);

  void asymptotic_Hb_dHb_omega_scaled (
				       const int omega ,
				       const complex<double> &kc ,
				       const complex<double> &lb_eff ,
				       const complex<double> &lb_eff_phase ,
				       const complex<double> &lb_eff_star_phase ,
				       class Coulomb_wave_functions &cwf_b ,
				       class Coulomb_wave_functions &cwf_conj_b ,
				       const complex<double> &z ,
				       complex<double> &Hb_scaled ,
				       complex<double> &dHb_scaled) const;

  complex<double> asymptotic_source_calc (
					  const class CC_rotor_potential_class &potential ,
					  const int omega ,
					  const complex<double> &lb_eff ,
					  const unsigned int ic ,
					  const complex<double> &z ,
					  const class vector_class <complex<double> > &Uz) const;

  friend double used_memory_calc (const class CC_bwd_basis_state &T);
    
private:
  
  bool S_matrix_pole; // true if one calculates a resonant particle-rotor state, false if not
  
  unsigned int N_channels; // number of channels of the coupled-channel equations
  
  unsigned int ic_entrance; // index of the entrance channel

  unsigned int ib; // index of the basis channel
  
  double R;  // rotation point of complex scaling

  double s_radial; // s radius in molecular potentials

  double R0; // Radius of the potential close to 5 fm or a0.

  double R_max; // maximal radius considered on the real-axis. All HO states must be negligible therein.
  
  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid [0:s] (electron) or [s_radial:R] (electron) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                          // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on ]0:R[ (nucleon) or ]s_radial:R[ (electron) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                               // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R0_uniform;                          // number of points on the uniform grid [0:R0] (before R0) for backward integration (see spherical_state.cpp)
  unsigned int N_aft_R0_uniform;                          // number of points on the uniform grid [R0:R] for backward integration (see spherical_state.cpp)
    
  double step_bef_R_uniform; // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  
  double step_aft_R_real_uniform; // radial step on the uniform grid on [R:R_real_max], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre

  class array<class CC_rotor_channel_class> channels_tab; // array of the channels entering the coupled-channel equations of the particle-rotor model

  class array<double> r_bef_R_tab_uniform; // Uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]
  
  class array<double> r_bef_R_tab_GL; // Gaussian abscissas before R : r in ]0:R[ (nucleon) or ]s_radial:R[ (electron).
  
  class array<double> u_aft_R_tab_GL; // Gaussian abscissas  u = r^(-4) on ]0:R^{-1/4}[ to deal with r > R in integrals

  class array<double> r_aft_R_real_tab_GL; // Gaussian abscissas after R : r in ]R:R_real_max[ if R_real_max > 0.
  
  class array<complex<double> > CC_bwd_basis_wf_aft_R0_tab_uniform;   // basis coupled-channel wave functions for backward integration on the uniform grid [R0:R]
  class array<complex<double> > CC_bwd_basis_dwf_aft_R0_tab_uniform;  // basis coupled-channel wave function derivatives after R0 for backward integration on the uniform grid [R0:R]

  class array<complex<double> > CC_bwd_basis_wf_aft_R0_tab_GL;   // basis coupled-channel wave functions after R0 for backward integration on the Gauss-Legendre grid [R0:R]
  class array<complex<double> > CC_bwd_basis_dwf_aft_R0_tab_GL;  // basis coupled-channel wave function derivatives after R0 for backward integration on the Gauss-Legendre grid [R0:R]

  class array<complex<double> > CC_bwd_basis_wf_R0_tab;   // basis coupled-channel wave functions on R0 for backward integration
  class array<complex<double> > CC_bwd_basis_dwf_R0_tab;  // basis coupled-channel wave function derivatives on R0 for backward integration

  bool is_it_bound_determine () const;

  void U_asymptotic_conditions_dipolar_calc (
					     const complex<double> &Cplus_b , 
					     const bool is_it_Uminus ,
					     const class array<complex<double> > &l_eff_tab ,
					     const class matrix<complex<double> > &asymptotic_channels ,
					     class vector_class <complex<double> > &UR ,
					     class vector_class <complex<double> > &dUR);

  void U_asymptotic_conditions_no_dipolar_calc (
						const complex<double> &Cplus_b , 
						const bool is_it_Uminus ,
						class vector_class <complex<double> > &UR ,
						class vector_class <complex<double> > &dUR);
  void U_asymptotic_conditions_calc (
				     const enum potential_type potential ,
				     const complex<double> &Cplus_b , 
				     const bool is_it_Uminus ,
				     const class array<complex<double> > &l_eff_tab ,
				     const class matrix<complex<double> > &asymptotic_channels ,
				     class vector_class <complex<double> > &UR ,
				     class vector_class <complex<double> > &dUR);
};

#endif
