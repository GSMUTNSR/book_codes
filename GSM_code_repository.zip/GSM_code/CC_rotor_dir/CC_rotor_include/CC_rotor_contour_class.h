#ifndef CONTOUR_CLASS
#define CONTOUR_CLASS


// This class contains all informations about one contour
// Contours are of arbitrary form (arbitrary number of segments and positions).


class CC_rotor_contour_class
{
public :
  // ================================== members ================================== //

  // constructor

  explicit CC_rotor_contour_class ();

  explicit CC_rotor_contour_class (const class CC_rotor_contour_class &X);

  void allocate_fill (const class CC_rotor_contour_class &X);

  void deallocate ();

  // ================================== methods ================================== //

  class array<complex<double> > & get_tab_k ()
  {
    return tab_k;
  }
  
  const class array<complex<double> > & get_tab_k () const
  {
    return tab_k;
  }

  class array<unsigned int> & get_tab_Nk ()
  {
    return tab_Nk;
  }
  
  const class array<unsigned int> & get_tab_Nk () const
  {
    return tab_Nk;
  }
  
  const class CC_rotor_contour_class & operator = (const class CC_rotor_contour_class &X);

  void check_contour_definition ();

  void print_contour_on_screen ();

  void print_contour_for_plot (const string plot_file_name_);

  void set_partial_wave (const string partial_wave_c);

  string get_partial_wave () const;

  void allocate_tab_k_and_Nk (const unsigned int number_edges_c);

  unsigned int get_number_edges () const;

  unsigned int get_number_points_total () const;

  bool is_partial_wave (const unsigned int l_init , const unsigned int jr_init) const;

  bool is_partial_wave (const unsigned int l_init , const double j_init) const; 

  friend double used_memory_calc (const class CC_rotor_contour_class &T);
  
private :
  
  string partial_wave; // considered partial ("0p3/2", ...)

  unsigned int number_edges; // number of edges on the contour
  
  unsigned int number_points_total; // total number of points on the contour

  class array<complex<double> > tab_k; // array of linear momenta on the contour

  class array<unsigned int> tab_Nk; //  array of numbers of linear momenta on the contour
};

#endif



