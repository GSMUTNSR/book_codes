#ifndef CCROTORJOSTMATRIX_H
#define CCROTORJOSTMATRIX_H


class matrix<complex<double> > CC_rotor_Jost_matrix_calc (
							  const class array<class CC_fwd_basis_state> &fwd_basis , 
							  const class array<class CC_bwd_basis_state> &bwd_basis);





#endif
