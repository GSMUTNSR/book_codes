#ifndef CCROTORBERGGRENDIAGONALIZATION_H
#define CCROTORBERGGRENDIAGONALIZATION_H

enum op_type {OVERLAP_OP , HAMILTONIAN_OP};

namespace CC_rotor_Berggren_diagonalization
{
  complex<double> radial_OBME_bef_R (
				     const enum op_type op,
				     const class CC_rotor_all_data_class &CC_rotor_all_data,
				     const unsigned int ic_in,
				     const unsigned int ic_out,
				     const class spherical_state &wf_in,
				     const class spherical_state &wf_out);

  complex<double> radial_OBME_aft_R_part_of_4 (
					       const enum op_type op,
					       const class CC_rotor_all_data_class &CC_rotor_all_data ,
					       const unsigned int asy_in,
					       const unsigned int asy_out,
					       const unsigned int angle_index,
					       const unsigned int ic_in,
					       const unsigned int ic_out,
					       const class spherical_state &wf_in,
					       const class spherical_state &wf_out);

  complex<double> radial_OBME_aft_R_cut (
					 const class CC_rotor_all_data_class &CC_rotor_all_data ,
					 const unsigned int ic_in , 
					 const unsigned int ic_out ,
					 const class spherical_state &wf_in ,
					 const class spherical_state &wf_out);

  complex<double> radial_OBME_aft_R (
				     const enum op_type op,
				     const class CC_rotor_all_data_class &CC_rotor_all_data,
				     const unsigned int ic_in,
				     const unsigned int ic_out,
				     const class spherical_state &wf_in,
				     const class spherical_state &wf_out);

  complex<double> OBME (
			const enum op_type op,
			const class CC_rotor_all_data_class &CC_rotor_all_data,
			const unsigned int ic_in,
			const unsigned int ic_out,
			const class spherical_state &wf_in,
			const class spherical_state &wf_out);

  void H_calc (
	       const class CC_rotor_all_data_class &CC_rotor_all_data,
	       class matrix<complex<double> > &H);

  void Vccp_tabs_calc (class CC_rotor_all_data_class &CC_rotor_all_data);

  void eigenstate_pole_approximation (
				      const class CC_rotor_all_data_class &CC_rotor_all_data ,
				      complex<double> &E ,
				      class vector_class<complex<double> > &eigenvector ,
				      const string file_name);

  void eigenstate_no_basis_poles_full_calculation (
						   const class CC_rotor_all_data_class &CC_rotor_all_data ,
						   complex<double> &E ,
						   class vector_class<complex<double> > &eigenvector ,
						   const string file_name);

  void eigenstate_Davidson (
			    const class CC_rotor_all_data_class &CC_rotor_all_data ,
			    complex<double> &E ,
			    class vector_class<complex<double> > &eigenvector);


  void eigenstate_calc (
			const class CC_rotor_all_data_class &CC_rotor_all_data ,
			complex<double> &E,
			class vector_class<complex<double> > &eig_vec ,
			const string file_name);



  //--// calcule et affiche des sommes de ME
  void H_test (const class Berggren_data &data , class matrix<complex<double> > &H);
}


#endif
