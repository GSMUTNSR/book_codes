#ifndef CCROTORPOTENTIAL_CLASS
#define CCROTORPOTENTIAL_CLASS


class CC_rotor_potential_class
{
public :

  //  Get and set members
		
  enum potential_type get_potential () const
  {
    return potential;
  }
			
  class dipolar_potential_class & get_dipolar_potential ()
  {
    return dipolar_potential;
  }

  const class dipolar_potential_class & get_dipolar_potential () const
  {
    return dipolar_potential;
  }
		
  class quadrupolar_potential_class & get_quadrupolar_potential ()
  {
    return quadrupolar_potential;
  }

  const class quadrupolar_potential_class & get_quadrupolar_potential () const
  {
    return quadrupolar_potential;
  }
		
  class deformed_WS_class & get_deformed_WS_potential_basis ()
  {
    return deformed_WS_potential_basis;
  }

  const class deformed_WS_class & get_deformed_WS_potential_basis () const
  {
    return deformed_WS_potential_basis;
  }
		
  class deformed_WS_static_class & get_deformed_WS_static_potential_basis ()
  {
    return deformed_WS_static_potential_basis;
  }

  const class deformed_WS_static_class & get_deformed_WS_static_potential_basis () const
  {
    return deformed_WS_static_potential_basis;
  }
		
  class deformed_WS_class & get_deformed_WS_potential ()
  {
    return deformed_WS_potential;
  }

  const class deformed_WS_class & get_deformed_WS_potential () const
  {
    return deformed_WS_potential;
  }
		
  class deformed_WS_static_class & get_deformed_WS_static_potential ()
  {
    return deformed_WS_static_potential;
  }

  const class deformed_WS_static_class & get_deformed_WS_static_potential () const
  {
    return deformed_WS_static_potential;
  }
		
  class Gaussian_potential_class & get_Gaussian_potential ()
  {
    return Gaussian_potential;
  }

  const class Gaussian_potential_class & get_Gaussian_potential () const
  {
    return Gaussian_potential;
  }

  // constructors

  CC_rotor_potential_class ();

  explicit CC_rotor_potential_class (const class CC_rotor_all_data_class &CC_rotor_all_data);
  explicit CC_rotor_potential_class (const class CC_rotor_potential_class &X);

  //Allocation and deallocation		
  void allocate (const class CC_rotor_all_data_class &CC_rotor_all_data);
  void allocate_fill (const class CC_rotor_potential_class &X);
  void deallocate ();

  // ================================== methods ================================== //
  void test_WS_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const;
  void test_WS_static_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const;
  void test_quadrupolar_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const;
  void test_Gaussian_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  friend double used_memory_calc (const class CC_rotor_potential_class &T);
    
private :

  enum potential_type potential;  // type of potential used (deformed WS for nucleon, dipolar, quadruplar for electron)

  // Different potentials which can be used in the particle-rotor model
  // ..._basis potential generates the basis.
  // Other potentials are used in the Hamiltonian.
  
  class dipolar_potential_class dipolar_potential;
  
  class quadrupolar_potential_class quadrupolar_potential;

  class Gaussian_potential_class Gaussian_potential;

  class deformed_WS_class deformed_WS_potential_basis;

  class deformed_WS_static_class deformed_WS_static_potential_basis;

  class deformed_WS_class deformed_WS_potential;

  class deformed_WS_static_class deformed_WS_static_potential;
};

#endif



