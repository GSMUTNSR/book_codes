#ifndef CCROTORERMSRADIUSPLOT_H
#define CCROTORERMSRADIUSPLOT_H


namespace CC_rotor_E_rms_radius_plot
{  
  void E_rms_radius_plot_calc_store (class CC_rotor_all_data_class &CC_rotor_all_data);
}

#endif
