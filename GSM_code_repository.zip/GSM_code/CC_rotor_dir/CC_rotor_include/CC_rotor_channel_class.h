#ifndef CCROTORCHANNELCLASS_H
#define CCROTORCHANNELCLASS_H





/* ----------------------------------
   CC_rotor_channel_class.H

   Definition of:
   _ CC_rotor_channel_class (class).
   ------------------------------------*/


/* CC_rotor_channel_class (class):
   _ contains every information on a channel.

   States are assumed to be bound or resonance states.
   Antibound states are not considered.
   Antibound states typically occur when one has only s-waves, so that without deformation. 
*/

class CC_rotor_channel_class
{
public:
  CC_rotor_channel_class ();
    
  CC_rotor_channel_class (const class CC_rotor_channel_class &X);
    
  void initialize (const class CC_rotor_channel_class &X);

  void allocate_fill (const class CC_rotor_channel_class &X);
  
  void operator = (const class CC_rotor_channel_class &X);
  
  // Static rotor
  CC_rotor_channel_class (
			  const enum particle_type particle_c_c , 	
			  const double kinetic_factor_c_c , 
			  const int ZY_charge_c_c , 
			  const int lc_c , 
			  const double jc_c , 
			  const double K_c , 
			  const complex<double> &E_c);
  
  void initialize (
		   const enum particle_type particle_c_c , 	
		   const double kinetic_factor_c_c , 
		   const int ZY_charge_c_c , 
		   const int lc_c , 
		   const double jc_c , 
		   const double K_c , 
		   const complex<double> &E_c);
  
  // Rotating core
  CC_rotor_channel_class (
			  const enum particle_type particle_c_c , 	
			  const double kinetic_factor_c_c , 
			  const int ZY_charge_c_c , 
			  const int jrc_c , 
			  const int lc_c , 
			  const double jc_c , 
			  const double J_c , 
			  const double I_c , 
			  const complex<double> &E_c);
  
  void initialize (
		   const enum particle_type particle_c_c , 	
		   const double kinetic_factor_c_c , 
		   const int ZY_charge_c_c , 
		   const int jrc_c , 
		   const int lc_c , 
		   const double jc_c , 
		   const double J_c , 
		   const double I_c , 
		   const complex<double> &E_c);

  bool get_is_it_static_core () const
  {
    return is_it_static_core;
  }
  
  enum particle_type get_particle_c () const
  {
    return particle_c;
  }
  
  double get_kinetic_factor_c () const
  {
    return kinetic_factor_c;
  }

  int get_ZY_charge_c () const
  {
    return ZY_charge_c;
  }

  int get_jrc () const
  {
    return jrc;
  }

  int get_lc () const
  {
    return lc;
  }
  
  double get_jc () const
  {
    return jc;
  }
  
  double get_J () const
  {
    return J;
  }

  double get_K () const
  {
    return K;
  }

  double get_I () const
  {
    return I;
  }

  double get_E_Tc () const
  {
    return E_Tc;
  }

  complex<double> get_e_c  () const
  {
    return e_c;
  }

  complex<double> get_kc () const
  {
    return kc;
  }

  complex<double> get_eta_c () const
  {
    return eta_c;
  }
 
  complex<double> get_E () const
  {
    return E;
  }
  
  void E_dependent_values_change (const complex<double> &E_c);
    
private:

  bool is_it_static_core; // true if the rotor is static, false if it is rotating
  
  enum particle_type particle_c; // proton, neutron or electron in the channel c

  double kinetic_factor_c; // 2.m[c]/h^2 factor in the channel c

  int ZY_charge_c; // Z[charge] in the channel c (nucleon)

  int jrc; // rotor angular momentum in the channel c 
  
  int lc; // orbital angular momentum in the channel c 

  double jc; // total particle angular momentum in the channel c 

  double J; // total angular momentum

  double K;  // total angular momentum projection

  double I;  // moment of inertia

  double E_Tc;  // target energy in the channel c 

  complex<double> e_c; // particle energy in the channel c 
  
  complex<double> kc; // particle linear momentum in the channel c 

  complex<double> eta_c; // particle Sommerfeld parameter in the channel c  (nucleon)

  complex<double> E;  // total energy
};

ostream& operator << (ostream &os , const class CC_rotor_channel_class &channel);

double used_memory_calc (const class CC_rotor_channel_class &T);

#endif
