#ifndef CCBERGGRENCLASSES_H
#define CCBERGGRENCLASSES_H


class nlj_struct
{
public:
  nlj_struct ();

  nlj_struct (
	      const int n_c , 
	      const int jr_c , 
	      const int l_c , 
	      const double j_c , 
	      const bool S_matrix_pole_c , 
	      const complex<double> &k_c , 
	      const complex<double> &weight_c ,
	      const unsigned int ic_c);

  void initialize (
		   const int n_c , 
		   const int jr_c , 
		   const int l_c , 
		   const double j_c , 
		   const bool S_matrix_pole_c , 
		   const complex<double> &k_c , 
		   const complex<double> &weight_c ,
		   const unsigned int ic_c);
  
  void initialize (const class nlj_struct &X);
  
  void allocate_fill (const class nlj_struct &X);

  int get_n () const
  {
    return n;
  }
  
  int get_jr () const
  {
    return jr;
  }
  
  int get_l () const
  {
    return l;
  }
  
  double get_j () const
  {
    return j;
  }
  
  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  complex<double> get_k () const
  {
    return k;
  }
  
  complex<double> get_weight () const
  {
    return weight;
  }

  unsigned int get_ic () const
  {
    return ic;
  }
  
  void operator = (const class nlj_struct &X);
  
private:
  
  int n;
  int jr;
  int l;

  double j;

  bool S_matrix_pole;

  complex<double> k;
  complex<double> weight;

  unsigned int ic;
};

double used_memory_calc (const class nlj_struct &T);





class Berggren_data
{
public:

  Berggren_data ();
  
  Berggren_data ( 
		 const unsigned int N_bef_R_uniform_c ,
		 const unsigned int N_aft_R_uniform_c ,
		 const unsigned int N_bef_s_GL_c ,
		 const unsigned int N_bef_R_GL_c ,
		 const unsigned int N_aft_R_GL_c ,
		 const unsigned int Nk_momentum_uniform_c , 
		 const unsigned int Nk_momentum_GL_c , 
		 const double s_c , 
		 const double R_c , 
		 const double R0_c , 
		 const double R_real_max_c ,
		 const double kmax_momentum_c , 
		 const double R_Fermi_momentum_c , 
		 const unsigned int A_equiv_c ,
		 const class array<class CC_rotor_channel_class> &channels_tab_);

  Berggren_data (const class Berggren_data &X);
  
  void allocate ( 
		 const unsigned int N_bef_R_uniform_c ,
		 const unsigned int N_aft_R_uniform_c ,
		 const unsigned int N_bef_s_GL_c ,
		 const unsigned int N_bef_R_GL_c ,
		 const unsigned int N_aft_R_GL_c ,
		 const unsigned int Nk_momentum_uniform_c , 
		 const unsigned int Nk_momentum_GL_c , 
		 const double s_c , 
		 const double R_c , 
		 const double R0_c , 
		 const double R_real_max_c ,
		 const double kmax_momentum_c , 
		 const double R_Fermi_momentum_c , 
		 const unsigned int A_equiv_c ,
		 const class array<class CC_rotor_channel_class> &channels_tab_);

  void allocate_fill (const class Berggren_data &X);

  void deallocate ();

  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }
  
  unsigned int get_N_bef_s_GL () const
  {
    return N_bef_s_GL;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }
  
  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }
  
  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }

  void set_N_nlj (const unsigned int N_nlj_c)
  {
    N_nlj = N_nlj_c;
  }
  
  unsigned short int get_N_nlj () const
  {
    return N_nlj;
  }

  void set_N_nlj_res (const unsigned int N_nlj_res_c)
  {
    N_nlj_res = N_nlj_res_c;
  }
  
  unsigned short int get_N_nlj_res () const
  {
    return N_nlj_res;
  }
  
  double get_s () const
  {
    return s;
  }
  
  double get_R () const
  {
    return R;
  }
  
  double get_R0 () const
  {
    return R0;
  }
  
  double get_R_real_max () const
  {
    return R_real_max;
  }
  
  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }
  
  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }
  
  int get_A_equiv () const
  {
    return A_equiv;
  }
  
  const class array<unsigned int> & get_Nk_peak_tab () const
  {
    return Nk_peak_tab;
  }
  
  class array<unsigned int> & get_Nk_peak_tab ()
  {
    return Nk_peak_tab;
  }

  const class array<unsigned int> & get_Nk_middle_tab () const
  {
    return Nk_middle_tab;
  }

  class array<unsigned int> & get_Nk_middle_tab ()
  {
    return Nk_middle_tab;
  }

  const class array<unsigned int> & get_Nk_max_tab () const
  {
    return Nk_max_tab;
  }

  class array<unsigned int> & get_Nk_max_tab ()
  {
    return Nk_max_tab;
  }

  const class array<complex<double> > & get_k_peak_tab () const
  {
    return k_peak_tab;
  }
  
  class array<complex<double> > & get_k_peak_tab ()
  {
    return k_peak_tab;
  }

  const class array<double> & get_k_middle_tab () const
  {
    return k_middle_tab;
  }
  
  class array<double> & get_k_middle_tab ()
  {
    return k_middle_tab;
  }

  const class array<double> & get_k_max_tab () const
  {
    return k_max_tab;
  }
  
  class array<double> & get_k_max_tab ()
  {
    return k_max_tab;
  }

  const class array<class spherical_state> & get_shells () const
  {
    return shells;
  }

  class array<class spherical_state> & get_shells ()
  {
    return shells;
  }

  const class array<class nlj_struct> & get_shells_quantum_numbers () const
  {
    return shells_quantum_numbers;
  }
  
  class array<class nlj_struct> & get_shells_quantum_numbers ()
  {
    return shells_quantum_numbers;
  }

  const class array<class CC_rotor_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  class array<class CC_rotor_channel_class> & get_channels_tab ()
  {
    return channels_tab;
  }

  const class CC_rotor_contour_data_class & get_contours_data () const
  {
    return contours_data;
  }
  
  class CC_rotor_contour_data_class & get_contours_data ()
  {
    return contours_data;
  }

  void build_Berggren_data    (class CC_rotor_all_data_class &CC_rotor_all_data);
  void calc_resonant_states   (class CC_rotor_all_data_class &CC_rotor_all_data);
  void calc_scattering_states (class CC_rotor_all_data_class &CC_rotor_all_data);

  friend double used_memory_calc (const class Berggren_data &T);
  
private:

  unsigned int N_channels; // number of channels of the coupled-channel equations
  
  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid  [0 or s:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                          // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_s_GL;                               // number of Gauss-Legendre points on [0:s] (before s) (see spherical_state.cpp) (molecular case only)
  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on [0 or s:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                               // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)

  unsigned int Nk_momentum_uniform;                      // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_GL;                           // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  
  unsigned int N_nlj , N_nlj_res;                        // number of shells, for which n,l,j are fixed, for full space or pole approximation space

  double s;  // s radius in molecular potentials

  double R;  // rotation point of complex scaling

  double R0; // matching point of wave functions for direct integration
  
  double R_real_max; // maximal radius considered on the real-axis. All HO states must be negligible therein.

  double kmax_momentum;                             // maximal momentum for the calculation of densities and correlation densities in momentum space
  
  double R_Fermi_momentum;                          // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.
  
  int A_equiv; // number of nucleons A in the nucleus or zero for molecules. It is denoted as "equivalent" as it is zero for molecules, where A does not enter the Hamiltonian.

  class array<unsigned int> Nk_peak_tab;   // numbers of discretized scattering states on the segment [0:k[peak]]
  class array<unsigned int> Nk_middle_tab; // numbers of discretized scattering states on the segment [k[peak]:k[middle]]
  class array<unsigned int> Nk_max_tab;    // numbers of discretized scattering states on the segment [k[middle]:k[max]]

  class array<complex<double> > k_peak_tab; // linear momenta of discretized scattering states on the segment [0:k[peak]]

  class array<double> k_middle_tab; // linear momenta of discretized scattering states on the segment [k[peak]:k[middle]]
  
  class array<double> k_max_tab;    // linear momenta of discretized scattering states on the segment [k[middle]:k[max]]

  class array<class spherical_state> shells; // Array of one-body wave functions (see spherical_state.cpp)
  
  class array<class nlj_struct> shells_quantum_numbers; // Array of structures providing with the quantum numbers of basis shells

  class array<CC_rotor_channel_class> channels_tab;  // array of the channels entering the coupled-channel equations of the particle-rotor model

  class CC_rotor_contour_data_class contours_data; // classes containing data about contours
};

#endif
