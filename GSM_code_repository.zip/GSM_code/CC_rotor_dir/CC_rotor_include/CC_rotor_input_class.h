#ifndef CCROTORINPUTCLASS_H
#define CCROTORINPUTCLASS_H

// Input file data are read and stored in this class.
// Automatic checks are done to make sure the input file is written properly.
// Trivial inconsistencies between input data are also detected (min > max for example)
// 


class CC_rotor_input_class
{
public:

  // ================================== methods ================================== //

  // constructor

  explicit CC_rotor_input_class ();

  explicit CC_rotor_input_class (const class CC_rotor_input_class &X);

  void allocate_fill (const class CC_rotor_input_class &X);
  
  void deallocate ();
  
  // get members 

  enum calc_type_rotor_CC get_calc_type () const
  {
    return calc_type;
  }

  bool get_are_wfs_stored () const
  {
    return are_wfs_stored;
  }

  bool get_are_radial_form_factors_densities_stored () const
  {
    return are_radial_form_factors_densities_stored;
  }

  bool get_is_basis_fixed_for_E_rms_radius_plot () const
  {
    return is_basis_fixed_for_E_rms_radius_plot;
  }

  enum potential_type get_potential () const
  {
    return potential;
  }

  double get_s () const
  {
    return s;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R () const
  {
    return R;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }
  
  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }

  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }

  double get_rmin_for_fit () const
  {
    return rmin_for_fit;
  }
  
  double get_rmax_for_fit () const
  {
    return rmax_for_fit;
  }

  unsigned int get_N_bef_s_GL () const
  {
    return N_bef_s_GL;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_N_asymptotic_fit () const
  {
    return N_asymptotic_fit;
  }

  double get_I () const
  {
    return I;
  }

  bool get_is_I_tab_used () const
  {
    return is_I_tab_used;
  }

  int get_lmax () const
  {
    return lmax;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  double get_J () const
  {
    return J;
  }

  double get_K_static () const
  {
    return K_static;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }

  bool get_pole_approximation () const
  {
    return pole_approximation;
  }

  unsigned int get_Davidson_N_restarts () const
  {
    return Davidson_N_restarts;
  }

  double get_Davidson_eigenvector_precision () const
  {
    return Davidson_eigenvector_precision;
  }

  unsigned int get_Davidson_max_dimension_subspace () const
  {
    return Davidson_max_dimension_subspace;
  }

  double get_real_E () const
  {
    return real_E;
  }

  double get_Gamma () const
  {
    return Gamma;
  }

  complex<double> get_E () const
  {
    return E;
  }

  int get_nmax_bound_res () const
  {
    return nmax_bound_res;
  }

  unsigned int get_Nk_peak () const
  {
    return Nk_peak;
  }

  unsigned int get_Nk_middle () const
  {
    return Nk_middle;
  }

  unsigned int get_Nk_max () const
  {
    return Nk_max;
  }

  complex<double> get_k_peak () const
  {
    return k_peak;
  }

  double get_k_middle () const
  {
    return k_middle;
  }

  double get_k_max () const
  {
    return k_max;
  }

  double get_Gamma_max () const
  {
    return Gamma_max;
  }

  double get_b_HO () const
  {
    return b_HO;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }

  bool get_is_CC_solver_direct_integration () const
  {
    return is_CC_solver_direct_integration;
  }

  bool get_is_asymptotic_wave_function_fit_used () const
  {
    return is_asymptotic_wave_function_fit_used;
  }

  double get_mu () const
  {
    return mu;
  }

  double get_Qpm () const
  {
    return Qpm;
  }

  double get_alpha_0 () const
  {
    return alpha_0;
  }

  double get_alpha_2 () const
  {
    return alpha_2;
  }

  double get_r0 () const
  {
    return r0;
  }

  double get_Qzz () const
  {
    return Qzz;
  }

  double get_V0 () const
  {
    return V0;
  }

  double get_rc () const
  {
    return rc;
  }

  unsigned int get_N_Qpm_BEM_max () const
  {
    return N_Qpm_BEM_max;
  }

  double get_Qpm_BEM_initial () const
  {
    return Qpm_BEM_initial;
  }

  unsigned int get_N_V0_Gaussian_BEM_max () const
  {
    return N_V0_Gaussian_BEM_max;
  }

  double get_V0_Gaussian_BEM_initial () const
  {
    return V0_Gaussian_BEM_initial;
  }

  int get_Z () const
  {
    return Z;
  }

  int get_N () const
  {
    return N;
  }

  int get_A () const
  {
    return A;
  }

  double get_mass_modif () const
  {
    return mass_modif;
  }

  double get_nucleon_mass_for_calc () const
  {
    return nucleon_mass_for_calc;
  }

  unsigned int get_Nt () const
  {
    return Nt;
  }

  unsigned int get_Nr () const
  {
    return Nr;
  }
  
  unsigned int get_N_points () const
  {
    return N_points;
  }

  int get_ZY_charge () const
  {
    return ZY_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }
  
  double get_d () const
  {
    return d;
  }

  double get_R0_WS () const
  {
    return R0_WS;
  }

  double get_beta_2 () const
  {
    return beta_2;
  }

  double get_Vo_basis () const
  {
    return Vo_basis;
  }
  
  double get_Vo_debut () const
  {
    return Vo_debut;
  }
  
  double get_Vo_end () const
  {
    return Vo_end;
  }
  
  double get_Vo () const
  {
    return Vo;
  }

  double get_Vso () const
  {
    return Vso;
  }
  
  double get_Vo_basis_IN () const
  {
    return Vo_basis_IN;
  }

  double get_Vo_basis_OUT () const
  {
    return Vo_basis_OUT;
  }
  
  double get_Vo_IN () const
  {
    return Vo_IN;
  }

  double get_Vo_OUT () const
  {
    return Vo_OUT;
  }

  double get_V0_Gaussian () const
  {
    return V0_Gaussian;
  }

  double get_r0_Gaussian () const
  {
    return r0_Gaussian;
  }

  double get_mu_Gaussian () const
  {
    return mu_Gaussian;
  }

  int get_polarity_Gaussian () const
  {
    return polarity_Gaussian;
  }

  unsigned int get_eigenvector_index () const
  {
    return eigenvector_index;
  }

  enum EM_type get_EM () const
  {
    return EM;
  }

  int get_L () const
  {
    return L;
  }
  
  bool get_is_it_longwavelength_approximation () const
  {
    return is_it_longwavelength_approximation;
  }

  double get_effective_charge () const
  {
    return effective_charge;
  }

  unsigned int get_BP_IN () const
  {
    return BP_IN;
  }

  unsigned int get_BP_OUT () const
  {
    return BP_OUT;
  }

  double get_J_IN () const
  {
    return J_IN;
  }

  double get_J_OUT () const
  {
    return J_OUT;
  }

  unsigned int get_eigenvector_index_IN () const
  {
    return eigenvector_index_IN;
  }

  unsigned int get_eigenvector_index_OUT () const
  {
    return eigenvector_index_OUT;
  }

  void set_BP (const unsigned int X)
  {
    BP = X;
  }

  void set_J (const double X)
  {
    J = X;
  }
  
  void set_K_static (const double X)
  {
    K_static = X;
  }

  void set_eigenvector_index (const unsigned int X)
  {
    eigenvector_index = X;
  }

  void set_Vo_basis (const double X)
  {
    Vo_basis = X;
  }
  
  void set_Vo (const double X)
  {
    Vo = X;
  }

  void set_E (const complex<double> &X)
  {
    E = X;
  }

  const class CC_rotor_contour_data_class & get_contours_data () const
  {
    return contours_data;
  }

  const class array<unsigned int> & get_rotor_angular_momenta () const
  {
    return rotor_angular_momenta;
  }

  const class array<double> & get_moments_of_inertia () const
  {
    return moments_of_inertia;
  }

  const class array<string> & get_core_shells_tab () const
  {
    return core_shells_tab;
  }

  const class array<string> & get_contours_tab_shells () const
  {
    return contours_tab_shells;
  }

  const class array<complex<double> > & get_contours_tab_k_peak () const
  {
    return contours_tab_k_peak;
  }

  const class array<double> & get_contours_tab_k_middle () const
  {
    return contours_tab_k_middle;
  }

  const class array<double> & get_contours_tab_k_max () const
  {
    return contours_tab_k_max;
  }

  const class array<unsigned int> & get_contours_tab_Nk_peak () const
  {
    return contours_tab_Nk_peak;
  }

  const class array<unsigned int> & get_contours_tab_Nk_middle () const
  {
    return contours_tab_Nk_middle;
  }

  const class array<unsigned int> & get_contours_tab_Nk_max () const
  {
    return contours_tab_Nk_max;
  }

  const class array<double> & get_E_BEM_start_tab () const
  {
    return E_BEM_start_tab;
  }

  const class array<double> & get_G_BEM_start_tab () const
  {
    return G_BEM_start_tab;
  }

  void set_Ef_BEM_start_tab (class array<complex<double> > &X)
  {
    Ef_BEM_start_tab = X;
  }
  
  const class array<complex<double> > & get_Ef_BEM_start_tab () const
  {
    return Ef_BEM_start_tab;
  }

  class array<complex<double> > & get_Ef_BEM_start_tab ()
  {
    return Ef_BEM_start_tab;
  }
  
  // ================================== members ================================== //

  void read_input_data_from_file ();

  double get_moment_of_inertia (const int jr) const;

  void store_input_data_for_fit ();

  friend double used_memory_calc (const class CC_rotor_input_class &T);
  
private :
    
  // ================================== methods ================================== //

  void read_store_potential_constants ();

  void read_store_radial_momentum_parameters ();

  void read_store_rotor_state_data ();

  void read_store_EM_transition_data ();

  void check_input_data_consistency ();

  void read_and_print_input_file_E_G_BEM_start ();
  
  void read_and_print_input_file_contours ();
  
  void store_input_file_tables_core_shells ();

  void store_input_file_table_moment_of_inertia_nuclear_case ();
  
  void read_store_all_E_G_BEM_start_contour_tables ();

  // ================================== values ================================== //

  enum calc_type_rotor_CC calc_type; // type of calculation : MOLECULAR , NUCLEAR_ONE_STATE , NUCLEAR_E_RMS_RADIUS_PLOT , NUCLEAR_EM_TRANSITION

  bool are_wfs_stored; // true if coupled-channel wave functions are stored on disk, false if not

  bool are_radial_form_factors_densities_stored; // true if squared coupled-channel wave functions (eadial form factors) are stored on disk, false if not

  bool is_basis_fixed_for_E_rms_radius_plot; // true if one uses the same WS basis for all energies and rms radii with varying Hamiltonian WS potentials, false if they change and basis and Hamiltonian Ws potentials are equal

  enum potential_type potential; // type of potential used (deformed WS for nucleon, dipolar, quadruplar for electron)

  double s;  // s radius in molecular potentials

  double R0; // matching point of wave functions for direct integration
  
  double R;  // rotation point of complex scaling
  
  double R_real_max; // maximal radius considered on the real-axis. All HO states must be negligible therein.
  
  double kmax_momentum;                             // maximal momentum for the calculation of densities and correlation densities in momentum space
  
  double R_Fermi_momentum;                          // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.

  unsigned int N_bef_s_GL;                               // number of Gauss-Legendre points on [0:s] (before s) (see spherical_state.cpp) (molecular case only)
  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on [0 or s:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                               // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)
  
  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid  [0 or s:R] (before R) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                          // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)

  unsigned int Nk_momentum_uniform;                      // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_GL;                           // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  
  double I; // moment of inertia
  
  bool is_I_tab_used; // true if a table of moments of inertia is used to define moments of inertia, false if one has onely moment of inertia

  int lmax; // maximal orbital angular momentum used in coupled-channel equations

  enum particle_type particle; // proton, neutron, electron

  double J; // total angular momentum
  
  unsigned int BP; // binary parity (see observables_basic_functions.cpp for definition) 

  bool S_matrix_pole; // true if one calculates a resonant particle-rotor state, false if not
  
  bool pole_approximation; // true if one uses pole approximation, false if not

  unsigned int Davidson_N_restarts; // number of restarts in the Jacobi-Davidson method

  double Davidson_eigenvector_precision; // precision used in the Jacobi-Davidson method

  unsigned int Davidson_max_dimension_subspace; // maximal number of vectors used in the subspace in the Jacobi-Davidson method

  double real_E;   // total real part of energy
  
  double Gamma;  // total width

  complex<double> E;  // total energy

  int nmax_bound_res; // maximal principal quantum number of resonant states in the Berggren basis

  unsigned int Nk_peak;   // number of discretized scattering states on the segment [0:k[peak]]
  unsigned int Nk_middle; // number of discretized scattering states on the segment [k[peak]:k[middle]]
  unsigned int Nk_max;    // number of discretized scattering states on the segment [k[middle]:k[max]]

  complex<double> k_peak; // linear momentum k[peak] on the segment [0:k[peak]]
  
  double k_middle; // linear momentum k[middle] on the segment [k[peak]:k[middle]]
  
  double k_max; // linear momentum k[max] on the segment [k[middle]:k[max]]

  double Gamma_max; // maximal width of resonance Berggren basis states

  double b_HO; // HO length

  unsigned int ic_entrance; // index of entrance channel

  bool is_CC_solver_direct_integration; // true if one uses direct integration to solve coupled-channel equations, false if one uses Berggren basis diagonalization

  bool is_asymptotic_wave_function_fit_used; // true if one fits the coupled-channel wave functions in the asymptotic region with a simple eexponential ansatz, false if not




  
  // Parameters of molecular potentials
  
  double mu;
  double Qpm;
  double alpha_0;
  double alpha_2;
  double r0;
  double Qzz;
  double V0;
  double rc;



  
  // parameters to control the BEM basis states calculation in the quadrupolar case

  unsigned int N_Qpm_BEM_max;
  
  double Qpm_BEM_initial;

  complex<double> E_BEM_initial;

  unsigned int N_V0_Gaussian_BEM_max;

  double V0_Gaussian_BEM_initial;




  
  int A; // number of nucleons (nucleus)
  int Z; // number of protons  (nucleus)
  int N; // number of neutrons (nucleus)

  double mass_modif; // recoil correction in amu
  
  double nucleon_mass_for_calc; // mass of the nucleon used i h^2/2m

  unsigned int Nt; // number of theta angles
  unsigned int Nr; // number of radii
  
  unsigned int N_points; // number of WS potentials depths to plot energy or rms radius vs. WS potential depth or energy. Last values are then like points for figure.

  int ZY_charge; // charge of the nucleus

  double R_charge; // charge radius of the WS potential

  // Parameters of WS potentials
  
  double d;
  double R0_WS;
  double beta_2;
  
  double Vo_basis;
  double Vo_debut;
  double Vo_end;
  double Vo;
  
  double Vso;


  
  // Parameters of Gaussian potentials
  
  double V0_Gaussian;
  double r0_Gaussian;
  double mu_Gaussian;

  int polarity_Gaussian;



  
  unsigned int eigenvector_index; // index of the many-body eigenvector (0 in 1-(0))

  enum EM_type EM; // type of electromagnetic transition (E1, M1, E2, ...)

  int L; // multipole of the electromagnetic transition (1 E1 or M1, 2 in E2,...)

  double K_static; // conserved K-projection of total angular momentum with a static core.
  
  bool is_it_longwavelength_approximation; // true if one uses longwavelength approximation in electromagnetic transition, false if not

  double effective_charge; // effective charge used in electromagnetic transition

  unsigned int BP_IN;  // binary parity of in the |Psi[in]>  state in <Psi[out] | EM | Psi[in]>  (see observables_basic_functions.cpp for definition)  
  unsigned int BP_OUT; // binary parity of in the |Psi[out]> state in <Psi[out] | EM | Psi[in]>  (see observables_basic_functions.cpp for definition)  

  double J_IN;  // total angular momentum of in the |Psi[in]>  state in <Psi[out] | EM | Psi[in]>
  double J_OUT; // total angular momentum of in the |Psi[out]> state in <Psi[out] | EM | Psi[in]>

  unsigned int eigenvector_index_IN;  // eigenvector index of in the |Psi[in]>  state in <Psi[out] | EM | Psi[in]> (0 in 1-(0))
  unsigned int eigenvector_index_OUT; // eigenvector index of in the |Psi[out]> state in <Psi[out] | EM | Psi[in]> (0 in 1-(0))
  
  double Vo_basis_IN;  // WS basis potential depth for the |Psi[in]>  state in <Psi[out] | EM | Psi[in]>
  double Vo_basis_OUT; // WS basis potential depth for the |Psi[out]> state in <Psi[out] | EM | Psi[in]>
  
  double Vo_IN;  // WS Hamiltonian potential depth for the |Psi[in]>  state in <Psi[out] | EM | Psi[in]>
  double Vo_OUT; // WS Hamiltonian potential depth for the |Psi[out]> state in <Psi[out] | EM | Psi[in]>

  unsigned int N_asymptotic_fit;  // number of points for the fit of the coupled-channel wave functions in the asymptotic region

  double rmin_for_fit; // r[min] used for the fit of the coupled-channel wave functions in the asymptotic region
  double rmax_for_fit; // r[max] used for the fit of the coupled-channel wave functions in the asymptotic region
  
  class CC_rotor_contour_data_class contours_data; // classes containing data about contours

  class array<unsigned int> rotor_angular_momenta; // array of rotor angular momenta

  class array<double> moments_of_inertia; // array of moments of inertia

  class array<string> core_shells_tab; // array of shells occupied in the core, of the form "0s1/2"

  class array<string> contours_tab_shells; 

  class array<complex<double> > contours_tab_k_peak; // linear momenta of discretized scattering states on the segment [0:k[peak]]

  class array<double> contours_tab_k_middle; // linear momenta of discretized scattering states on the segment [k[peak]:k[middle]]

  class array<double> contours_tab_k_max;    // linear momenta of discretized scattering states on the segment [k[middle]:k[max]]

  class array<unsigned int> contours_tab_Nk_peak;   // numbers of discretized scattering states on the segment [0:k[peak]]

  class array<unsigned int> contours_tab_Nk_middle; // numbers of discretized scattering states on the segment [k[peak]:k[middle]]

  class array<unsigned int> contours_tab_Nk_max;    // numbers of discretized scattering states on the segment [k[middle]:k[max]]

  class array<double> E_BEM_start_tab; // starting energies used to search the basis states of the Berggren Expansion Method (BEM)
  class array<double> G_BEM_start_tab; // starting widths   used to search the basis states of the Berggren Expansion Method (BEM)

  class array<complex<double> > Ef_BEM_start_tab; // complex starting energies used to search the basis states of the Berggren Expansion Method (BEM)
};

#endif



