#ifndef CCROTORSYSTEMINTEGRATIONH_H
#define CCROTORSYSTEMINTEGRATIONH_H


/* CC_rotor_system_integration (class):
   _ contains functions to integrate the ...

   One uses the Burlisch-Stoer-Henrici method , where one integrates on different meshes
   with the Henrici method , and then use the Richardson method to extrapolate the final result. 
*/


class CC_rotor_system_integration
{
public:
  CC_rotor_system_integration ();
  
  CC_rotor_system_integration (
			       const int N_channels_c , 
			       const class CC_rotor_potential_class &CC_rotor_potential_c , 
			       const class array<class CC_rotor_channel_class> &channels_tab_c);

  CC_rotor_system_integration (const class CC_rotor_system_integration &X);
			  
  void allocate (
		 const int N_channels_c , 
		 const class CC_rotor_potential_class &CC_rotor_potential_c , 
		 const class array<class CC_rotor_channel_class> &channels_tab_c);
  
  void allocate_fill (const class CC_rotor_system_integration &X);

  void deallocate ();

  void operator() (
		   const double r0 , 
		   const class vector_class<complex<double> > &U0 , 
		   const class vector_class<complex<double> > &dU0 , 
		   const double r , 
		   class vector_class<complex<double> > &U , 
		   class vector_class<complex<double> > &dU);

  friend double used_memory_calc (const class CC_rotor_system_integration &T);
  
private:

  unsigned int N_channels; // number of channels

  class CC_rotor_potential_class CC_rotor_potential; // class containing data about the Hamiltonian potential

  class array<class CC_rotor_channel_class> channels_tab; // array of the channels entering the coupled-channel equations of the particle-rotor model
  
  unsigned int m_tab[7];                   // integers used in the extrapolation method.

  double one_over_m_tab[7];                // doubles used in the extrapolation method.

  double interpolation_term_tab[28];       // doubles used in the extrapolation method.

  mutable double H_over_m_tab[7];          // doubles storing H/m, when one integrates from r0 to r = r0 + m.H

  // Work numbers used in the direct integration method
  
  class vector_class<complex<double> > h_square_F_r_U_tab;

  class vector_class<complex<double> > U_debut;
  class vector_class<complex<double> > dU_debut;

  class vector_class<complex<double> > U_end[7];
  class vector_class<complex<double> > dU_end[7];

  class vector_class<complex<double> > U_extrapolated;
  class vector_class<complex<double> > U_extrapolated_next;
  class vector_class<complex<double> > dU_extrapolated_next;

  class vector_class<complex<double> > Res;
  class vector_class<complex<double> > Delta;

  void extrapolation_in_zero (
			      const unsigned int n , 
			      const class vector_class<complex<double> > F[] , 
			      class vector_class<complex<double> > &F_in_zero);

  void F_r_U_tab_calc (
		       const double r , 
		       const class vector_class<complex<double> > &U , 
		       class vector_class<complex<double> > &F_r_U_tab);

  void integration_Henrici (
			    const unsigned int m , 
			    const double h , 
			    const double r0 , 
			    const class vector_class<complex<double> > &U0 , 
			    const class vector_class<complex<double> > &dU0 , 
			    const double r , 
			    class vector_class<complex<double> > &U , 
			    class vector_class<complex<double> > &dU);
};

#endif

