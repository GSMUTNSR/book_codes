#ifndef CCROTORALLDATACLASS_H
#define CCROTORALLDATACLASS_H

class CC_rotor_all_data_class
{
public :

  // constructor

  explicit CC_rotor_all_data_class ();
  
  explicit CC_rotor_all_data_class (const class CC_rotor_all_data_class &X);
  
  ~CC_rotor_all_data_class ();
  
  void allocate_fill (const class CC_rotor_all_data_class &X);
  
  void deallocate ();
  
  // ================================== methods ================================== //
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }
  
  unsigned int get_Nr_fit () const
  {
    return Nr_fit;
  }
  
  class CC_rotor_input_class & get_CC_rotor_input () 
  {
    return CC_rotor_input;
  }
  
  const class CC_rotor_input_class & get_CC_rotor_input () const
  {
    return CC_rotor_input;
  }

  class array<class CC_rotor_channel_class> & get_channels_tab () 
  {
    return channels_tab;
  }
  
  const class array<class CC_rotor_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }
  
  class CC_rotor_potential_class & get_CC_rotor_potential () 
  {
    return CC_rotor_potential;
  }
  
  const class CC_rotor_potential_class & get_CC_rotor_potential () const
  {
    return CC_rotor_potential;
  }
  
  class Berggren_data & get_data () 
  {
    return data;
  }

  const class Berggren_data & get_data () const
  {
    return data;
  }

  class array<double> & get_Vccp_tab_bef_s_GL () 
  {
    return Vccp_tab_bef_s_GL;
  }

  const class array<double> & get_Vccp_tab_bef_s_GL () const
  {
    return Vccp_tab_bef_s_GL;
  }
  
  class array<double> & get_Vccp_tab_bef_R_GL () 
  {
    return Vccp_tab_bef_R_GL;
  }

  const class array<double> & get_Vccp_tab_bef_R_GL () const
  {
    return Vccp_tab_bef_R_GL;
  }
  
  class array<complex<double> > & get_Vccp_tab_aft_R_GL () 
  {
    return Vccp_tab_aft_R_GL;
  }

  const class array<complex<double> > & get_Vccp_tab_aft_R_GL () const
  {
    return Vccp_tab_aft_R_GL;
  }
  
  class array<double> & get_Vccp_tab_aft_R_GL_real () 
  {
    return Vccp_tab_aft_R_GL_real;
  }

  const class array<double> & get_Vccp_tab_aft_R_GL_real () const
  {
    return Vccp_tab_aft_R_GL_real;
  }

  void check_and_read_input_file ();
  void build_channels ();
  void build_potential ();
  void build_Berggren_basis ();
  void calc_potential_channel_channel_MEs_Vccp ();
  void build_data_for_solvers ();

  friend double used_memory_calc (const class CC_rotor_all_data_class &T);

private :

  class CC_rotor_input_class CC_rotor_input; // class containing all date issued from the input file

  class array<class CC_rotor_channel_class> channels_tab; // array of the channels entering the coupled-channel equations of the particle-rotor model

  class CC_rotor_potential_class CC_rotor_potential; // class containing all the potentials which can be used in the particle-rotor model

  class Berggren_data data; //class containing the Berggren basis

  unsigned int N_channels; // Number of channels of the coupled-channel equations of the particle-rotor model
  
  unsigned int Nr_fit; // Number of points for the fit of the coupled-channel wave function of dipolar potential in the asymptotic region

  class array<double> Vccp_tab_bef_s_GL; // coupled-channel potentials before s
  class array<double> Vccp_tab_bef_R_GL; // coupled-channel potentials before R

  class array<complex<double> > Vccp_tab_aft_R_GL; // coupled-channel potentials after R (complex)

  class array<double> Vccp_tab_aft_R_GL_real; // coupled-channel potentials after R (real)

  // ================================== methods ================================== //
  
  void N_channels_calc_static_core ();
  
  void fill_channels_static_core ();
  
  void N_channels_calc_rotating_core ();  

  void fill_channels_rotating_core ();
};

#endif
