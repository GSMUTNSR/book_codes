#ifndef CCROTORSTATESCLASS_H
#define CCROTORSTATESCLASS_H



class CC_rotor_states_class
{
public:
  
  CC_rotor_states_class ();
  
  CC_rotor_states_class (const class CC_rotor_all_data_class &CC_rotor_all_data);

  CC_rotor_states_class (const class CC_rotor_states_class &X);

  void allocate (const class CC_rotor_all_data_class &CC_rotor_all_data);
  
  void allocate_fill (const class CC_rotor_states_class &X);

  void deallocate ();

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
    
  enum potential_type get_potential () const
  {
    return potential;
  }
  
  unsigned int get_N_channels () const
  {
    return N_channels;
  }

  unsigned int get_ic_entrance () const
  {
    return ic_entrance;
  }
  
  double get_R () const
  {
    return R;
  }
  
  double get_matching_point () const
  {
    return matching_point;
  }

  double get_s_radial () const
  {
    return s_radial;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_max () const
  {
    return R_max;
  }

  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }

  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }
  
  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }
  
  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_N_bef_s_GL () const
  {
    return N_bef_s_GL;
  }
  
  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R0_uniform () const
  {
    return N_bef_R0_uniform;
  }
  
  unsigned int get_N_aft_R0_uniform () const
  {
    return N_aft_R0_uniform;
  }

  unsigned int get_Nk_momentum_uniform () const
  {
    return Nk_momentum_uniform;
  }
  
  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }
  
  unsigned int get_BP () const
  {
    return BP;
  }
  
  double get_J () const
  {
    return J;
  }
  
  double get_K_static () const
  {
    return K_static;
  }

  complex<double> get_E () const
  {
    return E;
  }
  
  complex<double> get_rms_radius () const
  {
    return rms_radius;
  }

  bool get_is_E_ok () const
  {
    return is_E_ok;
  }

  bool get_is_asymptotic_wave_function_fit_used () const
  {
    return is_asymptotic_wave_function_fit_used;
  }

  unsigned int get_Nt () const
  {
    return Nt;
  }
  
  const class array<class CC_fwd_basis_state > & get_fwd_basis () const
  {
    return fwd_basis;
  }

  const class array<class CC_bwd_basis_state > & get_bwd_basis () const
  {
    return bwd_basis;
  }

  const class CC_bwd_basis_state & get_bwd_U_minus () const
  {
    return bwd_U_minus;
  }

  const class array<complex<double> > & get_asymptotic_fit_tab () const
  {
    return asymptotic_fit_tab;
  }

  const class vector_class<complex<double> > & get_eigenvector () const
  {
    return eigenvector;
  }

  const class array<class CC_rotor_channel_class> & get_channels_tab () const
  {
    return channels_tab;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_r_bef_s_tab_GL () const
  {
    return r_bef_s_tab_GL;
  }

  const class array<double> & get_w_bef_s_tab_GL () const
  {
    return w_bef_s_tab_GL;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }

  const class array<double> & get_r_aft_R_tab_GL_real () const
  {
    return r_aft_R_tab_GL_real;
  }

  const class array<double> & get_w_aft_R_tab_GL_real () const
  {
    return w_aft_R_tab_GL_real;
  }

  const class array<complex<double> > & get_r_aft_R_tab_GL_complex () const
  {
    return r_aft_R_tab_GL_complex;
  }

  const class array<complex<double> > & get_w_aft_R_tab_GL_complex () const
  {
    return w_aft_R_tab_GL_complex;
  }
  
  const class array<double> & get_u_aft_R_GL () const
  {
    return u_aft_R_GL;
  }

  const class array<double> & get_weights_aft_R_GL () const
  {
    return weights_aft_R_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_uniform () const
  {
    return CC_wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_uniform () const
  {
    return CC_dwf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_uniform () const
  {
    return CC_d2wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_CC_wf_bef_s_tab_GL () const
  {
    return CC_wf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_bef_s_tab_GL () const
  {
    return CC_dwf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_s_tab_GL () const
  {
    return CC_d2wf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_bef_R_tab_GL () const
  {
    return CC_wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_dwf_bef_R_tab_GL () const
  {
    return CC_dwf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_d2wf_bef_R_tab_GL () const
  {
    return CC_d2wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_CC_wf_aft_R_tab_GL_real () const
  {
    return CC_wf_aft_R_tab_GL_real;
  }

  const class array<complex<double> > & get_CC_dwf_aft_R_tab_GL_real () const
  {
    return CC_dwf_aft_R_tab_GL_real;
  }

  const class array<complex<double> > & get_CC_d2wf_aft_R_tab_GL_real () const
  {
    return CC_d2wf_aft_R_tab_GL_real;
  }

  const class array<complex<double> > & get_CC_wf_aft_R_tab_GL_complex () const
  {
    return CC_wf_aft_R_tab_GL_complex;
  }

  const class array<complex<double> > & get_CC_dwf_aft_R_tab_GL_complex () const
  {
    return CC_dwf_aft_R_tab_GL_complex;
  }

  const class array<complex<double> > & get_CC_d2wf_aft_R_tab_GL_complex () const
  {
    return CC_d2wf_aft_R_tab_GL_complex;
  }

  const class array<complex<double> > & get_CC_wf_momentum_tab_uniform () const
  {
    return CC_wf_momentum_tab_uniform;
  }

  const class array<complex<double> > & get_CC_wf_momentum_tab_GL () const
  {
    return CC_wf_momentum_tab_GL;
  }

  const class array<complex<double> > & get_C0_tab () const
  {
    return C0_tab;
  }

  const class array<complex<double> > & get_Cplus_tab () const
  {
    return Cplus_tab;
  }

  const class array<complex<double> > & get_A0_tab () const
  {
    return A0_tab;
  }

  const class array<complex<double> > & get_Aplus_tab () const
  {
    return Aplus_tab;
  }

  const class array<complex<double> > & get_llp1_eff_tab () const
  {
    return llp1_eff_tab;
  }

  const class array<complex<double> > & get_l_eff_tab () const
  {
    return l_eff_tab;
  }

  const class matrix<complex<double> > & get_asymptotic_channels () const
  {
    return asymptotic_channels;
  }
  
  void CC_wf_dwf_d2wf_zero ();

  void change_channels_energy (const complex<double> &E_change);

  void solve_CC_equations (class CC_rotor_all_data_class &CC_rotor_all_data);

  void DIM_calc_asymptotic_channels (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void DIM_E_search (const class CC_rotor_all_data_class &CC_rotor_all_data);

  complex<double> Jost_det_calc (const class CC_rotor_potential_class &CC_rotor_potential);

  void DIM_calc_CC_wfs_basis_position (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void DIM_calc_partial_norms ();
  void DIM_calc_rms_radius ();

  void BEM_calc_partial_norms_asymptotic_wave_function ();

  void BEM_calc_rms_radius ();

  void asymptotic_fit_tab_from_diagonalization_calc (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void CC_wfs_dwfs_momentum_calc_from_DIM (const double b_HO);
  
  void draw_CC_wfs_coordinate (const string &file_name , const bool is_it_real_axis) const;
  
  void draw_CC_wfs_coordinate_form_factors (const string &file_name , const bool is_it_real_axis) const;
  
  void draw_CC_wfs_momentum (const string &file_name) const;
  
  void draw_CC_wfs_momentum_form_factors (const string &file_name) const;

  void density_calc_store (const string &debut_file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  void intrinsic_density_calc_store_rotating_core (const string &debut_file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  void BEM_calc_CC_wfs_coordinate_momentum (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void BEM_print_energy (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void BEM_calc_partial_norms (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void width_current_formula_calc (const string &file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  complex<double> get_phase_shift (const unsigned int ic) const;

  void DIM_complex_scaling_wave_function_after_R_calc (
						       const unsigned int ic ,
						       const class array<complex<double> > &z_aft_R_tab , 
						       class array<complex<double> > &CC_wf_aft_R_tab ,
						       class array<complex<double> > &CC_dwf_aft_R_tab ,
						       class array<complex<double> > &CC_d2wf_aft_R_tab) const;
  
  void complex_scaling_wave_function_after_R_calc (
						   const unsigned int ic ,
						   const class array<complex<double> > &z_aft_R_tab , 
						   class array<complex<double> > &CC_wf_aft_R_tab ,
						   class array<complex<double> > &CC_dwf_aft_R_tab ,
						   class array<complex<double> > &CC_d2wf_aft_R_tab) const;

  friend double used_memory_calc (const class CC_rotor_states_class &T);
  
private:

  bool S_matrix_pole; // true if one calculates a resonant particle-rotor state, false if not
  
  enum potential_type potential; // type of potential used (deformed WS for nucleon, dipolar, quadruplar for electron)

  unsigned int N_channels; // number of channels of the coupled-channel equations

  unsigned int ic_entrance; // index of the entrance channel
  
  double R;  // rotation point of complex scaling

  double matching_point;  // matching point of wave functions for diract integration

  double s_radial;  // s radius in molecular potentials

  double R0;  // Radius of the potential close to 5 fm or a0.

  double R_max;  // maximal radius considered on the real-axis. All HO states must be negligible therein.

  double kmax_momentum; // maximal momentum for the calculation of densities and correlation densities in momentum space

  double R_Fermi_momentum;  // Radius of the Fermi function applied to one-body basis states for the calculation of their approximate Fourier-Bessel transform. The diffuseness can be fixed at a large value.
  
  double step_bef_R_uniform; // radial step on the uniform grid on [0:R], with R the rotation point. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre
  
  double step_momentum_uniform; // momentum step on the uniform grid on [0:kmax_momentum]. The number of points on the uniform grid is typically 10 times that of Gauss-Legendre

  unsigned int N_bef_R_uniform;                          // number of points on the uniform grid [0:R] (nucleon) or [s_radial:R] (electron) (see spherical_state.cpp)
  unsigned int N_aft_R_uniform;                          // number of points on the uniform grids [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)

  unsigned int N_bef_s_GL;                               // number of Gauss-Legendre points on [0:s] (before s) (see spherical_state.cpp) (molecular case only)
  unsigned int N_bef_R_GL;                               // number of Gauss-Legendre points on ]0:R[ (nucleon) or ]s_radial:R[ (electron) (see spherical_state.cpp)
  unsigned int N_aft_R_GL;                               // number of Gauss-Legendre points on [R:R_real_max], [0:1/R^4] (after R) (see spherical_state.cpp)

  unsigned int N_bef_R0_uniform;                          // number of points on the uniform grid [0:R0] (before R0) for backward integration (see spherical_state.cpp) 
  unsigned int N_aft_R0_uniform;                          // number of points on the uniform grid [R0:R] for backward integration (see spherical_state.cpp)

  unsigned int Nk_momentum_uniform;                      // number of points on the uniform grid [0:kmax_momentum] for wave functions in momentum space
  unsigned int Nk_momentum_GL;                           // number of Gauss-Legendre points on [0:kmax_momentum] for wave functions in momentum space
  
  unsigned int BP; // binary parity (see observables_basic_functions.cpp for definition) 

  double J; // total angular momentum
  
  double K_static; // conserved K-projection of total angular momentum with a static core.

  complex<double> E;  // total energy

  bool is_E_ok; // true if direct integration provided with a reasonable value of energy, false if not
  
  bool is_asymptotic_wave_function_fit_used; // true if one fits the coupled-channel wave functions in the asymptotic region with a simple eexponential ansatz, false if not

  unsigned int Nt; // number of theta angles

  complex<double> rms_radius; // value of rms radius
  
  unsigned int N_asymptotic_fit;  // number of points for the fit of the coupled-channel wave functions in the asymptotic region

  double rmin_for_fit; // r[min] used for the fit of the coupled-channel wave functions in the asymptotic region
  double rmax_for_fit; // r[max] used for the fit of the coupled-channel wave functions in the asymptotic region
  
  class vector_class<complex<double> > eigenvector; // components of the Hamiltonian eigenvector in the Berggren basis when the Berggren Expansion Method (BEM) is used

  class array<class CC_rotor_channel_class> channels_tab; // array of the channels entering the coupled-channel equations of the particle-rotor model

  class array<double> r_bef_R_tab_uniform; // Uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]

  class array<double> k_tab_uniform;  // array of uniformly distributed momenta on [0:kmax_momentum]
  
  class array<double> r_bef_s_tab_GL;  // Gaussian abscissas before R : r in ]0:s[ (electron)
  class array<double> w_bef_s_tab_GL;  // Gaussian weigths   before R : r in ]0:s[ (electron)

  class array<double> r_bef_R_tab_GL; // Gaussian abscissas before R : r in ]0:R[ (nucleon) or ]s_radial:R[ (electron). 
  class array<double> w_bef_R_tab_GL; // Gaussian weights   before R : r in ]0:R[ (nucleon) or ]s_radial:R[ (electron).

  class array<double> r_aft_R_tab_GL_real; // Gaussian abscissas after R on the real r-axis : r in ]R:R_real_max[
  class array<double> w_aft_R_tab_GL_real; // Gaussian weights   after R on the real r-axis : r in ]R:R_real_max[

  class array<complex<double> > r_aft_R_tab_GL_complex; // Gaussian abscissas after R on the complex r-axis : r in ]R:R + (R - R_real_max)exp(i.theta)[
  class array<complex<double> > w_aft_R_tab_GL_complex; // Gaussian weights   after R on the complex r-axis : r in ]R:R + (R - R_real_max)exp(i.theta)[

  class array<double> u_aft_R_GL; // Gaussian abscissas  u = r^(-4) on ]0:R^{-1/4}[ to deal with r > R in integrals

  class array<double> weights_aft_R_GL;// Gaussian weights associated to  u = r^(-4) on ]0:R^{-1/4}[ to deal with r > R in integrals

  class array<double> k_tab_GL;   // Gaussian abscissas on [0:kmax_momentum]
  class array<double> wk_tab_GL;  // Gaussian weights   on [0:kmax_momentum]
  
  class array<complex<double> > CC_wf_bef_R_tab_uniform;  // coupled-channel wave functions on [0:R] (nucleon) or [s_radial:R] (electron) with N_bef_R_uniform points.
  class array<complex<double> > CC_dwf_bef_R_tab_uniform;  // coupled-channel wave functions derivative on [0:R] (nucleon) or [s_radial:R] (electron) with N_bef_R_uniform points.
  class array<complex<double> > CC_d2wf_bef_R_tab_uniform; // coupled-channel wave functions second derivative on [0:R] (nucleon) or [s_radial:R] (electron) with N_bef_R_uniform points.

  class array<complex<double> > CC_wf_bef_s_tab_GL;   // coupled-channel wave functions on [0:s] (electron) with Gaussian points.
  class array<complex<double> > CC_dwf_bef_s_tab_GL;  // coupled-channel wave functions derivative on [0:s] (electron) with Gaussian points.
  class array<complex<double> > CC_d2wf_bef_s_tab_GL; // coupled-channel wave functions second derivatives on [0:s] (electron) with Gaussian points.

  class array<complex<double> > CC_wf_bef_R_tab_GL;   // coupled-channel wave functions on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.
  class array<complex<double> > CC_dwf_bef_R_tab_GL;  // coupled-channel wave functions derivative on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.
  class array<complex<double> > CC_d2wf_bef_R_tab_GL; // coupled-channel wave functions second derivatives on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.

  class array<complex<double> > CC_wf_aft_R_tab_GL_real;    // coupled-channel wave functions on [R:R_real_max] with Gaussian points.
  class array<complex<double> > CC_dwf_aft_R_tab_GL_real;   // coupled-channel wave functions derivative on [R:R_real_max] with Gaussian points.
  class array<complex<double> > CC_d2wf_aft_R_tab_GL_real;  // coupled-channel wave functions second derivative on [R:R_real_max] with Gaussian points.

  class array<complex<double> > CC_wf_aft_R_tab_GL_complex;   // coupled-channel wave functions on [R:R + (R - R_real_max)exp(i.theta)].
  class array<complex<double> > CC_dwf_aft_R_tab_GL_complex;  // coupled-channel wave functions derivative on [R:R + (R - R_real_max)exp(i.theta)].
  class array<complex<double> > CC_d2wf_aft_R_tab_GL_complex; // coupled-channel wave functions second derivative on [R:R + (R - R_real_max)exp(i.theta)].

  class array<complex<double> > CC_wf_momentum_tab_uniform;  // coupled-channel wave functions in momentum space on [0:kmax_momentum] using a unform grid
  class array<complex<double> > CC_dwf_momentum_tab_uniform; // coupled-channel wave functions derivative in momentum space on [0:kmax_momentum] using a unform grid
  
  class array<complex<double> > CC_wf_momentum_tab_GL;  // coupled-channel wave functions in momentum space on [0:kmax_momentum] using with Gaussian points
  class array<complex<double> > CC_dwf_momentum_tab_GL; // coupled-channel wave functions derivative in momentum space on [0:kmax_momentum] using with Gaussian points



  
  // Integration constants
  
  class array<complex<double> > C0_tab;
  class array<complex<double> > Cplus_tab;
  class array<complex<double> > A0_tab;
  class array<complex<double> > Aplus_tab;



  
  class array<class CC_fwd_basis_state> fwd_basis; // forward basis coupled-channel wave functions
  class array<class CC_bwd_basis_state> bwd_basis; // backward basis coupled-channel wave functions

  class array<complex<double> > asymptotic_fit_tab; 

  class array<complex<double> > llp1_eff_tab; // array of effective l[eff](l[eff] + 1) values for the analytical solutions of the eigenfunctions of the dipolar potential at large distance with I = +oo
  
  class array<complex<double> > l_eff_tab; // array of effective l[eff] values for the analytical solutions of the eigenfunctions of the dipolar potential at large distance with I = +oo
  
  class matrix<complex<double> > asymptotic_channels; // eigenvectors associated to the effective l[eff] values for the analytical solutions of the eigenfunctions of the dipolar potential at large distance with I = +oo

  class CC_bwd_basis_state bwd_U_minus; // backward entrance coupled-channel wave function
  
  complex<double> Gamow_squared_norm_one_channel (const unsigned int ic) const;

  void DIM_complex_scaling_wave_function_dipolar_after_R_calc (
							       const unsigned int ic ,
							       const class array<complex<double> > &z_aft_R_tab , 
							       class array<complex<double> > &CCb_wf_aft_R_tab ,
							       class array<complex<double> > &CCb_dwf_aft_R_tab ,
							       class array<complex<double> > &CCb_d2wf_aft_R_tab) const;

  void complex_scaling_wave_function_asymptotic_fit_after_R_calc (
								  const unsigned int ic ,
								  const class array<complex<double> > &z_aft_R_tab , 
								  class array<complex<double> > &CC_wf_aft_R_tab ,
								  class array<complex<double> > &CC_dwf_aft_R_tab ,
								  class array<complex<double> > &CC_d2wf_aft_R_tab) const;

  void DIM_complex_scaling_wave_function_no_dipolar_after_R_calc (
								  const unsigned int ic ,
								  const class array<complex<double> > &z_aft_R_tab , 
								  class array<complex<double> > &CC_wf_aft_R_tab ,
								  class array<complex<double> > &CC_dwf_aft_R_tab ,
								  class array<complex<double> > &CC_d2wf_aft_R_tab) const;

  void complex_scaling_wave_function_no_dipolar_after_R_calc (
							      const unsigned int ic ,
							      const class array<complex<double> > &z_aft_R_tab , 
							      class array<complex<double> > &CC_wf_aft_R_tab ,
							      class array<complex<double> > &CC_dwf_aft_R_tab ,
							      class array<complex<double> > &CC_d2wf_aft_R_tab) const;

  void BEM_Cplus_constants_nuclear_calc ();

  void Gamow_squared_norms_calc (
				 const class CC_rotor_all_data_class &CC_rotor_all_data , 
				 class array<complex<double> > &Gamow_squared_norms) const;
 
  void normalization ();

  void basis_states_calc (const class CC_rotor_potential_class &CC_rotor_potential);

  void constants_calc ();

  void DIM_CC_wf_dwf_bef_R_calc ();

  void CC_d2wf_bef_R_calc (const class CC_rotor_potential_class &CC_rotor_potential);

  void DIM_CC_wave_aft_R_GL_calc ();

  bool is_E_here (const class CC_rotor_all_data_class &CC_rotor_all_data , double &E_debut , double &E_end);

  void E_bisection (const class CC_rotor_all_data_class &CC_rotor_all_data);

  void angular_tabs_density_molecular_calc (
					    const class array<double> &PYlm_tab ,
					    class array<bool> &is_angular_trivial_zero_tab ,
					    class array<double> &angular_weights_tab_for_density ,
					    class array<double> &angular_tab) const;

  void subangular_tab_for_density_nuclear_calc_static_core (
							    const class array<double> &PYlm_tab ,
							    class array<double> &sub_angular_tab) const;
  
  void angular_tabs_density_nuclear_calc_static_core (
						      const class array<double> &PYlm_tab ,
						      class array<double> &angular_tab) const;
  
  void subangular_tab_for_density_nuclear_calc_rotating_core (
							      const class array<double> &PYlm_tab ,
							      class array<double> &sub_angular_tab) const;

  void angular_tabs_density_nuclear_calc_rotating_core (
							const class array<double> &PYlm_tab ,
							class array<bool> &is_angular_trivial_zero_tab ,
							class array<double> &angular_tab) const;

  void angular_weights_tab_for_density_nuclear_calc_rotating_core (class array<double> &angular_weights_tab_for_density) const;

  complex<double> cylindrical_density_r_theta_bef_R_uniform_calc (
								  const class array<bool> &is_angular_trivial_zero_tab ,
								  const class array<double> &angular_tab , 
								  const unsigned int ir ,
								  const unsigned int it) const;
  
  complex<double> cylindrical_density_r_theta_aft_R_GL_real_calc (
								  const class array<bool> &is_angular_trivial_zero_tab ,
								  const class array<double> &angular_tab , 
								  const unsigned int ir ,
								  const unsigned int it) const;

  void cylindrical_density_coordinate_calc_store (
						  const string &file_name , 
						  const class array<bool> &is_angular_trivial_zero_tab ,
						  const class array<double> &angular_tab) const;
  
  complex<double> cylindrical_density_k_theta_k_momentum_uniform_calc (
								       const class array<bool> &is_angular_trivial_zero_tab ,
								       const class array<double> &angular_tab , 
								       const unsigned int ik ,
								       const unsigned int it) const;

  void cylindrical_density_momentum_calc_store (
						const string &file_name , 
						const class array<bool> &is_angular_trivial_zero_tab ,
						const class array<double> &angular_tab) const;

  complex<double> radial_density_r_bef_R_uniform_calc (
						       const class array<double> &angular_weights_tab_for_density ,
						       const unsigned int ir) const;
  
  complex<double> radial_density_r_aft_R_GL_real_calc (
						       const class array<double> &angular_weights_tab_for_density ,
						       const unsigned int ir) const;

  complex<double> momentum_density_uniform_calc (
						 const class array<double> &angular_weights_tab_for_density ,
						 const unsigned int ik) const;
 
  void radial_density_calc_store (const string &file_name ,
				  const class array<double> &angular_weights_tab_for_density) const;

  void momentum_density_calc_store (
				    const string &file_name ,
				    const class array<double> &angular_weights_tab_for_density) const;
  
  void angular_tab_intrinsic_density_molecular_calc (
						     const class array<double> &PYlm_tab ,
						     class array<double> &angular_tab) const;

  complex<double> cylindrical_intrinsic_density_K_r_theta_bef_R_uniform_calc (
									      const class array<double> &angular_tab , 
									      const unsigned int iK ,
									      const unsigned int ir ,
									      const unsigned int it) const;

  complex<double> cylindrical_intrinsic_density_K_r_theta_bef_R_GL_calc (
									 const class array<double> &angular_tab , 
									 const unsigned int iK ,
									 const unsigned int ir ,
									 const unsigned int it) const;

  complex<double> cylindrical_intrinsic_density_K_r_theta_aft_R_GL_real_calc (
									      const class array<double> &angular_tab , 
									      const unsigned int iK ,
									      const unsigned int ir ,
									      const unsigned int it) const;

  complex<double> cylindrical_intrinsic_density_K_momentum_uniform_calc (
									 const class array<double> &angular_tab , 
									 const unsigned int iK ,
									 const unsigned int ik ,
									 const unsigned int it) const;
 
  void calc_cylindrical_intrinsic_density_coordinate_molecular (
								const string &debut_file_name , 
								const class array<double> &angular_tab ,
								class array<double> &bare_sum_real_densities) const;

  void calc_cylindrical_intrinsic_density_momentum_molecular (
							      const string &debut_file_name , 
							      const class array<double> &angular_tab) const;
 
  void angular_tab_partial_density_integrated_molecular_calc (class array<double> &partial_density_integrated_angular_tab) const;

  void integrated_real_densities_molecular_calc (
						 const class array<double> &angular_tab ,
						 class array<double> &integrated_real_densities) const;

  void partial_density_integrated_molecular_calc (
						  const class array<complex<double> > &Gamow_squared_norms ,
						  const class array<double> &angular_tab ,  
						  class array<double> &bare_sum_real_densities) const;
  
  void intrinsic_density_calc_store_rotating_core_molecular (
							     const string &debut_file_name , 
							     const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  void angular_tab_intrinsic_density_nuclear_calc (
						   const class array<double> &PYlm_tab ,
						   class array<double> &angular_tab) const;

  void calc_cylindrical_intrinsic_density_coordinate_nuclear (
							      const string &debut_file_name , 
							      const class array<double> &angular_tab , 
							      class array<double> &bare_sum_real_densities) const;
  
  void calc_cylindrical_intrinsic_density_momentum_nuclear (
							    const string &debut_file_name , 
							    const class array<double> &angular_tab) const;

  void angular_tab_partial_density_integrated_nuclear_calc (class array<double> &partial_density_integrated_angular_tab) const;

  void integrated_real_densities_nuclear_calc (
					       const class array<double> &angular_tab_GL ,
					       class array<double> &integrated_real_densities) const;

  void partial_density_integrated_nuclear_calc (
						const class array<complex<double> > &Gamow_squared_norms , 
						class array<double> &bare_sum_real_densities) const;

  void intrinsic_density_calc_store_rotating_core_nuclear (
							   const string &debut_file_name , 
							   const class CC_rotor_all_data_class &CC_rotor_all_data) const;

  class CC_rotor_channel_class & lowest_channel_determine () const;

  bool is_it_bound_determine () const;

  int lc_max_calc () const;

  int Kmin_all_channels_molecular_determine () const;
  int Kmax_all_channels_molecular_calc () const;

  double Kmin_all_channels_nuclear_determine () const;
  double Kmax_all_channels_nuclear_calc () const;
};

ostream& operator << (ostream &os , const class CC_rotor_states_class &ps);

#endif
