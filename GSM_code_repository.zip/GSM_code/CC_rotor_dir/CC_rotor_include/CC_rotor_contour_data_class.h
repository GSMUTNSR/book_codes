#ifndef CCROTORCONTOURDATACLASS
#define CCROTORCONTOURDATACLASS


// This class contains all informations about contours defined in the input file for each partial wave.
// Informations are extracted by CC_rotor_input_data_class and then used to build this class.
//
// A default contour can be defined and it will be used if no specific contour has been defined for a given partial wave.
// Several files are created in workspace/ to plot contours and a Gnuplot file is also written.
//
// Contours are of arbitrary form (arbitrary number of segments and positions).


class CC_rotor_contour_data_class
{
public :

  // ================================== members ================================== //

  // constructors

  explicit CC_rotor_contour_data_class ();
  
  explicit CC_rotor_contour_data_class (const class CC_rotor_contour_data_class &X);
  
  explicit CC_rotor_contour_data_class (
					const class array<string> &partial_wave_str_tab ,
					const class array<complex<double> > &tabs_k ,
					const class array<unsigned int> &tabs_Nk);
  
  explicit CC_rotor_contour_data_class (
					const class CC_rotor_contour_data_class &X , 
					const unsigned int N_channels , 
					const class array<class CC_rotor_channel_class> &channels_tab_c , 
					const enum potential_type potential);

  void allocate (
		 const class array<string> &partial_wave_str_tab ,
		 const class array<complex<double> > &tabs_k ,
		 const class array<unsigned int> &tabs_Nk);
  
  void allocate (
		 const class CC_rotor_contour_data_class &X , 
		 const unsigned int N_channels , 
		 const class array<class CC_rotor_channel_class> &channels_tab_c , 
		 const enum potential_type potential);

  void allocate_fill (const class CC_rotor_contour_data_class &X);
  
  void deallocate ();

  // get members

  const class array<class CC_rotor_contour_class> & get_contours_tab () const
  {
    return contours_tab;
  }

  unsigned int get_number_contours () const
  {
    return number_contours;
  }
  
  unsigned int get_index_default_partial_wave () const
  {
    return index_default_case;
  }

  // ================================== methods ================================== //
  
  void run (
	    const class array<string> &partial_wave_str_tab ,
	    const class array<complex<double> > &tabs_k ,
	    const class array<unsigned int> &tabs_Nk);
  
  void check_contour_definitions ();

  void print_contours_on_screen ();

  void print_contours_for_plot ();
  
  friend double used_memory_calc (const class CC_rotor_contour_data_class &T);
  
private :

  unsigned int number_contours;

  unsigned int number_edges_max;

  class array<class CC_rotor_contour_class> contours_tab;

  string plot_file_name;

  unsigned int index_default_case;

  unsigned int N_channels;
};

#endif



