#ifndef CCROTOREMTRANSITIONS_H
#define CCROTOREMTRANSITIONS_H


namespace CC_rotor_EM_transitions
{
  //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> before R
  complex<double> radial_integral_bef_R_calc (
					      const enum radial_operator_type radial_operator , 
					      const int L , 
					      const bool is_it_longwavelength_approximation , 
					      const class CC_rotor_states_class &CC_state_in , 
					      const class CC_rotor_states_class &CC_state_out , 
					      const unsigned int ic_in , 
					      const unsigned int ic_out);

  //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> after R using complex scaling
  complex<double> radial_integral_aft_R_calc (
					      const enum radial_operator_type radial_operator , 
					      const int L , 
					      const bool is_it_longwavelength_approximation , 
					      const class CC_rotor_states_class &CC_state_in , 
					      const class CC_rotor_states_class &CC_state_out , 
					      const unsigned int ic_in , 
					      const unsigned int ic_out);

  //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji>
  complex<double> radial_integral_calc ( 
					const enum radial_operator_type radial_operator , 
					const int L , 
					const bool is_it_longwavelength_approximation ,
					const class CC_rotor_states_class &CC_state_in , 
					const class CC_rotor_states_class &CC_state_out , 
					const unsigned int ic_in , 
					const unsigned int ic_out);

  complex<double> OBME_electric_reduced_calc (
					      const int L , 
					      const bool is_it_longwavelength_approximation , 
					      const double effective_charge , 
					      const class CC_rotor_states_class &CC_state_in , 
					      const class CC_rotor_states_class &CC_state_out , 
					      const unsigned int ic_in , 
					      const unsigned int ic_out);

  complex<double> OBME_magnetic_reduced_calc (
					      const int L , 
					      const bool is_it_longwavelength_approximation , 
					      const class CC_rotor_states_class &CC_state_in , 
					      const class CC_rotor_states_class &CC_state_out , 
					      const unsigned int ic_in , 
					      const unsigned int ic_out);
  complex<double> OBME_reduced_calc (
				     const enum EM_type EM , 
				     const int L , 
				     const bool is_it_longwavelength_approximation , 
				     const double effective_charge , 
				     const class CC_rotor_states_class &CC_state_in , 
				     const class CC_rotor_states_class &CC_state_out , 
				     const unsigned int ic_in , 
				     const unsigned int ic_out);

  complex<double> B_amplitude_calc (
				    const enum EM_type EM , 
				    const int L , 
				    const bool is_it_longwavelength_approximation , 
				    const double effective_charge , 
				    const class CC_rotor_states_class &CC_state_in , 
				    const class CC_rotor_states_class &CC_state_out);

  void EM_transition_calc (const class CC_rotor_all_data_class &CC_rotor_all_data ,
			   const class CC_rotor_states_class &CC_state_in , 
			   const class CC_rotor_states_class &CC_state_out);

  void CC_states_IN_OUT_EM_transition_calc (class CC_rotor_all_data_class &CC_rotor_all_data);
}

#endif
