#ifndef CCROTORBERGGRENBASIS_H
#define CCROTORBERGGRENBASIS_H

namespace CC_rotor_Berggren_basis
{
  void state_rejection_test (
			     const class array<class nlj_struct> &shells_qn,
			     const unsigned int state ,
			     class array<class spherical_state> &shells);

  void wave_function_potential_allocate (
					 class CC_rotor_all_data_class &CC_rotor_all_data , 
					 const unsigned int shell_index , 
					 class potentials_effective_mass &all);
  
  void wave_function_quadrupolar_starting_point_calculation (
							     class CC_rotor_all_data_class &CC_rotor_all_data , 
							     const unsigned int shell_index, 
							     class potentials_effective_mass &all);

  void wave_function_Gaussian_starting_point_calculation (
							  class CC_rotor_all_data_class &CC_rotor_all_data , 
							  const unsigned int shell_index, 
							  class potentials_effective_mass &all);

  void wave_function_calculation (class CC_rotor_all_data_class &CC_rotor_all_data , const unsigned int shell_index);

  void shells_quantum_numbers_with_scat_calc (const enum particle_type particle , const int ZY_charge , class Berggren_data &data);

  void contours_discretization (class CC_rotor_all_data_class &CC_rotor_all_data);

  void bad_resonant_states_removal (class Berggren_data &data);

  void print_poles (const class CC_rotor_all_data_class &CC_rotor_all_data , const bool are_poles_printed);

  void build_basis_states (class CC_rotor_all_data_class &CC_rotor_all_data);

  void print_basis_states_bad_overlaps (const class CC_rotor_all_data_class &CC_rotor_all_data);
}

#endif
