#include "../CC_rotor_include/CC_rotor_include.h"

using namespace string_routines;



// Calculation of the resonant and scattering states of the Berggren basis to diagonalize the coupled-channel Hamiltonian matrix
// ------------------------------------------------------------------------------------------------------------------------------


nlj_struct::nlj_struct () {}

nlj_struct::nlj_struct (
		        const int n_c , 
			const int jr_c , 
			const int l_c , 
			const double j_c , 
			const bool S_matrix_pole_c , 
			const complex<double> &k_c , 
			const complex<double> &weight_c ,
			const unsigned int ic_c)
{
  initialize (n_c , jr_c , l_c , j_c , S_matrix_pole_c , k_c , weight_c , ic_c);
}

void nlj_struct::initialize (
			     const int n_c , 
			     const int jr_c , 
			     const int l_c , 
			     const double j_c , 
			     const bool S_matrix_pole_c , 
			     const complex<double> &k_c , 
			     const complex<double> &weight_c ,
			     const unsigned int ic_c)
{
  n = n_c;

  jr = jr_c;

  l = l_c;

  j = j_c;

  S_matrix_pole = S_matrix_pole_c;

  k = k_c;

  weight = weight_c;

  ic = ic_c;
}
 
void nlj_struct::initialize (const class nlj_struct &X)
{
  n = X.n;

  jr = X.jr;

  l = X.l;

  j = X.j;

  S_matrix_pole = X.S_matrix_pole;

  k = X.k;

  weight = X.weight;

  ic = X.ic;
}

void nlj_struct::allocate_fill (const class nlj_struct &X)
{
  initialize (X);
}

void nlj_struct::operator = (const class nlj_struct &X)
{
  initialize (X);
}


bool operator == (const class nlj_struct &a , const class nlj_struct &b)
{
  if (a.get_S_matrix_pole () != b.get_S_matrix_pole ()) return false;
  if ((a.get_n () != b.get_n ()) || (a.get_ic () != b.get_ic ())) return false;

  if (inf_norm (a.get_k () - b.get_k ()) > precision) return false;
  if (inf_norm (a.get_weight () - b.get_weight ()) > precision) return false;

  return true;
}



bool operator != (const class nlj_struct &a , const class nlj_struct &b)
{
  return !(a == b);
}



bool operator > (const class nlj_struct &a , const class nlj_struct &b)
{
  if (!a.get_S_matrix_pole () && b.get_S_matrix_pole ()) return true; 
  if ((a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_ic () > b.get_ic ())) return true; 
  if ((a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_ic () == b.get_ic ()) && (real (a.get_k ()) > real (b.get_k ()))) return true;

  return false;
}



bool operator >= (const class nlj_struct &a , const class nlj_struct &b)
{
  return ((a > b) || (a == b));
}



bool operator < (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b > a);
}

bool operator <= (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b >= a);
}




ostream & operator << (ostream &os , const class nlj_struct &s)
{
  return os << s.get_n () << angular_state (s.get_l () , s.get_j ());
}




double used_memory_calc (const class nlj_struct &T)
{
  return sizeof (T)/1000000.0;
}



Berggren_data::Berggren_data () :
  N_channels (0) ,
  N_bef_R_uniform (0) ,
  N_aft_R_uniform (0) ,
  N_bef_s_GL (0) ,
  N_bef_R_GL (0) ,
  N_aft_R_GL (0) , 
  Nk_momentum_uniform (0) , 
  Nk_momentum_GL (0) , 
  N_nlj (0) , 
  N_nlj_res (0) , 
  s (0.0) , 
  R (0.0) , 
  R0 (0.0) , 
  R_real_max (0.0) ,
  kmax_momentum (0.0) ,
  A_equiv (0.0)
{}
  

Berggren_data::Berggren_data (
			      const unsigned int N_bef_R_uniform_c , 
			      const unsigned int N_aft_R_uniform_c , 
			      const unsigned int N_bef_s_GL_c , 
			      const unsigned int N_bef_R_GL_c , 
			      const unsigned int N_aft_R_GL_c ,
			      const unsigned int Nk_momentum_uniform_c , 
			      const unsigned int Nk_momentum_GL_c , 
			      const double s_c , 
			      const double R_c , 
			      const double R0_c , 
			      const double R_real_max_c , 
			      const double kmax_momentum_c , 
			      const double R_Fermi_momentum_c , 
			      const unsigned int A_equiv_c ,
			      const class array<class CC_rotor_channel_class> &channels_tab_c)
{
  allocate (N_bef_R_uniform_c , N_aft_R_uniform_c , N_bef_s_GL_c , N_bef_R_GL_c , N_aft_R_GL_c , Nk_momentum_uniform_c , Nk_momentum_GL_c ,
	    s_c , R_c , R0_c , R_real_max_c , kmax_momentum_c , R_Fermi_momentum_c , A_equiv_c , channels_tab_c);
}

Berggren_data::Berggren_data (const class Berggren_data &X)
{
  allocate_fill (X);
}

void Berggren_data::allocate (
			      const unsigned int N_bef_R_uniform_c , 
			      const unsigned int N_aft_R_uniform_c , 
			      const unsigned int N_bef_s_GL_c , 
			      const unsigned int N_bef_R_GL_c , 
			      const unsigned int N_aft_R_GL_c , 
			      const unsigned int Nk_momentum_uniform_c , 
			      const unsigned int Nk_momentum_GL_c , 
			      const double s_c , 
			      const double R_c , 
			      const double R0_c , 
			      const double R_real_max_c , 
			      const double kmax_momentum_c , 
			      const double R_Fermi_momentum_c , 
			      const unsigned int A_equiv_c ,
			      const class array<class CC_rotor_channel_class> &channels_tab_c)
{
  N_channels = channels_tab_c.dimension (0);

  N_bef_R_uniform = N_bef_R_uniform_c; 
  N_aft_R_uniform = N_aft_R_uniform_c; 

  N_bef_s_GL = N_bef_s_GL_c; 
  N_bef_R_GL = N_bef_R_GL_c; 
  N_aft_R_GL = N_aft_R_GL_c; 

  Nk_momentum_uniform = Nk_momentum_uniform_c;

  Nk_momentum_GL = Nk_momentum_GL_c;

  N_nlj = 0; 

  N_nlj_res = 0; 

  s = s_c; 

  R = R_c; 

  R0 = R0_c; 

  R_real_max = R_real_max_c;

  kmax_momentum = kmax_momentum_c;

  R_Fermi_momentum = R_Fermi_momentum_c;

  A_equiv = A_equiv_c;

  channels_tab.allocate_fill (channels_tab_c);
}

void Berggren_data::allocate_fill (const class Berggren_data &X)
{
  N_channels = X.N_channels;

  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform; 

  N_bef_s_GL = X.N_bef_s_GL; 
  N_bef_R_GL = X.N_bef_R_GL; 

  Nk_momentum_uniform = X.Nk_momentum_uniform;

  Nk_momentum_GL = X.Nk_momentum_GL;

  N_aft_R_GL = X.N_aft_R_GL; 

  N_nlj = X.N_nlj; 

  N_nlj_res = X.N_nlj_res; 

  s = X.s; 

  R = X.R; 

  R0 = X.R0; 

  R_real_max = X.R_real_max; 

  kmax_momentum = X.kmax_momentum;

  R_Fermi_momentum = X.R_Fermi_momentum;

  A_equiv = X.A_equiv;

  Nk_peak_tab.allocate_fill (X.Nk_peak_tab);
  Nk_middle_tab.allocate_fill (X.Nk_middle_tab);
  Nk_max_tab.allocate_fill (X.Nk_max_tab);

  k_peak_tab.allocate_fill (X.k_peak_tab);
  k_middle_tab.allocate_fill (X.k_middle_tab);
  k_max_tab.allocate_fill (X.k_max_tab);

  shells_quantum_numbers.allocate_fill (X.shells_quantum_numbers);

  shells.allocate_fill (X.shells);

  channels_tab.allocate_fill (X.channels_tab);

  contours_data.allocate_fill (X.contours_data);
}

void Berggren_data::deallocate ()
{
  Nk_peak_tab.deallocate ();
  Nk_middle_tab.deallocate ();
  Nk_max_tab.deallocate ();

  k_peak_tab.deallocate ();
  k_middle_tab.deallocate ();
  k_max_tab.deallocate ();

  shells_quantum_numbers.deallocate ();

  shells.deallocate ();

  channels_tab.deallocate ();

  contours_data.deallocate ();
  
  N_channels = 0;

  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  N_bef_s_GL = 0;
  N_bef_R_GL = 0;

  Nk_momentum_uniform = 0;

  Nk_momentum_GL = 0;

  N_aft_R_GL = 0;

  N_nlj = 0;

  N_nlj_res = 0;

  s = 0.0; 

  R = 0.0; 

  R0 = 0.0;

  R_real_max = 0.0;

  kmax_momentum = 0.0;

  R_Fermi_momentum = 0.0;

  A_equiv = 0;
}




void Berggren_data::build_Berggren_data (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  calc_resonant_states (CC_rotor_all_data);

  calc_scattering_states (CC_rotor_all_data);
}


void Berggren_data::calc_resonant_states (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum particle_type particle = CC_rotor_input.get_particle ();

  const unsigned int nmax_bound_res = CC_rotor_input.get_nmax_bound_res ();

  // ================================== ================================== //
  if (particle == ELECTRON)
    {
      N_nlj_res = N_channels * (nmax_bound_res + 1);

      shells_quantum_numbers.allocate (N_nlj_res);

      unsigned int s = 0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  // l , jr basis
	  const int lc = channel_c.get_lc ();
	  const double jrc = channel_c.get_jrc ();

	  for (unsigned int n = 0 ; n <= nmax_bound_res ; n++)
	    shells_quantum_numbers (s++).initialize (n , jrc , lc , NADA , true , 0.0 , NADA , ic);
	}
    }
  // ================================== ================================== //
  else if ((particle == NEUTRON) || (particle == PROTON))
    {
      N_nlj_res = N_channels * (nmax_bound_res + 1);

      shells_quantum_numbers.allocate (N_nlj_res);

      unsigned int s = 0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();
	  const double jc = channel_c.get_jc ();
	  const int jrc = channel_c.get_jrc ();

	  for (unsigned int n = 0 ; n <= nmax_bound_res ; n++)
	    shells_quantum_numbers(s++).initialize (n , jrc , lc , jc , true , 0.0 , NADA , ic);
	}
    }
  else
    error_message_print_abort ("------ fill_input::shells_to_consider: bad particle type ------");
}







void Berggren_data::calc_scattering_states (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum particle_type particle = CC_rotor_input.get_particle ();
    
  const enum potential_type potential = CC_rotor_input.get_potential ();
  
  if ((potential == QUADRUPOLAR) || (potential == GAUSSIAN))
    {
      // copy of the original and extend it to N_channels (set at "default" if not defined , ordered like channels)

      const class CC_rotor_contour_data_class &contours_data_input = CC_rotor_input.get_contours_data ();

      contours_data.allocate (contours_data_input , N_channels , channels_tab , potential);
    }
  else if ((potential == DIPOLAR) || (potential == DEFORMED_WS) || (potential == DEFORMED_WS_STATIC))
    {
      k_peak_tab.allocate (N_channels);
      k_middle_tab.allocate (N_channels);
      k_max_tab.allocate (N_channels);

      Nk_peak_tab.allocate (N_channels);
      Nk_middle_tab.allocate (N_channels);
      Nk_max_tab.allocate (N_channels);
      
      // get default values for (l , j) or (l , jr) contours in the input file
      const class array<string> &contours_tab_shells = CC_rotor_input.get_contours_tab_shells ();

      const class array<complex<double> > &contours_tab_k_peak = CC_rotor_input.get_contours_tab_k_peak ();
      const class array<double> &contours_tab_k_middle = CC_rotor_input.get_contours_tab_k_middle ();
      const class array<double> &contours_tab_k_max = CC_rotor_input.get_contours_tab_k_max ();

      const class array<unsigned int> &contours_tab_Nk_peak = CC_rotor_input.get_contours_tab_Nk_peak ();
      const class array<unsigned int> &contours_tab_Nk_middle = CC_rotor_input.get_contours_tab_Nk_middle ();
      const class array<unsigned int> &contours_tab_Nk_max = CC_rotor_input.get_contours_tab_Nk_max ();

      complex<double> k_peak = 0.0;
      
      double k_middle = 0.0;
      double k_max = 0.0;

      unsigned int Nk_peak = 0;
      unsigned int Nk_middle = 0;
      unsigned int Nk_max = 0;

      for (unsigned int i = 0 ; i < contours_tab_shells.dimension (0) ; i++)
	{
	  string shell = contours_tab_shells[i];

	  // stay to zero if there is no default case , unless it is defined in the input file
	  if (shell == "default")
	    {
	      k_peak = contours_tab_k_peak[i];
	      k_middle = contours_tab_k_middle[i];
	      k_max = contours_tab_k_max[i];

	      Nk_peak = contours_tab_Nk_peak[i];
	      Nk_middle = contours_tab_Nk_middle[i];
	      Nk_max = contours_tab_Nk_max[i];
	    }
	}

      // update (l , j) or (l , jr) contours definitions
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  // initialize the (l , j) or (l , jr) contour associated to the channel at default values
	  k_peak_tab(ic) = k_peak;
	  k_middle_tab(ic) = k_middle;
	  k_max_tab(ic) = k_max;

	  Nk_peak_tab(ic) = Nk_peak;
	  Nk_middle_tab(ic) = Nk_middle;
	  Nk_max_tab(ic) = Nk_max;
	  
	  // search if the considered (l , j) or (l , jr) contour has a different def in the input file
	  for (unsigned int i = 0 ; i < contours_tab_shells.dimension (0) ; i++)
	    {
	      string shell = contours_tab_shells[i];
	      
	      if (shell != "default")
		{
		  // get channel quantum numbers

		  const class CC_rotor_channel_class &channel_c = channels_tab[ic];

		  const int lc = channel_c.get_lc ();
		  
		  const double jc = channel_c.get_jc ();

		  const int l = determine_l (shell);

		  const double j = determine_j (shell);

		  if (same_lj_particle (particle , l , j , particle , lc , jc))
		    {				 
		      k_peak_tab  (ic) = contours_tab_k_peak  [i];
		      k_middle_tab(ic) = contours_tab_k_middle[i];
		      k_max_tab   (ic) = contours_tab_k_max   [i];

		      Nk_peak_tab  (ic) = contours_tab_Nk_peak  [i];
		      Nk_middle_tab(ic) = contours_tab_Nk_middle[i];
		      Nk_max_tab   (ic) = contours_tab_Nk_max   [i];
		    }
		}
	    }	  
	}
    }
  else
    error_message_print_abort ("Berggren_data::calc_scattering_states: bad calculation type");
}



double used_memory_calc (const class Berggren_data &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;
  
  const double used_memory_allocated_arrays = used_memory_calc (T.Nk_peak_tab) +
    used_memory_calc (T.Nk_middle_tab) +
    used_memory_calc (T.Nk_max_tab) +
    used_memory_calc (T.k_peak_tab) +
    used_memory_calc (T.k_middle_tab) +
    used_memory_calc (T.k_max_tab) +
    used_memory_calc (T.shells) +
    used_memory_calc (T.shells_quantum_numbers) +
    used_memory_calc (T.channels_tab) +
    used_memory_calc (T.contours_data)
    - (sizeof (T.Nk_peak_tab) +
       sizeof (T.Nk_middle_tab) +
       sizeof (T.Nk_max_tab) +
       sizeof (T.k_peak_tab) +
       sizeof (T.k_middle_tab) +
       sizeof (T.k_max_tab) +
       sizeof (T.shells) +
       sizeof (T.shells_quantum_numbers) +
       sizeof (T.channels_tab) +
       sizeof (T.contours_data))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}
