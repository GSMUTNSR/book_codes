#include "../CC_rotor_include/CC_rotor_include.h"

using namespace string_routines;


// Input file data treated to calculate the solution of the coupled-channel equations
// ----------------------------------------------------------------------------------


CC_rotor_all_data_class::CC_rotor_all_data_class () : N_channels (0) , Nr_fit (0) {}

CC_rotor_all_data_class::CC_rotor_all_data_class (const class CC_rotor_all_data_class &X)
{
  allocate_fill (X);
}

CC_rotor_all_data_class::~CC_rotor_all_data_class () {}

void CC_rotor_all_data_class::allocate_fill (const class CC_rotor_all_data_class &X)
{
  N_channels = X.N_channels;
  
  Nr_fit = X.Nr_fit;
  
  CC_rotor_input.allocate_fill (X.CC_rotor_input);

  channels_tab.allocate_fill (X.channels_tab);

  CC_rotor_potential.allocate_fill (X.CC_rotor_potential);

  data.allocate_fill (X.data);

  Vccp_tab_bef_s_GL.allocate_fill (X.Vccp_tab_bef_s_GL);
  Vccp_tab_bef_R_GL.allocate_fill (X.Vccp_tab_bef_R_GL);

  Vccp_tab_aft_R_GL.allocate_fill (X.Vccp_tab_aft_R_GL);

  Vccp_tab_aft_R_GL_real.allocate_fill (X.Vccp_tab_aft_R_GL_real);
}
  
void CC_rotor_all_data_class::deallocate ()
{  
  CC_rotor_input.deallocate ();

  channels_tab.deallocate ();

  CC_rotor_potential.deallocate ();

  data.deallocate ();

  Vccp_tab_bef_s_GL.deallocate ();
  Vccp_tab_bef_R_GL.deallocate ();

  Vccp_tab_aft_R_GL.deallocate ();

  Vccp_tab_aft_R_GL_real.deallocate ();
  
  N_channels = 0;
  
  Nr_fit = 0;
}

void CC_rotor_all_data_class::check_and_read_input_file ()
{
  cout << "======================================================================================" << endl;
  cout << "========================= CC_rotor_all_data_class: read input ========================" << endl;
  cout << "======================================================================================" << endl << endl;

  // get the name of the storage directory and check if it exists
  cin >> STORAGE_DIR;

  STORAGE_DIR += "/";

  if (access (STORAGE_DIR.c_str () , F_OK) != 0) error_message_print_abort (STORAGE_DIR + " does not exist");

  cout << "STORAGE_DIR : " << STORAGE_DIR << endl << endl;

  CC_rotor_input.read_input_data_from_file ();
}




void CC_rotor_all_data_class::N_channels_calc_static_core ()
{
  const enum particle_type particle = CC_rotor_input.get_particle ();

  const int lmax = CC_rotor_input.get_lmax ();

  const double K = CC_rotor_input.get_K_static ();
  
  const unsigned int BP = CC_rotor_input.get_BP ();
	    
  cout << endl << "channels for K : " << M_Pi_string ( BP , K ) << endl << endl;

  N_channels = 0;

  if ((particle == NEUTRON) || (particle == PROTON))
    {
      for (int lc = 0 ; lc <= lmax ; lc++)
	{
	  const double jmin_lc = abs (0.5 - lc);

	  const double jmax_lc = 0.5 + lc;

	  const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);
	  
	  for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	    {
	      const double jc = jmin_lc + i_jc;
	      	  
	      if ((binary_parity_from_orbital_angular_momentum (lc) == BP) && (rint (K - jc) <= 0.0)) N_channels++;	  
	    }
	}
    }
  else
    error_message_print_abort ("CC_rotor_all_data_class::N_channels_calc_static_core: wrong particle type");

  cout << endl;

  if (N_channels != 0)
    cout << "channels number : " << N_channels << endl << endl;
  else
    error_message_print_abort ("CC_rotor_all_data_class::N_channels_calc_static_core: no channels");
}



void CC_rotor_all_data_class::fill_channels_static_core ()
{
  // channel counter
  unsigned int ic = 0;

  const enum particle_type particle = CC_rotor_input.get_particle ();

  const int ZY_charge = CC_rotor_input.get_ZY_charge ();
  
  const double K = CC_rotor_input.get_K_static ();

  const double mass_modif = CC_rotor_input.get_mass_modif ();

  const double nucleon_mass_for_calc = CC_rotor_input.get_nucleon_mass_for_calc ();

  const unsigned int BP = CC_rotor_input.get_BP ();

  const complex<double> E = CC_rotor_input.get_E ();

  const int lmax = CC_rotor_input.get_lmax ();

  const double kinetic_factor = kinetic_factor_calc (false , mass_modif , nucleon_mass_for_calc);

  cout << "kinetic_factor : " << kinetic_factor << endl << endl;

  if ((particle == NEUTRON) || (particle == PROTON))
    {
      for (int lc = 0 ; lc <= lmax ; lc++)
	{
	  const double jmin_lc = abs (0.5 - lc);

	  const double jmax_lc = 0.5 + lc;

	  const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);
	  
	  for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	    {
	      const double jc = jmin_lc + i_jc;

	      if ((binary_parity_from_orbital_angular_momentum (lc) == BP) && (rint (K - jc) <= 0.0))
		{
		  channels_tab(ic) = CC_rotor_channel_class (particle , kinetic_factor , ZY_charge , lc , jc , K , E);

		  cout << "channel c : " << ic << " " << channels_tab(ic) << endl;
		      
		  ic++;
		}
	    }
	}
    }
  else
    error_message_print_abort ("CC_rotor_all_data_class::fill_channels_static_core: wrong particle type");
}




void CC_rotor_all_data_class::N_channels_calc_rotating_core ()
{
  const enum particle_type particle = CC_rotor_input.get_particle ();

  const int lmax = CC_rotor_input.get_lmax ();

  const double J = CC_rotor_input.get_J ();

  const unsigned int BP = CC_rotor_input.get_BP ();

  const enum potential_type potential = CC_rotor_input.get_potential ();

  cout << endl << "channels for J: " << J_Pi_string ( BP , J ) << endl << endl;

  N_channels = 0;

  if ((particle == NEUTRON) || (particle == PROTON))
    {
      for (int lc = 0 ; lc <= lmax ; lc++)
	{
	  const double jmin_lc = abs (0.5 - lc);

	  const double jmax_lc = 0.5 + lc;

	  const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);

	  for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	    {
	      const double jc = jmin_lc + i_jc;

	      const int jr_min_jc = make_int (abs (J - jc));

	      const int jr_max_jc = make_int (J + jc);
	      
	      for (int jrc = jr_min_jc ; jrc <= jr_max_jc ; jrc++)
		{
		  // lambda = 2 deformation and pi = (-1)^(l+jr)
		  if ((jrc%2 == 0) && (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP)) N_channels++;
		}
	    }
	}
    }	
  else if (particle == ELECTRON)
    {  
      // here J is supposed to be an integer
      const int J_integer = make_int (J);

      for (int lc = 0; lc <= lmax ; lc++)
	{
	  const int jr_min_lc = abs (J_integer - lc);
	  const int jr_max_lc = J_integer + lc;

	  for (int jrc = jr_min_lc; jrc <= jr_max_lc; jrc++)
	    {
	      bool parity_symmetry_condition = false;

	      // asymmetric rotor, only parity condition: pi = (-1)^(l+jr)
	      if (potential == DIPOLAR) parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);

	      // symmetric rotor, jrc must be even and parity respected
	      if (potential == QUADRUPOLAR) parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);

	      //anti/symmetric rotor, jrc must be parity respected to polarity
	      if (potential == GAUSSIAN)
		{
		  const int polarity =  CC_rotor_input.get_polarity_Gaussian ();
		  
		  //need to add && (jrc%2 == lambda%2)  consider symmetry of rotor
		  if (polarity%2 == 0)
		    parity_symmetry_condition = ((binary_parity_from_orbital_angular_momentum (jrc + lc) == BP) && (jrc%2 == 0));
		  else 
		    parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);//xyzttt
		}

	      if (parity_symmetry_condition) N_channels++;
	    }
	}
    }
  else
    error_message_print_abort ("CC_rotor_all_data_class::N_channels_calc_rotating_core: wrong particle type");

  cout << endl;

  if (N_channels != 0)
    cout << "channels number: " << N_channels << endl << endl;
  else
    error_message_print_abort ("CC_rotor_all_data_class::N_channels_calc_rotating_core: no channels");
}



void CC_rotor_all_data_class::fill_channels_rotating_core ()
{
  // channel counter
  unsigned int ic = 0;

  const enum particle_type particle = CC_rotor_input.get_particle ();

  const bool is_it_electron = (particle == ELECTRON) ? (true) : (false);

  const bool is_I_tab_used = CC_rotor_input.get_is_I_tab_used ();

  const int ZY_charge = CC_rotor_input.get_ZY_charge ();

  const double I = CC_rotor_input.get_I ();
  const double J = CC_rotor_input.get_J ();

  const double mass_modif = CC_rotor_input.get_mass_modif ();

  const double nucleon_mass_for_calc = CC_rotor_input.get_nucleon_mass_for_calc ();

  const unsigned int BP = CC_rotor_input.get_BP ();

  const complex<double> E = CC_rotor_input.get_E ();

  const int lmax = CC_rotor_input.get_lmax ();

  const double kinetic_factor = kinetic_factor_calc (is_it_electron , mass_modif , nucleon_mass_for_calc);

  cout << "kinetic_factor: " << kinetic_factor << endl << endl;

  if ((particle == NEUTRON) || (particle == PROTON))
    {
      for (int lc = 0 ; lc <= lmax ; lc++)
	{
	  const double jmin_lc = abs (0.5 - lc);

	  const double jmax_lc = 0.5 + lc;
	  
	  const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);

	  for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	    {
	      const double jc = jmin_lc + i_jc;

	      const int jr_min_jc = make_int (abs (J - jc));

	      const int jr_max_jc = make_int (J + jc);
	      
	      for (int jrc = jr_min_jc ; jrc <= jr_max_jc ; jrc++)
		{
		  // lambda = 2 deformation and pi = (-1)^(l+jr)
		  if ((jrc%2 == 0) && (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP))
		    {
		      // corrective factor due to the mass of the core + particle system

		      const double I_corrected = (is_I_tab_used) ? (CC_rotor_input.get_moment_of_inertia (jrc) * two_amu_over_hbar_square / kinetic_factor) : (I);

		      channels_tab(ic) = CC_rotor_channel_class (particle , kinetic_factor , ZY_charge , jrc , lc , jc , J , I_corrected , E);

		      cout << "channel c : " << ic << " " << channels_tab(ic) << endl;
		      
		      ic++;
		    }
		}
	    }
	}
    }
  else if (particle == ELECTRON)
    {
      const enum potential_type potential = CC_rotor_input.get_potential ();

      // here J is supposed to be an integer
      const int J_integer = make_int (J);

      for (int lc = 0 ; lc <= lmax ; lc++)
	{
	  const int jr_min_lc = abs (J_integer - lc);
	  const int jr_max_lc = J_integer + lc;

	  for (int jrc = jr_min_lc ; jrc <= jr_max_lc ; jrc++)
	    {
	      bool parity_symmetry_condition = false;

	      // asymmetric rotor, only parity condition: pi = (-1)^(l+jr)
	      if (potential == DIPOLAR) parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);

	      // symmetric rotor, jrc must be even and parity respected
	      if (potential == QUADRUPOLAR) parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);

	      //symmetric rotor, jrc must be even and parity respected
	      if (potential == GAUSSIAN)
		{
		  const int polarity = CC_rotor_input.get_polarity_Gaussian ();
		  
		  if (polarity%2 == 0)
		    parity_symmetry_condition = ((binary_parity_from_orbital_angular_momentum (jrc + lc) == BP) && (jrc%2 == 0));
		  else 
		    parity_symmetry_condition = (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP);//xyzttt
		}

	      if (parity_symmetry_condition)
		{
		  // here jc = 0
		  channels_tab(ic) = CC_rotor_channel_class (particle , kinetic_factor , 0 , jrc , lc , 0 , J , I , E);
		  
		  cout << "channel c : " << ic << " " << channels_tab(ic) << endl;
		  
		  ic ++;
		}
	    }
	}
    }
  else
    error_message_print_abort ("CC_rotor_all_data_class::fill_channels_rotating_core: wrong particle type");
}



void CC_rotor_all_data_class::build_channels ()
{
	cout << endl << "==========================================================================================" << endl;
  cout         << "========================= CC_rotor_all_data_class: build channels ========================" << endl;
  cout         << "==========================================================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = get_CC_rotor_input ();
	
  const enum potential_type potential = CC_rotor_input.get_potential ();
  
  if (potential == DEFORMED_WS_STATIC)
    {
      N_channels_calc_static_core ();
      
      channels_tab.allocate (N_channels);
      
      fill_channels_static_core ();
    }
  else
    {
      N_channels_calc_rotating_core ();
      
      channels_tab.allocate (N_channels);
      
      fill_channels_rotating_core ();
    } 
}





void CC_rotor_all_data_class::build_potential ()
{
  cout << endl;
  cout << "==========================================================================================" << endl;
  cout << "======================== CC_rotor_all_data_class: build potential ========================" << endl;
  cout << "==========================================================================================" << endl << endl;

  class CC_rotor_all_data_class &CC_rotor_all_data = *this;

  CC_rotor_potential.allocate (CC_rotor_all_data);

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const bool are_radial_form_factors_densities_stored = CC_rotor_input.get_are_radial_form_factors_densities_stored ();

  if (are_radial_form_factors_densities_stored)
    {
      const enum potential_type potential = CC_rotor_potential.get_potential ();

      switch (potential)
	{
	case DIPOLAR: break;
	  
	case QUADRUPOLAR: CC_rotor_potential.test_quadrupolar_potential (CC_rotor_all_data); break;
      
	case GAUSSIAN: CC_rotor_potential.test_Gaussian_potential (CC_rotor_all_data); break;
      
	case DEFORMED_WS: CC_rotor_potential.test_WS_potential (CC_rotor_all_data); break;
	  
	case DEFORMED_WS_STATIC: CC_rotor_potential.test_WS_static_potential (CC_rotor_all_data); break;
      
	default: error_message_print_abort ("CC_rotor_all_data_class::build_potential: bad potential type");
	}
    }
}




void CC_rotor_all_data_class::build_Berggren_basis ()
{
  cout << "=================================================================================================" << endl;
  cout << "========================= CC_rotor_all_data_class: build Berggren basis ========================" << endl;
  cout << "================================================================================================" << endl << endl;
 
  // initialization
  data.allocate (
		 CC_rotor_input.get_N_bef_R_uniform () ,
		 CC_rotor_input.get_N_aft_R_uniform () ,
		 CC_rotor_input.get_N_bef_s_GL () ,
		 CC_rotor_input.get_N_bef_R_GL () ,
		 CC_rotor_input.get_N_aft_R_GL () ,
		 CC_rotor_input.get_Nk_momentum_uniform () ,
		 CC_rotor_input.get_Nk_momentum_GL () ,
		 CC_rotor_input.get_s () ,
		 CC_rotor_input.get_R () ,
		 CC_rotor_input.get_R0 () ,
		 CC_rotor_input.get_R_real_max () ,
		 CC_rotor_input.get_kmax_momentum () ,
		 CC_rotor_input.get_R_Fermi_momentum () ,
		 CC_rotor_input.get_A () ,
		 channels_tab);

  class CC_rotor_all_data_class &all_data = *this;

  data.build_Berggren_data (all_data);
}


void CC_rotor_all_data_class::calc_potential_channel_channel_MEs_Vccp ()
{
  cout << "===============================================================================================" << endl;
  cout << "========================= CC_rotor_all_data_class: Vcc'(r) calculation ========================" << endl;
  cout << "===============================================================================================" << endl << endl;

  Vccp_tab_bef_s_GL.allocate (N_channels , N_channels , CC_rotor_input.get_N_bef_s_GL ());
  Vccp_tab_bef_R_GL.allocate (N_channels , N_channels , CC_rotor_input.get_N_bef_R_GL ());

  Vccp_tab_aft_R_GL.allocate (N_channels , N_channels , 4 , CC_rotor_input.get_N_aft_R_GL ());

  Vccp_tab_aft_R_GL_real.allocate (N_channels , N_channels , CC_rotor_input.get_N_aft_R_GL ());

  class CC_rotor_all_data_class &all_data = *this;

  CC_rotor_Berggren_diagonalization::Vccp_tabs_calc (all_data);
}



void CC_rotor_all_data_class::build_data_for_solvers ()
{
  cout << "==================================================================================================" << endl;
  cout << "========================= CC_rotor_all_data_class: build data for solvers ========================" << endl;
  cout << "==================================================================================================" << endl << endl;

  const bool is_asymptotic_wave_function_fit_used = CC_rotor_input.get_is_asymptotic_wave_function_fit_used ();

  if (is_asymptotic_wave_function_fit_used)
    {
      const unsigned int N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();
      
      const unsigned int N_asymptotic_fit = CC_rotor_input.get_N_asymptotic_fit ();

      const double R = CC_rotor_input.get_R ();
  
      const double R_real_max = CC_rotor_input.get_R_real_max ();

      const double rmin_for_fit = CC_rotor_input.get_rmin_for_fit ();      
      const double rmax_for_fit = CC_rotor_input.get_rmax_for_fit ();
      
      class array<double> r_aft_R_tab_GL_real(N_aft_R_GL);
      class array<double> w_aft_R_tab_GL_real(N_aft_R_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (R , R_real_max , r_aft_R_tab_GL_real , w_aft_R_tab_GL_real);
  
      Nr_fit = 0;

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL_real(i);
      
	  if ((r >= rmin_for_fit) && (r <= rmax_for_fit)) Nr_fit++;
	}

      if (Nr_fit < N_asymptotic_fit) 
	error_message_print_abort ("Nr_fit=" + make_string<unsigned int> (Nr_fit) + " cannot be smaller than N_asymptotic_fit=" + make_string<unsigned int> (N_asymptotic_fit));
    }
  
  const bool is_CC_solver_direct_integration = CC_rotor_input.get_is_CC_solver_direct_integration ();

  // BEM
  if (!is_CC_solver_direct_integration)
    {
      cout << "Berggren expansion method (BEM)" << endl;
      cout << "-------------------------------" << endl << endl;
      cout << "--> build Berggren basis and CC potentials" << endl << endl;

      build_Berggren_basis ();

      calc_potential_channel_channel_MEs_Vccp ();      
    }
  else
    { 
      cout << "Direct integration method (DIM)" << endl;
      cout << "-------------------------------" << endl << endl;
      cout << "Nothing to prepare" << endl << endl;
    }
}




double used_memory_calc (const CC_rotor_all_data_class &T)
{
  return (sizeof (T)/1000000.0 +
	  used_memory_calc (T.CC_rotor_input) +
	  used_memory_calc (T.channels_tab) +
	  used_memory_calc (T.CC_rotor_potential) +
	  used_memory_calc (T.data) +
	  used_memory_calc (T.Vccp_tab_bef_s_GL) +
	  used_memory_calc (T.Vccp_tab_bef_R_GL) +
	  used_memory_calc (T.Vccp_tab_aft_R_GL) +
	  used_memory_calc (T.Vccp_tab_aft_R_GL_real)
	  - (sizeof (T.CC_rotor_input) +
	     sizeof (T.channels_tab) +
	     sizeof (T.CC_rotor_potential) +
	     sizeof (T.data) +
	     sizeof (T.Vccp_tab_bef_s_GL) +
	     sizeof (T.Vccp_tab_bef_R_GL) +
	     sizeof (T.Vccp_tab_aft_R_GL) +
	     sizeof (T.Vccp_tab_aft_R_GL_real))/1000000.0);
}

