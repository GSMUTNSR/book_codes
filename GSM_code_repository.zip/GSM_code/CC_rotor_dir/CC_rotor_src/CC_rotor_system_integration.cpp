#include "../CC_rotor_include/CC_rotor_include.h"

// Class allowing to integrate an equation of the form U''(z) = F(z).U(z), where U(z) = {uc(z)}_c and F(z) = {Fcc'(z)}_cc'
// -----------------------------------------------------------------------------------------------------------------------
// One uses the Burlisch-Stoer-Henrici method , where one integrates on different meshes
// with the Henrici method , and then use the Richardson method to extrapolate the final result.



/* Constructors and Destructors
 */
CC_rotor_system_integration::CC_rotor_system_integration () : N_channels (0)
{
  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = 0.0;

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 0.0;

      one_over_m_tab[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}

 
CC_rotor_system_integration::CC_rotor_system_integration (
							  const int N_channels_c,
							  const class CC_rotor_potential_class &CC_rotor_potential_c ,
							  const class array<class CC_rotor_channel_class> &channels_tab_c)
{
  allocate (N_channels_c , CC_rotor_potential_c , channels_tab_c);
}

CC_rotor_system_integration::CC_rotor_system_integration (const class CC_rotor_system_integration &X)
{
  allocate_fill (X);
}
						
void CC_rotor_system_integration::allocate (
					    const int N_channels_c ,
					    const class CC_rotor_potential_class &CC_rotor_potential_c ,
					    const class array<class CC_rotor_channel_class> &channels_tab_c)
{
  N_channels = N_channels_c;
  
  channels_tab.allocate_fill (channels_tab_c);

  CC_rotor_potential.allocate_fill (CC_rotor_potential_c);

  for (int n = 0 ; n < 8 ; n++)
    for (int i = 0 ; i < n ; i++)
      {
	const int i_plus_one = i + 1;

	double interpolation_term = 1.0;

	for (int ii = 0 ; ii < n ; ii++)
	  {
	    if (i != ii) interpolation_term *= i_plus_one/static_cast<double> (i - ii);
	  }

	interpolation_term_tab[Richardson_interpolation_index (n , i)] = interpolation_term;
      }

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 2*(k + 1);
      
      one_over_m_tab[k] = 1.0/static_cast<double> (m_tab[k]);

      H_over_m_tab[k] = 0.0;
    }

  h_square_F_r_U_tab.allocate (N_channels);

  U_debut.allocate (N_channels);
  dU_debut.allocate (N_channels);

  U_extrapolated.allocate (N_channels);

  U_extrapolated_next.allocate (N_channels);
  dU_extrapolated_next.allocate (N_channels);

  Res.allocate (N_channels);

  Delta.allocate (N_channels);

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].allocate (N_channels);
      dU_end[k].allocate (N_channels);
    }
}

					
void CC_rotor_system_integration::allocate_fill (const class CC_rotor_system_integration &X)
{
  N_channels = X.N_channels;
  
  channels_tab.allocate_fill (X.channels_tab);

  CC_rotor_potential.allocate_fill (X.CC_rotor_potential);

  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = X.interpolation_term_tab[i];

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = X.m_tab[k];
      
      one_over_m_tab[k] = X.one_over_m_tab[k];

      H_over_m_tab[k] = X.H_over_m_tab[k];
    }

  h_square_F_r_U_tab.allocate_fill (X.h_square_F_r_U_tab);

  U_debut.allocate_fill (X.U_debut);
  dU_debut.allocate_fill (X.dU_debut);

  U_extrapolated.allocate_fill (X.U_extrapolated);
  U_extrapolated_next.allocate_fill (X.U_extrapolated_next);

  dU_extrapolated_next.allocate_fill (X.dU_extrapolated_next);

  Res.allocate_fill (X.Res);

  Delta.allocate_fill (X.Delta);

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].allocate_fill (X.U_end[k]);
      dU_end[k].allocate_fill (X.dU_end[k]);
    }
}


void CC_rotor_system_integration::deallocate ()
{
  channels_tab.deallocate ();
  CC_rotor_potential.deallocate ();

  h_square_F_r_U_tab.deallocate ();
  U_debut.deallocate ();
  dU_debut.deallocate ();
  U_extrapolated.deallocate ();
  U_extrapolated_next.deallocate ();
  dU_extrapolated_next.deallocate ();
  Res.deallocate ();
  Delta.deallocate ();
  
  N_channels = 0;

  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = 0.0;

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      U_end[k].deallocate ();

      dU_end[k].deallocate ();

      m_tab[k] = 0.0;

      one_over_m_tab[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}







// Extrapolation in h=0 of a table of function values h close to h=0
// -----------------------------------------------------------------
//
// Variables:
// ----------
// n : number of points of the function F[] near h = {0}. It smaller or equal to 8.
// F[] : table containing the points F_0[]...F_{n - 1}[] close to h = {0}.
// F_in_zero : extrapolated value of the vectors F_0[]...F_{n - 1}[] in h = {0}.

void CC_rotor_system_integration::extrapolation_in_zero (
							 const unsigned int n ,
							 const class vector_class<complex<double> > F[] ,
							 class vector_class<complex<double> > &F_in_zero)
{
  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      complex<double> F_in_zero_c = 0.;

      for (unsigned int i = 0 ; i < n ; i++)
	{
	  const class vector_class<complex<double> > &Fi = F[i];
	  
	  F_in_zero_c += interpolation_term_tab[Richardson_interpolation_index (n , i)] * Fi(ic);
	}

      F_in_zero(ic) = F_in_zero_c;
    }
}




// Integration with discretization of U''(z) = F(z).U(z) with the Henrici method
// -----------------------------------------------------------------------------
//
// See Numerical Recipes for the method.
//
// Initials conditions : z0 , U(z0) , dU/dz(z0).
// Obtained functions : z , U(z) , dU/dz(z).
//
// Variables:
// ----------
// m : number of intervals between z0 and z
// h : integration step (z-z0)/m .
// z0 , U0 , dU0 : z0 , U(z0) , dU/dz(z0).
// z , U , dU : z , U(z) , dU/dz(z).
// ri : radius inside [z0:r]. It is z0 + i.h .
// h_square : h*h
// half_h = 0.5*h
// Delta : value used in the Henrici method.

void CC_rotor_system_integration::F_r_U_tab_calc (
						  const double r , 
						  const class vector_class<complex<double> > &U ,
						  class vector_class<complex<double> > &F_r_U_tab)
{
  const enum potential_type potential = CC_rotor_potential.get_potential ();

  const class dipolar_potential_class &dipolar_potential             = CC_rotor_potential.get_dipolar_potential ();
  const class quadrupolar_potential_class &quadrupolar_potential     = CC_rotor_potential.get_quadrupolar_potential ();
  const class Gaussian_potential_class &Gaussian_potential           = CC_rotor_potential.get_Gaussian_potential ();
  const class deformed_WS_class &deformed_WS_potential               = CC_rotor_potential.get_deformed_WS_potential ();
  const class deformed_WS_static_class &deformed_WS_static_potential = CC_rotor_potential.get_deformed_WS_static_potential ();
		
  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
      const int jrc = channel_c.get_jrc ();
      
      const int lc = channel_c.get_lc ();
      
      const double jc = channel_c.get_jc ();
      
      const double kinetic_factor_c = channel_c.get_kinetic_factor_c ();
      
      const complex<double> e_c = channel_c.get_e_c ();

      const double centrifugal_c = ((lc != 0) && (r > 0)) ? (lc * (lc + 1.0) / (r * r)) : (0.);

      complex<double> F_r_U_c = (centrifugal_c - kinetic_factor_c*e_c) * U(ic);

      for (unsigned icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);
	  
	  const int jrcp = channel_cp.get_jrc ();
	  
	  const int lcp = channel_cp.get_lc ();
	  
	  const double jcp = channel_cp.get_jc ();

	  switch (potential)
	    {
	    case DIPOLAR:            F_r_U_c += dipolar_potential     (jrc , lc , jrcp , lcp , r) * U (icp); break;
	    case QUADRUPOLAR:        F_r_U_c += quadrupolar_potential (jrc , lc , jrcp , lcp , r) * U (icp); break;
	    case GAUSSIAN:           F_r_U_c += Gaussian_potential    (jrc , lc , jrcp , lcp , r) * U (icp); break;
	      
	    case DEFORMED_WS:        F_r_U_c += kinetic_factor_c*deformed_WS_potential (jrc , lc , jc , jrcp , lcp , jcp , r) * U (icp); break;

	    case DEFORMED_WS_STATIC: F_r_U_c += kinetic_factor_c*deformed_WS_static_potential (lc , jc , lcp , jcp , r) * U (icp); break;
	      
	    default: error_message_print_abort ("CC_rotor_system_integration::F_r_U_tab_calc : bad potential type");
	    }
	}
      
      F_r_U_tab(ic) = F_r_U_c;
    }
}



// Integration with discretization of U''(z)=F(z).U(z) with the Henrici method
// ---------------------------------------------------------------------------
//
// See Numerical Recipes for the method.
//
// Initials conditions : z0 , U(z0) , dU/dz(z0).
// Obtained functions : z , U(z) , dU/dz(z).
//
// Variables:
// ----------
// m : number of intervals between z0 and z
// h : integration step (z-z0)/m .
// z0 , U0 , dU0 : z0 , U(z0) , dU/dz(z0).
// z , U , dU : z , U(z) , dU/dz(z).
// ri : radius inside [z0:r]. It is z0 + i.h .
// h_square : h*h
// half_h = 0.5*h
// Delta : value used in the Henrici method.


void CC_rotor_system_integration::integration_Henrici (
						       const unsigned int m , 
						       const double h , 
						       const double r0 ,
						       const class vector_class<complex<double> > &U0 ,
						       const class vector_class<complex<double> > &dU0 ,
						       const double r , 
						       class vector_class<complex<double> > &U ,
						       class vector_class<complex<double> > &dU)
{
  const double h2 = h * h;
  const double half_h = 0.5 * h;

  F_r_U_tab_calc (r0 , U0 , Delta);
  
  Delta *= half_h;
  
  Delta += dU0;
  
  Delta *= h;

  U = U0;

  U += Delta;

  for (unsigned int i = 1 ; i<m ; i++)
    {
      F_r_U_tab_calc (r0 + i * h , U , h_square_F_r_U_tab);

      h_square_F_r_U_tab *= h2;

      Delta += h_square_F_r_U_tab;

      U += Delta;
    }

  F_r_U_tab_calc (r , U , dU);
  
  dU *= half_h;
  
  Delta /= h;
  
  dU += Delta;
}










// Integration of U''(z) = F(z).U(z) with the Bulirsch-Stoer method
// ----------------------------------------------------------------
//
// Initials conditions : z0 , U0=U(z0) , dU0=dU/dz(z0)
// Obtained functions : z , U=U(z) , dU=dU/dz(z)
//
// See Numerical Recipes for the method.
//
// Variables:
// ---------- 
// z0 , U0 , dU0 : z0 , U(z0) , dU/dz(z0).
// z , U , dU : z , U(z) , dU/dz(z).
// H , z_debut , z_end , U_debut , dU_debut : length of an integration interval , debut and end of the integration interval , U(z_debut) , U'(z_debut).
//                                    H is equal to z-z0 at the beginning and is divided by 2 each time the extrapolation fails with 16 sub-intervals 
//                                    between z_debut and z_end. If H = [z - z0]/N , with N=2 , 4 , 8 , 16 , ... , 
//                                    the integration intervals are [z_debut = z0:z_end = z0+H] , ... , [z_debut = z0+(N-1).H , z_end = z].
// U_end , dU_end , k : tables of U(z_end) and U'(z_end) values calculated with the Henrici method with 2 , 4 , 6 , ... , 2(k+1) sub-intervals between z_debut and z_end , 
//                  with 0 <= k <= 7.
// H_over_m_tab : H/m for m=2 , 4 , 6 , ... , 16.
// inf_norm_half_H : |H/2|oo. It is used to know if z = z_debut up to numerical accuracy , as one has |r-z_debut|oo <= |H/2|oo for this case only.
// U_extrapolated , U_extrapolated_next : values of U extrapolated from the points of the table U_end with k and k->k+1 points , k >= 2.
// test : test to know if the method worked , i.e. , |u_extrapolated/u_extrapolated_next - 1|oo < precision.
// dU_extrapolated_next : value of U'(z_end) extrapolated from k points of the table dU_end , k >= 3.
// z_debut_plus_H : z_debut+H. z_debut+H at the end of integration is not necessarily z because of numerical cancellations.
//                             In this case , z_end must be put equal to z.

void CC_rotor_system_integration::operator () (
					       const double r0 , 
					       const class vector_class<complex<double> > &U0 ,
					       const class vector_class<complex<double> > &dU0 ,
					       const double r , 
					       class vector_class<complex<double> > &U ,
					       class vector_class<complex<double> > &dU)
{
  if (r == r0)
    {
      U  = U0;
      dU = dU0;

      return;
    }

  double r_debut = r0;

  double H = r - r0;

  U_debut  = U0;
  dU_debut = dU0;

  double test = INFINITE;

  while (test > precision)
    {
      for (unsigned int k = 0 ; k < 7 ; k++) H_over_m_tab[k] = H*one_over_m_tab[k];

      const double inf_norm_half_H = inf_norm (H_over_m_tab[0]);

      while (inf_norm (r_debut - r) > inf_norm_half_H)
	{
	  const double r_debut_plus_H = r_debut + H;

	  const double r_end = (inf_norm (r - r_debut_plus_H) > inf_norm_half_H) ? (r_debut_plus_H) : (r);

	  integration_Henrici (2 , H_over_m_tab[0] , r_debut , U_debut , dU_debut , r_end , U_end[0] , dU_end[0]);
	  integration_Henrici (4 , H_over_m_tab[1] , r_debut , U_debut , dU_debut , r_end , U_end[1] , dU_end[1]);

	  extrapolation_in_zero (2 , U_end , U_extrapolated);

	  Res = U_extrapolated;

	  unsigned int k = 2;

	  do
	    {
	      integration_Henrici (m_tab[k] , H_over_m_tab[k] , r_debut , U_debut , dU_debut , r_end , U_end[k] , dU_end[k]);

	      extrapolation_in_zero (++k , U_end , U_extrapolated_next);

	      Res -= U_extrapolated_next;

	      const double Res_inf_norm = Res.infinite_norm ();

	      const double U_extrapolated_next_inf_norm = U_extrapolated_next.infinite_norm ();

	      test = Res_inf_norm/U_extrapolated_next_inf_norm;

	      Res = U_extrapolated = U_extrapolated_next;
	    }
	  while ((test > precision) && (k < 7));

	  r_debut += H;

	  U_debut = U_extrapolated_next;

	  extrapolation_in_zero (k , dU_end , dU_extrapolated_next);

	  dU_debut = dU_extrapolated_next;
	}

      H *= 0.5;
      
      r_debut  = r0;
      U_debut  = U0; 
      dU_debut = dU0;
    }

  U  = U_extrapolated_next;
  dU = dU_extrapolated_next;
}



double used_memory_calc (const class CC_rotor_system_integration &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.CC_rotor_potential) +
    used_memory_calc (T.channels_tab) +
    used_memory_calc (T.h_square_F_r_U_tab) +
    used_memory_calc (T.U_debut) +
    used_memory_calc (T.dU_debut) +
    used_memory_calc (T.U_extrapolated) +
    used_memory_calc (T.U_extrapolated_next) +
    used_memory_calc (T.dU_extrapolated_next) +
    used_memory_calc (T.Res) +
    used_memory_calc (T.Delta) +
    used_memory_calc (T.U_end[0]) +
    used_memory_calc (T.dU_end[0]) +
    used_memory_calc (T.U_end[1]) +
    used_memory_calc (T.dU_end[1]) +
    used_memory_calc (T.U_end[2]) +
    used_memory_calc (T.dU_end[2]) +
    used_memory_calc (T.U_end[3]) +
    used_memory_calc (T.dU_end[3]) +
    used_memory_calc (T.U_end[4]) +
    used_memory_calc (T.dU_end[4]) +
    used_memory_calc (T.U_end[5]) +
    used_memory_calc (T.dU_end[5]) +
    used_memory_calc (T.U_end[6]) +
    used_memory_calc (T.dU_end[6])
    - (sizeof (T.CC_rotor_potential) +
       sizeof (T.channels_tab) +
       sizeof (T.h_square_F_r_U_tab) +
       sizeof (T.U_debut) +
       sizeof (T.dU_debut) +
       sizeof (T.U_extrapolated) +
       sizeof (T.U_extrapolated_next) +
       sizeof (T.dU_extrapolated_next) +
       sizeof (T.Res) +
       sizeof (T.Delta) +
       sizeof (T.U_end[0]) +
       sizeof (T.dU_end[0]) +
       sizeof (T.U_end[1]) +
       sizeof (T.dU_end[1]) +
       sizeof (T.U_end[2]) +
       sizeof (T.dU_end[2]) +
       sizeof (T.U_end[3]) +
       sizeof (T.dU_end[3]) +
       sizeof (T.U_end[4]) +
       sizeof (T.dU_end[4]) +
       sizeof (T.U_end[5]) +
       sizeof (T.dU_end[5]) +
       sizeof (T.U_end[6]) +
       sizeof (T.dU_end[6]))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays; 

  return used_memory;
}
