#include "../CC_rotor_include/CC_rotor_include.h"

using namespace string_routines;

// store input file data here.

// ================================== constructors ================================== //

CC_rotor_input_class::CC_rotor_input_class () 
  :
  calc_type (NO_CALC_TYPE_ROTOR_CC) ,
  are_wfs_stored (false) ,
  are_radial_form_factors_densities_stored (false) ,
  is_basis_fixed_for_E_rms_radius_plot (false) ,
  potential (NO_POTENTIAL) ,
  s (0.0) ,
  R0 (0.0) , 
  R (0.0) , 
  R_real_max (0.0) , 
  kmax_momentum (0.0) , 
  R_Fermi_momentum (0.0) , 
  N_bef_s_GL (0) , 
  N_bef_R_GL (0) , 
  N_aft_R_GL (0) , 
  N_bef_R_uniform (0) , 
  N_aft_R_uniform (0) ,  
  Nk_momentum_uniform (0) , 
  Nk_momentum_GL (0) ,
  I (0.0) ,  
  is_I_tab_used (false) ,
  lmax (0) ,
  particle (NO_PARTICLE) ,
  J (0.0) ,
  BP (0) , 
  S_matrix_pole (false) , 
  pole_approximation (false) , 
  Davidson_N_restarts (0) , 
  Davidson_eigenvector_precision (0.0) , 
  Davidson_max_dimension_subspace (0) , 
  real_E (0.0) , 
  Gamma (0.0) , 
  E (0.0) , 
  nmax_bound_res (0) , 
  Nk_peak (0) , 
  Nk_middle (0) , 
  Nk_max (0) , 
  k_peak (0.0) , 
  k_middle (0.0) , 
  k_max (0.0) , 
  Gamma_max (0.0) , 
  ic_entrance (0) , 
  is_CC_solver_direct_integration (false) , 
  is_asymptotic_wave_function_fit_used (false) , 
  // molecular
  mu (0.0) , 
  Qpm (0.0) , 
  alpha_0 (0.0) , 
  alpha_2 (0.0) , 
  r0 (0.0) , 
  Qzz (0.0) , 
  V0 (0.0) , 
  rc (0.0) , 
  N_Qpm_BEM_max (0) , 
  Qpm_BEM_initial (0.0) , 
  E_BEM_initial (0.0) ,
  N_V0_Gaussian_BEM_max (0.0) ,
  V0_Gaussian_BEM_initial (0.0) ,
  //nuclear
  A (0) , 
  Z (0) , 
  N (0) , 
  mass_modif (0) , 
  nucleon_mass_for_calc (0.0) , 
  Nt (0) , 
  Nr (0) , 
  N_points (0) , 
  ZY_charge (0) , 
  R_charge (0.0) , 
  d (0.0) , 
  R0_WS (0.0) , 
  beta_2 (0.0) , 
  Vo_basis (0.0) , 
  Vo_debut (0.0) , 
  Vo_end (0.0) , 
  Vo (0.0) , 
  Vso (0.0) , 
  V0_Gaussian (0.0) , 
  r0_Gaussian (0.0) , 
  mu_Gaussian (0.0) , 
  polarity_Gaussian (0),
  eigenvector_index (0) ,
  EM (NO_EM) ,
  L (0) ,
  K_static (0.0) ,
  is_it_longwavelength_approximation (false) ,
  effective_charge (0.0) ,
  BP_IN (0) ,
  BP_OUT (0) , 
  J_IN (0.0) ,
  J_OUT (0.0) ,
  eigenvector_index_IN (0) ,
  eigenvector_index_OUT (0) ,
  Vo_basis_IN (0.0) , 
  Vo_basis_OUT (0.0) ,
  Vo_IN (0.0) , 
  Vo_OUT (0.0) ,
  N_asymptotic_fit (0) ,
  rmin_for_fit (0.0) ,
  rmax_for_fit (0.0)
{}


CC_rotor_input_class::CC_rotor_input_class (const class CC_rotor_input_class &X)
{
  allocate_fill (X);
}

void CC_rotor_input_class::allocate_fill (const class CC_rotor_input_class &X)
{
  calc_type = X.calc_type;
  
  are_wfs_stored = X.are_wfs_stored;

  are_radial_form_factors_densities_stored = X.are_radial_form_factors_densities_stored;

  is_basis_fixed_for_E_rms_radius_plot = X.is_basis_fixed_for_E_rms_radius_plot;

  potential = X.potential;

  s = X.s;

  R0 = X.R0;
  
  R = X.R;
  
  R_real_max = X.R_real_max;
  
  kmax_momentum = X.kmax_momentum;
  
  R_Fermi_momentum = X.R_Fermi_momentum;

  N_bef_s_GL = X.N_bef_s_GL;
  N_bef_R_GL = X.N_bef_R_GL;
  N_aft_R_GL = X.N_aft_R_GL;
  
  N_bef_R_uniform = X.N_bef_R_uniform;
  N_aft_R_uniform = X.N_aft_R_uniform;

  Nk_momentum_uniform = X.Nk_momentum_uniform;
  
  Nk_momentum_GL = X.Nk_momentum_GL;
  
  I = X.I;
  
  is_I_tab_used = X.is_I_tab_used;

  lmax = X.lmax;

  particle = X.particle;

  J = X.J;
  
  BP = X.BP;

  S_matrix_pole = X.S_matrix_pole;
  
  pole_approximation = X.pole_approximation;

  Davidson_N_restarts = X.Davidson_N_restarts;

  Davidson_eigenvector_precision = X.Davidson_eigenvector_precision;

  Davidson_max_dimension_subspace = X.Davidson_max_dimension_subspace;

  real_E = X.real_E;
  
  Gamma = X.Gamma;

  E = X.E;

  nmax_bound_res = X.nmax_bound_res;

  Nk_peak = X.Nk_peak;
  Nk_middle = X.Nk_middle;
  Nk_max = X.Nk_max;

  k_peak = X.k_peak;
  
  k_middle = X.k_middle;
  
  k_max = X.k_max;

  Gamma_max = X.Gamma_max;

  b_HO = X.b_HO;

  ic_entrance = X.ic_entrance;

  is_CC_solver_direct_integration = X.is_CC_solver_direct_integration;

  is_asymptotic_wave_function_fit_used = X.is_asymptotic_wave_function_fit_used;


  
  
  mu = X.mu;                            
  Qpm = X.Qpm;                            
  alpha_0 = X.alpha_0;                            
  alpha_2 = X.alpha_2;                            
  r0 = X.r0;                            
  Qzz = X.Qzz;                            
  V0 = X.V0;                            
  rc = X.rc;                            



  

  N_Qpm_BEM_max = X.N_Qpm_BEM_max;                            
  
  Qpm_BEM_initial = X.Qpm_BEM_initial;                            

  E_BEM_initial = X.E_BEM_initial;                            

  N_V0_Gaussian_BEM_max = X.N_V0_Gaussian_BEM_max;                            

  V0_Gaussian_BEM_initial = X.V0_Gaussian_BEM_initial;                            




  
  A = X.A;
  N = X.N;
  Z = X.Z;

  mass_modif = X.mass_modif;
  
  nucleon_mass_for_calc = X.nucleon_mass_for_calc;

  Nt = X.Nt;
  Nr = X.Nr;
  
  N_points = X.N_points;

  ZY_charge = X.ZY_charge;

  R_charge = X.R_charge;
  
  d = X.d;                            
  R0_WS = X.R0_WS;                            
  beta_2 = X.beta_2;                            
  
  Vo_basis = X.Vo_basis;                            
  Vo_debut = X.Vo_debut;                            
  Vo_end = X.Vo_end;                            
  Vo = X.Vo;                            
  
  Vso = X.Vso;                            

  
  V0_Gaussian = X.V0_Gaussian;                            
  r0_Gaussian = X.r0_Gaussian;                            
  mu_Gaussian = X.mu_Gaussian;                            

  polarity_Gaussian = X.polarity_Gaussian;                            



  
  eigenvector_index = X.eigenvector_index;

  EM = X.EM;

  L = X.L;

  K_static = X.K_static;
  
  is_it_longwavelength_approximation = X.is_it_longwavelength_approximation;

  effective_charge = X.effective_charge;

  BP_IN = X.BP_IN;
  BP_OUT = X.BP_OUT;

  J_IN = X.J_IN;
  J_OUT = X.J_OUT;

  eigenvector_index_IN = X.eigenvector_index_IN;
  eigenvector_index_OUT = X.eigenvector_index_OUT;
  
  Vo_basis_IN = X.Vo_basis_IN; 
  Vo_basis_OUT = X.Vo_basis_OUT; 
  
  Vo_IN = X.Vo_IN;
  Vo_OUT = X.Vo_OUT;

  N_asymptotic_fit = X.N_asymptotic_fit; 

  rmin_for_fit = X.rmin_for_fit;
  rmax_for_fit = X.rmax_for_fit;
  
  contours_data.allocate_fill (X.contours_data);

  rotor_angular_momenta.allocate_fill (X.rotor_angular_momenta);

  moments_of_inertia.allocate_fill (X.moments_of_inertia);

  core_shells_tab.allocate_fill (X.core_shells_tab);

  contours_tab_shells.allocate_fill (X.contours_tab_shells);
  
  contours_tab_k_peak.allocate_fill (X.contours_tab_k_peak);

  contours_tab_k_middle.allocate_fill (X.contours_tab_k_middle);

  contours_tab_k_max.allocate_fill (X.contours_tab_k_max);

  contours_tab_Nk_peak.allocate_fill (X.contours_tab_Nk_peak);

  contours_tab_Nk_middle.allocate_fill (X.contours_tab_Nk_middle);

  contours_tab_Nk_max.allocate_fill (X.contours_tab_Nk_max);

  E_BEM_start_tab.allocate_fill (X.E_BEM_start_tab);
  G_BEM_start_tab.allocate_fill (X.G_BEM_start_tab);

  Ef_BEM_start_tab.allocate_fill (X.Ef_BEM_start_tab);
}

void CC_rotor_input_class::deallocate ()
{
  contours_data.deallocate ();

  rotor_angular_momenta.deallocate ();

  moments_of_inertia.deallocate ();

  core_shells_tab.deallocate ();

  contours_tab_shells.deallocate ();
  
  contours_tab_k_peak.deallocate ();

  contours_tab_k_middle.deallocate ();

  contours_tab_k_max.deallocate ();

  contours_tab_Nk_peak.deallocate ();

  contours_tab_Nk_middle.deallocate ();

  contours_tab_Nk_max.deallocate ();

  E_BEM_start_tab.deallocate ();
  G_BEM_start_tab.deallocate ();

  Ef_BEM_start_tab.deallocate ();
  
  calc_type = NO_CALC_TYPE_ROTOR_CC;
  are_wfs_stored = false;
  are_radial_form_factors_densities_stored = false;
  is_basis_fixed_for_E_rms_radius_plot = false;
  potential = NO_POTENTIAL;
  s = 0.0;
  R0 = 0.0;
  R = 0.0;
  R_real_max = 0.0;
  kmax_momentum = 0.0;
  R_Fermi_momentum = 0.0;
  N_bef_s_GL = 0;
  N_bef_R_GL = 0;
  N_aft_R_GL = 0;
  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0; 
  Nk_momentum_uniform = 0;
  Nk_momentum_GL = 0;
  I = 0.0;  
  is_I_tab_used = false;
  lmax = 0;
  particle = NO_PARTICLE;
  J = 0.0;
  BP = 0;
  S_matrix_pole = false;
  pole_approximation = false;
  Davidson_N_restarts = 0;
  Davidson_eigenvector_precision = 0.0;
  Davidson_max_dimension_subspace = 0;
  real_E = 0.0;
  Gamma = 0.0;
  E = 0.0;
  nmax_bound_res = 0;
  Nk_peak = 0;
  Nk_middle = 0;
  Nk_max = 0;
  k_peak = 0.0;
  k_middle = 0.0;
  k_max = 0.0;
  Gamma_max = 0.0;
  ic_entrance = 0;
  is_CC_solver_direct_integration = false;
  is_asymptotic_wave_function_fit_used = false;
  // molecular
  mu = 0.0;
  Qpm = 0.0;
  alpha_0 = 0.0;
  alpha_2 = 0.0;
  r0 = 0.0;
  Qzz = 0.0;
  V0 = 0.0;
  rc = 0.0;
  N_Qpm_BEM_max = 0;
  Qpm_BEM_initial = 0.0;
  E_BEM_initial = 0.0;
  N_V0_Gaussian_BEM_max = 0.0;
  V0_Gaussian_BEM_initial = 0.0;
  //nuclear
  A = 0;
  Z = 0;
  N = 0;
  mass_modif = 0;
  nucleon_mass_for_calc = 0.0;
  Nt = 0;
  Nr = 0;
  N_points = 0;
  ZY_charge = 0;
  R_charge = 0.0;
  d = 0.0;
  R0_WS = 0.0;
  beta_2 = 0.0;
  Vo_basis = 0.0;
  Vo_debut = 0.0;
  Vo_end = 0.0;
  Vo = 0.0;
  Vso = 0.0;
  V0_Gaussian = 0.0;
  r0_Gaussian = 0.0;
  mu_Gaussian = 0.0;
  polarity_Gaussian = 0;
  eigenvector_index = 0;
  EM = NO_EM;
  L = 0;
  K_static = 0.0;
  is_it_longwavelength_approximation = false;
  effective_charge = 0.0;
  BP_IN = 0;
  BP_OUT = 0;
  J_IN = 0.0;
  J_OUT = 0.0;
  eigenvector_index_IN = 0;
  eigenvector_index_OUT = 0;
  Vo_basis_IN = 0.0;
  Vo_basis_OUT = 0.0;
  Vo_IN = 0.0;
  Vo_OUT = 0.0;
  N_asymptotic_fit = 0;
  rmin_for_fit = 0.0;
  rmax_for_fit = 0.0;
}
  

// ================================== methods ================================== //
// run the CC_rotor_input_class
void CC_rotor_input_class::read_input_data_from_file ()
{
  cin >> calc_type;
  word_check_print<enum calc_type_rotor_CC> ("(calculation)" , calc_type);

  cout << "calculation : " << calc_type << endl << endl;
  
  if ((calc_type == MOLECULAR) || (calc_type == NUCLEAR_ONE_STATE))
    {
      are_wfs_stored = bool_determination ("wave.functions.files.stored");
      cout << endl;
      
      are_radial_form_factors_densities_stored = bool_determination ("radial.form.factors.densities.stored");
      cout << endl;
    }
  else
    are_wfs_stored = are_radial_form_factors_densities_stored = false;
  
  if (calc_type == NUCLEAR_EM_TRANSITION) read_store_EM_transition_data ();
  cout << endl;
  
  is_CC_solver_direct_integration = bool_determination ("direct.integration");
  cout << endl;
    
  read_store_potential_constants ();

  read_store_radial_momentum_parameters ();

  read_store_rotor_state_data ();

  if (!is_CC_solver_direct_integration) read_store_all_E_G_BEM_start_contour_tables ();
      
  check_input_data_consistency ();
}








// Read constants from input file

void CC_rotor_input_class::read_store_potential_constants ()
{
  cout << "Potential constants" << endl;
  cout << "===================" << endl;
    
  cin >> potential;
  word_check_print<enum potential_type> ("(potential)" , potential);

  cin >> particle;
  word_check_print<enum particle_type> ("(particle)" , particle);

  cout << endl;

  const bool are_moments_of_inertia_infinite = bool_determination ("moments.of.inertia.infinite");
    
  if (!are_moments_of_inertia_infinite && (potential == DEFORMED_WS_STATIC)) error_message_print_abort ("Moments of inertia have to be infinite when using a static core");
  
  is_basis_fixed_for_E_rms_radius_plot = false;
      
  if (calc_type != MOLECULAR)
    {
      if (!are_moments_of_inertia_infinite) is_I_tab_used = bool_determination ("moment.of.inertia.table.used");

      cout << endl;
    }

  if (!are_moments_of_inertia_infinite)
    { 
      if (!is_I_tab_used)
	{
	  cin >> I;

	  if (calc_type == MOLECULAR)
	    word_check_print<double> ("me.a0^2(moment.of.inertia)"  , I); 
	  else
	    word_check_print<double> ("amu.fm^2(moment.of.inertia)" , I); 
	}
      else
	{
	  store_input_file_table_moment_of_inertia_nuclear_case ();

	  I = moments_of_inertia.max ();
	}
      
      cout << endl;
    }
  else
    {
      is_I_tab_used = false;

      moments_of_inertia = INFINITE;
      
      I = INFINITE;
    }

  if (calc_type == MOLECULAR)
    {
      is_I_tab_used = false;
        
      if (potential == QUADRUPOLAR)
	{
	  cin >> Qpm;
	  word_check_print<double> ("(Qpm)" , Qpm);

	  cin >> V0;
	  word_check_print<double> ("Ry(V0)" , V0);

	  cin >> rc;
	  word_check_print<double> ("a0(r.cut)" , rc);
	  
	  cin >> Nt;
	  word_check_print<unsigned int> ("(Nt)" , Nt);
	}

      if (potential == DIPOLAR)
	{ 
	  cin >> mu;
	  word_check_print<double> ("e.a0(mu)" , mu);

	  cin >> alpha_0;
	  word_check_print<double> ("a0^3(alpha[0])" , alpha_0);

	  cin >> alpha_2;
	  word_check_print<double> ("a0^3(alpha[2])" , alpha_2);

	  cin >> Qzz;
	  word_check_print<double> ("e.a0^2(Qzz)" , Qzz);

	  cin >> r0;
	  word_check_print<double> ("a0(r0)" , r0);

	  cin >> V0;
	  word_check_print<double> ("Ry(V0)" , V0);

	  cin >> rc;
	  word_check_print<double> ("a0(r.cut)" , rc);

	  cin >> Nt;	  
	  word_check_print<unsigned int> ("(Nt)" , Nt);
	}

      cout << endl;

      if (potential == GAUSSIAN)
	{
	  cin >> V0_Gaussian;
	  word_check_print<double> ("Ry(V0)" , V0_Gaussian); 

	  cin >> r0_Gaussian;
	  word_check_print<double> ("a0(r0)" , r0_Gaussian);

	  cin >> mu_Gaussian;
	  word_check_print<double> ("a0(range)" , mu_Gaussian);

	  cin >> polarity_Gaussian;
	  word_check_print<int> ("(polarity)" , polarity_Gaussian);

	  cin >> Nt;
	  word_check_print<unsigned int> ("(Nt)" , Nt);
	  
	  cin >> Nr;
	  word_check_print<unsigned int> ("(Nr)" , Nr);
	}
    }
  
  if (calc_type != MOLECULAR)
    {
      cin >> A;
      word_check_print<int> ("(A)" , A); 

      cin >> Z;
      word_check_print<int> ("(Z)" , Z); 

      N = A - Z;
 
      cin >> mass_modif;
      word_check_print<double> ("(target.mass)" , mass_modif); 

      cin >> nucleon_mass_for_calc;
      word_check_print<double> ("(nucleon.mass.for.calculation)" , nucleon_mass_for_calc); 

      cout << endl;

      if (particle == PROTON)
	{
	  cin >> ZY_charge;
	  word_check_print<int> ("(Z.charge)" , ZY_charge); 
	  
	  cin >> R_charge;
	  word_check_print<double> ("fm(charge.radius)" , R_charge); 
	}
      
      cin >> d;
      word_check_print<double> ("fm(diffuseness)" , d); 

      cin >> R0_WS;
      word_check_print<double> ("fm(R0)" , R0_WS); 

      cin >> beta_2;
      word_check_print<double> ("(beta.2)" , beta_2); 

      cin >> Vso;
      word_check_print<double> ("MeV(Vso)" , Vso);

      if (calc_type == NUCLEAR_EM_TRANSITION)
	{
	  if (!is_CC_solver_direct_integration)
	    {	  
	      cin >> Vo_basis_IN;
	      word_check_print<double> ("MeV(Vo.in[basis.potential])" , Vo_basis_IN);  

	      cin >> Vo_basis_OUT;
	      word_check_print<double> ("MeV(Vo.out[basis.potential])" , Vo_basis_OUT);
	  
	      cin >> Vo_IN;
	      word_check_print<double> ("MeV(Vo.in[potential.to.diagonalize])" , Vo_IN);  

	      cin >> Vo_OUT;
	      word_check_print<double> ("MeV(Vo.out[potential.to.diagonalize])" , Vo_OUT);
	    }
	  else
	    {
	      cin >> Vo_IN;
	      word_check_print<double> ("MeV(Vo.in)" , Vo_IN);  

	      cin >> Vo_OUT;
	      word_check_print<double> ("MeV(Vo.out)" , Vo_OUT);
	    }
	}
      else if (calc_type == NUCLEAR_ONE_STATE)
	{      
	  if (!is_CC_solver_direct_integration)
	    {
	      cin >> Vo_basis;
	      word_check_print<double> ("MeV(Vo[basis.potential])" , Vo_basis);
	      
	      cin >> Vo;
	      word_check_print<double> ("MeV(Vo[potential.to.diagonalize])" , Vo);	      
	    }
	  else
	    {
	      cin >> Vo;
	      word_check_print<double> ("MeV(Vo)" , Vo);
	    }

	  Vo_debut = Vo_end = Vo; // For convenience only: in case one wants to use these values somewhere.
	}
      else if (calc_type == NUCLEAR_E_RMS_RADIUS_PLOT)
	{
	  if (!is_CC_solver_direct_integration)
	    {
	      is_basis_fixed_for_E_rms_radius_plot = bool_determination ("same.basis.for.all.states");

	      if (is_basis_fixed_for_E_rms_radius_plot)
		{
		  cin >> Vo_basis;
		  word_check_print<double> ("MeV(Vo[basis.potential])" , Vo_basis);
		}
	      
	      cin >> Vo_debut;
	      word_check_print<double> ("MeV(Vo.debut[potential.to.diagonalize])" , Vo_debut);
	      
	      cin >> Vo_end;
	      word_check_print<double> ("MeV(Vo.end[potential.to.diagonalize])" , Vo_end);	      
	    }
	  else
	    {
	      cin >> Vo_debut;
	      word_check_print<double> ("MeV(Vo.debut[potential.to.diagonalize])" , Vo_debut);
	      
	      cin >> Vo_end;
	      word_check_print<double> ("MeV(Vo.end[potential.to.diagonalize])" , Vo_end);
	    }
	  
	  cin >> N_points;
	  word_check_print<unsigned int> ("(N.points)" , N_points);  
	}
      else
	error_message_print_abort ("CC_rotor_input_class::read_store_potential_constants: bad calc type");
 
      cin >> Nt;
      word_check_print<unsigned int> ("(Nt)" , Nt);
      
      cin >> Nr;
      word_check_print<unsigned int> ("(Nr)" , Nr);
      
      cout << endl;
    }
      
  cout << endl;
}
















void CC_rotor_input_class::read_store_radial_momentum_parameters ()
{
  cout << "Radial parameters" << endl;
  cout << "=================" << endl;

  if (calc_type == MOLECULAR)
    { 
      cin >> R0;
      word_check_print<double> ("a0(matching.point)" , R0); 
 
      cin >> R;
      word_check_print<double> ("a0(R)" , R); 
  
      cin >> R_real_max;
      word_check_print<double> ("a0(R.real.max)" , R_real_max); 

      cout << endl;

      if (potential != GAUSSIAN)
	{
	  cin >> s;
	  word_check_print<double> ("a0(s)" , s);
	}
      
      cout << endl;

      cin >> b_HO;
      word_check_print<double> ("a0(b.HO)" , b_HO);

      cin >> kmax_momentum;      
      word_check_print<double> ("a0^(-1)(k.max.momentum)" , kmax_momentum);
      
      cin >> R_Fermi_momentum;      
      word_check_print<double> ("a0(R.Fermi.function.momentum)" , R_Fermi_momentum);

      if (potential != GAUSSIAN)
	{
	  cin >> N_bef_s_GL;
	  word_check_print<unsigned int> ("(N.bef.s.GL)" , N_bef_s_GL);
	}
    }
  else
    {
      cin >> R0;
      word_check_print<double> ("fm(matching.point)" , R0); 
 
      cin >> R;
      word_check_print<double> ("fm(R)" , R); 
  
      cin >> R_real_max;
      word_check_print<double> ("fm(R.real.max)" , R_real_max); 

      cin >> b_HO;
      word_check_print<double> ("fm(b.HO)" , b_HO);

      cin >> kmax_momentum;      
      word_check_print<double> ("fm^(-1)(k.max.momentum)" , kmax_momentum);
  
      cin >> R_Fermi_momentum;      
      word_check_print<double> ("fm(R.Fermi.function.momentum)" , R_Fermi_momentum);

      cout << endl;
    }

  cin >> N_bef_R_GL;
  word_check_print<unsigned int> ("(N.bef.R.GL)" , N_bef_R_GL);

  cin >> N_aft_R_GL;
  word_check_print<unsigned int> ("(N.aft.R.GL)" , N_aft_R_GL);

  cin >> N_bef_R_uniform;
  word_check_print<unsigned int> ("(N.bef.R.uniform)" , N_bef_R_uniform);

  cin >> N_aft_R_uniform;
  word_check_print<unsigned int> ("(N.aft.R.uniform)" , N_aft_R_uniform);
  
  cin >> Nk_momentum_GL;
  word_check_print<unsigned int> ("(Nk.momentum.GL)" , Nk_momentum_GL);
  
  cin >> Nk_momentum_uniform;
  word_check_print<unsigned int> ("(Nk.momentum.uniform)" , Nk_momentum_uniform);
      
  cout << endl;
}











void CC_rotor_input_class::read_store_rotor_state_data ()
{
  cout << "Rotor state parameters" << endl;
  cout << "======================" << endl;

  if (calc_type != NUCLEAR_EM_TRANSITION)
    {	  
      if (potential == DEFORMED_WS_STATIC)
	{
	  quantum_numbers_read (BP  , K_static  , eigenvector_index);
	  
	  cout << M_Pi_vector_index_string (BP  , K_static  , eigenvector_index) << endl;
	}
      else
	{	  
	  if (calc_type == MOLECULAR)
	    {
	      string J_BP_str;

	      cin >> J_BP_str;
      
	      J = determine_M (J_BP_str);
	  
	      BP = determine_Binary_Parity (J_BP_str);
	      
	      cout << "J-Pi: " << J_BP_str << endl;
	    }
	  else
	    {
	      quantum_numbers_read (BP  , J  , eigenvector_index);
	      
	      cout << J_Pi_vector_index_string (BP  , J  , eigenvector_index) << endl;
	    }
	}
      
      S_matrix_pole = bool_determination ("S.matrix.pole");
    }
  else
    S_matrix_pole = true;

  cin >> lmax;
  word_check_print<int> ("(lmax)" , lmax);

  if (is_CC_solver_direct_integration)
    {
      cout << endl;
      cout << "Direct integration parameters" << endl;
      cout << "=============================" << endl;
      
      if (calc_type == MOLECULAR)
	{
	  cin >> real_E;
	  word_check_print<double> ("Ry(E.start)" , real_E);
	  
	  cin >> Gamma;
	  word_check_print<double> ("Ry(Gamma.start)" , Gamma);

	  E = complex<double> (real_E , -0.5*Gamma);
	}
      else
	{
	  cin >> real_E;
	  word_check_print<double> ("MeV(E.start)" , real_E);
	  
	  cin >> Gamma;
	  word_check_print<double> ("keV(Gamma.start)" , Gamma);
	  
	  E = complex<double> (real_E , -0.0005*Gamma);
	}

      cout << endl;

      if (!S_matrix_pole)
	{
	  cin >> ic_entrance;
	  word_check_print<unsigned int> ("(entrance.channel)" , ic_entrance);
	}

      cout << endl;
    }
  else
    {      
      pole_approximation = bool_determination ("pole.approximation");
  
      cout << endl << "Berggren basis diagonalization parameters" << endl;
      cout <<         "=========================================" << endl;

      cin >> Davidson_N_restarts;
      word_check_print<unsigned int> ("(Davidson.restarts.number)" , Davidson_N_restarts);

      cin >> Davidson_eigenvector_precision;
      word_check_print<double> ("(Davidson_eigenvector.precision)" , Davidson_eigenvector_precision);

      cin >> Davidson_max_dimension_subspace;
      word_check_print<unsigned int> ("(Davidson.subspace.maximal.dimension)" , Davidson_max_dimension_subspace);

      cin >> nmax_bound_res;
      word_check_print<int> ("(nmax.basis.bound.resonant)" , nmax_bound_res);

      cin >> Gamma_max;
      word_check_print<double> ("(maximal.widths.basis)" , Gamma_max);

      cout << endl;

      cout << "Contours parameters" << endl;
      cout << "===================" << endl;

      if (potential == GAUSSIAN)
	{	  
	  cout << "Initial potential a value for Berggren basis diagonalization" << endl;
	  cout << "============================================================" << endl;
	  
	  cin >> V0_Gaussian_BEM_initial;
	  word_check_print<double> ("(V0.initial)" , V0_Gaussian_BEM_initial);
	  
	  cin >> N_V0_Gaussian_BEM_max;
	  word_check_print<unsigned int> ("(V0.maximal.number)" , N_V0_Gaussian_BEM_max);
	}
	
      if (potential == QUADRUPOLAR)
	{
	  cout << "Initial potential Qpm value for Berggren basis diagonalization" << endl;
	  cout << "==============================================================" << endl;

	  cin >> Qpm_BEM_initial;
	  word_check_print<double> ("e.a0^2(Qpm.initial)" , Qpm_BEM_initial);

	  cin >> N_Qpm_BEM_max;
	  word_check_print<unsigned int> ("(Qpm.maximal.number)" , N_Qpm_BEM_max);

	  cout << endl;
	}
    }

  if (calc_type == MOLECULAR)
    {
      cout << "fit of u_c(r) tails" << endl;
      cout << "===================" << endl;

      is_asymptotic_wave_function_fit_used = bool_determination ("asymptotic.wave.function.fit.used");

      if (is_asymptotic_wave_function_fit_used) store_input_data_for_fit ();
  
      cout << endl;
    }
}


void CC_rotor_input_class::read_store_EM_transition_data ()
{
  cin >> effective_charge;

  word_check_print<double> ("(effective.charge)" , effective_charge);

  word_check ("EM.type");
  word_check ("quantum.numbers.in");
  word_check ("quantum.numbers.out");
  word_check ("long.wavelength.approximation(yes/no)");  

  string EM_string;

  string L_of_EM;
  
  cin >> EM_string;

  EM = EM_determine (EM_string);

  EM_string += '\n';

  for (unsigned int ii = 1 ; EM_string[ii] != '\n' ; ii++) L_of_EM += EM_string[ii];

  L = atoi (L_of_EM.c_str ());

  quantum_numbers_read (BP_IN  , J_IN  , eigenvector_index_IN);
  quantum_numbers_read (BP_OUT , J_OUT , eigenvector_index_OUT);

  is_it_longwavelength_approximation = bool_determination_no_print ("long.wavelength.approximation");

  const string EM_is_it_longwavelength_approximation_string = (is_it_longwavelength_approximation) ? ("long.wavelength.approximation(yes)") : ("long.wavelength.approximation(no)");

  cout << EM << L << "    " 
       << J_Pi_vector_index_string (BP_IN  , J_IN  , eigenvector_index_IN) << "    " 
       << J_Pi_vector_index_string (BP_OUT , J_OUT , eigenvector_index_OUT) << "    " 
       << EM_is_it_longwavelength_approximation_string << "    " << endl;
}














//check trivial inconsistencies within input data
void CC_rotor_input_class::check_input_data_consistency ()
{    
  if (((potential == DEFORMED_WS) || (potential == DEFORMED_WS_STATIC)) && (particle == ELECTRON)) error_message_print_abort ("Inconsistent particle and potential types");
  
  if (calc_type == MOLECULAR)
    {
      if (potential == DIPOLAR)
	{
	  if ((mu < 0.0) || (alpha_0 < 0.0) || (alpha_2 < 0.0) || (r0 < 0.0) || (Qzz < 0.0) || (V0 < 0.0) || (rc < 0.0))
	    error_message_print_abort ("Dipolar potential does not support negative parameters");
	}

      if ((potential == QUADRUPOLAR) && (!is_CC_solver_direct_integration))
	{
	  if (Qpm_BEM_initial == 0.0) error_message_print_abort ("Zero Qpm_BEM_initial cannot lead to stable results");

	  if (abs (Qpm_BEM_initial) < abs (Qpm)) error_message_print_abort ("|Qpm_BEM_initial| cannot be smaller than |Q_pm|");
	}

      if ((potential == GAUSSIAN) && (!is_CC_solver_direct_integration))
	{
	  if (V0_Gaussian_BEM_initial > 0.0) error_message_print_abort ("positive a_BEM_initial cannot generate potential well");
	}
    }
  else
    {      
      if ((potential == DEFORMED_WS_STATIC) && (make_int (2.0*K_static) < 0)) error_message_print_abort ("One must have K >= 0 when using the deformed Woods-Saxon potential in a static picture");

      if (nucleon_mass_for_calc < 0.0) error_message_print_abort ("Nucleon mass cannot be negative");

      if ((ZY_charge < 0) || (R_charge < 0.0)) error_message_print_abort ("Coulomb potential does not support negative parameters");

      if ((d <= 0.0) || (R0_WS <= 0.0) || (Vso < 0.0)) error_message_print_abort ("WS potential does not support negative parameters for d, R0 or Vso");
      
      if ((calc_type == NUCLEAR_ONE_STATE) && (Vo < 0.0)) error_message_print_abort ("WS potential does not support negative parameters for Vo");
            
      if ((calc_type == NUCLEAR_E_RMS_RADIUS_PLOT) && ((Vo_debut < 0.0) || (Vo_end < 0.0))) error_message_print_abort ("WS potential does not support negative parameters for Vo[debut] and Vo[end]");
      
      if ((calc_type == NUCLEAR_E_RMS_RADIUS_PLOT) && ((Vo_debut < 0.0) || (Vo_end < 0.0))) error_message_print_abort ("WS potential does not support negative parameters for Vo[debut] and Vo[end]");
      
      if ((calc_type == NUCLEAR_EM_TRANSITION) && ((Vo_IN < 0.0) || (Vo_OUT < 0.0))) error_message_print_abort ("WS potential does not support negative parameters for Vo[in] and Vo[out]");
      
      if ((calc_type == NUCLEAR_EM_TRANSITION) && !is_CC_solver_direct_integration && ((Vo_basis_IN < 0.0) || (Vo_basis_OUT < 0.0))) error_message_print_abort ("WS potential does not support negative parameters for Vo[in][basis] and Vo[out][basis]");

      if ((calc_type == NUCLEAR_E_RMS_RADIUS_PLOT) && (N_points == 1)) error_message_print_abort ("N.points must be 2 at least");
      
      if ((Nt == 0) || (Nr == 0)) error_message_print_abort ("Nr and Nt must be positive");
    }

  if ((particle == ELECTRON) && (ZY_charge != 0)) error_message_print_abort ("The charge of the core molecule is always zero");

  if (!S_matrix_pole && !is_CC_solver_direct_integration) error_message_print_abort ("Scattering states can be calculated with direct integration only");

  if (is_asymptotic_wave_function_fit_used && (potential != DIPOLAR)) error_message_print_abort ("The asymptotic wave function fit can be used only with dipolar molecules");

  if (I <= 0.0) error_message_print_abort ("The moment of inertia cannot be negative or zero");

  if (J < 0.0) error_message_print_abort ("The total angular momentum cannot be negative");

  if (lmax < 0) error_message_print_abort ("lmax cannot be negative");

  if ((R0 < 0.0) || (R < 0.0) || (R_real_max < 0.0) || (R0 >= R) || (R >= R_real_max)) error_message_print_abort ("Radial discretization incorrect or inconsistent (R0 < R < R_max)");

  if (calc_type == MOLECULAR)
    {
      if ((potential != GAUSSIAN) && ((s < 0.0) || (s > R0) || (N_bef_s_GL == 0))) error_message_print_abort ("Radial discretization incorrect or inconsistent (r = s < R0 < R < R_max)");
    }

  if ((N_bef_R_GL == 0) || (N_aft_R_GL == 0) || (N_bef_R_uniform == 0) || (N_aft_R_uniform == 0)) error_message_print_abort ("Radial discretization incorrect or inconsistent (Gauss-Legendre , uniform grid)");
  
  if (is_asymptotic_wave_function_fit_used)
    {
      if (rmin_for_fit < R) error_message_print_abort ("CC_rotor_input_class::store_input_file_tables_for_fit: rmin_for_fit must be larger than R.");
      if (rmax_for_fit > R_real_max) error_message_print_abort ("CC_rotor_input_class::store_input_file_tables_for_fit: rmax_for_fit must be smaller than R_max.");
    }
}







void CC_rotor_input_class::read_and_print_input_file_E_G_BEM_start ()
{
  unsigned int N_E_G_BEM_start = 0;

  cin >> N_E_G_BEM_start;
  word_check_print<unsigned int> ("(E.start.number)" , N_E_G_BEM_start);

  cout << endl;
  
  word_check ("E.start");
  word_check ("Gamma.start");

  E_BEM_start_tab.allocate (N_E_G_BEM_start);
  G_BEM_start_tab.allocate (N_E_G_BEM_start);

  for (unsigned int i = 0 ; i < N_E_G_BEM_start ; i++)
    {
      cin >> E_BEM_start_tab[i];
      cin >> G_BEM_start_tab[i];

      cout << E_BEM_start_tab[i] << " " << G_BEM_start_tab[i] << endl;
    }
  
  if (nmax_bound_res == 0) error_message_print_abort ("CC_rotor_input_class::read_and_print_input_file_E_G_BEM_start: wrong number of pole states");
 
  Ef_BEM_start_tab.allocate (nmax_bound_res + 1);
  Ef_BEM_start_tab = 0.0; // Arbitrary initialization. Used later as starting point

  cout << endl;
}








// read contours in a table for nuclear and optimization calculations
// s1/2 k_peak k_middle kmax Npeak Nmid Nmax
void CC_rotor_input_class::read_and_print_input_file_contours ()
{
  unsigned int N_contours = 0;

  cin >> N_contours;
  word_check_print<unsigned int> ("(contours.number)" , N_contours);

  if (N_contours == 0) error_message_print_abort ("CC_rotor_input_class::read_and_print_input_file_contours: no contour");

  contours_tab_shells.allocate (N_contours);

  contours_tab_k_peak.allocate (N_contours);
  contours_tab_k_middle.allocate (N_contours);
  contours_tab_k_max.allocate (N_contours);

  contours_tab_Nk_peak.allocate (N_contours);
  contours_tab_Nk_middle.allocate (N_contours);
  contours_tab_Nk_max.allocate (N_contours);

  word_check ("partial.wave");

  switch (calc_type)
    {
    case MOLECULAR:
      {
	word_check ("k.peak(a0^(-1))");
	word_check ("k.middle(a0^(-1))");
	word_check ("k.max(a0^(-1))");

	cout << "k.peak(a0^(-1))     k.middle(a0^(-1))     k.max(a0^(-1))" << endl;
      } break;

    case NO_CALC_TYPE_ROTOR_CC: abort_all (); break;
    
    default:
      {
	word_check ("k.peak(fm^(-1))");
	word_check ("k.middle(fm^(-1))");
	word_check ("k.max(fm^(-1))");
	
	cout << "k.peak(fm^(-1))     k.middle(fm^(-1))     k.max(fm^(-1))" << endl;
      } break;
    }
  
  word_check ("N.k.peak");
  word_check ("N.k.middle");
  word_check ("N.k.max");

  cout << "N.k.peak      N.k.middle      N.k.max" << endl;

  for (unsigned int i = 0 ; i < N_contours ; i++)
    {
      cin >> contours_tab_shells[i] >> contours_tab_k_peak[i] >> contours_tab_k_middle[i] >> contours_tab_k_max[i] >> contours_tab_Nk_peak[i] >> contours_tab_Nk_middle[i] >> contours_tab_Nk_max[i];

      cout << contours_tab_shells[i] << " " << contours_tab_k_peak[i] << " " << contours_tab_k_middle[i] << " " << contours_tab_k_max[i] << " " << contours_tab_Nk_peak[i] << " " << contours_tab_Nk_middle[i] << " " << contours_tab_Nk_max[i] << endl;
    }

  if ((calc_type == MOLECULAR) && ((potential == QUADRUPOLAR)|| (potential == GAUSSIAN)))    
    {
      const unsigned int N_contour_edges_max = 3; // triangular contours
            
      class array<complex<double> > tabs_k(N_contours , N_contour_edges_max);
      
      class array<unsigned int> tabs_Nk(N_contours , N_contour_edges_max);
      
      for (unsigned int i = 0 ; i < N_contours ; i++)
	{
	  tabs_k(i , 0) = contours_tab_k_peak[i];
	  tabs_k(i , 1) = contours_tab_k_middle[i];
	  tabs_k(i , 2) = contours_tab_k_max[i];
	  
	  tabs_Nk(i , 0) = contours_tab_Nk_peak[i];
	  tabs_Nk(i , 1) = contours_tab_Nk_middle[i];
	  tabs_Nk(i , 2) = contours_tab_Nk_max[i];	  
	}
      
      contours_data.allocate (contours_tab_shells , tabs_k , tabs_Nk);
    }
  
  cout << endl;
}




// store all core shells to be removed in the calculations (deformed WS cases)
void CC_rotor_input_class::store_input_file_tables_core_shells ()
{

  if (!is_CC_solver_direct_integration)
    {
      unsigned int N_core_shells = 0;
  
      cin >> N_core_shells;
      word_check_print<unsigned int> ("(core.shells.number)" , N_core_shells);

      core_shells_tab.allocate (N_core_shells);

      for (unsigned int i = 0 ; i < N_core_shells ; i++)
	{
	  cin >> core_shells_tab[i];

	  cout << core_shells_tab[i] << " "; 
	}

      cout << endl;
    }
}


// store moments of inertia for all rotor angular momenta in the nuclear case
void CC_rotor_input_class::store_input_file_table_moment_of_inertia_nuclear_case ()
{
  unsigned int N_moments_of_inertia = 0;

  cin >> N_moments_of_inertia;
  word_check_print<unsigned int> ("(moments.of.inertia.energies.number)" , N_moments_of_inertia);

  moments_of_inertia.deallocate ();
  moments_of_inertia.allocate (N_moments_of_inertia);

  rotor_angular_momenta.deallocate ();
  rotor_angular_momenta.allocate (N_moments_of_inertia);

  word_check ("rotor.angular.momenta");
  
  word_check ("rotor.energy(MeV)");
	
  for (unsigned int i = 0 ; i < N_moments_of_inertia ; i++)
    {
      cin >> rotor_angular_momenta[i];

      const unsigned int rotor_jr = rotor_angular_momenta[i];

      // MeV

      double rotor_E;

      cin >> rotor_E;

      if (rotor_E == 0) error_message_print_abort ("CC_rotor_input_class::store_input_file_table_moment_of_inertia_nuclear_case: rotor energy cannot be zero");

      // I [amu . fm^2] , no correction from the core + particle masses
      moments_of_inertia[i] = rotor_jr * (rotor_jr + 1.0) / (rotor_E * two_amu_over_hbar_square);

      cout << "jr: " << rotor_angular_momenta[i] << "  E.rotor: " << rotor_E << " MeV   I: " << moments_of_inertia[i] << " amu.fm^2" << endl;
    }

  cout << endl;
}




void CC_rotor_input_class::read_store_all_E_G_BEM_start_contour_tables ()
{
  // initial energies and widths for integration of basis states in BEM

  if ((calc_type == MOLECULAR) && ((potential == QUADRUPOLAR) || (potential == GAUSSIAN))) read_and_print_input_file_E_G_BEM_start ();
  
  read_and_print_input_file_contours ();

  if (calc_type != MOLECULAR) store_input_file_tables_core_shells ();
}









// store all tables values for the fit
// has to be called once N_channels has been calculated
void CC_rotor_input_class::store_input_data_for_fit ()
{
  cin >> rmin_for_fit;

  word_check_print<double> ("a0(r.min)" , rmin_for_fit);
      
  cin >> rmax_for_fit;

  word_check_print<double> ("a0(r.max)" , rmax_for_fit);
      
  cin >> N_asymptotic_fit;
      
  word_check_print<unsigned int> ("(N.points)" , N_asymptotic_fit);
}





// return the moment of inertia associated to jr , or the default value if it had not been set
double CC_rotor_input_class::get_moment_of_inertia (const int jr) const
{
  if (jr == 0) return I;

  double rotor_I = I;

  const unsigned int I_number = moments_of_inertia.dimension (0);

  unsigned int i = 0;

  bool is_found = false;

  while ((!is_found) && (i < I_number))
    {
      const int rotor_jr = rotor_angular_momenta[i];

      if (jr == rotor_jr)
	{
	  rotor_I = moments_of_inertia[i];

	  is_found = true;
	}

      i++;
    }

  if (!is_found) error_message_print_abort ("------ CC_rotor_input_class::get_moment_of_inertia: no moment of inertia specified for jr: " + make_string<int> (jr) + " ------");

  return rotor_I;
}





double used_memory_calc (const class CC_rotor_input_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.contours_data) +
    used_memory_calc (T.rotor_angular_momenta) +
    used_memory_calc (T.moments_of_inertia) +
    used_memory_calc (T.core_shells_tab) +
    used_memory_calc (T.contours_tab_shells) +
    used_memory_calc (T.contours_tab_k_peak) +
    used_memory_calc (T.contours_tab_k_middle) +
    used_memory_calc (T.contours_tab_k_max) +
    used_memory_calc (T.contours_tab_Nk_peak) +
    used_memory_calc (T.contours_tab_Nk_middle) +
    used_memory_calc (T.contours_tab_Nk_max) +
    used_memory_calc (T.E_BEM_start_tab) +
    used_memory_calc (T.G_BEM_start_tab) +
    used_memory_calc (T.Ef_BEM_start_tab)
    - (sizeof (T.contours_data) +
       sizeof (T.rotor_angular_momenta) +
       sizeof (T.moments_of_inertia) +
       sizeof (T.core_shells_tab) +
       sizeof (T.contours_tab_shells) +
       sizeof (T.contours_tab_k_peak) +
       sizeof (T.contours_tab_k_middle) +
       sizeof (T.contours_tab_k_max) +
       sizeof (T.contours_tab_Nk_peak) +
       sizeof (T.contours_tab_Nk_middle) +
       sizeof (T.contours_tab_Nk_max) +
       sizeof (T.E_BEM_start_tab) +
       sizeof (T.G_BEM_start_tab) +
       sizeof (T.Ef_BEM_start_tab))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays; 

  return used_memory;
}
