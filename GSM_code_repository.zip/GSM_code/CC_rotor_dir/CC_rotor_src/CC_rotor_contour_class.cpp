#include "../CC_rotor_include/CC_rotor_include.h"

using namespace string_routines;




// Class of data related to used contours
// --------------------------------------


// CC_rotor_contour_class contains the name of the associated partial wave (str) , 
// the number of edges and the total number of scattering states on the contour (number_points_total) , 
// as well as the position of edges (except the origin at 0 , 0) and the number of points (scatt states) on each edge.


// ================================== constructors ================================== //

CC_rotor_contour_class::CC_rotor_contour_class () 
  : 
  partial_wave ("") , 
  number_edges (0) , 
  number_points_total (0)
{}

CC_rotor_contour_class::CC_rotor_contour_class (const class CC_rotor_contour_class &X)
{
  allocate_fill (X);
}


void CC_rotor_contour_class::allocate_fill (const class CC_rotor_contour_class &X)
{
  partial_wave = X.partial_wave;

  number_edges = X.number_edges;

  number_points_total = X.number_points_total;

  tab_k.allocate_fill (X.tab_k);

  tab_Nk.allocate_fill (X.tab_Nk);
}




void CC_rotor_contour_class::deallocate ()
{
  tab_k.deallocate ();

  tab_Nk.deallocate ();
  
  partial_wave = "";

  number_edges = 0;

  number_points_total = 0;
}





// ================================== methods ================================== //


// "=" overloading
const class CC_rotor_contour_class & CC_rotor_contour_class::operator = (const class CC_rotor_contour_class &X)
{
  class CC_rotor_contour_class &Y = *this;

  Y.partial_wave = X.get_partial_wave ();

  Y.number_edges = X.get_number_edges ();

  Y.number_points_total = X.get_number_points_total ();

  // direct access of "Y" ptrs

  tab_k.allocate_fill (X.tab_k);

  tab_Nk.allocate_fill (X.tab_Nk);

  return Y;
}






void CC_rotor_contour_class::check_contour_definition ()
{
  bool is_there_a_hole = false;

  for (unsigned int i = 0 ; i < number_edges ; i++)
    {
      const double Re_ki = real (tab_k[i]);
      const double Im_ki = imag (tab_k[i]);

      if (Im_ki > 0) error_message_print_abort ("CC_rotor_contour_class::check_contour_definition: the imaginary component of the contour" + partial_wave + "has to be negative.");

      for (unsigned int j = 0 ; j < number_edges ; j++)
	{
	  if (j != i)
	    {
	      const double Re_kj = real (tab_k[j]);
	      const double Im_kj = imag (tab_k[j]);

	      if ((Re_ki == Re_kj) && (Im_ki == Im_kj) && (tab_k[i] != 0.0)) error_message_print_abort ("CC_rotor_contour_class::check_contour_definition: identical points in the contour " + partial_wave);
	    }
	}


      // calculate the total number of points on the contour
      const unsigned int Nki = tab_Nk[i];

      number_points_total += Nki;

      if (Nki == 0) is_there_a_hole = true;

      if (is_there_a_hole && (Nki != 0)) error_message_print_abort ("CC_rotor_contour_class::check_contour_definition: invalid discretization of the contour (hole) " + partial_wave);
    }

  if (number_points_total == 0) error_message_print_abort ("CC_rotor_contour_class::check_contour_definition: invalid (zero) discretization of the contour " + partial_wave);
}






void CC_rotor_contour_class::print_contour_on_screen ()
{
  cout << " " << partial_wave;

  for (unsigned int i = 0 ; i < number_edges ; i++)
    {
      cout << " " << tab_k[i];
    }

  cout << " ";

  for (unsigned int i = 0 ; i < number_edges ; i++)
    {
      cout << " " << tab_Nk[i];
    }

  cout << endl;
}


void CC_rotor_contour_class::print_contour_for_plot (const string plot_file_name)
{
  // print contour points

  string s = partial_wave;

  std::replace (s.begin () , s.end () , '/' , 'I');

  const string file_name = STORAGE_DIR + "contour_" + s;

  ofstream outfile (file_name.c_str ());

  outfile << 0.0 << " " << 0.0 << endl;

  for (unsigned int i = 0 ; i < number_edges ; i++) outfile << real (tab_k[i]) << " " << imag (tab_k[i]) << endl;

  // print plot file

  ofstream plot_outfile (plot_file_name.c_str () , std::ios_base::app);

  plot_outfile << "plot \"" << file_name << "\" u 1:2 w l" << endl;
}



void CC_rotor_contour_class::set_partial_wave (const string partial_wave_c)
{
  if (partial_wave_c != "")
    partial_wave = partial_wave_c;
  else
    error_message_print_abort ("CC_rotor_contour_class::set_partial_wave: no partial wave defined");
}

string CC_rotor_contour_class::get_partial_wave () const
{
  return partial_wave;
}

void CC_rotor_contour_class::allocate_tab_k_and_Nk (const unsigned int number_edges_c)
{
  number_edges = number_edges_c;

  tab_k.allocate (number_edges_c);

  tab_Nk.allocate (number_edges_c);
}




unsigned int CC_rotor_contour_class::get_number_edges () const
{
  return number_edges;
}




unsigned int CC_rotor_contour_class::get_number_points_total () const
{
  return number_points_total;
}




bool CC_rotor_contour_class::is_partial_wave (const unsigned int l_init , const unsigned int jr_init) const
{
  if (partial_wave == "default") return true;

  const unsigned int l = determine_l (partial_wave);

  const unsigned int jr = determine_jr (partial_wave);

  return same_lj (l , jr , l_init , jr_init);
}




bool CC_rotor_contour_class::is_partial_wave (const unsigned int l_init , const double j_init) const
{
  string shell = partial_wave;

  if (shell == "default") return true;

  const unsigned int l = determine_l (shell);

  const double j = determine_j (shell);

  return same_lj (l , j , l_init , j_init);
}





double used_memory_calc (const class CC_rotor_contour_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.tab_k) + used_memory_calc (T.tab_Nk) - (sizeof (T.tab_k) + sizeof (T.tab_Nk))/1000000.0);
}
