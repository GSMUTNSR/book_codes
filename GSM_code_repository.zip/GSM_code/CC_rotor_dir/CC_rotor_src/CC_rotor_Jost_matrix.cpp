#include "../CC_rotor_include/CC_rotor_include.h"

// Jost matrix of the coupled-channel equations solved with direct integration
// ---------------------------------------------------------------------------

class matrix<complex<double> > CC_rotor_Jost_matrix_calc (
							  const class array<class CC_fwd_basis_state> &fwd_basis , 
							  const class array<class CC_bwd_basis_state> &bwd_basis)
{
  const class CC_fwd_basis_state &fwd_basis_zero = fwd_basis(0);

  const unsigned int N_channels = fwd_basis_zero.get_N_channels ();

  class matrix<complex<double> > Jost_matrix (2*N_channels);

  for (unsigned ib = 0 ; ib < N_channels ; ib++)
    {
      const class CC_fwd_basis_state &fwd_basis_b  = fwd_basis(ib);
      const class CC_bwd_basis_state &bwd_basis_b  = bwd_basis(ib);

      const class array<complex<double> > &CC_fwd_basis_wf_R0_tab  = fwd_basis_b.get_CC_fwd_basis_wf_R0_tab ();
      const class array<complex<double> > &CC_fwd_basis_dwf_R0_tab = fwd_basis_b.get_CC_fwd_basis_dwf_R0_tab ();

      const class array<complex<double> > &CC_bwd_basis_wf_R0_tab  = bwd_basis_b.get_CC_bwd_basis_wf_R0_tab ();
      const class array<complex<double> > &CC_bwd_basis_dwf_R0_tab = bwd_basis_b.get_CC_bwd_basis_dwf_R0_tab ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const unsigned int ic_deriv = ic + N_channels;
	  
	  const unsigned int ib_fwd = ib;
	  
	  const unsigned int ib_bwd = ib + N_channels;

	  Jost_matrix (ic       , ib_fwd) =  CC_fwd_basis_wf_R0_tab(ic);
	  Jost_matrix (ic_deriv , ib_fwd) =  CC_fwd_basis_dwf_R0_tab(ic);

	  Jost_matrix (ic       , ib_bwd) = -CC_bwd_basis_wf_R0_tab(ic);
	  Jost_matrix (ic_deriv , ib_bwd) = -CC_bwd_basis_dwf_R0_tab(ic);
	}
    }

  return Jost_matrix;
}






