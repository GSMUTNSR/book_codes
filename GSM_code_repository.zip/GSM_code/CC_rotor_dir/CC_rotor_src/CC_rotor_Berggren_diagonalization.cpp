#include "../CC_rotor_include/CC_rotor_include.h"



// Calculation and diagonalization of the coupled-channel Hamiltonian matrix represented with the Berggren basis
// -------------------------------------------------------------------------------------------------------------




complex<double> CC_rotor_Berggren_diagonalization::radial_OBME_bef_R (
								      const enum op_type op ,
								      const class CC_rotor_all_data_class &CC_rotor_all_data ,
								      const unsigned int ic_in , 
								      const unsigned int ic_out ,
								      const class spherical_state &wf_in ,
								      const class spherical_state &wf_out)
{
  const enum particle_type particle = wf_in.get_particle ();

  const unsigned int Ns = wf_in.get_N_bef_s_GL ();
  const unsigned int N  = wf_in.get_N_bef_R_GL ();

  const class array<complex<double> > &wf_in_bef_s = wf_in.get_wf_bef_s_tab_GL ();
  const class array<complex<double> > &wf_in_bef_R = wf_in.get_wf_bef_R_tab_GL ();

  const class array<complex<double> > &wf_out_bef_s = wf_out.get_wf_bef_s_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R = wf_out.get_wf_bef_R_tab_GL ();

  const class array<double> &ws_table = wf_in.get_w_bef_s_tab_GL ();
  const class array<double> &w_table = wf_in.get_w_bef_R_tab_GL ();

  const class array<double> &Vccp_tab_bef_s_GL = CC_rotor_all_data.get_Vccp_tab_bef_s_GL ();
  const class array<double> &Vccp_tab_bef_R_GL = CC_rotor_all_data.get_Vccp_tab_bef_R_GL ();

  complex<double> IF = 0.0;

  if (particle == ELECTRON)
    {
      for (unsigned int i = 0 ; i < Ns ; i++)
	{
	  switch (op)
	    {
	    case OVERLAP_OP:     IF += wf_in_bef_s(i) * wf_out_bef_s(i) * ws_table(i); break;
	    case HAMILTONIAN_OP: IF += wf_in_bef_s(i) * wf_out_bef_s(i) * ws_table(i) * Vccp_tab_bef_s_GL (ic_in , ic_out , i); break;
	    }
	}
    }

  for (unsigned int i = 0 ; i < N ; i++)
    {
      switch (op)
	{
	case OVERLAP_OP:     IF += wf_in_bef_R(i) * wf_out_bef_R(i) * w_table(i); break;
	case HAMILTONIAN_OP: IF += wf_in_bef_R(i) * wf_out_bef_R(i) * w_table(i) * Vccp_tab_bef_R_GL (ic_in , ic_out , i); break;
	}
    }

  return IF;
}






complex<double> CC_rotor_Berggren_diagonalization::radial_OBME_aft_R_part_of_4 (
										const enum op_type op ,
										const class CC_rotor_all_data_class &CC_rotor_all_data ,
										const unsigned int asy_in ,
										const unsigned int asy_out ,
										const unsigned int angle_index ,
										const unsigned int ic_in , 
										const unsigned int ic_out ,
										const class spherical_state &wf_in ,
										const class spherical_state &wf_out)
{
  const unsigned int N = wf_in.get_N_aft_R_GL ();

  const double R = wf_in.get_R ();

  const class array<complex<double> > &sc_wf_in_aft_R  = wf_in.get_scaled_wf_aft_R_tab_GL ();
  const class array<complex<double> > &sc_wf_out_aft_R = wf_out.get_scaled_wf_aft_R_tab_GL ();

  const complex<double> exp_Itheta (cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const complex<double> k_in  = wf_in.get_k ()  , eta_in  = wf_in.get_eta ()  , I_omega_in  (0 , minus_one_pow (asy_in));
  const complex<double> k_out = wf_out.get_k () , eta_out = wf_out.get_eta () , I_omega_out (0 , minus_one_pow (asy_out));

  const class array<double> &um4_aft_R_tab_GL = wf_in.get_um4_aft_R_tab_GL ();

  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL ();

  complex<double> IF = 0.0;

  const class array<complex<double> > &Vccp_tab_aft_R_GL = CC_rotor_all_data.get_Vccp_tab_aft_R_GL ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const complex<double> z = R + (um4_aft_R_tab_GL(i) - R) * exp_Itheta;
      
      const complex<double> k_in_z  = k_in  * z;
      const complex<double> k_out_z = k_out * z;

      const complex<double> scale = exp (I_omega_in * (k_in_z - eta_in * (M_LN2 + log (k_in_z))) + I_omega_out * (k_out_z - eta_out * (M_LN2 + log (k_out_z))));

      switch (op)
	{
	case OVERLAP_OP:     IF += sc_wf_in_aft_R(asy_in , angle_index , i) * sc_wf_out_aft_R(asy_out , angle_index , i) * scale * w_aft_R_tab_GL(i); break;
	case HAMILTONIAN_OP: IF += sc_wf_in_aft_R(asy_in , angle_index , i) * sc_wf_out_aft_R(asy_out , angle_index , i) * scale * w_aft_R_tab_GL(i) * Vccp_tab_aft_R_GL (ic_in , ic_out , angle_index , i); break;
	default: abort_all ();
	}
    }

  IF *= 4.0 * exp_Itheta;

  return IF;
}






complex<double> CC_rotor_Berggren_diagonalization::radial_OBME_aft_R_cut (
									  const class CC_rotor_all_data_class &CC_rotor_all_data ,
									  const unsigned int ic_in , 
									  const unsigned int ic_out ,
									  const class spherical_state &wf_in ,
									  const class spherical_state &wf_out)
{
  const unsigned int N = wf_in.get_N_aft_R_GL ();

  const class array<complex<double> > &wf_in_aft_R_tab_GL_real  = wf_in.get_wf_aft_R_tab_GL_real ();
  const class array<complex<double> > &wf_out_aft_R_tab_GL_real = wf_out.get_wf_aft_R_tab_GL_real ();

  const class array<double> &w_aft_R_tab_GL_real = wf_in.get_w_aft_R_tab_GL_real ();

  const class array<double> &Vccp_tab_aft_R_GL_real = CC_rotor_all_data.get_Vccp_tab_aft_R_GL_real ();

  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    IF += wf_in_aft_R_tab_GL_real(i) * wf_out_aft_R_tab_GL_real(i) * Vccp_tab_aft_R_GL_real (ic_in , ic_out , i) * w_aft_R_tab_GL_real(i);

  return IF;
}




complex<double> CC_rotor_Berggren_diagonalization::radial_OBME_aft_R (
								      const enum op_type op ,
								      const class CC_rotor_all_data_class &CC_rotor_all_data ,
								      const unsigned int ic_in , 
								      const unsigned int ic_out ,
								      const class spherical_state &wf_in ,
								      const class spherical_state &wf_out)
{
  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (wf_in.get_S_matrix_pole ()) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (wf_out.get_S_matrix_pole ()) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      {
	const complex<double> sum_over_k = wf_in.get_k () * minus_one_pow (asy_in) + wf_out.get_k () * minus_one_pow (asy_out);

	const unsigned int angle_index = optimal_angle_index (sum_over_k);

	integral_aft_R += radial_OBME_aft_R_part_of_4 (op , CC_rotor_all_data , asy_in , asy_out , angle_index , ic_in , ic_out , wf_in , wf_out);
      }

  return integral_aft_R;
}



complex<double> CC_rotor_Berggren_diagonalization::OBME (
							 const enum op_type op ,
							 const class CC_rotor_all_data_class &CC_rotor_all_data ,
							 const unsigned int ic_in , 
							 const unsigned int ic_out ,
							 const class spherical_state &wf_in ,
							 const class spherical_state &wf_out)
{
  switch (op)
    {
    case OVERLAP_OP:
      {
	if (ic_in != ic_out)
	  return 0.0;
	else
	  return (radial_OBME_bef_R (op , CC_rotor_all_data , ic_in , ic_out , wf_in , wf_out) + radial_OBME_aft_R (op , CC_rotor_all_data , ic_in , ic_out , wf_in , wf_out));
      }

    default:
      {  
	if (ic_in == ic_out)
	  {
	    const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
  
	    const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

	    if (calc_type == MOLECULAR) return 0.0;
	    
	    const bool is_it_same_Vo_basis_diagonalized_potential = (inf_norm (CC_rotor_input.get_Vo () - CC_rotor_input.get_Vo_basis ()) < precision);
  
	    if (is_it_same_Vo_basis_diagonalized_potential) return 0.0;
	  }
	
	const complex<double> radial_OBME = radial_OBME_bef_R (op , CC_rotor_all_data , ic_in , ic_out , wf_in , wf_out) + radial_OBME_aft_R (op , CC_rotor_all_data , ic_in , ic_out , wf_in , wf_out);

	if (!finite (radial_OBME)) 
	  error_message_print_abort ("OBME not finite. ic_in : " + make_string<int> (ic_in) + " ic_out : " + make_string<int> (ic_out) + " n_in : " + make_string<int> (wf_in.get_n ()) + " n_out : " + make_string<int> (wf_out.get_n ()));
	
	return radial_OBME;
      }
    }

  return NADA;
}







void CC_rotor_Berggren_diagonalization::H_calc (
						const class CC_rotor_all_data_class &CC_rotor_all_data ,
						class matrix<complex<double> > &H)
{
  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const unsigned int N_shells = H.get_dimension ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells = data.get_shells ();

  const class array<class CC_rotor_channel_class> &channels_tab = data.get_channels_tab ();

  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      const class nlj_struct &si_qn = shells_qn(i);

      const class spherical_state &si = shells(i);

      const unsigned int ic = si_qn.get_ic ();

      for (unsigned int ii = 0 ; ii <= i ; ii++)
	{
	  const class nlj_struct &sii_qn = shells_qn(ii);

	  const class spherical_state &sii = shells(ii);

	  const unsigned int iic = sii_qn.get_ic ();

	  H (ii , i) = H (i , ii) = OBME (HAMILTONIAN_OP , CC_rotor_all_data , ic , iic , si , sii);
	}
    }

  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      const class nlj_struct &si_qn = shells_qn(i);

      const class spherical_state &si = shells(i);

      const complex<double> Ei = si.get_E ();

      const unsigned int ic = si_qn.get_ic ();

      const class CC_rotor_channel_class &channel_c = channels_tab[ic];

      const double E_Tc = channel_c.get_E_Tc ();

      // add the kinetic and rotor energies on the diagonal
      const complex<double> E = Ei + E_Tc;
      
      H (i , i) += E;
    }
}





void CC_rotor_Berggren_diagonalization::Vccp_tabs_calc (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum particle_type particle = CC_rotor_input.get_particle ();
  
  const bool are_radial_form_factors_densities_stored = CC_rotor_input.get_are_radial_form_factors_densities_stored ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  const class dipolar_potential_class &dipolar_potential                   = CC_rotor_potential.get_dipolar_potential ();
  const class quadrupolar_potential_class &quadrupolar_potential           = CC_rotor_potential.get_quadrupolar_potential ();
  const class Gaussian_potential_class &Gaussian_potential                 = CC_rotor_potential.get_Gaussian_potential ();
  const class deformed_WS_class &deformed_WS_potential_basis               = CC_rotor_potential.get_deformed_WS_potential_basis ();
  const class deformed_WS_static_class &deformed_WS_static_potential_basis = CC_rotor_potential.get_deformed_WS_static_potential_basis ();
  const class deformed_WS_class &deformed_WS_potential                     = CC_rotor_potential.get_deformed_WS_potential ();
  const class deformed_WS_static_class &deformed_WS_static_potential       = CC_rotor_potential.get_deformed_WS_static_potential ();
  
  const bool is_it_same_Vo_basis_diagonalized_potential = (inf_norm (CC_rotor_input.get_Vo () - CC_rotor_input.get_Vo_basis ()) < precision);
	    
  class array<double> &Vccp_tab_bef_s_GL = CC_rotor_all_data.get_Vccp_tab_bef_s_GL ();
  class array<double> &Vccp_tab_bef_R_GL = CC_rotor_all_data.get_Vccp_tab_bef_R_GL ();
  
  class array<complex<double> > &Vccp_tab_aft_R_GL = CC_rotor_all_data.get_Vccp_tab_aft_R_GL ();
  
  class array<double> &Vccp_tab_aft_R_GL_real = CC_rotor_all_data.get_Vccp_tab_aft_R_GL_real ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const unsigned int N_channels = data.get_N_channels (); 

  const unsigned int N_bef_s_GL = data.get_N_bef_s_GL (); 
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL (); 
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();

  const double s_radial = data.get_s (); 

  const double R = data.get_R ();

  const double R_max = data.get_R_real_max ();
  
  const double R_pow_minus_0p25 = pow (R , -0.25);

  const class array<class CC_rotor_channel_class> &channels_tab = data.get_channels_tab ();

  class array<double> r_bef_s_tab_GL (N_bef_s_GL); 
  class array<double> w_bef_s_tab_GL (N_bef_s_GL);

  class array<double> r_bef_R_tab_GL (N_bef_R_GL); 
  class array<double> w_bef_R_tab_GL (N_bef_R_GL);

  class array<double> r_aft_R_tab_GL_real (N_aft_R_GL); 
  class array<double> w_aft_R_tab_GL_real (N_aft_R_GL);

  class array<double> u_aft_R (N_aft_R_GL); 
  class array<double> w_aft_R (N_aft_R_GL);

  class array<complex<double> > z_aft_R (4 , N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0      , s_radial         , r_bef_s_tab_GL      , w_bef_s_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R                , r_bef_R_tab_GL      , w_bef_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R        , R_max            , r_aft_R_tab_GL_real , w_aft_R_tab_GL_real);
  Gauss_Legendre::abscissas_weights_tables_calc (0.0      , R_pow_minus_0p25 , u_aft_R             , w_aft_R);

  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
    {
      const complex<double> exp_Itheta (cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) z_aft_R (angle_index , i) = R + (pow (u_aft_R (i) , -4) - R) * exp_Itheta;
    }

  Vccp_tab_bef_s_GL = 0.0;
  Vccp_tab_bef_R_GL = 0.0;
  Vccp_tab_aft_R_GL = 0.0;

  Vccp_tab_aft_R_GL_real = 0.0;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab[ic];
      
      const int lc = channel_c.get_lc ();
      const int jrc = channel_c.get_jrc ();
      
      const double jc = channel_c.get_jc ();
  
      for (unsigned int icp = 0 ; icp <= ic ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab[icp];
	  
	  const int lcp = channel_cp.get_lc ();
	  const int jrcp = channel_cp.get_jrc ();
	  
	  const double jcp = channel_cp.get_jc ();
	  
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    {
	      const double r = r_bef_s_tab_GL(i);

	      switch (potential)
		{
		case DIPOLAR:     Vccp_tab_bef_s_GL (ic , icp , i) = Vccp_tab_bef_s_GL (icp , ic , i) = dipolar_potential     (jrc , lc , jrcp , lcp , r); break;
		case QUADRUPOLAR: Vccp_tab_bef_s_GL (ic , icp , i) = Vccp_tab_bef_s_GL (icp , ic , i) = quadrupolar_potential (jrc , lc , jrcp , lcp , r); break;
		case GAUSSIAN:    Vccp_tab_bef_s_GL (ic , icp , i) = Vccp_tab_bef_s_GL (icp , ic , i) = Gaussian_potential    (jrc , lc , jrcp , lcp , r); break;
		  		  
		default: break;
		}
	    }
	  
	  if (ic != icp)
	    {
	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double r = r_bef_R_tab_GL(i);

		  switch (potential)
		    {
		    case DIPOLAR:            Vccp_tab_bef_R_GL (ic , icp , i) = Vccp_tab_bef_R_GL (icp , ic , i) = dipolar_potential     (jrc , lc , jrcp , lcp , r); break;
		    case QUADRUPOLAR:        Vccp_tab_bef_R_GL (ic , icp , i) = Vccp_tab_bef_R_GL (icp , ic , i) = quadrupolar_potential (jrc , lc , jrcp , lcp , r); break;
		    case GAUSSIAN:           Vccp_tab_bef_R_GL (ic , icp , i) = Vccp_tab_bef_R_GL (icp , ic , i) = Gaussian_potential    (jrc , lc , jrcp , lcp , r); break;		  
		    case DEFORMED_WS:        Vccp_tab_bef_R_GL (ic , icp , i) = Vccp_tab_bef_R_GL (icp , ic , i) = deformed_WS_potential (jrc , lc , jc , jrcp , lcp , jcp , r); break;
		    case DEFORMED_WS_STATIC: Vccp_tab_bef_R_GL (ic , icp , i) = Vccp_tab_bef_R_GL (icp , ic , i) = deformed_WS_static_potential (lc , jc , lcp , jcp , r); break;
		    default: error_message_print_abort ("CC_rotor_Berggren_diagonalization::Vccp_tabs_calc : bad potential type (1)");
		    }
		}
	    }
	  else if (!is_it_same_Vo_basis_diagonalized_potential)
	    {
	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double r = r_bef_R_tab_GL(i);

		  switch (potential)
		    {
		    case DEFORMED_WS:        Vccp_tab_bef_R_GL (ic , ic , i) = deformed_WS_potential (jrc , lc , jc , jrc , lc , jc , r) - deformed_WS_potential_basis (jrc , lc , jc , jrc , lc , jc , r); break;

		    case DEFORMED_WS_STATIC: Vccp_tab_bef_R_GL (ic , ic , i) = deformed_WS_static_potential (lc , jc , lc , jc , r) - deformed_WS_static_potential_basis (lc , jc , lc , jc , r); break;
		      
		    default: break;
		    }
		}
	    }	  

	  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	    {
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{
		  const complex<double> z = z_aft_R (angle_index , i);

		  switch (potential)
		    {
		    case DIPOLAR:     Vccp_tab_aft_R_GL (ic , icp , angle_index , i) = Vccp_tab_aft_R_GL (icp , ic , angle_index , i) = dipolar_potential.V_asymptotic_calc     (jrc , lc , jrcp , lcp , z); break;
		    case QUADRUPOLAR: Vccp_tab_aft_R_GL (ic , icp , angle_index , i) = Vccp_tab_aft_R_GL (icp , ic , angle_index , i) = quadrupolar_potential.V_asymptotic_calc (jrc , lc , jrcp , lcp , z); break;
		      
		    default: break;
		    }
		}
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real (i);

	      switch (potential)
		{
		case DIPOLAR:     Vccp_tab_aft_R_GL_real (ic , icp , i) = Vccp_tab_aft_R_GL_real (icp , ic , i) = dipolar_potential     (jrc , lc , jrcp , lcp , r); break;
		case QUADRUPOLAR: Vccp_tab_aft_R_GL_real (ic , icp , i) = Vccp_tab_aft_R_GL_real (icp , ic , i) = quadrupolar_potential (jrc , lc , jrcp , lcp , r); break;
		  
		default: break;
		}
	    }
	}
    }

  if ((potential != DEFORMED_WS) && (potential != DEFORMED_WS_STATIC) && are_radial_form_factors_densities_stored)
    {
      for (unsigned ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int jrc = channel_c.get_jrc ();

	  const int lc = channel_c.get_lc ();

	  for (unsigned icp = 0 ; icp <= ic ; icp++)
	    {
	      const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

	      const int jrcp = channel_cp.get_jrc ();
	      
	      const int lcp = channel_cp.get_lc ();

	      const double Vccp_quad_inv = (potential == DIPOLAR) ? (dipolar_potential.Vccp_quadratic_inverse_calc (jrcp , lcp , jrc , lc)) : (0.0);

	      if (Vccp_quad_inv != 0.0) cout << "channel " << ic << " jrc : " << jrc << " lc : " << lc << "--channel " << icp << " jrcp : " << jrcp << " lcp : " << lcp << "--Vcc' (1/r^2) : " << Vccp_quad_inv << endl;

	      if (same_lj_particle (particle , lc , jrc , particle , lcp , jrcp) && (Vccp_quad_inv != 0.0)) error_message_print_abort ("Vcc (1/r^2) non zero in diagonal part.");
	    }
	}

      cout << endl;
    }
}










void CC_rotor_Berggren_diagonalization::eigenstate_pole_approximation (
								       const class CC_rotor_all_data_class &CC_rotor_all_data ,
								       complex<double> &E ,
								       class vector_class<complex<double> > &eigenvector ,
								       const string file_name)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const bool are_wfs_stored = CC_rotor_input.get_are_wfs_stored ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  // full space and pole space sizes

  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  const string file_to_print = file_name + "_pole";

  const unsigned int eigenvector_index = CC_rotor_input.get_eigenvector_index ();

  // ================================== only pole space calculations  ================================== //

  if (N_nlj_res == 0) error_message_print_abort ("--> no poles, calculations cannot be done");

  cout << endl << "--> pole space calculations" << endl << endl;

  cout << "Total dimension (pole approximation) : " << N_nlj_res << endl << endl;
  
  class matrix<complex<double> > H (N_nlj_res);

  H_calc (CC_rotor_all_data , H);

  cout << "Non zeros (pole approximation): " << H.non_zeros_proportion () << " %" << endl << endl;
	
  // Hamiltonian matrix calculation

  class matrix<complex<double> > H_copy;

  if (are_wfs_stored) H_copy.allocate_fill (H);

  // eigenenergies calculations
  class array<complex<double> > eig_val (N_nlj_res);

  total_diagonalization::symmetric::all_eigenpairs (H , eig_val);

  // print eigenenergies
  ofstream file (file_to_print.c_str ());	

  file.precision (8);

  for (unsigned int i = 0 ; i < N_nlj_res ; i++)
    {
      const complex<double> &E = eig_val (i);

      const double Re_E_i = real (E);
      const double Im_E_i = imag (E);

      file << i << " " << Re_E_i << " " << Im_E_i << " " << - 2.0 * Im_E_i << endl;
    }

  file.close ();

  E = eig_val (eigenvector_index);

  eigenvector = H.eigenvector (eigenvector_index);

  if (are_wfs_stored)
    {
      const class vector_class<complex<double> > Res = H_copy*eigenvector - E*eigenvector;

      const double pres_eigenvector = Res.infinite_norm ();

      cout << "Eigenvector precision ||H|Psi> - E|Psi>||oo=" << pres_eigenvector << endl << endl;

      if (pres_eigenvector > 1.0e-6) cout << "================== WARNING: BAD DIAGONALIZATION ==================" << pres_eigenvector << endl; //xyz arbitrary
    }
}








void CC_rotor_Berggren_diagonalization::eigenstate_no_basis_poles_full_calculation (
										    const class CC_rotor_all_data_class &CC_rotor_all_data ,
										    complex<double> &E ,
										    class vector_class<complex<double> > &eigenvector ,
										    const string file_name)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const bool are_wfs_stored = CC_rotor_input.get_are_wfs_stored ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  // full space and pole space sizes
  const unsigned int N_nlj = data.get_N_nlj ();

  const unsigned int eigenvector_index = CC_rotor_input.get_eigenvector_index ();  

  cout << endl << "--> no pole space in full calculations" << endl << endl;
	
  cout << "Total dimension (full space) : " << N_nlj << endl;
  
  class matrix<complex<double> > H (N_nlj);

  H_calc (CC_rotor_all_data , H);

  cout << "Non zeros (full space) : " << H.non_zeros_proportion () << " %" << endl << endl;

  // Hamiltonian matrix calculation

  class matrix<complex<double> > H_copy;

  if (are_wfs_stored) H_copy.allocate_fill (H);

  // eigenenergies calculations

  class array<complex<double> > eig_val (N_nlj);

  total_diagonalization::symmetric::all_eigenpairs (H , eig_val);

  // print eigenenergies
  ofstream file (file_name.c_str ());	

  file.precision (8);

  for (unsigned int i = 0 ; i < N_nlj ; i++)
    {
      const complex<double> E = eig_val (i);

      const double Re_E_i = real (E);
      const double Im_E_i = imag (E);

      file << i << " " << Re_E_i << " " << Im_E_i << " " << - 2.0 * Im_E_i << endl;
    }

  file.close ();

  E = eig_val (eigenvector_index);

  eigenvector = H.eigenvector (eigenvector_index);

  if (are_wfs_stored)
    {
      const class vector_class<complex<double> > Res = H_copy*eigenvector - E*eigenvector;

      const double pres_eigenvector = Res.infinite_norm ();

      cout << "Eigenvector precision ||H|Psi> - E|Psi>||oo=" << pres_eigenvector << endl << endl;

      if (pres_eigenvector > 1.0e-6) cout << "================== WARNING: BAD DIAGONALIZATION ==================" << pres_eigenvector << endl; //xyz arbitrary
    }
}










void CC_rotor_Berggren_diagonalization::eigenstate_Davidson (
							     const class CC_rotor_all_data_class &CC_rotor_all_data ,
							     complex<double> &E ,
							     class vector_class<complex<double> > &eigenvector)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const bool are_wfs_stored = CC_rotor_input.get_are_wfs_stored ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  // full space and pole space sizes

  const unsigned int N_nlj = data.get_N_nlj ();

  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  const unsigned int eigenvector_index = CC_rotor_input.get_eigenvector_index ();

  cout << endl << "--> full space calculation with the Jacobi-Davidson method" << endl << endl;

  if (eigenvector_index >= N_nlj_res) error_message_print_abort ("CC_rotor_Berggren_diagonalization::eigenstate_calc: eigenvector index is not associated with a resonant state");
	    
  // Davidson method parameters

  const unsigned int N_restarts = CC_rotor_input.get_Davidson_N_restarts ();

  const double eigenvector_precision = CC_rotor_input.get_Davidson_eigenvector_precision ();

  const unsigned int Davidson_subspace_size = CC_rotor_input.get_Davidson_max_dimension_subspace ();

  const unsigned int max_dimension = (Davidson_subspace_size < N_nlj) ? (Davidson_subspace_size) : (N_nlj);

  cout << "Total dimension (full space) : " << N_nlj << endl;
  
  class matrix<complex<double> > H (N_nlj);

  H_calc (CC_rotor_all_data , H);

  cout << "Non zeros (full space) : " << H.non_zeros_proportion () << " %" << endl << endl;

  // pole state calculations

  class array<complex<double> > eig_val_pole_tab (N_nlj_res);

  class matrix<complex<double> > P_pole (N_nlj_res);

  P_pole.assign (H);

  total_diagonalization::symmetric::all_eigenpairs (P_pole , eig_val_pole_tab);

  // pivot (eig_val and eigenvector of dimension N_nlj are filled with pole space values of dimension N_nlj_res)

  const complex<double> &eig_val_start = eig_val_pole_tab (eigenvector_index);

  const vector_class<complex<double> > &eigenvector_start_pole = (P_pole.eigenvector (eigenvector_index));

  class vector_class<complex<double> > eigenvector_start (N_nlj);

  eigenvector_start.assign (eigenvector_start_pole);

  complex<double> eig_val = eig_val_start;

  eigenvector = eigenvector_start;

  // fill eig_val and eigenvector with the maximal overlapping values in the full space

  const bool is_there_cout = false;

  Davidson::iterative_diagonalization_largest_overlap (is_there_cout , eig_val_pole_tab , P_pole , N_restarts , eigenvector_precision , max_dimension , H , eig_val , eigenvector);

  E = eig_val;

  if (are_wfs_stored)
    {
      const class vector_class<complex<double> > Res = H*eigenvector - eig_val*eigenvector;

      cout << "starting eigenvalue : " << eig_val_start << endl;
      cout << "final eigenvalue : " << eig_val << endl;

      cout << endl;

      cout << "|<V|Vstart>|oo : " << inf_norm (eigenvector*eigenvector_start) << endl;
      cout << "|A.V - E.V|oo : " << Res.infinite_norm () << endl << endl;
    }
}








void CC_rotor_Berggren_diagonalization::eigenstate_calc (
							 const class CC_rotor_all_data_class &CC_rotor_all_data ,
							 complex<double> &E ,
							 class vector_class<complex<double> > &eigenvector ,
							 const string file_name)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  cout << "===============================================================================" << endl;
  cout << "========= CC_rotor_Berggren_diagonalization: eigenstate calculation ===========" << endl;
  cout << "===============================================================================" << endl << endl;

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  const bool pole_approximation = CC_rotor_input.get_pole_approximation ();

  if (pole_approximation) 
    eigenstate_pole_approximation (CC_rotor_all_data , E , eigenvector , file_name);
  else
    {
      if ((N_nlj_res == 0) || (calc_type == MOLECULAR))
	eigenstate_no_basis_poles_full_calculation (CC_rotor_all_data , E , eigenvector , file_name);
      else
	eigenstate_Davidson (CC_rotor_all_data , E , eigenvector);
    }
}








//--// calcule et affiche des sommes de ME
void CC_rotor_Berggren_diagonalization::H_test (const class Berggren_data &data , class matrix<complex<double> > &H)
{
  const unsigned int N_shells = H.get_dimension ();
  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  //--// ouverture en ecriture d'un fichier pour les resultats (efface tout avant)
  ofstream file ("sum_me.out" , ios::out | ios::trunc);

  unsigned int c = 6;

  for (unsigned int c_ = 0 ; c_ < 10 ; c_++)
    {
      complex<double> sum_nn_ = 0.0;

      for (unsigned int i = 0 ; i < N_shells ; i++)
	{
	  const class nlj_struct &si_qn = shells_qn(i);
	  const unsigned int ic = si_qn.get_ic ();

	  for (unsigned int ii = 0 ; ii < N_shells ; ii++)
	    {
	      const class nlj_struct &sii_qn = shells_qn(ii);
	      const unsigned int iic = sii_qn.get_ic ();

	      if (ic == c && iic == c_)
		{
		  sum_nn_ += abs (H (i , ii));
		}
	    }
	}

      file << c << " " << c_ << " " << real (sum_nn_ / (N_shells * N_shells)) << " " << imag (sum_nn_ / (N_shells * N_shells)) << endl;
    }

  file.close ();
}



