#include "../CC_rotor_include/CC_rotor_include.h"

using namespace Wigner_signs;
using namespace CC_rotor_Berggren_basis;
using namespace string_routines;

// Solution of coupled-channel equations in coordinate space
// ---------------------------------------------------------
// One uses either the Direct Integration method (DIM) or the Berggren Expansion Method (BEM).
// With a dipolar potential, one can calculate the wave function in the asymptotic zone with an exponential ansatz.
// It is usually precise, except when energy is very small, as then the exponential term is close to one and does not decrease fast enough.
// The wave function can be stored on disk, as well as its square (radial form factor).
// Observables can also be calculated: partial norms of wave functions for fixed channel, rms radius, radial and momentum densities, phase shift

/* Constructors and Destructors
 */
CC_rotor_states_class::CC_rotor_states_class () :
  S_matrix_pole (false) , 
  potential (NO_POTENTIAL) ,
  N_channels (0) , 
  ic_entrance (0) ,
  R (0.0) ,
  matching_point (0.0) ,
  s_radial (0.0) ,
  R0 (0.0) ,
  R_max (0.0) ,
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  step_bef_R_uniform (0.0) ,
  step_momentum_uniform (0.0) ,
  N_bef_R_uniform (0) ,
  N_aft_R_uniform (0) ,
  N_bef_s_GL (0) ,
  N_bef_R_GL (0) ,
  N_aft_R_GL (0) ,
  N_bef_R0_uniform (0) ,
  N_aft_R0_uniform (0) ,
  Nk_momentum_uniform (0) ,
  Nk_momentum_GL (0) ,
  BP (0) ,
  J (0.0) ,
  K_static (0.0) ,
  E (0.0) ,
  is_E_ok (false) , 
  is_asymptotic_wave_function_fit_used (false) ,
  Nt (0) ,
  rms_radius (0.0) ,
  N_asymptotic_fit (0) ,
  rmin_for_fit (0.0) ,
  rmax_for_fit (0.0)
{}

CC_rotor_states_class::CC_rotor_states_class (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  allocate (CC_rotor_all_data);
}

CC_rotor_states_class::CC_rotor_states_class (const class CC_rotor_states_class &X)
{
  allocate_fill (X);
}

void CC_rotor_states_class::allocate (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
	    
  S_matrix_pole = CC_rotor_input.get_S_matrix_pole ();

  potential = CC_rotor_input.get_potential ();

  N_channels = CC_rotor_all_data.get_N_channels ();

  ic_entrance = CC_rotor_input.get_ic_entrance ();

  N_bef_R_uniform = CC_rotor_input.get_N_bef_R_uniform ();
  N_aft_R_uniform = CC_rotor_input.get_N_aft_R_uniform ();

  N_bef_s_GL = CC_rotor_input.get_N_bef_s_GL ();

  N_bef_R_GL = CC_rotor_input.get_N_bef_R_GL ();
  N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();

  Nk_momentum_uniform = CC_rotor_input.get_Nk_momentum_uniform ();

  Nk_momentum_GL = CC_rotor_input.get_Nk_momentum_GL ();

  kmax_momentum = CC_rotor_input.get_kmax_momentum ();

  R_Fermi_momentum = CC_rotor_input.get_R_Fermi_momentum ();
    
  R = CC_rotor_input.get_R ();

  R0 = CC_rotor_input.get_R0 ();

  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);

  step_momentum_uniform = kmax_momentum/static_cast<double> (Nk_momentum_uniform - 1);
  
  s_radial = CC_rotor_input.get_s ();

  matching_point = CC_rotor_input.get_R0 ();

  N_bef_R0_uniform = make_uns_int (floor ((N_bef_R_uniform - 1) * matching_point/R)) + 1;

  N_aft_R0_uniform = N_bef_R_uniform - 1 - make_uns_int (floor ((N_bef_R_uniform - 1) * matching_point/R));

  R_max = CC_rotor_input.get_R_real_max ();
  
  BP = CC_rotor_input.get_BP ();

  J = CC_rotor_input.get_J ();
  E = CC_rotor_input.get_E ();

  K_static = CC_rotor_input.get_K_static ();
    
  is_E_ok = (E != 0.0);

  is_asymptotic_wave_function_fit_used = CC_rotor_input.get_is_asymptotic_wave_function_fit_used ();
  
  if (is_asymptotic_wave_function_fit_used)
    {
      N_asymptotic_fit = CC_rotor_input.get_N_asymptotic_fit ();

      rmin_for_fit = CC_rotor_input.get_rmin_for_fit ();
      rmax_for_fit = CC_rotor_input.get_rmax_for_fit ();
    }

  Nt = CC_rotor_input.get_Nt ();

  channels_tab.allocate_fill (CC_rotor_all_data.get_channels_tab ());

  cout << "===============================================================" << endl;
  cout << "========= CC_rotor_states_class: initialize CC states =========" << endl;
  cout << "===============================================================" << endl << endl;

  // determination of N_asymptotic_fit max
  if (is_asymptotic_wave_function_fit_used)
    {
      asymptotic_fit_tab.allocate (N_channels , N_asymptotic_fit);
      asymptotic_fit_tab = 0.0;
    }


  // GL == Gauss - Legendre
  // before

  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  k_tab_uniform.allocate (Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;
  
  r_bef_s_tab_GL.allocate (N_bef_s_GL);
  w_bef_s_tab_GL.allocate (N_bef_s_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , s_radial , r_bef_s_tab_GL , w_bef_s_tab_GL);

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  r_aft_R_tab_GL_real.allocate (N_aft_R_GL);
  w_aft_R_tab_GL_real.allocate (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_tab_GL_real , w_aft_R_tab_GL_real);
  
  const complex<double> exp_Itheta(cos_theta_tab[0] , sin_theta_tab[0]);
      
  r_aft_R_tab_GL_complex.allocate (N_aft_R_GL);
  w_aft_R_tab_GL_complex.allocate (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      r_aft_R_tab_GL_complex(i) = R + (r_aft_R_tab_GL_real(i) - R)*exp_Itheta;

      w_aft_R_tab_GL_complex(i) = w_aft_R_tab_GL_real(i)*exp_Itheta;
    }
 
  const double R_pow_minus_0p25 = pow (R , -0.25);

  u_aft_R_GL.allocate (N_aft_R_GL);

  weights_aft_R_GL.allocate (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_pow_minus_0p25 , u_aft_R_GL , weights_aft_R_GL);

  k_tab_GL.allocate  (Nk_momentum_GL);
  wk_tab_GL.allocate (Nk_momentum_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);
  
  CC_wf_bef_R_tab_uniform.allocate   (N_channels , N_bef_R_uniform);
  CC_dwf_bef_R_tab_uniform.allocate  (N_channels , N_bef_R_uniform);
  CC_d2wf_bef_R_tab_uniform.allocate (N_channels , N_bef_R_uniform);

  CC_wf_bef_s_tab_GL.allocate   (N_channels , N_bef_R_uniform);
  CC_dwf_bef_s_tab_GL.allocate  (N_channels , N_bef_R_uniform);
  CC_d2wf_bef_s_tab_GL.allocate (N_channels , N_bef_R_uniform);

  CC_wf_bef_R_tab_GL.allocate   (N_channels , N_bef_R_uniform);
  CC_dwf_bef_R_tab_GL.allocate  (N_channels , N_bef_R_uniform);
  CC_d2wf_bef_R_tab_GL.allocate (N_channels , N_bef_R_uniform);

  CC_wf_bef_R_tab_uniform = INFINITE , CC_dwf_bef_R_tab_uniform = INFINITE , CC_d2wf_bef_R_tab_uniform = INFINITE;

  CC_wf_bef_s_tab_GL = INFINITE , CC_dwf_bef_s_tab_GL = INFINITE , CC_d2wf_bef_s_tab_GL = INFINITE;
  CC_wf_bef_R_tab_GL = INFINITE , CC_dwf_bef_R_tab_GL = INFINITE , CC_d2wf_bef_R_tab_GL = INFINITE;

  if (R_max > 0.0) 
    {
      CC_wf_aft_R_tab_GL_real.allocate   (N_channels , N_aft_R_GL);
      CC_dwf_aft_R_tab_GL_real.allocate  (N_channels , N_aft_R_GL);
      CC_d2wf_aft_R_tab_GL_real.allocate (N_channels , N_aft_R_GL);
      
      CC_wf_aft_R_tab_GL_complex.allocate   (N_channels , N_aft_R_GL);
      CC_dwf_aft_R_tab_GL_complex.allocate  (N_channels , N_aft_R_GL);
      CC_d2wf_aft_R_tab_GL_complex.allocate (N_channels , N_aft_R_GL);

      CC_wf_aft_R_tab_GL_real    = INFINITE , CC_dwf_aft_R_tab_GL_real    = INFINITE, CC_d2wf_aft_R_tab_GL_real    = INFINITE;
      CC_wf_aft_R_tab_GL_complex = INFINITE , CC_dwf_aft_R_tab_GL_complex = INFINITE, CC_d2wf_aft_R_tab_GL_complex = INFINITE;
    }

  if (kmax_momentum > 0.0)
    {
      CC_wf_momentum_tab_uniform.allocate  (N_channels , Nk_momentum_uniform);
      CC_dwf_momentum_tab_uniform.allocate (N_channels , Nk_momentum_uniform);
      
      CC_wf_momentum_tab_GL.allocate  (N_channels , Nk_momentum_GL);
      CC_dwf_momentum_tab_GL.allocate (N_channels , Nk_momentum_GL);
      
      CC_wf_momentum_tab_uniform = INFINITE , CC_dwf_momentum_tab_uniform = INFINITE;

      CC_wf_momentum_tab_GL = INFINITE , CC_dwf_momentum_tab_GL = INFINITE;
    }
  
  fwd_basis.allocate (N_channels);
  bwd_basis.allocate (N_channels);

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      fwd_basis(ib).allocate (S_matrix_pole , N_channels , ib , channels_tab , N_bef_R_uniform , N_bef_s_GL , N_bef_R_GL , R , s_radial , R0 , R_max);

      bwd_basis(ib).allocate (S_matrix_pole , N_channels , ic_entrance , ib , channels_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , R , s_radial , R0 , R_max);
    }

  if (!S_matrix_pole) bwd_U_minus.allocate (false , N_channels , ic_entrance , ic_entrance , channels_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , R , s_radial , R0 , R_max);

  C0_tab.allocate (N_channels);

  Cplus_tab.allocate (N_channels);

  A0_tab.allocate (N_channels);

  Aplus_tab.allocate (N_channels);

  C0_tab = 1.0;
  Cplus_tab = 1.0;
  
  A0_tab = 1.0;
  Aplus_tab = 1.0;

  const bool is_DIM = CC_rotor_input.get_is_CC_solver_direct_integration ();
  
  if (is_DIM)
    {
      llp1_eff_tab.allocate (N_channels);

      l_eff_tab.allocate (N_channels);

      asymptotic_channels.allocate (N_channels);

      DIM_calc_asymptotic_channels (CC_rotor_all_data);
    }
}



void CC_rotor_states_class::allocate_fill (const class CC_rotor_states_class &X) 
{
  S_matrix_pole = X.S_matrix_pole; 

  potential = X.potential; 

  N_channels = X.N_channels; 

  ic_entrance = X.ic_entrance;

  R = X.R;

  matching_point = X.R0;

  s_radial = X.s_radial;

  R0 = X.R0;

  R_max = X.R_max;

  kmax_momentum = X.kmax_momentum;
  
  step_bef_R_uniform = X.step_bef_R_uniform;

  step_momentum_uniform = X.step_momentum_uniform;
  
  N_bef_R_uniform = X.N_bef_R_uniform;
  N_aft_R_uniform = X.N_aft_R_uniform;

  N_bef_s_GL = X.N_bef_s_GL; 

  N_bef_R_GL = X.N_bef_R_GL;
  N_aft_R_GL = X.N_aft_R_GL;

  N_bef_R0_uniform = X.N_bef_R0_uniform;
  N_aft_R0_uniform = X.N_aft_R0_uniform;

  Nk_momentum_uniform = X.Nk_momentum_uniform; 

  Nk_momentum_GL = X.Nk_momentum_GL;
  
  BP = X.BP;

  J = X.J;
  E = X.E;

  K_static = X.K_static;
  
  is_E_ok = X.is_E_ok;

  is_asymptotic_wave_function_fit_used = X.is_asymptotic_wave_function_fit_used;

  Nt = X.Nt;

  N_asymptotic_fit = X.N_asymptotic_fit;
  
  rmin_for_fit = X.rmin_for_fit;
  rmax_for_fit = X.rmax_for_fit;

  // Channel class
  channels_tab.allocate_fill (X.channels_tab);


  // GL == Gauss - Legendre
  // bef_R: before R
  // aft_R: after R

  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  r_bef_s_tab_GL.allocate_fill (X.r_bef_s_tab_GL);
  w_bef_s_tab_GL.allocate_fill (X.w_bef_s_tab_GL);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  r_aft_R_tab_GL_complex.allocate_fill (X.r_aft_R_tab_GL_complex);
  w_aft_R_tab_GL_complex.allocate_fill (X.w_aft_R_tab_GL_complex);

  u_aft_R_GL.allocate_fill (X.u_aft_R_GL);

  weights_aft_R_GL.allocate_fill (X.weights_aft_R_GL);

  r_aft_R_tab_GL_real.allocate_fill (X.r_aft_R_tab_GL_real);
  w_aft_R_tab_GL_real.allocate_fill (X.w_aft_R_tab_GL_real);

  CC_wf_bef_R_tab_uniform.allocate_fill   (X.CC_wf_bef_R_tab_uniform);
  CC_dwf_bef_R_tab_uniform.allocate_fill  (X.CC_dwf_bef_R_tab_uniform);
  CC_d2wf_bef_R_tab_uniform.allocate_fill (X.CC_d2wf_bef_R_tab_uniform);

  CC_wf_bef_s_tab_GL.allocate_fill   (X.CC_wf_bef_s_tab_GL);
  CC_dwf_bef_s_tab_GL.allocate_fill  (X.CC_dwf_bef_s_tab_GL);
  CC_d2wf_bef_s_tab_GL.allocate_fill (X.CC_d2wf_bef_s_tab_GL);

  CC_wf_bef_R_tab_GL.allocate_fill   (X.CC_wf_bef_R_tab_GL);
  CC_dwf_bef_R_tab_GL.allocate_fill  (X.CC_dwf_bef_R_tab_GL);
  CC_d2wf_bef_R_tab_GL.allocate_fill (X.CC_d2wf_bef_R_tab_GL);

  CC_wf_aft_R_tab_GL_real.allocate_fill   (X.CC_wf_aft_R_tab_GL_real);
  CC_dwf_aft_R_tab_GL_real.allocate_fill  (X.CC_dwf_aft_R_tab_GL_real);
  CC_d2wf_aft_R_tab_GL_real.allocate_fill (X.CC_d2wf_aft_R_tab_GL_real);

  CC_wf_aft_R_tab_GL_complex.allocate_fill   (X.CC_wf_aft_R_tab_GL_complex);
  CC_dwf_aft_R_tab_GL_complex.allocate_fill  (X.CC_dwf_aft_R_tab_GL_complex);
  CC_d2wf_aft_R_tab_GL_complex.allocate_fill (X.CC_d2wf_aft_R_tab_GL_complex);

  CC_wf_momentum_tab_uniform.allocate_fill  (X.CC_wf_momentum_tab_uniform);
  CC_dwf_momentum_tab_uniform.allocate_fill (X.CC_dwf_momentum_tab_uniform);

  CC_wf_momentum_tab_GL.allocate_fill  (X.CC_wf_momentum_tab_GL);
  CC_dwf_momentum_tab_GL.allocate_fill (X.CC_dwf_momentum_tab_GL);
  
  // Forward basis and backward basis states
  fwd_basis.allocate (N_channels);
  bwd_basis.allocate (N_channels);
    
  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      fwd_basis(ib).allocate_fill (X.fwd_basis(ib));
      bwd_basis(ib).allocate_fill (X.bwd_basis(ib));
    }

  if (!S_matrix_pole) bwd_U_minus.allocate_fill (X.bwd_U_minus);

  /* C0 and Cplus tabs */
  C0_tab.allocate_fill (X.C0_tab);

  Cplus_tab.allocate_fill (X.Cplus_tab);

  A0_tab.allocate_fill (X.A0_tab);

  Aplus_tab.allocate_fill (X.Aplus_tab);

  asymptotic_fit_tab.allocate_fill (X.asymptotic_fit_tab);

  eigenvector.allocate_fill (X.eigenvector);

}




void CC_rotor_states_class::deallocate ()
{
  // Channel class
  channels_tab.deallocate ();

  // GL == Gauss - Legendre

  // GL == Gauss - Legendre
  // bef_R: before R
  // aft_R: after R

  r_bef_R_tab_uniform.deallocate ();

  r_bef_s_tab_GL.deallocate ();
  w_bef_s_tab_GL.deallocate ();

  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();

  r_aft_R_tab_GL_real.deallocate ();
  w_aft_R_tab_GL_real.deallocate ();

  r_aft_R_tab_GL_complex.deallocate ();
  w_aft_R_tab_GL_complex.deallocate ();
      
  u_aft_R_GL.deallocate ();

  weights_aft_R_GL.deallocate ();

  CC_wf_bef_R_tab_uniform.deallocate ();
  CC_dwf_bef_R_tab_uniform.deallocate ();
  CC_d2wf_bef_R_tab_uniform.deallocate ();

  CC_wf_bef_s_tab_GL.deallocate ();
  CC_dwf_bef_s_tab_GL.deallocate ();
  CC_d2wf_bef_s_tab_GL.deallocate ();

  CC_wf_bef_R_tab_GL.deallocate ();
  CC_dwf_bef_R_tab_GL.deallocate ();
  CC_d2wf_bef_R_tab_GL.deallocate ();

  CC_wf_aft_R_tab_GL_real.deallocate ();
  CC_dwf_aft_R_tab_GL_real.deallocate ();
  CC_d2wf_aft_R_tab_GL_real.deallocate ();

  CC_wf_aft_R_tab_GL_complex.deallocate ();
  CC_dwf_aft_R_tab_GL_complex.deallocate ();
  CC_d2wf_aft_R_tab_GL_complex.deallocate ();

  CC_wf_momentum_tab_uniform.deallocate ();
  CC_dwf_momentum_tab_uniform.deallocate ();

  CC_wf_momentum_tab_GL.deallocate ();
  CC_dwf_momentum_tab_GL.deallocate ();
  
  // Forward basis and backward basis states
  fwd_basis.deallocate ();
  bwd_basis.deallocate ();

  bwd_U_minus.deallocate ();

  /* C0 and Cplus tabs */
  C0_tab.deallocate (); 

  Cplus_tab.deallocate (); 

  A0_tab.deallocate (); 

  Aplus_tab.deallocate ();

  asymptotic_fit_tab.deallocate (); 

  eigenvector.deallocate ();

  S_matrix_pole = false; 

  potential = NO_POTENTIAL; 

  N_channels = 0; 

  ic_entrance = 0;

  R = 0.0;

  matching_point = 0.0;

  s_radial = 0.0;

  R0 = 0.0;

  R_max = 0.0;

  kmax_momentum = 0.0;
  
  step_bef_R_uniform = 0.0;

  step_momentum_uniform = 0.0;
  
  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  N_bef_s_GL = 0;

  N_bef_R_GL = 0;
  N_aft_R_GL = 0;

  N_bef_R0_uniform = 0;
  N_aft_R0_uniform = 0;

  Nk_momentum_uniform = 0;

  Nk_momentum_GL = 0;
  
  BP = 0;

  J = 0.0;
  E = 0.0;

  K_static = 0.0;
  
  is_E_ok = false; 

  is_asymptotic_wave_function_fit_used = false;

  Nt = 0;

  rmin_for_fit = 0.0;
  rmax_for_fit = 0.0;
  
  N_asymptotic_fit = 0;
}







void CC_rotor_states_class::solve_CC_equations (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "===============================================================" << endl;
  cout << "========= CC_rotor_states_class: solve CC equations ===========" << endl;
  cout << "===============================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
  
  const double b_HO = CC_rotor_input.get_b_HO ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const bool is_DIM = CC_rotor_input.get_is_CC_solver_direct_integration ();

  if (!S_matrix_pole && !is_DIM) error_message_print_abort ("CC_rotor_states_class::solve_CC_equations: scattering states are calculated with direct integration only");

  const bool are_wfs_stored  = CC_rotor_input.get_are_wfs_stored ();

  const bool are_radial_form_factors_densities_stored = CC_rotor_input.get_are_radial_form_factors_densities_stored ();
      
  // DIM
  if (is_DIM)
    {
      cout << "--> Direct Integration method (DIM)" << endl << endl;

      // solve the CC eqs in the basis (backward and forward)
      if (S_matrix_pole) DIM_E_search (CC_rotor_all_data);

      if (are_wfs_stored)
	{
	  // building of u_c (r)
	  DIM_calc_CC_wfs_basis_position (CC_rotor_all_data);

	  CC_wfs_dwfs_momentum_calc_from_DIM (b_HO);
	  
	  draw_CC_wfs_coordinate ("out_DIM_real_axis.dat" , true);
	  draw_CC_wfs_coordinate ("out_DIM_complex_scaling.dat" , false);
	  
	  if (kmax_momentum > 0.0) draw_CC_wfs_momentum ("out_DIM_momentum.dat");

	  if (S_matrix_pole) DIM_calc_partial_norms ();
	}

      if (are_radial_form_factors_densities_stored)
	{
	  draw_CC_wfs_coordinate_form_factors (STORAGE_DIR + "out_CC_wfs_form_factors_DIM_real_axis.dat" , true);
	  draw_CC_wfs_coordinate_form_factors (STORAGE_DIR + "out_CC_wfs_form_factors_DIM_complex_scaling.dat" , false);
	  
	  if (kmax_momentum > 0.0) draw_CC_wfs_momentum_form_factors (STORAGE_DIR + "out_CC_wfs_form_factors_DIM_momentum.dat");

	  if ((calc_type != MOLECULAR) || (inf_norm (E) > 1E-3))
	    DIM_calc_rms_radius ();
	  else
	    cout << "<r^2> is not calculated with direct integration in this case as energy is very small" << endl << endl;

	  if (S_matrix_pole)
	    {
	      density_calc_store ("density_DIM" , CC_rotor_all_data);

	      if (potential != DEFORMED_WS_STATIC) intrinsic_density_calc_store_rotating_core ("intrinsic_density_DIM" , CC_rotor_all_data);
		  
	      width_current_formula_calc (STORAGE_DIR + "out_width_current_formula_DIM" , CC_rotor_all_data);
	    }
	}
      
      if (calc_type == NUCLEAR_E_RMS_RADIUS_PLOT)
	{
	  DIM_calc_CC_wfs_basis_position (CC_rotor_all_data);
	  
	  if (S_matrix_pole) DIM_calc_partial_norms ();
	  
	  DIM_calc_rms_radius ();
	}
    }
  //BEM
  else
    {
      const bool is_basis_fixed = CC_rotor_input.get_is_basis_fixed_for_E_rms_radius_plot ();
  
      const bool pole_approximation = CC_rotor_input.get_pole_approximation ();

      cout << "--> Berggren Ensemble method (BEM)" << endl << endl;

      if (!is_basis_fixed) build_basis_states (CC_rotor_all_data);

      if (calc_type != MOLECULAR) print_basis_states_bad_overlaps (CC_rotor_all_data);

      // get the eigenenergy and the corresponding eigenvector

      const unsigned int H_matrix_dimension = (pole_approximation) ? (data.get_N_nlj_res ()) : (data.get_N_nlj ());

      eigenvector.allocate (H_matrix_dimension);

      eigenvector = 0.0;

      CC_rotor_Berggren_diagonalization::eigenstate_calc (CC_rotor_all_data , E , eigenvector , "spectrum");

      change_channels_energy (E);
      
      BEM_print_energy (CC_rotor_all_data);

      // calculation of the u_c (r) (position basis)
      BEM_calc_CC_wfs_coordinate_momentum (CC_rotor_all_data);
	  
      if (are_wfs_stored)
	{	  
	  const string CC_wfs_out_file_name_real = (is_asymptotic_wave_function_fit_used) ? ("out_BEM_fit_real_axis.dat") : ("out_BEM_no_fit_real_axis.dat");
	  draw_CC_wfs_coordinate (CC_wfs_out_file_name_real , true);
	  
	  const string CC_wfs_out_file_name_complex = (is_asymptotic_wave_function_fit_used) ? ("out_BEM_fit_complex_scaling.dat") : ("out_BEM_no_fit_complex_scaling.dat");
	  draw_CC_wfs_coordinate (CC_wfs_out_file_name_complex , false);

	  if (kmax_momentum > 0.0)
	    {
	      const string CC_wfs_momentum_out_file_name_real = (is_asymptotic_wave_function_fit_used) ? ("out_BEM_fit_momentum.dat") : ("out_BEM_no_fit_momentum.dat");
	      draw_CC_wfs_momentum (CC_wfs_momentum_out_file_name_real);
	    }
	  
	  BEM_calc_partial_norms (CC_rotor_all_data);
	}
      
      if (are_radial_form_factors_densities_stored)// because of the fit
	{
	  const string file_path_name_real = STORAGE_DIR + "out_CC_wfs_form_factors_BEM_real_axis.dat";
	  draw_CC_wfs_coordinate_form_factors (file_path_name_real , true);
	  
	  const string file_path_name_complex = STORAGE_DIR + "out_CC_wfs_form_factors_BEM_complex_scaling.dat";
	  draw_CC_wfs_coordinate_form_factors (file_path_name_complex , false);

	  if (kmax_momentum > 0.0)
	    {
	      const string file_path_name_momentum = STORAGE_DIR + "out_CC_wfs_form_factors_BEM_momentum.dat";
	      draw_CC_wfs_momentum_form_factors (file_path_name_momentum);
	    }
	      
	  // calc channels norms in the position basis to compare with channels norm in the current method

	  if (is_asymptotic_wave_function_fit_used || (potential != DIPOLAR)) 
	    {
	      BEM_calc_partial_norms_asymptotic_wave_function ();

	      BEM_calc_rms_radius ();
	    }
	  else
	    cout << endl << "Partial norms and rms radii are not calculated when the dipolar potential is used without asymptotic wave function fit" << endl << endl;

	  if (!pole_approximation)
	    {
	      const string density_out_debut_file_name = (is_asymptotic_wave_function_fit_used) ? ("density_BEM_fit") : ("density_BEM");	  
	      density_calc_store (density_out_debut_file_name , CC_rotor_all_data);

	      if (potential != DEFORMED_WS_STATIC) 
		{
		  const string intrinsic_density_out_debut_file_name = (is_asymptotic_wave_function_fit_used) ? ("intrinsic_density_BEM_fit") : ("intrinsic_density_BEM");
		  intrinsic_density_calc_store_rotating_core (intrinsic_density_out_debut_file_name , CC_rotor_all_data);
		}
		  
	      width_current_formula_calc (STORAGE_DIR + "out_width_current_formula_BEM" , CC_rotor_all_data);
	    }
	}
      
      if (calc_type == NUCLEAR_E_RMS_RADIUS_PLOT)
	{	  
	  BEM_calc_partial_norms (CC_rotor_all_data);
	  	  
	  BEM_calc_partial_norms_asymptotic_wave_function ();

	  BEM_calc_rms_radius ();
	}
    }
}





void CC_rotor_states_class::DIM_calc_asymptotic_channels (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "------ DIM_calc_asymptotic_channels: asymptotic channels (start) ------" << endl << endl;

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();
  
  if (potential == DIPOLAR)
    {
      const class dipolar_potential_class &dipolar_potential = CC_rotor_potential.get_dipolar_potential ();

      for (unsigned ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab[ic];

	  const int jrc = channel_c.get_jrc ();

	  const int lc = channel_c.get_lc ();

	  for (unsigned icp = 0 ; icp <= ic ; icp++)
	    {
	      const class CC_rotor_channel_class &channel_cp = channels_tab[icp];
	      
	      const int jrcp = channel_cp.get_jrc ();

	      const int lcp = channel_cp.get_lc ();

	      asymptotic_channels (ic , icp) = dipolar_potential.Vccp_quadratic_inverse_calc (jrc , lc , jrcp , lcp);

	      if (ic != icp) asymptotic_channels (icp , ic) = asymptotic_channels (ic , icp);

	      if (ic == icp) asymptotic_channels (ic , ic) += lc * (lc + 1.0);
	    }
	}

      total_diagonalization::symmetric::all_eigenpairs (asymptotic_channels , llp1_eff_tab);

      for (unsigned ic = 0 ; ic < N_channels ; ic++) l_eff_tab (ic) = 2.0 * llp1_eff_tab (ic)/ (1.0 + sqrt (1.0 + 4.0 * llp1_eff_tab (ic)));
    }
  else
    {
      asymptotic_channels.identity ();

      for (unsigned ic = 0 ; ic < N_channels ; ic++) l_eff_tab (ic) = channels_tab[ic].get_lc ();
    }

  cout << "------ DIM_calc_asymptotic_channels: asymptotic channels (end) ------" << endl << endl;
}














void CC_rotor_states_class::BEM_print_energy (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "========================================================================================" << endl;
  cout << "========= CC_rotor_states_class: Berggren Expansion Method (BEM) print energy ==========" << endl;
  cout << "========================================================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const double E_print = real (E);
  
  const double Gamma_print = -2.0*imag (E);

  if (potential == DEFORMED_WS_STATIC)
    {
      const string K_Pi_str = M_Pi_string (BP , K_static);

      if (calc_type != MOLECULAR)
	cout << "K-Pi: " << K_Pi_str << " E : " << E_print << " MeV Gamma : " << Gamma_print << " MeV " << endl << endl;
      else
	error_message_print_abort ("CC_rotor_states_class::BEM_print_energy: bad calc type");
    }
  else
    {
      const string J_Pi_str = J_Pi_string (BP , J);

      if (calc_type == MOLECULAR) 
	cout << "J-Pi: " << J_Pi_str << " E : " << E_print << " Ry Gamma : " << Gamma_print << " Ry " << endl << endl;
      else
	cout << "J-Pi: " << J_Pi_str << " E : " << E_print << " MeV Gamma : " << Gamma_print << " MeV " << endl << endl;
    }
}










void CC_rotor_states_class::BEM_calc_partial_norms (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "=====================================================================================================" << endl;
  cout << "========= CC_rotor_states_class: Berggren Expansion Method (BEM) partial norms calculation ==========" << endl;
  cout << "=====================================================================================================" << endl << endl;

  const class Berggren_data &data = CC_rotor_all_data.get_data ();
  
  const unsigned int N_channels = data.get_N_channels ();

  class array<complex<double> > Gamow_squared_norms (N_channels);

  Gamow_squared_norms_calc (CC_rotor_all_data , Gamow_squared_norms);

  const class array<class CC_rotor_channel_class> &channels_tab = data.get_channels_tab ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab[ic];
      
      cout << "channel " << ic << " " << channel_c << " Gamow squared norm (diagonalization) : " << Gamow_squared_norms (ic) << endl; 
    }

  cout << endl << "total Gamow squared norm (diagonalization) : " << Gamow_squared_norms.sum () << endl << endl;
}








/*
 */

void CC_rotor_states_class::CC_wf_dwf_d2wf_zero ()
{	
  CC_wf_bef_R_tab_uniform   = 0.0; 
  CC_dwf_bef_R_tab_uniform  = 0.0; 
  CC_d2wf_bef_R_tab_uniform = 0.0;

  CC_wf_bef_s_tab_GL   = 0.0; 
  CC_dwf_bef_s_tab_GL  = 0.0; 
  CC_d2wf_bef_s_tab_GL = 0.0;

  CC_wf_bef_R_tab_GL   = 0.0; 
  CC_dwf_bef_R_tab_GL  = 0.0; 
  CC_d2wf_bef_R_tab_GL = 0.0;

  CC_wf_aft_R_tab_GL_real   = 0.0; 
  CC_dwf_aft_R_tab_GL_real  = 0.0; 
  CC_d2wf_aft_R_tab_GL_real = 0.0;

  CC_wf_aft_R_tab_GL_complex   = 0.0; 
  CC_dwf_aft_R_tab_GL_complex  = 0.0; 
  CC_d2wf_aft_R_tab_GL_complex = 0.0;
  
  CC_wf_momentum_tab_uniform  = 0.0;
  CC_dwf_momentum_tab_uniform = 0.0;

  CC_wf_momentum_tab_GL  = 0.0;
  CC_dwf_momentum_tab_GL = 0.0;
}









void CC_rotor_states_class::DIM_complex_scaling_wave_function_dipolar_after_R_calc (
										    const unsigned int ic ,
										    const class array<complex<double> > &z_aft_R_tab , 
										    class array<complex<double> > &CCb_wf_aft_R_tab ,
										    class array<complex<double> > &CCb_dwf_aft_R_tab ,
										    class array<complex<double> > &CCb_d2wf_aft_R_tab) const
{
  const complex<double> I (0 , 1);

  const bool is_it_bound = is_it_bound_determine ();

  const bool is_it_bound_pole = (is_it_bound && S_matrix_pole);

  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
  const complex<double> kc = channel_c.get_kc () , kc2 = kc*kc;

  const unsigned int N_aft_R = z_aft_R_tab.dimension (0);

  class array<complex<double> > unscale_plus_tab(N_aft_R);

  for (unsigned int i = 0 ; i < N_aft_R ; i++) unscale_plus_tab(i) = exp (I * kc * z_aft_R_tab (i));

  CCb_wf_aft_R_tab = 0.0;
  CCb_dwf_aft_R_tab = 0.0;
  CCb_d2wf_aft_R_tab = 0.0;

  if (!S_matrix_pole && (ic == ic_entrance))
    {
      const class vector_class <complex<double> > &asymptotic_eigenvector_entrance_channel = asymptotic_channels.eigenvector (ic_entrance);

      const class CC_bwd_basis_state &bwd_state_entrance_channel = bwd_basis(ic_entrance);

      const complex<double> Cplus_entrance_channel = Cplus_tab(ic_entrance);

      const complex<double> lc_entrance_eff = l_eff_tab (ic_entrance); 
      const complex<double> lc_entrance_lc_entrance_plus_one_eff = lc_entrance_eff * (lc_entrance_eff + 1.0); 
      const complex<double> lc_entrance_eff_star = conj (lc_entrance_eff);
      
      const complex<double> lc_entrance_eff_phase = exp (-I * lc_entrance_eff * M_PI_2); 
      const complex<double> lc_entrance_eff_phase_star = exp (-I * lc_entrance_eff_star * M_PI_2);

      class Coulomb_wave_functions cwf_entrance_channel (true , lc_entrance_eff , 0.0);
      class Coulomb_wave_functions cwf_conj_entrance_channel (true , lc_entrance_eff_star , 0.0);

      const complex<double> asymptotic_eigenvector_entrance_channel_ic_Cplus_entrance_channel = asymptotic_eigenvector_entrance_channel (ic) * Cplus_entrance_channel;

      for (unsigned int i = 0 ; i < N_aft_R ; i++)
	{
	  const complex<double> z = z_aft_R_tab (i) , z2 = z*z;
	      
	  const complex<double> unscale_minus = 1.0/unscale_plus_tab(i);
	  
	  const complex<double> unscale_minus_asymptotic_eigenvector_entrance_channel_ic_Cplus_entrance_channel = unscale_minus * asymptotic_eigenvector_entrance_channel_ic_Cplus_entrance_channel;
	  
	  complex<double> CC_entrance_wf_aft_R = 0.0;
	  complex<double> CC_entrance_dwf_aft_R = 0.0;

	  bwd_state_entrance_channel.asymptotic_Hb_dHb_omega_scaled (-1 , kc , lc_entrance_eff , lc_entrance_eff_phase , lc_entrance_eff_phase_star , 
								     cwf_entrance_channel , cwf_conj_entrance_channel , z , CC_entrance_wf_aft_R , CC_entrance_dwf_aft_R);
	  
	  CC_entrance_wf_aft_R  *= unscale_minus_asymptotic_eigenvector_entrance_channel_ic_Cplus_entrance_channel;
	  CC_entrance_dwf_aft_R *= unscale_minus_asymptotic_eigenvector_entrance_channel_ic_Cplus_entrance_channel;
	  
	  CCb_wf_aft_R_tab(ic , i) = CC_entrance_wf_aft_R;
	  CCb_dwf_aft_R_tab(ic , i) = CC_entrance_dwf_aft_R;
	  CCb_d2wf_aft_R_tab(ic , i) = (lc_entrance_lc_entrance_plus_one_eff/z2 - kc2) * CC_entrance_wf_aft_R;
	}
    }

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      const class vector_class <complex<double> > &asymptotic_eigenvector_b = asymptotic_channels.eigenvector (ib);

      const complex<double> asymptotic_eigenvector_b_ic = asymptotic_eigenvector_b (ic);

      const class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

      const complex<double> Cplus_b = Cplus_tab(ib);

      const complex<double> lb_eff = l_eff_tab (ib);
      const complex<double> lb_lb_plus_one_eff = lb_eff * (lb_eff + 1.0); 
      const complex<double> lb_eff_star = conj (lb_eff);

      const complex<double> lb_eff_phase = exp (I * lb_eff * M_PI_2);
      const complex<double> lb_eff_phase_star = exp (I * lb_eff_star * M_PI_2);

      class Coulomb_wave_functions cwf_b (true , lb_eff , 0.0);
      class Coulomb_wave_functions cwf_conj_b (true , lb_eff_star , 0.0);

      const complex<double> asymptotic_eigenvector_b_ic_Cplus_b = asymptotic_eigenvector_b_ic * Cplus_b;

      for (unsigned int i = 0 ; i < N_aft_R ; i++)
	{
	  const complex<double> z = z_aft_R_tab (i);

	  const complex<double> z2 = z*z;

	  const complex<double> unscale_plus = unscale_plus_tab(i);
	      
	  const complex<double> unscale_plus_asymptotic_eigenvector_b_ic_Cplus_b = unscale_plus * asymptotic_eigenvector_b_ic_Cplus_b;

	  complex<double> CCb_wf_aft_R = 0.0;
	  complex<double> CCb_dwf_aft_R = 0.0;

	  bwd_state_b.asymptotic_Hb_dHb_omega_scaled (1 , kc , lb_eff , lb_eff_phase , lb_eff_phase_star , cwf_b , cwf_conj_b , z , CCb_wf_aft_R , CCb_dwf_aft_R);

	  CCb_wf_aft_R  *= unscale_plus_asymptotic_eigenvector_b_ic_Cplus_b;
	  CCb_dwf_aft_R *= unscale_plus_asymptotic_eigenvector_b_ic_Cplus_b;

	  CCb_wf_aft_R_tab(ib , i) += CCb_wf_aft_R;
	  CCb_dwf_aft_R_tab(ib , i) += CCb_dwf_aft_R;
	  CCb_d2wf_aft_R_tab(ib , i) += (lb_lb_plus_one_eff/z2 - kc2) * CCb_wf_aft_R;
	}
    }

  if (is_it_bound_pole)
    {    
      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	for (unsigned int i = 0 ; i < N_aft_R ; i++)
	  {
	    CCb_wf_aft_R_tab(ib , i) = real (CCb_wf_aft_R_tab(ib , i));
	    CCb_dwf_aft_R_tab(ib , i) = real (CCb_dwf_aft_R_tab(ib , i));
	    CCb_d2wf_aft_R_tab(ib , i) = real (CCb_d2wf_aft_R_tab(ib , i));
	  }
    }
}












void CC_rotor_states_class::complex_scaling_wave_function_asymptotic_fit_after_R_calc (
										       const unsigned int ic ,
										       const class array<complex<double> > &z_aft_R_tab , 
										       class array<complex<double> > &CC_wf_aft_R_tab ,
										       class array<complex<double> > &CC_dwf_aft_R_tab ,
										       class array<complex<double> > &CC_d2wf_aft_R_tab) const
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::complex_scaling_wave_function_asymptotic_fit_after_R_calc: S matrix poles only");

  if (!is_asymptotic_wave_function_fit_used) error_message_print_abort ("CC_rotor_states_class::complex_scaling_wave_function_asymptotic_fit_after_R_calc: cannot be called if the fit is not used");

  const complex<double> I (0 , 1);

  const unsigned int N_aft_R = z_aft_R_tab.dimension (0);

  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
  const complex<double> kc = channel_c.get_kc ();

  const complex<double> kc2 = kc*kc;

  const complex<double> Ikc(-imag (kc) , real (kc));

  const complex<double> two_Ikc = 2.0*Ikc;

  for (unsigned int i = 0 ; i < N_aft_R ; i++)
    {
      const complex<double> z = z_aft_R_tab (i);

      const complex<double> unscale_plus = exp (I * kc * z);

      complex<double> CC_wf_aft_R_z   = 0.0;
      complex<double> CC_dwf_aft_R_z  = 0.0;
      complex<double> CC_d2wf_aft_R_z = 0.0;

      complex<double> z_pow = 1.0;

      for (unsigned int ii = 0 ; ii < N_asymptotic_fit ; ii++)
	{
	  const complex<double> asymptotic_fit_constant = asymptotic_fit_tab(ic , ii);

	  CC_wf_aft_R_z += asymptotic_fit_constant/z_pow;

	  CC_dwf_aft_R_z -= ii * asymptotic_fit_constant/(z_pow * z);

	  CC_d2wf_aft_R_z += ii * (ii + 1) * asymptotic_fit_constant/(z_pow * z * z);

	  z_pow *= z;
	}

      CC_d2wf_aft_R_z += two_Ikc*CC_dwf_aft_R_z - kc2*CC_wf_aft_R_z;

      CC_dwf_aft_R_z += Ikc*CC_wf_aft_R_z;

      CC_wf_aft_R_z   *= unscale_plus;
      CC_dwf_aft_R_z  *= unscale_plus;
      CC_d2wf_aft_R_z *= unscale_plus;
      
      CC_wf_aft_R_tab(i)   = CC_wf_aft_R_z;
      CC_dwf_aft_R_tab(i)  = CC_dwf_aft_R_z;
      CC_d2wf_aft_R_tab(i) = CC_d2wf_aft_R_z;
    }
}





void CC_rotor_states_class::DIM_complex_scaling_wave_function_no_dipolar_after_R_calc (
										       const unsigned int ic ,
										       const class array<complex<double> > &z_aft_R_tab , 
										       class array<complex<double> > &CC_wf_aft_R_tab ,
										       class array<complex<double> > &CC_dwf_aft_R_tab ,
										       class array<complex<double> > &CC_d2wf_aft_R_tab) const
{
  if (is_asymptotic_wave_function_fit_used) error_message_print_abort ("CC_rotor_states_class::BEM_complex_scaling_wave_function_no_dipolar_after_R_calc: cannot be called if the fit is used");

  const bool is_it_bound = is_it_bound_determine ();

  const bool is_it_bound_pole = (is_it_bound && S_matrix_pole);

  const complex<double> I (0 , 1);

  const unsigned int N_aft_R = z_aft_R_tab.dimension (0);

  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
  
  const enum particle_type particle_c = channel_c.get_particle_c ();

  const int lc = channel_c.get_lc ();

  const int lc_lc_plus_one = lc*(lc + 1);
    
  const int ZY_charge_c = channel_c.get_ZY_charge_c ();

  const double kinetic_factor_c = channel_c.get_kinetic_factor_c ();

  const complex<double> kc = channel_c.get_kc ();

  const complex<double> kc2 = kc*kc;

  const complex<double> eta_c = channel_c.get_eta_c ();

  const class Coulomb_potential_class Coulomb_potential(false , particle_c , ZY_charge_c , NADA);

  class Coulomb_wave_functions cwf_c (true , lc , eta_c);

  CC_wf_aft_R_tab = 0.0;
  CC_dwf_aft_R_tab = 0.0;
  CC_d2wf_aft_R_tab = 0.0;

  if (!S_matrix_pole && (ic == ic_entrance))
    {
      for (unsigned int i = 0 ; i < N_aft_R ; i++)
	{
	  const complex<double> z = z_aft_R_tab (i);

	  const complex<double> z2 = z*z;

	  complex<double> CC_wf_aft_R_z = 0.0;
	  complex<double> CC_dwf_aft_R_z = 0.0;

	  cwf_c.H_kz_dH_kz (-1 , kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);
      
	  CC_wf_aft_R_tab(ic , i)   = CC_wf_aft_R_z;
	  CC_dwf_aft_R_tab(ic , i)  = CC_dwf_aft_R_z;
	  CC_d2wf_aft_R_tab(ic , i) = (lc_lc_plus_one/z2 + kinetic_factor_c*Coulomb_potential.point_potential_calc (z) - kc2) * CC_wf_aft_R_z;
	}
    }

  const complex<double> Cplus_c = Cplus_tab(ic);

  for (unsigned int i = 0 ; i < N_aft_R ; i++)
    {
      const complex<double> z = z_aft_R_tab (i);

      const complex<double> z2 = z*z;

      complex<double> CC_wf_aft_R_z = 0.0;
      complex<double> CC_dwf_aft_R_z = 0.0;

      if (is_it_bound_pole)
	cwf_c.Wm_kz_dWm_kz (kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);
      else
	cwf_c.H_kz_dH_kz (1 , kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);

      CC_wf_aft_R_z *= Cplus_c;
      CC_dwf_aft_R_z *= Cplus_c;
      
      CC_wf_aft_R_tab(ic , i)   += CC_wf_aft_R_z;
      CC_dwf_aft_R_tab(ic , i)  += CC_dwf_aft_R_z;
      CC_d2wf_aft_R_tab(ic , i) += (lc_lc_plus_one/z2 + kinetic_factor_c*Coulomb_potential.point_potential_calc (z) - kc2) * CC_wf_aft_R_z;
    }

  if (is_it_bound_pole)
    {    
      for (unsigned int i = 0 ; i < N_aft_R ; i++)
	{
	  CC_wf_aft_R_tab(ic , i)   = real (CC_wf_aft_R_tab(ic , i));
	  CC_dwf_aft_R_tab(ic , i)  = real (CC_dwf_aft_R_tab(ic , i));
	  CC_d2wf_aft_R_tab(ic , i) = real (CC_d2wf_aft_R_tab(ic , i));
	}
    }
}










void CC_rotor_states_class::complex_scaling_wave_function_no_dipolar_after_R_calc (
										   const unsigned int ic ,
										   const class array<complex<double> > &z_aft_R_tab , 
										   class array<complex<double> > &CC_wf_aft_R_tab ,
										   class array<complex<double> > &CC_dwf_aft_R_tab ,
										   class array<complex<double> > &CC_d2wf_aft_R_tab) const
{
  if (is_asymptotic_wave_function_fit_used) error_message_print_abort ("CC_rotor_states_class::complex_scaling_wave_function_no_dipolar_after_R_calc: cannot be called if the fit is used");

  const bool is_it_bound = is_it_bound_determine ();

  const bool is_it_bound_pole = (is_it_bound && S_matrix_pole);

  const complex<double> I (0 , 1);

  const unsigned int N_aft_R = z_aft_R_tab.dimension (0);

  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
  
  const enum particle_type particle_c = channel_c.get_particle_c ();

  const int lc = channel_c.get_lc ();

  const int lc_lc_plus_one = lc*(lc + 1);
    
  const int ZY_charge_c = channel_c.get_ZY_charge_c ();

  const double kinetic_factor_c = channel_c.get_kinetic_factor_c ();

  const complex<double> kc = channel_c.get_kc ();

  const complex<double> kc2 = kc*kc;

  const complex<double> eta_c = channel_c.get_eta_c ();

  const class Coulomb_potential_class Coulomb_potential(false , particle_c , ZY_charge_c , NADA);

  class Coulomb_wave_functions cwf_c (true , lc , eta_c);

  CC_wf_aft_R_tab = 0.0;
  CC_dwf_aft_R_tab = 0.0;
  CC_d2wf_aft_R_tab = 0.0;

  if (!S_matrix_pole && (ic == ic_entrance))
    {
      for (unsigned int i = 0 ; i < N_aft_R ; i++)
	{
	  const complex<double> z = z_aft_R_tab (i);

	  const complex<double> z2 = z*z;

	  complex<double> CC_wf_aft_R_z = 0.0;
	  complex<double> CC_dwf_aft_R_z = 0.0;

	  cwf_c.H_kz_dH_kz (-1 , kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);
      
	  CC_wf_aft_R_tab(i)   = CC_wf_aft_R_z;
	  CC_dwf_aft_R_tab(i)  = CC_dwf_aft_R_z;
	  CC_d2wf_aft_R_tab(i) = (lc_lc_plus_one/z2 + kinetic_factor_c*Coulomb_potential.point_potential_calc (z) - kc2) * CC_wf_aft_R_z;
	}
    }

  const complex<double> Cplus_c = Cplus_tab(ic);

  for (unsigned int i = 0 ; i < N_aft_R ; i++)
    {
      const complex<double> z = z_aft_R_tab (i);

      const complex<double> z2 = z*z;

      complex<double> CC_wf_aft_R_z = 0.0;
      complex<double> CC_dwf_aft_R_z = 0.0;

      if (is_it_bound_pole)
	cwf_c.Wm_kz_dWm_kz (kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);
      else
	cwf_c.H_kz_dH_kz (1 , kc , z , CC_wf_aft_R_z , CC_dwf_aft_R_z);

      CC_wf_aft_R_z  *= Cplus_c;
      CC_dwf_aft_R_z *= Cplus_c;
      
      CC_wf_aft_R_tab(i)   += CC_wf_aft_R_z;
      CC_dwf_aft_R_tab(i)  += CC_dwf_aft_R_z;
      CC_d2wf_aft_R_tab(i) += (lc_lc_plus_one/z2 + kinetic_factor_c*Coulomb_potential.point_potential_calc (z) - kc2) * CC_wf_aft_R_z;
    }
}










void CC_rotor_states_class::DIM_complex_scaling_wave_function_after_R_calc (
									    const unsigned int ic ,
									    const class array<complex<double> > &z_aft_R_tab , 
									    class array<complex<double> > &CC_wf_aft_R_tab ,
									    class array<complex<double> > &CC_dwf_aft_R_tab ,
									    class array<complex<double> > &CC_d2wf_aft_R_tab) const
{
  if (potential == DIPOLAR)
    DIM_complex_scaling_wave_function_dipolar_after_R_calc (ic , z_aft_R_tab , CC_wf_aft_R_tab , CC_dwf_aft_R_tab , CC_d2wf_aft_R_tab);
  else
    DIM_complex_scaling_wave_function_no_dipolar_after_R_calc (ic , z_aft_R_tab , CC_wf_aft_R_tab , CC_dwf_aft_R_tab , CC_d2wf_aft_R_tab);
}





void CC_rotor_states_class::complex_scaling_wave_function_after_R_calc (
									const unsigned int ic ,
									const class array<complex<double> > &z_aft_R_tab , 
									class array<complex<double> > &CC_wf_aft_R_tab ,
									class array<complex<double> > &CC_dwf_aft_R_tab ,
									class array<complex<double> > &CC_d2wf_aft_R_tab) const
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::complex_scaling_wave_function_after_R_calc: S matrix poles only");

  if (is_asymptotic_wave_function_fit_used)
    complex_scaling_wave_function_asymptotic_fit_after_R_calc (ic , z_aft_R_tab , CC_wf_aft_R_tab , CC_dwf_aft_R_tab , CC_d2wf_aft_R_tab);
  else if (potential != DIPOLAR)
    complex_scaling_wave_function_no_dipolar_after_R_calc (ic , z_aft_R_tab , CC_wf_aft_R_tab , CC_dwf_aft_R_tab , CC_d2wf_aft_R_tab);
  else
    error_message_print_abort ("Asymptotic wave function fit must be used with the dipolar potential in CC_rotor_states_class::complex_scaling_wave_function_after_R_calc");
}






void CC_rotor_states_class::BEM_Cplus_constants_nuclear_calc ()
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::BEM_Cplus_constants_nuclear_calc: S matrix poles only");

  const bool is_it_bound = is_it_bound_determine ();

  const bool is_it_bound_pole = (is_it_bound && S_matrix_pole);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {	      
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	      
      const int lc = channel_c.get_lc ();
	      
      const complex<double> kc = channel_c.get_kc ();

      const complex<double> eta_c = channel_c.get_eta_c ();

      class Coulomb_wave_functions cwf_c (true , lc , eta_c);

      const unsigned int N_bef_R_GL_minus_one = N_bef_R_GL - 1;

      const double R_minus = r_bef_R_tab_GL(N_bef_R_GL_minus_one);

      complex<double>  Hc_kR_minus = 0.0;
      complex<double> dHc_kR_minus = 0.0;
	      
      if (is_it_bound_pole)
	cwf_c.Wm_kz_dWm_kz (kc , R_minus , Hc_kR_minus , dHc_kR_minus);
      else
	cwf_c.H_kz_dH_kz (1 , kc , R_minus , Hc_kR_minus , dHc_kR_minus);
      
      const complex<double> Cplus_c = CC_wf_bef_R_tab_GL(ic , N_bef_R_GL_minus_one)/Hc_kR_minus;

      Cplus_tab(ic) = Cplus_c;
    }
}




complex<double> CC_rotor_states_class::Gamow_squared_norm_one_channel (const unsigned int ic) const
{
  if (!S_matrix_pole)
    {
      const complex<double> norm_no_phase = sqrt (Aplus_tab(ic_entrance));

      if (!finite (norm_no_phase)) return 1.0;

      return norm_no_phase;
    }
  else
    {
      class array<complex<double> > z_tab_GL (N_aft_R_GL);
      class array<complex<double> > w_tab_GL (N_aft_R_GL);
      
      class array<complex<double> > CCb_wf_aft_R_GL_tab (N_channels , N_aft_R_GL);
      class array<complex<double> > CCb_dwf_aft_R_GL_tab (N_channels , N_aft_R_GL);
      class array<complex<double> > CCb_d2wf_aft_R_GL_tab (N_channels , N_aft_R_GL);

      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
      const complex<double> kc = channel_c.get_kc ();
      
      const unsigned int angle_index = optimal_angle_index (2.0 * kc);
      
      const complex<double> exp_Itheta (cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  const double u = u_aft_R_GL (i);

	  const double x = pow (u , -4);

	  z_tab_GL (i) = R + (x - R) * exp_Itheta;
	  
	  w_tab_GL (i) = weights_aft_R_GL (i) * x/u;
	}

      DIM_complex_scaling_wave_function_after_R_calc (ic , z_tab_GL , CCb_wf_aft_R_GL_tab , CCb_dwf_aft_R_GL_tab , CCb_d2wf_aft_R_GL_tab);

      complex<double> norm2_bef_R = 0.0;

      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++) norm2_bef_R += CC_wf_bef_s_tab_GL (ic , i) * CC_wf_bef_s_tab_GL (ic , i) * w_bef_s_tab_GL(i);
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) norm2_bef_R += CC_wf_bef_R_tab_GL (ic , i) * CC_wf_bef_R_tab_GL (ic , i) * w_bef_R_tab_GL(i);

      complex<double> norm2_aft_R = 0.0;

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  const complex<double> w = w_tab_GL(i);

	  for (unsigned int ib = 0 ; ib < N_channels ; ib++) norm2_aft_R += CCb_wf_aft_R_GL_tab(ib , i) * CCb_wf_aft_R_GL_tab(ib , i) * w;
	}

      norm2_aft_R *= 4.0*exp_Itheta;

      const complex<double> norm2 = norm2_bef_R + norm2_aft_R;

      return norm2;
    }
}





void CC_rotor_states_class::Gamow_squared_norms_calc (
						      const class CC_rotor_all_data_class &CC_rotor_all_data , 
						      class array<complex<double> > &Gamow_squared_norms) const
{ 
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();
  
  const bool is_DIM = CC_rotor_input.get_is_CC_solver_direct_integration ();

  Gamow_squared_norms = 0.0;

  // Direct Integration Method (DIM)
  if (is_DIM)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const complex<double> Gamow_squared_norm_c = Gamow_squared_norm_one_channel (ic);

	  Gamow_squared_norms (ic) = Gamow_squared_norm_c;
	}
    }
  // Berggren Expansion Method (BEM)
  else
    {
      const unsigned int dimension = eigenvector.get_dimension ();

      const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

      // for each eigenvector, calc the contribution for the corresponding channel (s1/2: 0(jr=2)s1/2, 1(jr=2)s1/2, ...)
      // the sum of the Gamow_squared_norms is equal to 1 (has been checked numerically).

      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  const class nlj_struct &si_qn = shells_qn(i);

	  const unsigned int ic = si_qn.get_ic ();

	  const complex<double> proba = eigenvector (i) * eigenvector (i);

	  Gamow_squared_norms (ic) += proba;
	}
    } 
}









void CC_rotor_states_class::normalization ()
{
  complex<double> Gamow_squared_norm = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) Gamow_squared_norm += Gamow_squared_norm_one_channel (ic);

  const complex<double> factor = 1.0/sqrt (Gamow_squared_norm);

  CC_wf_bef_R_tab_uniform   *= factor;
  CC_dwf_bef_R_tab_uniform  *= factor;
  CC_d2wf_bef_R_tab_uniform *= factor;

  CC_wf_bef_s_tab_GL   *= factor;
  CC_dwf_bef_s_tab_GL  *= factor;
  CC_d2wf_bef_s_tab_GL *= factor;

  CC_wf_bef_R_tab_GL   *= factor;
  CC_dwf_bef_R_tab_GL  *= factor;
  CC_d2wf_bef_R_tab_GL *= factor;

  CC_wf_aft_R_tab_GL_real   *= factor;
  CC_dwf_aft_R_tab_GL_real  *= factor;
  CC_d2wf_aft_R_tab_GL_real *= factor;	

  CC_wf_aft_R_tab_GL_complex   *= factor;
  CC_dwf_aft_R_tab_GL_complex  *= factor;
  CC_d2wf_aft_R_tab_GL_complex *= factor;	

  CC_wf_momentum_tab_uniform  *= factor;
  CC_dwf_momentum_tab_uniform *= factor;

  CC_wf_momentum_tab_GL  *= factor;
  CC_dwf_momentum_tab_GL *= factor;
  
  C0_tab *= factor;

  Cplus_tab *= factor;
}







void CC_rotor_states_class::change_channels_energy (const complex<double> &E_change)
{	
  E = E_change;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      class CC_rotor_channel_class &channel_c = channels_tab(ic);

      channel_c.E_dependent_values_change (E);
    }

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);
      class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

      fwd_state_b.change_channels (E);
      bwd_state_b.change_channels (E);
    }

  if (!S_matrix_pole) bwd_U_minus.change_channels (E);
}






void CC_rotor_states_class::basis_states_calc (const class CC_rotor_potential_class &CC_rotor_potential)
{
  class CC_rotor_system_integration SI (N_channels , CC_rotor_potential , channels_tab);

  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    { 
      const complex<double> C0_b = C0_tab(ib);

      complex<double> &Cplus_b = Cplus_tab(ib);

      // forward integration ->
      class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);

      fwd_state_b.forward_integration_before_R (C0_b , CC_rotor_potential , SI);

      // backward integration <-
      class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

      bwd_state_b.backward_integration_before_R (Cplus_b , potential , false , l_eff_tab , asymptotic_channels , SI);
    }

  if (!S_matrix_pole)
    {
      complex<double> &Cplus_ic_entrance = Cplus_tab(ic_entrance);

      bwd_U_minus.backward_integration_before_R (Cplus_ic_entrance , potential , true , l_eff_tab , asymptotic_channels , SI);
    }
}





complex<double> CC_rotor_states_class::Jost_det_calc (const class CC_rotor_potential_class &CC_rotor_potential)
{
  basis_states_calc (CC_rotor_potential);

  class matrix<complex<double> > Jost_matrix = CC_rotor_Jost_matrix_calc (fwd_basis , bwd_basis);

  return Jost_matrix.determinant ();
}






void CC_rotor_states_class::DIM_E_search (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "========================================================================================" << endl;
  cout << "========= CC_rotor_states_class: Direct Integration Method (DIM) energy search =========" << endl;
  cout << "========================================================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const string energy_unit = (CC_rotor_input.get_particle () == ELECTRON) ? ("Ry") : ("MeV");

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  if (!is_E_ok) E_bisection (CC_rotor_all_data);

  if (!is_E_ok || (E == 0.0)) return;

  cout << "Starting of the DIM (direct integration method)" << endl << endl;

  double test = INFINITE;

  const complex<double> E_start = E;

  complex<double> E_bef = E * (1.0 + sqrt_precision);

  change_channels_energy (E_bef);

  complex<double> Jost_det_E_bef = Jost_det_calc (CC_rotor_potential);

  E = E_start;

  change_channels_energy (E);

  complex<double> Jost_det_E = Jost_det_calc (CC_rotor_potential);

  complex<double> dJost_det_E = (Jost_det_E_bef - Jost_det_E)/ (E_bef - E);

  cout << "E: " << E << " det[Jost (E)]: " << Jost_det_E << endl << endl;

  unsigned int count = 0;

  while (count++ < 25)
    {
      if (inf_norm (E) > 5000.0)
	{
	  is_E_ok = false;

	  return;
	}

      E_bef = E;

      E -= Jost_det_E/dJost_det_E;

      if (abs (imag (E)) < precision) E = complex<double> (real (E) , 0.);

      change_channels_energy (E);

      test = inf_norm (E_bef/E - 1.0);

      if (test < precision) break;

      Jost_det_E = Jost_det_calc (CC_rotor_potential);

      dJost_det_E = (Jost_det_E_bef - Jost_det_E)/ (E_bef - E);

      Jost_det_E_bef = Jost_det_E;

      cout << "count : " << count << " E : " << real (E) << " " << energy_unit << " G : " << - 2. * imag (E) << " " << energy_unit << " det[Jost (E)]: " << Jost_det_E << endl;
    }

  change_channels_energy (E);

  cout << endl << "E : " << real (E) << " " << energy_unit << " G : " << - 2. * imag (E) << " " << energy_unit << " |det[Jost (E)]|oo : " << inf_norm (Jost_det_E) << endl << endl;
}











// calcul des coefficients a_i^F/B
void CC_rotor_states_class::constants_calc ()
{
  switch (S_matrix_pole)
    {
    case true:
      {
	const class matrix<complex<double> > Jost_matrix = CC_rotor_Jost_matrix_calc (fwd_basis , bwd_basis);

	class matrix<complex<double> > symmetric_matrix = transpose (Jost_matrix) * Jost_matrix;

	const unsigned int dimension = Jost_matrix.get_dimension ();

	class array<complex<double> > eig_val (dimension);

	total_diagonalization::symmetric::all_eigenpairs (symmetric_matrix , eig_val);

	const unsigned int index_min = eig_val.closest_value_index_determine (0.0);

	cout << "Minimal Jost matrix eigenvalue (it must be zero): " << eig_val(index_min) << endl << endl;

	class vector_class<complex<double> > A0_Aplus_tab = symmetric_matrix.eigenvector (index_min);

	if (real (A0_Aplus_tab(index_min)) <= 0) A0_Aplus_tab = -A0_Aplus_tab;

	for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	  {
	    const unsigned int ib_plus = ib + N_channels;
	    
	    const complex<double> A0_b    = A0_Aplus_tab(ib);
	    const complex<double> Aplus_b = A0_Aplus_tab(ib_plus);
	    
	    A0_tab(ib)  = A0_b , Aplus_tab(ib)  = Aplus_b;
	    C0_tab(ib) *= A0_b , Cplus_tab(ib) *= Aplus_b;
	  }
      } break;

    case false:
      {
	const unsigned int two_N_channels = 2 * N_channels;
	
	const class array<complex<double> > &bwd_U_minus_uniform  = bwd_U_minus.get_CC_bwd_basis_wf_aft_R0_tab_uniform ();
	const class array<complex<double> > &bwd_dU_minus_uniform = bwd_U_minus.get_CC_bwd_basis_dwf_aft_R0_tab_uniform ();

	class vector_class<complex<double> > U_dU_minus_tab (two_N_channels);
	
	class vector_class<complex<double> > A0_Aplus_tab (two_N_channels);

	for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	  {
	    const unsigned int ic_deriv = ic + N_channels;

	    U_dU_minus_tab (ic) = bwd_U_minus_uniform (ic , 0);

	    U_dU_minus_tab (ic_deriv) = bwd_dU_minus_uniform (ic , 0);
	  }

	cout << "Incoming U(r) and U'(r) tables : ";
	cout << U_dU_minus_tab << endl;

	class matrix<complex<double> > Jost_matrix = CC_rotor_Jost_matrix_calc (fwd_basis , bwd_basis);

	cout << "Jost matrix : ";
	cout << Jost_matrix << endl;

	linear_system_solution_calc (Jost_matrix , U_dU_minus_tab , A0_Aplus_tab);

	for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	  {
	    const unsigned int ib_plus = ib + N_channels;
	    
	    const complex<double> A0_b = A0_Aplus_tab(ib);
	    const complex<double> Aplus_b = A0_Aplus_tab(ib_plus);
	    
	    A0_tab(ib)  = A0_b , Aplus_tab(ib)  = Aplus_b;
	    C0_tab(ib) *= A0_b , Cplus_tab(ib) *= Aplus_b;
	  }
      } break;
    }
}







void CC_rotor_states_class::DIM_CC_wf_dwf_bef_R_calc ()
{	
  for (unsigned int ib = 0 ; ib < N_channels ; ib++)
    {
      const complex<double> A0_b = A0_tab(ib) , Aplus_b = Aplus_tab(ib);

      const class CC_fwd_basis_state &fwd_state_b = fwd_basis(ib);
      const class CC_bwd_basis_state &bwd_state_b = bwd_basis(ib);

      const class array<complex<double> > &CC_fwd_basis_wf_uniform_b  = fwd_state_b.get_CC_fwd_basis_wf_bef_R0_tab_uniform ();
      const class array<complex<double> > &CC_fwd_basis_dwf_uniform_b = fwd_state_b.get_CC_fwd_basis_dwf_bef_R0_tab_uniform ();

      const class array<complex<double> > &CC_fwd_basis_wf_bef_s_tab_GL_b  = fwd_state_b.get_CC_fwd_basis_wf_bef_s_tab_GL ();
      const class array<complex<double> > &CC_fwd_basis_dwf_bef_s_tab_GL_b = fwd_state_b.get_CC_fwd_basis_dwf_bef_s_tab_GL ();

      const class array<complex<double> > &CC_fwd_basis_wf_bef_R0_tab_GL_b  = fwd_state_b.get_CC_fwd_basis_wf_bef_R0_tab_GL ();
      const class array<complex<double> > &CC_fwd_basis_dwf_bef_R0_tab_GL_b = fwd_state_b.get_CC_fwd_basis_dwf_bef_R0_tab_GL ();

      const class array<complex<double> > &CC_bwd_basis_wf_uniform_b  = bwd_state_b.get_CC_bwd_basis_wf_aft_R0_tab_uniform ();
      const class array<complex<double> > &CC_bwd_basis_dwf_uniform_b = bwd_state_b.get_CC_bwd_basis_dwf_aft_R0_tab_uniform ();

      const class array<complex<double> > &CC_bwd_basis_wf_aft_R0_tab_GL_b  = bwd_state_b.get_CC_bwd_basis_wf_aft_R0_tab_GL ();
      const class array<complex<double> > &CC_bwd_basis_dwf_aft_R0_tab_GL_b = bwd_state_b.get_CC_bwd_basis_dwf_aft_R0_tab_GL ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int i = 0 ; i < N_bef_R0_uniform ; i++)
	    {
	      CC_wf_bef_R_tab_uniform  (ic , i) += A0_b * CC_fwd_basis_wf_uniform_b  (ic , i);
	      CC_dwf_bef_R_tab_uniform (ic , i) += A0_b * CC_fwd_basis_dwf_uniform_b (ic , i);
	    }

	  for (unsigned int i = 0 ; i < N_aft_R0_uniform ; i++)
	    {
	      const unsigned int ii = i + N_bef_R0_uniform;

	      CC_wf_bef_R_tab_uniform (ic , ii)  += Aplus_b * CC_bwd_basis_wf_uniform_b  (ic , i);
	      CC_dwf_bef_R_tab_uniform (ic , ii) += Aplus_b * CC_bwd_basis_dwf_uniform_b (ic , i);
	    }

	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    {
	      CC_wf_bef_s_tab_GL  (ic , i) += A0_b * CC_fwd_basis_wf_bef_s_tab_GL_b  (ic , i);
	      CC_dwf_bef_s_tab_GL (ic , i) += A0_b * CC_fwd_basis_dwf_bef_s_tab_GL_b (ic , i);
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      if (r_bef_R_tab_GL(i) <= R0)
		{
		  CC_wf_bef_R_tab_GL  (ic , i) += A0_b * CC_fwd_basis_wf_bef_R0_tab_GL_b  (ic , i);
		  CC_dwf_bef_R_tab_GL (ic , i) += A0_b * CC_fwd_basis_dwf_bef_R0_tab_GL_b (ic , i);
		}
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      if (r_bef_R_tab_GL(i) >= R0)
		{
		  CC_wf_bef_R_tab_GL  (ic , i) += Aplus_b * CC_bwd_basis_wf_aft_R0_tab_GL_b  (ic , i);
		  CC_dwf_bef_R_tab_GL (ic , i) += Aplus_b * CC_bwd_basis_dwf_aft_R0_tab_GL_b (ic , i);
		}
	    }
	}
    }

  if (!S_matrix_pole)
    {
      const class array<complex<double> > &bwd_U_minus_aft_R0_tab_uniform  = bwd_U_minus.get_CC_bwd_basis_wf_aft_R0_tab_uniform ();
      const class array<complex<double> > &bwd_dU_minus_aft_R0_tab_uniform = bwd_U_minus.get_CC_bwd_basis_dwf_aft_R0_tab_uniform ();

      const class array<complex<double> > &bwd_U_minus_aft_R0_tab_GL  = bwd_U_minus.get_CC_bwd_basis_wf_aft_R0_tab_GL ();
      const class array<complex<double> > &bwd_dU_minus_aft_R0_tab_GL = bwd_U_minus.get_CC_bwd_basis_dwf_aft_R0_tab_GL ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int i = 0 ; i < N_aft_R0_uniform ; i++)
	    {
	      const unsigned int ii = i + N_bef_R0_uniform;

	      CC_wf_bef_R_tab_uniform (ic , ii)  += bwd_U_minus_aft_R0_tab_uniform  (ic , i);
	      CC_dwf_bef_R_tab_uniform (ic , ii) += bwd_dU_minus_aft_R0_tab_uniform (ic , i);
	    }

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      CC_wf_bef_R_tab_GL  (ic , i) += bwd_U_minus_aft_R0_tab_GL  (ic , i);
	      CC_dwf_bef_R_tab_GL (ic , i) += bwd_dU_minus_aft_R0_tab_GL (ic , i);
	    }
	}
    }
}









void CC_rotor_states_class::CC_d2wf_bef_R_calc (const class CC_rotor_potential_class &CC_rotor_potential)
{	
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_lc ();

      const unsigned int ib = ic;

      const complex<double> C0_b = C0_tab(ib);

      CC_d2wf_bef_R_tab_uniform (ic , 0) = (lc == 1)? (2.0 * C0_b): (0.0);
    }

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const double kinetic_factor_c = channel_c.get_kinetic_factor_c ();

      const int lc = channel_c.get_lc ();

      const int lc_lcp1 = lc * (lc + 1);

      const complex<double> e_c = channel_c.get_e_c ();

      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = r_bef_R_tab_uniform(i);

	  CC_d2wf_bef_R_tab_uniform (ic , i) = (lc_lcp1/ (r * r) - kinetic_factor_c * e_c) * CC_wf_bef_R_tab_uniform (ic , i);
	}

      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  const double r = r_bef_s_tab_GL(i);

	  CC_d2wf_bef_s_tab_GL (ic , i) = (lc_lcp1/ (r * r) - kinetic_factor_c * e_c) * CC_wf_bef_s_tab_GL (ic , i);
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);

	  CC_d2wf_bef_R_tab_GL (ic , i) = (lc_lcp1/ (r * r) - kinetic_factor_c * e_c) * CC_wf_bef_R_tab_GL (ic , i);
	}
    }

  for (unsigned ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const double kinetic_factor_c = channel_c.get_kinetic_factor_c ();
      
      const int jrc = channel_c.get_jrc ();
      
      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();
      //const complex<double> e_c = channel_c.get_e_c ();

      for (unsigned icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab[icp];
	  	      
	  const int jrcp = channel_cp.get_jrc ();
	  
	  const int lcp = channel_cp.get_lc ();

	  const double jcp = channel_cp.get_jc ();

	  switch (potential)
	    {
	    case DIPOLAR:
	      {
		const class dipolar_potential_class &dipolar_potential = CC_rotor_potential.get_dipolar_potential ();

		for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		  {
		    const double r = r_bef_R_tab_uniform (i);

		    CC_d2wf_bef_R_tab_uniform (ic , i) += dipolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_uniform (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
		  {
		    const double r = r_bef_s_tab_GL(i);

		    CC_d2wf_bef_s_tab_GL (ic , i) += dipolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_s_tab_GL (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);

		    CC_d2wf_bef_R_tab_GL (ic , i) += dipolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }
	      } break;

	    case QUADRUPOLAR:
	      {
		const class quadrupolar_potential_class &quadrupolar_potential = CC_rotor_potential.get_quadrupolar_potential ();

		for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		  {
		    const double r = r_bef_R_tab_uniform (i);

		    CC_d2wf_bef_R_tab_uniform (ic , i) += quadrupolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_uniform (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
		  {
		    const double r = r_bef_s_tab_GL(i);

		    CC_d2wf_bef_s_tab_GL (ic , i) += quadrupolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_s_tab_GL (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);

		    CC_d2wf_bef_R_tab_GL (ic , i) += quadrupolar_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }
	      } break;

	    case GAUSSIAN:
	      {
		const class Gaussian_potential_class &Gaussian_potential = CC_rotor_potential.get_Gaussian_potential ();

		for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		  {
		    const double r = r_bef_R_tab_uniform (i);

		    CC_d2wf_bef_R_tab_uniform (ic , i) += Gaussian_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_uniform (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
		  {
		    const double r = r_bef_s_tab_GL(i);

		    CC_d2wf_bef_s_tab_GL (ic , i) += Gaussian_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);

		    CC_d2wf_bef_R_tab_GL (ic , i) += Gaussian_potential (jrc , lc , jrcp , lcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }
				
	      } break;

	    case DEFORMED_WS:
	      {
		const class deformed_WS_class &deformed_WS_potential = CC_rotor_potential.get_deformed_WS_potential ();

		for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		  {
		    const double r = r_bef_R_tab_uniform (i);

		    CC_d2wf_bef_R_tab_uniform (ic , i) += kinetic_factor_c * deformed_WS_potential (jrc , lc , jc , jrcp , lcp , jcp , r) * CC_wf_bef_R_tab_uniform (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
		  {
		    const double r = r_bef_s_tab_GL(i);

		    CC_d2wf_bef_s_tab_GL (ic , i) += kinetic_factor_c * deformed_WS_potential (jrc , lc , jc , jrcp , lcp , jcp , r) * CC_wf_bef_s_tab_GL (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);

		    CC_d2wf_bef_R_tab_GL (ic , i) += kinetic_factor_c * deformed_WS_potential (jrc , lc , jc , jrcp , lcp , jcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }
	      } break;
	  
	    case DEFORMED_WS_STATIC:
	      {
		const class deformed_WS_static_class &deformed_WS_static_potential = CC_rotor_potential.get_deformed_WS_static_potential ();

		for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
		  {
		    const double r = r_bef_R_tab_uniform (i);

		    CC_d2wf_bef_R_tab_uniform (ic , i) += kinetic_factor_c * deformed_WS_static_potential (lc , jc , lcp , jcp , r) * CC_wf_bef_R_tab_uniform (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
		  {
		    const double r = r_bef_s_tab_GL(i);

		    CC_d2wf_bef_s_tab_GL (ic , i) += kinetic_factor_c * deformed_WS_static_potential (lc , jc , lcp , jcp , r) * CC_wf_bef_s_tab_GL (icp , i);
		  }

		for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		  {
		    const double r = r_bef_R_tab_GL(i);

		    CC_d2wf_bef_R_tab_GL (ic , i) += kinetic_factor_c * deformed_WS_static_potential (lc , jc , lcp , jcp , r) * CC_wf_bef_R_tab_GL (icp , i);
		  }
	      } break;
	  
	    default: error_message_print_abort ("CC_rotor_states_class::CC_d2wf_bef_R_calc : bad potential type");
	    }
	}
    }
}














void CC_rotor_states_class::DIM_CC_wave_aft_R_GL_calc ()
{
  class vector_class <complex<double> > UR (N_channels);
  class vector_class <complex<double> > dUR (N_channels);

  class array<complex<double> > CCb_wf_aft_R_tab_GL   (N_channels , N_aft_R_GL);
  class array<complex<double> > CCb_dwf_aft_R_tab_GL  (N_channels , N_aft_R_GL);
  class array<complex<double> > CCb_d2wf_aft_R_tab_GL (N_channels , N_aft_R_GL);

  class array<complex<double> > r_aft_R_tab_GL_real_c(N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) r_aft_R_tab_GL_real_c(i) = r_aft_R_tab_GL_real(i);
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      DIM_complex_scaling_wave_function_after_R_calc (ic , r_aft_R_tab_GL_real_c , CCb_wf_aft_R_tab_GL , CCb_dwf_aft_R_tab_GL , CCb_d2wf_aft_R_tab_GL);

      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  {
	    CC_wf_aft_R_tab_GL_real   (ic , i) += CCb_wf_aft_R_tab_GL (ib , i);
	    CC_dwf_aft_R_tab_GL_real  (ic , i) += CCb_dwf_aft_R_tab_GL (ib , i);
	    CC_d2wf_aft_R_tab_GL_real (ic , i) += CCb_d2wf_aft_R_tab_GL (ib , i);
	  }

      DIM_complex_scaling_wave_function_after_R_calc (ic , r_aft_R_tab_GL_complex , CCb_wf_aft_R_tab_GL , CCb_dwf_aft_R_tab_GL , CCb_d2wf_aft_R_tab_GL);

      for (unsigned int ib = 0 ; ib < N_channels ; ib++)
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  {
	    CC_wf_aft_R_tab_GL_complex   (ic , i) += CCb_wf_aft_R_tab_GL (ib , i);
	    CC_dwf_aft_R_tab_GL_complex  (ic , i) += CCb_dwf_aft_R_tab_GL (ib , i);
	    CC_d2wf_aft_R_tab_GL_complex (ic , i) += CCb_d2wf_aft_R_tab_GL (ib , i);
	  }
    }
}













void CC_rotor_states_class::DIM_calc_CC_wfs_basis_position (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "==============================================================================================================" << endl;
  cout << "========= CC_rotor_states_class: Direct Integration Method (DIM) u_c(r) calculated in basis position =========" << endl;
  cout << "==============================================================================================================" << endl << endl;

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) channels_tab(ic).E_dependent_values_change (E);

  CC_wf_dwf_d2wf_zero ();

  basis_states_calc (CC_rotor_potential);

  constants_calc ();

  DIM_CC_wf_dwf_bef_R_calc ();

  CC_d2wf_bef_R_calc (CC_rotor_potential);

  DIM_CC_wave_aft_R_GL_calc ();

  normalization ();
}






void CC_rotor_states_class::DIM_calc_partial_norms ()
{
  complex<double> Gamow_squared_norm = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const complex<double> Gamow_squared_norm_c = Gamow_squared_norm_one_channel (ic);

      cout << "channel " << ic << " " << channel_c << " Gamow squared norm : " << Gamow_squared_norm_c << endl; 

      Gamow_squared_norm += Gamow_squared_norm_c;
    }

  cout << endl << "Total Gamow squared norm : " << Gamow_squared_norm << endl << endl;
}







void CC_rotor_states_class::DIM_calc_rms_radius ()
{
  const class CC_rotor_channel_class &channel_zero = channels_tab(0);

  const enum particle_type particle = channel_zero.get_particle_c ();

  const string length_unit = (particle == ELECTRON) ? ("a0") : ("fm");

  class array<complex<double> > z_tab_GL (N_aft_R_GL);
  class array<complex<double> > w_tab_GL (N_aft_R_GL);

  class array<complex<double> > CCb_wf_aft_R_GL_tab   (N_channels , N_aft_R_GL);
  class array<complex<double> > CCb_dwf_aft_R_GL_tab  (N_channels , N_aft_R_GL);
  class array<complex<double> > CCb_d2wf_aft_R_GL_tab (N_channels , N_aft_R_GL);

  complex<double> squared_rms_radius = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const complex<double> kc = channel_c.get_kc ();

      const unsigned int angle_index = optimal_angle_index (2.0 * kc);

      const complex<double> exp_Itheta (cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  const double u = u_aft_R_GL (i);

	  const double x = pow (u , -4);

	  z_tab_GL (i) = R + (x - R) * exp_Itheta;
	  
	  w_tab_GL (i) = weights_aft_R_GL (i) * x/u;
	}

      DIM_complex_scaling_wave_function_after_R_calc (ic , z_tab_GL , CCb_wf_aft_R_GL_tab , CCb_dwf_aft_R_GL_tab , CCb_d2wf_aft_R_GL_tab);

      complex<double> squared_rms_radius_bef_R_c = 0.0;
      complex<double> squared_rms_radius_aft_R_c = 0.0;

      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++) squared_rms_radius_bef_R_c += CC_wf_bef_s_tab_GL (ic , i) * CC_wf_bef_s_tab_GL (ic , i) * r_bef_s_tab_GL(i) * r_bef_s_tab_GL(i) * w_bef_s_tab_GL(i);
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) squared_rms_radius_bef_R_c += CC_wf_bef_R_tab_GL (ic , i) * CC_wf_bef_R_tab_GL (ic , i) * r_bef_R_tab_GL(i) * r_bef_R_tab_GL(i) * w_bef_R_tab_GL(i);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  const complex<double> z = z_tab_GL(i);
	  const complex<double> w = w_tab_GL(i);

	  const complex<double> z2_w = z*z*w;

	  for (unsigned int ib = 0 ; ib < N_channels ; ib++) squared_rms_radius_aft_R_c += CCb_wf_aft_R_GL_tab(ib , i) * CCb_wf_aft_R_GL_tab(ib , i) * z2_w;
	}

      squared_rms_radius_aft_R_c *= 4.0*exp_Itheta;

      const complex<double> squared_rms_radius_c = squared_rms_radius_bef_R_c + squared_rms_radius_aft_R_c;

      squared_rms_radius += squared_rms_radius_c;

      cout << "channel " << ic << " " << channel_c << " <r^2> : " << squared_rms_radius_c << endl;
    }

  rms_radius = sqrt (squared_rms_radius);
 
  cout << endl << "<r^2> : " << squared_rms_radius << " " << length_unit << "^2 , sqrt[<r^2>] : " << rms_radius << " " << length_unit << endl << endl;
}

















void CC_rotor_states_class::BEM_calc_partial_norms_asymptotic_wave_function ()
{
  const complex<double> I(0 , 1);

  class array<complex<double> > z_tab_GL (N_aft_R_GL);
  class array<complex<double> > w_tab_GL (N_aft_R_GL);

  class array<complex<double> > CC_wf_aft_R_tab_GL   (N_aft_R_GL);
  class array<complex<double> > CC_dwf_aft_R_tab_GL  (N_aft_R_GL);
  class array<complex<double> > CC_d2wf_aft_R_tab_GL (N_aft_R_GL);

  complex<double> test_norm = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      complex<double> partial_norm_bef_R_c = 0.0;
      complex<double> partial_norm_aft_R_c = 0.0;

      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++) partial_norm_bef_R_c += CC_wf_bef_s_tab_GL (ic , i) * CC_wf_bef_s_tab_GL (ic , i) * w_bef_s_tab_GL(i);
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) partial_norm_bef_R_c += CC_wf_bef_R_tab_GL (ic , i) * CC_wf_bef_R_tab_GL (ic , i) * w_bef_R_tab_GL(i);

      if (is_asymptotic_wave_function_fit_used)
	{
	  if (is_it_bound_determine ())
	    {
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		partial_norm_aft_R_c += CC_wf_aft_R_tab_GL_real (ic , i) * CC_wf_aft_R_tab_GL_real (ic , i) * w_aft_R_tab_GL_real(i);
	    }
	  else 
	    {
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		partial_norm_aft_R_c += CC_wf_aft_R_tab_GL_complex (ic , i) * CC_wf_aft_R_tab_GL_complex (ic , i) * w_aft_R_tab_GL_complex(i);
	    }
	}	
      else
	{
	  const complex<double> kc = channel_c.get_kc ();

	  const double theta = M_PI_2 - arg (2.0 * kc);

	  const complex<double> exp_Itheta = exp (I*theta);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      const double u = u_aft_R_GL (i);

	      const double x = pow (u , -4);

	      z_tab_GL (i) = R + (x - R) * exp_Itheta;
	  
	      w_tab_GL (i) = weights_aft_R_GL (i) * x/u;
	    }

	  complex_scaling_wave_function_after_R_calc (ic , z_tab_GL , CC_wf_aft_R_tab_GL , CC_dwf_aft_R_tab_GL , CC_d2wf_aft_R_tab_GL);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) partial_norm_aft_R_c += CC_wf_aft_R_tab_GL(i) * CC_wf_aft_R_tab_GL(i) * w_tab_GL (i);

	  partial_norm_aft_R_c *= 4.0*exp_Itheta;
	}

      const complex<double> partial_norm_c = partial_norm_bef_R_c + partial_norm_aft_R_c;

      test_norm += partial_norm_c;

      cout << "channel " << ic << " " << channel_c << " test norm (complex scaling) : " << partial_norm_c << endl;
    }

  cout << endl << "Total test norm (complex scaling) : " << test_norm << endl << endl;
}














void CC_rotor_states_class::BEM_calc_rms_radius ()
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::BEM_calc_rms_radius: S matrix poles only");

  const complex<double> I(0 , 1);

  const class CC_rotor_channel_class &channel_zero = channels_tab(0);

  const enum particle_type particle = channel_zero.get_particle_c ();

  const string length_unit = (particle == ELECTRON) ? ("a0") : ("fm");

  class array<complex<double> > z_tab_GL (N_aft_R_GL);
  class array<complex<double> > w_tab_GL (N_aft_R_GL);

  class array<complex<double> > CC_wf_aft_R_tab_GL   (N_aft_R_GL);
  class array<complex<double> > CC_dwf_aft_R_tab_GL  (N_aft_R_GL);
  class array<complex<double> > CC_d2wf_aft_R_tab_GL (N_aft_R_GL);

  complex<double> squared_rms_radius = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab[ic];

      complex<double> squared_rms_radius_bef_R_c = 0.0;
      complex<double> squared_rms_radius_aft_R_c = 0.0;

      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++) squared_rms_radius_bef_R_c += CC_wf_bef_s_tab_GL (ic , i) * CC_wf_bef_s_tab_GL (ic , i) * r_bef_s_tab_GL(i) * r_bef_s_tab_GL(i) * w_bef_s_tab_GL(i);
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) squared_rms_radius_bef_R_c += CC_wf_bef_R_tab_GL (ic , i) * CC_wf_bef_R_tab_GL (ic , i) * r_bef_R_tab_GL(i) * r_bef_R_tab_GL(i) * w_bef_R_tab_GL(i);

      if (is_asymptotic_wave_function_fit_used)
	{
	  if (is_it_bound_determine ())
	    {
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		squared_rms_radius_aft_R_c += CC_wf_aft_R_tab_GL_real (ic , i) * CC_wf_aft_R_tab_GL_real (ic , i) * r_aft_R_tab_GL_real(i) * r_aft_R_tab_GL_real(i) * w_aft_R_tab_GL_real(i);
	    }
	  else 
	    {
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
		squared_rms_radius_aft_R_c += CC_wf_aft_R_tab_GL_complex (ic , i) * CC_wf_aft_R_tab_GL_complex (ic , i) * r_aft_R_tab_GL_complex(i) * r_aft_R_tab_GL_complex(i) * w_aft_R_tab_GL_complex(i);
	    }
	}
      else
	{
	  const complex<double> kc = channel_c.get_kc ();

	  const double theta = M_PI_2 - arg (2.0 * kc);

	  const complex<double> exp_Itheta = exp (I*theta);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      z_tab_GL (i) = R + (pow (u_aft_R_GL (i) , -4) - R) * exp_Itheta;

	      w_tab_GL (i) = weights_aft_R_GL (i) * pow (u_aft_R_GL (i) , -4)/u_aft_R_GL (i);
	    }

	  complex_scaling_wave_function_after_R_calc (ic , z_tab_GL , CC_wf_aft_R_tab_GL , CC_dwf_aft_R_tab_GL , CC_d2wf_aft_R_tab_GL);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) squared_rms_radius_aft_R_c += CC_wf_aft_R_tab_GL(i) * CC_wf_aft_R_tab_GL(i) * z_tab_GL (i) * z_tab_GL (i) * w_tab_GL (i);

	  squared_rms_radius_aft_R_c *= 4.0*exp_Itheta;
	}

      const complex<double> squared_rms_radius_c = squared_rms_radius_bef_R_c + squared_rms_radius_aft_R_c;

      squared_rms_radius += squared_rms_radius_c;

      cout << "channel " << ic << " " << channel_c << "  <r^2> : " << squared_rms_radius_c << endl;
    }

  rms_radius = sqrt (squared_rms_radius);
  
  cout << endl << "<r^2> : " << squared_rms_radius << " " << length_unit << "^2 , sqrt[<r^2>] : " << rms_radius << " " << length_unit << endl << endl;
}







void CC_rotor_states_class::CC_wfs_dwfs_momentum_calc_from_DIM (const double b_HO)
{
  if (kmax_momentum == 0.0) error_message_print_abort ("kmax_momentum must be positive to use CC_rotor_states_class::CC_wfs_dwfs_momentum_calc");
    
  if (R_max == 0.0) error_message_print_abort ("R_max must be positive to use CC_rotor_states_class::CC_wfs_dwfs_momentum_calc");
    
  if (inf_norm (CC_wf_bef_R_tab_GL(0 , 0)) > SQRT_INFINITE) error_message_print_abort ("The wave function must have been calculated in radial space in order to calculate it in momentum space in CC_rotor_states_class::CC_wfs_dwfs_momentum_calc");

  const double d_Fermi_momentum = 10.0;
  
  const int nmax_HO = 40;
  
  const int nmax_HO_plus_one = nmax_HO + 1;

  const double bk_HO = 1.0/b_HO;
  
  class array<double> HO_wfs_bef_R_tab_GL (nmax_HO_plus_one , N_bef_R_GL);  
  class array<double> HO_wfs_aft_R_tab_GL (nmax_HO_plus_one , N_aft_R_GL);
      
  class array<double> HO_wfs_momentum_tab_uniform (nmax_HO_plus_one , Nk_momentum_uniform);
  class array<double> HO_dwfs_momentum_tab_uniform(nmax_HO_plus_one , Nk_momentum_uniform);
  
  class array<double> HO_wfs_momentum_tab_GL (nmax_HO_plus_one , Nk_momentum_GL);
  class array<double> HO_dwfs_momentum_tab_GL(nmax_HO_plus_one , Nk_momentum_GL);
  
  class array<double> Fermi_w_bef_R_tab_GL (N_bef_R_GL);  
  class array<double> Fermi_w_aft_R_tab_GL (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) Fermi_w_bef_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_bef_R_tab_GL(i))     *w_bef_R_tab_GL(i);
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) Fermi_w_aft_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_aft_R_tab_GL_real(i))*w_aft_R_tab_GL_real(i);
  
  class array<complex<double> > CC_wf_Fermi_w_bef_R_tab_GL (N_bef_R_GL);  
  class array<complex<double> > CC_wf_Fermi_w_aft_R_tab_GL (N_aft_R_GL);
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab[ic];
      
      const int lc = channel_c.get_lc ();

      HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , lc , r_bef_R_tab_GL      , HO_wfs_bef_R_tab_GL);
      HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , lc , r_aft_R_tab_GL_real , HO_wfs_aft_R_tab_GL);
    
      HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , lc , k_tab_uniform , HO_wfs_momentum_tab_uniform , HO_dwfs_momentum_tab_uniform);
      HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , lc , k_tab_GL      , HO_wfs_momentum_tab_GL      , HO_dwfs_momentum_tab_GL);

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) CC_wf_Fermi_w_bef_R_tab_GL(i) = Fermi_w_bef_R_tab_GL(i)*CC_wf_bef_R_tab_GL     (ic , i);
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) CC_wf_Fermi_w_aft_R_tab_GL(i) = Fermi_w_aft_R_tab_GL(i)*CC_wf_aft_R_tab_GL_real(ic , i);
  
      for (int nHOc = 0 ; nHOc <= nmax_HO ; nHOc++)
	{
	  complex<double> HO_overlap_nHOc = 0.0;
	
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) HO_overlap_nHOc += CC_wf_Fermi_w_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(nHOc , i);
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) HO_overlap_nHOc += CC_wf_Fermi_w_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(nHOc , i);
	      
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      CC_wf_momentum_tab_uniform (ic , i) += HO_wfs_momentum_tab_uniform (nHOc , i)*HO_overlap_nHOc;
	      CC_dwf_momentum_tab_uniform(ic , i) += HO_dwfs_momentum_tab_uniform(nHOc , i)*HO_overlap_nHOc;
	    }
	      
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      CC_wf_momentum_tab_GL (ic , i) += HO_wfs_momentum_tab_GL (nHOc , i)*HO_overlap_nHOc;
	      CC_dwf_momentum_tab_GL(ic , i) += HO_dwfs_momentum_tab_GL(nHOc , i)*HO_overlap_nHOc;
	    }
	}
    }    
}








void CC_rotor_states_class::asymptotic_fit_tab_from_diagonalization_calc (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::asymptotic_fit_tab_from_diagonalization_calc: S matrix poles only");

  if (!is_asymptotic_wave_function_fit_used) error_message_print_abort ("CC_rotor_states_class::asymptotic_fit_tab_from_diagonalization_calc: cannot be called if the fit is not used");

  const complex<double> I (0 , 1);

  const unsigned int Nr_fit = CC_rotor_all_data.get_Nr_fit ();
  
  class array<double> r_fit_tab(Nr_fit);

  class array<complex<double> > r_pow_inv_tab (Nr_fit , N_asymptotic_fit);
  
  class array<complex<double> > CC_wf_aft_R_tab_GL_real_scaled_fit (N_channels , Nr_fit);
  
  unsigned int ir_fit = 0;
      
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double r = r_aft_R_tab_GL_real(i);
	  
      if ((r >= rmin_for_fit) && (r <= rmax_for_fit))
	{	  
	  double r_pow_inv = 1.0;

	  for (unsigned int ii = 0 ; ii < N_asymptotic_fit ; ii++) 
	    {
	      r_pow_inv_tab (ir_fit , ii) = r_pow_inv;

	      r_pow_inv /= r;
	    }
	  
	  r_fit_tab(ir_fit) = r;
      
	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    {
	      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	      const complex<double> kc = channel_c.get_kc ();
	      
	      CC_wf_aft_R_tab_GL_real_scaled_fit (ic , ir_fit) = CC_wf_aft_R_tab_GL_real (ic , i) * exp (-I * kc * r);
	    }
  
	  ir_fit++;
	}
    }
  
  class matrix<complex<double> > A (N_asymptotic_fit);

  for (unsigned int i = 0 ; i < N_asymptotic_fit ; i++)
    for (unsigned int ip = 0 ; ip < N_asymptotic_fit ; ip++)
      {
	complex<double> A_ME = 0.0;

	for (unsigned int ir = 0 ; ir < Nr_fit ; ir++) A_ME += r_pow_inv_tab (ir , i) * r_pow_inv_tab (ir , ip);

	A(i , ip) = A_ME;
      }

  class vector_class<complex<double> > B (N_asymptotic_fit);  
  class vector_class<complex<double> > X (N_asymptotic_fit);
      
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      for (unsigned int i = 0 ; i < N_asymptotic_fit ; i++)
	{
	  complex<double> Bi = 0.0;

	  for (unsigned int ir = 0 ; ir < Nr_fit ; ir++)
	    {
	      const complex<double> CC_wf_aft_R_tab_GL_real_scaled_fit_r = CC_wf_aft_R_tab_GL_real_scaled_fit (ic , ir);

	      Bi += CC_wf_aft_R_tab_GL_real_scaled_fit_r * r_pow_inv_tab (ir , i);
	    }

	  B(i) = Bi;
	}

      linear_system_solution_calc (A , B , X);

      for (unsigned int i = 0 ; i < N_asymptotic_fit ; i++) asymptotic_fit_tab (ic , i) = X (i);
    }
}











void CC_rotor_states_class::draw_CC_wfs_coordinate (const string &file_name , const bool is_it_real_axis) const
{
  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      outfile << r_bef_R_tab_uniform(i) << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  outfile << real (CC_wf_bef_R_tab_uniform   (ic , i)) << " " << imag (CC_wf_bef_R_tab_uniform   (ic , i)) << " "
		  << real (CC_dwf_bef_R_tab_uniform  (ic , i)) << " " << imag (CC_dwf_bef_R_tab_uniform  (ic , i)) << " "
		  << real (CC_d2wf_bef_R_tab_uniform (ic , i)) << " " << imag (CC_d2wf_bef_R_tab_uniform (ic , i)) << " ";
	}

      outfile << endl;
    }

  if (is_it_real_axis)
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  outfile << r_aft_R_tab_GL_real(i) << " ";

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    outfile << real (CC_wf_aft_R_tab_GL_real   (ic , i)) << " " << imag (CC_wf_aft_R_tab_GL_real   (ic , i)) << " "
		    << real (CC_dwf_aft_R_tab_GL_real  (ic , i)) << " " << imag (CC_dwf_aft_R_tab_GL_real  (ic , i)) << " "
		    << real (CC_d2wf_aft_R_tab_GL_real (ic , i)) << " " << imag (CC_d2wf_aft_R_tab_GL_real (ic , i)) << " ";

	  outfile << endl;
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  outfile << real (r_aft_R_tab_GL_complex(i)) << " ";

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    outfile << real (CC_wf_aft_R_tab_GL_complex   (ic , i)) << " " << imag (CC_wf_aft_R_tab_GL_complex   (ic , i)) << " "
		    << real (CC_dwf_aft_R_tab_GL_complex  (ic , i)) << " " << imag (CC_dwf_aft_R_tab_GL_complex  (ic , i)) << " "
		    << real (CC_d2wf_aft_R_tab_GL_complex (ic , i)) << " " << imag (CC_d2wf_aft_R_tab_GL_complex (ic , i)) << " ";

	  outfile << endl;
	}
    }
}









void CC_rotor_states_class::draw_CC_wfs_coordinate_form_factors (const string &file_name , const bool is_it_real_axis) const
{
  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      outfile << r_bef_R_tab_uniform(i) << " ";

      // real (u_c (r))^2 + imag (u_c (r))^2

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) outfile << norm (CC_wf_bef_R_tab_uniform (ic , i)) << " ";

      outfile << endl;
    }

  if (is_it_real_axis)
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  outfile << r_aft_R_tab_GL_real(i) << " ";

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++) outfile << norm (CC_wf_aft_R_tab_GL_real (ic , i)) << " ";

	  outfile << endl;
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  outfile << r_aft_R_tab_GL_complex(i) << " ";

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++) outfile << norm (CC_wf_aft_R_tab_GL_complex (ic , i)) << " ";

	  outfile << endl;
	}
    }
}








void CC_rotor_states_class::draw_CC_wfs_momentum (const string &file_name) const
{
  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
    {
      outfile << k_tab_uniform(i) << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  outfile << real (CC_wf_momentum_tab_uniform (ic , i)) << " " << imag (CC_wf_momentum_tab_uniform (ic , i)) << " "
		  << real (CC_dwf_momentum_tab_uniform(ic , i)) << " " << imag (CC_dwf_momentum_tab_uniform(ic , i)) << " ";
	}

      outfile << endl;
    }
}









void CC_rotor_states_class::draw_CC_wfs_momentum_form_factors (const string &file_name) const
{
  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
    {
      outfile << k_tab_uniform(i) << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) outfile << norm (CC_wf_momentum_tab_uniform (ic , i)) << " ";

      outfile << endl;
    }
}









void CC_rotor_states_class::angular_tabs_density_molecular_calc (
								 const class array<double> &PYlm_tab ,
								 class array<bool> &is_angular_trivial_zero_tab ,
								 class array<double> &angular_weights_tab_for_density ,
								 class array<double> &angular_tab) const
{
  class array<double> angular_tab_theta (Nt);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();

      const int lc = channel_c.get_lc ();

      for (unsigned int icp = 0 ; icp <= ic ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

	  const int jrcp = channel_cp.get_jrc ();

	  if (jrc == jrcp)
	    {
	      const int lcp = channel_cp.get_lc ();
	      const int lc_min = min (lc , lcp);

	      angular_tab_theta = 0.0;

	      for (int mjrc = - jrc ; mjrc <= jrc ; mjrc++)
		{
		  for (int mlc = - lc_min ; mlc <= lc_min ; mlc++)
		    {
		      const int M = mjrc + mlc;

		      if (abs (M) <= J)
			{
			  const int abs_mlc = abs (mlc);

			  const double CGs_prod_norm = Clebsch_Gordan (jrc , mjrc , lc , mlc , J , M) * Clebsch_Gordan (jrc , mjrc , lcp , mlc , J , M);

			  for (unsigned int i = 0 ; i < Nt ; i++) angular_tab_theta (i) += CGs_prod_norm * PYlm_tab (lc , abs_mlc , i) * PYlm_tab (lcp , abs_mlc , i);

			  is_angular_trivial_zero_tab (ic , icp) = false;
			}
		    }
		}
	      for (unsigned int i = 0 ; i < Nt ; i++) angular_tab (ic , icp , i) = angular_tab_theta (i);
	    }
	}
    }

  // ================================== ================================== //
  // rho_J (r)
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
      const int jrc = channel_c.get_jrc ();

      const int lc = channel_c.get_lc ();

      const unsigned int N_mjrc = 2*jrc + 1;

      const int mjrc_min = -jrc;

      const unsigned int N_mlc = 2*lc + 1;

      const int mlc_min = -lc;

      for (unsigned int i_mjrc = 0 ; i_mjrc < N_mjrc ; i_mjrc++)
	{
	  const int mjrc = mjrc_min + i_mjrc;

	  for (unsigned int i_mlc = 0 ; i_mlc < N_mlc ; i_mlc++)
	    {
	      const int mlc = mlc_min + i_mlc;

	      const int M = mjrc + mlc;

	      if (abs (M) <= J)
		{
		  const double CG = Clebsch_Gordan (lc , mlc , jrc , mjrc , J , M) , CG2 = CG * CG;

		  angular_weights_tab_for_density (ic) += CG2;
		}
	    }
	}
    }
}










void CC_rotor_states_class::subangular_tab_for_density_nuclear_calc_static_core (
										 const class array<double> &PYlm_tab ,
										 class array<double> &sub_angular_tab) const
{
  if (potential != DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::subangular_tab_for_density_nuclear_calc_static_core: static core only");
  
  sub_angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();
      
      for (unsigned int i_msc = 0 ; i_msc <= 1 ; i_msc++)
	{
	  const double msc = -0.5 + i_msc;

	  const int mlc = make_int (K_static - msc);

	  if (abs (mlc) <= lc)
	    {
	      for (unsigned int it = 0 ; it < Nt ; it++) sub_angular_tab (ic , i_msc , it) = Clebsch_Gordan (lc , mlc , 0.5 , msc , jc , K_static) * PYlm_tab (lc , abs (mlc) , it);
	    }
	}
    }
}








void CC_rotor_states_class::angular_tabs_density_nuclear_calc_static_core (
									   const class array<double> &PYlm_tab ,
									   class array<double> &angular_tab) const
{
  if (potential != DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::angular_tabs_density_nuclear_calc_static_core: static core only");
  
  // angular terms calculations for all angles (part I)
  // sub_angular_tab (c,mjc,msc,theta) = <lc,K-msc,1/2,msc|jc,mjc> Y^l_{K-msc} (theta)
  // The (-1)^(K-msc) phase for K-msc < 0 in Y^l_{K-msc}(theta) is not considered as it cancels out afterwards.

  class array<double> sub_angular_tab (N_channels , 2 , Nt);

  subangular_tab_for_density_nuclear_calc_static_core (PYlm_tab , sub_angular_tab);

  // angular terms calculations for all angles (part II)
  // angular_tab (c,c',theta) = sum_{mjc,msc} sub_angular_tab (c,mjc,msc,theta) * sub_angular_tab (c',mjc,msc,theta)

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    for (unsigned int icp = 0 ; icp <= ic ; icp++)
      for (unsigned int it = 0 ; it < Nt ; it++)
	angular_tab (ic , icp , it) = angular_tab (icp , ic , it) = sub_angular_tab (ic , 0 , it) * sub_angular_tab (icp , 0 , it) + sub_angular_tab (ic , 1 , it) * sub_angular_tab (icp , 1 , it);
}










void CC_rotor_states_class::subangular_tab_for_density_nuclear_calc_rotating_core (
										   const class array<double> &PYlm_tab ,
										   class array<double> &sub_angular_tab) const
{
  if (potential == DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::subangular_tab_for_density_nuclear_calc_rotating_core: rotating core only");
  
  sub_angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
      const int jrc = channel_c.get_jrc ();

      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();

      const unsigned int N_mjrc = 2*jrc + 1;

      const int mjrc_min = -jrc;

      const unsigned int N_mjc = make_uns_int (2*jc + 1);

      const double mjc_min = -jc;
      
      for (unsigned int i_mjrc = 0 ; i_mjrc < N_mjrc ; i_mjrc++)
	{
	  const int mjrc = mjrc_min + i_mjrc;

	  for (unsigned int i_mjc = 0 ; i_mjc < N_mjc ; i_mjc++)
	    {
	      const double mjc = mjc_min + i_mjc;

	      const double M = mjrc + mjc;

	      if (rint (abs (M) - J) <= 0.0)
		{
		  const double CG = Clebsch_Gordan (jc , mjc , jrc , mjrc , J , M);

		  for (unsigned int i_msc = 0 ; i_msc <= 1 ; i_msc++)
		    {
		      const double msc = -0.5 + i_msc;

		      const int mlc = make_int (mjc - msc);

		      if (abs (mlc) <= lc)
			{
			  for (unsigned int it = 0 ; it < Nt ; it++) sub_angular_tab (ic , i_mjrc , i_mjc , i_msc , it) = CG * Clebsch_Gordan (lc , mlc , 0.5 , msc , jc , mjc) * PYlm_tab (lc , abs (mlc) , it);
			}
		    }
		}
	    }
	}
    }
}








void CC_rotor_states_class::angular_tabs_density_nuclear_calc_rotating_core (
									     const class array<double> &PYlm_tab ,
									     class array<bool> &is_angular_trivial_zero_tab ,
									     class array<double> &angular_tab) const
{
  if (potential == DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::angular_tabs_density_nuclear_calc_rotating_core: rotating core only");
  
  int jrc_max = 0;

  double jc_max = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();

      jrc_max = max (jrc_max , jrc);

      const double jc = channel_c.get_jc ();

      jc_max = max (jc_max , jc);
    }

  const unsigned int N_mjrc_max = 2 * jrc_max + 1;

  const unsigned int N_mjc_max = make_uns_int (2 * jc_max + 1);

  // angular terms calculations for all angles (part I)
  // sub_angular_tab (c,mjrc,mjc,msc,theta) = <jc,mjc,jrc,mjrc|J,M> * <lc,M-mjrc-msc,1/2,msc|jc,mjc> Y^l_{|M-mjrc-msc|} (theta).
  // The (-1)^(M-mjrc-msc) phase for M-mjrc-msc < 0 in Y^l_{M-mjrc-msc}(theta) is not considered as it cancels out afterwards.

  class array<double> sub_angular_tab (N_channels , N_mjrc_max + 1 , N_mjc_max + 1 , 2 , Nt);

  subangular_tab_for_density_nuclear_calc_rotating_core (PYlm_tab , sub_angular_tab);

  // angular terms calculations for all angles (part II)
  // angular_tab (c,c',theta) = sum_{mjrc,mjc,msc} sub_angular_tab (c,mjrc,mjc,msc,theta) * sub_angular_tab (c',mjrc,mjc,msc,theta)

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();

      const double jc = channel_c.get_jc ();

      for (unsigned int icp = 0 ; icp <= ic ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

	  const int jrcp = channel_cp.get_jrc ();

	  if (jrc == jrcp)
	    {
	      const unsigned int N_mjrc = 2*jrc + 1;

	      const int mjrc_min = -jrc;
 
	      const unsigned int N_mjc = make_uns_int (2*jc + 1);

	      const double mjc_min = -jc;

	      for (unsigned int it = 0 ; it < Nt ; it++)
		{
		  for (unsigned int i_mjrc = 0 ; i_mjrc < N_mjrc ; i_mjrc++)
		    {
		      const int mjrc = mjrc_min + i_mjrc;

		      for (unsigned int i_mjc = 0 ; i_mjc < N_mjc ; i_mjc++)
			{
			  const double mjc = mjc_min + i_mjc;

			  const double M = mjrc + mjc;

			  if (rint (abs (M) - J) <= 0.0)
			    {
			      for (unsigned int i_msc = 0 ; i_msc <= 1 ; i_msc++) angular_tab (ic , icp , it) += sub_angular_tab (ic , i_mjrc , i_mjc , i_msc , it) * sub_angular_tab (icp , i_mjrc , i_mjc , i_msc , it);
			    }
			}
		    }
		}
	      is_angular_trivial_zero_tab (ic , icp) = false;
	    }
	}
    }

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      for (unsigned int icp = 0 ; icp < ic ; icp++)
	{
	  is_angular_trivial_zero_tab (icp , ic) = is_angular_trivial_zero_tab (ic , icp);

	  if (!is_angular_trivial_zero_tab (ic , icp))
	    {
	      for (unsigned int i = 0 ; i < Nt ; i++) angular_tab (icp , ic , i) = angular_tab (ic , icp , i);   
	    }
	}
    }
}







void CC_rotor_states_class::angular_weights_tab_for_density_nuclear_calc_rotating_core (class array<double> &angular_weights_tab_for_density) const
{
  if (potential == DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::angular_weights_tab_for_density_nuclear_calc_rotating_core: rotating core only");
  
  // ================================== ================================== //
  // rho_J (r)
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
      const int jrc = channel_c.get_jrc ();
      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();

      const unsigned int N_mjrc = 2*jrc + 1;

      const int mjrc_min = -jrc;

      const unsigned int N_mjc = make_uns_int (2*jc + 1);

      const double mjc_min = -jc;

      for (unsigned int i_mjrc = 0 ; i_mjrc < N_mjrc ; i_mjrc++)
	{
	  const int mjrc = mjrc_min + i_mjrc;

	  for (unsigned int i_mjc = 0 ; i_mjc < N_mjc ; i_mjc++)
	    {
	      const double mjc = mjc_min + i_mjc;

	      const double M = mjrc + mjc;

	      if (rint (abs (M) - J) <= 0.0)
		{
		  const double CG_JM = Clebsch_Gordan (jc , mjc , jrc , mjrc , J , M);

		  const double CG_JM_2 = CG_JM * CG_JM;

		  for (unsigned int i_msc = 0 ; i_msc <= 1 ; i_msc++)
		    {
		      const double msc = -0.5 + i_msc;

		      const int mlc = make_int (mjc - msc);

		      if (abs (mlc) <= lc)
			{
			  const double CG_jmc = Clebsch_Gordan (lc , mlc , 0.5 , msc , jc , mjc);

			  const double CG_jmc_2 = CG_jmc * CG_jmc;

			  angular_weights_tab_for_density (ic) += CG_JM_2 * CG_jmc_2;
			}
		    }
		}
	    }
	}
    }
}





complex<double> CC_rotor_states_class::cylindrical_density_r_theta_bef_R_uniform_calc (
										       const class array<bool> &is_angular_trivial_zero_tab ,
										       const class array<double> &angular_tab , 
										       const unsigned int ir ,
										       const unsigned int it) const
{
  complex<double> density_r_theta = 0.0;

  if (ir == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    {
	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

		  const int lcp = channel_cp.get_lc ();

		  if (lcp == 0) density_r_theta += CC_dwf_bef_R_tab_uniform (ic , 0) * conj (CC_dwf_bef_R_tab_uniform (icp , 0)) * angular_tab (ic , icp , it);
		}
	    }
	}
    }
  else
    {
      const double r = r_bef_R_tab_uniform(ir);

      const double r2 = r * r;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      if (!is_angular_trivial_zero_tab (ic , icp)) density_r_theta += CC_wf_bef_R_tab_uniform (ic , ir) * conj (CC_wf_bef_R_tab_uniform (icp , ir)) * angular_tab (ic , icp , it);
	    }
	}

      density_r_theta /= r2;
    }

  return density_r_theta;
}


complex<double> CC_rotor_states_class::cylindrical_density_r_theta_aft_R_GL_real_calc (
										       const class array<bool> &is_angular_trivial_zero_tab ,
										       const class array<double> &angular_tab , 
										       const unsigned int ir ,
										       const unsigned int it) const
{
  const double r = r_aft_R_tab_GL_real(ir);

  const double r2 = r * r;

  complex<double> density_r_theta = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  if (!is_angular_trivial_zero_tab (ic , icp)) density_r_theta += CC_wf_aft_R_tab_GL_real (ic , ir) * conj (CC_wf_aft_R_tab_GL_real (icp , ir)) * angular_tab (ic , icp , it);
	}
    }

  density_r_theta /= r2;

  return density_r_theta;
}



void CC_rotor_states_class::cylindrical_density_coordinate_calc_store (
								       const string &file_name , 
								       const class array<bool> &is_angular_trivial_zero_tab ,
								       const class array<double> &angular_tab) const
{
  // ================================== ================================== //

  const double theta_step = M_PI/static_cast<double> (Nt - 1);

  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int ir = 0 ; ir < N_bef_R_uniform ; ir++)
    {
      const double r = r_bef_R_tab_uniform(ir);

      for (unsigned int it = 0 ; it < Nt ; it++)
	{
	  const complex<double> density_r_theta = cylindrical_density_r_theta_bef_R_uniform_calc (is_angular_trivial_zero_tab , angular_tab , ir , it);

	  const double theta = it * theta_step;

	  const double r_cyl = r * sin (theta);
	  const double z     = r * cos (theta);

	  outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	  outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;
	}
    }

  for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
    {
      const double r = r_aft_R_tab_GL_real(ir);

      for (unsigned int it = 0 ; it < Nt ; it++)
	{
	  const complex<double> density_r_theta = cylindrical_density_r_theta_aft_R_GL_real_calc (is_angular_trivial_zero_tab , angular_tab , ir , it);

	  const double theta = it * theta_step;

	  const double r_cyl = r * sin (theta);
	  const double z     = r * cos (theta);

	  outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	  outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;
	}
    }
}








complex<double> CC_rotor_states_class::cylindrical_density_k_theta_k_momentum_uniform_calc (
											    const class array<bool> &is_angular_trivial_zero_tab ,
											    const class array<double> &angular_tab , 
											    const unsigned int ik ,
											    const unsigned int it) const
{
  complex<double> density_k_theta_k = 0.0;

  if (ik == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    {
	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

		  const int lcp = channel_cp.get_lc ();

		  if (lcp == 0) density_k_theta_k += CC_dwf_momentum_tab_uniform (ic , 0) * conj (CC_dwf_momentum_tab_uniform (icp , 0)) * angular_tab (ic , icp , it);
		}
	    }
	}
    }
  else
    {
      const double k = k_tab_uniform(ik) , k2 = k * k;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	    {
	      if (!is_angular_trivial_zero_tab (ic , icp))
		density_k_theta_k += CC_wf_momentum_tab_uniform (ic , ik) * conj (CC_wf_momentum_tab_uniform (icp , ik)) * angular_tab (ic , icp , it);
	    }
	}

      density_k_theta_k /= k2;
    }

  return density_k_theta_k;
}




void CC_rotor_states_class::cylindrical_density_momentum_calc_store (
								     const string &file_name , 
								     const class array<bool> &is_angular_trivial_zero_tab ,
								     const class array<double> &angular_tab) const
{
  // ================================== ================================== //

  const double theta_k_step = M_PI/static_cast<double> (Nt - 1);

  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  for (unsigned int ik = 0 ; ik < Nk_momentum_uniform ; ik++)
    {
      const double k = k_tab_uniform(ik);

      for (unsigned int it = 0 ; it < Nt ; it++)
	{
	  const complex<double> density_k_theta_k = cylindrical_density_k_theta_k_momentum_uniform_calc (is_angular_trivial_zero_tab , angular_tab , ik , it);

	  const double theta_k = it * theta_k_step;

	  const double k_cyl = k * sin (theta_k);
	  const double kz    = k * cos (theta_k);

	  outfile << -k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	  outfile <<  k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	}
    }
}







complex<double> CC_rotor_states_class::radial_density_r_bef_R_uniform_calc (
									    const class array<double> &angular_weights_tab_for_density ,
									    const unsigned int ir) const
{
  complex<double> density_radial_r = 0.0;

  if (ir == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0) density_radial_r += CC_dwf_bef_R_tab_uniform (ic , 0) * conj (CC_dwf_bef_R_tab_uniform (ic , 0)) * angular_weights_tab_for_density (ic);
	}
    }
  else
    {
      const double r = r_bef_R_tab_uniform(ir);

      const double r2 = r * r;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	density_radial_r += CC_wf_bef_R_tab_uniform (ic , ir) * conj (CC_wf_bef_R_tab_uniform (ic , ir)) * angular_weights_tab_for_density (ic);

      density_radial_r /= r2;
    }

  return density_radial_r;
}




complex<double> CC_rotor_states_class::radial_density_r_aft_R_GL_real_calc (
									    const class array<double> &angular_weights_tab_for_density ,
									    const unsigned int ir) const
{
  const double r = r_aft_R_tab_GL_real(ir);

  const double r2 = r * r;

  complex<double> density_radial_r = 0.0;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    density_radial_r += CC_wf_aft_R_tab_GL_real (ic , ir) * conj (CC_wf_aft_R_tab_GL_real (ic , ir)) * angular_weights_tab_for_density (ic);
  
  density_radial_r /= r2;

  return density_radial_r;
}




void CC_rotor_states_class::radial_density_calc_store (
						       const string &file_name ,
						       const class array<double> &angular_weights_tab_for_density) const
{
  ofstream outfile_radial (file_name.c_str ());

  outfile_radial.precision (15);

  for (unsigned int ir = 0 ; ir < N_bef_R_uniform ; ir++)
    {
      const double r = r_bef_R_tab_uniform(ir);

      const complex<double> density_radial_r = radial_density_r_bef_R_uniform_calc (angular_weights_tab_for_density , ir);

      outfile_radial << r << " " << real (density_radial_r) << endl;
    }

  for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
    {
      const double r = r_aft_R_tab_GL_real(ir);

      const complex<double> density_radial_r = radial_density_r_aft_R_GL_real_calc (angular_weights_tab_for_density , ir);

      outfile_radial << r << " " << real (density_radial_r) << endl;
    }
}










complex<double> CC_rotor_states_class::momentum_density_uniform_calc (
								      const class array<double> &angular_weights_tab_for_density ,
								      const unsigned int ik) const
{
  complex<double> density_momentum_k = 0.0;

  if (ik == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    density_momentum_k += CC_dwf_momentum_tab_uniform (ic , 0) * conj (CC_dwf_momentum_tab_uniform (ic , 0)) * angular_weights_tab_for_density (ic);
	}
    }
  else
    {
      const double k = k_tab_uniform(ik) , k2 = k * k;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	density_momentum_k += CC_wf_momentum_tab_uniform (ic , ik) * conj (CC_wf_momentum_tab_uniform (ic , ik)) * angular_weights_tab_for_density (ic);

      density_momentum_k /= k2;
    }

  return density_momentum_k;
}



void CC_rotor_states_class::momentum_density_calc_store (
							 const string &file_name ,
							 const class array<double> &angular_weights_tab_for_density) const
{
  ofstream outfile_radial (file_name.c_str ());

  outfile_radial.precision (15);

  for (unsigned int ik = 0 ; ik < Nk_momentum_uniform ; ik++)
    {
      const double k = k_tab_uniform(ik);

      const complex<double> density_momentum_k = momentum_density_uniform_calc (angular_weights_tab_for_density , ik);
      
      outfile_radial << k << " " << real (density_momentum_k) << endl;
    }
}













void CC_rotor_states_class::density_calc_store (const string &debut_file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::density_calc_store: S matrix poles only");

  cout << "=======================================================================" << endl;
  cout << "CC_rotor_states_class: calculation and storage of density (static core)" << endl;
  cout << "=======================================================================" << endl << endl;

  // initialization

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const double theta_step = M_PI/static_cast<double> (Nt - 1);

  // ================================== ================================== //
  
  const int lc_max = lc_max_calc ();

  class array<double> cos_theta_tab (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) cos_theta_tab (it) = cos (it * theta_step);

  class array<double> PYlm_tab (lc_max + 1 , lc_max + 1 , Nt);

  spherical_harmonics::PYlm_tables_calc (cos_theta_tab , PYlm_tab);

  // common to all cases
  class array<double> angular_tab (N_channels , N_channels , Nt);

  class array<bool> is_angular_trivial_zero_tab (N_channels , N_channels);
  
  class array<double> angular_weights_tab_for_density (N_channels);

  // ================================== ================================== //

  if (potential == DEFORMED_WS_STATIC)
    {
      angular_tab = 0.0;
      
      angular_weights_tab_for_density = 1.0;
  
      is_angular_trivial_zero_tab = false;      
      
      if (calc_type == NUCLEAR_ONE_STATE)
	angular_tabs_density_nuclear_calc_static_core (PYlm_tab , angular_tab);
      else
	error_message_print_abort ("CC_rotor_states_class::density_calc_store: bad calc type (static core)");
    }
  else
    {
      angular_tab = 0.0;
      
      angular_weights_tab_for_density = 0.0;
      
      is_angular_trivial_zero_tab = true;
  
      if (calc_type == MOLECULAR) 
	angular_tabs_density_molecular_calc (PYlm_tab , is_angular_trivial_zero_tab , angular_weights_tab_for_density , angular_tab);
      else if (calc_type == NUCLEAR_ONE_STATE)
	{
	  angular_tabs_density_nuclear_calc_rotating_core (PYlm_tab , is_angular_trivial_zero_tab , angular_tab);

	  angular_weights_tab_for_density_nuclear_calc_rotating_core (angular_weights_tab_for_density);
	}
      else
	error_message_print_abort ("CC_rotor_states_class::density_calc_store: bad calc type (rotating core)");
    }

  // ================================== ================================== //
  
  cylindrical_density_coordinate_calc_store (debut_file_name + "_cylindrical_coordinate.dat" , is_angular_trivial_zero_tab , angular_tab);
  cylindrical_density_momentum_calc_store   (debut_file_name + "_cylindrical_momentum.dat"   , is_angular_trivial_zero_tab , angular_tab);

  radial_density_calc_store   (debut_file_name + "_radial.dat" , angular_weights_tab_for_density);
  momentum_density_calc_store (debut_file_name + "_momentum.dat"   , angular_weights_tab_for_density);
}











void CC_rotor_states_class::angular_tab_intrinsic_density_molecular_calc (
									  const class array<double> &PYlm_tab ,
									  class array<double> &angular_tab) const
{
  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();
        
  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();

  const int J_integer = make_int (J);
    
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  class array<double> sub_angular_tab (N_channels , N_Kmax_all_channels + 1 , Nt);
  
  // ================================== ================================== //
  // angular terms calculations for all angles (part I)
  // sub_angular_tab (c,K,theta) = sqrt{ (2*jrc+1)/(2*J+1) } * <lc,K,jrc,0|J,K> * Y^l_{K} (theta)
  
  sub_angular_tab = 0.0;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();
      
      const int lc = channel_c.get_lc ();
      
      const int Kmax = min (lc , J_integer);

      const unsigned int N_Kmax = make_uns_int (Kmax - Kmin_all_channels + 1);
      
      const double hats = hat (jrc) / hat (J_integer);
      //const double hats = sqrt (8.0 * M_PI * M_PI) / hat (J_integer);
      
      for (unsigned int iK = 0 ; iK < N_Kmax ; iK++)
	{
	  const int K = Kmin_all_channels + iK;

	  const double hats_CG_prod = hats*Clebsch_Gordan (lc , K , jrc , 0 , J_integer , K);
	  
	  for (unsigned int it = 0 ; it < Nt ; it++) sub_angular_tab (ic , iK , it) = hats_CG_prod * PYlm_tab (lc , make_int (K) , it);
	}
    }

  // ================================== ================================== //
  // angular terms calculations for all angles (part II)
  // angular_tab (c,c',theta,K) = 2 * sub_ang (c,K,theta) * sub_ang (c',K,theta) (except K = 0 special case)
  
  angular_tab = 0.0;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
      const int lc = channel_c.get_lc ();

      const int Kmax = min (lc , J_integer);
      
      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);
	  
	  const int lcp = channel_cp.get_lc ();
	  
	  const int Kmax_p = min (lcp , J_integer);
	  
	  const int Kmax_tot = min (Kmax , Kmax_p);
	  
	  const unsigned int N_Kmax_tot = make_uns_int (Kmax_tot - Kmin_all_channels + 1);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      // K = 0 case
	      angular_tab (ic , icp , it , 0) = sub_angular_tab (ic , 0 , it) * sub_angular_tab (icp , 0 , it);
	      
	      // K != 0 (degeneracy because of the axial symmetry)
	      for (unsigned int iK = 1 ; iK < N_Kmax_tot ; iK++) angular_tab (ic , icp , it , iK) = 2.0 * sub_angular_tab (ic , iK , it) * sub_angular_tab (icp , iK , it);
	    }
	}
    }
}






complex<double> CC_rotor_states_class::cylindrical_intrinsic_density_K_r_theta_bef_R_uniform_calc (
												   const class array<double> &angular_tab , 
												   const unsigned int iK ,
												   const unsigned int ir ,
												   const unsigned int it) const
{
  complex<double> density_r_theta = 0.0;

  if (ir == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    {
	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

		  const int lcp = channel_cp.get_lc ();

		  if (lcp == 0) density_r_theta += angular_tab (ic , icp , 0 , iK) * CC_dwf_bef_R_tab_uniform (ic , 0) * conj (CC_dwf_bef_R_tab_uniform (icp , 0));
		}
	    }
	}
    }
  else
    {
      const double r = r_bef_R_tab_uniform(ir);

      const double r2 = r * r;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  density_r_theta += angular_tab (ic , icp , it , iK) * CC_wf_bef_R_tab_uniform (ic , ir) * conj (CC_wf_bef_R_tab_uniform (icp , ir));

      density_r_theta /= r2;
    }

  return density_r_theta;
}






complex<double> CC_rotor_states_class::cylindrical_intrinsic_density_K_r_theta_bef_R_GL_calc (
											      const class array<double> &angular_tab , 
											      const unsigned int iK ,
											      const unsigned int ir ,
											      const unsigned int it) const
{
  complex<double> density_r_theta = 0.0;

  const double r = r_bef_R_tab_GL (ir);

  const double r2 = r * r;
  
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    for (unsigned int icp = 0 ; icp < N_channels ; icp++)
      density_r_theta += angular_tab (ic , icp , it , iK) * CC_wf_bef_R_tab_GL (ic , ir) * conj (CC_wf_bef_R_tab_GL (icp , ir));
  
  density_r_theta /= r2;

  return density_r_theta;
}





complex<double> CC_rotor_states_class::cylindrical_intrinsic_density_K_r_theta_aft_R_GL_real_calc (
												   const class array<double> &angular_tab , 
												   const unsigned int iK ,
												   const unsigned int ir ,
												   const unsigned int it) const
{
  complex<double> density_r_theta = 0.0;

  const double r = r_aft_R_tab_GL_real(ir);

  const double r2 = r * r;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    for (unsigned int icp = 0 ; icp < N_channels ; icp++)
      density_r_theta += angular_tab (ic , icp , it , iK) * CC_wf_aft_R_tab_GL_real (ic , ir) * conj (CC_wf_aft_R_tab_GL_real (icp , ir));
      
  density_r_theta /= r2;

  return density_r_theta;
}





void CC_rotor_states_class::calc_cylindrical_intrinsic_density_coordinate_molecular (
										     const string &debut_file_name , 
										     const class array<double> &angular_tab , 
										     class array<double> &bare_sum_real_densities) const
{
  // ================================== ================================== //
  // calculation of the density
  // ================================== ================================== //

  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();
        
  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();
  
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  const double theta_step = M_PI/static_cast<double> (Nt - 1);

  class array<double> sin_theta_tab_density (Nt);
  class array<double> cos_theta_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) 
    {
      const double theta = it * theta_step;

      sin_theta_tab_density (it) = sin (theta);
      cos_theta_tab_density (it) = cos (theta);
    }

  bare_sum_real_densities = 0.0;

  // sum over all c,c' == (l,l',s,s',jr,jr')
  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      const int K = Kmin_all_channels + iK;

      double bare_sum_real_density = 0.0;

      // open a file for each K index
      const string file_name = debut_file_name + "_K_" + file_name_J_string (K) + ".dat";
      
      ofstream outfile (file_name.c_str ());

      outfile.precision (15);

      // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
      for (unsigned int ir = 0 ; ir < N_bef_R_uniform ; ir++)
	{
	  const double r = r_bef_R_tab_uniform(ir);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double sin_theta = sin_theta_tab_density (it);
	      const double cos_theta = cos_theta_tab_density (it);
	      
	      const double z     = r * cos_theta;	      
	      const double r_cyl = r * sin_theta;
	      
	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_bef_R_uniform_calc (angular_tab , iK , ir , it);

	      outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	      outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;

	      bare_sum_real_density += real (density_r_theta);
	    }
	}

      for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
	{
	  const double r = r_aft_R_tab_GL_real(ir);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double sin_theta = sin_theta_tab_density (it);
	      const double cos_theta = cos_theta_tab_density (it);
	      
	      const double z     = r * cos_theta;	      
	      const double r_cyl = r * sin_theta;
	      
	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_aft_R_GL_real_calc (angular_tab , iK , ir , it);

	      outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	      outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;

	      bare_sum_real_density += real (density_r_theta);
	    }
	}

      bare_sum_real_densities (iK) = bare_sum_real_density;
    }
}





complex<double> CC_rotor_states_class::cylindrical_intrinsic_density_K_momentum_uniform_calc (
											      const class array<double> &angular_tab , 
											      const unsigned int iK ,
											      const unsigned int ik ,
											      const unsigned int it) const
{
  complex<double> density_k_theta_k = 0.0;

  if (ik == 0)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    {
	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

		  const int lcp = channel_cp.get_lc ();

		  if (lcp == 0) density_k_theta_k += angular_tab (ic , icp , 0 , iK) * CC_dwf_bef_R_tab_uniform (ic , 0) * conj (CC_dwf_bef_R_tab_uniform (icp , 0));
		}
	    }
	}
    }
  else
    {
      const double k = k_tab_uniform(ik) , k2 = k * k;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	  density_k_theta_k += angular_tab (ic , icp , it , iK) * CC_wf_bef_R_tab_uniform (ic , ik) * conj (CC_wf_bef_R_tab_uniform (icp , ik));

      density_k_theta_k /= k2;
    }

  return density_k_theta_k;
}


void CC_rotor_states_class::calc_cylindrical_intrinsic_density_momentum_molecular (
										   const string &debut_file_name , 
										   const class array<double> &angular_tab) const
{
  // ================================== ================================== //
  // calculation of the density
  // ================================== ================================== //

  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();
        
  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();
  
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  const double theta_k_step = M_PI/static_cast<double> (Nt - 1);

  class array<double> sin_theta_k_tab_density (Nt);
  class array<double> cos_theta_k_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) 
    {
      const double theta_k = it * theta_k_step;

      sin_theta_k_tab_density (it) = sin (theta_k);
      cos_theta_k_tab_density (it) = cos (theta_k);
    }

  // sum over all c,c' == (l,l',s,s',jr,jr')
  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      const int K = Kmin_all_channels + iK;

      // open a file for each K index
      const string file_name = debut_file_name + "_K_" + file_name_J_string (K) + ".dat";
      
      ofstream outfile (file_name.c_str ());

      outfile.precision (15);

      // sum_{c,c'} angular_tab (c,c',theta_k,K) * u_c (r) * u_{c'}* (r)
      for (unsigned int ik = 0 ; ik < Nk_momentum_uniform ; ik++)
	{
	  const double k = k_tab_uniform(ik);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double sin_theta_k = sin_theta_k_tab_density (it);
	      const double cos_theta_k = cos_theta_k_tab_density (it);
	      
	      const double kz    = k * cos_theta_k;	      
	      const double k_cyl = k * sin_theta_k;
	      
	      const complex<double> density_k_theta_k = cylindrical_intrinsic_density_K_momentum_uniform_calc (angular_tab , iK , ik , it);

	      outfile << -k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	      outfile <<  k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	    }
	}
    }
}










void CC_rotor_states_class::angular_tab_partial_density_integrated_molecular_calc (class array<double> &partial_density_integrated_angular_tab) const
{
  // angular part

  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();

  const int J_integer = make_int (J);

  partial_density_integrated_angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();
      
      const int lc = channel_c.get_lc ();
      
      const int Kmax = min (lc , J_integer);

      const unsigned int N_Kmax = make_uns_int (Kmax - Kmin_all_channels + 1);

      const double hats = hat (jrc) / hat (J);

      // angular terms
      for (unsigned int iK = 0 ; iK < N_Kmax ; iK++)
	{
	  const int K = Kmin_all_channels + iK;

	  const double CG_K = Clebsch_Gordan (lc , K , jrc , 0 , J , K);

	  const double hats_CG_prod = hats * hats * CG_K * CG_K;

	  partial_density_integrated_angular_tab (ic , iK) += hats_CG_prod;
	}
    }
}











void CC_rotor_states_class::integrated_real_densities_molecular_calc (
								      const class array<double> &angular_tab ,
								      class array<double> &integrated_real_densities) const
{ 
  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();
        
  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();
    
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  // ================================== ================================== //
  class array<double> cos_theta_tab_density_GL (Nt);
  class array<double> w_cos_theta_tab_density_GL (Nt);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , cos_theta_tab_density_GL , w_cos_theta_tab_density_GL);

  integrated_real_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      for (unsigned int ir = 0 ; ir < N_bef_R_GL ; ir++)
	{
	  const double w_r = w_bef_R_tab_GL (ir);

	  // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double w_cos_theta = w_cos_theta_tab_density_GL (it);

	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_bef_R_GL_calc (angular_tab , iK , ir , it);

	      integrated_real_densities (iK) += real (density_r_theta) * w_r * w_cos_theta;
	    }
	}

      // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
      for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
	{
	  const double w_r = w_aft_R_tab_GL_real (ir);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double w_cos_theta = w_cos_theta_tab_density_GL (it);

	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_aft_R_GL_real_calc (angular_tab , iK , ir , it);

	      integrated_real_densities (iK) += real (density_r_theta) * w_r * w_cos_theta;
	    }
	}
    }
}













void CC_rotor_states_class::partial_density_integrated_molecular_calc (
								       const class array<complex<double> > &Gamow_squared_norms ,
								       const class array<double> &angular_tab , 
								       class array<double> &bare_sum_real_densities) const
{
  // ================================== ================================== //
  // calculation of n_{ J , K_J } = int_0^oo r^2 dr int_0^pi sin_t d_t rho_{ J , K_J } (r,t)
  // exact formula from analytical integration: sum_c (2jrc+1)/(2J+1) <l,K,jr,0|J,K>^2 n_c
  // ================================== ================================== //

  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();
        
  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();
    
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  class array<double> partial_density_integrated_angular_tab (N_channels + 1 , N_Kmax_all_channels + 1);
  
  angular_tab_partial_density_integrated_molecular_calc (partial_density_integrated_angular_tab);

  // calc and print n_J_KJ

  ofstream out_file_n_J_KJ ("n_J_KJ_file");

  out_file_n_J_KJ.precision (15);

  class array<double> real_n_J_KJ_tab (N_Kmax_all_channels + 1);
  class array<double> imag_n_J_KJ_tab (N_Kmax_all_channels + 1);

  real_n_J_KJ_tab = 0.0;
  imag_n_J_KJ_tab = 0.0;

  const unsigned int N_Kmax_tot = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  double sum_real_n_J_KJ = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_tot ; iK++)
    {
      // n_J_KJ
      complex<double> n_J_KJ = 0.0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) n_J_KJ += partial_density_integrated_angular_tab (ic , iK) * Gamow_squared_norms (ic);

      real_n_J_KJ_tab (iK) = abs (real (n_J_KJ));

      imag_n_J_KJ_tab (iK) = imag (n_J_KJ);

      sum_real_n_J_KJ += real_n_J_KJ_tab (iK);
    }

  out_file_n_J_KJ << "Exact formula : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_tot ; iK++)
    {
      const int K = Kmin_all_channels + iK;

      // K , renormalized real (n_J_KJ) in percents, imag (n_J_KJ) just to see
      // the normalization is useless since it is normalized by definition
      out_file_n_J_KJ << K << " " << 100.0 * real_n_J_KJ_tab (iK) / sum_real_n_J_KJ << " " << real_n_J_KJ_tab (iK) << " " << imag_n_J_KJ_tab (iK) << endl;
    }


  // ================================== ================================== //
  // estimate of the n_J_KJ by summation of the rho (r_cyl , z)
  // ================================== ================================== //
  double total_bare_sum_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) total_bare_sum_densities += bare_sum_real_densities (iK);

  bare_sum_real_densities /= total_bare_sum_densities;

  out_file_n_J_KJ << "Estimation : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) out_file_n_J_KJ << Kmin_all_channels + iK << " " << bare_sum_real_densities (iK) * 100.0 << endl;


  // ================================== ================================== //
  // brute calculation of the n_J_KJ by integrating the density over r and theta
  // ================================== ================================== //

  // ================================== ================================== //
  // calculation of the density
  // sum over all c,c' == (l,l',s,s',jr,jr')
  class array<double> integrated_real_densities (N_Kmax_all_channels + 1);

  integrated_real_densities_molecular_calc (angular_tab , integrated_real_densities);

  double total_integrated_real_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) total_integrated_real_densities += integrated_real_densities (iK);

  out_file_n_J_KJ << "Direct integration of rho (r_cyl,z) : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) out_file_n_J_KJ << Kmin_all_channels + iK << " " << integrated_real_densities (iK) / total_integrated_real_densities * 100.0 << endl;
}














void CC_rotor_states_class::intrinsic_density_calc_store_rotating_core_molecular (
										  const string &debut_file_name , 
										  const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  // norm of each channel
  class array<complex<double> > Gamow_squared_norms (N_channels + 1);

  Gamow_squared_norms_calc (CC_rotor_all_data , Gamow_squared_norms);

  const double theta_step = M_PI/static_cast<double> (Nt - 1);
  
  // ================================== ================================== //
  // lc_max and Kmax_all_channels determination

  const int lc_max = lc_max_calc ();

  const int Kmin_all_channels = Kmin_all_channels_molecular_determine ();

  const int Kmax_all_channels = Kmax_all_channels_molecular_calc ();

  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  // ================================== ================================== //

  // ================================== ================================== //
  // spherical harmonics calculations for all angles

  class array<double> cos_theta_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) cos_theta_tab_density (it) = cos (it * theta_step);

  class array<double> PYlm_tab (lc_max + 1 , N_Kmax_all_channels + 1 , Nt);
  
  spherical_harmonics::PYlm_tables_calc (cos_theta_tab_density , PYlm_tab);
  
  class array<double> angular_tab (N_channels , N_channels , Nt , N_Kmax_all_channels + 1);

  // for the estimate of the n_J_KJ
  class array<double> bare_sum_real_densities (N_Kmax_all_channels + 1);

  angular_tab_intrinsic_density_molecular_calc (PYlm_tab , angular_tab);

  calc_cylindrical_intrinsic_density_coordinate_molecular (debut_file_name + "_coordinate_" , angular_tab , bare_sum_real_densities);
  
  partial_density_integrated_molecular_calc (Gamow_squared_norms , angular_tab , bare_sum_real_densities);
  
  calc_cylindrical_intrinsic_density_momentum_molecular (debut_file_name + "_momentum_" , angular_tab);
}












void CC_rotor_states_class::angular_tab_intrinsic_density_nuclear_calc (
									const class array<double> &PYlm_tab ,
									class array<double> &angular_tab) const
{
  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();

  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();

  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  const unsigned int N_ks_max = 2;

  class array<double> sub_angular_tab (N_channels + 1 , N_Kmax_all_channels + 1 , N_ks_max + 1 , Nt);

  // ================================== ================================== //
  // angular terms calculations for all angles (part I)
  // sub_angular_tab (c,K,ks,theta) = sqrt{ (2*jrc+1)/(2*J+1) } * <jc,K,jrc,0|J,K> * <lc,K-ks,0.5,ks|jc,K> Y^l_{K-ks} (theta)

  sub_angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
      const int jrc = channel_c.get_jrc ();

      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();

      const double Kmin = 0.5;
      const double Kmax = min (jc , J);
      
      const unsigned int N_Kmax = make_uns_int (Kmax - Kmin + 1);

      const double hats = hat (jrc) / hat (J);

      for (unsigned int iK = 0 ; iK < N_Kmax ; iK++)
	{
	  const double K = Kmin + iK;

	  const double hats_CG_prod = hats*Clebsch_Gordan (jc , K , jrc , 0 , J , K);

	  for (unsigned int iks = 0 ; iks < N_ks_max ; iks++)
	    {
	      const double ks = -0.5 + iks;

	      for (unsigned int it = 0 ; it < Nt ; it++) sub_angular_tab (ic , iK , iks , it) = hats_CG_prod * Clebsch_Gordan (lc , make_int (K - ks) , 0.5 , ks , jc , K) * PYlm_tab (lc , make_int (K - ks) , it);
	    }
	}
    }


  // ================================== ================================== //
  // angular terms calculations for all angles (part II)
  // angular_tab (c,c',theta,K) = 2 * sum_{ks} sub_angular_tab (c,K,ks,theta) * sub_angular_tab (c',K,ks,theta)

  angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const double jc = channel_c.get_jc ();

      const double Kmax = min (jc , J);

      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
	{
	  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

	  const double jcp = channel_cp.get_jc ();

	  const double Kmax_p = min (jcp , J);

	  const double Kmin_tot = 0.5;
	  const double Kmax_tot = min (Kmax , Kmax_p);

	  const unsigned int N_Kmax_tot = make_uns_int (Kmax_tot - Kmin_tot + 1);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      for (unsigned int iK = 0 ; iK < N_Kmax_tot ; iK++)
		{
		  //const double K = Kmin_tot + iK;
		  // degeneracy -K/K, K!=0 always because of s=1/2

		  for (unsigned int iks = 0 ; iks < N_ks_max ; iks++) angular_tab (ic , icp , it , iK) += 2.0 * sub_angular_tab (ic , iK , iks , it) * sub_angular_tab (icp , iK , iks , it);
		}
	    }
	}
    }
}













void CC_rotor_states_class::calc_cylindrical_intrinsic_density_coordinate_nuclear (
										   const string &debut_file_name , 
										   const class array<double> &angular_tab , 
										   class array<double> &bare_sum_real_densities) const
{
  // ================================== ================================== //
  // calculation of the density
  // ================================== ================================== //

  // for the estimate of the n_J_KJ

  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();
        
  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();
    
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  const double theta_step = M_PI/static_cast<double> (Nt - 1);

  class array<double> sin_theta_tab_density (Nt);
  class array<double> cos_theta_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) 
    {
      const double theta = it * theta_step;

      sin_theta_tab_density (it) = sin (theta);
      cos_theta_tab_density (it) = cos (theta);
    }

  bare_sum_real_densities = 0.0;

  // sum over all c,c' == (l,l',s,s',jr,jr')
  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      double bare_sum_real_density = 0.0;

      const double K = Kmin_all_channels + iK;

      // open a file for each K index
      const string file_name = debut_file_name + "_K_" + file_name_J_string (K) + ".dat";

      ofstream outfile (file_name.c_str ());

      outfile.precision (15);

      for (unsigned int ir = 0 ; ir < N_bef_R_uniform ; ir++)
	{
	  const double r = r_bef_R_tab_uniform(ir);

	  // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double cos_theta = cos_theta_tab_density (it);
	      const double sin_theta = sin_theta_tab_density (it);

	      const double z     = r * cos_theta;
	      const double r_cyl = r * sin_theta;

	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_bef_R_uniform_calc (angular_tab , iK , ir , it);

	      outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	      outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;

	      bare_sum_real_density += real (density_r_theta);
	    }
	}

      // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
      for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
	{
	  const double r = r_aft_R_tab_GL_real(ir);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double cos_theta = cos_theta_tab_density (it);
	      const double sin_theta = sin_theta_tab_density (it);

	      const double z     = r * cos_theta;
	      const double r_cyl = r * sin_theta;

	      const complex<double> density_r_theta = cylindrical_intrinsic_density_K_r_theta_aft_R_GL_real_calc (angular_tab , iK , ir , it);

	      outfile << -r_cyl << " " << z << " " << real (density_r_theta) << endl;
	      outfile <<  r_cyl << " " << z << " " << real (density_r_theta) << endl;

	      bare_sum_real_density += real (density_r_theta);
	    }
	}

      bare_sum_real_densities (iK) = bare_sum_real_density;
    }
}










void CC_rotor_states_class::calc_cylindrical_intrinsic_density_momentum_nuclear (
										 const string &debut_file_name , 
										 const class array<double> &angular_tab) const
{
  // ================================== ================================== //
  // calculation of the density
  // ================================== ================================== //

  // for the estimate of the n_J_KJ

  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();
        
  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();
    
  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  const double theta_k_step = M_PI/static_cast<double> (Nt - 1);

  class array<double> sin_theta_k_tab_density (Nt);
  class array<double> cos_theta_k_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) 
    {
      const double theta_k = it * theta_k_step;

      sin_theta_k_tab_density (it) = sin (theta_k);
      cos_theta_k_tab_density (it) = cos (theta_k);
    }

  // sum over all c,c' == (l,l',s,s',jr,jr')
  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      const double K = Kmin_all_channels + iK;

      // open a file for each K index
      const string file_name = debut_file_name + "_K_" + file_name_J_string (K) + ".dat";

      ofstream outfile (file_name.c_str ());

      outfile.precision (15);

      for (unsigned int ik = 0 ; ik < Nk_momentum_uniform ; ik++)
	{
	  const double k = k_tab_uniform(ik);

	  // sum_{c,c'} angular_tab (c,c',theta_k,K) * u_c (r) * u_{c'}* (r)
	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double cos_theta_k = cos_theta_k_tab_density (it);
	      const double sin_theta_k = sin_theta_k_tab_density (it);

	      const double kz    = k * cos_theta_k;
	      const double k_cyl = k * sin_theta_k;

	      const complex<double> density_k_theta_k = cylindrical_intrinsic_density_K_momentum_uniform_calc (angular_tab , iK , ik , it);

	      outfile << -k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	      outfile <<  k_cyl << " " << kz << " " << real (density_k_theta_k) << endl;
	    }
	}
    }
}













void CC_rotor_states_class::angular_tab_partial_density_integrated_nuclear_calc (class array<double> &partial_density_integrated_angular_tab) const
{
  const unsigned int N_ks_max = 2;

  partial_density_integrated_angular_tab = 0.0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
      const int jrc = channel_c.get_jrc ();

      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();

      const double Kmin = 0.5;
      const double Kmax = min (jc , J);

      const unsigned int N_Kmax = make_uns_int (Kmax - Kmin + 1);

      const double hats = hat (jrc) / hat (J);

      // angular terms
      for (unsigned int iK = 0 ; iK < N_Kmax ; iK++)
	{
	  const double K = Kmin + iK;

	  const double CG_K = Clebsch_Gordan (jc , K , jrc , 0 , J , K);

	  const double hats_CG_prod = hats * hats * CG_K * CG_K;

	  //const double K = Kmin_tot + iK;
	  // degeneracy -K/K, K!=0 always because of s=1/2
	  for (unsigned int iks = 0 ; iks < N_ks_max ; iks++)
	    {
	      const double ks = -0.5 + iks;

	      const double CG_K_minus_ks = Clebsch_Gordan (lc , make_int (K - ks) , 0.5 , ks , jc , K);

	      // factor 2 because of theta

	      partial_density_integrated_angular_tab (ic , iK) += 2.0 * hats_CG_prod * CG_K_minus_ks * CG_K_minus_ks;
	    }
	}
    }
}












void CC_rotor_states_class::integrated_real_densities_nuclear_calc (
								    const class array<double> &angular_tab_GL ,
								    class array<double> &integrated_real_densities) const
{ 
  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();

  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();

  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  class array<double> cos_theta_tab_density_GL (Nt);
  
  class array<double> w_cos_theta_tab_density_GL (Nt);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , cos_theta_tab_density_GL , w_cos_theta_tab_density_GL);

  integrated_real_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++)
    {
      complex<double> density_zero = 0.0;

      // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (0) * u_{c'}* (0)
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const int lc = channel_c.get_lc ();

	  if (lc == 0)
	    {
	      for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		{
		  const class CC_rotor_channel_class &channel_cp = channels_tab(icp);

		  const int lcp = channel_cp.get_lc ();

		  if (lcp == 0) density_zero += angular_tab_GL (ic , icp , 0 , iK) * CC_dwf_bef_R_tab_uniform (ic , 0) * conj (CC_dwf_bef_R_tab_uniform (icp , 0));
		}
	    }
	}

      double w_bef_R_tab_GL_0 = w_bef_R_tab_GL (0);

      double w_cos_theta = w_cos_theta_tab_density_GL (0);

      integrated_real_densities (iK) += real (density_zero) * w_bef_R_tab_GL_0 * w_cos_theta;

      for (unsigned int ir = 1 ; ir < N_bef_R_GL ; ir++)
	{
	  const double r = r_bef_R_tab_GL (ir);

	  const double r2 = r * r;

	  const double w_r = w_bef_R_tab_GL (ir);

	  // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double w_cos_theta = w_cos_theta_tab_density_GL (it);

	      complex<double> density_r_theta = 0.0;

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		  density_r_theta += angular_tab_GL (ic , icp , it , iK) * CC_wf_bef_R_tab_GL (ic , ir) * conj (CC_wf_bef_R_tab_GL (icp , ir));

	      density_r_theta /= r2;

	      integrated_real_densities (iK) += real (density_r_theta) * w_r * w_cos_theta;
	    }
	}

      // sum_{c,c'} angular_tab (c,c',theta,K) * u_c (r) * u_{c'}* (r)
      for (unsigned int ir = 0 ; ir < N_aft_R_GL ; ir++)
	{
	  const double r = r_aft_R_tab_GL_real(ir);

	  const double r2 = r * r;

	  const double w_r = w_aft_R_tab_GL_real (ir);

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      const double w_cos_theta = w_cos_theta_tab_density_GL (it);

	      complex<double> density_r_theta = 0.0;

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		for (unsigned int icp = 0 ; icp < N_channels ; icp++)
		  density_r_theta += angular_tab_GL (ic , icp , it , iK) * CC_wf_aft_R_tab_GL_real (ic , ir) * conj (CC_wf_aft_R_tab_GL_real (icp , ir));

	      density_r_theta /= r2;

	      integrated_real_densities (iK) += real (density_r_theta) * w_r * w_cos_theta;
	    }
	}
    }
}










void CC_rotor_states_class::partial_density_integrated_nuclear_calc (
								     const class array<complex<double> > &Gamow_squared_norms ,
								     class array<double> &bare_sum_real_densities) const
{
  // ================================== ================================== //
  // calculation of n_{ J , K_J } = int_0^oo r^2 dr int_0^pi sin_t d_t rho_{ J , K_J } (r,t)
  // exact formula from analytical integration
  // ================================== ================================== //

  const int lc_max = lc_max_calc ();

  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();

  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();

  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  // angular part
  class array<double> partial_density_integrated_angular_tab (N_channels + 1 , N_Kmax_all_channels + 1);

  angular_tab_partial_density_integrated_nuclear_calc (partial_density_integrated_angular_tab);
 
  // calc and print n_J_KJ
  ofstream out_file_n_J_KJ ("n_J_KJ_file");

  out_file_n_J_KJ.precision (15);

  class array<double> real_n_J_KJ_tab (N_Kmax_all_channels + 1);
  class array<double> imag_n_J_KJ_tab (N_Kmax_all_channels + 1);

  real_n_J_KJ_tab = 0.0;
  imag_n_J_KJ_tab = 0.0;

  const unsigned int N_Kmax_tot = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  double sum_real_n_J_KJ = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_tot ; iK++)
    {
      // n_J_KJ
      complex<double> n_J_KJ = 0.0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) n_J_KJ += partial_density_integrated_angular_tab (ic , iK) * Gamow_squared_norms (ic);

      real_n_J_KJ_tab (iK) = abs (real (n_J_KJ));
      imag_n_J_KJ_tab (iK) = imag (n_J_KJ);

      sum_real_n_J_KJ += real_n_J_KJ_tab (iK);
    }

  out_file_n_J_KJ << "Exact formula : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_tot ; iK++)
    {
      const double K = Kmin_all_channels + iK;

      // K , renormalized real (n_J_KJ) in percents, imag (n_J_KJ) just to see
      // the normalization is useless since it is normalized by definition
      out_file_n_J_KJ << K << " " << 100.0 * real_n_J_KJ_tab (iK) / sum_real_n_J_KJ << " " << real_n_J_KJ_tab (iK) << " " << imag_n_J_KJ_tab (iK) << endl;
    }


  // ================================== ================================== //
  // estimate of the n_J_KJ by summation of the rho (r_cyl , z)
  // ================================== ================================== //
  double total_bare_sum_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) total_bare_sum_densities += bare_sum_real_densities (iK);

  bare_sum_real_densities /= total_bare_sum_densities;

  out_file_n_J_KJ << "Estimation : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) out_file_n_J_KJ << Kmin_all_channels + iK << " " << bare_sum_real_densities (iK) * 100.0 << endl;

  // ================================== ================================== //
  // brute calculation of the n_J_KJ by integrating the density over r and theta
  // ================================== ================================== //

  // ================================== ================================== //
  class array<double> PYlm_tab_GL (lc_max + 1 , N_Kmax_all_channels + 1 , Nt);

  // ================================== ================================== //
  class array<double> cos_theta_tab_density_GL (Nt);
  class array<double> w_cos_theta_tab_density_GL (Nt);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , cos_theta_tab_density_GL , w_cos_theta_tab_density_GL);

  // ================================== ================================== //
  // spherical harmonics calculations for all angles
  spherical_harmonics::PYlm_tables_calc (cos_theta_tab_density_GL , PYlm_tab_GL);

  class array<double> angular_tab_GL (N_channels , N_channels , Nt , N_Kmax_all_channels + 1);

  angular_tab_intrinsic_density_nuclear_calc (PYlm_tab_GL , angular_tab_GL);

  // ================================== ================================== //
  // calculation of the density
  // sum over all c,c' == (l,l',s,s',jr,jr')

  class array<double> integrated_real_densities (N_Kmax_all_channels + 1);

  integrated_real_densities_nuclear_calc (angular_tab_GL , integrated_real_densities);

  double total_integrated_real_densities = 0.0;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) total_integrated_real_densities += integrated_real_densities (iK);

  out_file_n_J_KJ << "Direct integration of rho (r_cyl,z) : " << endl;

  for (unsigned int iK = 0 ; iK < N_Kmax_all_channels ; iK++) out_file_n_J_KJ << Kmin_all_channels + iK << " " << integrated_real_densities (iK) / total_integrated_real_densities * 100.0 << endl;
}












void CC_rotor_states_class::intrinsic_density_calc_store_rotating_core_nuclear (
										const string &debut_file_name , 
										const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  // norm of each channel
  class array<complex<double> > Gamow_squared_norms (N_channels + 1);

  Gamow_squared_norms_calc (CC_rotor_all_data , Gamow_squared_norms);

  const double theta_step = M_PI/static_cast<double> (Nt - 1);

  // ================================== ================================== //
  // lc_max and Kmax_all_channels determination

  const int lc_max = lc_max_calc ();

  const double Kmin_all_channels = Kmin_all_channels_nuclear_determine ();

  const double Kmax_all_channels = Kmax_all_channels_nuclear_calc ();

  const unsigned int N_Kmax_all_channels = make_uns_int (Kmax_all_channels - Kmin_all_channels) + 1;

  // ================================== ================================== //
  // spherical harmonics calculations for all angles

  class array<double> cos_theta_tab_density (Nt);

  for (unsigned int it = 0 ; it < Nt ; it++) cos_theta_tab_density (it) = cos (it * theta_step);

  class array<double> PYlm_tab (lc_max + 1 , N_Kmax_all_channels + 1 , Nt);

  spherical_harmonics::PYlm_tables_calc (cos_theta_tab_density , PYlm_tab);

  class array<double> angular_tab (N_channels , N_channels , Nt , N_Kmax_all_channels + 1);

  class array<double> bare_sum_real_densities (N_Kmax_all_channels + 1);

  angular_tab_intrinsic_density_nuclear_calc (PYlm_tab , angular_tab);

  calc_cylindrical_intrinsic_density_coordinate_nuclear (debut_file_name + "_coordinate_" , angular_tab , bare_sum_real_densities);

  partial_density_integrated_nuclear_calc (Gamow_squared_norms , bare_sum_real_densities);

  calc_cylindrical_intrinsic_density_momentum_nuclear (debut_file_name + "_momentum_" , angular_tab);
}






void CC_rotor_states_class::intrinsic_density_calc_store_rotating_core (const string &debut_file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (potential == DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_states_class::intrinsic_density_calc_store_rotating_core: rotating core only");
  
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::intrinsic_density_calc_store_rotating_core: S matrix poles only");
    
  cout << "===================================================================================" << endl;
  cout << "CC_rotor_states_class: calculation and storage of intrinsic density (rotating core)" << endl;
  cout << "===================================================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  if (calc_type == MOLECULAR) 
    intrinsic_density_calc_store_rotating_core_molecular (debut_file_name , CC_rotor_all_data);
  else if (calc_type == NUCLEAR_ONE_STATE)
    intrinsic_density_calc_store_rotating_core_nuclear (debut_file_name , CC_rotor_all_data);
  else
    error_message_print_abort ("CC_rotor_states_class::intrinsic_density_calc_store_rotating_core: not defined for spherical potentials (no rotor quantum number)");
}



















void CC_rotor_states_class::BEM_calc_CC_wfs_coordinate_momentum (const class CC_rotor_all_data_class &CC_rotor_all_data)
{ 
  if (!S_matrix_pole) error_message_print_abort ("CC_rotor_states_class::BEM_calc_CC_wfs_coordinate_momentum: S matrix poles only");

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const bool is_asymptotic_wave_function_fit_used = CC_rotor_input.get_is_asymptotic_wave_function_fit_used ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const bool pole_approximation = CC_rotor_input.get_pole_approximation ();

  const unsigned int N_nlj = (pole_approximation) ? (data.get_N_nlj_res ()) : (data.get_N_nlj ());

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells = data.get_shells ();

  CC_wf_dwf_d2wf_zero ();

  for (unsigned int state = 0 ; state < N_nlj ; state++)
    {
      const complex<double> eigenvector_component = eigenvector (state);

      const class nlj_struct &s_qn = shells_qn (state);

      const class spherical_state &shell = shells (state);

      const class array<complex<double> > &wf_bef_R_tab_uniform   = shell.get_wf_bef_R_tab_uniform (); 
      const class array<complex<double> > &dwf_bef_R_tab_uniform  = shell.get_dwf_bef_R_tab_uniform (); 
      const class array<complex<double> > &d2wf_bef_R_tab_uniform = shell.get_d2wf_bef_R_tab_uniform ();

      const class array<complex<double> > &wf_bef_s_tab_GL   = shell.get_wf_bef_s_tab_GL (); 
      const class array<complex<double> > &dwf_bef_s_tab_GL  = shell.get_dwf_bef_s_tab_GL (); 
      const class array<complex<double> > &d2wf_bef_s_tab_GL = shell.get_d2wf_bef_s_tab_GL ();

      const class array<complex<double> > &wf_bef_R_tab_GL   = shell.get_wf_bef_R_tab_GL ();
      const class array<complex<double> > &dwf_bef_R_tab_GL  = shell.get_dwf_bef_R_tab_GL (); 
      const class array<complex<double> > &d2wf_bef_R_tab_GL = shell.get_d2wf_bef_R_tab_GL ();

      const class array<complex<double> > &wf_aft_R_tab_GL_real   = shell.get_wf_aft_R_tab_GL_real (); 
      const class array<complex<double> > &dwf_aft_R_tab_GL_real  = shell.get_dwf_aft_R_tab_GL_real (); 
      const class array<complex<double> > &d2wf_aft_R_tab_GL_real = shell.get_d2wf_aft_R_tab_GL_real ();

      const class array<complex<double> > &wf_aft_R_tab_GL_complex   = shell.get_wf_aft_R_tab_GL_complex (); 
      const class array<complex<double> > &dwf_aft_R_tab_GL_complex  = shell.get_dwf_aft_R_tab_GL_complex (); 
      const class array<complex<double> > &d2wf_aft_R_tab_GL_complex = shell.get_d2wf_aft_R_tab_GL_complex ();

      const class array<complex<double> > &wf_momentum_tab_uniform  = shell.get_wf_momentum_tab_uniform (); 
      const class array<complex<double> > &dwf_momentum_tab_uniform = shell.get_dwf_momentum_tab_uniform (); 

      const class array<complex<double> > &wf_momentum_tab_GL  = shell.get_wf_momentum_tab_GL (); 
      const class array<complex<double> > &dwf_momentum_tab_GL = shell.get_dwf_momentum_tab_GL (); 
      
      const unsigned int ic = s_qn.get_ic ();

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  CC_wf_bef_R_tab_uniform  (ic , i) += eigenvector_component * wf_bef_R_tab_uniform  (i);
	  CC_dwf_bef_R_tab_uniform (ic , i) += eigenvector_component * dwf_bef_R_tab_uniform (i);
	  CC_d2wf_bef_R_tab_uniform(ic , i) += eigenvector_component * d2wf_bef_R_tab_uniform(i);
	}

      if (calc_type == MOLECULAR) 
	{
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    {
	      CC_wf_bef_s_tab_GL  (ic , i) += eigenvector_component * wf_bef_s_tab_GL  (i);
	      CC_dwf_bef_s_tab_GL (ic , i) += eigenvector_component * dwf_bef_s_tab_GL (i);
	      CC_d2wf_bef_s_tab_GL(ic , i) += eigenvector_component * d2wf_bef_s_tab_GL(i);
	    }
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  CC_wf_bef_R_tab_GL  (ic , i) += eigenvector_component * wf_bef_R_tab_GL  (i);
	  CC_dwf_bef_R_tab_GL (ic , i) += eigenvector_component * dwf_bef_R_tab_GL (i);
	  CC_d2wf_bef_R_tab_GL(ic , i) += eigenvector_component * d2wf_bef_R_tab_GL(i);
	}
  
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  CC_wf_aft_R_tab_GL_real  (ic , i) += eigenvector_component * wf_aft_R_tab_GL_real  (i);
	  CC_dwf_aft_R_tab_GL_real (ic , i) += eigenvector_component * dwf_aft_R_tab_GL_real (i);
	  CC_d2wf_aft_R_tab_GL_real(ic , i) += eigenvector_component * d2wf_aft_R_tab_GL_real(i);
	}
    
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  CC_wf_aft_R_tab_GL_complex  (ic , i) += eigenvector_component * wf_aft_R_tab_GL_complex  (i);
	  CC_dwf_aft_R_tab_GL_complex (ic , i) += eigenvector_component * dwf_aft_R_tab_GL_complex (i);
	  CC_d2wf_aft_R_tab_GL_complex(ic , i) += eigenvector_component * d2wf_aft_R_tab_GL_complex(i);
	}
      
      if (kmax_momentum > 0.0)
	{	   
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      CC_wf_momentum_tab_uniform (ic , i) += eigenvector_component * wf_momentum_tab_uniform (i);
	      CC_dwf_momentum_tab_uniform(ic , i) += eigenvector_component * dwf_momentum_tab_uniform(i);
	    }
	      
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      CC_wf_momentum_tab_GL (ic , i) += eigenvector_component * wf_momentum_tab_GL (i);
	      CC_dwf_momentum_tab_GL(ic , i) += eigenvector_component * dwf_momentum_tab_GL(i);
	    } 
	}
    } 
  
  if (is_asymptotic_wave_function_fit_used) asymptotic_fit_tab_from_diagonalization_calc (CC_rotor_all_data);

  if (is_asymptotic_wave_function_fit_used || (potential != DIPOLAR))
    {      
      class array<complex<double> > r_aft_R_tab_GL_real_c(N_aft_R_GL);
      
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) r_aft_R_tab_GL_real_c(i) = r_aft_R_tab_GL_real(i);

      if (potential != DIPOLAR) BEM_Cplus_constants_nuclear_calc ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  class array<complex<double> > CC_wf_aft_R_tab_GL(N_aft_R_GL);
	  class array<complex<double> > CC_dwf_aft_R_tab_GL(N_aft_R_GL);
	  class array<complex<double> > CC_d2wf_aft_R_tab_GL(N_aft_R_GL);

	  complex_scaling_wave_function_after_R_calc (ic , r_aft_R_tab_GL_real_c , CC_wf_aft_R_tab_GL , CC_dwf_aft_R_tab_GL , CC_d2wf_aft_R_tab_GL);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);

	      if (!is_asymptotic_wave_function_fit_used || (r >= rmin_for_fit) || (abs (r - rmin_for_fit) < precision))
		{
		  CC_wf_aft_R_tab_GL_real  (ic , i) = CC_wf_aft_R_tab_GL  (i);
		  CC_dwf_aft_R_tab_GL_real (ic , i) = CC_dwf_aft_R_tab_GL (i);
		  CC_d2wf_aft_R_tab_GL_real(ic , i) = CC_d2wf_aft_R_tab_GL(i);
		}
	    }
	  
	  complex_scaling_wave_function_after_R_calc (ic , r_aft_R_tab_GL_complex , CC_wf_aft_R_tab_GL , CC_dwf_aft_R_tab_GL , CC_d2wf_aft_R_tab_GL);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const complex<double> r = r_aft_R_tab_GL_complex(i);

	      const double real_r = real (r);

	      if (!is_asymptotic_wave_function_fit_used || (real_r >= rmin_for_fit) || (abs (real_r - rmin_for_fit) < precision))
		{
		  CC_wf_aft_R_tab_GL_complex  (ic , i) = CC_wf_aft_R_tab_GL  (i);
		  CC_dwf_aft_R_tab_GL_complex (ic , i) = CC_dwf_aft_R_tab_GL (i);
		  CC_d2wf_aft_R_tab_GL_complex(ic , i) = CC_d2wf_aft_R_tab_GL(i);
		}
	    }
	}
    }
}












class CC_rotor_channel_class & CC_rotor_states_class::lowest_channel_determine () const
{
  unsigned int ic_min = 0;

  double E_Tc_min = INFINITE;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const double E_Tc = channel_c.get_E_Tc ();

      if (E_Tc < E_Tc_min) 
	{
	  E_Tc_min = E_Tc;

	  ic_min = ic;
	}
    }

  return channels_tab(ic_min);
}


bool CC_rotor_states_class::is_it_bound_determine () const
{
  if (!S_matrix_pole) return false;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const complex<double> kc = channel_c.get_kc ();

      if (imag (kc) < precision) return false;
    }

  return true;
}



int CC_rotor_states_class::lc_max_calc () const
{
  int lc_max = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_lc ();

      lc_max = max (lc , lc_max);
    }

  return lc_max;
}





int CC_rotor_states_class::Kmin_all_channels_molecular_determine () const
{
  return 0; //not: ..., -2, -1, 0, 1, ... but: 0, 1, ... because of the degeneracy K/-K
}

double CC_rotor_states_class::Kmin_all_channels_nuclear_determine () const
{
  if (potential == DEFORMED_WS_STATIC)
    return K_static;
  else
    return 0.5; //not: ..., -3/2, -1/2, 1/2, 3/2, ... but: 1/2, 3/2, ... because of the degeneracy K/-K
}




int CC_rotor_states_class::Kmax_all_channels_molecular_calc () const
{
  const int J_integer = make_int (J);

  int Kmax_all_channels = 0;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int lc = channel_c.get_lc ();

      const int Kmax = min (lc , J_integer);

      Kmax_all_channels = max (Kmax , Kmax_all_channels);
    }

  return Kmax_all_channels;
}

double CC_rotor_states_class::Kmax_all_channels_nuclear_calc () const
{
  if (potential == DEFORMED_WS_STATIC)
    return make_int (K_static);
  else
    {
      double Kmax_all_channels = 0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);

	  const double jc = channel_c.get_jc ();
      
	  const double Kmax = min (jc , J);
      
	  Kmax_all_channels = max (Kmax , Kmax_all_channels);
	}

      return Kmax_all_channels;
    }
}





bool CC_rotor_states_class::is_E_here (const class CC_rotor_all_data_class &CC_rotor_all_data , double &E_debut , double &E_end)
{
  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const complex<double> E_init = E;

  const unsigned int N = 100;

  const double dE = (E_end - E_debut)/static_cast<double> (N);

  double E_bef = E_debut;

  change_channels_energy (E_bef);

  complex<double> Jost_det_E_bef = Jost_det_calc (CC_rotor_potential);

  for (unsigned int i = 1 ; i <= N ; i++)
    {
      const double E_aft = E_debut + i * dE;

      change_channels_energy (E_aft);

      const complex<double> Jost_det_E_aft = Jost_det_calc (CC_rotor_potential);

      cout << "E : " << E_aft << " Jost : " << Jost_det_E_aft << endl;

      const double Re_J_bef = real (Jost_det_E_bef) , Im_J_bef = imag (Jost_det_E_bef);
      const double Re_J_aft = real (Jost_det_E_aft) , Im_J_aft = imag (Jost_det_E_aft);

      const bool is_it_real_part = (abs (Re_J_bef) > abs (Im_J_bef));

      const double J_bef = (is_it_real_part)? (Re_J_bef): (Im_J_bef);
      const double J_aft = (is_it_real_part)? (Re_J_aft): (Im_J_aft);

      if (SIGN (J_bef) != SIGN (J_aft))
	{
	  E_debut = E_bef , E_end = E_aft;

	  return true;
	}

      E_bef = E_aft;

      Jost_det_E_bef = Jost_det_E_aft;
    }

  change_channels_energy (E_init);			// if it didn't work.

  return false;
}








void CC_rotor_states_class::E_bisection (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "======================================================" << endl;
  cout << "========= CC_rotor_states_class: E bisection =========" << endl;
  cout << "======================================================" << endl << endl;

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const class CC_rotor_channel_class &lowest_channel = lowest_channel_determine ();

  const double E_Tc_lowest_channel = lowest_channel.get_E_Tc ();

  double bnd_E_debut = E_Tc_lowest_channel - 0.01;
  double bnd_E_end   = E_Tc_lowest_channel - sqrt_precision;//xyz arbitrary

  double res_E_debut = E_Tc_lowest_channel + sqrt_precision;
  double res_E_end   = E_Tc_lowest_channel + 0.01;

  const bool bnd_found = is_E_here (CC_rotor_all_data , bnd_E_debut , bnd_E_end);

  const bool res_found = ((!bnd_found) && (is_E_here (CC_rotor_all_data , res_E_debut , res_E_end)));

  if ((!bnd_found)&& (!res_found))
    {
      cout << "E not found with bisection" << endl;

      is_E_ok = false;

      return;
    }

  double E_debut = 0.0;
  double E_end = 0.0;
  
  if (bnd_found) E_debut = bnd_E_debut , E_end = bnd_E_end;
  if (res_found) E_debut = res_E_debut , E_end = res_E_end;

  change_channels_energy (E_debut);

  complex<double> Jost_det_E_debut = Jost_det_calc (CC_rotor_potential);

  const double Re_J_debut = real (Jost_det_E_debut);
  const double Im_J_debut = imag (Jost_det_E_debut);

  const bool is_it_real_part = (abs (Re_J_debut) > abs (Im_J_debut));

  double J_debut = (is_it_real_part) ? (Re_J_debut) : (Im_J_debut);

  double test;

  do
    {
      const double E_middle = E_debut + 0.5 * (E_end - E_debut);

      change_channels_energy (E_middle);

      const complex<double> Jost_det_E_middle = Jost_det_calc (CC_rotor_potential);

      cout << "E : " << E_middle << " Jost : " << Jost_det_E_middle << endl;

      const double Re_J_middle = real (Jost_det_E_middle);
      const double Im_J_middle = imag (Jost_det_E_middle);

      const double J_middle = (is_it_real_part)? (Re_J_middle): (Im_J_middle);

      if (SIGN (J_debut) != SIGN (J_middle)) 
	E_end = E_middle;
      else 
	{
	  E_debut = E_middle;
	  J_debut = J_middle;
	}

      test = inf_norm (E_debut/E_end - 1.0);
    }
  while (test > precision);

  change_channels_energy (E_debut);

  is_E_ok = true;
}









void CC_rotor_states_class::width_current_formula_calc (const string &file_name , const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  cout << "================================================================" << endl;
  cout << "CC_rotor_states_class: width calculated with the current formula" << endl;
  cout << "================================================================" << endl << endl;

  ofstream outfile (file_name.c_str ());

  outfile.precision (15);

  // ================================== bef_R_uniform ================================== //

  class array<double> CC_wfc_modulus_square_sum_tab_bef_R_uniform (N_bef_R_uniform);

  // calc f (r) = sum_c |u_c (r)|^2 for each r value

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      double CC_wfc_modulus_square_sum = 0.0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) CC_wfc_modulus_square_sum += norm (CC_wf_bef_R_tab_uniform (ic , i));

      CC_wfc_modulus_square_sum_tab_bef_R_uniform (i) = CC_wfc_modulus_square_sum;
    }

  const class splines_class<double> CC_wfc_modulus_square_sum_splines_bef_R_uniform (r_bef_R_tab_uniform , CC_wfc_modulus_square_sum_tab_bef_R_uniform);

  // calc Gamma (r) and Gamma_ (r) using two equivalent current formula

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      // r and f(r)
      const double r = r_bef_R_tab_uniform (i);
      
      const double CC_wfc_modulus_square_sum_integral = CC_wfc_modulus_square_sum_splines_bef_R_uniform.primitive (r);
      
      double Gamma_r = 0.0;
      double Gamma_p_r = 0.0;

      outfile << r << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  const class CC_rotor_channel_class &channel = channels_tab (ic);

	  const double kinetic_factor_c = channel.get_kinetic_factor_c ();

	  // u_c (r) , u_c' (r) and u_c'' (r)
	  const complex<double> CC_wfc_r   = CC_wf_bef_R_tab_uniform   (ic , i); 
	  const complex<double> CC_dwfc_r  = CC_dwf_bef_R_tab_uniform  (ic , i); 
	  const complex<double> CC_d2wfc_r = CC_d2wf_bef_R_tab_uniform (ic , i);

	  // 2 Im (u_c* (r) * u_c' (r)) and Gamma_c (r)
	  const double two_wfc_star_dwfc_imag = 2.0 * imag (conj (CC_wfc_r) * CC_dwfc_r);
	  
	  const double Gamma_cr = two_wfc_star_dwfc_imag/kinetic_factor_c/CC_wfc_modulus_square_sum_integral;

	  Gamma_r += Gamma_cr;

	  // g (r) = sum_cp |u_cp (r)|^2

	  double sum_norm_wfcp = 0.0;

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++) sum_norm_wfcp += norm (CC_wf_bef_R_tab_uniform (icp , i)); 

	  const double two_wfc_star_d2wfc_imag = 2.0 * imag (conj (CC_wfc_r) * CC_d2wfc_r);
	  
	  const double Gamma_p_c_r = two_wfc_star_d2wfc_imag/kinetic_factor_c/sum_norm_wfcp;

	  Gamma_p_r += Gamma_p_c_r;

	  outfile << Gamma_cr << " ";
	}

      if (finite (Gamma_r)) outfile << Gamma_r << " " << CC_wfc_modulus_square_sum_integral << " " << Gamma_p_r << endl;
    }

  // ================================== aft_R_GL_real ================================== //

  class array<double> r_aft_R_tab_GL_real_tab (N_aft_R_GL);
  
  class array<double> CC_wfc_modulus_square_sum_tab_aft_R_GL_real (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      r_aft_R_tab_GL_real_tab (i) = r_aft_R_tab_GL_real (i);

      double CC_wfc_modulus_square_sum = 0.0;

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) CC_wfc_modulus_square_sum += norm (CC_wf_aft_R_tab_GL_real (ic , i));

      CC_wfc_modulus_square_sum_tab_aft_R_GL_real (i) = CC_wfc_modulus_square_sum;
    }

  const double CC_wfc_modulus_square_integral_R = CC_wfc_modulus_square_sum_splines_bef_R_uniform.primitive (R);

  const class splines_class<double> CC_wfc_modulus_square_sum_splines_aft_R_GL_real (r_aft_R_tab_GL_real_tab , CC_wfc_modulus_square_sum_tab_aft_R_GL_real);

  vector<double> vec_Gamma_c_at_R_max (N_channels , 0.0);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double r = r_aft_R_tab_GL_real_tab(i);
      
      const double CC_wfc_modulus_square_sum_integral = CC_wfc_modulus_square_integral_R + CC_wfc_modulus_square_sum_splines_aft_R_GL_real.primitive (r);

      double Gamma_r = 0.0;
      double Gamma_p_r = 0.0;

      outfile << r << " ";

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  const class CC_rotor_channel_class &channel = channels_tab (ic);

	  const double kinetic_factor_c = channel.get_kinetic_factor_c ();

	  const complex<double> CC_wfc_r   = CC_wf_aft_R_tab_GL_real   (ic , i); 
	  const complex<double> CC_dwfc_r  = CC_dwf_aft_R_tab_GL_real  (ic , i); 
	  const complex<double> CC_d2wfc_r = CC_d2wf_aft_R_tab_GL_real (ic , i);

	  const double two_wfc_star_dwfc_imag = 2.0 * imag (conj (CC_wfc_r) * CC_dwfc_r);

	  const double Gamma_cr = two_wfc_star_dwfc_imag/kinetic_factor_c/CC_wfc_modulus_square_sum_integral;

	  Gamma_r += Gamma_cr;

	  double sum_norm_wfcp = 0.0;

	  for (unsigned int icp = 0 ; icp < N_channels ; icp++) sum_norm_wfcp += norm (CC_wf_aft_R_tab_GL_real (icp , i));

	  const double two_wfc_star_d2wfc_imag = 2.0 * imag (conj (CC_wfc_r) * CC_d2wfc_r);

	  const double Gamma_p_c_r = two_wfc_star_d2wfc_imag/kinetic_factor_c/sum_norm_wfcp;

	  Gamma_p_r += Gamma_p_c_r;

	  outfile << Gamma_cr << " ";

	  // store Gamma_c (R_max)
	  if (i == N_channels - 1) vec_Gamma_c_at_R_max[ic] = Gamma_cr;
	}

      if (finite (Gamma_r)) outfile << Gamma_r << " " << CC_wfc_modulus_square_sum_integral << " " << Gamma_p_r << endl;

      // print the total width on screen

      if (i == N_channels - 1)
	{
	  const string length_unit = (CC_rotor_input.get_particle () == ELECTRON) ? ("a0") : ("fm");
	  const string energy_unit = (CC_rotor_input.get_particle () == ELECTRON) ? ("Ry") : ("MeV");

	  cout << "R[max] = " << r << " " << length_unit << " , Psi modulus squared norm = " << CC_wfc_modulus_square_sum_integral << endl;
	  cout << "-----------------------------------------------------------------------------------------" << endl;
	  cout << "Gamma (r) = " << Gamma_r   << " " << energy_unit << " (current formula)" << endl;
	  cout << "Gamma (r) = " << Gamma_p_r << " " << energy_unit << " (alternative current formula)" << endl;
	}
    }

  ofstream outfile_Gamma_c ("out_Gamma_c_at_R_max");

  outfile_Gamma_c.precision (15);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) outfile_Gamma_c << ic << " " << vec_Gamma_c_at_R_max[ic] << endl;
}





//--// return the phase shift associated to a given channel
complex<double> CC_rotor_states_class::get_phase_shift (const unsigned int ic) const
{
  const complex<double> minus_half_I (0.0 , -0.5);
  
  const complex<double> Cplus_c = Cplus_tab(ic);

  const complex<double> phase_shift_c = minus_half_I*log (-Cplus_c);

  return phase_shift_c;
}






double used_memory_calc (const class CC_rotor_states_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.eigenvector) +
    used_memory_calc (T.channels_tab) +
    used_memory_calc (T.r_bef_R_tab_uniform) +
    used_memory_calc (T.k_tab_uniform) +
    used_memory_calc (T.r_bef_s_tab_GL) +
    used_memory_calc (T.w_bef_s_tab_GL) +
    used_memory_calc (T.r_bef_R_tab_GL) +
    used_memory_calc (T.w_bef_R_tab_GL) +
    used_memory_calc (T.r_aft_R_tab_GL_real) +
    used_memory_calc (T.w_aft_R_tab_GL_real) +
    used_memory_calc (T.r_aft_R_tab_GL_complex) +
    used_memory_calc (T.w_aft_R_tab_GL_complex) +
    used_memory_calc (T.u_aft_R_GL) +
    used_memory_calc (T.weights_aft_R_GL) +
    used_memory_calc (T.k_tab_GL) +
    used_memory_calc (T.wk_tab_GL) +
    used_memory_calc (T.CC_wf_bef_R_tab_uniform) +
    used_memory_calc (T.CC_dwf_bef_R_tab_uniform) +
    used_memory_calc (T.CC_d2wf_bef_R_tab_uniform) +
    used_memory_calc (T.CC_wf_bef_s_tab_GL) +
    used_memory_calc (T.CC_dwf_bef_s_tab_GL) +
    used_memory_calc (T.CC_d2wf_bef_s_tab_GL) +
    used_memory_calc (T.CC_wf_bef_R_tab_GL) +
    used_memory_calc (T.CC_dwf_bef_R_tab_GL) +
    used_memory_calc (T.CC_d2wf_bef_R_tab_GL) +
    used_memory_calc (T.CC_wf_aft_R_tab_GL_real) +
    used_memory_calc (T.CC_dwf_aft_R_tab_GL_real) +
    used_memory_calc (T.CC_d2wf_aft_R_tab_GL_real) +
    used_memory_calc (T.CC_wf_aft_R_tab_GL_complex) +
    used_memory_calc (T.CC_dwf_aft_R_tab_GL_complex) +
    used_memory_calc (T.CC_d2wf_aft_R_tab_GL_complex) +
    used_memory_calc (T.CC_wf_momentum_tab_uniform) +
    used_memory_calc (T.CC_dwf_momentum_tab_uniform) +
    used_memory_calc (T.CC_wf_momentum_tab_GL) +
    used_memory_calc (T.CC_dwf_momentum_tab_GL) +
    used_memory_calc (T.C0_tab) +
    used_memory_calc (T.Cplus_tab) +
    used_memory_calc (T.A0_tab) +
    used_memory_calc (T.Aplus_tab) +
    used_memory_calc (T.fwd_basis) +
    used_memory_calc (T.bwd_basis) +
    used_memory_calc (T.asymptotic_fit_tab) +
    used_memory_calc (T.llp1_eff_tab) +
    used_memory_calc (T.l_eff_tab) +
    used_memory_calc (T.asymptotic_channels) +
    used_memory_calc (T.bwd_U_minus)
    - (sizeof (T.eigenvector) +
       sizeof (T.channels_tab) +
       sizeof (T.r_bef_R_tab_uniform) +
       sizeof (T.k_tab_uniform) +
       sizeof (T.r_bef_s_tab_GL) +
       sizeof (T.w_bef_s_tab_GL) +
       sizeof (T.r_bef_R_tab_GL) +
       sizeof (T.w_bef_R_tab_GL) +
       sizeof (T.r_aft_R_tab_GL_real) +
       sizeof (T.w_aft_R_tab_GL_real) +
       sizeof (T.r_aft_R_tab_GL_complex) +
       sizeof (T.w_aft_R_tab_GL_complex) +
       sizeof (T.u_aft_R_GL) +
       sizeof (T.weights_aft_R_GL) +
       sizeof (T.k_tab_GL) +
       sizeof (T.wk_tab_GL) +
       sizeof (T.CC_wf_bef_R_tab_uniform) +
       sizeof (T.CC_dwf_bef_R_tab_uniform) +
       sizeof (T.CC_d2wf_bef_R_tab_uniform) +
       sizeof (T.CC_wf_bef_s_tab_GL) +
       sizeof (T.CC_dwf_bef_s_tab_GL) +
       sizeof (T.CC_d2wf_bef_s_tab_GL) +
       sizeof (T.CC_wf_bef_R_tab_GL) +
       sizeof (T.CC_dwf_bef_R_tab_GL) +
       sizeof (T.CC_d2wf_bef_R_tab_GL) +
       sizeof (T.CC_wf_aft_R_tab_GL_real) +
       sizeof (T.CC_dwf_aft_R_tab_GL_real) +
       sizeof (T.CC_d2wf_aft_R_tab_GL_real) +
       sizeof (T.CC_wf_aft_R_tab_GL_complex) +
       sizeof (T.CC_dwf_aft_R_tab_GL_complex) +
       sizeof (T.CC_d2wf_aft_R_tab_GL_complex) +
       sizeof (T.CC_wf_momentum_tab_uniform) +
       sizeof (T.CC_dwf_momentum_tab_uniform) +
       sizeof (T.CC_wf_momentum_tab_GL) +
       sizeof (T.CC_dwf_momentum_tab_GL) +
       sizeof (T.C0_tab) +
       sizeof (T.Cplus_tab) +
       sizeof (T.A0_tab) +
       sizeof (T.Aplus_tab) +
       sizeof (T.fwd_basis) +
       sizeof (T.bwd_basis) +
       sizeof (T.asymptotic_fit_tab) +
       sizeof (T.llp1_eff_tab) +
       sizeof (T.l_eff_tab) +
       sizeof (T.asymptotic_channels) +
       sizeof (T.bwd_U_minus))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}


