#include "../CC_rotor_include/CC_rotor_include.h"

// Allocation and calculation of the used Hamiltonian potential
// ------------------------------------------------------------


// ================================== constructors ================================== //



CC_rotor_potential_class::CC_rotor_potential_class () : potential (NO_POTENTIAL) {}

CC_rotor_potential_class::CC_rotor_potential_class (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  allocate (CC_rotor_all_data);
}
  
CC_rotor_potential_class::CC_rotor_potential_class (const class CC_rotor_potential_class &X)
{
  allocate_fill (X);
}
    
void CC_rotor_potential_class::allocate (const class CC_rotor_all_data_class &CC_rotor_all_data) 
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  potential = CC_rotor_input.get_potential ();

  switch (potential)
    {
    case DIPOLAR:
      {
	const double J = CC_rotor_input.get_J ();

	dipolar_potential.allocate_calc (
					 CC_rotor_input.get_mu () , CC_rotor_input.get_s () , CC_rotor_input.get_alpha_0 () , CC_rotor_input.get_alpha_2 () , CC_rotor_input.get_r0 () , 
					 CC_rotor_input.get_Qzz () , CC_rotor_input.get_V0 () , CC_rotor_input.get_rc () , J , CC_rotor_input.get_lmax ());
      } break;
  
    case QUADRUPOLAR:
      {
	const double J = CC_rotor_input.get_J ();

	quadrupolar_potential.allocate_calc (CC_rotor_input.get_s () , CC_rotor_input.get_Qpm () , CC_rotor_input.get_V0 () , CC_rotor_input.get_rc () , J , CC_rotor_input.get_lmax ());
      } break;
  
    case GAUSSIAN:
      {
	const double J = CC_rotor_input.get_J ();
      
	Gaussian_potential.allocate_calc (CC_rotor_input.get_Nt () , CC_rotor_input.get_Nr () , CC_rotor_input.get_R () ,
					  CC_rotor_input.get_V0_Gaussian (), CC_rotor_input.get_r0_Gaussian (), CC_rotor_input.get_mu_Gaussian (), J , CC_rotor_input.get_lmax (), CC_rotor_input.get_polarity_Gaussian ());
      } break;
  
    case DEFORMED_WS:
      {
	const double J = CC_rotor_input.get_J ();
      
	deformed_WS_potential_basis.allocate_calc (
						   CC_rotor_input.get_Nt () , CC_rotor_input.get_Nr () , CC_rotor_input.get_R () , CC_rotor_input.get_particle () , 
						   CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , CC_rotor_input.get_d () , 
						   CC_rotor_input.get_R0_WS () , CC_rotor_input.get_beta_2 () , CC_rotor_input.get_Vo_basis () , CC_rotor_input.get_Vso () , J , CC_rotor_input.get_lmax ());
      
	deformed_WS_potential.allocate_calc (
					     CC_rotor_input.get_Nt () , CC_rotor_input.get_Nr () , CC_rotor_input.get_R () , CC_rotor_input.get_particle () , 
					     CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , CC_rotor_input.get_d () , 
					     CC_rotor_input.get_R0_WS () , CC_rotor_input.get_beta_2 () , CC_rotor_input.get_Vo () , CC_rotor_input.get_Vso () , J , CC_rotor_input.get_lmax ());
	
	// the potential does not depend on I but it is required in ODE to build the basis. It is done in both basis and diagonalized potentials for values to be the same therein.
	
	deformed_WS_potential.set_moment_of_inertia (CC_rotor_input.get_I () , CC_rotor_input.get_is_I_tab_used () , CC_rotor_input.get_rotor_angular_momenta () , 
						     CC_rotor_input.get_moments_of_inertia () , CC_rotor_input.get_mass_modif () , CC_rotor_input.get_nucleon_mass_for_calc ());
	
	deformed_WS_potential_basis.set_moment_of_inertia (CC_rotor_input.get_I () , CC_rotor_input.get_is_I_tab_used () , CC_rotor_input.get_rotor_angular_momenta () , 
							   CC_rotor_input.get_moments_of_inertia () , CC_rotor_input.get_mass_modif () , CC_rotor_input.get_nucleon_mass_for_calc ());
      } break;
  
    case DEFORMED_WS_STATIC:
      {
	const double K = CC_rotor_input.get_K_static ();

	deformed_WS_static_potential_basis.allocate_calc (
							  CC_rotor_input.get_Nt () , CC_rotor_input.get_Nr () , CC_rotor_input.get_R () , CC_rotor_input.get_particle () , 
							  CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , CC_rotor_input.get_d () , 
							  CC_rotor_input.get_R0_WS () , CC_rotor_input.get_beta_2 () , CC_rotor_input.get_Vo_basis () , CC_rotor_input.get_Vso () , K , CC_rotor_input.get_lmax ());
	
	deformed_WS_static_potential.allocate_calc (
						    CC_rotor_input.get_Nt () , CC_rotor_input.get_Nr () , CC_rotor_input.get_R () , CC_rotor_input.get_particle () , 
						    CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , CC_rotor_input.get_d () , 
						    CC_rotor_input.get_R0_WS () , CC_rotor_input.get_beta_2 () , CC_rotor_input.get_Vo () , CC_rotor_input.get_Vso () , K , CC_rotor_input.get_lmax ());      
      } break; 
  
    default: error_message_print_abort ("------ CC_rotor_potential_class: bad potential type (" + make_string<enum potential_type> (potential) + ") ------");
    }
}

void CC_rotor_potential_class::allocate_fill (const class CC_rotor_potential_class &X)
{
  potential = X.potential;
  
  switch (potential)
    {
    case DIPOLAR: dipolar_potential.allocate_fill (X.dipolar_potential); break;
      
    case QUADRUPOLAR: quadrupolar_potential.allocate_fill (X.quadrupolar_potential); break;
      
    case GAUSSIAN: Gaussian_potential.allocate_fill (X.Gaussian_potential); break;
      
    case DEFORMED_WS:
      {
	deformed_WS_potential_basis.allocate_fill (X.deformed_WS_potential_basis);
	
	deformed_WS_potential.allocate_fill (X.deformed_WS_potential);
      } break;
      
    case DEFORMED_WS_STATIC:
      {
	deformed_WS_static_potential_basis.allocate_fill (X.deformed_WS_static_potential_basis);
	
	deformed_WS_static_potential.allocate_fill (X.deformed_WS_static_potential);
      } break;
      
    default: error_message_print_abort ("------ CC_rotor_potential_class (copy): bad potential type (" + make_string<enum potential_type> (potential) + ") ------");
    }
}


void CC_rotor_potential_class::deallocate ()
{  
  dipolar_potential.deallocate ();

  quadrupolar_potential.deallocate ();

  deformed_WS_potential_basis.deallocate ();
  
  deformed_WS_static_potential_basis.deallocate ();
  
  deformed_WS_potential.deallocate ();
  
  deformed_WS_static_potential.deallocate ();

  Gaussian_potential.deallocate ();

  potential = NO_POTENTIAL;
}







// ================================== methods ================================== //

// just for tests, one can put anything we need inside
void CC_rotor_potential_class::test_WS_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (potential != DEFORMED_WS) error_message_print_abort ("CC_rotor_potential_class::test_WS_potential: only for deformed WS potential.");
    
  const string file_path_name = STORAGE_DIR + "test_pot";

  ofstream file (file_path_name.c_str ());

  cout << "--> Write the deformed WS potential in " + STORAGE_DIR + "/test_pot file." << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const unsigned int BP = CC_rotor_input.get_BP ();
  const double J = CC_rotor_input.get_J ();

  const unsigned int N_bef_R_GL = CC_rotor_input.get_N_bef_R_GL ();
      
  const double R = CC_rotor_input.get_R ();
  const double R_max = CC_rotor_input.get_R_real_max ();
      
  class array<double> r_bef_R_GL (N_bef_R_GL);
  class array<double> w_bef_R_GL (N_bef_R_GL);
      
  Gauss_Legendre::abscissas_weights_tables_calc (CC_rotor_input.get_s () , R , r_bef_R_GL , w_bef_R_GL);

  const unsigned int N_bef_R_uniform = CC_rotor_input.get_N_bef_R_uniform ();
      
  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);
      
  class array<double> r_bef_R_uniform (N_bef_R_uniform);
      
  for (unsigned int i = 0 ; i<N_bef_R_uniform ; i++) r_bef_R_uniform (i) = i * step_bef_R_uniform;

  const unsigned int N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();

  class array<double> r_aft_R_GL_real (N_aft_R_GL);
  class array<double> w_aft_R_GL_real (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_GL_real , w_aft_R_GL_real);

  for (int lc = 0 ; lc <= CC_rotor_input.get_lmax () ; lc++)
    {
      const double jmin_lc = abs (0.5 - lc) , jmax_lc = 0.5 + lc;
      const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);

      for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	{
	  const double jc = jmin_lc + i_jc;

	  class WS_class WS_potential_basis (false , CC_rotor_input.get_d () , CC_rotor_input.get_R0_WS () , CC_rotor_input.get_Vo_basis () , CC_rotor_input.get_Vso () , 
					     CC_rotor_input.get_particle () , CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , lc , jc);
	  
	  class WS_class WS_potential (false , CC_rotor_input.get_d () , CC_rotor_input.get_R0_WS () , CC_rotor_input.get_Vo () , CC_rotor_input.get_Vso () , 
				       CC_rotor_input.get_particle () , CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , lc , jc);

	  const int jr_min_jc = make_int (abs (J - jc));
	  const int jr_max_jc = make_int (J + jc);

	  const double step_Nr = CC_rotor_input.get_R () / static_cast<double> (CC_rotor_input.get_Nr () - 1);

	  for (int jrc = jr_min_jc ; jrc <= jr_max_jc ; jrc++)
	    {
	      if ((jrc%2 == 0) && (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP))
		{
		  for (unsigned int i = 0 ; i < CC_rotor_input.get_Nr () ; i++)
		    {
		      const double r = i * step_Nr;

		      file << r << " ";
		      
		      file << deformed_WS_potential_basis (jrc , lc , jc , jrc , lc , jc , r) << " " << WS_potential_basis (r) << " " << deformed_WS_potential_basis (jrc , lc , jc , jrc , lc , jc , r) - WS_potential_basis (r) << " ";		      
		      file << deformed_WS_potential       (jrc , lc , jc , jrc , lc , jc , r) << " " << WS_potential       (r) << " " << deformed_WS_potential       (jrc , lc , jc , jrc , lc , jc , r) - WS_potential (r) << endl;
		    }
		}
	    }
	}
    }
}





void CC_rotor_potential_class::test_WS_static_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (potential != DEFORMED_WS_STATIC) error_message_print_abort ("CC_rotor_potential_class::test_WS_potential: only for deformed WS static potential.");
  
  const string file_path_name = STORAGE_DIR + "test_pot";

  ofstream file (file_path_name.c_str ());

  cout << "--> Write the deformed WS_static potential in " + STORAGE_DIR + "/test_pot file." << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const unsigned int BP = CC_rotor_input.get_BP ();

  const unsigned int N_bef_R_GL = CC_rotor_input.get_N_bef_R_GL ();
      
  const double R = CC_rotor_input.get_R ();
  const double R_max = CC_rotor_input.get_R_real_max ();
      
  class array<double> r_bef_R_GL (N_bef_R_GL);
  class array<double> w_bef_R_GL (N_bef_R_GL);
      
  Gauss_Legendre::abscissas_weights_tables_calc (CC_rotor_input.get_s () , R , r_bef_R_GL , w_bef_R_GL);

  const unsigned int N_bef_R_uniform = CC_rotor_input.get_N_bef_R_uniform ();
      
  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);
      
  class array<double> r_bef_R_uniform (N_bef_R_uniform);
      
  for (unsigned int i = 0 ; i<N_bef_R_uniform ; i++) r_bef_R_uniform (i) = i * step_bef_R_uniform;

  const unsigned int N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();

  class array<double> r_aft_R_GL_real (N_aft_R_GL);
  class array<double> w_aft_R_GL_real (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_GL_real , w_aft_R_GL_real);

  for (int lc = 0 ; lc <= CC_rotor_input.get_lmax () ; lc++)
    {
      const double jmin_lc = abs (0.5 - lc) , jmax_lc = 0.5 + lc;
      const unsigned int N_jc = make_int (jmax_lc - jmin_lc + 1);

      for (unsigned int i_jc = 0 ; i_jc < N_jc ; i_jc ++)
	{
	  const double jc = jmin_lc + i_jc;

	  class WS_class WS_potential_basis (false , CC_rotor_input.get_d () , CC_rotor_input.get_R0_WS () , CC_rotor_input.get_Vo_basis () , CC_rotor_input.get_Vso () , 
					     CC_rotor_input.get_particle () , CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , lc , jc);
	  
	  class WS_class WS_potential (false , CC_rotor_input.get_d () , CC_rotor_input.get_R0_WS () , CC_rotor_input.get_Vo () , CC_rotor_input.get_Vso () , 
				       CC_rotor_input.get_particle () , CC_rotor_input.get_ZY_charge () , CC_rotor_input.get_R_charge () , lc , jc);

	  const double step_Nr = CC_rotor_input.get_R () / static_cast<double> (CC_rotor_input.get_Nr () - 1);

	  if (binary_parity_from_orbital_angular_momentum (lc) == BP)
	    {
	      for (unsigned int i = 0 ; i < CC_rotor_input.get_Nr () ; i++)
		{
		  const double r = i * step_Nr;
		      
		  file << r << " ";
		      
		  file << deformed_WS_static_potential_basis (lc , jc , lc , jc , r) << " " << WS_potential_basis (r) << " " << deformed_WS_static_potential_basis (lc , jc , lc , jc , r) - WS_potential_basis (r) << " ";
		  file << deformed_WS_static_potential       (lc , jc , lc , jc , r) << " " << WS_potential       (r) << " " << deformed_WS_static_potential       (lc , jc , lc , jc , r) - WS_potential (r) << endl;		      
		}
	    }
	}
    }
}








// just for tests, one can put anything we need inside
void CC_rotor_potential_class::test_quadrupolar_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (potential != QUADRUPOLAR) error_message_print_abort ("potential_class::testQuad_potential: only for quadrupolar potential.");
  
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const string file_path_name = STORAGE_DIR + "test_pot";
  ofstream file (file_path_name.c_str ());

  cout << "--> Write the quadrupolar potential in " + STORAGE_DIR + "/test_pot file." << endl << endl;

  const unsigned int BP = CC_rotor_input.get_BP ();
  const double J = CC_rotor_input.get_J ();

  const unsigned int N_bef_R_GL = CC_rotor_input.get_N_bef_R_GL ();
  
  const double R = CC_rotor_input.get_R ();
  const double R_max = CC_rotor_input.get_R_real_max ();
  
  class array<double> r_bef_R_GL (N_bef_R_GL);
  class array<double> w_bef_R_GL (N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (CC_rotor_input.get_s () , R , r_bef_R_GL , w_bef_R_GL);

  const unsigned int N_bef_R_uniform = CC_rotor_input.get_N_bef_R_uniform ();
  
  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);
  
  class array<double> r_bef_R_uniform (N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_uniform (i) = i * step_bef_R_uniform;

  const unsigned int N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();

  class array<double> r_aft_R_GL_real (N_aft_R_GL);
  class array<double> w_aft_R_GL_real (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_GL_real , w_aft_R_GL_real);

  const double step_Nr = CC_rotor_input.get_R () / static_cast<double> (CC_rotor_input.get_Nr () - 1);

  for (int lc = 0 ; lc <= CC_rotor_input.get_lmax () ; lc++)
    {
      const int jr_min_lc = abs (J - lc);

      const int jr_max_lc = J + lc;

      for (int jrc = jr_min_lc ; jrc <= jr_max_lc ; jrc++)
	{
	  if ((jrc%2 == 0) && (binary_parity_from_orbital_angular_momentum (jrc + lc) == BP))
	    {
	      for (unsigned int i = 0 ; i < CC_rotor_input.get_Nr () ; i++)
		{
		  const double r = i * step_Nr;

		  file << r << " " << quadrupolar_potential (jrc , lc , jrc , lc , r)  << endl;
		}
	    }
	}
    }
}








void CC_rotor_potential_class::test_Gaussian_potential (const class CC_rotor_all_data_class &CC_rotor_all_data) const
{
  if (potential != GAUSSIAN) error_message_print_abort ("potential_class::testGaus_potential: only for Gaussian potential.");
  
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const string file_path_name = STORAGE_DIR + "test_pot";

  ofstream file (file_path_name.c_str ());

  cout << "--> Write the Gaussian potential in " + STORAGE_DIR + "/test_pot file." << endl << endl;

  const unsigned int BP = CC_rotor_input.get_BP ();

  const double J = CC_rotor_input.get_J ();

  const unsigned int polarity =  CC_rotor_input.get_polarity_Gaussian ();

  const unsigned int N_bef_R_GL = CC_rotor_input.get_N_bef_R_GL ();

  const double s_radial = CC_rotor_input.get_s ();

  const double R = CC_rotor_input.get_R ();
  const double R_max = CC_rotor_input.get_R_real_max ();

  class array<double> r_bef_R_GL (N_bef_R_GL);
  class array<double> w_bef_R_GL (N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R , r_bef_R_GL , w_bef_R_GL);

  const unsigned int N_bef_R_uniform = CC_rotor_input.get_N_bef_R_uniform ();

  const double step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1);

  class array<double> r_bef_R_uniform (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_uniform (i) = i * step_bef_R_uniform;

  const unsigned int N_aft_R_GL = CC_rotor_input.get_N_aft_R_GL ();

  class array<double> r_aft_R_GL_real (N_aft_R_GL);
  class array<double> w_aft_R_GL_real (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_GL_real , w_aft_R_GL_real);

  for (int lc = 0 ; lc <= CC_rotor_input.get_lmax () ; lc++)
    {
      const int jr_min_lc = abs (J - lc);
      const int jr_max_lc = J + lc;

      bool polarity_condition;

      for (int jrc = jr_min_lc ; jrc <= jr_max_lc ; jrc++)
	{
	  if (polarity%2==0)  
	    polarity_condition = (make_uns_int(jrc)%2 == polarity%2);
	  else  
	    polarity_condition = true;

	  if ((make_uns_int (jrc + lc)%2 == BP) && (polarity_condition))
	    {
	      for (unsigned int i = 0; i < N_bef_R_uniform; i++)
		{
		  const double r = r_bef_R_uniform (i);

		  file << r << " " << lc << "   " << Gaussian_potential (jrc , lc , jrc , lc , r)  << endl;
		}
	    }
	}
    }
}


double used_memory_calc (const class CC_rotor_potential_class &T)
{
  return (sizeof (T)/1000000.0 +
	  used_memory_calc (T.dipolar_potential) +
	  used_memory_calc (T.quadrupolar_potential) +
	  used_memory_calc (T.Gaussian_potential) +
	  used_memory_calc (T.deformed_WS_potential_basis) +
	  used_memory_calc (T.deformed_WS_static_potential_basis) +
	  used_memory_calc (T.deformed_WS_potential) +
	  used_memory_calc (T.deformed_WS_static_potential)
	  - (sizeof (T.dipolar_potential) +
	     sizeof (T.quadrupolar_potential) +
	     sizeof (T.Gaussian_potential) +
	     sizeof (T.deformed_WS_potential_basis) +
	     sizeof (T.deformed_WS_static_potential_basis) +
	     sizeof (T.deformed_WS_potential) +
	     sizeof (T.deformed_WS_static_potential))/1000000.0);
}


