#include "../CC_rotor_include/CC_rotor_include.h"


// Forward and backward direct integration of the coupled-channel equations
// ------------------------------------------------------------------------








/*-------------------------------------------------------------------------------------------------------------------
  ELEMENTS FOR CLASS CC_fwd_basis_state
  ---------------------------------------------------------------------------------------------------------------------*/


/* Constructors and Destructors
 */


CC_fwd_basis_state::CC_fwd_basis_state () :
  S_matrix_pole (false) ,
  N_channels (0) , 
  ib (0) ,
  R (0.0) ,
  s_radial (0.0) ,
  R0 (0.0) , 
  R_max (0.0) ,
  step_bef_R_uniform (0.0) ,
  N_bef_R_uniform (0) , 
  N_bef_s_GL (0) , 
  N_bef_R_GL (0) ,
  N_bef_R0_uniform (0)
{}

CC_fwd_basis_state::CC_fwd_basis_state (
					const bool S_matrix_pole_c , 
					const unsigned int N_channels_c ,
					const unsigned int ib_c , 
					const class array<class CC_rotor_channel_class> &channels_tab_c ,
					const unsigned int N_bef_R_uniform_c , 
					const unsigned int N_bef_s_GL_c , 
					const unsigned int N_bef_R0_GL_c ,
					const double R_c , 
					const double s_radial_c , 
					const double R0_c , 
					const double R_real_max_c)
{
  allocate (S_matrix_pole_c , N_channels_c , ib_c , channels_tab_c , N_bef_R_uniform_c , N_bef_s_GL_c , N_bef_R0_GL_c , R_c , s_radial_c , R0_c , R_real_max_c);
}

CC_fwd_basis_state::CC_fwd_basis_state (const class CC_fwd_basis_state &X)
{
  allocate_fill (X);
}
  



void CC_fwd_basis_state::allocate (
				   const bool S_matrix_pole_c , 
				   const unsigned int N_channels_c ,
				   const unsigned int ib_c , 
				   const class array<class CC_rotor_channel_class> &channels_tab_c ,
				   const unsigned int N_bef_R_uniform_c , 
				   const unsigned int N_bef_s_GL_c , 
				   const unsigned int N_bef_R_GL_c ,
				   const double R_c , 
				   const double s_radial_c , 
				   const double R0_c , 
				   const double R_real_max_c)
{
  S_matrix_pole = S_matrix_pole_c; 

  N_channels = N_channels_c; 

  ib = ib_c;

  R = R_c; 

  s_radial = s_radial_c; 

  R0 = R0_c; 

  R_max = R_real_max_c;

  step_bef_R_uniform = R_c/static_cast<double> (N_bef_R_uniform_c - 1);

  N_bef_R_uniform = N_bef_R_uniform_c; 

  N_bef_s_GL = N_bef_s_GL_c; 

  N_bef_R_GL = N_bef_R_GL_c;

  N_bef_R0_uniform = make_uns_int (floor ((N_bef_R_uniform_c - 1) * R0_c/R_c)) + 1;
	
  channels_tab.allocate_fill (channels_tab_c);

  // before R
  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class array<double> weights_bef_s_tab_GL (N_bef_s_GL);
  class array<double> weights_bef_R_tab_GL (N_bef_R_GL);

  r_bef_s_tab_GL.allocate (N_bef_s_GL);
  r_bef_R_tab_GL.allocate (N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , s_radial , r_bef_s_tab_GL , weights_bef_s_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R , r_bef_R_tab_GL , weights_bef_R_tab_GL);

  CC_fwd_basis_wf_bef_R0_tab_uniform.allocate (N_channels , N_bef_R0_uniform);
  CC_fwd_basis_dwf_bef_R0_tab_uniform.allocate (N_channels , N_bef_R0_uniform);
  CC_fwd_basis_wf_bef_R0_tab_uniform = INFINITE , CC_fwd_basis_dwf_bef_R0_tab_uniform = INFINITE;

  CC_fwd_basis_wf_bef_s_tab_GL.allocate (N_channels , N_bef_s_GL);
  CC_fwd_basis_dwf_bef_s_tab_GL.allocate (N_channels , N_bef_s_GL);
  CC_fwd_basis_wf_bef_s_tab_GL = INFINITE , CC_fwd_basis_dwf_bef_s_tab_GL = INFINITE;

  CC_fwd_basis_wf_bef_R0_tab_GL.allocate (N_channels , N_bef_R_GL);
  CC_fwd_basis_dwf_bef_R0_tab_GL.allocate (N_channels , N_bef_R_GL);
  CC_fwd_basis_wf_bef_R0_tab_GL = INFINITE , CC_fwd_basis_dwf_bef_R0_tab_GL = INFINITE;

  CC_fwd_basis_wf_R0_tab.allocate (N_channels);
  CC_fwd_basis_dwf_R0_tab.allocate (N_channels);
  CC_fwd_basis_wf_R0_tab = INFINITE , CC_fwd_basis_dwf_R0_tab = INFINITE;
}





void CC_fwd_basis_state::allocate_fill (const class CC_fwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  ib = X.ib;

  R = X.R;

  s_radial = X.s_radial; 

  R0 = X.R0; 

  R_max = X.R_max;

  step_bef_R_uniform = X.step_bef_R_uniform;

  N_bef_R_uniform = X.N_bef_R_uniform; 

  N_bef_s_GL = X.N_bef_s_GL; 
  N_bef_R_GL = X.N_bef_R_GL;

  N_bef_R0_uniform = X.N_bef_R0_uniform;
	
  channels_tab.allocate_fill (X.channels_tab);

  // before R
  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  r_bef_s_tab_GL.allocate_fill (X.r_bef_s_tab_GL);
  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);

  CC_fwd_basis_wf_bef_R0_tab_uniform.allocate_fill (X.CC_fwd_basis_wf_bef_R0_tab_uniform);
  CC_fwd_basis_dwf_bef_R0_tab_uniform.allocate_fill (X.CC_fwd_basis_dwf_bef_R0_tab_uniform);

  CC_fwd_basis_wf_bef_s_tab_GL.allocate_fill (X.CC_fwd_basis_wf_bef_s_tab_GL);
  CC_fwd_basis_dwf_bef_s_tab_GL.allocate_fill (X.CC_fwd_basis_dwf_bef_s_tab_GL);

  CC_fwd_basis_wf_bef_R0_tab_GL.allocate_fill (X.CC_fwd_basis_wf_bef_R0_tab_GL);
  CC_fwd_basis_dwf_bef_R0_tab_GL.allocate_fill (X.CC_fwd_basis_dwf_bef_R0_tab_GL);

  CC_fwd_basis_wf_R0_tab.allocate_fill (X.CC_fwd_basis_wf_R0_tab);
  CC_fwd_basis_dwf_R0_tab.allocate_fill (X.CC_fwd_basis_dwf_R0_tab);
}



void CC_fwd_basis_state::deallocate ()
{	
  channels_tab.deallocate ();

  // before R
  r_bef_R_tab_uniform.deallocate ();

  r_bef_s_tab_GL.deallocate ();
  r_bef_R_tab_GL.deallocate ();

  CC_fwd_basis_wf_bef_R0_tab_uniform.deallocate ();
  CC_fwd_basis_dwf_bef_R0_tab_uniform.deallocate ();

  CC_fwd_basis_wf_bef_s_tab_GL.deallocate ();
  CC_fwd_basis_dwf_bef_s_tab_GL.deallocate ();

  CC_fwd_basis_wf_bef_R0_tab_GL.deallocate ();
  CC_fwd_basis_dwf_bef_R0_tab_GL.deallocate ();

  CC_fwd_basis_wf_R0_tab.deallocate ();
  CC_fwd_basis_dwf_R0_tab.deallocate ();

  S_matrix_pole = false;

  N_channels = 0; 

  ib = 0;

  R = 0.0;

  s_radial = 0.0;

  R0 = 0.0; 

  R_max = 0.0;

  step_bef_R_uniform = 0.0;

  N_bef_R_uniform = 0; 

  N_bef_s_GL = 0; 

  N_bef_R_GL = 0;

  N_bef_R0_uniform = 0;
}




/*
 */
void CC_fwd_basis_state::CC_wf_dwf_d2wf_zero ()
{
  CC_fwd_basis_wf_bef_R0_tab_uniform = 0.0;
  CC_fwd_basis_dwf_bef_R0_tab_uniform = 0.0;

  CC_fwd_basis_wf_bef_s_tab_GL = 0.0;
  CC_fwd_basis_dwf_bef_s_tab_GL= 0.0;

  CC_fwd_basis_wf_bef_R0_tab_GL = 0.0;
  CC_fwd_basis_dwf_bef_R0_tab_GL = 0.0;

  CC_fwd_basis_wf_R0_tab = 0.0;
  CC_fwd_basis_dwf_R0_tab = 0.0;
}





void CC_fwd_basis_state::init_conditions_calc (
					       const complex<double> &C0 , 
					       const class CC_rotor_potential_class &CC_rotor_potential ,
					       const double r0 , 
					       class vector_class<complex<double> > &U0 ,
					       class vector_class<complex<double> > &dU0) const
{
  const enum potential_type potential = CC_rotor_potential.get_potential ();

  const class dipolar_potential_class &dipolar_potential             = CC_rotor_potential.get_dipolar_potential ();
  const class quadrupolar_potential_class &quadrupolar_potential     = CC_rotor_potential.get_quadrupolar_potential ();
  const class Gaussian_potential_class &Gaussian_potential           = CC_rotor_potential.get_Gaussian_potential ();
  const class deformed_WS_class &deformed_WS_potential               = CC_rotor_potential.get_deformed_WS_potential ();
  const class deformed_WS_static_class &deformed_WS_static_potential = CC_rotor_potential.get_deformed_WS_static_potential ();

  const class CC_rotor_channel_class &channel_b = channels_tab(ib);

  const int jrb = channel_b.get_jrc ();
  
  const int lb = channel_b.get_lc ();

  const double jb = channel_b.get_jc ();

  // terme diag en r^ (l + 1)
  
  U0 (ib) = C0 * pow (r0 , lb + 1);
  
  dU0 (ib) = C0 * (lb + 1.0) * pow (r0 , lb);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if (ic != ib)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
	  const int jrc = channel_c.get_jrc ();
	  
	  const int lc = channel_c.get_lc ();
	  
	  const double jc = channel_c.get_jc ();

	  complex<double> a_cb = 0.0;

	  switch (potential)
	    {
	    case DIPOLAR:            a_cb = dipolar_potential            (jrb , lb , jrc , lc , 0.0); break;
	    case QUADRUPOLAR:        a_cb = quadrupolar_potential        (jrb , lb , jrc , lc , 0.0); break;
	    case GAUSSIAN:           a_cb = Gaussian_potential           (jrb , lb , jrc , lc , 0.0); break;
	      
	    case DEFORMED_WS:        a_cb = deformed_WS_potential        (jrb , lb , jb , jrc , lc , jc , 0.0); break;

	    case DEFORMED_WS_STATIC: a_cb = deformed_WS_static_potential (lb , jb , lc , jc , 0.0); break;
	      
	    default: error_message_print_abort ("CC_fwd_basis_state::init_conditions_calc: bad potential type");
	    }
	  
	  if (lc != lb + 2)
	    {
	      const complex<double> factor = a_cb/ ((lb + 2.0) * (lb + 3.0) - lc * (lc + 1.0));

	      U0 (ic)  = C0 * factor * pow (r0 , lb + 3);
	      dU0 (ic) = C0 * factor * (lb + 3.0) * pow (r0 , lb + 2);
	    }
	  else
	    {
	      const double factor1 = 1.0/ (2.0 * lb + 5.0);
	      
	      const double r0_log_r0 = z_log_z (r0);
	      
	      const double r0_pow_lbp1 = pow (r0 , lb + 1);
	      
	      const double r0_pow_lbp2 = r0 * r0_pow_lbp1;
	      
	      const complex<double> factor2 = a_cb * factor1;
	      
	      const complex<double> C0_factor2 = C0 * factor2;

	      U0 (ic) = C0_factor2 * (r0_pow_lbp2 * r0_log_r0);
	      dU0 (ic) = C0_factor2 * ((lb + 3.0) * r0_log_r0 * r0_pow_lbp1 + r0_pow_lbp2);
	    }
	}
    }
}




// integration forward
void CC_fwd_basis_state::forward_integration_before_R (
						       const complex<double> &C0 , 
						       const class CC_rotor_potential_class &potential ,
						       class CC_rotor_system_integration &SI)
{
  CC_wf_dwf_d2wf_zero ();

  const class CC_rotor_channel_class &channel_b = channels_tab(ib);
  const int lb = channel_b.get_lc ();
  const double lb_lbp1 = lb * (lb + 1.);
  const double r0 = 0.005 * sqrt (lb_lbp1);//xyz arbitrary
  const double r_bef_R0 = (N_bef_R0_uniform - 1) * step_bef_R_uniform;

  class vector_class<complex<double> >  U0 (N_channels);
  class vector_class<complex<double> > dU0 (N_channels);

  init_conditions_calc (C0 , potential , r0 , U0 , dU0);

  CC_fwd_basis_wf_bef_R0_tab_uniform = 0., CC_fwd_basis_dwf_bef_R0_tab_uniform = 0.;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      if ((lb == 0) && (ic == ib))
	CC_fwd_basis_dwf_bef_R0_tab_uniform (ic , 0) = C0;
    }

  class vector_class<complex<double> > U_previous = U0 , dU_previous = dU0 , U = U0 , dU = dU0 , U_GL = U0 , dU_GL = dU0;

  unsigned int iGL_s = 0 , iGL_R0 = 0;

  while ((iGL_s < N_bef_s_GL) && (r_bef_s_tab_GL(iGL_s) <= r0))
    {
      const double r_GL = r_bef_s_tab_GL(iGL_s);
      init_conditions_calc (C0 , potential , r_GL , U_GL , dU_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	CC_fwd_basis_wf_bef_s_tab_GL (ic , iGL_s) = U_GL (ic) , CC_fwd_basis_dwf_bef_s_tab_GL (ic , iGL_s) = dU_GL (ic);

      iGL_s++;
    }

  while ((iGL_R0 < N_bef_R_GL) && (r_bef_R_tab_GL(iGL_R0) <= r0))
    {
      const double r_GL = r_bef_R_tab_GL(iGL_R0);
      init_conditions_calc (C0 , potential , r_GL , U_GL , dU_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	CC_fwd_basis_wf_bef_R0_tab_GL (ic , iGL_R0) = U_GL (ic) , CC_fwd_basis_dwf_bef_R0_tab_GL (ic , iGL_R0) = dU_GL (ic);

      iGL_R0++;
    }

  for (unsigned int i = 1 ; i < N_bef_R0_uniform ; i++)
    {
      const double r_previous = r_bef_R_tab_uniform(i - 1) , r = r_bef_R_tab_uniform(i);

      if (r <= r0)
	{
	  init_conditions_calc (C0 , potential , r , U , dU);

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    CC_fwd_basis_wf_bef_R0_tab_uniform (ic , i) = U (ic) , CC_fwd_basis_dwf_bef_R0_tab_uniform (ic , i) = dU (ic);
	}
      else
	{
	  if (r_previous < r0)
	    {
	      if ((s_radial > r0) && (s_radial < r))
		{
		  class vector_class<complex<double> > Us = U0 , dUs = dU0;

		  SI (r0 , U0 , dU0 , s_radial , Us , dUs);
		  SI (s_radial , Us , dUs , r , U , dU);
		}
	      else
		SI (r0 , U0 , dU0 , r , U , dU);
	    }
	  else
	    {
	      if ((s_radial > r_previous) && (s_radial < r))
		{
		  class vector_class<complex<double> > Us = U0 , dUs = dU0;

		  SI (r_previous , U_previous , dU_previous , s_radial , Us , dUs);
		  SI (s_radial , Us , dUs , r , U , dU);
		}
	      else
		SI (r_previous , U_previous , dU_previous , r , U , dU);

	    }

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    CC_fwd_basis_wf_bef_R0_tab_uniform (ic , i) = U (ic) , CC_fwd_basis_dwf_bef_R0_tab_uniform (ic , i) = dU (ic);

	  while ((iGL_s < N_bef_s_GL) && (r_bef_s_tab_GL(iGL_s) >= r_previous) && (r_bef_s_tab_GL(iGL_s) <= r))
	    {
	      const double r_GL = r_bef_s_tab_GL(iGL_s);

	      (r_previous < r0) ? (SI (r0 , U0 , dU0 , r_GL , U_GL , dU_GL)) : (SI (r_previous , U_previous , dU_previous , r_GL , U_GL , dU_GL));

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		CC_fwd_basis_wf_bef_s_tab_GL (ic , iGL_s) = U_GL (ic) , CC_fwd_basis_dwf_bef_s_tab_GL (ic , iGL_s) = dU_GL (ic);

	      iGL_s++;
	    }

	  while ((iGL_R0 < N_bef_R_GL) && (r_bef_R_tab_GL(iGL_R0) >= r_previous) && (r_bef_R_tab_GL(iGL_R0) <= r))
	    {
	      const double r_GL = r_bef_R_tab_GL(iGL_R0);

	      (r_previous < r0) ? (SI (r0 , U0 , dU0 , r_GL , U_GL , dU_GL)) : (SI (r_previous , U_previous , dU_previous , r_GL , U_GL , dU_GL));

	      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
		CC_fwd_basis_wf_bef_R0_tab_GL (ic , iGL_R0) = U_GL (ic) , CC_fwd_basis_dwf_bef_R0_tab_GL (ic , iGL_R0) = dU_GL (ic);

	      iGL_R0++;
	    }
	}

      U_previous = U , dU_previous = dU;
    }

  // SI
  SI (r_bef_R0 , U_previous , dU_previous , R0 , U , dU);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    CC_fwd_basis_wf_R0_tab(ic) = U (ic) , CC_fwd_basis_dwf_R0_tab(ic) = dU (ic);

  while ((iGL_R0 < N_bef_R_GL) && (r_bef_R_tab_GL(iGL_R0) < R0)) 
    {
      const double r_GL = r_bef_R_tab_GL(iGL_R0);

      SI (r_bef_R0 , U_previous , dU_previous , r_GL , U_GL , dU_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	CC_fwd_basis_wf_bef_R0_tab_GL (ic , iGL_R0) = U_GL (ic) , CC_fwd_basis_dwf_bef_R0_tab_GL (ic , iGL_R0) = dU_GL (ic);

      iGL_R0++;
    }
}







void CC_fwd_basis_state::change_channels (const complex<double> &E)
{
  for (unsigned int ic = 0 ; ic < N_channels ; ic++) channels_tab(ic).E_dependent_values_change (E);
}



double used_memory_calc (const class CC_fwd_basis_state &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.channels_tab) +
    used_memory_calc (T.r_bef_R_tab_uniform) +
    used_memory_calc (T.r_bef_s_tab_GL) +
    used_memory_calc (T.r_bef_R_tab_GL) +
    used_memory_calc (T.CC_fwd_basis_wf_bef_R0_tab_uniform) +
    used_memory_calc (T.CC_fwd_basis_dwf_bef_R0_tab_uniform) +
    used_memory_calc (T.CC_fwd_basis_wf_bef_s_tab_GL) +
    used_memory_calc (T.CC_fwd_basis_dwf_bef_s_tab_GL) +
    used_memory_calc (T.CC_fwd_basis_wf_bef_R0_tab_GL) +
    used_memory_calc (T.CC_fwd_basis_dwf_bef_R0_tab_GL) +
    used_memory_calc (T.CC_fwd_basis_wf_R0_tab) +
    used_memory_calc (T.CC_fwd_basis_dwf_R0_tab)
    - (sizeof (T.channels_tab) +
       sizeof (T.r_bef_R_tab_uniform) +
       sizeof (T.r_bef_s_tab_GL) +
       sizeof (T.r_bef_R_tab_GL) +
       sizeof (T.CC_fwd_basis_wf_bef_R0_tab_uniform) +
       sizeof (T.CC_fwd_basis_dwf_bef_R0_tab_uniform) +
       sizeof (T.CC_fwd_basis_wf_bef_s_tab_GL) +
       sizeof (T.CC_fwd_basis_dwf_bef_s_tab_GL) +
       sizeof (T.CC_fwd_basis_wf_bef_R0_tab_GL) +
       sizeof (T.CC_fwd_basis_dwf_bef_R0_tab_GL) +
       sizeof (T.CC_fwd_basis_wf_R0_tab) +
       sizeof (T.CC_fwd_basis_dwf_R0_tab))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}

/*-------------------------------------------------------------------------------------------------------------------
  ELEMENTS FOR CLASS CC_bwd_basis_state
  ---------------------------------------------------------------------------------------------------------------------*/


/* ructors and Destructors
 */

CC_bwd_basis_state::CC_bwd_basis_state () :
  S_matrix_pole (false) , 
  N_channels (0) ,
  ic_entrance (0) ,
  ib (0) ,
  R (0.0), 
  s_radial (0.0) , 
  R0 (0.0) , 
  R_max (0.0) ,
  N_bef_R_uniform (0), 
  N_aft_R_uniform (0) ,
  N_bef_R_GL (0), 
  N_aft_R_GL (0) ,
  N_bef_R0_uniform (0) ,
  N_aft_R0_uniform (0) ,
  step_bef_R_uniform (0.0), 
  step_aft_R_real_uniform (0.0)
{}
  
CC_bwd_basis_state::CC_bwd_basis_state (
					const bool S_matrix_pole_c , 
					const unsigned int N_channels_c , 
					const unsigned ic_entrance_c ,
					const unsigned int ib_c , 
					const class array<class CC_rotor_channel_class> &channels_tab_c ,
					const unsigned int N_bef_R_uniform_c , 
					const unsigned int N_aft_R_uniform_c ,
					const unsigned int N_bef_R_GL_c , 
					const unsigned int N_aft_R_GL_c ,
					const double R_c , 
					const double s_radial_c , 
					const double R0_c , 
					const double R_real_max_c)
{
  allocate (S_matrix_pole_c , N_channels_c , ic_entrance_c , ib_c , channels_tab_c , N_bef_R_uniform_c , N_aft_R_uniform_c , N_bef_R_GL_c , N_aft_R_GL_c , R_c , s_radial_c , R0_c , R_real_max_c);
}

CC_bwd_basis_state::CC_bwd_basis_state (const class CC_bwd_basis_state &X)
{
  allocate_fill (X);
}

void CC_bwd_basis_state::allocate (
				   const bool S_matrix_pole_c ,
				   const unsigned int N_channels_c ,
				   const unsigned ic_entrance_c ,
				   const unsigned int ib_c ,
				   const class array<class CC_rotor_channel_class> &channels_tab_c ,
				   const unsigned int N_bef_R_uniform_c ,
				   const unsigned int N_aft_R_uniform_c ,
				   const unsigned int N_bef_R_GL_c ,
				   const unsigned int N_aft_R_GL_c ,
				   const double R_c ,
				   const double s_radial_c ,
				   const double R0_c ,
				   const double R_real_max_c)
{
  S_matrix_pole = S_matrix_pole_c; 
 
  N_channels = N_channels_c; 

  ic_entrance = ic_entrance_c; 

  ib = ib_c;

  R = R_c; 

  s_radial = s_radial_c; 

  R0 = R0_c; 

  R_max = R_real_max_c;

  N_bef_R_uniform = N_bef_R_uniform_c; 
  N_aft_R_uniform = N_aft_R_uniform_c;

  N_bef_R_GL = N_bef_R_GL_c; 
  N_aft_R_GL = N_aft_R_GL_c;

  N_bef_R0_uniform = make_uns_int (floor ((N_bef_R_uniform_c - 1) * R0_c/R_c)) + 1;
  N_aft_R0_uniform = N_bef_R_uniform_c - 1 - make_uns_int (floor ((N_bef_R_uniform_c - 1) * R0_c/R_c));

  step_bef_R_uniform = R_c/static_cast<double> (N_bef_R_uniform_c - 1);

  step_aft_R_real_uniform = (R_real_max_c - R_c)/static_cast<double> (N_aft_R_uniform_c - 1);

  channels_tab.allocate_fill (channels_tab_c);

  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class array<double> weights_bef_R_tab_GL (N_bef_R_GL);

  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R , r_bef_R_tab_GL , weights_bef_R_tab_GL);

  class array<double> weights_aft_R_tab_GL (N_aft_R_GL);

  u_aft_R_tab_GL.allocate (N_aft_R_GL);
  r_aft_R_real_tab_GL.allocate (N_aft_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , pow (R , - 0.25) , u_aft_R_tab_GL , weights_aft_R_tab_GL);
  Gauss_Legendre::abscissas_weights_tables_calc (R , R_max , r_aft_R_real_tab_GL , weights_aft_R_tab_GL);

  CC_bwd_basis_wf_aft_R0_tab_uniform.allocate (N_channels , N_aft_R0_uniform);
  CC_bwd_basis_dwf_aft_R0_tab_uniform.allocate (N_channels , N_aft_R0_uniform);
  CC_bwd_basis_wf_aft_R0_tab_uniform = INFINITE , CC_bwd_basis_dwf_aft_R0_tab_uniform = INFINITE;

  CC_bwd_basis_wf_aft_R0_tab_GL.allocate (N_channels , N_bef_R_GL);
  CC_bwd_basis_dwf_aft_R0_tab_GL.allocate (N_channels , N_bef_R_GL);
  CC_bwd_basis_wf_aft_R0_tab_GL = INFINITE , CC_bwd_basis_dwf_aft_R0_tab_GL = INFINITE;

  CC_bwd_basis_wf_R0_tab.allocate (N_channels);
  CC_bwd_basis_dwf_R0_tab.allocate (N_channels);
  CC_bwd_basis_wf_R0_tab = INFINITE , CC_bwd_basis_dwf_R0_tab = INFINITE;
}



void CC_bwd_basis_state::allocate_fill (const class CC_bwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  ic_entrance = X.ic_entrance; 

  ib = X.ib;

  R = X.R; 

  s_radial = X.s_radial; 

  R0 = X.R0; 

  R_max = X.R_max;

  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform;

  N_bef_R_GL = X.N_bef_R_GL; 
  N_aft_R_GL = X.N_aft_R_GL;

  N_bef_R0_uniform = X.N_bef_R0_uniform;
  N_aft_R0_uniform = X.N_aft_R0_uniform;

  step_bef_R_uniform = X.step_bef_R_uniform;

  step_aft_R_real_uniform = X.step_aft_R_real_uniform;

  channels_tab.allocate_fill (X.channels_tab);

  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);

  u_aft_R_tab_GL.allocate_fill (X.u_aft_R_tab_GL);

  r_aft_R_real_tab_GL.allocate_fill (X.r_aft_R_real_tab_GL);

  CC_bwd_basis_wf_aft_R0_tab_uniform.allocate_fill (X.CC_bwd_basis_wf_aft_R0_tab_uniform);
  CC_bwd_basis_dwf_aft_R0_tab_uniform.allocate_fill (X.CC_bwd_basis_dwf_aft_R0_tab_uniform);

  CC_bwd_basis_wf_aft_R0_tab_GL.allocate_fill (X.CC_bwd_basis_wf_aft_R0_tab_GL);
  CC_bwd_basis_dwf_aft_R0_tab_GL.allocate_fill (X.CC_bwd_basis_dwf_aft_R0_tab_GL);

  CC_bwd_basis_wf_R0_tab.allocate_fill (X.CC_bwd_basis_wf_R0_tab);
  CC_bwd_basis_dwf_R0_tab.allocate_fill (X.CC_bwd_basis_dwf_R0_tab);
}





void CC_bwd_basis_state::deallocate ()
{
  channels_tab.deallocate ();

  r_bef_R_tab_uniform.deallocate ();

  r_bef_R_tab_GL.deallocate ();

  u_aft_R_tab_GL.deallocate ();
  r_aft_R_real_tab_GL.deallocate ();

  CC_bwd_basis_wf_aft_R0_tab_uniform.deallocate ();
  CC_bwd_basis_dwf_aft_R0_tab_uniform.deallocate ();

  CC_bwd_basis_wf_aft_R0_tab_GL.deallocate ();
  CC_bwd_basis_dwf_aft_R0_tab_GL.deallocate ();

  CC_bwd_basis_wf_R0_tab.deallocate ();
  CC_bwd_basis_dwf_R0_tab.deallocate ();

  S_matrix_pole = false; 

  N_channels = 0;

  ic_entrance = 0;

  ib = 0;

  R = 0.0; 

  s_radial = 0.0; 

  R0 = 0.0; 

  R_max = 0.0;

  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  N_bef_R_GL = 0; 
  N_aft_R_GL = 0;

  N_bef_R0_uniform = 0;
  N_aft_R0_uniform = 0;

  step_bef_R_uniform = 0.0;

  step_aft_R_real_uniform = 0.0;
}





/*
 */
void CC_bwd_basis_state::CC_wf_dwf_d2wf_zero ()
{
  CC_bwd_basis_wf_aft_R0_tab_uniform = 0.0;
  CC_bwd_basis_dwf_aft_R0_tab_uniform = 0.0;
  CC_bwd_basis_wf_aft_R0_tab_GL = 0.0;
  CC_bwd_basis_dwf_aft_R0_tab_GL = 0.0;
  CC_bwd_basis_wf_R0_tab = 0.0;
  CC_bwd_basis_dwf_R0_tab = 0.0;
}





bool CC_bwd_basis_state::is_it_bound_determine () const
{
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const complex<double> kc = channel_c.get_kc ();

      if (imag (kc) < precision) return false;
    }

  return true;
}





void CC_bwd_basis_state::asymptotic_Hb_dHb_omega_scaled (
							 const int omega , 
							 const complex<double> &kc ,
							 const complex<double> &lb_eff , 
							 const complex<double> &lb_eff_phase , 
							 const complex<double> &lb_eff_star_phase ,
							 class Coulomb_wave_functions &cwf_b , 
							 class Coulomb_wave_functions &cwf_conj_b ,
							 const complex<double> &z , 
							 complex<double> &Hb_scaled , 
							 complex<double> &dHb_scaled) const
{
  cwf_b.H_kz_dH_kz_scaled (omega , kc , z , Hb_scaled , dHb_scaled);

  Hb_scaled *= lb_eff_phase;
  dHb_scaled *= lb_eff_phase;

  if (imag (lb_eff) != 0.0)
    {
      complex<double> Hb_conj_scaled , dHb_conj_scaled;

      cwf_conj_b.H_kz_dH_kz_scaled (omega , kc , z , Hb_conj_scaled , dHb_conj_scaled);

      Hb_conj_scaled  *= lb_eff_star_phase;
      dHb_conj_scaled *= lb_eff_star_phase;

      Hb_scaled  = 0.5 * (Hb_scaled  + Hb_conj_scaled);
      dHb_scaled = 0.5 * (dHb_scaled + dHb_conj_scaled);
    }
}






complex<double> CC_bwd_basis_state::asymptotic_source_calc (
							    const class CC_rotor_potential_class &CC_rotor_potential ,
							    const int omega , 
							    const complex<double> &lb_eff , 
							    const unsigned int ic ,
							    const complex<double> &z , 
							    const class vector_class <complex<double> > &Uz) const
{
  const enum potential_type potential = CC_rotor_potential.get_potential ();
  const class dipolar_potential_class &dipolar_potential = CC_rotor_potential.get_dipolar_potential ();
  const class quadrupolar_potential_class &quadrupolar_potential = CC_rotor_potential.get_quadrupolar_potential ();

  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
  const int jrc = channel_c.get_jrc () , lc = channel_c.get_lc () , lc_lcp1 = lc * (lc + 1);

  const complex<double> Iomega_z ( - omega * imag (z) , omega * real (z));
  const complex<double> lb_lbp1 = lb_eff * (lb_eff + 1.0);
  const complex<double> z2 = z * z;
  //const complex<double> kc = channel_c.kc;

  complex<double> asymptotic_source_z = Uz (ic) * (lc_lcp1 - lb_lbp1)/z2;

  for (unsigned int icp = 0 ; icp < N_channels ; icp++)
    {
      const class CC_rotor_channel_class &channel_cp = channels_tab(icp);
      const int jrcp = channel_cp.get_jrc () , lcp = channel_cp.get_lc ();

      complex<double> Vccp_z (0.0 , 0.0);

      switch (potential)
	{
	case DIPOLAR:            Vccp_z =     dipolar_potential.V_asymptotic_calc (jrc , lc , jrcp , lcp , z); break;
	case QUADRUPOLAR:        Vccp_z = quadrupolar_potential.V_asymptotic_calc (jrc , lc , jrcp , lcp , z); break;
	      
	default: error_message_print_abort ("CC_bwd_basis_state::asymptotic_source_calc: bad potential type");
	}
	  
      //const complex<double> kcp = channel_cp.kc;

      asymptotic_source_z += Vccp_z * Uz (icp);
    }

  return asymptotic_source_z;
}








void CC_bwd_basis_state::U_asymptotic_conditions_dipolar_calc (
							       const complex<double> &Cplus_b , 
							       const bool is_it_Uminus ,
							       const class array<complex<double> > &l_eff_tab ,
							       const class matrix<complex<double> > &asymptotic_channels ,
							       class vector_class <complex<double> > &UR ,
							       class vector_class <complex<double> > &dUR)
{
  if (is_it_Uminus)
    {
      if (ic_entrance != ib) error_message_print_abort ("ic_entrance not equal to ib");
      if (!S_matrix_pole) error_message_print_abort ("Not an S-matrix pole");
    }

  const complex<double> I (0 , 1);

  const int omega = (is_it_Uminus) ? (-1) : (1);

  const class vector_class <complex<double> > &asymptotic_eig_vec_b = asymptotic_channels.eigenvector (ib);

  const complex<double> H_norm = (omega == 1) ? (Cplus_b) : (1.0/ (2.0 * M_PI * Cplus_b));

  const complex<double> lb_eff = l_eff_tab (ib);

  const complex<double> lb_eff_star = conj (lb_eff);

  const complex<double> lb_eff_phase_omega = exp (omega * I * lb_eff * M_PI_2);

  const complex<double> lb_eff_phase_omega_star = exp (omega * I * lb_eff_star * M_PI_2);
  
  class Coulomb_wave_functions cwf_b (true , lb_eff , 0.0);
  
  class Coulomb_wave_functions cwf_conj_b (true , lb_eff_star , 0.0);

  UR  = asymptotic_eig_vec_b;
  dUR = asymptotic_eig_vec_b;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);
      
      const complex<double> kc = channel_c.get_kc ();
      
      const complex<double> unscale = exp (I * omega * kc * R);

      complex<double> Hb_scaled , dHb_scaled;
      asymptotic_Hb_dHb_omega_scaled (omega , kc , lb_eff , lb_eff_phase_omega , lb_eff_phase_omega_star , cwf_b , cwf_conj_b , R , Hb_scaled , dHb_scaled);

      UR (ic) *= Hb_scaled * H_norm * unscale;
      
      dUR (ic) *= dHb_scaled * H_norm * unscale;
    }

  const bool is_it_bound = is_it_bound_determine ();
  
  if (!is_it_Uminus && is_it_bound)
    {
      const class vector_class<double> Re_UR  = real<double , complex<double> > (UR);
      const class vector_class<double> Re_dUR = real<double , complex<double> > (dUR);
      
      UR  = complex_vector<double , complex<double> > (Re_UR);
      dUR = complex_vector<double , complex<double> > (Re_dUR);
    }
}


void CC_bwd_basis_state::U_asymptotic_conditions_no_dipolar_calc (
								  const complex<double> &Cplus_b , 
								  const bool is_it_Uminus ,
								  class vector_class <complex<double> > &UR ,
								  class vector_class <complex<double> > &dUR)
{
  if (is_it_Uminus)
    {
      if (ic_entrance != ib) error_message_print_abort ("ic_entrance not equal to ib");
      if (!S_matrix_pole) error_message_print_abort ("Not an S-matrix pole");
    }

  const bool is_it_bound = is_it_bound_determine ();

  const int omega = (is_it_Uminus) ? (-1) : (1);

  const complex<double> H_norm = (omega == 1) ? (Cplus_b) : (1.0/ (2.0 * M_PI * Cplus_b));

  const class CC_rotor_channel_class &channel_b = channels_tab(ib);
      
  const enum particle_type particle_b = channel_b.get_particle_c ();

  const int lb = channel_b.get_lc ();

  const int ZY_charge_b = channel_b.get_ZY_charge_c ();

  const complex<double> kb = channel_b.get_kc ();
      
  const complex<double> eta_b = channel_b.get_eta_c ();

  const class Coulomb_potential_class Coulomb_potential(false , particle_b , ZY_charge_b , NADA);

  class Coulomb_wave_functions cwf_b (true , lb , eta_b);

  complex<double> Hb , dHb;

  if (!is_it_Uminus && is_it_bound)
    cwf_b.Wm_kz_dWm_kz (kb , R , Hb , dHb);
  else
    cwf_b.H_kz_dH_kz (omega , kb , R , Hb , dHb);

  UR  = 0.0;
  dUR = 0.0;

  UR  (ib) =  Hb * H_norm;      
  dUR (ib) = dHb * H_norm;

  if (!is_it_Uminus && is_it_bound)
    {
      const class vector_class<double> Re_UR  = real<double , complex<double> > (UR);
      const class vector_class<double> Re_dUR = real<double , complex<double> > (dUR);
      
      UR  = complex_vector<double , complex<double> > (Re_UR);
      dUR = complex_vector<double , complex<double> > (Re_dUR);
    }
}



void CC_bwd_basis_state::U_asymptotic_conditions_calc (
						       const enum potential_type potential ,
						       const complex<double> &Cplus_b , 
						       const bool is_it_Uminus ,
						       const class array<complex<double> > &l_eff_tab ,
						       const class matrix<complex<double> > &asymptotic_channels ,
						       class vector_class <complex<double> > &UR ,
						       class vector_class <complex<double> > &dUR)
{
  if (potential == DIPOLAR)
    U_asymptotic_conditions_dipolar_calc (Cplus_b , is_it_Uminus , l_eff_tab , asymptotic_channels , UR , dUR);
  else
    U_asymptotic_conditions_no_dipolar_calc (Cplus_b , is_it_Uminus , UR , dUR);
}


// integration backward
void CC_bwd_basis_state::backward_integration_before_R (
							complex<double> &Cplus_b ,
							const enum potential_type potential ,  
							const bool is_it_Uminus ,
							const class array<complex<double> > &l_eff_tab ,
							const class matrix<complex<double> > &asymptotic_channels ,
							class CC_rotor_system_integration &SI)
{
  CC_wf_dwf_d2wf_zero ();

  const double r_aft_R0 = N_bef_R0_uniform * step_bef_R_uniform;
	
  class vector_class<complex<double> >  UR (N_channels);
  class vector_class<complex<double> > dUR (N_channels);

  U_asymptotic_conditions_calc (potential , Cplus_b , is_it_Uminus , l_eff_tab , asymptotic_channels , UR , dUR);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      CC_bwd_basis_wf_aft_R0_tab_uniform  (ic , N_aft_R0_uniform - 1) = UR (ic);
      CC_bwd_basis_dwf_aft_R0_tab_uniform (ic , N_aft_R0_uniform - 1) = dUR (ic);
    }

  class vector_class<complex<double> > U_aft = UR , dU_aft = dUR , U = UR , dU = dUR , U_GL = UR , dU_GL = dUR;

  unsigned int iGL = N_bef_R_GL - 1;

  for (unsigned int i = N_aft_R0_uniform - 2 ; i < N_aft_R0_uniform - 1 ; i--)
    {
      const double r_next = r_bef_R_tab_uniform(i + N_bef_R0_uniform + 1);

      const double r = r_bef_R_tab_uniform(i + N_bef_R0_uniform);

      SI (r_next , U_aft , dU_aft , r , U , dU);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	CC_bwd_basis_wf_aft_R0_tab_uniform (ic , i) = U (ic) , CC_bwd_basis_dwf_aft_R0_tab_uniform (ic , i) = dU (ic);

      // SI
      while ((iGL > 0) && (r_bef_R_tab_GL(iGL) <= r_next) && (r_bef_R_tab_GL(iGL) >= r))
	{
	  const double r_GL = r_bef_R_tab_GL(iGL);

	  SI (r_next , U_aft , dU_aft , r_GL , U_GL , dU_GL);

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	    CC_bwd_basis_wf_aft_R0_tab_GL (ic , iGL) = U_GL (ic) , CC_bwd_basis_dwf_aft_R0_tab_GL (ic , iGL) = dU_GL (ic);

	  iGL--;
	}
      U_aft = U , dU_aft = dU;
    }

  SI (r_aft_R0 , U_aft , dU_aft , R0 , U , dU);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      CC_bwd_basis_wf_R0_tab(ic) = U (ic);
      CC_bwd_basis_dwf_R0_tab(ic) = dU (ic);
    }


  while (iGL > 0)
    {
      const double r_GL = r_bef_R_tab_GL(iGL);

      SI (r_aft_R0 , U_aft , dU_aft , r_GL , U_GL , dU_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  CC_bwd_basis_wf_aft_R0_tab_GL (ic , iGL) = U_GL (ic);
	  CC_bwd_basis_dwf_aft_R0_tab_GL (ic , iGL) = dU_GL (ic);
	}

      iGL--;
    }

  //return;
  const double U_R0_inf_norm = U.infinite_norm ();

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      for (unsigned int i = 0 ; i < N_aft_R0_uniform ; i++)
	{
	  CC_bwd_basis_wf_aft_R0_tab_uniform (ic , i)  /= U_R0_inf_norm;
	  CC_bwd_basis_dwf_aft_R0_tab_uniform (ic , i) /= U_R0_inf_norm;
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  CC_bwd_basis_wf_aft_R0_tab_GL (ic , i)  /= U_R0_inf_norm;
	  CC_bwd_basis_dwf_aft_R0_tab_GL (ic , i) /= U_R0_inf_norm;
	}

      CC_bwd_basis_wf_R0_tab(ic)  /= U_R0_inf_norm;
      CC_bwd_basis_dwf_R0_tab(ic) /= U_R0_inf_norm;
    }

  Cplus_b /= U_R0_inf_norm;
}





void CC_bwd_basis_state::change_channels (const complex<double> &E)
{
  for (unsigned int ic = 0 ; ic < N_channels ; ic++) channels_tab(ic).E_dependent_values_change (E);
}



double used_memory_calc (const class CC_bwd_basis_state &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.channels_tab) +
    used_memory_calc (T.r_bef_R_tab_uniform) +
    used_memory_calc (T.r_bef_R_tab_GL) +
    used_memory_calc (T.u_aft_R_tab_GL) +
    used_memory_calc (T.r_aft_R_real_tab_GL) +
    used_memory_calc (T.CC_bwd_basis_wf_aft_R0_tab_uniform) +
    used_memory_calc (T.CC_bwd_basis_dwf_aft_R0_tab_uniform) +
    used_memory_calc (T.CC_bwd_basis_wf_aft_R0_tab_GL) +
    used_memory_calc (T.CC_bwd_basis_dwf_aft_R0_tab_GL) +
    used_memory_calc (T.CC_bwd_basis_wf_R0_tab) +
    used_memory_calc (T.CC_bwd_basis_dwf_R0_tab)
    - (sizeof (T.channels_tab) +
       sizeof (T.r_bef_R_tab_uniform) +
       sizeof (T.r_bef_R_tab_GL) +
       sizeof (T.u_aft_R_tab_GL) +
       sizeof (T.r_aft_R_real_tab_GL) +
       sizeof (T.CC_bwd_basis_wf_aft_R0_tab_uniform) +
       sizeof (T.CC_bwd_basis_dwf_aft_R0_tab_uniform) +
       sizeof (T.CC_bwd_basis_wf_aft_R0_tab_GL) +
       sizeof (T.CC_bwd_basis_dwf_aft_R0_tab_GL) +
       sizeof (T.CC_bwd_basis_wf_R0_tab) +
       sizeof (T.CC_bwd_basis_dwf_R0_tab))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}


