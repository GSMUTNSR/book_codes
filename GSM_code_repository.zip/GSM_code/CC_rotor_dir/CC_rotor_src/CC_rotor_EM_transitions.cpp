#include "../CC_rotor_include/CC_rotor_include.h"

using namespace Wigner_signs;
using namespace correlated_state_routines;




// Calculation of |Psi[in]>, |Psi[out]> and <Psi[out] | EM | Psi[in]> in the nuclear case
// --------------------------------------------------------------------------------------



//--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> before R

complex<double> CC_rotor_EM_transitions::radial_integral_bef_R_calc (
								     const enum radial_operator_type radial_operator , 
								     const int L , 
								     const bool is_it_longwavelength_approximation , 
								     const class CC_rotor_states_class &CC_state_in , 
								     const class CC_rotor_states_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out)
{
  //--// positions and weights
  const class array<double> &r_bef_R_tab_GL = CC_state_out.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = CC_state_out.get_w_bef_R_tab_GL ();

  //--// tables containing the wfs of all channels
  const class array<complex<double> > &CC_wf_bef_R_tab_GL_in  = CC_state_in.get_CC_wf_bef_R_tab_GL ();
  const class array<complex<double> > &CC_wf_bef_R_tab_GL_out = CC_state_out.get_CC_wf_bef_R_tab_GL ();

  const complex<double> E_in  = CC_state_in.get_E ();
  const complex<double> E_out = CC_state_out.get_E ();

  const complex<double> q = (E_in - E_out) / hbar_c;
  
  //--// number of discretization points , and a factor
  const unsigned int N_bef_R_GL = CC_state_out.get_N_bef_R_GL ();

  const complex<double> factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  complex<double> radial_integral_bef_R = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i); 

      const complex<double> Or = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor ,  Bessel , r);

      if (!finite (Or)) continue;

      const complex<double> CC_wf_bef_R_in_r  = CC_wf_bef_R_tab_GL_in  (ic_in  , i);
      const complex<double> CC_wf_bef_R_out_r = CC_wf_bef_R_tab_GL_out (ic_out , i);
      
      radial_integral_bef_R += w * CC_wf_bef_R_in_r * CC_wf_bef_R_out_r * Or;
    }

  return radial_integral_bef_R;
}













complex<double> CC_rotor_EM_transitions::radial_integral_aft_R_calc (
								     const enum radial_operator_type radial_operator , 
								     const int L , 
								     const bool is_it_longwavelength_approximation , 
								     const class CC_rotor_states_class &CC_state_in , 
								     const class CC_rotor_states_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out)
{
  //--// number of discretization points , and a factor
  const unsigned int N_aft_R_GL = CC_state_out.get_N_aft_R_GL ();

  const double R = CC_state_out.get_R ();

  const complex<double> I(0 , 1);

  const class array<class CC_rotor_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_rotor_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_rotor_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_rotor_channel_class &channel_c_out = channels_tab_out(ic_out);

  const complex<double> E_in  = CC_state_in.get_E ();
  const complex<double> E_out = CC_state_out.get_E ();

  const complex<double> q = (E_in - E_out) / hbar_c;
  
  const complex<double> factor = double_factorial (2*L + 1)/(L + 1.0)/pow (q , L);

  class Coulomb_wave_functions Bessel(true , L , 0);

  const complex<double> kc_in  = channel_c_in.get_kc ();
  const complex<double> kc_out = channel_c_out.get_kc ();

  const double theta = M_PI_2 - arg (kc_in + kc_out);

  const complex<double> exp_Itheta = exp (I*theta);

  const class array<double> &u_aft_R_GL = CC_state_out.get_u_aft_R_GL ();
  const class array<double> &weights_aft_R_GL = CC_state_out.get_weights_aft_R_GL ();

  class array<complex<double> > z_tab_GL (N_aft_R_GL);
  class array<complex<double> > w_tab_GL (N_aft_R_GL);

  class array<complex<double> > CC_wf_in_aft_R_tab_GL (N_aft_R_GL);
  class array<complex<double> > CC_dwf_in_aft_R_tab_GL (N_aft_R_GL);
  class array<complex<double> > CC_d2wf_in_aft_R_tab_GL (N_aft_R_GL);

  class array<complex<double> > CC_wf_out_aft_R_tab_GL (N_aft_R_GL);
  class array<complex<double> > CC_dwf_out_aft_R_tab_GL (N_aft_R_GL);
  class array<complex<double> > CC_d2wf_out_aft_R_tab_GL (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double u = u_aft_R_GL (i);

      const double x = pow (u , -4);

      z_tab_GL (i) = R + (x - R) * exp_Itheta;
	  
      w_tab_GL (i) = weights_aft_R_GL (i) * x/u;
    }

  CC_state_in.complex_scaling_wave_function_after_R_calc  (ic_in  , z_tab_GL , CC_wf_in_aft_R_tab_GL  , CC_dwf_in_aft_R_tab_GL  , CC_d2wf_in_aft_R_tab_GL);
  CC_state_out.complex_scaling_wave_function_after_R_calc (ic_out , z_tab_GL , CC_wf_out_aft_R_tab_GL , CC_dwf_out_aft_R_tab_GL , CC_d2wf_out_aft_R_tab_GL);

  complex<double> radial_integral_aft_R = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const complex<double> z = z_tab_GL (i);
      const complex<double> w = w_tab_GL (i);

      const complex<double> Oz = EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , factor , Bessel , z);

      if (!finite (Oz)) continue;

      const complex<double> CC_wf_aft_R_in_z  = CC_wf_in_aft_R_tab_GL (i);
      const complex<double> CC_wf_aft_R_out_z = CC_wf_out_aft_R_tab_GL(i);
      
      radial_integral_aft_R += w * CC_wf_aft_R_in_z * CC_wf_aft_R_out_z * Oz;
    }

  radial_integral_aft_R *= 4.0*exp_Itheta;

  return radial_integral_aft_R;
}





//--// return the radial part of <uc_f lf jf || E_L || uc_i li ji>
complex<double> CC_rotor_EM_transitions::radial_integral_calc ( 
							       const enum radial_operator_type radial_operator , 
							       const int L , 
							       const bool is_it_longwavelength_approximation ,
							       const class CC_rotor_states_class &CC_state_in , 
							       const class CC_rotor_states_class &CC_state_out , 
							       const unsigned int ic_in , 
							       const unsigned int ic_out)
{
  const complex<double> radial_integral_bef_R = radial_integral_bef_R_calc (radial_operator , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> radial_integral_aft_R = radial_integral_aft_R_calc (radial_operator , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  
  const complex<double> radial_integral = radial_integral_bef_R + radial_integral_aft_R;
  
  return radial_integral;
}








//--// return <uc_f lf jf || E_L || uc_i li ji>
complex<double> CC_rotor_EM_transitions::OBME_electric_reduced_calc (
								     const int L , 
								     const bool is_it_longwavelength_approximation , 
								     const double effective_charge , 
								     const class CC_rotor_states_class &CC_state_in , 
								     const class CC_rotor_states_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out)
{
  const unsigned int BP_Op = BP_EM_determine (ELECTRIC , L);
  
  const class array<class CC_rotor_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_rotor_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_rotor_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_rotor_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int lc_in  = channel_c_in.get_lc ();
  const int lc_out = channel_c_out.get_lc ();
  
  if (binary_parity_from_orbital_angular_momentum (lc_in + lc_out) != BP_Op) return 0.0;
    
  const enum particle_type particle_c_in  = channel_c_in.get_particle_c ();
  const enum particle_type particle_c_out = channel_c_out.get_particle_c ();
  
  if (particle_c_in != particle_c_out) return 0.0;
  
  const int jrc_in  = channel_c_in.get_jrc ();
  const int jrc_out = channel_c_out.get_jrc ();

  if (jrc_in != jrc_out) return 0.0;

  const double jc_in  = channel_c_in.get_jc ();
  const double jc_out = channel_c_out.get_jc ();
  
  const int Lmin = abs (make_int (jc_in - jc_out));

  const int Lmax = make_int (jc_in + jc_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;

  //--// calculations of the radial electric charge and current
  const complex<double> ECH_radial_ME = radial_integral_calc (ELECTRIC_CHARGE_RADIAL  , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> EC_radial_ME  = radial_integral_calc (ELECTRIC_CURRENT_RADIAL , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  //--// here the angular part <lf jf || E_L || li ji> is taken into account

  const complex<double> ECH_ME = EM_suboperator_OBME_reduced_calc (ELECTRIC_CHARGE  , L , particle_c_in , particle_c_out , effective_charge , NADA , ECH_radial_ME , lc_in , jc_in , lc_out , jc_out);
  const complex<double> EC_ME  = EM_suboperator_OBME_reduced_calc (ELECTRIC_CURRENT , L , particle_c_in , particle_c_out , effective_charge , NADA , EC_radial_ME  , lc_in , jc_in , lc_out , jc_out);

  const complex<double> electric_ME = ECH_ME + EC_ME;

  return electric_ME;
}









//--// return <uc_f lf jf || M_L || uc_i li ji>
complex<double> CC_rotor_EM_transitions::OBME_magnetic_reduced_calc (
								     const int L , 
								     const bool is_it_longwavelength_approximation , 
								     const class CC_rotor_states_class &CC_state_in , 
								     const class CC_rotor_states_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out)
{	
  const unsigned int BP_Op = BP_EM_determine (MAGNETIC , L);

  const class array<class CC_rotor_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_rotor_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_rotor_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_rotor_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int lc_in  = channel_c_in.get_lc ();
  const int lc_out = channel_c_out.get_lc ();

  if (binary_parity_from_orbital_angular_momentum (lc_in + lc_out) != BP_Op) return 0.0;
  
  const enum particle_type particle_c_in  = channel_c_in.get_particle_c ();
  const enum particle_type particle_c_out = channel_c_out.get_particle_c ();

  if (particle_c_in != particle_c_out) return 0.0;

  const int jrc_in  = channel_c_in.get_jrc ();
  const int jrc_out = channel_c_out.get_jrc ();

  if (jrc_in != jrc_out) return 0.0;
  
  const double jc_in  = channel_c_in.get_jc ();
  const double jc_out = channel_c_out.get_jc ();

  const int Lmin = abs (make_int (jc_in - jc_out));

  const int Lmax = make_int (jc_in + jc_out);

  if ((L < Lmin) || (L > Lmax)) return 0.0;
  
  // calculations of the radial magnetic charge and current

  const complex<double> MOLP1_radial_ME = radial_integral_calc (GRADIENT_BESSEL_YLP1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> MOLM1_radial_ME = radial_integral_calc (GRADIENT_BESSEL_YLM1                    , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> MSLP1_radial_ME = radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> MSLM1_radial_ME = radial_integral_calc (GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1 , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
  const complex<double> MSSCE_radial_ME = radial_integral_calc (MAGNETIC_SPIN_S_SCALAR_E_RADIAL         , L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);

  // here the angular part <lf jf || M_L || li ji> is taken into account
  const complex<double> MOLP1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLP1_TENSOR_L_L                 , L , particle_c_in , particle_c_out , NADA , NADA , MOLP1_radial_ME , lc_in , jc_in , lc_out , jc_out);
  const complex<double> MOLM1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_ORBITAL_GRADIENT_BESSEL_YLM1_TENSOR_L_L                 , L , particle_c_in , particle_c_out , NADA , NADA , MOLM1_radial_ME , lc_in , jc_in , lc_out , jc_out);  
  const complex<double> MSLP1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLP1_TENSOR_S_L , L , particle_c_in , particle_c_out , NADA , NADA , MSLP1_radial_ME , lc_in , jc_in , lc_out , jc_out);
  const complex<double> MSLM1_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_YLM1_TENSOR_S_L , L , particle_c_in , particle_c_out , NADA , NADA , MSLM1_radial_ME , lc_in , jc_in , lc_out , jc_out); 
  const complex<double> MSSCE_ME = EM_suboperator_OBME_reduced_calc (MAGNETIC_SPIN_S_SCALAR_E                                         , L , particle_c_in , particle_c_out , NADA , NADA , MSSCE_radial_ME , lc_in , jc_in , lc_out , jc_out);

  const complex<double> magnetic_ME = MOLP1_ME + MOLM1_ME + MSLP1_ME + MSLM1_ME + MSSCE_ME;

  return magnetic_ME;
}







// return <uc_f lf jf || M/E_L || uc_i li ji>
complex<double> CC_rotor_EM_transitions::OBME_reduced_calc (
							    const enum EM_type EM , 
							    const int L , 
							    const bool is_it_longwavelength_approximation , 
							    const double effective_charge , 
							    const class CC_rotor_states_class &CC_state_in , 
							    const class CC_rotor_states_class &CC_state_out , 
							    const unsigned int ic_in , 
							    const unsigned int ic_out)
{
  switch (EM)
    {
    case ELECTRIC: return OBME_electric_reduced_calc (L , is_it_longwavelength_approximation , effective_charge , CC_state_in , CC_state_out , ic_in , ic_out);
      
    case MAGNETIC: return OBME_magnetic_reduced_calc (L , is_it_longwavelength_approximation , CC_state_in , CC_state_out , ic_in , ic_out);
      
    default: abort_all ();
    }

  return NADA;
}









complex<double> CC_rotor_EM_transitions::B_amplitude_calc (
							   const enum EM_type EM , 
							   const int L , 
							   const bool is_it_longwavelength_approximation , 
							   const double effective_charge , 
							   const class CC_rotor_states_class &CC_state_in , 
							   const class CC_rotor_states_class &CC_state_out)
{
  const unsigned int N_channels = CC_state_in.get_N_channels ();

  complex<double> B_amplitude = 0.0;

  for (unsigned int ic_in = 0 ; ic_in < N_channels ; ic_in++)
    for (unsigned int ic_out = 0 ; ic_out < N_channels ; ic_out++)
      B_amplitude += OBME_reduced_calc (EM , L , is_it_longwavelength_approximation , effective_charge , CC_state_in , CC_state_out , ic_in , ic_out);

  return B_amplitude;
}













void CC_rotor_EM_transitions::EM_transition_calc (const class CC_rotor_all_data_class &CC_rotor_all_data ,
						  const class CC_rotor_states_class &CC_state_in , 
						  const class CC_rotor_states_class &CC_state_out)
{  
  cout << endl;
  cout << "=====================================================================================================" << endl;
  cout << "========================= CC_rotor_EM_transitions: EM transition calculation ========================" << endl;
  cout << "=====================================================================================================" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum EM_type EM = CC_rotor_input.get_EM ();

  const int A = CC_rotor_input.get_A  ();
  const int N = CC_rotor_input.get_N  ();
  const int Z = CC_rotor_input.get_Z  ();

  const int L = CC_rotor_input.get_L  ();

  const bool is_it_longwavelength_approximation = CC_rotor_input.get_is_it_longwavelength_approximation ();

  const double effective_charge = CC_rotor_input.get_effective_charge ();

  const unsigned int BP_IN  = CC_rotor_input.get_BP_IN ();
  const unsigned int BP_OUT = CC_rotor_input.get_BP_OUT ();

  const double J_IN  = CC_rotor_input.get_J_IN ();
  const double J_OUT = CC_rotor_input.get_J_OUT ();

  const unsigned int eigenvector_index_IN  = CC_rotor_input.get_eigenvector_index_IN ();
  const unsigned int eigenvector_index_OUT = CC_rotor_input.get_eigenvector_index_OUT ();

  const complex<double> E_IN  = CC_state_in.get_E ();
  const complex<double> E_OUT = CC_state_out.get_E ();

  const complex<double> q = (E_IN - E_OUT)/hbar_c;

  const complex<double> B_amplitude = B_amplitude_calc (EM , L , is_it_longwavelength_approximation , effective_charge , CC_state_in , CC_state_out);

  const class correlated_state_str CC_rotor_state_IN_qn  (Z , N , BP_IN  , 0 , J_IN  , eigenvector_index_IN  , E_IN  , NADA , NADA , NADA , false); 
  const class correlated_state_str CC_rotor_state_OUT_qn (Z , N , BP_OUT , 0 , J_OUT , eigenvector_index_OUT , E_OUT , NADA , NADA , NADA , false); 

  print_B_G (EM , q , L , is_it_longwavelength_approximation , A , CC_rotor_state_IN_qn , CC_rotor_state_OUT_qn , B_amplitude);
}





void CC_rotor_EM_transitions::CC_states_IN_OUT_EM_transition_calc (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const unsigned int BP_IN  = CC_rotor_input.get_BP_IN ();
  const unsigned int BP_OUT = CC_rotor_input.get_BP_OUT ();

  const double J_IN  = CC_rotor_input.get_J_IN ();
  const double J_OUT = CC_rotor_input.get_J_OUT ();

  const unsigned int eigenvector_index_IN  = CC_rotor_input.get_eigenvector_index_IN ();
  const unsigned int eigenvector_index_OUT = CC_rotor_input.get_eigenvector_index_OUT ();

  const double Vo_basis_IN  = CC_rotor_input.get_Vo_basis_IN ();
  const double Vo_basis_OUT = CC_rotor_input.get_Vo_basis_OUT ();
  
  const double Vo_IN  = CC_rotor_input.get_Vo_IN ();
  const double Vo_OUT = CC_rotor_input.get_Vo_OUT ();

  CC_rotor_input.set_BP (BP_IN);
  CC_rotor_input.set_J (J_IN);
  CC_rotor_input.set_eigenvector_index (eigenvector_index_IN);
  CC_rotor_input.set_Vo_basis (Vo_basis_IN);
  CC_rotor_input.set_Vo (Vo_IN);

  CC_rotor_all_data.build_channels ();
  CC_rotor_all_data.build_potential ();
  CC_rotor_all_data.build_data_for_solvers ();

  class CC_rotor_states_class CC_state_IN (CC_rotor_all_data);

  CC_state_IN.solve_CC_equations (CC_rotor_all_data);

  CC_rotor_input.set_BP (BP_OUT);
  CC_rotor_input.set_J (J_OUT);
  CC_rotor_input.set_eigenvector_index (eigenvector_index_OUT);
  CC_rotor_input.set_Vo_basis (Vo_basis_OUT);
  CC_rotor_input.set_Vo (Vo_OUT);

  CC_rotor_all_data.get_channels_tab ()          .deallocate ();
  CC_rotor_all_data.get_CC_rotor_potential ()    .deallocate ();
  CC_rotor_all_data.get_data ()                  .deallocate ();
  CC_rotor_all_data.get_Vccp_tab_bef_s_GL ()     .deallocate ();
  CC_rotor_all_data.get_Vccp_tab_bef_R_GL ()     .deallocate ();
  CC_rotor_all_data.get_Vccp_tab_aft_R_GL ()     .deallocate ();
  CC_rotor_all_data.get_Vccp_tab_aft_R_GL_real ().deallocate ();

  CC_rotor_all_data.build_channels ();
  CC_rotor_all_data.build_potential ();
  CC_rotor_all_data.build_data_for_solvers ();

  class CC_rotor_states_class CC_state_OUT (CC_rotor_all_data);

  CC_state_OUT.solve_CC_equations (CC_rotor_all_data);

  EM_transition_calc (CC_rotor_all_data , CC_state_IN , CC_state_OUT);
}
