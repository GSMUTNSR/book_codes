#include "../CC_rotor_include/CC_rotor_include.h"

using namespace CC_rotor_Berggren_basis;


// Calculation of the energy and rms radii of Hamiltonian eigenvectors in the nuclear case with several WS potential depths
// ------------------------------------------------------------------------------------------------------------------------



void CC_rotor_E_rms_radius_plot::E_rms_radius_plot_calc_store (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << endl;
  cout << "========================================================================================================================================" << endl;
  cout << "========================= CC_rotor_E_rms_radius_plot: calculation and storage of plots of energy and rms radius ========================" << endl;
  cout << "========================================================================================================================================" << endl << endl;
 
  class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
  
  const enum potential_type potential = CC_rotor_input.get_potential ();
  
  const enum particle_type particle = CC_rotor_input.get_particle ();
  
  const int ZY_charge = CC_rotor_input.get_ZY_charge ();
  
  const double mass_modif = CC_rotor_input.get_mass_modif ();

  const double nucleon_mass_for_calc = CC_rotor_input.get_nucleon_mass_for_calc ();

  const double kinetic_factor_static_core = kinetic_factor_calc (false , mass_modif , nucleon_mass_for_calc);
  
  const unsigned int N_points = CC_rotor_input.get_N_points ();

  const double Vo_debut = CC_rotor_input.get_Vo_debut ();
  const double Vo_end   = CC_rotor_input.get_Vo_end   ();

  const double step_Vo = (Vo_end - Vo_debut)/static_cast<double> (N_points - 1);
  
  const bool is_DIM = CC_rotor_input.get_is_CC_solver_direct_integration ();
  
  const bool is_basis_fixed = CC_rotor_input.get_is_basis_fixed_for_E_rms_radius_plot ();

  ofstream E_rms_radius_plot_outfile ("E_rms_radius_plot.dat");

  CC_rotor_all_data.build_channels ();
  
  if (is_basis_fixed)
    {
      cout << endl;
      cout << "Berggren expansion method (BEM)" << endl;
      cout << "-------------------------------" << endl << endl;
      cout << "--> build fixed Berggren basis" << endl << endl;

      CC_rotor_all_data.build_potential ();
      CC_rotor_all_data.build_Berggren_basis ();
      
      build_basis_states (CC_rotor_all_data);

      print_basis_states_bad_overlaps (CC_rotor_all_data);
      
      CC_rotor_all_data.get_CC_rotor_potential ().deallocate ();
    }
  
  for (unsigned int i = 0 ; i < N_points ; i++)
    {
      const double Vo = Vo_debut + i*step_Vo;

      cout << endl;
      cout << "=================================================================================================" << endl;

      if (i <= 9)              cout << "========================================= Iteration : " << i << " =========================================" << endl;
      else if (i <= 99)        cout << "========================================= Iteration : " << i << " ========================================"  << endl;
      else if (i <= 999)       cout << "========================================= Iteration : " << i << " ======================================="   << endl;
      else if (i <= 9999)      cout << "========================================= Iteration : " << i << " ======================================"    << endl;
      else if (i <= 99999)     cout << "========================================= Iteration : " << i << " ====================================="     << endl;
      else if (i <= 999999)    cout << "========================================= Iteration : " << i << " ===================================="      << endl;
      else if (i <= 9999999)   cout << "========================================= Iteration : " << i << " ==================================="       << endl;
      else if (i <= 99999999)  cout << "========================================= Iteration : " << i << " =================================="        << endl;
      else if (i <= 999999999) cout << "========================================= Iteration : " << i << " ================================="         << endl;
      else                     cout << "========================================= Iteration : " << i << " ================================"          << endl;
      
      cout << "=================================================================================================" << endl << endl;
      
      cout << "Vo : " << Vo << " MeV" << endl << endl;

      CC_rotor_input.set_Vo (Vo);

      if (!is_basis_fixed) CC_rotor_input.set_Vo_basis (Vo);
	
      CC_rotor_all_data.build_potential ();
	  
      if (is_basis_fixed)
	{
	  cout << endl;
	  cout << "Berggren expansion method (BEM)" << endl;
	  cout << "-------------------------------" << endl << endl;
	  cout << "--> build CC potentials" << endl << endl;

	  CC_rotor_all_data.calc_potential_channel_channel_MEs_Vccp ();
	}
      else
	CC_rotor_all_data.build_data_for_solvers ();
      
      class CC_rotor_states_class CC_states (CC_rotor_all_data);
  
      CC_states.solve_CC_equations (CC_rotor_all_data);

      const complex<double> E = CC_states.get_E ();

      const double energy = real (E);

      const double width = -2000.0*imag (E);
	      
      const complex<double> rms_radius = CC_states.get_rms_radius ();

      if (potential == DEFORMED_WS_STATIC)
	{
	  const complex<double> k = sqrt_mod (kinetic_factor_static_core*E);

	  const complex<double> eta = eta_calc (false , particle , ZY_charge , kinetic_factor_static_core , k);
			
	  E_rms_radius_plot_outfile << Vo << " " << real (k) << " " << imag (k) << " " << real (eta) << " " << imag (eta) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;
	}
      else
	E_rms_radius_plot_outfile << Vo << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;

      if (!is_basis_fixed) CC_rotor_all_data.get_data ().deallocate ();
      
      CC_rotor_all_data.get_CC_rotor_potential ().deallocate ();
      CC_rotor_all_data.get_Vccp_tab_bef_s_GL ().deallocate ();
      CC_rotor_all_data.get_Vccp_tab_bef_R_GL ().deallocate ();
      CC_rotor_all_data.get_Vccp_tab_aft_R_GL ().deallocate ();
      CC_rotor_all_data.get_Vccp_tab_aft_R_GL_real ().deallocate ();
      
      if (is_DIM) CC_rotor_input.set_E (E); // better starting point for next DIM
    }
}
