#include "../CC_rotor_include/CC_rotor_include.h"


// Rotor channel class
// ------------------

// Constructors
// ------------
// Static rotor: I = +oo and K representation => J and jr are not good quantum numbers and K is a good quantum number
//               Electromagnetic transitions are undefined as they demand J to be a good quantum number.
//               Densities based on the transformation laboratory/COSM -> rotation axis cannot be used as well.
//
// Rotating core: I is finite and one uses laboratory/COSM representation, J and jr are well defined and K is not a good quantum number in general.

CC_rotor_channel_class::CC_rotor_channel_class () :
  is_it_static_core (false) ,
  particle_c (NO_PARTICLE) ,
  kinetic_factor_c (0.0) , 
  ZY_charge_c (0.0) , 
  jrc (0.0) , 
  lc (0) ,
  jc (0.0) , 
  J (0.0) , 
  K (0.0) , 
  I (0.0) , 
  E_Tc (0.0) ,
  e_c (0.0) ,
  kc (0.0) ,
  eta_c (0.0) , 
  E (0.0)
{}

CC_rotor_channel_class::CC_rotor_channel_class (const class CC_rotor_channel_class &X)
{
  initialize (X);
}
  
void CC_rotor_channel_class::initialize (const class CC_rotor_channel_class &X)
{
  is_it_static_core = X.is_it_static_core;

  particle_c = X.particle_c; 

  kinetic_factor_c = X.kinetic_factor_c; 

  ZY_charge_c = X.ZY_charge_c; 

  jrc = X.jrc;

  lc = X.lc; 

  jc = X.jc; 

  J = X.J;

  K = X.K;

  I = X.I;

  E_Tc = X.E_Tc;

  e_c = X.e_c;
  
  kc = X.kc;

  eta_c = X.eta_c;

  E = X.E;
}

void CC_rotor_channel_class::allocate_fill (const class CC_rotor_channel_class &X)
{
  initialize (X);
}

void CC_rotor_channel_class::operator = (const class CC_rotor_channel_class &X)
{
  initialize (X);
}

// Static rotor
CC_rotor_channel_class::CC_rotor_channel_class (
						const enum particle_type particle_c_c , 	
						const double kinetic_factor_c_c , 
						const int ZY_charge_c_c , 
						const int lc_c , 
						const double jc_c , 
						const double K_c , 
						const complex<double> &E_c)
{
  initialize (particle_c_c , kinetic_factor_c_c , ZY_charge_c_c , lc_c , jc_c , K_c , E_c);
}



void CC_rotor_channel_class::initialize (
					 const enum particle_type particle_c_c , 	
					 const double kinetic_factor_c_c , 
					 const int ZY_charge_c_c , 
					 const int lc_c , 
					 const double jc_c , 
					 const double K_c , 
					 const complex<double> &E_c)
{
  is_it_static_core = true;

  particle_c = particle_c_c; 

  kinetic_factor_c = kinetic_factor_c_c; 

  ZY_charge_c = ZY_charge_c_c; 

  jrc = NADA; 

  lc = lc_c; 

  jc = jc_c; 

  J = NADA;

  K = K_c;

  I = INFINITE;

  E_Tc = 0.0;  

  E_dependent_values_change (E_c);
}





// Rotating core
CC_rotor_channel_class::CC_rotor_channel_class (
						const enum particle_type particle_c_c , 	
						const double kinetic_factor_c_c , 
						const int ZY_charge_c_c , 
						const int jrc_c , 
						const int lc_c , 
						const double jc_c , 
						const double J_c , 
						const double I_c , 
						const complex<double> &E_c)
{
  initialize (particle_c_c , kinetic_factor_c_c , ZY_charge_c_c , jrc_c , lc_c , jc_c , J_c , I_c , E_c);
}

void CC_rotor_channel_class::initialize (
					 const enum particle_type particle_c_c , 	
					 const double kinetic_factor_c_c , 
					 const int ZY_charge_c_c , 
					 const int jrc_c , 
					 const int lc_c , 
					 const double jc_c , 
					 const double J_c , 
					 const double I_c , 
					 const complex<double> &E_c)
{
  is_it_static_core = false;

  particle_c = particle_c_c; 

  kinetic_factor_c = kinetic_factor_c_c; 

  ZY_charge_c = ZY_charge_c_c; 

  jrc = jrc_c; 

  lc = lc_c; 

  jc = jc_c; 

  J = J_c;

  K = NADA;

  I = I_c; 

  E_dependent_values_change (E_c);
}





/* E_dependent_values_change
 */

void CC_rotor_channel_class::E_dependent_values_change (const complex<double> &E_c)
{
  E = E_c;
  
  if (!is_it_static_core) E_Tc = (particle_c == ELECTRON) ? (jrc * (jrc + 1.0)/I) : ((jrc * (jrc + 1.0)/I) / kinetic_factor_c);
    
  e_c = E - E_Tc;
      
  // in our case : - hbar^2/2I * j (j + 1) + E_n^J = kc^2
  kc = (particle_c == ELECTRON) ? (sqrt_mod (e_c)) : (sqrt_mod (kinetic_factor_c*e_c));
  
  eta_c = (particle_c == ELECTRON) ? (0.0) : (eta_calc (false , particle_c , ZY_charge_c , kinetic_factor_c , kc));
}




ostream& operator << (ostream &os , const class CC_rotor_channel_class &channel)
{ 
  const enum particle_type particle_c = channel.get_particle_c ();

  const bool is_it_static_core = channel.get_is_it_static_core ();
  
  const int jrc = channel.get_jrc ();

  const int lc = channel.get_lc ();
  
  const double jc = channel.get_jc ();
  
  const double J = channel.get_J ();
  const double K = channel.get_K ();
  
  if (is_it_static_core)
    {
      const unsigned int BP = binary_parity_from_orbital_angular_momentum (lc);
      
      if ((particle_c == PROTON) || (particle_c == NEUTRON))
	os << angular_state (lc , jc) << " K:" << M_Pi_string (BP , K);
      else
	error_message_print_abort ("Particle type unavailable in operator << (CC_rotor_channel_class (static rotor)");
    }
  else
    {
      const unsigned int BP = binary_parity_from_orbital_angular_momentum (jrc + lc);
  
      if (particle_c == ELECTRON) 
	os << "(jr:" << jrc << " l:" << lc << ")^(J-Pi=" << J_Pi_string (BP , J) << ")";
      else if ((particle_c == PROTON) || (particle_c == NEUTRON))
	os << "(jr:" << jrc << " " << angular_state (lc , jc) << ")^(J=" << J_Pi_string (BP , J) << ")";
      else
	error_message_print_abort ("Particle type unavailable in operator << (CC_rotor_channel_class (rotating core)");
    }
  
  return os;
}


double used_memory_calc (const class CC_rotor_channel_class &T)
{
  return sizeof (T)/1000000.0;
}
