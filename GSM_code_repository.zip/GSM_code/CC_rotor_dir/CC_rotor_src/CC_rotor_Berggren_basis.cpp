#include "../CC_rotor_include/CC_rotor_include.h"

using namespace string_routines;
using namespace Gauss_Legendre;

// Calculation of the Berggren basis to diagonalize the coupled-channel Hamiltonian matrix
// ---------------------------------------------------------------------------------------





void CC_rotor_Berggren_basis::state_rejection_test ( 
						    const class array<class nlj_struct> &shells_qn , 
						    const unsigned int state , 
						    class array<class spherical_state> &shells)

{
  class spherical_state &shell = shells[state];

  const enum particle_type particle = shell.get_particle ();
      
  const int n = shell.get_n ();

  const int l = shell.get_l ();

  const int jr = shell.get_jr ();

  const double j = shell.get_j ();

  const complex<double> ks = shell.get_k ();

  const double Es = real (shell.get_E ());

  //// ===================================================================== // 
  //// remove core shells
  //if ((particle == NEUTRON) || (particle == PROTON))
  //{
  //	const enum calc_type_rotor_CC calc_type = CC_rotor_input.calc_type;
  //	const double j = shell.get_j ();

  //	if ((calc_type != MOLECULAR) || (calc_type == OPTIMIZATION))
  //	{
  //		const class array<string> &core_shells_tab = CC_rotor_input.get_core_shells_tab ();
  //		for (unsigned int i = 0 ; i < core_shells_tab.dimension (0) ; i++)
  //		{
  //			string core_shell = core_shells_tab (i);
  //			const int n_core_shell = determine_n (core_shell);
  //			const int l_core_shell = determine_l (core_shell);
  //			const double j_core_shell = determine_j (core_shell);
  //                    if (same_nlj_particle (n , l , j , n_core_shell , l_core_shell , j_core_shell))
  //			{
  //				shell.is_k_OK = false;
  //				cout << "--> Core shell rejected : " << core_shell << endl;
  //			}
  //		}
  //	}
  //	else
  //	{
  //		error_message_print_abort ("CC_rotor_Berggren_basis::state_rejection_test: bad calc type");
  //	}
  //}
  //// ===================================================================== //

  // remove antibound states
  if ((Es < 0.0) && (imag (ks) < 0.0))
    {
      cout << "--> Antibound or virtual state rejected : " << shell << endl << endl;
      shell.reject ();
      return;
    }

  if (!shell.get_is_k_OK ()) return;

  bool rejected = false;

  //xyz ce test n'est pas valide si n , l , j , jr
  for (unsigned int state_p = 0 ; (state_p < state) && (!rejected) ; state_p++)
    {
      const class nlj_struct &shell_qn_p = shells_qn[state_p];
  
      const bool S_matrix_pole_p = shell_qn_p.get_S_matrix_pole ();
      
      const int np = shell_qn_p.get_n ();

      const int lp = shell_qn_p.get_l ();

      const int jrp = shell_qn_p.get_jr ();

      const double jp = shell_qn_p.get_j ();

      if (S_matrix_pole_p && same_lj_particle (particle , l , jr , j , particle , lp , jrp , jp) && (np < n))
	{
	  const class spherical_state &shell_p = shells[state_p];
	  
	  const double Esp = real (shell_p.get_E ());

	  const bool is_k_OK_p = shell_p.get_is_k_OK ();

	  //if ((Es < Esp) || (abs (Es - Esp) < 1))//xyz original , elimine trop , arbitrary
	  if (is_k_OK_p && ((Es < Esp) || (abs (Es - Esp) < 1.0e-5)))//xyz arbitrary
	    {
	      cout << "--> Pole not found: rejected" << endl;
	      rejected = true;
	      shell.reject ();
	    }
	}
    }
}












void CC_rotor_Berggren_basis::wave_function_potential_allocate (
								class CC_rotor_all_data_class &CC_rotor_all_data , 
								const unsigned int shell_index , 
								class potentials_effective_mass &all)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  class Berggren_data &data = CC_rotor_all_data.get_data ();

  class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class nlj_struct &sh = shells_qn(shell_index);

  const int n = sh.get_n ();

  const int jr = sh.get_jr ();

  const int l = sh.get_l ();

  const int A_equiv = data.get_A_equiv ();

  const double j = sh.get_j ();

  class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_bef_s_GL = data.get_N_bef_s_GL ();
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();
  
  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = data.get_N_aft_R_uniform ();
  
  const unsigned int Nk_momentum_GL = data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = data.get_Nk_momentum_uniform ();
  
  const double R = data.get_R ();
  
  const double R0 = data.get_R0 ();
  
  const double R_real_max = data.get_R_real_max ();
  
  const double kmax_momentum = data.get_kmax_momentum ();

  const double R_Fermi_momentum = data.get_R_Fermi_momentum ();
  
  const double s_radial = data.get_s ();

  const bool S_matrix_pole = sh.get_S_matrix_pole ();

  const complex<double> k = sh.get_k ();

  // alias on the shell
  class spherical_state &shell = shells (shell_index);

  // create the shell (no calculations)
    
  switch (potential)
    {
    case DIPOLAR:
      {
	// basis with l and jr
	const class dipolar_potential_class &dipolar_potential = CC_rotor_potential.get_dipolar_potential ();

	class dipolar_potential_class &V_dipolar = all.get_V_dipolar ();
      
	V_dipolar.allocate_fill (dipolar_potential);

	shell.allocate (false , true , potential , A_equiv , 0 , 0.0 , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
			R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , ELECTRON , n , jr , l , NADA , true , k , NADA , 1.0 , 1.0);
      } break;
  
    case QUADRUPOLAR:
      {
	// basis with l and jr
	const class quadrupolar_potential_class &quadrupolar_potential = CC_rotor_potential.get_quadrupolar_potential ();

	class quadrupolar_potential_class &V_quadrupolar = all.get_V_quadrupolar ();
      
	V_quadrupolar.allocate_fill (quadrupolar_potential);

	shell.allocate (false , true , potential , A_equiv , 0 , 0.0 , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
			R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , ELECTRON , n , jr , l , NADA , true , k , NADA , 1.0 , 1.0);
      } break;

    case GAUSSIAN:
      {
	// basis with l and jr
	const class Gaussian_potential_class &Gaussian_potential = CC_rotor_potential.get_Gaussian_potential ();
	
	class Gaussian_potential_class &V_Gaussian = all.get_V_Gaussian ();

	V_Gaussian.allocate_fill (Gaussian_potential);

	shell.allocate(false , true , potential , A_equiv , 0 , 0.0 , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
		       R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , ELECTRON , n , jr , l , NADA , true , k , NADA , 1.0 , 1.0);
      } break;
  
    case DEFORMED_WS:
      {
	const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();
	
	if (calc_type == MOLECULAR) error_message_print_abort ("CC_rotor_Berggren_basis::wave_function_potential_allocate: bad calc type (deformed WS)");    

	const enum particle_type particle = CC_rotor_input.get_particle ();

	const class deformed_WS_class &deformed_WS_potential_basis = CC_rotor_potential.get_deformed_WS_potential_basis ();

	const unsigned int A = CC_rotor_input.get_A ();
	
	const int ZY_charge = CC_rotor_input.get_ZY_charge ();

	const unsigned int core_mass = CC_rotor_input.get_mass_modif ();

	const double nucleon_mass_for_calc = CC_rotor_input.get_nucleon_mass_for_calc ();

	// basis with l and j
	class deformed_WS_class &V_deformed_WS = all.get_V_deformed_WS ();

	V_deformed_WS.allocate_fill (deformed_WS_potential_basis);

	shell.allocate (false , true , potential , A , ZY_charge , core_mass , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
			R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , particle , n , jr , l , j , true , k , nucleon_mass_for_calc , 1.0 , 1.0);
      } break;
      
    case DEFORMED_WS_STATIC:
      {
	const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();
	
	if (calc_type == MOLECULAR) error_message_print_abort ("CC_rotor_Berggren_basis::wave_function_potential_allocate: bad calc type (deformed WS static)");    

	const enum particle_type particle = CC_rotor_input.get_particle ();

	const class deformed_WS_static_class &deformed_WS_static_potential_basis = CC_rotor_potential.get_deformed_WS_static_potential_basis ();

	const unsigned int A = CC_rotor_input.get_A ();

	const int ZY_charge = CC_rotor_input.get_ZY_charge ();
	
	const unsigned int core_mass = CC_rotor_input.get_mass_modif ();

	const double nucleon_mass_for_calc = CC_rotor_input.get_nucleon_mass_for_calc ();

	// basis with l and j
	class deformed_WS_static_class &V_deformed_WS_static = all.get_V_deformed_WS_static ();

	V_deformed_WS_static.allocate_fill (deformed_WS_static_potential_basis);

	shell.allocate (false , true , potential , A , ZY_charge , core_mass , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
			R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , particle , n , jr , l , j , true , k , nucleon_mass_for_calc , 1.0 , 1.0);
      } break;
      
    default: error_message_print_abort ("CC_rotor_Berggren_basis::wave_function_potential_allocate: bad potential type");    
    }

  all.initialize_constants (
			    shell.get_potential () ,
			    shell.get_kinetic_factor () ,
			    shell.get_jr () ,
			    shell.get_l () ,
			    shell.get_ZY_charge () ,
			    shell.get_j () ,
			    shell.get_k () ,
			    shell.get_eta () ,
			    NADA);
}












void CC_rotor_Berggren_basis::wave_function_quadrupolar_starting_point_calculation (
										    class CC_rotor_all_data_class &CC_rotor_all_data , 
										    const unsigned int shell_index, 
										    class potentials_effective_mass &all)
{
  class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class nlj_struct &sh = shells_qn(shell_index);

  const int n = sh.get_n ();

  const int jr = sh.get_jr ();

  const int l = sh.get_l ();

  const int A_equiv = data.get_A_equiv ();

  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_bef_s_GL = data.get_N_bef_s_GL (); 
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL (); 

  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();

  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform (); 
  const unsigned int N_aft_R_uniform = data.get_N_aft_R_uniform ();

  const unsigned int Nk_momentum_GL = data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = data.get_Nk_momentum_uniform ();
  
  const double R = data.get_R (); 

  const double R0 = data.get_R0 (); 

  const double R_real_max = data.get_R_real_max (); 

  const double kmax_momentum = data.get_kmax_momentum ();

  const double R_Fermi_momentum = data.get_R_Fermi_momentum ();
  
  const double s_radial = data.get_s ();

  const bool S_matrix_pole = sh.get_S_matrix_pole ();

  const complex<double> k = sh.get_k ();

  // alias on the shell
  class spherical_state &shell = shells (shell_index);

  // 1) try to guess the energy using an HO potential
  // 2) if nothing is found or badly determined (large det_Jost) , 
  // try to approach step-by-step the possible state by using an unphysical potential (easy convergence) that changes smoothly to the physical one

  cout << endl << "Try HO guess: n : " << n << " l : " << l << " jr : " << jr << endl;
  shell.k_search (all , false , true);
  bool is_state_found = shell.get_is_k_OK ();

  // keep track of previous E found
  // initialise to zero if one starts a new series of n = 0 , 1 , etc.
  class array<complex<double> > &Ef_BEM_start_tab = CC_rotor_input.get_Ef_BEM_start_tab ();
  if (n == 0)
    Ef_BEM_start_tab = 0.0;

  const complex<double> Ef = shell.get_E ();
  Ef_BEM_start_tab[n] = Ef;

  // try to make the integration of the Vcc potential 
  // to converge for any value of Qpm in N steps
  if (!is_state_found)
    {
      cout << "State not found using HO_guess" << endl << endl;
      // activate the step-by-step search of the energy
      shell.set_is_k_search_start_used (true);

      const unsigned int N_Qpm_BEM_max = CC_rotor_input.get_N_Qpm_BEM_max ();
      const double Qpm_BEM_final = CC_rotor_input.get_Qpm ();
      const double sign_Q = (Qpm_BEM_final < 0) ? (-1.0) : (1.0);

      const double Qpm_BEM_initial = CC_rotor_input.get_Qpm_BEM_initial ();
      cout << endl << "Basis state calculation using step-by-step approach (Qpm_initial = " << Qpm_BEM_initial << ") n : " << n << " l : " << l << " jr : " << jr << endl;

      // partition of a segment (whatever its length) in various ways
      // the partition series must be positive decreasing and ends to zero into N_Qpm_BEM_max steps
      vector<double> vec_Q_diff_partition (N_Qpm_BEM_max);
      double sum_Q_diff = 0.0;
      for (unsigned int i = 0 ; i < N_Qpm_BEM_max ; i++)
	{
	  // partition function
	  vec_Q_diff_partition[i] = 1.0/(i + 1.0) - 1.0/(N_Qpm_BEM_max + 1.0);

	  sum_Q_diff += vec_Q_diff_partition[i];
	}

      // normalization of the partition to the Q range length
      const double Q_range_length = abs (Qpm_BEM_initial - Qpm_BEM_final);
      const double Q_normalization_factor = Q_range_length / sum_Q_diff;

      for (unsigned int i = 0 ; i < N_Qpm_BEM_max ; i++) vec_Q_diff_partition[i] *= Q_normalization_factor;

      const class array<double> &E_BEM_start_tab = CC_rotor_input.get_E_BEM_start_tab ();
      const class array<double> &G_BEM_start_tab = CC_rotor_input.get_G_BEM_start_tab ();
      
      const unsigned int num_trials = E_BEM_start_tab.dimension (0);

      // try to converge on the n'(l , jr) energy using each initial E 
      // that has not been found previously for any given n(l , jr) with n < n'
      // stop if the convergence is established
      unsigned int j = 0;

      while ((!is_state_found) && (j < num_trials))
	{	  
	  const double ReE =      E_BEM_start_tab[j];
	  const double ImE = -0.5*G_BEM_start_tab[j];
	  
	  complex<double> E_BEM_initial (ReE , ImE);

	  cout << endl << "Initial E : " << E_BEM_initial << endl;

	  const double J = CC_rotor_input.get_J ();

	  double Q_intermediate = Qpm_BEM_initial;
	  
	  for (unsigned int i = 0 ; i <= N_Qpm_BEM_max ; i++)
	    {	      
	      cout << "Q[intermediate] : " << Q_intermediate << endl;
	      
	      const class quadrupolar_potential_class quad_pot_tempo (CC_rotor_input.get_s () , Q_intermediate , CC_rotor_input.get_V0 () , CC_rotor_input.get_rc () , J , CC_rotor_input.get_lmax ());

	      class potentials_effective_mass all_quad_tempo;

	      class quadrupolar_potential_class &V_quadrupolar = all_quad_tempo.get_V_quadrupolar ();

	      V_quadrupolar.allocate_fill (quad_pot_tempo);

	      class spherical_state sph_state_quad_tempo (false , true , potential , A_equiv , 0 , 0.0 ,
							  N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
							  R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , ELECTRON , n , jr , l , NADA , true , k , NADA , 1.0 , 1.0);
	      
	      // activate the step-by-step search of the energy
	      sph_state_quad_tempo.set_is_k_search_start_used (true);
	      sph_state_quad_tempo.set_k_search_start (sqrt_mod (sph_state_quad_tempo.get_kinetic_factor ()*E_BEM_initial));	      
	      sph_state_quad_tempo.k_search (all_quad_tempo , false , true);

	      E_BEM_initial = sph_state_quad_tempo.get_E ();

	      const double Q_step = sign_Q * vec_Q_diff_partition[i];
	      Q_intermediate -= Q_step;

	      cout << endl;
	    }

	  cout << "Final trial : " << endl;
	  shell.set_k_search_start (sqrt_mod (shell.get_kinetic_factor ()*E_BEM_initial));
	  shell.k_search (all , false , true);
	  // true if converged
	  is_state_found = shell.get_is_k_OK ();

	  if (is_state_found)
	    {
	      // keep track of previous E found
	      const complex<double> Ef = shell.get_E ();
	      Ef_BEM_start_tab[n] = Ef;

	      // eliminate false positive (E already found before , for the same l , jr but smaller n)
	      bool is_discarded = false;
	      for (unsigned int ki = 0 ; ki < Ef_BEM_start_tab.dimension (0) ; ki++)
		for (unsigned int kj = 0 ; kj < ki ; kj++)
		  {
		    const complex<double> Ef_i = Ef_BEM_start_tab[ki];
		    const complex<double> Ef_j = Ef_BEM_start_tab[kj];
		    const bool is_it_zero = ((Ef_i == 0.0) || (Ef_j == 0.0));
		    const double diff = abs (Ef_BEM_start_tab[ki] - Ef_BEM_start_tab[kj]);

		    // if two energies (except zero) are almost identical , discard the state
		    if ((!is_it_zero) && (diff < 1.0e-4) && (!is_discarded))//xyz arbitrary
		      {
			shell.reject ();
			is_state_found = shell.get_is_k_OK ();
			is_discarded = true;
			cout << "State discarded: same energy as the previous one" << endl << endl;
		      }
		  }
	    }

	  j++;
	}
    }
  else
    cout << "State found using HO_guess" << endl << endl;
}




void CC_rotor_Berggren_basis::wave_function_Gaussian_starting_point_calculation (
										 class CC_rotor_all_data_class &CC_rotor_all_data , 
										 const unsigned int shell_index, 
										 class potentials_effective_mass &all)
{
  class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class nlj_struct &sh = shells_qn(shell_index);

  const int n = sh.get_n ();

  const int jr = sh.get_jr ();

  const int l = sh.get_l ();

  const int A_equiv = data.get_A_equiv ();

  const class array<class spherical_state> &shells = data.get_shells ();

  const unsigned int N_bef_s_GL = data.get_N_bef_s_GL ();
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();

  const unsigned int N_bef_R_uniform = data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = data.get_N_aft_R_uniform ();

  const unsigned int Nk_momentum_GL = data.get_Nk_momentum_GL ();

  const unsigned int Nk_momentum_uniform = data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = CC_rotor_input.get_Nr ();
  const unsigned int Nt = CC_rotor_input.get_Nt ();
  
  const double R = data.get_R ();

  const double R0 = data.get_R0 ();

  const double R_real_max = data.get_R_real_max ();

  const double kmax_momentum = data.get_kmax_momentum ();

  const double R_Fermi_momentum = data.get_R_Fermi_momentum ();
  
  const double s_radial = data.get_s ();

  const bool S_matrix_pole = sh.get_S_matrix_pole ();

  const complex<double> k = sh.get_k ();

  // alias on the shell
  class spherical_state &shell = shells (shell_index);

  // 1) try to guess the energy using an HO potential
  // 2) if nothing is found or badly determined (large det_Jost),
  // try to approach step-by-step the possible state by using an unphysical potential (easy convergence) that changes smoothly to the physical one

  //cout << "Try HO guess: n : " << n << " l : " << l << " jr : " << jr << endl;
  //shell.k_search (all , false , true);
  //bool is_state_found = shell.is_k_OK;
  bool is_state_found = false;

  // keep track of previous E found
  // initialise to zero if one starts a new series of n = 0, 1, etc.
  class array<complex<double> > &Ef_BEM_start_tab = CC_rotor_input.get_Ef_BEM_start_tab ();

  if (n == 0) Ef_BEM_start_tab = 0.0;

  const complex<double> Ef = shell.get_E ();

  Ef_BEM_start_tab[n] = Ef;

  // try to make the integration of the Vcc potential 
  // to converge for any value of Qpm in N steps
  if (!is_state_found)
    {
      cout << "State not found using HO_guess" << endl << endl;
      
      // activate the step-by-step search of the energy

      shell.set_is_k_search_start_used (true);

      const unsigned int N_V0_Gaussian_BEM_max = CC_rotor_input.get_N_V0_Gaussian_BEM_max ();
      
      const double V0_Gaussian_BEM_final = CC_rotor_input.get_V0_Gaussian ();

      const double V0_Gaussian_BEM_initial = CC_rotor_input.get_V0_Gaussian_BEM_initial ();

      cout << "Basis state calculation using step-by-step approach (V0_Gaussian_BEM_intial = " << V0_Gaussian_BEM_initial << ") n : " << n << " l : " << l << " jr : " << jr << endl;

      // partition of a segment (whatever its length) in various ways
      // the partition series must be positive decreasing and ends to zero into N_Qpm_BEM_max steps

      vector<double> vec_V0_Gaussian_diff_partition (N_V0_Gaussian_BEM_max);

      double sum_V0_Gaussian_diff = 0.0;

      for (unsigned int i = 0 ; i < N_V0_Gaussian_BEM_max ; i++)
	{
	  // partition function

	  vec_V0_Gaussian_diff_partition[i] = 1.0/(i + 1.0) - 1.0/(N_V0_Gaussian_BEM_max + 1.0);

	  sum_V0_Gaussian_diff += vec_V0_Gaussian_diff_partition[i];
	}

      // normalization of the partition to the V0 range length

      const double V0_Gaussian_range_length = abs (V0_Gaussian_BEM_initial - V0_Gaussian_BEM_final);

      const double V0_Gaussian_normalization_factor = V0_Gaussian_range_length / sum_V0_Gaussian_diff;
      
      for (unsigned int i = 0 ; i < N_V0_Gaussian_BEM_max ; i++)
	vec_V0_Gaussian_diff_partition[i] *= V0_Gaussian_normalization_factor;


      const class array<double> &E_BEM_start_tab = CC_rotor_input.get_E_BEM_start_tab ();
      const class array<double> &G_BEM_start_tab = CC_rotor_input.get_G_BEM_start_tab ();
      
      const unsigned int num_trials = E_BEM_start_tab.dimension (0);

      // try to converge on the n'(l,jr) energy using each initial E 
      // that has not been found previously for any given n(l,jr) with n < n'
      // stop if the convergence is established

      unsigned int j = 0;

      while ((!is_state_found) && (j < num_trials))
	{
	  const double ReE = E_BEM_start_tab[j];
	  const double ImE = -G_BEM_start_tab[j] / 2.0;
	  
	  complex<double> E_BEM_initial (ReE,ImE);

	  cout << "Initial E : " << E_BEM_initial << endl;

	  double V0_Gaussian_intermediate = V0_Gaussian_BEM_initial;
	  
	  for (unsigned int i = 0; i <= N_V0_Gaussian_BEM_max; i++)
	    {	
	      const class Gaussian_potential_class Gaussian_pot_tempo(Nr , Nt , R ,
								      V0_Gaussian_intermediate,
								      CC_rotor_input.get_r0_Gaussian (),
								      CC_rotor_input.get_mu_Gaussian (),
								      CC_rotor_input.get_J (),
								      CC_rotor_input.get_lmax (),
								      CC_rotor_input.get_polarity_Gaussian ());
	      
	      class potentials_effective_mass all_Gaussian_tempo;
	      
	      all_Gaussian_tempo.get_V_Gaussian ().allocate_fill (Gaussian_pot_tempo);

	      class spherical_state sph_state_gauss_tempo (false , true , potential , A_equiv , 0 , 0.0 ,
							   N_bef_s_GL , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , Nk_momentum_GL , Nk_momentum_uniform , 
							   R , s_radial , R0 , R_real_max , kmax_momentum , R_Fermi_momentum , S_matrix_pole , ELECTRON , n , jr , l , NADA , true , k , NADA , 1.0 , 1.0);

	      cout << "V0 try = " << V0_Gaussian_intermediate << endl;

	      // activate the step-by-step search of the energy
	      sph_state_gauss_tempo.set_is_k_search_start_used (true);
	      sph_state_gauss_tempo.set_k_search_start (sqrt_mod (sph_state_gauss_tempo.get_kinetic_factor ()*E_BEM_initial));
	      sph_state_gauss_tempo.k_search (all_Gaussian_tempo , false , true);

	      const complex<double> E_i = sph_state_gauss_tempo.get_E ();
	      E_BEM_initial = E_i;

	      const double V0_Gaussian_step = vec_V0_Gaussian_diff_partition[i];
	      
	      V0_Gaussian_intermediate += V0_Gaussian_step;
	    }

	  cout << "Final trial : " << endl;

	  shell.set_k_search_start (sqrt_mod (shell.get_kinetic_factor ()*E_BEM_initial));

	  shell.k_search (all , false , true);
	  // true if converged
	  is_state_found = shell.get_is_k_OK ();

	  cout << "state found : " << is_state_found << endl;
	  
	  if (is_state_found)
	    {
	      // keep track of previous E found
	      const complex<double> Ef = shell.get_E ();
	      Ef_BEM_start_tab[n] = Ef;

	      // eliminate false positive (E already found before, for the same l,jr but smaller n)
	      bool is_discarded = false;
	      for (unsigned int ki = 0 ; ki < Ef_BEM_start_tab.dimension (0) ; ki++)
		{
		  for (unsigned int kj = 0 ; kj < ki ; kj++)
		    {
		      const complex<double> Ef_i = Ef_BEM_start_tab[ki];
		      const complex<double> Ef_j = Ef_BEM_start_tab[kj];

		      const bool is_it_zero = ((Ef_i == 0.0) || (Ef_j == 0.0));
		      
		      const double diff = abs (Ef_BEM_start_tab[ki] - Ef_BEM_start_tab[kj]);
								
		      // if two energies (except zero) are almost identical, discard the state

		      if ((!is_it_zero) && (diff < 1.0e-4) && (!is_discarded))//xyz arbitrary
			{
			  shell.reject ();

			  is_state_found = shell.get_is_k_OK ();

			  is_discarded = true;

			  cout << "State discarded: same energy as the previous one" << endl;
			}
		    }
		}
	    }
	  j++;
	}
    }
  else
    cout << "State found using HO_guess" << endl;
}









void CC_rotor_Berggren_basis::wave_function_calculation (class CC_rotor_all_data_class &CC_rotor_all_data , const unsigned int shell_index)
{
  class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
   
  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  class Berggren_data &data = CC_rotor_all_data.get_data ();

  class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  class nlj_struct &sh = shells_qn(shell_index);

  const double b_HO = CC_rotor_input.get_b_HO ();
  
  const int n = sh.get_n ();
  
  const int jr = sh.get_jr ();
  
  const int l = sh.get_l ();

  const double j = sh.get_j ();
    
  class array<class spherical_state> &shells = data.get_shells ();

  const bool S_matrix_pole = sh.get_S_matrix_pole ();

  // interface for potentials and spherical states
  class potentials_effective_mass all;

  // alias on the shell
  class spherical_state &shell = shells (shell_index);
    
  wave_function_potential_allocate (CC_rotor_all_data , shell_index , all);

  all.initialize_constants (shell.get_potential () , shell.get_kinetic_factor () , shell.get_jr () , shell.get_l () , shell.get_ZY_charge () , shell.get_j () , shell.get_k () , shell.get_eta () , NADA);

  // ================================== ================================== //
  // remove core shells

  const enum particle_type particle = shell.get_particle ();	

  bool is_it_rejected_core_shell = false;

  if ((calc_type != MOLECULAR) && S_matrix_pole)
    {
      const class array<string> &core_shells_tab = CC_rotor_input.get_core_shells_tab ();

      for (unsigned int i = 0 ; i < core_shells_tab.dimension (0) ; i++)
	{
	  string core_shell = core_shells_tab (i);

	  const int n_core_shell = determine_n (core_shell);
	  const int l_core_shell = determine_l (core_shell);

	  const double j_core_shell = determine_j (core_shell);

	  if (same_nlj_particle (particle , n , l , j , particle , n_core_shell , l_core_shell , j_core_shell))
	    {
	      shell.reject ();

	      is_it_rejected_core_shell = true;

	      if (potential == DEFORMED_WS_STATIC)
		cout << "--> Core shell rejected : " << core_shell << endl;
	      else
		cout << "--> Core shell rejected : " << "(jr : " << jr << ")" << core_shell << endl;
	      
	    }
	}

      cout << endl;
    }

  // calculate the associated energy and print
  if (S_matrix_pole)
    {
      if (potential == QUADRUPOLAR) 
	wave_function_quadrupolar_starting_point_calculation (CC_rotor_all_data , shell_index, all);
      else if (potential == GAUSSIAN) 
	wave_function_Gaussian_starting_point_calculation (CC_rotor_all_data , shell_index, all);
      else
	{
	  // here core shells have been declared as "not OK" , no need to search their energies
	  if (!is_it_rejected_core_shell)
	    {
	      const bool all_states = (particle != ELECTRON);

	      shell.k_search (all , all_states , true);
	    }
	}

      // remove core shells , antibound states or duplicate states (different qn but same energy because of the algorithm)
      state_rejection_test (shells_qn , shell_index , shells);
    }

  // calculate the wf (normalized if resonant)
  shell.wave_calculation (true , all , true);
  
  shell.wave_calculation_momentum (b_HO);
  
  if (!S_matrix_pole) shell.normalization (sqrt (sh.get_weight ()));

  sh.initialize (n , jr , l , j , S_matrix_pole , shell.get_k () , sh.get_weight () , sh.get_ic ());
}











void CC_rotor_Berggren_basis::shells_quantum_numbers_with_scat_calc (const enum particle_type particle , const int ZY_charge , class Berggren_data &data)
{
  const class array<unsigned int> &Nk_peak_tab = data.get_Nk_peak_tab ();
  const class array<unsigned int> &Nk_middle_tab = data.get_Nk_middle_tab ();
  const class array<unsigned int> &Nk_max_tab = data.get_Nk_max_tab ();
  
  const class array<complex<double> > &k_peak_tab = data.get_k_peak_tab ();
  
  const class array<double> &k_middle_tab = data.get_k_middle_tab ();
  const class array<double> &k_max_tab = data.get_k_max_tab ();

  const unsigned int N_channels = data.get_N_channels ();
  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  const class array<class CC_rotor_channel_class> &channels_tab = data.get_channels_tab ();
  
  const double R = data.get_R ();

  class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
	      
  unsigned int s_counter = N_nlj_res;

  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    {
      const class CC_rotor_channel_class &channel_c = channels_tab(ic);

      const int jrc = channel_c.get_jrc ();
      const int lc = channel_c.get_lc ();

      const double jc = channel_c.get_jc ();

      const complex<double> k_peak = k_peak_tab (ic);

      const double k_middle = k_middle_tab (ic);
      const double k_max = k_max_tab (ic);

      const unsigned int Nk_peak = Nk_peak_tab (ic);
      const unsigned int Nk_middle = Nk_middle_tab (ic);

      const unsigned int Nk_max = Nk_max_tab (ic);
      const unsigned int N_scat = Nk_peak + Nk_middle + Nk_max;

      const complex<double> k_start = k_start_calc (false , particle , lc , ZY_charge , R);

      class array<complex<double> > k_tab (N_scat);
      class array<complex<double> > weight_tab (N_scat);
	  
      k_w_tab_segment_part_calc (0                   , Nk_peak   , k_start  , k_peak   , k_tab , weight_tab);
      k_w_tab_segment_part_calc (Nk_peak             , Nk_middle , k_peak   , k_middle , k_tab , weight_tab);
      k_w_tab_segment_part_calc (Nk_peak + Nk_middle , Nk_max    , k_middle , k_max    , k_tab , weight_tab);
      
      //get the "n" (radial number) of the first scattering state above resonant states for this partial wave

      int n_deb = 0;

      for (unsigned int i = 0 ; i < N_nlj_res ; i++)
	{
	  const class nlj_struct &s_qn = shells_qn[i];

	  if ((s_qn.get_ic () == ic) && (s_qn.get_n () > n_deb)) n_deb = s_qn.get_n ();
	}

      n_deb++;

      const int nmax =  make_int (N_scat) + n_deb - 1;

	      
      // build the shells quantum numbers objetcs for scattering states
      for (int n = n_deb ; n <= nmax ; n++)
	{
	  const complex<double> k = k_tab (n - n_deb);
	  const complex<double> w = weight_tab (n - n_deb);
      
	  shells_qn(s_counter++).initialize (n , jrc , lc , jc , false , k , w , ic);
	}
    }
}




// dscretize the contour edge by edge for each partial wave
void CC_rotor_Berggren_basis::contours_discretization (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  class Berggren_data &data = CC_rotor_all_data.get_data ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();

  if ((potential != QUADRUPOLAR) && (potential != GAUSSIAN))
    {
      const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();
  
      const enum particle_type particle = CC_rotor_input.get_particle ();

      const int ZY_charge = CC_rotor_input.get_ZY_charge ();
  
      shells_quantum_numbers_with_scat_calc (particle , ZY_charge , data);
    }
  else
    {
      const class CC_rotor_contour_data_class &contours = data.get_contours_data ();

      const class array<class CC_rotor_contour_class> &contours_tab = contours.get_contours_tab ();

      const unsigned int N_channels = data.get_N_channels ();

      const unsigned int N_nlj_res = data.get_N_nlj_res ();

      const class array<class CC_rotor_channel_class> &channels_tab = data.get_channels_tab ();

      const double R = data.get_R ();

      class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

      unsigned int s_counter = N_nlj_res;
      
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab(ic);
	  
	  const int jrc = channel_c.get_jrc ();

	  const int lc = channel_c.get_lc ();

	  const double jc = channel_c.get_jc ();

	  const complex<double> k_start = k_start_calc (false , ELECTRON , lc , 0 , R);

	  class CC_rotor_contour_class &contour_ic = contours_tab[ic];
	  
	  const unsigned int N_scat = contour_ic.get_number_points_total ();
	  
	  class array<complex<double> > k_tab (N_scat);

	  class array<complex<double> > weight_tab (N_scat);

	  class array<complex<double> > &tab_k_ic = contour_ic.get_tab_k ();
	  
	  class array<unsigned int> &tab_Nk_ic = contour_ic.get_tab_Nk ();

	  const unsigned int number_edge = contour_ic.get_number_edges ();
	  
	  unsigned int Nk_shift_tab_index = 0;
	  
	  for (unsigned int i = 0 ; i < number_edge ; i++)
	    {
	      // the origin is assumed to be at (0 , 0)
	      
	      const complex<double> k_initial = (i == 0) ? (k_start) : (tab_k_ic[i-1]);
	      
	      const complex<double> k_final = tab_k_ic[i];

	      const unsigned int Nk = tab_Nk_ic[i];
	      
	      if (Nk != 0) k_w_tab_segment_part_calc (Nk_shift_tab_index , Nk , k_initial , k_final , k_tab , weight_tab);

	      Nk_shift_tab_index += Nk;
	    }

	  //get the "n" (radial number) of the first scattering state above resonant states for this partial wave
	  int n_deb = 0;
	  
	  for (unsigned int i = 0 ; i < N_nlj_res ; i++)
	    {
	      const class nlj_struct &s_qn = shells_qn[i];

	      if ((s_qn.get_ic () == ic) && (s_qn.get_n () > n_deb))
		n_deb = s_qn.get_n ();
	    }
	  
	  n_deb++;

	  const int nmax =  make_int (N_scat) + n_deb - 1;

	  // build the shells quantum numbers objetcs for scattering states
	  for (int n = n_deb ; n <= nmax ; n++)
	    {
	      const complex<double> k = k_tab (n - n_deb) , w =  weight_tab (n - n_deb);

	      shells_qn(s_counter++).initialize (n , jrc , lc , jc , false , k , w , ic);
	    }
	}
    }
}





void CC_rotor_Berggren_basis::bad_resonant_states_removal (class Berggren_data &data)
{
  const unsigned int N_nlj_res_start = data.get_N_nlj_res ();

  const unsigned int N_nlj_start = data.get_N_nlj ();

  class array<class spherical_state> &shells = data.get_shells ();

  class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  unsigned int N_nlj_res = N_nlj_res_start;

  for (unsigned int s = 0 ; s < N_nlj_res_start ; s++)
    {
      const class spherical_state &shell = shells(s);
      
      const bool is_k_OK = shell.get_is_k_OK ();

      if (!is_k_OK) N_nlj_res--;
    }

  const unsigned int N_nlj_scat = N_nlj_start - N_nlj_res_start;

  const unsigned int N_nlj = N_nlj_res + N_nlj_scat;

  // this new table will contain all shells (res and scatt)
  
  class array<class spherical_state> new_shells(N_nlj);

  class array<class nlj_struct> new_shells_qn(N_nlj);

  unsigned int new_s = 0;

  // update of res shells
  for (unsigned int s = 0 ; s < N_nlj_res_start ; s++)
    {
      const class spherical_state &shell = shells(s);

      const bool is_k_OK = shell.get_is_k_OK ();

      if (is_k_OK)
	{
	  new_shells(new_s).allocate_fill (shells(s));
	  new_shells_qn(new_s) = shells_qn(s);
	  new_s++;
	}
    }

  data.set_N_nlj_res (N_nlj_res);

  data.set_N_nlj (N_nlj);

  shells.deallocate ();

  shells.allocate (N_nlj);

  for (unsigned int s = 0 ; s < N_nlj ; s++) shells(s).allocate_fill (new_shells(s));

  shells_qn.deallocate ();

  shells_qn.allocate_fill (new_shells_qn);
}



void CC_rotor_Berggren_basis::print_poles (const class CC_rotor_all_data_class &CC_rotor_all_data , const bool are_poles_printed)
{
  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const class array<class spherical_state> &shells_res = data.get_shells ();

  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  if (N_nlj_res != 0)
    {
      const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

      for (unsigned int s = 0 ; s < N_nlj_res ; s++)
	{
	  const class spherical_state &shell = shells_res(s);

	  const bool is_k_OK = shell.get_is_k_OK ();

	  const complex<double> k = shell.get_k ();
	  const complex<double> E = shell.get_E ();

	  if (is_k_OK)
	    {
	      const double E_print = real (E);
  
	      const double Gamma_print = -2.0*imag (E);

	      if (calc_type == MOLECULAR) 
		cout << shell << "  k : " << k << " fm^(-1)  E : " << E_print << " Ry Gamma : " << Gamma_print << " Ry " << endl << endl;
	      else
		cout << shell << "  k : " << k << " fm^(-1)  E : " << E_print << " MeV Gamma : " << Gamma_print << " MeV " << endl << endl;
	    }

	  const int l = shell.get_l ();

	  const int jr = shell.get_jr ();

	  const double j = shell.get_j ();

	  if (are_poles_printed)
	    {
	      ostringstream os;

	      if (calc_type == MOLECULAR)
		os << "contour_l_" << l << "_jr_" << jr;
	      else
		os << "contour_l_" << l << "_j_" << j;

	      const string file_name = STORAGE_DIR + os.str () + "_poles"; 

	      ofstream outfile (file_name.c_str () , std::ofstream::out | std::ofstream::app);

	      outfile << real (k) << " \t " << imag (k) << " \t " << real (E) << " \t " << imag (E) << endl;
	    }
	}
    }
  else
    {
      cout << "--> no poles" << endl << endl;
    }
}

















void CC_rotor_Berggren_basis::build_basis_states (class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "================================================================================================" << endl;
  cout << "================ CC_rotor_Berggren_basis::build_basis_states (n , [jr] , l , j) ================" << endl;
  cout << "================================================================================================" << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const enum calc_type_rotor_CC calc_type = CC_rotor_input.get_calc_type ();

  const string units = (calc_type == MOLECULAR) ? (" Ry") : (" MeV");

  class Berggren_data &data = CC_rotor_all_data.get_data ();

  const unsigned int N_channels = data.get_N_channels ();

  const double Gamma_max = CC_rotor_input.get_Gamma_max ();

  const class CC_rotor_potential_class &CC_rotor_potential = CC_rotor_all_data.get_CC_rotor_potential ();

  const enum potential_type potential = CC_rotor_potential.get_potential ();
  
  if ((potential != QUADRUPOLAR) && (potential != GAUSSIAN))
    {
      const class array<unsigned int> &Nk_peak_tab = data.get_Nk_peak_tab ();

      const class array<unsigned int> &Nk_middle_tab = data.get_Nk_middle_tab ();

      const class array<unsigned int> &Nk_max_tab = data.get_Nk_max_tab ();

      unsigned int N_nlj = data.get_N_nlj_res ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) N_nlj += Nk_peak_tab (ic) + Nk_middle_tab (ic) + Nk_max_tab (ic);

      data.set_N_nlj (N_nlj);
    }
  else
    {
      const class CC_rotor_contour_data_class &contours = data.get_contours_data ();

      const class array<class CC_rotor_contour_class> &contours_tab = contours.get_contours_tab ();

      unsigned int N_nlj = data.get_N_nlj_res ();

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) N_nlj += contours_tab[ic].get_number_points_total ();
      
      data.set_N_nlj (N_nlj);
    }

  const unsigned int N_nlj_res_start = data.get_N_nlj_res ();

  class array<class spherical_state> &shells = data.get_shells ();
  
  shells.allocate (N_nlj_res_start);
  
  // resonant states
  cout << endl;
  cout << "Resonant states (poles) search" << endl;
  cout << "------------------------------" << endl;

  for (unsigned int s = 0 ; s < N_nlj_res_start ; s++)
    {
      // build spherical states
      wave_function_calculation (CC_rotor_all_data , s);

      class spherical_state &shell = shells(s);

      const complex<double> k = shell.get_k () , E = shell.get_E ();
      const double Gamma = -2.0*imag (E);

      if ((real (k) == 0.0) && (imag (k) < precision)) shell.reject ();

      if (Gamma > Gamma_max)
	{
	  shell.reject ();
	  cout << "--> " << shell << " Shell rejected: width (E : " << real (E) << " , G : " << Gamma << ") larger than " << Gamma_max << units << endl << endl;
	}

    }

  cout << endl;

  cout << "Possible poles in the basis" << endl;
  cout << "---------------------------" << endl << endl;

  bool are_poles_printed = false;

  print_poles (CC_rotor_all_data , are_poles_printed);

  cout << "Remove bad resonant shells" << endl;
  cout << "--------------------------" << endl << endl;
  bad_resonant_states_removal (data);

  cout << "Remaining poles in the basis (printed in " + STORAGE_DIR + "/contour_lj_poles)" << endl;
  cout << "----------------------------------------------------------------------" << endl << endl;
  are_poles_printed = true;
  print_poles (CC_rotor_all_data , are_poles_printed);

  // scattering states
  const unsigned int N_nlj_res = data.get_N_nlj_res ();

  const bool pole_approximation = CC_rotor_input.get_pole_approximation ();

  if (pole_approximation)
    {
      cout << "--> No scattering states in pole space." << endl << endl;
    }
  else
    {
      cout << "Scattering states" << endl;
      cout << "-----------------" << endl << endl;

      cout << "contour L+ discretization" << endl;
      cout << "-------------------------" << endl << endl;
      contours_discretization (CC_rotor_all_data);

      cout << "Scattering states calculation" << endl;
      cout << "-----------------------------" << endl << endl;

      const unsigned int N_nlj = data.get_N_nlj ();

      for (unsigned int s = N_nlj_res ; s < N_nlj ; s++) wave_function_calculation (CC_rotor_all_data , s);

      cout << endl;
    }
}











void CC_rotor_Berggren_basis::print_basis_states_bad_overlaps (const class CC_rotor_all_data_class &CC_rotor_all_data)
{
  cout << "Berggren basis overlaps" << endl;
  cout << "-----------------------" << endl << endl;

  const class CC_rotor_input_class &CC_rotor_input = CC_rotor_all_data.get_CC_rotor_input ();

  const bool pole_approximation = CC_rotor_input.get_pole_approximation ();

  const class Berggren_data &data = CC_rotor_all_data.get_data ();

  const unsigned int N_nlj = (pole_approximation) ? (data.get_N_nlj_res ()) : (data.get_N_nlj ());

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();

  const class array<class spherical_state> &shells = data.get_shells ();

  class array<double> infinite_norm_overlap_tab(N_nlj , N_nlj);

  for (unsigned int in = 0 ; in < N_nlj ; in++)
    for (unsigned int out = 0 ; out < in ; out++)
      {
	const class nlj_struct &s_in_qn  = shells_qn(in);
	const class nlj_struct &s_out_qn = shells_qn(out);
	  
	const unsigned int ic_in  = s_in_qn.get_ic ();
	const unsigned int ic_out = s_out_qn.get_ic ();
	  
	const class spherical_state &wf_in  = shells(in);
	const class spherical_state &wf_out = shells(out);

	infinite_norm_overlap_tab(in , out) = inf_norm (CC_rotor_Berggren_diagonalization::OBME (OVERLAP_OP , CC_rotor_all_data , ic_in , ic_out , wf_in , wf_out));
      }

  double max_infinite_norm_overlap = 0.0 , infinite_norm_overlap_sum = 0.0 , infinite_norm_overlap_squares_sum = 0.0;

  unsigned int N = 0;

  for (unsigned int in = 0 ; in < N_nlj ; in++)
    for (unsigned int out = 0 ; out < in ; out++)
      {
	const class nlj_struct &s_in_qn  = shells_qn(in);
	const class nlj_struct &s_out_qn = shells_qn(out);
	  
	const unsigned int ic_in  = s_in_qn.get_ic ();
	const unsigned int ic_out = s_out_qn.get_ic ();

	if (ic_in == ic_out)
	  {
	    const double infinite_norm_overlap = infinite_norm_overlap_tab(in , out);

	    max_infinite_norm_overlap = max (infinite_norm_overlap , max_infinite_norm_overlap);
	    
	    infinite_norm_overlap_sum += infinite_norm_overlap;
	    
	    infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;
	    
	    N++;
	  }
      }

  if (N >= 1)
    {
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N;

      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);  

      cout << "Maximal       |overlap|oo : " << max_infinite_norm_overlap << endl;
      cout << "Average       |overlap|oo : " << infinite_norm_overlap_average << endl; 
      cout << "Dispersion of |overlap|oo : " << infinite_norm_overlap_sigma << endl << endl;
    }
}

