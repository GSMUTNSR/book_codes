#include "../CC_rotor_include/CC_rotor_include.h"



// ================================== constructors ================================== //


CC_rotor_contour_data_class::CC_rotor_contour_data_class ()
  : 
  number_contours (0) , 
  number_edges_max (0) , 
  plot_file_name ("plot_contours") , 
  index_default_case (0) , 
  N_channels (0)
{
	
}


CC_rotor_contour_data_class::CC_rotor_contour_data_class (
							  const class array<string> &partial_wave_str_tab ,
							  const class array<complex<double> > &tabs_k ,
							  const class array<unsigned int> &tabs_Nk)
{
  allocate (partial_wave_str_tab , tabs_k , tabs_Nk); 
}

CC_rotor_contour_data_class::CC_rotor_contour_data_class (
							  const class CC_rotor_contour_data_class &X , 
							  const unsigned int N_channels_c , 
							  const class array<class CC_rotor_channel_class> &channels_tab_c , 
							  const enum potential_type potential)
{
  allocate (X , N_channels_c , channels_tab_c , potential);
}


CC_rotor_contour_data_class::CC_rotor_contour_data_class (const class CC_rotor_contour_data_class &X)
{
  allocate_fill (X);
}


void CC_rotor_contour_data_class::allocate (
					    const class array<string> &partial_wave_str_tab ,
					    const class array<complex<double> > &tabs_k ,
					    const class array<unsigned int> &tabs_Nk)
{
  number_contours = 0;

  number_edges_max = 0; 

  plot_file_name = "plot_contours";

  index_default_case = 0;

  N_channels = 0;

  class CC_rotor_contour_data_class &contour = *this;
  
  contour.run (partial_wave_str_tab , tabs_k , tabs_Nk);
}




// copy of a CC_rotor_contour_data_class and extension to N_channels
void CC_rotor_contour_data_class::allocate (
					    const class CC_rotor_contour_data_class &X , 
					    const unsigned int N_channels_c , 
					    const class array<class CC_rotor_channel_class> &channels_tab_c , 
					    const enum potential_type potential)
{
  number_contours = 0;

  number_edges_max = 0;

  plot_file_name = "plot_contours";

  index_default_case = 0;

  N_channels = N_channels_c;

  if ((potential != QUADRUPOLAR) && (potential != GAUSSIAN))
    error_message_print_abort ("CC_rotor_contour_data_class::CC_rotor_contour_data_class: behavior not defined for this potential " + make_string<enum potential_type> (potential));

  const unsigned int X_number_contours = X.get_number_contours ();

  if (N_channels < X_number_contours) error_message_print_abort ("CC_rotor_contour_data_class::CC_rotor_contour_data_class (copy): fewer channels than contours defined");

  contours_tab.allocate (N_channels);

  const class array<class CC_rotor_contour_class> &contours_tab_X = X.contours_tab;

  // copy defined partial waves from X if defined into the new object , 
  // at the corresponding position in channel_tab
  // put "default" if not defined

  const unsigned int index_default_partial_wave = X.get_index_default_partial_wave ();

  for (unsigned int i = 0 ; i < X_number_contours ; i++)
    {
      for (unsigned int ic = 0 ; ic < N_channels ; ic++)
	{
	  const class CC_rotor_channel_class &channel_c = channels_tab_c[ic];

	  const unsigned int lc = channel_c.get_lc ();

	  const unsigned int jrc = channel_c.get_jrc ();

	  if (contours_tab_X[i].is_partial_wave (lc , jrc))
	    contours_tab[ic] = contours_tab_X[i];
	  else
	    contours_tab[ic] = contours_tab_X[index_default_partial_wave];
	}
    }
}



void CC_rotor_contour_data_class::allocate_fill (const class CC_rotor_contour_data_class &X)
{
  contours_tab.allocate_fill (X.contours_tab);
  
  number_contours = X.number_contours;

  number_edges_max = X.number_edges_max; 

  plot_file_name = X.plot_file_name;

  index_default_case = X.index_default_case;

  N_channels = X.index_default_case;
}



void CC_rotor_contour_data_class::deallocate ()
{
  contours_tab.deallocate ();
  
  number_contours = 0;

  number_edges_max = 0; 

  plot_file_name = "plot_contours";

  index_default_case = 0;

  N_channels = 0;
}







// ================================== methods ================================== //

// run the CC_rotor_contour_data_class
void CC_rotor_contour_data_class::run (
				       const class array<string> &partial_wave_str_tab ,
				       const class array<complex<double> > &tabs_k ,
				       const class array<unsigned int> &tabs_Nk)
{
  cout << "CC_rotor_contour_data_class::run" << endl;
  cout << endl;

  number_contours = tabs_k.dimension (0);

  number_edges_max = tabs_k.dimension (1);

  contours_tab.deallocate ();

  contours_tab.allocate (number_contours);

  for (unsigned int i = 0 ; i < number_contours ; i++)
    {
      class CC_rotor_contour_class &contour_tab = contours_tab[i];
      
      const string partial_wave_str = partial_wave_str_tab[i];

      contours_tab[i].set_partial_wave (partial_wave_str);

      if (partial_wave_str == "default") index_default_case = i;

      contour_tab.allocate_tab_k_and_Nk (number_edges_max);

      class array<complex<double> > &contour_tab_k = contour_tab.get_tab_k ();

      class array<unsigned int> &contour_tab_Nk = contour_tab.get_tab_Nk ();

      for (unsigned int j = 0 ; j < number_edges_max ; j++)
	{
	  contour_tab_k[j] = tabs_k(i , j);
	  contour_tab_Nk[j] = tabs_Nk(i , j);
	}
    }

  check_contour_definitions ();

  print_contours_on_screen ();

  print_contours_for_plot ();
}














void CC_rotor_contour_data_class::check_contour_definitions ()
{
  cout << "CC_rotor_contour_data_class::check_contour_definitions" << endl;

  for (unsigned int i = 0 ; i < number_contours ; i++)
    {
      contours_tab[i].check_contour_definition ();

      for (unsigned int j = 0 ; j < i ; j++)
	{
	  if (contours_tab[i].get_partial_wave () == contours_tab[j].get_partial_wave ())
	    error_message_print_abort ("CC_rotor_contour_data_class::check_contour_definitions: identical partial waves defined (" + contours_tab[i].get_partial_wave () + ")");	
	}
    }
}





void CC_rotor_contour_data_class::print_contours_on_screen ()
{
  cout << "CC_rotor_contour_data_class::print_contours_on_screen" << endl;
  cout << endl;

  for (unsigned int i = 0 ; i < number_contours ; i++) contours_tab[i].print_contour_on_screen ();
}






void CC_rotor_contour_data_class::print_contours_for_plot ()
{
  cout << "CC_rotor_contour_data_class::print_contours_for_plot" << endl;

  for (unsigned int i = 0 ; i < number_contours ; i++)
    contours_tab[i].print_contour_for_plot (plot_file_name);
}








double used_memory_calc (const class CC_rotor_contour_data_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.contours_tab) + used_memory_calc (T.plot_file_name) - (sizeof (T.contours_tab) + sizeof (T.plot_file_name))/1000000.0);
}


