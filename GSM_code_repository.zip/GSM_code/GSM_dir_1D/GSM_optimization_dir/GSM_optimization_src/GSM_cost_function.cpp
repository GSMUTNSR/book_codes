#include "../GSM_optimization_include/GSM_optimization_include_def.h"


using namespace string_routines;
using namespace optimization_data_handling;






// TYPE is double or complex
// ----------------------------


// Calculation of the cost function depending on energies
// ------------------------------------------------------

double cost_function::calc (
			    const unsigned int N_states_to_fit , 
			    const class vector_class<double> &FHT_EFT_parameters ,
			    const class array<class interaction_class> &inter_data_units ,  
			    class array<class input_data_str> &input_data_tab , 
			    class interaction_class &inter_data_Coulomb , 
			    class interaction_class &inter_data_basis , 
			    class interaction_class &inter_data ,
			    ofstream &fit_results_file)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

  const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

  class array<class correlated_state_str> PSI_qn_tab(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl << "states in cost_function_calc: " << N_states_to_fit << endl << endl;
      
      cout << endl << "states in cost_function_calc: " << N_states_to_fit << endl << endl;
    }

  energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_all_states_calc (FHT_EFT_parameters , input_data_tab , inter_data_units ,
											inter_data_Coulomb , inter_data_basis , inter_data , fit_results_file , PSI_qn_tab);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl;
      cout << endl;
    }

  const double cost_function = cost_function_calc_from_energies_gradients (input_data_tab , PSI_qn_tab , fit_results_file);

  cout.precision (6);

  fit_results_file.precision (6);
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl << "cost.function=" << cost_function << endl << endl;

      cout << endl << "cost.function=" << cost_function << endl << endl;
    }

  cout.precision (15);

  fit_results_file.precision (15);
  
  return cost_function;
}
















// Calculation of the gradient of the cost function depending on energies with respect to Hamiltonian parameters
// -------------------------------------------------------------------------------------------------------------

class vector_class<double> cost_function::grad_calc (
						     const unsigned int N_states_to_fit , 
						     const class vector_class<double> &FHT_EFT_parameters , 
						     const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
						     const class array<bool> &is_there_l_dependence_from_fit_index , 
						     const class array<int> &l_from_fit_index , 
						     const class array<class interaction_class> &inter_data_units , 
						     class array<class input_data_str> &input_data_tab , 
						     class interaction_class &inter_data_Coulomb , 
						     class interaction_class &inter_data_basis , 
						     class interaction_class &inter_data , 
						     ofstream &fit_results_file)
{
  const class input_data_str &input_data_zero = input_data_tab(0);

  const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << "states in cost_function_grad_calc: " << N_states_to_fit << endl << endl;

      cout << "states in cost_function_grad_calc: " << N_states_to_fit << endl << endl;
    }

  const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

  const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

  class array<class correlated_state_str> PSI_qn_tab(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  class array<class vector_class<TYPE> > E_grad_all_states(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

  energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_grad_all_states_calc (FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index , FHT_EFT_parameters , input_data_tab ,
											     inter_data_units , inter_data_Coulomb , inter_data_basis , inter_data , fit_results_file , PSI_qn_tab , E_grad_all_states);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << endl;
      cout << endl;
    }

  double cost_function = 0.0;

  class vector_class<double> cost_function_grad(N_parameters_to_fit);
	
  cost_function_grad_calc_from_energies_gradients (input_data_tab , PSI_qn_tab , E_grad_all_states , cost_function , cost_function_grad , fit_results_file);

  cout.precision (6);

  fit_results_file.precision (6);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      fit_results_file << "cost.function : " << cost_function << endl;

      fit_results_file << endl << "cost.function.grad=" << cost_function_grad << endl;

      fit_results_file << "cost.function.grad.norm=" << sqrt (cost_function_grad*cost_function_grad) << endl << endl;

      cout << "cost.function : " << cost_function << endl;

      cout << endl << "cost.function.grad=" << cost_function_grad << endl;

      cout << "cost.function.grad.norm=" << sqrt (cost_function_grad*cost_function_grad) << endl << endl;
    }

  cout.precision (15);

  fit_results_file.precision (15);

  return cost_function_grad;
}
















// Results printed  at convergence and Birge factor renormalization done for statistical studies
// ---------------------------------------------------------------------------------------------

void cost_function::results_calc_print_Birge_factor_renormalization (
								     const class vector_class<double> &FHT_EFT_parameters ,
								     const class array<class interaction_class> &inter_data_units ,
								     const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index ,
								     class interaction_class &inter_data_Coulomb ,
								     class interaction_class &inter_data_basis ,
								     class interaction_class &inter_data ,
								     class array<class input_data_str> &input_data_tab ,
								     class array<bool> &is_there_l_dependence_from_fit_index ,
								     class array<int> &l_from_fit_index , 
								     ofstream &fit_results_file)
{
  const unsigned int N_states_to_fit = optimization_data_handling::N_states_to_fit_calc (input_data_tab);
  
  const bool are_all_weights_zero_all_eigensets = optimization_data_handling::are_all_weights_zero_all_eigensets_determine (input_data_tab);
    
  const unsigned int N_parameters_to_fit = FHT_EFT_parameters_from_fit_index.dimension (0);
  
  if (are_all_weights_zero_all_eigensets)
    {
      const class input_data_str &input_data_zero = input_data_tab(0);
      
      const unsigned int N_nuclei_to_consider = input_data_zero.get_N_nuclei_to_consider ();

      const unsigned int eigensets_number_max = optimization_data_handling::eigensets_number_max_determine (input_data_tab);

      const unsigned int eigenset_vectors_number_max = optimization_data_handling::eigenset_vectors_number_max_determine (input_data_tab);

      class array<class correlated_state_str> PSI_qn_tab(N_nuclei_to_consider , eigensets_number_max , eigenset_vectors_number_max);

      energies_gradients_Hessian_natural_orbitals_all_nuclei::PSI_qn_tab_E_all_states_calc (FHT_EFT_parameters , input_data_tab , inter_data_units , inter_data_Coulomb ,
											    inter_data_basis , inter_data , fit_results_file , PSI_qn_tab);
    }
  else
    {
      const double chi_square = calc (N_states_to_fit , FHT_EFT_parameters , inter_data_units , input_data_tab , inter_data_Coulomb , inter_data_basis , inter_data , fit_results_file);
      
      const double chi = sqrt (chi_square);

      const class vector_class<double> cost_function_grad = grad_calc (N_states_to_fit , FHT_EFT_parameters , FHT_EFT_parameters_from_fit_index , is_there_l_dependence_from_fit_index , l_from_fit_index ,
								       inter_data_units , input_data_tab , inter_data_Coulomb , inter_data_basis , inter_data , fit_results_file);

      const double cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

      cout.precision (6);

      fit_results_file.precision (6);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  fit_results_file << endl << "--------------------------------------------------------------------------------------------------------------------" << endl;
	  fit_results_file         << "chi : " << chi << " ,  ||grad (chi^2)|| : " << cost_grad_norm << endl;
	  fit_results_file         << "--------------------------------------------------------------------------------------------------------------------" << endl;

	  cout << endl << "--------------------------------------------------------------------------------------------------------------------" << endl;
	  cout         << "chi : " << chi << " ,  ||grad (chi^2)|| : " << cost_grad_norm << endl;
	  cout         << "--------------------------------------------------------------------------------------------------------------------" << endl;
	}

      cout.precision (15);
      
      fit_results_file.precision (15);
  
      if ((N_states_to_fit > N_parameters_to_fit) && (chi > precision))
	{
	  const double Birge_factor = (N_states_to_fit - N_parameters_to_fit)/chi_square;

	  weights_normalization (Birge_factor , input_data_tab);
	}
      else
	weights_normalization (0.0 , input_data_tab);
    }
}





