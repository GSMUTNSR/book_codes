#ifndef COST_FUNCTION_H
#define COST_FUNCTION_H

namespace cost_function
{
  double calc (
	       const unsigned int N_states_to_fit , 
	       const class vector_class<double> &FHT_EFT_parameters ,
	       const class array<class interaction_class> &inter_data_units ,  
	       class array<class input_data_str> &input_data_tab , 
	       class interaction_class &inter_data_Coulomb , 
	       class interaction_class &inter_data_basis , 
	       class interaction_class &inter_data , 
	       ofstream &fit_results_file);

  class vector_class<double> grad_calc (
					const unsigned int N_states_to_fit , 
					const class vector_class<double> &FHT_EFT_parameters , 
					const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					const class array<bool> &is_there_l_dependence_from_fit_index , 
					const class array<int> &l_from_fit_index , 
					const class array<class interaction_class> &inter_data_units , 
					class array<class input_data_str> &input_data_tab , 
					class interaction_class &inter_data_Coulomb , 
					class interaction_class &inter_data_basis , 
					class interaction_class &inter_data , 
					ofstream &fit_results_file);

  void results_calc_print_Birge_factor_renormalization (
							const class vector_class<double> &FHT_EFT_parameters ,
							const class array<class interaction_class> &inter_data_units ,
							const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index ,
							class interaction_class &inter_data_Coulomb ,
							class interaction_class &inter_data_basis ,
							class interaction_class &inter_data ,
							class array<class input_data_str> &input_data_tab ,
							class array<bool> &is_there_l_dependence_from_fit_index ,
							class array<int> &l_from_fit_index , 
							ofstream &fit_results_file);
}

#endif


