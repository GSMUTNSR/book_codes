#ifndef ENERGIES_GRADIENTS_HESSIAN_NATURAL_ORBITALS_ALL_NUCLEI_H
#define ENERGIES_GRADIENTS_HESSIAN_NATURAL_ORBITALS_ALL_NUCLEI_H

namespace energies_gradients_Hessian_natural_orbitals_all_nuclei
{
  void PSI_qn_tab_E_all_states_calc ( 
				     const class vector_class<double> &FHT_EFT_parameters , 
				     const class array<class input_data_str> &input_data_tab , 
				     const class array<class interaction_class> &inter_data_units , 
				     class interaction_class &inter_data_Coulomb , 
				     class interaction_class &inter_data_basis , 
				     class interaction_class &inter_data , 
				     ofstream &fit_results_file , 
				     class array<class correlated_state_str> &PSI_qn_tab);

  void PSI_qn_tab_E_grad_all_states_calc (
					  const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
					  const class array<bool> &is_there_l_dependence_from_fit_index , 
					  const class array<int> &l_from_fit_index , 
					  const class vector_class<double> &FHT_EFT_parameters , 
					  const class array<class input_data_str> &input_data_tab , 
					  const class array<class interaction_class> &inter_data_units , 
					  class interaction_class &inter_data_Coulomb , 
					  class interaction_class &inter_data_basis , 
					  class interaction_class &inter_data , 
					  ofstream &fit_results_file , 
					  class array<class correlated_state_str> &PSI_qn_tab , 
					  class array<class vector_class<TYPE> > &E_grad_all_states);

  void all_natural_orbitals_calc_store (
					const unsigned int N_nuclei_to_fit,
					const class interaction_class &inter_data_basis ,
					const class interaction_class &inter_data ,
					const class array<class input_data_str> &input_data_tab);

  void cost_function_Hessian_matrix_calc_print (
						const class array<enum FHT_EFT_parameter_type> &FHT_EFT_parameters_from_fit_index , 
						const class array<bool> &is_there_l_dependence_from_fit_index , 
						const class array<int> &l_from_fit_index ,  
						const class vector_class<double> &FHT_EFT_parameters ,
						const class array<class interaction_class> &inter_data_units , 
						class array<class input_data_str> &input_data_tab , 
						class interaction_class &inter_data_Coulomb , 
						class interaction_class &inter_data_basis , 
						class interaction_class &inter_data , 
						ofstream &fit_results_file);
}

#endif












