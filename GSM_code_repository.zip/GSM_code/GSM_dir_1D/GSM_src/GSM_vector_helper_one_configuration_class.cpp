#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;




// TYPE is double or complex
// -------------------------

// Class providing with data necessary to calculate basis Slater determinant indices in a GSM vector when only one configuration is occupied in basis space for MSDHF calculations
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// As only one configuration occurs, it is much more efficient to recode H in this particular case, than to use the full H class of the general case.
//
// This class is a helper for GSM vector when only one configuration is occupied  as it contains data common to all GSM vectors necessary to deal with basis Slater determinant states.
//
// One has here constructors, destructors and member routines.
// Arrays and constants are allocated and calculated in the constructor, and are not supposed to change afterwards.
// As GSM_vector_helper_class contains pointers to nucleon_data classes prot_Y_data and neut_Y_data, it is nevertheless not constant as the latter are modified very often.
//
// The MPI distribution of GSM vectors is also taken into account in this class.
//
//
// same_parity_M_projection
// ------------------------
// check if two classes have same parity and M projection, which has to be the case with scalar operators for |Psi[in]> and |Psi[out]>.
// The routine is straightforward so that it is not commented.
//
// TRS_data_calc_store
// -------------------
// Time-reversal symmetry (TRS) arrays are calculated, which are used when TRS is applied to |Psi[M=0]> (see GSM_TRS_class.cpp for details).

GSM_vector_helper_one_configuration_class::GSM_vector_helper_one_configuration_class () :
  space (NO_SPACE) ,
  inter (NO_INTERACTION) , 
  BPp (2) , 
  iCp (OUT_OF_CONFIGURATION) ,
  BPn (2) , 
  iCn (OUT_OF_CONFIGURATION) ,
  BP (2) , 
  iC (OUT_OF_CONFIGURATION) ,
  J (0.0) , 
  M (0.0) ,  
  iMp_max (0) , 
  iMn_max (0) ,
  iM (0) , 
  TRS_iM (0) ,  
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) , 
  is_it_TRS (false) ,
  Jmax (0.0) , 
  space_dimension (0) , 
  prot_Y_data_ptr (NULL) , 
  neut_Y_data_ptr (NULL)
{}

GSM_vector_helper_one_configuration_class::GSM_vector_helper_one_configuration_class (
										      const enum space_type space_c , 
										      const enum interaction_type inter_c , 
										      const class baryons_data &prot_Y_data , 
										      const class baryons_data &neut_Y_data , 
										      const double J_c , 
										      const double M_c , 
										      const bool is_it_TRS_for_M_zero) :
  space (NO_SPACE) ,
  inter (NO_INTERACTION) , 
  BPp (2) , 
  iCp (OUT_OF_CONFIGURATION) ,
  BPn (2) , 
  iCn (OUT_OF_CONFIGURATION) ,
  BP (2) , 
  iC (OUT_OF_CONFIGURATION) ,
  J (0.0) , 
  M (0.0) ,  
  iMp_max (0) , 
  iMn_max (0) ,
  iM (0) , 
  TRS_iM (0) ,  
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) , 
  is_it_TRS (false) ,
  Jmax (0.0) , 
  space_dimension (0) , 
  prot_Y_data_ptr (NULL) , 
  neut_Y_data_ptr (NULL)
{
  allocate (space_c , inter_c , prot_Y_data , neut_Y_data , J_c , M_c , is_it_TRS_for_M_zero);
}

GSM_vector_helper_one_configuration_class::GSM_vector_helper_one_configuration_class (const class GSM_vector_helper_one_configuration_class &X) :
  space (NO_SPACE) ,
  inter (NO_INTERACTION) , 
  BPp (2) , 
  iCp (OUT_OF_CONFIGURATION) ,
  BPn (2) , 
  iCn (OUT_OF_CONFIGURATION) ,
  BP (2) , 
  iC (OUT_OF_CONFIGURATION) ,
  J (0.0) , 
  M (0.0) ,  
  iMp_max (0) , 
  iMn_max (0) ,
  iM (0) , 
  TRS_iM (0) ,  
  iMp_min_M (0) , 
  iMp_max_M (0) , 
  iMn_min_M (0) , 
  iMn_max_M (0) , 
  is_it_TRS (false) ,
  Jmax (0.0) , 
  space_dimension (0) , 
  prot_Y_data_ptr (NULL) , 
  neut_Y_data_ptr (NULL)
{
  allocate_fill (X);
}

GSM_vector_helper_one_configuration_class::~GSM_vector_helper_one_configuration_class () {}

void GSM_vector_helper_one_configuration_class::allocate (
							  const enum space_type space_c , 
							  const enum interaction_type inter_c , 
							  const class baryons_data &prot_Y_data , 
							  const class baryons_data &neut_Y_data , 
							  const double J_c , 
							  const double M_c , 
							  const bool is_it_TRS_for_M_zero)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_helper_one_configuration_class cannot be allocated twice in GSM_vector_helper_one_configuration_class::allocate");

  space = space_c; 

  inter = inter_c; 

  BP = BP_one_configuration_determine (space , prot_Y_data , neut_Y_data); 

  BPp = prot_Y_data.get_BP_one_configuration (); 
  iCp = prot_Y_data.get_iC_one_configuration (); 

  BPn = neut_Y_data.get_BP_one_configuration (); 
  iCn = neut_Y_data.get_iC_one_configuration (); 

  if (space == PROT_Y_ONLY) iC = iCp;
  if (space == NEUT_Y_ONLY) iC = iCn;

  J = J_c; 
  M = M_c; 

  iMp_max = prot_Y_data.get_iM_max (); 
  iMn_max = neut_Y_data.get_iM_max (); 

  const double M_max = M_max_calc (space , prot_Y_data , neut_Y_data);

  iM = make_int (M + M_max);

  TRS_iM = make_int (-M + M_max);

  iMp_min_M = max (0 , iM - iMn_max); 
  iMn_min_M = max (0 , iM - iMp_max);
  
  iMp_max_M = min (iMp_max , iM); 
  iMn_max_M = min (iMn_max , iM);

  is_it_TRS = is_it_TRS_for_M_zero && (TRS_iM == iM); 

  Jmax = M_max_dimension_non_zero_calc_one_configuration (space , prot_Y_data , neut_Y_data); 

  space_dimension = total_space_dimension_M_calc_one_configuration (space , prot_Y_data , neut_Y_data , M);

  prot_Y_data_ptr = &prot_Y_data;
  neut_Y_data_ptr = &neut_Y_data;

  if (space_dimension == 0) return;

  const int TRS_iMp_min_M = max (0 , TRS_iM - iMn_max);
  
  const int TRS_iMp_max_M = min (iMp_max , TRS_iM);

  sum_dimensions_GSM_vector.allocate (space , prot_Y_data , neut_Y_data , iM , iMp_min_M , iMp_max_M);

  sum_dimensions_GSM_vector_TRS.allocate (space , prot_Y_data , neut_Y_data , TRS_iM , TRS_iMp_min_M , TRS_iMp_max_M);

  TRS_PSI_indices.allocate (space_dimension);

  TRS_bin_phases.allocate (space_dimension);
	
  TRS_data_calc_store ();
}     



void GSM_vector_helper_one_configuration_class::allocate_fill (const class GSM_vector_helper_one_configuration_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("GSM_vector_helper_one_configuration_class cannot be allocated twice in GSM_vector_helper_one_configuration_class::allocate_fill");

  space = X.space; 

  inter = X.inter; 

  BP = X.BP;

  BPp = X.BPp;
  iCp = X.iCp;

  BPn = X.BPn;
  iCn = X.iCn;

  iC = X.iC;

  J = X.J; 
  M = X.M; 

  iMp_max = X.iMp_max;
  iMn_max = X.iMn_max;

  iM = X.iM;

  TRS_iM = X.TRS_iM;

  iMp_min_M = X.iMp_min_M;
  iMp_max_M = X.iMp_max_M;

  iMn_min_M = X.iMn_min_M;
  iMn_max_M = X.iMn_max_M;

  is_it_TRS = X.is_it_TRS;

  Jmax = X.Jmax;

  space_dimension = X.space_dimension;

  prot_Y_data_ptr = X.prot_Y_data_ptr;
  neut_Y_data_ptr = X.neut_Y_data_ptr;

  if (space_dimension == 0) return;

  sum_dimensions_GSM_vector.allocate_fill (X.sum_dimensions_GSM_vector);

  sum_dimensions_GSM_vector_TRS.allocate_fill (X.sum_dimensions_GSM_vector_TRS);

  TRS_PSI_indices.allocate_fill (X.TRS_PSI_indices);

  TRS_bin_phases.allocate_fill (X.TRS_bin_phases);
}


void GSM_vector_helper_one_configuration_class::deallocate ()
{
  sum_dimensions_GSM_vector.deallocate ();
  sum_dimensions_GSM_vector_TRS.deallocate ();

  TRS_PSI_indices.deallocate ();
  TRS_bin_phases.deallocate ();

  space = NO_SPACE;
  inter = NO_INTERACTION; 

  BPp = 2; 
  iCp = OUT_OF_CONFIGURATION;

  BPn = 2; 
  iCn = OUT_OF_CONFIGURATION;

  BP = 2; 
  iC = OUT_OF_CONFIGURATION;

  J = 0.0; 
  M = 0.0;  

  iMp_max = 0;
  iMn_max = 0;

  iM = 0; 

  TRS_iM = 0;  

  iMp_min_M = 0; 
  iMp_max_M = 0; 

  iMn_min_M = 0; 
  iMn_max_M = 0; 

  is_it_TRS = false;

  Jmax = 0.0; 

  space_dimension = 0; 

  prot_Y_data_ptr = NULL;
  neut_Y_data_ptr = NULL;
}     



void GSM_vector_helper_one_configuration_class::TRS_data_calc_store ()
{
  const class baryons_data &prot_Y_data = get_prot_Y_data ();
  const class baryons_data &neut_Y_data = get_neut_Y_data ();

  if (space == PROT_NEUT_Y)
    {      
      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> &SDp_TRS_bin_phases = prot_Y_data.get_SD_TRS_bin_phases ();
      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> &SDn_TRS_bin_phases = neut_Y_data.get_SD_TRS_bin_phases ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
	{
	  const int iMn = iM - iMp;
	  
	  const int TRS_iMp = iMp_max - iMp;

	  const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 ,iCp , iMp);
	  const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 ,iCn , iMn);

	  if ((dimension_SDp == 0) || (dimension_SDn == 0)) continue;

	  const unsigned int sum_dimensions = sum_dimensions_GSM_vector(iMp);

	  const unsigned int sum_dimensions_TRS = sum_dimensions_GSM_vector_TRS(TRS_iMp);

	  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	    {
	      const unsigned int SDp_TRS_index = SDp_TRS_indices(BPp , 0 , 0 , 0 ,iCp , iMp , SDp_index);

	      const unsigned int SDp_TRS_bin_phase = SDp_TRS_bin_phases(BPp , 0 , 0 , 0 ,iCp , iMp , SDp_index);

	      const unsigned int PSI_index_zero_SDp = sum_dimensions + dimension_SDn*SDp_index;

	      const unsigned int TRS_PSI_index_zero_SDp = sum_dimensions_TRS + dimension_SDn*SDp_TRS_index;

	      for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		{
		  const unsigned int SDn_TRS_index = SDn_TRS_indices(BPn , 0 , 0 , 0 ,iCn , iMn , SDn_index);

		  const unsigned int PSI_index = PSI_index_zero_SDp + SDn_index;

		  const unsigned int TRS_PSI_index = TRS_PSI_index_zero_SDp + SDn_TRS_index;

		  const unsigned int SDn_TRS_bin_phase = SDn_TRS_bin_phases(BPn , 0 , 0 , 0 ,iCn , iMn , SDn_index);

		  const unsigned int SD_TRS_bin_phase = binary_parity_product (SDp_TRS_bin_phase , SDn_TRS_bin_phase);

		  TRS_PSI_indices(PSI_index) = TRS_PSI_index;

		  TRS_bin_phases(PSI_index) = SD_TRS_bin_phase;
		}
	    }
	}
    }
  else
    {
      const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

      const unsigned int BP = data.get_BP_one_configuration ();
      const unsigned int iC = data.get_iC_one_configuration ();

      const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();

      const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned char> &SD_TRS_bin_phases = data.get_SD_TRS_bin_phases ();

      const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 ,iC , iM);

      for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
	{
	  const unsigned int SD_TRS_index = SD_TRS_indices(BP , 0 , 0 , 0 ,iC , iM , SD_index);

	  const unsigned int SD_TRS_bin_phase = SD_TRS_bin_phases(BP , 0 , 0 , 0 ,iC , iM , SD_index);

	  TRS_PSI_indices(SD_index) = SD_TRS_index;

	  TRS_bin_phases(SD_index) = SD_TRS_bin_phase;
	}
    }
}



bool GSM_vector_helper_one_configuration_class::same_parity_M_projection (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_other) const
{
  const unsigned int BP_other = GSM_vector_helper_other.get_BP ();

  if (BP != BP_other) return false;

  const int iM_other = GSM_vector_helper_other.get_iM ();

  if (iM != iM_other) return false;

  return true;
}


double used_memory_calc (const class GSM_vector_helper_one_configuration_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.sum_dimensions_GSM_vector) +
    used_memory_calc (T.sum_dimensions_GSM_vector_TRS) +
    used_memory_calc (T.TRS_PSI_indices) +
    used_memory_calc (T.TRS_bin_phases)
    - (sizeof (T.sum_dimensions_GSM_vector) +
       sizeof (T.sum_dimensions_GSM_vector_TRS) +
       sizeof (T.TRS_PSI_indices) +
       sizeof (T.TRS_bin_phases))/1000000.0;
      
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}


