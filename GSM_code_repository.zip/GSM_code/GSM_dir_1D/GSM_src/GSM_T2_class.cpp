#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;

// TYPE is double or complex
// -------------------------

// Class xT2_plus_alpha_str is used only in closures and then is not commented.




// Class applying T^2 plus number times identity to |Psi[in]> to obtain |Psi[out]>
// -------------------------------------------------------------------------------
// One always assumes that the core part is coupled to T=0.
//
// One has here constructors, destructors, T^2 operator apply call and operators overloading of operations of the type a.T2 + b.
// Diagonal and off-diagonal NBMEs of T^2 are calculated on the fly.
//
// One uses T^2 = T-.T+ + Tz(Tz+1) with isospin formalism. For this, one uses an approximate isospin operator if charged and uncharged baryon radial parts are different.
// Indeed, one poses <n | t+ |p> = 1 if both states have same n,l,j,m,t quantum numbers, and <n | t+ |p> = 0 otherwise.
// One tested a direct radial overlap of different radial wave functions of charged and uncharged baryons :
// The result is much further from integers or half-integers for T than using the previous scheme.
// Hence, one uses this scheme. It allows to identify states if isospin is almost conserved.
// It also becomes exact if one uses same radial wave functions for charged and uncharged baryons.
//
// One firstly calculates the diagonal matrix elements of T^2 : <SD | T^2 | SD> = <SD | \sum_{i} t-(i) t+(i) | SD> + Tz.(Tz + 1).
//
// If one has only one state changing from in to out space, <SD' | T^2 | SD> = 0.
// Indeed, if it differs by one uncharged baryon, |<SD' | T^2 | SD>| = | \sum_p <ap bn' | t-(n) t+(p) | ap bn> | = | \sum_p <ap | t- | bn>  <bn' | t+ | ap> | = 0,
// as <ap | t- | bn> != 0 => ap,bn have same n,l,j,m quantum numbers => ap,bn' do not have same n,l,j,m quantum numbers => <bn' | t+ | ap> = 0.
// Same if <bn' | t+ | ap> != 0 with bn <-> bn', and if it differs by one charged baryon with p <-> n.
//
// If one has two charged or uncharged baryon states changing from in to out space, <SD' | T^2 | SD> = 0 as well.
// Indeed, if it differs by two uncharged baryons, |<SD'' | T^2 | SD>| = | <an' bn' | t- t+ | an bn> | = 0.
// This is because the only non-vanishing t+ actions are t+|Sigma0> = |Sigma-> and t+|Xi0> = |Xi->, so that <n' | t+ | n> = 0 in all cases as |n>,|n'> are both uncharged baryons.
// Same if it differs by two charged baryons with p <-> n and t- <-> t+.
//
// Thus, the off-diagonal part only consists of the 2p-2h pn and cv parts <SD'' | T^2 | SD> = +/- <a' b' | t-(a) t+(b) + t+(a) t-(b) | a b>.
// pn part : <SD'' | T^2 | SD> = +/- <ap' bn' | t-(a) t+(b) + t+(a) t-(b) | ap bn> with +/- 1 is the reordering phase.
// cv part : <SD'' | T^2 | SD> = +/- <ap' bp' | t-(a) t+(b) + t+(a) t-(b) | an bn> or +/- <an' bn' | t-(a) t+(b) + t+(a) t-(b) | ap bp> with +/- 1 is the reordering phase.
//
// One loops over charged and uncharged baryon Slater determinants, the first loop being charged or uncharged baryon according to the case.
// Routines are used if NYval >= ZYval, and other if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
//
// diagonal_part_pp_nn_calc_store , diagonal_part_Nval_larger_pn_calc_store, diagonal_part_pn_Zval_larger_calc_store
// ---------------------------------------------------------------------------------------------------------------------------
// These routines calculate the diagonal part of |Psi[out]> if NYval >= ZYval or NYval < ZYval (see above).
// The pp-nn routine is used only for non-zero strangeness, as is reduces to T(T+1) otherwise.
//
//
// two_jumps_pn_part_pn_Nval_larger_calc, two_jumps_pn_part_pn_Zval_larger_calc
// --------------------------------------------------------------------------------------
// These routines calculate the 2p-2h off-diagonal pn part of |Psi[out]> if NYval >= ZYval or NYval < ZYval (see above).
//
//
// two_jumps_cv_part_pn_Nval_larger_calc, two_jumps_cv_part_pn_Zval_larger_calc
// --------------------------------------------------------------------------------------
// These routines calculate the 2p-2h off-diagonal cv part of |Psi[out]> if NYval >= ZYval or NYval < ZYval (see above).
//
//
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + (T^2 + alpha.Id).|Psi[in]>, where alpha is a constant.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + (T^2 + alpha.Id).|Psi[in]>
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
//
// Even though it is used in practice, T^2 is provided with valence protons or valence neutrons only for completeness, where T^2 = T.(T+1).Id, with T = ZYval/2 or NYval/2.
// 
//
//
// xT2_plus_alpha_str
// -----------------
// T2pa must be understood here as T^2 + alpha.Id (see above).
// Operators overloading of operations are of the type a.T2pa + b.Id, to which operators of the form c.T2pa + d.Id as well can be added. 
// One cannot add another operator to a.T2pa + b.Id besides c.T2pa + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).T2pa + (b + d).Id .
// One can use instead (a*T2pa + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.

T2_class::T2_class () :
  J (0.0) ,
  is_cv_possible (false) ,
  GSM_vector_helper_ptr (NULL) 
{}



T2_class::T2_class (
		    const double J_c , 
		    const bool is_cv_possible_c ,
		    const class GSM_vector_helper_class &GSM_vector_helper) :
  J (0.0) ,
  is_cv_possible (false) ,
  GSM_vector_helper_ptr (NULL)
{
  allocate (J_c , is_cv_possible_c , GSM_vector_helper);
}




T2_class::T2_class (const class T2_class &X) :
  J (0.0) ,
  is_cv_possible (false) ,
  GSM_vector_helper_ptr (NULL)
{
  allocate_fill (X);
}



T2_class::~T2_class () {}





void T2_class::allocate (
			 const double J_c ,
			 const bool is_cv_possible_c ,
			 const class GSM_vector_helper_class &GSM_vector_helper)
{
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();

  if (space_dimension == 0) return;
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
  
  const int S = GSM_vector_helper.get_S ();
    
  J = J_c;

  is_cv_possible = is_cv_possible_c;
 
  GSM_vector_helper_ptr = &GSM_vector_helper;
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  if ((S == 0) && ((ZYval == 0) || (NYval == 0))) return;

  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  if (space != NEUT_Y_ONLY)
    {
      Tminus_Tplus_OBMEs_p_tab.allocate (Np_nljm);
      
      Tminus_Tplus_OBMEs_calc (phi_p_table , Tminus_Tplus_OBMEs_p_tab);
    }
    
  if (space != PROT_Y_ONLY)
    {
      Tminus_Tplus_OBMEs_n_tab.allocate (Nn_nljm);

      Tminus_Tplus_OBMEs_calc (phi_n_table , Tminus_Tplus_OBMEs_n_tab);
    }
      
  T2_diagonal_tab.allocate (space_dimension_process);
  
  T2_diagonal_tab = 0.0;

  if (space == PROT_NEUT_Y)
    {
      Tminus_OBMEs_pn_tab.allocate (Np_nljm , Nn_nljm);
      Tplus_OBMEs_pn_tab.allocate  (Np_nljm , Nn_nljm);
  
      are_Tminus_OBMEs_pn_non_zero_tab.allocate (Np_nljm , Nn_nljm);
      are_Tplus_OBMEs_pn_non_zero_tab.allocate  (Np_nljm , Nn_nljm);
      
      Tpm_OBMEs_pn_calc (-1 , phi_p_table , phi_n_table , Tminus_OBMEs_pn_tab);
      Tpm_OBMEs_pn_calc ( 1 , phi_p_table , phi_n_table , Tplus_OBMEs_pn_tab);
  
      are_Tpm_OBMEs_pn_non_zero_calc (-1 , phi_p_table , phi_n_table , are_Tminus_OBMEs_pn_non_zero_tab);
      are_Tpm_OBMEs_pn_non_zero_calc ( 1 , phi_p_table , phi_n_table , are_Tplus_OBMEs_pn_non_zero_tab);
    
      if (NYval >= ZYval)
	diagonal_part_pn_Nval_larger_calc_store ();
      else
	diagonal_part_pn_Zval_larger_calc_store ();
    }
  else
    diagonal_part_pp_nn_calc_store ();
}




void T2_class::allocate_fill (const class T2_class &X)
{
  J = X.J;

  is_cv_possible = X.is_cv_possible;
   
  GSM_vector_helper_ptr = X.GSM_vector_helper_ptr;

  Tminus_Tplus_OBMEs_p_tab.allocate_fill (X.Tminus_Tplus_OBMEs_p_tab);
  Tminus_Tplus_OBMEs_n_tab.allocate_fill (X.Tminus_Tplus_OBMEs_n_tab);
    
  Tminus_OBMEs_pn_tab.allocate_fill (X.Tminus_OBMEs_pn_tab);

  Tplus_OBMEs_pn_tab.allocate_fill (X.Tplus_OBMEs_pn_tab);
  
  are_Tminus_OBMEs_pn_non_zero_tab.allocate_fill (X.are_Tminus_OBMEs_pn_non_zero_tab);

  are_Tplus_OBMEs_pn_non_zero_tab.allocate_fill (X.are_Tplus_OBMEs_pn_non_zero_tab);
      
  T2_diagonal_tab.allocate_fill (X.T2_diagonal_tab);
}




void T2_class::deallocate ()
{
  Tminus_Tplus_OBMEs_p_tab.deallocate ();
  Tminus_Tplus_OBMEs_n_tab.deallocate ();
  
  Tminus_OBMEs_pn_tab.deallocate ();
  
  Tplus_OBMEs_pn_tab.deallocate ();
  
  are_Tminus_OBMEs_pn_non_zero_tab.deallocate ();

  are_Tplus_OBMEs_pn_non_zero_tab.deallocate ();
  
  T2_diagonal_tab.deallocate ();
  
  J = 0.0;
  
  is_cv_possible = false;
  
  GSM_vector_helper_ptr = NULL;
}









void T2_class::diagonal_part_pp_nn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int Zval = prot_Y_data.get_N_valence_nucleons ();
  const int Nval = neut_Y_data.get_N_valence_nucleons ();
  
  const TYPE Tz = 0.5*(Nval - Zval);
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);
    
  const enum particle_type nucleonic_particle = data.get_nucleonic_particle ();

  const bool is_it_charged = (nucleonic_particle == PROTON);
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
        
  const int iM = GSM_vector_helper.get_iM (); 

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
      
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array<int> &Tminus_Tplus_OBMEs_tab = (is_it_charged) ? (Tminus_Tplus_OBMEs_p_tab) : (Tminus_Tplus_OBMEs_n_tab);
  
  const class array_of_SD &SD_set = data.get_SD_set ();
      
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper.get_total_SD_index_max ();

  const unsigned int first_PSI_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper.get_last_PSI_index ();
  
  if (total_SD_index_min > total_SD_index_max) return;
  
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) SD_tab(i).allocate (N_valence_baryons);
      
  T2_diagonal_tab = 0.0;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {      
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);
 
      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
      
      const int S_SD = SD_qn.get_S ();
  
      if (S_SD != S) continue;
      
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , S , 0 , n_scat , iC);
	  
      const int E_hw = E_hw_table(BP , S , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();
      
      const unsigned int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

      const unsigned int PSI_index = sum_dimensions_configuration_fixed + SD_index;
      
      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
	{	
	  const unsigned int PSI_index_shifted = PSI_index - first_PSI_index;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &SD = SD_tab(i_thread);
	        
	  SD = SD_set(BP , S , 0 , n_scat , iC , iM , SD_index);
		      
	  int NBME_Tplus_Tminus = 0;
					      
	  for (int i = 0 ; i < N_valence_baryons ; i++)
	    {
	      const unsigned int SDi = SD[i];

	      NBME_Tplus_Tminus += Tminus_Tplus_OBMEs_tab(SDi);
	    }

	  T2_diagonal_tab(PSI_index_shifted) = NBME_Tplus_Tminus;
	}
    }
  
  T2_diagonal_tab += Tz*(Tz + 1);
}


void T2_class::diagonal_part_pn_Nval_larger_calc_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int Zval = prot_Y_data.get_N_valence_nucleons ();
  const int Nval = neut_Y_data.get_N_valence_nucleons ();
  
  const TYPE Tz = 0.5*(Nval - Zval);
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();

  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
   
  const unsigned int first_PSI_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper.get_last_PSI_index ();
  
  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper.get_iCp_max_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SDn_quantum_numbers_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = S - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
            
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      		      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;
  
	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
				       
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
		  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned int PSI_index = PSI_index_zero + SDp_index*dimension_SDn;

		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const unsigned int PSI_index_shifted = PSI_index - first_PSI_index;
			      
			      const unsigned long int total_SDp_index = total_SDp_index_zero + SDp_index;

			      SDp = SDp_set[total_SDp_index];
			      				      
			      int NBME_Tplus_Tminus = 0;
					      
			      for (int p = 0 ; p < ZYval ; p++)
				{
				  const unsigned int state_p = SDp[p];

				  NBME_Tplus_Tminus += Tminus_Tplus_OBMEs_p_tab(state_p);
				}
			      
			      for (int n = 0 ; n < NYval ; n++)
				{
				  const unsigned int state_n = SDn[n];
				  
				  NBME_Tplus_Tminus += Tminus_Tplus_OBMEs_n_tab(state_n);
				}
			      
			      for (int p = 0 ; p < ZYval ; p++)
				for (int n = 0 ; n < NYval ; n++)
				  {
				    const unsigned int state_p = SDp[p];
				    const unsigned int state_n = SDn[n];

				    const double Tplus_OBME_pn = Tplus_OBMEs_pn_tab(state_p , state_n);

				    if (Tplus_OBME_pn != 0.0) NBME_Tplus_Tminus -= make_int (Tplus_OBME_pn*Tplus_OBME_pn);
				  }
			      
			      T2_diagonal_tab(PSI_index_shifted) = NBME_Tplus_Tminus;
			      
			    }}}}}}}
  
  T2_diagonal_tab += Tz*(Tz + 1);
}
























void T2_class::diagonal_part_pn_Zval_larger_calc_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int Zval = prot_Y_data.get_N_valence_nucleons ();
  const int Nval = neut_Y_data.get_N_valence_nucleons ();
  
  const TYPE Tz = 0.5*(Nval - Zval);
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM (); 

  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
    
  const unsigned int first_PSI_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper.get_last_PSI_index ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper.get_iCn_max_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
       
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SDp_quantum_numbers_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = S - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
				  
	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDn_minus_one;
  
	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
			
		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
		      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned int PSI_index = PSI_index_zero + SDn_index;

		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const unsigned int PSI_index_shifted = PSI_index - first_PSI_index;
			      
			      const unsigned long int total_SDn_index = total_SDn_index_zero + SDn_index;

			      SDn = SDn_set[total_SDn_index];
			      		      
			      int NBME_Tplus_Tminus = 0;
					      
			      for (int p = 0 ; p < ZYval ; p++)
				{
				  const unsigned int state_p = SDp[p];

				  NBME_Tplus_Tminus += Tminus_Tplus_OBMEs_p_tab(state_p);
				}
			      
			      for (int n = 0 ; n < NYval ; n++)
				{
				  const unsigned int state_n = SDn[n];
				  
				  NBME_Tplus_Tminus += Tminus_Tplus_OBMEs_n_tab(state_n);
				}
			      
			      for (int p = 0 ; p < ZYval ; p++)
				for (int n = 0 ; n < NYval ; n++)
				  {
				    const unsigned int state_p = SDp[p];
				    const unsigned int state_n = SDn[n];

				    const double Tplus_OBME_pn = Tplus_OBMEs_pn_tab(state_p , state_n);

				    if (Tplus_OBME_pn != 0.0) NBME_Tplus_Tminus -= make_int (Tplus_OBME_pn*Tplus_OBME_pn);
				  }
			      
			      T2_diagonal_tab(PSI_index_shifted) = NBME_Tplus_Tminus;
			      
			    }}}}}}}
  
  T2_diagonal_tab += Tz*(Tz + 1);
}




















		


void T2_class::two_jumps_pn_part_pn_Nval_larger_calc (
						      const class GSM_vector &PSI_in ,
						      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
            		  		  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
      
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
    
  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > one_jump_n_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(i);
			
      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
    }
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
      
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);

      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(i_thread);
      
      class jumps_data_str &one_jump_p = one_jump_p_tab(i_thread);
        
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  				       		      
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;

		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;

					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);
				  
					  class jumps_data_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
	      				  
					  if (!is_one_jump_n_calculated)
					    {
					      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									    BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

					      is_one_jump_n_calculated = true;				      
					    }

					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
					  if (dimension_one_jump_n == 0) continue;
		  
					  one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
					  if (dimension_one_jump_p == 0) continue;
				  
					  unsigned int PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					      const unsigned int p_in = one_jump_p_inSDp.get_mu_in ();
					      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
					  
					      const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
					  
					      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();
					  
					      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
					  						
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

						  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						      if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						      if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
						      
							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
			      
							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      
							  PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int n_in = one_jump_n_inSDn.get_mu_in ();
						      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
						    
						      const bool  is_Tplus_OBMEs_p_in_n_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_in , n_out) ,  is_Tplus_OBMEs_n_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_out , n_in);
						      const bool is_Tminus_OBMEs_p_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , n_out) , is_Tminus_OBMEs_n_in_p_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_out , n_in);

						      if ((is_Tplus_OBMEs_p_in_n_out_non_zero && is_Tminus_OBMEs_n_in_p_out_non_zero) || (is_Tplus_OBMEs_n_in_p_out_non_zero && is_Tminus_OBMEs_p_in_n_out_non_zero))
							{						  
							  const double  Tplus_OBMEs_p_in_n_out =  Tplus_OBMEs_pn_tab(p_in , n_out) ,  Tplus_OBMEs_n_in_p_out = Tminus_OBMEs_pn_tab(p_out , n_in);
							  const double Tminus_OBMEs_p_in_n_out = Tminus_OBMEs_pn_tab(p_in , n_out) , Tminus_OBMEs_n_in_p_out =  Tplus_OBMEs_pn_tab(p_out , n_in);

							  const double TBME = Tplus_OBMEs_p_in_n_out*Tminus_OBMEs_n_in_p_out + Tplus_OBMEs_n_in_p_out*Tminus_OBMEs_p_in_n_out;

							  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

							  const unsigned int PSI_in_index = PSI_in_index_zero_inSDn + inSDn_index;
							  
							  const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();
						      
							  const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							  
							  const TYPE PSI_in_component_TBME = (TBME == 1.0) ? (PSI_in_component) : (PSI_in_component*TBME);
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part -= PSI_in_component_TBME) : (component_part += PSI_in_component_TBME);

							}}}}
							  
					  PSI_out[PSI_out_index] += component_part;
				      
					}}}}}}}}}}
}








void T2_class::two_jumps_pn_part_pn_Zval_larger_calc (
						      const class GSM_vector &PSI_in ,
						      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
      
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
          
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();
    
  if (total_outSDp_index_min > total_outSDp_index_max) return;

  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > one_jump_p_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(i);
      
      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;

      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
      
      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);

      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(i_thread);
      
      class jumps_data_str &one_jump_n = one_jump_n_tab(i_thread);
            
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
		      			  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;

					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;

					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);
				  
					  class jumps_data_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
	      
					  if (!is_one_jump_p_calculated)
					    {
					      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									    BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					      is_one_jump_p_calculated = true;
					    }

					  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
					  if (dimension_one_jump_p == 0) continue;
				  
					  one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

					  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
					  if (dimension_one_jump_n == 0) continue;

					  unsigned int PSI_in_index_zero_inSDp = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				  
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++) 
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

					      const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

					      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
						{
						  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);
					  
						  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						      if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						      if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
			      
							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      						  
							  PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
								      
						  if (is_configuration_accepted)
						    {
						      const unsigned int p_in = one_jump_p_inSDp.get_mu_in ();
						      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

						      const bool  is_Tplus_OBMEs_p_in_n_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_in , n_out) ,  is_Tplus_OBMEs_n_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_out , n_in);
						      const bool is_Tminus_OBMEs_p_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , n_out) , is_Tminus_OBMEs_n_in_p_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_out , n_in);

						      if ((is_Tplus_OBMEs_p_in_n_out_non_zero && is_Tminus_OBMEs_n_in_p_out_non_zero) || (is_Tplus_OBMEs_n_in_p_out_non_zero && is_Tminus_OBMEs_p_in_n_out_non_zero))
							{						  
							  const double  Tplus_OBMEs_p_in_n_out =  Tplus_OBMEs_pn_tab(p_in , n_out) ,  Tplus_OBMEs_n_in_p_out = Tminus_OBMEs_pn_tab(p_out , n_in);
							  const double Tminus_OBMEs_p_in_n_out = Tminus_OBMEs_pn_tab(p_in , n_out) , Tminus_OBMEs_n_in_p_out =  Tplus_OBMEs_pn_tab(p_out , n_in);

							  const double TBME = Tplus_OBMEs_p_in_n_out*Tminus_OBMEs_n_in_p_out + Tplus_OBMEs_n_in_p_out*Tminus_OBMEs_p_in_n_out;

							  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

							  const unsigned int PSI_in_index = PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
							  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

							  const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							  
							  const TYPE PSI_in_component_TBME = (TBME == 1.0) ? (PSI_in_component) : (PSI_in_component*TBME);
							  
							  (total_bin_phase_p == total_bin_phase_n) ? (component_part -= PSI_in_component_TBME) : (component_part += PSI_in_component_TBME);
						      
							}}}}
				      
					  PSI_out[PSI_out_index] += component_part;
				      
					}}}}}}}}}}
}










		


void T2_class::two_jumps_cv_part_pn_Nval_larger_calc (
						      const bool is_it_cv_pp_to_nn , 
						      const class GSM_vector &PSI_in ,
						      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max (); 

  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
              		  		  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
      
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
      
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab ();
    
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
    
  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > are_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > two_jumps_cv_n_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> two_jumps_cv_p_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      are_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      class array<class jumps_data_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs(i);
			
      two_jumps_cv_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
	  for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	    two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
      
      two_jumps_cv_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
    }
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
      
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &are_two_jumps_cv_n_calculated_tab = are_two_jumps_cv_n_calculated_tabs(i_thread);

      class array<class jumps_data_str> &two_jumps_cv_n_tab = two_jumps_cv_n_tabs(i_thread);
      
      class jumps_data_str &two_jumps_cv_p = two_jumps_cv_p_tab(i_thread);
        
      are_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  				       		      
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;

		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;
				      
					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;

					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  bool &are_two_jumps_cv_n_calculated = are_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);
				  
					  class jumps_data_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
	      				  
					  if (!are_two_jumps_cv_n_calculated)
					    {
					      two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
										 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);

					      are_two_jumps_cv_n_calculated = true;				      
					    }

					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				  
					  if (dimension_two_jumps_cv_n == 0) continue;
		  
					  two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
									     BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
				      
					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  
					  if (dimension_two_jumps_cv_p == 0) continue;
				  
					  unsigned int PSI_in_index_zero_inSDn = 0;
					      
					  bool is_configuration_accepted = true;
				      
					  TYPE component_part = 0.0;
				      
					  for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);

					      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
					      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();

					      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
					      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();
					  
					      const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();

					      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();
					  
					      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();
					  
					      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
					  
					      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

					      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();
					  						
					      for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++)
						{
						  const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

						  const bool is_configuration_changing = two_jumps_cv_n_inSDn.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
						  
						      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

						      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						      if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						      if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();
						      
							  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
			      
							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      
							  PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
							}
						    }
					      
						  if (is_configuration_accepted)
						    {
						      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
						      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

						      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
						      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();

						      if (is_it_cv_pp_to_nn)
							{
							  const bool  is_Tplus_OBMEs_p_in_n_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_in , n_out) ,  is_Tplus_OBMEs_pp_in_nn_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(pp_in , nn_out);
							  const bool is_Tminus_OBMEs_p_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , n_out) , is_Tminus_OBMEs_pp_in_nn_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(pp_in , nn_out);
							  
							  const bool  is_Tplus_OBMEs_pp_in_n_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(pp_in , n_out) ,  is_Tplus_OBMEs_p_in_nn_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(p_in , nn_out);
							  const bool is_Tminus_OBMEs_pp_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(pp_in , n_out) , is_Tminus_OBMEs_p_in_nn_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , nn_out);

							  const bool is_TBME_dir_non_zero = (( is_Tplus_OBMEs_p_in_n_out_non_zero && is_Tminus_OBMEs_pp_in_nn_out_non_zero) || (is_Tplus_OBMEs_pp_in_nn_out_non_zero &&  is_Tminus_OBMEs_p_in_n_out_non_zero));
							  const bool is_TBME_exc_non_zero = ((is_Tplus_OBMEs_pp_in_n_out_non_zero &&  is_Tminus_OBMEs_p_in_nn_out_non_zero) || ( is_Tplus_OBMEs_p_in_nn_out_non_zero && is_Tminus_OBMEs_pp_in_n_out_non_zero));
							  
							  if (is_TBME_dir_non_zero || is_TBME_exc_non_zero)
							    {
							      const double  Tplus_OBMEs_p_in_n_out =  Tplus_OBMEs_pn_tab(p_in , n_out) ,  Tplus_OBMEs_pp_in_nn_out  = Tplus_OBMEs_pn_tab(pp_in , nn_out);
							      const double Tminus_OBMEs_p_in_n_out = Tminus_OBMEs_pn_tab(p_in , n_out) , Tminus_OBMEs_pp_in_nn_out = Tminus_OBMEs_pn_tab(pp_in , nn_out);
							  
							      const double  Tplus_OBMEs_pp_in_n_out  = Tplus_OBMEs_pn_tab(pp_in , n_out) ,  Tplus_OBMEs_p_in_nn_out  = Tplus_OBMEs_pn_tab(p_in , nn_out);
							      const double Tminus_OBMEs_pp_in_n_out = Tminus_OBMEs_pn_tab(pp_in , n_out) , Tminus_OBMEs_p_in_nn_out = Tminus_OBMEs_pn_tab(p_in , nn_out);
							      
							      const double TBME_dir = Tplus_OBMEs_p_in_n_out*Tminus_OBMEs_pp_in_nn_out + Tplus_OBMEs_pp_in_nn_out*Tminus_OBMEs_p_in_n_out;
							      const double TBME_exc = Tplus_OBMEs_pp_in_n_out*Tminus_OBMEs_p_in_nn_out + Tplus_OBMEs_p_in_nn_out*Tminus_OBMEs_pp_in_n_out;
							      
							      const double TBME = TBME_dir - TBME_exc;
							      
							      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();
							      
							      const unsigned int PSI_in_index = PSI_in_index_zero_inSDn + inSDn_index;
							      
							      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();
							      
							      const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							      
							      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							    }
							}
						      else
							{
							  const bool  is_Tplus_OBMEs_n_in_p_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(n_in , p_out) ,  is_Tplus_OBMEs_nn_in_pp_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(nn_in , pp_out);
							  const bool is_Tminus_OBMEs_n_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(n_in , p_out) , is_Tminus_OBMEs_nn_in_pp_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(nn_in , pp_out);
							  
							  const bool  is_Tplus_OBMEs_nn_in_p_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(nn_in , p_out) ,  is_Tplus_OBMEs_n_in_pp_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(n_in , pp_out);
							  const bool is_Tminus_OBMEs_nn_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(nn_in , p_out) , is_Tminus_OBMEs_n_in_pp_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(n_in , pp_out);

							  const bool is_TBME_dir_non_zero = (( is_Tplus_OBMEs_n_in_p_out_non_zero && is_Tminus_OBMEs_nn_in_pp_out_non_zero) || (is_Tplus_OBMEs_nn_in_pp_out_non_zero &&  is_Tminus_OBMEs_n_in_p_out_non_zero));
							  const bool is_TBME_exc_non_zero = ((is_Tplus_OBMEs_nn_in_p_out_non_zero &&  is_Tminus_OBMEs_n_in_pp_out_non_zero) || ( is_Tplus_OBMEs_n_in_pp_out_non_zero && is_Tminus_OBMEs_nn_in_p_out_non_zero));
							  
							  if (is_TBME_dir_non_zero || is_TBME_exc_non_zero)
							    {
							      const double  Tplus_OBMEs_n_in_p_out =  Tplus_OBMEs_pn_tab(n_in , p_out) ,  Tplus_OBMEs_nn_in_pp_out  = Tplus_OBMEs_pn_tab(nn_in , pp_out);
							      const double Tminus_OBMEs_n_in_p_out = Tminus_OBMEs_pn_tab(n_in , p_out) , Tminus_OBMEs_nn_in_pp_out = Tminus_OBMEs_pn_tab(nn_in , pp_out);
							  
							      const double  Tplus_OBMEs_nn_in_p_out  = Tplus_OBMEs_pn_tab(nn_in , p_out) ,  Tplus_OBMEs_n_in_pp_out  = Tplus_OBMEs_pn_tab(n_in , pp_out);
							      const double Tminus_OBMEs_nn_in_p_out = Tminus_OBMEs_pn_tab(nn_in , p_out) , Tminus_OBMEs_n_in_pp_out = Tminus_OBMEs_pn_tab(n_in , pp_out);
							      
							      const double TBME_dir = Tplus_OBMEs_n_in_p_out*Tminus_OBMEs_nn_in_pp_out + Tplus_OBMEs_nn_in_pp_out*Tminus_OBMEs_n_in_p_out;
							      const double TBME_exc = Tplus_OBMEs_nn_in_p_out*Tminus_OBMEs_n_in_pp_out + Tplus_OBMEs_n_in_pp_out*Tminus_OBMEs_nn_in_p_out;
							      
							      const double TBME = TBME_dir - TBME_exc;
							      
							      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();
							      
							      const unsigned int PSI_in_index = PSI_in_index_zero_inSDn + inSDn_index;
							      
							      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();
							      
							      const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							      
							      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							    }}}}}
							  
					  PSI_out[PSI_out_index] += component_part;
				      
					}}}}}}}}}}
}








void T2_class::two_jumps_cv_part_pn_Zval_larger_calc (
						      const bool is_it_cv_pp_to_nn , 
						      const class GSM_vector &PSI_in ,
						      class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n (); 
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();

  const int S = GSM_vector_helper.get_S ();
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int S_plus_one = S + 1;
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
  const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
            
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();
    
  if (total_outSDp_index_min > total_outSDp_index_max) return;

  class array<class array<bool> > are_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > two_jumps_cv_p_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> two_jumps_cv_n_tab(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      are_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      class array<class jumps_data_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs(i);
      
      two_jumps_cv_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
	  for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	    two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
      
      two_jumps_cv_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;

      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
      
      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &are_two_jumps_cv_p_calculated_tab = are_two_jumps_cv_p_calculated_tabs(i_thread);

      class array<class jumps_data_str> &two_jumps_cv_p_tab = two_jumps_cv_p_tabs(i_thread);
      
      class jumps_data_str &two_jumps_cv_n = two_jumps_cv_n_tab(i_thread);
            
      are_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
		      			  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
			  
			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
				    {
				      const int Sn_in = S - Sp_in;
				      
				      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
					{
					  const int iMn_in = iM - iMp_in;

					  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
					  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;

					  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
					  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

					  bool &are_two_jumps_cv_p_calculated = are_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);
				  
					  class jumps_data_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
	      
					  if (!are_two_jumps_cv_p_calculated)
					    {
					      two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
										 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
				      
					      are_two_jumps_cv_p_calculated = true;
					    }

					  const unsigned int dimension_two_jumps_cv_p = two_jumps_cv_p.get_dimension ();
				  
					  if (dimension_two_jumps_cv_p == 0) continue;
				  
					  two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									     BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);

					  const unsigned int dimension_two_jumps_cv_n = two_jumps_cv_n.get_dimension ();
				  
					  if (dimension_two_jumps_cv_n == 0) continue;

					  unsigned int PSI_in_index_zero_inSDp = 0;
					      
					  bool is_configuration_accepted = true;
									  
					  TYPE component_part = 0.0;
				  
					  for (unsigned int in = 0 ; in < dimension_two_jumps_cv_n ; in++) 
					    {
					      const class jumps_data_inSD_str &two_jumps_cv_n_inSDn = two_jumps_cv_n(in);

					      const unsigned int n_in  = two_jumps_cv_n_inSDn.get_left_in ();
					      const unsigned int nn_in = two_jumps_cv_n_inSDn.get_right_in ();

					      const unsigned int  n_out = two_jumps_cv_n_inSDn.get_left_out ();
					      const unsigned int nn_out = two_jumps_cv_n_inSDn.get_right_out ();

					      const unsigned int iCn_in = two_jumps_cv_n_inSDn.get_iC ();
					  
					      const unsigned int inSDn_index = two_jumps_cv_n_inSDn.get_inSD_index ();

					      const unsigned int total_bin_phase_n = two_jumps_cv_n_inSDn.get_total_bin_phase ();

					      const int n_holes_n_in = two_jumps_cv_n_inSDn.get_n_holes ();
					  
					      const int n_scat_n_in = two_jumps_cv_n_inSDn.get_n_scat ();

					      const int En_hw_in = two_jumps_cv_n_inSDn.get_E_hw ();
					  
					      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);
				      
					      for (unsigned int ip = 0 ; ip < dimension_two_jumps_cv_p ; ip++)  
						{
						  const class jumps_data_inSD_str &two_jumps_cv_p_inSDp = two_jumps_cv_p(ip);
					  
						  const bool is_configuration_changing = two_jumps_cv_p_inSDp.get_is_configuration_changing ();
		      
						  if (is_configuration_changing) 
						    { 
						      const int n_holes_p_in = two_jumps_cv_p_inSDp.get_n_holes ();
						  
						      const int n_scat_p_in = two_jumps_cv_p_inSDp.get_n_scat ();

						      const int Ep_hw_in = two_jumps_cv_p_inSDp.get_E_hw ();

						      is_configuration_accepted = true;
									  
						      if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						      if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						      if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						      if (is_configuration_accepted) 
							{
							  const unsigned int iCp_in = two_jumps_cv_p_inSDp.get_iC ();
			      
							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
			      			      						  
							  PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
							}
						    }
								      
						  if (is_configuration_accepted)
						    {
						      const unsigned int p_in  = two_jumps_cv_p_inSDp.get_left_in ();
						      const unsigned int pp_in = two_jumps_cv_p_inSDp.get_right_in ();
						      
						      const unsigned int  p_out = two_jumps_cv_p_inSDp.get_left_out ();
						      const unsigned int pp_out = two_jumps_cv_p_inSDp.get_right_out ();

						      if (is_it_cv_pp_to_nn)
							{
							  const bool  is_Tplus_OBMEs_p_in_n_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(p_in , n_out) ,  is_Tplus_OBMEs_pp_in_nn_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(pp_in , nn_out);
							  const bool is_Tminus_OBMEs_p_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , n_out) , is_Tminus_OBMEs_pp_in_nn_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(pp_in , nn_out);
							  
							  const bool  is_Tplus_OBMEs_pp_in_n_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(pp_in , n_out) ,  is_Tplus_OBMEs_p_in_nn_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(p_in , nn_out);
							  const bool is_Tminus_OBMEs_pp_in_n_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(pp_in , n_out) , is_Tminus_OBMEs_p_in_nn_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(p_in , nn_out);

							  const bool is_TBME_dir_non_zero = (( is_Tplus_OBMEs_p_in_n_out_non_zero && is_Tminus_OBMEs_pp_in_nn_out_non_zero) || (is_Tplus_OBMEs_pp_in_nn_out_non_zero &&  is_Tminus_OBMEs_p_in_n_out_non_zero));
							  const bool is_TBME_exc_non_zero = ((is_Tplus_OBMEs_pp_in_n_out_non_zero &&  is_Tminus_OBMEs_p_in_nn_out_non_zero) || ( is_Tplus_OBMEs_p_in_nn_out_non_zero && is_Tminus_OBMEs_pp_in_n_out_non_zero));
							  
							  if (is_TBME_dir_non_zero || is_TBME_exc_non_zero)
							    {
							      const double  Tplus_OBMEs_p_in_n_out =  Tplus_OBMEs_pn_tab(p_in , n_out) ,  Tplus_OBMEs_pp_in_nn_out  = Tplus_OBMEs_pn_tab(pp_in , nn_out);
							      const double Tminus_OBMEs_p_in_n_out = Tminus_OBMEs_pn_tab(p_in , n_out) , Tminus_OBMEs_pp_in_nn_out = Tminus_OBMEs_pn_tab(pp_in , nn_out);
							  
							      const double  Tplus_OBMEs_pp_in_n_out  = Tplus_OBMEs_pn_tab(pp_in , n_out) ,  Tplus_OBMEs_p_in_nn_out  = Tplus_OBMEs_pn_tab(p_in , nn_out);
							      const double Tminus_OBMEs_pp_in_n_out = Tminus_OBMEs_pn_tab(pp_in , n_out) , Tminus_OBMEs_p_in_nn_out = Tminus_OBMEs_pn_tab(p_in , nn_out);
							      
							      const double TBME_dir = Tplus_OBMEs_p_in_n_out*Tminus_OBMEs_pp_in_nn_out + Tplus_OBMEs_pp_in_nn_out*Tminus_OBMEs_p_in_n_out;
							      const double TBME_exc = Tplus_OBMEs_pp_in_n_out*Tminus_OBMEs_p_in_nn_out + Tplus_OBMEs_p_in_nn_out*Tminus_OBMEs_pp_in_n_out;
							      
							      const double TBME = TBME_dir - TBME_exc;
							      
							      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

							      const unsigned int PSI_in_index = PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
							      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();

							      const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							      
							      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							    }
							}
						      else
							{
							  const bool  is_Tplus_OBMEs_n_in_p_out_non_zero =  are_Tplus_OBMEs_pn_non_zero_tab(n_in , p_out) ,  is_Tplus_OBMEs_nn_in_pp_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(nn_in , pp_out);
							  const bool is_Tminus_OBMEs_n_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(n_in , p_out) , is_Tminus_OBMEs_nn_in_pp_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(nn_in , pp_out);
							  
							  const bool  is_Tplus_OBMEs_nn_in_p_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(nn_in , p_out) ,  is_Tplus_OBMEs_n_in_pp_out_non_zero  = are_Tplus_OBMEs_pn_non_zero_tab(n_in , pp_out);
							  const bool is_Tminus_OBMEs_nn_in_p_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(nn_in , p_out) , is_Tminus_OBMEs_n_in_pp_out_non_zero = are_Tminus_OBMEs_pn_non_zero_tab(n_in , pp_out);

							  const bool is_TBME_dir_non_zero = (( is_Tplus_OBMEs_n_in_p_out_non_zero && is_Tminus_OBMEs_nn_in_pp_out_non_zero) || (is_Tplus_OBMEs_nn_in_pp_out_non_zero &&  is_Tminus_OBMEs_n_in_p_out_non_zero));
							  const bool is_TBME_exc_non_zero = ((is_Tplus_OBMEs_nn_in_p_out_non_zero &&  is_Tminus_OBMEs_n_in_pp_out_non_zero) || ( is_Tplus_OBMEs_n_in_pp_out_non_zero && is_Tminus_OBMEs_nn_in_p_out_non_zero));
							  
							  if (is_TBME_dir_non_zero || is_TBME_exc_non_zero)
							    {
							      const double  Tplus_OBMEs_n_in_p_out =  Tplus_OBMEs_pn_tab(n_in , p_out) ,  Tplus_OBMEs_nn_in_pp_out  = Tplus_OBMEs_pn_tab(nn_in , pp_out);
							      const double Tminus_OBMEs_n_in_p_out = Tminus_OBMEs_pn_tab(n_in , p_out) , Tminus_OBMEs_nn_in_pp_out = Tminus_OBMEs_pn_tab(nn_in , pp_out);
							  
							      const double  Tplus_OBMEs_nn_in_p_out  = Tplus_OBMEs_pn_tab(nn_in , p_out) ,  Tplus_OBMEs_n_in_pp_out  = Tplus_OBMEs_pn_tab(n_in , pp_out);
							      const double Tminus_OBMEs_nn_in_p_out = Tminus_OBMEs_pn_tab(nn_in , p_out) , Tminus_OBMEs_n_in_pp_out = Tminus_OBMEs_pn_tab(n_in , pp_out);
							      
							      const double TBME_dir = Tplus_OBMEs_n_in_p_out*Tminus_OBMEs_nn_in_pp_out + Tplus_OBMEs_nn_in_pp_out*Tminus_OBMEs_n_in_p_out;
							      const double TBME_exc = Tplus_OBMEs_nn_in_p_out*Tminus_OBMEs_n_in_pp_out + Tplus_OBMEs_n_in_pp_out*Tminus_OBMEs_nn_in_p_out;
							      
							      const double TBME = TBME_dir - TBME_exc;
							      
							      const unsigned int inSDp_index = two_jumps_cv_p_inSDp.get_inSD_index ();

							      const unsigned int PSI_in_index = PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;
							  
							      const unsigned int total_bin_phase_p = two_jumps_cv_p_inSDp.get_total_bin_phase ();

							      const TYPE &PSI_in_component = PSI_in[PSI_in_index];
							      
							      (total_bin_phase_p == total_bin_phase_n) ? (component_part += PSI_in_component*TBME) : (component_part -= PSI_in_component*TBME);
							    }}}}}
							  
					  PSI_out[PSI_out_index] += component_part;
				      
					}}}}}}}}}}
}











void T2_class::apply_add (
			  const class GSM_vector &PSI_in , 
			  const TYPE &alpha , 
			  class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  if (!PSI_in.same_parity_strangeness_M_projection (GSM_vector_helper)) return;
  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper)) return;
  
  const enum space_type space = GSM_vector_helper.get_space ();
        
  const int S = GSM_vector_helper.get_S ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  if (space == PROT_NEUT_Y)
    {      

#ifdef UseMPI

      if (is_it_MPI_parallelized)
	{
	  double PSI_out_infinite_norm = PSI_out.infinite_norm ();

	  MPI_helper::Bcast<double> (PSI_out_infinite_norm , MASTER_PROCESS , MPI_COMM_WORLD);  

	  if (PSI_out_infinite_norm > 0.0)
	    {
	      PSI_out.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	      
	      PSI_out /= NUMBER_OF_PROCESSES;
	    }
	}
          
#endif

      const class GSM_vector_helper_class dummy_helper;

      const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
      
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
      
      PSI_out.diagonal_part_PSI_add (PSI_in , T2_diagonal_tab , alpha);
      
      if (NYval >= ZYval)
	two_jumps_pn_part_pn_Nval_larger_calc (PSI_in , PSI_out);
      else
	two_jumps_pn_part_pn_Zval_larger_calc (PSI_in , PSI_out);

      if (is_cv_possible)
	{	  
	  if (NYval >= ZYval)
	    {
	      two_jumps_cv_part_pn_Nval_larger_calc (true  , PSI_in , PSI_out);
	      two_jumps_cv_part_pn_Nval_larger_calc (false , PSI_in , PSI_out);
	    }
	  else
	    {
	      two_jumps_cv_part_pn_Zval_larger_calc (true  , PSI_in , PSI_out);
	      two_jumps_cv_part_pn_Zval_larger_calc (false , PSI_in , PSI_out);
	    }
	}
      
      
#ifdef UseMPI
      if (is_it_MPI_parallelized) PSI_out.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
#endif 
     
      if (is_it_TRS && (THIS_PROCESS == MASTER_PROCESS)) PSI_out.TRS_rest_part_fill (J); 
    }
  else if (S != 0)
    PSI_out.diagonal_part_PSI_add (PSI_in , T2_diagonal_tab , alpha);
  else
    {          
      const int Zval = prot_Y_data.get_N_valence_nucleons ();
      const int Nval = neut_Y_data.get_N_valence_nucleons ();
  
      const double Tz = 0.5*(Nval - Zval);
  
      const double T = abs (Tz);
      
      PSI_out += (T*(T + 1.0) + alpha)*PSI_in;
    }
}














double T2_class::T_coupling_precision_calc (
					    const class GSM_vector &PSI , 
					    const double T , 
					    class GSM_vector &PSI_test) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const int S = GSM_vector_helper.get_S ();
  
  if ((S == 0) && (space != PROT_NEUT_Y)) return 0.0;

  const class T2_class &T2 = *this;

  PSI_test = (T2 - T*(T + 1.0))*PSI;

  double PSI_infinite_norm = PSI_test.infinite_norm ();
 
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) MPI_helper::Bcast<double> (PSI_infinite_norm , MASTER_PROCESS , MPI_COMM_WORLD);  
  
#endif
  
  return PSI_infinite_norm;
}









xT2_plus_alpha_str::xT2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class T2_class &T2_c) : x (x_c) , alpha (alpha_c) , T2 (T2_c) {}

class xT2_plus_alpha_str operator + (const class T2_class &T2)
{
  return xT2_plus_alpha_str (1.0 , 0.0 , T2);
}

class xT2_plus_alpha_str operator - (const class T2_class &T2)
{
  return xT2_plus_alpha_str (-1.0 , 0.0 , T2);
}

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const double alpha)
{
  return xT2_plus_alpha_str (1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator - (const class T2_class &T2 , const double alpha)
{
  return xT2_plus_alpha_str (1.0 , -alpha , T2);
}

class xT2_plus_alpha_str operator + (const double alpha , const class T2_class &T2)
{
  return xT2_plus_alpha_str (1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator - (const double alpha , const class T2_class &T2)
{
  return xT2_plus_alpha_str (-1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const double x)
{
  return xT2_plus_alpha_str (x , 0.0 , T2);
}

class xT2_plus_alpha_str operator * (const double x , const class T2_class &T2)
{
  return xT2_plus_alpha_str (x , 0.0 , T2);
}

class xT2_plus_alpha_str operator / (const class T2_class &T2 , const double x)
{
  const double one_over_x = 1.0/x;

  return xT2_plus_alpha_str (one_over_x , 0.0 , T2);
}

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (Op.x , Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (-Op.x , -Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const double term)
{
  return xT2_plus_alpha_str (Op.x , Op.alpha + term , Op.T2);
}

class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const double term)
{
  return xT2_plus_alpha_str (Op.x , Op.alpha - term , Op.T2);
}

class xT2_plus_alpha_str operator + (const double term , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (Op.x , term + Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator - (const double term , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (-Op.x , term - Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const double factor)
{
  return xT2_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.T2);
}

class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const double factor)
{
  return xT2_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.T2);
}

class xT2_plus_alpha_str operator * (const double factor , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.T2);
}

#ifdef TYPEisDOUBLECOMPLEX

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const complex<double> &alpha)
{
  return xT2_plus_alpha_str (1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator - (const class T2_class &T2 , const complex<double> &alpha)
{
  return xT2_plus_alpha_str (1.0 , -alpha , T2);
}

class xT2_plus_alpha_str operator + (const complex<double> &alpha , const class T2_class &T2)
{
  return xT2_plus_alpha_str (1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator - (const complex<double> &alpha , const class T2_class &T2)
{
  return xT2_plus_alpha_str (-1.0 , alpha , T2);
}

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const complex<double> &x)
{
  return xT2_plus_alpha_str (x , 0.0 , T2);
}

class xT2_plus_alpha_str operator * (const complex<double> &x , const class T2_class &T2)
{
  return xT2_plus_alpha_str (x , 0.0 , T2);
}

class xT2_plus_alpha_str operator / (const class T2_class &T2 , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xT2_plus_alpha_str (one_over_x , 0.0 , T2);
}

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const complex<double> &term)
{
  return xT2_plus_alpha_str (Op.x , Op.alpha + term , Op.T2);
}

class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const complex<double> &term)
{
  return xT2_plus_alpha_str (Op.x , Op.alpha - term , Op.T2);
}

class xT2_plus_alpha_str operator + (const complex<double> &term , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (Op.x , term + Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator - (const complex<double> &term , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (-Op.x , term - Op.alpha , Op.T2);
}

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const complex<double> &factor)
{
  return xT2_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.T2);
}

class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const complex<double> &factor)
{
  return xT2_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.T2);
}

class xT2_plus_alpha_str operator * (const complex<double> &factor , const class xT2_plus_alpha_str &Op)
{
  return xT2_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.T2);
}

#endif

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b)
{
  if (&(Op_a.T2) != &(Op_b.T2))
    error_message_print_abort ("T2 must be the same in both Op_a and Op_b in class xT2_plus_alpha_str operator +");

  return xT2_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.T2);
}

class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b)
{	
  if (&(Op_a.T2) != &(Op_b.T2))
    error_message_print_abort ("T2 must be the same in both Op_a and Op_b in class xT2_plus_alpha_str operator -");

  return xT2_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.T2);
}



double used_memory_calc (const class T2_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.T2_diagonal_tab) - sizeof (T.T2_diagonal_tab)/1000000.0);
}
