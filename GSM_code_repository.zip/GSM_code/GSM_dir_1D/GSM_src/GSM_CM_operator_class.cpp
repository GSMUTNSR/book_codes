#include "../GSM_include/GSM_include_def.h"


// TYPE is double or complex
// -------------------------

// CM means center of mass
// -----------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------



// Class applying a center of mass operator (Hcm, P^2/2M, rms radius, L+, L-, Lz, A+[CM-HO]) to |Psi[in]> to obtain |Psi[out]>
// ---------------------------------------------------------------------------------------------------------------------------
// One calculates first the angular tables with which CM TBMEs can be calculated. Then one calculates and stores diagonal matrix elements if any.
// One has here constructors, destructors, CM operator apply call and operators overloading of operations of the type a.Hcm + b.
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
//
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + (CM_operator + alpha.Id).|Psi[in]>.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + (CM_operator + alpha.Id).|Psi[in]>
//
// TRS is time-reversal symmetry. It allows to calculate about one half of |Psi[out]>,
// while the rest is given from the first half up to a phase if M=0 in |Psi[in]> and |Psi[out]> and if CM-Op is a scalar.
// Indeed, the components of |SD> and TRS|SD> differ only by a +/-1 phase, which is straightforward to calculate.
// 
// For the proton-neutron case, one routine is used if NYval >= ZYval, and another if not, as SD indices are calculated differently in each case to optimize their use (see GSM_vector_dimensions.cpp).
//
// A_dagger_CM_HO_component_determine
// ----------------------------------
// A+[CM-HO] is a tensor operator of rank 1, of tensor component then equal to -1,0,1. The proper A+[CM-HO]_mu operator is given in A_dagger_CM_HO_component_determine from the three possible operators.
//
// xCM_operator_plus_alpha_str
// ---------------------------
// Operators overloading of operations are of the type a.Hcm + b.Id, to which operators of the form c.Hcm + d.Id can be added. One cannot add b.Id to a non-scalar operator.
// One cannot add another operator to a.Hcm + b.Id besides c.Hcm + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).Hcm + (b + d).Id .
// One can use instead (a*Hcm + b)*PSI_0 + H*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.

CM_operator_class::CM_operator_class () :
  CM_operator_inter (NO_OPERATOR) ,
  is_it_HO_expansion (false) ,
  J (0.0) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{}








CM_operator_class::CM_operator_class (
				      const enum operator_type CM_operator_inter_c ,
				      const double J_c , 
				      const bool is_it_HO_expansion_c , 
				      const class GSM_vector_helper_class &GSM_vector_helper_in ,
				      const class GSM_vector_helper_class &GSM_vector_helper_out) :
  CM_operator_inter (NO_OPERATOR) ,
  is_it_HO_expansion (false) ,
  J (0.0) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate (CM_operator_inter_c , J_c , is_it_HO_expansion_c , GSM_vector_helper_in , GSM_vector_helper_out);
}





CM_operator_class::CM_operator_class (const class CM_operator_class &X) :
  CM_operator_inter (NO_OPERATOR) ,
  is_it_HO_expansion (false) ,
  J (0.0) ,
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate_fill (X);
}



CM_operator_class::~CM_operator_class () {}










void CM_operator_class::allocate (
				  const enum operator_type CM_operator_inter_c , 
				  const double J_c ,  
				  const bool is_it_HO_expansion_c , 
				  const class GSM_vector_helper_class &GSM_vector_helper_in ,
				  const class GSM_vector_helper_class &GSM_vector_helper_out)
{
  if (is_it_filled ()) error_message_print_abort ("CM_operator_class cannot be allocated twice in CM_operator_class::allocate");

  if (GSM_vector_helper_in.get_space_dimension () == 0) return;
  
  if (GSM_vector_helper_out.get_space_dimension () == 0) return;
  
  CM_operator_inter = CM_operator_inter_c;

  is_it_HO_expansion = is_it_HO_expansion_c;
  
  J = J_c;
     
  GSM_vector_helper_in_ptr = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;
	  
  const bool is_it_CM_symmetric_operator = is_it_CM_symmetric_operator_determine (CM_operator_inter);
  
  const bool is_it_two_body_operator = !is_it_A_dagger_CM_HO_determine (CM_operator_inter);
      
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const double mp_max = prot_Y_data.get_m_max ();
  const double mn_max = neut_Y_data.get_m_max ();

  const unsigned long int dimension_SDp_total = prot_Y_data.get_dimension_SD_total ();
  const unsigned long int dimension_SDn_total = neut_Y_data.get_dimension_SD_total ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SDp_set = prot_Y_data.get_sum_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SDn_set = neut_Y_data.get_sum_dimensions_SD_set ();
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	if (is_it_two_body_operator) TBMEs_angular_table.allocate_calc_uncoupled (CM_operator_inter , mp_max);

	if (is_it_CM_symmetric_operator)
	  {
	    diagonal_NBMEs_p.allocate (dimension_SDp_total , sum_dimensions_SDp_set);
	
	    NBMEs_diagonal_all_SDs_calc_pp_nn (prot_Y_data);
	  }
	
      } break;

    case NEUT_Y_ONLY:
      {
	if (is_it_two_body_operator) TBMEs_angular_table.allocate_calc_uncoupled (CM_operator_inter , mn_max);
	
	if (is_it_CM_symmetric_operator)
	  {
	    diagonal_NBMEs_n.allocate (dimension_SDn_total , sum_dimensions_SDn_set);

	    NBMEs_diagonal_all_SDs_calc_pp_nn (neut_Y_data);
	  }
      } break;

    case PROT_NEUT_Y:
      {
	if (is_it_two_body_operator)
	  {
	    const double m_max = max (mp_max , mn_max);
	    
	    TBMEs_angular_table.allocate_calc_uncoupled (CM_operator_inter , m_max);
	  }
	
	if (is_it_CM_symmetric_operator)
	  {
	    diagonal_NBMEs_p.allocate (dimension_SDp_total , sum_dimensions_SDp_set);
	    diagonal_NBMEs_n.allocate (dimension_SDn_total , sum_dimensions_SDn_set);
 
	    NBMEs_p_diagonal_all_SDs_calc_pn (prot_Y_data);
	    NBMEs_n_diagonal_all_SDs_calc_pn (neut_Y_data);
	  }
	
      } break;

    default: abort_all ();
    }
}








void CM_operator_class::allocate_fill (const class CM_operator_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("CM_operator_class cannot be allocated twice in CM_operator_class::allocate_fill");

  CM_operator_inter = X.CM_operator_inter;

  is_it_HO_expansion = X.is_it_HO_expansion;

  J = X.J;
  
  GSM_vector_helper_in_ptr = X.GSM_vector_helper_in_ptr;

  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;
        
  TBMEs_angular_table.allocate_fill (X.TBMEs_angular_table);

  diagonal_NBMEs_p.allocate_fill (X.diagonal_NBMEs_p);
  diagonal_NBMEs_n.allocate_fill (X.diagonal_NBMEs_n);
}





void CM_operator_class::deallocate ()
{
  TBMEs_angular_table.deallocate ();

  diagonal_NBMEs_p.deallocate ();
  diagonal_NBMEs_n.deallocate ();
  
  GSM_vector_helper_in_ptr = NULL;

  GSM_vector_helper_out_ptr = NULL;
  
  CM_operator_inter = NO_OPERATOR;

  is_it_HO_expansion = false;

  J = 0.0; 
}






void CM_operator_class::apply_add (
				   const class GSM_vector &PSI_in ,
				   const TYPE &alpha , 
				   class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  if (!PSI_in.same_parity_strangeness_M_projection (GSM_vector_helper_in)) return;

  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper_out)) return;
  
  const unsigned int BP_in  = GSM_vector_helper_in.get_BP ();
  const unsigned int BP_out = GSM_vector_helper_out.get_BP ();
  
  const unsigned int BP_CM_operator = Op_BP_determine (CM_operator_inter);

  if (BP_out != binary_parity_product (BP_in , BP_CM_operator)) return;
  
  const int S_in  = GSM_vector_helper_in.get_S ();
  const int S_out = GSM_vector_helper_out.get_S ();
  
  if (S_in != S_out) return;
  
  const int iM_in  = GSM_vector_helper_in.get_iM ();
  const int iM_out = GSM_vector_helper_out.get_iM ();
  
  const int CM_operator_mu = Op_standard_coordinate_determine (CM_operator_inter); 
  
  if (iM_out != iM_in + CM_operator_mu) return;
  
#ifdef UseMPI
   
  if (is_it_MPI_parallelized)
    {
      double PSI_out_infinite_norm = PSI_out.infinite_norm ();

      MPI_helper::Bcast<double> (PSI_out_infinite_norm , MASTER_PROCESS , MPI_COMM_WORLD);  

      if (PSI_out_infinite_norm > 0.0)
	{
	  PSI_out.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

	  PSI_out /= NUMBER_OF_PROCESSES;
	}
    }
      
#endif
    
  const class GSM_vector_helper_class dummy_helper;
  
  const bool is_it_CM_symmetric_operator = is_it_CM_symmetric_operator_determine (CM_operator_inter);
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
    
  const bool is_it_two_body_operator = !is_it_A_dagger_CM_HO_determine (CM_operator_inter);
      
  const int CM_operator_rank = Op_rank_determine (CM_operator_inter);
  
  const bool is_it_TRS_in = GSM_vector_helper_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = ((CM_operator_rank == 0) && is_it_TRS_in && is_it_TRS_out);
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
      
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
   
  if (space == PROT_NEUT_Y)
    {
      if (is_it_CM_symmetric_operator)
      	{
	  if (NYval >= ZYval)
	    diagonal_part_pn_Nval_larger_calc (alpha , PSI_in , PSI_out);
	  else
	    diagonal_part_pn_Zval_larger_calc (alpha , PSI_in , PSI_out);
	}
      
      jumps_p_one_body_part_pn_calc (PSI_in , PSI_out);
      jumps_n_one_body_part_pn_calc (PSI_in , PSI_out);
      
      if (is_it_two_body_operator)
	{
	  jumps_p_two_body_part_pn_calc (PSI_in , PSI_out);
	  jumps_n_two_body_part_pn_calc (PSI_in , PSI_out);
      
	  if (NYval >= ZYval)
	    two_jumps_pn_part_pn_Nval_larger_calc (PSI_in , PSI_out);
	  else
	    two_jumps_pn_part_pn_Zval_larger_calc (PSI_in , PSI_out);
	}
    }
  else
    {  
      if (is_it_CM_symmetric_operator) diagonal_part_pp_nn_calc (alpha , PSI_in , PSI_out);
      
      jumps_part_pp_nn_calc (PSI_in , PSI_out);
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) PSI_out.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);  
#endif
  
  if (is_it_TRS && (THIS_PROCESS == MASTER_PROCESS)) PSI_out.TRS_rest_part_fill (J);
}













const class CM_operator_class & A_dagger_CM_HO_component_determine (
								    const int mu , 
								    const class CM_operator_class &A_dagger_CM_HO_minus , 
								    const class CM_operator_class &A_dagger_CM_HO_zero , 
								    const class CM_operator_class &A_dagger_CM_HO_plus)
{
  switch (mu)
    {
    case -1: return A_dagger_CM_HO_minus;
    case  0: return A_dagger_CM_HO_zero;
    case  1: return A_dagger_CM_HO_plus;
      
    default: abort_all ();
    }

  return A_dagger_CM_HO_zero;
}



xCM_operator_plus_alpha_str::xCM_operator_plus_alpha_str (
							  const TYPE &x_c ,
							  const TYPE &alpha_c ,
							  const class CM_operator_class &CM_operator_c) :
  x (x_c) ,
  alpha (alpha_c) ,
  CM_operator (CM_operator_c) 
{
  if (alpha != 0.0)
    {
      const enum operator_type CM_operator_inter = CM_operator.get_CM_operator_inter ();

      const unsigned int BP_CM_operator = Op_BP_determine (CM_operator_inter);

      const int CM_operator_mu = Op_standard_coordinate_determine (CM_operator_inter);

      if ((BP_CM_operator == 1) || (CM_operator_mu != 0)) error_message_print_abort ("One cannot have an operator of the form x.O[CM] + alpha with alpha non zero if O[CM] changes parity or J-projection.");
    }
}

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (1.0 , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (-1.0 , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const double alpha)
{
  return xCM_operator_plus_alpha_str (1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const double alpha)
{
  return xCM_operator_plus_alpha_str (1.0 , -alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const double alpha , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const double alpha , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (-1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const double x)
{
  return xCM_operator_plus_alpha_str (x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const double x , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const double x)
{
  const double one_over_x = 1.0/x;

  return xCM_operator_plus_alpha_str (one_over_x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (Op.x , Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (-Op.x , -Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const double term)
{
  return xCM_operator_plus_alpha_str (Op.x , Op.alpha + term , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const double term)
{
  return xCM_operator_plus_alpha_str (Op.x , Op.alpha - term , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const double term , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (Op.x , term + Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const double term , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (-Op.x , term - Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const double factor)
{
  return xCM_operator_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const double factor)
{
  return xCM_operator_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const double factor , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.CM_operator);
}

#ifdef TYPEisDOUBLECOMPLEX

class xCM_operator_plus_alpha_str operator + (const class CM_operator_class &CM_operator , const complex<double> &alpha)
{
  return xCM_operator_plus_alpha_str (1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class CM_operator_class &CM_operator , const complex<double> &alpha)
{
  return xCM_operator_plus_alpha_str (1.0 , -alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const complex<double> &alpha , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const complex<double> &alpha , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (-1.0 , alpha , CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const class CM_operator_class &CM_operator , const complex<double> &x)
{
  return xCM_operator_plus_alpha_str (x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const complex<double> &x , const class CM_operator_class &CM_operator)
{
  return xCM_operator_plus_alpha_str (x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator / (const class CM_operator_class &CM_operator , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xCM_operator_plus_alpha_str (one_over_x , 0.0 , CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term)
{
  return xCM_operator_plus_alpha_str (Op.x , Op.alpha + term , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op , const complex<double> &term)
{
  return xCM_operator_plus_alpha_str (Op.x , Op.alpha - term , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator + (const complex<double> &term , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (Op.x , term + Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const complex<double> &term , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (-Op.x , term - Op.alpha , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor)
{
  return xCM_operator_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator / (const class xCM_operator_plus_alpha_str &Op , const complex<double> &factor)
{
  return xCM_operator_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.CM_operator);
}

class xCM_operator_plus_alpha_str operator * (const complex<double> &factor , const class xCM_operator_plus_alpha_str &Op)
{
  return xCM_operator_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.CM_operator);
}

#endif

class xCM_operator_plus_alpha_str operator + (const class xCM_operator_plus_alpha_str &Op_a , const class xCM_operator_plus_alpha_str &Op_b)
{
  if (&(Op_a.CM_operator) != &(Op_b.CM_operator)) error_message_print_abort ("CM_operator must be the same in both Op_a and Op_b in class xCM_operator_plus_alpha_str operator +");

  return xCM_operator_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.CM_operator);
}

class xCM_operator_plus_alpha_str operator - (const class xCM_operator_plus_alpha_str &Op_a , const class xCM_operator_plus_alpha_str &Op_b)
{	
  if (&(Op_a.CM_operator) != &(Op_b.CM_operator)) error_message_print_abort ("CM_operator must be the same in both Op_a and Op_b in class xCM_operator_plus_alpha_str operator -");

  return xCM_operator_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.CM_operator);
}



double used_memory_calc (const class CM_operator_class &T)
{
  return (sizeof (T)/1000000.0 +
	  used_memory_calc (T.TBMEs_angular_table) +
	  used_memory_calc (T.diagonal_NBMEs_p) +
	  used_memory_calc (T.diagonal_NBMEs_n) -
	  (sizeof (T.TBMEs_angular_table) +
	   sizeof (T.diagonal_NBMEs_p) +
	   sizeof (T.diagonal_NBMEs_n))/1000000.0);
}
