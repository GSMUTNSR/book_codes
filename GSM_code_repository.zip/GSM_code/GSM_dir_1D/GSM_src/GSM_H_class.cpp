#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;


// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Class xH_plus_alpha_str is used only in closures and then is not commented.


// Class applying Hamiltonian plus number times identity to |Psi[in]> to obtain |Psi[out]>
// ----------------------------------------------------------------------------------------
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.H + b.
//
// Routines here besides one_jump_p_tab_all_SDp_calc, one_jump_n_tab_all_SDn_calc, NBMEs_two_jumps_pp_nn_calc_store
// are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The average and maximal memories occupied in MPI ranks and its dispersion are written on screen after memory allocation.
// Indeed, this a measure a load imbalance, which is usually less or about a factor 2 but can be significant nevertheless.
// Average and maximal memories are equal for a sequential calculation and dispersion is equal to zero.
//
// Full storage and on the fly methods can be used.
// One can store either NBMEs or NBMEs indices for the 2p-2h part, with Hamiltonian_storage put to FULL_STORAGE or PARTIAL_STORAGE.
// A NBME index is of the form reordering binary phase + 2.TBME index, where reordering binary phase is 0,1 (see observables_basic_functions.cpp for definition)
// and TBME index is the index the TBME in the array of uncoupled TBMEs M_TBMEs, as NBME = reordering phase . TBME.
// Thus, one can reconstruct the NBME from the NBME index, as TBME index = NBME index/2 and reordering binary phase = NBME index%2.
// As NBMEs are complex numbers and indices are integers, and as one always has to store the associated in Slater determinant index, which is an unsigned integer,
// PARTIAL_STORAGE stores two unsigned integers (4 + 4 = 8 bytes) where FULL_STORAGE stores one complex number and one unsigned integer (16 + 4 = 20 bytes).
// Hence, PARTIAL_STORAGE provides with a memory gain of 2.5 compared to FULL_STORAGE.
// However, PARTIAL_STORAGE is typically slower by a factor of 2-3,
// as one has to look for non-contiguous uncoupled TBMEs in M_TBMEs when looping on in Slater determinants, which takes more time as looping on arrays element after element.
//
// used_memory_calc
// ----------------
// This routine calculates the memory used by the class in Mb by looping over its data and adding their used memory.
//
// print
// -----
// This routine prints non-zero Hamiltonian NBMEs on screen, This can be used only in a sequential calculation and using the FULL_STORAGE option. It is typically used for tests.
//
//
//
// NBMEs_one_jump_pp_nn_calc_store, NBMEs_two_jumps_indices_pp_nn_calc_store
// -------------------------------------------------------------------------
// One considers only the proton or neutron 1p-1h or 2p-2h part (PARTIAL_STORAGE only for 2p-2h, see GSM_H_class.cpp), and one uses the notation mu for proton or neutron.
// This is for p -> p', n -> n', p1 p2 -> p1' p2' and n1 n2 -> n1' n2' only.
// The routine NBMEs_two_jumps_pp_nn_calc_store of GSM_H_class.cpp is used for FULL_STORAGE (see GSM_H_class.cpp).
// This provides with non-zero off-diagonal NBMEs for 1p-1h or 2p-2h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one calculates the NBME without reordering phase, 
// which is multiplied afterwards by the reordering phase, calculated along with jumps data and stored in jumps data arrays.
//
//
// is_there_Hamiltonian_storage_determine
// --------------------------------------
// This should be used with Hamiltonian_storage equal to FULL_STORAGE or PARTIAL_STORAGE. No test is made.
// This routine is related to the symmetry of the Hamiltonian matrix.
// One checks whether one stores the NBME <outSD | H | inSD> or not (FULL_STORAGE only for 2p-2h matrix elements),
// or whether one stores its associated TBME index and phase or not (PARTIAL_STORAGE only).
// Indeed, without TRS, one stores H data if PSI_in_index + PSI_out_index is even if PSI_in_index > PSI_out_index, and if PSI_in_index + PSI_out_index is odd if PSI_in_index <= PSI_out_index.
// This allows to store half of Hamiltonian in a well balanced way.
// H data are always stored if TRS is used, as Hamiltonian matrix symmetry is taken into account by TRS for about 87% of H.
// One could use both Hamiltonian matrix symmetry and TRS symmetry for Hamiltonian_storage in principle.
// But one would gain only about 13% of H memory, as for additional memory gain to occur,
// one has to have TRS(outSD) > outSD or TRS(inSD) > inSD (Hamiltonian matrix symmetry is included in other cases), which is 25% of memory, which would be divided by 2.
// Calculations would also be much slower as additional tests would be made. Hence, one does not use Hamiltonian matrix symmetry when TRS is used.
//
// The symmetry of the Hamiltonian matrix is fully taken into account if TRS is not used, as it is about 50% gain therein.
// For this, one stores NBMEs if: inSD_index > outSD_index and inSD_index + outSD_index is even, or, inSD_index < outSD_index and inSD_index + outSD_index is odd.
//
//
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + (H + alpha.Id).|Psi[in]>, where alpha is a constant.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + (H + alpha.Id).|Psi[in]>
//
// TRS is time-reversal symmetry and can be used therein.
// It allows to calculate about one half of |Psi[out]> if M=0, while the rest is given from the first half up to a phase in |Psi[in]> and |Psi[out]>.
// 
// When recovering the symmetric part of the Hamiltonian matrix, one has to pay attention that inSD and outSD indices are exchanged,
// so that this would create a race condition with OpenMP as OpenMP distribution is done on outSD indices.
// To avoid it, one uses an array of GSM vectors, one for each core.
// This creates no additional memory as such an array is already used to orthogonalize Lanczos or Jacobi/Davidson vectors.
// 
// The time taken for a Hamiltonian times vector operation can be printed on screen.
//
//
//
// xH_plus_alpha_str
// -----------------
// Hpa must be understood here as H + alpha.Id (see above).
// Operators overloading of operations are of the type a.Hpa + b.Id, to which operators of the form c.Hpa + d.Id as well can be added. 
// One cannot add another operator to a.Hpa + b.Id besides c.Hpa + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).Hpa + (b + d).Id .
// One can use instead (a*Hpa + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.


H_class::H_class () :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  is_it_Davidson (false) ,
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) ,
  space_dimension_process_non_zeros_one_jump (0) , 
  space_dimension_process_non_zeros_two_jumps (0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL) ,
  H_PSI_table_ptr (NULL)
{}






H_class::H_class (
		  const bool is_there_cout_c , 
		  const bool print_detailed_information , 
		  const bool non_zero_NBMEs_proportion_only ,
		  const bool is_it_Davidson_c , 
		  const class TBMEs_class &TBMEs_pn , 
		  const class TBMEs_class &TBMEs_cv , 
		  const enum storage_type Hamiltonian_storage_c ,
		  const enum storage_type M_TBMEs_storage_c ,
		  const enum storage_type one_jumps_pn_two_jumps_cv_storage_c ,
		  const bool is_one_body_p_non_zero_if_here_c , 
		  const bool is_one_body_n_non_zero_if_here_c , 
		  const bool is_pp_non_zero_if_here_c , 
		  const bool is_nn_non_zero_if_here_c , 
		  const bool is_pn_non_zero_if_here_c , 
		  const bool is_cv_non_zero_if_here_c , 
		  const double J_c , 
		  const class GSM_vector_helper_class &GSM_vector_helper ,
		  class array<class GSM_vector> &H_PSI_table) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  is_it_Davidson (false) ,
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) ,
  space_dimension_process_non_zeros_one_jump (0) , 
  space_dimension_process_non_zeros_two_jumps (0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL) ,
  H_PSI_table_ptr (NULL)
{
  allocate (is_there_cout_c , print_detailed_information , non_zero_NBMEs_proportion_only , is_it_Davidson_c , 
	    TBMEs_pn , TBMEs_cv , Hamiltonian_storage_c , M_TBMEs_storage_c , one_jumps_pn_two_jumps_cv_storage_c , is_one_body_p_non_zero_if_here_c , is_one_body_n_non_zero_if_here_c ,
	    is_pp_non_zero_if_here_c , is_nn_non_zero_if_here_c , is_pn_non_zero_if_here_c , is_cv_non_zero_if_here_c , J_c , GSM_vector_helper , H_PSI_table);
}




H_class::H_class (const class H_class &X) :
  is_there_cout (false) , 
  is_there_cout_detailed (false) , 
  Hamiltonian_storage (NO_STORAGE) ,
  M_TBMEs_storage (NO_STORAGE) , 
  one_jumps_pn_two_jumps_cv_storage (NO_STORAGE) , 
  is_it_Davidson (false) , 
  is_one_body_p_non_zero (false) , 
  is_one_body_n_non_zero (false) , 
  is_pp_non_zero (false) , 
  is_nn_non_zero (false) , 
  is_pn_non_zero (false) ,
  is_cv_non_zero (false) ,
  J (0.0) ,
  space_dimension_process_non_zeros_one_jump (0) , 
  space_dimension_process_non_zeros_two_jumps (0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL) ,
  TBMEs_cv_ptr (NULL) ,
  H_PSI_table_ptr (NULL)
{
  allocate_fill (X);
}






H_class::~H_class ()
{
  if (rows_non_zero_NBMEs_one_jump_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_one_jump_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_one_jump_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs_one_jump.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_one_jump.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_one_jump(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps_indices(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps(i);
    }
}





void H_class::allocate (
			const bool is_there_cout_c ,
			const bool print_detailed_information , 
			const bool non_zero_NBMEs_proportion_only , 
			const bool is_it_Davidson_c , 
			const class TBMEs_class &TBMEs_pn , 
			const class TBMEs_class &TBMEs_cv , 
			const enum storage_type Hamiltonian_storage_c ,
			const enum storage_type M_TBMEs_storage_c ,
			const enum storage_type one_jumps_pn_two_jumps_cv_storage_c ,
			const bool is_one_body_p_non_zero_if_here_c , 
			const bool is_one_body_n_non_zero_if_here_c , 
			const bool is_pp_non_zero_if_here_c , 
			const bool is_nn_non_zero_if_here_c , 
			const bool is_pn_non_zero_if_here_c ,
			const bool is_cv_non_zero_if_here_c ,
			const double J_c , 
			const class GSM_vector_helper_class &GSM_vector_helper ,
			class array<class GSM_vector> &H_PSI_table)
{
  if (is_it_filled ()) error_message_print_abort ("H_class cannot be allocated twice in H_class::allocate");

  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  is_there_cout = is_there_cout_c;

  is_there_cout_detailed = (is_there_cout && print_detailed_information);

  Hamiltonian_storage = Hamiltonian_storage_c;

  M_TBMEs_storage = M_TBMEs_storage_c;
  
  one_jumps_pn_two_jumps_cv_storage = one_jumps_pn_two_jumps_cv_storage_c;

  if ((Hamiltonian_storage == FULL_STORAGE) && (M_TBMEs_storage != ON_THE_FLY) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S == 0))
    error_message_print_abort ("If one has Hamiltonian full storage, storage of uncoupled TBMEs and one jumps proton-neutron must be on the fly");
  
  if ((Hamiltonian_storage == FULL_STORAGE) && (M_TBMEs_storage != ON_THE_FLY) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S != 0))
    error_message_print_abort ("If one has Hamiltonian full storage, storage of uncoupled TBMEs and one jumps proton-neutron / two jumps for pp <-> m conversions must be on the fly");
  
  if ((Hamiltonian_storage == PARTIAL_STORAGE) && (M_TBMEs_storage != FULL_STORAGE) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S == 0))
    error_message_print_abort ("If one has Hamiltonian partial storage, storage of uncoupled TBMEs must be full storage and that of one jumps proton-neutron must be on the fly");

  if ((Hamiltonian_storage == PARTIAL_STORAGE) && (M_TBMEs_storage != FULL_STORAGE) && (one_jumps_pn_two_jumps_cv_storage != ON_THE_FLY) && (S != 0))
    error_message_print_abort ("If one has Hamiltonian partial storage, storage of uncoupled TBMEs must be full storage and that of one jumps proton-neutron / two jumps for pp <-> m conversions must be on the fly");
    
  is_it_Davidson = is_it_Davidson_c;
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  is_one_body_p_non_zero = (space != NEUT_Y_ONLY) ? (is_one_body_p_non_zero_if_here_c) : (false);
  is_one_body_n_non_zero = (space != PROT_Y_ONLY) ? (is_one_body_n_non_zero_if_here_c) : (false);
 
  is_pp_non_zero = (space != NEUT_Y_ONLY) ? (is_pp_non_zero_if_here_c) : (false);
  is_nn_non_zero = (space != PROT_Y_ONLY) ? (is_nn_non_zero_if_here_c) : (false);
  is_pn_non_zero = (space == PROT_NEUT_Y) ? (is_pn_non_zero_if_here_c) : (false);
  is_cv_non_zero = (space == PROT_NEUT_Y) ? (is_cv_non_zero_if_here_c) : (false);
  
  J = J_c;
  
  GSM_vector_helper_ptr = &GSM_vector_helper; 

  TBMEs_pn_ptr = &TBMEs_pn; 
  TBMEs_cv_ptr = &TBMEs_cv; 
   
  H_PSI_table_ptr = &H_PSI_table;
  
  space_dimension_process_non_zeros_one_jump  = 0;
  space_dimension_process_non_zeros_two_jumps = 0;

  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  if (space_dimension == 0) return;

  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
    
  const bool is_it_full_or_partial_storage = is_it_full_or_partial_storage_determine (Hamiltonian_storage);

  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const unsigned int ZYval = prot_Y_data.get_N_valence_baryons ();
  const unsigned int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const bool is_it_Nval_larger = (NYval >= ZYval);
	      
  // See comments of one_jump_p_tab_all_SDp_calc, one_jump_p_tab_all_SDn_calc, two_jumps_cv_n_tab_all_SDn_calc , ttwo_jumps_cv_p_tab_all_SDp_calc for array allocation of one_jump_p_tabs, one_jump_n_tabs below.
   
  if ((space == PROT_NEUT_Y) && is_pn_non_zero)
    {      
      const unsigned int ZY_valence_pairs_number = (ZYval*(ZYval - 1))/2;
      const unsigned int NY_valence_pairs_number = (NYval*(NYval - 1))/2;
  
      const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
      const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();

      const bool is_it_jumps_full_storage = (one_jumps_pn_two_jumps_cv_storage == FULL_STORAGE);
      
      const bool is_it_one_jumps_pn_two_jumps_cv_partial_storage = (one_jumps_pn_two_jumps_cv_storage == PARTIAL_STORAGE);

      const bool is_it_jumps_p_partial_storage = (is_it_one_jumps_pn_two_jumps_cv_partial_storage &&  is_it_Nval_larger);
      const bool is_it_jumps_n_partial_storage = (is_it_one_jumps_pn_two_jumps_cv_partial_storage && !is_it_Nval_larger);

      class array<class jumps_data_str> dummy_two_jumps_cv_tab;
	  
      if (is_it_jumps_full_storage || is_it_jumps_p_partial_storage)
	{      
	  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
	  const int four_mp_max = prot_Y_data.get_four_m_max ();
	  
	  const int four_mp_max_plus_one = four_mp_max + 1;

	  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
	  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

	  const unsigned long int total_outSDp_number = (total_outSDp_index_max >= total_outSDp_index_min) ? ((total_outSDp_index_max - total_outSDp_index_min) + 1) : (0);   
	  
	  one_jump_p_tabs.allocate (total_outSDp_number);  

	  if (is_cv_non_zero)
	    {
	      two_jumps_cv_p_pp_to_nn_tabs.allocate (total_outSDp_number);
	      two_jumps_cv_p_nn_to_pp_tabs.allocate (total_outSDp_number);
	    }
			
	  for (unsigned long int i = 0 ; i < total_outSDp_number ; i++)
	    {
	      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(i);
	  
	      one_jump_p_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);

	      class array<class jumps_data_str> &two_jumps_cv_p_pp_to_nn_tab = (is_cv_non_zero) ? (two_jumps_cv_p_pp_to_nn_tabs(i)) : (dummy_two_jumps_cv_tab);
	      class array<class jumps_data_str> &two_jumps_cv_p_nn_to_pp_tab = (is_cv_non_zero) ? (two_jumps_cv_p_nn_to_pp_tabs(i)) : (dummy_two_jumps_cv_tab);
		  
	      if (is_cv_non_zero)
		{
		  two_jumps_cv_p_pp_to_nn_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
		  two_jumps_cv_p_nn_to_pp_tab.allocate (2 , S_plus_one , four_mp_max_plus_one);
		}
		      
	      for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
		for (int Sp = 0 ; Sp <= S ; Sp++)
		  for (int Delta_iMp = 0 ; Delta_iMp <= four_mp_max ; Delta_iMp++)
		    {
		      one_jump_p_tab(BPp , Sp , Delta_iMp).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

		      if (is_cv_non_zero)
			{
			  two_jumps_cv_p_pp_to_nn_tab(BPp , Sp , Delta_iMp).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
			  two_jumps_cv_p_nn_to_pp_tab(BPp , Sp , Delta_iMp).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , ZY_valence_pairs_number);
			}
		    }
	    }
	  
	  one_jump_p_tab_all_SDp_calc ();
	  
	  if (is_cv_non_zero)
	    {
	      two_jumps_cv_p_tab_all_SDp_calc (true);
	      two_jumps_cv_p_tab_all_SDp_calc (false);
	    }
	}
           
      if (is_it_jumps_full_storage || is_it_jumps_n_partial_storage) 
	{
	  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
      
	  const int four_mn_max = neut_Y_data.get_four_m_max ();

	  const int four_mn_max_plus_one = four_mn_max + 1;
	  
	  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
	  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();
      
	  const unsigned long int total_outSDn_number = (total_outSDn_index_max >= total_outSDn_index_min) ? ((total_outSDn_index_max - total_outSDn_index_min) + 1) : (0);
	  
	  one_jump_n_tabs.allocate (total_outSDn_number);
      
	  if (is_cv_non_zero)
	    {
	      two_jumps_cv_n_pp_to_nn_tabs.allocate (total_outSDn_number);
	      two_jumps_cv_n_nn_to_pp_tabs.allocate (total_outSDn_number);
	    }
		
	  for (unsigned long int i = 0 ; i < total_outSDn_number ; i++)
	    {
	      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(i);
	 
	      one_jump_n_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
				      
	      class array<class jumps_data_str> &two_jumps_cv_n_pp_to_nn_tab = (is_cv_non_zero) ? (two_jumps_cv_n_pp_to_nn_tabs(i)) : (dummy_two_jumps_cv_tab);
	      class array<class jumps_data_str> &two_jumps_cv_n_nn_to_pp_tab = (is_cv_non_zero) ? (two_jumps_cv_n_nn_to_pp_tabs(i)) : (dummy_two_jumps_cv_tab);

	      if (is_cv_non_zero)
		{
		  two_jumps_cv_n_pp_to_nn_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
		  two_jumps_cv_n_nn_to_pp_tab.allocate (2 , S_plus_one , four_mn_max_plus_one);
		}
	      
	      for (unsigned int BPn = 0 ; BPn <= 1 ; BPn++)
		for (int Sn = 0 ; Sn <= S ; Sn++)
		  for (int Delta_iMn = 0 ; Delta_iMn <= four_mn_max ; Delta_iMn++)
		    {
		      one_jump_n_tab(BPn , Sn , Delta_iMn).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

		      if (is_cv_non_zero)
			{
			  two_jumps_cv_n_pp_to_nn_tabs(BPn , Sn , Delta_iMn).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
			  two_jumps_cv_n_nn_to_pp_tabs(BPn , Sn , Delta_iMn).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , NY_valence_pairs_number);
			}
		    }
	    }
  
	  one_jump_n_tab_all_SDn_calc ();
	  
	  if (is_cv_non_zero)
	    {
	      two_jumps_cv_n_tab_all_SDn_calc (true);
	      two_jumps_cv_n_tab_all_SDn_calc (false);
	    }
	}
      
      if (is_there_cout_detailed)
	{
	  const double one_jump_tabs_used_memory_process_partial = used_memory_calc (one_jump_p_tabs) + used_memory_calc (one_jump_n_tabs);

	  const double one_jump_tabs_used_memory_process_partial_square = one_jump_tabs_used_memory_process_partial*one_jump_tabs_used_memory_process_partial;

	  const double one_jump_tabs_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
	  const double one_jump_tabs_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
      
	  const double one_jump_tabs_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial);
	  const double one_jump_tabs_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , one_jump_tabs_used_memory_process_partial_square);
	  
	  const double two_jumps_cv_tabs_used_memory_process_partial =
	    used_memory_calc (two_jumps_cv_p_pp_to_nn_tabs) + used_memory_calc (two_jumps_cv_p_nn_to_pp_tabs) +
	    used_memory_calc (two_jumps_cv_n_pp_to_nn_tabs) + used_memory_calc (two_jumps_cv_n_nn_to_pp_tabs);

	  const double two_jumps_cv_tabs_used_memory_process_partial_square = two_jumps_cv_tabs_used_memory_process_partial*two_jumps_cv_tabs_used_memory_process_partial;

	  const double two_jumps_cv_tabs_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
	  const double two_jumps_cv_tabs_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
      
	  const double two_jumps_cv_tabs_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial);
	  const double two_jumps_cv_tabs_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , two_jumps_cv_tabs_used_memory_process_partial_square);
	  
	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      const double one_jump_tabs_used_memory_process_average = one_jump_tabs_used_memory_process_sum/NUMBER_OF_PROCESSES;

	      const double one_jump_tabs_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , one_jump_tabs_used_memory_process_sum , one_jump_tabs_used_memory_process_squares_sum);
	  
	      cout << endl;
	      cout << "One jump pn tables memory min used by a process       : " << one_jump_tabs_used_memory_process_min     << " Mb" << endl;
	      cout << "One jump pn tables memory max used by a process       : " << one_jump_tabs_used_memory_process_max     << " Mb" << endl;
	      cout << "One jump pn tables memory average for all processes   : " << one_jump_tabs_used_memory_process_average << " Mb" << endl;
	      cout << "One jump pn tables memory dispersion for all processes: " << one_jump_tabs_used_memory_process_sigma   << " Mb" << endl;
	      cout << endl;

	      if (is_cv_non_zero)
		{
		  const double two_jumps_cv_tabs_used_memory_process_average = two_jumps_cv_tabs_used_memory_process_sum/NUMBER_OF_PROCESSES;

		  const double two_jumps_cv_tabs_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , two_jumps_cv_tabs_used_memory_process_sum , two_jumps_cv_tabs_used_memory_process_squares_sum);
	  
		  cout << endl;
		  cout << "Two jumps cv tables memory min used by a process       : " << two_jumps_cv_tabs_used_memory_process_min     << " Mb" << endl;
		  cout << "Two jumps cv tables memory max used by a process       : " << two_jumps_cv_tabs_used_memory_process_max     << " Mb" << endl;
		  cout << "Two jumps cv tables memory average for all processes   : " << two_jumps_cv_tabs_used_memory_process_average << " Mb" << endl;
		  cout << "Two jumps cv tables memory dispersion for all processes: " << two_jumps_cv_tabs_used_memory_process_sigma   << " Mb" << endl;
		  cout << endl;
		}
	    }
	}
    }

  rows_non_zero_NBMEs_one_jump_numbers.allocate (space_dimension_process);

  rows_non_zero_NBMEs_two_jumps_numbers.allocate (space_dimension_process);

  rows_non_zero_NBMEs_off_diagonal_numbers_calc ();
    
  if (non_zero_NBMEs_proportion_only) return;
  
  H_diagonal_tab.allocate (space_dimension_process);
  
  H_diagonal_tab = 0.0;

  if (is_it_Davidson) 
    {
      H_diagonal_averaged_tab.allocate (space_dimension_process);

      H_diagonal_averaged_tab = 0.0;
    }
  
  if (space == PROT_NEUT_Y)
    {
      if (is_one_body_p_non_zero || is_pp_non_zero) diagonal_part_p_part_pn_calc_store ();
      if (is_one_body_n_non_zero || is_nn_non_zero) diagonal_part_n_part_pn_calc_store ();
      
      if (is_pn_non_zero)
	{
	  if (is_it_Nval_larger)
	    {
	      diagonal_part_pn_part_pn_Nval_larger_calc_store ();
	      
	      if (is_it_Davidson) diagonal_part_averaged_pn_Nval_larger_calc_store ();
	    }
	  else
	    {
	      diagonal_part_pn_part_pn_Zval_larger_calc_store ();
	      
	      if (is_it_Davidson) diagonal_part_averaged_pn_Zval_larger_calc_store ();
	    }
	}
    }
  else
    {
      diagonal_part_pp_nn_calc_store ();
      
      if (is_it_Davidson) diagonal_part_averaged_pp_nn_calc_store ();
    }
  
  if (is_it_full_or_partial_storage)
    {	
      if (Hamiltonian_storage == PARTIAL_STORAGE)
	{
	  if (space == PROT_NEUT_Y)
	    {
	      M_TBMEs_pn_alloc_calc ();

	      M_TBMEs_pn_cv_indices_alloc_calc (is_it_Nval_larger);
	    }      
	  else      
	    M_TBMEs_pp_nn_alloc_calc ();
	}
      
      rows_non_zero_NBMEs_one_jump_PSI_in_indices.allocate (space_dimension_process);

      rows_non_zero_NBMEs_one_jump.allocate (space_dimension_process);

      rows_non_zero_NBMEs_two_jumps_PSI_in_indices.allocate (space_dimension_process);
  
      if (Hamiltonian_storage == PARTIAL_STORAGE) rows_non_zero_NBMEs_two_jumps_indices.allocate (space_dimension_process);
      if (Hamiltonian_storage == FULL_STORAGE)    rows_non_zero_NBMEs_two_jumps.allocate         (space_dimension_process);
      
      rows_non_zero_NBMEs_one_jump_PSI_in_indices = NULL;
      rows_non_zero_NBMEs_one_jump                = NULL;

      rows_non_zero_NBMEs_two_jumps_PSI_in_indices = NULL;
      rows_non_zero_NBMEs_two_jumps_indices        = NULL;
      rows_non_zero_NBMEs_two_jumps                = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_one_jump_number  = rows_non_zero_NBMEs_one_jump_numbers(i);
	  const unsigned int row_non_zero_NBMEs_two_jumps_number = rows_non_zero_NBMEs_two_jumps_numbers(i);
	  
	  if (row_non_zero_NBMEs_one_jump_number > 0)
	    {
	      rows_non_zero_NBMEs_one_jump_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_one_jump_number];	      
	      rows_non_zero_NBMEs_one_jump(i)                = new TYPE         [row_non_zero_NBMEs_one_jump_number];
	      
	      space_dimension_process_non_zeros_one_jump++;
	    }
	  
	  if (row_non_zero_NBMEs_two_jumps_number > 0)
	    {
	      rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_two_jumps_number];

	      if (Hamiltonian_storage == PARTIAL_STORAGE) rows_non_zero_NBMEs_two_jumps_indices(i) = new unsigned int [row_non_zero_NBMEs_two_jumps_number];
	      if (Hamiltonian_storage == FULL_STORAGE)    rows_non_zero_NBMEs_two_jumps(i)         = new TYPE         [row_non_zero_NBMEs_two_jumps_number];

	      space_dimension_process_non_zeros_two_jumps++;
	    }
	}
      
      PSI_out_indices_shifted_non_zeros_one_jump.allocate  (space_dimension_process_non_zeros_one_jump);
      PSI_out_indices_shifted_non_zeros_two_jumps.allocate (space_dimension_process_non_zeros_two_jumps);

      space_dimension_process_non_zeros_one_jump = 0;
      space_dimension_process_non_zeros_two_jumps = 0;

      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_one_jump_number  = rows_non_zero_NBMEs_one_jump_numbers(i);
	  const unsigned int row_non_zero_NBMEs_two_jumps_number = rows_non_zero_NBMEs_two_jumps_numbers(i);
	  
	  if (row_non_zero_NBMEs_one_jump_number  > 0) PSI_out_indices_shifted_non_zeros_one_jump (space_dimension_process_non_zeros_one_jump++)  = i;
	  if (row_non_zero_NBMEs_two_jumps_number > 0) PSI_out_indices_shifted_non_zeros_two_jumps(space_dimension_process_non_zeros_two_jumps++) = i;
	}
        
      matrix_off_diagonal_store ();
      
      one_jump_p_tabs.deallocate ();
      one_jump_n_tabs.deallocate ();
      
      two_jumps_cv_p_pp_to_nn_tabs.deallocate ();
      two_jumps_cv_p_nn_to_pp_tabs.deallocate ();
      two_jumps_cv_n_pp_to_nn_tabs.deallocate ();
      two_jumps_cv_n_nn_to_pp_tabs.deallocate ();

      M_TBMEs_pn_indices.deallocate ();
      
      M_TBMEs_cv_pp_to_nn_indices.deallocate ();
      M_TBMEs_cv_nn_to_pp_indices.deallocate ();
    }

  if ((Hamiltonian_storage == ON_THE_FLY) && (M_TBMEs_storage != ON_THE_FLY))
    {
      if (space == PROT_NEUT_Y)
	{
	  M_TBMEs_pn_alloc_calc ();

	  M_TBMEs_pn_cv_indices_alloc_calc (is_it_Nval_larger);
	}      
      else      
	M_TBMEs_pp_nn_alloc_calc ();
    }
  
  if (is_there_cout)
    {
      const double H_used_memory_process_partial = used_memory_calc (*this);

      const double H_used_memory_process_partial_square = H_used_memory_process_partial*H_used_memory_process_partial;

      const double H_used_memory_process_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      const double H_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      
      const double H_used_memory_process_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial);
      const double H_used_memory_process_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_used_memory_process_partial_square);
      	  
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const double H_used_memory_process_average = H_used_memory_process_sum/NUMBER_OF_PROCESSES;

	  const double H_used_memory_process_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_used_memory_process_sum , H_used_memory_process_squares_sum);
	  
	  cout << endl;
	  cout << "H memory min used by a process       : " << H_used_memory_process_min     << " Mb" << endl;
	  cout << "H memory max used by a process       : " << H_used_memory_process_max     << " Mb" << endl;
	  cout << "H memory average for all processes   : " << H_used_memory_process_average << " Mb" << endl;
	  cout << "H memory dispersion for all processes: " << H_used_memory_process_sigma   << " Mb" << endl;
	  cout << endl;
	}
    }
}








void H_class::allocate_fill (const class H_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("H_class cannot be allocated twice in H_class::allocate_fill");

  is_there_cout = X.is_there_cout;
  
  is_there_cout_detailed = X.is_there_cout_detailed;

  Hamiltonian_storage = X.Hamiltonian_storage;

  M_TBMEs_storage = X.M_TBMEs_storage;
  
  one_jumps_pn_two_jumps_cv_storage = X.one_jumps_pn_two_jumps_cv_storage;
  
  is_it_Davidson = X.is_it_Davidson;
  
  is_one_body_p_non_zero = X.is_one_body_p_non_zero;
  is_one_body_n_non_zero = X.is_one_body_n_non_zero;
 
  is_pp_non_zero = X.is_pp_non_zero;
  is_nn_non_zero = X.is_nn_non_zero;
  is_pn_non_zero = X.is_pn_non_zero;
  is_cv_non_zero = X.is_cv_non_zero;
  
  J = X.J;
  
  GSM_vector_helper_ptr = X.GSM_vector_helper_ptr;

  TBMEs_pn_ptr = X.TBMEs_pn_ptr; 
  TBMEs_cv_ptr = X.TBMEs_cv_ptr; 
  
  H_PSI_table_ptr = X.H_PSI_table_ptr;
  
  space_dimension_process_non_zeros_one_jump = X.space_dimension_process_non_zeros_one_jump;
  space_dimension_process_non_zeros_two_jumps = X.space_dimension_process_non_zeros_two_jumps;
  
  rows_non_zero_NBMEs_one_jump_numbers.allocate_fill (X.rows_non_zero_NBMEs_one_jump_numbers);
  rows_non_zero_NBMEs_two_jumps_numbers.allocate_fill (X.rows_non_zero_NBMEs_two_jumps_numbers);

  M_TBMEs.allocate_fill (X.M_TBMEs);
  
  M_TBMEs_pn_indices.allocate_fill (X.M_TBMEs_pn_indices);
      
  M_TBMEs_cv_pp_to_nn_indices.allocate_fill (X.M_TBMEs_cv_pp_to_nn_indices);
  M_TBMEs_cv_nn_to_pp_indices.allocate_fill (X.M_TBMEs_cv_nn_to_pp_indices);
  
  H_diagonal_tab.allocate_fill (X.H_diagonal_tab);

  H_diagonal_averaged_tab.allocate_fill (X.H_diagonal_averaged_tab);

  PSI_out_indices_shifted_non_zeros_one_jump.allocate_fill (X.PSI_out_indices_shifted_non_zeros_one_jump);
  
  PSI_out_indices_shifted_non_zeros_two_jumps.allocate_fill (X.PSI_out_indices_shifted_non_zeros_two_jumps);
      
  if (X.rows_non_zero_NBMEs_one_jump_PSI_in_indices.is_it_filled ())
    {	
      const unsigned int space_dimension_process = X.rows_non_zero_NBMEs_one_jump_PSI_in_indices.dimension (0);
  
      rows_non_zero_NBMEs_one_jump_PSI_in_indices.allocate (space_dimension_process);
      
      rows_non_zero_NBMEs_one_jump.allocate (space_dimension_process);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_one_jump_number = X.rows_non_zero_NBMEs_one_jump_numbers(i);

	  if (row_non_zero_NBMEs_one_jump_number > 0)
	    {	  
	      rows_non_zero_NBMEs_one_jump_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_one_jump_number];
	      
	      const unsigned int *const X_rows_non_zero_NBMEs_one_jump_PSI_in_indices_i = X.rows_non_zero_NBMEs_one_jump_PSI_in_indices(i);
	      
	      unsigned int *const rows_non_zero_NBMEs_one_jump_PSI_in_indices_i = rows_non_zero_NBMEs_one_jump_PSI_in_indices(i);
	  
	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_one_jump_number ; ii++) rows_non_zero_NBMEs_one_jump_PSI_in_indices_i[ii] = X_rows_non_zero_NBMEs_one_jump_PSI_in_indices_i[ii];
	    }
	}
    }
  
  if (X.rows_non_zero_NBMEs_one_jump.is_it_filled ())
    {	
      const unsigned int space_dimension_process = X.rows_non_zero_NBMEs_one_jump.dimension (0);
	  
      rows_non_zero_NBMEs_one_jump.allocate (space_dimension_process);
	  
      rows_non_zero_NBMEs_one_jump = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_one_jump_number = X.rows_non_zero_NBMEs_one_jump_numbers(i);
	      
	  if (row_non_zero_NBMEs_one_jump_number > 0)
	    {
	      rows_non_zero_NBMEs_one_jump(i) = new TYPE [row_non_zero_NBMEs_one_jump_number];
	      
	      const TYPE *const X_rows_non_zero_NBMEs_one_jump_i = X.rows_non_zero_NBMEs_one_jump(i);
	      
	      TYPE *const rows_non_zero_NBMEs_one_jump_i = rows_non_zero_NBMEs_one_jump(i);
	  
	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_one_jump_number ; ii++) rows_non_zero_NBMEs_one_jump_i[ii] = X_rows_non_zero_NBMEs_one_jump_i[ii];
	    }
	}
    }
  
  if (X.rows_non_zero_NBMEs_two_jumps_PSI_in_indices.is_it_filled ())
    {	
      const unsigned int space_dimension_process = X.rows_non_zero_NBMEs_two_jumps_PSI_in_indices.dimension (0);
	  
      rows_non_zero_NBMEs_two_jumps_PSI_in_indices.allocate (space_dimension_process);
	  
      rows_non_zero_NBMEs_two_jumps_PSI_in_indices = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_two_jumps_number = X.rows_non_zero_NBMEs_two_jumps_numbers(i);
	  
	  if (row_non_zero_NBMEs_two_jumps_number > 0)
	    {
	      rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_two_jumps_number];

	      const unsigned int *const X_rows_non_zero_NBMEs_two_jumps_PSI_in_indices_i = X.rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i);

	      unsigned int *const rows_non_zero_NBMEs_two_jumps_PSI_in_indices_i = rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i);
		  
	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_two_jumps_number ; ii++) rows_non_zero_NBMEs_two_jumps_PSI_in_indices_i[ii] = X_rows_non_zero_NBMEs_two_jumps_PSI_in_indices_i[ii];
	    }
	}
    }
  
  if (X.rows_non_zero_NBMEs_two_jumps_indices.is_it_filled ())
    {	
      const unsigned int space_dimension_process = X.rows_non_zero_NBMEs_two_jumps_indices.dimension (0);
	      
      rows_non_zero_NBMEs_two_jumps_indices.allocate (space_dimension_process);
	  
      rows_non_zero_NBMEs_two_jumps_indices = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_two_jumps_number = X.rows_non_zero_NBMEs_two_jumps_numbers(i);
	      
	  if (row_non_zero_NBMEs_two_jumps_number > 0)
	    {
	      rows_non_zero_NBMEs_two_jumps_indices(i) = new unsigned int [row_non_zero_NBMEs_two_jumps_number];

	      const unsigned int *const X_rows_non_zero_NBMEs_two_jumps_indices_i = X.rows_non_zero_NBMEs_two_jumps_indices(i);

	      unsigned int *const rows_non_zero_NBMEs_two_jumps_indices_i = rows_non_zero_NBMEs_two_jumps_indices(i);
	  
	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_two_jumps_number ; ii++) rows_non_zero_NBMEs_two_jumps_indices_i[ii] = X_rows_non_zero_NBMEs_two_jumps_indices_i[ii];
	    }
	}
    }
      
  if (X.rows_non_zero_NBMEs_two_jumps.is_it_filled ())
    {	
      const unsigned int space_dimension_process = X.rows_non_zero_NBMEs_two_jumps.dimension (0);
	    
      rows_non_zero_NBMEs_two_jumps.allocate (space_dimension_process);
	  
      rows_non_zero_NBMEs_two_jumps = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_two_jumps_number = X.rows_non_zero_NBMEs_two_jumps_numbers(i);
	      
	  if (row_non_zero_NBMEs_two_jumps_number > 0)
	    {
	      rows_non_zero_NBMEs_two_jumps(i) = new TYPE [row_non_zero_NBMEs_two_jumps_number];

	      const TYPE *const X_rows_non_zero_NBMEs_two_jumps_i = X.rows_non_zero_NBMEs_two_jumps(i);

	      TYPE *const rows_non_zero_NBMEs_two_jumps_i = rows_non_zero_NBMEs_two_jumps(i);
	  
	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_two_jumps_number ; ii++) rows_non_zero_NBMEs_two_jumps_i[ii] = X_rows_non_zero_NBMEs_two_jumps_i[ii];
	    }
	}
    }

  one_jump_p_tabs.allocate_fill (X.one_jump_p_tabs);
  one_jump_n_tabs.allocate_fill (X.one_jump_n_tabs);  
 
  two_jumps_cv_p_pp_to_nn_tabs.allocate_fill (X.two_jumps_cv_p_pp_to_nn_tabs);
  two_jumps_cv_p_nn_to_pp_tabs.allocate_fill (X.two_jumps_cv_p_nn_to_pp_tabs);
  two_jumps_cv_n_pp_to_nn_tabs.allocate_fill (X.two_jumps_cv_n_pp_to_nn_tabs);
  two_jumps_cv_n_nn_to_pp_tabs.allocate_fill (X.two_jumps_cv_n_nn_to_pp_tabs);
}



void H_class::deallocate ()
{
  if (rows_non_zero_NBMEs_one_jump_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_one_jump_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_one_jump_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs_one_jump.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_one_jump.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_one_jump(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps_indices(i);
    }
      
  if (rows_non_zero_NBMEs_two_jumps.is_it_filled ())
    {
      const unsigned int space_dimension_process = rows_non_zero_NBMEs_two_jumps.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) delete [] rows_non_zero_NBMEs_two_jumps(i);
    }

  M_TBMEs.deallocate ();

  M_TBMEs_pn_indices.deallocate ();
      
  M_TBMEs_cv_pp_to_nn_indices.deallocate ();
  M_TBMEs_cv_nn_to_pp_indices.deallocate ();
	  
  H_diagonal_tab.deallocate ();

  H_diagonal_averaged_tab.deallocate ();

  rows_non_zero_NBMEs_one_jump_PSI_in_indices.deallocate ();
  rows_non_zero_NBMEs_one_jump.deallocate ();
  
  rows_non_zero_NBMEs_two_jumps_PSI_in_indices.deallocate ();
  rows_non_zero_NBMEs_two_jumps_indices.deallocate ();
  rows_non_zero_NBMEs_two_jumps.deallocate ();

  rows_non_zero_NBMEs_one_jump_numbers.deallocate ();
  rows_non_zero_NBMEs_two_jumps_numbers.deallocate ();

  one_jump_p_tabs.deallocate ();
  one_jump_n_tabs.deallocate ();
  
  two_jumps_cv_p_pp_to_nn_tabs.deallocate ();
  two_jumps_cv_p_nn_to_pp_tabs.deallocate ();
  two_jumps_cv_n_pp_to_nn_tabs.deallocate ();
  two_jumps_cv_n_nn_to_pp_tabs.deallocate ();
      
  PSI_out_indices_shifted_non_zeros_one_jump.deallocate ();
  PSI_out_indices_shifted_non_zeros_two_jumps.deallocate ();

  is_there_cout = false; 

  is_there_cout_detailed = false; 

  Hamiltonian_storage = NO_STORAGE;

  M_TBMEs_storage = NO_STORAGE;
  
  one_jumps_pn_two_jumps_cv_storage = NO_STORAGE;
  
  is_it_Davidson = false;  

  is_one_body_p_non_zero = false; 
  is_one_body_n_non_zero = false;

  is_pp_non_zero = false; 
  is_nn_non_zero = false; 
  is_pn_non_zero = false;
  is_cv_non_zero = false;

  J = 0.0;

  GSM_vector_helper_ptr = NULL; 

  TBMEs_pn_ptr = NULL;
  TBMEs_cv_ptr = NULL;

  H_PSI_table_ptr = NULL;
  
  space_dimension_process_non_zeros_one_jump  = 0; 
  space_dimension_process_non_zeros_two_jumps = 0; 
}



// Calculation of arrays of arrays of 1p-1h jumps data for protons and neutrons (plus a few hyperons if any) for the 2p-2h pn part of H (pn only)
// ----------------------------------------------------------------------------------------------------------------------------------------------
// They are functions of full outSDp/outSDn basis state indices,
// and of the binary parity BPp_in or BPn_in, strangeness and number of spectators (see observables_basic_functions.cpp and enum_struct_definitions.h for definition), 
// and M projection difference index iMp_in - iMp_out + 2.mp_max or iMn_in - iMn_out + 2.mn_max (see GSM_vector_dimensions.cpp for definition)
// of the inSDp/inSDn basis state. They contain data related to the application of a+(alpha) a(beta) to inSDp/inSDn to obtain outSDp/outSDn,
// for the pn H part of the form \sum a+(alpha[p]) a+(alpha[n]) a(beta[p]) a(beta[n]) <alpha[p] alpha[n] | V | beta[p] beta[n]>. 
// They are stored if one_jumps_pn_two_jumps_cv_storage is not on the fly, as then one gains time as otherwise they are recalculated on the fly.
// 
// For this, one loops over all outSDp/outSDn basis states, and one generates all possible 1p-1h excitations from them.
// Associated 1p-1h jumps data are then stored in arrays.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.

void H_class::one_jump_p_tab_all_SDp_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) is_one_jump_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BP , BPp_out);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();
      
      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();	

      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
      
      const int n_spec_p_in = n_spec_p_out;
      
      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;
      
      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(total_outSDp_index_shifted);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);
      
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
		     			  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
			      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				{
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;	    
			
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
	
				  bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				  if (!is_one_jump_p_calculated)
				    {
				      class jumps_data_str &one_jump_p = one_jump_p_tab(BPp_in , Sp_in , Delta_iMp_in);
      
				      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);

				      is_one_jump_p_calculated = true; 
				    }}}}}}}}
}

void H_class::one_jump_n_tab_all_SDn_calc ()
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();
    
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mn_max = neut_Y_data.get_four_m_max ();
          		  		  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mn_max_minus_mn_min = neut_Y_data.get_m_max_minus_m_min ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) is_one_jump_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BP , BPn_out);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
				 
      const int n_spec_n_out = outSDn_qn.get_n_spec ();
      
      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();	

      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
      
      const int n_spec_n_in = n_spec_n_out;
      
      const int iMp_out = iM - iMn_out;

      const int iMn_in_min_M = max (iMn_min_M , iMn_out - mn_max_minus_mn_min);
      const int iMn_in_max_M = min (iMn_max_M , iMn_out + mn_max_minus_mn_min);

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(total_outSDn_index_shifted);
      			  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
            
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);
      
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
			    for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
			      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
				{
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;	    
			
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
	
				  bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				  if (!is_one_jump_n_calculated)
				    {
				      class jumps_data_str &one_jump_n = one_jump_n_tab(BPn_in , Sn_in , Delta_iMn_in);
      
				      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

				      is_one_jump_n_calculated = true;
				    }}}}}}}}
}







// Calculation of arrays of arrays of 2p-2h jumps data for protons and neutrons (plus a few hyperons if any) for the 2p-2h pp <-> nn conversion part of H
// ------------------------------------------------------------------------------------------------------------------------------------------------------
// They are functions of full outSDp/outSDn basis state indices,
// and of the binary parity BPp_in or BPn_in, strangeness and number of spectators (see observables_basic_functions.cpp and enum_struct_definitions.h for definition), 
// and M projection difference index iMp_in - iMp_out + 2.mp_max or iMn_in - iMn_out + 2.mn_max (see GSM_vector_dimensions.cpp for definition)
// of the inSDp/inSDn basis state. They contain data related to the application of a+(alpha) a+(beta) a(alpha_spec) a(beta_spec) to inSDp/inSDn to obtain outSDp/outSDn,
// and to the application of a+(alpha_spec) a+(beta_spec) a(alpha) a(beta) to inSDp/inSDn to obtain outSDp/outSDn,
// for the cv H part of the form \sum a+(alpha_p) a+(beta_p) a(alpha_n) a(beta_n) <alpha_p beta_p | V | alpha_n beta_n> (nn to pp)
// and \sum a+(alpha_n) a+(beta_n) a(alpha_p) a(beta_p) <alpha_n beta_n | V | alpha_p beta_p> (pp to nn).
// They are stored if one_jumps_pn_two_jumps_cv_storage is not on the fly, as then one gains time as otherwise they are recalculated on the fly.
// 
// For this, one loops over all outSDp/outSDn basis states, and one generates all possible 2p-2h excitations from them.
// Associated 2p-2h jumps data are then stored in arrays.
//
// OpenMP parallelization is used on the loop of proton or neutron Slater determinants.
// MPI parallelization here is implicit, as on considers only the Slater determinants of the current node.

void H_class::two_jumps_cv_p_tab_all_SDp_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const int n_holes_max = GSM_vector_helper.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP ();
  
  const int S = GSM_vector_helper.get_S ();
  
  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();
    
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper.get_all_dimensions_SDn_zero_tab ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();

  const int four_mp_max = prot_Y_data.get_four_m_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
 
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper.get_iCn_max_tab ();
    
  const unsigned long int total_outSDp_index_min = GSM_vector_helper.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<bool> > are_two_jumps_cv_p_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) are_two_jumps_cv_p_calculated_tabs(i).allocate (2 , S_plus_one , four_mp_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BP , BPp_out);

      const int Sp_out = outSDp_qn.get_S ();
      
      const int Sn_out = S - Sp_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();
      
      const int n_spec_n_out = n_spec_max - n_spec_p_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();	

      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;
      
      const int n_spec_p_in = (is_it_cv_pp_to_nn) ? (n_spec_p_out - 2) : (n_spec_p_out + 2);
      
      const int iMn_out = iM - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned long int total_outSDp_index_shifted = total_outSDp_index - total_outSDp_index_min;

      class array<class jumps_data_str> &two_jumps_cv_p_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_p_pp_to_nn_tabs(total_outSDp_index_shifted)) : (two_jumps_cv_p_nn_to_pp_tabs(total_outSDp_index_shifted));
            
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class array<bool> &are_two_jumps_cv_p_calculated_tab = are_two_jumps_cv_p_calculated_tabs(i_thread);
      
      are_two_jumps_cv_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
		     			  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
			    for (int Sp_in = 0 ; Sp_in <= S ; Sp_in++)
			      for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				{
				  const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;	    
			
				  if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
	
				  bool &are_two_jumps_cv_p_calculated = are_two_jumps_cv_p_calculated_tab(BPp_in , Sp_in , Delta_iMp_in);

				  if (!are_two_jumps_cv_p_calculated)
				    {
				      class jumps_data_str &two_jumps_cv_p = two_jumps_cv_p_tab(BPp_in , Sp_in , Delta_iMp_in);
				      
				      two_jumps_cv_p.two_jumps_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p ,  Ep_max_hw ,
									 BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , !is_it_cv_pp_to_nn , is_it_cv_pp_to_nn , prot_Y_data);
				      
				      are_two_jumps_cv_p_calculated = true;
				    }}}}}}}}
}

void H_class::two_jumps_cv_n_tab_all_SDn_calc (const bool is_it_cv_pp_to_nn)
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int n_holes_max = GSM_vector_helper.get_n_holes_max (); 

  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();

  const int n_scat_max = GSM_vector_helper.get_n_scat_max (); 

  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper.get_BP (); 

  const int S = GSM_vector_helper.get_S ();

  const int S_plus_one = S + 1;
  
  const int n_spec_max = GSM_vector_helper.get_n_spec_max ();
  
  const int iM = GSM_vector_helper.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper.get_iMn_max_M (); 
        
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper.get_sum_dimensions_GSM_vector ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper.get_all_dimensions_SDp_zero_tab ();
    
  const int two_mn_max = neut_Y_data.get_two_m_max ();

  const int four_mn_max = neut_Y_data.get_four_m_max ();
          		  		  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const int mn_max_minus_mn_min = neut_Y_data.get_m_max_minus_m_min ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
    
  const unsigned int first_PSI_out_index = GSM_vector_helper.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper.get_last_PSI_index ();
    
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper.get_iCp_max_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
  
  class array<class array<bool> > are_two_jumps_cv_n_calculated_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) are_two_jumps_cv_n_calculated_tabs(i).allocate (2 , S_plus_one , four_mn_max_plus_one);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();
      
      const unsigned int BPp_out = binary_parity_product (BP , BPn_out);

      const int Sn_out = outSDn_qn.get_S ();
      
      const int Sp_out = S - Sn_out;
				 
      const int n_spec_n_out = outSDn_qn.get_n_spec ();
      
      const int n_spec_p_out = n_spec_max - n_spec_n_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();	

      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
      
      const int n_spec_n_in = (is_it_cv_pp_to_nn) ? (n_spec_n_out + 2) : (n_spec_n_out - 2);
      
      const int iMp_out = iM - iMn_out;

      const int iMn_in_min_M = max (iMn_min_M , iMn_out - mn_max_minus_mn_min);
      const int iMn_in_max_M = min (iMn_max_M , iMn_out + mn_max_minus_mn_min);

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const unsigned long int total_outSDn_index_shifted = total_outSDn_index - total_outSDn_index_min;

      class array<class jumps_data_str> &two_jumps_cv_n_tab = (is_it_cv_pp_to_nn) ? (two_jumps_cv_n_pp_to_nn_tabs(total_outSDn_index_shifted)) : (two_jumps_cv_n_nn_to_pp_tabs(total_outSDn_index_shifted)); 
      			  
      const unsigned int i_thread = OpenMP_thread_number_determine ();           

      class array<bool> &are_two_jumps_cv_n_calculated_tab = are_two_jumps_cv_n_calculated_tabs(i_thread);
      
      are_two_jumps_cv_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
			    for (int Sn_in = 0 ; Sn_in <= S ; Sn_in++)
			      for (int iMn_in = iMn_in_min_M ; iMn_in <= iMn_in_max_M ; iMn_in++)
				{
				  const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;	    
			
				  if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;
	
				  bool &are_two_jumps_cv_n_calculated = are_two_jumps_cv_n_calculated_tab(BPn_in , Sn_in , Delta_iMn_in);

				  if (!are_two_jumps_cv_n_calculated)
				    {
				      class jumps_data_str &two_jumps_cv_n = two_jumps_cv_n_tab(BPn_in , Sn_in , Delta_iMn_in);
				      
				      two_jumps_cv_n.two_jumps_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw ,
									 BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , is_it_cv_pp_to_nn , !is_it_cv_pp_to_nn , neut_Y_data);
				      
				      are_two_jumps_cv_n_calculated = true;
				    }}}}}}}}
}









double used_memory_calc (const class H_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  double used_memory_allocated_arrays = used_memory_calc (T.H_diagonal_tab) +
    used_memory_calc (T.H_diagonal_averaged_tab) +
    used_memory_calc (T.rows_non_zero_NBMEs_one_jump_numbers) +
    used_memory_calc (T.rows_non_zero_NBMEs_two_jumps_numbers) +
    used_memory_calc (T.PSI_out_indices_shifted_non_zeros_one_jump) +
    used_memory_calc (T.PSI_out_indices_shifted_non_zeros_two_jumps) +
    used_memory_calc (T.rows_non_zero_NBMEs_one_jump_PSI_in_indices) +
    used_memory_calc (T.rows_non_zero_NBMEs_two_jumps_PSI_in_indices) +
    used_memory_calc (T.rows_non_zero_NBMEs_one_jump) +
    used_memory_calc (T.rows_non_zero_NBMEs_two_jumps_indices) +
    used_memory_calc (T.one_jump_p_tabs) +
    used_memory_calc (T.one_jump_n_tabs) +
    used_memory_calc (T.two_jumps_cv_p_pp_to_nn_tabs) +
    used_memory_calc (T.two_jumps_cv_p_nn_to_pp_tabs) +
    used_memory_calc (T.two_jumps_cv_n_pp_to_nn_tabs) +
    used_memory_calc (T.two_jumps_cv_n_nn_to_pp_tabs) +
    used_memory_calc (T.M_TBMEs) +
    used_memory_calc (T.M_TBMEs_pn_indices) +
    used_memory_calc (T.M_TBMEs_cv_pp_to_nn_indices) +
    used_memory_calc (T.M_TBMEs_cv_nn_to_pp_indices)
    - (sizeof (T.H_diagonal_tab) +
       sizeof (T.H_diagonal_averaged_tab) +
       sizeof (T.rows_non_zero_NBMEs_one_jump_numbers) +
       sizeof (T.rows_non_zero_NBMEs_two_jumps_numbers) +
       sizeof (T.PSI_out_indices_shifted_non_zeros_one_jump) +
       sizeof (T.PSI_out_indices_shifted_non_zeros_two_jumps) +
       sizeof (T.rows_non_zero_NBMEs_one_jump_PSI_in_indices) +
       sizeof (T.rows_non_zero_NBMEs_two_jumps_PSI_in_indices) +
       sizeof (T.rows_non_zero_NBMEs_one_jump) +
       sizeof (T.rows_non_zero_NBMEs_two_jumps_indices) +
       sizeof (T.one_jump_p_tabs) +
       sizeof (T.one_jump_n_tabs) +
       sizeof (T.two_jumps_cv_p_pp_to_nn_tabs) +
       sizeof (T.two_jumps_cv_p_nn_to_pp_tabs) +
       sizeof (T.two_jumps_cv_n_pp_to_nn_tabs) +
       sizeof (T.two_jumps_cv_n_nn_to_pp_tabs) +
       sizeof (T.M_TBMEs) +
       sizeof (T.M_TBMEs_pn_indices) +
       sizeof (T.M_TBMEs_cv_pp_to_nn_indices) +
       sizeof (T.M_TBMEs_cv_nn_to_pp_indices))/1000000.0;

  if (T.rows_non_zero_NBMEs_one_jump_numbers.is_it_filled () && T.rows_non_zero_NBMEs_two_jumps_numbers.is_it_filled ())
    {
      const class GSM_vector_helper_class &GSM_vector_helper = T.get_GSM_vector_helper ();
  
      const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();
      
      const double unsigned_int_memory = sizeof (unsigned int)/1000000.0;

      const double TYPE_memory = sizeof (TYPE)/1000000.0;
        
      const double unsigned_int_TYPE_memory = unsigned_int_memory + TYPE_memory;
      
      for (unsigned int i = 0 ; i < space_dimension_process ; i++) 
	{
	  const unsigned int rows_non_zero_NBMEs_one_jump_number  = T.rows_non_zero_NBMEs_one_jump_numbers(i);
	  const unsigned int rows_non_zero_NBMEs_two_jumps_number = T.rows_non_zero_NBMEs_two_jumps_numbers(i);
	
	  used_memory_allocated_arrays += rows_non_zero_NBMEs_one_jump_number*unsigned_int_TYPE_memory;
	  
	  used_memory_allocated_arrays += rows_non_zero_NBMEs_two_jumps_number*unsigned_int_memory;	      

	  if (T.Hamiltonian_storage == PARTIAL_STORAGE) used_memory_allocated_arrays += rows_non_zero_NBMEs_two_jumps_number*unsigned_int_memory;	  
	  if (T.Hamiltonian_storage == FULL_STORAGE)    used_memory_allocated_arrays += rows_non_zero_NBMEs_two_jumps_number*TYPE_memory;
	}
    }
     
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;
  
  return used_memory;
}






void H_class::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Only serial processes allowed for the use of print of H_class.");
  
  if (Hamiltonian_storage != FULL_STORAGE) error_message_print_abort ("Full storage option must be used in print of H_class.");

  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
    
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
	  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();

  const class Slater_determinant dummy_SD;

  const class GSM_vector V(GSM_vector_helper);

  class Slater_determinant inSDp(ZYval);
  class Slater_determinant inSDn(NYval);
  
  class Slater_determinant outSDp(ZYval);
  class Slater_determinant outSDn(NYval);
  
  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension ; PSI_out_index++)
    {
      outSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int row_non_zero_NBMEs_one_jump_number  = rows_non_zero_NBMEs_one_jump_numbers(PSI_out_index);
      const unsigned int row_non_zero_NBMEs_two_jumps_number = rows_non_zero_NBMEs_two_jumps_numbers(PSI_out_index);
      
      const unsigned int *const row_non_zero_NBMEs_one_jump_PSI_in_indices  = rows_non_zero_NBMEs_one_jump_PSI_in_indices(PSI_out_index);
      const unsigned int *const row_non_zero_NBMEs_two_jumps_PSI_in_indices = rows_non_zero_NBMEs_two_jumps_PSI_in_indices(PSI_out_index);
      
      const TYPE *const row_non_zero_NBMEs_one_jump  = rows_non_zero_NBMEs_one_jump(PSI_out_index);
      const TYPE *const row_non_zero_NBMEs_two_jumps = rows_non_zero_NBMEs_two_jumps(PSI_out_index);

      switch (space)
	{
	case PROT_Y_ONLY: 
	  {
	    cout << "inSD: "  , outSDp.print (phi_p_table);
	    cout << "outSD: " , outSDp.print (phi_p_table);
	  } break;

	case NEUT_Y_ONLY:
	  {
	    cout << "inSD: "  , outSDn.print (phi_n_table);
	    cout << "outSD: " , outSDn.print (phi_n_table);
	  } break;

	case PROT_NEUT_Y:
	  {
	    if (S == 0)
	      {
		cout << "inSDp: "  , outSDp.print (phi_p_table);
		cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		cout << "outSDp: " , outSDp.print (phi_p_table);
		cout << "outSDn: " , outSDn.print (phi_n_table);
	      }
	    else
	      {
		cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
	      }
	  } break;

	default: abort_all ();
	}

      cout << "inSD index: " << PSI_out_index << " outSD index: " << PSI_out_index << " NBME: " << H_diagonal_tab(PSI_out_index) << endl << endl;

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_one_jump_number ; i++) 
	{
	  const unsigned int PSI_in_index = row_non_zero_NBMEs_one_jump_PSI_in_indices[i];
	  
	  const TYPE NBME = row_non_zero_NBMEs_one_jump[i];	

	  inSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "inSD: "  , inSDp.print (phi_p_table);

		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "inSD: "  , inSDn.print (phi_n_table);

		cout << "outSD: " , outSDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		if (S == 0)
		  {
		    cout << "inSDp: "  , outSDp.print (phi_p_table);
		    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  }
		else
		  {
		    cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		    cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		    cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
		  }
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}
      
      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_two_jumps_number ; i++) 
	{
	  const unsigned int PSI_in_index = row_non_zero_NBMEs_two_jumps_PSI_in_indices[i];

	  const TYPE &NBME = row_non_zero_NBMEs_two_jumps[i];

	  inSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);	

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "inSD: "  , inSDp.print (phi_p_table);

		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "inSD: "  , inSDn.print (phi_n_table);

		cout << "outSD: " , outSDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		if (S == 0)
		  {
		    cout << "inSDp: "  , outSDp.print (phi_p_table);
		    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  }
		else
		  {
		    cout << "inSD[  charged baryons]: "  , outSDp.print (phi_p_table);
		    cout << "inSD[uncharged baryons]: "  , outSDn.print (phi_n_table);
	    
		    cout << "outSD[  charged baryons]: " , outSDp.print (phi_p_table);
		    cout << "outSD[uncharged baryons]: " , outSDn.print (phi_n_table);
		  }
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}
    }
}


// Calculation and storage of the 1p-1h NBMEs involving an outSD basis state of proton or neutron type from TBMEs and reordering phases
// ------------------------------------------------------------------------------------------------------------------------------------
// This is for p -> p', n -> n' only.
// This provides with non-zero off-diagonal NBMEs for 1p-1h jumps from a proton/neutron out Slater determinant to an in proton/neutron Slater determinant.
// Jumps have already been calculated at this level, so that one calculates the NBME without reordering phase, 
// which is multiplied afterwards by the reordering phase, calculated along with jumps data and stored in jumps data arrays.
// Even though it is the on the fly method, the NBMEs for a fixed proton/neutron out Slater determinant are stored, as storage memory is negligible.
// Indeed, when one runs over neutrons SDs for a fixed proton SD (or over protons SDs for a fixed neutron SD), the same NBME can be reused several times.

void H_class::NBMEs_one_jump_pp_nn_calc_store (
					       const unsigned int BPmu , 
					       const int Smu , 
					       const int n_spec_mu , 
					       const int iMmu , 
					       const int n_scat_mu_out , 
					       const unsigned int iCmu_out , 
					       const unsigned int outSDmu_index , 
					       const class Slater_determinant &outSDmu ,
					       const class baryons_data &data , 
					       bool &is_there_one_jump_calc ,
					       class jumps_data_str &one_jump_mu ,
					       class array<TYPE> &NBMEs_one_jump_mu) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();
 
  const enum interaction_type inter = GSM_vector_helper.get_inter ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw ();

  const bool is_it_charged = (nucleonic_particle_mu == PROTON);

  const bool is_one_body_mu_non_zero = (is_it_charged) ? (is_one_body_p_non_zero) : (is_one_body_n_non_zero);
  const bool is_two_body_mu_non_zero = (is_it_charged) ? (is_pp_non_zero)         : (is_nn_non_zero);

  const int n_holes_max_mu = (is_it_charged) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (is_it_charged) ? (n_scat_max_p) : (n_scat_max_n);
  
  const int Emu_max_hw = (is_it_charged) ? (Ep_max_hw) : (En_max_hw);
    
  is_there_one_jump_calc = false;
      
  if (is_one_body_mu_non_zero || is_two_body_mu_non_zero || is_pn_non_zero)
    {
      one_jump_mu.one_jump_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , 0 , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , data);
      
      const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
      
      if (dimension_one_jump_mu > 0)
	{ 
	  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

	      const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	      const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();

	      const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();
	      
	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      	      
	      const TYPE NBME_one_jump_mu_no_phase = H_NBMEs::no_pn_one_jump_mu_no_phase_calc (inter , is_one_body_mu_non_zero , is_two_body_mu_non_zero , mu_in , mu_out , outSDmu , data);
	      
	      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (NBME_one_jump_mu_no_phase) : (-NBME_one_jump_mu_no_phase);
	    }
	  
	  is_there_one_jump_calc = true;
	}
    }
}



// Calculation and storage of the 2p-2h NBMEs involving an outSD basis state of proton or neutron type from TBMEs and reordering phases
// ------------------------------------------------------------------------------------------------------------------------------------
// One considers only the pp or nn 2p-2h part, and one used the notation mu for proton or neutron.
// This routine can be used with valence protons only, valence neutrons only, or both valence protons and neutrons.
// It is used with both full storage and on the fly methods.
// The difference is that it is used only once with full storage, when calculating and storing the Hamiltoniam,
// whereas it is called for each Hamiltonian time vector operation with on the fly methods.
//
// One has a fixed proton or neutron outSD, whose quantum numbers and index are provided, and the array of 2p-2h jumps data to generate all inSD is calculated and stored.
// One loops over all possible 2p-2h jumps, so that one can find the one-body states alpha, beta, gamma, delta to form the TBME <alpha beta | V | gamma delta>,
// and one can find the reordering phase +/- 1, so that the NBME is equal to phase time TBME. The TBME is then stored in NBMEs_two_jumps_mu.

void H_class::NBMEs_two_jumps_pp_nn_calc_store (
						const unsigned int BPmu , 
						const int Smu , 
						const int n_spec_mu , 
						const int iMmu , 
						const int n_scat_mu_out , 
						const unsigned int iCmu_out , 
						const unsigned int outSDmu_index , 
						const class baryons_data &data , 
						bool &are_there_two_jumps_calc , 
						class jumps_data_str &two_jumps_mu , 
						class array<TYPE> &NBMEs_two_jumps_mu) const
{
  are_there_two_jumps_calc = false;
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  if (N_valence_baryons == 1) return;
  
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const enum particle_type nucleonic_particle_mu = data.get_nucleonic_particle ();
  
  const bool is_it_largest_subspace = (((nucleonic_particle_mu == NEUTRON) && (NYval >= ZYval)) || ((nucleonic_particle_mu == PROTON) && (NYval < ZYval)));
  
  const enum space_type TBME_space_mu = (nucleonic_particle_mu == PROTON) ? (PROT_Y_ONLY) : (NEUT_Y_ONLY);
  
  const class TBMEs_class &TBMEs = data.get_TBMEs ();
    
  const int n_holes_max_p = GSM_vector_helper.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper.get_n_scat_max_n (); 

  const int Ep_max_hw = GSM_vector_helper.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper.get_En_max_hw (); 

  const bool is_two_body_mu_non_zero = (TBME_space_mu == PROT_Y_ONLY) ? (is_pp_non_zero) : (is_nn_non_zero);

  const int n_holes_max_mu = (TBME_space_mu == PROT_Y_ONLY) ? (n_holes_max_p) : (n_holes_max_n);
  
  const int n_scat_max_mu = (TBME_space_mu == PROT_Y_ONLY) ? (n_scat_max_p) : (n_scat_max_n);

  const int Emu_max_hw = (TBME_space_mu == PROT_Y_ONLY) ? (Ep_max_hw) : (En_max_hw);
  
  const bool are_M_TBMEs_stored = ((M_TBMEs_storage == FULL_STORAGE) || (!is_it_largest_subspace && (M_TBMEs_storage == PARTIAL_STORAGE)));
    
  if (is_two_body_mu_non_zero && (N_valence_baryons >= 2))
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , false , false , data);
      
      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();
	      
      if (dimension_two_jumps_mu > 0)
	{  
	  for (unsigned int i = 0 ; i < dimension_two_jumps_mu ; i++)
	    { 
	      const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(i);

	      const unsigned int mu_left_in  = two_jumps_mu_inSD.get_left_in ();
	      const unsigned int mu_right_in = two_jumps_mu_inSD.get_right_in ();

	      const unsigned int mu_left_out  = two_jumps_mu_inSD.get_left_out ();
	      const unsigned int mu_right_out = two_jumps_mu_inSD.get_right_out ();
	      
	      const unsigned int total_bin_phase_mu = two_jumps_mu_inSD.get_total_bin_phase ();

	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);

	      const TYPE TBME_mu = (are_M_TBMEs_stored) ? (M_TBMEs (TBME_space_mu , false , mu_left_in , mu_right_in , mu_left_out , mu_right_out)) : (TBMEs.M_TBME (false , mu_left_in , mu_right_in , mu_left_out , mu_right_out));
	     	      		  
	      NBMEs_two_jumps_mu(i) = (total_phase_mu == 1) ? (TBME_mu) : (-TBME_mu);
	    }
 
	  are_there_two_jumps_calc = true;
	}
    }
}



bool H_class::is_there_Hamiltonian_storage_determine (
						      const bool is_it_TRS ,
						      const unsigned int PSI_in_index ,
						      const unsigned int PSI_out_index) const
{
  if (is_it_TRS) return true;

  const bool is_PSI_indices_sum_even = ((PSI_in_index + PSI_out_index)%2 == 0);

  const bool is_there_storage = (PSI_in_index > PSI_out_index) ? (is_PSI_indices_sum_even) : (!is_PSI_indices_sum_even);
  
  return is_there_storage;
}




void H_class::apply_add (
			 const class GSM_vector &PSI_in , 
			 const TYPE &E , 
			 class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  H_MPI_communication_time = 0.0;

  H_multiplications_number = 0.0;
  
  const unsigned int space_dimension_process = GSM_vector_helper.get_space_dimension_process ();

  const unsigned int first_PSI_index = basic_first_index_determine_for_MPI (space_dimension_process , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();
  
  const class array<unsigned int> &TRS_PSI_indices = GSM_vector_helper.get_TRS_PSI_indices ();

  for (unsigned int PSI_index_shifted = 0 ; PSI_index_shifted < space_dimension_process ; PSI_index_shifted++) 
    {
      const unsigned int PSI_index = PSI_index_shifted + first_PSI_index;

      if (!is_it_TRS || (TRS_PSI_indices(PSI_index) >= PSI_index)) H_multiplications_number += 1.0;
    }
  
  if (!PSI_in.same_parity_strangeness_M_projection (GSM_vector_helper)) return;
  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper)) return;
  
  const double reference_time = ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed) ? (absolute_time_determine ()) : (NADA);
    
#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      const double reference_time = absolute_time_determine ();
	    
      double PSI_out_infinite_norm = PSI_out.infinite_norm ();
	
      MPI_helper::Bcast<double> (PSI_out_infinite_norm , MASTER_PROCESS , MPI_COMM_WORLD);  

      if (PSI_out_infinite_norm > 0.0)
	{
	  PSI_out.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	  PSI_out /= NUMBER_OF_PROCESSES;
	}
      
      const double MPI_Bcast_absolute_time = absolute_time_determine ();
      
      H_MPI_communication_time += MPI_Bcast_absolute_time - reference_time;
    }
  
#endif

  PSI_out.diagonal_part_PSI_add (PSI_in , H_diagonal_tab , E); 
  
  switch (Hamiltonian_storage)
    {
    case FULL_STORAGE:    (is_it_TRS) ? (apply_add_off_diagonal_full_or_partial_storage_TRS (PSI_in , PSI_out)) : (apply_add_off_diagonal_full_or_partial_storage_no_TRS (PSI_in , PSI_out)); break;
    case PARTIAL_STORAGE: (is_it_TRS) ? (apply_add_off_diagonal_full_or_partial_storage_TRS (PSI_in , PSI_out)) : (apply_add_off_diagonal_full_or_partial_storage_no_TRS (PSI_in , PSI_out)); break;

    case ON_THE_FLY: apply_add_off_diagonal_on_the_fly (PSI_in , PSI_out); break;    
      
    default: abort_all ();
    }

  H_multiplications_number /= NUMBER_OF_THREADS;
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      const double reference_time = absolute_time_determine ();
      
      PSI_out.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      
      const double MPI_Reduce_absolute_time = absolute_time_determine ();
	
      H_MPI_communication_time += MPI_Reduce_absolute_time - reference_time;
    }
  
#endif
  
  if (is_it_TRS && (THIS_PROCESS == MASTER_PROCESS)) PSI_out.TRS_rest_part_fill (J);

  if (is_there_cout_detailed) H_MPI_communication_times_multiplications_number_print ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout_detailed)
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time;
      
      cout << "Time before H.PSI:" << reference_time << " s" << endl;
      cout << "Time after  H.PSI:" << now << " s" << endl;
      
      cout << "Hamiltonian applied. time:" << relative_time << " s" << endl << endl;
    }
}





void H_class::H_MPI_communication_times_multiplications_number_print () const
{    
  const double H_MPI_communication_time_square = H_MPI_communication_time*H_MPI_communication_time;

  const double H_MPI_communication_time_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
  const double H_MPI_communication_time_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
      
  const double H_MPI_communication_time_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time);
  const double H_MPI_communication_time_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_MPI_communication_time_square);
      
  const double H_multiplications_number_square = H_multiplications_number*H_multiplications_number;

  const double H_multiplications_number_min = min_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
  const double H_multiplications_number_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
      
  const double H_multiplications_number_sum         = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number);
  const double H_multiplications_number_squares_sum = sum_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , H_multiplications_number_square);

  if ((THIS_PROCESS == MASTER_PROCESS))
    {
      const double H_MPI_communication_time_average = H_MPI_communication_time_sum/NUMBER_OF_PROCESSES;

      const double H_MPI_communication_time_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_MPI_communication_time_sum , H_MPI_communication_time_squares_sum);
	  
      const double H_multiplications_number_average = H_multiplications_number_sum/NUMBER_OF_PROCESSES;

      const double H_multiplications_number_sigma = statistical_sigma_calc (NUMBER_OF_PROCESSES , H_multiplications_number_sum , H_multiplications_number_squares_sum);
	  
      cout << endl;
      cout << "Hamiltonian MPI communication time min used by a process        : " << H_MPI_communication_time_min     << " s" << endl;
      cout << "Hamiltonian MPI communication time max used by a process        : " << H_MPI_communication_time_max     << " s" << endl;
      cout << "Hamiltonian MPI communication time average for all processes    : " << H_MPI_communication_time_average << " s" << endl;
      cout << "Hamiltonian MPI communication time dispersion for all processes : " << H_MPI_communication_time_sigma   << " s" << endl;

      cout << endl;
      cout << "Hamiltonian average multiplications number per thread min used by a process        : " << H_multiplications_number_min     << endl;
      cout << "Hamiltonian average multiplications number per thread max used by a process        : " << H_multiplications_number_max     << endl;
      cout << "Hamiltonian average multiplications number per thread average for all processes    : " << H_multiplications_number_average << endl;
      cout << "Hamiltonian average multiplications number per thread dispersion for all processes : " << H_multiplications_number_sigma   << endl;

      cout << endl;
    }
}



xH_plus_alpha_str::xH_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_class &H_c) : x (x_c) , alpha (alpha_c) , H (H_c) {}

class xH_plus_alpha_str operator + (const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , 0.0 , H);
}

class xH_plus_alpha_str operator - (const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class H_class &H , const double alpha)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const class H_class &H , const double alpha)
{
  return xH_plus_alpha_str (1.0 , -alpha , H);
}

class xH_plus_alpha_str operator + (const double alpha , const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const double alpha , const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , alpha , H);
}

class xH_plus_alpha_str operator * (const class H_class &H , const double x)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator * (const double x , const class H_class &H)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator / (const class H_class &H , const double x)
{
  const double one_over_x = 1.0/x;

  return xH_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , -Op.alpha , Op.H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const double term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const double term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_plus_alpha_str operator + (const double term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const double term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const double factor)
{
  return xH_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const double factor)
{
  return xH_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_plus_alpha_str operator * (const double factor , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#ifdef TYPEisDOUBLECOMPLEX

class xH_plus_alpha_str operator + (const class H_class &H , const complex<double> &alpha)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const class H_class &H , const complex<double> &alpha)
{
  return xH_plus_alpha_str (1.0 , -alpha , H);
}

class xH_plus_alpha_str operator + (const complex<double> &alpha , const class H_class &H)
{
  return xH_plus_alpha_str (1.0 , alpha , H);
}

class xH_plus_alpha_str operator - (const complex<double> &alpha , const class H_class &H)
{
  return xH_plus_alpha_str (-1.0 , alpha , H);
}

class xH_plus_alpha_str operator * (const class H_class &H , const complex<double> &x)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator * (const complex<double> &x , const class H_class &H)
{
  return xH_plus_alpha_str (x , 0.0 , H);
}

class xH_plus_alpha_str operator / (const class H_class &H , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xH_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_plus_alpha_str operator + (const complex<double> &term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_plus_alpha_str operator - (const complex<double> &term , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_plus_alpha_str operator * (const class xH_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_plus_alpha_str operator / (const class xH_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_plus_alpha_str operator * (const complex<double> &factor , const class xH_plus_alpha_str &Op)
{
  return xH_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#endif

class xH_plus_alpha_str operator + (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b)
{
  if (&(Op_a.H) != &(Op_b.H)) error_message_print_abort ("H must be the same in both Op_a and Op_b in class xH_plus_alpha_str operator +");

  return xH_plus_alpha_str (Op_a.x + Op_b.x , Op_a.alpha + Op_b.alpha , Op_a.H);
}

class xH_plus_alpha_str operator - (const class xH_plus_alpha_str &Op_a , const class xH_plus_alpha_str &Op_b)
{	
  if (&(Op_a.H) != &(Op_b.H)) error_message_print_abort ("H must be the same in both Op_a and Op_b in class xH_plus_alpha_str operator -");

  return xH_plus_alpha_str (Op_a.x - Op_b.x , Op_a.alpha - Op_b.alpha , Op_a.H);
}


