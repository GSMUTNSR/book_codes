#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace beta_transitions_common;
using namespace inputs_misc;
using namespace correlated_state_routines;



// TYPE is double or complex
// -------------------------

// Calculation of the beta transition matrix elements for a given suboperator for all one-body basis states
// --------------------------------------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// Reduced beta transition matrix elements are calculated first, and dereduced afterwards.

void beta_transitions::beta_suboperator_OBMEs_calc (
						    const bool is_it_HO_expansion , 
						    const enum radial_operator_type radial_operator , 
						    const enum beta_suboperator_type beta_suboperator , 
						    const class interaction_class &inter_data , 
						    const int rank_Op_projection , 
						    const class baryons_data &data_in , 
						    const class baryons_data &data_out , 
						    class array<TYPE> &OBMEs)
{
  const unsigned int N_nlj_in  = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out);

  beta_suboperator_OBMEs_reduced_calc (is_it_HO_expansion , radial_operator , beta_suboperator , inter_data , data_in , data_out , OBMEs_reduced);

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

  OBMEs_dereduced_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);
}







// Calculation of the beta transition many-body matrix elements <Psi[out] | Op | Psi[in]> for a given suboperator 
// --------------------------------------------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// <Psi[out] | Op | Psi[in]> is calculated and stored in an array of beta transition many-body matrix elements.

void beta_transitions::beta_suboperator_NBME_calc (
						   const enum beta_pm_type beta_pm , 
						   const bool is_it_HO_expansion , 
						   const enum radial_operator_type radial_operator , 
						   const enum beta_suboperator_type beta_suboperator , 
						   const class interaction_class &inter_data , 
						   const class correlated_state_str &PSI_IN_qn , 
						   const class correlated_state_str &PSI_OUT_qn , 
						   const class GSM_vector &PSI_OUT , 
						   class array<TYPE> &beta_suboperators_NBMEs)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_in  = data_in_determine  (beta_pm , prot_Y_data , neut_Y_data);
  const class baryons_data &data_out = data_out_determine (beta_pm , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_in  = data_in.get_N_nlj_baryon ();
  const unsigned int N_nlj_out = data_out.get_N_nlj_baryon ();

  const unsigned int N_nljm_in  = data_in.get_N_nljm_baryon ();
  const unsigned int N_nljm_out = data_out.get_N_nljm_baryon ();

  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);
  
  const int rank_Op_projection = make_int (M_OUT - M_IN);

  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

  class array<TYPE> OBMEs_reduced(N_nlj_in , N_nlj_out);

  class array<TYPE> OBMEs(N_nljm_in , N_nljm_out);

  beta_suboperator_OBMEs_reduced_calc (is_it_HO_expansion , radial_operator , beta_suboperator , inter_data , data_in , data_out , OBMEs_reduced);

  OBMEs_dereduced_calc<TYPE> (rank_Op , rank_Op_projection , data_in , data_out , OBMEs_reduced , OBMEs);

  beta_suboperators_NBMEs(beta_suboperator_index) = beta_transitions_NBMEs::calc (beta_pm ,  beta_suboperator , OBMEs , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
}

void beta_transitions::beta_suboperators_NBMEs_calc (
						     const enum beta_type beta , 
						     const enum beta_pm_type beta_pm , 
						     const bool is_it_HO_expansion , 
						     const class interaction_class &inter_data , 
						     const class correlated_state_str &PSI_IN_qn ,  
						     const class correlated_state_str &PSI_OUT_qn ,  
						     const class GSM_vector &PSI_OUT , 
						     class array<TYPE> &beta_suboperators_NBMEs)

{
  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , OVERLAP , FERMI_ALLOWED        , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , OVERLAP , GAMOW_TELLER_ALLOWED , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);	
      } break;

    case FIRST_FORBIDDEN:
      {
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD , W_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD , U_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD , Z_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD , X_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD_COULOMB , W_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD_COULOMB , U_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , FFBD_COULOMB , X_FFBD_COULOMB , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , REDUCED_GRADIENT , XI_PRIME_V_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
	beta_suboperator_NBME_calc (beta_pm , is_it_HO_expansion , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);
      } break;

    default: error_message_print_abort ("No beta transition recognized in beta_transitions::beta_suboperators_NBMEs_calc");
    }
}











// Calculation and print on screen of beta transition many-body matrix elements <Psi[out] | Op | Psi[in]> for all operators
// ------------------------------------------------------------------------------------------------------------------------
// First-forbidden or allowed beta decays are calculated and printed on screen, by looping over the demanded values in the input file.
// All possible allowed or first-forbidden beta decay suboperators are calculated if one asks for allowed or first-forbidden beta decay operators (one or the other).

void beta_transitions::calc_print (
				   const input_data_str &input_data , 
				   const class interaction_class &inter_data , 
				   const class baryons_data &prot_Y_data , 
				   const class baryons_data &neut_Y_data , 
				   const class array<class correlated_state_str> &PSI_qn_tab)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "beta transitions" << endl;
      cout <<         "----------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw () ;
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();

  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();

  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const int A = prot_Y_data.get_A ();

  const int Z_OUT = prot_Y_data.get_N_nucleons ();
  const int N_OUT = neut_Y_data.get_N_nucleons ();

  const int S = prot_Y_data.get_hypernucleus_strangeness ();
  
  if (S != 0) error_message_print_abort ("beta transitions cannot be calculated with hypernuclei in beta_transitions::calc_print");
  
  const unsigned int beta_transitions_number = input_data.get_beta_transitions_number ();
 
  const class array<enum beta_type> &beta_tab = input_data.get_beta_tab ();
  
  const class array<enum beta_pm_type> &beta_pm_tab = input_data.get_beta_pm_tab ();

  const class array<unsigned int> &beta_BP_IN_tab  = input_data.get_beta_BP_IN_tab ();
  const class array<unsigned int> &beta_BP_OUT_tab = input_data.get_beta_BP_OUT_tab ();

  const class array<double> &beta_J_IN_tab  = input_data.get_beta_J_IN_tab ();
  const class array<double> &beta_J_OUT_tab = input_data.get_beta_J_OUT_tab ();
  
  const class array<unsigned int> &beta_vector_index_IN_tab  = input_data.get_beta_vector_index_IN_tab ();
  const class array<unsigned int> &beta_vector_index_OUT_tab = input_data.get_beta_vector_index_OUT_tab (); 

  const class array<bool> &beta_is_it_HO_expansion_tab = input_data.get_beta_is_it_HO_expansion_tab ();
  
  const class array<double> &beta_W0_tab = input_data.get_beta_W0_tab ();

  for (unsigned int beta_index = 0 ; beta_index < beta_transitions_number ; beta_index++)
    {
      const enum beta_type beta = beta_tab(beta_index);

      const enum beta_pm_type beta_pm = beta_pm_tab(beta_index);

      const bool is_it_HO_expansion = beta_is_it_HO_expansion_tab(beta_index);

      const double W0 = beta_W0_tab(beta_index);

      const unsigned int BP_IN  = beta_BP_IN_tab(beta_index);
      const unsigned int BP_OUT = beta_BP_OUT_tab(beta_index);
  
      const unsigned int vector_index_IN  = beta_vector_index_IN_tab(beta_index);
      const unsigned int vector_index_OUT = beta_vector_index_OUT_tab(beta_index);

      const double J_IN  = beta_J_IN_tab(beta_index);
      const double J_OUT = beta_J_OUT_tab(beta_index);

      const double M_OUT = J_OUT;

      const int Z_IN = Z_IN_beta_determine (beta_pm , Z_OUT);
      const int N_IN = N_IN_beta_determine (beta_pm , N_OUT);

      const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , 0 , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

      const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , 0 , J_OUT , vector_index_OUT , PSI_qn_tab);

      const class GSM_vector_helper_class PSI_OUT_helper(space , inter , truncation_hw , truncation_ph ,
							 n_holes_max   , n_scat_max   , E_max_hw  ,
							 n_holes_max_p , n_scat_max_p , Ep_max_hw ,
							 n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP_OUT , M_OUT , false);
		
      class GSM_vector PSI_OUT(PSI_OUT_helper);

      if (THIS_PROCESS == MASTER_PROCESS) PSI_OUT.eigenvector_read_disk (PSI_OUT_qn);

#ifdef UseMPI
      PSI_OUT.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      const unsigned int beta_suboperator_type_number = beta_suboperator_type_number_determine ();

      class array<TYPE> beta_suboperators_NBMEs(beta_suboperator_type_number);
      
      beta_suboperators_NBMEs = 0.0;

      beta_suboperators_NBMEs_calc (beta , beta_pm , is_it_HO_expansion , inter_data , PSI_IN_qn , PSI_OUT_qn , PSI_OUT , beta_suboperators_NBMEs);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << endl;

	  beta_transitions_common::calc_print (beta , beta_pm , A , Z_OUT , W0 , J_IN , beta_suboperators_NBMEs);
	}
    }
}



