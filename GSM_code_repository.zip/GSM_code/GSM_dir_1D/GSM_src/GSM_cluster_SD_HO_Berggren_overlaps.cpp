#include "../GSM_include/GSM_include_def.h"

using namespace GSM_vector_dimensions;


// TYPE is double or complex
// -------------------------

// Storage of dimensions and <SD-Berggren | SD-HO> in arrays
// -------------------------------------------------------
// <SD-Berggren | SD-HO> has been generated and belongs to the proton or neutron model space.
// They are Slater determinants of the expansion of cluster states and these overlaps are used in GSM-CC.
// If arrays dimensions are calculated only, the dimension of fixed |SD-HO> is increased. 
// If <SD-Berggren | SD-HO> arrays are constructed, the considered <SD-Berggren | SD-HO> is also stored in the array containing <SD-Berggren | SD-HO>.

void cluster_SD_HO_Berggren_overlaps::fill_SD_HO_Berggren_overlaps_table (
									  const enum operation_type operation , 
									  const unsigned int n_scat_HO_in , 
									  const unsigned int iC_HO_in , 
									  const unsigned int inSD_HO_index , 
									  const unsigned int dimensions_SD_HO_Berggren_overlaps_table_index , 
									  const unsigned int SD_HO_Berggren_overlaps_table_zero_index , 
									  const TYPE SD_HO_Berggren_overlap , 
									  class baryons_data &cluster_particles_data)
{
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table = cluster_particles_data.get_dimensions_SD_HO_Berggren_overlaps_table ();
  
  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      dimensions_SD_HO_Berggren_overlaps_table[dimensions_SD_HO_Berggren_overlaps_table_index]++;
      break;

    case TABLES_FILL:
      {
	const unsigned int SD_HO_Berggren_overlaps_index = dimensions_SD_HO_Berggren_overlaps_table[dimensions_SD_HO_Berggren_overlaps_table_index]++;

	const unsigned int SD_HO_Berggren_overlaps_table_index = SD_HO_Berggren_overlaps_table_zero_index + SD_HO_Berggren_overlaps_index;

	class array_of_SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_table = cluster_particles_data.get_SD_HO_Berggren_overlaps_table ();

	SD_HO_Berggren_overlaps_table[SD_HO_Berggren_overlaps_table_index].initialize (n_scat_HO_in , iC_HO_in , inSD_HO_index , SD_HO_Berggren_overlap);
      } break;

    default: abort_all ();
    } 
}




// Generation of all the HO Slater determinants of a fixed Berggren Slater determinant
// -----------------------------------------------------------------------------------
// inSD is always |SD-HO> and outSD is always |SD-Berggren>.
//
// The HO sub-Slater determinants |s0 s1 s2>, |s3>, |s4 s5> of a given Berggren Slater determinant, 
// each parts having fixed angular quantum quantum numbers (l0,j0,m0), (l1,j1,m1), (l2,j2,m2), but varying principal quantum numbers, have been generated.
//
// For example, if one has a Berggren Slater determinant equal to |0p3/2(-3/2) 1p3/2(1/2) 0f7/2(-1/2) 0g9/2(1/2)> the HO sub-Slater determinants are, for n=0,1:
//
// |0p3/2(-3/2) 1p3/2(1/2)>: |0p3/2(-3/2) 0p3/2(-3/2)>_HO, |0p3/2(-3/2) 1p3/2(-3/2)>_HO, |1p3/2(-3/2) 0p3/2(-3/2)>_HO, |1p3/2(-3/2) 1p3/2(-3/2)>_HO,  written as A[0], A[1], A[2], A[3]
//
// |0f7/2(-1/2)>: |0f7/2(-1/2)>_HO, |1f7/2(-1/2)>_HO, written as B[0], B[1]
//
// |0g9/2(1/2)>: |0s1/2(1/2)>_HO, |0g9/2(1/2)>_HO, written as C[0], C[1]
//
// Hence, one has 16 possible HO Slater determinants in this Berggren Slater determinant.
// The HO Slater determinants are then constructed this way:
// 
// A[0] B[0] C[0]  (This HO Slater determinant always exists)
// A[1] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[0] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[1] C[0]  (A index is increased: A[4] does not exist => A index is put to zero and B index is increased)
// A[1] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[1] C[0]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[0] C[1]  (A index is increased: A[4] does not exist => A index is put to zero)
//                 (B index is increased: B[2] does not exist => A,B indices are put to zero and C index is increased)
// A[1] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[0] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[0] B[1] C[1]  (A index is increased: A[4] does not exist => A index is put to zero and B index is increased)
// A[1] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[2] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
// A[3] B[1] C[1]  (A index is increased: sub-indices are correct => accepted)
//
// Stop  (A index is increased: A[4] does not exist => A index is put to zero)
//       (B index is increased: B[2] does not exist => A,B indices are put to zero)
//       (C index is increased: C[2] does not exist: no other shell to consider => the routine stops)
//
// For each accepted HO Slater determinant, one reorders it so that its one-body states are ordered in an increasing manner, and one calculates its <SD-Berggren | SD-HO> overlap.
// The interest of this representation is that one-body overlaps between HO and Berggren states are equal to zero unless their angular quantum quantum numbers are identical.
// <SD-Berggren | SD-HO> overlap> is then a product of overlaps between Berggren and HO sub-Slater determinants (see GSM_Slater_determinant.cpp).
//
//
// "nljm reordered" means that one uses the ordering used above, where one has groups of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers: 
// |0p3/2(-3/2) 1p3/2(1/2) 0f7/2(-1/2) 0g9/2(1/2)> is nljm ordered.
// A group of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers is called an (l,j,m) group.
// 
// But, if their one-body indices are so that it is equal to |0 4 1 2 3>, it is not ordered according to one-body indices. Its ordered representation is then |0 1 2 3 4>, with a reordering phase of -1.
// If "nljm_reordered" us not written for Slater determinants, the latter ordering is supposed to be used.

void cluster_SD_HO_Berggren_overlaps::all_SDs_HO_Berggren_overlaps_of_SD (
									  const enum operation_type operation , 
									  const bool truncation_hw , 
									  const bool truncation_ph , 
									  const unsigned int BP , 
									  const int S , 
									  const int n_spec , 
									  const int iM , 
									  const unsigned int dimensions_SD_HO_Berggren_overlaps_table_index , 
									  const unsigned int SD_HO_Berggren_overlaps_table_zero_index , 
									  const unsigned int outSD_nljm_reordering_bin_phase , 
									  const class Slater_determinant &outSD_nljm_reordered , 
									  const class array<class ljm_struct> &ljm_states , 
									  const class array<unsigned int> &N_valence_baryons_per_ljm , 
									  const class array<unsigned int> &N_sub_SDs_HO_per_ljm , 
									  const class array<class array<class Slater_determinant> > &sub_SDs_HO_tab , 
									  const class baryons_data &cluster_particles_data_HO , 
									  class baryons_data &cluster_particles_data)
{
  const int n_holes_max_HO = cluster_particles_data_HO.get_n_holes_max ();
  
  const int n_scat_max_HO = cluster_particles_data_HO.get_n_scat_max ();

  const int E_max_hw_HO = cluster_particles_data_HO.get_E_max_hw ();

  const unsigned int ljm_number = N_sub_SDs_HO_per_ljm.dimension (0);

  const unsigned int N_valence_baryons = cluster_particles_data_HO.get_N_valence_baryons ();

  const class array<class nljm_struct> &phi_table = cluster_particles_data.get_phi_table ();
  
  const class array<class nljm_struct> &phi_table_HO = cluster_particles_data_HO.get_phi_table ();

  const class array<class vector_class<complex<double> > > &HO_overlaps = cluster_particles_data.get_HO_overlaps ();

  const class array<class nlj_struct> &shells_qn_HO = cluster_particles_data_HO.get_shells_quantum_numbers ();

  const class array<unsigned int> &dimensions_configuration_set_HO = cluster_particles_data_HO.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set_HO = cluster_particles_data_HO.get_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set_HO = cluster_particles_data_HO.get_dimensions_SD_set ();

  const class array_of_SD &SD_set_HO = cluster_particles_data_HO.get_SD_set ();

  class array<unsigned int> sub_SDs_HO_index_tab(ljm_number);

  sub_SDs_HO_index_tab = 0;

  class configuration C_HO_in(N_valence_baryons);

  class configuration C_HO_try(N_valence_baryons);
  
  class Slater_determinant inSD_HO_nljm_reordered(N_valence_baryons);

  class Slater_determinant inSD_HO(N_valence_baryons);

  class Slater_determinant SD_HO_try(N_valence_baryons);
  
  while (true)
    {
      inSD_HO_nljm_reordered.get_antisymmetrized_product (N_valence_baryons_per_ljm , sub_SDs_HO_index_tab , sub_SDs_HO_tab);

      inSD_HO = inSD_HO_nljm_reordered;

      unsigned int inSD_nljm_reordering_bin_phase_HO = 0;

      SD_reordering_bin_phase (inSD_HO , inSD_nljm_reordering_bin_phase_HO);
	
      C_HO_in.get_SD_configuration (phi_table_HO , inSD_HO);

      const int n_scat_HO_in = C_HO_in.n_scat_determine (shells_qn_HO);

      const int n_holes_HO_in = C_HO_in.n_holes_determine (shells_qn_HO);
      
      const int E_HO_in_hw = C_HO_in.E_hw_determine (shells_qn_HO);

      if (is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_HO_in , n_scat_HO_in , E_HO_in_hw , n_holes_max_HO , n_scat_max_HO , E_max_hw_HO))
	{	  
	  const unsigned int iC_HO_in = C_HO_in.index_search (BP , S , n_spec , n_scat_HO_in , dimensions_configuration_set_HO , configuration_set_HO , C_HO_try);

	  const TYPE SD_HO_Berggren_nljm_reordered_overlap = overlap_SD_Berggren_HO_nljm_reordered_calc (phi_table , phi_table_HO , HO_overlaps , ljm_states , outSD_nljm_reordered , inSD_HO_nljm_reordered);

	  const TYPE SD_HO_Berggren_overlap = (outSD_nljm_reordering_bin_phase == inSD_nljm_reordering_bin_phase_HO) ? (SD_HO_Berggren_nljm_reordered_overlap) : (-SD_HO_Berggren_nljm_reordered_overlap);

	  const unsigned int inSD_HO_index = inSD_HO.index_search (BP , S , n_spec , n_scat_HO_in , iC_HO_in , iM , dimensions_SD_set_HO , SD_set_HO , SD_HO_try);

	  fill_SD_HO_Berggren_overlaps_table (operation , n_scat_HO_in , iC_HO_in , inSD_HO_index , dimensions_SD_HO_Berggren_overlaps_table_index ,
					      SD_HO_Berggren_overlaps_table_zero_index , SD_HO_Berggren_overlap , cluster_particles_data);
	}
      
      bool good_sub_SDs_HO_indices = false;

      for (unsigned int ljm_index = 0  ; (!good_sub_SDs_HO_indices) && (ljm_index < ljm_number) ; ljm_index++)
	{	  
	  sub_SDs_HO_index_tab(ljm_index)++;

	  if (sub_SDs_HO_index_tab(ljm_index) == N_sub_SDs_HO_per_ljm(ljm_index))
	    {
	      for (unsigned int ljm_subindex = 0 ; ljm_subindex <= ljm_index ; ljm_subindex++) sub_SDs_HO_index_tab(ljm_subindex) = 0;
	    }
	  else
	    good_sub_SDs_HO_indices = true;	  	  
	}
	    
      if (!good_sub_SDs_HO_indices) return;
    }
}







// Calculation of all the HO sub-Slater determinants of a (l,j,m) group
// ---------------------------------------------------------------------
// A group of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers is called an (l,j,m) group.
//
// One calculates all the HO sub-Slater determinants of a (l,j,m) group having a fixed number of nucleons.
// Its number of nucleons does not have that of the full Slater determinant, but has to be smaller or equal.
//
// As only one state of fixed (n,l,j,m) quantum numbers can be occupied, n=0,1,... can be used only once in a HO sub-Slater determinants of a (l,j,m) group.
// 
// For example, one considers three nucleons in the p3/2(3/2) group, with n=0,1,2,3 for HO one-body states. The HO sub-Slater determinants are:
// |0p3/2(3/2) 1p3/2(3/2) 2p3/2(3/2)>_HO , |0p3/2(3/2) 1p3/2(3/2) 3p3/2(3/2)>_HO , |0p3/2(3/2) 2p3/2(3/2) 3p3/2(3/2)>_HO , |1p3/2(3/2) 2p3/2(3/2) 3p3/2(3/2)>_HO
// written as {0,1,2}, {0,1,3}, {0,2,3}, {1,2,3}
//
// They are generated the following way:
// {0,1,2} (it is the ground state of considered HO sub-Slater determinants and always exists)
// {0,1,3} (the third state index is increased: state indices are correct => accepted)
// {0,2,3} (the third state index is increased: there is no third state of index 4)
//         (the second state index is increased and the third state index is second state+1: state indices are correct => accepted)
// {1,2,3} (the third state index is increased: there is no third state of index 4)
//         (the second state index is increased and the third state index is second state+1: there is no third state of index 4)
//         (the first state index is increased, the second state is first state+1 and the third state index is second state+1: state indices are correct => accepted)
//
// Stop (the third state index is increased: there is no third state of index 4)
//      (the second state index is increased and the third state index is second state+1: there is no third state of index 4)
//      (the first state index is increased, the second state is first state+1 and the third state index is second state+1: there is no third state of index 4)
//      (As all nucleons have been tried unsuccessfully to generate a new HO sub-Slater determinant, this means that all HO sub-Slater determinants have been generated as the algorithm is lexicographic, and the routine stops.)

void cluster_SD_HO_Berggren_overlaps::all_sub_SDs_HO_per_ljm (
							      const class ljm_struct &ljm , 
							      const unsigned int N_valence_baryons_fixed_ljm , 
							      const class array<int> &nmax_HO_lab_tab , 
							      const class one_body_indices_str &one_body_indices_HO , 
							      class array<class Slater_determinant> &sub_SDs_HO_tab_ljm)
{
  const enum particle_type particle = ljm.get_particle ();
  
  const int l = ljm.get_l ();
  
  const double j = ljm.get_j ();
  const double m = ljm.get_m ();

  const int lmax_for_interaction = nmax_HO_lab_tab.dimension (0) - 1;

  if (l > lmax_for_interaction) return; 

  const int nmax_HO_l = nmax_HO_lab_tab(l);

  unsigned int sub_SD_HO_index = 0;

  class Slater_determinant n_HO_of_sub_SD_HO(N_valence_baryons_fixed_ljm);

  class Slater_determinant sub_SD_HO(N_valence_baryons_fixed_ljm);

  n_HO_of_sub_SD_HO.ground_state (0);

  for (unsigned int i = 0 ; i < N_valence_baryons_fixed_ljm ; i++) sub_SD_HO[i] = one_body_indices_HO(particle , n_HO_of_sub_SD_HO[i] , l , j , m);

  sub_SDs_HO_tab_ljm(sub_SD_HO_index++) = sub_SD_HO;

  while (true)
    {
      unsigned int i = N_valence_baryons_fixed_ljm - 1;
      
      n_HO_of_sub_SD_HO[i]++;

      while (n_HO_of_sub_SD_HO[N_valence_baryons_fixed_ljm - 1] > nmax_HO_l)
	{
	  if (--i >= N_valence_baryons_fixed_ljm) return; 

	  int n = ++n_HO_of_sub_SD_HO[i];

	  for (unsigned int ii = i + 1 ; ii < N_valence_baryons_fixed_ljm ; ii++) n_HO_of_sub_SD_HO[ii] = ++n;
	}

      for (unsigned int i = 0 ; i < N_valence_baryons_fixed_ljm ; i++) sub_SD_HO[i] = one_body_indices_HO(particle , n_HO_of_sub_SD_HO[i] , l , j , m);

      sub_SDs_HO_tab_ljm(sub_SD_HO_index++) = sub_SD_HO;
    }
}





// Determination and storage of number of nucleons on each (l,j,m) group for a given Berggren Slater determinant
// -------------------------------------------------------------------------------------------------------------
// A group of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers is called an (l,j,m) group.
//
// One has a fixed Berggren Slater determinant in which HO Slater determinants will be built.
// One determines here the number of nucleons on each (l,j,m) group.

void cluster_SD_HO_Berggren_overlaps::N_valence_baryons_per_ljm_fill (
								       const class array<class nljm_struct> &phi_table , 
								       const class Slater_determinant &SD_nljm_reordered , 
								       const class array<class ljm_struct> &ljm_states , 
								       class array<unsigned int> &N_valence_baryons_per_ljm)
{
  const unsigned int ljm_number = ljm_states.dimension (0);

  for (unsigned int ljm_index = 0 ; ljm_index < ljm_number ; ljm_index++)
    {
      const class ljm_struct &ljm = ljm_states(ljm_index);
      
      const unsigned int N_valence_baryons_fixed_ljm = SD_nljm_reordered.N_valence_baryons_fixed_ljm_determine (phi_table , ljm);

      N_valence_baryons_per_ljm(ljm_index) = N_valence_baryons_fixed_ljm;
    }
}






// Calculation of the number of HO sub-Slater determinants in occupied (l,j,m) groups
// ----------------------------------------------------------------------------------
// A group of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers is called an (l,j,m) group.
//
// One loops over all the occupied (l,j,m) groups of the Berggren Slater determinant and one calculated the number of HO sub-Slater determinants on each occupied (l,j,m) group.
// For a given (l,j,m) group having Nv valence nucleons and Ns states, it is Ns! / (Nv! (Ns-Nv)!) as nucleons are indistinguishable and Nv <= Ns.
//
// In order not to have to consider large factorials, one uses the formula: Ns! / (Nv! (Ns-Nv)!) = (Ns-Nv+1) ... Ns / (Ns-Nv)!.
//
// One starts with Ns-Nv+1, and one divides by i=1,2,... entering (Ns-Nv)! only if it is a multiple of it. 
// One stops once i is no longer a multiple of Ns-Nv+1 or it is equal to Nv.
//
// One multiplies by Ns-Nv+2, and one divides by i,i+1,... entering (Ns-Nv)! only if it is a multiple of it.
// One stops once i is no longer a multiple of Ns-Nv+1 or it is equal to Nv.
// 
// One continues until one reaches Ns in the numerator.

void cluster_SD_HO_Berggren_overlaps::N_sub_SDs_HO_per_ljm_fill (
								 const class array<class ljm_struct> &ljm_states , 
								 const class array<unsigned int> &N_valence_baryons_per_ljm , 
								 const class array<int> &nmax_HO_lab_tab , 
								 class array<unsigned int> &N_sub_SDs_HO_per_ljm)
{
  const unsigned int ljm_number = ljm_states.dimension (0);

  const int lmax_for_interaction = nmax_HO_lab_tab.dimension (0) - 1;

  N_sub_SDs_HO_per_ljm = 0;
  
  for (unsigned int ljm_index = 0 ; ljm_index < ljm_number ; ljm_index++)
    {
      const class ljm_struct &ljm = ljm_states(ljm_index);
      
      const int l = ljm.get_l ();
  
      if (l > lmax_for_interaction) continue; 

      const int nmax_HO_l = nmax_HO_lab_tab(l);

      const unsigned int N_states = nmax_HO_l + 1;

      const unsigned int N_valence_baryons_fixed_ljm = N_valence_baryons_per_ljm(ljm_index);

      const unsigned int N_valence_baryons_fixed_ljm_minus_one = N_valence_baryons_fixed_ljm - 1;

      unsigned int N_sub_SDs_per_fixed_ljm = 1;

      unsigned int i_denominator = 1;

      for (unsigned int i = N_states - N_valence_baryons_fixed_ljm_minus_one ; i <= N_states ; i++)
	{
	  N_sub_SDs_per_fixed_ljm *= i;	
  
	  while ((N_sub_SDs_per_fixed_ljm%i_denominator == 0) && (i_denominator <= N_valence_baryons_fixed_ljm)) N_sub_SDs_per_fixed_ljm /= i_denominator++;
	}
	  
      N_sub_SDs_HO_per_ljm(ljm_index) = N_sub_SDs_per_fixed_ljm;
    }
}






// Calculation of the dimensions of arrays and generation of <SD-Berggren | SD-HO> overlaps
// ----------------------------------------------------------------------------------------
// A group of states of same (l,j,m) angular quantum quantum numbers but different principal quantum numbers is called an (l,j,m) group.
//
// A Slater determinant which is nljm ordered is of the form SD_nljm = |I(n0_0 l0 j0 m0) ... I(n0_N0 l0 j0 m0) ... I(n1_0 l1 j1 m1) ... I(n1_N1 l1 j1 m1) ... >, 
// that is the one-body states have fixed ljm, and vary only through n afterwards, and so for all ljm combinations.
// SD_nljm_reordered is well ordered using the array of indices I_nljm, where I_nljm(n0_0 l0 j0 m0) < ... < I_nljm(n0_N0 l0 j0 m0) < I(n1_0 l1 j1 m1) < ... < I(n1_N1 l1 j1 m1) < ... ,
// but is not well with the initial indices I(ni_j li ji mi).
// Hence, there is a reordering phase after reordering SD_nljm with I(ni_j li ji mi) indices.
// To calculate, one takes the initial, well ordered Slater determinant SD_initial = |s[0] s[1] ... > equal to SD_nljm_reordered up to is a reordering phase.
// Form the array of indices initial_to_nljm_ordered_states(I(ni_j li ji mi)) = I_nljm(ni_j li ji mi), one generates firstly SD_nljm with I_nljm indices, equal to |I_nljm(n[0] l[0] j[0] m[0]) I_nljm(n[1] l[1] j[1] m[1]) ... >.
//
// Arrays of <SD-Berggren | SD-HO> overlaps and/or their dimensions are generated here.
// Dimensions are put to zero first and increased afterwards. 
// One runs over all Berggren Slater determinants, one identifies its occupied (l,j,m) groups, one builds associated HO sub-Slater determinants (see above), 
// and then one builds HO Slater determinants of the configuration from the latter.
// As HO Slater determinants of different Berggren Slater determinants are independently built, the loop over Berggren Slater determinants is parallelized with OpenMP.
// MPI parallelization is not used as calling functions are already parallelized with MPI.

void cluster_SD_HO_Berggren_overlaps::tables_fill_dimensions_calc (
								   const enum operation_type operation , 
								   const bool truncation_hw , 
								   const bool truncation_ph , 
								   const class array<int> &nmax_HO_lab_tab , 
								   const class baryons_data &cluster_particles_data_HO , 
								   class baryons_data &cluster_particles_data)
{
  const int strangeness_max = cluster_particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = cluster_particles_data.get_n_spec_max (); 
  
  const int n_scat_max = cluster_particles_data.get_n_scat_max ();
  
  const int iM_max = cluster_particles_data.get_iM_max ();

  const class array<unsigned int> &initial_to_nljm_ordered_states = cluster_particles_data.get_initial_to_nljm_ordered_states ();

  const class array<unsigned int> &nljm_ordered_to_initial_states = cluster_particles_data.get_nljm_ordered_to_initial_states ();

  const class array<class nljm_struct> &phi_table = cluster_particles_data.get_phi_table ();

  const class one_body_indices_str &one_body_indices_HO = cluster_particles_data_HO.get_one_body_indices ();

  const class array<unsigned int> &dimensions_configuration_set = cluster_particles_data.get_dimensions_configuration_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = cluster_particles_data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = cluster_particles_data.get_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_out_in_space_tab = cluster_particles_data.get_is_configuration_out_in_space_tab ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = cluster_particles_data.get_is_outSD_in_space_tab ();

  class array_of_SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_table = cluster_particles_data.get_SD_HO_Berggren_overlaps_table ();

  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table = cluster_particles_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  dimensions_SD_HO_Berggren_overlaps_table = 0;

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int S = 0 ; S <= strangeness_max ; S++)
      for (int n_spec = 0 ; n_spec <= n_spec_max ; n_spec++)
	for (int n_scat_out = 0 ; n_scat_out <= n_scat_max ; n_scat_out++)
	  {
	    const unsigned int dimension_C_out = dimensions_configuration_set(BP , S , n_spec , n_scat_out);

	    const unsigned int is_configuration_out_in_space_zero_index = is_configuration_out_in_space_tab.index_determine (BP , S , n_spec , n_scat_out , 0);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	    for (unsigned int iC_out = 0 ; iC_out < dimension_C_out ; iC_out++)
	      {			
		const unsigned int is_configuration_out_in_space_iC_out_index = is_configuration_out_in_space_zero_index + iC_out;

		const bool is_configuration_out_in_space = is_configuration_out_in_space_tab[is_configuration_out_in_space_iC_out_index];

		if (is_configuration_out_in_space)
		  {
		    const unsigned int dimension_SD_set_zero_index = dimensions_SD_set.index_determine (BP , S , n_spec , n_scat_out , iC_out , 0);

		    for (int iM = 0 ; iM <= iM_max ; iM++)
		      {
			const unsigned int dimension_SD_set_index = dimension_SD_set_zero_index + iM;

			const unsigned int dimension_SD_set_BP_S_n_scat_iC_iM = dimensions_SD_set[dimension_SD_set_index];

			const unsigned int is_outSD_in_space_zero_index = is_outSD_in_space_tab.index_determine (BP , S , n_spec , n_scat_out , iC_out , iM , 0);

			const unsigned int SD_set_zero_index = SD_set.index_determine (BP , S , n_spec , n_scat_out , iC_out , iM , 0);

			const unsigned int dimensions_SD_HO_Berggren_overlaps_table_zero_index = dimensions_SD_HO_Berggren_overlaps_table.index_determine (BP , S , n_spec , n_scat_out , iC_out , iM , 0);

			for (unsigned int outSD_index = 0 ; outSD_index < dimension_SD_set_BP_S_n_scat_iC_iM ; outSD_index++)
			  {						
			    const unsigned int is_outSD_in_space_outSD_index = is_outSD_in_space_zero_index + outSD_index;

			    const bool is_outSD_in_space = is_outSD_in_space_tab[is_outSD_in_space_outSD_index];

			    if (is_outSD_in_space)
			      {		
				const unsigned int SD_set_outSD_index = SD_set_zero_index + outSD_index;
			    
				const class Slater_determinant outSD = SD_set[SD_set_outSD_index];

				const unsigned int dimensions_SD_HO_Berggren_overlaps_table_index = dimensions_SD_HO_Berggren_overlaps_table_zero_index + outSD_index;
			    
				const unsigned int SD_HO_Berggren_overlaps_table_zero_index = (operation == TABLES_FILL) ? (SD_HO_Berggren_overlaps_table.index_determine (BP , S , n_spec , n_scat_out , iC_out , iM , outSD_index , 0)) : (NADA);

				class Slater_determinant outSD_nljm_reordered = outSD;
			    
				unsigned int outSD_nljm_reordering_bin_phase = 0;

				outSD.nljm_reordering_bin_phase (initial_to_nljm_ordered_states , nljm_ordered_to_initial_states , outSD_nljm_reordered , outSD_nljm_reordering_bin_phase);

				const unsigned int ljm_number = outSD_nljm_reordered.ljm_number_determine (phi_table);

				class array<class ljm_struct> ljm_states(ljm_number);

				outSD_nljm_reordered.ljm_states_table_calc (phi_table , ljm_states);

				class array<unsigned int> N_valence_baryons_per_ljm(ljm_number);

				N_valence_baryons_per_ljm_fill (phi_table , outSD_nljm_reordered , ljm_states , N_valence_baryons_per_ljm);

				class array<unsigned int> N_sub_SDs_HO_per_ljm(ljm_number);

				N_sub_SDs_HO_per_ljm_fill (ljm_states , N_valence_baryons_per_ljm , nmax_HO_lab_tab , N_sub_SDs_HO_per_ljm);

				if (N_sub_SDs_HO_per_ljm.min () == 0) continue;
				
				class array<class array<class Slater_determinant> > sub_SDs_HO_tab(ljm_number);

				for (unsigned int ljm_index = 0 ; ljm_index < ljm_number ; ljm_index++)
				  {
				    const unsigned int N_sub_SDs_HO_per_ljm_ljm_index = N_sub_SDs_HO_per_ljm(ljm_index);
				    
				    sub_SDs_HO_tab(ljm_index).allocate (N_sub_SDs_HO_per_ljm_ljm_index);
				    
				    class array<class Slater_determinant> &sub_SDs_HO_tab_ljm = sub_SDs_HO_tab(ljm_index);

				    for (unsigned int ljm_subindex = 0 ; ljm_subindex < N_sub_SDs_HO_per_ljm_ljm_index ; ljm_subindex++) sub_SDs_HO_tab_ljm(ljm_subindex).allocate (N_valence_baryons_per_ljm(ljm_index));

				    const class ljm_struct &ljm = ljm_states(ljm_index);
				
				    const unsigned int N_valence_baryons_fixed_ljm = N_valence_baryons_per_ljm(ljm_index);

				    all_sub_SDs_HO_per_ljm (ljm , N_valence_baryons_fixed_ljm , nmax_HO_lab_tab , one_body_indices_HO , sub_SDs_HO_tab_ljm);
				  }
			
				all_SDs_HO_Berggren_overlaps_of_SD (operation , truncation_hw , truncation_ph , BP , S , n_spec , iM , dimensions_SD_HO_Berggren_overlaps_table_index , SD_HO_Berggren_overlaps_table_zero_index , 
								    outSD_nljm_reordering_bin_phase , outSD_nljm_reordered , ljm_states , N_valence_baryons_per_ljm , N_sub_SDs_HO_per_ljm ,
								    sub_SDs_HO_tab , cluster_particles_data_HO , cluster_particles_data);
			      }}}}}}
}










// Allocation and generation of all arrays related to <SD-Berggren | SD-HO> overlaps
// ----------------------------------------------------------------------
// Arrays related to <SD-Berggren | SD-HO> overlaps, hence those storing <SD-Berggren | SD-HO> overlaps and the dimensions of arrays, as well as arrays used afterwards in matrix-GSM vector operations, are allocated here.
// One firstly calculates the dimensions of arrays of <SD-Berggren | SD-HO> overlaps, one allocates them and then one generates arrays of <SD-Berggren | SD-HO> overlaps.

void cluster_SD_HO_Berggren_overlaps::tables_allocated_built (
							      const bool is_there_cout , 
							      const bool truncation_hw , 
							      const bool truncation_ph , 
							      const class array<int> &nmax_HO_lab_tab , 
							      const enum particle_type cluster , 
							      const class baryons_data &cluster_particles_data_HO , 
							      class baryons_data &cluster_particles_data)
{
  class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table = cluster_particles_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  class array_of_SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_table = cluster_particles_data.get_SD_HO_Berggren_overlaps_table ();
  
  dimensions_SD_HO_Berggren_overlaps_table.deallocate ();

  SD_HO_Berggren_overlaps_table.deallocate ();

  const int strangeness_max = cluster_particles_data.get_hypernucleus_strangeness ();
  
  const int n_spec_max = cluster_particles_data.get_n_spec_max ();
  
  const enum particle_type nucleonic_particle = cluster_particles_data.get_nucleonic_particle ();

  const int n_scat_max = cluster_particles_data.get_n_scat_max ();

  const int iM_max = cluster_particles_data.get_iM_max ();

  const class array<unsigned int> &dimensions_configuration_set = cluster_particles_data.get_dimensions_configuration_set ();

  const unsigned long int dimension_SD_total = cluster_particles_data.get_dimension_SD_total ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = cluster_particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned long int> &sum_dimensions_SD_set = cluster_particles_data.get_sum_dimensions_SD_set ();

  dimensions_SD_HO_Berggren_overlaps_table.allocate (dimension_SD_total , sum_dimensions_SD_set);

  tables_fill_dimensions_calc (DIMENSIONS_TABLES_CALC , truncation_hw , truncation_ph , nmax_HO_lab_tab , cluster_particles_data_HO , cluster_particles_data);
    
  SD_HO_Berggren_overlaps_table.allocate (strangeness_max , n_spec_max , n_scat_max , dimensions_configuration_set , iM_max , dimension_SD_total , dimensions_SD_set , sum_dimensions_SD_set , dimensions_SD_HO_Berggren_overlaps_table);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const double dimensions_SD_HO_Berggren_overlaps_table_used_memory = used_memory_calc (dimensions_SD_HO_Berggren_overlaps_table);

      const double SD_HO_Berggren_overlaps_table_used_memory = used_memory_calc (SD_HO_Berggren_overlaps_table);
      
      cout << endl << "SD HO -> Berggren overlaps table " << nucleonic_particle << " space" << endl;
      
      cout << "dimensions: " << dimensions_SD_HO_Berggren_overlaps_table_used_memory << " Mb" << endl;
      cout << "array     : " <<            SD_HO_Berggren_overlaps_table_used_memory << " Mb" << endl;
    }

  tables_fill_dimensions_calc (TABLES_FILL , truncation_hw , truncation_ph , nmax_HO_lab_tab , cluster_particles_data_HO , cluster_particles_data);
  
#ifdef UseMPI
  MPI_helper::Barrier ();
#endif

  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const enum particle_type nucleonic_particle = cluster_particles_data.get_nucleonic_particle ();

      if (cluster != NO_PARTICLE)
	{
	  switch (nucleonic_particle)
	    {
	    case PROTON:  cout << "Proton space "  << cluster << " SD HO -> Berggren overlaps built." << endl << endl; break;
	    case NEUTRON: cout << "Neutron space " << cluster << " SD HO -> Berggren overlaps built." << endl << endl; break;

	    default: abort_all ();
	    }
	}
      else
	{
	  switch (nucleonic_particle)
	    {
	    case PROTON:  cout << "Proton space SD HO -> Berggren overlaps built." << endl << endl; break;
	    case NEUTRON: cout << "Neutron space SD HO -> Berggren overlaps built." << endl << endl; break;

	    default: abort_all ();
	    }
	}
    }
}
