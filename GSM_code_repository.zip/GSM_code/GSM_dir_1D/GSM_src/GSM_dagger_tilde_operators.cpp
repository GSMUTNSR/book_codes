#include "../GSM_include/GSM_include_def.h"

using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace correlated_state_routines;
using namespace GSM_vector_dimensions;
using namespace dagger_tilde_operators_common;










// TYPE is double or complex
// -------------------------

void dagger_tilde_operators::a_dagger_MK_table_pn_calc (
							const enum dagger_tilde_operator_type Op , 
							const class nlj_struct &shell_dagger_a_qn , 
							const class correlated_state_str &PSI_IN_qn , 
							const class correlated_state_str &PSI_OUT_qn , 
							const class GSM_vector &PSI_OUT ,
							const class array<unsigned int> &inSDp_tab ,
							const class array<unsigned int> &inSDn_tab ,
							const class array<TYPE> &PSI_IN_component_tab ,
							const class array<bool> &is_inSDp_in_new_space_tab ,
							const class array<bool> &is_inSDn_in_new_space_tab ,
							const class array<unsigned char> &reordering_bin_phases_p ,
							const class array<unsigned char> &reordering_bin_phases_n ,
							class uncoupled_dagger_tilde_table<TYPE> &a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
    
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
    
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  a_dagger_MK_table = 0.0;  
  
  if (rint (abs (MK) - j_dagger_a) > 0.0) return;
  
  const double m_dagger_a = MK;
	      
  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
	      
  if (phi_dagger_a_index == OUT_OF_RANGE) return;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_MK_tables(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_MK_tables(i).allocate (j_dagger_a);

      a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  	      
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;
 
	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_MK_table = a_dagger_MK_tables(i_thread);
  	      
	  const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);

	  if (is_phi_dagger_a_not_in_inSD_dagger_a)
	    {
	      unsigned int bin_phase_p = reordering_bin_phase_p;
	      unsigned int bin_phase_n = reordering_bin_phase_n;
	  
	      switch (Op)
		{
		case A_DAGGER_P: inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p); break;
		case A_DAGGER_N: inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n); break;
	      
		default: abort_all ();
		}

	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
	      
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);

	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				
	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

	      (bin_phase_p == bin_phase_n)
		? (a_dagger_MK_table(m_dagger_a) += PSI_IN_component*PSI_OUT_component)
		: (a_dagger_MK_table(m_dagger_a) -= PSI_IN_component*PSI_OUT_component);
				    
	    }
	}
    }
    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_MK_table += a_dagger_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}








void dagger_tilde_operators::a_tilde_MK_table_pn_calc (
						       const enum dagger_tilde_operator_type Op , 
						       const class nlj_struct &shell_tilde_a_qn , 
						       const class correlated_state_str &PSI_IN_qn , 
						       const class correlated_state_str &PSI_OUT_qn , 
						       const class GSM_vector &PSI_OUT ,
						       const class array<unsigned int> &inSDp_tab ,
						       const class array<unsigned int> &inSDn_tab ,
						       const class array<TYPE> &PSI_IN_component_tab ,
						       const class array<bool> &is_inSDp_in_new_space_tab ,
						       const class array<bool> &is_inSDn_in_new_space_tab ,
						       const class array<unsigned char> &reordering_bin_phases_p ,
						       const class array<unsigned char> &reordering_bin_phases_n ,
						       class uncoupled_dagger_tilde_table<TYPE> &a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_tilde_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();
  
  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  
  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  a_tilde_MK_table = 0.0;

  if (rint (abs (MK) - j_tilde_a) > 0.0) return;
  
  const double m_tilde_a = MK;
  
  const unsigned int phi_tilde_a_index = one_body_tilde_a_indices(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);

  if (phi_tilde_a_index == OUT_OF_RANGE) return;

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_MK_tables(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_tilde_MK_tables(i).allocate (j_tilde_a);

      a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;
 
	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_tilde_a  = SD_find (Op , 0 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_MK_table = a_tilde_MK_tables(i_thread);
  
	  const bool is_phi_tilde_a_in_inSD_tilde_a = inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index);

	  if (is_phi_tilde_a_in_inSD_tilde_a)
	    {
	      unsigned int bin_phase_p = reordering_bin_phase_p;
	      unsigned int bin_phase_n = reordering_bin_phase_n;
	  
	      switch (Op)
		{
		case A_TILDE_P: inSDp.excitation_1h_and_bin_phase (phi_tilde_a_index , outSDp , bin_phase_p); break;
		case A_TILDE_N: inSDn.excitation_1h_and_bin_phase (phi_tilde_a_index , outSDn , bin_phase_n); break;

		default: abort_all ();
		}

	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);

	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);

	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				
	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

	      (bin_phase_p == bin_phase_n)
		? (a_tilde_MK_table(m_tilde_a) += PSI_IN_component*PSI_OUT_component)
		: (a_tilde_MK_table(m_tilde_a) -= PSI_IN_component*PSI_OUT_component);
				    
	    }
	}
    }
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_MK_table += a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}











void dagger_tilde_operators::a_dagger_a_tilde_MK_table_pn_calc (
								const enum dagger_tilde_operator_type Op , 
								const class nlj_struct &shell_dagger_a_qn , 
								const class nlj_struct &shell_tilde_b_qn , 
								const class correlated_state_str &PSI_IN_qn , 
								const class correlated_state_str &PSI_OUT_qn , 
								const class GSM_vector &PSI_OUT ,
								const class array<unsigned int> &inSDp_tab ,
								const class array<unsigned int> &inSDn_tab ,
								const class array<TYPE> &PSI_IN_component_tab ,
								const class array<bool> &is_inSDp_in_new_space_tab ,
								const class array<bool> &is_inSDn_in_new_space_tab ,
								const class array<unsigned char> &reordering_bin_phases_p ,
								const class array<unsigned char> &reordering_bin_phases_n ,
								class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b  = data_find (Op , 1 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  
  const bool particle_ab_same = (particle_a == particle_b);
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b);

      a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
  
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;
 
	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b  = SD_find (Op , 1 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table = a_dagger_a_tilde_MK_tables(i_thread);
  
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;

	      const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if (phi_tilde_b_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);

		  if (is_phi_tilde_b_in_inSD_tilde_b)
		    {
		      const double m_dagger_a = MK - m_tilde_b;

		      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
			{
			  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

			  if (phi_dagger_a_index != OUT_OF_RANGE)
			    {
			      const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);

			      const bool are_phi_dagger_a_phi_tilde_b_equal = particle_ab_same && (phi_dagger_a_index == phi_tilde_b_index);

			      if (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_dagger_a_phi_tilde_b_equal)
				{
				  unsigned int bin_phase_p = reordering_bin_phase_p;
				  unsigned int bin_phase_n = reordering_bin_phase_n;
	  
				  switch (Op)
				    {
				    case A_DAGGER_A_TILDE_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;
				    case A_DAGGER_A_TILDE_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;

				    case RHO_COUPLED_REDUCED_RDM_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;
				    case RHO_COUPLED_REDUCED_RDM_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;
			      
				    case A_DAGGER_A_TILDE_NP:
				      {
					inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n);
					inSDp.excitation_1h_and_bin_phase (phi_tilde_b_index  , outSDp , bin_phase_p);
				      } break;
			    
				    case A_DAGGER_A_TILDE_PN:
				      {
					inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
					inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index  , outSDn , bin_phase_n);
				      } break;
	      
				    default: abort_all ();
				    }

				  class configuration &Cp_out = Cp_out_work_tab(i_thread);
				  class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
				  Cp_out.get_SD_configuration (phi_p_table , outSDp);
				  Cn_out.get_SD_configuration (phi_n_table , outSDn);

				  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
				  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

				  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
				  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
				  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
				  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);

				  const int iMp_out = outSDp.iM_determine (phi_p_table);
				  const int iMn_out = outSDn.iM_determine (phi_n_table);

				  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
				  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
				  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
				  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
				  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
				  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
				  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
				  class configuration &Cp_try = Cp_try_tab(i_thread);
				  class configuration &Cn_try = Cn_try_tab(i_thread);

				  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
				  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
				  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
				  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
				  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
				  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 

				  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				
				  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

				  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

				  (bin_phase_p == bin_phase_n)
				    ? (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
				    : (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
				    
				}}}}}}}}
  
  a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_MK_table += a_dagger_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
  
}










void dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pn_calc (
							      const enum dagger_tilde_operator_type Op ,
							      const class nljm_struct &phi_dagger_d , 
							      const class nljm_struct &phi_tilde_c , 
							      const class array<unsigned int> &inSDp_tab ,
							      const class array<unsigned int> &inSDn_tab ,
							      const class GSM_vector &PSI_IN ,
							      class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_d = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_c  = data_find (Op , 3 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const enum particle_type particle_d = phi_dagger_d.get_particle ();  
  const enum particle_type particle_c = phi_tilde_c.get_particle ();
  
  const int n_dagger_d = phi_dagger_d.get_n ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const int n_tilde_c = phi_tilde_c.get_n ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();
  
  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const bool particle_dc_same = (particle_d == particle_c);
  
  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  
  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
  
  const bool are_phi_dagger_d_phi_tilde_c_equal = (particle_dc_same && (phi_dagger_d_index == phi_tilde_c_index));
	  
  PSI_OUT = 0.0;
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {      
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
  
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);
 
	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
	  
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const class Slater_determinant &inSD_dagger_d = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c  = SD_find (Op , 3 , inSDp , inSDn);
  
	  const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);

	  if (is_phi_tilde_c_in_inSD_tilde_c)
	    {
	      const bool is_phi_dagger_d_not_in_inSD_dagger_d = !inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index);
		      
	      if (is_phi_dagger_d_not_in_inSD_dagger_d || are_phi_dagger_d_phi_tilde_c_equal)
		{
		  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
		  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
		  if (ZYval_IN == ZYval) outSDp = inSDp;
		  if (NYval_IN == NYval) outSDn = inSDn;
	      
		  switch (Op)
		    {
		    case G_RDM_PP: inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
		    case G_RDM_NN: inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
		  
		    case G_RDM_PN:
		      {
			inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
			inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index  , outSDp , bin_phase_p);
		      } break;
	      
		    case G_RDM_NP:
		      {
			inSDp.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDp , bin_phase_p);
			inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index  , outSDn , bin_phase_n);
		      } break;
	      
		    default: abort_all ();
		    }
	      
		  class configuration &Cp_out = Cp_out_work_tab(i_thread);
		  class configuration &Cn_out = Cn_out_work_tab(i_thread);
	  
		  Cp_out.get_SD_configuration (phi_p_table , outSDp);
		  Cn_out.get_SD_configuration (phi_n_table , outSDn);
	      
		  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
		  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

		  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
		  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
		  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
		  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
				  
		  const int iMp_out = outSDp.iM_determine (phi_p_table);
		  const int iMn_out = outSDn.iM_determine (phi_n_table);

		  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
		  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
		  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
		  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
	  
		  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
		  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
		  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
		  class configuration &Cp_try = Cp_try_tab(i_thread);
		  class configuration &Cn_try = Cn_try_tab(i_thread);
		  
		  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		  
		  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
		  
		  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try); 
		  
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
		  
		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);
		  
		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;
		  
		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
		  
#ifdef UseOpenMP
#pragma omp critical
#endif
		  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
		}
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}














void dagger_tilde_operators::a_dagger_a_dagger_MK_table_pn_calc (
								 const enum dagger_tilde_operator_type Op , 
								 const class nlj_struct &shell_dagger_a_qn , 
								 const class nlj_struct &shell_dagger_b_qn , 
								 const class correlated_state_str &PSI_IN_qn , 
								 const class correlated_state_str &PSI_OUT_qn , 
								 const class GSM_vector &PSI_OUT ,
								 const class array<unsigned int> &inSDp_tab ,
								 const class array<unsigned int> &inSDn_tab ,
								 const class array<TYPE> &PSI_IN_component_tab ,
								 const class array<bool> &is_inSDp_in_new_space_tab ,
								 const class array<bool> &is_inSDn_in_new_space_tab ,
								 const class array<unsigned char> &reordering_bin_phases_p ,
								 const class array<unsigned char> &reordering_bin_phases_n ,
								 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  
  const bool particle_ab_same = (particle_a == particle_b);
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b);

      a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_b = SD_find (Op , 1 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table = a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	    {
	      const double m_dagger_a = im_dagger_a - j_dagger_a;

	      const double m_dagger_b = MK - m_dagger_a;

	      if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
		{
		  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
		    { 
		      const bool are_phi_dagger_ab_different = (!particle_ab_same || (phi_dagger_a_index != phi_dagger_b_index));

		      if (are_phi_dagger_ab_different && !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index) && !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index))
			{	  
			  unsigned int bin_phase_p = reordering_bin_phase_p;
			  unsigned int bin_phase_n = reordering_bin_phase_n;
	  
			  switch (Op)
			    {
			    case A_DAGGER_A_DAGGER_PP: inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p); break;
			    case A_DAGGER_A_DAGGER_NN: inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n); break;
			      
			    case A_DAGGER_A_DAGGER_PN:
			      {
				inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
				inSDn.excitation_1p_and_bin_phase (phi_dagger_b_index , outSDn , bin_phase_n);
			      } break;
			    
			    default: abort_all ();
			    }
					
			  class configuration &Cp_out = Cp_out_work_tab(i_thread);
			  class configuration &Cn_out = Cn_out_work_tab(i_thread);
	      	      
			  Cp_out.get_SD_configuration (phi_p_table , outSDp);
			  Cn_out.get_SD_configuration (phi_n_table , outSDn);			

			  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
			  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
			  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
			  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
			  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
			  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
				  
			  const int iMp_out = outSDp.iM_determine (phi_p_table);
			  const int iMn_out = outSDn.iM_determine (phi_n_table);

			  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
			  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
			  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
			  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
			  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
			  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n); 

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
			  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			  class configuration &Cp_try = Cp_try_tab(i_thread);
			  class configuration &Cn_try = Cn_try_tab(i_thread);

			  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
			  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

			  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

			  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
	
			  (bin_phase_p == bin_phase_n)
			    ? (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) += PSI_IN_component*PSI_OUT_component)
			    : (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) -= PSI_IN_component*PSI_OUT_component);
				      
			}}}}}}

  a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_MK_table += a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}










void dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pn_calc (
							       const enum dagger_tilde_operator_type Op , 
							       const class nljm_struct &phi_dagger_d , 
							       const class nljm_struct &phi_dagger_c , 
							       const class array<unsigned int> &inSDp_tab ,
							       const class array<unsigned int> &inSDn_tab ,
							       const class GSM_vector &PSI_IN ,
							       class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_d = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_c = data_find (Op , 3 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const enum particle_type particle_d = phi_dagger_d.get_particle ();
  const enum particle_type particle_c = phi_dagger_c.get_particle ();
  
  const int n_dagger_d = phi_dagger_d.get_n ();
  const int n_dagger_c = phi_dagger_c.get_n ();
  
  const int l_dagger_d = phi_dagger_d.get_l ();
  const int l_dagger_c = phi_dagger_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_dagger_c = phi_dagger_c.get_j ();
  const double m_dagger_c = phi_dagger_c.get_m ();

  const bool particle_dc_same = (particle_d == particle_c);
  
  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);
		  
  const bool are_phi_dagger_dc_different = (!particle_dc_same || (phi_dagger_d_index != phi_dagger_c_index));

  PSI_OUT = 0.0;
  
  if (!are_phi_dagger_dc_different) return;
	  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const class Slater_determinant &inSD_dagger_d = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_c = SD_find (Op , 3 , inSDp , inSDn);

	  if (!inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index) && !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index))
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;

	      switch (Op)
		{
		case Q_RDM_PP: inSDp.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSDp , bin_phase_p); break;
		case Q_RDM_NN: inSDn.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSDn , bin_phase_n); break;
			    
		case Q_RDM_PN:
		  {
		    inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
		    inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
		  } break;
			    			    
		default: abort_all ();
		}
							
	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);

	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);			

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n); 

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);

	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

#endif
  
}














void dagger_tilde_operators::a_tilde_a_tilde_MK_table_pn_calc (
							       const enum dagger_tilde_operator_type Op , 
							       const class nlj_struct &shell_tilde_a_qn , 
							       const class nlj_struct &shell_tilde_b_qn , 
							       const class correlated_state_str &PSI_IN_qn , 
							       const class correlated_state_str &PSI_OUT_qn , 
							       const class GSM_vector &PSI_OUT ,
							       const class array<unsigned int> &inSDp_tab ,
							       const class array<unsigned int> &inSDn_tab ,
							       const class array<TYPE> &PSI_IN_component_tab ,
							       const class array<bool> &is_inSDp_in_new_space_tab ,
							       const class array<bool> &is_inSDn_in_new_space_tab ,
							       const class array<unsigned char> &reordering_bin_phases_p ,
							       const class array<unsigned char> &reordering_bin_phases_n ,
							       class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_tilde_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
   
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();  
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const bool particle_ab_same = (particle_a == particle_b);
  
  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b);

      a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;
 
	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_tilde_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b = SD_find (Op , 1 , inSDp , inSDn);
      
	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table = a_tilde_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	    {
	      const double m_tilde_a = im_tilde_a - j_tilde_a;
	      
	      const double m_tilde_b = MK - m_tilde_a;

	      if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
		{
		  const unsigned int phi_tilde_a_index = one_body_tilde_a_indices(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		  const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

		  if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE))
		    {
		      const bool are_phi_tilde_ab_different = (!particle_ab_same || (phi_tilde_a_index != phi_tilde_b_index));

		      if (are_phi_tilde_ab_different && inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index) && inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index))
			{
			  unsigned int bin_phase_p = reordering_bin_phase_p;
			  unsigned int bin_phase_n = reordering_bin_phase_n;
	  
			  switch (Op)
			    {
			    case A_TILDE_A_TILDE_PP: inSDp.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDp , bin_phase_p); break;			    
			    case A_TILDE_A_TILDE_NN: inSDn.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDn , bin_phase_n); break;
			    
			    case A_TILDE_A_TILDE_PN:
			      {
				inSDp.excitation_1h_and_bin_phase (phi_tilde_a_index , outSDp , bin_phase_p);
				inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDn , bin_phase_n);
			      } break;
			    
			    default: abort_all ();
			    }
							
			  class configuration &Cp_out = Cp_out_work_tab(i_thread);
			  class configuration &Cn_out = Cn_out_work_tab(i_thread);
			  
			  Cp_out.get_SD_configuration (phi_p_table , outSDp);
			  Cn_out.get_SD_configuration (phi_n_table , outSDn);

			  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
			  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
			  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
			  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
			  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
			  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			
			  const int iMp_out = outSDp.iM_determine (phi_p_table);
			  const int iMn_out = outSDn.iM_determine (phi_n_table);

			  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
			  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
			  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
			  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
			  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
			  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);
 
			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
			  
			  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				
			  class configuration &Cp_try = Cp_try_tab(i_thread);
			  class configuration &Cn_try = Cn_try_tab(i_thread);

			  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
			  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
			  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
			  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

			  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

			  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

			  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

			  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

			  (bin_phase_p == bin_phase_n)
			    ? (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			    : (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
 
			}}}}}}
  
  a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_MK_table += a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}












void dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pn_calc (
							     const enum dagger_tilde_operator_type Op , 
							     const class nljm_struct &phi_tilde_d , 
							     const class nljm_struct &phi_tilde_c , 
							     const class array<unsigned int> &inSDp_tab ,
							     const class array<unsigned int> &inSDn_tab ,
							     const class GSM_vector &PSI_IN ,
							     class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_tilde_d = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_c = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
   
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
    
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  const enum particle_type particle_c = phi_tilde_c.get_particle ();
  
  const int n_tilde_d = phi_tilde_d.get_n ();
  const int n_tilde_c = phi_tilde_c.get_n ();
    
  const int l_tilde_d = phi_tilde_d.get_l ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();
  
  const bool particle_dc_same = (particle_d == particle_c);
  
  const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
  
  const bool are_phi_tilde_dc_different = (!particle_dc_same || (phi_tilde_d_index != phi_tilde_c_index));
  
  PSI_OUT = 0.0;
  
  if (!are_phi_tilde_dc_different) return;
	  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }
  
  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);
 
	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const class Slater_determinant &inSD_tilde_d = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c = SD_find (Op , 3 , inSDp , inSDn);
      
	  if (inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index) && inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index))
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;
	      
	      switch (Op)
		{
		case P_RDM_PP: inSDp.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSDp , bin_phase_p); break;			    
		case P_RDM_NN: inSDn.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
			    
		case P_RDM_PN:
		  {
		    inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
		    inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
		  } break;
		  
		default: abort_all ();
		}
	      
	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
	      
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);
	      
	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			
	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
			  
	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);
 
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);

	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
    
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);

#endif
  
}
















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_table_pn_calc (
									 const enum dagger_tilde_operator_type Op , 
									 const class nlj_struct &shell_dagger_a_qn , 
									 const class nlj_struct &shell_dagger_b_qn , 
									 const class nlj_struct &shell_tilde_c_qn , 
									 const class correlated_state_str &PSI_IN_qn , 
									 const class correlated_state_str &PSI_OUT_qn , 
									 const class GSM_vector &PSI_OUT ,
									 const class array<unsigned int> &inSDp_tab ,
									 const class array<unsigned int> &inSDn_tab ,
									 const class array<TYPE> &PSI_IN_component_tab ,
									 const class array<bool> &is_inSDp_in_new_space_tab ,
									 const class array<bool> &is_inSDn_in_new_space_tab ,
									 const class array<unsigned char> &reordering_bin_phases_p ,
									 const class array<unsigned char> &reordering_bin_phases_n ,
									 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_b = data_find (Op , 1 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_c  = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();
  
  const bool particle_ca_same = (particle_c == particle_a);
  const bool particle_cb_same = (particle_c == particle_b);  
  const bool particle_ab_same = (particle_a == particle_b);
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c);

      a_dagger_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{	  
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_b = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c  = SD_find (Op , 2 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_MK_tables(i_thread);

	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {	  
	      const double m_tilde_c = im_tilde_c - j_tilde_c;

	      const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

	      if (phi_tilde_c_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);

		  if (is_phi_tilde_c_in_inSD_tilde_c)
		    {		  
		      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
			{
			  const double m_dagger_a = im_dagger_a - j_dagger_a;

			  const double m_dagger_b = MK - m_tilde_c - m_dagger_a;
	  			  
			  if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
			    {
			      const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
			      const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
		      
			      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
				{
				  const bool are_phi_dagger_ab_different = (!particle_ab_same || (phi_dagger_a_index != phi_dagger_b_index));

				  if (are_phi_dagger_ab_different)
				    {			  
				      const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);
				      const bool is_phi_dagger_b_not_in_inSD_dagger_b = !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index);

				      const bool no_dagger_ab_case = (is_phi_dagger_a_not_in_inSD_dagger_a && is_phi_dagger_b_not_in_inSD_dagger_b);

				      const bool are_phi_tilde_c_phi_dagger_a_equal = (particle_ca_same && (phi_tilde_c_index == phi_dagger_a_index));
				      const bool are_phi_tilde_c_phi_dagger_b_equal = (particle_cb_same && (phi_tilde_c_index == phi_dagger_b_index));

				      const bool phi_tilde_c_phi_dagger_a_equal_case = (are_phi_tilde_c_phi_dagger_a_equal && is_phi_dagger_b_not_in_inSD_dagger_b);
				      const bool phi_tilde_c_phi_dagger_b_equal_case = (are_phi_tilde_c_phi_dagger_b_equal && is_phi_dagger_a_not_in_inSD_dagger_a);				  

				      if (no_dagger_ab_case || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_c_phi_dagger_b_equal_case)
					{				      
					  unsigned int bin_phase_p = reordering_bin_phase_p;
					  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
					  switch (Op)
					    { 
					    case A_DAGGER_A_DAGGER_A_TILDE_PPP: inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
					    case A_DAGGER_A_DAGGER_A_TILDE_NNN: inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				  
					    case A_DAGGER_A_DAGGER_A_TILDE_PPN:
					      {
						inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
						inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p);
					      } break;
				      
					    case A_DAGGER_A_DAGGER_A_TILDE_PNN:
					      {
						inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_b_index , phi_tilde_c_index , outSDn , bin_phase_n);
						inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
					      } break;				  

					    case A_DAGGER_A_DAGGER_A_TILDE_PNP:
					      {
						inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , outSDp , bin_phase_p);
						inSDn.excitation_1p_and_bin_phase (phi_dagger_b_index , outSDn , bin_phase_n);
					      } break;				  
				  
					    case A_DAGGER_A_DAGGER_A_TILDE_NNP:
					      {
						inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
						inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n);
					      } break;
				      				  
					    default: abort_all ();
					    }							
					  
					  class configuration &Cp_out = Cp_out_work_tab(i_thread);
					  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
					  Cp_out.get_SD_configuration (phi_p_table , outSDp);
					  Cn_out.get_SD_configuration (phi_n_table , outSDn);
					  
					  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
					  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
					  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
					  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
					  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
					  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
					  const int iMp_out = outSDp.iM_determine (phi_p_table);
					  const int iMn_out = outSDn.iM_determine (phi_n_table);

					  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
					  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
					  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
					  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

					  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
					  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);
					  
					  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
					  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
					  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
					  class configuration &Cp_try = Cp_try_tab(i_thread);
					  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
					  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
					  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
					  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
					  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  					  
					  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
					  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

					  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

					  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

					  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

					  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
					  
					  (bin_phase_p == bin_phase_n)
					    ? (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
					    : (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);
					  
					}}}}}}}}}}
  
  a_dagger_a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pn_calc (
								       const enum dagger_tilde_operator_type Op ,  
								       const class nljm_struct &phi_dagger_f , 
								       const class nljm_struct &phi_dagger_e , 
								       const class nljm_struct &phi_tilde_d , 
								       const class array<unsigned int> &inSDp_tab ,
								       const class array<unsigned int> &inSDn_tab ,
								       const class GSM_vector &PSI_IN ,
								       class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_f = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_e = data_find (Op , 4 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_d  = data_find (Op , 5 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_e_indices = data_dagger_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_dagger_e.get_particle (); 
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();  
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();
  
  const bool particle_df_same = (particle_d == particle_f);
  const bool particle_de_same = (particle_d == particle_e);  
  const bool particle_fe_same = (particle_f == particle_e);
  
  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(particle_f , n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_dagger_e_indices(particle_e , n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_tilde_d_index  = one_body_tilde_d_indices (particle_d , n_tilde_d  , l_tilde_d  , j_tilde_d  ,-m_tilde_d);
		      
  const bool are_phi_dagger_fe_different = (!particle_fe_same || (phi_dagger_f_index != phi_dagger_e_index));

  PSI_OUT = 0.0;
  
  if (!are_phi_dagger_fe_different) return;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
	  const class Slater_determinant &inSD_dagger_f = SD_find (Op , 3 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_e = SD_find (Op , 4 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_d  = SD_find (Op , 5 , inSDp , inSDn);
	  
	  const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);

	  if (is_phi_tilde_d_in_inSD_tilde_d)
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	      
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;
	  
	      const bool is_phi_dagger_f_not_in_inSD_dagger_f = !inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index);
	      const bool is_phi_dagger_e_not_in_inSD_dagger_e = !inSD_dagger_e.is_valence_state_occupied (phi_dagger_e_index);

	      const bool no_dagger_fe_case = (is_phi_dagger_f_not_in_inSD_dagger_f && is_phi_dagger_e_not_in_inSD_dagger_e);

	      const bool are_phi_tilde_d_phi_dagger_f_equal = (particle_df_same && (phi_tilde_d_index == phi_dagger_f_index));
	      const bool are_phi_tilde_d_phi_dagger_e_equal = (particle_de_same && (phi_tilde_d_index == phi_dagger_e_index));

	      const bool phi_tilde_d_phi_dagger_f_equal_case = (are_phi_tilde_d_phi_dagger_f_equal && is_phi_dagger_e_not_in_inSD_dagger_e);
	      const bool phi_tilde_d_phi_dagger_e_equal_case = (are_phi_tilde_d_phi_dagger_e_equal && is_phi_dagger_f_not_in_inSD_dagger_f);				  

	      if (no_dagger_fe_case || phi_tilde_d_phi_dagger_f_equal_case || phi_tilde_d_phi_dagger_e_equal_case)
		{
		  switch (Op)
		    { 
		    case T2_2_RDM_PPP: inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;
		    case T2_2_RDM_NNN: inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;
		  
		    case T2_2_RDM_PPN:
		      {
			inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
			inSDp.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDp , bin_phase_p);
		      } break;
				      
		    case T2_2_RDM_PNN:
		      {
			inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
			inSDp.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDp , bin_phase_p);
		      } break;				  

		    case T2_2_RDM_PNP:
		      {
			inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_d_index , outSDp , bin_phase_p);
			inSDn.excitation_1p_and_bin_phase (phi_dagger_e_index , outSDn , bin_phase_n);
		      } break;				  
				  
		    case T2_2_RDM_NNP:
		      {
			inSDp.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDp , bin_phase_p);
			inSDn.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDn , bin_phase_n);
		      } break;
				  
		    default: abort_all ();
		    }
										      
		  class configuration &Cp_out = Cp_out_work_tab(i_thread);
		  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
		  Cp_out.get_SD_configuration (phi_p_table , outSDp);
		  Cn_out.get_SD_configuration (phi_n_table , outSDn);

		  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
		  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
		  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
		  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
		  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
		  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
		  const int iMp_out = outSDp.iM_determine (phi_p_table);
		  const int iMn_out = outSDn.iM_determine (phi_n_table);

		  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
		  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
		  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
		  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

		  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
		  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		  
		  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
		  class configuration &Cp_try = Cp_try_tab(i_thread);
		  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
		  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
		  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  
		  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
		  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
		}}}}
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}






















void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_table_pn_calc (
									const enum dagger_tilde_operator_type Op , 
									const class nlj_struct &shell_dagger_a_qn , 
									const class nlj_struct &shell_tilde_b_qn , 
									const class nlj_struct &shell_tilde_c_qn , 
									const class correlated_state_str &PSI_IN_qn , 
									const class correlated_state_str &PSI_OUT_qn , 
									const class GSM_vector &PSI_OUT ,
									const class array<unsigned int> &inSDp_tab ,
									const class array<unsigned int> &inSDn_tab ,
									const class array<TYPE> &PSI_IN_component_tab ,
									const class array<bool> &is_inSDp_in_new_space_tab ,
									const class array<bool> &is_inSDn_in_new_space_tab ,
									const class array<unsigned char> &reordering_bin_phases_p ,
									const class array<unsigned char> &reordering_bin_phases_n ,
									class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_a  = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b   = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_c   = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();

  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();
    
  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();
  
  const bool particle_ab_same = (particle_a == particle_b);
  const bool particle_ac_same = (particle_a == particle_c);
  const bool particle_bc_same = (particle_b == particle_c);
  
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_tilde_c);

      a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
        
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;
	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  const class Slater_determinant &inSD_dagger_a  = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b   = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c   = SD_find (Op , 2 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_tilde_a_tilde_MK_tables(i_thread);
      
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;
	  
	      const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		      
	      if (phi_tilde_b_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);

		  if (is_phi_tilde_b_in_inSD_tilde_b)
		    {			      
		      for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
			{
			  const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
			  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

			  if (phi_tilde_c_index != OUT_OF_RANGE)
			    {
			      const bool are_phi_tilde_bc_different = (!particle_bc_same || (phi_tilde_b_index != phi_tilde_c_index));

			      if (are_phi_tilde_bc_different)
				{
				  const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);

				  if (is_phi_tilde_c_in_inSD_tilde_c)
				    {				  
				      const double m_dagger_a = MK - m_tilde_b - m_tilde_c;
	  
				      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
					{	      
					  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		      
					  if (phi_dagger_a_index != OUT_OF_RANGE)
					    {
					      const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);

					      const bool are_phi_dagger_a_phi_tilde_b_equal = (particle_ab_same && (phi_dagger_a_index == phi_tilde_b_index));
					      const bool are_phi_dagger_a_phi_tilde_c_equal = (particle_ac_same && (phi_dagger_a_index == phi_tilde_c_index));

					      if (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_dagger_a_phi_tilde_b_equal || are_phi_dagger_a_phi_tilde_c_equal)
						{
						  unsigned int bin_phase_p = reordering_bin_phase_p;
						  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
						  switch (Op)
						    { 
						    case A_DAGGER_A_TILDE_A_TILDE_PPP: inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
						    case A_DAGGER_A_TILDE_A_TILDE_NNN: inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				    
						    case A_DAGGER_A_TILDE_A_TILDE_PPN:
						      {
							inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p);
							inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_TILDE_NPP:
						      {
							inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n);
							inSDp.excitation_2h_and_bin_phase (phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p);
						      } break;
				  
						    case A_DAGGER_A_TILDE_A_TILDE_PNN:
						      {
							inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
							inSDn.excitation_2h_and_bin_phase (phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_TILDE_NPN:
						      {
							inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , outSDn , bin_phase_n);
							inSDp.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDp , bin_phase_p);
						      } break;
				      				      
						    default: abort_all ();
						    }

						  class configuration &Cp_out = Cp_out_work_tab(i_thread);
						  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
						  Cp_out.get_SD_configuration (phi_p_table , outSDp);
						  Cn_out.get_SD_configuration (phi_n_table , outSDn);

						  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
						  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
						  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
						  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
						  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
						  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
						  const int iMp_out = outSDp.iM_determine (phi_p_table);
						  const int iMn_out = outSDn.iM_determine (phi_n_table);

						  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
						  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
						  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
						  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			      
						  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
						  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
						  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
						  class configuration &Cp_try = Cp_try_tab(i_thread);
						  class configuration &Cn_try = Cn_try_tab(i_thread);

						  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
						  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
						  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
						  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
						  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
						  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

						  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				      
						  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

						  (bin_phase_p == bin_phase_n)
						    ? (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component)
						    : (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}

  a_dagger_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}










void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc (
								      const enum dagger_tilde_operator_type Op ,
								      const class nljm_struct &phi_dagger_f , 
								      const class nljm_struct &phi_tilde_e , 
								      const class nljm_struct &phi_tilde_d ,
								      const class array<unsigned int> &inSDp_tab ,
								      const class array<unsigned int> &inSDn_tab ,
								      const class GSM_vector &PSI_IN ,
								      class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_dagger_f  = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_e   = data_find (Op , 4 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_d   = data_find (Op , 5 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();

  const class one_body_indices_str &one_body_tilde_e_indices = data_tilde_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
    
  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_tilde_e.get_particle ();
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_tilde_e  = phi_tilde_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_tilde_e  = phi_tilde_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_tilde_e  = phi_tilde_e.get_j ();
  const double m_tilde_e  = phi_tilde_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const bool particle_fe_same = (particle_f == particle_e);
  const bool particle_fd_same = (particle_f == particle_d);
  const bool particle_ed_same = (particle_e == particle_d);
  
  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(particle_f , n_dagger_f , l_dagger_f , j_dagger_f ,  m_dagger_f);
  const unsigned int phi_tilde_e_index  = one_body_tilde_e_indices (particle_e , n_tilde_e  , l_tilde_e  , j_tilde_e  , -m_tilde_e);
  const unsigned int phi_tilde_d_index  = one_body_tilde_d_indices (particle_d , n_tilde_d  , l_tilde_d  , j_tilde_d  , -m_tilde_d);
		      
  const bool are_phi_tilde_ed_different = (!particle_ed_same || (phi_tilde_e_index != phi_tilde_d_index));
  
  PSI_OUT = 0.0;
  
  if (!are_phi_tilde_ed_different) return;			    
  
  const bool are_phi_dagger_f_phi_tilde_e_equal = (particle_fe_same && (phi_dagger_f_index == phi_tilde_e_index));
  const bool are_phi_dagger_f_phi_tilde_d_equal = (particle_fd_same && (phi_dagger_f_index == phi_tilde_d_index));
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
    
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);
      
      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
        
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);
	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const class Slater_determinant &inSD_dagger_f  = SD_find (Op , 3 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_e   = SD_find (Op , 4 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_d   = SD_find (Op , 5 , inSDp , inSDn);

	  const bool is_phi_tilde_e_in_inSD_tilde_e = inSD_tilde_e.is_valence_state_occupied (phi_tilde_e_index);
	  const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);

	  if (is_phi_tilde_e_in_inSD_tilde_e && is_phi_tilde_d_in_inSD_tilde_d)
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;
	  
	      const bool is_phi_dagger_f_not_in_inSD_dagger_f = !inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index);
	      
	      if (is_phi_dagger_f_not_in_inSD_dagger_f || are_phi_dagger_f_phi_tilde_e_equal || are_phi_dagger_f_phi_tilde_d_equal)
		{
		  switch (Op)
		    { 
		    case T2_1_RDM_PPP: inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;
		    case T2_1_RDM_NNN: inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;				    
				      
		    case T2_1_RDM_PPN:
		      {
			inSDn.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDn , bin_phase_n);
			inSDp.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p);
		      } break;
				  
		    case T2_1_RDM_NNP:
		      {
			inSDp.excitation_1p_and_bin_phase (phi_dagger_f_index , outSDp , bin_phase_p);
			inSDn.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
		      } break;
				      
		    case T2_1_RDM_PNN:
		      {
			inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , outSDn , bin_phase_n);
			inSDp.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDp , bin_phase_p);
		      } break;				  				
				  
		    case T2_1_RDM_PNP:
		      {
			inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_f_index , phi_tilde_d_index , outSDp , bin_phase_p);
			inSDn.excitation_1h_and_bin_phase (phi_tilde_e_index , outSDn , bin_phase_n);
		      } break;
		      
		    default: abort_all ();
		    }

		  class configuration &Cp_out = Cp_out_work_tab(i_thread);
		  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
		  Cp_out.get_SD_configuration (phi_p_table , outSDp);
		  Cn_out.get_SD_configuration (phi_n_table , outSDn);

		  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
		  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
		  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
		  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
		  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
		  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
		  const int iMp_out = outSDp.iM_determine (phi_p_table);
		  const int iMn_out = outSDn.iM_determine (phi_n_table);

		  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
		  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
		  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
		  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n);
			      
		  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
		  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
		  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			
		  class configuration &Cp_try = Cp_try_tab(i_thread);
		  class configuration &Cn_try = Cn_try_tab(i_thread);

		  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
		  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
		  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
		  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
		  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
		  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
				      
		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
		  (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
		}}}}
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}















void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_table_pn_calc (
									  const enum dagger_tilde_operator_type Op , 
									  const class nlj_struct &shell_dagger_a_qn , 
									  const class nlj_struct &shell_dagger_b_qn ,
									  const class nlj_struct &shell_dagger_c_qn ,  
									  const class correlated_state_str &PSI_IN_qn , 
									  const class correlated_state_str &PSI_OUT_qn , 
									  const class GSM_vector &PSI_OUT ,
									  const class array<unsigned int> &inSDp_tab ,
									  const class array<unsigned int> &inSDn_tab ,
									  const class array<TYPE> &PSI_IN_component_tab ,
									  const class array<bool> &is_inSDp_in_new_space_tab ,
									  const class array<bool> &is_inSDn_in_new_space_tab ,
									  const class array<unsigned char> &reordering_bin_phases_p ,
									  const class array<unsigned char> &reordering_bin_phases_n ,
									  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_b = data_find (Op , 1 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_dagger_c = data_find (Op , 2 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();
  
  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();  
  const int l_dagger_c = shell_dagger_c_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  
  const bool particle_ab_same = (particle_a == particle_b);
  const bool particle_ac_same = (particle_a == particle_c);
  const bool particle_bc_same = (particle_b == particle_c);
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_dagger_c);

      a_dagger_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_b = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_c = SD_find (Op , 2 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table = a_dagger_a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	    {
	      const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	      const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		      
	      if (phi_dagger_a_index != OUT_OF_RANGE)
		{
		  const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);
		  
		  if (is_phi_dagger_a_not_in_inSD_dagger_a)
		    {		      		      
		      for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
			{
			  const double m_dagger_b = im_dagger_b - j_dagger_b;

			  const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
			  
			  const bool are_phi_dagger_ab_different = (!particle_ab_same || (phi_dagger_a_index != phi_dagger_b_index));
			  
			  if (are_phi_dagger_ab_different)
			    {
			      const bool is_phi_dagger_b_not_in_inSD_dagger_b = !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index);
		  
			      if (is_phi_dagger_b_not_in_inSD_dagger_b)
				{
				  const double m_dagger_c = MK - m_dagger_a - m_dagger_b;
	  
				  if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
				    {
				      const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

				      if (phi_dagger_c_index != OUT_OF_RANGE)
					{
					  const bool are_phi_dagger_ac_different = (!particle_ac_same || (phi_dagger_a_index != phi_dagger_c_index));
					  const bool are_phi_dagger_bc_different = (!particle_bc_same || (phi_dagger_b_index != phi_dagger_c_index));

					  if (are_phi_dagger_ac_different && are_phi_dagger_bc_different)
					    {
					      const bool is_phi_dagger_c_not_in_inSD_dagger_c = !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index);
		  
					      if (is_phi_dagger_c_not_in_inSD_dagger_c)
						{
						  unsigned int bin_phase_p = reordering_bin_phase_p;
						  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
						  switch (Op)
						    { 
						    case A_DAGGER_A_DAGGER_A_DAGGER_PPP: inSDp.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSDp , bin_phase_p); break;
						    case A_DAGGER_A_DAGGER_A_DAGGER_NNN: inSDn.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSDn , bin_phase_n); break;
				  
						    case A_DAGGER_A_DAGGER_A_DAGGER_PPN:
						      {
							inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p);
							inSDn.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDn , bin_phase_n);
						      } break;
				  				  
						    case A_DAGGER_A_DAGGER_A_DAGGER_NNP:
						      {
							inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n);
							inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
						      } break;
				  
						    default: abort_all ();
						    }
									
						  class configuration &Cp_out = Cp_out_work_tab(i_thread);
						  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
						  Cp_out.get_SD_configuration (phi_p_table , outSDp);
						  Cn_out.get_SD_configuration (phi_n_table , outSDn);

						  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
						  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
						  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
						  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
						  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
						  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
						  const int iMp_out = outSDp.iM_determine (phi_p_table);
						  const int iMn_out = outSDn.iM_determine (phi_n_table);

						  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
						  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
						  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
						  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

						  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
						  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
						  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
						  class configuration &Cp_try = Cp_try_tab(i_thread);
						  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
						  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
						  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
						  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
						  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
						  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
						  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

						  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

						  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

						  (bin_phase_p == bin_phase_n)
						    ? (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) += PSI_IN_component*PSI_OUT_component) 
						    : (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) -= PSI_IN_component*PSI_OUT_component);
					  
						}}}}}}}}}}}}
  
  a_dagger_a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_dagger_MK_table += a_dagger_a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}










void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pn_calc (
									const enum dagger_tilde_operator_type Op ,
									const class nljm_struct &phi_dagger_f , 
									const class nljm_struct &phi_dagger_e ,
									const class nljm_struct &phi_dagger_d ,  
									const class array<unsigned int> &inSDp_tab ,
									const class array<unsigned int> &inSDn_tab ,
									const class GSM_vector &PSI_IN ,
									class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_f = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_e = data_find (Op , 4 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_dagger_d = data_find (Op , 5 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_dagger_f_indices = data_dagger_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_e_indices = data_dagger_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_dagger_e.get_particle ();
  const enum particle_type particle_d = phi_dagger_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_dagger_d = phi_dagger_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();  
  const int l_dagger_d = phi_dagger_d.get_l ();  
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const bool particle_fe_same = (particle_f == particle_e);
  const bool particle_fd_same = (particle_f == particle_d);
  const bool particle_ed_same = (particle_e == particle_d);
  
  const unsigned int phi_dagger_f_index = one_body_dagger_f_indices(particle_f , n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_dagger_e_indices(particle_e , n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
		      
  const bool are_phi_dagger_fe_different = (!particle_fe_same || (phi_dagger_f_index != phi_dagger_e_index));
  const bool are_phi_dagger_fd_different = (!particle_fd_same || (phi_dagger_f_index != phi_dagger_d_index));
  const bool are_phi_dagger_ed_different = (!particle_ed_same || (phi_dagger_e_index != phi_dagger_d_index));

  PSI_OUT = 0.0;
  
  if (!are_phi_dagger_fe_different || !are_phi_dagger_fd_different || !are_phi_dagger_ed_different) return;
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);
	  
	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
	  const class Slater_determinant &inSD_dagger_f = SD_find (Op , 3 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_e = SD_find (Op , 4 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_d = SD_find (Op , 5 , inSDp , inSDn);

	  if (!inSD_dagger_f.is_valence_state_occupied (phi_dagger_f_index) &&
	      !inSD_dagger_e.is_valence_state_occupied (phi_dagger_e_index) &&
	      !inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index))
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;
	  
	      switch (Op)
		{ 
		case T1_2_RDM_PPP: inSDp.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSDp , bin_phase_p); break;
		case T1_2_RDM_NNN: inSDn.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSDn , bin_phase_n); break;
				  
		case T1_2_RDM_PPN:
		  {
		    inSDp.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDp , bin_phase_p);
		    inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
		  } break;
				  				  
		case T1_2_RDM_NNP:
		  {
		    inSDn.excitation_2p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , outSDn , bin_phase_n);
		    inSDp.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDp , bin_phase_p);
		  } break;
				  
		default: abort_all ();
		}
									
	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);

	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}














void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_table_pn_calc (
								       const enum dagger_tilde_operator_type Op , 
								       const class nlj_struct &shell_tilde_a_qn , 
								       const class nlj_struct &shell_tilde_b_qn , 
								       const class nlj_struct &shell_tilde_c_qn , 
								       const class correlated_state_str &PSI_IN_qn , 
								       const class correlated_state_str &PSI_OUT_qn , 
								       const class GSM_vector &PSI_OUT ,
								       const class array<unsigned int> &inSDp_tab ,
								       const class array<unsigned int> &inSDn_tab ,
								       const class array<TYPE> &PSI_IN_component_tab ,
								       const class array<bool> &is_inSDp_in_new_space_tab ,
								       const class array<bool> &is_inSDn_in_new_space_tab ,
								       const class array<unsigned char> &reordering_bin_phases_p ,
								       const class array<unsigned char> &reordering_bin_phases_n ,
								       class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_tilde_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b = data_find (Op , 1 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_c = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  
  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();
  
  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();  
  const int l_tilde_c = shell_tilde_c_qn.get_l ();  
  
  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();
  
  const bool particle_ab_same = (particle_a == particle_b);
  const bool particle_ac_same = (particle_a == particle_c);
  const bool particle_bc_same = (particle_b == particle_c);
  
  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_tilde_a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_tilde_c);

      a_tilde_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_tilde_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c = SD_find (Op , 2 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table = a_tilde_a_tilde_a_tilde_MK_tables(i_thread);

	  for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	    {
	      const double m_tilde_a = im_tilde_a - j_tilde_a;
	  
	      const unsigned int phi_tilde_a_index = one_body_tilde_a_indices(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		      
	      if (phi_tilde_a_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_a_in_inSD_tilde_a = inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index);
		  
		  if (is_phi_tilde_a_in_inSD_tilde_a)
		    {		      
		      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
			{
			  const double m_tilde_b = im_tilde_b - j_tilde_b;

			  const unsigned int phi_tilde_b_index = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
			  
			  if (phi_tilde_b_index != OUT_OF_RANGE)
			    {
			      const bool are_phi_tilde_ab_different = (!particle_ab_same || (phi_tilde_a_index != phi_tilde_b_index));
			      
			      if (are_phi_tilde_ab_different)
				{
				  const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);
		  
				  if (is_phi_tilde_b_in_inSD_tilde_b)
				    {		      
				      const double m_tilde_c = MK - m_tilde_a - m_tilde_b;
	  
				      if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
					{
					  const unsigned int phi_tilde_c_index = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

					  if (phi_tilde_c_index != OUT_OF_RANGE)
					    {
					      const bool are_phi_tilde_ac_different = (!particle_ac_same || (phi_tilde_a_index != phi_tilde_c_index));
					      const bool are_phi_tilde_bc_different = (!particle_bc_same || (phi_tilde_b_index != phi_tilde_c_index));

					      if (are_phi_tilde_ac_different && are_phi_tilde_bc_different)
						{						  
						  const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);
		  
						  if (is_phi_tilde_c_in_inSD_tilde_c)
						    {	
						      unsigned int bin_phase_p = reordering_bin_phase_p;
						      unsigned int bin_phase_n = reordering_bin_phase_n;
			  
						      switch (Op)
							{ 
							case A_TILDE_A_TILDE_A_TILDE_PPP: inSDp.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDp , bin_phase_p); break;
							case A_TILDE_A_TILDE_A_TILDE_NNN: inSDn.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSDn , bin_phase_n); break;
				  
							case A_TILDE_A_TILDE_A_TILDE_PPN:
							  {
							    inSDp.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDp , bin_phase_p);
							    inSDn.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDn , bin_phase_n);
							  } break;
				  				  
							case A_TILDE_A_TILDE_A_TILDE_NNP:
							  {
							    inSDn.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSDn , bin_phase_n);
							    inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
							  } break;
				      				  
							default: abort_all ();
							}
									
						      class configuration &Cp_out = Cp_out_work_tab(i_thread);
						      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
						      Cp_out.get_SD_configuration (phi_p_table , outSDp);
						      Cn_out.get_SD_configuration (phi_n_table , outSDn);

						      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
						      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
						      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
						      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
						      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
						      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
						      const int iMp_out = outSDp.iM_determine (phi_p_table);
						      const int iMn_out = outSDn.iM_determine (phi_n_table);

						      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
						      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
						      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
						      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

						      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
						      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

						      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
						      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
						      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
						      class configuration &Cp_try = Cp_try_tab(i_thread);
						      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
						      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
						      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
						      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
						      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
						      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
						      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

						      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

						      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

						      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

						      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

						      (bin_phase_p == bin_phase_n)
							? (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
							: (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);
					  
						    }}}}}}}}}}}}}
  
  a_tilde_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_tilde_MK_table += a_tilde_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}













void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pn_calc (
								     const enum dagger_tilde_operator_type Op , 
								     const class nljm_struct &phi_tilde_f, 
								     const class nljm_struct &phi_tilde_e , 
								     const class nljm_struct &phi_tilde_d , 
								     const class array<unsigned int> &inSDp_tab ,
								     const class array<unsigned int> &inSDn_tab ,
								     const class GSM_vector &PSI_IN ,
								     class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_tilde_f = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_e = data_find (Op , 4 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_d = data_find (Op , 5 , prot_Y_data , neut_Y_data);

  const class one_body_indices_str &one_body_tilde_f_indices = data_tilde_f.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_e_indices = data_tilde_e.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const enum particle_type particle_f = phi_tilde_f.get_particle ();
  const enum particle_type particle_e = phi_tilde_e.get_particle ();
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
	  
  const int n_tilde_f = phi_tilde_f.get_n ();
  const int n_tilde_e = phi_tilde_e.get_n ();
  const int n_tilde_d = phi_tilde_d.get_n ();
  
  const int l_tilde_f = phi_tilde_f.get_l ();
  const int l_tilde_e = phi_tilde_e.get_l ();  
  const int l_tilde_d = phi_tilde_d.get_l ();  
  
  const double j_tilde_f = phi_tilde_f.get_j ();
  const double m_tilde_f = phi_tilde_f.get_m ();
  
  const double j_tilde_e = phi_tilde_e.get_j ();
  const double m_tilde_e = phi_tilde_e.get_m ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const bool particle_fe_same = (particle_f == particle_e);
  const bool particle_fd_same = (particle_f == particle_d);
  const bool particle_ed_same = (particle_e == particle_d);
  
  const unsigned int phi_tilde_f_index = one_body_tilde_f_indices(particle_f , n_tilde_f , l_tilde_f , j_tilde_f , -m_tilde_f);
  const unsigned int phi_tilde_e_index = one_body_tilde_e_indices(particle_e , n_tilde_e , l_tilde_e , j_tilde_e , -m_tilde_e);
  const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
		      
  const bool are_phi_tilde_fe_different = (!particle_fe_same || (phi_tilde_f_index != phi_tilde_e_index));
  const bool are_phi_tilde_fd_different = (!particle_fd_same || (phi_tilde_f_index != phi_tilde_d_index));
  const bool are_phi_tilde_ed_different = (!particle_ed_same || (phi_tilde_e_index != phi_tilde_d_index));

  PSI_OUT = 0.0;
  
  if (!are_phi_tilde_fe_different || !are_phi_tilde_fd_different || !are_phi_tilde_ed_different) return;
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);

  PSI_OUT = 0.0;
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  unsigned int bin_phase_p = 0;
	  unsigned int bin_phase_n = 0;
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
	  const class Slater_determinant &inSD_tilde_f = SD_find (Op , 3 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_e = SD_find (Op , 4 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_d = SD_find (Op , 5 , inSDp , inSDn);

	  if (inSD_tilde_f.is_valence_state_occupied (phi_tilde_f_index) &&
	      inSD_tilde_e.is_valence_state_occupied (phi_tilde_e_index) &&
	      inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index))
	    {
	      class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	      class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	      if (ZYval_IN == ZYval) outSDp = inSDp;
	      if (NYval_IN == NYval) outSDn = inSDn;	      
	      
	      switch (Op)
		{ 				  
		case T1_1_RDM_PPP: inSDp.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p); break;		      
		case T1_1_RDM_NNN: inSDn.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n); break;
				  
		case T1_1_RDM_PPN:
		  {
		    inSDp.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDp , bin_phase_p);
		    inSDn.excitation_1h_and_bin_phase (phi_tilde_f_index , outSDn , bin_phase_n);
		  } break;
				  				  
		case T1_1_RDM_NNP:
		  {
		    inSDn.excitation_2h_and_bin_phase (phi_tilde_e_index , phi_tilde_d_index , outSDn , bin_phase_n);
		    inSDp.excitation_1h_and_bin_phase (phi_tilde_f_index , outSDp , bin_phase_p);
		  } break;
				  
		default: abort_all ();
		}
	      
	      class configuration &Cp_out = Cp_out_work_tab(i_thread);
	      class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
	      Cp_out.get_SD_configuration (phi_p_table , outSDp);
	      Cn_out.get_SD_configuration (phi_n_table , outSDn);
	      
	      const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
	      const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);

	      const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
	      const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
	      const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
	      const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
	      const int iMp_out = outSDp.iM_determine (phi_p_table);
	      const int iMn_out = outSDn.iM_determine (phi_n_table);

	      const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
	      const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
	      const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
	      const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

	      const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
	      const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
	      class configuration &Cp_try = Cp_try_tab(i_thread);
	      class configuration &Cn_try = Cn_try_tab(i_thread);
					  
	      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
	      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
	      const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	      const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
				      
	      const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
	      const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);
		      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (bin_phase_p == bin_phase_n) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);
				    
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}






void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_a_tilde_MK_table_pn_calc (
										 const enum dagger_tilde_operator_type Op , 
										 const class nlj_struct &shell_dagger_a_qn , 
										 const class nlj_struct &shell_dagger_b_qn , 
										 const class nlj_struct &shell_tilde_c_qn , 
										 const class nlj_struct &shell_tilde_d_qn , 
										 const class correlated_state_str &PSI_IN_qn , 
										 const class correlated_state_str &PSI_OUT_qn , 
										 const class GSM_vector &PSI_OUT ,
										 const class array<unsigned int> &inSDp_tab ,
										 const class array<unsigned int> &inSDn_tab ,
										 const class array<TYPE> &PSI_IN_component_tab ,
										 const class array<bool> &is_inSDp_in_new_space_tab ,
										 const class array<bool> &is_inSDn_in_new_space_tab ,
										 const class array<unsigned char> &reordering_bin_phases_p ,
										 const class array<unsigned char> &reordering_bin_phases_n ,
										 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_b = data_find (Op , 1 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_c  = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_d  = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  
  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle ();
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  const enum particle_type particle_d = shell_tilde_d_qn.get_particle ();

  const bool particle_ca_same = (particle_c == particle_a);
  const bool particle_cb_same = (particle_c == particle_b);
  const bool particle_da_same = (particle_d == particle_a);
  const bool particle_db_same = (particle_d == particle_b);  
  const bool particle_ab_same = (particle_a == particle_b);  
  const bool particle_cd_same = (particle_c == particle_d);

  const class one_body_indices_str &one_body_tilde_c_indices = data_tilde_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_b_indices = data_dagger_b.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  const int n_tilde_d  = shell_tilde_d_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();  
  const int l_tilde_d  = shell_tilde_d_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();
  const double j_tilde_d  = shell_tilde_d_qn.get_j ();
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();

  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  const int m_tilde_d_number = shell_tilde_d_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c , j_tilde_d);

      a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_b = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_c  = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_d  = SD_find (Op , 3 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i_thread);

	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {
	      const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
	      const unsigned int phi_tilde_c_index  = one_body_tilde_c_indices(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
	      
	      if (phi_tilde_c_index != OUT_OF_RANGE)
		{	
		  const bool is_phi_tilde_c_in_inSD_tilde_c = inSD_tilde_c.is_valence_state_occupied (phi_tilde_c_index);
				  
		  if (is_phi_tilde_c_in_inSD_tilde_c)
		    {
		      for (int im_tilde_d = 0 ; im_tilde_d < m_tilde_d_number ; im_tilde_d++)
			{
			  const double m_tilde_d = im_tilde_d - j_tilde_d;

			  const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);

			  if (phi_tilde_d_index != OUT_OF_RANGE)
			    {		  
			      const bool are_phi_tilde_cd_different = (!particle_cd_same || (phi_tilde_c_index != phi_tilde_d_index));
			      
			      if (are_phi_tilde_cd_different)
				{
				  const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);

				  if (is_phi_tilde_d_in_inSD_tilde_d)
				    {
				      const int Mcd = make_int (m_tilde_c + m_tilde_d);
			  
				      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
					{
					  const double m_dagger_a = im_dagger_a - j_dagger_a;
		  		      
					  const double m_dagger_b = MK - Mcd - m_dagger_a;
	  
					  if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
					    {
					      const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
					      const unsigned int phi_dagger_b_index = one_body_dagger_b_indices(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

					      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE))
						{			      
						  const bool are_phi_dagger_ab_different = (!particle_ab_same || (phi_dagger_a_index != phi_dagger_b_index));
			      			      
						  if (are_phi_dagger_ab_different)
						    {				      
						      const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);
						      const bool is_phi_dagger_b_not_in_inSD_dagger_b = !inSD_dagger_b.is_valence_state_occupied (phi_dagger_b_index);

						      const bool are_phi_tilde_c_phi_dagger_a_equal = (particle_ca_same && (phi_tilde_c_index == phi_dagger_a_index));
						      const bool are_phi_tilde_d_phi_dagger_a_equal = (particle_da_same && (phi_tilde_d_index == phi_dagger_a_index));
						      const bool are_phi_tilde_c_phi_dagger_b_equal = (particle_cb_same && (phi_tilde_c_index == phi_dagger_b_index));
						      const bool are_phi_tilde_d_phi_dagger_b_equal = (particle_db_same && (phi_tilde_d_index == phi_dagger_b_index));
				      
						      const bool phi_tilde_c_phi_dagger_b_equal_case = (are_phi_tilde_c_phi_dagger_b_equal && (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_tilde_d_phi_dagger_a_equal));
						      const bool phi_tilde_d_phi_dagger_b_equal_case = (are_phi_tilde_d_phi_dagger_b_equal && (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_tilde_c_phi_dagger_a_equal));
						      const bool phi_tilde_c_phi_dagger_a_equal_case = (are_phi_tilde_c_phi_dagger_a_equal && (is_phi_dagger_b_not_in_inSD_dagger_b || are_phi_tilde_d_phi_dagger_b_equal));
						      const bool phi_tilde_d_phi_dagger_a_equal_case = (are_phi_tilde_d_phi_dagger_a_equal && (is_phi_dagger_b_not_in_inSD_dagger_b || are_phi_tilde_c_phi_dagger_b_equal));

						      const bool dagger_a_conditions = (is_phi_dagger_a_not_in_inSD_dagger_a || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_d_phi_dagger_a_equal_case);
						      const bool dagger_b_conditions = (is_phi_dagger_b_not_in_inSD_dagger_b || phi_tilde_c_phi_dagger_b_equal_case || phi_tilde_d_phi_dagger_b_equal_case);
				  						      
						      if (dagger_a_conditions && dagger_b_conditions)
							{							  
							  unsigned int bin_phase_p = reordering_bin_phase_p;
							  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
							  switch (Op)
							    { 
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PPPP:
							      {
								inSDp.excitation_2p_2h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
							      } break;
					  
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_NNNN:
							      {
								inSDn.excitation_2p_2h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
							      } break;
				  
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PPPN:
							      {
								inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSDp , bin_phase_p);
								inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
							      } break;
				      
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_NNPN:
							      {
								inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_d_index , outSDn , bin_phase_n);
								inSDp.excitation_1h_and_bin_phase (phi_tilde_c_index , outSDp , bin_phase_p);
							      } break;
				      
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PPNN:
							      {
								inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDp , bin_phase_p);
								inSDn.excitation_2h_and_bin_phase (phi_tilde_c_index  , phi_tilde_d_index  , outSDn , bin_phase_n);
							      } break;				  

							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_NNPP:
							      {
								inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSDn , bin_phase_n);
								inSDp.excitation_2h_and_bin_phase (phi_tilde_c_index  , phi_tilde_d_index  , outSDp , bin_phase_p);
							      } break;				  
				  
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PNNN:
							      {
								inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
								inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_b_index , phi_tilde_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
							      } break;
				      				  
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PNPP:
							      {
								inSDn.excitation_1p_and_bin_phase (phi_dagger_b_index , outSDn , bin_phase_n);
								inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
							      } break;
				      		
							    case A_DAGGER_A_DAGGER_A_TILDE_A_TILDE_PNPN:
							      {
								inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_c_index , outSDp , bin_phase_p);
								inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_b_index , phi_tilde_d_index , outSDn , bin_phase_n);
							      } break;
					      
							    default: abort_all ();
							    }
										      
							  class configuration &Cp_out = Cp_out_work_tab(i_thread);
							  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
							  Cp_out.get_SD_configuration (phi_p_table , outSDp);
							  Cn_out.get_SD_configuration (phi_n_table , outSDn);

							  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
							  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
							  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
							  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
							  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
							  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
							  const int iMp_out = outSDp.iM_determine (phi_p_table);
							  const int iMn_out = outSDn.iM_determine (phi_n_table);

							  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
							  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
							  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
							  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

							  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
							  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

							  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
							  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
							  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
							  class configuration &Cp_try = Cp_try_tab(i_thread);
							  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
							  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
							  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
							  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
							  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  
							  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
							  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

							  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

							  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;
							  
							  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

							  (bin_phase_p == bin_phase_n)
							    ? (a_dagger_a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c , m_tilde_d) += PSI_IN_component*PSI_OUT_component) 
							    : (a_dagger_a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c , m_tilde_d) -= PSI_IN_component*PSI_OUT_component);
					  
							}}}}}}}}}}}}}}
  
  a_dagger_a_dagger_a_tilde_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}













void dagger_tilde_operators::a_dagger_a_tilde_a_dagger_a_tilde_MK_table_pn_calc (
										 const enum dagger_tilde_operator_type Op , 
										 const class nlj_struct &shell_dagger_a_qn , 
										 const class nlj_struct &shell_tilde_b_qn , 
										 const class nlj_struct &shell_dagger_c_qn , 
										 const class nlj_struct &shell_tilde_d_qn , 
										 const class correlated_state_str &PSI_IN_qn , 
										 const class correlated_state_str &PSI_OUT_qn , 
										 const class GSM_vector &PSI_OUT ,
										 const class array<unsigned int> &inSDp_tab ,
										 const class array<unsigned int> &inSDn_tab ,
										 const class array<TYPE> &PSI_IN_component_tab ,
										 const class array<bool> &is_inSDp_in_new_space_tab ,
										 const class array<bool> &is_inSDn_in_new_space_tab ,
										 const class array<unsigned char> &reordering_bin_phases_p ,
										 const class array<unsigned char> &reordering_bin_phases_n ,
										 class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_dagger_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b  = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_c = data_find (Op , 2 , prot_Y_data , neut_Y_data); 
  const class baryons_data &data_tilde_d  = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  
  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  const enum particle_type particle_d = shell_tilde_d_qn.get_particle ();

  const bool particle_ba_same = (particle_b == particle_a);
  const bool particle_bc_same = (particle_b == particle_c);
  const bool particle_da_same = (particle_d == particle_a);
  const bool particle_dc_same = (particle_d == particle_c);  
  const bool particle_ac_same = (particle_a == particle_c);  
  const bool particle_bd_same = (particle_b == particle_d);
  
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_d_indices = data_tilde_d.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_a_indices = data_dagger_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  const int n_tilde_d  = shell_tilde_d_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();  
  const int l_dagger_c = shell_dagger_c_qn.get_l ();
  const int l_tilde_d  = shell_tilde_d_qn.get_l ();  
  
  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  const double j_tilde_d  = shell_tilde_d_qn.get_j ();
  
  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_d_number = shell_tilde_d_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_dagger_c , j_tilde_d);

      a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_dagger_a = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b  = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_c = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_d  = SD_find (Op , 3 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_dagger_a_tilde_MK_table = a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i_thread);
		      
	  for (int im_tilde_d = 0 ; im_tilde_d < m_tilde_d_number ; im_tilde_d++)
	    {
	      const double m_tilde_d = im_tilde_d - j_tilde_d;

	      const unsigned int phi_tilde_d_index = one_body_tilde_d_indices(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
		     
	      if (phi_tilde_d_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_d_in_inSD_tilde_d = inSD_tilde_d.is_valence_state_occupied (phi_tilde_d_index);
		  
		  if (is_phi_tilde_d_in_inSD_tilde_d)
		    {		      
		      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
			{
			  const double m_tilde_b = im_tilde_b - j_tilde_b;

			  const unsigned int phi_tilde_b_index  = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

			  if (phi_tilde_b_index != OUT_OF_RANGE)
			    {	
			      const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);
			      
			      const bool are_phi_tilde_bd_equal = (particle_bd_same && (phi_tilde_b_index == phi_tilde_d_index));

			      const bool is_phi_tilde_b_in_inSD_tilde_b_and_are_bd_different = (is_phi_tilde_b_in_inSD_tilde_b && !are_phi_tilde_bd_equal);
					      
			      const int Mbd = make_int (m_tilde_b + m_tilde_d);
				      
			      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
				{
				  const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
				  const unsigned int phi_dagger_a_index = one_body_dagger_a_indices(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
					  
				  if (phi_dagger_a_index != OUT_OF_RANGE)
				    {			  
				      const double m_dagger_c = MK - m_dagger_a - Mbd;
	  
				      if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
					{
					  const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

					  if (phi_dagger_c_index != OUT_OF_RANGE)
					    {					  
					      const bool are_phi_tilde_b_phi_dagger_c_equal = (particle_bc_same && (phi_tilde_b_index == phi_dagger_c_index));	
					  
					      const bool are_phi_dagger_ac_equal = (particle_ac_same && (phi_dagger_a_index == phi_dagger_c_index));
			      
					      if (!are_phi_tilde_b_phi_dagger_c_equal && (!is_phi_tilde_b_in_inSD_tilde_b_and_are_bd_different || are_phi_dagger_ac_equal)) continue;

					      if (are_phi_tilde_b_phi_dagger_c_equal && is_phi_tilde_b_in_inSD_tilde_b_and_are_bd_different) continue;
					  			      
					      const bool are_phi_tilde_b_phi_dagger_a_equal = (particle_ba_same && (phi_tilde_b_index == phi_dagger_a_index));
					      const bool are_phi_tilde_d_phi_dagger_a_equal = (particle_da_same && (phi_tilde_d_index == phi_dagger_a_index));
					      const bool are_phi_tilde_d_phi_dagger_c_equal = (particle_dc_same && (phi_tilde_d_index == phi_dagger_c_index));
					      
					      const bool is_phi_dagger_a_not_in_inSD_dagger_a = !inSD_dagger_a.is_valence_state_occupied (phi_dagger_a_index);
					      const bool is_phi_dagger_c_not_in_inSD_dagger_c = !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index);
					  					  
					      const bool bc_equal_case = (are_phi_tilde_b_phi_dagger_c_equal && (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_tilde_d_phi_dagger_a_equal));
					  
					      const bool dagger_a_conditions_bc_different = (is_phi_dagger_a_not_in_inSD_dagger_a || are_phi_tilde_b_phi_dagger_a_equal || are_phi_tilde_d_phi_dagger_a_equal);
					      const bool dagger_c_conditions_bc_different = (is_phi_dagger_c_not_in_inSD_dagger_c || are_phi_tilde_b_phi_dagger_c_equal || are_phi_tilde_d_phi_dagger_c_equal);
				  
					      const bool bc_different_case = (!are_phi_tilde_b_phi_dagger_c_equal && dagger_a_conditions_bc_different && dagger_c_conditions_bc_different);

					      if (bc_equal_case || bc_different_case)
						{
						  unsigned int bin_phase_p = reordering_bin_phase_p;
						  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
						  switch (Op)
						    { 
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PPPP:
						      {
							inSDp.excitation_1p_1h_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
						      } break;
					  
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NNNN:
						      {
							inSDn.excitation_1p_1h_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
						      } break;
				  
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PPPN:
						      {
							inSDp.excitation_1p_1h_1p_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_dagger_c_index , outSDp , bin_phase_p);
							inSDn.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDn , bin_phase_n);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PPNP:
						      {
							inSDp.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_d_index , outSDp , bin_phase_p);
							inSDn.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDn , bin_phase_n);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NNPN:
						      {
							inSDn.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_d_index , outSDn , bin_phase_n);
							inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NNNP:
						      {
							inSDn.excitation_1p_1h_1p_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_dagger_c_index , outSDn , bin_phase_n);
							inSDp.excitation_1h_and_bin_phase (phi_tilde_d_index , outSDp , bin_phase_p);
						      } break;
				      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PPNN:
						      {
							inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDp , bin_phase_p);
							inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
						      } break;				  

						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NNPP:
						      {
							inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSDn , bin_phase_n);
							inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
						      } break;				  
				  
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PNNN:
						      {
							inSDp.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDp , bin_phase_p);
							inSDn.excitation_1h_1p_1h_and_bin_phase (phi_tilde_b_index , phi_dagger_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
						      } break;
				      				  
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NPNN:
						      {
							inSDp.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDp , bin_phase_p);
							inSDn.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_c_index , phi_tilde_d_index , outSDn , bin_phase_n);
						      } break;
				      				  
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PNPP:
						      {
							inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDn , bin_phase_n);
							inSDp.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
						      } break;
				      		
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NPPP:
						      {
							inSDn.excitation_1p_and_bin_phase (phi_dagger_a_index , outSDn , bin_phase_n);
							inSDp.excitation_1h_1p_1h_and_bin_phase (phi_tilde_b_index , phi_dagger_c_index , phi_tilde_d_index , outSDp , bin_phase_p);
						      } break;
				      		
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PNPN:
						      {
							inSDp.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_c_index , outSDp , bin_phase_p);
							inSDn.excitation_2h_and_bin_phase (phi_tilde_b_index  , phi_tilde_d_index  , outSDn , bin_phase_n);
						      } break;
					      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_PNNP:
						      {
							inSDp.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_d_index  , outSDp , bin_phase_p);
							inSDn.excitation_1h_1p_and_bin_phase (phi_tilde_b_index  , phi_dagger_c_index , outSDn , bin_phase_n);
						      } break;
					      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NPPN:
						      {
							inSDn.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_d_index  , outSDn , bin_phase_n);
							inSDp.excitation_1h_1p_and_bin_phase (phi_tilde_b_index  , phi_dagger_c_index , outSDp , bin_phase_p);
						      } break;
					      
						    case A_DAGGER_A_TILDE_A_DAGGER_A_TILDE_NPNP:
						      {
							inSDn.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_c_index , outSDn , bin_phase_n);
							inSDp.excitation_2h_and_bin_phase (phi_tilde_b_index  , phi_tilde_d_index  , outSDp , bin_phase_p);
						      } break;
					      
						    default: abort_all ();
						    }
										      
						  class configuration &Cp_out = Cp_out_work_tab(i_thread);
						  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
						  Cp_out.get_SD_configuration (phi_p_table , outSDp);
						  Cn_out.get_SD_configuration (phi_n_table , outSDn);

						  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
						  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
						  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
						  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
						  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
						  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
						  const int iMp_out = outSDp.iM_determine (phi_p_table);
						  const int iMn_out = outSDn.iM_determine (phi_n_table);

						  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
						  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
						  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
						  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

						  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
						  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
						  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
						  class configuration &Cp_try = Cp_try_tab(i_thread);
						  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
						  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
						  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
						  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
						  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  
						  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
						  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

						  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

						  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

						  (bin_phase_p == bin_phase_n)
						    ? (a_dagger_a_tilde_a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_dagger_c , m_tilde_d) += PSI_IN_component*PSI_OUT_component) 
						    : (a_dagger_a_tilde_a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_dagger_c , m_tilde_d) -= PSI_IN_component*PSI_OUT_component);
					  
						}}}}}}}}}}}}
  
  a_dagger_a_tilde_a_dagger_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_dagger_a_tilde_MK_table += a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}









void dagger_tilde_operators::a_tilde_a_tilde_a_dagger_a_dagger_MK_table_pn_calc (
										 const enum dagger_tilde_operator_type Op , 
										 const class nlj_struct &shell_tilde_a_qn , 
										 const class nlj_struct &shell_tilde_b_qn , 
										 const class nlj_struct &shell_dagger_c_qn , 
										 const class nlj_struct &shell_dagger_d_qn , 
										 const class correlated_state_str &PSI_IN_qn , 
										 const class correlated_state_str &PSI_OUT_qn , 
										 const class GSM_vector &PSI_OUT ,
										 const class array<unsigned int> &inSDp_tab ,
										 const class array<unsigned int> &inSDn_tab ,
										 const class array<TYPE> &PSI_IN_component_tab ,
										 const class array<bool> &is_inSDp_in_new_space_tab ,
										 const class array<bool> &is_inSDn_in_new_space_tab ,
										 const class array<unsigned char> &reordering_bin_phases_p ,
										 const class array<unsigned char> &reordering_bin_phases_n ,
										 class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const class baryons_data &data_tilde_a  = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_tilde_b  = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_c = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_dagger_d = data_find (Op , 3 , prot_Y_data , neut_Y_data); 
  
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  const enum particle_type particle_d = shell_dagger_d_qn.get_particle ();
  const enum particle_type particle_a  = shell_tilde_a_qn.get_particle ();
  const enum particle_type particle_b  = shell_tilde_b_qn.get_particle ();

  const bool particle_ac_same = (particle_a == particle_c);
  const bool particle_ad_same = (particle_a == particle_d);
  const bool particle_bc_same = (particle_b == particle_c);
  const bool particle_bd_same = (particle_b == particle_d);  
  const bool particle_cd_same = (particle_c == particle_d);  
  const bool particle_ab_same = (particle_a == particle_b);

  const class one_body_indices_str &one_body_tilde_a_indices = data_tilde_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_tilde_b_indices = data_tilde_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_c_indices = data_dagger_c.get_one_body_indices ();
  const class one_body_indices_str &one_body_dagger_d_indices = data_dagger_d.get_one_body_indices ();
 
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
    
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_p = prot_Y_data.get_nmax_lj_tabs ();
  const class array<class lj_table<int> > &nmax_lj_tabs_n = neut_Y_data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_p = prot_Y_data.get_is_it_valence_shell_tabs ();
  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_n = neut_Y_data.get_is_it_valence_shell_tabs ();

  const int n_tilde_a  = shell_tilde_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  const int n_dagger_d = shell_dagger_d_qn.get_n ();
  
  const int l_tilde_a  = shell_tilde_a_qn.get_l ();  
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();  
  const int l_dagger_c = shell_dagger_c_qn.get_l ();
  const int l_dagger_d = shell_dagger_d_qn.get_l ();
  
  const double j_tilde_a  = shell_tilde_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  const double j_dagger_d = shell_dagger_d_qn.get_j ();
  
  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();

  const int m_dagger_c_number = shell_dagger_c_qn.m_number_determine ();
  const int m_dagger_d_number = shell_dagger_d_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
      
  class array<class Slater_determinant> inSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> inSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> outSDp_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_work_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_work_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSDp_work_tab(i).allocate (ZYval_IN);
      inSDn_work_tab(i).allocate (NYval_IN);

      outSDp_work_tab(i).allocate (ZYval);
      outSDn_work_tab(i).allocate (NYval);

      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);

      Cp_out_work_tab(i).allocate (ZYval);
      Cn_out_work_tab(i).allocate (NYval);

      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
      
      a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_dagger_c , j_dagger_d);

      a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSDp_in_new_space_tab(PSI_IN_index) || !is_inSDn_in_new_space_tab(PSI_IN_index)) continue;
	  
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &inSDp = inSDp_work_tab(i_thread);

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(PSI_IN_index , p);

	  if (!inSDp.is_it_in_new_space (phi_p_table , nmax_lj_tabs_p , is_it_valence_shell_tabs_p)) continue;

	  class Slater_determinant &inSDn = inSDn_work_tab(i_thread);

	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(PSI_IN_index , n);

	  if (!inSDn.is_it_in_new_space (phi_n_table , nmax_lj_tabs_n , is_it_valence_shell_tabs_n)) continue;

	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(PSI_IN_index);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(PSI_IN_index);
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  const class Slater_determinant &inSD_tilde_a  = SD_find (Op , 0 , inSDp , inSDn);
	  const class Slater_determinant &inSD_tilde_b  = SD_find (Op , 1 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_c = SD_find (Op , 2 , inSDp , inSDn);
	  const class Slater_determinant &inSD_dagger_d = SD_find (Op , 3 , inSDp , inSDn);

	  class Slater_determinant &outSDp = outSDp_work_tab(i_thread);
	  class Slater_determinant &outSDn = outSDn_work_tab(i_thread);
	  
	  if (ZYval_IN == ZYval) outSDp = inSDp;
	  if (NYval_IN == NYval) outSDn = inSDn;

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_dagger_a_dagger_MK_table = a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_c = 0 ; im_dagger_c < m_dagger_c_number ; im_dagger_c++)
	    {
	      const double m_dagger_c = im_dagger_c - j_dagger_c;

	      const unsigned int phi_dagger_c_index = one_body_dagger_c_indices(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

	      if (phi_dagger_c_index != OUT_OF_RANGE)
		{
		  const bool is_phi_dagger_c_not_in_inSD_dagger_c = !inSD_dagger_c.is_valence_state_occupied (phi_dagger_c_index);
		  
		  if (is_phi_dagger_c_not_in_inSD_dagger_c)
		    {
		      for (int im_dagger_d = 0 ; im_dagger_d < m_dagger_d_number ; im_dagger_d++)
			{
			  const double m_dagger_d = im_dagger_d - j_dagger_d;

			  const unsigned int phi_dagger_d_index = one_body_dagger_d_indices(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);

			  if (phi_dagger_d_index != OUT_OF_RANGE)
			    {
			      const bool are_phi_dagger_cd_different = (!particle_cd_same || (phi_dagger_c_index != phi_dagger_d_index));
			      
			      if (are_phi_dagger_cd_different)
				{		  
				  const bool is_phi_dagger_d_not_in_inSD_dagger_d = !inSD_dagger_d.is_valence_state_occupied (phi_dagger_d_index);
				  
				  if (is_phi_dagger_d_not_in_inSD_dagger_d)
				    {		 
				      const int Mcd = make_int (m_dagger_c + m_dagger_d);
				  
				      for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
					{
					  const double m_tilde_a = im_tilde_a - j_tilde_a;		      
					  
					  const double m_tilde_b = MK - Mcd - m_tilde_a;
		  	  
					  if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
					    {			  
					      const unsigned int phi_tilde_a_index  = one_body_tilde_a_indices(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
					      const unsigned int phi_tilde_b_index  = one_body_tilde_b_indices(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);			  

					      if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE))
						{			      
						  const bool are_phi_tilde_ab_different = (!particle_ab_same || (phi_tilde_a_index != phi_tilde_b_index));
			      
						  if (are_phi_tilde_ab_different)
						    {
						      const bool is_phi_tilde_a_in_inSD_tilde_a = inSD_tilde_a.is_valence_state_occupied (phi_tilde_a_index);
						      const bool is_phi_tilde_b_in_inSD_tilde_b = inSD_tilde_b.is_valence_state_occupied (phi_tilde_b_index);

						      const bool are_phi_tilde_a_phi_dagger_c_equal = (particle_ac_same && (phi_tilde_a_index == phi_dagger_c_index));
						      const bool are_phi_tilde_a_phi_dagger_d_equal = (particle_ad_same && (phi_tilde_a_index == phi_dagger_d_index));					  
						      const bool are_phi_tilde_b_phi_dagger_c_equal = (particle_bc_same && (phi_tilde_b_index == phi_dagger_c_index));
						      const bool are_phi_tilde_b_phi_dagger_d_equal = (particle_bd_same && (phi_tilde_b_index == phi_dagger_d_index));
					  
						      const bool phi_tilde_a_phi_dagger_c_equal_case = (are_phi_tilde_a_phi_dagger_c_equal && (is_phi_tilde_b_in_inSD_tilde_b || are_phi_tilde_b_phi_dagger_d_equal));
						      const bool phi_tilde_a_phi_dagger_d_equal_case = (are_phi_tilde_a_phi_dagger_d_equal && (is_phi_tilde_b_in_inSD_tilde_b || are_phi_tilde_b_phi_dagger_c_equal));
						      const bool phi_tilde_b_phi_dagger_c_equal_case = (are_phi_tilde_b_phi_dagger_c_equal && (is_phi_tilde_a_in_inSD_tilde_a || are_phi_tilde_a_phi_dagger_d_equal));
						      const bool phi_tilde_b_phi_dagger_d_equal_case = (are_phi_tilde_b_phi_dagger_d_equal && (is_phi_tilde_a_in_inSD_tilde_a || are_phi_tilde_a_phi_dagger_c_equal));
					  
						      const bool tilde_a_conditions = (is_phi_tilde_a_in_inSD_tilde_a || phi_tilde_a_phi_dagger_c_equal_case || phi_tilde_a_phi_dagger_d_equal_case);
						      const bool tilde_b_conditions = (is_phi_tilde_b_in_inSD_tilde_b || phi_tilde_b_phi_dagger_c_equal_case || phi_tilde_b_phi_dagger_d_equal_case);

						      if (tilde_a_conditions && tilde_b_conditions)
							{							  
							  unsigned int bin_phase_p = reordering_bin_phase_p;
							  unsigned int bin_phase_n = reordering_bin_phase_n;
			  
							  switch (Op)
							    { 
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PPPP:
							      {
								inSDp.excitation_2h_2p_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_dagger_d_index , outSDp , bin_phase_p);
							      } break;
					  
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_NNNN:
							      {
								inSDn.excitation_2h_2p_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_dagger_d_index , outSDn , bin_phase_n);
							      } break;
				  
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PPPN:
							      {
								inSDp.excitation_2h_1p_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_dagger_c_index , outSDp , bin_phase_p);
								inSDn.excitation_1p_and_bin_phase (phi_dagger_d_index , outSDn , bin_phase_n);
							      } break;
				      
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_NNPN:
							      {
								inSDn.excitation_2h_1p_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_dagger_d_index , outSDn , bin_phase_n);
								inSDp.excitation_1p_and_bin_phase (phi_dagger_c_index , outSDp , bin_phase_p);
							      } break;
				      
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PPNN:
							      {
								inSDp.excitation_2h_and_bin_phase (phi_tilde_a_index  , phi_tilde_b_index  , outSDp , bin_phase_p);
								inSDn.excitation_2p_and_bin_phase (phi_dagger_c_index , phi_dagger_d_index , outSDn , bin_phase_n);
							      } break;				  

							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_NNPP:
							      {
								inSDn.excitation_2h_and_bin_phase (phi_tilde_a_index  , phi_tilde_b_index  , outSDn , bin_phase_n);
								inSDp.excitation_2p_and_bin_phase (phi_dagger_c_index , phi_dagger_d_index , outSDp , bin_phase_p);
							      } break;				  
				  
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PNNN:
							      {
								inSDn.excitation_1h_2p_and_bin_phase (phi_tilde_b_index , phi_dagger_c_index , phi_dagger_d_index , outSDn , bin_phase_n);
								inSDp.excitation_1h_and_bin_phase (phi_tilde_a_index , outSDp , bin_phase_p);
							      } break;
				      				  
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PNPP:
							      {
								inSDn.excitation_1h_and_bin_phase (phi_tilde_b_index , outSDn , bin_phase_n);
								inSDp.excitation_1h_2p_and_bin_phase (phi_tilde_a_index , phi_dagger_c_index , phi_dagger_d_index , outSDp , bin_phase_p);
							      } break;
				      		
							    case A_TILDE_A_TILDE_A_DAGGER_A_DAGGER_PNPN:
							      {
								inSDp.excitation_1h_1p_and_bin_phase (phi_tilde_a_index , phi_dagger_c_index , outSDp , bin_phase_p);
								inSDn.excitation_1h_1p_and_bin_phase (phi_tilde_b_index , phi_dagger_d_index , outSDn , bin_phase_n);
							      } break;
					      
							    default: abort_all ();
							    }
										      
							  class configuration &Cp_out = Cp_out_work_tab(i_thread);
							  class configuration &Cn_out = Cn_out_work_tab(i_thread);
				  
							  Cp_out.get_SD_configuration (phi_p_table , outSDp);
							  Cn_out.get_SD_configuration (phi_n_table , outSDn);

							  const unsigned int BPp_out = Cp_out.BP_determine (shells_qn_p);
							  const unsigned int BPn_out = Cn_out.BP_determine (shells_qn_n);
			
							  const int Sp_out = Cp_out.strangeness_determine (shells_qn_p);
							  const int Sn_out = Cn_out.strangeness_determine (shells_qn_n);
	      
							  const int n_spec_p_out = Cp_out.n_spec_determine (shells_qn_p);
							  const int n_spec_n_out = Cn_out.n_spec_determine (shells_qn_n);
			      
							  const int iMp_out = outSDp.iM_determine (phi_p_table);
							  const int iMn_out = outSDn.iM_determine (phi_n_table);

							  const int n_holes_p_out = Cp_out.n_holes_determine (shells_qn_p);
							  const int n_holes_n_out = Cn_out.n_holes_determine (shells_qn_n);
				  
							  const int n_scat_p_out = Cp_out.n_scat_determine (shells_qn_p);
							  const int n_scat_n_out = Cn_out.n_scat_determine (shells_qn_n); 

							  const int Ep_out_hw = Cp_out.E_hw_determine (shells_qn_p);
							  const int En_out_hw = Cn_out.E_hw_determine (shells_qn_n);

							  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
							  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
				  
							  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
					
							  class configuration &Cp_try = Cp_try_tab(i_thread);
							  class configuration &Cn_try = Cn_try_tab(i_thread);
					  
							  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
							  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
		      
							  const unsigned int iCp_out = Cp_out.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
							  const unsigned int iCn_out = Cn_out.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);
					  
							  const unsigned int outSDp_index = outSDp.index_search (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);
							  const unsigned int outSDn_index = outSDn.index_search (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

							  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

							  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

							  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;
							  
							  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];

							  (bin_phase_p == bin_phase_n)
							    ? (a_tilde_a_tilde_a_dagger_a_dagger_MK_table(m_tilde_a , m_tilde_b , m_dagger_c , m_dagger_d) += PSI_IN_component*PSI_OUT_component) 
							    : (a_tilde_a_tilde_a_dagger_a_dagger_MK_table(m_tilde_a , m_tilde_b , m_dagger_c , m_dagger_d) -= PSI_IN_component*PSI_OUT_component);
					  
							}}}}}}}}}}}}}}
  
  a_tilde_a_tilde_a_dagger_a_dagger_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_dagger_a_dagger_MK_table += a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}















void dagger_tilde_operators::a_dagger_MK_table_pp_nn_calc (
							   const class nlj_struct &shell_dagger_a_qn , 
							   const class correlated_state_str &PSI_IN_qn , 
							   const class correlated_state_str &PSI_OUT_qn , 
							   const class GSM_vector &PSI_OUT ,
							   const class array<unsigned int> &inSD_tab ,
							   const class array<TYPE> &PSI_IN_component_tab ,
							   const class array<bool> &is_inSD_in_new_space_tab ,
							   const class array<unsigned char> &reordering_bin_phases ,
							   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int N_valence_baryons_IN = N_valence_baryons - 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;
  
  a_dagger_MK_table = 0.0;
  
  if (rint (abs (MK) - j_dagger_a) > 0.0) return;
  
  const double m_dagger_a = MK;
	      
  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
	      
  if (phi_dagger_a_index == OUT_OF_RANGE) return;

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_MK_tables(i).allocate (j_dagger_a);

      a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	      
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_MK_table = a_dagger_MK_tables(i_thread);

	  const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);

	  if (is_phi_dagger_a_not_in_inSD)
	    {
	      unsigned int bin_phase = reordering_bin_phase;
			  
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_1p_and_bin_phase (phi_dagger_a_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
							      
	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				   

	      (phase == 1)
		? (a_dagger_MK_table(m_dagger_a) += PSI_IN_component*PSI_OUT_component)
		: (a_dagger_MK_table(m_dagger_a) -= PSI_IN_component*PSI_OUT_component);
			      
	    }
	}
    }

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_MK_table += a_dagger_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}







void dagger_tilde_operators::a_tilde_MK_table_pp_nn_calc (
							  const class nlj_struct &shell_tilde_a_qn , 
							  const class correlated_state_str &PSI_IN_qn , 
							  const class correlated_state_str &PSI_OUT_qn , 
							  const class GSM_vector &PSI_OUT ,
							  const class array<unsigned int> &inSD_tab ,
							  const class array<TYPE> &PSI_IN_component_tab ,
							  const class array<bool> &is_inSD_in_new_space_tab ,
							  const class array<unsigned char> &reordering_bin_phases ,
							  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int N_valence_baryons_IN = N_valence_baryons + 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int l_tilde_a = shell_tilde_a_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  a_tilde_MK_table = 0.0;
  
  if (rint (abs (MK) - j_tilde_a) > 0.0) return;
  
  const double m_tilde_a = MK;
  
  const unsigned int phi_tilde_a_index = one_body_indices_mu(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);

  if (phi_tilde_a_index == OUT_OF_RANGE) return;

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_tilde_MK_tables(i).allocate (j_tilde_a);

      a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	      
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_MK_table = a_tilde_MK_tables(i_thread);

	  const bool is_phi_tilde_a_in_inSD = inSD.is_valence_state_occupied (phi_tilde_a_index);

	  if (is_phi_tilde_a_in_inSD)
	    {
	      unsigned int bin_phase = reordering_bin_phase;
			  
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_1h_and_bin_phase (phi_tilde_a_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
							      
	      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				   

	      (phase == 1)
		? (a_tilde_MK_table(m_tilde_a) += PSI_IN_component*PSI_OUT_component)
		: (a_tilde_MK_table(m_tilde_a) -= PSI_IN_component*PSI_OUT_component);
			      
	    }
	}
    }

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_MK_table += a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}









void dagger_tilde_operators::a_dagger_a_tilde_MK_table_pp_nn_calc (
								   const class nlj_struct &shell_dagger_a_qn , 
								   const class nlj_struct &shell_tilde_b_qn , 
								   const class correlated_state_str &PSI_IN_qn , 
								   const class correlated_state_str &PSI_OUT_qn , 
								   const class GSM_vector &PSI_OUT ,
								   const class array<unsigned int> &inSD_tab ,
								   const class array<TYPE> &PSI_IN_component_tab ,
								   const class array<bool> &is_inSD_in_new_space_tab ,
								   const class array<unsigned char> &reordering_bin_phases ,
								   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int N_valence_baryons_IN = N_valence_baryons;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();

  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b);

      a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	      
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_MK_table = a_dagger_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;

	      const unsigned int phi_tilde_b_index = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

	      if (phi_tilde_b_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);

		  if (is_phi_tilde_b_in_inSD)
		    {
		      const double m_dagger_a = MK - m_tilde_b;

		      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
			{
			  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);

			  if (phi_dagger_a_index != OUT_OF_RANGE)
			    {
			      const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);

			      if (is_phi_dagger_a_not_in_inSD || (phi_dagger_a_index == phi_tilde_b_index))
				{
				  unsigned int bin_phase = reordering_bin_phase;
			  
				  class Slater_determinant &outSD = outSD_work_tab(i_thread);

				  inSD.excitation_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , outSD , bin_phase);

				  class configuration &C_out = C_out_work_tab(i_thread);

				  C_out.get_SD_configuration (phi_mu_table , outSD);

				  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
				  const int S_out = C_out.strangeness_determine (shells_qn_mu);

				  const int iM_out = outSD.iM_determine (phi_mu_table);

				  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
				  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
				  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

				  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
				  class configuration &C_try = C_try_tab(i_thread);

				  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
				  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
				  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

				  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

				  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

				  const int phase = parity_from_binary_parity (bin_phase);
							      
				  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				   

				  (phase == 1)
				    ? (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
				    : (a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
			      
				}}}}}}}}

  a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_MK_table += a_dagger_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}









void dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pp_nn_calc (
								 const enum dagger_tilde_operator_type Op , 
								 const class nljm_struct &phi_dagger_d , 
								 const class nljm_struct &phi_tilde_c , 
								 const class array<unsigned int> &inSD_tab ,
								 const class GSM_vector &PSI_IN ,
								 class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const int N_valence_baryons_IN = N_valence_baryons;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const enum particle_type particle_d = phi_dagger_d.get_particle ();
  const enum particle_type particle_c = phi_tilde_c.get_particle ();
  
  const int n_dagger_d = phi_dagger_d.get_n ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const int n_tilde_c = phi_tilde_c.get_n ();
  const int l_tilde_c = phi_tilde_c.get_l ();

  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_indices_mu(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);

  const unsigned int phi_tilde_c_index = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
		  	  
  const bool are_phi_dagger_d_phi_tilde_c_equal = (phi_dagger_d_index == phi_tilde_c_index);
	  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);

  PSI_OUT = 0.0;
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;
	      
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);

	  if (is_phi_tilde_c_in_inSD)
	    {
	      const bool is_phi_dagger_d_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_d_index);
  
	      if (is_phi_dagger_d_not_in_inSD || are_phi_dagger_d_phi_tilde_c_equal)
		{
		  class Slater_determinant &outSD = outSD_work_tab(i_thread);

		  inSD.excitation_1p_1h_and_bin_phase (phi_dagger_d_index , phi_tilde_c_index , outSD , bin_phase);

		  class configuration &C_out = C_out_work_tab(i_thread);
	      
		  C_out.get_SD_configuration (phi_mu_table , outSD);

		  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
		  const int S_out = C_out.strangeness_determine (shells_qn_mu);

		  const int iM_out = outSD.iM_determine (phi_mu_table);

		  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
			
		  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
		  class configuration &C_try = C_try_tab(i_thread);

		  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
		  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

		  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

		  const int phase = parity_from_binary_parity (bin_phase);
						      
		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
		  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

		}
	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}


















void dagger_tilde_operators::a_dagger_a_dagger_MK_table_pp_nn_calc (
								    const class nlj_struct &shell_dagger_a_qn , 
								    const class nlj_struct &shell_dagger_b_qn , 
								    const class correlated_state_str &PSI_IN_qn , 
								    const class correlated_state_str &PSI_OUT_qn , 
								    const class GSM_vector &PSI_OUT ,
								    const class array<unsigned int> &inSD_tab ,
								    const class array<TYPE> &PSI_IN_component_tab ,
								    const class array<bool> &is_inSD_in_new_space_tab ,
								    const class array<unsigned char> &reordering_bin_phases ,
								    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b);

      a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);
      
	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_MK_table = a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	    {
	      const double m_dagger_a = im_dagger_a - j_dagger_a;

	      const double m_dagger_b = MK - m_dagger_a;

	      if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
		{
		  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		  const unsigned int phi_dagger_b_index = one_body_indices_mu(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

		  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_a_index != phi_dagger_b_index))
		    {
		      if (!inSD.is_valence_state_occupied (phi_dagger_a_index) && !inSD.is_valence_state_occupied (phi_dagger_b_index))
			{
			  unsigned int bin_phase = reordering_bin_phase;
	      
			  class Slater_determinant &outSD = outSD_work_tab(i_thread);
      
			  inSD.excitation_2p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , outSD , bin_phase);

			  class configuration &C_out = C_out_work_tab(i_thread);

			  C_out.get_SD_configuration (phi_mu_table , outSD);

			  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
			  const int S_out = C_out.strangeness_determine (shells_qn_mu);

			  const int iM_out = outSD.iM_determine (phi_mu_table);

			  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
			  class configuration &C_try = C_try_tab(i_thread);

			  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
			      
			  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

			  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

			  const int phase = parity_from_binary_parity (bin_phase);
			      
			  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				    
		
			  (phase == 1)
			    ? (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) += PSI_IN_component*PSI_OUT_component)
			    : (a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b) -= PSI_IN_component*PSI_OUT_component);
			      				  
			}}}}}}

  a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_MK_table += a_dagger_a_dagger_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}
















void dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pp_nn_calc (
								  const enum dagger_tilde_operator_type Op , 
								  const class nljm_struct &phi_dagger_d , 
								  const class nljm_struct &phi_dagger_c , 
								  const class array<unsigned int> &inSD_tab ,
								  const class GSM_vector &PSI_IN ,
								  class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const enum particle_type particle_d = phi_dagger_d.get_particle ();
  const enum particle_type particle_c = phi_dagger_c.get_particle ();
  
  const int n_dagger_d = phi_dagger_d.get_n ();
  const int n_dagger_c = phi_dagger_c.get_n ();
  
  const int l_dagger_d = phi_dagger_d.get_l ();
  const int l_dagger_c = phi_dagger_c.get_l ();
  
  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const double j_dagger_c = phi_dagger_c.get_j ();
  const double m_dagger_c = phi_dagger_c.get_m ();

  const unsigned int phi_dagger_d_index = one_body_indices_mu(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  const unsigned int phi_dagger_c_index = one_body_indices_mu(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);
		  
  PSI_OUT = 0.0;
  
  if (phi_dagger_d_index == phi_dagger_c_index) return;
	  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
      
	  if (!inSD.is_valence_state_occupied (phi_dagger_d_index) && !inSD.is_valence_state_occupied (phi_dagger_c_index))
	    {	      
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_2p_and_bin_phase (phi_dagger_d_index , phi_dagger_c_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
	      
	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
						      
	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}





























void dagger_tilde_operators::a_tilde_a_tilde_MK_table_pp_nn_calc (
								  const class nlj_struct &shell_tilde_a_qn , 
								  const class nlj_struct &shell_tilde_b_qn , 
								  const class correlated_state_str &PSI_IN_qn , 
								  const class correlated_state_str &PSI_OUT_qn , 
								  const class GSM_vector &PSI_OUT ,
								  const class array<unsigned int> &inSD_tab ,
								  const class array<TYPE> &PSI_IN_component_tab ,
								  const class array<bool> &is_inSD_in_new_space_tab ,
								  const class array<unsigned char> &reordering_bin_phases ,
								  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons + 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();

  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  
  const double J_IN = PSI_IN_qn.get_J ();
  const double M_IN = J_IN;

  const double J_OUT = PSI_OUT_qn.get_J ();
  const double M_OUT = J_OUT;

  const int MK = make_int (M_OUT - M_IN);

  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b);

      a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);
	    
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_MK_table = a_tilde_a_tilde_MK_tables(i_thread);

	  for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	    {
	      const double m_tilde_a = im_tilde_a - j_tilde_a;

	      const double m_tilde_b = MK - m_tilde_a;

	      if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
		{
		  const unsigned int phi_tilde_a_index = one_body_indices_mu(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		  const unsigned int phi_tilde_b_index = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

		  const bool are_phi_tilde_ab_different = (phi_tilde_a_index != phi_tilde_b_index);
			  
		  if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && are_phi_tilde_ab_different)
		    {
		      if (inSD.is_valence_state_occupied (phi_tilde_a_index) && inSD.is_valence_state_occupied (phi_tilde_b_index))
			{
			  unsigned int bin_phase = reordering_bin_phase;
	      
			  class Slater_determinant &outSD = outSD_work_tab(i_thread);

			  inSD.excitation_2h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , outSD , bin_phase);

			  class configuration &C_out = C_out_work_tab(i_thread);

			  C_out.get_SD_configuration (phi_mu_table , outSD);

			  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
			  const int S_out = C_out.strangeness_determine (shells_qn_mu);
		      
			  const int iM_out = outSD.iM_determine (phi_mu_table);

			  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
			  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
		      
			  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
			    
			  class configuration &C_try = C_try_tab(i_thread);
			  
			  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
			  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

			  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

			  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

			  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

			  const int phase = parity_from_binary_parity (bin_phase);
						      
			  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];			     
			    			
			  (phase == 1)
			    ? (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) += PSI_IN_component*PSI_OUT_component)
			    : (a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b) -= PSI_IN_component*PSI_OUT_component);
			      
			}}}}}}

  a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_MK_table += a_tilde_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}












void dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pp_nn_calc (
								const enum dagger_tilde_operator_type Op , 
								const class nljm_struct &phi_tilde_d , 
								const class nljm_struct &phi_tilde_c , 
								const class array<unsigned int> &inSD_tab ,
								const class GSM_vector &PSI_IN ,
								class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);
  
  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons + 2;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  const enum particle_type particle_c = phi_tilde_c.get_particle ();
  
  const int n_tilde_d = phi_tilde_d.get_n ();
  const int n_tilde_c = phi_tilde_c.get_n ();
  
  const int l_tilde_d = phi_tilde_d.get_l ();
  const int l_tilde_c = phi_tilde_c.get_l ();
  
  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const double j_tilde_c = phi_tilde_c.get_j ();
  const double m_tilde_c = phi_tilde_c.get_m ();

  const unsigned int phi_tilde_d_index = one_body_indices_mu(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  const unsigned int phi_tilde_c_index = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
  
  PSI_OUT = 0.0;
  
  if (phi_tilde_d_index == phi_tilde_c_index) return;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);

  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;
	    
	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  if (inSD.is_valence_state_occupied (phi_tilde_c_index) && inSD.is_valence_state_occupied (phi_tilde_d_index))
	    {	      
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);
	      
	      inSD.excitation_2h_and_bin_phase (phi_tilde_d_index , phi_tilde_c_index , outSD , bin_phase);
	  
	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);
		      
	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);
		      
	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);
	      
	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);

	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 
		  
	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
			      
	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
  
#endif
  
}






















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (
									    const class nlj_struct &shell_dagger_a_qn , 
									    const class nlj_struct &shell_dagger_b_qn , 
									    const class nlj_struct &shell_tilde_c_qn , 
									    const class correlated_state_str &PSI_IN_qn , 
									    const class correlated_state_str &PSI_OUT_qn , 
									    const class GSM_vector &PSI_OUT ,
									    const class array<unsigned int> &inSD_tab ,
									    const class array<TYPE> &PSI_IN_component_tab ,
									    const class array<bool> &is_inSD_in_new_space_tab ,
									    const class array<unsigned char> &reordering_bin_phases ,
									    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle ();
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c);

      a_dagger_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {
	      const double m_tilde_c = im_tilde_c - j_tilde_c;

	      const unsigned int phi_tilde_c_index = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

	      if (phi_tilde_c_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);

		  if (is_phi_tilde_c_in_inSD)
		    {		  
		      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
			{
			  const double m_dagger_a = im_dagger_a - j_dagger_a;

			  const double m_dagger_b = MK - m_tilde_c - m_dagger_a;
	  
			  if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
			    {
			      const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
			      const unsigned int phi_dagger_b_index = one_body_indices_mu(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
		      
			      if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_a_index != phi_dagger_b_index))
				{
				  const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);
				  const bool is_phi_dagger_b_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_b_index);

				  const bool no_dagger_ab_case = (is_phi_dagger_a_not_in_inSD && is_phi_dagger_b_not_in_inSD);

				  const bool are_phi_tilde_c_phi_dagger_a_equal = (phi_tilde_c_index == phi_dagger_a_index);
				  const bool are_phi_tilde_c_phi_dagger_b_equal = (phi_tilde_c_index == phi_dagger_b_index);

				  const bool phi_tilde_c_phi_dagger_a_equal_case = (are_phi_tilde_c_phi_dagger_a_equal && is_phi_dagger_b_not_in_inSD);
				  const bool phi_tilde_c_phi_dagger_b_equal_case = (are_phi_tilde_c_phi_dagger_b_equal && is_phi_dagger_a_not_in_inSD);				  

				  if (no_dagger_ab_case || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_c_phi_dagger_b_equal_case)
				    {
				      unsigned int bin_phase = reordering_bin_phase;
	      
				      class Slater_determinant &outSD = outSD_work_tab(i_thread);

				      inSD.excitation_2p_1h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , outSD , bin_phase);

				      class configuration &C_out = C_out_work_tab(i_thread);

				      C_out.get_SD_configuration (phi_mu_table , outSD);

				      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
				      const int S_out = C_out.strangeness_determine (shells_qn_mu);

				      const int iM_out = outSD.iM_determine (phi_mu_table);

				      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

				      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
				      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

				      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
				      class configuration &C_try = C_try_tab(i_thread);

				      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
				      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				  
				      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

				      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

				      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

				      const int phase = parity_from_binary_parity (bin_phase);
				      
				      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
				      (phase == 1)
					? (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
					: (a_dagger_a_dagger_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

				    }}}}}}}}}

  a_dagger_a_dagger_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}















void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc (
									  const enum dagger_tilde_operator_type Op , 
									  const class nljm_struct &phi_dagger_f , 
									  const class nljm_struct &phi_dagger_e , 
									  const class nljm_struct &phi_tilde_d , 
									  const class array<unsigned int> &inSD_tab ,
									  const class GSM_vector &PSI_IN ,
									  class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_dagger_e.get_particle (); 
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();

  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(particle_f , n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_indices_mu(particle_e , n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_tilde_d_index  = one_body_indices_mu(particle_d , n_tilde_d  , l_tilde_d  , j_tilde_d  ,-m_tilde_d);
		      
  PSI_OUT = 0.0;
  
  if (phi_dagger_f_index == phi_dagger_e_index) return;
	
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);      
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);

  PSI_OUT = 0.0;
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  const bool is_phi_tilde_d_in_inSD = inSD.is_valence_state_occupied (phi_tilde_d_index);

	  if (is_phi_tilde_d_in_inSD)
	    {
	      const bool is_phi_dagger_f_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_f_index);
	      const bool is_phi_dagger_e_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_e_index);

	      const bool no_dagger_fe_case = (is_phi_dagger_f_not_in_inSD && is_phi_dagger_e_not_in_inSD);

	      const bool phi_tilde_d_phi_dagger_f_equal_case = ((phi_tilde_d_index == phi_dagger_f_index) && is_phi_dagger_e_not_in_inSD);
	      const bool phi_tilde_d_phi_dagger_e_equal_case = ((phi_tilde_d_index == phi_dagger_e_index) && is_phi_dagger_f_not_in_inSD);

	      if (no_dagger_fe_case || phi_tilde_d_phi_dagger_f_equal_case || phi_tilde_d_phi_dagger_e_equal_case)
		{	      
		  class Slater_determinant &outSD = outSD_work_tab(i_thread);

		  inSD.excitation_2p_1h_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_tilde_d_index , outSD , bin_phase);

		  class configuration &C_out = C_out_work_tab(i_thread);

		  C_out.get_SD_configuration (phi_mu_table , outSD);

		  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
		  const int S_out = C_out.strangeness_determine (shells_qn_mu);

		  const int iM_out = outSD.iM_determine (phi_mu_table);

		  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
		  class configuration &C_try = C_try_tab(i_thread);

		  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
		  
		  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

		  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

		  const int phase = parity_from_binary_parity (bin_phase);
				      
		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
		  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

		}}}}
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}
























void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (
									   const class nlj_struct &shell_dagger_a_qn , 
									   const class nlj_struct &shell_tilde_b_qn , 
									   const class nlj_struct &shell_tilde_c_qn , 
									   const class correlated_state_str &PSI_IN_qn , 
									   const class correlated_state_str &PSI_OUT_qn , 
									   const class GSM_vector &PSI_OUT ,
									   const class array<unsigned int> &inSD_tab ,
									   const class array<TYPE> &PSI_IN_component_tab ,
									   const class array<bool> &is_inSD_in_new_space_tab ,
									   const class array<unsigned char> &reordering_bin_phases ,
									   class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons () ;

  const int N_valence_baryons_IN = N_valence_baryons + 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_tilde_c);

      a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
      
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_tilde_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
	    {
	      const double m_tilde_b = im_tilde_b - j_tilde_b;
	  
	      const unsigned int phi_tilde_b_index = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
		      
	      if (phi_tilde_b_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);

		  if (is_phi_tilde_b_in_inSD)
		    {			      
		      for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
			{
			  const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
			  const unsigned int phi_tilde_c_index = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

			  if (phi_tilde_c_index != OUT_OF_RANGE)
			    {
			      if (phi_tilde_b_index != phi_tilde_c_index)
				{
				  const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);

				  if (is_phi_tilde_c_in_inSD)
				    {				  
				      const double m_dagger_a = MK - m_tilde_b - m_tilde_c;
	  
				      if (rint (abs (m_dagger_a) - j_dagger_a) <= 0.0)
					{	      
					  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		      
					  if (phi_dagger_a_index != OUT_OF_RANGE)
					    {
					      const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);

					      if (is_phi_dagger_a_not_in_inSD || (phi_dagger_a_index == phi_tilde_b_index) || (phi_dagger_a_index == phi_tilde_c_index))
						{
						  unsigned int bin_phase = reordering_bin_phase;
	      
						  class Slater_determinant &outSD = outSD_work_tab(i_thread);

						  inSD.excitation_1p_2h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_tilde_c_index , outSD , bin_phase);

						  class configuration &C_out = C_out_work_tab(i_thread);

						  C_out.get_SD_configuration (phi_mu_table , outSD);

						  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
						  const int S_out = C_out.strangeness_determine (shells_qn_mu);

						  const int iM_out = outSD.iM_determine (phi_mu_table);

						  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

						  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
						  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
						  class configuration &C_try = C_try_tab(i_thread);
				    
						  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
						  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				    
						  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

						  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

						  const int phase = parity_from_binary_parity (bin_phase);
				      
						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
						  (phase == 1)
						    ? (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component)
						    : (a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}
  
  a_dagger_a_tilde_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_tilde_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}














void dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
									 const enum dagger_tilde_operator_type Op , 
									 const class nljm_struct &phi_dagger_f , 
									 const class nljm_struct &phi_tilde_e , 
									 const class nljm_struct &phi_tilde_d , 
									 const class array<unsigned int> &inSD_tab ,
									 const class GSM_vector &PSI_IN ,
									 class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons () ;

  const int N_valence_baryons_IN = N_valence_baryons + 1;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_tilde_e.get_particle ();
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_tilde_e  = phi_tilde_e.get_n ();
  const int n_tilde_d  = phi_tilde_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_tilde_e  = phi_tilde_e.get_l ();
  const int l_tilde_d  = phi_tilde_d.get_l ();

  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_tilde_e  = phi_tilde_e.get_j ();
  const double m_tilde_e  = phi_tilde_e.get_m ();
  
  const double j_tilde_d  = phi_tilde_d.get_j ();
  const double m_tilde_d  = phi_tilde_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(particle_f , n_dagger_f , l_dagger_f , j_dagger_f ,  m_dagger_f);
  const unsigned int phi_tilde_e_index  = one_body_indices_mu(particle_e , n_tilde_e  , l_tilde_e  , j_tilde_e  , -m_tilde_e);
  const unsigned int phi_tilde_d_index  = one_body_indices_mu(particle_d , n_tilde_d  , l_tilde_d  , j_tilde_d  , -m_tilde_d);
  
  PSI_OUT = 0.0;
  
  if (phi_tilde_e_index == phi_tilde_d_index) return;
  
  const bool are_phi_dagger_f_phi_tilde_e_equal = (phi_dagger_f_index == phi_tilde_e_index);
  const bool are_phi_dagger_f_phi_tilde_d_equal = (phi_dagger_f_index == phi_tilde_d_index);
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);

	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  if (inSD.is_valence_state_occupied (phi_tilde_e_index) && inSD.is_valence_state_occupied (phi_tilde_d_index))
	    {
	      const bool is_phi_dagger_f_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_f_index);

	      if (is_phi_dagger_f_not_in_inSD || are_phi_dagger_f_phi_tilde_e_equal || are_phi_dagger_f_phi_tilde_d_equal)
		{	      
		  class Slater_determinant &outSD = outSD_work_tab(i_thread);

		  inSD.excitation_1p_2h_and_bin_phase (phi_dagger_f_index , phi_tilde_e_index , phi_tilde_d_index , outSD , bin_phase);

		  class configuration &C_out = C_out_work_tab(i_thread);

		  C_out.get_SD_configuration (phi_mu_table , outSD);

		  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
		  const int S_out = C_out.strangeness_determine (shells_qn_mu);

		  const int iM_out = outSD.iM_determine (phi_mu_table);

		  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

		  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
		  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		    
		  class configuration &C_try = C_try_tab(i_thread);
				    
		  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
		  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				    
		  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try); 

		  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

		  const int phase = parity_from_binary_parity (bin_phase);
				      
		  TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];				    

#ifdef UseOpenMP
#pragma omp critical
#endif
		  (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

		}}}}
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}




















void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (
									     const class nlj_struct &shell_dagger_a_qn , 
									     const class nlj_struct &shell_dagger_b_qn , 
									     const class nlj_struct &shell_dagger_c_qn , 
									     const class correlated_state_str &PSI_IN_qn , 
									     const class correlated_state_str &PSI_OUT_qn , 
									     const class GSM_vector &PSI_OUT ,
									     const class array<unsigned int> &inSD_tab ,
									     const class array<TYPE> &PSI_IN_component_tab ,
									     const class array<bool> &is_inSD_in_new_space_tab ,
									     const class array<unsigned char> &reordering_bin_phases ,
									     class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_dagger_c = shell_dagger_c_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();
  const int m_dagger_b_number = shell_dagger_b_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_dagger_a_dagger_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_dagger_c);

      a_dagger_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_dagger_MK_table = a_dagger_a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
	    {
	      const double m_dagger_a = im_dagger_a - j_dagger_a;
	  
	      const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
		      
	      if (phi_dagger_a_index != OUT_OF_RANGE)
		{
		  const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);
		  
		  if (is_phi_dagger_a_not_in_inSD)
		    {		      		      
		      for (int im_dagger_b = 0 ; im_dagger_b < m_dagger_b_number ; im_dagger_b++)
			{
			  const double m_dagger_b = im_dagger_b - j_dagger_b;

			  const unsigned int phi_dagger_b_index = one_body_indices_mu(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);
			  			  
			  if (phi_dagger_a_index != phi_dagger_b_index)
			    {
			      const bool is_phi_dagger_b_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_b_index);
		  
			      if (is_phi_dagger_b_not_in_inSD)
				{
				  const double m_dagger_c = MK - m_dagger_a - m_dagger_b;
	  
				  if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
				    {
				      const unsigned int phi_dagger_c_index = one_body_indices_mu(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

				      if (phi_dagger_c_index != OUT_OF_RANGE)
					{
					  if ((phi_dagger_a_index != phi_dagger_c_index) && (phi_dagger_b_index != phi_dagger_c_index))
					    {
					      const bool is_phi_dagger_c_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_c_index);
		  
					      if (is_phi_dagger_c_not_in_inSD)
						{
						  unsigned int bin_phase = reordering_bin_phase;
	      
						  class Slater_determinant &outSD = outSD_work_tab(i_thread);

						  inSD.excitation_3p_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_dagger_c_index , outSD , bin_phase);

						  class configuration &C_out = C_out_work_tab(i_thread);

						  C_out.get_SD_configuration (phi_mu_table , outSD);

						  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
						  const int S_out = C_out.strangeness_determine (shells_qn_mu);

						  const int iM_out = outSD.iM_determine (phi_mu_table);

						  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

						  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
						  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
						  class configuration &C_try = C_try_tab(i_thread);

						  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
						  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
						  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

						  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

						  const int phase = parity_from_binary_parity (bin_phase);
				      
						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
						  (phase == 1)
						    ? (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) += PSI_IN_component*PSI_OUT_component) 
						    : (a_dagger_a_dagger_a_dagger_MK_table(m_dagger_a , m_dagger_b , m_dagger_c) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}

  a_dagger_a_dagger_a_dagger_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_dagger_MK_table += a_dagger_a_dagger_a_dagger_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}









void dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (
									   const enum dagger_tilde_operator_type Op , 
									   const class nljm_struct &phi_dagger_f , 
									   const class nljm_struct &phi_dagger_e , 
									   const class nljm_struct &phi_dagger_d , 
									   const class array<unsigned int> &inSD_tab ,
									   const class GSM_vector &PSI_IN ,
									   class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operator only in dagger_tilde_operators::a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons - 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const enum particle_type particle_f = phi_dagger_f.get_particle ();  
  const enum particle_type particle_e = phi_dagger_e.get_particle ();
  const enum particle_type particle_d = phi_dagger_d.get_particle ();
  
  const int n_dagger_f = phi_dagger_f.get_n ();
  const int n_dagger_e = phi_dagger_e.get_n ();
  const int n_dagger_d = phi_dagger_d.get_n ();
  
  const int l_dagger_f = phi_dagger_f.get_l ();
  const int l_dagger_e = phi_dagger_e.get_l ();
  const int l_dagger_d = phi_dagger_d.get_l ();
  
  const double j_dagger_f = phi_dagger_f.get_j ();
  const double m_dagger_f = phi_dagger_f.get_m ();
  
  const double j_dagger_e = phi_dagger_e.get_j ();
  const double m_dagger_e = phi_dagger_e.get_m ();

  const double j_dagger_d = phi_dagger_d.get_j ();
  const double m_dagger_d = phi_dagger_d.get_m ();

  const unsigned int phi_dagger_f_index = one_body_indices_mu(particle_f , n_dagger_f , l_dagger_f , j_dagger_f , m_dagger_f);
  const unsigned int phi_dagger_e_index = one_body_indices_mu(particle_e , n_dagger_e , l_dagger_e , j_dagger_e , m_dagger_e);
  const unsigned int phi_dagger_d_index = one_body_indices_mu(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);
  
  const bool are_phi_dagger_fe_different = (phi_dagger_f_index != phi_dagger_e_index);
  const bool are_phi_dagger_fd_different = (phi_dagger_f_index != phi_dagger_d_index);
  const bool are_phi_dagger_ed_different = (phi_dagger_e_index != phi_dagger_d_index);
  
  PSI_OUT = 0.0;
  
  if (!are_phi_dagger_fe_different || !are_phi_dagger_fd_different || !are_phi_dagger_ed_different) return;
	
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];

	  if (!inSD.is_valence_state_occupied (phi_dagger_f_index) &&
	      !inSD.is_valence_state_occupied (phi_dagger_e_index) &&
	      !inSD.is_valence_state_occupied (phi_dagger_d_index))
	    {	      
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_3p_and_bin_phase (phi_dagger_f_index , phi_dagger_e_index , phi_dagger_d_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
				      
	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}

















void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (
									  const class nlj_struct &shell_tilde_a_qn , 
									  const class nlj_struct &shell_tilde_b_qn , 
									  const class nlj_struct &shell_tilde_c_qn , 
									  const class correlated_state_str &PSI_IN_qn , 
									  const class correlated_state_str &PSI_OUT_qn , 
									  const class GSM_vector &PSI_OUT ,
									  const class array<unsigned int> &inSD_tab ,
									  const class array<TYPE> &PSI_IN_component_tab ,
									  const class array<bool> &is_inSD_in_new_space_tab ,
									  const class array<unsigned char> &reordering_bin_phases ,
									  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons + 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double MK = M_OUT - M_IN;

  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  
  const int n_tilde_a = shell_tilde_a_qn.get_n ();
  const int n_tilde_b = shell_tilde_b_qn.get_n ();
  const int n_tilde_c = shell_tilde_c_qn.get_n ();
  
  const int l_tilde_a = shell_tilde_a_qn.get_l ();
  const int l_tilde_b = shell_tilde_b_qn.get_l ();
  const int l_tilde_c = shell_tilde_c_qn.get_l ();

  const double j_tilde_a = shell_tilde_a_qn.get_j ();
  const double j_tilde_b = shell_tilde_b_qn.get_j ();
  const double j_tilde_c = shell_tilde_c_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();
  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_tilde_a_tilde_a_tilde_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_tilde_c);

      a_tilde_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_tilde_MK_table = a_tilde_a_tilde_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
	    {
	      const double m_tilde_a = im_tilde_a - j_tilde_a;
	  
	      const unsigned int phi_tilde_a_index = one_body_indices_mu(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
		      
	      if (phi_tilde_a_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_a_in_inSD = inSD.is_valence_state_occupied (phi_tilde_a_index);
		  
		  if (is_phi_tilde_a_in_inSD)
		    {		      
		      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
			{
			  const double m_tilde_b = im_tilde_b - j_tilde_b;

			  const unsigned int phi_tilde_b_index = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);
			  
			  if ((phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_a_index != phi_tilde_b_index))
			    {
			      const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);
		  
			      if (is_phi_tilde_b_in_inSD)
				{		      
				  const double m_tilde_c = MK - m_tilde_a - m_tilde_b;
	  
				  if (rint (abs (m_tilde_c) - j_tilde_c) <= 0.0)
				    {
				      const unsigned int phi_tilde_c_index = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);

				      if ((phi_tilde_c_index != OUT_OF_RANGE) && (phi_tilde_a_index != phi_tilde_c_index) && (phi_tilde_b_index != phi_tilde_c_index))
					{						  
					  const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);
					      
					  if (is_phi_tilde_c_in_inSD)
					    {	
					      unsigned int bin_phase = reordering_bin_phase;
	      
					      class Slater_determinant &outSD = outSD_work_tab(i_thread);

					      inSD.excitation_3h_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_tilde_c_index , outSD , bin_phase);

					      class configuration &C_out = C_out_work_tab(i_thread);

					      C_out.get_SD_configuration (phi_mu_table , outSD);

					      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
					      const int S_out = C_out.strangeness_determine (shells_qn_mu);

					      const int iM_out = outSD.iM_determine (phi_mu_table);

					      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

					      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
					      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

					      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
					      class configuration &C_try = C_try_tab(i_thread);

					      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
					      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
					      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

					      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

					      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

					      const int phase = parity_from_binary_parity (bin_phase);
				      
					      const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
					      (phase == 1)
						? (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) += PSI_IN_component*PSI_OUT_component) 
						: (a_tilde_a_tilde_a_tilde_MK_table(m_tilde_a , m_tilde_b , m_tilde_c) -= PSI_IN_component*PSI_OUT_component);

					    }}}}}}}}}}}

  a_tilde_a_tilde_a_tilde_MK_table = 0.0;

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_tilde_MK_table += a_tilde_a_tilde_a_tilde_MK_tables(i);

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}








void dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc (
									const enum dagger_tilde_operator_type Op , 
									const class nljm_struct &phi_tilde_f , 
									const class nljm_struct &phi_tilde_e , 
									const class nljm_struct &phi_tilde_d , 
									const class array<unsigned int> &inSD_tab ,
									const class GSM_vector &PSI_IN ,
									class GSM_vector &PSI_OUT)
{
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons + 3;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();
  
  const enum particle_type particle_f = phi_tilde_f.get_particle ();
  const enum particle_type particle_e = phi_tilde_e.get_particle ();
  const enum particle_type particle_d = phi_tilde_d.get_particle ();
  
  const int n_tilde_f = phi_tilde_f.get_n ();
  const int n_tilde_e = phi_tilde_e.get_n ();
  const int n_tilde_d = phi_tilde_d.get_n ();
  
  const int l_tilde_f = phi_tilde_f.get_l ();
  const int l_tilde_e = phi_tilde_e.get_l ();
  const int l_tilde_d = phi_tilde_d.get_l ();
  
  const double j_tilde_f = phi_tilde_f.get_j ();
  const double m_tilde_f = phi_tilde_f.get_m ();
  
  const double j_tilde_e = phi_tilde_e.get_j ();
  const double m_tilde_e = phi_tilde_e.get_m ();

  const double j_tilde_d = phi_tilde_d.get_j ();
  const double m_tilde_d = phi_tilde_d.get_m ();

  const unsigned int phi_tilde_f_index = one_body_indices_mu(particle_f , n_tilde_f , l_tilde_f , j_tilde_f , -m_tilde_f);
  const unsigned int phi_tilde_e_index = one_body_indices_mu(particle_e , n_tilde_e , l_tilde_e , j_tilde_e , -m_tilde_e);
  const unsigned int phi_tilde_d_index = one_body_indices_mu(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
  
  const bool are_phi_tilde_fe_different = (phi_tilde_f_index != phi_tilde_e_index);
  const bool are_phi_tilde_fd_different = (phi_tilde_f_index != phi_tilde_d_index);
  const bool are_phi_tilde_ed_different = (phi_tilde_e_index != phi_tilde_d_index);
  
  PSI_OUT = 0.0;
  
  if (!are_phi_tilde_fe_different || !are_phi_tilde_fd_different || !are_phi_tilde_ed_different) return;
	
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
    }

  const unsigned int space_dimension_IN = PSI_IN.get_space_dimension ();
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  unsigned int bin_phase = 0;

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  
	      
	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
	      
	  if (inSD.is_valence_state_occupied (phi_tilde_f_index) &&
	      inSD.is_valence_state_occupied (phi_tilde_e_index) &&
	      inSD.is_valence_state_occupied (phi_tilde_d_index))
	    {	      
	      class Slater_determinant &outSD = outSD_work_tab(i_thread);

	      inSD.excitation_3h_and_bin_phase (phi_tilde_f_index , phi_tilde_e_index , phi_tilde_d_index , outSD , bin_phase);

	      class configuration &C_out = C_out_work_tab(i_thread);

	      C_out.get_SD_configuration (phi_mu_table , outSD);

	      const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
	      const int S_out = C_out.strangeness_determine (shells_qn_mu);

	      const int iM_out = outSD.iM_determine (phi_mu_table);

	      const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

	      const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
	      const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      class configuration &C_try = C_try_tab(i_thread);

	      class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
	      const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				      
	      const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

	      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

	      const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

	      const int phase = parity_from_binary_parity (bin_phase);
				      
	      TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
#ifdef UseOpenMP
#pragma omp critical
#endif
	      (phase == 1) ? (PSI_OUT_component += PSI_IN_component) : (PSI_OUT_component -= PSI_IN_component);

	    }
	}
    }
      
#ifdef UseMPI
      
  if (is_it_MPI_parallelized) PSI_OUT.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
}












void dagger_tilde_operators::a_dagger_a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (
										    const class nlj_struct &shell_dagger_a_qn , 
										    const class nlj_struct &shell_dagger_b_qn , 
										    const class nlj_struct &shell_tilde_c_qn , 
										    const class nlj_struct &shell_tilde_d_qn , 
										    const class correlated_state_str &PSI_IN_qn , 
										    const class correlated_state_str &PSI_OUT_qn , 
										    const class GSM_vector &PSI_OUT ,
										    const class array<unsigned int> &inSD_tab ,
										    const class array<TYPE> &PSI_IN_component_tab ,
										    const class array<bool> &is_inSD_in_new_space_tab ,
										    const class array<unsigned char> &reordering_bin_phases ,
										    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_dagger_b_qn.get_particle ();
  const enum particle_type particle_c = shell_tilde_c_qn.get_particle ();
  const enum particle_type particle_d = shell_tilde_d_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_dagger_b = shell_dagger_b_qn.get_n ();
  const int n_tilde_c  = shell_tilde_c_qn.get_n ();
  const int n_tilde_d  = shell_tilde_d_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_dagger_b = shell_dagger_b_qn.get_l ();
  const int l_tilde_c  = shell_tilde_c_qn.get_l ();
  const int l_tilde_d  = shell_tilde_d_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_dagger_b = shell_dagger_b_qn.get_j ();
  const double j_tilde_c  = shell_tilde_c_qn.get_j ();
  const double j_tilde_d  = shell_tilde_d_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();

  const int m_tilde_c_number = shell_tilde_c_qn.m_number_determine ();
  const int m_tilde_d_number = shell_tilde_d_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i).allocate (j_dagger_a , j_dagger_b , j_tilde_c , j_tilde_d);

      a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_dagger_a_tilde_a_tilde_MK_table = a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_c = 0 ; im_tilde_c < m_tilde_c_number ; im_tilde_c++)
	    {
	      const double m_tilde_c = im_tilde_c - j_tilde_c;
		  
	      const unsigned int phi_tilde_c_index  = one_body_indices_mu(particle_c , n_tilde_c , l_tilde_c , j_tilde_c , -m_tilde_c);
		  
	      if (phi_tilde_c_index != OUT_OF_RANGE)
		{	
		  const bool is_phi_tilde_c_in_inSD = inSD.is_valence_state_occupied (phi_tilde_c_index);
				  
		  if (is_phi_tilde_c_in_inSD)
		    {
		      for (int im_tilde_d = 0 ; im_tilde_d < m_tilde_d_number ; im_tilde_d++)
			{
			  const double m_tilde_d = im_tilde_d - j_tilde_d;

			  const unsigned int phi_tilde_d_index = one_body_indices_mu(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);

			  if ((phi_tilde_d_index != OUT_OF_RANGE) && (phi_tilde_c_index != phi_tilde_d_index))
			    {
			      const bool is_phi_tilde_d_in_inSD = inSD.is_valence_state_occupied (phi_tilde_d_index);

			      if (is_phi_tilde_d_in_inSD)
				{
				  const int Mcd = make_int (m_tilde_c + m_tilde_d);
			  
				  for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
				    {
				      const double m_dagger_a = im_dagger_a - j_dagger_a;
		  		      
				      const double m_dagger_b = MK - Mcd - m_dagger_a;
	  
				      if (rint (abs (m_dagger_b) - j_dagger_b) <= 0.0)
					{
					  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
					  const unsigned int phi_dagger_b_index = one_body_indices_mu(particle_b , n_dagger_b , l_dagger_b , j_dagger_b , m_dagger_b);

					  if ((phi_dagger_a_index != OUT_OF_RANGE) && (phi_dagger_b_index != OUT_OF_RANGE) && (phi_dagger_a_index != phi_dagger_b_index))
					    {
					      const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);
					      const bool is_phi_dagger_b_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_b_index);
				      
					      const bool are_phi_tilde_c_phi_dagger_a_equal = (phi_tilde_c_index == phi_dagger_a_index);
					      const bool are_phi_tilde_d_phi_dagger_a_equal = (phi_tilde_d_index == phi_dagger_a_index);
					      const bool are_phi_tilde_c_phi_dagger_b_equal = (phi_tilde_c_index == phi_dagger_b_index);
					      const bool are_phi_tilde_d_phi_dagger_b_equal = (phi_tilde_d_index == phi_dagger_b_index);
				      
					      const bool phi_tilde_c_phi_dagger_b_equal_case = (are_phi_tilde_c_phi_dagger_b_equal && (is_phi_dagger_a_not_in_inSD || are_phi_tilde_d_phi_dagger_a_equal));
					      const bool phi_tilde_d_phi_dagger_b_equal_case = (are_phi_tilde_d_phi_dagger_b_equal && (is_phi_dagger_a_not_in_inSD || are_phi_tilde_c_phi_dagger_a_equal));
					      const bool phi_tilde_c_phi_dagger_a_equal_case = (are_phi_tilde_c_phi_dagger_a_equal && (is_phi_dagger_b_not_in_inSD || are_phi_tilde_d_phi_dagger_b_equal));
					      const bool phi_tilde_d_phi_dagger_a_equal_case = (are_phi_tilde_d_phi_dagger_a_equal && (is_phi_dagger_b_not_in_inSD || are_phi_tilde_c_phi_dagger_b_equal));

					      const bool dagger_a_conditions = (is_phi_dagger_a_not_in_inSD || phi_tilde_c_phi_dagger_a_equal_case || phi_tilde_d_phi_dagger_a_equal_case);
					      const bool dagger_b_conditions = (is_phi_dagger_b_not_in_inSD || phi_tilde_c_phi_dagger_b_equal_case || phi_tilde_d_phi_dagger_b_equal_case);
				  
					      if (dagger_a_conditions && dagger_b_conditions)
						{
						  unsigned int bin_phase = reordering_bin_phase;
	      
						  class Slater_determinant &outSD = outSD_work_tab(i_thread);

						  inSD.excitation_2p_2h_and_bin_phase (phi_dagger_a_index , phi_dagger_b_index , phi_tilde_c_index , phi_tilde_d_index , outSD , bin_phase);

						  class configuration &C_out = C_out_work_tab(i_thread);
					  
						  C_out.get_SD_configuration (phi_mu_table , outSD);

						  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
						  const int S_out = C_out.strangeness_determine (shells_qn_mu);

						  const int iM_out = outSD.iM_determine (phi_mu_table);

						  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

						  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
						  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
						  class configuration &C_try = C_try_tab(i_thread);

						  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
						  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				  
						  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

						  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

						  const int phase = parity_from_binary_parity (bin_phase);
				      
						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
						  
						  (phase == 1)
						    ? (a_dagger_a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c , m_tilde_d) += PSI_IN_component*PSI_OUT_component) 
						    : (a_dagger_a_dagger_a_tilde_a_tilde_MK_table(m_dagger_a , m_dagger_b , m_tilde_c , m_tilde_d) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}
  
  a_dagger_a_dagger_a_tilde_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_dagger_a_tilde_a_tilde_MK_table += a_dagger_a_dagger_a_tilde_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_dagger_a_tilde_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}










void dagger_tilde_operators::a_dagger_a_tilde_a_dagger_a_tilde_MK_table_pp_nn_calc (
										    const class nlj_struct &shell_dagger_a_qn , 
										    const class nlj_struct &shell_tilde_b_qn , 
										    const class nlj_struct &shell_dagger_c_qn , 
										    const class nlj_struct &shell_tilde_d_qn , 
										    const class correlated_state_str &PSI_IN_qn , 
										    const class correlated_state_str &PSI_OUT_qn , 
										    const class GSM_vector &PSI_OUT ,
										    const class array<unsigned int> &inSD_tab ,
										    const class array<TYPE> &PSI_IN_component_tab ,
										    const class array<bool> &is_inSD_in_new_space_tab ,
										    const class array<unsigned char> &reordering_bin_phases ,
										    class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_dagger_a_tilde_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const enum particle_type particle_a = shell_dagger_a_qn.get_particle ();
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle ();
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  const enum particle_type particle_d = shell_tilde_d_qn.get_particle ();
  
  const int n_dagger_a = shell_dagger_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  const int n_tilde_d  = shell_tilde_d_qn.get_n ();
  
  const int l_dagger_a = shell_dagger_a_qn.get_l ();
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();
  const int l_dagger_c = shell_dagger_c_qn.get_l ();
  const int l_tilde_d  = shell_tilde_d_qn.get_l ();

  const double j_dagger_a = shell_dagger_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  const double j_tilde_d  = shell_tilde_d_qn.get_j ();

  const int m_dagger_a_number = shell_dagger_a_qn.m_number_determine ();

  const int m_tilde_b_number = shell_tilde_b_qn.m_number_determine ();
  const int m_tilde_d_number = shell_tilde_d_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i).allocate (j_dagger_a , j_tilde_b , j_dagger_c , j_tilde_d);

      a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_dagger_a_tilde_a_dagger_a_tilde_MK_table = a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i_thread);
	  
	  for (int im_tilde_d = 0 ; im_tilde_d < m_tilde_d_number ; im_tilde_d++)
	    {
	      const double m_tilde_d = im_tilde_d - j_tilde_d;

	      const unsigned int phi_tilde_d_index = one_body_indices_mu(particle_d , n_tilde_d , l_tilde_d , j_tilde_d , -m_tilde_d);
		     
	      if (phi_tilde_d_index != OUT_OF_RANGE)
		{
		  const bool is_phi_tilde_d_in_inSD = inSD.is_valence_state_occupied (phi_tilde_d_index);
		  
		  if (is_phi_tilde_d_in_inSD)
		    {		  
		      for (int im_tilde_b = 0 ; im_tilde_b < m_tilde_b_number ; im_tilde_b++)
			{
			  const double m_tilde_b = im_tilde_b - j_tilde_b;

			  const unsigned int phi_tilde_b_index = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);

			  if (phi_tilde_b_index != OUT_OF_RANGE)
			    {	
			      const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);
									  
			      const bool are_phi_tilde_bd_equal = (phi_tilde_b_index == phi_tilde_d_index);

			      const bool is_phi_tilde_b_in_inSD_and_are_bd_different = (is_phi_tilde_b_in_inSD && !are_phi_tilde_bd_equal);

			      const int Mbd = make_int (m_tilde_b + m_tilde_d);
			      
			      for (int im_dagger_a = 0 ; im_dagger_a < m_dagger_a_number ; im_dagger_a++)
				{
				  const double m_dagger_a = im_dagger_a - j_dagger_a;
				  
				  const unsigned int phi_dagger_a_index = one_body_indices_mu(particle_a , n_dagger_a , l_dagger_a , j_dagger_a , m_dagger_a);
				  
				  if (phi_dagger_a_index != OUT_OF_RANGE)
				    {		  
				      const double m_dagger_c = MK - m_dagger_a - Mbd;
	  
				      if (rint (abs (m_dagger_c) - j_dagger_c) <= 0.0)
					{
					  const unsigned int phi_dagger_c_index = one_body_indices_mu(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);
					  
					  if (phi_dagger_c_index != OUT_OF_RANGE)
					    {
					      const bool are_phi_tilde_b_phi_dagger_c_equal = (phi_tilde_b_index == phi_dagger_c_index);
					  
					      const bool are_phi_dagger_ac_equal = (phi_dagger_a_index == phi_dagger_c_index);
			      
					      if (!are_phi_tilde_b_phi_dagger_c_equal && (!is_phi_tilde_b_in_inSD_and_are_bd_different || are_phi_dagger_ac_equal)) continue;

					      if (are_phi_tilde_b_phi_dagger_c_equal && is_phi_tilde_b_in_inSD_and_are_bd_different) continue;
			      
					      const bool are_phi_tilde_b_phi_dagger_a_equal = (phi_tilde_b_index == phi_dagger_a_index);
					      const bool are_phi_tilde_d_phi_dagger_a_equal = (phi_tilde_d_index == phi_dagger_a_index);
					      const bool are_phi_tilde_d_phi_dagger_c_equal = (phi_tilde_d_index == phi_dagger_c_index);
					      
					      const bool is_phi_dagger_a_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_a_index);
					      const bool is_phi_dagger_c_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_c_index);
					  					  
					      const bool bc_equal_case = (are_phi_tilde_b_phi_dagger_c_equal && (is_phi_dagger_a_not_in_inSD || are_phi_tilde_d_phi_dagger_a_equal));
					  
					      const bool dagger_a_conditions_bc_different = (is_phi_dagger_a_not_in_inSD || are_phi_tilde_b_phi_dagger_a_equal || are_phi_tilde_d_phi_dagger_a_equal);
					      const bool dagger_c_conditions_bc_different = (is_phi_dagger_c_not_in_inSD || are_phi_tilde_b_phi_dagger_c_equal || are_phi_tilde_d_phi_dagger_c_equal);
				  
					      const bool bc_different_case = (!are_phi_tilde_b_phi_dagger_c_equal && dagger_a_conditions_bc_different && dagger_c_conditions_bc_different);

					      if (bc_equal_case || bc_different_case)
						{
						  unsigned int bin_phase = reordering_bin_phase;
	      
						  class Slater_determinant &outSD = outSD_work_tab(i_thread);

						  inSD.excitation_1p_1h_1p_1h_and_bin_phase (phi_dagger_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_tilde_d_index , outSD , bin_phase);

						  class configuration &C_out = C_out_work_tab(i_thread);

						  C_out.get_SD_configuration (phi_mu_table , outSD);

						  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
						  const int S_out = C_out.strangeness_determine (shells_qn_mu);

						  const int iM_out = outSD.iM_determine (phi_mu_table);

						  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

						  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
						  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
						  class configuration &C_try = C_try_tab(i_thread);

						  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
						  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				  
						  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

						  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

						  const int phase = parity_from_binary_parity (bin_phase);
				      
						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
						  (phase == 1)
						    ? (a_dagger_a_tilde_a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_dagger_c , m_tilde_d) += PSI_IN_component*PSI_OUT_component) 
						    : (a_dagger_a_tilde_a_dagger_a_tilde_MK_table(m_dagger_a , m_tilde_b , m_dagger_c , m_tilde_d) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}
  
  a_dagger_a_tilde_a_dagger_a_tilde_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_dagger_a_tilde_a_dagger_a_tilde_MK_table += a_dagger_a_tilde_a_dagger_a_tilde_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_dagger_a_tilde_a_dagger_a_tilde_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}








void dagger_tilde_operators::a_tilde_a_tilde_a_dagger_a_dagger_MK_table_pp_nn_calc (
										    const class nlj_struct &shell_tilde_a_qn , 
										    const class nlj_struct &shell_tilde_b_qn , 
										    const class nlj_struct &shell_dagger_c_qn , 
										    const class nlj_struct &shell_dagger_d_qn , 
										    const class correlated_state_str &PSI_IN_qn , 
										    const class correlated_state_str &PSI_OUT_qn , 
										    const class GSM_vector &PSI_OUT ,
										    const class array<unsigned int> &inSD_tab ,
										    const class array<TYPE> &PSI_IN_component_tab ,
										    const class array<bool> &is_inSD_in_new_space_tab ,
										    const class array<unsigned char> &reordering_bin_phases ,
										    class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_dagger_a_dagger_MK_table)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == NEUT_Y_ONLY) ? (neut_Y_data) : (prot_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const int N_valence_baryons_IN = N_valence_baryons;
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class array<class nlj_struct> &shells_qn_mu = data.get_shells_quantum_numbers ();

  const class one_body_indices_str &one_body_indices_mu = data.get_one_body_indices ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = data.get_dimensions_SD_set ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class array<unsigned int> &dimensions_configuration_set = data.get_dimensions_configuration_set ();

  const class array_of_configuration &configuration_set = data.get_configuration_set ();

  const class array<class nljm_struct> &phi_mu_table = data.get_phi_table ();

  const class array<class lj_table<int> > &nmax_lj_tabs_mu = data.get_nmax_lj_tabs ();

  const class array<class nlj_table<bool> > &is_it_valence_shell_tabs_mu = data.get_is_it_valence_shell_tabs ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int MK = make_int (M_OUT - M_IN);

  const enum particle_type particle_a = shell_tilde_a_qn.get_particle ();  
  const enum particle_type particle_b = shell_tilde_b_qn.get_particle (); 
  const enum particle_type particle_c = shell_dagger_c_qn.get_particle ();
  const enum particle_type particle_d = shell_dagger_d_qn.get_particle ();
  
  const int n_tilde_a  = shell_tilde_a_qn.get_n ();
  const int n_tilde_b  = shell_tilde_b_qn.get_n ();
  const int n_dagger_c = shell_dagger_c_qn.get_n ();
  const int n_dagger_d = shell_dagger_d_qn.get_n ();
  
  const int l_tilde_a  = shell_tilde_a_qn.get_l ();
  const int l_tilde_b  = shell_tilde_b_qn.get_l ();
  const int l_dagger_c = shell_dagger_c_qn.get_l ();
  const int l_dagger_d = shell_dagger_d_qn.get_l ();

  const double j_tilde_a  = shell_tilde_a_qn.get_j ();
  const double j_tilde_b  = shell_tilde_b_qn.get_j ();
  const double j_dagger_c = shell_dagger_c_qn.get_j ();
  const double j_dagger_d = shell_dagger_d_qn.get_j ();

  const int m_tilde_a_number = shell_tilde_a_qn.m_number_determine ();

  const int m_dagger_c_number = shell_dagger_c_qn.m_number_determine ();
  const int m_dagger_d_number = shell_dagger_d_qn.m_number_determine ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  class array<class Slater_determinant>  inSD_work_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSD_work_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SD_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> C_out_work_tab(NUMBER_OF_THREADS);
  
  class array<class configuration> C_try_tab(NUMBER_OF_THREADS);

  class array<class uncoupled_dagger_tilde_table<TYPE> > a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      inSD_work_tab(i).allocate (N_valence_baryons_IN);

      outSD_work_tab(i).allocate (N_valence_baryons);

      SD_try_tab(i).allocate (N_valence_baryons);

      C_out_work_tab(i).allocate (N_valence_baryons);

      C_try_tab(i).allocate (N_valence_baryons);
      
      a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i).allocate (j_tilde_a , j_tilde_b , j_dagger_c , j_dagger_d);

      a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i) = 0.0;
    }

  const unsigned int space_dimension_IN = PSI_IN_component_tab.dimension (0);
    
  const bool is_process_active = is_process_active_for_MPI (space_dimension_IN , THIS_PROCESS);
  
  if (is_process_active) 
    {
      const unsigned int first_PSI_IN_index = basic_first_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);
      const unsigned int last_PSI_IN_index = basic_last_index_determine_for_MPI (space_dimension_IN , NUMBER_OF_PROCESSES , THIS_PROCESS);	      
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int PSI_IN_index = first_PSI_IN_index ; PSI_IN_index <= last_PSI_IN_index ; PSI_IN_index++)
	{
	  if (!is_inSD_in_new_space_tab(PSI_IN_index)) continue;
	      
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
      
	  const unsigned int reordering_bin_phase = reordering_bin_phases(PSI_IN_index);

	  class Slater_determinant &inSD = inSD_work_tab(i_thread);	  

	  for (int i = 0 ; i < N_valence_baryons_IN ; i++) inSD[i] = inSD_tab(PSI_IN_index , i);
      
	  if (!inSD.is_it_in_new_space (phi_mu_table , nmax_lj_tabs_mu , is_it_valence_shell_tabs_mu)) continue;
	  
	  const TYPE &PSI_IN_component = PSI_IN_component_tab(PSI_IN_index);

	  class uncoupled_dagger_tilde_table<TYPE> &a_tilde_a_tilde_a_dagger_a_dagger_MK_table = a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i_thread);

	  for (int im_dagger_c = 0 ; im_dagger_c < m_dagger_c_number ; im_dagger_c++)
	    {
	      const double m_dagger_c = im_dagger_c - j_dagger_c;

	      const unsigned int phi_dagger_c_index = one_body_indices_mu(particle_c , n_dagger_c , l_dagger_c , j_dagger_c , m_dagger_c);

	      if (phi_dagger_c_index != OUT_OF_RANGE)
		{
		  const bool is_phi_dagger_c_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_c_index);
		  
		  if (is_phi_dagger_c_not_in_inSD)
		    {
		      for (int im_dagger_d = 0 ; im_dagger_d < m_dagger_d_number ; im_dagger_d++)
			{
			  const double m_dagger_d = im_dagger_d - j_dagger_d;

			  const unsigned int phi_dagger_d_index = one_body_indices_mu(particle_d , n_dagger_d , l_dagger_d , j_dagger_d , m_dagger_d);

			  if ((phi_dagger_d_index != OUT_OF_RANGE) && (phi_dagger_c_index != phi_dagger_d_index))
			    {
			      const bool is_phi_dagger_d_not_in_inSD = !inSD.is_valence_state_occupied (phi_dagger_d_index);
				  
			      if (is_phi_dagger_d_not_in_inSD)
				{		 
				  const int Mcd = make_int (m_dagger_c + m_dagger_d);
				  
				  for (int im_tilde_a = 0 ; im_tilde_a < m_tilde_a_number ; im_tilde_a++)
				    {
				      const double m_tilde_a = im_tilde_a - j_tilde_a;		      
					  
				      const double m_tilde_b = MK - Mcd - m_tilde_a;
		  	  
				      if (rint (abs (m_tilde_b) - j_tilde_b) <= 0.0)
					{			  
					  const unsigned int phi_tilde_a_index  = one_body_indices_mu(particle_a , n_tilde_a , l_tilde_a , j_tilde_a , -m_tilde_a);
					  const unsigned int phi_tilde_b_index  = one_body_indices_mu(particle_b , n_tilde_b , l_tilde_b , j_tilde_b , -m_tilde_b);			  

					  if ((phi_tilde_a_index != OUT_OF_RANGE) && (phi_tilde_b_index != OUT_OF_RANGE) && (phi_tilde_a_index != phi_tilde_b_index))
					    {
					      const bool is_phi_tilde_a_in_inSD = inSD.is_valence_state_occupied (phi_tilde_a_index);
					      const bool is_phi_tilde_b_in_inSD = inSD.is_valence_state_occupied (phi_tilde_b_index);
					  
					      const bool are_phi_tilde_a_phi_dagger_c_equal = (phi_tilde_a_index == phi_dagger_c_index);
					      const bool are_phi_tilde_a_phi_dagger_d_equal = (phi_tilde_a_index == phi_dagger_d_index);					  
					      const bool are_phi_tilde_b_phi_dagger_c_equal = (phi_tilde_b_index == phi_dagger_c_index);
					      const bool are_phi_tilde_b_phi_dagger_d_equal = (phi_tilde_b_index == phi_dagger_d_index);
						      
					      const bool phi_tilde_a_phi_dagger_c_equal_case = (are_phi_tilde_a_phi_dagger_c_equal && (is_phi_tilde_b_in_inSD || are_phi_tilde_b_phi_dagger_d_equal));
					      const bool phi_tilde_a_phi_dagger_d_equal_case = (are_phi_tilde_a_phi_dagger_d_equal && (is_phi_tilde_b_in_inSD || are_phi_tilde_b_phi_dagger_c_equal));
					      const bool phi_tilde_b_phi_dagger_c_equal_case = (are_phi_tilde_b_phi_dagger_c_equal && (is_phi_tilde_a_in_inSD || are_phi_tilde_a_phi_dagger_d_equal));
					      const bool phi_tilde_b_phi_dagger_d_equal_case = (are_phi_tilde_b_phi_dagger_d_equal && (is_phi_tilde_a_in_inSD || are_phi_tilde_a_phi_dagger_c_equal));
					  
					      const bool tilde_a_conditions = (is_phi_tilde_a_in_inSD || phi_tilde_a_phi_dagger_c_equal_case || phi_tilde_a_phi_dagger_d_equal_case);
					      const bool tilde_b_conditions = (is_phi_tilde_b_in_inSD || phi_tilde_b_phi_dagger_c_equal_case || phi_tilde_b_phi_dagger_d_equal_case);

					      if (tilde_a_conditions && tilde_b_conditions)
						{
						  unsigned int bin_phase = reordering_bin_phase;
	      
						  class Slater_determinant &outSD = outSD_work_tab(i_thread);

						  inSD.excitation_2h_2p_and_bin_phase (phi_tilde_a_index , phi_tilde_b_index , phi_dagger_c_index , phi_dagger_d_index , outSD , bin_phase);

						  class configuration &C_out = C_out_work_tab(i_thread);
						  
						  C_out.get_SD_configuration (phi_mu_table , outSD);

						  const unsigned int BP_out = C_out.BP_determine (shells_qn_mu);
	      
						  const int S_out = C_out.strangeness_determine (shells_qn_mu);

						  const int iM_out = outSD.iM_determine (phi_mu_table);

						  const int E_out_hw = C_out.E_hw_determine (shells_qn_mu);

						  const int n_holes_out = C_out.n_holes_determine (shells_qn_mu);
			  
						  const int n_scat_out = C_out.n_scat_determine (shells_qn_mu);

						  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
				    
						  class configuration &C_try = C_try_tab(i_thread);

						  class Slater_determinant &SD_try = SD_try_tab(i_thread);
				    
						  const unsigned int iC_out = C_out.index_search (BP_out , S_out , 0 , n_scat_out , dimensions_configuration_set , configuration_set , C_try);
				  
						  const unsigned int outSD_index = outSD.index_search (BP_out , S_out , 0 , n_scat_out , iC_out , iM_out , dimensions_SD_set , SD_set , SD_try);

						  const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_OUT(n_scat_out , iC_out);

						  const unsigned int PSI_OUT_index = sum_dimensions_configuration_fixed_out + outSD_index;

						  const int phase = parity_from_binary_parity (bin_phase);
				      
						  const TYPE &PSI_OUT_component = PSI_OUT[PSI_OUT_index];
				    
						  (phase == 1)
						    ? (a_tilde_a_tilde_a_dagger_a_dagger_MK_table(m_tilde_a , m_tilde_b , m_dagger_c , m_dagger_d) += PSI_IN_component*PSI_OUT_component) 
						    : (a_tilde_a_tilde_a_dagger_a_dagger_MK_table(m_tilde_a , m_tilde_b , m_dagger_c , m_dagger_d) -= PSI_IN_component*PSI_OUT_component);

						}}}}}}}}}}}}
  
  a_tilde_a_tilde_a_dagger_a_dagger_MK_table = 0.0;
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++) a_tilde_a_tilde_a_dagger_a_dagger_MK_table += a_tilde_a_tilde_a_dagger_a_dagger_MK_tables(i);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) a_tilde_a_tilde_a_dagger_a_dagger_MK_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}












void dagger_tilde_operators::one_body_K_tables_calc_store (
							   const enum dagger_tilde_operator_type Op , 
							   const class correlated_state_str &PSI_IN_qn , 
							   const class correlated_state_str &PSI_OUT_qn , 
							   const class GSM_vector &PSI_OUT)
{
  if (!is_it_one_body_determine (Op)) error_message_print_abort ("One-body operators only in dagger_tilde_operators::one_body_K_tables_calc_store");
    
  if (is_it_RDM_determine (Op)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::one_body_K_tables_calc_store");
  
  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0);
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();

  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);
  
  const int S_IN  = PSI_IN_qn.get_S ();
  const int S_OUT = PSI_OUT_qn.get_S ();

  const int S_dagger_tilde = S_OUT - S_IN;
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double Kmin_PSI = abs (J_IN - J_OUT);
  const double Kmax_PSI =      J_IN + J_OUT;

  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
      
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + ".dat";
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);

  const string file_name_IN_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_baryons_IN = (space == PROT_Y_ONLY) ? (ZYval_IN) : (NYval_IN);
  
  const unsigned int space_dimension_IN = (space == PROT_NEUT_Y)
    ? (space_dimension_read_disk (true , ZYval_IN , NYval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (N_valence_baryons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , prot_Y_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , neut_Y_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_baryon (true , ZYval_IN , NYval_IN , PSI_IN_qn , M_IN , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
    
  const int K_number_PSI = make_int (Kmax_PSI - Kmin_PSI) + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }

  for (unsigned int sa = 0 ; sa < N_nlj_baryon_a ; sa++)
    {
      const class nlj_struct &shell_sa_qn = shells_a_qn(sa);

      const bool frozen_state_a = shell_sa_qn.get_frozen_state ();

      const enum particle_type particle_a = shell_sa_qn.get_particle ();
      
      const bool is_it_spectator_a = (particle_a == SPECTATOR);
		    
      if (!frozen_state_a && !is_it_spectator_a)
	{
	  const int Sa = particle_strangeness_determine (particle_a);
	  
	  const int S_dagger_tilde_a = (is_it_dagger_a) ? (Sa) : (-Sa);
	  
	  const int la = shell_sa_qn.get_l ();

	  const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);

	  if ((bp_a == BP_dagger_tilde) && (S_dagger_tilde_a == S_dagger_tilde))
	    {
	      const double ja = shell_sa_qn.get_j ();

	      if (is_it_triangle (J_IN , J_OUT , ja))
		{
		  class uncoupled_dagger_tilde_table<TYPE> one_body_MK_table(ja);

		  switch (space)
		    {
		    case PROT_Y_ONLY:
		      {
			if (is_it_dagger_a)
			  a_dagger_MK_table_pp_nn_calc (shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , one_body_MK_table);

			else
			  a_tilde_MK_table_pp_nn_calc (shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
						       inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , one_body_MK_table);
		      } break;

		    case NEUT_Y_ONLY:
		      {
			if (is_it_dagger_a)
			  a_dagger_MK_table_pp_nn_calc (shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , one_body_MK_table);
			else
			  a_tilde_MK_table_pp_nn_calc (shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
						       inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , one_body_MK_table);
		      } break;

		
		    case PROT_NEUT_Y:
		      {
			if (is_it_dagger_a)
			  a_dagger_MK_table_pn_calc (Op , shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
						     inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
						     reordering_bin_phases_p , reordering_bin_phases_n , one_body_MK_table);
			else
			  a_tilde_MK_table_pn_calc (Op , shell_sa_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
						    inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
						    reordering_bin_phases_p , reordering_bin_phases_n , one_body_MK_table);
		      
		      } break;
		    
		    default: abort_all ();
		    }
		
		  if (THIS_PROCESS == MASTER_PROCESS)
		    {		    
		      class coupled_dagger_tilde_table<TYPE> one_body_K_table(Op , ja);

		      one_body_K_table_from_MK_table_calc  (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms , one_body_MK_table , one_body_K_table);

		      outfile << particle_a << " " << shell_sa_qn;

		      if (!is_it_dagger_a) outfile << "~";
		
		      outfile << " " << one_body_K_table(ja) << endl;
		    }}}}}
}









void dagger_tilde_operators::two_body_K_tables_calc_store (
							   const enum dagger_tilde_operator_type Op , 
							   const class correlated_state_str &PSI_IN_qn , 
							   const class correlated_state_str &PSI_OUT_qn , 
							   const class GSM_vector &PSI_OUT)
{
  if (!is_it_two_body_determine (Op)) error_message_print_abort ("Two-body operators only in dagger_tilde_operators::two_body_K_tables_calc_store");
    
  if (is_it_RDM_determine (Op)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::two_body_K_tables_calc_store");
  
  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (Op , 1);
  
  const bool is_it_a_dagger_a_tilde  = ( is_it_dagger_a && !is_it_dagger_b);
  const bool is_it_a_dagger_a_dagger = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde   = (!is_it_dagger_a && !is_it_dagger_b);
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon ();
  const unsigned int N_nlj_baryon_b = data_b.get_N_nlj_baryon ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();

  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);

  const int S_IN  = PSI_IN_qn.get_S ();
  const int S_OUT = PSI_OUT_qn.get_S ();

  const int S_dagger_tilde = S_OUT - S_IN;
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int Kmin_PSI = abs (make_int (J_IN - J_OUT));
  const int Kmax_PSI =      make_int (J_IN + J_OUT);

  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
      
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + ".dat";
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);

  const string file_name_IN_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_baryons_IN = (space == PROT_Y_ONLY) ? (ZYval_IN) : (NYval_IN);
  
  const unsigned int space_dimension_IN = (space == PROT_NEUT_Y)
    ? (space_dimension_read_disk (true , ZYval_IN , NYval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (N_valence_baryons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , prot_Y_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , neut_Y_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_baryon (true , ZYval_IN , NYval_IN , PSI_IN_qn , M_IN , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();

  const double m_max = max (ma_max , mb_max);
  
  const class CG_str CGs(m_max);
  
  const int K_number_PSI = Kmax_PSI - Kmin_PSI + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }

  for (unsigned int sa = 0 ; sa < N_nlj_baryon_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_baryon_b ; sb++)
      {	  
	const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_b_qn(sb);

	const enum particle_type particle_a = shell_sa_qn.get_particle ();
	const enum particle_type particle_b = shell_sb_qn.get_particle ();
	
	const bool ab_shells_ordered = ((particle_a != particle_b) || (sa <= sb));

	if (is_it_a_dagger_a_dagger && !ab_shells_ordered) continue;
	if (is_it_a_tilde_a_tilde   && !ab_shells_ordered) continue;
      
	const bool is_it_spectator_a = (particle_a == SPECTATOR);
	const bool is_it_spectator_b = (particle_b == SPECTATOR);
		    
	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
		    
	if (!frozen_state_a && !frozen_state_b && !is_it_spectator_a && !is_it_spectator_b)
	  {	
	    const int Sa = particle_strangeness_determine (particle_a) , S_dagger_tilde_a = (is_it_dagger_a) ? (Sa) : (-Sa);
	    const int Sb = particle_strangeness_determine (particle_b) , S_dagger_tilde_b = (is_it_dagger_b) ? (Sb) : (-Sb);

	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();
	    
	    const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
	    
	    const int S_dagger_tilde_ab = S_dagger_tilde_a + S_dagger_tilde_b;
	      
	    if ((bp_ab == BP_dagger_tilde) && (S_dagger_tilde_ab == S_dagger_tilde))
	      {
		const double ja = shell_sa_qn.get_j ();
		const double jb = shell_sb_qn.get_j ();

		class uncoupled_dagger_tilde_table<TYPE> two_body_MK_table(ja , jb);

		switch (space)
		  {
		  case PROT_Y_ONLY:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							      inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);

		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							       inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							     inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table);
		    } break;

		  case NEUT_Y_ONLY:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							      inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		      
		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							       inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							     inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table);
		    } break;

		
		  case PROT_NEUT_Y:
		    {
		      if (is_it_a_dagger_a_tilde)
			a_dagger_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							   inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							   reordering_bin_phases_p , reordering_bin_phases_n , two_body_MK_table);

		      if (is_it_a_dagger_a_dagger)
			a_dagger_a_dagger_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							    inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							    reordering_bin_phases_p , reordering_bin_phases_n , two_body_MK_table);
		      
		      if (is_it_a_tilde_a_tilde)
			a_tilde_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
							  inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							  reordering_bin_phases_p , reordering_bin_phases_n , two_body_MK_table);
		      
		    } break;
		    
		  default: abort_all ();
		  }
		
		if (THIS_PROCESS == MASTER_PROCESS)
		  {		    
		    class coupled_dagger_tilde_table<TYPE> two_body_K_table(Op , ja , jb);

		    two_body_K_table_from_MK_table_calc  (J_IN , J_OUT , M_IN , M_OUT , CGs , K_reducing_terms , two_body_MK_table , two_body_K_table);
		    
		    const bool are_ab_same_shell = ((particle_a == particle_b) && same_nlj_particle (shell_sa_qn , shell_sb_qn));

		    const int Kmin_j = two_body_K_table.get_Kmin ();
		    const int Kmax_j = two_body_K_table.get_Kmax ();
	    
		    const int Kmin = max (Kmin_j , Kmin_PSI);
		    const int Kmax = min (Kmax_j , Kmax_PSI);

		    bool is_it_to_write = false;
	    
		    for (int K = Kmin ; K <= Kmax ; K++)
		      {
			if (!is_it_to_write) is_it_to_write = (!are_ab_same_shell || (minus_one_pow (K) == 1));
		      }
	    
		    if (is_it_to_write)
		      {
			outfile << "[" << particle_a << " " << shell_sa_qn;

			if (!is_it_dagger_a) outfile << "~";

			outfile << " " << particle_b << " " << shell_sb_qn;

			if (!is_it_dagger_b) outfile << "~";
			
			outfile << "]^K" << endl;

			for (int K = Kmin ; K <= Kmax ; K++)
			  {
			    if (!are_ab_same_shell || (minus_one_pow (K) == 1)) outfile << K << " " << two_body_K_table(K) << endl;
			  }
			
			outfile << endl;
		      }}}}}
}












void dagger_tilde_operators::three_body_L_K_tables_calc_store (
							       const enum dagger_tilde_operator_type Op , 
							       const class correlated_state_str &PSI_IN_qn , 
							       const class correlated_state_str &PSI_OUT_qn , 
							       const class GSM_vector &PSI_OUT)
{
  if (!is_it_three_body_determine (Op)) error_message_print_abort ("Three-body operators only in dagger_tilde_operators::three_body_L_K_tables_calc_store");  
      
  if (is_it_RDM_determine (Op)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::three_body_L_K_tables_calc_store");
  
  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0);
  const bool is_it_dagger_b = is_it_dagger_determine (Op , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (Op , 2);
  
  const bool is_it_a_dagger_a_tilde_a_tilde   = ( is_it_dagger_a && !is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_a_tilde  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_a_dagger = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_a_tilde    = (!is_it_dagger_a && !is_it_dagger_b && !is_it_dagger_c);
    
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_tilde || is_it_a_dagger_a_dagger_a_dagger);
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_c = data_find (Op , 2 , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon ();
  const unsigned int N_nlj_baryon_b = data_b.get_N_nlj_baryon ();
  const unsigned int N_nlj_baryon_c = data_c.get_N_nlj_baryon ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();
  
  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);
    
  const int S_IN  = PSI_IN_qn.get_S ();
  const int S_OUT = PSI_OUT_qn.get_S ();

  const int S_dagger_tilde = S_OUT - S_IN;
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const double Kmin_PSI = abs (J_IN - J_OUT);
  const double Kmax_PSI =      J_IN + J_OUT;

  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
    
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + ".dat";
  
  const double ma_max = data_a.get_m_max ();
  const double mb_max = data_b.get_m_max ();
  const double mc_max = data_b.get_m_max ();

  const double m_max_ab = max (ma_max , mb_max);
  
  const double m_max = max (m_max_ab , mc_max);
    
  const double three_m_max = 3.0*m_max;

  const class CG_str CGs(three_m_max);
  
  const int K_number_PSI = make_int (Kmax_PSI - Kmin_PSI) + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const string file_name_IN_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_baryons_IN = (space == PROT_Y_ONLY) ? (ZYval_IN) : (NYval_IN);
  
  const unsigned int space_dimension_IN = (space == PROT_NEUT_Y)
    ? (space_dimension_read_disk (true , ZYval_IN , NYval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (N_valence_baryons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , prot_Y_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , neut_Y_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_baryon (true , ZYval_IN , NYval_IN , PSI_IN_qn , M_IN , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					    is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
    
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }
  
  for (unsigned int sa = 0 ; sa < N_nlj_baryon_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_baryon_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_baryon_c ; sc++)
	{  		
	  const class nlj_struct &shell_sa_qn = shells_a_qn(sa);
	  const class nlj_struct &shell_sb_qn = shells_b_qn(sb);
	  const class nlj_struct &shell_sc_qn = shells_c_qn(sc);
	  
	  const enum particle_type particle_a = shell_sa_qn.get_particle ();
	  const enum particle_type particle_b = shell_sb_qn.get_particle ();
	  const enum particle_type particle_c = shell_sc_qn.get_particle ();
	  
	  const bool ab_shells_ordered = ((particle_a != particle_b) || (sa <= sb));
	  const bool cb_shells_ordered = ((particle_b != particle_c) || (sc <= sb));
	  	  
	  if (!are_ab_coupled_first && !cb_shells_ordered)  continue;
	  if ( are_ab_coupled_first && !ab_shells_ordered)  continue;
	
	  const bool is_it_spectator_a = (particle_a == SPECTATOR);
	  const bool is_it_spectator_b = (particle_b == SPECTATOR);
	  const bool is_it_spectator_c = (particle_c == SPECTATOR);
		    
	  const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	  const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  const bool frozen_state_c = shell_sc_qn.get_frozen_state ();
		    
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !is_it_spectator_a && !is_it_spectator_b && !is_it_spectator_c)
	    {	
	      const int Sa = particle_strangeness_determine (particle_a) , S_dagger_tilde_a = (is_it_dagger_a) ? (Sa) : (-Sa);
	      const int Sb = particle_strangeness_determine (particle_b) , S_dagger_tilde_b = (is_it_dagger_b) ? (Sb) : (-Sb);
	      const int Sc = particle_strangeness_determine (particle_c) , S_dagger_tilde_c = (is_it_dagger_c) ? (Sc) : (-Sc);
	    
	      const int la = shell_sa_qn.get_l ();
	      const int lb = shell_sb_qn.get_l ();
	      const int lc = shell_sc_qn.get_l ();

	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);

	      const int S_dagger_tilde_abc = S_dagger_tilde_a + S_dagger_tilde_b + S_dagger_tilde_c;
	    
	      if ((bp_abc == BP_dagger_tilde) && (S_dagger_tilde_abc == S_dagger_tilde))
		{
		  const double ja = shell_sa_qn.get_j ();
		  const double jb = shell_sb_qn.get_j ();
		  const double jc = shell_sc_qn.get_j ();
	      
		  class uncoupled_dagger_tilde_table<TYPE> three_body_MK_table(ja , jb , jc);

		  switch (space)
		    {
		    case PROT_Y_ONLY:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									 inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									  inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								       inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , three_body_MK_table);
		      } break;

		    case NEUT_Y_ONLY:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									 inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
									  inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								       inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , three_body_MK_table);
		     
		      } break;
		
		    case PROT_NEUT_Y:
		      {
			if (is_it_a_dagger_a_tilde_a_tilde)
			  a_dagger_a_tilde_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								     inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								     reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_tilde)
			  a_dagger_a_dagger_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								      inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								      reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);

			if (is_it_a_dagger_a_dagger_a_dagger)
			  a_dagger_a_dagger_a_dagger_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								       inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								       reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);
		      
			if (is_it_a_tilde_a_tilde_a_tilde)
			  a_tilde_a_tilde_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
								    inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
								    reordering_bin_phases_p , reordering_bin_phases_n , three_body_MK_table);
		      } break;
		    
		    default: abort_all ();
		    }

		  if (THIS_PROCESS == MASTER_PROCESS)
		    {
		      class coupled_dagger_tilde_table<TYPE> three_body_L_K_table(Op , ja , jb , jc);

		      three_body_L_K_table_from_MK_table_calc (J_IN , J_OUT , M_IN , M_OUT , CGs , K_reducing_terms , three_body_MK_table , three_body_L_K_table);
			  
		      const bool are_ab_same_shell = ((particle_a == particle_b) && same_nlj_particle (shell_sa_qn , shell_sb_qn));
		      const bool are_bc_same_shell = ((particle_b == particle_c) && same_nlj_particle (shell_sb_qn , shell_sc_qn));
		      
		      const bool is_it_same_shell_case = (are_ab_coupled_first) ? (are_ab_same_shell) : (are_bc_same_shell);
		      
		      const int Lmin = make_int (three_body_L_K_table.get_Lmin ());
		      const int Lmax = make_int (three_body_L_K_table.get_Lmax ());

		      bool is_it_to_write = false;
	      
		      for (int L = Lmin ; L <= Lmax ; L++)
			{
			  if (!is_it_to_write)
			    {
			      const double Kmin_j = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
			      
			      const double Kmax_j = (are_ab_coupled_first) ? (jc + L) : (ja + L);
		      
			      const double Kmin = max (Kmin_PSI , Kmin_j);
			      const double Kmax = min (Kmax_PSI , Kmax_j);
		      
			      is_it_to_write = ((!is_it_same_shell_case || (minus_one_pow (L) == 1)) && (make_int (Kmax - Kmin) >= 0));
			    } 
			}
	      
		      if (is_it_to_write)
			{
			  if (are_ab_coupled_first)
			    {
			      outfile << "[[" << particle_a << " " << shell_sa_qn;

			      if (!is_it_dagger_a) outfile << "~";

			      outfile << " " << particle_b << " " << shell_sb_qn;

			      if (!is_it_dagger_b) outfile << "~";
			
			      outfile << "]^L " << particle_c << " " << shell_sc_qn;
			  
			      if (!is_it_dagger_c) outfile << "~";
			    }
			  else
			    {
			      outfile << "[" << particle_a << " " << shell_sa_qn;

			      if (!is_it_dagger_a) outfile << "~";

			      outfile << "[" << particle_b << " " << shell_sb_qn;

			      if (!is_it_dagger_b) outfile << "~";
			
			      outfile << " " << particle_c << " " << shell_sc_qn;
			  
			      if (!is_it_dagger_c) outfile << "~";
			      
			      outfile << "]^L";
			    }
			  
			  outfile << "]^K" << endl;
			  
			  for (int L = Lmin ; L <= Lmax ; L++)
			    {
			      if (!is_it_same_shell_case || (minus_one_pow (L) == 1))
				{
				  const double Kmin_j = (are_ab_coupled_first) ? (abs (jc - L)) : (abs (ja - L));
				  
				  const double Kmax_j = (are_ab_coupled_first) ? (jc + L) : (ja + L);
			
				  const double Kmin = max (Kmin_PSI , Kmin_j);
				  const double Kmax = min (Kmax_PSI , Kmax_j);

				  for (double K = Kmin ; make_int (K - Kmax) <= 0 ; K++) outfile << L << " " << K << " " << three_body_L_K_table(L , K) << endl;
				}
			    }
		  
			  outfile << endl;
			  
			}}}}}
}









void dagger_tilde_operators::four_body_L1_L2_K_tables_calc_store (
								  const enum dagger_tilde_operator_type Op , 
								  const class correlated_state_str &PSI_IN_qn , 
								  const class correlated_state_str &PSI_OUT_qn , 
								  const class GSM_vector &PSI_OUT)
{
  if (!is_it_four_body_determine (Op)) error_message_print_abort ("Four-body operators only in dagger_tilde_operators::four_body_L1_L2_K_tables_calc_store");  
  
  if (is_it_RDM_determine (Op)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::four_body_L1_L2_K_tables_calc_store");
  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0) , is_it_dagger_b = is_it_dagger_determine (Op , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (Op , 2) , is_it_dagger_d = is_it_dagger_determine (Op , 3);
  
  const bool is_it_a_dagger_a_dagger_a_tilde_a_tilde = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c && !is_it_dagger_d);
  const bool is_it_a_dagger_a_tilde_a_dagger_a_tilde = ( is_it_dagger_a && !is_it_dagger_b &&  is_it_dagger_c && !is_it_dagger_d);
  const bool is_it_a_tilde_a_tilde_a_dagger_a_dagger = (!is_it_dagger_a && !is_it_dagger_b &&  is_it_dagger_c &&  is_it_dagger_d);
  
  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data) , &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_c = data_find (Op , 2 , prot_Y_data , neut_Y_data) , &data_d = data_find (Op , 3 , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon () , N_nlj_baryon_b = data_b.get_N_nlj_baryon ();
  const unsigned int N_nlj_baryon_c = data_c.get_N_nlj_baryon () , N_nlj_baryon_d = data_d.get_N_nlj_baryon ();

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();
      
  const unsigned int BP_dagger_tilde = binary_parity_product (BP_IN , BP_OUT);
  
  const int S_IN  = PSI_IN_qn.get_S ();
  const int S_OUT = PSI_OUT_qn.get_S ();

  const int S_dagger_tilde = S_OUT - S_IN;
  
  const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers () , &shells_b_qn = data_b.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_c_qn = data_c.get_shells_quantum_numbers () , &shells_d_qn = data_d.get_shells_quantum_numbers ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_IN  = J_IN;
  const double M_OUT = J_OUT;
  
  const int Kmin_PSI = abs (make_int (J_IN - J_OUT));
  const int Kmax_PSI =      make_int (J_IN + J_OUT);

  const int MK = make_int (M_OUT - M_IN);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  const string PSI_OUT_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_OUT_qn);
    
  const string outfile_name = dagger_tilde_operator_string + "_" + PSI_IN_qn_string + "_" + PSI_OUT_qn_string + ".dat";
  
  const double ma_max = data_a.get_m_max () , mb_max = data_b.get_m_max ();
  const double mc_max = data_c.get_m_max () , md_max = data_d.get_m_max ();

  const double m_max_ab = max (ma_max , mb_max);
  const double m_max_cd = max (mc_max , md_max);
  
  const double m_max = max (m_max_ab , m_max_cd);
  
  const int L1_max = make_int (ma_max + mb_max);
  const int L2_max = make_int (mc_max + md_max);
    
  const int L1_max_plus_one = L1_max + 1;
  const int L2_max_plus_one = L2_max + 1;
  
  const class CG_str CGs_js(m_max);
		
  class array<class array<double> > CG_L1_L2_K_tables(L1_max_plus_one , L2_max_plus_one);

  CG_L1_L2_K_tables_alloc_calc (Kmin_PSI , Kmax_PSI , MK , CG_L1_L2_K_tables);
  
  const int K_number_PSI = Kmax_PSI - Kmin_PSI + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J_IN , J_OUT , M_IN , M_OUT , K_reducing_terms);
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_calc (Op , ZYval);
  const int NYval_IN = N_IN_calc (Op , NYval);
  
  const string file_name_IN_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_IN_qn , M_IN);

  const unsigned int N_valence_baryons_IN = (space == PROT_Y_ONLY) ? (ZYval_IN) : (NYval_IN);
  
  const unsigned int space_dimension_IN = (space == PROT_NEUT_Y)
    ? (space_dimension_read_disk (true , ZYval_IN , NYval_IN , file_name_IN_dimension))
    : (space_dimension_read_disk (N_valence_baryons_IN , file_name_IN_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);
	
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , prot_Y_data , inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_n.allocate (space_dimension_IN);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_IN_qn , M_IN , neut_Y_data , inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension_IN);
	is_inSDn_in_new_space_tab.allocate (space_dimension_IN);

	reordering_bin_phases_p.allocate (space_dimension_IN);
	reordering_bin_phases_n.allocate (space_dimension_IN);

	files_IN_tables_read_pn_one_baryon (true , ZYval_IN , NYval_IN , PSI_IN_qn , M_IN , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , PSI_IN_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
    
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }
  
  for (unsigned int sa = 0 ; sa < N_nlj_baryon_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_baryon_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nlj_baryon_c ; sc++)
	for (unsigned int sd = 0 ; sd < N_nlj_baryon_d ; sd++)
	  {  		
	    const class nlj_struct &shell_sa_qn = shells_a_qn(sa) , &shell_sb_qn = shells_b_qn(sb);
	    const class nlj_struct &shell_sc_qn = shells_c_qn(sc) , &shell_sd_qn = shells_d_qn(sd);

	    const enum particle_type particle_a = shell_sa_qn.get_particle () , particle_b = shell_sb_qn.get_particle ();
	    const enum particle_type particle_c = shell_sc_qn.get_particle () , particle_d = shell_sd_qn.get_particle ();
	    
	    const bool are_ab_shells_ordered = ((particle_a != particle_b) || (sa <= sb));
	    const bool are_cd_shells_ordered = ((particle_c != particle_d) || (sc <= sd));
	  	  
	    if (!are_ab_shells_ordered || !are_cd_shells_ordered) continue;
	
	    const bool is_it_spectator_a = (particle_a == SPECTATOR) , is_it_spectator_b = (particle_b == SPECTATOR);
	    const bool is_it_spectator_c = (particle_c == SPECTATOR) , is_it_spectator_d = (particle_d == SPECTATOR);
		    
	    const bool frozen_state_a = shell_sa_qn.get_frozen_state () , frozen_state_b = shell_sb_qn.get_frozen_state ();
	    const bool frozen_state_c = shell_sc_qn.get_frozen_state () , frozen_state_d = shell_sd_qn.get_frozen_state ();
		    
	    if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !frozen_state_d && !is_it_spectator_a && !is_it_spectator_b && !is_it_spectator_c && !is_it_spectator_d)
	      {	
		const int Sa = particle_strangeness_determine (particle_a) , S_dagger_tilde_a = (is_it_dagger_a) ? (Sa) : (-Sa);
		const int Sb = particle_strangeness_determine (particle_b) , S_dagger_tilde_b = (is_it_dagger_b) ? (Sb) : (-Sb);
		const int Sc = particle_strangeness_determine (particle_c) , S_dagger_tilde_c = (is_it_dagger_c) ? (Sc) : (-Sc);
		const int Sd = particle_strangeness_determine (particle_d) , S_dagger_tilde_d = (is_it_dagger_d) ? (Sd) : (-Sd);
	      
		const int la = shell_sa_qn.get_l () , lb = shell_sb_qn.get_l ();
		const int lc = shell_sc_qn.get_l () , ld = shell_sd_qn.get_l ();

		const unsigned int bp_abcd = binary_parity_from_orbital_angular_momentum (la + lb + lc + ld);

		const int S_dagger_tilde_abcd = S_dagger_tilde_a + S_dagger_tilde_b + S_dagger_tilde_c + S_dagger_tilde_d;
	      
		if ((bp_abcd == BP_dagger_tilde) && (S_dagger_tilde_abcd == S_dagger_tilde))
		  {  
		    const double ja = shell_sa_qn.get_j () , jb = shell_sb_qn.get_j ();
		    const double jc = shell_sc_qn.get_j () , jd = shell_sd_qn.get_j ();
	      
		    class uncoupled_dagger_tilde_table<TYPE> four_body_MK_table(ja , jb , jc , jd);
  
		    switch (space)
		      {
		      case PROT_Y_ONLY:
			{
			  if (is_it_a_dagger_a_dagger_a_tilde_a_tilde)
			    a_dagger_a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , four_body_MK_table);			  
			  if (is_it_a_dagger_a_tilde_a_dagger_a_tilde)
			    a_dagger_a_tilde_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , four_body_MK_table);
			  if (is_it_a_tilde_a_tilde_a_dagger_a_dagger)
			    a_tilde_a_tilde_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDp_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , four_body_MK_table);
			} break;

		      case NEUT_Y_ONLY:
			{
			  if (is_it_a_dagger_a_dagger_a_tilde_a_tilde)
			    a_dagger_a_dagger_a_tilde_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , four_body_MK_table);
			  
			  if (is_it_a_dagger_a_tilde_a_dagger_a_tilde)
			    a_dagger_a_tilde_a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , four_body_MK_table);
			  
			  if (is_it_a_tilde_a_tilde_a_dagger_a_dagger)
			    a_tilde_a_tilde_a_dagger_a_dagger_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										   inSDn_tab , PSI_IN_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , four_body_MK_table);	     
			} break;
		
		      case PROT_NEUT_Y:
			{
			  if (is_it_a_dagger_a_dagger_a_tilde_a_tilde)
			    a_dagger_a_dagger_a_tilde_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
										reordering_bin_phases_p , reordering_bin_phases_n , four_body_MK_table);
			  
			  if (is_it_a_dagger_a_tilde_a_dagger_a_tilde)
			    a_dagger_a_tilde_a_dagger_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
										reordering_bin_phases_p , reordering_bin_phases_n , four_body_MK_table);
			  
			  if (is_it_a_tilde_a_tilde_a_dagger_a_dagger)
			    a_tilde_a_tilde_a_dagger_a_dagger_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , shell_sc_qn , shell_sd_qn , PSI_IN_qn , PSI_OUT_qn , PSI_OUT ,
										inSDp_tab , inSDn_tab , PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
										reordering_bin_phases_p , reordering_bin_phases_n , four_body_MK_table);
			} break;
		    
		      default: abort_all ();
		      }

		    if (THIS_PROCESS == MASTER_PROCESS)
		      {			
			class coupled_dagger_tilde_table<TYPE> four_body_L1_L2_K_table(Op , ja , jb , jc , jd);

			four_body_L1_L2_K_table_from_MK_table_calc (J_IN , J_OUT , M_IN , M_OUT , CGs_js , CG_L1_L2_K_tables , K_reducing_terms , four_body_MK_table , four_body_L1_L2_K_table);
			  
			const bool are_ab_same_shell = ((particle_a == particle_b) && same_nlj_particle (shell_sa_qn , shell_sb_qn));
			const bool are_cd_same_shell = ((particle_c == particle_d) && same_nlj_particle (shell_sc_qn , shell_sd_qn));
		      		      
			const int L1_min = make_int (four_body_L1_L2_K_table.get_L1_min ()) , L2_min = make_int (four_body_L1_L2_K_table.get_L2_min ());
			const int L1_max = make_int (four_body_L1_L2_K_table.get_L1_max ()) , L2_max = make_int (four_body_L1_L2_K_table.get_L2_max ());
		      
			bool is_it_to_write = false;
	      
			for (int L1 = L1_min ; L1 <= L1_max ; L1++)
			  for (int L2 = L2_min ; L2 <= L2_max ; L2++)
			    {
			      if (!is_it_to_write)
				{
				  const int Kmin_L1_L2 = abs (L1 - L2);
				  const int Kmax_L1_L2 =      L1 + L2;
		      
				  const int Kmin = max (Kmin_PSI , Kmin_L1_L2);
				  const int Kmax = min (Kmax_PSI , Kmax_L1_L2);
		      
				  is_it_to_write = ((!are_ab_same_shell || (minus_one_pow (L1) == 1)) && (!are_cd_same_shell || (minus_one_pow (L2) == 1)) && (Kmax >= Kmin));
				} 
			    }
		      
			if (is_it_to_write)
			  {
			    outfile << "[[" << particle_a << " " << shell_sa_qn;

			    if (!is_it_dagger_a) outfile << "~";
			      
			    outfile << " " << particle_b << " " << shell_sb_qn;
			
			    if (!is_it_dagger_b) outfile << "~";
			      
			    outfile << "]^L1";
			  
			    outfile << " [" << particle_c << " " << shell_sc_qn;

			    if (!is_it_dagger_c) outfile << "~";
			      
			    outfile << " " << particle_d << " " << shell_sd_qn;
			
			    if (!is_it_dagger_d) outfile << "~";
			      
			    outfile << "]^L2";
			  
			    outfile << "]^K" << endl;
			  
			    for (int L1 = L1_min ; L1 <= L1_max ; L1++)
			      for (int L2 = L2_min ; L2 <= L2_max ; L2++)
				{
				  if ((!are_ab_same_shell || (minus_one_pow (L1) == 1)) && (!are_cd_same_shell || (minus_one_pow (L2) == 1)))
				    {
				      const int Kmin_L1_L2 = abs (L1 - L2);
				      const int Kmax_L1_L2 =      L1 + L2;
		      
				      const int Kmin = max (Kmin_PSI , Kmin_L1_L2);
				      const int Kmax = min (Kmax_PSI , Kmax_L1_L2);
				    
				      for (int K = Kmin ; K <= Kmax ; K++) outfile << L1 << " " << L2 << " " << K << " " << four_body_L1_L2_K_table(L1 , L2 , K) << endl;
				    }
				}
		  
			    outfile << endl;
			    
			  }}}}}
}














void dagger_tilde_operators::PQG_uncoupled_MEs_table_calc (
							   const enum dagger_tilde_operator_type Op ,
							   const class correlated_state_str &PSI_IN_qn , 
							   const class GSM_vector_helper_class &GSM_vector_helper_IN ,
							   class array<TYPE> &PQG_uncoupled_MEs_table)
{
  if (!is_it_two_body_determine (Op)) error_message_print_abort ("Two-body operators only in dagger_tilde_operators::PQG_uncoupled_MEs_tables_calc_store");
  
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::PQG_uncoupled_MEs_tables_calc_store");

  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0) , is_it_dagger_b = is_it_dagger_determine (Op , 1);
  const bool is_it_dagger_c = is_it_dagger_determine (Op , 3) , is_it_dagger_d = is_it_dagger_determine (Op , 2);
  
  const bool is_it_a_dagger_a_dagger_ab = ( is_it_dagger_a &&  is_it_dagger_b);
  const bool is_it_a_tilde_a_tilde_ab   = (!is_it_dagger_a && !is_it_dagger_b);
    
  const bool is_it_a_dagger_a_tilde_dc  = ( is_it_dagger_d && !is_it_dagger_c);
  const bool is_it_a_dagger_a_dagger_dc = ( is_it_dagger_d &&  is_it_dagger_c);
  const bool is_it_a_tilde_a_tilde_dc   = (!is_it_dagger_d && !is_it_dagger_c);
  
  const enum space_type space = GSM_vector_helper_IN.get_space ();

  const enum interaction_type inter = GSM_vector_helper_IN.get_inter ();

  const bool truncation_hw = GSM_vector_helper_IN.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN.get_truncation_ph ();

  const int n_holes_max_p = GSM_vector_helper_IN.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_IN.get_n_holes_max_n ();

  const int n_holes_max = GSM_vector_helper_IN.get_n_holes_max ();

  const int n_scat_max_p_init = GSM_vector_helper_IN.get_n_scat_max_p ();
  const int n_scat_max_n_init = GSM_vector_helper_IN.get_n_scat_max_n ();
  
  const int n_scat_max_init = GSM_vector_helper_IN.get_n_scat_max ();
  
  const int Ep_max_hw = GSM_vector_helper_IN.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_IN.get_En_max_hw ();

  const int E_max_hw = GSM_vector_helper_IN.get_E_max_hw ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_IN.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN.get_neut_Y_data ();

  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data) , &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_c = data_find (Op , 3 , prot_Y_data , neut_Y_data) , &data_d = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  
  const unsigned int N_nljm_baryon_a = data_a.get_N_nljm_baryon () , N_nljm_baryon_b = data_b.get_N_nljm_baryon ();
  const unsigned int N_nljm_baryon_c = data_c.get_N_nljm_baryon () , N_nljm_baryon_d = data_d.get_N_nljm_baryon ();

  const unsigned int BP_IN = GSM_vector_helper_IN.get_BP ();
  
  const double M_IN = GSM_vector_helper_IN.get_M ();

  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
    
  const double ma_max = data_a.get_m_max () , mb_max = data_b.get_m_max ();
  const double mc_max = data_c.get_m_max () , md_max = data_d.get_m_max ();
    
  const int ma_max_plus_mb_max = make_int (ma_max + mb_max);
  const int mc_max_plus_md_max = make_int (mc_max + md_max);
  
  const int two_ma_max = data_a.get_two_m_max ();
  const int two_mb_max = data_b.get_two_m_max ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table () , &phi_table_b = data_b.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table () , &phi_table_c = data_c.get_phi_table ();

  const int ZYval_IN = prot_Y_data.get_N_valence_baryons ();
  const int NYval_IN = neut_Y_data.get_N_valence_baryons ();
        
  const int ZYval_OUT = Z_OUT_calc (Op , ZYval_IN);
  const int NYval_OUT = N_OUT_calc (Op , NYval_IN);
  
  if ((ZYval_OUT < 0) || (NYval_OUT < 0)) return;
    	    
  const int Z_IN = prot_Y_data.get_N_nucleons ();
  const int N_IN = neut_Y_data.get_N_nucleons ();
      
  const int Z_OUT = Z_OUT_calc (Op , Z_IN);
  const int N_OUT = N_OUT_calc (Op , N_IN);
    
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  const class array<double> &effective_masses_for_calc_p = prot_Y_data.get_effective_masses_for_calc ();
  const class array<double> &effective_masses_for_calc_n = neut_Y_data.get_effective_masses_for_calc ();
      
  const double prot_mass_for_calc = effective_masses_for_calc_p(prot_index);  
  const double neut_mass_for_calc = effective_masses_for_calc_n(neut_index);
  
  const double nucleus_mass_OUT = Z_OUT*prot_mass_for_calc + N_OUT*neut_mass_for_calc;
      
  const unsigned int space_dimension_IN = GSM_vector_helper_IN.get_space_dimension ();
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;
  
  class baryons_data prot_Y_data_OUT;
  class baryons_data neut_Y_data_OUT;
	
  prot_Y_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , 0 , nucleus_mass_OUT , nucleus_mass_OUT , prot_Y_data);
  neut_Y_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , 0 , nucleus_mass_OUT , nucleus_mass_OUT , neut_Y_data);
  
  prot_Y_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (prot_Y_data);
  neut_Y_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (neut_Y_data);
	  
  const int n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p_init , prot_Y_data_OUT);
  const int n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n_init , neut_Y_data_OUT);

  const int n_scat_max = n_scat_max_pn_calc (truncation_ph , n_scat_max_init , prot_Y_data_OUT , neut_Y_data_OUT);

  prot_Y_data_OUT.set_n_scat_max (n_scat_max_p);
  neut_Y_data_OUT.set_n_scat_max (n_scat_max_n);
    
  class GSM_vector PSI_IN(GSM_vector_helper_IN);

  if (THIS_PROCESS == MASTER_PROCESS) PSI_IN.eigenvector_read_disk (PSI_IN_qn);

#ifdef UseMPI
  PSI_IN.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDp_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_Y_data_OUT , false);

      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_Y_data_OUT , false);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	PSI_IN.get_SDs_pn (inSDp_tab , inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_Y_data_OUT);
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_Y_data_OUT , false);
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_Y_data_OUT , false);
      } break;
      
    default: abort_all ();
    }
  
  class array<class GSM_vector_helper_class> PSI_OUT_helpers(N_nljm_baryon_c , N_nljm_baryon_d);
  
  class array<class GSM_vector> PSI_OUT_tab(N_nljm_baryon_c , N_nljm_baryon_d);
  
  for (unsigned int sc = 0 ; sc < N_nljm_baryon_c ; sc++)
    for (unsigned int sd = 0 ; sd < N_nljm_baryon_d ; sd++)
      {
	const class nljm_struct &phi_c = phi_table_c(sc);
	const class nljm_struct &phi_d = phi_table_d(sd);

	const enum particle_type particle_c = phi_c.get_particle ();	
	const enum particle_type particle_d = phi_d.get_particle ();
	
	const unsigned int sc_shell_index = phi_c.get_shell_index (); 
	const unsigned int sd_shell_index = phi_d.get_shell_index ();
  
	const bool cd_shells_ordered = ((particle_c != particle_d) || (sc_shell_index <= sd_shell_index));

	if (is_it_a_dagger_a_dagger_dc && !cd_shells_ordered) continue;
	if (is_it_a_tilde_a_tilde_dc   && !cd_shells_ordered) continue;

	const bool frozen_state_c = phi_c.get_frozen_state ();
	const bool frozen_state_d = phi_d.get_frozen_state ();
		    
	if (!frozen_state_c && !frozen_state_d)
	  {	
	    const int lc = phi_c.get_l ();
	    const int ld = phi_d.get_l ();

	    const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);
	    
	    const unsigned int BP_OUT = binary_parity_product (BP_IN , bp_cd);

	    const int im_c = phi_c.get_im ();
	    const int im_d = phi_d.get_im ();
	    
	    const int MK = im_c + im_d - mc_max_plus_md_max;
	    
	    const double M_OUT = MK + M_IN;

	    class GSM_vector_helper_class &PSI_OUT_helper = PSI_OUT_helpers(sc , sd);
	    
	    class GSM_vector &PSI_OUT = PSI_OUT_tab(sc , sd);
	    
	    PSI_OUT_helper.allocate (space , inter , truncation_hw , truncation_ph ,
				     n_holes_max   , n_scat_max   , E_max_hw  ,
				     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
				     n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data_OUT , neut_Y_data_OUT , BP_OUT , M_OUT , false);
	    
	    PSI_OUT.allocate (PSI_OUT_helper);

	    switch (space)
	      {
	      case PROT_Y_ONLY:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pp_nn_calc  (Op , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pp_nn_calc (Op , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT);
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pp_nn_calc   (Op , phi_d , phi_c , inSDp_tab , PSI_IN , PSI_OUT);

		} break;

	      case NEUT_Y_ONLY:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pp_nn_calc  (Op , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pp_nn_calc (Op , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT);
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pp_nn_calc   (Op , phi_d , phi_c , inSDn_tab , PSI_IN , PSI_OUT);
		  
		} break;
		
	      case PROT_NEUT_Y:
		{
		  if (is_it_a_dagger_a_tilde_dc)  a_dagger_a_tilde_MK_RDM_pn_calc  (Op , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);
		  if (is_it_a_dagger_a_dagger_dc) a_dagger_a_dagger_MK_RDM_pn_calc (Op , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);		      
		  if (is_it_a_tilde_a_tilde_dc)   a_tilde_a_tilde_MK_RDM_pn_calc   (Op , phi_d , phi_c , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);
		      
		} break;
		    
	      default: abort_all ();
	      }
	  }
      }

  const unsigned int abcd_total_indices_dimension = N_nljm_baryon_a*N_nljm_baryon_b*N_nljm_baryon_c*N_nljm_baryon_d;

  const unsigned int first_abcd_total_index = basic_first_index_determine_for_MPI (abcd_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_abcd_total_index = basic_last_index_determine_for_MPI (abcd_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
    
  const bool is_process_active = is_process_active_for_MPI (abcd_total_indices_dimension ,  THIS_PROCESS);
  
  class array<unsigned int> a_nljm_indices(abcd_total_indices_dimension) , b_nljm_indices(abcd_total_indices_dimension);
  class array<unsigned int> c_nljm_indices(abcd_total_indices_dimension) , d_nljm_indices(abcd_total_indices_dimension);

  unsigned int total_index = 0;
  
  for (unsigned int sa = 0 ; sa < N_nljm_baryon_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nljm_baryon_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nljm_baryon_c ; sc++)
	for (unsigned int sd = 0 ; sd < N_nljm_baryon_d ; sd++)
	  {	    
	    a_nljm_indices(total_index) = sa , b_nljm_indices(total_index) = sb;
	    c_nljm_indices(total_index) = sc , d_nljm_indices(total_index) = sd;

	    total_index++;
	  }

  if (is_process_active)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int abcd_total_index = first_abcd_total_index ; abcd_total_index <= last_abcd_total_index ; abcd_total_index++)
	{
	  const unsigned int sa = a_nljm_indices(abcd_total_index) , sb = b_nljm_indices(abcd_total_index);
	  const unsigned int sc = c_nljm_indices(abcd_total_index) , sd = d_nljm_indices(abcd_total_index);
      
	  const class nljm_struct &phi_a = phi_table_a(sa) , &phi_b = phi_table_b(sb);
	  const class nljm_struct &phi_c = phi_table_c(sc) , &phi_d = phi_table_d(sd);

	  const enum particle_type particle_a = phi_a.get_particle () , particle_b = phi_b.get_particle ();
	  const enum particle_type particle_c = phi_c.get_particle () , particle_d = phi_d.get_particle ();
		    
	  const bool frozen_state_a = phi_a.get_frozen_state () , frozen_state_b = phi_b.get_frozen_state ();
	  const bool frozen_state_c = phi_c.get_frozen_state () , frozen_state_d = phi_d.get_frozen_state ();
		    
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !frozen_state_d)
	    {	
	      const int la = phi_a.get_l () , lb = phi_b.get_l ();
	      const int lc = phi_c.get_l () , ld = phi_d.get_l ();
	    
	      const unsigned int sa_shell_index = phi_a.get_shell_index () , sb_shell_index = phi_b.get_shell_index (); 
	      const unsigned int sc_shell_index = phi_c.get_shell_index () , sd_shell_index = phi_d.get_shell_index ();
	    
	      const bool ab_shells_ordered = ((particle_a != particle_b) || (sa_shell_index <= sb_shell_index));
	      const bool cd_shells_ordered = ((particle_c != particle_d) || (sc_shell_index <= sd_shell_index));

	      if (is_it_a_dagger_a_dagger_ab && !ab_shells_ordered) continue;
	      if (is_it_a_tilde_a_tilde_ab   && !ab_shells_ordered) continue;
		  
	      if (is_it_a_dagger_a_dagger_dc && !cd_shells_ordered) continue;
	      if (is_it_a_tilde_a_tilde_dc   && !cd_shells_ordered) continue;
		  
	      const unsigned int bp_ab = binary_parity_from_orbital_angular_momentum (la + lb);
	      const unsigned int bp_cd = binary_parity_from_orbital_angular_momentum (lc + ld);
		      		
	      if (bp_ab == bp_cd)
		{
		  const int im_a = phi_a.get_im () , im_b = phi_b.get_im ();
		  const int im_c = phi_c.get_im () , im_d = phi_d.get_im ();
		      
		  const int im_a_minus = two_ma_max - im_a;
		  const int im_b_minus = two_mb_max - im_b;
	    
		  const unsigned int sa_minus = one_body_a_indices(sa_shell_index , im_a_minus);
		  const unsigned int sb_minus = one_body_b_indices(sb_shell_index , im_b_minus);
		    
		  const int MK_ab = im_a + im_b - ma_max_plus_mb_max;		    
		  const int MK_cd = im_c + im_d - mc_max_plus_md_max;
	    			      
		  if (MK_ab == MK_cd)
		    {			      
		      const class GSM_vector &PSI_OUT_ab = PSI_OUT_tab(sa , sb);
		      const class GSM_vector &PSI_OUT_cd = PSI_OUT_tab(sc , sd);
			  			  
		      const unsigned int sd_shell_index = phi_d.get_shell_index ();

		      if (is_it_a_tilde_a_tilde_dc)   PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_ab*PSI_OUT_cd;
		      if (is_it_a_dagger_a_dagger_dc) PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_ab*PSI_OUT_cd;
		      if (is_it_a_dagger_a_tilde_dc)  PQG_uncoupled_MEs_table(sa_minus , sb_minus , sc , sd_shell_index) = PSI_OUT_ab*PSI_OUT_cd;
						      
		    }}}}}
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PQG_uncoupled_MEs_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

#endif
}













void dagger_tilde_operators::T1_T2_part_uncoupled_MEs_table_calc (
								  const enum dagger_tilde_operator_type Op ,
								  const class correlated_state_str &PSI_IN_qn ,
								  const class GSM_vector_helper_class &GSM_vector_helper_IN ,
								  class array<TYPE> &T1_T2_part_uncoupled_MEs_table)
{
  if (is_it_two_body_determine (Op)) error_message_print_abort ("Three-body operators only in dagger_tilde_operators::T1_T2_part_uncoupled_MEs_table");
  
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::T1_T2_part_uncoupled_MEs_tables_calc");

  const bool is_it_dagger_a = is_it_dagger_determine (Op , 0) , is_it_dagger_b = is_it_dagger_determine (Op , 1) , is_it_dagger_c = is_it_dagger_determine (Op , 2);
  const bool is_it_dagger_d = is_it_dagger_determine (Op , 5) , is_it_dagger_e = is_it_dagger_determine (Op , 4) , is_it_dagger_f = is_it_dagger_determine (Op , 3);
  
  const bool is_it_a_dagger_a_dagger_a_dagger_abc = ( is_it_dagger_a &&  is_it_dagger_b &&  is_it_dagger_c); 
  const bool is_it_a_dagger_a_dagger_a_tilde_abc  = ( is_it_dagger_a &&  is_it_dagger_b && !is_it_dagger_c);
    
  const bool is_it_a_dagger_a_tilde_a_tilde_fed   = ( is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_dagger_a_dagger_a_tilde_fed  = ( is_it_dagger_f &&  is_it_dagger_e && !is_it_dagger_d);
  const bool is_it_a_dagger_a_dagger_a_dagger_fed = ( is_it_dagger_f &&  is_it_dagger_e &&  is_it_dagger_d);
  const bool is_it_a_tilde_a_tilde_a_tilde_fed    = (!is_it_dagger_f && !is_it_dagger_e && !is_it_dagger_d);
  
  const bool are_ab_coupled_first = (is_it_a_dagger_a_dagger_a_dagger_abc || is_it_a_dagger_a_dagger_a_tilde_abc);

  const bool are_de_coupled_first = (is_it_a_tilde_a_tilde_a_tilde_fed || is_it_a_dagger_a_tilde_a_tilde_fed);
        
  const enum space_type space = GSM_vector_helper_IN.get_space ();

  const enum interaction_type inter = GSM_vector_helper_IN.get_inter ();

  const bool truncation_hw = GSM_vector_helper_IN.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_IN.get_truncation_ph ();

  const int n_holes_max_p = GSM_vector_helper_IN.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_IN.get_n_holes_max_n ();

  const int n_holes_max = GSM_vector_helper_IN.get_n_holes_max ();
  
  const int n_scat_max_p_init = GSM_vector_helper_IN.get_n_scat_max_p ();
  const int n_scat_max_n_init = GSM_vector_helper_IN.get_n_scat_max_n ();
  
  const int n_scat_max_init = GSM_vector_helper_IN.get_n_scat_max ();
  
  const int Ep_max_hw = GSM_vector_helper_IN.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_IN.get_En_max_hw ();

  const int E_max_hw = GSM_vector_helper_IN.get_E_max_hw ();

  const class baryons_data &prot_Y_data = GSM_vector_helper_IN.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_IN.get_neut_Y_data ();
  
  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data) , &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data) , &data_c = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  const class baryons_data &data_d = data_find (Op , 5 , prot_Y_data , neut_Y_data) , &data_e = data_find (Op , 4 , prot_Y_data , neut_Y_data) , &data_f = data_find (Op , 3 , prot_Y_data , neut_Y_data);
  
  const int two_ma_max = data_a.get_two_m_max ();
  const int two_mb_max = data_b.get_two_m_max ();
  const int two_mc_max = data_c.get_two_m_max ();
  
  const unsigned int N_nljm_baryon_a = data_a.get_N_nljm_baryon () , N_nljm_baryon_b = data_b.get_N_nljm_baryon () , N_nljm_baryon_c = data_c.get_N_nljm_baryon ();
  const unsigned int N_nljm_baryon_d = data_d.get_N_nljm_baryon () , N_nljm_baryon_e = data_e.get_N_nljm_baryon () , N_nljm_baryon_f = data_f.get_N_nljm_baryon ();

  const unsigned int BP_IN = GSM_vector_helper_IN.get_BP ();
  
  const double M_IN = GSM_vector_helper_IN.get_M ();

  const class array<class nljm_struct> &phi_table_a = data_a.get_phi_table () , &phi_table_b = data_b.get_phi_table () , &phi_table_c = data_c.get_phi_table ();
  const class array<class nljm_struct> &phi_table_d = data_d.get_phi_table () , &phi_table_e = data_e.get_phi_table () , &phi_table_f = data_f.get_phi_table ();
  
  const class one_body_indices_str &one_body_a_indices = data_a.get_one_body_indices ();
  const class one_body_indices_str &one_body_b_indices = data_b.get_one_body_indices ();
  const class one_body_indices_str &one_body_c_indices = data_c.get_one_body_indices ();
  
  const int ZYval_IN = prot_Y_data.get_N_valence_baryons ();
  const int NYval_IN = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_OUT = Z_OUT_calc (Op , ZYval_IN);
  const int NYval_OUT = N_OUT_calc (Op , NYval_IN);
  
  if ((ZYval_OUT < 0) || (NYval_OUT < 0)) return;
    
  const int Z_IN = prot_Y_data.get_N_nucleons ();
  const int N_IN = neut_Y_data.get_N_nucleons ();
  
  const int Z_OUT = Z_OUT_calc (Op , Z_IN);
  const int N_OUT = N_OUT_calc (Op , N_IN);
    
  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  const class array<double> &effective_masses_for_calc_p = prot_Y_data.get_effective_masses_for_calc ();
  const class array<double> &effective_masses_for_calc_n = neut_Y_data.get_effective_masses_for_calc ();
      
  const double prot_mass_for_calc = effective_masses_for_calc_p(prot_index);  
  const double neut_mass_for_calc = effective_masses_for_calc_n(neut_index);

  const double nucleus_mass_OUT = Z_OUT*prot_mass_for_calc + N_OUT*neut_mass_for_calc;
        
  const unsigned int space_dimension_IN = GSM_vector_helper_IN.get_space_dimension ();
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class baryons_data prot_Y_data_OUT;
  class baryons_data neut_Y_data_OUT;
	
  prot_Y_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , 0 , nucleus_mass_OUT , nucleus_mass_OUT , prot_Y_data);
  neut_Y_data_OUT.initialize_constants_from_other_nucleus (false , Z_OUT , N_OUT , 0 , nucleus_mass_OUT , nucleus_mass_OUT , neut_Y_data);
  
  prot_Y_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (prot_Y_data);
  neut_Y_data_OUT.alloc_copy_one_body_data_tables_E_min_max_hw (neut_Y_data);
    
  const int n_scat_max_p = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_p_init , prot_Y_data_OUT);
  const int n_scat_max_n = n_scat_max_pp_nn_calc (truncation_ph , n_scat_max_n_init , neut_Y_data_OUT);

  const int n_scat_max = n_scat_max_pn_calc (truncation_ph , n_scat_max_init , prot_Y_data_OUT , neut_Y_data_OUT);
  
  prot_Y_data_OUT.set_n_scat_max (n_scat_max_p);
  neut_Y_data_OUT.set_n_scat_max (n_scat_max_n);
  
  class GSM_vector PSI_IN(GSM_vector_helper_IN);

  if (THIS_PROCESS == MASTER_PROCESS) PSI_IN.eigenvector_read_disk (PSI_IN_qn);

#ifdef UseMPI
  PSI_IN.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDp_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_Y_data_OUT , false);

      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	PSI_IN.get_SDs_pp_nn (inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_Y_data_OUT , false);
	
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension_IN , ZYval_IN);
	inSDn_tab.allocate (space_dimension_IN , NYval_IN);
	
	PSI_IN.get_SDs_pn (inSDp_tab , inSDn_tab);
	
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , prot_Y_data_OUT);
	configuration_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , truncation_hw , truncation_ph , false , neut_Y_data_OUT);
	
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , prot_Y_data_OUT , false);
	SD_construction_set::tables_allocated_built_1D_hybrid_1D_2D_partitioning (false , false , false , false , neut_Y_data_OUT , false);
      } break;
      
    default: abort_all ();
    }

  class array<class GSM_vector_helper_class> PSI_OUT_helpers(N_nljm_baryon_d , N_nljm_baryon_e , N_nljm_baryon_f);
  
  class array<class GSM_vector> PSI_OUT_tab(N_nljm_baryon_d , N_nljm_baryon_e , N_nljm_baryon_f);
  
  for (unsigned int sd = 0 ; sd < N_nljm_baryon_d ; sd++)
    for (unsigned int se = 0 ; se < N_nljm_baryon_e ; se++)
      for (unsigned int sf = 0 ; sf < N_nljm_baryon_f ; sf++)
	{
	  const class nljm_struct &phi_d = phi_table_d(sd);
	  const class nljm_struct &phi_e = phi_table_e(se);
	  const class nljm_struct &phi_f = phi_table_f(sf);
 	  	  	  
	  const enum particle_type particle_d = phi_d.get_particle ();
	  const enum particle_type particle_e = phi_e.get_particle ();
	  const enum particle_type particle_f = phi_f.get_particle ();
	  
	  const unsigned int sd_shell_index = phi_d.get_shell_index ();
	  const unsigned int se_shell_index = phi_e.get_shell_index ();
	  const unsigned int sf_shell_index = phi_f.get_shell_index ();
		  
	  const bool de_shells_ordered = ((particle_d != particle_e) || (sd_shell_index <= se_shell_index));	  
	  const bool fe_shells_ordered = ((particle_e != particle_f) || (sf_shell_index <= se_shell_index));
	      
	  if ( are_de_coupled_first && !de_shells_ordered) continue;
	  if (!are_de_coupled_first && !fe_shells_ordered) continue;
	    	
	  const bool frozen_state_d = phi_d.get_frozen_state ();
	  const bool frozen_state_e = phi_e.get_frozen_state ();
	  const bool frozen_state_f = phi_f.get_frozen_state ();
		    
	  if (!frozen_state_f && !frozen_state_e && !frozen_state_d)
	    {
	      const int ld = phi_d.get_l ();
	      const int le = phi_e.get_l ();
	      const int lf = phi_f.get_l ();

	      const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);
	    
	      const unsigned int BP_OUT = binary_parity_product (BP_IN , bp_def);
	      	    
	      const double md = phi_d.get_m ();
	      const double me = phi_e.get_m ();
	      const double mf = phi_f.get_m ();

	      const double MK = md + me + mf;
	    
	      const double M_OUT = MK + M_IN;

	      class GSM_vector_helper_class &PSI_OUT_helper = PSI_OUT_helpers(sd , se , sf);
	    
	      class GSM_vector &PSI_OUT = PSI_OUT_tab(sd , se , sf);
	      	        
	      PSI_OUT_helper.allocate (space , inter , truncation_hw , truncation_ph ,
				       n_holes_max   , n_scat_max   , E_max_hw  ,
				       n_holes_max_p , n_scat_max_p , Ep_max_hw ,
				       n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data_OUT , neut_Y_data_OUT , BP_OUT , M_OUT , false);
	        
	      PSI_OUT.allocate (PSI_OUT_helper);
	      
	      switch (space)
		{
		case PROT_Y_ONLY:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc   (Op , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc  (Op , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (Op , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc    (Op , phi_f , phi_e , phi_d , inSDp_tab , PSI_IN , PSI_OUT);
		  
		  } break;

		case NEUT_Y_ONLY:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pp_nn_calc   (Op , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pp_nn_calc  (Op , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pp_nn_calc (Op , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pp_nn_calc    (Op , phi_f , phi_e , phi_d , inSDn_tab , PSI_IN , PSI_OUT);
		     
		  } break;
		
		case PROT_NEUT_Y:
		  {
		    if (is_it_a_dagger_a_tilde_a_tilde_fed)   a_dagger_a_tilde_a_tilde_MK_RDM_pn_calc   (Op , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_tilde_fed)  a_dagger_a_dagger_a_tilde_MK_RDM_pn_calc  (Op , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);
		    if (is_it_a_dagger_a_dagger_a_dagger_fed) a_dagger_a_dagger_a_dagger_MK_RDM_pn_calc (Op , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);		      
		    if (is_it_a_tilde_a_tilde_a_tilde_fed)    a_tilde_a_tilde_a_tilde_MK_RDM_pn_calc    (Op , phi_f , phi_e , phi_d , inSDp_tab , inSDn_tab , PSI_IN , PSI_OUT);
		  } break;
		   		  
		default: abort_all ();
		}
	    }	
	}
  
  const unsigned int abcdef_total_indices_dimension = N_nljm_baryon_a*N_nljm_baryon_b*N_nljm_baryon_c*N_nljm_baryon_d*N_nljm_baryon_e*N_nljm_baryon_f;

  const unsigned int first_abcdef_total_index = basic_first_index_determine_for_MPI (abcdef_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_abcdef_total_index = basic_last_index_determine_for_MPI (abcdef_total_indices_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
    
  const bool is_process_active = is_process_active_for_MPI (abcdef_total_indices_dimension ,  THIS_PROCESS);
  
  class array<unsigned int> a_nljm_indices(abcdef_total_indices_dimension) , b_nljm_indices(abcdef_total_indices_dimension) , c_nljm_indices(abcdef_total_indices_dimension);
  class array<unsigned int> d_nljm_indices(abcdef_total_indices_dimension) , e_nljm_indices(abcdef_total_indices_dimension) , f_nljm_indices(abcdef_total_indices_dimension);

  unsigned int total_index = 0;
  
  for (unsigned int sa = 0 ; sa < N_nljm_baryon_a ; sa++)
    for (unsigned int sb = 0 ; sb < N_nljm_baryon_b ; sb++)
      for (unsigned int sc = 0 ; sc < N_nljm_baryon_c ; sc++)
	for (unsigned int sd = 0 ; sd < N_nljm_baryon_d ; sd++)
	  for (unsigned int se = 0 ; se < N_nljm_baryon_e ; se++)
	    for (unsigned int sf = 0 ; sf < N_nljm_baryon_f ; sf++)
	      {	    
		a_nljm_indices(total_index) = sa , b_nljm_indices(total_index) = sb , c_nljm_indices(total_index) = sc;
		d_nljm_indices(total_index) = sd , e_nljm_indices(total_index) = se , f_nljm_indices(total_index) = sf;

		total_index++;
	      }

  if (is_process_active)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
      for (unsigned int abcdef_total_index = first_abcdef_total_index ; abcdef_total_index <= last_abcdef_total_index ; abcdef_total_index++)
	{		
	  const unsigned int sa = a_nljm_indices(abcdef_total_index) , sb = b_nljm_indices(abcdef_total_index) , sc = c_nljm_indices(abcdef_total_index);
	  const unsigned int sd = d_nljm_indices(abcdef_total_index) , se = e_nljm_indices(abcdef_total_index) , sf = f_nljm_indices(abcdef_total_index);
	  
	  const class nljm_struct &phi_a = phi_table_a(sa) , &phi_b = phi_table_b(sb) , &phi_c = phi_table_c(sc);
	  const class nljm_struct &phi_d = phi_table_d(sd) , &phi_e = phi_table_e(se) , &phi_f = phi_table_f(sf);
	  	  	  	  	  
	  const enum particle_type particle_a = phi_a.get_particle () , particle_b = phi_b.get_particle () ,  particle_c = phi_c.get_particle ();
	  const enum particle_type particle_d = phi_d.get_particle () , particle_e = phi_e.get_particle () ,  particle_f = phi_f.get_particle ();
		  
	  const bool frozen_state_a = phi_a.get_frozen_state () , frozen_state_b = phi_b.get_frozen_state () , frozen_state_c = phi_c.get_frozen_state ();
	  const bool frozen_state_d = phi_d.get_frozen_state () , frozen_state_e = phi_e.get_frozen_state () , frozen_state_f = phi_f.get_frozen_state ();
		    
	  if (!frozen_state_a && !frozen_state_b && !frozen_state_c && !frozen_state_d && !frozen_state_e && !frozen_state_f)
	    {	
	      const unsigned int sa_shell_index = phi_a.get_shell_index () , sb_shell_index = phi_b.get_shell_index () , sc_shell_index = phi_c.get_shell_index ();
	      const unsigned int sd_shell_index = phi_d.get_shell_index () , se_shell_index = phi_e.get_shell_index () , sf_shell_index = phi_f.get_shell_index ();
		  	  
	      const bool ab_shells_ordered = ((particle_a != particle_b) || (sa_shell_index <= sb_shell_index)) , cb_shells_ordered = ((particle_b != particle_c) || (sc_shell_index <= sb_shell_index));
	      const bool de_shells_ordered = ((particle_d != particle_e) || (sd_shell_index <= se_shell_index)) , fe_shells_ordered = ((particle_e != particle_f) || (sf_shell_index <= se_shell_index));
	      	  
	      if ( are_ab_coupled_first && !ab_shells_ordered) continue;
	      if (!are_ab_coupled_first && !cb_shells_ordered) continue;
	      if ( are_de_coupled_first && !de_shells_ordered) continue;
	      if (!are_de_coupled_first && !fe_shells_ordered) continue;
	      	      
	      const int la = phi_a.get_l () , lb = phi_b.get_l () , lc = phi_c.get_l ();
	      const int ld = phi_d.get_l () , le = phi_e.get_l () , lf = phi_f.get_l ();

	      const unsigned int bp_abc = binary_parity_from_orbital_angular_momentum (la + lb + lc);
	      const unsigned int bp_def = binary_parity_from_orbital_angular_momentum (ld + le + lf);
	      	      
	      if (bp_abc == bp_def)
		{
		  const int im_a = phi_a.get_im () , im_b = phi_b.get_im () , im_c = phi_c.get_im () , iMK_abc = im_a + im_b + im_c;
		  const int im_d = phi_d.get_im () , im_e = phi_e.get_im () , im_f = phi_f.get_im () , iMK_def = im_d + im_e + im_f;
	    			      
		  if (iMK_abc == iMK_def)
		    {	
		      const int im_a_minus = two_ma_max - im_a;
		      const int im_b_minus = two_mb_max - im_b;
		      const int im_c_minus = two_mc_max - im_c;
	    
		      const unsigned int sa_shell_index = phi_a.get_shell_index (); 
		      const unsigned int sb_shell_index = phi_b.get_shell_index (); 
		      const unsigned int sc_shell_index = phi_c.get_shell_index (); 
	    
		      const unsigned int sa_minus = one_body_a_indices(sa_shell_index , im_a_minus);
		      const unsigned int sb_minus = one_body_b_indices(sb_shell_index , im_b_minus);
		      const unsigned int sc_minus = one_body_c_indices(sc_shell_index , im_c_minus);
	    		      
		      const class GSM_vector &PSI_OUT_abc = PSI_OUT_tab(sa , sb , sc);
		      const class GSM_vector &PSI_OUT_def = PSI_OUT_tab(sd , se , sf);			     			      
		    	    
		      const unsigned int sf_shell_index = phi_f.get_shell_index ();
	      
		      if (is_it_a_tilde_a_tilde_a_tilde_fed)    T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_abc*PSI_OUT_def;
		      if (is_it_a_dagger_a_dagger_a_dagger_fed) T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_abc*PSI_OUT_def;
		      if (is_it_a_dagger_a_tilde_a_tilde_fed)   T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_abc*PSI_OUT_def;
		      if (is_it_a_dagger_a_dagger_a_tilde_fed)  T1_T2_part_uncoupled_MEs_table(sa_minus , sb_minus , sc_minus , sd , se , sf_shell_index) = PSI_OUT_abc*PSI_OUT_def;
	      
		    }}}}}

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) T1_T2_part_uncoupled_MEs_table.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}



















void dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc (
								 const enum dagger_tilde_operator_type Op ,
								 const class correlated_state_str &PSI_qn , 
								 const class GSM_vector_helper_class &GSM_vector_helper ,
								 class array<TYPE> &rho_coupled_reduced_MEs_table)
{
  if (!is_it_rho_coupled_reduced_determine (Op)) error_message_print_abort ("rho.coupled.reduced operators only in dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc");
  
  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::rho_coupled_reduced_MEs_table_calc");
    
  const enum space_type space = GSM_vector_helper.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();

  const class baryons_data &data = data_find (Op , 0 , prot_Y_data , neut_Y_data);

  const unsigned int N_nlj_baryon = data.get_N_nlj_baryon ();

  const class array<class nlj_struct> &shells_qn = data.get_shells_quantum_numbers ();
  
  const double J = PSI_qn.get_J ();
  
  const double M = J;
  
  const int Kmax_PSI = make_int (2.0*J);
		
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);      
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const string file_name_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_qn , M);

  const unsigned int N_valence_baryons = (space == PROT_Y_ONLY) ? (ZYval) : (NYval);
  
  const unsigned int space_dimension = (space == PROT_NEUT_Y)
    ? (space_dimension_read_disk (true , ZYval , NYval , file_name_dimension))
    : (space_dimension_read_disk (N_valence_baryons , file_name_dimension));
  
  class array<unsigned int> inSDp_tab;
  class array<unsigned int> inSDn_tab;

  class array<bool> is_inSDp_in_new_space_tab;
  class array<bool> is_inSDn_in_new_space_tab;

  class array<unsigned char> reordering_bin_phases_p;
  class array<unsigned char> reordering_bin_phases_n;  

  class array<TYPE> PSI_component_tab(space_dimension);
	
  class GSM_vector PSI(GSM_vector_helper);

  if (THIS_PROCESS == MASTER_PROCESS) PSI.eigenvector_read_disk (PSI_qn);

#ifdef UseMPI
  PSI.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	inSDp_tab.allocate (space_dimension , ZYval);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_p.allocate (space_dimension);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_qn , M , prot_Y_data , inSDp_tab , PSI_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p);
      } break;

    case NEUT_Y_ONLY:
      {
	inSDn_tab.allocate (space_dimension , NYval);
	
	is_inSDn_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_n.allocate (space_dimension);
	
	files_IN_tables_read_pp_nn_one_baryon (true , PSI_qn , M , neut_Y_data , inSDn_tab , PSI_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n);
      } break;
		
    case PROT_NEUT_Y:
      {
	inSDp_tab.allocate (space_dimension , ZYval);
	inSDn_tab.allocate (space_dimension , NYval);
	
	is_inSDp_in_new_space_tab.allocate (space_dimension);
	is_inSDn_in_new_space_tab.allocate (space_dimension);

	reordering_bin_phases_p.allocate (space_dimension);
	reordering_bin_phases_n.allocate (space_dimension);

	files_IN_tables_read_pn_one_baryon (true , ZYval , NYval , PSI_qn , M , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , PSI_component_tab ,
					     is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);
      } break;
      
    default: abort_all ();
    }
  
  const double m_max = data.get_m_max ();
  
  const class CG_str CGs(m_max);
  
  const int K_number_PSI = make_int (2*J) + 1;

  class array<double> K_reducing_terms(K_number_PSI);

  K_reducing_terms_calc (J , J , M , M , K_reducing_terms);
  
  for (unsigned int sa = 0 ; sa < N_nlj_baryon ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj_baryon ; sb++)
      {
	const class nlj_struct &shell_sa_qn = shells_qn(sa);
	const class nlj_struct &shell_sb_qn = shells_qn(sb);
		    	
	const bool frozen_state_a = shell_sa_qn.get_frozen_state ();
	const bool frozen_state_b = shell_sb_qn.get_frozen_state ();
	  
	if (!frozen_state_a && !frozen_state_b)
	  {	
	    const int la = shell_sa_qn.get_l ();
	    const int lb = shell_sb_qn.get_l ();

	    const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);
	    const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);

	    if (bp_a == bp_b)
	      {
		const double ja = shell_sa_qn.get_j ();
		const double jb = shell_sb_qn.get_j ();

		class uncoupled_dagger_tilde_table<TYPE> two_body_MK_table(ja , jb);

		switch (space)
		  {
		  case PROT_Y_ONLY: a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI , inSDp_tab , PSI_component_tab , is_inSDp_in_new_space_tab , reordering_bin_phases_p , two_body_MK_table); break;
		  case NEUT_Y_ONLY: a_dagger_a_tilde_MK_table_pp_nn_calc (shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI , inSDn_tab , PSI_component_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_n , two_body_MK_table); break;
		
		  case PROT_NEUT_Y:
		    {
		      a_dagger_a_tilde_MK_table_pn_calc (Op , shell_sa_qn , shell_sb_qn , PSI_qn , PSI_qn , PSI ,
							 inSDp_tab , inSDn_tab , PSI_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab ,
							 reordering_bin_phases_p , reordering_bin_phases_n , two_body_MK_table);
		    } break;
		    
		  default: abort_all ();
		  }
			    
		class coupled_dagger_tilde_table<TYPE> two_body_K_table(Op , ja , jb);

		two_body_K_table_from_MK_table_calc  (J , J , M , M , CGs , K_reducing_terms , two_body_MK_table , two_body_K_table);
		    
		const int Kmin = two_body_K_table.get_Kmin ();

		const int Kmax_j = two_body_K_table.get_Kmax ();
	    
		const int Kmax = min (Kmax_j , Kmax_PSI);
	    
		for (int K = Kmin ; K <= Kmax ; K++) rho_coupled_reduced_MEs_table(sa , sb , K) = two_body_K_table(K);
	      }
	  }
      }
}






















void dagger_tilde_operators::calc_store_PSI_IN_OUT (
						    const input_data_str &input_data , 
						    const class baryons_data &prot_Y_data , 
						    const class baryons_data &neut_Y_data , 
						    const class array<class correlated_state_str> &PSI_qn_tab ,
						    const unsigned int dagger_tilde_operators_index)
{   
  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  
  const enum dagger_tilde_operator_type Op = dagger_tilde_operators_tab(dagger_tilde_operators_index);
  
  if (is_it_RDM_determine (Op)) error_message_print_abort ("No RDM operator in dagger_tilde_operators::calc_store_PSI_IN_OUT");
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int Z_OUT = prot_Y_data.get_N_nucleons ();
  const int N_OUT = neut_Y_data.get_N_nucleons ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
    
  const int S_OUT = input_data.get_hypernucleus_strangeness ();
  
  const class array<unsigned int> &dagger_tilde_operators_BP_IN_tab  = input_data.get_dagger_tilde_operators_BP_IN_tab ();
  const class array<unsigned int> &dagger_tilde_operators_BP_OUT_tab = input_data.get_dagger_tilde_operators_BP_OUT_tab ();
    
  const class array<double> &dagger_tilde_operators_J_IN_tab  = input_data.get_dagger_tilde_operators_J_IN_tab ();
  const class array<double> &dagger_tilde_operators_J_OUT_tab = input_data.get_dagger_tilde_operators_J_OUT_tab ();
  
  const class array<unsigned int> &dagger_tilde_operators_vector_index_IN_tab  = input_data.get_dagger_tilde_operators_vector_index_IN_tab ();
  const class array<unsigned int> &dagger_tilde_operators_vector_index_OUT_tab = input_data.get_dagger_tilde_operators_vector_index_OUT_tab (); 
  
  const class array<int> &dagger_tilde_operators_S_IN_tab  = input_data.get_dagger_tilde_operators_S_IN_tab ();
  
  const unsigned int BP_IN  = dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index);
  const unsigned int BP_OUT = dagger_tilde_operators_BP_OUT_tab(dagger_tilde_operators_index);
      
  const unsigned int vector_index_IN  = dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index);
  const unsigned int vector_index_OUT = dagger_tilde_operators_vector_index_OUT_tab(dagger_tilde_operators_index);
      
  const double J_IN  = dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index);
  const double J_OUT = dagger_tilde_operators_J_OUT_tab(dagger_tilde_operators_index);
      
  const int S_IN = dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index);
  
  const double M_OUT = J_OUT;
      
  const int Z_IN = Z_IN_calc (Op , Z_OUT);
  const int N_IN = N_IN_calc (Op , N_OUT);

  const class correlated_state_str PSI_IN_qn(Z_IN , N_IN , BP_IN , S_IN , J_IN , vector_index_IN , NADA , NADA , NADA , NADA , false);

  const class correlated_state_str PSI_OUT_qn = PSI_quantum_numbers_find (Z_OUT , N_OUT , BP_OUT , S_OUT , J_OUT , vector_index_OUT , PSI_qn_tab);

  const class GSM_vector_helper_class PSI_OUT_helper(space , inter , truncation_hw , truncation_ph ,
						     n_holes_max   , n_scat_max   , E_max_hw  ,
						     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						     n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP_OUT , M_OUT , false);

  class GSM_vector PSI_OUT(PSI_OUT_helper);

  if (THIS_PROCESS == MASTER_PROCESS) PSI_OUT.eigenvector_read_disk (PSI_OUT_qn);

#ifdef UseMPI
  PSI_OUT.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

  if (is_it_one_body_determine (Op))
    one_body_K_tables_calc_store (Op , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
  else if (is_it_two_body_determine (Op))
    two_body_K_tables_calc_store (Op , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
  else if (is_it_three_body_determine (Op))
    three_body_L_K_tables_calc_store (Op , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
  else if (is_it_four_body_determine (Op))
    four_body_L1_L2_K_tables_calc_store (Op , PSI_IN_qn , PSI_OUT_qn , PSI_OUT);
  else
    error_message_print_abort ("No operators found in dagger_tilde_operators::calc_store_PSI_IN_OUT");
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << Op << " matrix elements calculated and stored for " << PSI_IN_qn << "  --> " << PSI_OUT_qn << endl;
}











void dagger_tilde_operators::calc_store_RDM (
					     const input_data_str &input_data , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const class array<class correlated_state_str> &PSI_qn_tab ,
					     const unsigned int dagger_tilde_operators_index)
{   
  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  
  const enum dagger_tilde_operator_type Op = dagger_tilde_operators_tab(dagger_tilde_operators_index);

  if (!is_it_RDM_determine (Op)) error_message_print_abort ("RDM operators only in dagger_tilde_operators::calc_store_RDM");

  const int S = input_data.get_hypernucleus_strangeness ();

  if (S != 0) error_message_print_abort ("RDM operators can only be used with zero strangeness in dagger_tilde_operators::calc_store_RDM");
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int Z_IN = prot_Y_data.get_N_nucleons ();
  const int N_IN = neut_Y_data.get_N_nucleons ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();
  
  const class array<unsigned int> &dagger_tilde_operators_BP_IN_tab = input_data.get_dagger_tilde_operators_BP_IN_tab ();
      
  const class array<int> &dagger_tilde_operators_S_IN_tab  = input_data.get_dagger_tilde_operators_S_IN_tab ();
  
  const class array<double> &dagger_tilde_operators_J_IN_tab = input_data.get_dagger_tilde_operators_J_IN_tab ();
    
  const class array<unsigned int> &dagger_tilde_operators_vector_index_IN_tab = input_data.get_dagger_tilde_operators_vector_index_IN_tab ();  
  
  const unsigned int BP_IN = dagger_tilde_operators_BP_IN_tab(dagger_tilde_operators_index);
  
  const int S_IN = dagger_tilde_operators_S_IN_tab(dagger_tilde_operators_index);
    
  const unsigned int vector_index_IN = dagger_tilde_operators_vector_index_IN_tab(dagger_tilde_operators_index);
      
  const double J_IN = dagger_tilde_operators_J_IN_tab(dagger_tilde_operators_index);
      
  const double M_IN = J_IN;

  const class correlated_state_str PSI_IN_qn = PSI_quantum_numbers_find (Z_IN , N_IN , BP_IN , S_IN , J_IN , vector_index_IN , PSI_qn_tab);

  const class GSM_vector_helper_class PSI_IN_helper(space , inter , truncation_hw , truncation_ph ,
						    n_holes_max   , n_scat_max   , E_max_hw  ,
						    n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						    n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP_IN , M_IN , false);
      	  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Op);
  
  const string PSI_IN_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  
  const string outfile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_IN_qn_string + ".dat";
  
  ofstream outfile;

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      outfile.open (outfile_name.c_str ());

      outfile.precision (15);
    }

  if (is_it_two_body_determine (Op))
    {
      if (is_it_rho_coupled_reduced_determine (Op))
	{
	  const class baryons_data &data = data_find (Op , 0 , prot_Y_data , neut_Y_data);
  
	  const unsigned int N_nlj_baryon = data.get_N_nlj_baryon ();
      
	  const double jmax = data.get_jmax ();
	  
	  const int Kmax_j = make_int (2.0*jmax);

	  const int Kmax_PSI = make_int (2.0*J_IN);
  
	  const int Kmax = min (Kmax_j , Kmax_PSI);
		
	  const int Kmax_plus_one = Kmax + 1;

	  class array<TYPE> rho_coupled_reduced_MEs_table(N_nlj_baryon , N_nlj_baryon , Kmax_plus_one);
      
	  rho_coupled_reduced_MEs_table = 0.0;
      
	  rho_coupled_reduced_MEs_table_calc (Op , PSI_IN_qn , PSI_IN_helper , rho_coupled_reduced_MEs_table);

	  if (THIS_PROCESS == MASTER_PROCESS) rho_coupled_reduced_MEs_table.copy_disk (outfile_name);
	}
      else
	{
	  const class baryons_data &data_a = data_find (Op , 0 , prot_Y_data , neut_Y_data) , &data_b = data_find (Op , 1 , prot_Y_data , neut_Y_data);
	  const class baryons_data &data_c = data_find (Op , 3 , prot_Y_data , neut_Y_data) , &data_d = data_find (Op , 2 , prot_Y_data , neut_Y_data);
  
	  const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon () , N_nljm_baryon_a = data_a.get_N_nljm_baryon ();
	  const unsigned int N_nlj_baryon_b = data_b.get_N_nlj_baryon () , N_nljm_baryon_b = data_b.get_N_nljm_baryon ();
	  const unsigned int N_nlj_baryon_c = data_c.get_N_nlj_baryon () , N_nljm_baryon_c = data_c.get_N_nljm_baryon ();
	  const unsigned int N_nlj_baryon_d = data_d.get_N_nlj_baryon () , N_nljm_baryon_d = data_d.get_N_nljm_baryon ();
      
	  const double ja_max = data_a.get_jmax ();
	  const double jb_max = data_b.get_jmax ();
	  
	  const int Kmax = make_int (ja_max + jb_max);

	  const int Kmax_plus_one = Kmax + 1;
	  
	  class array<TYPE> PQG_uncoupled_MEs_table(N_nljm_baryon_a , N_nljm_baryon_b , N_nljm_baryon_c , N_nlj_baryon_d);

	  class array<TYPE> PQG_partially_coupled_MEs_table(N_nlj_baryon_a , N_nlj_baryon_b , N_nljm_baryon_c , N_nljm_baryon_d , Kmax_plus_one);

	  class array<TYPE> PQG_coupled_MEs_table(N_nlj_baryon_a , N_nlj_baryon_b , N_nlj_baryon_c , N_nlj_baryon_d , Kmax_plus_one);
      
	  PQG_uncoupled_MEs_table = 0.0;
      
	  PQG_uncoupled_MEs_table_calc (Op , PSI_IN_qn , PSI_IN_helper , PQG_uncoupled_MEs_table);	 

	  if (THIS_PROCESS == MASTER_PROCESS)
	    {
	      PQG_partially_coupled_MEs_table = 0.0;
	  
	      PQG_partially_coupled_MEs_table_calc (Op , prot_Y_data , neut_Y_data , PQG_uncoupled_MEs_table , PQG_partially_coupled_MEs_table); 
	  
	      PQG_coupled_MEs_table = 0.0;
	  
	      PQG_coupled_MEs_table_calc (Op , prot_Y_data , neut_Y_data , PQG_partially_coupled_MEs_table , PQG_coupled_MEs_table);
	  
	      PQG_coupled_MEs_table.copy_disk (outfile_name);
	    }
	}
    }
  else
    {
      const enum dagger_tilde_operator_type Op_1 = T1_T2_dagger_tilde_operator_part_determine (1 , Op);
      const enum dagger_tilde_operator_type Op_2 = T1_T2_dagger_tilde_operator_part_determine (2 , Op);
      
      const class baryons_data &data_a = data_find (Op_1 , 0 , prot_Y_data , neut_Y_data) , &data_b = data_find (Op_1 , 1 , prot_Y_data , neut_Y_data) , &data_c = data_find (Op_1 , 2 , prot_Y_data , neut_Y_data);
      const class baryons_data &data_d = data_find (Op_1 , 5 , prot_Y_data , neut_Y_data) , &data_e = data_find (Op_1 , 4 , prot_Y_data , neut_Y_data) , &data_f = data_find (Op_1 , 3 , prot_Y_data , neut_Y_data);
  
      const unsigned int N_nlj_baryon_a = data_a.get_N_nlj_baryon () , N_nljm_baryon_a = data_a.get_N_nljm_baryon ();
      const unsigned int N_nlj_baryon_b = data_b.get_N_nlj_baryon () , N_nljm_baryon_b = data_b.get_N_nljm_baryon ();
      const unsigned int N_nlj_baryon_c = data_c.get_N_nlj_baryon () , N_nljm_baryon_c = data_c.get_N_nljm_baryon ();
      const unsigned int N_nlj_baryon_d = data_d.get_N_nlj_baryon () , N_nljm_baryon_d = data_d.get_N_nljm_baryon ();
      const unsigned int N_nlj_baryon_e = data_e.get_N_nlj_baryon () , N_nljm_baryon_e = data_e.get_N_nljm_baryon ();
      const unsigned int N_nlj_baryon_f = data_f.get_N_nlj_baryon () , N_nljm_baryon_f = data_f.get_N_nljm_baryon ();
  
      const double ja_max = data_a.get_jmax ();
      const double jb_max = data_b.get_jmax ();
      const double jc_max = data_c.get_jmax ();
	  
      const class array<class nlj_struct> &shells_a_qn = data_a.get_shells_quantum_numbers () , &shells_b_qn = data_b.get_shells_quantum_numbers () , &shells_c_qn = data_c.get_shells_quantum_numbers ();
      const class array<class nlj_struct> &shells_d_qn = data_d.get_shells_quantum_numbers () , &shells_e_qn = data_e.get_shells_quantum_numbers () , &shells_f_qn = data_f.get_shells_quantum_numbers ();  
            
      const int Lmax_ab = make_int (ja_max + jb_max);
      const int Lmax_bc = make_int (jb_max + jc_max);

      const int Lmax = max (Lmax_ab , Lmax_bc);
      
      const int Lmax_plus_one = Lmax + 1;
	  
      const double Kmax = ja_max + jb_max + jc_max;

      const unsigned int K_number = make_uns_int (Kmax - 0.5) + 1;
	  	  
      class array<TYPE> T1_T2_coupled_MEs_table     (N_nlj_baryon_a , N_nlj_baryon_b , N_nlj_baryon_c , Lmax_plus_one , N_nlj_baryon_d , N_nlj_baryon_e , N_nlj_baryon_f , Lmax_plus_one , K_number);
      class array<TYPE> T1_T2_coupled_MEs_table_comm(N_nlj_baryon_f , N_nlj_baryon_e , N_nlj_baryon_d , Lmax_plus_one , N_nlj_baryon_c , N_nlj_baryon_b , N_nlj_baryon_a , Lmax_plus_one , K_number);
      
      class array<TYPE> T1_T2_uncoupled_MEs_table(N_nljm_baryon_a , N_nljm_baryon_b , N_nljm_baryon_c , N_nljm_baryon_d , N_nljm_baryon_e , N_nlj_baryon_f);
      
      T1_T2_uncoupled_MEs_table = 0.0;

      T1_T2_part_uncoupled_MEs_table_calc (Op_1 , PSI_IN_qn , PSI_IN_helper , T1_T2_uncoupled_MEs_table);
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  class array<TYPE> T1_T2_partially_coupled_MEs_table(N_nlj_baryon_a , N_nlj_baryon_b , N_nlj_baryon_c , Lmax_plus_one , N_nljm_baryon_d , N_nljm_baryon_e , N_nljm_baryon_f , K_number);
      
	  T1_T2_partially_coupled_MEs_table = 0.0;
      
	  T1_T2_partially_coupled_MEs_table_calc (Op_1 , prot_Y_data , neut_Y_data , T1_T2_uncoupled_MEs_table , T1_T2_partially_coupled_MEs_table);

	  T1_T2_coupled_MEs_table = 0.0;
      
	  T1_T2_coupled_MEs_table_calc (Op_1 , prot_Y_data , neut_Y_data , T1_T2_partially_coupled_MEs_table , T1_T2_coupled_MEs_table);
	}
      
      T1_T2_uncoupled_MEs_table.deallocate ();
      
      class array<TYPE> T1_T2_uncoupled_MEs_table_comm(N_nljm_baryon_f , N_nljm_baryon_e , N_nljm_baryon_d , N_nljm_baryon_c , N_nljm_baryon_b , N_nlj_baryon_a);

      T1_T2_uncoupled_MEs_table_comm = 0.0;

      T1_T2_part_uncoupled_MEs_table_calc (Op_2 , PSI_IN_qn , PSI_IN_helper , T1_T2_uncoupled_MEs_table_comm);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  class array<TYPE> T1_T2_partially_coupled_MEs_table_comm(N_nlj_baryon_f , N_nlj_baryon_e , N_nlj_baryon_d , Lmax_plus_one , N_nljm_baryon_c , N_nljm_baryon_b , N_nljm_baryon_a , K_number);
      
	  T1_T2_partially_coupled_MEs_table_comm = 0.0;
	  
	  T1_T2_partially_coupled_MEs_table_calc (Op_2 , prot_Y_data , neut_Y_data , T1_T2_uncoupled_MEs_table_comm , T1_T2_partially_coupled_MEs_table_comm);

	  T1_T2_coupled_MEs_table_comm = 0.0;
      
	  T1_T2_coupled_MEs_table_calc (Op_2 , prot_Y_data , neut_Y_data , T1_T2_partially_coupled_MEs_table_comm , T1_T2_coupled_MEs_table_comm);
	}
      
      T1_T2_uncoupled_MEs_table_comm.deallocate ();
      		      
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  // Same shell case in T1 is taken into account as one goes from L=0 to L=Lmax. Thus, L and L' must be understood as alpha and alpha' in the same shell case with T1.
	  
	  for (unsigned int sa = 0 ; sa < N_nlj_baryon_a ; sa++)
	    for (unsigned int sb = 0 ; sb < N_nlj_baryon_b ; sb++)
	      for (unsigned int sc = 0 ; sc < N_nlj_baryon_c ; sc++)
		for (unsigned int sd = 0 ; sd < N_nlj_baryon_d ; sd++)
		  for (unsigned int se = 0 ; se < N_nlj_baryon_e ; se++)
		    for (unsigned int sf = 0 ; sf < N_nlj_baryon_f ; sf++)
		      {
			const class nlj_struct &shell_sa_qn = shells_a_qn(sa) , &shell_sb_qn = shells_b_qn(sb) , &shell_sc_qn = shells_c_qn(sc);
			const class nlj_struct &shell_sd_qn = shells_d_qn(sd) , &shell_se_qn = shells_e_qn(se) , &shell_sf_qn = shells_f_qn(sf);
	  
			const int ija = shell_sa_qn.get_ij () , ijb = shell_sb_qn.get_ij () , ijc = shell_sc_qn.get_ij ();
			const int ijd = shell_sd_qn.get_ij () , ije = shell_se_qn.get_ij () , ijf = shell_sf_qn.get_ij ();

			const int phase = minus_one_pow (ija + ijb + ijc + ijd + ije + ijf);
			
			for (int L = 0 ; L <= Lmax ; L++)
			  for (int Lp = 0 ; Lp <= Lmax ; Lp++)
			    for (unsigned int iK = 0 ; iK < K_number ; iK++)
			      {				
				(phase == 1)
				  ? (T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , Lp , iK) += T1_T2_coupled_MEs_table_comm(sf , se , sd , Lp , sc , sb , sa , L , iK))
				  : (T1_T2_coupled_MEs_table(sa , sb , sc , L , sd , se , sf , Lp , iK) -= T1_T2_coupled_MEs_table_comm(sf , se , sd , Lp , sc , sb , sa , L , iK));
			      }
		      }
	  	  
	  T1_T2_coupled_MEs_table.copy_disk (outfile_name);
	}
    }
	
  if (THIS_PROCESS == MASTER_PROCESS) cout << Op << " matrix elements calculated and stored for " << PSI_IN_qn << endl << endl;
}












void dagger_tilde_operators::calc_store (
					 const input_data_str &input_data , 
					 const class baryons_data &prot_Y_data , 
					 const class baryons_data &neut_Y_data , 
					 const class array<class correlated_state_str> &PSI_qn_tab)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "dagger tilde operators matrix elements" << endl;
      cout <<         "--------------------------------------" << endl << endl;
    }

  const unsigned int dagger_tilde_operators_number = input_data.get_dagger_tilde_operators_number ();

  const class array<enum dagger_tilde_operator_type> &dagger_tilde_operators_tab = input_data.get_dagger_tilde_operators_tab ();
  	
  for (unsigned int dagger_tilde_operators_index = 0 ; dagger_tilde_operators_index < dagger_tilde_operators_number ; dagger_tilde_operators_index++)
    {
      const enum dagger_tilde_operator_type Op = dagger_tilde_operators_tab(dagger_tilde_operators_index);

      if (is_it_RDM_determine (Op))
	calc_store_RDM (input_data , prot_Y_data , neut_Y_data , PSI_qn_tab , dagger_tilde_operators_index);
      else
	calc_store_PSI_IN_OUT (input_data , prot_Y_data , neut_Y_data , PSI_qn_tab , dagger_tilde_operators_index);
    }
}
