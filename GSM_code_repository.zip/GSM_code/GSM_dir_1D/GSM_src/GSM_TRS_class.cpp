#include "../GSM_include/GSM_include_def.h"


// TYPE is double or complex
// -------------------------

// Class applying time-reversal symmetry to |Psi[in]> to obtain |Psi[out]>
// -----------------------------------------------------------------------
// One has here initializers (they are neither allocations nor deallocations, so that implicit constructors/destructors are sufficient),
// time-reversal symmetry (TRS) operator apply call and operators overloading of TRS call.
//
// For a one-body state, TRS|nlj m> = (-1)^(j - m) |nlj -m>.
// It is straightforward to extend TRS to Slater determinant.
// TRS|SD> is then another Slater determinant multiplied by a phase (-1)^(alpha_SD), arising from both (-1)^(j - m) and reordering phases.
//
// The main interest of TRS is that [H , TRS] = 0 for M=0, so that H |Psi> = E |Psi> => TRS |Psi> = (-1)^J |Psi>.
// Hence, one can check that <Psi|TRS|SD> = <Psi|SD> (-1)^(J + alpha_SD), so that one just has to calculate about half of the |Psi> components
// (there is no gain if TRS|SD> = +/- |SD>, which is a rare case), the others being obtained with the previous relation.
//
// TRS is also useful to obtain the GSM vector |J -M> from a GSM vector |J M>, with M > 0, as |J -M> = (-1)^(J - M) TRS |J M>.
// This occurs with reactions, where the composite [|Psi[target]> |Psi[projectile]>]^J_M is calculated from Clebsch-Gordans coefficients and |Psi[target] MT> |Psi[projectile] mp> states.
//
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The TRS of a Slater determinant |inSD>, |outSD> = +/- TRS |inSD> is another Slater determinant multiplied by a phase.
// The index and phases of |outSD> are stored, so that one loops over |inSD> to obtained |Psi[out]> -> |Psi[out]> + TRS |Psi[in]>.
//
// Operator overloading only consists of a wrapper routine so that TRS is called elsewhere from a instruction of the form "PSI_out += alpha*TRS (PSI_in)".
//
// Tests are done to check if |Psi[in]> and |Psi[out]> have same parities, opposite total angular quantum numbers and same GSM dimensions.
//
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + TRS.|Psi[in]>.





TRS_class::TRS_class () :
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{}

TRS_class::TRS_class (
		      const class GSM_vector_helper_class &GSM_vector_helper_in , 
		      const class GSM_vector_helper_class &GSM_vector_helper_out)
{
  initialize (GSM_vector_helper_in , GSM_vector_helper_out);
}

void TRS_class::initialize (
			    const class GSM_vector_helper_class &GSM_vector_helper_in , 
			    const class GSM_vector_helper_class &GSM_vector_helper_out)
{
  GSM_vector_helper_in_ptr  = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;
    
  if (GSM_vector_helper_in.get_BP () != GSM_vector_helper_out.get_BP ())     error_message_print_abort ("Parities are not equal in TRS_class");
  if (GSM_vector_helper_in.get_iM () != GSM_vector_helper_out.get_TRS_iM ()) error_message_print_abort ("J projections are not opposite in TRS_class"); 

  if (GSM_vector_helper_in.get_space_dimension () != GSM_vector_helper_out.get_space_dimension ()) error_message_print_abort ("Space dimensions are not equal in TRS_class");
}

void TRS_class::initialize (const class TRS_class &X)
{
  GSM_vector_helper_in_ptr  = X.GSM_vector_helper_in_ptr;
  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;
}

void TRS_class::allocate_fill (const class TRS_class &X)
{
  initialize (X);
}

void TRS_class::deallocate ()
{
  GSM_vector_helper_in_ptr  = NULL;
  GSM_vector_helper_out_ptr = NULL;
}







void TRS_class::apply_add (
			   const class GSM_vector &PSI_in , 
			   class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();

  const class GSM_vector_helper_class &GSM_vector_helper_PSI_in  = PSI_in.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_PSI_out = PSI_out.get_GSM_vector_helper ();

  if (GSM_vector_helper_PSI_in.get_BP () != GSM_vector_helper_in.get_BP ()) error_message_print_abort ("in/PSI_in parities are not equal in TRS_class::apply_add");
  if (GSM_vector_helper_PSI_in.get_iM () != GSM_vector_helper_in.get_iM ()) error_message_print_abort ("in/PSI_in M projections are not equal in TRS_class::apply_add");
  
  if (GSM_vector_helper_PSI_in.get_space_dimension () != GSM_vector_helper_in.get_space_dimension ()) error_message_print_abort ("in/PSI_in space dimensions are not equal in TRS_class::apply_add");

  if (GSM_vector_helper_PSI_out.get_BP () != GSM_vector_helper_out.get_BP ()) error_message_print_abort ("out/PSI_out parities are not equal in TRS_class::apply_add");
  if (GSM_vector_helper_PSI_out.get_iM () != GSM_vector_helper_out.get_iM ()) error_message_print_abort ("out/PSI_out M projections are not equal in TRS_class::apply_add");
  
  if (GSM_vector_helper_PSI_out.get_space_dimension () != GSM_vector_helper_out.get_space_dimension ()) error_message_print_abort ("out/PSI_out space dimensions are not equal in TRS_class::apply_add"); 
     
  const unsigned int space_dimension = GSM_vector_helper_in.get_space_dimension ();
  
  const class array<unsigned int> &TRS_PSI_indices_in_to_out = GSM_vector_helper_in.get_TRS_PSI_indices ();
  
  const class array<unsigned char> &TRS_bin_phases_in_to_out = GSM_vector_helper_in.get_TRS_bin_phases ();
  
  for (unsigned int PSI_in_index = 0 ; PSI_in_index < space_dimension ; PSI_in_index++) 
    {
      const unsigned int PSI_out_index = TRS_PSI_indices_in_to_out(PSI_in_index);

      const unsigned int TRS_bin_phase_out = TRS_bin_phases_in_to_out(PSI_in_index);
      
      const int TRS_phase_out = parity_from_binary_parity (TRS_bin_phase_out);
	      
      PSI_out[PSI_out_index] += (TRS_phase_out == 1) ? (PSI_in[PSI_in_index]) : (-PSI_in[PSI_in_index]);
    }
}



class Op_PSI_closure_str TRS_class::operator () (const class GSM_vector &PSI) const
{
  return Op_PSI_closure_str (*this , PSI);
}

double used_memory_calc (const class TRS_class &T)
{
  return sizeof (T)/1000000.0;
}



