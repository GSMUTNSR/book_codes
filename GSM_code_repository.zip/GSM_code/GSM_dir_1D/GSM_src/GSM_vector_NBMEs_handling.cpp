#include "../GSM_include/GSM_include_def.h"


using namespace MPI_2D_partitioning;
using namespace GSM_vector_dimensions;



// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------





// Calculation of the part of the component of |Psi[out]> for a fixed |outSD> from the jumps on a given |inSD> in O |Psi[in]>
// --------------------------------------------------------------------------------------------------------------------------
//
// component_part_jumps_calc, component_part_one_jump_calc_Jpm
// -----------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |inSD> states obtained from 1p-1h or 2p-2h excitations from |outSD>, for example, so that a part of <outSD | Psi[out]> is calculated.
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
// Jumps are always of proton or neutron type.
//
// component_part_one_jump_calc_Jpm
// --------------------------------
// One uses this routine if one considers O = J+ or J-. As configuration does not change from |inSD> to |outSD>,
// one does not check if the configuration of |inSD> belongs to the GSM model space, at it automatically does.
//
//
// component_part_jumps_number_calc
// --------------------------------
// Number of jumps taking into account model space truncation for a given component part (see above)

TYPE GSM_vector_NBMEs_handling::component_part_jumps_calc (
							   const unsigned int dimension_jumps ,
							   const class array<bool> &is_configuration_accepted_tab , 
							   const class array<unsigned int> &PSI_in_indices , 
							   const class array<TYPE> &NBMEs_jumps ,
							   const class GSM_vector &PSI_in)
{    
  TYPE component_part = 0.0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const unsigned int PSI_in_index = PSI_in_indices(i);

      const bool is_configuration_accepted = is_configuration_accepted_tab(i);
      
      if (is_configuration_accepted)
	{
	  const TYPE &NBME_jump = NBMEs_jumps(i);

	  const TYPE &PSI_in_component = PSI_in[PSI_in_index];
	  
	  component_part += PSI_in_component*NBME_jump;
	} 
    }
  
  return component_part;
}

TYPE GSM_vector_NBMEs_handling::component_part_one_jump_calc_Jpm (
								  const unsigned int dimension_jumps ,
								  const class array<unsigned int> &PSI_in_indices , 
								  const class array<double> &NBMEs_one_jump ,
								  const class GSM_vector &PSI_in)
{  
  TYPE component_part = 0.0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const unsigned int PSI_in_index = PSI_in_indices(i);

      const double NBME_one_jump = NBMEs_one_jump(i);

      const TYPE &PSI_in_component = PSI_in[PSI_in_index];
      
      component_part += PSI_in_component*NBME_one_jump;
    } 
  
  return component_part;
}


unsigned int GSM_vector_NBMEs_handling::component_part_jumps_number_calc (
									  const unsigned int dimension_jumps ,
									  const class array<bool> &is_configuration_accepted_tab)
{  
  unsigned int component_part_jumps_number = 0;

  for (unsigned int i = 0 ; i < dimension_jumps ; i++)
    {
      const bool is_configuration_accepted = is_configuration_accepted_tab(i);
      
      if (is_configuration_accepted) component_part_jumps_number++;
    }
  
  return component_part_jumps_number;
}













// Calculation of the part of the component of |Psi[out]> for a fixed |outSD> from the jumps on a given |inSD> in O |Psi[in]> and OBMEs for a one-body operator
// ------------------------------------------------------------------------------------------------------------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given one-body operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |inSD> states obtained from 1p-1h excitations from |outSD> and one calculates the NBMEs equal to <outSD | O | inSD>.
// Indeed, one has <outSD | O | inSD> = +/- <s[out] | O | s[in]>, with |s[in]> and |s[out]> the differing states in |inSD> and |outSD>, and +/- 1 is the reordering phase. 
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
//
// One uses NBMEs_one_jump_mu_calc_one_body_operator_Jpm if one considers O = J+ or J-.
// The only difference with the previous case is that the OBMEs and NBMEs of J+ and J- are real, instead of complex for the general operator.
//
// mu is proton or neutron.

void GSM_vector_NBMEs_handling::NBMEs_jumps_mu_calc_one_body_operator (
								       const class array<TYPE> &OBMEs_mu,
								       const class jumps_data_str &jumps_one_mu,
								       class array<TYPE> &NBMEs_jumps_mu)
{
  const unsigned int dimension_one_jump = jumps_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_inSD_str &jumps_one_mu_inSD = jumps_one_mu(i);

      const unsigned int mu_in  = jumps_one_mu_inSD.get_mu_in ();
      const unsigned int mu_out = jumps_one_mu_inSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = jumps_one_mu_inSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
      const TYPE &OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_jumps_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}

void GSM_vector_NBMEs_handling::NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
									      const class array<double> &OBMEs_mu,
									      const class jumps_data_str &one_jump_one_mu,
									      class array<double> &NBMEs_one_jump_mu)
{
  const unsigned int dimension_one_jump = one_jump_one_mu.get_dimension ();

  for (unsigned int i = 0 ; i < dimension_one_jump ; i++)
    {
      const class jumps_data_inSD_str &one_jump_one_mu_inSD = one_jump_one_mu(i);

      const unsigned int mu_in  = one_jump_one_mu_inSD.get_mu_in ();
      const unsigned int mu_out = one_jump_one_mu_inSD.get_mu_out ();

      const unsigned int total_bin_phase_mu = one_jump_one_mu_inSD.get_total_bin_phase ();

      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
      
      const double OBME_mu = OBMEs_mu(mu_in , mu_out);

      NBMEs_one_jump_mu(i) = (total_phase_mu == 1) ? (OBME_mu) : (-OBME_mu);
    }
}








// Calculation and storage of booleans stating if the configuration or |inSD> belongs to the model space and of the indices of |inSD> in |Psi[in]>, issued from jumps on |outSD>
// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// One considers |Psi[out]> = O |Psi[in]> for a given operator O.
// One has <outSD | Psi[out]> = <outSD | O | Psi[in]> = \sum_{inSD} <outSD | O | inSD> . <inSD | Psi[in]> for a fixed |outSD>.
// One considers here the |inSD> states obtained from 1p-1h or 2p-2h excitations from |outSD>, for example.
//
// One calculates and stores booleans stating if the configuration of |inSD> belongs to the model space in ...is_configuration_accepted...fill routines.
// One calculates and stores the indices of |inSD> in |Psi[in]> as well in ...PSI_in_indices... routines.
//
// As the indices of |inSD> in |Psi[in]> are fonction of their configuration (see GSM_vector_dimensions.cpp),
// one precalculates part of the index everytime the configuration changes when looping on jumps values.
//
// Slater determinants here can possess only protons, only neutrons or protons and neutrons.
// Jumps are always of proton or neutron type.
//
// mu is proton or neutron.
//
//
// ..._Jpm routines
// ----------------
// One uses these routines if one considers O = J+ or J-. As configuration does not change from |inSD> to |outSD>,
// one does not check if the configuration of |inSD> belongs to the GSM model space, at it automatically does.


void GSM_vector_NBMEs_handling::is_configuration_accepted_p_fill (
								  const int n_holes_n , 
								  const int n_scat_n , 
								  const int En_hw , 
								  const class jumps_data_str &jumps_p , 
								  const class GSM_vector_helper_class &GSM_vector_helper_in , 
								  class array<bool> &is_configuration_accepted_p_tab ,
								  bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const unsigned int dimension_jumps_p = jumps_p.get_dimension ();
    
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();

  bool is_configuration_accepted = true;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_p ; i++)
    {
      const class jumps_data_inSD_str &jumps_p_inSDp = jumps_p(i);
      
      const bool is_configuration_changing = jumps_p_inSDp.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_p_in = jumps_p_inSDp.get_n_holes ();
	  
	  const int n_scat_p_in = jumps_p_inSDp.get_n_scat ();

	  const int Ep_hw_in = jumps_p_inSDp.get_E_hw ();

	  is_configuration_accepted = true;
									  
	  if (truncation_hw && (Ep_hw_in + En_hw > E_max_hw)) is_configuration_accepted = false;
	  
	  if (truncation_ph && ((n_holes_p_in + n_holes_n > n_holes_max) || (n_scat_p_in + n_scat_n > n_scat_max))) is_configuration_accepted = false;
	}

      if (is_configuration_accepted) is_there_calc = true;

      is_configuration_accepted_p_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::is_configuration_accepted_n_fill (
								  const int n_holes_p , 
								  const int n_scat_p ,
								  const int Ep_hw , 
								  const class jumps_data_str &jumps_n , 
								  const class GSM_vector_helper_class &GSM_vector_helper_in , 
								  class array<bool> &is_configuration_accepted_n_tab ,
								  bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const unsigned int dimension_jumps_n = jumps_n.get_dimension ();
    
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();

  bool is_configuration_accepted = true;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_n ; i++)
    {
      const class jumps_data_inSD_str &jumps_n_inSDn = jumps_n(i);
      
      const bool is_configuration_changing = jumps_n_inSDn.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_n_in = jumps_n_inSDn.get_n_holes ();
	  
	  const int n_scat_n_in = jumps_n_inSDn.get_n_scat ();

	  const int En_hw_in = jumps_n_inSDn.get_E_hw ();

	  is_configuration_accepted = true;
									  
	  if (truncation_hw && (Ep_hw + En_hw_in > E_max_hw)) is_configuration_accepted = false;
	  
	  if (truncation_ph && ((n_holes_p + n_holes_n_in > n_holes_max) || (n_scat_p + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	}

      if (is_configuration_accepted) is_there_calc = true;

      is_configuration_accepted_n_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::is_configuration_accepted_PSI_in_indices_p_fill (
										 const unsigned int BPn , 
										 const int Sn , 
										 const int n_spec_n , 
										 const int n_holes_n , 
										 const int n_scat_n , 
										 const unsigned int iCn , 
										 const int iMn , 
										 const unsigned int SDn_index , 
										 const int En_hw , 
										 const class jumps_data_str &jumps_p , 
										 const class GSM_vector_helper_class &GSM_vector_helper_in , 
										 const unsigned int dimension_SDn ,
										 class array<bool> &is_configuration_accepted_p_tab ,
										 class array<unsigned int> &PSI_in_indices_p ,
										 bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const int S = GSM_vector_helper_in.get_S ();
  
  const unsigned int dimension_jumps_p = jumps_p.get_dimension ();

  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
    
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();

  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();

  const int iM = GSM_vector_helper_in.get_iM ();
  
  const unsigned int BPp = binary_parity_product (BP , BPn);

  const int Sp = S - Sn;
  
  const int n_spec_p = n_spec_max - n_spec_n;
  
  const int iMp = iM - iMn;
	      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();

  bool is_configuration_accepted = true;

  unsigned int PSI_in_index_zero_SDn_fixed = 0;

  PSI_in_indices_p = space_dimension_in;

  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_jumps_p ; i++)
    {
      const class jumps_data_inSD_str &jumps_p_inSDp = jumps_p(i);

      const bool is_configuration_changing = jumps_p_inSDp.get_is_configuration_changing ();
      
      if (is_configuration_changing)
	{ 
	  const int n_holes_p_in = jumps_p_inSDp.get_n_holes ();
	  
	  const int n_scat_p_in = jumps_p_inSDp.get_n_scat ();

	  const int Ep_hw_in = jumps_p_inSDp.get_E_hw ();

	  is_configuration_accepted = true;
									  
	  if (truncation_hw && (Ep_hw_in + En_hw > E_max_hw)) is_configuration_accepted = false;

	  if (truncation_ph && ((n_holes_p_in + n_holes_n > n_holes_max) || (n_scat_p_in + n_scat_n > n_scat_max))) is_configuration_accepted = false;
						  
	  if (is_configuration_accepted) 
	    {
	      const unsigned int iCp_in = jumps_p_inSDp.get_iC ();

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);
	      
	      PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
	    }
	}

      if (is_configuration_accepted)
	{
	  const unsigned int inSDp_index = jumps_p_inSDp.get_inSD_index ();

	  const unsigned int PSI_in_index = PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;

	  PSI_in_indices_p(i) = PSI_in_index;
		
	  is_there_calc = true;
	}

      is_configuration_accepted_p_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::is_configuration_accepted_PSI_in_indices_n_fill (
										 const unsigned int BPp , 
										 const int Sp ,   
										 const int n_spec_p ,   
										 const int n_holes_p ,  
										 const int n_scat_p , 
										 const unsigned int iCp , 
										 const int iMp , 
										 const unsigned int SDp_index , 
										 const int Ep_hw , 
										 const class jumps_data_str &jumps_n , 
										 const class GSM_vector_helper_class &GSM_vector_helper_in ,
										 class array<bool> &is_configuration_accepted_n_tab , 
										 class array<unsigned int> &PSI_in_indices_n ,
										 bool &is_there_calc)
{
  const bool truncation_hw = GSM_vector_helper_in.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_in.get_truncation_ph ();
  
  const int S = GSM_vector_helper_in.get_S ();
  
  const unsigned int dimension_jumps_n = jumps_n.get_dimension ();
  
  const int n_holes_max = GSM_vector_helper_in.get_n_holes_max ();
  
  const int n_spec_max = GSM_vector_helper_in.get_n_spec_max ();
  
  const int n_scat_max = GSM_vector_helper_in.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_in.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_in.get_BP ();
  
  const int iM = GSM_vector_helper_in.get_iM ();
    
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
     
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
  
  const class baryons_data &neut_Y_data = GSM_vector_helper_in.get_neut_Y_data ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const unsigned int BPn = binary_parity_product (BP , BPp);

  const int Sn = S - Sp;

  const int n_spec_n = n_spec_max - n_spec_p;
  
  const int iMn = iM - iMp;
	      
  bool is_configuration_accepted = true;

  unsigned int PSI_in_index_zero_SDp_fixed = 0;

  PSI_in_indices_n = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_jumps_n ; i++)
    {
      const class jumps_data_inSD_str &jumps_n_inSDn = jumps_n(i);

      const bool is_configuration_changing = jumps_n_inSDn.get_is_configuration_changing ();

      if (is_configuration_changing)
	{ 
	  const int n_holes_n_in = jumps_n_inSDn.get_n_holes ();
	  
	  const int n_scat_n_in = jumps_n_inSDn.get_n_scat ();

	  const int En_hw_in = jumps_n_inSDn.get_E_hw ();
	      
	  is_configuration_accepted = true;
	  
	  if (truncation_hw && (Ep_hw + En_hw_in > E_max_hw)) is_configuration_accepted = false;

	  if (truncation_ph && ((n_holes_p + n_holes_n_in > n_holes_max) || (n_scat_p + n_scat_n_in > n_scat_max))) is_configuration_accepted = false;
	      
	  if (is_configuration_accepted)
	    {
	      const unsigned int iCn_in = jumps_n_inSDn.get_iC ();

	      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector_in(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);

	      PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
	    }
	} 

      if (is_configuration_accepted)
	{
	  const unsigned int inSDn_index = jumps_n_inSDn.get_inSD_index ();

	  const unsigned int PSI_in_index = PSI_in_index_zero_SDp_fixed + inSDn_index;

	  PSI_in_indices_n(i) = PSI_in_index;	      

	  is_there_calc = true;
	}

      is_configuration_accepted_n_tab(i) = is_configuration_accepted;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_pp_nn_fill (
							   const class jumps_data_str &jumps_mu , 
							   const class GSM_vector_helper_class &GSM_vector_helper_in ,
							   class array<unsigned int> &PSI_in_indices ,
							   bool &is_there_calc)
{
  const unsigned int dimension_jumps_mu = jumps_mu.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
   
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_in = GSM_vector_helper_in.get_sum_dimensions_GSM_vector ();
    
  unsigned int sum_dimensions_configuration_fixed_in = 0;

  PSI_in_indices = space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_jumps_mu ; i++)
    {
      const class jumps_data_inSD_str &jumps_mu_inSD = jumps_mu(i);

      const bool is_configuration_changing = jumps_mu_inSD.get_is_configuration_changing ();

      if (is_configuration_changing)
	{
	  const int n_scat_in = jumps_mu_inSD.get_n_scat ();

	  const unsigned int iC_in = jumps_mu_inSD.get_iC ();

	  sum_dimensions_configuration_fixed_in = sum_dimensions_GSM_vector_in(n_scat_in , iC_in);
	}

      const unsigned int inSD_index = jumps_mu_inSD.get_inSD_index ();

      const unsigned int PSI_in_index = sum_dimensions_configuration_fixed_in + inSD_index;
	  
      PSI_in_indices(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_p_fill_Jpm (
							   const unsigned int SDn_index ,
							   const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
							   const class jumps_data_str &one_jump_p , 
							   const class GSM_vector_helper_class &GSM_vector_helper_in ,
							   const unsigned int dimension_SDn ,
							   class array<unsigned int> &PSI_in_indices_p ,
							   bool &is_there_calc)
{
  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
   
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
 
  PSI_in_indices_p = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
    {
      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;
      
      PSI_in_indices_p(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_p_fill_Jpm (
							   const unsigned int SDn_index ,
							   const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
							   const class jumps_data_str &one_jump_p , 
							   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
							   const unsigned int dimension_SDn ,
							   class array<unsigned int> &PSI_in_indices_p ,
							   bool &is_there_calc)
{
  const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
   
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero_SDn_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
 
  PSI_in_indices_p = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_p ; i++)
    {
      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(i);

      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
      
      const unsigned int PSI_in_index = PSI_in_index_zero_SDn_fixed + dimension_SDn*inSDp_index;
      
      PSI_in_indices_p(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_n_fill_Jpm (
							   const unsigned int SDp_index , 							      
							   const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
							   const unsigned int dimension_inSDn ,
							   const class jumps_data_str &one_jump_n , 
							   const class GSM_vector_helper_class &GSM_vector_helper_in ,
							   class array<unsigned int> &PSI_in_indices_n ,
							   bool &is_there_calc)
{
  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
 
  const unsigned int PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
		  
  PSI_in_indices_n = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
    {
      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero_SDp_fixed + inSDn_index;

      PSI_in_indices_n(i) = PSI_in_index; 
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_n_fill_Jpm (
							   const unsigned int SDp_index , 							      
							   const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
							   const unsigned int dimension_inSDn ,
							   const class jumps_data_str &one_jump_n , 
							   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
							   class array<unsigned int> &PSI_in_indices_n ,
							   bool &is_there_calc)
{
  const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();
 
  const unsigned int PSI_in_index_zero_SDp_fixed = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
		  
  PSI_in_indices_n = space_dimension_in;

  is_there_calc = false;

  for (unsigned int i = 0 ; i < dimension_one_jump_n ; i++)
    {
      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(i);

      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero_SDp_fixed + inSDn_index;

      PSI_in_indices_n(i) = PSI_in_index; 
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_pp_nn_fill_Jpm (			      
							       const unsigned int sum_dimensions_configuration_fixed_in ,
							       const class jumps_data_str &one_jump_mu , 
							       const class GSM_vector_helper_class &GSM_vector_helper_in ,
							       class array<unsigned int> &PSI_in_indices ,
							       bool &is_there_calc)
{
  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero = sum_dimensions_configuration_fixed_in;
  
  PSI_in_indices = space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
    {
      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

      const unsigned int inSD_index = one_jump_mu_inSD.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero + inSD_index;

      PSI_in_indices(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}

void GSM_vector_NBMEs_handling::PSI_in_indices_pp_nn_fill_Jpm (			      
							       const unsigned int sum_dimensions_configuration_fixed_in ,
							       const class jumps_data_str &one_jump_mu , 
							       const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
							       class array<unsigned int> &PSI_in_indices ,
							       bool &is_there_calc)
{
  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();
  
  const unsigned int space_dimension_in = GSM_vector_helper_in.get_space_dimension ();

  const unsigned int PSI_in_index_zero = sum_dimensions_configuration_fixed_in;
  
  PSI_in_indices = space_dimension_in;
  
  is_there_calc = false;
  
  for (unsigned int i = 0 ; i < dimension_one_jump_mu ; i++)
    {
      const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(i);

      const unsigned int inSD_index = one_jump_mu_inSD.get_inSD_index ();

      const unsigned int PSI_in_index = PSI_in_index_zero + inSD_index;

      PSI_in_indices(i) = PSI_in_index;
	  
      is_there_calc = true;
    }
}


