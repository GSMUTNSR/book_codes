#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace correlated_state_routines;

// TYPE is double or complex
// -------------------------

// Calculation of the Coulomb isospin mixture <Psi[good T] | Psi>^2
// ----------------------------------------------------------------



void Coulomb_isospin_mixture::calc_print (
					  const class input_data_str &input_data , 
					  class baryons_data &prot_Y_data , 
					  class baryons_data &neut_Y_data , 
					  const class array<class correlated_state_str> &PSI_qn_tab)
{ 
  cout.precision (15);
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Coulomb isospin mixtures" << endl;
      cout <<         "------------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();

  const int S = input_data.get_hypernucleus_strangeness ();
  
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
  
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const unsigned int Coulomb_isospin_mixture_number = input_data.get_Coulomb_isospin_mixture_number ();

  const class array<unsigned int> &Coulomb_isospin_mixture_BP_tab  = input_data.get_Coulomb_isospin_mixture_BP_tab ();

  const class array<double> &Coulomb_isospin_mixture_J_tab  = input_data.get_Coulomb_isospin_mixture_J_tab ();

  const class array<unsigned int> &Coulomb_isospin_mixture_vector_index_tab  = input_data.get_Coulomb_isospin_mixture_vector_index_tab ();
  
  for (unsigned int Coulomb_isospin_mixture_index = 0 ; Coulomb_isospin_mixture_index < Coulomb_isospin_mixture_number ; Coulomb_isospin_mixture_index++)
    {
      const unsigned int BP = Coulomb_isospin_mixture_BP_tab(Coulomb_isospin_mixture_index);

      const unsigned int vector_index = Coulomb_isospin_mixture_vector_index_tab(Coulomb_isospin_mixture_index);

      const double J = Coulomb_isospin_mixture_J_tab(Coulomb_isospin_mixture_index);

      const double M = J;
      
      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , S , J , vector_index , PSI_qn_tab);

      const class GSM_vector_helper_class PSI_helper(space , inter , truncation_hw , truncation_ph , 						     
						     n_holes_max   , n_scat_max   , E_max_hw  ,
						     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						     n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP , M , true);
      
      class GSM_vector PSI_good_T(PSI_helper);

      if (THIS_PROCESS == MASTER_PROCESS) PSI_good_T.eigenvector_good_T_read_disk (PSI_qn);

#ifdef UseMPI
      PSI_good_T.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
      class GSM_vector PSI(PSI_helper);

      if (THIS_PROCESS == MASTER_PROCESS) PSI.eigenvector_read_disk (PSI_qn);

#ifdef UseMPI
      PSI.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      const TYPE Coulomb_isospin_mixture_overlap = (PSI_good_T*PSI);
	  
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const TYPE Coulomb_isospin_mixture_PSI = Coulomb_isospin_mixture_overlap*Coulomb_isospin_mixture_overlap;
	  
	  cout << J_Pi_vector_index_string (BP , J , vector_index) << " Coulomb isospin mixture : " << Coulomb_isospin_mixture_PSI << endl;
	}
    }
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}





