#include "../GSM_include/GSM_include_def.h"

using namespace Wigner_signs;
using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;
using namespace correlated_state_routines;



// TYPE is double or complex
// -------------------------

// Calculation of the <Psi[out] | Op | Psi[in]> beta-transition matrix elements from their <Psi[out] | Op | SD[in]> parts
// ----------------------------------------------------------------------------------------------------------------------
// Two different routines are used for beta+ and beta- operators.
// One has <Psi[out] | Op | SD[in]> = \sum_{SD[out]} c_{SD[in]} c_{SD[out]} <SD[out] | Op | SD[in]>, so that summing for all c_{SD[in]} <Psi[out] | Op | SD[in]> provides with <Psi[out] | Op | Psi[in]>.
// A single c_{SD[in]} <Psi[out] | Op | SD[in]> is calculated in the next two functions.
// They are summed afterwards. 
// Only the value of <Psi[out] | Op | Psi[in]> in the master process is meaningful after MPI reduction.
//
// One generates |SD[out]> from |SD[in]> with a+(p) a(n) for beta- or a+(n) a(p) for beta+, 
// with <SD[out] | Op | SD[in]> = +/- <out | Op | in>, and |in> and |out> the different proton and neutron one-body states in the Slater determinants.
// For this, one loops over all the proton/neutron states occupied in |SD[in]>, and one loops over all neutron/proton states of the model space to generate |SD[out]>.
// Then, one checks if the obtained |SD[out]> belongs to the model space. Antisymmetry requirements, parity, M-conservation ,and rank requirement (\vec{J[in]} + \vec{rank[Op]} = \vec{J[out]}) are taken into account.
// 
// OpenMP parallelization can be used therein, as well as MPI parallelization.
// MPI parallelization is already in the loop over |SD[in]>, calling the functions returning c_{SD[in]} <Psi[out] | Op | SD[in]>.
// OpenMP parallelization is done at the level of the loop of nucleon index in |SD[in]>, which is the first loop.
// The gain is apparently small, but calculations start to be long only for a number of proton or neutron valence nucleons larger than 4, and the number of threads is typically close to 10 (32 is a very maximum).
// Hence, the gain in speed is not that bad. Moreover, MPI parallelization is well balanced.
// Work arrays, one for each thread, are allocated to avoid race conditions.

TYPE beta_transitions_NBMEs::component_part_beta_plus_calc (
							    const int rank_Op , 
							    const int rank_Op_projection , 
							    const class array<TYPE> &OBMEs , 
							    const class configuration &Cp_in , 
							    const class configuration &Cn_in , 
							    const class Slater_determinant &inSDp , 
							    const class Slater_determinant &inSDn ,
							    const TYPE &PSI_IN_component ,  
							    const unsigned int reordering_bin_phase_p ,
							    const unsigned int reordering_bin_phase_n ,
							    const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int ZYval_IN = ZYval + 1;

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
    
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const double Mp_max = prot_Y_data.get_M_max ();
  const double Mn_max = neut_Y_data.get_M_max ();
  
  const class one_body_indices_str &one_body_n_indices = neut_Y_data.get_one_body_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const unsigned int BPp_in = Cp_in.BP_determine (shells_qn_p);
  const unsigned int BPn_in = Cn_in.BP_determine (shells_qn_n);
    
  const double Mp_in = inSDp.M_determine (phi_p_table);
  const double Mn_in = inSDn.M_determine (phi_n_table);
  
  const int Ep_in_hw = Cp_in.E_hw_determine (shells_qn_p);
  const int En_in_hw = Cn_in.E_hw_determine (shells_qn_n);
  
  const int n_holes_p_in = Cp_in.n_holes_determine (shells_qn_p);
  const int n_holes_n_in = Cn_in.n_holes_determine (shells_qn_n);
  
  const int n_scat_p_in = Cp_in.n_scat_determine (shells_qn_p);
  const int n_scat_n_in = Cn_in.n_scat_determine (shells_qn_n); 

  class array<class Slater_determinant> outSDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDp_tab(i).allocate (ZYval);
      outSDn_tab(i).allocate (NYval);
      
      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);
      
      Cp_out_tab(i).allocate (ZYval);
      Cn_out_tab(i).allocate (NYval);
      
      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
    }
  
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
  for (int p_in = 0 ; p_in < ZYval_IN ; p_in++)
    {
      const unsigned int state_p_in = inSDp[p_in];

      const unsigned i_thread = OpenMP_thread_number_determine ();
      
      class Slater_determinant &outSDp = outSDp_tab(i_thread);

      unsigned int bin_phase_p = reordering_bin_phase_p;

      inSDp.excitation_1h_and_bin_phase (state_p_in , outSDp , bin_phase_p);

      const class nljm_struct &phi_p_in = phi_p_table(state_p_in);
            
      const double mp_in = phi_p_in.get_m ();

      const double Mp_out = Mp_in - mp_in;
      
      const int ijp_in = phi_p_in.get_ij ();

      const int lp_in = phi_p_in.get_l ();

      const int iMp_out = make_int (Mp_out + Mp_max);
      
      const unsigned int bp_p_in = binary_parity_from_orbital_angular_momentum (lp_in);

      const unsigned int BPp_out = binary_parity_product (BPp_in  , bp_p_in);
      const unsigned int BPn_out = binary_parity_product (BPp_out , BP_OUT);
      
      const int ep_trunc_in = phi_p_in.get_e_trunc ();
      
      const int Ep_out_hw = Ep_in_hw - ep_trunc_in;
      
      const bool core_state_p_in = phi_p_in.get_core_state ();
      
      const int n_holes_p_out = (core_state_p_in) ? (n_holes_p_in + 1) : (n_holes_p_in);
            
      const bool S_matrix_pole_p_in = phi_p_in.get_S_matrix_pole ();
  
      const int scat_p_in = (S_matrix_pole_p_in) ? (0) : (1);
        
      const int n_scat_p_out = n_scat_p_in - scat_p_in;

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      class configuration &Cp_out = Cp_out_tab(i_thread);
      class configuration &Cp_try = Cp_try_tab(i_thread);

      Cp_out.get_SD_configuration (phi_p_table , outSDp);

      class Slater_determinant &SDp_try = SDp_try_tab(i_thread);

      const unsigned int iCp_out = Cp_out.index_search (BPp_out , 0 , 0 , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
	  
      const unsigned int outSDp_index = outSDp.index_search (BPp_out , 0 , 0 , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);

      const double mn_out = mp_in + rank_Op_projection;

      const double Mn_out = Mn_in + mn_out;

      const int iMn_out = make_int (Mn_out + Mn_max);

      const int abs_mn_out_minus_half = make_int (abs (mn_out) - 0.5);

      for (unsigned int sn_out = 0 ; sn_out < Nn_nlj ; sn_out++)
	{
	  const class nlj_struct &shell_n_out = shells_qn_n(sn_out);
	      
	  const bool frozen_state_n_out = shell_n_out.get_frozen_state ();

	  if (frozen_state_n_out) continue;
		      
	  const enum particle_type particle_n_out = shell_n_out.get_particle ();
            
	  const int nn_out = shell_n_out.get_n ();
	  const int ln_out = shell_n_out.get_l ();
	      
	  const double jn_out = shell_n_out.get_j ();

	  const int ijn_out = shell_n_out.get_ij ();

	  const unsigned int bp_n_out = binary_parity_from_orbital_angular_momentum (ln_out);

	  const unsigned int BPn_out_sn_out = binary_parity_product (BPn_in , bp_n_out);
	  
	  if ((BPn_out_sn_out == BPn_out) && (abs_mn_out_minus_half - ijn_out <= 0) && (abs (ijp_in - ijn_out) <= rank_Op) && (ijp_in + ijn_out + 1 >= rank_Op))
	    {
	      const unsigned int state_n_out = one_body_n_indices(particle_n_out , nn_out , ln_out , jn_out , mn_out);

	      if (!inSDn.is_valence_state_occupied (state_n_out))
		{
		  const int en_trunc_out = shell_n_out.get_e_trunc ();

		  const int En_out_hw = En_in_hw + en_trunc_out;

		  const bool core_state_n_out = shell_n_out.get_core_state ();
		                  
		  const int n_holes_n_out = (core_state_n_out) ? (n_holes_n_in - 1) : (n_holes_n_in);
      
		  const bool S_matrix_pole_n_out = shell_n_out.get_S_matrix_pole ();
		      
		  const int scat_n_out = (S_matrix_pole_n_out) ? (0) : (1);
		            		  
		  const int n_scat_n_out = n_scat_n_in + scat_n_out;

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
		      
		  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;     
		
		  class Slater_determinant &outSDn = outSDn_tab(i_thread);
      
		  class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
	  
		  unsigned int bin_phase_n = reordering_bin_phase_n;

		  inSDn.excitation_1p_and_bin_phase (state_n_out , outSDn , bin_phase_n); 

		  class configuration &Cn_out = Cn_out_tab(i_thread);

		  class configuration &Cn_try = Cn_try_tab(i_thread);
	  
		  Cn_out.get_SD_configuration (phi_n_table , outSDn);

		  const unsigned int iCn_out = Cn_out.index_search (BPn_out , 0 , 0 , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);

		  const unsigned int outSDn_index = outSDn.index_search (BPn_out , 0 , 0 , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , 0 , 0 , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
			  
		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , 0 , 0 , n_scat_n_out , iCn_out , iMn_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		  const TYPE OBME = OBMEs(state_p_in , state_n_out);

		  const TYPE NBME = (bin_phase_p == bin_phase_n) ? (OBME) : (-OBME);

		  const TYPE PSI_OUT_component_times_NBME = PSI_OUT[PSI_OUT_index]*NBME;

		  Re_Op_amplitude_part += real_dc (PSI_OUT_component_times_NBME);
		  Im_Op_amplitude_part += imag_dc (PSI_OUT_component_times_NBME);
		}
	    }
	}
    } 

  TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);

  Op_amplitude_part *= PSI_IN_component;

  return Op_amplitude_part;
}












TYPE beta_transitions_NBMEs::component_part_beta_minus_calc (
							     const int rank_Op , 
							     const int rank_Op_projection , 
							     const class array<TYPE> &OBMEs , 
							     const class configuration &Cp_in , 
							     const class configuration &Cn_in , 
							     const class Slater_determinant &inSDp , 
							     const class Slater_determinant &inSDn , 
							     const TYPE &PSI_IN_component , 
							     const unsigned int reordering_bin_phase_p ,
							     const unsigned int reordering_bin_phase_n ,		  
							     const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const int NYval_IN = NYval + 1;
  
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const double Mp_max = prot_Y_data.get_M_max ();
  const double Mn_max = neut_Y_data.get_M_max ();
  
  const class one_body_indices_str &one_body_p_indices = prot_Y_data.get_one_body_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<unsigned int> &dimensions_configuration_p_set = prot_Y_data.get_dimensions_configuration_set ();
  const class array<unsigned int> &dimensions_configuration_n_set = neut_Y_data.get_dimensions_configuration_set ();
  
  const class array_of_configuration &configuration_p_set = prot_Y_data.get_configuration_set ();
  const class array_of_configuration &configuration_n_set = neut_Y_data.get_configuration_set ();
  
  const class array<class nlj_struct> &shells_qn_p = prot_Y_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &shells_qn_n = neut_Y_data.get_shells_quantum_numbers ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_OUT = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const unsigned int BPp_in = Cp_in.BP_determine (shells_qn_p);
  const unsigned int BPn_in = Cn_in.BP_determine (shells_qn_n);
    
  const double Mp_in = inSDp.M_determine (phi_p_table);
  const double Mn_in = inSDn.M_determine (phi_n_table);
  
  const int Ep_in_hw = Cp_in.E_hw_determine (shells_qn_p);
  const int En_in_hw = Cn_in.E_hw_determine (shells_qn_n);
  
  const int n_holes_p_in = Cp_in.n_holes_determine (shells_qn_p);
  const int n_holes_n_in = Cn_in.n_holes_determine (shells_qn_n);
    
  const int n_scat_p_in = Cp_in.n_scat_determine (shells_qn_p);
  const int n_scat_n_in = Cn_in.n_scat_determine (shells_qn_n); 	    

  class array<class Slater_determinant> outSDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> outSDn_tab(NUMBER_OF_THREADS);

  class array<class Slater_determinant> SDp_try_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_try_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_out_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_out_tab(NUMBER_OF_THREADS);

  class array<class configuration> Cp_try_tab(NUMBER_OF_THREADS);
  class array<class configuration> Cn_try_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDp_tab(i).allocate (ZYval);
      outSDn_tab(i).allocate (NYval);
      
      SDp_try_tab(i).allocate (ZYval);
      SDn_try_tab(i).allocate (NYval);
      
      Cp_out_tab(i).allocate (ZYval);
      Cn_out_tab(i).allocate (NYval);
      
      Cp_try_tab(i).allocate (ZYval);
      Cn_try_tab(i).allocate (NYval);
    }
  
  double Re_Op_amplitude_part = 0.0;
  double Im_Op_amplitude_part = 0.0;

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) reduction(+:Re_Op_amplitude_part , Im_Op_amplitude_part)
#endif
  for (int n_in = 0 ; n_in < NYval_IN ; n_in++)
    {
      const unsigned int state_n_in = inSDn[n_in];

      const unsigned i_thread = OpenMP_thread_number_determine ();
      
      class Slater_determinant &outSDn = outSDn_tab(i_thread);
      
      unsigned int bin_phase_n = reordering_bin_phase_n;

      inSDn.excitation_1h_and_bin_phase (state_n_in , outSDn , bin_phase_n);

      const class nljm_struct &phi_n_in = phi_n_table(state_n_in);
      
      const double mn_in = phi_n_in.get_m ();
      
      const double Mn_out = Mn_in - mn_in;
      
      const int ijn_in = phi_n_in.get_ij ();

      const int ln_in = phi_n_in.get_l ();

      const int iMn_out = make_int (Mn_out + Mn_max);
      
      const unsigned int bp_n_in = binary_parity_from_orbital_angular_momentum (ln_in);

      const unsigned int BPn_out = binary_parity_product (BPn_in  , bp_n_in);
      const unsigned int BPp_out = binary_parity_product (BPn_out , BP_OUT);
            
      const int en_trunc_in = phi_n_in.get_e_trunc ();
      
      const int En_out_hw = En_in_hw - en_trunc_in;
      
      const bool core_state_n_in = phi_n_in.get_core_state ();

      const int n_holes_n_out = (core_state_n_in) ? (n_holes_n_in + 1) : (n_holes_n_in);
            
      const bool S_matrix_pole_n_in = phi_n_in.get_S_matrix_pole ();
            
      const int scat_n_in = (S_matrix_pole_n_in) ? (0) : (1);
      
      const int n_scat_n_out = n_scat_n_in - scat_n_in;

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
	
      class configuration &Cn_out = Cn_out_tab(i_thread);
      class configuration &Cn_try = Cn_try_tab(i_thread);
			  
      Cn_out.get_SD_configuration (phi_n_table , outSDn);

      class Slater_determinant &SDn_try = SDn_try_tab(i_thread);
			  
      const unsigned int iCn_out = Cn_out.index_search (BPn_out , 0 , 0 , n_scat_n_out , dimensions_configuration_n_set , configuration_n_set , Cn_try);

      const unsigned int outSDn_index = outSDn.index_search (BPn_out , 0 , 0 , n_scat_n_out , iCn_out , iMn_out , dimensions_SDn_set , SDn_set , SDn_try);

      const double mp_out = mn_in + rank_Op_projection;

      const double Mp_out = Mp_in + mp_out;

      const int iMp_out = make_int (Mp_out + Mp_max);

      const int abs_mp_out_minus_half = make_int (abs (mp_out) - 0.5);

      for (unsigned int sp_out = 0 ; sp_out < Np_nlj ; sp_out++)
	{
	  const class nlj_struct &shell_p_out = shells_qn_p(sp_out);

	  const bool frozen_state_p_out = shell_p_out.get_frozen_state ();

	  if (frozen_state_p_out) continue;
		      
	  const enum particle_type particle_p_out = shell_p_out.get_particle ();
	  
	  const int np_out = shell_p_out.get_n ();
	  const int lp_out = shell_p_out.get_l ();

	  const double jp_out = shell_p_out.get_j ();

	  const int ijp_out = shell_p_out.get_ij ();
	      
	  const unsigned int bp_p_out = binary_parity_from_orbital_angular_momentum (lp_out);
	      
	  const unsigned int BPp_out_sp_out = binary_parity_product (BPp_in , bp_p_out);
	  
	  if ((BPp_out_sp_out == BPp_out) && (abs_mp_out_minus_half - ijp_out <= 0) && (abs (ijn_in - ijp_out) <= rank_Op) && (ijn_in + ijp_out + 1 >= rank_Op))
	    {
	      const unsigned int state_p_out = one_body_p_indices(particle_p_out , np_out , lp_out , jp_out , mp_out);

	      if (!inSDp.is_valence_state_occupied (state_p_out))
		{
		  const int ep_trunc_out = shell_p_out.get_e_trunc ();

		  const int Ep_out_hw = Ep_in_hw + ep_trunc_out;

		  const bool core_state_p_out = shell_p_out.get_core_state ();
		      
		  const int n_holes_p_out = (core_state_p_out) ? (n_holes_p_in - 1) : (n_holes_p_in);
		      
		  const bool S_matrix_pole_p_out = shell_p_out.get_S_matrix_pole ();
      
		  const int scat_p_out = (S_matrix_pole_p_out) ? (0) : (1);
		  
		  const int n_scat_p_out = n_scat_p_in + scat_p_out;

		  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
		      
		  if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_out_hw , n_holes_n_out , n_scat_n_out , En_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

		  class Slater_determinant &outSDp = outSDp_tab(i_thread);

		  class Slater_determinant &SDp_try = SDp_try_tab(i_thread);
			  
		  unsigned int bin_phase_p = reordering_bin_phase_p;

		  inSDp.excitation_1p_and_bin_phase (state_p_out , outSDp , bin_phase_p);

		  class configuration &Cp_out = Cp_out_tab(i_thread);

		  class configuration &Cp_try = Cp_try_tab(i_thread);

		  Cp_out.get_SD_configuration (phi_p_table , outSDp);

		  const unsigned int iCp_out = Cp_out.index_search (BPp_out , 0 , 0 , n_scat_p_out , dimensions_configuration_p_set , configuration_p_set , Cp_try);
			  
		  const unsigned int outSDp_index = outSDp.index_search (BPp_out , 0 , 0 , n_scat_p_out , iCp_out , iMp_out , dimensions_SDp_set , SDp_set , SDp_try);

		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_OUT(BPp_out , 0 , 0 , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);

		  const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , 0 , 0 , n_scat_n_out , iCn_out , iMn_out);

		  const unsigned int PSI_OUT_index = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index + outSDn_index;

		  const TYPE OBME = OBMEs(state_n_in , state_p_out);

		  const TYPE NBME = (bin_phase_p == bin_phase_n) ? (OBME) : (-OBME);

		  const TYPE PSI_OUT_component_times_NBME = PSI_OUT[PSI_OUT_index]*NBME;

		  Re_Op_amplitude_part += real_dc (PSI_OUT_component_times_NBME);
		  Im_Op_amplitude_part += imag_dc (PSI_OUT_component_times_NBME);
		}
	    }
	}
    }

  TYPE Op_amplitude_part = generate_scalar<TYPE> (Re_Op_amplitude_part , Im_Op_amplitude_part);

  Op_amplitude_part *= PSI_IN_component;

  return Op_amplitude_part;
}









TYPE beta_transitions_NBMEs::calc (
				   const enum beta_pm_type beta_pm , 
				   const enum beta_suboperator_type beta_suboperator , 
				   const class array<TYPE> &OBMEs , 
				   const class correlated_state_str &PSI_IN_qn , 
				   const class correlated_state_str &PSI_OUT_qn , 
				   const class GSM_vector &PSI_OUT)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();
  
  const unsigned int BP_Op = BP_beta_suboperator_determine (beta_suboperator);

  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  if (BP_OUT != binary_parity_product (BP_Op , BP_IN)) return 0.0;
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int ZYval_IN = Z_IN_beta_determine (beta_pm , ZYval);
  const int NYval_IN = N_IN_beta_determine (beta_pm , NYval);
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

  if (!is_it_triangle (J_IN , rank_Op , J_OUT)) return 0.0;
  
  const double M_IN = J_IN;

  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const int rank_Op_projection = make_int (M_OUT - M_IN);
  
  if (abs (rank_Op_projection) > rank_Op) return 0.0;
    
  const string file_name_IN = file_name_eigenvector_string (true , "eigenvector" , PSI_IN_qn , M_IN); 

  const string file_name_IN_dimension = file_name_eigenvector_string (true , "eigenvector_dimension" , PSI_IN_qn , M_IN);
  
  const unsigned int space_dimension_IN = space_dimension_read_disk (true , ZYval_IN , NYval_IN , file_name_IN_dimension);

  class array<unsigned int> inSDp_tab(space_dimension_IN , ZYval_IN);
  class array<unsigned int> inSDn_tab(space_dimension_IN , NYval_IN);
  
  class array<TYPE> PSI_IN_component_tab(space_dimension_IN);

  class array<bool> is_inSDp_in_new_space_tab(space_dimension_IN);
  class array<bool> is_inSDn_in_new_space_tab(space_dimension_IN);

  class array<unsigned char> reordering_bin_phases_p(space_dimension_IN);
  class array<unsigned char> reordering_bin_phases_n(space_dimension_IN);

  files_IN_tables_read_pn_one_baryon (true , ZYval_IN , NYval_IN , PSI_IN_qn , M_IN , prot_Y_data , neut_Y_data , inSDp_tab , inSDn_tab , 
				       PSI_IN_component_tab , is_inSDp_in_new_space_tab , is_inSDn_in_new_space_tab , reordering_bin_phases_p , reordering_bin_phases_n);

  class configuration Cp_in(ZYval_IN);
  class configuration Cn_in(NYval_IN);

  class Slater_determinant inSDp(ZYval_IN);
  class Slater_determinant inSDn(NYval_IN);

  TYPE Op_amplitude_partial = 0.0;

  const unsigned int first_index = basic_first_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_index = basic_last_index_determine_for_MPI (space_dimension_IN  , NUMBER_OF_PROCESSES , THIS_PROCESS);

  for (unsigned int i = 0 ; i < space_dimension_IN ; i++)
    {
      if ((i >= first_index) && (i <= last_index))
	{
	  if (!is_inSDp_in_new_space_tab(i) || !is_inSDn_in_new_space_tab(i)) continue;

	  for (int p = 0 ; p < ZYval_IN ; p++) inSDp[p] = inSDp_tab(i , p);
	  for (int n = 0 ; n < NYval_IN ; n++) inSDn[n] = inSDn_tab(i , n);
  
	  const unsigned int reordering_bin_phase_p = reordering_bin_phases_p(i);
	  const unsigned int reordering_bin_phase_n = reordering_bin_phases_n(i);

	  const TYPE PSI_IN_component = PSI_IN_component_tab(i);
		  
	  Cp_in.get_SD_configuration (phi_p_table , inSDp);
	  Cn_in.get_SD_configuration (phi_n_table , inSDn);
	      
	  switch (beta_pm)
	    {
	    case BETA_PLUS:
	      {
		Op_amplitude_partial += component_part_beta_plus_calc (rank_Op , rank_Op_projection , OBMEs , Cp_in , Cn_in , inSDp , inSDn , PSI_IN_component, reordering_bin_phase_p , reordering_bin_phase_n , PSI_OUT);
	      } break;
		    
	    case BETA_MINUS:
	      {
		Op_amplitude_partial += component_part_beta_minus_calc (rank_Op , rank_Op_projection , OBMEs , Cp_in , Cn_in , inSDp , inSDn , PSI_IN_component , reordering_bin_phase_p , reordering_bin_phase_n , PSI_OUT);
	      } break;

	    default: abort_all ();
	    }
	}
    }
      
  const TYPE Op_amplitude = sum_Reduce<TYPE> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , Op_amplitude_partial);

  const TYPE reduced_Op_amplitude = (THIS_PROCESS == MASTER_PROCESS) ? (ME_reduced (Op_amplitude , rank_Op , rank_Op_projection , J_IN , M_IN , J_OUT , M_OUT)) : (NADA);
  
  return reduced_Op_amplitude;
}




