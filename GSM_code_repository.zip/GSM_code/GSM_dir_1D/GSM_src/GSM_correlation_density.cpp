#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace correlation_density_TBMEs;
using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace configuration_SD_in_space_one_jump;


// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// See GSM_correlation_density_TBMEs.cpp for the calculation of TBMEs
// ------------------------------------------------------------------

// Calculation of the correlation density for one pair of many-body states <Psi[out] | rho(r/k , theta) | Psi[in]> or the correlation density of a fixed state |Psi> <Psi | rho(r/k , theta) | Psi>
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Angular correlation densities <Psi[out] | rho(theta) | Psi[in]> (integrated over all radii) are also calculated.
// Except that one calculates <Psi[out] | rho(r/k , theta) | Psi[in]> and <Psi[out] | rho(theta) | Psi[in]> for all values r/k and/or theta, routines are very similar to those of Hamiltonian.
// Parallelization is done on r/k only.
//
// Correlation densities involving hyperons are not considered. Indeed, hyperons cannot form clusters with any baryon as they are almost only present in 0s1/2 states.




void correlation_density::NBMEs_diagonal_pp_nn_part_calc (
							  const bool is_it_HO_expansion , 
							  const class interaction_class &inter_data , 
							  const class baryons_data &data , 
							  const class array<TYPE> &rk_OBMEs , 
							  const class array<double> &theta12_Dirac_multipolar_tab , 
							  const class lm_table<unsigned int> &lm_indices , 
							  const class ljm_table<unsigned int> &ljm_indices , 
							  const class array<double> &Ylm_table_coupled_to_l , 
							  const class array<double> &Ylm_table_coupled_to_j , 
							  const class array<double> &CGs , 
							  const class Slater_determinant &SD , 
							  class array<TYPE> &angular_densities_TBMEs ,
							  class array<TYPE> &density_TBMEs ,
							  class array<TYPE> &angular_densities_NBMEs , 
							  class array<TYPE> &density_NBMEs)
{
  const int N_valence_baryons = SD.get_N_valence_baryons ();

  for (int i = 0 ; i < N_valence_baryons ; i++)
    {
      const unsigned int state_i = SD[i];

      for (int ii = 0 ; ii < N_valence_baryons ; ii++)
	{
	  const unsigned int state_ii = SD[ii];

	  if (state_i < state_ii)
	    {
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , state_i , state_ii , state_i , state_ii , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

	      angular_densities_NBMEs += angular_densities_TBMEs;
	      
	      density_NBMEs += density_TBMEs;
	    }
	}
    } 
}






void correlation_density::NBMEs_diagonal_pn_part_calc (
						       const bool is_it_HO_expansion , 
						       const class interaction_class &inter_data , 
						       const class baryons_data &prot_Y_data , 
						       const class baryons_data &neut_Y_data , 
						       const class array<TYPE> &rk_OBMEs_p , 
						       const class array<TYPE> &rk_OBMEs_n ,
						       const class array<double> &theta12_Dirac_multipolar_tab , 
						       const class lm_table<unsigned int> &lm_indices , 
						       const class ljm_table<unsigned int> &ljm_indices , 
						       const class array<double> &Ylm_table_coupled_to_l , 
						       const class array<double> &Ylm_table_coupled_to_j , 
						       const class array<double> &CGs , 
						       const class Slater_determinant &SDp , 
						       const class Slater_determinant &SDn , 
						       class array<TYPE> &angular_densities_TBMEs_pn , 
						       class array<TYPE> &density_TBMEs_pn , 
						       class array<TYPE> &angular_densities_NBMEs , 
						       class array<TYPE> &density_NBMEs)
{
  const int ZYval = SDp.get_N_valence_baryons ();
  const int NYval = SDn.get_N_valence_baryons ();

  for (int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      for (int n = 0 ; n < NYval ; n++)
	{
	  const unsigned int state_n = SDn[n];

	  uncoupled_TBMEs_pn_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , state_p , state_n , state_p , state_n , 
				   theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs_pn , density_TBMEs_pn);

	  angular_densities_NBMEs += angular_densities_TBMEs_pn;
	  
	  density_NBMEs += density_TBMEs_pn;
	}
    }
}






void correlation_density::diagonal_part_pn_prot_part_pn_calc (	
							      const bool is_it_HO_expansion , 
							      const class interaction_class &inter_data , 								
							      const class array<TYPE> &rk_OBMEs_p , 
							      const class array<double> &theta12_Dirac_multipolar_tab , 
							      const class lm_table<unsigned int> &lm_indices , 
							      const class ljm_table<unsigned int> &ljm_indices , 
							      const class array<double> &Ylm_table_coupled_to_l , 
							      const class array<double> &Ylm_table_coupled_to_j , 
							      const class array<double> &CGs , 
							      const class GSM_vector &PSI_IN ,
							      const class GSM_vector &PSI_OUT , 
							      class array<TYPE> &angular_densities_tab , 
							      class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();

  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();

  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();

  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
  
  const unsigned int first_PSI_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper_OUT.get_last_PSI_index ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper_OUT.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper_OUT.get_iCn_max_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
   
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);
	        
  class array<class array<TYPE> > PSI_components_TRS_factor_product_density_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      
      angular_densities_TBMEs_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_tab(i).allocate (2 , theta_number);
      
      density_TBMEs_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
  
      PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);
      
      PSI_components_TRS_factor_product_density_NBMEs_tab(i).allocate (N_RKmax , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;
      density_part_tabs(i) = 0.0;	  
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SD_quantum_numbers_prot_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = Strangeness - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;

      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
		  
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;
	      
      const unsigned int SDp_index = SDp_qn.get_SD_index ();
        
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs = angular_densities_NBMEs_tab(i_thread);

      class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
      class array<TYPE> &density_NBMEs = density_NBMEs_tab(i_thread);      
      
      class array<TYPE> &PSI_components_TRS_factor_product_angular_densities_NBMEs = PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i_thread);
      
      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);
      
      class array<TYPE> &PSI_components_TRS_factor_product_density_NBMEs = PSI_components_TRS_factor_product_density_NBMEs_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);     

      bool are_NBMEs_calculated = false;
				       
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      angular_densities_NBMEs = 0.0;

      density_NBMEs = 0.0;
			  
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
				      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
					  
	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDn_minus_one;

	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);
				      
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
					      
		  if (!are_NBMEs_calculated)
		    {
		      NBMEs_diagonal_pp_nn_part_calc (is_it_HO_expansion , inter_data , prot_Y_data , rk_OBMEs_p , theta12_Dirac_multipolar_tab , 
						      lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , SDp ,
						      angular_densities_TBMEs , density_TBMEs , angular_densities_NBMEs , density_NBMEs);

		      are_NBMEs_calculated = true;
		    }
					  
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {
		      const unsigned int PSI_index = PSI_index_zero + SDn_index;
					  
		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + SDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const TYPE &PSI_IN_component = PSI_IN[PSI_index];
				  
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];
						  
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_index == PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
				  
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;

			      PSI_components_TRS_factor_product_angular_densities_NBMEs = angular_densities_NBMEs;
			      PSI_components_TRS_factor_product_angular_densities_NBMEs *= PSI_components_TRS_factor_product;

			      angular_densities_part_tab += PSI_components_TRS_factor_product_angular_densities_NBMEs;

			      PSI_components_TRS_factor_product_density_NBMEs = density_NBMEs;
			      PSI_components_TRS_factor_product_density_NBMEs *= PSI_components_TRS_factor_product;

			      density_part_tab += PSI_components_TRS_factor_product_density_NBMEs;
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}






void correlation_density::diagonal_part_pn_neut_part_pn_calc (			
							      const bool is_it_HO_expansion , 
							      const class interaction_class &inter_data , 						
							      const class array<TYPE> &rk_OBMEs_n , 
							      const class array<double> &theta12_Dirac_multipolar_tab , 
							      const class lm_table<unsigned int> &lm_indices , 
							      const class ljm_table<unsigned int> &ljm_indices , 
							      const class array<double> &Ylm_table_coupled_to_l , 
							      const class array<double> &Ylm_table_coupled_to_j , 
							      const class array<double> &CGs , 
							      const class GSM_vector &PSI_IN , 
							      const class GSM_vector &PSI_OUT , 
							      class array<TYPE> &angular_densities_tab , 
							      class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();

  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper_OUT.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper_OUT.get_iCp_max_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
    
  const unsigned int first_PSI_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);	      
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_density_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (NYval);
      
      angular_densities_TBMEs_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      density_TBMEs_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_tab(i).allocate (N_RKmax , theta_number);  
  
      PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);	      

      PSI_components_TRS_factor_product_density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
      
      density_part_tabs(i).allocate (N_RKmax , theta_number);

      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;	  
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SD_quantum_numbers_neut_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = Strangeness - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
        
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
	      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
		  
      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs = angular_densities_NBMEs_tab(i_thread);

      class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
      class array<TYPE> &density_NBMEs = density_NBMEs_tab(i_thread);  
      
      class array<TYPE> &PSI_components_TRS_factor_product_angular_densities_NBMEs = PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i_thread);
      
      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);	      

      class array<TYPE> &PSI_components_TRS_factor_product_density_NBMEs = PSI_components_TRS_factor_product_density_NBMEs_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
			      
      bool are_NBMEs_calculated = false;

      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      angular_densities_NBMEs = 0.0;

      density_NBMEs = 0.0;
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);

	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
				      
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
		
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;
				  
	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;
				  
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);				  
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDn*dimension_SDp_minus_one;
  
	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
		      
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  if (!are_NBMEs_calculated)
		    {
		      NBMEs_diagonal_pp_nn_part_calc (is_it_HO_expansion , inter_data , neut_Y_data , rk_OBMEs_n , theta12_Dirac_multipolar_tab , 
						      lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , SDn ,
						      angular_densities_TBMEs , density_TBMEs , angular_densities_NBMEs , density_NBMEs);
			      
		      are_NBMEs_calculated = true;
		    }
					  
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned int PSI_index = PSI_index_zero + dimension_SDn*SDp_index;
					  
		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + SDp_TRS_index*dimension_SDn) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const TYPE &PSI_IN_component = PSI_IN[PSI_index];

			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];
						  
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_index == PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;

			      PSI_components_TRS_factor_product_angular_densities_NBMEs = angular_densities_NBMEs;
			      PSI_components_TRS_factor_product_angular_densities_NBMEs *= PSI_components_TRS_factor_product;

			      angular_densities_part_tab += PSI_components_TRS_factor_product_angular_densities_NBMEs;

			      PSI_components_TRS_factor_product_density_NBMEs = density_NBMEs;
			      PSI_components_TRS_factor_product_density_NBMEs *= PSI_components_TRS_factor_product;

			      density_part_tab += PSI_components_TRS_factor_product_density_NBMEs;
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}














void correlation_density::diagonal_part_pn_part_pn_Nval_larger_calc (
									  const bool is_it_HO_expansion , 
									  const class interaction_class &inter_data , 
									  const class array<TYPE> &rk_OBMEs_p , 
									  const class array<TYPE> &rk_OBMEs_n , 
									  const class array<double> &theta12_Dirac_multipolar_tab , 
									  const class lm_table<unsigned int> &lm_indices , 
									  const class ljm_table<unsigned int> &ljm_indices , 
									  const class array<double> &Ylm_table_coupled_to_l , 
									  const class array<double> &Ylm_table_coupled_to_j , 
									  const class array<double> &CGs , 
									  const class GSM_vector &PSI_IN ,
									  const class GSM_vector &PSI_OUT ,
									  class array<TYPE> &angular_densities_tab , 
									  class array<TYPE> &density_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();
    
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab (); 

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
   
  const unsigned int first_PSI_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper_OUT.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper_OUT.get_iCp_max_tab ();

  const unsigned long int total_SDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
    
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);	      
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_density_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
      
      angular_densities_TBMEs_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_tab(i).allocate (2 , theta_number);
      
      density_TBMEs_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
  
      PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);	      
      
      PSI_components_TRS_factor_product_density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
      
      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;	
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SD_quantum_numbers_neut_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();
      
      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();
      
      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = Strangeness - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
      
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
		  
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
      
      class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs = angular_densities_NBMEs_tab(i_thread);

      class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
      class array<TYPE> &density_NBMEs = density_NBMEs_tab(i_thread);      
      
      class array<TYPE> &PSI_components_TRS_factor_product_angular_densities_NBMEs = PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i_thread);
      
      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);	  

      class array<TYPE> &PSI_components_TRS_factor_product_density_NBMEs = PSI_components_TRS_factor_product_density_NBMEs_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
      
      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p = 0 ; n_scat_p <= n_scat_max_p ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);
			  
	  for (unsigned int iCp = iCp_min ; iCp <= iCp_max ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
	      
	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);

	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + SDn_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDp_minus_one*dimension_SDn;
  
	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + SDn_TRS_index) : (NADA);
		  
		  const unsigned long int total_SDp_index_zero = SDp_set.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0);
      
		  for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
		    {
		      const unsigned int PSI_index = PSI_index_zero + SDp_index*dimension_SDn;

		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDp_index = total_SDp_index_zero  + SDp_index;
      
			  SDp = SDp_set[total_SDp_index];
      
			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + dimension_SDn*SDp_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const TYPE &PSI_IN_component = PSI_IN[PSI_index];

			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];						  
			      
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_index == PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);  
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;

			      angular_densities_NBMEs = 0.0;

			      density_NBMEs = 0.0;

			      NBMEs_diagonal_pn_part_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , 
							   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , SDp , SDn ,
							   angular_densities_TBMEs , density_TBMEs , angular_densities_NBMEs , density_NBMEs);

			      PSI_components_TRS_factor_product_angular_densities_NBMEs = angular_densities_NBMEs;
			      PSI_components_TRS_factor_product_angular_densities_NBMEs *= PSI_components_TRS_factor_product;

			      angular_densities_part_tab += PSI_components_TRS_factor_product_angular_densities_NBMEs;

			      PSI_components_TRS_factor_product_density_NBMEs = density_NBMEs;
			      PSI_components_TRS_factor_product_density_NBMEs *= PSI_components_TRS_factor_product;

			      density_part_tab += PSI_components_TRS_factor_product_density_NBMEs;
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}
























void correlation_density::diagonal_part_pn_part_pn_Zval_larger_calc (
									  const bool is_it_HO_expansion , 
									  const class interaction_class &inter_data , 
									  const class array<TYPE> &rk_OBMEs_p , 
									  const class array<TYPE> &rk_OBMEs_n , 
									  const class array<double> &theta12_Dirac_multipolar_tab , 
									  const class lm_table<unsigned int> &lm_indices , 
									  const class ljm_table<unsigned int> &ljm_indices , 
									  const class array<double> &Ylm_table_coupled_to_l , 
									  const class array<double> &Ylm_table_coupled_to_j , 
									  const class array<double> &CGs , 
									  const class GSM_vector &PSI_IN ,
									  const class GSM_vector &PSI_OUT ,
									  class array<TYPE> &angular_densities_tab , 
									  class array<TYPE> &density_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_OUT.get_iM (); 

  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M (); 

  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
      
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();  
    
  const unsigned int first_PSI_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper_OUT.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper_OUT.get_iCn_max_tab ();
  
  const unsigned long int total_SDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
    
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
 
  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_tab(NUMBER_OF_THREADS);  
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);	      

  class array<class array<TYPE> > PSI_components_TRS_factor_product_density_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      SDn_tab(i).allocate (NYval);
      
      angular_densities_TBMEs_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      density_TBMEs_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_tab(i).allocate (N_RKmax , theta_number);  

      PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i).allocate (2 , theta_number);
      
      angular_densities_part_tabs(i).allocate (2 , theta_number);	      

      PSI_components_TRS_factor_product_density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
      
      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;	
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SD_quantum_numbers_prot_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = Strangeness - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;
	
      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);

      const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
      class Slater_determinant &SDp = SDp_tab(i_thread);
      class Slater_determinant &SDn = SDn_tab(i_thread);
	  
      class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs = angular_densities_NBMEs_tab(i_thread);

      class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
      class array<TYPE> &density_NBMEs = density_NBMEs_tab(i_thread);      
      
      class array<TYPE> &PSI_components_TRS_factor_product_angular_densities_NBMEs = PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i_thread);
      
      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

      class array<TYPE> &PSI_components_TRS_factor_product_density_NBMEs = PSI_components_TRS_factor_product_density_NBMEs_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
      
      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n = 0 ; n_scat_n <= n_scat_max_n ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; iCn <= iCn_max ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);
	      
	      if (dimension_SDn == 0) continue;

	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , iMp);
				  
	      const unsigned int PSI_index_zero = sum_dimensions_configuration_Mp_Mn_fixed + dimension_SDn*SDp_index;

	      const unsigned int PSI_index_dimension_minus_one = PSI_index_zero + dimension_SDn_minus_one;
  
	      if ((PSI_index_zero <= last_PSI_index) && (PSI_index_dimension_minus_one >= first_PSI_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n , iCp , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS + dimension_SDn*SDp_TRS_index) : (NADA);

		  const unsigned long int total_SDn_index_zero = SDn_set.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0);
      
		  for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
		    {		    			  
		      const unsigned int PSI_index = PSI_index_zero + SDn_index;

		      if ((PSI_index >= first_PSI_index) && (PSI_index <= last_PSI_index))
			{
			  const unsigned long int total_SDn_index = total_SDn_index_zero  + SDn_index;
      
			  SDn = SDn_set[total_SDn_index];
		      
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_index = (is_it_TRS) ? (TRS_PSI_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
			    {
			      const TYPE &PSI_IN_component = PSI_IN[PSI_index];

			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];						  
			      
			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_index == PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			      
			      const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;
			      
			      angular_densities_NBMEs = 0.0;

			      density_NBMEs = 0.0;

			      NBMEs_diagonal_pn_part_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , 
							   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , SDp , SDn ,
							   angular_densities_TBMEs , density_TBMEs , angular_densities_NBMEs , density_NBMEs);

			      PSI_components_TRS_factor_product_angular_densities_NBMEs = angular_densities_NBMEs;
			      PSI_components_TRS_factor_product_angular_densities_NBMEs *= PSI_components_TRS_factor_product;

			      angular_densities_part_tab += PSI_components_TRS_factor_product_angular_densities_NBMEs;

			      PSI_components_TRS_factor_product_density_NBMEs = density_NBMEs;
			      PSI_components_TRS_factor_product_density_NBMEs *= PSI_components_TRS_factor_product;

			      density_part_tab += PSI_components_TRS_factor_product_density_NBMEs;
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}
			   








void correlation_density::NBMEs_one_jump_mu_no_phase_calc (
							   const bool is_it_HO_expansion , 
							   const class interaction_class &inter_data , 
							   const unsigned int out_jump , 
							   const unsigned int in_jump , 
							   const class Slater_determinant &outSD , 
							   const class baryons_data &data , 
							   const class array<TYPE> &rk_OBMEs , 
							   const class array<double> &theta12_Dirac_multipolar_tab , 
							   const class lm_table<unsigned int> &lm_indices , 
							   const class ljm_table<unsigned int> &ljm_indices , 
							   const class array<double> &Ylm_table_coupled_to_l , 
							   const class array<double> &Ylm_table_coupled_to_j , 
							   const class array<double> &CGs , 
							   class array<TYPE> &angular_densities_TBMEs , 
							   class array<TYPE> &density_TBMEs , 
							   class array<TYPE> &angular_densities_NBMEs_no_phase_fixed_inSD , 
							   class array<TYPE> &density_NBMEs_no_phase_fixed_inSD)
{
  const int N_valence_baryons = data.get_N_valence_baryons ();

  angular_densities_NBMEs_no_phase_fixed_inSD = 0.0;

  density_NBMEs_no_phase_fixed_inSD = 0.0;

  for (int i_nucl = 0 ; i_nucl < N_valence_baryons ; i_nucl++)
    {
      const unsigned int idem = outSD[i_nucl];

      if ((idem != in_jump) && (idem != out_jump))
	{
	  const bool is_in_ordered  = (in_jump  < idem);
	  const bool is_out_ordered = (out_jump < idem);

	  if (is_in_ordered && is_out_ordered) 
	    {
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , in_jump , idem , out_jump , idem , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

	      angular_densities_NBMEs_no_phase_fixed_inSD += angular_densities_TBMEs;
	      
	      density_NBMEs_no_phase_fixed_inSD += density_TBMEs;
	    }
	  else if (!is_in_ordered && is_out_ordered) 
	    {
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , idem , in_jump , out_jump , idem , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

	      angular_densities_NBMEs_no_phase_fixed_inSD -= angular_densities_TBMEs;

	      density_NBMEs_no_phase_fixed_inSD -= density_TBMEs;
	    }
	  else if (is_in_ordered && !is_out_ordered) 
	    {
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , in_jump , idem , idem , out_jump , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

	      angular_densities_NBMEs_no_phase_fixed_inSD -= angular_densities_TBMEs;

	      density_NBMEs_no_phase_fixed_inSD -= density_TBMEs;
	    }
	  else if (!is_in_ordered && !is_out_ordered) 
	    {
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , idem , in_jump , idem , out_jump , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

	      angular_densities_NBMEs_no_phase_fixed_inSD += angular_densities_TBMEs;

	      density_NBMEs_no_phase_fixed_inSD += density_TBMEs;
	    }
	}
    }
}




void correlation_density::NBMEs_pn_no_phase_one_jump_p_calc (
							     const bool is_it_HO_expansion , 
							     const class interaction_class &inter_data , 
							     const unsigned int p_in , 
							     const unsigned int p_out , 
							     const class Slater_determinant &SDn , 
							     const class baryons_data &prot_Y_data , 
							     const class baryons_data &neut_Y_data , 
							     const class array<TYPE> &rk_OBMEs_p , 
							     const class array<TYPE> &rk_OBMEs_n , 
							     const class array<double> &theta12_Dirac_multipolar_tab , 
							     const class lm_table<unsigned int> &lm_indices , 
							     const class ljm_table<unsigned int> &ljm_indices , 
							     const class array<double> &Ylm_table_coupled_to_l , 
							     const class array<double> &Ylm_table_coupled_to_j , 
							     const class array<double> &CGs , 
							     class array<TYPE> &angular_densities_NBMEs_pn_no_phase_fixed_pair , 
							     class array<TYPE> &density_NBMEs_pn_no_phase_fixed_pair)
{
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const unsigned int N_RKmax = density_NBMEs_pn_no_phase_fixed_pair.dimension (0);

  const unsigned int theta_number = density_NBMEs_pn_no_phase_fixed_pair.dimension (1);
  
  class array<TYPE> angular_densities_TBMEs(2 , theta_number);

  class array<TYPE> density_TBMEs(N_RKmax , theta_number);

  angular_densities_NBMEs_pn_no_phase_fixed_pair = 0.0;

  density_NBMEs_pn_no_phase_fixed_pair = 0.0;

  for (int n = 0 ; n < NYval ; n++)
    {
      const unsigned int state_n = SDn[n];

      uncoupled_TBMEs_pn_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , p_out , state_n , p_in , state_n , theta12_Dirac_multipolar_tab , 
			       lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

      angular_densities_NBMEs_pn_no_phase_fixed_pair += angular_densities_TBMEs;

      density_NBMEs_pn_no_phase_fixed_pair += density_TBMEs;
    }
}




void correlation_density::NBMEs_pn_no_phase_one_jump_n_calc (
							     const bool is_it_HO_expansion , 
							     const class interaction_class &inter_data , 
							     const unsigned int n_in , 
							     const unsigned int n_out , 
							     const class Slater_determinant &SDp , 
							     const class baryons_data &prot_Y_data , 
							     const class baryons_data &neut_Y_data , 
							     const class array<TYPE> &rk_OBMEs_p , 
							     const class array<TYPE> &rk_OBMEs_n , 
							     const class array<double> &theta12_Dirac_multipolar_tab , 
							     const class lm_table<unsigned int> &lm_indices , 
							     const class ljm_table<unsigned int> &ljm_indices , 
							     const class array<double> &Ylm_table_coupled_to_l , 
							     const class array<double> &Ylm_table_coupled_to_j , 
							     const class array<double> &CGs , 
							     class array<TYPE> &angular_densities_NBMEs_no_phase_fixed_pair , 
							     class array<TYPE> &density_NBMEs_no_phase_fixed_pair)
{
  const int ZYval = prot_Y_data.get_N_valence_baryons ();

  const unsigned int N_RKmax = density_NBMEs_no_phase_fixed_pair.dimension (0);

  const unsigned int theta_number = density_NBMEs_no_phase_fixed_pair.dimension (1);
  
  class array<TYPE> angular_densities_TBMEs(2 , theta_number);

  class array<TYPE> density_TBMEs(N_RKmax , theta_number);

  angular_densities_NBMEs_no_phase_fixed_pair = 0.0;

  density_NBMEs_no_phase_fixed_pair = 0.0;

  for (int p = 0 ; p < ZYval ; p++)
    {
      const unsigned int state_p = SDp[p];

      uncoupled_TBMEs_pn_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , state_p , n_out , state_p , n_in , theta12_Dirac_multipolar_tab , 
			       lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

      angular_densities_NBMEs_no_phase_fixed_pair += angular_densities_TBMEs;

      density_NBMEs_no_phase_fixed_pair += density_TBMEs;
    }
}





void correlation_density::NBMEs_jumps_pp_nn_calc_store (
							const bool is_it_HO_expansion , 
							const class interaction_class &inter_data , 
							const int n_holes_max_mu , 
							const int n_scat_max_mu , 
							const int Emu_max_hw , 
							const unsigned int BPmu ,
							const int Smu , 
							const int n_spec_mu , 
							const int iMmu , 
							const int n_scat_mu_out , 
							const unsigned int iCmu_out , 
							const unsigned int outSDmu_index , 
							const class Slater_determinant &outSDmu , 
							const class baryons_data &data , 
							const class array<TYPE> &rk_OBMEs , 
							const class array<double> &theta12_Dirac_multipolar_tab , 
							const class lm_table<unsigned int> &lm_indices , 
							const class ljm_table<unsigned int> &ljm_indices , 
							const class array<double> &Ylm_table_coupled_to_l , 
							const class array<double> &Ylm_table_coupled_to_j , 
							const class array<double> &CGs , 
							bool &is_there_one_jump_calc , 
							bool &are_there_two_jumps_calc , 
							class jumps_data_str &one_jump_mu , 
							class jumps_data_str &two_jumps_mu , 
							class array<TYPE> &angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD , 
							class array<TYPE> &angular_densities_NBMEs_one_jump_mu , 
							class array<TYPE> &angular_densities_TBMEs_mu , 
							class array<TYPE> &angular_densities_NBMEs_two_jumps_mu , 
							class array<TYPE> &density_NBMEs_one_jump_mu_no_phase_fixed_inSD , 
							class array<TYPE> &density_NBMEs_one_jump_mu , 
							class array<TYPE> &density_TBMEs_mu , 
							class array<TYPE> &density_NBMEs_two_jumps_mu)
{
  const int N_valence_baryons = data.get_N_valence_baryons ();
    
  const unsigned int N_RKmax = density_TBMEs_mu.dimension (0);

  const unsigned int theta_number = density_TBMEs_mu.dimension (1);

  is_there_one_jump_calc = false;

  are_there_two_jumps_calc = false;

  one_jump_mu.one_jump_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , data);

  const unsigned int dimension_one_jump_mu = one_jump_mu.get_dimension ();

  if (dimension_one_jump_mu > 0)
    {     
      for (unsigned int ii = 0 ; ii < dimension_one_jump_mu ; ii++)
	{ 
	  const class jumps_data_inSD_str &one_jump_mu_inSD = one_jump_mu(ii);

	  const unsigned int mu_in  = one_jump_mu_inSD.get_mu_in ();
	  const unsigned int mu_out = one_jump_mu_inSD.get_mu_out ();

	  const unsigned int total_bin_phase_mu = one_jump_mu_inSD.get_total_bin_phase ();

	  const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	  NBMEs_one_jump_mu_no_phase_calc (is_it_HO_expansion , inter_data , mu_out , mu_in , outSDmu , data , rk_OBMEs ,
					   theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
					   angular_densities_TBMEs_mu , density_TBMEs_mu , angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD , density_NBMEs_one_jump_mu_no_phase_fixed_inSD);

	  for (int S = 0 ; S <= 1 ; S++)
	    for (unsigned int it = 0 ; it < theta_number ; it++)
	      {
		const TYPE angular_densities_NBME_one_jump_mu_no_phase = angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD(S , it);

		angular_densities_NBMEs_one_jump_mu(S , it , ii) = (total_phase_mu == 1) ? (angular_densities_NBME_one_jump_mu_no_phase) : (-angular_densities_NBME_one_jump_mu_no_phase);
	      }

	  for (unsigned int i = 0 ; i < N_RKmax ; i++)
	    for (unsigned int it = 0 ; it < theta_number ; it++)
	      {
		const TYPE density_NBME_one_jump_mu_no_phase = density_NBMEs_one_jump_mu_no_phase_fixed_inSD(i , it);

		density_NBMEs_one_jump_mu(i , it , ii) = (total_phase_mu == 1) ? (density_NBME_one_jump_mu_no_phase) : (-density_NBME_one_jump_mu_no_phase);
	      }
	}

      is_there_one_jump_calc = true;
    }

  if (N_valence_baryons >= 2)
    {
      two_jumps_mu.two_jumps_mu_store (BPmu , Smu , n_spec_mu , iMmu , n_holes_max_mu , n_scat_max_mu , Emu_max_hw , BPmu , Smu , n_spec_mu , n_scat_mu_out , iCmu_out , iMmu , outSDmu_index , false , false , data);

      const unsigned int dimension_two_jumps_mu = two_jumps_mu.get_dimension ();

      if (dimension_two_jumps_mu > 0)
	{    
	  for (unsigned int ii = 0 ; ii < dimension_two_jumps_mu ; ii++)
	    { 
	      const class jumps_data_inSD_str &two_jumps_mu_inSD = two_jumps_mu(ii);

	      const unsigned int mu_left_in  = two_jumps_mu_inSD.get_left_in ();
	      const unsigned int mu_left_out = two_jumps_mu_inSD.get_left_out ();
	      
	      const unsigned int mu_right_in  = two_jumps_mu_inSD.get_right_in ();	      
	      const unsigned int mu_right_out = two_jumps_mu_inSD.get_right_out ();
	      
	      const unsigned int total_bin_phase_mu = two_jumps_mu_inSD.get_total_bin_phase ();

	      const int total_phase_mu = parity_from_binary_parity (total_bin_phase_mu);
	      
	      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , mu_left_in , mu_right_in , mu_left_out , mu_right_out , theta12_Dirac_multipolar_tab , 
					  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs_mu , density_TBMEs_mu);

	      for (int S = 0 ; S <= 1 ; S++)
		for (unsigned int it = 0 ; it < theta_number ; it++)
		  {
		    const TYPE angular_densities_TBME_mu = angular_densities_TBMEs_mu(S , it);

		    angular_densities_NBMEs_two_jumps_mu(S , it , ii) = (total_phase_mu == 1) ? (angular_densities_TBME_mu) : (-angular_densities_TBME_mu);
		  }

	      for (unsigned int i = 0 ; i < N_RKmax ; i++)
		for (unsigned int it = 0 ; it < theta_number ; it++)
		  {
		    const TYPE density_TBME_mu = density_TBMEs_mu(i , it);

		    density_NBMEs_two_jumps_mu(i , it , ii) = (total_phase_mu == 1) ? (density_TBME_mu) : (-density_TBME_mu);
		  }
	    }

	  are_there_two_jumps_calc = true;
	}
    }
}





void correlation_density::densities_part_calc (
					       const class jumps_data_str &jump , 
					       const class array<bool> &is_configuration_accepted_tab , 
					       const class array<unsigned int> &PSI_IN_indices , 
					       const class array<TYPE> &angular_densities_NBMEs_jump , 
					       const class array<TYPE> &density_NBMEs_jump , 
					       const TYPE &PSI_OUT_component_TRS_factor , 
					       const class GSM_vector &PSI_IN , 
					       class array<TYPE> &angular_densities_part_tab , 
					       class array<TYPE> &density_part_tab)
{
  const unsigned int N_RKmax = density_part_tab.dimension (0);

  const unsigned int theta_number = density_part_tab.dimension (1);
  
  for (int S = 0 ; S <= 1 ; S++) 
    for (unsigned int it = 0 ; it < theta_number ; it++)
      {
	TYPE component_part_angular_density = 0.0;

	const unsigned int dimension = jump.get_dimension ();

	for (unsigned int ii = 0 ; ii < dimension ; ii++)
	  {
	    if (is_configuration_accepted_tab(ii)) 
	      {
		const unsigned int PSI_IN_index = PSI_IN_indices(ii);

		const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
		
		component_part_angular_density += PSI_IN_component*angular_densities_NBMEs_jump(S , it , ii);
	      }
	  }

	angular_densities_part_tab(S , it) += PSI_OUT_component_TRS_factor*component_part_angular_density;
      }

  for (unsigned int i = 0 ; i < N_RKmax ; i++) 
    for (unsigned int it = 0 ; it < theta_number ; it++)
      {
	TYPE component_part_density = 0.0;

	const unsigned int dimension = jump.get_dimension ();

	for (unsigned int ii = 0 ; ii < dimension ; ii++)
	  {
	    if (is_configuration_accepted_tab(ii)) 
	      {
		const unsigned int PSI_IN_index = PSI_IN_indices(ii);

		const TYPE &PSI_IN_component = PSI_IN[PSI_IN_index];
		
		component_part_density += PSI_IN_component*density_NBMEs_jump(i , it , ii);
	      }
	  }

	density_part_tab(i , it) += PSI_OUT_component_TRS_factor*component_part_density;
      }
}






void correlation_density::jumps_p_prot_part_pn_calc (
						     const bool is_it_HO_expansion , 
						     const class interaction_class &inter_data , 
						     const class array<TYPE> &rk_OBMEs_p , 
						     const class array<double> &theta12_Dirac_multipolar_tab , 
						     const class lm_table<unsigned int> &lm_indices , 
						     const class ljm_table<unsigned int> &ljm_indices , 
						     const class array<double> &Ylm_table_coupled_to_l , 
						     const class array<double> &Ylm_table_coupled_to_j , 
						     const class array<double> &CGs , 
						     const class GSM_vector &PSI_IN ,  
						     const class GSM_vector &PSI_OUT , 
						     class array<TYPE> &angular_densities_tab , 
						     class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
    
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const unsigned int N_RKmax = density_tab.dimension (0);

  const int theta_number = density_tab.dimension (1);
    
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max  = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_pp_2p2h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set (); 

  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_min_tab = GSM_vector_helper_OUT.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_max_tab = GSM_vector_helper_OUT.get_iCn_max_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
    
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  class array<class Slater_determinant> outSDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_str> two_jumps_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_prot_one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_TBMEs_pp_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_prot_one_jump_p_tab(NUMBER_OF_THREADS);
	      
  class array<class array<TYPE> > density_TBMEs_pp_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > is_configuration_accepted_two_jumps_p_tabs(NUMBER_OF_THREADS);
	      
  class array<class array<unsigned int> > PSI_IN_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_IN_indices_two_jumps_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDp_tab(i).allocate (ZYval);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
	      
      angular_densities_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(i).allocate (2 , theta_number);
      
      angular_densities_NBMEs_prot_one_jump_p_tab(i).allocate (2 , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      density_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(i).allocate (N_RKmax , theta_number);

      density_NBMEs_prot_one_jump_p_tab(i).allocate (N_RKmax , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max);
	      
      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
	      
      PSI_IN_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      if (ZYval >= 2)
	{
	  two_jumps_p_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_pp_2p2h_space_BP_S_iM_fixed_max);

	  angular_densities_TBMEs_pp_tab(i).allocate (2 , theta_number);

	  angular_densities_NBMEs_two_jumps_p_tab(i).allocate (2 , theta_number , dimension_pp_2p2h_space_BP_S_iM_fixed_max);

	  density_TBMEs_pp_tab(i).allocate (N_RKmax , theta_number);
	  
	  density_NBMEs_two_jumps_p_tab(i).allocate (N_RKmax , theta_number , dimension_pp_2p2h_space_BP_S_iM_fixed_max);	  
      
	  is_configuration_accepted_two_jumps_p_tabs(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
      
	  PSI_IN_indices_two_jumps_p_tab(i).allocate (dimension_pp_2p2h_space_BP_S_iM_fixed_max);
	}
      
      angular_densities_part_tabs(i).allocate (2 , theta_number);
      
      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SD_quantum_numbers_prot_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = outSDp_qn.get_S ();

      const int Sn = Strangeness - Sp;
      
      const int n_spec_p = outSDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
      
      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &outSDp = outSDp_tab(i_thread);
      
      class jumps_data_str &one_jump_p = one_jump_p_tab(i_thread);
      
      class jumps_data_str &two_jumps_p = two_jumps_p_tab(i_thread);
      
      class array<TYPE> &angular_densities_NBMEs_prot_one_jump_p_no_phase_fixed_inSD = angular_densities_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(i_thread);

      class array<TYPE> &angular_densities_NBMEs_prot_one_jump_p = angular_densities_NBMEs_prot_one_jump_p_tab(i_thread);

      class array<TYPE> &angular_densities_TBMEs_pp = angular_densities_TBMEs_pp_tab(i_thread);
      
      class array<TYPE> &angular_densities_NBMEs_two_jumps_p = angular_densities_NBMEs_two_jumps_p_tab(i_thread);

      class array<TYPE> &density_NBMEs_prot_one_jump_p_no_phase_fixed_inSD = density_NBMEs_prot_one_jump_p_no_phase_fixed_inSD_tab(i_thread);
      class array<TYPE> &density_NBMEs_prot_one_jump_p = density_NBMEs_prot_one_jump_p_tab(i_thread);

      class array<TYPE> &density_TBMEs_pp = density_TBMEs_pp_tab(i_thread);
      
      class array<TYPE> &density_NBMEs_two_jumps_p = density_NBMEs_two_jumps_p_tab(i_thread);
      
      class array<bool> &is_configuration_accepted_one_jump_p_tab  = is_configuration_accepted_one_jump_p_tabs(i_thread);
      class array<bool> &is_configuration_accepted_two_jumps_p_tab = is_configuration_accepted_two_jumps_p_tabs(i_thread);
	      
      class array<unsigned int> &PSI_IN_indices_one_jump_p  = PSI_IN_indices_one_jump_p_tab(i_thread);
      class array<unsigned int> &PSI_IN_indices_two_jumps_p = PSI_IN_indices_two_jumps_p_tab(i_thread);

      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);
      
      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
      
      bool are_jumps_p_calculated = false;

      bool is_there_one_jump_calc_all = true;

      bool are_there_two_jumps_calc_all = true;

      outSDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index);

      for (int n_scat_n = 0 ; (n_scat_n <= n_scat_max_n) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_n++)
	{
	  const unsigned int iCn_min = iCn_min_tab(BPn , Sn , n_spec_n , n_scat_n);
	  const unsigned int iCn_max = iCn_max_tab(BPn , Sn , n_spec_n , n_scat_n);
			  
	  for (unsigned int iCn = iCn_min ; (iCn <= iCn_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCn++)
	    {
	      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
	      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

	      if (dimension_SDn == 0) continue;
				  
	      const unsigned int dimension_SDn_minus_one = dimension_SDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
				  
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_SDn*outSDp_index;

	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_SDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_SDn*outSDp_TRS_index) : (NADA);
				      
		  if (!are_jumps_p_calculated)
		    {
		      NBMEs_jumps_pp_nn_calc_store (is_it_HO_expansion , inter_data , n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						    BPp , Sp , n_spec_p , iMp , n_scat_p_out , iCp_out , outSDp_index , outSDp , prot_Y_data , 
						    rk_OBMEs_p , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
						    is_there_one_jump_calc_all , are_there_two_jumps_calc_all , one_jump_p , two_jumps_p , 
						    angular_densities_NBMEs_prot_one_jump_p_no_phase_fixed_inSD , angular_densities_NBMEs_prot_one_jump_p ,
						    angular_densities_TBMEs_pp , angular_densities_NBMEs_two_jumps_p , 
						    density_NBMEs_prot_one_jump_p_no_phase_fixed_inSD , density_NBMEs_prot_one_jump_p , density_TBMEs_pp , density_NBMEs_two_jumps_p);
		      
		      are_jumps_p_calculated = true;
		    }
				       
		  for (unsigned int SDn_index = 0 ; (SDn_index < dimension_SDn) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; SDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + SDn_index;

		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_SDn_TRS_indices_index = (is_it_TRS) ? (total_SDn_TRS_indices_zero_index + SDn_index) : (NADA);

			  const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_SDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + SDn_TRS_index) : (NADA);

			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

			      if (is_there_one_jump_calc_all)
				{
				  bool is_there_one_jump_calc = false;
						      
				  is_configuration_accepted_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , one_jump_p , GSM_vector_helper_IN ,
										   dimension_SDn , is_configuration_accepted_one_jump_p_tab , PSI_IN_indices_one_jump_p , is_there_one_jump_calc);

				  if (is_there_one_jump_calc)
				    densities_part_calc (one_jump_p , is_configuration_accepted_one_jump_p_tab , PSI_IN_indices_one_jump_p , 
							 angular_densities_NBMEs_prot_one_jump_p , density_NBMEs_prot_one_jump_p , 
							 PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
				}
				      
			      if (are_there_two_jumps_calc_all)
				{
				  bool are_there_two_jumps_calc = false;
				
				  is_configuration_accepted_PSI_in_indices_p_fill (BPn , Sn , n_spec_n , n_holes_n , n_scat_n , iCn , iMn , SDn_index , En_hw , two_jumps_p , GSM_vector_helper_IN ,
										   dimension_SDn , is_configuration_accepted_two_jumps_p_tab , PSI_IN_indices_two_jumps_p , are_there_two_jumps_calc);
				  
				  if (are_there_two_jumps_calc)
				    densities_part_calc (two_jumps_p , is_configuration_accepted_two_jumps_p_tab , PSI_IN_indices_two_jumps_p , 
							 angular_densities_NBMEs_two_jumps_p , density_NBMEs_two_jumps_p , 
							 PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}








void correlation_density::jumps_n_neut_part_pn_calc (
						     const bool is_it_HO_expansion , 
						     const class interaction_class &inter_data , 
						     const class array<TYPE> &rk_OBMEs_n , 
						     const class array<double> &theta12_Dirac_multipolar_tab , 
						     const class lm_table<unsigned int> &lm_indices , 
						     const class ljm_table<unsigned int> &ljm_indices , 
						     const class array<double> &Ylm_table_coupled_to_l , 
						     const class array<double> &Ylm_table_coupled_to_j , 
						     const class array<double> &CGs , 
						     const class GSM_vector &PSI_IN , 
						     const class GSM_vector &PSI_OUT , 
						     class array<TYPE> &angular_densities_tab , 
						     class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
    
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
    
  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p (); 
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();

  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();

  const int iMp_max = prot_Y_data.get_iM_max ();
      
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
  
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max  = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_nn_2p2h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_min_tab = GSM_vector_helper_OUT.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_max_tab = GSM_vector_helper_OUT.get_iCp_max_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();    

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  class array<class Slater_determinant> outSDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_str> two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_neut_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_TBMEs_nn_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_two_jumps_n_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_neut_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_TBMEs_nn_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);
  class array<class array<bool> > is_configuration_accepted_two_jumps_n_tabs(NUMBER_OF_THREADS);
	      
  class array<class array<unsigned int> > PSI_IN_indices_one_jump_n_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_IN_indices_two_jumps_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDn_tab(i).allocate (NYval);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      angular_densities_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(i).allocate (2 , theta_number);
      
      angular_densities_NBMEs_neut_one_jump_n_tab(i).allocate (2 , theta_number , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      density_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(i).allocate (N_RKmax , theta_number);

      density_NBMEs_neut_one_jump_n_tab(i).allocate (N_RKmax , theta_number , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      PSI_IN_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      if (NYval >= 2)
	{
	  two_jumps_n_tab(i).allocate (TWO_JUMPS , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_nn_2p2h_space_BP_S_iM_fixed_max);
      
	  angular_densities_NBMEs_two_jumps_n_tab(i).allocate (2 , theta_number , dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	  
	  angular_densities_TBMEs_nn_tab(i).allocate (2 , theta_number);

	  density_TBMEs_nn_tab(i).allocate (N_RKmax , theta_number);
	  
	  density_NBMEs_two_jumps_n_tab(i).allocate (N_RKmax , theta_number , dimension_nn_2p2h_space_BP_S_iM_fixed_max);

	  is_configuration_accepted_two_jumps_n_tabs(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	      
	  PSI_IN_indices_two_jumps_n_tab(i).allocate (dimension_nn_2p2h_space_BP_S_iM_fixed_max);
	}
      
      angular_densities_part_tabs(i).allocate (2 , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SD_quantum_numbers_neut_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = outSDn_qn.get_S ();

      const int Sp = Strangeness - Sn;
      
      const int n_spec_n = outSDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;

      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;

      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
		  		  
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class Slater_determinant &outSDn = outSDn_tab(i_thread);
      
      class jumps_data_str &one_jump_n = one_jump_n_tab(i_thread);

      class jumps_data_str &two_jumps_n = two_jumps_n_tab(i_thread);
      
      class array<TYPE> &angular_densities_NBMEs_neut_one_jump_n_no_phase_fixed_inSD = angular_densities_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(i_thread);

      class array<TYPE> &angular_densities_NBMEs_neut_one_jump_n = angular_densities_NBMEs_neut_one_jump_n_tab(i_thread);

      class array<TYPE> &angular_densities_TBMEs_nn = angular_densities_TBMEs_nn_tab(i_thread);
 
      class array<TYPE> &angular_densities_NBMEs_two_jumps_n = angular_densities_NBMEs_two_jumps_n_tab(i_thread);
      
      class array<TYPE> &density_NBMEs_neut_one_jump_n_no_phase_fixed_inSD = density_NBMEs_neut_one_jump_n_no_phase_fixed_inSD_tab(i_thread);
      class array<TYPE> &density_NBMEs_neut_one_jump_n = density_NBMEs_neut_one_jump_n_tab(i_thread);
	      
      class array<TYPE> &density_TBMEs_nn = density_TBMEs_nn_tab(i_thread);

      class array<TYPE> &density_NBMEs_two_jumps_n = density_NBMEs_two_jumps_n_tab(i_thread);
      
      class array<bool> &is_configuration_accepted_one_jump_n_tab  = is_configuration_accepted_one_jump_n_tabs(i_thread);
      class array<bool> &is_configuration_accepted_two_jumps_n_tab = is_configuration_accepted_two_jumps_n_tabs(i_thread);
	      
      class array<unsigned int> &PSI_IN_indices_one_jump_n  = PSI_IN_indices_one_jump_n_tab(i_thread);
      class array<unsigned int> &PSI_IN_indices_two_jumps_n = PSI_IN_indices_two_jumps_n_tab(i_thread);

      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);
      
      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);

      bool are_jumps_n_calculated = false;
      
      bool is_there_one_jump_calc_all = true;
      
      bool are_there_two_jumps_calc_all = true;

      outSDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index);
      
      for (int n_scat_p = 0 ; (n_scat_p <= n_scat_max_p) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; n_scat_p++)
	{
	  const unsigned int iCp_min = iCp_min_tab(BPp , Sp , n_spec_p , n_scat_p);
	  const unsigned int iCp_max = iCp_max_tab(BPp , Sp , n_spec_p , n_scat_p);
	  
	  for (unsigned int iCp = iCp_min ; (iCp <= iCp_max) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; iCp++)
	    {
	      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
	      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

	      if (dimension_SDp == 0) continue;

	      const unsigned int dimension_SDp_minus_one = dimension_SDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;

	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_SDp_minus_one*dimension_outSDn;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_SDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  if (!are_jumps_n_calculated)
		    {
		      NBMEs_jumps_pp_nn_calc_store (is_it_HO_expansion , inter_data , n_holes_max_n , n_scat_max_n , En_max_hw ,
						    BPn , Sn , n_spec_n , iMn , n_scat_n_out , iCn_out , outSDn_index , outSDn , neut_Y_data , 
						    rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
						    is_there_one_jump_calc_all , are_there_two_jumps_calc_all , one_jump_n , two_jumps_n , 
						    angular_densities_NBMEs_neut_one_jump_n_no_phase_fixed_inSD , angular_densities_NBMEs_neut_one_jump_n ,
						    angular_densities_TBMEs_nn , angular_densities_NBMEs_two_jumps_n , 
						    density_NBMEs_neut_one_jump_n_no_phase_fixed_inSD , density_NBMEs_neut_one_jump_n , density_TBMEs_nn , density_NBMEs_two_jumps_n);
		  
		      are_jumps_n_calculated = true;
		    }
				       
		  for (unsigned int SDp_index = 0 ; (SDp_index < dimension_SDp) && (is_there_one_jump_calc_all || are_there_two_jumps_calc_all) ; SDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + dimension_outSDn*SDp_index;
					  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_SDp_TRS_indices_index = (is_it_TRS) ? (total_SDp_TRS_indices_zero_index + SDp_index) : (NADA);

			  const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_SDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_outSDn*SDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

			      if (is_there_one_jump_calc_all)
				{
				  bool is_there_one_jump_calc = false;
						      
				  is_configuration_accepted_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , one_jump_n , GSM_vector_helper_IN ,
										   is_configuration_accepted_one_jump_n_tab , PSI_IN_indices_one_jump_n , is_there_one_jump_calc);

				  if (is_there_one_jump_calc)
				    densities_part_calc (one_jump_n , is_configuration_accepted_one_jump_n_tab , PSI_IN_indices_one_jump_n , 
							 angular_densities_NBMEs_neut_one_jump_n , density_NBMEs_neut_one_jump_n , 
							 PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
				}

			      if (are_there_two_jumps_calc_all)
				{
				  bool are_there_two_jumps_calc = false;
				  
				  is_configuration_accepted_PSI_in_indices_n_fill (BPp , Sp , n_spec_p , n_holes_p , n_scat_p , iCp , iMp , SDp_index , Ep_hw , two_jumps_n , GSM_vector_helper_IN ,
										   is_configuration_accepted_two_jumps_n_tab , PSI_IN_indices_two_jumps_n , are_there_two_jumps_calc);
		      
				  if (are_there_two_jumps_calc)
				    densities_part_calc (two_jumps_n , is_configuration_accepted_two_jumps_n_tab , PSI_IN_indices_two_jumps_n , 
							 angular_densities_NBMEs_two_jumps_n , density_NBMEs_two_jumps_n , 
							 PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
				}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}





void correlation_density::one_jump_p_pn_part_pn_calc (
						      const bool is_it_HO_expansion , 
						      const class interaction_class &inter_data , 
						      const class array<TYPE> &rk_OBMEs_p , 
						      const class array<TYPE> &rk_OBMEs_n , 
						      const class array<double> &theta12_Dirac_multipolar_tab , 
						      const class lm_table<unsigned int> &lm_indices , 
						      const class ljm_table<unsigned int> &ljm_indices , 
						      const class array<double> &Ylm_table_coupled_to_l , 
						      const class array<double> &Ylm_table_coupled_to_j , 
						      const class array<double> &CGs , 
						      const class GSM_vector &PSI_IN , 
						      const class GSM_vector &PSI_OUT , 
						      class array<TYPE> &angular_densities_tab , 
						      class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();

  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M ();
  
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);

  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const unsigned int Np_nljm = prot_Y_data.get_N_nljm_baryon ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_of_SD &SDn_set = neut_Y_data.get_SD_set ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper_OUT.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper_OUT.get_iCp_max_tab ();
  
  const unsigned long int total_SDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_SDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_SDn_index_min > total_SDn_index_max) return;
      
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  class array<class Slater_determinant> SDn_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_p_no_phase_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_pn_one_jump_p_no_phase_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_pn_one_jump_p_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_p_no_phase_calculated_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_p_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_IN_indices_one_jump_p_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDn_tab(i).allocate (NYval);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_pn_one_jump_p_no_phase_tab(i).allocate (2 , theta_number , Np_nljm , Np_nljm);
      angular_densities_NBMEs_pn_one_jump_p_tab(i).allocate (2 , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      density_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_pn_one_jump_p_no_phase_tab(i).allocate (N_RKmax , theta_number , Np_nljm , Np_nljm);
      density_NBMEs_pn_one_jump_p_tab(i).allocate (N_RKmax , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_pn_one_jump_p_no_phase_calculated_tab(i).allocate (Np_nljm , Np_nljm);

      is_configuration_accepted_one_jump_p_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);

      PSI_IN_indices_one_jump_p_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      angular_densities_part_tabs(i).allocate (2 , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDn_index = total_SDn_index_min ; total_SDn_index <= total_SDn_index_max ; total_SDn_index++)
    {
      const class SD_quantum_numbers &SDn_qn = SD_quantum_numbers_neut_tab(total_SDn_index);

      const int iMn = SDn_qn.get_iM ();

      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = SDn_qn.get_BP ();

      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sn = SDn_qn.get_S ();

      const int Sp = Strangeness - Sn;
      
      const int n_spec_n = SDn_qn.get_n_spec ();

      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n = SDn_qn.get_n_scat ();
	
      const unsigned int iCn = SDn_qn.get_iC ();

      const int n_holes_n = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n , iCn);
	      
      const int En_hw = En_hw_table(BPn , Sn , n_spec_n , n_scat_n , iCn);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n , n_scat_n , En_hw , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (dimension_SDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int SDn_index = SDn_qn.get_SD_index ();
      
      const int iMp = iM - iMn;

      const int TRS_iMp = iMp_max - iMp;
		      
      const unsigned int SDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
		      
      class Slater_determinant &SDn = SDn_tab(i_thread);

      class jumps_data_str &one_jump_p = one_jump_p_tab(i_thread);

      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair = angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_p_no_phase = angular_densities_NBMEs_pn_one_jump_p_no_phase_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_p = angular_densities_NBMEs_pn_one_jump_p_tab(i_thread);
      
      class array<TYPE> &density_NBMEs_pn_one_jump_p_no_phase_fixed_pair = density_NBMEs_pn_one_jump_p_no_phase_fixed_pair_tab(i_thread);
      class array<TYPE> &density_NBMEs_pn_one_jump_p_no_phase = density_NBMEs_pn_one_jump_p_no_phase_tab(i_thread);
      class array<TYPE> &density_NBMEs_pn_one_jump_p = density_NBMEs_pn_one_jump_p_tab(i_thread);
      
      class array<bool> &NBMEs_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_p_tab = is_configuration_accepted_one_jump_p_tabs(i_thread);

      class array<unsigned int> &PSI_IN_indices_one_jump_p = PSI_IN_indices_one_jump_p_tab(i_thread);

      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
      
      angular_densities_NBMEs_pn_one_jump_p_no_phase = 0.0;		      

      density_NBMEs_pn_one_jump_p_no_phase = 0.0;

      NBMEs_pn_one_jump_p_no_phase_calculated = false;

      SDn = SDn_set(BPn , Sn , n_spec_n , n_scat_n , iCn , iMn , SDn_index);
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

	      if (dimension_outSDp == 0) continue;

	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , iMp);
    
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + SDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_SDn*dimension_outSDp_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n , iCp_out , iCn , TRS_iMp)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + SDn_TRS_index) : (NADA);
				      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + dimension_SDn*outSDp_index;
				      
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);

			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_SDn*outSDp_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

			      one_jump_p.one_jump_mu_store (BPp , Sp , n_spec_p , iMp , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , prot_Y_data);

			      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();

			      unsigned int PSI_in_index_zero_SDn = 0;
			      
			      bool is_configuration_accepted = true;
			      
			      for (unsigned int ii = 0 ; ii < dimension_one_jump_p ; ii++)
				{
				  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ii);

				  const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
				      
				      const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

				      const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_max_p , n_scat_max_p , Ep_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p_in , n_scat_p_in , Ep_hw_in , n_holes_n , n_scat_n , En_hw , n_holes_max , n_scat_max , E_max_hw);

				      if (is_configuration_accepted) 
					{
					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
					  
					  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p_in , n_scat_n , iCp_in , iCn , iMp);

					  PSI_in_index_zero_SDn = sum_dimensions_configuration_Mp_Mn_fixed_in + SDn_index;
					}
				    }

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();
							  
				      const unsigned int PSI_in_index = PSI_in_index_zero_SDn + dimension_SDn*inSDp_index;

				      const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
				      const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

				      const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

				      const bool NBME_pn_one_jump_p_no_phase_calculated = NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out);
						      
				      const int total_phase_p = parity_from_binary_parity (total_bin_phase_p);
		  
				      PSI_IN_indices_one_jump_p(ii) = PSI_in_index;
							  
				      if (!NBME_pn_one_jump_p_no_phase_calculated)
					{ 
					  NBMEs_pn_no_phase_one_jump_p_calc (is_it_HO_expansion , inter_data , p_in , p_out , SDn , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , 
									     theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
									     angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair , density_NBMEs_pn_one_jump_p_no_phase_fixed_pair);

					  NBMEs_pn_one_jump_p_no_phase_calculated(p_in , p_out) = NBMEs_pn_one_jump_p_no_phase_calculated(p_out , p_in) = true;


					  for (int S = 0 ; S <= 1 ; S++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      angular_densities_NBMEs_pn_one_jump_p_no_phase(S , it , p_in , p_out)
						= angular_densities_NBMEs_pn_one_jump_p_no_phase(S , it , p_out , p_in)
						= angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair(S , it);

					  for (unsigned int i = 0 ; i < N_RKmax ; i++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      density_NBMEs_pn_one_jump_p_no_phase(i , it , p_in , p_out)
						= density_NBMEs_pn_one_jump_p_no_phase(i , it , p_out , p_in)
						= density_NBMEs_pn_one_jump_p_no_phase_fixed_pair(i , it);
					}
				      else
					{
					  for (int S = 0 ; S <= 1 ; S++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      angular_densities_NBMEs_pn_one_jump_p_no_phase_fixed_pair(S , it) = angular_densities_NBMEs_pn_one_jump_p_no_phase(S , it , p_in , p_out);
							  
					  for (unsigned int i = 0 ; i < N_RKmax ; i++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      density_NBMEs_pn_one_jump_p_no_phase_fixed_pair(i , it) = density_NBMEs_pn_one_jump_p_no_phase(i , it , p_in , p_out);
					}

				      for (int S = 0 ; S <= 1 ; S++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const TYPE angular_densities_NBME_pn_one_jump_p_no_phase = angular_densities_NBMEs_pn_one_jump_p_no_phase(S , it , p_in , p_out);

					    angular_densities_NBMEs_pn_one_jump_p(S , it , ii) = (total_phase_p == 1) ? (angular_densities_NBME_pn_one_jump_p_no_phase) : (-angular_densities_NBME_pn_one_jump_p_no_phase);
					  }

				      for (unsigned int i = 0 ; i < N_RKmax ; i++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const TYPE density_NBME_pn_one_jump_p_no_phase = density_NBMEs_pn_one_jump_p_no_phase(i , it , p_in , p_out);

					    density_NBMEs_pn_one_jump_p(i , it , ii) = (total_phase_p == 1) ? (density_NBME_pn_one_jump_p_no_phase) : (-density_NBME_pn_one_jump_p_no_phase);
					  }
				    }
						  
				  is_configuration_accepted_one_jump_p_tab(ii) = is_configuration_accepted;
				}
					    
			      densities_part_calc (one_jump_p , is_configuration_accepted_one_jump_p_tab , PSI_IN_indices_one_jump_p , 
						   angular_densities_NBMEs_pn_one_jump_p , density_NBMEs_pn_one_jump_p , 
						   PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);

      density_tab += density_part_tabs(i);
    }
}










void correlation_density::one_jump_n_pn_part_pn_calc (
						      const bool is_it_HO_expansion , 
						      const class interaction_class &inter_data , 
						      const class array<TYPE> &rk_OBMEs_p , 
						      const class array<TYPE> &rk_OBMEs_n , 
						      const class array<double> &theta12_Dirac_multipolar_tab , 
						      const class lm_table<unsigned int> &lm_indices , 
						      const class ljm_table<unsigned int> &ljm_indices , 
						      const class array<double> &Ylm_table_coupled_to_l , 
						      const class array<double> &Ylm_table_coupled_to_j , 
						      const class array<double> &CGs , 
						      const class GSM_vector &PSI_IN ,  
						      const class GSM_vector &PSI_OUT , 
						      class array<TYPE> &angular_densities_tab , 
						      class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
 
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();

  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
    
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);

  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const unsigned int Nn_nljm = neut_Y_data.get_N_nljm_baryon ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();

  const class array_of_SD &SDp_set = prot_Y_data.get_SD_set ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper_OUT.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper_OUT.get_iCn_max_tab ();
  
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
    
  const unsigned long int total_SDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_SDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_SDp_index_min > total_SDp_index_max) return;
    
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  class array<class Slater_determinant> SDp_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_n_no_phase_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_pn_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_pn_one_jump_n_no_phase_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_pn_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > NBMEs_pn_one_jump_n_no_phase_calculated_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_one_jump_n_tabs(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_IN_indices_one_jump_n_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SDp_tab(i).allocate (ZYval);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(i).allocate (2 , theta_number);      

      angular_densities_NBMEs_pn_one_jump_n_no_phase_tab(i).allocate (2 , theta_number , Nn_nljm , Nn_nljm);

      angular_densities_NBMEs_pn_one_jump_n_tab(i).allocate (2 , theta_number , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      density_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(i).allocate (N_RKmax , theta_number);

      density_NBMEs_pn_one_jump_n_no_phase_tab(i).allocate (N_RKmax , theta_number , Nn_nljm , Nn_nljm);

      density_NBMEs_pn_one_jump_n_tab(i).allocate (N_RKmax , theta_number , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      NBMEs_pn_one_jump_n_no_phase_calculated_tab(i).allocate (Nn_nljm , Nn_nljm);

      is_configuration_accepted_one_jump_n_tabs(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);

      PSI_IN_indices_one_jump_n_tab(i).allocate (dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      angular_densities_part_tabs(i).allocate (2 , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SDp_index = total_SDp_index_min ; total_SDp_index <= total_SDp_index_max ; total_SDp_index++)
    {
      const class SD_quantum_numbers &SDp_qn = SD_quantum_numbers_prot_tab(total_SDp_index);

      const int iMp = SDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = SDp_qn.get_BP ();

      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sp = SDp_qn.get_S ();

      const int Sn = Strangeness - Sp;
      
      const int n_spec_p = SDp_qn.get_n_spec ();

      const int n_spec_n = n_spec_max - n_spec_p;

      const int n_scat_p = SDp_qn.get_n_scat ();
	
      const unsigned int iCp = SDp_qn.get_iC ();

      const int n_holes_p = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p , iCp);
	      
      const int Ep_hw = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p , iCp);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int SDp_index = SDp_qn.get_SD_index ();
      
      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (dimension_SDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int SDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
      
      class Slater_determinant &SDp = SDp_tab(i_thread);
      
      class jumps_data_str &one_jump_n = one_jump_n_tab(i_thread);
      
      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair = angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_n_no_phase = angular_densities_NBMEs_pn_one_jump_n_no_phase_tab(i_thread);
      class array<TYPE> &angular_densities_NBMEs_pn_one_jump_n = angular_densities_NBMEs_pn_one_jump_n_tab(i_thread);
      
      class array<TYPE> &density_NBMEs_pn_one_jump_n_no_phase_fixed_pair = density_NBMEs_pn_one_jump_n_no_phase_fixed_pair_tab(i_thread);
      class array<TYPE> &density_NBMEs_pn_one_jump_n_no_phase = density_NBMEs_pn_one_jump_n_no_phase_tab(i_thread);
      class array<TYPE> &density_NBMEs_pn_one_jump_n = density_NBMEs_pn_one_jump_n_tab(i_thread);

      class array<bool> &NBMEs_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated_tab(i_thread);

      class array<bool> &is_configuration_accepted_one_jump_n_tab = is_configuration_accepted_one_jump_n_tabs(i_thread);

      class array<unsigned int> &PSI_IN_indices_one_jump_n = PSI_IN_indices_one_jump_n_tab(i_thread);
	      
      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);

      angular_densities_NBMEs_pn_one_jump_n_no_phase = 0.0;

      density_NBMEs_pn_one_jump_n_no_phase = 0.0;
      
      NBMEs_pn_one_jump_n_no_phase_calculated = false;

      SDp = SDp_set(BPp , Sp , n_spec_p , n_scat_p , iCp , iMp , SDp_index);
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn , Sn , n_spec_n , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn , Sn , n_spec_n , n_scat_n_out);
	  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p , n_scat_p , Ep_hw , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);
	      
	      if (dimension_outSDn == 0) continue;
				  
	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , iMp);

	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*SDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_out , iCp , iCn_out , TRS_iMp)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*SDp_TRS_index) : (NADA);
				      
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
				      
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);

			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
					      
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
					      
			      one_jump_n.one_jump_mu_store (BPn , Sn , n_spec_n , iMn , n_holes_max_n , n_scat_max_n , En_max_hw , BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , neut_Y_data);

			      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

			      bool is_configuration_accepted = true;
			      
			      unsigned int PSI_in_index_zero_SDp = 0;
			      
			      for (unsigned int ii = 0 ; ii < dimension_one_jump_n ; ii++)
				{
				  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(ii);
				  
				  const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

				  if (is_configuration_changing)
				    { 
				      const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
				      
				      const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

				      const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

				      is_configuration_accepted =
					is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max_n , n_scat_max_n , En_max_hw) &&
					is_basis_state_in_space_pn    (truncation_hw , truncation_ph , n_holes_p    , n_scat_p    , Ep_hw    , n_holes_n_in , n_scat_n_in , En_hw_in , n_holes_max , n_scat_max , E_max_hw);
				      				      
				      if (is_configuration_accepted)
					{
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const int iMn = iM - iMp;

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_in , iCn_in , iMn);
					  
					  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp , Sp , n_spec_p , n_scat_p , n_scat_n_in , iCp , iCn_in , iMp);

					  PSI_in_index_zero_SDp = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*SDp_index;
					}
				    } 

				  if (is_configuration_accepted)
				    {
				      const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
							  
				      const unsigned int PSI_in_index = PSI_in_index_zero_SDp + inSDn_index;
							  
				      const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
				      const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();

				      const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

				      const int total_phase_n = parity_from_binary_parity (total_bin_phase_n);
		  
				      const bool NBME_pn_one_jump_n_no_phase_calculated = NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out);
						      
				      PSI_IN_indices_one_jump_n(ii) = PSI_in_index;
							  
				      if (!NBME_pn_one_jump_n_no_phase_calculated)
					{
					  NBMEs_pn_no_phase_one_jump_n_calc (is_it_HO_expansion , inter_data , n_in , n_out , SDp , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , 
									     theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
									     angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair , density_NBMEs_pn_one_jump_n_no_phase_fixed_pair);

					  NBMEs_pn_one_jump_n_no_phase_calculated(n_in , n_out) = NBMEs_pn_one_jump_n_no_phase_calculated(n_out , n_in) = true;

					  for (int S = 0 ; S <= 1 ; S++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      angular_densities_NBMEs_pn_one_jump_n_no_phase(S , it , n_in , n_out)
						= angular_densities_NBMEs_pn_one_jump_n_no_phase(S , it , n_out , n_in)
						= angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair(S , it);


					  for (unsigned int i = 0 ; i < N_RKmax ; i++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      density_NBMEs_pn_one_jump_n_no_phase(i , it , n_in , n_out)
						= density_NBMEs_pn_one_jump_n_no_phase(i , it , n_out , n_in)
						= density_NBMEs_pn_one_jump_n_no_phase_fixed_pair(i , it);
					}
				      else
					{
					  for (int S = 0 ; S <= 1 ; S++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      angular_densities_NBMEs_pn_one_jump_n_no_phase_fixed_pair(S , it) = angular_densities_NBMEs_pn_one_jump_n_no_phase(S , it , n_in , n_out);
							  
					  for (unsigned int i = 0 ; i < N_RKmax ; i++)
					    for (unsigned int it = 0 ; it < theta_number ; it++)
					      density_NBMEs_pn_one_jump_n_no_phase_fixed_pair(i , it) = density_NBMEs_pn_one_jump_n_no_phase(i , it , n_in , n_out);
					}
						      
				      for (int S = 0 ; S <= 1 ; S++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const TYPE angular_densities_NBME_pn_one_jump_n_no_phase = angular_densities_NBMEs_pn_one_jump_n_no_phase(S , it , n_in , n_out);

					    angular_densities_NBMEs_pn_one_jump_n(S , it , ii) = (total_phase_n == 1) ? (angular_densities_NBME_pn_one_jump_n_no_phase) : (-angular_densities_NBME_pn_one_jump_n_no_phase);
					  }

				      for (unsigned int i = 0 ; i < N_RKmax ; i++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const TYPE density_NBME_pn_one_jump_n_no_phase = density_NBMEs_pn_one_jump_n_no_phase(i , it , n_in , n_out);

					    density_NBMEs_pn_one_jump_n(i , it , ii) = (total_phase_n == 1) ? (density_NBME_pn_one_jump_n_no_phase) : (-density_NBME_pn_one_jump_n_no_phase);
					  }
				    }
						      
				  is_configuration_accepted_one_jump_n_tab(ii) = is_configuration_accepted;
				}

			      densities_part_calc (one_jump_n , is_configuration_accepted_one_jump_n_tab , PSI_IN_indices_one_jump_n , 
						   angular_densities_NBMEs_pn_one_jump_n , density_NBMEs_pn_one_jump_n , 
						   PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
			    }}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);

      density_tab += density_part_tabs(i);
    }
}













		


void correlation_density::two_jumps_pn_part_pn_Nval_larger_calc (
								      const bool is_it_HO_expansion , 
								      const class interaction_class &inter_data , 
								      const class array<TYPE> &rk_OBMEs_p , 
								      const class array<TYPE> &rk_OBMEs_n , 
								      const class array<double> &theta12_Dirac_multipolar_tab , 
								      const class lm_table<unsigned int> &lm_indices , 
								      const class ljm_table<unsigned int> &ljm_indices , 
								      const class array<double> &Ylm_table_coupled_to_l , 
								      const class array<double> &Ylm_table_coupled_to_j , 
								      const class array<double> &CGs , 
								      const class GSM_vector &PSI_IN ,  
								      const class GSM_vector &PSI_OUT ,
								      class array<TYPE> &angular_densities_tab , 
								      class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_process_IN = GSM_vector_helper_IN.get_space_dimension_process ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max (); 

  const int Strangeness_plus_one = Strangeness + 1;
  
  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
  
  const int iMn_min_M = GSM_vector_helper_OUT.get_iMn_min_M (); 
  const int iMn_max_M = GSM_vector_helper_OUT.get_iMn_max_M (); 
  
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mn_max_plus_one = four_mn_max + 1;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDp_zero_tab ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
     
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();

  const class array<class SD_quantum_numbers> &SD_quantum_numbers_neut_tab = neut_Y_data.get_SD_quantum_numbers_tab ();
    
  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper_OUT.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper_OUT.get_iCp_max_tab ();
  
  const unsigned long int total_outSDn_index_min = GSM_vector_helper_OUT.get_total_SDn_index_min ();
  const unsigned long int total_outSDn_index_max = GSM_vector_helper_OUT.get_total_SDn_index_max ();

  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
  class array<class array<TYPE> > angular_densities_TBMEs_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_TBMEs_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_IN_indices_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_pn_tabs(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_n_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > one_jump_n_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_p_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_TBMEs_pn_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);

      angular_densities_NBMEs_two_jumps_pn_tab(i).allocate (2 , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      density_TBMEs_pn_tab(i).allocate (N_RKmax , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);

      density_NBMEs_two_jumps_pn_tab(i).allocate (N_RKmax , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      PSI_IN_indices_two_jumps_pn_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_two_jumps_pn_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_n_calculated_tabs(i).allocate (2 , Strangeness_plus_one , four_mn_max_plus_one);
      
      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(i);
      
      one_jump_n_tab.allocate (2 , four_mn_max_plus_one);
      
      for (unsigned int BPn_in = 0 ; BPn_in <= 1 ; BPn_in++)
	for (int Delta_iMn_in = 0 ; Delta_iMn_in <= four_mn_max ; Delta_iMn_in++)
	  one_jump_n_tab(BPn_in , Delta_iMn_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_p_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      angular_densities_part_tabs(i) = 0.0;
      
      density_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {      
      const class SD_quantum_numbers &outSDn_qn = SD_quantum_numbers_neut_tab(total_outSDn_index);

      const int iMn_out = outSDn_qn.get_iM ();

      if ((iMn_out < iMn_min_M) || (iMn_out > iMn_max_M)) continue;
      
      const unsigned int BPn_out = outSDn_qn.get_BP ();

      const unsigned int BPp_out = binary_parity_product (BPn_out , BP);

      const int Sn_out = outSDn_qn.get_S ();

      const int Sp_out = Strangeness - Sn_out;

      const int Sn_in = Sn_out;
      const int Sp_in = Sp_out;
      
      const int n_spec_n_out = outSDn_qn.get_n_spec ();

      const int n_spec_p_out = n_spec_max - n_spec_n_out;

      const int n_spec_n_in = n_spec_n_out;
      const int n_spec_p_in = n_spec_p_out;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
      
      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp_out = iM - iMn_out;

      const int TRS_iMp_out = iMp_max - iMp_out;
      
      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();
    
      class array<TYPE> &angular_densities_TBMEs_pn = angular_densities_TBMEs_pn_tab(i_thread);

      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

      class array<TYPE> &angular_densities_NBMEs_two_jumps_pn = angular_densities_NBMEs_two_jumps_pn_tab(i_thread);

      class array<TYPE> &density_TBMEs_pn = density_TBMEs_pn_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);

      class array<TYPE> &density_NBMEs_two_jumps_pn = density_NBMEs_two_jumps_pn_tab(i_thread);

      class array<unsigned int> &PSI_IN_indices_two_jumps_pn = PSI_IN_indices_two_jumps_pn_tab(i_thread);

      class array<bool> &is_configuration_accepted_two_jumps_pn_tab = is_configuration_accepted_two_jumps_pn_tabs(i_thread);
	  
      class array<bool> &is_one_jump_n_calculated_tab = is_one_jump_n_calculated_tabs(i_thread);

      class array<class jumps_data_str> &one_jump_n_tab = one_jump_n_tabs(i_thread);
      
      class jumps_data_str &one_jump_p = one_jump_p_tab(i_thread);
        
      is_one_jump_n_calculated_tab = false;
      
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);
	      
	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int dimension_outSDp_minus_one = dimension_outSDp - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn*dimension_outSDp_minus_one;
				  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
				  
		  const unsigned long int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
		  for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);

			  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
			
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
		  
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				      
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;

				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

				      bool &is_one_jump_n_calculated = is_one_jump_n_calculated_tab(BPn_in , Delta_iMn_in);
				  
				      class jumps_data_str &one_jump_n = one_jump_n_tab(BPn_in , Delta_iMn_in);
	      				  
				      if (!is_one_jump_n_calculated)
					{
					  one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

					  is_one_jump_n_calculated = true;				      
					}

				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
				      if (dimension_one_jump_n == 0) continue;
		  
				      one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				      if (dimension_one_jump_p == 0) continue;

				      unsigned int PSI_in_index_zero_inSDn = 0;
								    
				      bool is_configuration_accepted = true;

				      PSI_IN_indices_two_jumps_pn = space_dimension_process_IN;
						     
				      for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					{
					  const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);

					  const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
					  const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();
					  
					  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();

					  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

					  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

					  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
					  
					  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

					  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();
		  
					  for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
					    {
					      const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);
					      
					      const bool is_configuration_changing = one_jump_n_inSDn.get_is_configuration_changing ();

					      if (is_configuration_changing)
						{ 
						  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
						  
						  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

						  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

						  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();
									  
						  is_configuration_accepted = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						  if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						  if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						  if (is_configuration_accepted) 
						    {
						      const int iMn_in = iM - iMp_in;

						      const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);

						      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
						  
						      PSI_in_index_zero_inSDn = sum_dimensions_configuration_Mp_Mn_fixed_in + dimension_inSDn*inSDp_index;
						    }
						}	

					      if (is_configuration_accepted)
						{ 
						  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();
						  
						  const unsigned int PSI_in_index = PSI_in_index_zero_inSDn + inSDn_index;

						  const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
						  const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
						  
						  const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

						  uncoupled_TBMEs_pn_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , p_in , n_in , p_out , n_out , theta12_Dirac_multipolar_tab , 
									   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs_pn , density_TBMEs_pn);

						  PSI_IN_indices_two_jumps_pn(ip , in) = PSI_in_index;
						  
						  for (int S = 0 ; S <= 1 ; S++)
						    for (unsigned int it = 0 ; it < theta_number ; it++)
						      {
							const TYPE angular_densities_TBME_pn = angular_densities_TBMEs_pn(S , it);
										    
							angular_densities_NBMEs_two_jumps_pn(S , it , ip , in) = (total_bin_phase_p == total_bin_phase_n) ? (angular_densities_TBME_pn) : (-angular_densities_TBME_pn);
						      }
									      
						  for (unsigned int i = 0 ; i < N_RKmax ; i++)
						    for (unsigned int it = 0 ; it < theta_number ; it++)
						      {
							const TYPE density_TBME_pn = density_TBMEs_pn(i , it);
										    
							density_NBMEs_two_jumps_pn(i , it , ip , in) = (total_bin_phase_p == total_bin_phase_n) ? (density_TBME_pn) : (-density_TBME_pn);
						      }
						}
					      
					      is_configuration_accepted_two_jumps_pn_tab(ip , in) = is_configuration_accepted;
					    }
					}
							      
				      for (int S = 0 ; S <= 1 ; S++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					    const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

					    TYPE component_angular_density = 0.0;

					    for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const bool is_configuration_accepted = is_configuration_accepted_two_jumps_pn_tab(ip , in);
						  
						  if (is_configuration_accepted)
						    {
						      const unsigned int PSI_IN_index_ip_in = PSI_IN_indices_two_jumps_pn(ip , in);

						      component_angular_density += PSI_IN[PSI_IN_index_ip_in]*angular_densities_NBMEs_two_jumps_pn(S , it , ip , in);
						    }
						}

					    angular_densities_part_tab(S , it) += PSI_OUT_component_TRS_factor*component_angular_density;
					  }
				       
				      for (unsigned int i = 0 ; i < N_RKmax ; i++) 
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					    const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

					    TYPE component_density = 0.0;

					    for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const bool is_configuration_accepted = is_configuration_accepted_two_jumps_pn_tab(ip , in);

						  if (is_configuration_accepted)
						    {
						      const unsigned int PSI_IN_index_ip_in = PSI_IN_indices_two_jumps_pn(ip , in);

						      component_density += PSI_IN[PSI_IN_index_ip_in]*density_NBMEs_two_jumps_pn(i , it , ip , in);
						    }
						}
								  								  
					    density_part_tab(i , it) += PSI_OUT_component_TRS_factor*component_density;
					  }}}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}












void correlation_density::two_jumps_pn_part_pn_Zval_larger_calc (
								 const bool is_it_HO_expansion , 
								 const class interaction_class &inter_data , 
								 const class array<TYPE> &rk_OBMEs_p , 
								 const class array<TYPE> &rk_OBMEs_n , 
								 const class array<double> &theta12_Dirac_multipolar_tab , 
								 const class lm_table<unsigned int> &lm_indices , 
								 const class ljm_table<unsigned int> &ljm_indices , 
								 const class array<double> &Ylm_table_coupled_to_l , 
								 const class array<double> &Ylm_table_coupled_to_j , 
								 const class array<double> &CGs , 
								 const class GSM_vector &PSI_IN ,  
								 const class GSM_vector &PSI_OUT ,
								 class array<TYPE> &angular_densities_tab , 
								 class array<TYPE> &density_tab)
{  
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int space_dimension_process_IN = GSM_vector_helper_IN.get_space_dimension_process ();
    
  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data (); 
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
    
  const int two_mp_max = prot_Y_data.get_two_m_max ();
  const int two_mn_max = neut_Y_data.get_two_m_max ();
  
  const int four_mp_max = prot_Y_data.get_four_m_max ();
  const int four_mn_max = neut_Y_data.get_four_m_max ();
  
  const int mp_max_minus_mp_min = prot_Y_data.get_m_max_minus_m_min ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_OUT.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_OUT.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_OUT.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_OUT.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw (); 

  const int Ep_max_hw = GSM_vector_helper_OUT.get_Ep_max_hw (); 
  const int En_max_hw = GSM_vector_helper_OUT.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int n_spec_max = GSM_vector_helper_OUT.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_OUT.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper_OUT.get_iMp_max_M ();
    
  const int iMp_max = prot_Y_data.get_iM_max ();
  
  const int four_mp_max_plus_one = four_mp_max + 1;
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_OUT.get_all_dimensions_SDn_zero_tab ();
  
  const unsigned int dimension_p_1p1h_space_BP_S_iM_fixed_max = prot_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_n_1p1h_space_BP_S_iM_fixed_max = neut_Y_data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();

  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
	    
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_Y_data.get_dimensions_SD_set ();
  
  const unsigned int first_PSI_out_index = GSM_vector_helper_OUT.get_first_PSI_index ();
  const unsigned int last_PSI_out_index = GSM_vector_helper_OUT.get_last_PSI_index ();

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_Y_data.get_SD_TRS_indices ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_prot_tab = prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper_OUT.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper_OUT.get_iCn_max_tab ();
  
  const unsigned long int total_outSDp_index_min = GSM_vector_helper_OUT.get_total_SDp_index_min ();
  const unsigned long int total_outSDp_index_max = GSM_vector_helper_OUT.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
  class array<class array<TYPE> > angular_densities_TBMEs_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_TBMEs_pn_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_IN_indices_two_jumps_pn_tab(NUMBER_OF_THREADS);

  class array<class array<bool> > is_configuration_accepted_two_jumps_pn_tabs(NUMBER_OF_THREADS);
  
  class array<class array<bool> > is_one_jump_p_calculated_tabs(NUMBER_OF_THREADS);
  
  class array<class array<class jumps_data_str> > one_jump_p_tabs(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_n_tab(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_TBMEs_pn_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);

      angular_densities_NBMEs_two_jumps_pn_tab(i).allocate (2 , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      density_TBMEs_pn_tab(i).allocate (N_RKmax , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);

      density_NBMEs_two_jumps_pn_tab(i).allocate (N_RKmax , theta_number , dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      PSI_IN_indices_two_jumps_pn_tab(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      is_configuration_accepted_two_jumps_pn_tabs(i).allocate (dimension_p_1p1h_space_BP_S_iM_fixed_max , dimension_n_1p1h_space_BP_S_iM_fixed_max);
      
      is_one_jump_p_calculated_tabs(i).allocate (2 , four_mp_max_plus_one);
      
      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(i);
      
      one_jump_p_tab.allocate (2 , four_mp_max_plus_one);
      
      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
	for (int Delta_iMp_in = 0 ; Delta_iMp_in <= four_mp_max ; Delta_iMp_in++)
	  one_jump_p_tab(BPp_in , Delta_iMp_in).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_p_1p1h_space_BP_S_iM_fixed_max);
      
      one_jump_n_tab(i).allocate (ONE_JUMP , PROT_NEUT_Y , truncation_hw , truncation_ph , dimension_n_1p1h_space_BP_S_iM_fixed_max);

      angular_densities_part_tabs(i) = 0.0;
      
      density_part_tabs(i) = 0.0;	  
    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SD_quantum_numbers_prot_tab(total_outSDp_index);

      const int iMp_out = outSDp_qn.get_iM ();

      if ((iMp_out < iMp_min_M) || (iMp_out > iMp_max_M)) continue;
      
      const unsigned int BPp_out = outSDp_qn.get_BP ();

      const unsigned int BPn_out = binary_parity_product (BPp_out , BP);

      const int Sp_out = outSDp_qn.get_S ();

      const int Sn_out = Strangeness - Sp_out;

      const int Sp_in = Sp_out;
      const int Sn_in = Sn_out;
      
      const int n_spec_p_out = outSDp_qn.get_n_spec ();

      const int n_spec_n_out = n_spec_max - n_spec_p_out;

      const int n_spec_p_in = n_spec_p_out;
      const int n_spec_n_in = n_spec_n_out;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out);

      if (all_dimensions_SDn_zero) continue;

      const int iMn_out = iM - iMp_out;

      const int TRS_iMp_out = iMp_max - iMp_out;

      const int iMp_in_min_M = max (iMp_min_M , iMp_out - mp_max_minus_mp_min);
      const int iMp_in_max_M = min (iMp_max_M , iMp_out + mp_max_minus_mp_min);

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();

      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index)) : (NADA);
      
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      class array<TYPE> &angular_densities_TBMEs_pn = angular_densities_TBMEs_pn_tab(i_thread);

      class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

      class array<TYPE> &angular_densities_NBMEs_two_jumps_pn = angular_densities_NBMEs_two_jumps_pn_tab(i_thread);

      class array<TYPE> &density_TBMEs_pn = density_TBMEs_pn_tab(i_thread);

      class array<TYPE> &density_part_tab = density_part_tabs(i_thread);

      class array<TYPE> &density_NBMEs_two_jumps_pn = density_NBMEs_two_jumps_pn_tab(i_thread);

      class array<unsigned int> &PSI_IN_indices_two_jumps_pn = PSI_IN_indices_two_jumps_pn_tab(i_thread);

      class array<bool> &is_configuration_accepted_two_jumps_pn_tab = is_configuration_accepted_two_jumps_pn_tabs(i_thread);
      
      class array<bool> &is_one_jump_p_calculated_tab = is_one_jump_p_calculated_tabs(i_thread);

      class array<class jumps_data_str> &one_jump_p_tab = one_jump_p_tabs(i_thread);
      
      class jumps_data_str &one_jump_n = one_jump_n_tab(i_thread);
            
      is_one_jump_p_calculated_tab = false;
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {
	      const int n_holes_n_out = n_holes_n_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out);

	      if (dimension_outSDn == 0) continue;

	      const unsigned int dimension_outSDn_minus_one = dimension_outSDn - 1;

	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp_out);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	      
	      const unsigned int PSI_out_index_dimension_minus_one = PSI_out_index_zero + dimension_outSDn_minus_one;
  
	      if ((PSI_out_index_zero <= last_PSI_out_index) && (PSI_out_index_dimension_minus_one >= first_PSI_out_index))
		{
		  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp_out)) : (NADA);
		  
		  const unsigned long int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , 0)) : (NADA);
				      
		  const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		    {
		      const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;
			  
		      if ((PSI_out_index >= first_PSI_out_index) && (PSI_out_index <= last_PSI_out_index))
			{
			  const unsigned long int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);

			  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
			  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
			
			  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
			    {
			      const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

			      const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
	  
			      for (unsigned int BPp_in = 0 ; BPp_in <= 1 ; BPp_in++)
				{
				  const unsigned int BPn_in = binary_parity_product (BP , BPp_in);
	  
				  for (int iMp_in = iMp_in_min_M ; iMp_in <= iMp_in_max_M ; iMp_in++)
				    {
				      const int iMn_in = iM - iMp_in;
				      
				      const int Delta_iMp_in = iMp_in - iMp_out + two_mp_max;
				      const int Delta_iMn_in = iMn_in - iMn_out + two_mn_max;
	       
				      if ((Delta_iMp_in < 0) || (Delta_iMp_in > four_mp_max)) continue;
				      if ((Delta_iMn_in < 0) || (Delta_iMn_in > four_mn_max)) continue;

				      bool &is_one_jump_p_calculated = is_one_jump_p_calculated_tab(BPp_in , Delta_iMp_in);
				  
				      class jumps_data_str &one_jump_p = one_jump_p_tab(BPp_in , Delta_iMp_in);
	      
				      if (!is_one_jump_p_calculated)
					{
					  one_jump_p.one_jump_mu_store (BPp_in , Sp_in , n_spec_p_in , iMp_in , n_holes_max_p , n_scat_max_p , Ep_max_hw , BPp_out , Sp_out , n_spec_p_out , n_scat_p_out , iCp_out , iMp_out , outSDp_index , prot_Y_data);
				      
					  is_one_jump_p_calculated = true;
					}

				      const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
				  
				      if (dimension_one_jump_p == 0) continue;
				  
				      one_jump_n.one_jump_mu_store (BPn_in , Sn_in , n_spec_n_in , iMn_in , n_holes_max_n , n_scat_max_n , En_max_hw , BPn_out , Sn_out , n_spec_n_out , n_scat_n_out , iCn_out , iMn_out , outSDn_index , neut_Y_data);

				      const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();
				  
				      if (dimension_one_jump_n == 0) continue;
					      
				      bool is_configuration_accepted = true;
				      
				      PSI_IN_indices_two_jumps_pn = space_dimension_process_IN;
				      
				      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)  
					{
					  const class jumps_data_inSD_str &one_jump_n_inSDn = one_jump_n(in);

					  const unsigned int n_in  = one_jump_n_inSDn.get_mu_in ();
					  const unsigned int n_out = one_jump_n_inSDn.get_mu_out ();
					  
					  const unsigned int iCn_in = one_jump_n_inSDn.get_iC ();

					  const unsigned int inSDn_index = one_jump_n_inSDn.get_inSD_index ();

					  const unsigned int total_bin_phase_n = one_jump_n_inSDn.get_total_bin_phase ();

					  const int n_holes_n_in = one_jump_n_inSDn.get_n_holes ();
					  
					  const int n_scat_n_in = one_jump_n_inSDn.get_n_scat ();

					  const int En_hw_in = one_jump_n_inSDn.get_E_hw ();

					  const unsigned int dimension_inSDn = dimensions_SDn_set(BPn_in , Sn_in , n_spec_n_in , n_scat_n_in , iCn_in , iMn_in);

					  unsigned int PSI_in_index_zero_inSDp = 0;
					
					  for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					    {
					      const class jumps_data_inSD_str &one_jump_p_inSDp = one_jump_p(ip);
					      
					      const bool is_configuration_changing = one_jump_p_inSDp.get_is_configuration_changing ();

					      if (is_configuration_changing)
						{ 
						  const int n_holes_p_in = one_jump_p_inSDp.get_n_holes ();
						  
						  const int n_scat_p_in = one_jump_p_inSDp.get_n_scat ();

						  const int Ep_hw_in = one_jump_p_inSDp.get_E_hw ();

						  const unsigned int iCp_in = one_jump_p_inSDp.get_iC ();
									  
						  is_configuration_accepted = true;
									  
						  if (truncation_hw && (Ep_hw_in + En_hw_in > E_max_hw))            is_configuration_accepted = false;
						  if (truncation_ph && (n_holes_p_in + n_holes_n_in > n_holes_max)) is_configuration_accepted = false;
						  if (truncation_ph && (n_scat_p_in + n_scat_n_in > n_scat_max))    is_configuration_accepted = false;
									  
						  if (is_configuration_accepted) 
						    {
						      const int iMp_in = iM - iMn_in;

						      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in = sum_dimensions_GSM_vector(BPp_in , Sp_in , n_spec_p_in , n_scat_p_in , n_scat_n_in , iCp_in , iCn_in , iMp_in);
						  
						      PSI_in_index_zero_inSDp = sum_dimensions_configuration_Mp_Mn_fixed_in + inSDn_index;
						    }
						}	

					      if (is_configuration_accepted)
						{ 
						  const unsigned int inSDp_index = one_jump_p_inSDp.get_inSD_index ();

						  const unsigned int PSI_in_index = PSI_in_index_zero_inSDp + dimension_inSDn*inSDp_index;

						  const unsigned int p_in  = one_jump_p_inSDp.get_mu_in ();
						  const unsigned int p_out = one_jump_p_inSDp.get_mu_out ();

						  const unsigned int total_bin_phase_p = one_jump_p_inSDp.get_total_bin_phase ();

						  uncoupled_TBMEs_pn_calc (is_it_HO_expansion , inter_data , prot_Y_data , neut_Y_data , rk_OBMEs_p , rk_OBMEs_n , p_in , n_in , p_out , n_out , theta12_Dirac_multipolar_tab , 
									   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs_pn , density_TBMEs_pn);

						  PSI_IN_indices_two_jumps_pn(ip , in) = PSI_in_index;

						  for (int S = 0 ; S <= 1 ; S++)
						    for (unsigned int it = 0 ; it < theta_number ; it++)
						      {
							const TYPE angular_densities_TBME_pn = angular_densities_TBMEs_pn(S , it);

							angular_densities_NBMEs_two_jumps_pn(S , it , ip , in) = (total_bin_phase_p == total_bin_phase_n) ? (angular_densities_TBME_pn) : (-angular_densities_TBME_pn);
						      }
									      
						  for (unsigned int i = 0 ; i < N_RKmax ; i++)
						    for (unsigned int it = 0 ; it < theta_number ; it++)
						      {
							const TYPE density_TBME_pn = density_TBMEs_pn(i , it);
										    
							density_NBMEs_two_jumps_pn(i , it , ip , in) = (total_bin_phase_p == total_bin_phase_n) ? (density_TBME_pn) : (-density_TBME_pn);
						      }
						}
					      
					      is_configuration_accepted_two_jumps_pn_tab(ip , in) = is_configuration_accepted;
					    }
					}
				    							      
				      for (int S = 0 ; S <= 1 ; S++)
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					    const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

					    TYPE component_angular_density = 0.0;

					    for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const bool is_configuration_accepted = is_configuration_accepted_two_jumps_pn_tab(ip , in);

						  if (is_configuration_accepted)
						    {
						      const unsigned int PSI_IN_index_ip_in = PSI_IN_indices_two_jumps_pn(ip , in);

						      component_angular_density += PSI_IN[PSI_IN_index_ip_in]*angular_densities_NBMEs_two_jumps_pn(S , it , ip , in);
						    }
						}

					    angular_densities_part_tab(S , it) += PSI_OUT_component_TRS_factor*component_angular_density;
					  }

				      for (unsigned int i = 0 ; i < N_RKmax ; i++) 
					for (unsigned int it = 0 ; it < theta_number ; it++)
					  {
					    const unsigned int dimension_one_jump_p = one_jump_p.get_dimension ();
					    const unsigned int dimension_one_jump_n = one_jump_n.get_dimension ();

					    TYPE component_density = 0.0;

					    for (unsigned int ip = 0 ; ip < dimension_one_jump_p ; ip++)  
					      for (unsigned int in = 0 ; in < dimension_one_jump_n ; in++)
						{
						  const bool is_configuration_accepted = is_configuration_accepted_two_jumps_pn_tab(ip , in);

						  if (is_configuration_accepted)
						    {
						      const unsigned int PSI_IN_index_ip_in = PSI_IN_indices_two_jumps_pn(ip , in);

						      component_density += PSI_IN[PSI_IN_index_ip_in]*density_NBMEs_two_jumps_pn(i , it , ip , in);
						    }
						}
								  								  
					    density_part_tab(i , it) += PSI_OUT_component_TRS_factor*component_density;
					  }}}}}}}}}}
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}






void correlation_density::diagonal_part_pp_nn_calc (
						    const bool is_it_HO_expansion , 
						    const class interaction_class &inter_data , 
						    const class array<TYPE> &rk_OBMEs , 
						    const class array<double> &theta12_Dirac_multipolar_tab , 
						    const class lm_table<unsigned int> &lm_indices , 
						    const class ljm_table<unsigned int> &ljm_indices , 
						    const class array<double> &Ylm_table_coupled_to_l , 
						    const class array<double> &Ylm_table_coupled_to_j , 
						    const class array<double> &CGs ,
						    const class GSM_vector &PSI_IN ,
						    const class GSM_vector &PSI_OUT ,  
						    class array<TYPE> &angular_densities_tab , 
						    class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();

  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();

  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
    
  const class array_of_SD &SD_set = data.get_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();

  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();
  
  const unsigned long int total_SD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_SD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();

  if (total_SD_index_min > total_SD_index_max) return;
    
  class array<class Slater_determinant> SD_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > PSI_components_TRS_factor_product_density_NBMEs_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      SD_tab(i).allocate (N_valence_baryons);
      
      angular_densities_TBMEs_tab(i).allocate (2 , theta_number);
      angular_densities_NBMEs_tab(i).allocate (2 , theta_number);
	  
      PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i).allocate (2 , theta_number);

      angular_densities_part_tabs(i).allocate (2 , theta_number);
	  
      density_TBMEs_tab(i).allocate (N_RKmax , theta_number);
      density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
      
      PSI_components_TRS_factor_product_density_NBMEs_tab(i).allocate (N_RKmax , theta_number);
      
      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;
      density_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_SD_index = total_SD_index_min ; total_SD_index <= total_SD_index_max ; total_SD_index++)
    {
      const class SD_quantum_numbers &SD_qn = SD_quantum_numbers_tab(total_SD_index);

      const int iM_SD = SD_qn.get_iM ();

      if (iM_SD != iM) continue;

      const unsigned int BP_SD = SD_qn.get_BP ();

      if (BP_SD != BP) continue;
      
      const int S_SD = SD_qn.get_S ();

      if (S_SD != Strangeness) continue;
 
      const unsigned int n_scat = SD_qn.get_n_scat ();

      const unsigned int iC = SD_qn.get_iC ();

      const int n_holes = n_holes_table(BP , Strangeness , 0 , n_scat , iC);
	  
      const int E_hw = E_hw_table(BP , Strangeness , 0 , n_scat , iC);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes , n_scat , E_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int SD_index = SD_qn.get_SD_index ();

      const unsigned int sum_dimensions_configuration_fixed = sum_dimensions_GSM_vector(n_scat , iC);

      const unsigned int PSI_index = sum_dimensions_configuration_fixed + SD_index;
      
      const unsigned int SD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , Strangeness , 0 , n_scat , iC , iM , SD_index)) : (NADA);

      const unsigned int sum_dimensions_configuration_fixed_TRS = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat , iC)) : (NADA);

      const unsigned int TRS_PSI_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS + SD_TRS_index) : (NADA);
	  
      if (!is_it_TRS || (TRS_PSI_index >= PSI_index))
	{
	  const TYPE &PSI_IN_component  = PSI_IN[PSI_index];
	  const TYPE &PSI_OUT_component = PSI_OUT[PSI_index];						  
			  
	  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_index == PSI_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);
			  
	  const TYPE PSI_components_TRS_factor_product = PSI_IN_component*PSI_OUT_component_TRS_factor;

	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	  
	  class Slater_determinant &SD = SD_tab(i_thread);
	  
	  class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
	  class array<TYPE> &angular_densities_NBMEs = angular_densities_NBMEs_tab(i_thread);
  
	  class array<TYPE> &PSI_components_TRS_factor_product_angular_densities_NBMEs = PSI_components_TRS_factor_product_angular_densities_NBMEs_tab(i_thread);
	  class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);
  
	  class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
	  class array<TYPE> &density_NBMEs = density_NBMEs_tab(i_thread);
  
	  class array<TYPE> &PSI_components_TRS_factor_product_density_NBMEs = PSI_components_TRS_factor_product_density_NBMEs_tab(i_thread);
  
	  class array<TYPE> &density_part_tab = density_part_tabs(i_thread);
      
	  SD = SD_set(BP , Strangeness , 0 , n_scat , iC , iM , SD_index);
	  
	  angular_densities_NBMEs = 0.0;

	  density_NBMEs = 0.0;

	  for (int mu = 0 ; mu < N_valence_baryons ; mu++)
	    {
	      const unsigned int state_mu = SD[mu];

	      for (int mu_p = 0 ; mu_p < N_valence_baryons ; mu_p++)
		{
		  const unsigned int state_mu_p = SD[mu_p];

		  if (state_mu < state_mu_p)
		    {
		      uncoupled_TBMEs_pp_nn_calc (is_it_HO_expansion , inter_data , data , rk_OBMEs , state_mu , state_mu_p , state_mu , state_mu_p , theta12_Dirac_multipolar_tab , 
						  lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , angular_densities_TBMEs , density_TBMEs);

		      angular_densities_NBMEs += angular_densities_TBMEs;

		      density_NBMEs += density_TBMEs;
		    }
		}
	    }

	  PSI_components_TRS_factor_product_angular_densities_NBMEs = angular_densities_NBMEs;
	  PSI_components_TRS_factor_product_angular_densities_NBMEs *= PSI_components_TRS_factor_product;

	  angular_densities_part_tab += PSI_components_TRS_factor_product_angular_densities_NBMEs;

	  PSI_components_TRS_factor_product_density_NBMEs = density_NBMEs;
	  PSI_components_TRS_factor_product_density_NBMEs *= PSI_components_TRS_factor_product;

	  density_part_tab += PSI_components_TRS_factor_product_density_NBMEs;
	}
    }
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);

      density_tab += density_part_tabs(i);
    }
}










void correlation_density::jumps_part_pp_nn_calc (
						 const bool is_it_HO_expansion , 
						 const class interaction_class &inter_data , 
						 const class array<TYPE> &rk_OBMEs , 
						 const class array<double> &theta12_Dirac_multipolar_tab , 
						 const class lm_table<unsigned int> &lm_indices , 
						 const class ljm_table<unsigned int> &ljm_indices , 
						 const class array<double> &Ylm_table_coupled_to_l , 
						 const class array<double> &Ylm_table_coupled_to_j , 
						 const class array<double> &CGs ,
						 const class GSM_vector &PSI_IN ,
						 const class GSM_vector &PSI_OUT ,  
						 class array<TYPE> &angular_densities_tab , 
						 class array<TYPE> &density_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
    
  const enum space_type space = GSM_vector_helper_OUT.get_space ();

  const bool truncation_hw = GSM_vector_helper_OUT.get_truncation_hw (); 
  const bool truncation_ph = GSM_vector_helper_OUT.get_truncation_ph ();
    
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();

  const class baryons_data &data = (space == PROT_Y_ONLY) ? (prot_Y_data) : (neut_Y_data);

  const int N_valence_baryons = data.get_N_valence_baryons ();
  
  const bool is_it_TRS = GSM_vector_helper_OUT.get_is_it_TRS ();
  
  const int n_holes_max = GSM_vector_helper_OUT.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_OUT.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_OUT.get_E_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_OUT.get_BP ();
  
  const int Strangeness = GSM_vector_helper_OUT.get_S ();
  
  const int iM = GSM_vector_helper_OUT.get_iM ();
  
  const unsigned int N_RKmax = density_tab.dimension (0);

  const unsigned int theta_number = density_tab.dimension (1);

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = data.get_n_holes_table ();
 
  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = data.get_E_hw_table ();
  
  const unsigned int dimension_1p1h_space_BP_S_iM_fixed_max = data.get_dimension_1p1h_space_BP_S_iM_fixed_max ();
  const unsigned int dimension_2p2h_space_BP_S_iM_fixed_max = data.get_dimension_2p2h_space_BP_S_iM_fixed_max ();

  const class array_of_SD &SD_set = data.get_SD_set ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS = GSM_vector_helper_OUT.get_sum_dimensions_GSM_vector_TRS ();
  
  const unsigned int dimension_max = max (dimension_1p1h_space_BP_S_iM_fixed_max , dimension_2p2h_space_BP_S_iM_fixed_max);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = data.get_SD_TRS_indices ();
    
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = data.get_SD_quantum_numbers_tab ();

  const unsigned long int total_outSD_index_min = GSM_vector_helper_OUT.get_total_SD_index_min ();
  const unsigned long int total_outSD_index_max = GSM_vector_helper_OUT.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return;
    
  class array<bool> is_configuration_accepted_tab(dimension_max);

  is_configuration_accepted_tab = true;
  
  class array<class Slater_determinant> outSDmu_tab(NUMBER_OF_THREADS);
  
  class array<class jumps_data_str> one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class jumps_data_str> two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<unsigned int> > PSI_IN_indices_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<unsigned int> > PSI_IN_indices_two_jumps_mu_tab(NUMBER_OF_THREADS);
	  
  class array<class array<TYPE> > angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > angular_densities_NBMEs_two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_TBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > angular_densities_part_tabs(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(NUMBER_OF_THREADS);
  
  class array<class array<TYPE> > density_NBMEs_one_jump_mu_tab(NUMBER_OF_THREADS);
  class array<class array<TYPE> > density_NBMEs_two_jumps_mu_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_TBMEs_tab(NUMBER_OF_THREADS);

  class array<class array<TYPE> > density_part_tabs(NUMBER_OF_THREADS);
	    
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      outSDmu_tab(i).allocate (N_valence_baryons);
      
      one_jump_mu_tab(i).allocate  (ONE_JUMP , space , truncation_hw , truncation_ph , dimension_1p1h_space_BP_S_iM_fixed_max);

      PSI_IN_indices_one_jump_mu_tab(i).allocate  (dimension_1p1h_space_BP_S_iM_fixed_max);
      
      angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(i).allocate (2 , theta_number);
      
      angular_densities_NBMEs_one_jump_mu_tab(i).allocate  (2 , theta_number , dimension_1p1h_space_BP_S_iM_fixed_max);

      density_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(i).allocate (N_RKmax , theta_number);
      
      density_NBMEs_one_jump_mu_tab(i).allocate  (N_RKmax , theta_number , dimension_1p1h_space_BP_S_iM_fixed_max);
     
      if (N_valence_baryons >= 2)
	{
	  two_jumps_mu_tab(i).allocate (TWO_JUMPS , space , truncation_hw , truncation_ph , dimension_2p2h_space_BP_S_iM_fixed_max);

	  PSI_IN_indices_two_jumps_mu_tab(i).allocate (dimension_2p2h_space_BP_S_iM_fixed_max);

	  angular_densities_NBMEs_two_jumps_mu_tab(i).allocate (2 , theta_number , dimension_2p2h_space_BP_S_iM_fixed_max);

	  angular_densities_TBMEs_tab(i).allocate (2 , theta_number);

	  density_TBMEs_tab(i).allocate (N_RKmax , theta_number);

	  density_NBMEs_two_jumps_mu_tab(i).allocate (N_RKmax , theta_number , dimension_2p2h_space_BP_S_iM_fixed_max);
	}

      angular_densities_part_tabs(i).allocate (2 , theta_number);

      density_part_tabs(i).allocate (N_RKmax , theta_number);
      
      angular_densities_part_tabs(i) = 0.0;

      density_part_tabs(i) = 0.0;
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned long int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
 
      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
      
      const int S_out = outSD_qn.get_S ();

      if (S_out != Strangeness) continue;
 
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP_out , S_out , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP_out , S_out , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector(n_scat_out , iC_out);

      const unsigned int PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , Strangeness , 0 , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

      const unsigned int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS(n_scat_out , iC_out)) : (NADA);

      const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);

      if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  class Slater_determinant &outSDmu = outSDmu_tab(i_thread);
	  
	  class jumps_data_str &one_jump_mu  = one_jump_mu_tab(i_thread);
	  class jumps_data_str &two_jumps_mu = two_jumps_mu_tab(i_thread);

	  class array<unsigned int> &PSI_IN_indices_one_jump_mu = PSI_IN_indices_one_jump_mu_tab(i_thread);
	  class array<unsigned int> &PSI_IN_indices_two_jumps_mu = PSI_IN_indices_two_jumps_mu_tab(i_thread);

	  class array<TYPE> &angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD = angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(i_thread);

	  class array<TYPE> &angular_densities_NBMEs_one_jump_mu  = angular_densities_NBMEs_one_jump_mu_tab(i_thread);
	  class array<TYPE> &angular_densities_NBMEs_two_jumps_mu = angular_densities_NBMEs_two_jumps_mu_tab(i_thread);

	  class array<TYPE> &angular_densities_TBMEs = angular_densities_TBMEs_tab(i_thread);
	  
	  class array<TYPE> &angular_densities_part_tab = angular_densities_part_tabs(i_thread);

	  class array<TYPE> &density_NBMEs_one_jump_mu_no_phase_fixed_inSD = density_NBMEs_one_jump_mu_no_phase_fixed_inSD_tab(i_thread);

	  class array<TYPE> &density_NBMEs_one_jump_mu  = density_NBMEs_one_jump_mu_tab(i_thread);
	  class array<TYPE> &density_NBMEs_two_jumps_mu = density_NBMEs_two_jumps_mu_tab(i_thread);

	  class array<TYPE> &density_TBMEs = density_TBMEs_tab(i_thread);
	  
	  class array<TYPE> &density_part_tab = density_part_tabs(i_thread);

	  const TYPE &PSI_OUT_component = PSI_OUT[PSI_out_index];

	  const TYPE PSI_OUT_component_TRS_factor = (!is_it_TRS || (TRS_PSI_out_index == PSI_out_index)) ? (PSI_OUT_component) : (2.0*PSI_OUT_component);

	  bool is_there_one_jump_calc_all = false;
	  
	  bool are_there_two_jumps_calc_all = false;
			      
	  outSDmu = SD_set(BP , Strangeness , 0 , n_scat_out , iC_out , iM , outSD_index);
	  
	  NBMEs_jumps_pp_nn_calc_store (is_it_HO_expansion , inter_data , n_holes_max , n_scat_max , E_max_hw , BP , Strangeness , 0 , iM , n_scat_out , iC_out , outSD_index , outSDmu , data , 
					rk_OBMEs , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , 
					is_there_one_jump_calc_all , are_there_two_jumps_calc_all , one_jump_mu , two_jumps_mu , 
					angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD ,
					angular_densities_NBMEs_one_jump_mu , angular_densities_TBMEs , angular_densities_NBMEs_two_jumps_mu , 
					density_NBMEs_one_jump_mu_no_phase_fixed_inSD , density_NBMEs_one_jump_mu , density_TBMEs , density_NBMEs_two_jumps_mu);

	  if (is_there_one_jump_calc_all)
	    {
	      bool is_there_one_jump_calc = false;
				
	      PSI_in_indices_pp_nn_fill (one_jump_mu , GSM_vector_helper_OUT , PSI_IN_indices_one_jump_mu , is_there_one_jump_calc);

	      if (is_there_one_jump_calc)
		densities_part_calc (one_jump_mu , is_configuration_accepted_tab , PSI_IN_indices_one_jump_mu , 
				     angular_densities_NBMEs_one_jump_mu , density_NBMEs_one_jump_mu , 
				     PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
	    }

	  if (are_there_two_jumps_calc_all)
	    {
	      bool are_there_two_jumps_calc = false;

	      PSI_in_indices_pp_nn_fill (two_jumps_mu , GSM_vector_helper_OUT , PSI_IN_indices_two_jumps_mu , are_there_two_jumps_calc);

	      if (are_there_two_jumps_calc)
		densities_part_calc (two_jumps_mu , is_configuration_accepted_tab , PSI_IN_indices_two_jumps_mu , 
				     angular_densities_NBMEs_two_jumps_mu , density_NBMEs_two_jumps_mu , 
				     PSI_OUT_component_TRS_factor , PSI_IN , angular_densities_part_tab , density_part_tab);
	    }
	}
    }
  
  for (unsigned int i = 0 ; i < NUMBER_OF_THREADS ; i++)
    {
      angular_densities_tab += angular_densities_part_tabs(i);
      
      density_tab += density_part_tabs(i);
    }
}










void correlation_density::pn_calc_one_pair (
					    const bool is_it_HO_expansion , 
					    const class interaction_class &inter_data , 
					    const class array<TYPE> &rk_OBMEs_p , 
					    const class array<TYPE> &rk_OBMEs_n , 
					    const class array<double> &theta12_Dirac_multipolar_tab , 
					    const class lm_table<unsigned int> &lm_indices , 
					    const class ljm_table<unsigned int> &ljm_indices , 
					    const class array<double> &Ylm_table_coupled_to_l , 
					    const class array<double> &Ylm_table_coupled_to_j , 
					    const class array<double> &CGs , 
					    const class GSM_vector &PSI_IN ,
					    const class GSM_vector &PSI_OUT , 
					    class array<TYPE> &angular_densities_pp_tab , 
					    class array<TYPE> &angular_densities_nn_tab , 
					    class array<TYPE> &angular_densities_pn_tab , 
					    class array<TYPE> &density_pp_tab , 
					    class array<TYPE> &density_nn_tab , 
					    class array<TYPE> &density_pn_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
      
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_OUT.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  diagonal_part_pn_prot_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
				      Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pp_tab , density_pp_tab);
  
  diagonal_part_pn_neut_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
				      Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_nn_tab , density_nn_tab);
  
  if (NYval >= ZYval)
    diagonal_part_pn_part_pn_Nval_larger_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
						    Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);
  else
    diagonal_part_pn_part_pn_Zval_larger_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
						    Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);

  jumps_p_prot_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			     Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pp_tab , density_pp_tab);

  jumps_n_neut_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			     Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_nn_tab , density_nn_tab);

  one_jump_p_pn_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			      Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);

  one_jump_n_pn_part_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			      Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);

  if (NYval >= ZYval)
    two_jumps_pn_part_pn_Nval_larger_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
						Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);
  else
    two_jumps_pn_part_pn_Zval_larger_calc (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
						Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pn_tab , density_pn_tab);
}








void correlation_density::pp_nn_calc_one_pair (	
					       const bool is_it_HO_expansion , 
					       const class interaction_class &inter_data , 
					       const class array<TYPE> &rk_OBMEs , 
					       const class array<double> &theta12_Dirac_multipolar_tab , 
					       const class lm_table<unsigned int> &lm_indices , 
					       const class ljm_table<unsigned int> &ljm_indices , 
					       const class array<double> &Ylm_table_coupled_to_l , 
					       const class array<double> &Ylm_table_coupled_to_j , 
					       const class array<double> &CGs , 
					       const class GSM_vector &PSI_IN ,
					       const class GSM_vector &PSI_OUT , 
					       class array<TYPE> &angular_densities_tab , 
					       class array<TYPE> &density_tab)
{
  diagonal_part_pp_nn_calc (is_it_HO_expansion , inter_data , rk_OBMEs , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			    Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_tab , density_tab);

  jumps_part_pp_nn_calc (is_it_HO_expansion , inter_data , rk_OBMEs , theta12_Dirac_multipolar_tab , lm_indices , ljm_indices ,
			 Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_tab , density_tab);
}











void correlation_density::calc_one_pair (
					 const bool is_it_radial ,
					 const bool is_it_Gauss_Legendre ,
					 const bool is_it_HO_expansion , 
					 const class interaction_class &inter_data , 
					 const class GSM_vector &PSI_IN ,
					 const class GSM_vector &PSI_OUT , 
					 const class array<double> &theta12_Dirac_multipolar_tab , 
					 const class lm_table<unsigned int> &lm_indices , 
					 const class ljm_table<unsigned int> &ljm_indices , 
					 const class array<double> &Ylm_table_coupled_to_l , 
					 const class array<double> &Ylm_table_coupled_to_j , 
					 const class array<double> &CGs , 
					 class baryons_data &prot_Y_data , 
					 class baryons_data &neut_Y_data , 
					 class array<TYPE> &angular_densities_pp_tab , 
					 class array<TYPE> &angular_densities_nn_tab , 
					 class array<TYPE> &angular_densities_pn_tab , 
					 class array<TYPE> &density_pp_tab , 
					 class array<TYPE> &density_nn_tab , 
					 class array<TYPE> &density_pn_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_IN  = PSI_IN.get_GSM_vector_helper ();
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
  
  const unsigned int BP_IN  = GSM_vector_helper_IN.get_BP ();
  const unsigned int BP_OUT = GSM_vector_helper_OUT.get_BP ();

  if (BP_OUT != BP_IN) return;
  
  const int S_IN  = GSM_vector_helper_IN.get_S ();
  const int S_OUT = GSM_vector_helper_OUT.get_S ();
  
  if (S_IN != S_OUT) return;
  
  const int iM_IN  = GSM_vector_helper_IN.get_iM ();
  const int iM_OUT = GSM_vector_helper_OUT.get_iM ();
  
  if (iM_OUT != iM_IN) return;
  
  const enum space_type space = GSM_vector_helper_OUT.get_space ();  
   
  const class GSM_vector_helper_class dummy_helper;
    
  const unsigned int Np_nlj = prot_Y_data.get_N_nlj_baryon ();
  const unsigned int Nn_nlj = neut_Y_data.get_N_nlj_baryon ();
  
  const unsigned int N_RKmax = max (max (density_pp_tab.dimension (0) , density_nn_tab.dimension (0)) , density_pn_tab.dimension (0));
    
  class array<TYPE> rk_OBMEs_p(Np_nlj , Np_nlj , N_RKmax);
  class array<TYPE> rk_OBMEs_n(Nn_nlj , Nn_nlj , N_RKmax);

  if (space != NEUT_Y_ONLY) radial_OBMEs_calc (is_it_radial , is_it_Gauss_Legendre , prot_Y_data , rk_OBMEs_p);
  if (space != PROT_Y_ONLY) radial_OBMEs_calc (is_it_radial , is_it_Gauss_Legendre , neut_Y_data , rk_OBMEs_n);

  configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , false , false , false , false , false , GSM_vector_helper_OUT , GSM_vector_helper_OUT , dummy_helper , prot_Y_data , neut_Y_data);

  angular_densities_pp_tab = 0.0;
  angular_densities_nn_tab = 0.0;
  angular_densities_pn_tab = 0.0;

  density_pp_tab = 0.0;  
  density_nn_tab = 0.0;  
  density_pn_tab = 0.0;  

  switch (space)
    {
    case PROT_Y_ONLY:
      pp_nn_calc_one_pair (is_it_HO_expansion , inter_data , rk_OBMEs_p , theta12_Dirac_multipolar_tab ,
			   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_pp_tab , density_pp_tab); break;

    case NEUT_Y_ONLY:
      pp_nn_calc_one_pair (is_it_HO_expansion , inter_data , rk_OBMEs_n , theta12_Dirac_multipolar_tab ,
			   lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT , angular_densities_nn_tab , density_nn_tab); break;

    case PROT_NEUT_Y:
      pn_calc_one_pair (is_it_HO_expansion , inter_data , rk_OBMEs_p , rk_OBMEs_n , theta12_Dirac_multipolar_tab ,
			lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , PSI_IN , PSI_OUT ,
			angular_densities_pp_tab , angular_densities_nn_tab , angular_densities_pn_tab , density_pp_tab , density_nn_tab , density_pn_tab); break;

    default: abort_all ();
    }
  
#ifdef UseMPI
    
  if (is_it_MPI_parallelized)
    {
      MPI_helper::Barrier ();
      
      angular_densities_pp_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      angular_densities_nn_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      angular_densities_pn_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      
      density_pp_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      density_nn_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
      density_pn_tab.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
    }

#endif
}








void correlation_density::calc_store_one_pair (
					       const bool is_it_radial ,
					       const bool is_it_Gauss_Legendre , 
					       const bool is_it_HO_expansion , 
					       const class interaction_class &inter_data ,  
					       const class array<double> &rk_tab ,
					       const class array<double> &theta_tab ,
					       const class correlated_state_str &PSI_qn , 
					       const class GSM_vector &PSI ,
					       class baryons_data &prot_Y_data , 
					       class baryons_data &neut_Y_data) 
{
  const unsigned int N_RKmax = rk_tab.dimension (0);

  const unsigned int theta_number = theta_tab.dimension (0);

  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();

  const int Aval = ZYval + NYval;
  
  const int lp_max = prot_Y_data.get_lmax ();
  const int ln_max = neut_Y_data.get_lmax ();

  const int lmax = max (lp_max , ln_max);

  const int two_lmax = 2*lmax;

  const int two_lmax_plus_one = two_lmax + 1;

  const double m_max = lmax + 0.5;

  const unsigned int lm_number = lm_number_calc (lmax);

  const unsigned int ljm_number = ljm_number_calc (lmax);

  class lm_table<unsigned int> lm_indices(lmax);

  class array<class lm_struct> lm_qn_table(lm_number);

  lm_quantum_numbers_indices_fill (NO_PARTICLE , lm_qn_table , lm_indices);

  class ljm_table<unsigned int> ljm_indices(0.5 , lmax , m_max);

  class array<class ljm_struct> ljm_qn_table(ljm_number);

  ljm_quantum_numbers_indices_fill (NO_PARTICLE , ljm_qn_table , ljm_indices);

  class array<double> Ylm_table_coupled_to_l(two_lmax_plus_one , lm_number , lm_number);
  class array<double> Ylm_table_coupled_to_j(two_lmax_plus_one , ljm_number , ljm_number);

  Ylm_table_coupled_to_l_calc (lm_qn_table , Ylm_table_coupled_to_l);
  
  Ylm_table_coupled_to_j_calc (ljm_qn_table , Ylm_table_coupled_to_j);

  class array<double> CGs(lm_number , 2 , ljm_number);

  CGs_lj_coupling_calc (lm_qn_table , ljm_indices , CGs);

  class array<double> theta12_Dirac_multipolar_tab(two_lmax_plus_one , theta_number);

  theta12_Dirac_multipolar_calc (theta_tab , theta12_Dirac_multipolar_tab);

  class array<TYPE> angular_densities_pp_tab(2 , theta_number);
  class array<TYPE> angular_densities_nn_tab(2 , theta_number);
  class array<TYPE> angular_densities_pn_tab(2 , theta_number);

  class array<TYPE> density_pp_tab(N_RKmax , theta_number);
  class array<TYPE> density_nn_tab(N_RKmax , theta_number);
  class array<TYPE> density_pn_tab(N_RKmax , theta_number);

  calc_one_pair (is_it_radial , is_it_Gauss_Legendre , is_it_HO_expansion , inter_data , PSI , PSI , theta12_Dirac_multipolar_tab ,
		 lm_indices , ljm_indices , Ylm_table_coupled_to_l , Ylm_table_coupled_to_j , CGs , prot_Y_data , neut_Y_data ,
		 angular_densities_pp_tab , angular_densities_nn_tab , angular_densities_pn_tab , density_pp_tab , density_nn_tab , density_pn_tab);

  const class array<TYPE> angular_densities_tab = angular_densities_pp_tab + angular_densities_nn_tab + angular_densities_pn_tab;

  const class array<TYPE> density_tab = density_pp_tab + density_nn_tab + density_pn_tab;
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

      if ((ZYval >= 1) && (NYval >= 1) && (Aval >= 3))
        {
	  if (ZYval >= 2) correlation_density_files_store (is_it_radial , PSI_qn_string , "pp" , rk_tab , theta_tab , angular_densities_pp_tab , density_pp_tab);
	  if (NYval >= 2) correlation_density_files_store (is_it_radial , PSI_qn_string , "nn" , rk_tab , theta_tab , angular_densities_nn_tab , density_nn_tab);
	  
	  if ((ZYval >= 1) && (NYval >= 1)) correlation_density_files_store (is_it_radial , PSI_qn_string , "pn" , rk_tab , theta_tab , angular_densities_pn_tab , density_pn_tab);
	}

      correlation_density_files_store (is_it_radial , PSI_qn_string , "total" , rk_tab , theta_tab , angular_densities_tab , density_tab);
      
      class array<TYPE> angular_density_tab(theta_number);
        
      for (unsigned int it = 0 ; it < theta_number ; it++) angular_density_tab(it) = angular_densities_tab(0 , it) + angular_densities_tab(1 , it);
  
      if (theta_number >= 2)
	{
	  const TYPE angular_density_norm_test = angular_density_norm_with_splines (theta_tab , angular_density_tab);
      
	  cout << "Angular density norm (from splines) : " << angular_density_norm_test << endl;
	}
    }
}






void correlation_density::calc_store (
				      const class input_data_str &input_data , 
				      const class interaction_class &inter_data , 
				      const class array<class correlated_state_str> &PSI_qn_tab , 
				      class baryons_data &prot_Y_data , 
				      class baryons_data &neut_Y_data) 
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Correlation densities" << endl;
      cout <<         "---------------------" << endl << endl;
    }

  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();
  
  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int Z = prot_Y_data.get_N_nucleons ();
  const int N = neut_Y_data.get_N_nucleons ();
  
  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();

  const int n_holes_max = input_data.get_n_holes_max ();
  
  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int n_scat_max = input_data.get_n_scat_max ();
    
  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const int E_max_hw = input_data.get_E_max_hw ();

  const int Strangeness = input_data.get_hypernucleus_strangeness ();
    
  const unsigned int theta_number = input_data.get_correlation_density_theta_number ();

  const bool is_correlation_density_theta_value_imposed = input_data.get_is_correlation_density_theta_value_imposed ();
  
  const double correlation_density_imposed_theta_value = input_data.get_correlation_density_imposed_theta_value ();
  
  const unsigned int correlation_density_number = input_data.get_correlation_density_number ();

  const class array<unsigned int> &correlation_density_BP_tab = input_data.get_correlation_density_BP_tab ();

  const class array<double> &correlation_density_J_tab = input_data.get_correlation_density_J_tab ();
  
  const class array<double> &correlation_density_RKmax_tab = input_data.get_correlation_density_RKmax_tab ();

  const class array<unsigned int> &correlation_density_vector_index_tab = input_data.get_correlation_density_vector_index_tab ();

  const class array<bool> &correlation_density_is_it_radial_tab = input_data.get_correlation_density_is_it_radial_tab ();
  
  const class array<bool> &correlation_density_is_it_Gauss_Legendre_tab = input_data.get_correlation_density_is_it_Gauss_Legendre_tab ();

  const class array<bool> &correlation_density_is_it_HO_expansion_tab = input_data.get_correlation_density_is_it_HO_expansion_tab ();

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL = input_data.get_Nk_momentum_GL ();
  
  const unsigned int Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();

  const double R = input_data.get_R ();
  
  const double kmax_momentum = input_data.get_kmax_momentum ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  const double step_momentum_uniform = input_data.get_step_momentum_uniform ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class array<double> k_tab_GL(Nk_momentum_GL);
  class array<double> wk_tab_GL(Nk_momentum_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  class array<double> k_tab_uniform(Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;
  
  class array<double> theta_tab_GL(theta_number);
  class array<double> w_theta_tab_GL(theta_number);
  
  class array<double> theta_tab_uniform(theta_number);

  if (is_correlation_density_theta_value_imposed)
    {
      theta_tab_GL(0) = theta_tab_uniform(0) = correlation_density_imposed_theta_value;

      w_theta_tab_GL(0) = 1.0;
    }
  else
    {
      const double step_theta_uniform = M_PI/static_cast<double> (theta_number - 1);
  
      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , M_PI , theta_tab_GL , w_theta_tab_GL);
  
      for (unsigned int it = 0 ; it < theta_number ; it++) theta_tab_uniform(it) = it*step_theta_uniform;
    }
  
  for (unsigned int correlation_density_index = 0 ; correlation_density_index < correlation_density_number ; correlation_density_index++)
    {
      const unsigned int BP = correlation_density_BP_tab(correlation_density_index);

      const unsigned int vector_index = correlation_density_vector_index_tab(correlation_density_index);

      const double J = correlation_density_J_tab(correlation_density_index);
      
      const double RKmax = correlation_density_RKmax_tab(correlation_density_index);

      const double M = J;

      const bool is_it_radial = correlation_density_is_it_radial_tab(correlation_density_index);
      
      const bool is_it_Gauss_Legendre = correlation_density_is_it_Gauss_Legendre_tab(correlation_density_index);

      const bool is_it_HO_expansion = correlation_density_is_it_HO_expansion_tab(correlation_density_index);

      const class correlated_state_str PSI_qn = PSI_quantum_numbers_find (Z , N , BP , Strangeness , J , vector_index , PSI_qn_tab);

      class GSM_vector_helper_class GSM_vector_helper(space , inter , truncation_hw , truncation_ph ,
						      n_holes_max   , n_scat_max   , E_max_hw  ,
						      n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						      n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP , M , true);
      
      class GSM_vector PSI(GSM_vector_helper);
      
      PSI.eigenvector_read_disk (PSI_qn);
      
      const class array<double> &theta_tab = (is_it_Gauss_Legendre) ? (theta_tab_GL) : (theta_tab_uniform);
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);
      
      const class array<double> &rk_tab_init = (is_it_radial) ? (r_bef_R_tab) : (k_tab);

      const unsigned int iRK_closest = rk_tab_init.closest_value_index_determine (RKmax);
      
      const unsigned int N_RKmax = (rk_tab_init(iRK_closest) > RKmax) ? (iRK_closest) : (iRK_closest + 1);

      const string radial_momentum_str = (is_it_radial) ? ("Radial") : ("Momentum");
      
      if (N_RKmax > 0)
	{
	  class array<double> rk_tab(N_RKmax);

	  for (unsigned int i = 0 ; i < N_RKmax ; i++) rk_tab(i) = rk_tab_init(i);
	  
	  calc_store_one_pair (is_it_radial , is_it_Gauss_Legendre , is_it_HO_expansion , inter_data , rk_tab , theta_tab , PSI_qn , PSI , prot_Y_data , neut_Y_data);
	  
	  if (THIS_PROCESS == MASTER_PROCESS)	      
	    cout << radial_momentum_str << " correlation density of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated." << endl << endl;
	}
      else if (THIS_PROCESS == MASTER_PROCESS)
	cout << radial_momentum_str << " correlation density of " << J_Pi_vector_index_string (BP , J , vector_index) << " not calculated: no points on grid" << endl << endl;
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}

