#include "../GSM_include/GSM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;
using namespace configuration_one_jump_construction_set;
using namespace configuration_SD_in_space_one_jump;
using namespace SD_one_jump_construction_set;


// TYPE is double or complex
// -------------------------


// Same as in GSM_configuration_SD_in_space_one_jump.cpp, except that it is done in the context of MSDHF, when one single configuration is used in shell model calculations to generate MSDHF potentials.
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



void configuration_SD_in_space_one_jump_only_basis::is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (
															   const class GSM_vector_helper_one_configuration_class &GSM_vector_helper , 
															   class baryons_data &particles_data)
{
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();

  if (space_dimension == 0) return;

  const unsigned int BP = particles_data.get_BP_one_configuration ();
  const unsigned int iC = particles_data.get_iC_one_configuration ();
  
  const int iM = GSM_vector_helper.get_iM ();
  
  const int TRS_iM = GSM_vector_helper.get_TRS_iM ();

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SD_set = particles_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = particles_data.get_SD_TRS_indices ();

  class array<bool> &BPin_Sin_Nspec_in_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();

  class array<bool> &BPin_Sin_Nspec_in_iMin_for_one_jump_tab = particles_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();
  
  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_in_in_space_tab  = particles_data.get_is_configuration_in_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC<bool> &is_configuration_out_in_space_tab = particles_data.get_is_configuration_out_in_space_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSD_in_space_tab  = particles_data.get_is_inSD_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSD_in_space_tab = particles_data.get_is_outSD_in_space_tab ();

  const unsigned int dimension_SD_set = dimensions_SD_set(BP , 0 , 0 , 0 , iC , iM);

  BPin_Sin_Nspec_in_for_one_jump_tab(BP , 0 , 0) = true;
  
  BPin_Sin_Nspec_in_iMin_for_one_jump_tab(BP , 0 , 0 , iM) = true;

  is_configuration_in_in_space_tab (BP , 0 , 0 , 0 , iC) = true;
  is_configuration_out_in_space_tab(BP , 0 , 0 , 0 , iC) = true;

  const unsigned int SD_TRS_indices_zero_index = SD_TRS_indices.index_determine (BP , 0 , 0 , 0 , iC , iM , 0);
  
  const unsigned int is_inSD_in_space_tab_zero_index = is_inSD_in_space_tab.index_determine (BP , 0 , 0 , 0 , iC , iM , 0);

  const unsigned int is_inSD_in_space_tab_TRS_zero_index = is_inSD_in_space_tab.index_determine (BP , 0 , 0 , 0 , iC , TRS_iM , 0);

  const unsigned int is_outSD_in_space_tab_zero_index = is_outSD_in_space_tab.index_determine (BP , 0 , 0 , 0 , iC , iM , 0);

  const unsigned int is_outSD_in_space_tab_TRS_zero_index = is_outSD_in_space_tab.index_determine (BP , 0 , 0 , 0 , iC , TRS_iM , 0);
	      
  for (unsigned int SD_index = 0 ; SD_index < dimension_SD_set ; SD_index++)
    {
      const unsigned int is_inSD_in_space_tab_index  = is_inSD_in_space_tab_zero_index  + SD_index;
      const unsigned int is_outSD_in_space_tab_index = is_outSD_in_space_tab_zero_index + SD_index;
		      
      is_inSD_in_space_tab[is_inSD_in_space_tab_index]   = true;
      is_outSD_in_space_tab[is_outSD_in_space_tab_index] = true;
			  
      const unsigned int SD_TRS_indices_index = SD_TRS_indices_zero_index + SD_index;
      
      const unsigned int SD_TRS_index = SD_TRS_indices[SD_TRS_indices_index];
      
      const unsigned int is_inSD_in_space_tab_TRS_index  = is_inSD_in_space_tab_TRS_zero_index  + SD_TRS_index;
      const unsigned int is_outSD_in_space_tab_TRS_index = is_outSD_in_space_tab_TRS_zero_index + SD_TRS_index;
      
      is_inSD_in_space_tab[is_inSD_in_space_tab_TRS_index]   = true;
      is_outSD_in_space_tab[is_outSD_in_space_tab_TRS_index] = true;
    }
}




void configuration_SD_in_space_one_jump_only_basis::is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pn_determine (
															const class GSM_vector_helper_one_configuration_class &GSM_vector_helper , 
															class baryons_data &prot_data , 
															class baryons_data &neut_data)
{
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();

  if (space_dimension == 0) return;

  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = prot_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = neut_data.get_dimensions_SD_set ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = prot_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = neut_data.get_SD_TRS_indices ();

  const unsigned int BPp = prot_data.get_BP_one_configuration ();
  const unsigned int BPn = neut_data.get_BP_one_configuration ();
  
  const unsigned int iCp = prot_data.get_iC_one_configuration ();
  const unsigned int iCn = neut_data.get_iC_one_configuration ();
  
  const int iMp_max = prot_data.get_iM_max ();
  const int iMn_max = neut_data.get_iM_max ();
  
  const int iMp_min_M = GSM_vector_helper.get_iMp_min_M ();
  const int iMp_max_M = GSM_vector_helper.get_iMp_max_M ();

  const int iM = GSM_vector_helper.get_iM ();
  
  class array<bool> &prot_BPin_Sin_Nspec_in_for_one_jump_tab = prot_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();
  class array<bool> &neut_BPin_Sin_Nspec_in_for_one_jump_tab = neut_data.get_BPin_Sin_Nspec_in_for_one_jump_tab ();
  
  class array<bool> &prot_BPin_iMin_for_one_jump_tab = prot_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();
  class array<bool> &neut_BPin_iMin_for_one_jump_tab = neut_data.get_BPin_Sin_Nspec_in_iMin_for_one_jump_tab ();

  class array_BP_S_Nspec_Nscat_iC<bool> &is_prot_configuration_in_in_space_tab = prot_data.get_is_configuration_in_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC<bool> &is_neut_configuration_in_in_space_tab = neut_data.get_is_configuration_in_in_space_tab (0);
  
  class array_BP_S_Nspec_Nscat_iC<bool> &is_prot_configuration_out_in_space_tab = prot_data.get_is_configuration_out_in_space_tab ();
  class array_BP_S_Nspec_Nscat_iC<bool> &is_neut_configuration_out_in_space_tab = neut_data.get_is_configuration_out_in_space_tab ();
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSDp_in_space_tab = prot_data.get_is_inSD_in_space_tab (0);
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_inSDn_in_space_tab = neut_data.get_is_inSD_in_space_tab (0);
  
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSDp_in_space_tab = prot_data.get_is_outSD_in_space_tab ();
  class array_BP_S_Nspec_Nscat_iC_iM_SD<bool> &is_outSDn_in_space_tab = neut_data.get_is_outSD_in_space_tab ();

  prot_BPin_Sin_Nspec_in_for_one_jump_tab(BPp , 0 , 0) = true;
  neut_BPin_Sin_Nspec_in_for_one_jump_tab(BPn , 0 , 0) = true;

  is_prot_configuration_in_in_space_tab(BPp , 0 , 0 , 0 , iCp) = true;
  is_neut_configuration_in_in_space_tab(BPn , 0 , 0 , 0 , iCn) = true;
  
  is_prot_configuration_out_in_space_tab(BPp , 0 , 0 , 0 , iCp) = true;
  is_neut_configuration_out_in_space_tab(BPn , 0 , 0 , 0 , iCn) = true;

  for (int iMp = iMp_min_M ; iMp <= iMp_max_M ; iMp++)
    {
      const int iMn = iM - iMp;

      const int two_iMp = 2*iMp;
      const int two_iMn = 2*iMn;

      const int TRS_iMp = iMp_max - iMp;
      const int TRS_iMn = iMn_max - iMn;
      
      const unsigned int dimension_SDp = dimensions_SDp_set(BPp , 0 , 0 , 0 , iCp , iMp);
      const unsigned int dimension_SDn = dimensions_SDn_set(BPn , 0 , 0 , 0 , iCn , iMn);
      
      if ((dimension_SDn == 0) || (dimension_SDp == 0)) continue;

      (two_iMp >= iMp_max) ? (prot_BPin_iMin_for_one_jump_tab(BPp , 0 , 0 , iMp) = true) : (prot_BPin_iMin_for_one_jump_tab(BPp , 0 , 0 , TRS_iMp) = true);
      (two_iMn >= iMn_max) ? (neut_BPin_iMin_for_one_jump_tab(BPn , 0 , 0 , iMn) = true) : (neut_BPin_iMin_for_one_jump_tab(BPn , 0 , 0 , TRS_iMn) = true);

      const unsigned int SDp_TRS_indices_zero_index = SDp_TRS_indices.index_determine (BPp , 0 , 0 , 0 , iCp , iMp , 0);
      const unsigned int SDn_TRS_indices_zero_index = SDn_TRS_indices.index_determine (BPn , 0 , 0 , 0 , iCn , iMn , 0);
	      
      const unsigned int is_inSDp_in_space_tab_zero_index = is_inSDp_in_space_tab.index_determine (BPp , 0 , 0 , 0 , iCp , iMp , 0);
      const unsigned int is_inSDn_in_space_tab_zero_index = is_inSDn_in_space_tab.index_determine (BPn , 0 , 0 , 0 , iCn , iMn , 0);
				  
      const unsigned int is_inSDp_in_space_tab_TRS_zero_index = is_inSDp_in_space_tab.index_determine (BPp , 0 , 0 , 0 , iCp , TRS_iMp , 0);
      const unsigned int is_inSDn_in_space_tab_TRS_zero_index = is_inSDn_in_space_tab.index_determine (BPn , 0 , 0 , 0 , iCn , TRS_iMn , 0);
				  
      const unsigned int is_outSDp_in_space_tab_zero_index = is_outSDp_in_space_tab.index_determine (BPp , 0 , 0 , 0 , iCp , iMp , 0);
      const unsigned int is_outSDn_in_space_tab_zero_index = is_outSDn_in_space_tab.index_determine (BPn , 0 , 0 , 0 , iCn , iMn , 0);
				  
      const unsigned int is_outSDp_in_space_tab_TRS_zero_index = is_outSDp_in_space_tab.index_determine (BPp , 0 , 0 , 0 , iCp , TRS_iMp , 0);
      const unsigned int is_outSDn_in_space_tab_TRS_zero_index = is_outSDn_in_space_tab.index_determine (BPn , 0 , 0 , 0 , iCn , TRS_iMn , 0);
				  
      for (unsigned int SDp_index = 0 ; SDp_index < dimension_SDp ; SDp_index++)
	for (unsigned int SDn_index = 0 ; SDn_index < dimension_SDn ; SDn_index++)
	  {
	    const unsigned int is_inSDp_in_space_tab_index = is_inSDp_in_space_tab_zero_index + SDp_index;
	    const unsigned int is_inSDn_in_space_tab_index = is_inSDn_in_space_tab_zero_index + SDn_index;
	    
	    const unsigned int is_outSDp_in_space_tab_index = is_outSDp_in_space_tab_zero_index + SDp_index;
	    const unsigned int is_outSDn_in_space_tab_index = is_outSDn_in_space_tab_zero_index + SDn_index;
						  
	    is_inSDp_in_space_tab[is_inSDp_in_space_tab_index] = true;
	    is_inSDn_in_space_tab[is_inSDn_in_space_tab_index] = true;
	    
	    is_outSDp_in_space_tab[is_outSDp_in_space_tab_index] = true;
	    is_outSDn_in_space_tab[is_outSDn_in_space_tab_index] = true;
						  						  
	    const unsigned int SDp_TRS_indices_index = SDp_TRS_indices_zero_index + SDp_index;
	    const unsigned int SDn_TRS_indices_index = SDn_TRS_indices_zero_index + SDn_index;
						  
	    const unsigned int SDp_TRS_index = SDp_TRS_indices[SDp_TRS_indices_index];
	    const unsigned int SDn_TRS_index = SDn_TRS_indices[SDn_TRS_indices_index];
						  
	    const unsigned int is_inSDp_in_space_tab_TRS_index = is_inSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
	    const unsigned int is_inSDn_in_space_tab_TRS_index = is_inSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
						  
	    const unsigned int is_outSDp_in_space_tab_TRS_index = is_outSDp_in_space_tab_TRS_zero_index + SDp_TRS_index;
	    const unsigned int is_outSDn_in_space_tab_TRS_index = is_outSDn_in_space_tab_TRS_zero_index + SDn_TRS_index;
		      
	    is_inSDp_in_space_tab[is_inSDp_in_space_tab_TRS_index] = true;
	    is_inSDn_in_space_tab[is_inSDn_in_space_tab_TRS_index] = true;
	    
	    is_outSDp_in_space_tab[is_outSDp_in_space_tab_TRS_index] = true;
	    is_outSDn_in_space_tab[is_outSDn_in_space_tab_TRS_index] = true;
	  }
    }
}




void configuration_SD_in_space_one_jump_only_basis::one_jump_tables_alloc_calc_pp_nn (class baryons_data &particles_data)
{
  all_configurations_one_jump_all_configurations_alloc_calc (false , true , false , true , true , true , particles_data);

  is_it_configuration_inter_to_include_determine_all_configurations (true , particles_data);

  is_it_SD_inter_to_include_determine_all_SDs (true , particles_data);

  all_SDs_one_jump_all_SDs_alloc_calc (false , false , false , true , particles_data);
  
  all_SDs_one_jump_all_SDs_alloc_calc_Jpm (false , true , true , NADA , particles_data);
}




void configuration_SD_in_space_one_jump_only_basis::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
														 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
														 const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1 , 
														 class baryons_data &prot_data , 
														 class baryons_data &neut_data)
{
  const enum space_type space = GSM_vector_helper_M.get_space ();
  
  if (space != NEUT_Y_ONLY)
    {
      prot_data.configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (false);

      prot_data.configuration_SD_inter_to_include_tables_init (false);

      prot_data.configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (false);
    }

  if (space != PROT_Y_ONLY)
    {
      neut_data.configuration_SD_in_in_space_BPin_Sin_Nspec_in_iMin_tables_init (false);

      neut_data.configuration_SD_inter_to_include_tables_init (false);

      neut_data.configuration_SD_out_in_space_BPout_Sout_Nspec_out_iMout_tables_init (false);
    }

  switch (space)
    {
    case PROT_Y_ONLY:
      {
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (GSM_vector_helper_M   , prot_data);
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , prot_data);
      } break;

    case NEUT_Y_ONLY:	
      {
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (GSM_vector_helper_M   , neut_data);
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pp_nn_determine (GSM_vector_helper_Mp1 , neut_data);
      } break;

    case PROT_NEUT_Y:
      {
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pn_determine (GSM_vector_helper_M   , prot_data , neut_data);
	is_configuration_in_out_BPin_iMin_inSD_outSD_in_space_pn_determine (GSM_vector_helper_Mp1 , prot_data , neut_data);
      } break;

    default: abort_all ();
    }

  if (space != NEUT_Y_ONLY) one_jump_tables_alloc_calc_pp_nn (prot_data);
  if (space != PROT_Y_ONLY) one_jump_tables_alloc_calc_pp_nn (neut_data);
}



