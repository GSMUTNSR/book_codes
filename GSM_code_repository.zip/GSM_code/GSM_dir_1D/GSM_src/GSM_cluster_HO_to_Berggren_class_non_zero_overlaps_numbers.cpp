#include "../GSM_include/GSM_include_def.h"


using namespace inputs_misc;
using namespace GSM_vector_dimensions;
using namespace GSM_vector_NBMEs_handling;



// TYPE is double or complex
// -------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Routines of name ...pn... are for proton-neutron space only, and those of name ...pp_nn... take into account only valence protons and valence neutrons
// ------------------------------------------------------------------------------------------------------------------------------------------------------







// Calculation and storage of the number of non zero <SD-Berggren | SD-HO> matrix elements of the operator
// -------------------------------------------------------------------------------------------------------
// One loops over all out basis states |SD-Berggren>, and the proton and neutron overlap <SDp-Berggren | SDp-HO> and <SDn-Berggren | SDn-HO> are stored arrays.
// 
// One calculates the number of NBMEs <SD-Berggren | SD-HO> = <SDp-Berggren | SDp-HO> (pp), <SD-Berggren | SD-HO> = <SDn-Berggren | SDn-HO> (nn),
// <SD-Berggren | SD-HO> = <SDp-Berggren | SDp-HO> . <SDn-Berggren | SDn-HO> (pn), and the index of |SD-HO> in the class.
//
// OpenMP parallelization is used therein, but not MPI. 
// Indeed, cluster wave functions are small, on the one hand, and these routines are used in MPI-distributed loops on the other hand.
// Hence, MPI parallelization has not been implemented.
//
// For the proton-neutron case, one routine is used if NYval >= ZYval, and another if not (see GSM_vector_dimensions.cpp).
// 
// One can calculate the proportion of non-zero NBMEs in percent, where one sums all matrix row numbers of non-zero NBMEs, multiply by &00 and divide the product of the GSM space dimensions of |Psi[HO-in]> and |Psi[Berggren-out]>.
//
// Time-reversal summetry (TRS) is used if both |Psi-HO> and cluster_HO_to_Berggren |Psi-HO> states have M=0.
 





void cluster_HO_to_Berggren_class::non_zero_overlaps_numbers_pn_Nval_larger_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO ();

  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();
    
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class baryons_data &cluster_prot_Y_data = cluster_data.get_cluster_prot_Y_data (); 
  const class baryons_data &cluster_neut_Y_data = cluster_data.get_cluster_neut_Y_data ();
  
  const class baryons_data &cluster_prot_Y_data_HO = cluster_data.get_cluster_prot_Y_data_HO (); 
  const class baryons_data &cluster_neut_Y_data_HO = cluster_data.get_cluster_neut_Y_data_HO ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();

  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_holes_max_p_HO = GSM_vector_helper_HO_in.get_n_holes_max_p ();
  const int n_holes_max_n_HO = GSM_vector_helper_HO_in.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();
  
  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p ();
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int n_scat_max_p_HO = GSM_vector_helper_HO_in.get_n_scat_max_p ();
  const int n_scat_max_n_HO = GSM_vector_helper_HO_in.get_n_scat_max_n ();
  
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const int Ep_max_hw_HO = GSM_vector_helper_HO_in.get_Ep_max_hw ();
  const int En_max_hw_HO = GSM_vector_helper_HO_in.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();

  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_out.get_iM ();

  const int iMn_min_M = GSM_vector_helper_out.get_iMn_min_M ();
  const int iMn_max_M = GSM_vector_helper_out.get_iMn_max_M ();
      
  const int iMp_max = cluster_prot_Y_data.get_iM_max ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = cluster_prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = cluster_neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
    
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDp_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDp_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = cluster_prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = cluster_neut_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = cluster_prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = cluster_neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = cluster_prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = cluster_neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table_HO_p = cluster_prot_Y_data_HO.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table_HO_n = cluster_neut_Y_data_HO.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table_HO = cluster_prot_Y_data_HO.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table_HO = cluster_neut_Y_data_HO.get_E_hw_table ();  
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SDp_HO_Berggren_overlaps_table = cluster_prot_Y_data.get_dimensions_SD_HO_Berggren_overlaps_table ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SDn_HO_Berggren_overlaps_table = cluster_neut_Y_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  const class array_of_SD_HO_Berggren_overlaps_data_str &SDp_HO_Berggren_overlaps_table = cluster_prot_Y_data.get_SD_HO_Berggren_overlaps_table ();
  const class array_of_SD_HO_Berggren_overlaps_data_str &SDn_HO_Berggren_overlaps_table = cluster_neut_Y_data.get_SD_HO_Berggren_overlaps_table ();

  const class array<unsigned int> &iCp_out_min_tab = GSM_vector_helper_out.get_iCp_min_tab ();
  const class array<unsigned int> &iCp_out_max_tab = GSM_vector_helper_out.get_iCp_max_tab ();
    
  const class array<class SD_quantum_numbers> &SDn_quantum_numbers_tab = cluster_neut_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned int total_outSDn_index_min = GSM_vector_helper_out.get_total_SDn_index_min ();
  const unsigned int total_outSDn_index_max = GSM_vector_helper_out.get_total_SDn_index_max ();
  
  if (total_outSDn_index_min > total_outSDn_index_max) return;
    
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSDn_index = total_outSDn_index_min ; total_outSDn_index <= total_outSDn_index_max ; total_outSDn_index++)
    {
      const class SD_quantum_numbers &outSDn_qn = SDn_quantum_numbers_tab(total_outSDn_index);

      const int iMn = outSDn_qn.get_iM ();
      
      if ((iMn < iMn_min_M) || (iMn > iMn_max_M)) continue;
      
      const unsigned int BPn = outSDn_qn.get_BP ();

      const int Sn = outSDn_qn.get_S ();
      
      const int n_spec_n = outSDn_qn.get_n_spec ();
      
      const unsigned int BPp = binary_parity_product (BPn , BP);

      const int Sp = S - Sn;
      
      const int n_spec_p = n_spec_max - n_spec_n;
      
      const int n_scat_n_out = outSDn_qn.get_n_scat ();
	
      const unsigned int iCn_out = outSDn_qn.get_iC ();

      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
 
      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;

      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (dimension_outSDn == 0) continue;
		  
      const bool all_dimensions_SDp_zero = all_dimensions_SDp_zero_tab(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

      if (all_dimensions_SDp_zero) continue;
		  
      const unsigned int outSDn_index = outSDn_qn.get_SD_index ();
            
      const int iMp = iM - iMn;
      
      const int TRS_iMp = iMp_max - iMp;
      
      const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index)) : (NADA);
            
      for (int n_scat_p_out = 0 ; n_scat_p_out <= n_scat_max_p ; n_scat_p_out++)
	{	  
	  const unsigned int iCp_out_min = iCp_out_min_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  const unsigned int iCp_out_max = iCp_out_max_tab(BPp , Sp , n_spec_p , n_scat_p_out);
	  
	  for (unsigned int iCp_out = iCp_out_min ; iCp_out <= iCp_out_max ; iCp_out++)
	    {
	      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
	      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

	      if (dimension_outSDp == 0) continue;
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp);
	          
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + outSDn_index;
	      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_out(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp)) : (NADA);
				  
	      const unsigned int total_outSDp_TRS_indices_zero_index = (is_it_TRS) ? (SDp_TRS_indices.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , 0)) : (NADA);
				      
	      const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + outSDn_TRS_index) : (NADA);
				      
	      for (unsigned int outSDp_index = 0 ; outSDp_index < dimension_outSDp ; outSDp_index++)
		{
		  const unsigned int PSI_out_index = PSI_out_index_zero + outSDp_index*dimension_outSDn;
      
		  const unsigned int total_outSDp_TRS_indices_index = (is_it_TRS) ? (total_outSDp_TRS_indices_zero_index + outSDp_index) : (NADA);
		  const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices[total_outSDp_TRS_indices_index]) : (NADA);
					      
		  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
		  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
		    {		      
		      const unsigned int dimension_SDp_HO_Berggren_overlaps = dimensions_SDp_HO_Berggren_overlaps_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index);
		      const unsigned int dimension_SDn_HO_Berggren_overlaps = dimensions_SDn_HO_Berggren_overlaps_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index);

		      const unsigned int SDp_HO_Berggren_overlaps_debut_index = SDp_HO_Berggren_overlaps_table.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , 0);
		      const unsigned int SDn_HO_Berggren_overlaps_debut_index = SDn_HO_Berggren_overlaps_table.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , 0);

		      unsigned int row_non_zero_overlaps_component_part = 0;
						  
		      for (unsigned int ip = 0 ; ip < dimension_SDp_HO_Berggren_overlaps ; ip++)
			{
			  const unsigned int SDp_HO_Berggren_overlaps_data_index = SDp_HO_Berggren_overlaps_debut_index + ip;

			  const class SD_HO_Berggren_overlaps_data_str &SDp_HO_Berggren_overlaps_data = SDp_HO_Berggren_overlaps_table[SDp_HO_Berggren_overlaps_data_index];

			  const int n_scat_p_HO_in = SDp_HO_Berggren_overlaps_data.get_n_scat_HO ();

			  const unsigned int iCp_HO_in = SDp_HO_Berggren_overlaps_data.get_iC_HO ();

			  const int Ep_hw_HO_in = Ep_hw_table_HO(BPp , Sp , n_spec_p , n_scat_p_HO_in , iCp_HO_in);
			  
			  const int n_holes_p_HO_in = n_holes_table_HO_p(BPp , Sp , n_spec_p , n_scat_p_HO_in , iCp_HO_in);

			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO)) continue;
	      
			  for (unsigned int in = 0 ; in < dimension_SDn_HO_Berggren_overlaps ; in++)
			    {
			      const unsigned int SDn_HO_Berggren_overlaps_data_index = SDn_HO_Berggren_overlaps_debut_index + in;

			      const class SD_HO_Berggren_overlaps_data_str &SDn_HO_Berggren_overlaps_data = SDn_HO_Berggren_overlaps_table[SDn_HO_Berggren_overlaps_data_index];

			      const int n_scat_n_HO_in = SDn_HO_Berggren_overlaps_data.get_n_scat_HO ();

			      const unsigned int iCn_HO_in = SDn_HO_Berggren_overlaps_data.get_iC_HO ();
																
			      const int En_hw_HO_in = En_hw_table_HO(BPn , Sn , n_spec_n , n_scat_n_HO_in , iCn_HO_in);
			      
			      const int n_holes_n_HO_in = n_holes_table_HO_n(BPn , Sn , n_spec_n , n_scat_n_HO_in , iCn_HO_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO)) continue;
			      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_HO , n_scat_max_HO , E_max_hw_HO)) continue;
			      
			      row_non_zero_overlaps_component_part++;				
			    }
			}
			      
		      rows_non_zero_overlaps_numbers(PSI_out_index) += row_non_zero_overlaps_component_part;
		    }}}}}
}
					












void cluster_HO_to_Berggren_class::non_zero_overlaps_numbers_pn_Zval_larger_calc_store ()
{  
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO ();
  
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();
    
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class baryons_data &cluster_prot_Y_data = cluster_data.get_cluster_prot_Y_data (); 
  const class baryons_data &cluster_neut_Y_data = cluster_data.get_cluster_neut_Y_data ();
  
  const class baryons_data &cluster_prot_Y_data_HO = cluster_data.get_cluster_prot_Y_data_HO (); 
  const class baryons_data &cluster_neut_Y_data_HO = cluster_data.get_cluster_neut_Y_data_HO ();
  
  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();

  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();
  
  const int n_holes_max_p = GSM_vector_helper_out.get_n_holes_max_p ();
  const int n_holes_max_n = GSM_vector_helper_out.get_n_holes_max_n ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();
  
  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n ();
  
  const int n_scat_max_p_HO = GSM_vector_helper_HO_in.get_n_scat_max_p ();
  const int n_scat_max_n_HO = GSM_vector_helper_HO_in.get_n_scat_max_n ();
  
  const int n_holes_max_p_HO = GSM_vector_helper_HO_in.get_n_holes_max_p ();
  const int n_holes_max_n_HO = GSM_vector_helper_HO_in.get_n_holes_max_n ();
  
  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();

  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const int Ep_max_hw = GSM_vector_helper_out.get_Ep_max_hw ();
  const int En_max_hw = GSM_vector_helper_out.get_En_max_hw ();
  
  const int Ep_max_hw_HO = GSM_vector_helper_HO_in.get_Ep_max_hw ();
  const int En_max_hw_HO = GSM_vector_helper_HO_in.get_En_max_hw ();
  
  const unsigned int BP = GSM_vector_helper_out.get_BP ();
  
  const int S = GSM_vector_helper_out.get_S ();
  
  const int n_spec_max = GSM_vector_helper_out.get_n_spec_max ();
  
  const int iM = GSM_vector_helper_out.get_iM ();
  
  const int iMp_min_M = GSM_vector_helper_out.get_iMp_min_M (); 
  const int iMp_max_M = GSM_vector_helper_out.get_iMp_max_M ();
  
  const int iMp_max = cluster_prot_Y_data.get_iM_max ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDp_TRS_indices = cluster_prot_Y_data.get_SD_TRS_indices ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SDn_TRS_indices = cluster_neut_Y_data.get_SD_TRS_indices ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector ();

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC<bool> &all_dimensions_SDn_zero_tab = GSM_vector_helper_out.get_all_dimensions_SDn_zero_tab ();
  
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDp_set = cluster_prot_Y_data.get_dimensions_SD_set ();
  const class array_BP_S_Nspec_Nscat_iC<unsigned int> &dimensions_SDn_set = cluster_neut_Y_data.get_dimensions_SD_set ();

  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_p_table = cluster_prot_Y_data.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_n_table = cluster_neut_Y_data.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table = cluster_prot_Y_data.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table = cluster_neut_Y_data.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table_HO_p = cluster_prot_Y_data_HO.get_n_holes_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table_HO_n = cluster_neut_Y_data_HO.get_n_holes_table ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &Ep_hw_table_HO = cluster_prot_Y_data_HO.get_E_hw_table ();
  const class array_BP_S_Nspec_Nscat_iC<int> &En_hw_table_HO = cluster_neut_Y_data_HO.get_E_hw_table ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SDp_HO_Berggren_overlaps_table = cluster_prot_Y_data.get_dimensions_SD_HO_Berggren_overlaps_table ();
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SDn_HO_Berggren_overlaps_table = cluster_neut_Y_data.get_dimensions_SD_HO_Berggren_overlaps_table ();

  const class array_of_SD_HO_Berggren_overlaps_data_str &SDp_HO_Berggren_overlaps_table = cluster_prot_Y_data.get_SD_HO_Berggren_overlaps_table ();
  const class array_of_SD_HO_Berggren_overlaps_data_str &SDn_HO_Berggren_overlaps_table = cluster_neut_Y_data.get_SD_HO_Berggren_overlaps_table ();
  
  const class array<unsigned int> &iCn_out_min_tab = GSM_vector_helper_out.get_iCn_min_tab ();
  const class array<unsigned int> &iCn_out_max_tab = GSM_vector_helper_out.get_iCn_max_tab ();
    
  const class array<class SD_quantum_numbers> &SDp_quantum_numbers_tab = cluster_prot_Y_data.get_SD_quantum_numbers_tab ();
  
  const unsigned int total_outSDp_index_min = GSM_vector_helper_out.get_total_SDp_index_min ();
  const unsigned int total_outSDp_index_max = GSM_vector_helper_out.get_total_SDp_index_max ();

  if (total_outSDp_index_min > total_outSDp_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSDp_index = total_outSDp_index_min ; total_outSDp_index <= total_outSDp_index_max ; total_outSDp_index++)
    {
      const class SD_quantum_numbers &outSDp_qn = SDp_quantum_numbers_tab(total_outSDp_index);

      const int iMp = outSDp_qn.get_iM ();

      if ((iMp < iMp_min_M) || (iMp > iMp_max_M)) continue;
      
      const unsigned int BPp = outSDp_qn.get_BP ();

      const int Sp = outSDp_qn.get_S ();
      
      const int n_spec_p = outSDp_qn.get_n_spec ();
      
      const unsigned int BPn = binary_parity_product (BPp , BP);

      const int Sn = S - Sp;
      
      const int n_spec_n = n_spec_max - n_spec_p;
      
      const int n_scat_p_out = outSDp_qn.get_n_scat ();
	
      const unsigned int iCp_out = outSDp_qn.get_iC ();

      const int n_holes_p_out = n_holes_p_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
	      
      const int Ep_hw_out = Ep_hw_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out);
      
      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_max_p , n_scat_max_p , Ep_max_hw)) continue;

      const unsigned int dimension_outSDp = dimensions_SDp_set(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (dimension_outSDp == 0) continue;
		  
      const bool all_dimensions_SDn_zero = all_dimensions_SDn_zero_tab(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp);

      if (all_dimensions_SDn_zero) continue;

      const int iMn = iM - iMp;

      const int TRS_iMp = iMp_max - iMp;

      const unsigned int outSDp_index = outSDp_qn.get_SD_index ();
      
      const unsigned int outSDp_TRS_index = (is_it_TRS) ? (SDp_TRS_indices(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index)) : (NADA);
      
      for (int n_scat_n_out = 0 ; n_scat_n_out <= n_scat_max_n ; n_scat_n_out++)
	{
	  const unsigned int iCn_out_min = iCn_out_min_tab(BPn , Sn , n_spec_n , n_scat_n_out);
	  const unsigned int iCn_out_max = iCn_out_max_tab(BPn , Sn , n_spec_n , n_scat_n_out);
		  
	  for (unsigned int iCn_out = iCn_out_min ; iCn_out <= iCn_out_max ; iCn_out++)
	    {      
	      const int n_holes_n_out = n_holes_n_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
 
	      const int En_hw_out = En_hw_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out);
	  
	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max_n , n_scat_max_n , En_max_hw)) continue;
      
	      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_out , n_scat_p_out , Ep_hw_out , n_holes_n_out , n_scat_n_out , En_hw_out , n_holes_max , n_scat_max , E_max_hw)) continue;

	      const unsigned int dimension_outSDn = dimensions_SDn_set(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn);

	      if (dimension_outSDn == 0) continue;
      
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_out = sum_dimensions_GSM_vector_out(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , iMp);
	      
	      const unsigned int PSI_out_index_zero = sum_dimensions_configuration_Mp_Mn_fixed_out + dimension_outSDn*outSDp_index;
	        
	      const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_out(BPp , Sp , n_spec_p , n_scat_p_out , n_scat_n_out , iCp_out , iCn_out , TRS_iMp)) : (NADA);
		  
	      const unsigned int total_outSDn_TRS_indices_zero_index = (is_it_TRS) ? (SDn_TRS_indices.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , 0)) : (NADA);
				      
	      const unsigned int TRS_PSI_out_index_zero = (is_it_TRS) ? (sum_dimensions_configuration_Mp_Mn_fixed_TRS_out + dimension_outSDn*outSDp_TRS_index) : (NADA);
		  
	      for (unsigned int outSDn_index = 0 ; outSDn_index < dimension_outSDn ; outSDn_index++)
		{      
		  const unsigned int PSI_out_index = PSI_out_index_zero + outSDn_index;

		  const unsigned int total_outSDn_TRS_indices_index = (is_it_TRS) ? (total_outSDn_TRS_indices_zero_index + outSDn_index) : (NADA);
		  
		  const unsigned int outSDn_TRS_index = (is_it_TRS) ? (SDn_TRS_indices[total_outSDn_TRS_indices_index]) : (NADA);
					      
		  const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (TRS_PSI_out_index_zero + outSDn_TRS_index) : (NADA);
      
		  if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
		    {	
		      const unsigned int dimension_SDp_HO_Berggren_overlaps = dimensions_SDp_HO_Berggren_overlaps_table(BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index);
		      const unsigned int dimension_SDn_HO_Berggren_overlaps = dimensions_SDn_HO_Berggren_overlaps_table(BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index);

		      const unsigned int SDp_HO_Berggren_overlaps_debut_index = SDp_HO_Berggren_overlaps_table.index_determine (BPp , Sp , n_spec_p , n_scat_p_out , iCp_out , iMp , outSDp_index , 0);
		      const unsigned int SDn_HO_Berggren_overlaps_debut_index = SDn_HO_Berggren_overlaps_table.index_determine (BPn , Sn , n_spec_n , n_scat_n_out , iCn_out , iMn , outSDn_index , 0);

		      unsigned int row_non_zero_overlaps_component_part = 0;			
			      
		      for (unsigned int ip = 0 ; ip < dimension_SDp_HO_Berggren_overlaps ; ip++)
			{
			  const unsigned int SDp_HO_Berggren_overlaps_data_index = SDp_HO_Berggren_overlaps_debut_index + ip;
			  
			  const class SD_HO_Berggren_overlaps_data_str &SDp_HO_Berggren_overlaps_data = SDp_HO_Berggren_overlaps_table[SDp_HO_Berggren_overlaps_data_index];
		      
			  const int n_scat_p_HO_in = SDp_HO_Berggren_overlaps_data.get_n_scat_HO ();

			  const unsigned int iCp_HO_in = SDp_HO_Berggren_overlaps_data.get_iC_HO ();

			  const int Ep_hw_HO_in = Ep_hw_table_HO(BPp , Sp , n_spec_p , n_scat_p_HO_in , iCp_HO_in);
				
			  const int n_holes_p_HO_in = n_holes_table_HO_p(BPp , Sp , n_spec_p , n_scat_p_HO_in , iCp_HO_in);
			  
			  if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_max_p_HO , n_scat_max_p_HO , Ep_max_hw_HO)) continue;
			  			  
			  for (unsigned int in = 0 ; in < dimension_SDn_HO_Berggren_overlaps ; in++)
			    {		      
			      const unsigned int SDn_HO_Berggren_overlaps_data_index = SDn_HO_Berggren_overlaps_debut_index + in;
				
			      const class SD_HO_Berggren_overlaps_data_str &SDn_HO_Berggren_overlaps_data = SDn_HO_Berggren_overlaps_table[SDn_HO_Berggren_overlaps_data_index];
		      
			      const int n_scat_n_HO_in = SDn_HO_Berggren_overlaps_data.get_n_scat_HO ();

			      const unsigned int iCn_HO_in = SDn_HO_Berggren_overlaps_data.get_iC_HO ();

			      const int En_hw_HO_in = En_hw_table_HO(BPn , Sn , n_spec_n , n_scat_n_HO_in , iCn_HO_in);

			      const int n_holes_n_HO_in = n_holes_table_HO_n(BPn , Sn , n_spec_n , n_scat_n_HO_in , iCn_HO_in);

			      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_n_HO , n_scat_max_n_HO , En_max_hw_HO)) continue;
			      
			      if (!is_basis_state_in_space_pn (truncation_hw , truncation_ph , n_holes_p_HO_in , n_scat_p_HO_in , Ep_hw_HO_in , n_holes_n_HO_in , n_scat_n_HO_in , En_hw_HO_in , n_holes_max_HO , n_scat_max_HO , E_max_hw_HO)) continue;

			      row_non_zero_overlaps_component_part++;
			    }
			}
			      
		      rows_non_zero_overlaps_numbers(PSI_out_index) += row_non_zero_overlaps_component_part;
		    }}}}}
}














void cluster_HO_to_Berggren_class::non_zero_overlaps_numbers_pp_nn_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();

  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO ();

  const bool truncation_hw = GSM_vector_helper_out.get_truncation_hw ();
  const bool truncation_ph = GSM_vector_helper_out.get_truncation_ph ();
  
  const int n_holes_max = GSM_vector_helper_out.get_n_holes_max ();
  
  const int n_scat_max = GSM_vector_helper_out.get_n_scat_max ();

  const int E_max_hw = GSM_vector_helper_out.get_E_max_hw ();
    
  const int n_holes_max_HO = GSM_vector_helper_HO_in.get_n_holes_max ();
  
  const int n_scat_max_HO = GSM_vector_helper_HO_in.get_n_scat_max ();

  const int E_max_hw_HO = GSM_vector_helper_HO_in.get_E_max_hw ();
  
  const enum space_type space = GSM_vector_helper_out.get_space ();
      
  const unsigned int BP = GSM_vector_helper_out.get_BP (); 

  const int S = GSM_vector_helper_out.get_S ();
    
  const int iM = GSM_vector_helper_out.get_iM ();
  
  const bool is_it_TRS_HO_in = GSM_vector_helper_HO_in.get_is_it_TRS ();

  const bool is_it_TRS_out = GSM_vector_helper_out.get_is_it_TRS ();

  const bool is_it_TRS = (is_it_TRS_HO_in && is_it_TRS_out);
  
  const class cluster_data &cluster_data = get_cluster_data ();
  
  const class baryons_data &cluster_prot_Y_data = cluster_data.get_cluster_prot_Y_data (); 
  const class baryons_data &cluster_neut_Y_data = cluster_data.get_cluster_neut_Y_data ();
  
  const class baryons_data &cluster_prot_Y_data_HO = cluster_data.get_cluster_prot_Y_data_HO (); 
  const class baryons_data &cluster_neut_Y_data_HO = cluster_data.get_cluster_neut_Y_data_HO ();
  
  const class baryons_data &cluster_particles_data = (space == PROT_Y_ONLY) ? (cluster_prot_Y_data) : (cluster_neut_Y_data);
  
  const class baryons_data &cluster_particles_data_HO = (space == PROT_Y_ONLY) ? (cluster_prot_Y_data_HO) : (cluster_neut_Y_data_HO);
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table_HO = cluster_particles_data_HO.get_n_holes_table ();

  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table_HO = cluster_particles_data_HO.get_E_hw_table ();
  
  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector (); 

  const class sum_GSM_vector_dimensions_class &sum_dimensions_GSM_vector_TRS_out = GSM_vector_helper_out.get_sum_dimensions_GSM_vector_TRS ();
  
  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &SD_TRS_indices = cluster_particles_data.get_SD_TRS_indices ();
  
  const class array_BP_S_Nspec_Nscat_iC<int> &n_holes_table = cluster_particles_data.get_n_holes_table ();

  const class array_BP_S_Nspec_Nscat_iC<int> &E_hw_table = cluster_particles_data.get_E_hw_table ();

  const class array_BP_S_Nspec_Nscat_iC_iM_SD<unsigned int> &dimensions_SD_HO_Berggren_overlaps_table = cluster_particles_data.get_dimensions_SD_HO_Berggren_overlaps_table ();	
  
  const class array_of_SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_table = cluster_particles_data.get_SD_HO_Berggren_overlaps_table ();
  
  const class array<class SD_quantum_numbers> &SD_quantum_numbers_tab = cluster_particles_data.get_SD_quantum_numbers_tab ();
  
  const unsigned int total_outSD_index_min = GSM_vector_helper_out.get_total_SD_index_min ();
  const unsigned int total_outSD_index_max = GSM_vector_helper_out.get_total_SD_index_max ();

  if (total_outSD_index_min > total_outSD_index_max) return;
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int total_outSD_index = total_outSD_index_min ; total_outSD_index <= total_outSD_index_max ; total_outSD_index++)
    {
      const class SD_quantum_numbers &outSD_qn = SD_quantum_numbers_tab(total_outSD_index);
 
      const int iM_out = outSD_qn.get_iM ();

      if (iM_out != iM) continue;

      const unsigned int BP_out = outSD_qn.get_BP ();

      if (BP_out != BP) continue;
      
      const int S_out = outSD_qn.get_S ();
  
      if (S_out != S) continue;
      
      const unsigned int n_scat_out = outSD_qn.get_n_scat ();

      const unsigned int iC_out = outSD_qn.get_iC ();

      const int n_holes_out = n_holes_table(BP , S , 0 , n_scat_out , iC_out);
      
      const int E_out_hw = E_hw_table(BP , S , 0 , n_scat_out , iC_out);

      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_out , n_scat_out , E_out_hw , n_holes_max , n_scat_max , E_max_hw)) continue;
      
      const unsigned int outSD_index = outSD_qn.get_SD_index ();

      const unsigned int sum_dimensions_configuration_fixed_out = sum_dimensions_GSM_vector_out(n_scat_out , iC_out);

      const unsigned int PSI_out_index = sum_dimensions_configuration_fixed_out + outSD_index;
      
      const unsigned int outSD_TRS_index = (is_it_TRS) ? (SD_TRS_indices(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index)) : (NADA);

      const unsigned int sum_dimensions_configuration_fixed_TRS_out = (is_it_TRS) ? (sum_dimensions_GSM_vector_TRS_out(n_scat_out , iC_out)) : (NADA);
      
      const unsigned int TRS_PSI_out_index = (is_it_TRS) ? (sum_dimensions_configuration_fixed_TRS_out + outSD_TRS_index) : (NADA);
      
      if (!is_it_TRS || (TRS_PSI_out_index >= PSI_out_index))
	{
	  const unsigned int dimension_SD_HO_Berggren_overlaps = dimensions_SD_HO_Berggren_overlaps_table(BP , S , 0 , n_scat_out , iC_out , iM , outSD_index);
  					   
	  const unsigned int SD_HO_Berggren_overlaps_debut_index = SD_HO_Berggren_overlaps_table.index_determine (BP , S , 0 , n_scat_out , iC_out , iM , outSD_index , 0);

	  for (unsigned int i = 0 ; i < dimension_SD_HO_Berggren_overlaps ; i++)
	    {
	      const unsigned int SD_HO_Berggren_overlaps_data_index = SD_HO_Berggren_overlaps_debut_index + i;

	      const class SD_HO_Berggren_overlaps_data_str &SD_HO_Berggren_overlaps_data = SD_HO_Berggren_overlaps_table[SD_HO_Berggren_overlaps_data_index];

	      const int n_scat_HO_in = SD_HO_Berggren_overlaps_data.get_n_scat_HO ();
				  
	      const unsigned int iC_HO_in = SD_HO_Berggren_overlaps_data.get_iC_HO ();

	      const int n_holes_HO_in = n_holes_table_HO(BP , S , 0 , n_scat_HO_in , iC_HO_in);
				      
	      const int E_HO_in_hw = E_hw_table_HO(BP , S , 0 , n_scat_HO_in , iC_HO_in);

	      if (!is_basis_state_in_space_pp_nn (truncation_hw , truncation_ph , n_holes_HO_in , n_scat_HO_in , E_HO_in_hw , n_holes_max_HO , n_scat_max_HO , E_max_hw_HO)) continue;
	      
	      rows_non_zero_overlaps_numbers(PSI_out_index)++;
	    }
	}
    }
}


void cluster_HO_to_Berggren_class::non_zero_overlaps_numbers_calc_store ()
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();
 
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  rows_non_zero_overlaps_numbers = 0;

  if (space == PROT_NEUT_Y)
    {
      const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
      const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
      const int ZYval = prot_Y_data.get_N_valence_baryons ();
      const int NYval = neut_Y_data.get_N_valence_baryons ();
      
      if (NYval >= ZYval)
	non_zero_overlaps_numbers_pn_Nval_larger_calc_store ();
      else
	non_zero_overlaps_numbers_pn_Zval_larger_calc_store ();
    }
  else
    non_zero_overlaps_numbers_pp_nn_calc_store ();
}

double cluster_HO_to_Berggren_class::non_zero_overlaps_proportion_calc () const
{
  const class GSM_vector_helper_class &GSM_vector_helper_HO_in = get_GSM_vector_helper_HO ();

  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper ();
      
  const double space_dimension_HO_in_double = GSM_vector_helper_HO_in.get_space_dimension ();

  const double space_dimension_out_double = GSM_vector_helper_out.get_space_dimension ();

  const double non_zero_overlaps = rows_non_zero_overlaps_numbers.sum ();
  
  const double non_zero_overlaps_proportion = 100.0*non_zero_overlaps/(space_dimension_out_double*space_dimension_HO_in_double);

  return non_zero_overlaps_proportion;
}


