#include "../GSM_include/GSM_include_def.h"

// TYPE is double or complex
// -------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------

// Class xH_one_configuration_plus_alpha_str is used only in closures and then is not commented.



// Class applying Hamiltonian plus number times identity to |Psi[in]> to obtain |Psi[out]> when only one configuration is occupied in basis space for MSDHF calculations
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
// In order to calculate the MSDHF potential, one has to diagonalize H on the MSDHF configuration, as its ground state is used in the HF-like formulas defining the MSDHF potential.
// As only one configuration occurs, it is much more efficient to recode H in this particular case, than to use the full H class of the general case.
//
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.H + b.
//
// Routines are rather straightforward so that they are not detailed. Only general explanations are given.
//
// Neither MPI nor OpenMP is used in this class, as parallelization is done an another level with MSDHF.
// It is done at level of the calculation of one-body scattering states, as they can be in large number, so that it is efficient for nodes to calculate them independently.
// Conversely, the space dimensions on one configuration are very small, so that a sequential calculation therein is efficient as well.
// Evidently, only full storage is used in this case, due to the very small dimensions involved.
// 
// print
// -----
// This routine prints non-zero Hamiltonian NBMEs on screen, It is typically used for tests.
// 
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + (H + alpha.Id).|Psi[in]>, where alpha is constant.
//
// TRS is time-reversal symmetry. It allows to calculate about one half of |Psi[out]>, while the rest is given from the first half up to a phase if M=0 in |Psi[in]> and |Psi[out]>.
// 
// The time taken for a Hamiltonian times vector operation can be printed on screen.
//
//
// xH_one_configuration_plus_alpha_str
// -----------------------------------
// Hpa must be understood here as H + alpha.Id (see above).
// Operators overloading of operations are of the type a.Hpa + b.Id, to which operators of the form c.Hpa + d.Id as well can be added. 
// One cannot add another operator to a.Hpa + b.Id besides c.Hpa + d.Id, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + c).Hpa + (b + d).Id .
// One can use instead (a*Hpa + b)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.
// Only operators when only one configuration is occupied in basis space for MSDHF calculations are considered.


H_one_configuration_class::H_one_configuration_class () :
  J (0.0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL)
{}
  
H_one_configuration_class::H_one_configuration_class (
						      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper ,
						      const class TBMEs_class &TBMEs_pn , 
						      const double J_c) :
  J (0.0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL)
{
  allocate (GSM_vector_helper , TBMEs_pn , J_c);
}

H_one_configuration_class::H_one_configuration_class (const class H_one_configuration_class &X) :
  J (0.0) ,
  GSM_vector_helper_ptr (NULL) , 
  TBMEs_pn_ptr (NULL)
{
  allocate_fill (X);
}
  
H_one_configuration_class::~H_one_configuration_class () {}

void H_one_configuration_class::allocate (
					  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper ,
					  const class TBMEs_class &TBMEs_pn , 
					  const double J_c)
{
  J = J_c;

  GSM_vector_helper_ptr = &GSM_vector_helper;

  TBMEs_pn_ptr = &TBMEs_pn;
  
  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();

  H_diagonal_tab.allocate (space_dimension);

  H_diagonal_tab = 0.0;

  const enum space_type space = GSM_vector_helper.get_space ();
  
  switch (space)
    {
    case PROT_Y_ONLY:
      {
	diagonal_part_pp_nn_calc ();
      } break;

    case NEUT_Y_ONLY:
      {
	diagonal_part_pp_nn_calc ();
      } break;

    case PROT_NEUT_Y:
      {
	diagonal_part_pn_p_part_calc ();
	diagonal_part_pn_n_part_calc ();
	
	diagonal_part_pn_pn_part_calc ();
      } break;

    default: abort_all ();
    }

  rows_non_zero_NBMEs_numbers.allocate (space_dimension);

  rows_non_zero_NBMEs_off_diagonal_numbers_calc ();
  
  const unsigned int rows_non_zero_NBMEs_number_max = rows_non_zero_NBMEs_numbers.max ();
  
  rows_non_zero_NBMEs_PSI_in_indices.allocate (space_dimension , rows_non_zero_NBMEs_number_max);

  rows_non_zero_NBMEs.allocate (space_dimension , rows_non_zero_NBMEs_number_max);
  
  matrix_off_diagonal_store ();
}







void H_one_configuration_class::allocate_fill (const class H_one_configuration_class &X)
{
  J = X.J;

  GSM_vector_helper_ptr = X.GSM_vector_helper_ptr;

  TBMEs_pn_ptr = X.TBMEs_pn_ptr;

  H_diagonal_tab.allocate_fill (X.H_diagonal_tab);

  rows_non_zero_NBMEs_numbers.allocate_fill (X.rows_non_zero_NBMEs_numbers);

  rows_non_zero_NBMEs_PSI_in_indices.allocate_fill (X.rows_non_zero_NBMEs_PSI_in_indices);

  rows_non_zero_NBMEs.allocate_fill (X.rows_non_zero_NBMEs);
}






void H_one_configuration_class::deallocate ()
{
  H_diagonal_tab.deallocate ();
  
  rows_non_zero_NBMEs_numbers.deallocate ();
      
  rows_non_zero_NBMEs_PSI_in_indices.deallocate ();

  rows_non_zero_NBMEs.deallocate ();
  
  J = 0.0;
  
  GSM_vector_helper_ptr = NULL;
  
  TBMEs_pn_ptr = NULL;
}

bool H_one_configuration_class::is_it_filled () const
{
  return H_diagonal_tab.is_it_filled ();
}

void H_one_configuration_class::apply_add (
					   const class GSM_vector_one_configuration &PSI_in , 
					   const TYPE &alpha , 
					   class GSM_vector_one_configuration &PSI_out) const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();
  
  if (!PSI_in.same_parity_M_projection (GSM_vector_helper)) return;
  if (!PSI_out.same_parity_M_projection (GSM_vector_helper)) return;
  
  const bool is_it_TRS = GSM_vector_helper.get_is_it_TRS ();

  PSI_out.diagonal_part_PSI_add (PSI_in , H_diagonal_tab , alpha); 

  apply_add_off_diagonal_full_storage (PSI_in , PSI_out);

  if (is_it_TRS) PSI_out.TRS_rest_part_fill (J);
}




void H_one_configuration_class::print () const
{
  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper = get_GSM_vector_helper ();

  const enum space_type space = GSM_vector_helper.get_space ();

  const unsigned int space_dimension = GSM_vector_helper.get_space_dimension ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper.get_neut_Y_data ();
   
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
  
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class Slater_determinant dummy_SD;

  const class GSM_vector_one_configuration V(GSM_vector_helper);

  class Slater_determinant inSDp(ZYval);
  class Slater_determinant inSDn(NYval);
  
  class Slater_determinant outSDp(ZYval);
  class Slater_determinant outSDn(NYval);

  for (unsigned int PSI_out_index = 0 ; PSI_out_index < space_dimension ; PSI_out_index++)
    {
      outSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_out_index);
      
      switch (space)
	{
	case PROT_Y_ONLY: 
	  {
	    cout << "inSD: "  , outSDp.print (phi_p_table);
	    cout << "outSD: " , outSDp.print (phi_p_table);
	  } break;

	case NEUT_Y_ONLY:
	  {
	    cout << "inSD: "  , outSDn.print (phi_n_table);
	    cout << "outSD: " , outSDn.print (phi_n_table);
	  } break;

	case PROT_NEUT_Y:
	  {
	    cout << "inSDp: "  , outSDp.print (phi_p_table);
	    cout << "inSDn: "  , outSDn.print (phi_n_table);

	    cout << "outSDp: " , outSDp.print (phi_p_table);
	    cout << "outSDn: " , outSDn.print (phi_n_table);
	  } break;

	default: abort_all ();
	}

      cout << "inSD index: " << PSI_out_index << " outSD index: " << PSI_out_index << " " << "NBME: " << H_diagonal_tab(PSI_out_index) << endl << endl;

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_number ; i++) 
	{
	  const unsigned int PSI_in_index = rows_non_zero_NBMEs_PSI_in_indices(PSI_out_index , i);
	  
	  const TYPE &NBME = rows_non_zero_NBMEs(PSI_out_index , i);

	  inSDp = (space != NEUT_Y_ONLY) ? (V.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	  inSDn = (space != PROT_Y_ONLY) ? (V.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);

	  switch (space)
	    {
	    case PROT_Y_ONLY: 
	      {
		cout << "inSD: "  , inSDp.print (phi_p_table);
		cout << "outSD: " , outSDp.print (phi_p_table);
	      } break;

	    case NEUT_Y_ONLY:
	      {
		cout << "inSD: "  , inSDn.print (phi_n_table);
		cout << "outSD: " , outSDn.print (phi_n_table);
	      } break;

	    case PROT_NEUT_Y:
	      {
		cout << "inSDp: "  , inSDp.print (phi_p_table);
		cout << "inSDn: "  , inSDn.print (phi_n_table);
		
		cout << "outSDp: " , outSDp.print (phi_p_table);
		cout << "outSDn: " , outSDn.print (phi_n_table);
	      } break;

	    default: abort_all ();
	    }

	  cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	}
    }
}







xH_one_configuration_plus_alpha_str::xH_one_configuration_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class H_one_configuration_class &H_c) : x (x_c) , alpha (alpha_c) , H (H_c) {}

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (1.0 , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (-1.0 , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H , const double alpha)
{
  return xH_one_configuration_plus_alpha_str (1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H , const double alpha)
{
  return xH_one_configuration_plus_alpha_str (1.0 , -alpha , H);
}

class xH_one_configuration_plus_alpha_str operator + (const double alpha , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator - (const double alpha , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (-1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator * (const class H_one_configuration_class &H , const double x)
{
  return xH_one_configuration_plus_alpha_str (x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator * (const double x , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator / (const class H_one_configuration_class &H , const double x)
{
  const double one_over_x = 1.0/x;

  return xH_one_configuration_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (Op.x , Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (-Op.x , -Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op , const double term)
{
  return xH_one_configuration_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op , const double term)
{
  return xH_one_configuration_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_one_configuration_plus_alpha_str operator + (const double term , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator - (const double term , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator * (const class xH_one_configuration_plus_alpha_str &Op , const double factor)
{
  return xH_one_configuration_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_one_configuration_plus_alpha_str operator / (const class xH_one_configuration_plus_alpha_str &Op , const double factor)
{
  return xH_one_configuration_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_one_configuration_plus_alpha_str operator * (const double factor , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#ifdef TYPEisDOUBLECOMPLEX

class xH_one_configuration_plus_alpha_str operator + (const class H_one_configuration_class &H , const complex<double> &alpha)
{
  return xH_one_configuration_plus_alpha_str (1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator - (const class H_one_configuration_class &H , const complex<double> &alpha)
{
  return xH_one_configuration_plus_alpha_str (1.0 , -alpha , H);
}

class xH_one_configuration_plus_alpha_str operator + (const complex<double> &alpha , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator - (const complex<double> &alpha , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (-1.0 , alpha , H);
}

class xH_one_configuration_plus_alpha_str operator * (const class H_one_configuration_class &H , const complex<double> &x)
{
  return xH_one_configuration_plus_alpha_str (x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator * (const complex<double> &x , const class H_one_configuration_class &H)
{
  return xH_one_configuration_plus_alpha_str (x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator / (const class H_one_configuration_class &H , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xH_one_configuration_plus_alpha_str (one_over_x , 0.0 , H);
}

class xH_one_configuration_plus_alpha_str operator + (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_one_configuration_plus_alpha_str (Op.x , Op.alpha + term , Op.H);
}

class xH_one_configuration_plus_alpha_str operator - (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &term)
{
  return xH_one_configuration_plus_alpha_str (Op.x , Op.alpha - term , Op.H);
}

class xH_one_configuration_plus_alpha_str operator + (const complex<double> &term , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (Op.x , term + Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator - (const complex<double> &term , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (-Op.x , term - Op.alpha , Op.H);
}

class xH_one_configuration_plus_alpha_str operator * (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_one_configuration_plus_alpha_str (Op.x*factor , Op.alpha*factor , Op.H);
}

class xH_one_configuration_plus_alpha_str operator / (const class xH_one_configuration_plus_alpha_str &Op , const complex<double> &factor)
{
  return xH_one_configuration_plus_alpha_str (Op.x/factor , Op.alpha/factor , Op.H);
}

class xH_one_configuration_plus_alpha_str operator * (const complex<double> &factor , const class xH_one_configuration_plus_alpha_str &Op)
{
  return xH_one_configuration_plus_alpha_str (factor*Op.x , factor*Op.alpha , Op.H);
}

#endif







double used_memory_calc (const class H_one_configuration_class &T)
{
  return (sizeof (T)/1000000.0 +
	  used_memory_calc (T.H_diagonal_tab) +
	  used_memory_calc (T.rows_non_zero_NBMEs_numbers) +
	  used_memory_calc (T.rows_non_zero_NBMEs_PSI_in_indices) +
	  used_memory_calc (T.rows_non_zero_NBMEs)
	  - (sizeof (T.H_diagonal_tab) +
	     sizeof (T.rows_non_zero_NBMEs_numbers) +
	     sizeof (T.rows_non_zero_NBMEs_PSI_in_indices) +
	     sizeof (T.rows_non_zero_NBMEs))/1000000.0);
}

