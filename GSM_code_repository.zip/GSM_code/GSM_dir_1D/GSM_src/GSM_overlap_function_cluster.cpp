#include "../GSM_include/GSM_include_def.h"

// MPI transfer is done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time


// TYPE is double or complex
// -------------------------

// Calculation of overlap functions involving one cluster
// ------------------------------------------------------
// Spectroscopic factors and overlap functions are related to transfer reactions:
// A stripping reaction removes a cluster from the projectile and then adds it to the target.
// A pick-up reaction adds a cluster to the projectile after removing it from the target.
//
// One considers spectroscopic factor amplitudes of one cluster of a fixed (LCM,J[cluster]) partial wave (see after).
// The latter cluster is called the projectile/ejectile for stripping/pick-up and the initial nucleus the target.
//
// A cluster consists of an intrinsic part, i.e. its nucleus at rest, and of a HO center of mass part, of quantum numbers NCM[HO] and LCM.
// The whole projectile/ejectile is coupled to J[cluster] and has a total angular momentum projection M[cluster].
// One uses a HO basis for the CM part of clusters, as then one can use HO algebra transformation,
// i.e. the repeated use of A+[HO-CM] operator on |intrinsic Os-CM>, issued form the Lawson method, to generate |intrinsic NCM[HO] LCM> (see GSM_cluster_CM_intrinsic_basis_states.cpp).
// Nevertheless, one could use in principle the Berggren basis for two-body clusters, as the two-body problem is solvable with the Berggren basis in relative + CM coordinates.
// This is straightforward to code from the current routine and routines of GSM_two_relative_dir.
// The case of clusters with more than two nucleons becomes very difficult to handle, however, as the use of Jacobi coordinates is necessary.
// 
// Spectroscopic factors are of the form S = \sum_{NCM[HO] <= NCM[HO]-max} (<Psi[out] || A+_{NCM[HO] LCM J[cluster]} || Psi[in]>^J[out]/hat(J[out]))^2 for stripping
//                                   and S = \sum_{NCM[HO] <= NCM[HO]-max} (<Psi[out] || A~_{NCM[HO] LCM J[cluster]} || Psi[in]>^J[out]/hat(J[in]))^2  for pick-up
//
// Overlap functions read: I(RCM) = \sum_{NCM[HO] <= NCM[HO]-max} <Psi[out] || A+_{NCM[HO] LCM J[cluster]} || Psi[in]>^J[out]/hat(J[out]) u[HO]_{NCM[HO] LCM J[cluster]}(RCM) for stripping
//                     and I(RCM) = \sum_{NCM[HO] <= NCM[HO]-max} <Psi[out] || A~_{NCM[HO] LCM J[cluster]} || Psi[in]>^J[out]/hat(J[in])  u[HO]_{NCM[HO] LCM J[cluster]}(RCM) for pick-up
//
// using the HO basis of |NCM[HO] LCM J[cluster]> shells, with u[HO]_{NCM[HO] LCM J[cluster]}(RCM)/RCM = <NCM[HO] LCM J[cluster] | RCM LCM J[cluster]>.
//
// S = \int_{0}^{+oo} I(RCM)^2 dRCM, as u[HO]_{NCM[HO] LCM J[cluster]}(RCM) one-body radial basis wave functions are orthogonal.
//
// The spectroscopic amplitude is defined to be equal to <Psi[out] | A+_{NCM[HO] LCM J[cluster] M[cluster]} | Psi[in]> for stripping, with M[cluster] = M[out] - M[in]
//                                                   and <Psi[out] | A~_{NCM[HO] LCM J[cluster] M[cluster]} | Psi[in]> for pick-up,   with M[cluster] = M[in]  - M[out]
//
// One uses M[in] = J[in] and M[out] = J[out] for convenience.
//
// Thus, one first calculates and stores an array of NCM_HO_max + 1 spectroscopic factor amplitudes.
// Reduced matrix elements function of A+_{NCM[HO] LCM J[cluster]} and A~_{NCM[HO] LCM J[cluster]} are calculated from the latter using Wigner-Eckart theorem,
// and one sums over 0 <= NCM[HO] <= NCM[HO]-max afterwards.
// The overlap function directly follows from reduced matrix elements function of A+_{NCM[HO] LCM J[cluster]} and A~_{NCM[HO] LCM J[cluster]}.
//
// |Psi[out]> is given as input and |Psi[in]> will be read from disk from its provided quantum numbers.
//
// Different routines are used for stripping and pick-up, for proton or neutron projectiles, and if one has both valence protons and neutrons, or only valence protons or neutrons (plus a few hyperons if any).
//
// mu is for proton or neutron in routines where one hase only valence protons or neutrons (plus a few hyperons if any).
//
// As the GSM vectors resulting from the action of a+ or a~ on |Psi[in]> are meaningful only in the master process, overlap functions are only calculated in the master process.
//
//
// stripping_calc, pick_up_calc
// ----------------------------
// Routines calculating the overlap functions for stripping or pick-up.


void overlap_function::cluster::stripping_calc (
						const double b_HO , 
						const int NCM_HO_max_projectile , 
						const class ljm_struct &LJM_cluster , 
						const bool is_it_Gauss_Legendre ,
						const class correlated_state_str &PSI_IN_qn , 
						const class correlated_state_str &PSI_OUT_qn , 
						const class correlated_state_str &PSI_projectile_qn , 
						const class GSM_vector &PSI_OUT , 
						const class array<double> &r_bef_R_tab , 
						class array<TYPE> &overlap_function_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
	
  const int LCM = LJM_cluster.get_l ();
  
  const double J_cluster = LJM_cluster.get_j ();
  const double M_cluster = LJM_cluster.get_m ();
  
  const double J_IN  = PSI_IN_qn.get_J ();  
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M (); 

  const double M_IN = M_OUT - M_cluster;
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int NCM_HO_max_projectile_plus_one = NCM_HO_max_projectile + 1;
  
  class array<double> HO_wfs(NCM_HO_max_projectile_plus_one , Nr);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , LCM , r_bef_R_tab , HO_wfs);
    
  class array<TYPE> amplitude_tab(NCM_HO_max_projectile_plus_one);

  spectroscopic_factor_amplitude::cluster::stripping_calc (NCM_HO_max_projectile , LJM_cluster , PSI_IN_qn , PSI_projectile_qn , PSI_OUT , amplitude_tab);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_projectile ; NCM_HO++)
	{
	  const TYPE &amplitude = amplitude_tab(NCM_HO);
	  
	  const TYPE amplitude_reduced = ME_reduced (amplitude , J_cluster , M_cluster , J_IN , M_IN , J_OUT , M_OUT)/hat (J_IN);
	 
	  for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*HO_wfs(NCM_HO , i);
	}
    }
}

void overlap_function::cluster::pick_up_calc (
					      const double b_HO , 
					      const int NCM_HO_max_projectile , 
					      const class ljm_struct &LJM_cluster , 
					      const bool is_it_Gauss_Legendre ,
					      const class correlated_state_str &PSI_IN_qn , 
					      const class correlated_state_str &PSI_OUT_qn , 
					      const class correlated_state_str &PSI_projectile_qn , 
					      const class GSM_vector &PSI_OUT , 
					      const class array<double> &r_bef_R_tab , 
					      class array<TYPE> &overlap_function_tab)
{
  const class GSM_vector_helper_class &GSM_vector_helper_OUT = PSI_OUT.get_GSM_vector_helper ();
 
  const class baryons_data &prot_Y_data = GSM_vector_helper_OUT.get_prot_Y_data ();
  
  const int LCM = LJM_cluster.get_l ();
  
  const double J_cluster = LJM_cluster.get_j ();
  const double M_cluster = LJM_cluster.get_m ();
  
  const double J_IN  = PSI_IN_qn.get_J ();  
  const double J_OUT = PSI_OUT_qn.get_J ();
  
  const double M_OUT = GSM_vector_helper_OUT.get_M ();
  
  const double M_IN = M_OUT + M_cluster;
  
  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);
  
  const unsigned int NCM_HO_max_projectile_plus_one = NCM_HO_max_projectile + 1;
  
  class array<double> HO_wfs(NCM_HO_max_projectile_plus_one , N_bef_R_uniform);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , LCM , r_bef_R_tab , HO_wfs);
  
  class array<TYPE> amplitude_tab(NCM_HO_max_projectile_plus_one);

  spectroscopic_factor_amplitude::cluster::pick_up_calc (NCM_HO_max_projectile , LJM_cluster , PSI_IN_qn , PSI_projectile_qn , PSI_OUT , amplitude_tab);
    
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      for (int NCM_HO = 0 ; NCM_HO <= NCM_HO_max_projectile ; NCM_HO++)
	{
	  const TYPE &amplitude = amplitude_tab(NCM_HO);
	  
	  const TYPE amplitude_reduced = ME_reduced (amplitude , J_cluster , -M_cluster , J_IN , M_IN , J_OUT , M_OUT)/hat (J_IN);
	  
	  for (unsigned int i = 0 ; i < Nr ; i++) overlap_function_tab(i) += amplitude_reduced*HO_wfs(NCM_HO , i);
	}
    }
}


