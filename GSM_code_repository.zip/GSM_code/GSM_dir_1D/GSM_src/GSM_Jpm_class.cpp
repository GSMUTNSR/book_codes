#include "../GSM_include/GSM_include_def.h"

using namespace inputs_misc;
using namespace GSM_vector_NBMEs_handling;
using namespace GSM_vector_dimensions;

// TYPE is double or complex
// -------------------------

// OBMEs means one-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------


// Class xJpm_str is used only in closures and then is not commented.



// Class applying J+ or J- to |Psi[in]> to obtain |Psi[out]>
// ---------------------------------------------------------
// Jpm means J+ or J-, as pm = +/1. One uses Jpm for J+ or J- in all Jpm classes files.
//
// One uses Jpm in J^2 = J-.J+ + Jz.(Jz + 1), and to generate |J M> Hamiltonian eigenstates for all M values starting from an eigenstate with a fixed M value.
//
// One has here constructors, destructors, Hamiltonian operator apply call and operators overloading of operations of the type a.Jpm + b.
//
// Routines here are rather straightforward so that they are not detailed. Only general explanations are given.
//
// The maximal memory occupied in MPI ranks is written on screen after memory allocation.
// The maximal memory is equal to the memory used for a sequential calculation.
//
//
// used_memory_calc
// ----------------
// This routine calculates the memory used by the class in Mb by looping over its data and adding their used memory.
//
// print
// -----
// This routine prints non-zero Jpm NBMEs on screen, This can be used only in a sequential calculation and using the FULL_STORAGE option. It is typically used for tests.
// 
// apply_add
// ---------
// One calculates |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>.
// If MPI parallelization is used and |Psi[out]> != 0, |Psi[out]> is firstly transfered to all nodes, as only the master process has a copy of it, and divided by the number of nodes.
// Consequently, the |Psi[out]> parts in all nodes can be summed up in the end to obtain |Psi[out]> -> |Psi[out]> + Jpm.|Psi[in]>
// 
// Full storage and on the fly methods can be used.
//
//
// xJpm_str
// --------
// Operators overloading of operations are of the type a.Jpm, to which operators of the form b.Jpm as well can be added.
// One cannot add another operator to a.Jpm besides b.Jpm, however, as one would have to call different many-body routines for it, which would be too complicated to handle.
// Indeed, the latter is seen as (a + b).Jpm.
// Moreover, as Jpm does not conserve M, one cannot add constant.Id to Jpm.
// One can use instead (a*Jpm)*PSI_0 + J^2*PSI_1 for example, up to 10 terms.
// Products of operators are not accepted with operator overloading.




Jpm_class::Jpm_class () :
  pm (0) ,
  storage (NO_STORAGE) ,
  space_dimension_process_out_non_zeros (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{}



Jpm_class::Jpm_class (
		      const bool is_there_cout , 
		      const int pm_c , 
		      const enum storage_type storage_c , 
		      const class GSM_vector_helper_class &GSM_vector_helper_in , 
		      const class GSM_vector_helper_class &GSM_vector_helper_out) :
  pm (0) ,
  storage (NO_STORAGE) ,
  space_dimension_process_out_non_zeros (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate (is_there_cout , pm_c , storage_c , GSM_vector_helper_in , GSM_vector_helper_out);
}



Jpm_class::Jpm_class (const class Jpm_class &X) :
  pm (0) ,
  storage (NO_STORAGE) ,
  space_dimension_process_out_non_zeros (0) , 
  GSM_vector_helper_in_ptr (NULL) ,
  GSM_vector_helper_out_ptr (NULL)
{
  allocate_fill (X);
}



Jpm_class::~Jpm_class ()
{  
  if (rows_non_zero_NBMEs_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process_out = rows_non_zero_NBMEs_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	delete [] rows_non_zero_NBMEs_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs.is_it_filled ())
    {
      const unsigned int space_dimension_process_out =rows_non_zero_NBMEs.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	delete [] rows_non_zero_NBMEs(i);
    }
}



void Jpm_class::allocate (
			  const bool is_there_cout , 
			  const int pm_c , 
			  const enum storage_type storage_c , 
			  const class GSM_vector_helper_class &GSM_vector_helper_in , 
			  const class GSM_vector_helper_class &GSM_vector_helper_out)
{
  if (is_it_filled ()) error_message_print_abort ("Jpm_class cannot be allocated twice in Jpm_class::allocate");

  pm = pm_c;
  storage = storage_c;
  space_dimension_process_out_non_zeros = 0;

  GSM_vector_helper_in_ptr = &GSM_vector_helper_in;
  GSM_vector_helper_out_ptr = &GSM_vector_helper_out;

  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();

  if (space_dimension_out == 0) return;

  const enum space_type space = GSM_vector_helper_out.get_space ();

  const int n_scat_max_p = GSM_vector_helper_out.get_n_scat_max_p (); 
  const int n_scat_max_n = GSM_vector_helper_out.get_n_scat_max_n (); 

  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();

  const unsigned int Np_nljm = (n_scat_max_p > 0) ? (prot_Y_data.get_N_nljm_baryon ()) : (prot_Y_data.get_N_nljm_res_baryon ());
  const unsigned int Nn_nljm = (n_scat_max_n > 0) ? (neut_Y_data.get_N_nljm_baryon ()) : (neut_Y_data.get_N_nljm_res_baryon ());

  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();
  
  if (space != NEUT_Y_ONLY)
    {
      Jpm_OBMEs_p_tab.allocate (Np_nljm , Np_nljm);

      Jpm_OBMEs_calc (pm , phi_p_table , Jpm_OBMEs_p_tab);
    }

  if (space != PROT_Y_ONLY)
    {
      Jpm_OBMEs_n_tab.allocate (Nn_nljm , Nn_nljm);

      Jpm_OBMEs_calc (pm , phi_n_table , Jpm_OBMEs_n_tab);
    }
  
  if (is_it_full_or_partial_storage_determine (storage))
    {
      const unsigned int space_dimension_process_out = GSM_vector_helper_out.get_space_dimension_process ();
      
      space_dimension_process_out_non_zeros = 0;

      rows_non_zero_NBMEs_numbers.allocate (space_dimension_process_out);

      rows_non_zero_NBMEs_numbers_calc ();

      rows_non_zero_NBMEs_PSI_in_indices.allocate (space_dimension_process_out);

      rows_non_zero_NBMEs.allocate (space_dimension_process_out);

      rows_non_zero_NBMEs_PSI_in_indices = NULL;

      rows_non_zero_NBMEs = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(i);
	  
	  if (row_non_zero_NBMEs_number > 0)
	    {
	      rows_non_zero_NBMEs_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_number];

	      rows_non_zero_NBMEs(i) = new double [row_non_zero_NBMEs_number];
	      
	      space_dimension_process_out_non_zeros++;
	    }
	}

      PSI_out_indices_shifted_non_zeros.allocate (space_dimension_process_out_non_zeros);

      space_dimension_process_out_non_zeros = 0;

      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(i);

	  if (row_non_zero_NBMEs_number > 0) PSI_out_indices_shifted_non_zeros(space_dimension_process_out_non_zeros++) = i;
	}

      matrix_store ();
    }
  
  const double Jpm_used_memory_process = used_memory_calc (*this);

  const double Jpm_used_memory_process_max = max_Reduce<double> (is_it_MPI_parallelized , MASTER_PROCESS , THIS_PROCESS , Jpm_used_memory_process);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout)
    {
      const string pm_string = (pm == 1) ? ("+") : ("-");
      
      cout << "J" << pm_string <<" memory max used for a process:" << Jpm_used_memory_process_max << " Mb" << endl;
    }
}







void Jpm_class::allocate_fill (const class Jpm_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("Jpm_class cannot be allocated twice in Jpm_class::allocate_fill");

  pm = X.pm;

  storage = X.storage;

  space_dimension_process_out_non_zeros = X.space_dimension_process_out_non_zeros;

  GSM_vector_helper_in_ptr  = X.GSM_vector_helper_in_ptr; 
  GSM_vector_helper_out_ptr = X.GSM_vector_helper_out_ptr;

  Jpm_OBMEs_p_tab.allocate_fill (X.Jpm_OBMEs_p_tab);
  Jpm_OBMEs_n_tab.allocate_fill (X.Jpm_OBMEs_n_tab);

  rows_non_zero_NBMEs_numbers.allocate_fill (X.rows_non_zero_NBMEs_numbers);
      
  PSI_out_indices_shifted_non_zeros.allocate_fill (X.PSI_out_indices_shifted_non_zeros);
      
  if (X.rows_non_zero_NBMEs_PSI_in_indices.is_it_filled () && X.rows_non_zero_NBMEs.is_it_filled ())
    {
      const unsigned int space_dimension_process_out = X.rows_non_zero_NBMEs_PSI_in_indices.dimension (0);
  
      rows_non_zero_NBMEs_PSI_in_indices.allocate (space_dimension_process_out);

      rows_non_zero_NBMEs.allocate (space_dimension_process_out);

      rows_non_zero_NBMEs_PSI_in_indices = NULL;

      rows_non_zero_NBMEs = NULL;
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(i);

	  if (row_non_zero_NBMEs_number > 0)
	    {
	      rows_non_zero_NBMEs_PSI_in_indices(i) = new unsigned int [row_non_zero_NBMEs_number];

	      rows_non_zero_NBMEs(i) = new double [row_non_zero_NBMEs_number];
	      
	      const unsigned int *const X_rows_non_zero_NBMEs_PSI_in_indices_i = X.rows_non_zero_NBMEs_PSI_in_indices(i);

	      const double *const X_rows_non_zero_NBMEs_i = X.rows_non_zero_NBMEs(i);

	      unsigned int *const rows_non_zero_NBMEs_PSI_in_indices_i = rows_non_zero_NBMEs_PSI_in_indices(i);

	      double *const rows_non_zero_NBMEs_i = rows_non_zero_NBMEs(i);	      

	      for (unsigned int ii = 0 ; ii < row_non_zero_NBMEs_number ; ii++)
		{
		  rows_non_zero_NBMEs_PSI_in_indices_i[ii] = X_rows_non_zero_NBMEs_PSI_in_indices_i[ii];

		  rows_non_zero_NBMEs_i[ii] = X_rows_non_zero_NBMEs_i[ii];
		} 
	    }
	}
    }
}





void Jpm_class::deallocate ()
{  
  if (rows_non_zero_NBMEs_PSI_in_indices.is_it_filled ())
    {
      const unsigned int space_dimension_process_out = rows_non_zero_NBMEs_PSI_in_indices.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	delete [] rows_non_zero_NBMEs_PSI_in_indices(i);
    }
      
  if (rows_non_zero_NBMEs.is_it_filled ())
    {
      const unsigned int space_dimension_process_out = rows_non_zero_NBMEs.dimension (0);
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	delete [] rows_non_zero_NBMEs(i);
    }
  
  Jpm_OBMEs_p_tab.deallocate ();
  Jpm_OBMEs_n_tab.deallocate ();   

  rows_non_zero_NBMEs_numbers.deallocate ();

  rows_non_zero_NBMEs_PSI_in_indices.deallocate ();

  rows_non_zero_NBMEs.deallocate ();

  PSI_out_indices_shifted_non_zeros.deallocate ();

  pm = 0;
  
  storage = NO_STORAGE;
  
  space_dimension_process_out_non_zeros = 0;
  
  GSM_vector_helper_in_ptr  = NULL;  
  GSM_vector_helper_out_ptr = NULL;
}



bool Jpm_class::is_it_filled () const
{
  return (storage != NO_STORAGE);
}




void Jpm_class::apply_add (
			   const class GSM_vector &PSI_in , 
			   class GSM_vector &PSI_out) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_in  = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  if (!PSI_in.same_parity_strangeness_M_projection (GSM_vector_helper_in)) return;
  if (!PSI_out.same_parity_strangeness_M_projection (GSM_vector_helper_out)) return;
  
  const unsigned int BP_in  = GSM_vector_helper_in.get_BP ();
  const unsigned int BP_out = GSM_vector_helper_out.get_BP ();

  if (BP_out != BP_in) return;
  
  const int S_in  = GSM_vector_helper_in.get_S ();
  const int S_out = GSM_vector_helper_out.get_S ();
  
  if (S_in != S_out) return;
  
  const int iM_in  = GSM_vector_helper_in.get_iM ();
  const int iM_out = GSM_vector_helper_out.get_iM ();
  
  if (iM_out != iM_in + pm) return;
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized)
    {
      double PSI_out_infinite_norm = PSI_out.infinite_norm ();
	
      MPI_helper::Bcast<double> (PSI_out_infinite_norm , MASTER_PROCESS , MPI_COMM_WORLD);  

      if (PSI_out_infinite_norm > 0.0)
	{
	  PSI_out.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	  PSI_out /= NUMBER_OF_PROCESSES;
	}
    }
  
#endif
	  
  switch (storage)
    {
    case FULL_STORAGE:    apply_add_full_storage (PSI_in , PSI_out); break;      
    case PARTIAL_STORAGE: apply_add_full_storage (PSI_in , PSI_out); break;

    case ON_THE_FLY: apply_add_on_the_fly (PSI_in , PSI_out); break;
      
    default: abort_all ();
    }

#ifdef UseMPI
  
  if (is_it_MPI_parallelized) PSI_out.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);
  
#endif
}







// The interest of the two next routines , which could be calculated by a direct application of J+/- otherwise , 
// is that they do not involve an MPI transfer of a vector , but of a double.



double Jpm_class::Jpm_PSI_infinite_norm_calc (
					      const class GSM_vector &PSI , 
					      class GSM_vector &PSI_test) const
{
  PSI_test = 0.0;

  switch (storage)
    {
    case FULL_STORAGE:    apply_add_full_storage (PSI , PSI_test); break;      
    case PARTIAL_STORAGE: apply_add_full_storage (PSI , PSI_test); break;

    case ON_THE_FLY: apply_add_on_the_fly (PSI , PSI_test); break;      

    default: abort_all ();
    }
  
  const double Jpm_PSI_infinite_norm_partial = PSI_test.infinite_norm ();
  
  const double Jpm_PSI_infinite_norm = max_Allreduce<double> (is_it_MPI_parallelized , Jpm_PSI_infinite_norm_partial);
  
  return Jpm_PSI_infinite_norm;
}








double Jpm_class::Jpm_PSI_minus_xPHI_infinite_norm_calc (
							 const class GSM_vector &PSI , 
							 const double x , 
							 const class GSM_vector &PHI , 
							 class GSM_vector &PSI_test) const
{
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
  
  const unsigned int space_dimension_out = GSM_vector_helper_out.get_space_dimension ();
  
  const bool is_process_active = is_process_active_for_MPI (space_dimension_out , THIS_PROCESS);

  const unsigned int first_PSI_test_index = PSI_test.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  const unsigned int last_PSI_test_index = PSI_test.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  PSI_test = 0.0;

  switch (storage)
    {
    case FULL_STORAGE:    apply_add_full_storage (PSI , PSI_test); break;
    case PARTIAL_STORAGE: apply_add_full_storage (PSI , PSI_test); break;
      
    case ON_THE_FLY: apply_add_on_the_fly (PSI , PSI_test); break;
      
    default: abort_all ();
    }
  
  if (!is_it_MPI_parallelized)
    PSI_test -= x*PHI;
  else if (is_process_active)
    {
      for (unsigned int i = first_PSI_test_index ; i <= last_PSI_test_index ; i++) 
	PSI_test[i] -= x*PHI[i];
    }
  
  const double Jpm_PSI_minus_xPHI_infinite_norm_partial = PSI_test.infinite_norm ();

  const double Jpm_PSI_minus_xPHI_infinite_norm = max_Allreduce<double> (is_it_MPI_parallelized , Jpm_PSI_minus_xPHI_infinite_norm_partial);
  
  return Jpm_PSI_minus_xPHI_infinite_norm;
}





void Jpm_class::print () const
{
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Only serial processes allowed for the use of print of Jpm_class.");

  if (storage != FULL_STORAGE) error_message_print_abort ("Full storage option must be used in print of Jpm_class.");

  const class GSM_vector_helper_class &GSM_vector_helper_in = get_GSM_vector_helper_in ();
  const class GSM_vector_helper_class &GSM_vector_helper_out = get_GSM_vector_helper_out ();
     
  const enum space_type space = GSM_vector_helper_out.get_space ();
  
  const class baryons_data &prot_Y_data = GSM_vector_helper_out.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = GSM_vector_helper_out.get_neut_Y_data ();
  
  const int ZYval = prot_Y_data.get_N_valence_baryons ();
  const int NYval = neut_Y_data.get_N_valence_baryons ();
      
  const class array<class nljm_struct> &phi_p_table = prot_Y_data.get_phi_table ();
  const class array<class nljm_struct> &phi_n_table = neut_Y_data.get_phi_table ();

  const class Slater_determinant dummy_SD;

  const class GSM_vector V_in(GSM_vector_helper_in);
  const class GSM_vector V_out(GSM_vector_helper_out);

  class Slater_determinant inSDp(ZYval);
  class Slater_determinant inSDn(NYval);
  
  class Slater_determinant outSDp(ZYval);
  class Slater_determinant outSDn(NYval);
  
  for (unsigned int PSI_out_index_non_zeros = 0 ; PSI_out_index_non_zeros < space_dimension_process_out_non_zeros ; PSI_out_index_non_zeros++)
    {
      const unsigned int PSI_out_index = PSI_out_indices_shifted_non_zeros(PSI_out_index_non_zeros);

      outSDp = (space != NEUT_Y_ONLY) ? (V_out.basis_SD_from_index (PROT_Y_ONLY , PSI_out_index)) : (dummy_SD);
      outSDn = (space != PROT_Y_ONLY) ? (V_out.basis_SD_from_index (NEUT_Y_ONLY , PSI_out_index)) : (dummy_SD);

      const unsigned int row_non_zero_NBMEs_number = rows_non_zero_NBMEs_numbers(PSI_out_index);
      
      const unsigned int *const row_non_zero_NBMEs_PSI_in_indices = rows_non_zero_NBMEs_PSI_in_indices(PSI_out_index);
      
      const double *const row_non_zero_NBMEs = rows_non_zero_NBMEs(PSI_out_index);

      switch (space)
	{
	case PROT_Y_ONLY: 
	  {
	    cout << "inSD: "  , outSDp.print (phi_p_table);
	    cout << "outSD: " , outSDp.print (phi_p_table);
	  } break;

	case NEUT_Y_ONLY:
	  {
	    cout << "inSD: "  , outSDn.print (phi_n_table);
	    cout << "outSD: " , outSDn.print (phi_n_table);
	  } break;

	case PROT_NEUT_Y:
	  {
	    cout << "inSDp: "  , outSDp.print (phi_p_table);
	    cout << "inSDn: "  , outSDn.print (phi_n_table);
	    
	    cout << "outSDp: " , outSDp.print (phi_p_table);
	    cout << "outSDn: " , outSDn.print (phi_n_table);
	  } break;

	default: abort_all ();
	}

      for (unsigned int i = 0 ; i < row_non_zero_NBMEs_number ; i++) 
	{
	  const unsigned int PSI_in_index = row_non_zero_NBMEs_PSI_in_indices[i];
	  
	  if (PSI_out_index < PSI_in_index)
	    {
	      const double NBME = row_non_zero_NBMEs[i];	

	      inSDp = (space != NEUT_Y_ONLY) ? (V_in.basis_SD_from_index (PROT_Y_ONLY , PSI_in_index)) : (dummy_SD);
	      inSDn = (space != PROT_Y_ONLY) ? (V_in.basis_SD_from_index (NEUT_Y_ONLY , PSI_in_index)) : (dummy_SD);

	      switch (space)
		{
		case PROT_Y_ONLY: 
		  {
		    cout << "inSD: "  , inSDp.print (phi_p_table);
		    
		    cout << "outSD: " , outSDp.print (phi_p_table);
		  } break;

		case NEUT_Y_ONLY:
		  {
		    cout << "inSD: "  , inSDn.print (phi_n_table);
		    
		    cout << "outSD: " , outSDn.print (phi_n_table);
		  } break;

		case PROT_NEUT_Y:
		  {
		    cout << "inSDp: "  , inSDp.print (phi_p_table);
		    cout << "inSDn: "  , inSDn.print (phi_n_table);

		    cout << "outSDp: " , outSDp.print (phi_p_table);
		    cout << "outSDn: " , outSDn.print (phi_n_table);
		  } break;

		default: abort_all ();
		}

	      cout << "inSD index: " << PSI_in_index << " outSD index: " << PSI_out_index << " NBME: " << NBME << endl << endl;
	    }
	}      
    }
}







double used_memory_calc (const class Jpm_class &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  double used_memory_allocated_arrays = used_memory_calc (T.Jpm_OBMEs_p_tab) +
    used_memory_calc (T.Jpm_OBMEs_n_tab) +
    used_memory_calc (T.rows_non_zero_NBMEs_PSI_in_indices) +
    used_memory_calc (T.rows_non_zero_NBMEs)
    - (sizeof (T.Jpm_OBMEs_p_tab) +
       sizeof (T.Jpm_OBMEs_n_tab) +
       sizeof (T.rows_non_zero_NBMEs_PSI_in_indices) +
       sizeof (T.rows_non_zero_NBMEs))/1000000.0;
  
  const double unsigned_int_double_memory = (sizeof (unsigned int) + sizeof (double))/1000000.0;
      
  const class GSM_vector_helper_class &GSM_vector_helper_out = T.get_GSM_vector_helper_out ();
      
  if (T.rows_non_zero_NBMEs_numbers.is_it_filled ())
    {
      const unsigned int space_dimension_process_out = GSM_vector_helper_out.get_space_dimension_process ();
      
      for (unsigned int i = 0 ; i < space_dimension_process_out ; i++) 
	{
	  const unsigned int row_non_zero_NBMEs_number = T.rows_non_zero_NBMEs_numbers(i);
      
	  used_memory_allocated_arrays += row_non_zero_NBMEs_number*unsigned_int_double_memory;
	}
    }
  
  double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}




xJpm_str::xJpm_str (const TYPE &x_c , const class Jpm_class &Jpm_c) : x (x_c) , Jpm (Jpm_c) {}

class xJpm_str operator + (const class Jpm_class &Jpm)
{
  return xJpm_str (1.0 , Jpm);
}

class xJpm_str operator - (const class Jpm_class &Jpm)
{
  return xJpm_str (-1.0 , Jpm);
}

class xJpm_str operator * (const class Jpm_class &Jpm , const double x)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator * (const double x , const class Jpm_class &Jpm)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator / (const class Jpm_class &Jpm , const double x)
{
  const double one_over_x = 1.0/x;

  return xJpm_str (one_over_x , Jpm);
}

class xJpm_str operator + (const class xJpm_str &xJpm)
{
  return xJpm_str (xJpm.x , xJpm.Jpm);
}

class xJpm_str operator - (const class xJpm_str &xJpm)
{
  return xJpm_str (-xJpm.x , xJpm.Jpm);
}

class xJpm_str operator * (const class xJpm_str &Op , const double factor)
{
  return xJpm_str (Op.x*factor , Op.Jpm);
}

class xJpm_str operator / (const class xJpm_str &Op , const double factor)
{
  return xJpm_str (Op.x/factor , Op.Jpm);
}

class xJpm_str operator * (const double factor , const class xJpm_str &Op)
{
  return xJpm_str (factor*Op.x , Op.Jpm);
}

#ifdef TYPEisDOUBLECOMPLEX

class xJpm_str operator * (const class Jpm_class &Jpm , const complex<double> &x)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator * (const complex<double> &x , const class Jpm_class &Jpm)
{
  return xJpm_str (x , Jpm);
}

class xJpm_str operator / (const class Jpm_class &Jpm , const complex<double> &x)
{
  const complex<double> one_over_x = 1.0/x;

  return xJpm_str (one_over_x , Jpm);
}

class xJpm_str operator * (const class xJpm_str &Op , const complex<double> &factor)
{
  return xJpm_str (Op.x*factor , Op.Jpm);
}

class xJpm_str operator / (const class xJpm_str &Op , const complex<double> &factor)
{
  return xJpm_str (Op.x/factor , Op.Jpm);
}

class xJpm_str operator * (const complex<double> &factor , const class xJpm_str &Op)
{
  return xJpm_str (factor*Op.x , Op.Jpm);
}

#endif

class xJpm_str operator + (const class xJpm_str &Op_a , const class xJpm_str &Op_b)
{
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm must be the same in both Op_a and Op_b in class xJpm_str operator +");

  return xJpm_str (Op_a.x + Op_b.x , Op_a.Jpm);
}

class xJpm_str operator - (const class xJpm_str &Op_a , const class xJpm_str &Op_b)
{	
  if (&(Op_a.Jpm) != &(Op_b.Jpm)) error_message_print_abort ("Jpm must be the same in both Op_a and Op_b in class xJpm_str operator -");

  return xJpm_str (Op_a.x - Op_b.x , Op_a.Jpm);
}


