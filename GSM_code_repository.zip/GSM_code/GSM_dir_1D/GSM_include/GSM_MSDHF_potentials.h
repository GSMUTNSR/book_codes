#ifndef GSMMSDHFPOTENTIALS_H
#define GSMMSDHFPOTENTIALS_H

// TYPE is double or complex
// -------------------------

namespace MSDHF_potentials
{
  namespace HO_expansion_part
  {
    void Up_HF_pp_part_HO_basis_SD_GS_one_jump_calc (
						     const int lp , 
						     const double jp , 
						     const int imp_out , 
						     const class CG_str &CGs , 
						     const class interaction_class &inter_data_basis , 
						     const class baryons_data &prot_data_one_configuration , 
						     const class array<unsigned int> &HO_index_from_n_tab , 
						     const unsigned int i_GS_in , 
						     const unsigned int i_GS_out , 
						     const class array<unsigned int> &p_jump_states_GS_in , 
						     const class HF_nucleons_data &prot_HF_data , 
						     class matrix<complex<double> > &Up_finite_range_HF_HO_basis_lj_part);

    void Up_HF_pp_part_HO_basis_SD_GS_two_jumps_calc (
						      const int lp , 
						      const double jp , 
						      const int imp_out , 
						      const class CG_str &CGs , 
						      const class interaction_class &inter_data_basis , 
						      const class baryons_data &prot_data_one_configuration , 
						      const class array<unsigned int> &HO_index_from_n_tab , 
						      const unsigned int i_GS_in , 
						      const unsigned int i_GS_out , 
						      const class array<unsigned int> &p_jump_states_GS_in , 
						      class array<unsigned int> &p_jump_states_1h_out , 
						      class HF_nucleons_data &prot_HF_data , 
						      class matrix<complex<double> > &Up_finite_range_HF_HO_basis_lj_part);

    void Up_HF_pp_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class baryons_data &prot_data_one_configuration , 
				      class HF_nucleons_data &prot_HF_data);

    void Up_HF_pn_part_HO_basis_SD_GS_one_jump_calc (
						     const int lp , 
						     const double jp , 
						     const int imp_out , 
						     const class CG_str &CGs , 
						     const class interaction_class &inter_data_basis , 
						     const class baryons_data &prot_data_one_configuration , 
						     const class baryons_data &neut_data_one_configuration , 
						     const class array<unsigned int> &HO_index_from_n_tab , 
						     const unsigned int i_GS_in , 
						     const unsigned int i_GS_out , 
						     const class array<unsigned int> &p_jump_states_GS_in , 
						     const class HF_nucleons_data &prot_HF_data , 
						     class matrix<complex<double> > &Up_finite_range_HF_HO_basis_lj_part);

    void Up_HF_pn_part_HO_basis_SD_GS_two_jumps_calc (
						      const int lp , 
						      const double jp , 
						      const int imp_out , 
						      const class CG_str &CGs , 
						      const class interaction_class &inter_data_basis , 
						      const class baryons_data &prot_data_one_configuration , 
						      const class baryons_data &neut_data_one_configuration , 
						      const class array<unsigned int> &HO_index_from_n_tab , 
						      const unsigned int i_GS_in , 
						      const unsigned int i_GS_out , 
						      const class array<unsigned int> &p_jump_states_GS_in , 
						      const class array<unsigned int> &n_jump_states_GS_in , 
						      class array<unsigned int> &n_jump_states_GS_out , 
						      class HF_nucleons_data &prot_HF_data , 
						      class matrix<complex<double> > &Up_finite_range_HF_HO_basis_lj_part);

    void Up_HF_pn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class baryons_data &prot_data_one_configuration , 
				      const class baryons_data &neut_data_one_configuration , 
				      class HF_nucleons_data &prot_HF_data);

    void Un_HF_nn_part_HO_basis_SD_GS_one_jump_calc (
						     const int ln , 
						     const double jn , 
						     const int imn_out , 
						     const class CG_str &CGs , 
						     const class interaction_class &inter_data_basis , 
						     const class baryons_data &neut_data_one_configuration , 
						     const class array<unsigned int> &HO_index_from_n_tab , 
						     const unsigned int i_GS_in , 
						     const unsigned int i_GS_out , 
						     const class array<unsigned int> &n_jump_states_GS_in , 
						     const class HF_nucleons_data &neut_HF_data , 
						     class matrix<complex<double> > &Un_finite_range_HF_HO_basis_lj_part);

    void Un_HF_nn_part_HO_basis_SD_GS_two_jumps_calc (
						      const int ln , 
						      const double jn , 
						      const int imn_out , 
						      const class CG_str &CGs , 
						      const class interaction_class &inter_data_basis , 
						      const class baryons_data &neut_data_one_configuration , 
						      const class array<unsigned int> &HO_index_from_n_tab , 
						      const unsigned int i_GS_in , 
						      const unsigned int i_GS_out , 
						      const class array<unsigned int> &n_jump_states_GS_in , 
						      class array<unsigned int> &n_jump_states_1h_out , 
						      class HF_nucleons_data &neut_HF_data , 
						      class matrix<complex<double> > &Un_finite_range_HF_HO_basis_lj_part);

    void Un_HF_nn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class baryons_data &neut_data_one_configuration , 
				      class HF_nucleons_data &neut_HF_data);

    void Un_HF_pn_part_HO_basis_SD_GS_one_jump_calc (
						     const int ln , 
						     const double jn , 
						     const int imn_out , 
						     const class CG_str &CGs , 
						     const class interaction_class &inter_data_basis , 
						     const class baryons_data &prot_data_one_configuration , 
						     const class baryons_data &neut_data_one_configuration , 
						     const class array<unsigned int> &HO_index_from_n_tab , 
						     const unsigned int i_GS_in , 
						     const unsigned int i_GS_out , 
						     const class array<unsigned int> &n_jump_states_GS_in , 
						     const class HF_nucleons_data &neut_HF_data , 
						     class matrix<complex<double> > &Un_finite_range_HF_HO_basis_lj_part);

    void Un_HF_pn_part_HO_basis_SD_GS_two_jumps_calc (
						      const int ln , 
						      const double jn , 
						      const int imn_out , 
						      const class CG_str &CGs , 
						      const class interaction_class &inter_data_basis , 
						      const class baryons_data &prot_data_one_configuration , 
						      const class baryons_data &neut_data_one_configuration , 
						      const class array<unsigned int> &HO_index_from_n_tab , 
						      const unsigned int i_GS_in , 
						      const unsigned int i_GS_out , 
						      const class array<unsigned int> &p_jump_states_GS_in , 
						      const class array<unsigned int> &n_jump_states_GS_in , 
						      class array<unsigned int> &p_jump_states_GS_out , 
						      class HF_nucleons_data &neut_HF_data , 
						      class matrix<complex<double> > &Un_finite_range_HF_HO_basis_lj_part);

    void Un_HF_pn_part_HO_basis_calc (
				      const class CG_str &CGs , 
				      const class interaction_class &inter_data_basis , 
				      const class baryons_data &prot_data_one_configuration , 
				      const class baryons_data &neut_data_one_configuration , 
				      class HF_nucleons_data &neut_HF_data);

    void Up_hole_double_counting_pp_part_HO_basis_remove (
							  const class interaction_class &inter_data_basis , 
							  class HF_nucleons_data &prot_HF_data);

    void Up_hole_double_counting_pn_part_HO_basis_remove (
							  const class interaction_class &inter_data_basis , 
							  const class HF_nucleons_data &neut_HF_data , 
							  class HF_nucleons_data &prot_HF_data);

    void Un_hole_double_counting_nn_part_HO_basis_remove (
							  const class interaction_class &inter_data_basis , 
							  class HF_nucleons_data &neut_HF_data);

    void Un_hole_double_counting_pn_part_HO_basis_remove (
							  const class interaction_class &inter_data_basis , 
							  const class HF_nucleons_data &prot_HF_data , 
							  class HF_nucleons_data &neut_HF_data);

    void prot_potentials_HO_basis_calc (
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class baryons_data &prot_data_one_configuration , 
					const class baryons_data &neut_data_one_configuration , 
					const class HF_nucleons_data &neut_HF_data , 
					class HF_nucleons_data &prot_HF_data);

    void neut_potentials_HO_basis_calc (
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class baryons_data &prot_data_one_configuration , 
					const class baryons_data &neut_data_one_configuration , 
					const class HF_nucleons_data &prot_HF_data , 
					class HF_nucleons_data &neut_HF_data);
  }

  namespace SGI_MSGI_part
  {
    namespace SGI_part
    {
      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_p , 
			    const class spherical_state &shell_p_occ , 
			    const double mp_in , 
			    const double mp_out , 
			    const double mp_occ_in , 
			    const double mp_occ_out , 
			    const complex<double> &SDs_weight ,
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &radial_p_tabs , 
			    class HF_nucleons_data &prot_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_p , 
			    const class spherical_state &shell_n_occ , 
			    const double mp_in , 
			    const double mp_out , 
			    const double mn_occ_in , 
			    const double mn_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &radial_n_tabs , 
			    class HF_nucleons_data &prot_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sn_occ , 
			    const class spherical_state &shell_n , 
			    const class spherical_state &shell_n_occ , 
			    const double mn_in , 
			    const double mn_out , 
			    const double mn_occ_in , 
			    const double mn_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &radial_n_tabs , 
			    class HF_nucleons_data &neut_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const unsigned int sp_occ , 
			    const class spherical_state &shell_n , 
			    const class spherical_state &shell_p_occ , 
			    const double mn_in , 
			    const double mn_out , 
			    const double mp_occ_in , 
			    const double mp_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    const class SGI_radial_tabs_str &radial_p_tabs , 
			    class HF_nucleons_data &neut_HF_data);

      void Up_hole_double_counting_pp_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const unsigned int sp_occ , 
						   const class spherical_state &shell_p , 
						   const class spherical_state &shell_p_occ , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   const class SGI_radial_tabs_str &radial_p_tabs , 
						   class HF_nucleons_data &prot_HF_data);

      void Up_hole_double_counting_pn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const unsigned int sn_occ , 
						   const class spherical_state &shell_p , 
						   const class spherical_state &shell_n_occ , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   const class SGI_radial_tabs_str &radial_n_tabs , 
						   class HF_nucleons_data &prot_HF_data);

      void Un_hole_double_counting_nn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const unsigned int sn_occ , 
						   const class spherical_state &shell_n , 
						   const class spherical_state &shell_n_occ , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   const class SGI_radial_tabs_str &radial_n_tabs , 
						   class HF_nucleons_data &neut_HF_data);

      void Un_hole_double_counting_pn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const unsigned int sp_occ , 
						   const class spherical_state &shell_n , 
						   const class spherical_state &shell_p_occ , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   const class SGI_radial_tabs_str &radial_p_tabs , 
						   class HF_nucleons_data &neut_HF_data);
    }

    namespace MSGI_part
    {
      void Up_pp_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_p , 
			    const class spherical_state &shell_p_occ , 
			    const double mp_in , 
			    const double mp_out , 
			    const double mp_occ_in , 
			    const double mp_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &prot_HF_data);

      void Up_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_p , 
			    const class spherical_state &shell_n_occ , 
			    const double mp_in , 
			    const double mp_out , 
			    const double mn_occ_in , 
			    const double mn_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &prot_HF_data);

      void Un_nn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_n , 
			    const class spherical_state &shell_n_occ , 
			    const double mn_in , 
			    const double mn_out , 
			    const double mn_occ_in , 
			    const double mn_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &neut_HF_data);

      void Un_pn_part_calc (
			    const bool is_it_res , 
			    const bool is_it_pm , 
			    const int pm , 
			    const class spherical_state &shell_n , 
			    const class spherical_state &shell_p_occ , 
			    const double mn_in , 
			    const double mn_out , 
			    const double mp_occ_in , 
			    const double mp_occ_out , 
			    const complex<double> &SDs_weight , 
			    const class CG_str &CGs , 
			    const class array<double> &Gaussian_table_GL , 
			    const class multipolar_expansion_str &multipolar_expansion , 
			    const class interaction_class &inter_data_basis , 
			    class HF_nucleons_data &neut_HF_data);

      void Up_hole_double_counting_pp_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const class spherical_state &shell_p , 
						   const class spherical_state &shell_p_occ , 
						   const class array<double> &Gaussian_table_GL , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   class HF_nucleons_data &prot_HF_data);

      void Up_hole_double_counting_pn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const class spherical_state &shell_p , 
						   const class spherical_state &shell_n_occ , 
						   const class array<double> &Gaussian_table_GL , 
						   const class multipolar_expansion_str &multipolar_expansion ,
						   const class interaction_class &inter_data_basis , 
						   class HF_nucleons_data &prot_HF_data);

      void Un_hole_double_counting_nn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const class spherical_state &shell_n , 
						   const class spherical_state &shell_n_occ , 
						   const class array<double> &Gaussian_table_GL , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   class HF_nucleons_data &neut_HF_data);

      void Un_hole_double_counting_pn_part_remove (
						   const bool is_it_res , 
						   const bool is_it_pm , 
						   const int pm , 
						   const class spherical_state &shell_n , 
						   const class spherical_state &shell_p_occ , 
						   const class array<double> &Gaussian_table_GL , 
						   const class multipolar_expansion_str &multipolar_expansion , 
						   const class interaction_class &inter_data_basis , 
						   class HF_nucleons_data &neut_HF_data);
    }
    void prot_trivially_equivalent_potential_pp_part_calc (
							   const bool is_it_res , 
							   const bool is_it_pm , 
							   const int pm , 
							   const class CG_str &CGs , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class interaction_class &inter_data_basis , 
							   const class SGI_radial_tabs_str &radial_p_tabs , 
							   const class baryons_data &prot_data_one_configuration , 
							   const class spherical_state &shell_p_HF , 
							   class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potential_pn_part_calc (
							   const bool is_it_res , 
							   const bool is_it_pm , 
							   const int pm , 
							   const class CG_str &CGs , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class interaction_class &inter_data_basis , 
							   const class SGI_radial_tabs_str &radial_n_tabs , 
							   const class baryons_data &prot_data_one_configuration , 
							   const class baryons_data &neut_data_one_configuration , 
							   const class spherical_state &shell_p_HF , 
							   class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potential_nn_part_calc (
							   const bool is_it_res , 
							   const bool is_it_pm , 
							   const int pm , 
							   const class CG_str &CGs , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class interaction_class &inter_data_basis , 
							   const class SGI_radial_tabs_str &radial_n_tabs , 
							   const class baryons_data &neut_data_one_configuration , 
							   const class spherical_state &shell_n_HF , 
							   class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potential_pn_part_calc (
							   const bool is_it_res , 
							   const bool is_it_pm , 
							   const int pm , 
							   const class CG_str &CGs , 
							   const class array<double> &Gaussian_table_GL , 
							   const class multipolar_expansion_str &multipolar_expansion , 
							   const class interaction_class &inter_data_basis , 
							   const class SGI_radial_tabs_str &radial_p_tabs , 
							   const class baryons_data &prot_data_one_configuration , 
							   const class baryons_data &neut_data_one_configuration , 
							   const class spherical_state &shell_n_HF , 
							   class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_pp_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &radial_p_tabs , 
							    const class baryons_data &prot_data_one_configuration , 
							    class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &radial_n_tabs , 
							    const class baryons_data &prot_data_one_configuration , 
							    const class baryons_data &neut_data_one_configuration , 
							    class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &radial_n_tabs , 
							    const class baryons_data &neut_data_one_configuration , 
							    class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_calc (
							    const bool HO_diag , 
							    const class CG_str &CGs , 
							    const class array<double> &Gaussian_table_GL , 
							    const class multipolar_expansion_str &multipolar_expansion , 
							    const class interaction_class &inter_data_basis , 
							    const class SGI_radial_tabs_str &radial_p_tabs , 
							    const class baryons_data &prot_data_one_configuration , 
							    const class baryons_data &neut_data_one_configuration , 
							    class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_pp_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &radial_p_tabs , 
								      const class baryons_data &prot_data_one_configuration , 
								      class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &radial_n_tabs , 
								      const class baryons_data &prot_data_one_configuration , 
								      const class baryons_data &neut_data_one_configuration , 
								      class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_nn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &radial_n_tabs , 
								      const class baryons_data &neut_data_one_configuration , 
								      class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_pn_part_shells_pm_calc (
								      const int pm , 
								      const class CG_str &CGs , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class interaction_class &inter_data_basis , 
								      const class SGI_radial_tabs_str &radial_p_tabs , 
								      const class baryons_data &prot_data_one_configuration , 
								      const class baryons_data &neut_data_one_configuration , 
								      class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class CG_str &CGs , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data_basis , 
						    const class SGI_radial_tabs_str &radial_p_tabs , 
						    const class SGI_radial_tabs_str &radial_n_tabs , 
						    const class baryons_data &prot_data_one_configuration , 
						    const class baryons_data &neut_data_one_configuration , 
						    const class HF_nucleons_data &neut_HF_data , 
						    class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_calc (
						    const bool HO_diag , 
						    const class CG_str &CGs , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion , 
						    const class interaction_class &inter_data_basis , 
						    const class SGI_radial_tabs_str &radial_p_tabs , 
						    const class SGI_radial_tabs_str &radial_n_tabs , 
						    const class baryons_data &prot_data_one_configuration , 
						    const class baryons_data &neut_data_one_configuration , 
						    const class HF_nucleons_data &prot_HF_data , 
						    class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class CG_str &CGs , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data_basis , 
							      const class SGI_radial_tabs_str &radial_p_tabs , 
							      const class SGI_radial_tabs_str &radial_n_tabs , 
							      const class baryons_data &prot_data_one_configuration , 
							      const class baryons_data &neut_data_one_configuration , 
							      const class HF_nucleons_data &neut_HF_data , 
							      class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_shells_pm_calc (
							      const int pm , 
							      const class CG_str &CGs , 
							      const class array<double> &Gaussian_table_GL , 
							      const class multipolar_expansion_str &multipolar_expansion , 
							      const class interaction_class &inter_data_basis , 
							      const class SGI_radial_tabs_str &radial_p_tabs , 
							      const class SGI_radial_tabs_str &radial_n_tabs , 
							      const class baryons_data &prot_data_one_configuration , 
							      const class baryons_data &neut_data_one_configuration , 
							      const class HF_nucleons_data &prot_HF_data , 
							      class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pp_part_remove (
										   const bool HO_diag , 
										   const class array<double> &Gaussian_table_GL , 
										   const class multipolar_expansion_str &multipolar_expansion , 
										   const class interaction_class &inter_data_basis , 
										   const class SGI_radial_tabs_str &radial_p_tabs , 
										   class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
										   const bool HO_diag , 
										   const class array<double> &Gaussian_table_GL , 
										   const class multipolar_expansion_str &multipolar_expansion , 
										   const class interaction_class &inter_data_basis , 
										   const class SGI_radial_tabs_str &radial_n_tabs , 
										   const class HF_nucleons_data &neut_HF_data , 
										   class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_nn_part_remove (
										   const bool HO_diag , 
										   const class array<double> &Gaussian_table_GL , 
										   const class multipolar_expansion_str &multipolar_expansion , 
										   const class interaction_class &inter_data_basis , 
										   const class SGI_radial_tabs_str &radial_n_tabs , 
										   class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_pn_part_remove (
										   const bool HO_diag , 
										   const class array<double> &Gaussian_table_GL , 
										   const class multipolar_expansion_str &multipolar_expansion , 
										   const class interaction_class &inter_data_basis , 
										   const class SGI_radial_tabs_str &radial_p_tabs , 
										   const class HF_nucleons_data &prot_HF_data , 
										   class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_p_tabs , 
											     class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_n_tabs , 
											     const class HF_nucleons_data &neut_HF_data , 
											     class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_n_tabs , 
											     class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_p_tabs , 
											     const class HF_nucleons_data &prot_HF_data , 
											     class HF_nucleons_data &neut_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pp_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_p_tabs , 
											     class HF_nucleons_data &prot_HF_data);

    void prot_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_n_tabs , 
											     const class HF_nucleons_data &neut_HF_data , 
											     class HF_nucleons_data &prot_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_nn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_n_tabs , 
											     class HF_nucleons_data &neut_HF_data);

    void neut_trivially_equivalent_potentials_hole_double_counting_pn_part_shells_pm_remove (
											     const int pm , 
											     const class array<double> &Gaussian_table_GL , 
											     const class multipolar_expansion_str &multipolar_expansion , 
											     const class interaction_class &inter_data_basis , 
											     const class SGI_radial_tabs_str &radial_p_tabs , 
											     const class HF_nucleons_data &prot_HF_data , 
											     class HF_nucleons_data &neut_HF_data);
  }

  namespace SGI_MSGI_OBMEs
  {
    complex<double> prot_OBME_HF_pp_subpart_calc (
						    const class spherical_state &shell_p_in , 
						    const class spherical_state &shell_p_out , 
						    const class spherical_state &shell_p_occ , 
						    const double mp_in , 
						    const double mp_out , 
						    const double mp_occ_in , 
						    const double mp_occ_out , 
						    const complex<double> &SDs_weight , 
						    const class CG_str &CGs , 
						    const class interaction_class &inter_data_basis , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion);

    complex<double> prot_OBME_HF_pn_subpart_calc (
						    const class spherical_state &shell_p_in , 
						    const class spherical_state &shell_p_out , 
						    const class spherical_state &shell_n_occ , 
						    const double mp_in , 
						    const double mp_out , 
						    const double mn_occ_in , 
						    const double mn_occ_out , 
						    const complex<double> &SDs_weight , 
						    const class CG_str &CGs , 
						    const class interaction_class &inter_data_basis , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion); 

    complex<double> prot_OBME_HF_pp_part_calc (
						 const class spherical_state &shell_p_HF_in , 
						 const class spherical_state &shell_p_HF_out , 
						 const bool is_it_only_poles , 
						 const class CG_str &CGs , 
						 const class interaction_class &inter_data_basis , 
						 const class array<double> &Gaussian_table_GL , 
						 const class multipolar_expansion_str &multipolar_expansion , 
						 const class baryons_data &prot_data_one_configuration , 
						 const class HF_nucleons_data &prot_HF_data);

    complex<double> prot_OBME_HF_pn_part_calc (
						 const class spherical_state &shell_p_HF_in , 
						 const class spherical_state &shell_p_HF_out , 
						 const bool is_it_only_poles , 
						 const class CG_str &CGs , 
						 const class interaction_class &inter_data_basis , 
						 const class array<double> &Gaussian_table_GL , 
						 const class multipolar_expansion_str &multipolar_expansion , 
						 const class baryons_data &prot_data_one_configuration , 
						 const class baryons_data &neut_data_one_configuration , 
						 const class HF_nucleons_data &prot_HF_data); 

    complex<double> prot_OBME_HF_hole_double_counting_pp_subpart_calc (
									 const class spherical_state &shell_p_in , 
									 const class spherical_state &shell_p_out , 
									 const class spherical_state &shell_p_occ , 
									 const class interaction_class &inter_data_basis , 
									 const class array<double> &Gaussian_table_GL , 
									 const class multipolar_expansion_str &multipolar_expansion);

    complex<double> prot_OBME_HF_hole_double_counting_pn_subpart_calc (
									 const class spherical_state &shell_p_in , 
									 const class spherical_state &shell_p_out , 
									 const class spherical_state &shell_n_occ , 
									 const class interaction_class &inter_data_basis , 
									 const class array<double> &Gaussian_table_GL , 
									 const class multipolar_expansion_str &multipolar_expansion);

    complex<double> prot_OBME_HF_hole_double_counting_pp_part_calc (
								      const class spherical_state &shell_p_in , 
								      const class spherical_state &shell_p_out , 
								      const bool is_it_only_poles , 
								      const class interaction_class &inter_data_basis , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class HF_nucleons_data &prot_HF_data);

    complex<double> prot_OBME_HF_hole_double_counting_pn_part_calc (
								      const class spherical_state &shell_p_in , 
								      const class spherical_state &shell_p_out , 
								      const bool is_it_only_poles , 
								      const class interaction_class &inter_data_basis , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class HF_nucleons_data &prot_HF_data , 
								      const class HF_nucleons_data &neut_HF_data);

    complex<double> prot_OBME_HF_calc (
					 const class spherical_state &shell_p_in , 
					 const class spherical_state &shell_p_out , 
					 const bool is_it_only_poles , 
					 const class CG_str &CGs , 
					 const class interaction_class &inter_data_basis , 
					 const class array<double> &Gaussian_table_GL , 
					 const class multipolar_expansion_str &multipolar_expansion , 
					 const class baryons_data &prot_data_one_configuration , 
					 const class baryons_data &neut_data_one_configuration , 
					 const class HF_nucleons_data &prot_HF_data , 
					 const class HF_nucleons_data &neut_HF_data);

    void prot_OBMEs_HF_calc (
			     const bool is_it_only_poles , 
			     const class CG_str &CGs , 
			     const class interaction_class &inter_data_basis , 
			     const class array<double> &Gaussian_table_GL , 
			     const class multipolar_expansion_str &multipolar_expansion , 
			     const class baryons_data &prot_data_one_configuration , 
			     const class baryons_data &neut_data_one_configuration , 
			     const class HF_nucleons_data &neut_HF_data , 
			     class HF_nucleons_data &prot_HF_data);

    complex<double> neut_OBME_HF_nn_subpart_calc (
						    const class spherical_state &shell_n_in , 
						    const class spherical_state &shell_n_out , 
						    const class spherical_state &shell_n_occ , 
						    const double mn_in , 
						    const double mn_out , 
						    const double mn_occ_in , 
						    const double mn_occ_out , 
						    const complex<double> &SDs_weight , 
						    const class CG_str &CGs , 
						    const class interaction_class &inter_data_basis , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion);

    complex<double> neut_OBME_HF_pn_subpart_calc (
						    const class spherical_state &shell_n_in , 
						    const class spherical_state &shell_n_out , 
						    const class spherical_state &shell_p_occ , 
						    const double mn_in , 
						    const double mn_out , 
						    const double mp_occ_in , 
						    const double mp_occ_out , 
						    const complex<double> &SDs_weight , 
						    const class CG_str &CGs , 
						    const class interaction_class &inter_data_basis , 
						    const class array<double> &Gaussian_table_GL , 
						    const class multipolar_expansion_str &multipolar_expansion);

    complex<double> neut_OBME_HF_nn_part_calc (
						 const class spherical_state &shell_n_HF_in , 
						 const class spherical_state &shell_n_HF_out , 
						 const bool is_it_only_poles , 
						 const class CG_str &CGs , 
						 const class interaction_class &inter_data_basis , 
						 const class array<double> &Gaussian_table_GL , 
						 const class multipolar_expansion_str &multipolar_expansion , 
						 const class baryons_data &neut_data_one_configuration , 
						 const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_pn_part_calc (
						 const class spherical_state &shell_n_HF_in , 
						 const class spherical_state &shell_n_HF_out , 
						 const bool is_it_only_poles , 
						 const class CG_str &CGs , 
						 const class interaction_class &inter_data_basis , 
						 const class array<double> &Gaussian_table_GL , 
						 const class multipolar_expansion_str &multipolar_expansion , 
						 const class baryons_data &prot_data_one_configuration , 
						 const class baryons_data &neut_data_one_configuration , 
						 const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_hole_double_counting_nn_subpart_calc (
									 const class spherical_state &shell_n_in , 
									 const class spherical_state &shell_n_out , 
									 const class spherical_state &shell_n_occ , 
									 const class interaction_class &inter_data_basis , 
									 const class array<double> &Gaussian_table_GL , 
									 const class multipolar_expansion_str &multipolar_expansion);

    complex<double> neut_OBME_HF_hole_double_counting_pn_subpart_calc (
									 const class spherical_state &shell_n_in , 
									 const class spherical_state &shell_n_out , 
									 const class spherical_state &shell_p_occ , 
									 const class interaction_class &inter_data_basis , 
									 const class array<double> &Gaussian_table_GL , 
									 const class multipolar_expansion_str &multipolar_expansion);

    complex<double> neut_OBME_HF_hole_double_counting_nn_part_calc (
								      const class spherical_state &shell_n_in , 
								      const class spherical_state &shell_n_out , 
								      const bool is_it_only_poles , 
								      const class interaction_class &inter_data_basis , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_hole_double_counting_pn_part_calc (
								      const class spherical_state &shell_n_in , 
								      const class spherical_state &shell_n_out , 
								      const bool is_it_only_poles , 
								      const class interaction_class &inter_data_basis , 
								      const class array<double> &Gaussian_table_GL , 
								      const class multipolar_expansion_str &multipolar_expansion , 
								      const class HF_nucleons_data &prot_HF_data , 
								      const class HF_nucleons_data &neut_HF_data);

    complex<double> neut_OBME_HF_calc (
					 const class spherical_state &shell_n_in , 
					 const class spherical_state &shell_n_out , 
					 const bool is_it_only_poles , 
					 const class CG_str &CGs , 
					 const class interaction_class &inter_data_basis , 
					 const class array<double> &Gaussian_table_GL , 
					 const class multipolar_expansion_str &multipolar_expansion , 
					 const class baryons_data &prot_data_one_configuration , 
					 const class baryons_data &neut_data_one_configuration , 
					 const class HF_nucleons_data &prot_HF_data , 
					 const class HF_nucleons_data &neut_HF_data);

    void neut_OBMEs_HF_calc (
			     const bool is_it_only_poles , 
			     const class CG_str &CGs , 
			     const class interaction_class &inter_data_basis , 
			     const class array<double> &Gaussian_table_GL , 
			     const class multipolar_expansion_str &multipolar_expansion , 
			     const class baryons_data &prot_data_one_configuration , 
			     const class baryons_data &neut_data_one_configuration , 
			     const class HF_nucleons_data &prot_HF_data , 
			     class HF_nucleons_data &neut_HF_data);

    namespace HO_basis
    {
      double prot_OBME_HF_pp_subpart_calc (
					     const int lp , 
					     const double jp , 
					     const int n_HO_in , 
					     const int n_HO_out , 
					     const class spherical_state &shell_p_occ , 
					     const double mp_in , 
					     const double mp_out , 
					     const double mp_occ_in , 
					     const double mp_occ_out , 
					     const complex<double> &SDs_weight , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion);

      double prot_OBME_HF_pn_subpart_calc (
					     const int lp , 
					     const double jp , 
					     const int n_HO_in , 
					     const int n_HO_out , 
					     const class spherical_state &shell_n_occ , 
					     const double mp_in , 
					     const double mp_out , 
					     const double mn_occ_in , 
					     const double mn_occ_out , 
					     const complex<double> &SDs_weight , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion);

      double prot_OBME_HF_pp_part_calc (
					  const int lp , 
					  const double jp , 
					  const int n_HO_in , 
					  const int n_HO_out , 
					  const class CG_str &CGs , 
					  const class interaction_class &inter_data_basis , 
					  const class array<double> &Gaussian_table_GL , 
					  const class multipolar_expansion_str &multipolar_expansion , 
					  const class baryons_data &prot_data_one_configuration , 
					  const class HF_nucleons_data &prot_HF_data);

      double prot_OBME_HF_pn_part_calc (
					  const int lp , 
					  const double jp , 
					  const int n_HO_in , 
					  const int n_HO_out , 
					  const class CG_str &CGs , 
					  const class interaction_class &inter_data_basis , 
					  const class array<double> &Gaussian_table_GL , 
					  const class multipolar_expansion_str &multipolar_expansion , 
					  const class baryons_data &prot_data_one_configuration , 
					  const class baryons_data &neut_data_one_configuration , 
					  const class HF_nucleons_data &prot_HF_data);

      double prot_OBME_HF_hole_double_counting_pp_subpart_calc (
								  const int lp , 
								  const double jp , 
								  const int n_HO_in , 
								  const int n_HO_out , 
								  const class spherical_state &shell_p_occ , 
								  const class interaction_class &inter_data_basis , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion);

      double prot_OBME_HF_hole_double_counting_pn_subpart_calc (
								  const int lp , 
								  const double jp , 
								  const int n_HO_in , 
								  const int n_HO_out , 
								  const class spherical_state &shell_n_occ , 
								  const class interaction_class &inter_data_basis , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion);

      double prot_OBME_HF_hole_double_counting_pp_part_calc (
							       const int lp , 
							       const double jp , 
							       const int n_HO_in , 
							       const int n_HO_out , 
							       const class interaction_class &inter_data_basis , 
							       const class array<double> &Gaussian_table_GL , 
							       const class multipolar_expansion_str &multipolar_expansion , 
							       const class HF_nucleons_data &prot_HF_data);

      double prot_OBME_HF_hole_double_counting_pn_part_calc (
							       const int lp , 
							       const double jp , 
							       const int n_HO_in , 
							       const int n_HO_out , 
							       const class interaction_class &inter_data_basis , 
							       const class array<double> &Gaussian_table_GL , 
							       const class multipolar_expansion_str &multipolar_expansion , 
							       const class HF_nucleons_data &prot_HF_data , 
							       const class HF_nucleons_data &neut_HF_data);

      double prot_OBME_HF_calc (
				  const int lp , 
				  const double jp , 
				  const int n_HO_in , 
				  const int n_HO_out , 
				  const class CG_str &CGs , 
				  const class interaction_class &inter_data_basis , 
				  const class array<double> &Gaussian_table_GL , 
				  const class multipolar_expansion_str &multipolar_expansion , 
				  const class baryons_data &prot_data_one_configuration , 
				  const class baryons_data &neut_data_one_configuration , 
				  const class HF_nucleons_data &prot_HF_data , 
				  const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_nn_subpart_calc (
					     const int ln , 
					     const double jn , 
					     const int n_HO_in , 
					     const int n_HO_out , 
					     const class spherical_state &shell_n_occ , 
					     const double mn_in , 
					     const double mn_out , 
					     const double mn_occ_in , 
					     const double mn_occ_out , 
					     const complex<double> &SDs_weight , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion);

      double neut_OBME_HF_pn_subpart_calc (
					     const int ln , 
					     const double jn , 
					     const int n_HO_in , 
					     const int n_HO_out , 
					     const class spherical_state &shell_p_occ , 
					     const double mn_in , 
					     const double mn_out , 
					     const double mp_occ_in , 
					     const double mp_occ_out , 
					     const complex<double> &SDs_weight , 
					     const class CG_str &CGs , 
					     const class interaction_class &inter_data_basis , 
					     const class array<double> &Gaussian_table_GL , 
					     const class multipolar_expansion_str &multipolar_expansion);

      double neut_OBME_HF_nn_part_calc (
					  const int ln , 
					  const double jn , 
					  const int n_HO_in , 
					  const int n_HO_out , 
					  const class CG_str &CGs , 
					  const class interaction_class &inter_data_basis , 
					  const class array<double> &Gaussian_table_GL , 
					  const class multipolar_expansion_str &multipolar_expansion , 
					  const class baryons_data &neut_data_one_configuration , 
					  const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_pn_part_calc (
					  const int ln , 
					  const double jn , 
					  const int n_HO_in , 
					  const int n_HO_out , 
					  const class CG_str &CGs , 
					  const class interaction_class &inter_data_basis , 
					  const class array<double> &Gaussian_table_GL , 
					  const class multipolar_expansion_str &multipolar_expansion , 
					  const class baryons_data &prot_data_one_configuration , 
					  const class baryons_data &neut_data_one_configuration , 
					  const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_hole_double_counting_nn_subpart_calc (
								  const int ln , 
								  const double jn , 
								  const int n_HO_in , 
								  const int n_HO_out , 
								  const class spherical_state &shell_n_occ , 
								  const class interaction_class &inter_data_basis , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion);

      double neut_OBME_HF_hole_double_counting_pn_subpart_calc (
								  const int ln , 
								  const double jn , 
								  const int n_HO_in , 
								  const int n_HO_out , 
								  const class spherical_state &shell_p_occ , 
								  const class interaction_class &inter_data_basis , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion);

      double neut_OBME_HF_hole_double_counting_nn_part_calc (
							       const int ln , 
							       const double jn , 
							       const int n_HO_in , 
							       const int n_HO_out , 
							       const class interaction_class &inter_data_basis , 
							       const class array<double> &Gaussian_table_GL , 
							       const class multipolar_expansion_str &multipolar_expansion , 
							       const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_hole_double_counting_pn_part_calc (
							       const int ln , 
							       const double jn , 
							       const int n_HO_in , 
							       const int n_HO_out , 
							       const class interaction_class &inter_data_basis , 
							       const class array<double> &Gaussian_table_GL , 
							       const class multipolar_expansion_str &multipolar_expansion , 
							       const class HF_nucleons_data &prot_HF_data , 
							       const class HF_nucleons_data &neut_HF_data);

      double neut_OBME_HF_calc (
				  const int ln , 
				  const double jn , 
				  const int n_HO_in , 
				  const int n_HO_out , 
				  const class CG_str &CGs , 
				  const class interaction_class &inter_data_basis , 
				  const class array<double> &Gaussian_table_GL , 
				  const class multipolar_expansion_str &multipolar_expansion , 
				  const class baryons_data &prot_data_one_configuration , 
				  const class baryons_data &neut_data_one_configuration , 
				  const class HF_nucleons_data &prot_HF_data , 
				  const class HF_nucleons_data &neut_HF_data);

      double OBME_HF_calc (
			   const enum particle_type particle , 
			   const int l , 
			   const double j , 
			   const int n_HO_in , 
			   const int n_HO_out , 	
			   const class CG_str &CGs , 
			   const class interaction_class &inter_data_basis , 
			   const class array<double> &Gaussian_table_GL , 
			   const class multipolar_expansion_str &multipolar_expansion , 
			   const class baryons_data &prot_data_one_configuration , 
			   const class baryons_data &neut_data_one_configuration , 
			   const class HF_nucleons_data &prot_HF_data , 
			   const class HF_nucleons_data &neut_HF_data);
    }
  }

  namespace one_configuration
  {
    void SDs_1h_coefficients_alloc_calc (
					 const class baryons_data &data_one_configuration , 
					 const unsigned int new_dimension_GS , 
					 const int highest_occupied_lj_n , 
					 const int l , 
					 const double j , 
					 class HF_nucleons_data &HF_data);

    void SDs_GS_alloc_fill (
			    const enum space_type SD_space , 
			    const class GSM_vector_one_configuration &PSI , 
			    const int N_valence_nucleons , 
			    const unsigned int new_dimension_GS , 
			    const int l , 
			    const double j , 
			    class HF_nucleons_data &HF_data);

    void configuration_to_diagonalize_index_BP_determine (
							  const enum space_type space , 
							  const int l , 
							  const double j , 
							  const class HF_nucleons_data &HF_data , 
							  class baryons_data &data_one_configuration);

    void HF_many_body_data_alloc_calc (
				       const bool is_there_cout , 
				       const enum space_type space ,
				       const enum interaction_type inter , 
				       const class lj_table<class correlated_state_str> &basis_PSI_qn_tab , 
				       const class TBMEs_class &TBMEs_pn , 
				       class baryons_data &prot_data_one_configuration , 
				       class baryons_data &neut_data_one_configuration , 
				       class HF_nucleons_data &HF_data);

    void all_HF_many_body_data_alloc_calc (
					   const bool is_there_cout , 
					   const class input_data_str &input_data , 
					   const class interaction_class &inter_data_basis , 
					   const class TBMEs_class &TBMEs_pn ,
					   class baryons_data &prot_data_one_configuration , 
					   class baryons_data &neut_data_one_configuration , 
					   class HF_nucleons_data &prot_HF_data , 
					   class HF_nucleons_data &neut_HF_data);

    void data_alloc_calc (
			  const class input_data_str &input_data , 
			  const class baryons_data &prot_Y_data , 
			  const class baryons_data &neut_Y_data , 
			  const class interaction_class &inter_data_basis , 
			  const class HF_nucleons_data &prot_HF_data , 
			  const class HF_nucleons_data &neut_HF_data , 
			  class baryons_data &prot_data_one_configuration , 
			  class baryons_data &neut_data_one_configuration ,
			  class TBMEs_class &TBMEs_pn);
  }

  complex<double> Up_HF_normalizing_sum_calc (
					      const int lp , 
					      const double jp , 
					      const class baryons_data &prot_data_one_configuration , 
					      const class HF_nucleons_data &prot_HF_data);

  complex<double> Un_HF_normalizing_sum_calc (
					      const int ln , 
					      const double jn , 
					      const class baryons_data &neut_data_one_configuration , 
					      class HF_nucleons_data &neut_HF_data);

  void U_HF_normalizing_sums_calc (
				   const class baryons_data &prot_data_one_configuration , 
				   const class baryons_data &neut_data_one_configuration , 
				   class HF_nucleons_data &HF_data);

  void potentials_calc (
			const bool HO_diag , 
			const double new_potential_fraction , 
			const class CG_str &CGs , 
			const class interaction_class &inter_data_basis , 
			const class array<double> &Gaussian_table_GL , 
			const class multipolar_expansion_str &multipolar_expansion , 
			const class baryons_data &prot_data_one_configuration , 
			const class baryons_data &neut_data_one_configuration , 
			class HF_nucleons_data &prot_HF_data , 
			class HF_nucleons_data &neut_HF_data);

  void potentials_shells_iteration_calc (
					 const bool is_there_cout , 
					 const class input_data_str &input_data , 
					 const class interaction_class &inter_data_basis , 
					 const class baryons_data &prot_Y_data , 
					 const class baryons_data &neut_Y_data , 
					 const unsigned int iter , 
					 const bool HO_diag ,
					 const double test ,
					 const class CG_str &CGs , 
					 const class array<double> &Gaussian_table_GL , 
					 const class multipolar_expansion_str &multipolar_expansion , 
					 const class array<double> &V_Coulomb_tab_uniform , 
					 class HF_nucleons_data &prot_HF_data , 
					 class HF_nucleons_data &neut_HF_data);

  void iterative_potentials_shells_OBMEs_calc_HO_removal (
							  const bool is_there_cout ,
							  const class input_data_str &input_data , 
							  const class interaction_class &inter_data_basis , 
							  class HF_nucleons_data &prot_HF_data , 
							  class HF_nucleons_data &neut_HF_data , 
							  class baryons_data &prot_Y_data , 
							  class baryons_data &neut_Y_data);
 
  void potentials_shells_OBMEs_realloc_calc (
					     const bool is_there_cout , 
					     const class input_data_str &input_data , 
					     const class interaction_class &inter_data_basis , 
					     class HF_nucleons_data &prot_HF_data , 
					     class HF_nucleons_data &neut_HF_data , 
					     class baryons_data &prot_Y_data , 
					     class baryons_data &neut_Y_data);
	
  void iterative_potentials_shells_OBMEs_calc (
					       const bool is_there_cout , 
					       const class input_data_str &input_data , 
					       const class interaction_class &inter_data_basis , 
					       class HF_nucleons_data &prot_HF_data , 
					       class HF_nucleons_data &neut_HF_data , 
					       class baryons_data &prot_Y_data , 
					       class baryons_data &neut_Y_data);
} 
#endif


