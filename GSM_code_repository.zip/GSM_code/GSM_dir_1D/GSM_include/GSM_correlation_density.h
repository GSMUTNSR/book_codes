#ifndef GSMCORRELATIONDENSITY_H
#define GSMCORRELATIONDENSITY_H

// TYPE is double or complex
// -------------------------

namespace correlation_density
{
  void NBMEs_diagonal_pp_nn_part_calc (
				       const bool is_it_HO_expansion , 
				       const class interaction_class &inter_data , 
				       const class baryons_data &data , 
				       const class array<TYPE> &rk_OBMEs , 
				       const class array<double> &theta12_Dirac_multipolar_tab , 
				       const class lm_table<unsigned int> &lm_indices , 
				       const class ljm_table<unsigned int> &ljm_indices , 
				       const class array<double> &Ylm_table_coupled_to_l , 
				       const class array<double> &Ylm_table_coupled_to_j , 
				       const class array<double> &CGs , 
				       const class Slater_determinant &SD , 
				       class array<TYPE> &angular_densities_TBMEs ,
				       class array<TYPE> &density_TBMEs ,
				       class array<TYPE> &angular_densities_NBMEs , 
				       class array<TYPE> &density_NBMEs);

  void NBMEs_diagonal_pn_part_calc (
				    const bool is_it_HO_expansion , 
				    const class interaction_class &inter_data , 
				    const class baryons_data &prot_Y_data , 
				    const class baryons_data &neut_Y_data , 
				    const class array<TYPE> &rk_OBMEs_p , 
				    const class array<TYPE> &rk_OBMEs_n , 								
				    const class array<double> &theta12_Dirac_multipolar_tab , 
				    const class lm_table<unsigned int> &lm_indices , 
				    const class ljm_table<unsigned int> &ljm_indices , 
				    const class array<double> &Ylm_table_coupled_to_l , 
				    const class array<double> &Ylm_table_coupled_to_j , 
				    const class array<double> &CGs , 
				    const class Slater_determinant &SDp , 
				    const class Slater_determinant &SDn , 
				    class array<TYPE> &angular_densities_TBMEs_pn , 
				    class array<TYPE> &density_TBMEs_pn , 
				    class array<TYPE> &angular_densities_NBMEs , 
				    class array<TYPE> &density_NBMEs);

  void diagonal_part_pn_prot_part_pn_calc (
					   const bool is_it_HO_expansion , 
					   const class interaction_class &inter_data , 
					   const class array<TYPE> &rk_OBMEs_p , 
					   const class array<double> &theta12_Dirac_multipolar_tab , 
					   const class lm_table<unsigned int> &lm_indices , 
					   const class ljm_table<unsigned int> &ljm_indices , 
					   const class array<double> &Ylm_table_coupled_to_l , 
					   const class array<double> &Ylm_table_coupled_to_j , 
					   const class array<double> &CGs , 				    						
					   const class GSM_vector &PSI_IN ,
					   const class GSM_vector &PSI_OUT , 
					   class array<TYPE> &angular_densities_tab , 
					   class array<TYPE> &density_tab);
  

  void diagonal_part_pn_neut_part_pn_calc (
					   const bool is_it_HO_expansion , 
					   const class interaction_class &inter_data , 
					   const class array<TYPE> &rk_OBMEs_n , 
					   const class array<double> &theta12_Dirac_multipolar_tab , 
					   const class lm_table<unsigned int> &lm_indices , 
					   const class ljm_table<unsigned int> &ljm_indices , 
					   const class array<double> &Ylm_table_coupled_to_l , 
					   const class array<double> &Ylm_table_coupled_to_j , 
					   const class array<double> &CGs , 
					   const class GSM_vector &PSI_IN ,
					   const class GSM_vector &PSI_OUT , 
					   class array<TYPE> &angular_densities_tab , 
					   class array<TYPE> &density_tab);

  void diagonal_part_pn_part_pn_Nval_larger_calc (
						       const bool is_it_HO_expansion , 
						       const class interaction_class &inter_data , 
						       const class array<TYPE> &rk_OBMEs_p , 
						       const class array<TYPE> &rk_OBMEs_n , 
						       const class array<double> &theta12_Dirac_multipolar_tab , 
						       const class lm_table<unsigned int> &lm_indices , 
						       const class ljm_table<unsigned int> &ljm_indices , 
						       const class array<double> &Ylm_table_coupled_to_l , 
						       const class array<double> &Ylm_table_coupled_to_j , 
						       const class array<double> &CGs , 
						       const class GSM_vector &PSI_IN ,
						       const class GSM_vector &PSI_OUT ,
						       class array<TYPE> &angular_densities_tab , 
						       class array<TYPE> &density_tab);

  
  void diagonal_part_pn_part_pn_Zval_larger_calc (
						       const bool is_it_HO_expansion , 
						       const class interaction_class &inter_data , 
						       const class array<TYPE> &rk_OBMEs_p , 
						       const class array<TYPE> &rk_OBMEs_n , 
						       const class array<double> &theta12_Dirac_multipolar_tab , 
						       const class lm_table<unsigned int> &lm_indices , 
						       const class ljm_table<unsigned int> &ljm_indices , 
						       const class array<double> &Ylm_table_coupled_to_l , 
						       const class array<double> &Ylm_table_coupled_to_j , 
						       const class array<double> &CGs , 
						       const class GSM_vector &PSI_IN ,
						       const class GSM_vector &PSI_OUT ,
						       class array<TYPE> &angular_densities_tab , 
						       class array<TYPE> &density_tab);


  void NBMEs_one_jump_mu_no_phase_calc (
					const bool is_it_HO_expansion , 
					const class interaction_class &inter_data , 
					const unsigned int out_jumps , 
					const unsigned int in_jumps , 
					const class Slater_determinant &outSD , 
					const class baryons_data &data , 
					const class array<TYPE> &rk_OBMEs , 
					const class array<double> &theta12_Dirac_multipolar_tab , 
					const class lm_table<unsigned int> &lm_indices , 
					const class ljm_table<unsigned int> &ljm_indices , 
					const class array<double> &Ylm_table_coupled_to_l , 
					const class array<double> &Ylm_table_coupled_to_j , 
					const class array<double> &CGs , 
					class array<TYPE> &angular_densities_TBMEs , 
					class array<TYPE> &density_TBMEs , 
					class array<TYPE> &angular_densities_NBMEs_no_phase_fixed_inSD , 
					class array<TYPE> &density_NBMEs_no_phase_fixed_inSD);


  void NBMEs_pn_no_phase_one_jump_p_calc (
					  const bool is_it_HO_expansion , 
					  const class interaction_class &inter_data , 
					  const unsigned int p_in , 
					  const unsigned int p_out , 
					  const class Slater_determinant &SDn , 
					  const class baryons_data &prot_Y_data , 
					  const class baryons_data &neut_Y_data , 
					  const class array<TYPE> &rk_OBMEs_p , 
					  const class array<TYPE> &rk_OBMEs_n , 
					  const class array<double> &theta12_Dirac_multipolar_tab , 
					  const class lm_table<unsigned int> &lm_indices , 
					  const class ljm_table<unsigned int> &ljm_indices , 
					  const class array<double> &Ylm_table_coupled_to_l , 
					  const class array<double> &Ylm_table_coupled_to_j , 
					  const class array<double> &CGs , 
					  class array<TYPE> &angular_densities_NBMEs_pn_no_phase_fixed_pair , 
					  class array<TYPE> &density_NBMEs_pn_no_phase_fixed_pair);

  void NBMEs_pn_no_phase_one_jump_n_calc (
					  const bool is_it_HO_expansion , 
					  const class interaction_class &inter_data , 
					  const unsigned int n_in , 
					  const unsigned int n_out , 
					  const class Slater_determinant &SDp , 
					  const class baryons_data &prot_Y_data , 
					  const class baryons_data &neut_Y_data , 
					  const class array<TYPE> &rk_OBMEs_p , 
					  const class array<TYPE> &rk_OBMEs_n , 
					  const class array<double> &theta12_Dirac_multipolar_tab , 
					  const class lm_table<unsigned int> &lm_indices , 
					  const class ljm_table<unsigned int> &ljm_indices , 
					  const class array<double> &Ylm_table_coupled_to_l , 
					  const class array<double> &Ylm_table_coupled_to_j , 
					  const class array<double> &CGs , 
					  class array<TYPE> &angular_densities_NBMEs_no_phase_fixed_pair , 
					  class array<TYPE> &density_NBMEs_no_phase_fixed_pair);

  void NBMEs_jumps_pp_nn_calc_store (
				     const bool is_it_HO_expansion , 
				     const class interaction_class &inter_data , 
				     const int nmax_holes_mu , 
				     const int n_scat_max_mu , 
				     const int Emu_max_hw , 
				     const unsigned int BPmu , 
				     const int Smu , 
				     const int n_spec_mu , 
				     const int iMmu , 
				     const int n_scat_mu_out , 
				     const unsigned int iCmu_out , 
				     const unsigned int outSDmu_index , 
				     const class Slater_determinant &outSDmu , 
				     const class baryons_data &data , 
				     const class array<TYPE> &rk_OBMEs , 
				     const class array<double> &theta12_Dirac_multipolar_tab , 
				     const class lm_table<unsigned int> &lm_indices , 
				     const class ljm_table<unsigned int> &ljm_indices , 
				     const class array<double> &Ylm_table_coupled_to_l , 
				     const class array<double> &Ylm_table_coupled_to_j , 
				     const class array<double> &CGs , 
				     bool &is_there_one_jump_calc , 
				     bool &is_there_two_jumps_calc , 
				     class jumps_data_str &one_jump_mu , 
				     class jumps_data_str &two_jumps_mu , 
				     class array<TYPE> &angular_densities_NBMEs_one_jump_mu_no_phase_fixed_inSD , 
				     class array<TYPE> &angular_densities_NBMEs_one_jump_mu , 
				     class array<TYPE> &angular_densities_TBMEs_mu , 
				     class array<TYPE> &angular_densities_NBMEs_two_jumps_mu , 
				     class array<TYPE> &density_NBMEs_one_jump_mu_no_phase_fixed_inSD , 
				     class array<TYPE> &density_NBMEs_one_jump_mu , 
				     class array<TYPE> &density_TBMEs_mu , 
				     class array<TYPE> &density_NBMEs_two_jumps_mu);
  
  void densities_part_calc (
			    const class jumps_data_str &jumps , 
			    const class array<bool> &is_configuration_accepted_tab , 
			    const class array<unsigned int> &PSI_IN_indices , 
			    const class array<TYPE> &angular_densities_NBMEs_jumps , 
			    const class array<TYPE> &density_NBMEs_jumps , 
			    const TYPE &PSI_OUT_component_TRS_factor , 
			    const class GSM_vector &PSI_IN ,
			    class array<TYPE> &angular_densities_part_tab , 
			    class array<TYPE> &density_part_tab);

  void jumps_p_prot_part_pn_calc (
				  const bool is_it_HO_expansion , 
				  const class interaction_class &inter_data , 
				  const class array<TYPE> &rk_OBMEs_p , 
				  const class array<double> &theta12_Dirac_multipolar_tab , 
				  const class lm_table<unsigned int> &lm_indices , 
				  const class ljm_table<unsigned int> &ljm_indices , 
				  const class array<double> &Ylm_table_coupled_to_l , 
				  const class array<double> &Ylm_table_coupled_to_j , 
				  const class array<double> &CGs , 
				  const class GSM_vector &PSI_IN ,
				  const class GSM_vector &PSI_OUT , 
				  class array<TYPE> &angular_densities_tab , 
				  class array<TYPE> &density_tab);

  void jumps_n_neut_part_pn_calc (
				  const bool is_it_HO_expansion , 
				  const class interaction_class &inter_data , 
				  const class array<TYPE> &rk_OBMEs_n , 
				  const class array<double> &theta12_Dirac_multipolar_tab , 
				  const class lm_table<unsigned int> &lm_indices , 
				  const class ljm_table<unsigned int> &ljm_indices , 
				  const class array<double> &Ylm_table_coupled_to_l , 
				  const class array<double> &Ylm_table_coupled_to_j , 
				  const class array<double> &CGs , 
				  const class GSM_vector &PSI_IN ,
				  const class GSM_vector &PSI_OUT , 
				  class array<TYPE> &angular_densities_tab , 
				  class array<TYPE> &density_tab);

  void one_jump_p_pn_part_pn_calc (
				   const bool is_it_HO_expansion , 
				   const class interaction_class &inter_data , 
				   const class array<TYPE> &rk_OBMEs_p , 
				   const class array<TYPE> &rk_OBMEs_n , 
				   const class array<double> &theta12_Dirac_multipolar_tab , 
				   const class lm_table<unsigned int> &lm_indices , 
				   const class ljm_table<unsigned int> &ljm_indices , 
				   const class array<double> &Ylm_table_coupled_to_l , 
				   const class array<double> &Ylm_table_coupled_to_j , 
				   const class array<double> &CGs , 
										
				   const class GSM_vector &PSI_IN ,
				   const class GSM_vector &PSI_OUT , 
				   class array<TYPE> &angular_densities_tab , 
				   class array<TYPE> &density_tab);

  void one_jump_n_pn_part_pn_calc (
				   const bool is_it_HO_expansion , 
				   const class interaction_class &inter_data , 
				   const class array<TYPE> &rk_OBMEs_p , 
				   const class array<TYPE> &rk_OBMEs_n , 
				   const class array<double> &theta12_Dirac_multipolar_tab , 
				   const class lm_table<unsigned int> &lm_indices , 
				   const class ljm_table<unsigned int> &ljm_indices , 
				   const class array<double> &Ylm_table_coupled_to_l , 
				   const class array<double> &Ylm_table_coupled_to_j , 
				   const class array<double> &CGs , 
				   const class GSM_vector &PSI_IN ,
				   const class GSM_vector &PSI_OUT , 
				   class array<TYPE> &angular_densities_tab , 
				   class array<TYPE> &density_tab);

  void two_jumps_pn_part_pn_Nval_larger_calc (
						   const bool is_it_HO_expansion , 
						   const class interaction_class &inter_data , 
						   const class array<TYPE> &rk_OBMEs_p , 
						   const class array<TYPE> &rk_OBMEs_n , 
						   const class array<double> &theta12_Dirac_multipolar_tab , 
						   const class lm_table<unsigned int> &lm_indices , 
						   const class ljm_table<unsigned int> &ljm_indices , 
						   const class array<double> &Ylm_table_coupled_to_l , 
						   const class array<double> &Ylm_table_coupled_to_j , 
						   const class array<double> &CGs , 
						   const class GSM_vector &PSI_IN ,
						   const class GSM_vector &PSI_OUT , 
						   class array<TYPE> &angular_densities_tab , 
						   class array<TYPE> &density_tab);
  
  void two_jumps_pn_part_pn_Zval_larger_calc (const bool is_it_HO_expansion , 
						   const class interaction_class &inter_data , 
						   const class array<TYPE> &rk_OBMEs_p , 
						   const class array<TYPE> &rk_OBMEs_n , 
						   const class array<double> &theta12_Dirac_multipolar_tab , 
						   const class lm_table<unsigned int> &lm_indices , 
						   const class ljm_table<unsigned int> &ljm_indices , 
						   const class array<double> &Ylm_table_coupled_to_l , 
						   const class array<double> &Ylm_table_coupled_to_j , 
						   const class array<double> &CGs , 
						   const class GSM_vector &PSI_IN ,  
						   const class GSM_vector &PSI_OUT ,
						   class array<TYPE> &angular_densities_tab , 
						   class array<TYPE> &density_tab);

  void pn_calc_one_pair (
			 const bool is_it_HO_expansion , 
			 const class interaction_class &inter_data , 
			 const class GSM_vector &PSI_IN ,
			 const class GSM_vector &PSI_OUT , 
			 const class array<TYPE> &rk_OBMEs_p , 
			 const class array<TYPE> &rk_OBMEs_n , 
			 const class array<double> &theta12_Dirac_multipolar_tab , 
			 const class lm_table<unsigned int> &lm_indices , 
			 const class ljm_table<unsigned int> &ljm_indices , 
			 const class array<double> &Ylm_table_coupled_to_l , 
			 const class array<double> &Ylm_table_coupled_to_j , 
			 const class array<double> &CGs ,  
			 class array<TYPE> &angular_densities_pp_tab , 
			 class array<TYPE> &angular_densities_nn_tab , 
			 class array<TYPE> &angular_densities_pn_tab , 
			 class array<TYPE> &density_pp_tab , 
			 class array<TYPE> &density_nn_tab , 
			 class array<TYPE> &density_pn_tab);
  
  void diagonal_part_pp_nn_calc (
				 const bool is_it_HO_expansion , 
				 const class interaction_class &inter_data , 
				 const class array<TYPE> &rk_OBMEs , 
				 const class array<double> &theta12_Dirac_multipolar_tab , 
				 const class lm_table<unsigned int> &lm_indices , 
				 const class ljm_table<unsigned int> &ljm_indices , 
				 const class array<double> &Ylm_table_coupled_to_l , 
				 const class array<double> &Ylm_table_coupled_to_j , 
				 const class array<double> &CGs ,
				 const class GSM_vector &PSI_IN ,
				 const class GSM_vector &PSI_OUT ,  
				 class array<TYPE> &angular_densities_tab , 
				 class array<TYPE> &density_tab);

  void jumps_part_pp_nn_calc (
			      const bool is_it_HO_expansion , 
			      const class interaction_class &inter_data , 
			      const class array<TYPE> &rk_OBMEs , 
			      const class array<double> &theta12_Dirac_multipolar_tab , 
			      const class lm_table<unsigned int> &lm_indices , 
			      const class ljm_table<unsigned int> &ljm_indices , 
			      const class array<double> &Ylm_table_coupled_to_l , 
			      const class array<double> &Ylm_table_coupled_to_j , 
			      const class array<double> &CGs ,
			      const class GSM_vector &PSI_IN ,
			      const class GSM_vector &PSI_OUT ,  
			      class array<TYPE> &angular_densities_tab , 
			      class array<TYPE> &density_tab);

  void pp_nn_calc_one_pair (
			    const bool is_it_HO_expansion , 
			    const class interaction_class &inter_data , 
			    const class array<TYPE> &rk_OBMEs , 
			    const class array<double> &theta12_Dirac_multipolar_tab , 
			    const class lm_table<unsigned int> &lm_indices , 
			    const class ljm_table<unsigned int> &ljm_indices , 
			    const class array<double> &Ylm_table_coupled_to_l , 
			    const class array<double> &Ylm_table_coupled_to_j , 
			    const class array<double> &CGs , 
			    const class GSM_vector &PSI_IN ,
			    const class GSM_vector &PSI_OUT , 
			    class array<TYPE> &angular_densities_tab , 
			    class array<TYPE> &density_tab);

  void pn_calc_one_pair (
			 const bool is_it_HO_expansion , 
			 const class interaction_class &inter_data , 
			 const class array<TYPE> &rk_OBMEs_p , 
			 const class array<TYPE> &rk_OBMEs_n , 
			 const class array<double> &theta12_Dirac_multipolar_tab , 
			 const class lm_table<unsigned int> &lm_indices , 
			 const class ljm_table<unsigned int> &ljm_indices , 
			 const class array<double> &Ylm_table_coupled_to_l , 
			 const class array<double> &Ylm_table_coupled_to_j , 
			 const class array<double> &CGs , 
			 const class GSM_vector &PSI_IN ,
			 const class GSM_vector &PSI_OUT ,  
			 class array<TYPE> &angular_densities_pp_tab , 
			 class array<TYPE> &angular_densities_nn_tab , 
			 class array<TYPE> &angular_densities_pn_tab , 
			 class array<TYPE> &density_pp_tab , 
			 class array<TYPE> &density_nn_tab , 
			 class array<TYPE> &density_pn_tab);
 
  void calc_one_pair (
		      const bool is_it_radial ,
		      const bool is_it_Gauss_Legendre ,
		      const bool is_it_HO_expansion , 
		      const class interaction_class &inter_data , 
		      const class GSM_vector &PSI_IN ,
		      const class GSM_vector &PSI_OUT , 
		      const class array<double> &theta12_Dirac_multipolar_tab , 
		      const class lm_table<unsigned int> &lm_indices , 
		      const class ljm_table<unsigned int> &ljm_indices , 
		      const class array<double> &Ylm_table_coupled_to_l , 
		      const class array<double> &Ylm_table_coupled_to_j , 
		      const class array<double> &CGs , 
		      class baryons_data &prot_Y_data , 
		      class baryons_data &neut_Y_data , 
		      class array<TYPE> &angular_densities_pp_tab , 
		      class array<TYPE> &angular_densities_nn_tab , 
		      class array<TYPE> &angular_densities_pn_tab , 
		      class array<TYPE> &density_pp_tab , 
		      class array<TYPE> &density_nn_tab , 
		      class array<TYPE> &density_pn_tab);
  
  void calc_store_one_pair (
			    const bool is_it_radial ,
			    const bool is_it_Gauss_Legendre ,
			    const bool is_it_HO_expansion , 
			    const class interaction_class &inter_data , 
			    const class array<double> &rk_tab ,
			    const class array<double> &theta_tab ,
			    const class correlated_state_str &PSI_qn , 
			    const class GSM_vector &PSI , 
			    class baryons_data &prot_Y_data , 
			    class baryons_data &neut_Y_data);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class interaction_class &inter_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab , 
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data);
}

#endif


