#ifndef GSMVECTORHELPERONECONFIGURATIONCLASS_H
#define GSMVECTORHELPERONECONFIGURATIONCLASS_H

using namespace GSM_vector_dimensions;

// TYPE is double or complex
// -------------------------

class GSM_vector_helper_one_configuration_class
{
public:

  GSM_vector_helper_one_configuration_class ();
 
  GSM_vector_helper_one_configuration_class (
					     const enum space_type space_c , 
					     const enum interaction_type inter_c , 
					     const class baryons_data &prot_Y_data , 
					     const class baryons_data &neut_Y_data , 
					     const double J_c , 
					     const double M_c , 
					     const bool is_it_TRS_for_M_zero);
  
  explicit GSM_vector_helper_one_configuration_class (const class GSM_vector_helper_one_configuration_class &X);

  ~GSM_vector_helper_one_configuration_class ();
  
  void allocate (
		 const enum space_type space_c , 
		 const enum interaction_type inter_c , 
		 const class baryons_data &prot_Y_data_c , 
		 const class baryons_data &neut_Y_data_c , 
		 const double J_c , 
		 const double M_c , 
		 const bool is_it_TRS_for_M_zero);

  void allocate_fill (const class GSM_vector_helper_one_configuration_class &X);

  void deallocate ();
  
  enum space_type get_space () const
  {
    return space;
  }
  
  enum interaction_type get_inter () const
  {
    return inter;
  }
  
  unsigned int get_BP () const
  {
    return BP;
  }
  
  unsigned int get_iC () const
  {
    return iC;
  }
  
  unsigned int get_BPp () const
  {
    return BPp;
  }
  
  unsigned int get_iCp () const
  {
    return iCp;
  }
  
  unsigned int get_BPn () const
  {
    return BPn;
  }
  
  unsigned int get_iCn () const
  {
    return iCn;
  }

  double get_J () const
  {
    return J;
  }
  
  double get_M () const
  {
    return M;
  }
  
  int get_iM () const
  {
    return iM;
  }

  int get_TRS_iM () const
  {
    return TRS_iM;
  }

  int get_iMp_max () const
  {
    return iMp_max;
  }

  int get_iMn_max () const
  {
    return iMn_max;
  }

  int get_iMp_min_M () const
  {
    return iMp_min_M;
  }

  int get_iMp_max_M () const
  {
    return iMp_max_M;
  }

  int get_iMn_min_M () const
  {
    return iMn_min_M;
  }

  int get_iMn_max_M () const
  {
    return iMn_max_M;
  }

  unsigned int get_is_it_TRS () const
  {
    return is_it_TRS;
  }
  
  double get_Jmax () const
  {
    return Jmax;
  }
  
  unsigned int get_space_dimension () const
  {
    return space_dimension;
  }

  const class baryons_data & get_prot_Y_data () const
  {
    return *prot_Y_data_ptr;
  }
  
  const class baryons_data & get_neut_Y_data () const
  {
    return *neut_Y_data_ptr;
  }

  const class sum_GSM_vector_dimensions_one_configuration_class & get_sum_dimensions_GSM_vector () const
  {
    return sum_dimensions_GSM_vector;
  }
  
  const class sum_GSM_vector_dimensions_one_configuration_class & get_sum_dimensions_GSM_vector_TRS () const
  {
    return sum_dimensions_GSM_vector_TRS;
  }
  
  const class array<unsigned int> & get_TRS_PSI_indices () const
  {
    return TRS_PSI_indices;
  }
  
  const class array<unsigned char> & get_TRS_bin_phases () const
  {
    return TRS_bin_phases;
  }
  
  bool is_it_filled () const
  {
    return (space != NO_SPACE);
  }

  bool same_parity_M_projection (const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_other) const;
    
  friend double used_memory_calc (const class GSM_vector_helper_one_configuration_class &T);

private:

  void TRS_data_calc_store ();

  // See GSM_vector_dimensions.cpp for additional details.
  
  enum space_type space;       // type of space used: protons only, neutrons only or protons-neutrons (plus a few hyperons if any)

  enum interaction_type inter; // type of the interaction used (FHT, realistic, ...)

  unsigned int BPp; // binary parity (see observables_basic_functions.cpp for definition) of the proton (plus a few hyperons if any) part of the GSM vector (valence protons and neutrons)
  unsigned int iCp; // index of the proton configuration of the GSM vector (valence protons and neutrons)

  unsigned int BPn; // binary parity (see observables_basic_functions.cpp for definition) of the neutron (plus a few hyperons if any) part of the GSM vector (valence protons and neutrons)
  unsigned int iCn; // index of the neutron configuration of the GSM vector (valence protons and neutrons)

  unsigned int BP; // binary parity of the GSM vector
  unsigned int iC; // index of the configuration of the GSM vector (valence protons or neutrons, plus a few hyperons if any)

  double J; // total angular momentum of the GSM vector
  double M; // M-projection of the GSM vector

  int iMp_max; // 2.M[proton-max], so that it is an integer (proton or charged hyperon)
  int iMn_max; // 2.M[neutron-max], so that it is an integer (proton or charged hyperon)

  int iM;     //  M + M[max] integer
  int TRS_iM; // -M + M[max] integer

  int iMp_min_M; // integer of the form M[proton] + M[proton-max] of the SD proton space associated to the smallest M[proton] value which can occur in the considered GSM vector (proton or charged hyperon)
  int iMp_max_M; // integer of the form M[proton] + M[proton-max] of the SD proton space associated to the largest  M[proton] value which can occur in the considered GSM vector (proton or charged hyperon)

  int iMn_min_M; // integer of the form M[neutron] + M[neutron-max] of the SD neutron space associated to the smallest M[neutron] value which can occur in the considered GSM vector (neutron or uncharged hyperon)
  int iMn_max_M; // integer of the form M[neutron] + M[neutron-max] of the SD neutron space associated to the largest  M[neutron] value which can occur in the considered GSM vector (neutron or uncharged hyperon)

  bool is_it_TRS; // true if one uses time-reversal symmetry (TRS) to calculate the GSM vector, false if not

  double Jmax; // largest total angular momentum that the GSM vector can have
  
  unsigned int space_dimension;          // Number of SDs in the GSM vector expansion

  const class baryons_data *prot_Y_data_ptr; // pointer to constants and arrays related to protons  only (plus a few   charged hyperons if any)
  const class baryons_data *neut_Y_data_ptr; // pointer to constants and arrays related to neutrons only (plus a few uncharged hyperons if any)
      
  class sum_GSM_vector_dimensions_one_configuration_class sum_dimensions_GSM_vector;     // sum of dimensions of SD space of given quantum numbers, to calculate the index of the current SD 
  class sum_GSM_vector_dimensions_one_configuration_class sum_dimensions_GSM_vector_TRS; // sum of dimensions of SD space of given quantum numbers, to calculate the index of TRS|SD> 

  class array<unsigned int> TRS_PSI_indices; // Indices of the TRS states of the SDs
  
  class array<unsigned char> TRS_bin_phases; // Binary phases (1 -> 0 , -1 -> 1) without reordering of the TRS states of the SDs
};

#endif


