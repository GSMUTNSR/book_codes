#ifndef GSMT2CLASS_H
#define GSMT2CLASS_H

// TYPE is double or complex
// -------------------------

class T2_class
{
public:

  T2_class ();
  
  T2_class (
	    const double J_c , 
	    const bool is_cv_possible_c ,
	    const class GSM_vector_helper_class &GSM_vector_helper);

  T2_class (const class T2_class &X);
  
  ~T2_class ();
  
  void allocate (
		 const double J_c , 
		 const bool is_cv_possible_c ,
		 const class GSM_vector_helper_class &GSM_vector_helper);

  void allocate_fill (const class T2_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI_in , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;

  double T_coupling_precision_calc (
				    const class GSM_vector &PSI , 
				    const double T , 
				    class GSM_vector &PSI_test) const;

  const class GSM_vector_helper_class & get_GSM_vector_helper () const
  {
    return *GSM_vector_helper_ptr;
  }
  
  bool is_it_filled () const
  {
    return (GSM_vector_helper_ptr != NULL);
  }

  friend double used_memory_calc (const class T2_class &T);
  
private:

  void diagonal_part_pp_nn_calc_store ();
  
  void diagonal_part_pn_Nval_larger_calc_store ();
  
  void diagonal_part_pn_Zval_larger_calc_store ();
  
  void two_jumps_pn_part_pn_Nval_larger_calc (const class GSM_vector &PSI_in ,class GSM_vector &PSI_out) const;
  
  void two_jumps_pn_part_pn_Zval_larger_calc (const class GSM_vector &PSI_in ,class GSM_vector &PSI_out) const;
  
  void two_jumps_cv_part_pn_Nval_larger_calc (const bool is_it_cv_pp_to_nn , const class GSM_vector &PSI_in , class GSM_vector &PSI_out) const;
  
  void two_jumps_cv_part_pn_Zval_larger_calc (const bool is_it_cv_pp_to_nn , const class GSM_vector &PSI_in , class GSM_vector &PSI_out) const;
  
  double J; // total angular momentum of the considered many body wave function

  bool is_cv_possible; // true if pp <-> nn conversions exist in the considered hypernucleus, false if not
  
  const class GSM_vector_helper_class *GSM_vector_helper_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.

  // One-body matrix elements of t- t+, and t+, t- from charged baryon to uncharged baryon
  
  class array<int> Tminus_Tplus_OBMEs_p_tab;
  class array<int> Tminus_Tplus_OBMEs_n_tab;
  
  class array<double> Tminus_OBMEs_pn_tab;
    
  class array<double> Tplus_OBMEs_pn_tab;
  
  class array<bool> are_Tminus_OBMEs_pn_non_zero_tab;

  class array<bool> are_Tplus_OBMEs_pn_non_zero_tab;
        
  class array<TYPE> T2_diagonal_tab; // diagonal NBMEs of T^2
};







class xT2_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;

  const class T2_class &T2;

  xT2_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class T2_class &T2_c);
};

class xT2_plus_alpha_str operator + (const class T2_class &T2);
class xT2_plus_alpha_str operator - (const class T2_class &T2);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const double term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const double term);

class xT2_plus_alpha_str operator + (const double term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const double term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const double x);
class xT2_plus_alpha_str operator * (const double x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const double x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const double term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const double term);

class xT2_plus_alpha_str operator + (const double alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const double alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const double factor);
class xT2_plus_alpha_str operator * (const double factor , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator + (const class T2_class &T2 , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class T2_class &T2 , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &term , const class T2_class &T2);
class xT2_plus_alpha_str operator - (const complex<double> &term , const class T2_class &T2);

class xT2_plus_alpha_str operator * (const class T2_class &T2 , const complex<double> &x);
class xT2_plus_alpha_str operator * (const complex<double> &x , const class T2_class &T2);
class xT2_plus_alpha_str operator / (const class T2_class &T2 , const complex<double> &x);

class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op , const complex<double> &term);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op , const complex<double> &term);

class xT2_plus_alpha_str operator + (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);
class xT2_plus_alpha_str operator - (const complex<double> &alpha , const class xT2_plus_alpha_str &Op);

class xT2_plus_alpha_str operator * (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator / (const class xT2_plus_alpha_str &Op , const complex<double> &factor);
class xT2_plus_alpha_str operator * (const complex<double> &factor , const class xT2_plus_alpha_str &Op);






class xT2_plus_alpha_str operator + (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b);
class xT2_plus_alpha_str operator - (const class xT2_plus_alpha_str &Op_a , const class xT2_plus_alpha_str &Op_b);

#endif

