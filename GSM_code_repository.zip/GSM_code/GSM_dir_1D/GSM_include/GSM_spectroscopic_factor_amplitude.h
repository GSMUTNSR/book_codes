#ifndef GSMSPECTROSCOPICFACTORAMPLITUDE_H
#define GSMSPECTROSCOPICFACTORAMPLITUDE_H

// TYPE is double or complex
// -------------------------

namespace spectroscopic_factor_amplitude
{
  namespace one_baryon
  {
    void stripping_p_pn_calc (
			      const class ljm_struct &ljm , 
			      const class correlated_state_str &PSI_IN_qn , 
			      const class GSM_vector &PSI_OUT , 
			      class array<TYPE> &amplitude_tab);

    void stripping_n_pn_calc (
			      const class ljm_struct &ljm , 
			      const class correlated_state_str &PSI_IN_qn , 
			      const class GSM_vector &PSI_OUT , 
			      class array<TYPE> &amplitude_tab);

    void stripping_pp_nn_calc (
			       const class ljm_struct &ljm , 
			       const class correlated_state_str &PSI_IN_qn , 
			       const class GSM_vector &PSI_OUT , 
			       class array<TYPE> &amplitude_tab);

    void stripping_calc (
			 const class ljm_struct &ljm , 
			 const class correlated_state_str &PSI_IN_qn , 
			 const class GSM_vector &PSI_OUT , 
			 class array<TYPE> &amplitude_tab);
 
    void pick_up_p_pn_calc (
			    const class ljm_struct &ljm , 
			    const class correlated_state_str &PSI_IN_qn , 
			    const class GSM_vector &PSI_OUT , 
			    class array<TYPE> &amplitude_tab);

    void pick_up_n_pn_calc (
			    const class ljm_struct &ljm , 
			    const class correlated_state_str &PSI_IN_qn , 
			    const class GSM_vector &PSI_OUT , 
			    class array<TYPE> &amplitude_tab);

    void pick_up_pp_nn_calc (
			     const class ljm_struct &ljm , 
			     const class correlated_state_str &PSI_IN_qn , 
			     const class GSM_vector &PSI_OUT , 
			     class array<TYPE> &amplitude_tab);
    
    void pick_up_calc (
		       const class ljm_struct &ljm , 
		       const class correlated_state_str &PSI_IN_qn , 
		       const class GSM_vector &PSI_OUT , 
		       class array<TYPE> &amplitude_tab);
  }

  namespace cluster
  {
    void stripping_pn_calc (
			    const int NCM_HO_max_projectile , 
			    const class ljm_struct &LJM_projectile , 
			    const class correlated_state_str &PSI_IN_qn , 
			    const class correlated_state_str &PSI_projectile_qn , 
			    const class GSM_vector &PSI_OUT , 
			    class array<TYPE> &amplitude_tab);

    void stripping_pp_nn_calc (
			       const int NCM_HO_max_projectile , 
			       const class ljm_struct &LJM_projectile , 
			       const class correlated_state_str &PSI_IN_qn , 
			       const class correlated_state_str &PSI_projectile_qn , 
			       const class GSM_vector &PSI_OUT , 
			       class array<TYPE> &amplitude_tab);

    void stripping_calc (
			 const int NCM_HO_max_projectile , 
			 const class ljm_struct &LJM_projectile , 
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_projectile_qn , 
			 const class GSM_vector &PSI_OUT , 
			 class array<TYPE> &amplitude_tab);
 
    void pick_up_pn_calc (
			  const int NCM_HO_max , 
			  const class ljm_struct &LJM_projectile , 
			  const class correlated_state_str &PSI_IN_qn , 
			  const class correlated_state_str &PSI_projectile_qn , 
			  const class GSM_vector &PSI_OUT , 
			  class array<TYPE> &amplitude_tab);

    void pick_up_pp_nn_calc (
			     const int NCM_HO_max , 
			     const class ljm_struct &LJM_projectile , 
			     const class correlated_state_str &PSI_IN_qn , 
			     const class correlated_state_str &PSI_projectile_qn , 
			     const class GSM_vector &PSI_OUT , 
			     class array<TYPE> &amplitude_tab);

    void pick_up_calc (
		       const int NCM_HO_max , 
		       const class ljm_struct &LJM_projectile , 
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_projectile_qn , 
		       const class GSM_vector &PSI_OUT , 
		       class array<TYPE> &amplitude_tab);
  }

  namespace nucleus
  {
    TYPE stripping_pn_calc (
			    const class correlated_state_str &PSI_IN_qn , 
			    const class correlated_state_str &PSI_projectile_qn ,
			    const double M_projectile , 
			    const class GSM_vector &PSI_OUT);

    TYPE stripping_pp_nn_calc (
			       const class correlated_state_str &PSI_IN_qn , 
			       const class correlated_state_str &PSI_projectile_qn , 
			       const double M_projectile , 
			       const class GSM_vector &PSI_OUT);
    
    TYPE stripping_calc (
			 const class correlated_state_str &PSI_IN_qn , 
			 const class correlated_state_str &PSI_projectile_qn ,
			 const double M_projectile ,  
			 const class GSM_vector &PSI_OUT);

    TYPE pick_up_pn_calc (
			  const class correlated_state_str &PSI_IN_qn , 
			  const class correlated_state_str &PSI_projectile_qn , 
			  const double M_projectile , 
			  const class GSM_vector &PSI_OUT);

    TYPE pick_up_pp_nn_calc (
			     const class correlated_state_str &PSI_IN_qn , 
			     const class correlated_state_str &PSI_projectile_qn , 
			     const double M_projectile , 
			     const class GSM_vector &PSI_OUT);
    
    TYPE pick_up_calc (
		       const class correlated_state_str &PSI_IN_qn , 
		       const class correlated_state_str &PSI_projectile_qn , 
		       const double M_projectile , 
		       const class GSM_vector &PSI_OUT);
  }
}

#endif


