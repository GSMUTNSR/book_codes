#ifndef GSMTRSCLASS_H
#define GSMTRSCLASS_H

// TYPE is double or complex
// -------------------------

class TRS_class
{
public:
  
  TRS_class ();
  
  TRS_class (
	     const class GSM_vector_helper_class &GSM_vector_helper_in_c , 
	     const class GSM_vector_helper_class &GSM_vector_helper_out_c);

  void initialize (
		   const class GSM_vector_helper_class &GSM_vector_helper_in_c , 
		   const class GSM_vector_helper_class &GSM_vector_helper_out_c);

  void initialize (const class TRS_class &X);
  
  void allocate_fill (const class TRS_class &X);
  
  void deallocate ();
  
  void apply_add (
		  const class GSM_vector &PSI_in , 
		  class GSM_vector &PSI_out) const;

  class Op_PSI_closure_str operator () (const class GSM_vector &PSI) const;

  const class GSM_vector_helper_class & get_GSM_vector_helper_in () const
  {
    return *GSM_vector_helper_in_ptr;
  }
  
  const class GSM_vector_helper_class & get_GSM_vector_helper_out () const
  {
    return *GSM_vector_helper_out_ptr;
  }
  
private:

  const class GSM_vector_helper_class *GSM_vector_helper_in_ptr;  // pointer to data necessary to handle |Psi[in]>. It does not contain their vector components.
  const class GSM_vector_helper_class *GSM_vector_helper_out_ptr; // pointer to data necessary to handle |Psi[out]>. It does not contain their vector components.
};

double used_memory_calc (const class TRS_class &T);


#endif







