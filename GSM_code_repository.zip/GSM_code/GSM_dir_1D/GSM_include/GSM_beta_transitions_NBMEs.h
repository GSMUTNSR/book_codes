#ifndef GSMBETATRANSITIONSNBMES_H
#define GSMBETATRANSITIONSNBMES_H

// TYPE is double or complex
// -------------------------

namespace beta_transitions_NBMEs
{
  TYPE component_part_beta_plus_calc (
				      const int rank_beta_operator , 
				      const int rank_beta_operator_projection , 
				      const class array<TYPE> &OBMEs , 
				      const class configuration &Cp_in , 
				      const class configuration &Cn_in , 
				      const class Slater_determinant &inSDp , 
				      const class Slater_determinant &inSDn , 
				      const TYPE &PSI_IN_component , 
				      const unsigned int reordering_bin_phase_p ,
				      const unsigned int reordering_bin_phase_n ,
				      const class GSM_vector &PSI_OUT);

  TYPE component_part_beta_minus_calc (
				       const int rank_beta_operator , 
				       const int rank_beta_operator_projection , 
				       const class array<TYPE> &OBMEs , 
				       const class configuration &Cp_in , 
				       const class configuration &Cn_in , 
				       const class Slater_determinant &inSDp , 
				       const class Slater_determinant &inSDn , 
				       const TYPE &PSI_IN_component , 
				       const unsigned int reordering_bin_phase_p ,
				       const unsigned int reordering_bin_phase_n ,
				       const class GSM_vector &PSI_OUT);
	
  TYPE calc (
	     const enum beta_pm_type beta_pm , 
	     const enum beta_suboperator_type beta_suboperator , 
	     const class array<TYPE> &OBMEs , 
	     const class correlated_state_str &PSI_IN_qn , 
	     const class correlated_state_str &PSI_OUT_qn , 
	     const class GSM_vector &PSI_OUT);
}

#endif


