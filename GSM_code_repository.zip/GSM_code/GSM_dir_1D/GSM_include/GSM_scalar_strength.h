#ifndef GSMSCALARSTRENGTH_H
#define GSMSCALARSTRENGTH_H 

// TYPE is double or complex
// -------------------------

namespace scalar_strength
{
  void diagonal_part_pp_nn_calc (
				 const class array<TYPE> &OBMEs ,
				 const class Slater_determinant &SD , 
				 class array<TYPE> &diagonal_part);

  void NBMEs_one_jump_mu_calc (
			       const class array<TYPE> &OBMEs_mu , 
			       const class jumps_data_str &one_jump_mu , 
			       class array<TYPE> &NBMEs_one_jump_mu);

  void scalar_strength_part_calc (
				  const class jumps_data_str &jump , 
				  const class array<bool> &is_configuration_accepted_tab , 
				  const class array<unsigned int> &PSI_indices , 
				  const class array<TYPE> &NBMEs_one_jump , 
				  const TYPE &PSI_OUT_component_TRS_factor , 
				  const class GSM_vector &PSI_IN ,
				  class array<TYPE> &scalar_strength_part_tab);

  void pp_nn_diagonal_part_calc (
				 const class array<TYPE> &OBMEs_mu , 
				 const class GSM_vector &PSI_IN ,
				 const class GSM_vector &PSI_OUT ,  
				 class array<TYPE> &density);
  
  void pp_nn_one_jump_part_calc (
				 const class array<TYPE> &OBMEs_mu , 
				 const class GSM_vector &PSI_IN ,
				 const class GSM_vector &PSI_OUT ,  
				 class array<TYPE> &density);

  void diagonal_part_pn_p_part_calc (
				     const class array<TYPE> &OBMEs_p , 
				     const class GSM_vector &PSI_IN ,
				     const class GSM_vector &PSI_OUT ,  
				     class array<TYPE> &density);

  void diagonal_part_pn_n_part_calc (
				     const class array<TYPE> &OBMEs_n , 
				     const class GSM_vector &PSI_IN ,
				     const class GSM_vector &PSI_OUT ,  
				     class array<TYPE> &density);

  void one_jump_p_part_pn_calc (
				const class array<TYPE> &OBMEs_p , 
				const class GSM_vector &PSI_IN ,
				const class GSM_vector &PSI_OUT ,  
				class array<TYPE> &density);

  void one_jump_n_part_pn_calc (
				const class array<TYPE> &OBMEs_n , 
				const class GSM_vector &PSI_IN ,
				const class GSM_vector &PSI_OUT ,  
				class array<TYPE> &density);

  void calc (
	     const class array<TYPE> &OBMEs_p , 
	     const class array<TYPE> &OBMEs_n , 
	     const class GSM_vector &PSI_IN ,
	     const class GSM_vector &PSI_OUT , 
	     class array<TYPE> &scalar_strength_p_tab , 
	     class array<TYPE> &scalar_strength_n_tab);
}

#endif


