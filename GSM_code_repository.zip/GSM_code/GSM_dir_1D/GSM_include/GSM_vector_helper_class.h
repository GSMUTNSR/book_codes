#ifndef GSMVECTORHELPERCLASS_H
#define GSMVECTORHELPERCLASS_H

using namespace GSM_vector_dimensions;

// TYPE is double or complex
// -------------------------

class GSM_vector_helper_class
{
public:
  
  GSM_vector_helper_class ();
  
  GSM_vector_helper_class (
			   const enum space_type space_c , 
			   const enum interaction_type inter_c , 
			   const bool truncation_hw_c , 
			   const bool truncation_ph_c , 
			   const int n_holes_max_c , 
			   const int n_scat_max_c , 
			   const int E_max_hw_c , 
			   const int n_holes_max_p_c , 
			   const int n_scat_max_p_c , 
			   const int Ep_max_hw_c , 
			   const int n_holes_max_n_c , 
			   const int n_scat_max_n_c , 
			   const int En_max_hw_c ,
			   const class baryons_data &prot_Y_data , 
			   const class baryons_data &neut_Y_data ,
			   const unsigned int BP_c , 
			   const double M_c , 
			   const bool is_it_TRS_for_M_zero);

  GSM_vector_helper_class (const class GSM_vector_helper_class &X);
  
  ~GSM_vector_helper_class ();
 
  void allocate (
		 const enum space_type space_c , 
		 const enum interaction_type inter_c , 
		 const bool truncation_hw_c , 
		 const bool truncation_ph_c , 
		 const int n_holes_max_c , 
		 const int n_scat_max_c , 
		 const int E_max_hw_c , 
		 const int n_holes_max_p_c , 
		 const int n_scat_max_p_c , 
		 const int Ep_max_hw_c , 
		 const int n_holes_max_n_c , 
		 const int n_scat_max_n_c , 
		 const int En_max_hw_c ,
		 const class baryons_data &prot_Y_data , 
		 const class baryons_data &neut_Y_data ,
		 const unsigned int BP_c ,
		 const double M_c , 
		 const bool is_it_TRS_for_M_zero);

  void allocate_fill (const class GSM_vector_helper_class &X);

  void deallocate ();
    
  enum space_type get_space () const
  {
    return space;
  }
  
  enum interaction_type get_inter () const
  {
    return inter;
  }
   
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }
  
  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_n_spec_max () const
  {
    return n_spec_max;
  }
  
  int get_n_holes_max () const
  {
    return n_holes_max;
  }
  
  int get_n_holes_max_p () const
  {
    return n_holes_max_p;
  }
  
  int get_n_holes_max_n () const
  {
    return n_holes_max_n;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }
  
  int get_n_scat_max_p () const
  {
    return n_scat_max_p;
  }
  
  int get_n_scat_max_n () const
  {
    return n_scat_max_n;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }
  
  int get_Ep_max_hw () const
  {
    return Ep_max_hw;
  }
  
  int get_En_max_hw () const
  {
    return En_max_hw;
  }
  
  unsigned int get_BP () const
  {
    return BP;
  }

  double get_M () const
  {
    return M;
  }
    
  int get_S () const
  {
    return S;
  }
  
  int get_iM () const
  {
    return iM;
  }

  int get_TRS_iM () const
  {
    return TRS_iM;
  }
  
  int get_iMp_min_M () const
  {
    return iMp_min_M;
  }

  int get_iMp_max_M () const
  {
    return iMp_max_M;
  }

  int get_iMn_min_M () const
  {
    return iMn_min_M;
  }

  int get_iMn_max_M () const
  {
    return iMn_max_M;
  }

  bool get_is_it_TRS () const
  {
    return is_it_TRS;
  }
  
  double get_Jmax () const
  {
    return Jmax;
  }
  
  unsigned int get_space_dimension_process () const
  {
    return space_dimension_process;
  }
 
  unsigned int get_space_dimension () const
  {
    return space_dimension;
  }
  
  unsigned int get_first_PSI_index () const
  {
    return first_PSI_index;
  }
  
  unsigned int get_last_PSI_index () const
  {
    return last_PSI_index;
  }

  unsigned long int get_total_SDp_index_min () const
  {
    return total_SDp_index_min;
  }

  unsigned long int get_total_SDp_index_max () const
  {
    return total_SDp_index_max;
  }

  unsigned long int get_total_SDn_index_min () const
  {
    return total_SDn_index_min;
  }

  unsigned long int get_total_SDn_index_max () const
  {
    return total_SDn_index_max;
  }

  unsigned long int get_total_SD_index_min () const
  {
    return total_SD_index_min;
  }

  unsigned long int get_total_SD_index_max () const
  {
    return total_SD_index_max;
  }

  const class baryons_data & get_prot_Y_data () const
  {
    return *prot_Y_data_ptr;
  }
  
  const class baryons_data & get_neut_Y_data () const
  {
    return *neut_Y_data_ptr;
  }
  
  const class sum_GSM_vector_dimensions_class & get_sum_dimensions_GSM_vector () const
  {
    return sum_dimensions_GSM_vector;
  }
  
  const class sum_GSM_vector_dimensions_class & get_sum_dimensions_GSM_vector_TRS () const
  {
    return sum_dimensions_GSM_vector_TRS;
  }
  
  const class array_BP_S_Nspec_Nscat_iC<bool> & get_all_dimensions_SDp_zero_tab () const
  {
    return all_dimensions_SDp_zero_tab;
  }
  
  const class array_BP_S_Nspec_Nscat_iC<bool> & get_all_dimensions_SDn_zero_tab () const
  {
    return all_dimensions_SDn_zero_tab;
  }

  class array<unsigned int> & get_TRS_PSI_indices ()
  {
    return TRS_PSI_indices;
  }
  
  const class array<unsigned int> & get_TRS_PSI_indices () const
  {
    return TRS_PSI_indices;
  }
    
  const class array<unsigned char> & get_TRS_bin_phases () const
  {
    return TRS_bin_phases;
  }

  bool is_it_filled () const
  {
    return (space != NO_SPACE);
  }
    
  const class array<unsigned int> & get_iCp_min_tab () const
  {
    return iCp_min_tab;
  }
  
  const class array<unsigned int> & get_iCp_max_tab () const
  {
    return iCp_max_tab;
  }
  
  const class array<unsigned int> & get_iCn_min_tab () const
  {
    return iCn_min_tab;
  }
  
  const class array<unsigned int> & get_iCn_max_tab () const
  {
    return iCn_max_tab;
  }
  
  const class array<unsigned int> & get_iC_min_tab () const
  {
    return iC_min_tab;
  }
  
  const class array<unsigned int> & get_iC_max_tab () const
  {
    return iC_max_tab;
  }
  
  bool same_parity_strangeness_M_projection (const class GSM_vector_helper_class &GSM_vector_helper_other) const;
  
  friend double used_memory_calc (const class GSM_vector_helper_class &T);
				  
private:

  void configuration_total_SDp_SDn_indices_min_max_calc_store ();
  
  void all_dimensions_SDp_zero_tabs_calc ();
  void all_dimensions_SDn_zero_tabs_calc ();
  
  void TRS_data_calc_store ();

  // See GSM_vector_dimensions.cpp for additional details.
  
  enum space_type space;  // type of space used: protons only, neutrons only or protons-neutrons

  enum interaction_type inter; // type of the interaction used (FHT, realistic, ...)

  bool truncation_hw; // true if one truncates in energy, given there in units of hbar omega (which can be used as arbitrary units as well), false if not
  bool truncation_ph; // true if one truncates with respect to particle number in the continuum, false if not
  
  int n_holes_max;    // maximal number of nucleon holes in core states
  int n_holes_max_p;  // maximal number of proton  holes in core states
  int n_holes_max_n;  // maximal number of neutron holes in core states
  
  int n_scat_max;    // maximal number of nucleons in the continuum
  int n_scat_max_p;  // maximal number of protons  in the continuum
  int n_scat_max_n;  // maximal number of neutrons in the continuum

  int E_max_hw;   // maximal truncation energy of configurations
  int Ep_max_hw;  // maximal truncation energy of proton configurations
  int En_max_hw;  // maximal truncation energy of neutron configurations
  
  unsigned int BP; // binary parity (see observables_basic_functions.cpp for definition) of the GSM vector
  
  double M; // M-projection of the GSM vector

  int S; // strangeness of the GSM vector
    
  int n_spec_max; // maximal number of spectator pairs in the considered hypernucleus (see enum_struct_definitions.h)
  
  int iM;     //  M + M[max] integer
  int TRS_iM; // -M + M[max] integer

  int iMp_min_M; // integer of the form M[proton] + M[proton-max] of the SD proton space associated to the smallest M[proton] value which can occur in the considered GSM vector
  int iMp_max_M; // integer of the form M[proton] + M[proton-max] of the SD proton space associated to the largest  M[proton] value which can occur in the considered GSM vector

  int iMn_min_M; // integer of the form M[neutron] + M[neutron-max] of the SD neutron space associated to the smallest M[neutron] value which can occur in the considered GSM vector
  int iMn_max_M; // integer of the form M[neutron] + M[neutron-max] of the SD neutron space associated to the largest  M[neutron] value which can occur in the considered GSM vector
  
  bool is_it_TRS; // true if one uses time-reversal symmetry (TRS) to calculate the GSM vector, false if not

  double Jmax; // largest total angular momentum that the GSM vector can have
  
  unsigned int space_dimension;          // Number of SDs in the GSM vector expansion
  unsigned int space_dimension_process;  // Number of SDs in the GSM vector expansion considered only by the current MPI node

  unsigned int first_PSI_index; // first SD index considered by the current MPI node
  unsigned int last_PSI_index;  // last  SD index considered by the current MPI node
    
  unsigned long int total_SDp_index_min; // smallest SD[proton] index considered by the current MPI node (valence protons and neutrons (plus a few hyperons if any))
  unsigned long int total_SDp_index_max; // largest  SD[proton] index considered by the current MPI node (valence protons and neutrons (plus a few hyperons if any))

  unsigned long int total_SDn_index_min; // smallest SD[neutron] index considered by the current MPI node (valence protons and neutrons (plus a few hyperons if any))
  unsigned long int total_SDn_index_max; // largest  SD[neutron] index considered by the current MPI node (valence protons and neutrons (plus a few hyperons if any))
  
  unsigned long int total_SD_index_min; // smallest SD index considered by the current MPI node (valence protons or neutrons (plus a few hyperons if any))
  unsigned long int total_SD_index_max; // smallest SD index considered by the current MPI node (valence protons or neutrons (plus a few hyperons if any))
  
  const class baryons_data *prot_Y_data_ptr; // pointer to constants and arrays related to protons  only
  const class baryons_data *neut_Y_data_ptr; // pointer to constants and arrays related to neutrons only
    
  class sum_GSM_vector_dimensions_class sum_dimensions_GSM_vector;     // sum of dimensions of SD space of given quantum numbers, to calculate the index of the current SD 
  class sum_GSM_vector_dimensions_class sum_dimensions_GSM_vector_TRS; // sum of dimensions of SD space of given quantum numbers, to calculate the index of TRS|SD> 

  class array<unsigned int> TRS_PSI_indices; // Indices of the TRS states of the SDs
  
  class array<unsigned char> TRS_bin_phases; // Binary phases (1 -> 0 , -1 -> 1) without reordering of the TRS states of the SDs
  
  class array_BP_S_Nspec_Nscat_iC<bool> all_dimensions_SDp_zero_tab; // arrays of booleans equal to true if the considered proton  SD space, with fixed quantum numbers, has a dimension equal to zero, false if not
  class array_BP_S_Nspec_Nscat_iC<bool> all_dimensions_SDn_zero_tab; // arrays of booleans equal to true if the considered neutron SD space, with fixed quantum numbers, has a dimension equal to zero, false if not

  class array<unsigned int> iCp_min_tab; // array of minimal proton configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons and neutrons (plus a few hyperons if any))
  class array<unsigned int> iCp_max_tab; // array of maximal proton configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons and neutrons (plus a few hyperons if any))

  class array<unsigned int> iCn_min_tab; // array of minimal neutron configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons and neutrons (plus a few hyperons if any))
  class array<unsigned int> iCn_max_tab; // array of maximal neutron configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons and neutrons (plus a few hyperons if any))
  
  class array<unsigned int> iC_min_tab; // array of minimal configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons or neutrons (plus a few hyperons if any))
  class array<unsigned int> iC_max_tab; // array of maximal configuration indices in the current MPI node as a function of parity and number of particles in the continuum (valence protons or neutrons (plus a few hyperons if any))
};

#endif


