#ifndef GSMEMTRANSITIONSSTRENGTHNBMES_H
#define GSMEMTRANSITIONSSTRENGTHNBMES_H

// TYPE is double or complex
// -------------------------

namespace EM_transitions_strength_NBMEs
{
  void B_amplitude_pp_nn_tab_calc (
				   const enum EM_type EM , 
				   const TYPE &q , 
				   const int L , 
				   const bool is_it_longwavelength_approximation , 
				   const bool is_it_Gauss_Legendre , 
				   const double J_IN , 
				   const class GSM_vector &PSI_IN , 
				   const double J_OUT , 
				   const class GSM_vector &PSI_OUT , 
				   class array<TYPE> &B_amplitude_tab);

  void B_amplitude_pn_tab_calc (
				const enum EM_type EM , 
				const TYPE &q , 
				const int L , 
				const bool is_it_longwavelength_approximation , 
				const bool is_it_Gauss_Legendre , 
				const double J_IN , 
				const class GSM_vector &PSI_IN , 
				const double J_OUT , 
				const class GSM_vector &PSI_OUT , 
				class array<TYPE> &B_amplitude_tab);

  void B_amplitude_tab_calc (
			     const enum EM_type EM , 
			     const TYPE &q , 
			     const int L ,
			     const bool is_it_longwavelength_approximation , 
			     const bool is_it_Gauss_Legendre , 
			     const double J_IN , 
			     const class GSM_vector &PSI_IN , 
			     const double J_OUT , 
			     const class GSM_vector &PSI_OUT , 
			     class array<TYPE> &B_amplitude_tab);
	
  void EM_suboperator_B_amplitude_pp_nn_tab_calc (
						  const enum EM_suboperator_type EM_suboperator , 
						  const TYPE &q , 
						  const int L ,
						  const bool is_it_longwavelength_approximation , 
						  const bool is_it_Gauss_Legendre , 
						  const double J_IN , 
						  const class GSM_vector &PSI_IN , 
						  const double J_OUT , 
						  const class GSM_vector &PSI_OUT , 
						  class array<TYPE> &EM_suboperator_B_amplitude_tab);

  void EM_suboperator_B_amplitude_pn_tab_calc (
					       const enum EM_suboperator_type EM_suboperator ,
					       const TYPE &q , 
					       const int L ,
					       const bool is_it_longwavelength_approximation , 
					       const bool is_it_Gauss_Legendre ,  
					       const double J_IN , 
					       const class GSM_vector &PSI_IN , 
					       const double J_OUT , 
					       const class GSM_vector &PSI_OUT , 
					       class array<TYPE> &EM_suboperator_B_amplitude_tab);

  void EM_suboperator_B_amplitude_tab_calc (		
					    const enum EM_suboperator_type EM_suboperator ,
					    const TYPE &q , 
					    const int L ,
					    const bool is_it_longwavelength_approximation , 
					    const bool is_it_Gauss_Legendre , 
					    const double J_IN , 
					    const class GSM_vector &PSI_IN , 
					    const double J_OUT , 
					    const class GSM_vector &PSI_OUT , 
					    class array<TYPE> &EM_suboperator_B_amplitude_tab);
}

#endif


