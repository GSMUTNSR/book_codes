#ifndef GSMHCMOBMESCC_H
#define GSMHCMOBMESCC_H

// TYPE is double or complex
// -------------------------

namespace H_CM_OBMEs_CC
{
  namespace one_baryon_CM
  {
    double OBME_h_basis_potential_calc (
					const int l , 
					const double j , 
					const int n_HO_in , 
					const int n_HO_out , 
					const class CG_str &CGs , 
					const class interaction_class &inter_data_basis , 
					const class array<double> &Gaussian_table_GL , 
					const class multipolar_expansion_str &multipolar_expansion , 
					const class HF_baryons_data &prot_Y_HF_data , 
					const class HF_baryons_data &neut_Y_HF_data , 
					const class baryons_data &prot_data_one_configuration_GSM , 
					const class baryons_data &neut_data_one_configuration_GSM , 
					const class baryons_data &neut_data_CC_Berggren , 
					const class baryons_data &data_CC_Berggren);

    double OBME_h_basis_calc (
			      const int l , 
			      const double j , 
			      const int n_HO_in , 
			      const int n_HO_out , 
			      const class CG_str &CGs , 
			      const class interaction_class &inter_data_basis , 
			      const class array<double> &Gaussian_table_GL , 
			      const class multipolar_expansion_str &multipolar_expansion , 
			      const class HF_baryons_data &prot_Y_HF_data , 
			      const class HF_baryons_data &neut_Y_HF_data , 
			      const class baryons_data &prot_data_one_configuration_GSM , 
			      const class baryons_data &neut_data_one_configuration_GSM , 
			      const class baryons_data &neut_data_CC_Berggren , 
			      const class baryons_data &data_CC_Berggren);
  }

  namespace cluster_CM
  {
    double H_potential_CC_OBME_HO_basis_calc (
					      const int L , 
					      const double J , 
					      const int N_HO_in , 
					      const int N_HO_out , 
					      const class cluster_data &data);

    double H_OBME_calc (
			const int L , 
			const double J , 
			const int N_HO_in , 
			const int N_HO_out , 
			const class cluster_data &data);
  }
}

#endif


