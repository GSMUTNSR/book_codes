#ifndef GSMVECTORNBMESHANDLING_H
#define GSMVECTORNBMESHANDLING_H

// TYPE is double or complex
// -------------------------

namespace GSM_vector_NBMEs_handling
{
  TYPE component_part_jumps_calc (
				  const unsigned int dimension_jumps ,
				  const class array<bool> &is_configuration_accepted_tab , 
				  const class array<unsigned int> &PSI_in_indices , 
				  const class array<TYPE> &NBMEs_jumps ,
				  const class GSM_vector &PSI_in);
  
  TYPE component_part_one_jump_calc_Jpm (
					 const unsigned int dimension_jumps ,
					 const class array<unsigned int> &PSI_in_indices , 
					 const class array<double> &NBMEs_one_jump ,
					 const class GSM_vector &PSI_in);
  
  unsigned int component_part_jumps_number_calc (
						 const unsigned int dimension_jumps ,
						 const class array<bool> &is_configuration_accepted_tab);
 
  void NBMEs_jumps_mu_calc_one_body_operator (
					      const class array<TYPE> &OBMEs_mu,
					      const class jumps_data_str &jumps_one_mu,
					      class array<TYPE> &NBMEs_jumps_mu);

  void is_configuration_accepted_p_fill (
					 const int n_holes_n , 
					 const int n_scat_n , 
					 const int En_hw , 
					 const class jumps_data_str &jumps_p , 
					 const class GSM_vector_helper_class &GSM_vector_helper_in , 
					 class array<bool> &is_configuration_accepted_p_tab ,
					 bool &is_there_calc);
  
  void is_configuration_accepted_n_fill (
					 const int n_holes_p ,
					 const int n_scat_p , 
					 const int Ep_hw , 
					 const class jumps_data_str &jumps_n , 
					 const class GSM_vector_helper_class &GSM_vector_helper_in , 
					 class array<bool> &is_configuration_accepted_n_tab ,
					 bool &is_there_calc);
  
  void is_configuration_accepted_PSI_in_indices_p_fill (
							const unsigned int BPn ,
							const int Sn ,   
							const int n_spec_n ,  
							const int n_holes_n , 
							const int n_scat_n , 
							const unsigned int iCn , 
							const int iMn , 
							const unsigned int SDn_index , 
							const int En_hw , 
							const class jumps_data_str &jumps_p , 
							const class GSM_vector_helper_class &GSM_vector_helper_in , 
							const unsigned int dimension_SDn ,
							class array<bool> &is_configuration_accepted_p_tab ,
							class array<unsigned int> &PSI_in_indices_p ,
							bool &is_there_calc);

  void is_configuration_accepted_PSI_in_indices_n_fill (
							const unsigned int BPp ,
							const int Sp ,   
							const int n_spec_p ,   
							const int n_holes_p ,  
							const int n_scat_p , 
							const unsigned int iCp , 
							const int iMp , 
							const unsigned int SDp_index , 
							const int Ep_hw , 
							const class jumps_data_str &jumps_n , 
							const class GSM_vector_helper_class &GSM_vector_helper_in ,
							class array<bool> &is_configuration_accepted_n_tab , 
							class array<unsigned int> &PSI_in_indices_n ,
							bool &is_there_calc);

  void PSI_in_indices_pp_nn_fill (
				  const class jumps_data_str &jumps_mu , 
				  const class GSM_vector_helper_class &GSM_vector_helper_in ,
				  class array<unsigned int> &PSI_in_indices ,
				  bool &is_there_calc);


  void NBMEs_one_jump_mu_calc_one_body_operator_Jpm (
						     const class array<double> &OBMEs_mu,
						     const class jumps_data_str &one_jump_one_mu,
						     class array<double> &NBMEs_one_jump_mu);
  
  void PSI_in_indices_p_fill_Jpm (
				  const unsigned int SDn_index , 							      
				  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				  const class jumps_data_str &one_jump_p , 
				  const class GSM_vector_helper_class &GSM_vector_helper_in ,
				  const unsigned int dimension_SDn ,
				  class array<unsigned int> &PSI_in_indices_p ,
				  bool &is_there_calc);
  
  void PSI_in_indices_p_fill_Jpm (
				  const unsigned int SDn_index , 							      
				  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				  const class jumps_data_str &one_jump_p , 
				  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
				  const unsigned int dimension_SDn ,
				  class array<unsigned int> &PSI_in_indices_p ,
				  bool &is_there_calc);

  void PSI_in_indices_n_fill_Jpm (
				  const unsigned int SDp_index , 							      
				  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				  const unsigned int dimension_inSDn ,
				  const class jumps_data_str &one_jump_n , 
				  const class GSM_vector_helper_class &GSM_vector_helper_in ,
				  class array<unsigned int> &PSI_in_indices_n ,
				  bool &is_there_calc);
  
  void PSI_in_indices_n_fill_Jpm (
				  const unsigned int SDp_index , 							      
				  const unsigned int sum_dimensions_configuration_Mp_Mn_fixed_in ,
				  const unsigned int dimension_inSDn ,
				  const class jumps_data_str &one_jump_n , 
				  const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
				  class array<unsigned int> &PSI_in_indices_n ,
				  bool &is_there_calc);

  void PSI_in_indices_pp_nn_fill_Jpm (			      
				      const unsigned int sum_dimensions_configuration_fixed_in ,
				      const class jumps_data_str &one_jump_mu , 
				      const class GSM_vector_helper_class &GSM_vector_helper_in ,
				      class array<unsigned int> &PSI_in_indices ,
				      bool &is_there_calc);
  
  void PSI_in_indices_pp_nn_fill_Jpm (			      
				      const unsigned int sum_dimensions_configuration_fixed_in ,
				      const class jumps_data_str &one_jump_mu , 
				      const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_in ,
				      class array<unsigned int> &PSI_in_indices ,
				      bool &is_there_calc);
}

#endif


