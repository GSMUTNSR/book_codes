#ifndef GSMJUMPSDATASTR_H
#define GSMJUMPSDATASTR_H

// TYPE is double or complex
// -------------------------



class jumps_data_str
{
public:

  jumps_data_str ();
  
  jumps_data_str (
		  const enum jump_data_type jumps_data_c , 
		  const enum space_type space_c ,
		  const bool truncation_hw_c , 
		  const bool truncation_ph_c , 
		  const unsigned int dimension_max);

  jumps_data_str (const class jumps_data_str &X);

  void allocate (
		 const enum jump_data_type jumps_data_c ,
		 const enum space_type space_c ,  
		 const bool truncation_hw_c , 
		 const bool truncation_ph_c , 
		 const unsigned int dimension_max);

  void allocate_fill (const class jumps_data_str &X);

  void deallocate ();

  void one_jump_mu_store (
			  const unsigned int BPmu_in , 
			  const int Smu_in , 
			  const int n_spec_mu_in , 
			  const int iMmu_in , 
			  const int n_holes_max_mu , 
			  const int n_scat_max_mu , 
			  const int Emu_max_hw , 
			  const unsigned int BPmu_out ,  
			  const int Smu_out , 
			  const int n_spec_mu_out , 
			  const int n_scat_mu_out , 
			  const unsigned int iCmu_out , 
			  const int iMmu_out , 
			  const unsigned int outSDmu_index , 
			  const class baryons_data &data);

  void one_jump_mu_Jpm_store (
			      const int pm , 
			      const unsigned int BPmu , 
			      const int Smu , 
			      const int n_spec_mu_in , 
			      const int n_scat_mu , 
			      const unsigned int iCmu , 
			      const int iMmu , 
			      const unsigned int outSDmu_index , 
			      const class baryons_data &data);

  void two_jumps_mu_store (
			   const unsigned int BPmu_in ,
			   const int Smu_in ,  
			   const int n_spec_mu_in , 
			   const int iMmu_in , 
			   const int n_holes_max_mu , 
			   const int n_scat_max_mu , 
			   const int Emu_max_hw , 
			   const unsigned int BPmu_out ,  
			   const int Smu_out , 
			   const int n_spec_mu_out ,
			   const int n_scat_mu_out , 
			   const unsigned int iCmu_out , 
			   const int iMmu_out , 
			   const unsigned int outSDmu_index , 
			   const bool are_01_spectators ,
			   const bool are_23_spectators ,
			   const class baryons_data &data);

  enum jump_data_type get_jump_type () const
  {
    return jump_type;	
  }

  enum space_type get_space_type () const
  {
    return space;	
  }

  unsigned int get_dimension () const
  {
    return dimension;
  }
  
  bool is_it_filled () const
  {
    return (jump_type != NO_JUMP_DATA);
  }

  friend double used_memory_calc (const class jumps_data_str &T);
  
  void remove_zero_NBMEs (class array<TYPE> &NBMEs);

  class jumps_data_inSD_str & operator () (const unsigned int index) const
  {
    return table(index);
  }

  class jumps_data_inSD_str & operator [] (const unsigned int index) const
  {
    return table[index];
  }

private:

  void reorder_minimal_configuration_changes ();
  
  enum jump_data_type jump_type; // type of consider jump (one-jump with a+ a, two jumps with a+ a+ a a)
  
  enum space_type space; // type of space used: protons only, neutrons only or protons-neutrons
  
  bool truncation_hw; // true if one truncates in energy, given there in units of hbar omega (which can be used as arbitrary units as well), false if not
  bool truncation_ph; // true if one truncates with respect to particle number in the continuum, false if not
  
  unsigned int dimension; // number of consider jumps. It is not the dimension of "table" below, as one uses the maximal possible dimension to define it.
  
  class array<class jumps_data_inSD_str> table; // array where data about jumps between SDs are stored
};


#endif

