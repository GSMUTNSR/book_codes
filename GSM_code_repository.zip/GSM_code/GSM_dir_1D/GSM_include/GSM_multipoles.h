#ifndef GSMMULTIPOLES_H
#define GSMMULTIPOLES_H

// TYPE is double or complex
// -------------------------

namespace GSM_multipoles
{
  TYPE diagonal_NBME_pp_nn_calc (
				 const int L ,
				 const bool is_it_HO_expansion ,
				 const class baryons_data &data ,
				 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				 const class Slater_determinant &SD);

  TYPE diagonal_NBME_pn_calc (
			      const int L ,
			      const bool is_it_HO_expansion ,
			      const class baryons_data &prot_Y_data ,
			      const class baryons_data &neut_Y_data ,
			      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
			      const class Slater_determinant &SDp , 
			      const class Slater_determinant &SDn);
  
  TYPE diagonal_part_p_part_pn_calc (
				     const int L ,
				     const bool is_it_HO_expansion ,
				     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				     const class GSM_vector &PSI_IN ,
				     const class GSM_vector &PSI_OUT);

  TYPE diagonal_part_n_part_pn_calc (
				     const int L ,
				     const bool is_it_HO_expansion ,
				     const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				     const class GSM_vector &PSI_IN ,
				     const class GSM_vector &PSI_OUT);
 
  TYPE diagonal_part_pn_part_pn_Nval_larger_calc (
						       const int L ,
						       const bool is_it_HO_expansion ,
						       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						       const class GSM_vector &PSI_IN ,
						       const class GSM_vector &PSI_OUT);

  TYPE diagonal_part_pn_part_pn_Zval_larger_calc (
						       const int L ,
						       const bool is_it_HO_expansion ,
						       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						       const class GSM_vector &PSI_IN ,
						       const class GSM_vector &PSI_OUT);
  TYPE diagonal_part_pp_nn_calc (
				 const int L ,
				 const bool is_it_HO_expansion ,
				 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				 const class GSM_vector &PSI_IN ,
				 const class GSM_vector &PSI_OUT);
 
  TYPE NBME_one_jump_mu_no_phase_calc (
				       const int L ,
				       const bool is_it_HO_expansion ,
				       const class baryons_data &data ,
				       const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				       const unsigned int in_jump , 
				       const unsigned int out_jump , 
				       const class Slater_determinant &outSD);
  
  TYPE NBME_pn_no_phase_one_jump_p_calc (
					 const int L ,
					 const bool is_it_HO_expansion ,
					 const class baryons_data &prot_Y_data ,
					 const class baryons_data &neut_Y_data ,
					 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					 const unsigned int p_in ,
					 const unsigned int p_out , 
					 const class Slater_determinant &SDn);
  
  TYPE NBME_pn_no_phase_one_jump_n_calc (
					 const int L ,
					 const bool is_it_HO_expansion ,
					 const class baryons_data &prot_Y_data ,
					 const class baryons_data &neut_Y_data ,
					 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					 const unsigned int n_in ,
					 const unsigned int n_out , 
					 const class Slater_determinant &SDp);
  
  void NBMEs_one_jump_pp_nn_calc_store (
					const class GSM_vector_helper_class &GSM_vector_helper ,
					const int L ,
					const bool is_it_HO_expansion ,
					const class baryons_data &data , 
					const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
					const unsigned int BPmu , 
					const int Smu , 
					const int n_spec_mu , 
					const int iMmu , 
					const int n_scat_mu_out , 
					const unsigned int iCmu_out , 
					const unsigned int outSDmu_index , 
					const class Slater_determinant &outSDmu , 
					bool &is_there_one_jump_calc , 
					class jumps_data_str &one_jump_mu , 
					class array<TYPE> &NBMEs_one_jump_mu);
 
  void NBMEs_two_jumps_pp_nn_calc_store (
					 const class GSM_vector_helper_class &GSM_vector_helper ,
					 const int L ,
					 const bool is_it_HO_expansion , 
					 const class baryons_data &data ,
					 const class multipole_TBMEs_angular_table_str &TBMEs_angular_table , 
					 const unsigned int BPmu , 
					 const int Smu , 
					 const int n_spec_mu , 
					 const int iMmu , 
					 const int n_scat_mu_out , 
					 const unsigned int iCmu_out , 
					 const unsigned int outSDmu_index , 
					 bool &are_there_two_jumps_calc , 
					 class jumps_data_str &two_jumps_mu , 
					 class array<TYPE> &NBMEs_two_jumps_mu);
 
  TYPE jumps_p_one_body_part_pn_calc (
				      const int L ,
				      const bool is_it_HO_expansion ,
				      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				      const class GSM_vector &PSI_IN ,
				      const class GSM_vector &PSI_OUT);
 
  TYPE jumps_p_two_body_part_pn_calc (
				      const int L ,
				      const bool is_it_HO_expansion ,
				      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				      const class GSM_vector &PSI_IN ,
				      const class GSM_vector &PSI_OUT);
  
  TYPE jumps_n_one_body_part_pn_calc (
				      const int L ,
				      const bool is_it_HO_expansion ,
				      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				      const class GSM_vector &PSI_IN ,
				      const class GSM_vector &PSI_OUT);
  
  TYPE jumps_n_two_body_part_pn_calc (
				      const int L ,
				      const bool is_it_HO_expansion ,
				      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				      const class GSM_vector &PSI_IN ,
				      const class GSM_vector &PSI_OUT);

  TYPE one_jump_p_pn_part_pn_calc (
				   const int L ,
				   const bool is_it_HO_expansion ,
				   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				   const class GSM_vector &PSI_IN ,
				   const class GSM_vector &PSI_OUT);
 
  TYPE one_jump_n_pn_part_pn_calc (
				   const int L ,
				   const bool is_it_HO_expansion ,
				   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
				   const class GSM_vector &PSI_IN ,
				   const class GSM_vector &PSI_OUT);
 
  TYPE two_jumps_pn_part_pn_Nval_larger_calc (
						   const int L ,
						   const bool is_it_HO_expansion ,
						   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						   const class GSM_vector &PSI_IN ,
						   const class GSM_vector &PSI_OUT);

  TYPE two_jumps_pn_part_pn_Zval_larger_calc (
						   const int L ,
						   const bool is_it_HO_expansion ,
						   const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
						   const class GSM_vector &PSI_IN ,
						   const class GSM_vector &PSI_OUT);
  TYPE jumps_part_pp_nn_calc (
			      const int L ,
			      const bool is_it_HO_expansion ,
			      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table ,
			      const class GSM_vector &PSI_IN ,
			      const class GSM_vector &PSI_OUT);
 
  TYPE multipole_ME_calc_one_pair (
				   const int L ,
				   const bool is_it_HO_expansion ,
				   const double J_IN ,  
				   const class GSM_vector &PSI_IN ,
				   const double J_OUT , 
				   const class GSM_vector &PSI_OUT);
  void calc_print (
		   const class input_data_str &input_data , 
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data , 
		   const class array<class correlated_state_str> &PSI_qn_tab);
}

#endif
