#ifndef GSMLANCZOSONECONFIGURATION_H
#define GSMLANCZOSONECONFIGURATION_H

// TYPE is double or complex
// -------------------------

namespace Lanczos_one_configuration
{
  void tridiagonalization (
			   const double J , 
			   const class J2_one_configuration_class &J2 , 
			   const class H_one_configuration_class &H , 
			   class array<class GSM_vector_one_configuration> &V_Lanczos_tab , 
			   class array<TYPE> &diagonal , 
			   class array<TYPE> &off_diagonal , 
			   class array<TYPE> &E_tab);

  void lowest_eigenvector_calc_store (
				      const bool is_there_cout , const double J , 
				      const class J2_one_configuration_class &J2 , 
				      const class H_one_configuration_class &H , 
				      const class array<TYPE> &diagonal , 
				      const class array<TYPE> &off_diagonal , 
				      const class array<TYPE> &E_tab , 
				      const class array<class GSM_vector_one_configuration> &V_Lanczos_tab , 
				      class GSM_vector_one_configuration &PSI);

  void iterative_diagonalization_lowest_states (
						const bool is_there_cout , 
						const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_M , 
						const class GSM_vector_helper_one_configuration_class &GSM_vector_helper_Mp1 , 
						const class TBMEs_class &TBMEs_pn , 
						const unsigned int dimension_BP_J ,
						const double J , 
						class GSM_vector_one_configuration &PSI);

  void H_J2_check (
		   const class GSM_vector_one_configuration &PSI , 
		   const double J , 
		   const class J2_one_configuration_class &J2 , 
		   const class H_one_configuration_class &H , 
		   const TYPE E);
}
#endif


