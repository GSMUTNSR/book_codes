#ifndef GSML2CMCLASS_H
#define GSML2CMCLASS_H

// TYPE is double or complex
// -------------------------

class L2_CM_class
{
public:

  L2_CM_class ();
  
  L2_CM_class (
	       const class GSM_vector_helper_class &GSM_vector_helper_M_c , 
	       class GSM_vector &PSI_Mp1_c);

  L2_CM_class (const class L2_CM_class &X);

  ~L2_CM_class ();
  
  void allocate (
		 const class GSM_vector_helper_class &GSM_vector_helper_M_c , 
		 class GSM_vector &PSI_Mp1_c);

  void allocate_fill (const class L2_CM_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI , 
		  const TYPE &alpha , 
		  class GSM_vector &PSI_out) const;

  const class GSM_vector_helper_class & get_GSM_vector_helper_M () const
  {
    return *GSM_vector_helper_M_ptr;
  }

  class GSM_vector & get_PSI_M () const
  {
    return *PSI_M_ptr;
  }
  
  class GSM_vector & get_PSI_Mp1 () const
  {
    return *PSI_Mp1_ptr;
  }
  
  bool is_it_filled () const
  {
    return (GSM_vector_helper_M_ptr != NULL);
  }

  friend double used_memory_calc (const class L2_CM_class &T);

private:

  const class GSM_vector_helper_class *GSM_vector_helper_M_ptr; // pointer to data necessary to handle |Psi[in]> and |Psi[out]>. It does not contain their vector components.

  class GSM_vector *PSI_M_ptr;   // pointer to GSM vector whose M-projection is equal to M.   It is necessary to store Lz|Psi[in]> + |Psi[in]>.
  class GSM_vector *PSI_Mp1_ptr; // pointer to GSM vector whose M-projection is equal to M+1. It is necessary to store L+|Psi[in]>.
  
  class CM_operator_class Lplus;  // Class containing data related to L+
  class CM_operator_class Lminus; // Class containing data related to L-
  class CM_operator_class Lz;     // Class containing data related to Lz
};






class xL2_CM_plus_alpha_str
{
public:

  const TYPE x;
  const TYPE alpha;

  const class L2_CM_class &L2_CM;

  xL2_CM_plus_alpha_str (const TYPE &x_c , const TYPE &alpha_c , const class L2_CM_class &L2_CM_c);
};

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const double term);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const double term);

class xL2_CM_plus_alpha_str operator + (const double term , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const double term , const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const double x);
class xL2_CM_plus_alpha_str operator * (const double x , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const double x);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const double term);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const double term);

class xL2_CM_plus_alpha_str operator + (const double alpha , const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const double alpha , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const double factor);
class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const double factor);
class xL2_CM_plus_alpha_str operator * (const double factor , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator + (const class L2_CM_class &L2_CM , const complex<double> &term);
class xL2_CM_plus_alpha_str operator - (const class L2_CM_class &L2_CM , const complex<double> &term);

class xL2_CM_plus_alpha_str operator + (const complex<double> &term , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator - (const complex<double> &term , const class L2_CM_class &L2_CM);

class xL2_CM_plus_alpha_str operator * (const class L2_CM_class &L2_CM , const complex<double> &x);
class xL2_CM_plus_alpha_str operator * (const complex<double> &x , const class L2_CM_class &L2_CM);
class xL2_CM_plus_alpha_str operator / (const class L2_CM_class &L2_CM , const complex<double> &x);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op , const complex<double> &term);

class xL2_CM_plus_alpha_str operator + (const complex<double> &alpha , const class xL2_CM_plus_alpha_str &Op);
class xL2_CM_plus_alpha_str operator - (const complex<double> &alpha , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator * (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor);
class xL2_CM_plus_alpha_str operator / (const class xL2_CM_plus_alpha_str &Op , const complex<double> &factor);
class xL2_CM_plus_alpha_str operator * (const complex<double> &factor , const class xL2_CM_plus_alpha_str &Op);

class xL2_CM_plus_alpha_str operator + (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b);
class xL2_CM_plus_alpha_str operator - (const class xL2_CM_plus_alpha_str &Op_a , const class xL2_CM_plus_alpha_str &Op_b);

#endif


