#ifndef GSMJPMCLASS_H
#define GSMJPMCLASS_H

// TYPE is double or complex
// -------------------------

class Jpm_class
{
public:
  
  Jpm_class ();
  
  Jpm_class (
	     const bool is_there_cout , 
	     const int pm_c , 
	     const enum storage_type storage_c , 
	     const class GSM_vector_helper_class &GSM_vector_helper_in , 
	     const class GSM_vector_helper_class &GSM_vector_helper_out);

  Jpm_class (const class Jpm_class &X);

  ~Jpm_class ();
  
  void allocate (
		 const bool is_there_cout , 
		 const int pm_c , 
		 const enum storage_type storage_c , 
		 const class GSM_vector_helper_class &GSM_vector_helper_in , 
		 const class GSM_vector_helper_class &GSM_vector_helper_out);

  void allocate_fill (const class Jpm_class &X);

  void deallocate ();

  void apply_add (
		  const class GSM_vector &PSI_in , 
		  class GSM_vector &PSI_out) const;

  friend double used_memory_calc (const class Jpm_class &T);

  void print () const;
  
  double Jpm_PSI_infinite_norm_calc (
				     const class GSM_vector &PSI , 
				     class GSM_vector &PSI_test) const;

  double Jpm_PSI_minus_xPHI_infinite_norm_calc (
						const class GSM_vector &PSI , 
						const double x , 
						const class GSM_vector &PHI , 
						class GSM_vector &PSI_test) const;
 
  const class GSM_vector_helper_class & get_GSM_vector_helper_in () const
  {
    return *GSM_vector_helper_in_ptr;
  }
  
  const class GSM_vector_helper_class & get_GSM_vector_helper_out () const
  {
    return *GSM_vector_helper_out_ptr;
  }

  bool is_it_filled () const;
  
private:

  void non_zero_NBMEs_numbers_one_jump_p_part_pn_calc ();

  void non_zero_NBMEs_numbers_one_jump_n_part_pn_calc ();

  void non_zero_NBMEs_numbers_pp_nn_calc ();

  void rows_non_zero_NBMEs_numbers_calc ();

  void one_jump_p_part_pn_calc_on_the_fly (
					   const class GSM_vector &PSI_in , 
					   class GSM_vector &PSI_out) const;

  void one_jump_n_part_pn_calc_on_the_fly (
					   const class GSM_vector &PSI_in , 
					   class GSM_vector &PSI_out) const;

  void pp_nn_calc_on_the_fly (
			      const class GSM_vector &PSI_in , 
			      class GSM_vector &PSI_out) const;

  void apply_add_on_the_fly (
			     const class GSM_vector &PSI_in , 
			     class GSM_vector &PSI_out) const;

  void Jpm_part_one_jump_store (
				const unsigned int PSI_out_index_shifted , 
				const unsigned int dimension_one_jump , 
				const class array<unsigned int> &PSI_in_indices ,
				const class array<double> &NBMEs_one_jump);
  
  void one_jump_p_part_pn_calc_full_storage ();

  void one_jump_n_part_pn_calc_full_storage ();

  void pp_nn_calc_full_storage ();

  void matrix_store ();

  void apply_add_full_storage (
			       const class GSM_vector &PSI_in , 
			       class GSM_vector &PSI_out) const;
  
  int pm; // It is 1 for J+ and -1 for J-.
  
  enum storage_type storage;  // FULL_STORAGE if J+/- matrix is fully stored , 
                              // PARTIAL_STORAGE is the same as FULL_STORAGE when considering J+/- 
                              // ON_THE_FLY for on the fly calculation
  
  unsigned int space_dimension_process_out_non_zeros;  // Number of non-zero NBMEs for the considered MPI node
  
  const class GSM_vector_helper_class *GSM_vector_helper_in_ptr;  // pointer to data necessary to handle |Psi[in]>. It does not contain their vector components.
  const class GSM_vector_helper_class *GSM_vector_helper_out_ptr; // pointer to data necessary to handle |Psi[out]>. It does not contain their vector components.
  
  class array<double> Jpm_OBMEs_p_tab; // proton  OBMEs of the j+ operator
  class array<double> Jpm_OBMEs_n_tab; // neutron OBMEs of the j+ operator

  class array<unsigned int> PSI_out_indices_shifted_non_zeros; // shifted indices of the SDs of |Psi[out]> associated to non-zeros NBMEs. Indices are shifted as the first index on each MPI node is not zero in general.
  
  class array<unsigned int> rows_non_zero_NBMEs_numbers;    // number of non-zeros NBMEs per row (Hamiltonian full or partial storage only)
  
  class array<unsigned int *> rows_non_zero_NBMEs_PSI_in_indices;  // indices of the SDs of |Psi[in]> leading to non-zeros NBMEs per row (Hamiltonian full or partial storage only)
  
  class array<double *> rows_non_zero_NBMEs;    // non-zeros NBMEs per row (Hamiltonian full or partial storage only)
};






class xJpm_str
{
public:

  const TYPE x;
  const class Jpm_class &Jpm;

  xJpm_str (const TYPE &x_c , const class Jpm_class &Jpm_c);
};

class xJpm_str operator + (const class Jpm_class &Jpm);
class xJpm_str operator - (const class Jpm_class &Jpm);

class xJpm_str operator * (const class Jpm_class &Jpm , const double x);
class xJpm_str operator * (const double x , const class Jpm_class &Jpm);
class xJpm_str operator / (const class Jpm_class &Jpm , const double x);

class xJpm_str operator + (const class xJpm_str &xJpm);
class xJpm_str operator - (const class xJpm_str &xJpm);

class xJpm_str operator * (const class xJpm_str &Op , const double factor);
class xJpm_str operator / (const class xJpm_str &Op , const double factor);

class xJpm_str operator * (const double factor , const class xJpm_str &Op);

class xJpm_str operator * (const class Jpm_class &Jpm , const complex<double> &x);
class xJpm_str operator * (const complex<double> &x , const class Jpm_class &Jpm);
class xJpm_str operator / (const class Jpm_class &Jpm , const complex<double> &x);

class xJpm_str operator * (const class xJpm_str &Op , const complex<double> &factor);
class xJpm_str operator / (const class xJpm_str &Op , const complex<double> &factor);

class xJpm_str operator * (const complex<double> &factor , const class xJpm_str &Op);

class xJpm_str operator + (const class xJpm_str &Op_a , const class xJpm_str &Op_b);
class xJpm_str operator - (const class xJpm_str &Op_a , const class xJpm_str &Op_b);

#endif


