#include "../CC_include/CC_include_def.h"

using namespace H_CM_OBMEs::HO_basis;


double CC_H_CM_OBMEs::one_baryon_CM::OBME_h_basis_potential_calc (
								  const enum particle_type particle ,
								  const int l , 
								  const double j , 
								  const int n_HO_in , 
								  const int n_HO_out , 
								  const class CG_str &CGs , 
								  const class interaction_class &inter_data_basis , 
								  const class array<double> &Gaussian_table_GL , 
								  const class multipolar_expansion_str &multipolar_expansion , 
								  const class HF_nucleons_data &prot_HF_data , 
								  const class HF_nucleons_data &neut_HF_data , 
								  const class baryons_data &prot_Y_data_one_configuration_GSM , 
								  const class baryons_data &neut_Y_data_one_configuration_GSM , 
								  const class baryons_data &neut_Y_data_CC_Berggren , 
								  const class baryons_data &data_CC_Berggren)
{ 
  const unsigned int particle_index = charge_baryon_index_determine (particle);
      
  const class array<class lj_table<enum potential_type> > &basis_potential_partial_waves_tab = data_CC_Berggren.get_basis_potential_partial_waves_tab ();

  const class lj_table<enum potential_type> &basis_potential_partial_waves = basis_potential_partial_waves_tab(particle_index);
  
  const bool good_isospin_basis_potential = data_CC_Berggren.get_good_isospin_basis_potential ();

  const class baryons_data &data_for_potential_Berggren = (good_isospin_basis_potential) ? (neut_Y_data_CC_Berggren) : (data_CC_Berggren);

  const bool are_core_basis_potentials_equal_l = are_core_basis_potentials_equal (l , data_CC_Berggren);

  const enum potential_type H_potential = data_CC_Berggren.get_H_potential ();

  const enum potential_type basis_potential = basis_potential_partial_waves(l , j);

  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();

  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const bool is_there_HF    = (basis_potential == HF);
  const bool is_there_MSDHF = (basis_potential == MSDHF);

  const bool is_there_HF_MSDHF = (is_there_HF || is_there_MSDHF);

  const bool is_it_OCM = (is_it_COSM && !are_core_basis_potentials_equal_l);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (TBME_inter);

  const bool is_there_HO_expansion = (is_there_HF_MSDHF || is_it_OCM);
	  
  const int ZY_charge_basis_potential_pos = data_CC_Berggren.get_ZY_charge_basis_potential_pos ();
  const int ZY_charge_basis_potential_neg = data_CC_Berggren.get_ZY_charge_basis_potential_neg ();
  
  const class lj_table<class matrix<complex<double> > > &U_finite_range_HF_HO_basis_HO_expansion_part = data_CC_Berggren.get_U_finite_range_HF_HO_basis_HO_expansion_part ();

  const class matrix<complex<double> > dummy_U_finite_range_HF_HO_basis_HO_expansion_part_lj;

  const class matrix<complex<double> > &U_finite_range_HF_HO_basis_HO_expansion_part_lj = (is_there_HO_expansion) ? (U_finite_range_HF_HO_basis_HO_expansion_part(l , j)) : (dummy_U_finite_range_HF_HO_basis_HO_expansion_part_lj);

  const class nlj_table<unsigned int> &shells_HO_indices = inter_data_basis.get_shells_HO_indices ();

  const unsigned int shell_HO_in  = shells_HO_indices(n_HO_in  , l , j);
  const unsigned int shell_HO_out = shells_HO_indices(n_HO_out , l , j);

  const class array<class vector_class<complex<double> > > &HO_overlaps_Fermi = inter_data_basis.get_HO_overlaps_Fermi ();
  
  const class vector_class<complex<double> > &HO_overlaps_Fermi_in  = HO_overlaps_Fermi(shell_HO_in);
  const class vector_class<complex<double> > &HO_overlaps_Fermi_out = HO_overlaps_Fermi(shell_HO_out);

  const double OBME_nuclear_potential_basis = (is_there_HF_MSDHF) 
    ? (OBME_nuclear_potential_calc (false , H_potential     , particle , l , j , n_HO_in , n_HO_out , inter_data_basis , data_for_potential_Berggren)) 
    : (OBME_nuclear_potential_calc (true  , basis_potential , particle , l , j , n_HO_in , n_HO_out , inter_data_basis , data_for_potential_Berggren));

  const double U_finite_range_HF_HO_expansion_part_OBME = (is_there_HO_expansion) ? (real_dc (HO_overlaps_Fermi_out*(U_finite_range_HF_HO_basis_HO_expansion_part_lj*HO_overlaps_Fermi_in))) : (0.0);

  const double OBME_HF_SGI_MSGI = (is_there_HF && is_it_SGI_MSGI) 
    ? (HF_potentials_common::SGI_MSGI_OBMEs::HO_basis::OBME_HF_calc (particle , l , j , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , prot_HF_data , neut_HF_data)) 
    : (0.0);

  const double OBME_MSDHF_SGI_MSGI = (is_there_MSDHF && is_it_SGI_MSGI) 
    ? (MSDHF_potentials::SGI_MSGI_OBMEs::HO_basis::OBME_HF_calc (particle , l , j , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion ,
								 prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , prot_HF_data , neut_HF_data)) 
    : (0.0);

  const double OBME_HF_MSDHF_SGI_MSGI = OBME_HF_SGI_MSGI + OBME_MSDHF_SGI_MSGI;

  const double OBME_Coulomb = OBME_Coulomb_potential_calc (ZY_charge_basis_potential_pos , ZY_charge_basis_potential_neg , particle , l , j , n_HO_in , n_HO_out , inter_data_basis , data_CC_Berggren); 

  const double OBME_potential = OBME_nuclear_potential_basis + OBME_HF_MSDHF_SGI_MSGI + U_finite_range_HF_HO_expansion_part_OBME + OBME_Coulomb;

  return OBME_potential;
}







double CC_H_CM_OBMEs::one_baryon_CM::OBME_h_basis_calc (
							const enum particle_type particle ,
							const int l , 
							const double j , 
							const int n_HO_in , 
							const int n_HO_out , 
							const class CG_str &CGs , 
							const class interaction_class &inter_data_basis , 
							const class array<double> &Gaussian_table_GL , 
							const class multipolar_expansion_str &multipolar_expansion , 
							const class HF_nucleons_data &prot_HF_data , 
							const class HF_nucleons_data &neut_HF_data , 
							const class baryons_data &prot_Y_data_one_configuration_GSM , 
							const class baryons_data &neut_Y_data_one_configuration_GSM , 
							const class baryons_data &neut_Y_data_CC_Berggren , 
							const class baryons_data &data_CC_Berggren)
{
  const unsigned int particle_index = charge_baryon_index_determine (particle);
  
  const enum interaction_type TBME_inter = inter_data_basis.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);

  const class array<double> &effective_masses_for_calc = data_CC_Berggren.get_effective_masses_for_calc ();
  
  const double nu_mass = effective_masses_for_calc(particle_index);
  
  const double b_lab = inter_data_basis.get_b_lab ();
  
  const double nucleus_mass = data_CC_Berggren.get_nucleus_mass ();
  
  const double mass_modif = (!is_it_COSM) ? (-nucleus_mass) : (nucleus_mass);
  
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , mass_modif , nu_mass , b_lab);

  const double OBME_kinetic = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n_HO_in , n_HO_out , hbar_omega);

  const double OBME_potential = OBME_h_basis_potential_calc (particle , l , j , n_HO_in , n_HO_out , CGs , inter_data_basis , Gaussian_table_GL , multipolar_expansion , 
							     prot_HF_data , neut_HF_data , prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , neut_Y_data_CC_Berggren , data_CC_Berggren); 

  const double OBME = OBME_kinetic + OBME_potential;
 
  return OBME;
}








double CC_H_CM_OBMEs::cluster_CM::H_potential_CC_OBME_HO_basis_calc (
								     const int L , 
								     const double J , 
								     const int N_HO_in , 
								     const int N_HO_out , 
								     const class cluster_data &data)
{
  const unsigned int N_bef_R_GL = data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = data.get_N_aft_R_GL ();
								       
  const class array<double> &w_bef_R_tab_GL = data.get_w_bef_R_tab_GL ();
  const class array<double> &w_aft_R_tab_GL = data.get_w_aft_R_tab_GL ();

  const class array<double> &HO_wfs_bef_R_tab_GL = data.get_HO_wfs_bef_R_tab_GL ();
  const class array<double> &HO_wfs_aft_R_tab_GL = data.get_HO_wfs_aft_R_tab_GL ();
  
  const class lj_table<double> &potential_cluster_CM_bef_R_tab_GL = data.get_potential_cluster_CM_bef_R_tab_GL ();
  const class lj_table<double> &potential_cluster_CM_aft_R_tab_GL = data.get_potential_cluster_CM_aft_R_tab_GL ();

  double cluster_CM_H_potential_OBME_HO = 0.0;
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const double w = w_bef_R_tab_GL(i);

      const double wf_in_r  = HO_wfs_bef_R_tab_GL(N_HO_in  , L , i);
      const double wf_out_r = HO_wfs_bef_R_tab_GL(N_HO_out , L , i);

      const double potential_cluster_CM_r = potential_cluster_CM_bef_R_tab_GL(L , J , i);

      cluster_CM_H_potential_OBME_HO += wf_in_r*potential_cluster_CM_r*wf_out_r*w;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const double w = w_aft_R_tab_GL(i);

      const double wf_in_r  = HO_wfs_aft_R_tab_GL(N_HO_in  , L , i);
      const double wf_out_r = HO_wfs_aft_R_tab_GL(N_HO_out , L , i);

      const double potential_cluster_CM_r = potential_cluster_CM_aft_R_tab_GL(L , J , i);
  
      cluster_CM_H_potential_OBME_HO += wf_in_r*potential_cluster_CM_r*wf_out_r*w;
    }

  return cluster_CM_H_potential_OBME_HO;
}








double CC_H_CM_OBMEs::cluster_CM::H_OBME_calc (
					       const int L , 
					       const double J , 
					       const int N_HO_in , 
					       const int N_HO_out , 
					       const class cluster_data &data)
{	
  const double hbar_omega_cluster = data.get_hbar_omega_cluster ();
  
  const double OBME_kinetic = HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (L , N_HO_in , N_HO_out , hbar_omega_cluster);
  
  const double OBME_potential = H_potential_CC_OBME_HO_basis_calc (L , J , N_HO_in , N_HO_out , data);
  
  const double OBME = OBME_kinetic + OBME_potential;
  
  return OBME;
}



