#include "../CC_include/CC_include_def.h"


using namespace inputs_misc;
using namespace GSM_multipoles;
using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;
using namespace CC_observables_common;
using namespace CC_multipoles_MEs;
using namespace CC_multipoles_MEs::radial;


// calculation of the antisymetrized + HO ME
TYPE CC_multipoles_MEs::composite::target_projectile_as_HO_NBME_calc (
								      const bool is_it_one_nucleon_COSM_case , 
								      const int L , 
								      const bool is_it_HO_expansion , 
								      const class CC_Hamiltonian_data &CC_H_data , 
								      const class CC_state_class &CC_state , 
								      const class input_data_str &input_data_CC_Berggren , 
								      class baryons_data &prot_Y_data , 
								      class baryons_data &neut_Y_data ,
								      const class array<class cluster_data> &cluster_projectile_data_tab , 
								      const class array<class vector_class<complex<double> > > &CC_HO_overlaps)
{
  const enum space_type space = input_data_CC_Berggren.get_space ();

  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();

  const bool truncation_hw = input_data_CC_Berggren.get_truncation_hw ();
  const bool truncation_ph = input_data_CC_Berggren.get_truncation_ph ();

  const int n_holes_max = input_data_CC_Berggren.get_n_holes_max ();

  const int n_holes_max_p = prot_Y_data.get_n_holes_max ();
  const int n_holes_max_n = neut_Y_data.get_n_holes_max ();
  
  const int n_scat_max = input_data_CC_Berggren.get_n_scat_max ();

  const int n_scat_max_p = prot_Y_data.get_n_scat_max ();
  const int n_scat_max_n = neut_Y_data.get_n_scat_max ();

  const int E_max_hw = input_data_CC_Berggren.get_E_max_hw ();

  const int Ep_max_hw = prot_Y_data.get_E_max_hw ();
  const int En_max_hw = neut_Y_data.get_E_max_hw ();

  const unsigned int BP = CC_state.get_BP ();

  const double J = CC_state.get_J ();

  const double M = J;

  // composite states (they have to be read in files)
  // they correspond to the [a^+ PSI_GSM]_M^J

  const class GSM_vector_helper_class PSI_HO_helper (space , inter , truncation_hw , truncation_ph ,
						     n_holes_max   , n_scat_max   , E_max_hw  ,
						     n_holes_max_p , n_scat_max_p , Ep_max_hw ,
						     n_holes_max_n , n_scat_max_n , En_max_hw , prot_Y_data , neut_Y_data , BP , M , true);

  class GSM_vector PSI_HO (PSI_HO_helper);

  target_projectile_PSI_HO_calc (is_it_one_nucleon_COSM_case , input_data_CC_Berggren , prot_Y_data , neut_Y_data , cluster_projectile_data_tab , CC_H_data , CC_state , CC_HO_overlaps , PSI_HO);
  
  const class GSM_vector_helper_class dummy_helper;

  configuration_SD_in_space_one_jump::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (false , true , false , false , false , false , PSI_HO_helper , PSI_HO_helper , dummy_helper , prot_Y_data , neut_Y_data);

  TYPE NBME = multipole_ME_calc_one_pair (L , is_it_HO_expansion , J , PSI_HO , J , PSI_HO);
	
#ifdef UseMPI
  if (is_it_MPI_parallelized) MPI_helper::Bcast<TYPE> (NBME , MASTER_PROCESS , MPI_COMM_WORLD);
#endif

  return NBME;
}














// target nas
// common to the non antisymetrized (nas) and for the non antisymetrized + HO (nas_HO)
TYPE CC_multipoles_MEs::composite::target_nas_NBME_calc (
							 const class CC_target_projectile_composite_data &Tpc_data , 
							 const class CC_state_class &CC_state , 
							 const class array<TYPE> &target_NBMEs)
{
  const class array<unsigned int> &target_indices = Tpc_data.get_target_indices ();

  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();

  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();

  TYPE target_nas_NBME = 0.0;
  
  // "out" target state
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A(ic_out);

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const int two_J_Tc_out = make_int (2.0*J_Tc_out);

      const unsigned int iTc_out = target_indices(BP_Tc_out , two_J_Tc_out , vector_index_Tc_out);

      // "in" target state
      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A(ic_in);

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const int two_J_Tc_in = make_int (2.0*J_Tc_in);

	  const unsigned int iTc_in = target_indices(BP_Tc_in , two_J_Tc_in , vector_index_Tc_in);

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_out - J_Tc_in) == 0);
	  
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool LCM_projectiles_condition = (LCM_projectile_c_out == LCM_projectile_c_in);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_out - J_projectile_c_in) == 0);

	  // deltas (is it the same projectile and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && projectiles_condition && LCM_projectiles_condition && J_projectiles_condition)
	    {
	      //get cf_<Jf | Rrms^2 (T) | Ji>_ci
	      const TYPE target_NBME = target_NBMEs(iTc_in , iTc_out);

	      // calculation of int_0^inf dr u_cf (r) * u_ci (r)
	      // radial factor
	      const TYPE factor_radial = radial_integral_calc (OVERLAP , NADA , CC_state , ic_in , ic_out);

	      // calculation of sum_{cf , ci} cf_<Jf | Rrms^2 (T) | Ji>_ci
	      const TYPE total_NBME = target_NBME * factor_radial;
	      
	      target_nas_NBME += total_NBME;
	    }//deltas
	}//loop ic_in
    }//loop ic_out

  return target_nas_NBME;
}











// projectile
// for the non antisymmetrized (nas) NBME
// the CC_state is used
// common to nas and nas+HO
TYPE CC_multipoles_MEs::composite::projectile_nas_NBME_calc (
							     const int L ,
							     const class CC_state_class &CC_state)
{
  const class array<class CC_channel_class> &channels_tab_JPi_A = CC_state.get_channels_tab ();
  
  const unsigned int N_channels_JPi_A = CC_state.get_N_channels ();
 
  TYPE projectile_NBME = 0.0;
  
  for (unsigned int ic_out = 0 ; ic_out < N_channels_JPi_A ; ic_out++)
    {
      const class CC_channel_class &channel_c_out = channels_tab_JPi_A(ic_out);

      const int LCM_projectile_c_out = channel_c_out.get_LCM_projectile ();

      const unsigned int BP_Tc_out = channel_c_out.get_BP_Tc ();

      const unsigned int bp_c_out = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_out);

      const unsigned int vector_index_Tc_out = channel_c_out.get_vector_index_Tc ();

      const double J_projectile_c_out = channel_c_out.get_J_projectile ();

      const double J_Tc_out = channel_c_out.get_J_Tc ();

      const enum particle_type projectile_c_out = channel_c_out.get_projectile ();

      for (unsigned int ic_in = 0 ; ic_in < N_channels_JPi_A ; ic_in++)
	{
	  const class CC_channel_class &channel_c_in = channels_tab_JPi_A(ic_in);

	  const int LCM_projectile_c_in = channel_c_in.get_LCM_projectile ();

	  const unsigned int BP_Tc_in = channel_c_in.get_BP_Tc ();

	  const unsigned int bp_c_in = binary_parity_from_orbital_angular_momentum (LCM_projectile_c_in);

	  const unsigned int vector_index_Tc_in = channel_c_in.get_vector_index_Tc ();

	  const double J_projectile_c_in = channel_c_in.get_J_projectile ();

	  const double J_Tc_in = channel_c_in.get_J_Tc ();

	  const enum particle_type projectile_c_in = channel_c_in.get_projectile ();

	  const bool BP_targets_condition = (BP_Tc_in == BP_Tc_out);

	  const bool J_targets_condition = (make_int (J_Tc_in - J_Tc_out) == 0);

	  const bool vector_index_targets_condition = (vector_index_Tc_in == vector_index_Tc_out);
	 
	  const bool projectiles_condition = (projectile_c_in == projectile_c_out);

	  const bool bp_projectiles_condition = (bp_c_in == bp_c_out);

	  const bool J_projectiles_condition = (make_int (J_projectile_c_in - J_projectile_c_out) == 0);
	   
	  // delta (if it is the same target and quantum numbers are conserved)
	  if (BP_targets_condition && J_targets_condition && vector_index_targets_condition && projectiles_condition && bp_projectiles_condition && J_projectiles_condition)
	    {
	      const TYPE projectile_ME = OBME_calc (L , CC_state , ic_in , ic_out);
	  	      
	      projectile_NBME += projectile_ME;
	    }//delta
	}//loop ic_in
    }//loop_ic_out

  return projectile_NBME;
}























// cf_<J_Tf |Rrms^2 (T) | J_Ti>_ci NBMEs stored
void CC_multipoles_MEs::composite::target_NBMEs_calc (
						      const enum interaction_type inter ,
						      const int L ,
						      const bool is_it_HO_expansion ,
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      class array<class baryons_data> &prot_Y_data_one_cluster_less_tab , 
						      class array<class baryons_data> &neut_Y_data_one_cluster_less_tab , 
						      class array<TYPE> &target_NBMEs)
{
  const bool truncation_hw = Tpc_data.get_truncation_hw ();
  const bool truncation_ph = Tpc_data.get_truncation_ph ();

  const int n_holes_max = Tpc_data.get_n_holes_max ();
  
  const int n_scat_max = Tpc_data.get_n_scat_max ();

  const int E_relative_max_hw = Tpc_data.get_E_relative_max_hw ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();
  
  const class array<unsigned int> &BP_target_tab = Tpc_data.get_BP_target_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &vector_index_target_tab = Tpc_data.get_vector_index_target_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<TYPE> &E_target_tab =  Tpc_data.get_E_target_tab ();

  const class GSM_vector_helper_class dummy_helper;
		  
  // "out" target state
  for (unsigned int iT_out = 0 ; iT_out < N_target_projectile_states ; iT_out++)
    {
      const unsigned int BP_target_out = BP_target_tab(iT_out);

      const unsigned int vector_index_target_out = vector_index_target_tab(iT_out);

      const double J_target_out = J_target_tab(iT_out);

      const double M_target_out = J_target_out;

      const TYPE E_target_out = E_target_tab(iT_out);

      const enum particle_type projectile_out = projectile_tab(iT_out);

      const int Z_projectile_out = Z_cluster_determine (projectile_out);
      const int N_projectile_out = N_cluster_determine (projectile_out);
      
      const int S_projectile_out = particle_strangeness_determine (projectile_out);
      
      const int Y_projectile_out = (S_projectile_out > 0) ? (1) : (0);

      const class baryons_data &prot_Y_data_target_out = prot_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);
      const class baryons_data &neut_Y_data_target_out = neut_Y_data_one_cluster_less_tab(Z_projectile_out , N_projectile_out , Y_projectile_out);

      const int n_holes_max_p_target_out = prot_Y_data_target_out.get_n_holes_max ();
      const int n_holes_max_n_target_out = neut_Y_data_target_out.get_n_holes_max ();
      
      const int n_scat_max_p_target_out = prot_Y_data_target_out.get_n_scat_max ();
      const int n_scat_max_n_target_out = neut_Y_data_target_out.get_n_scat_max ();

      const int ZYval_target_out = prot_Y_data_target_out.get_N_valence_baryons ();
      const int NYval_target_out = neut_Y_data_target_out.get_N_valence_baryons ();

      if ((ZYval_target_out == 0) && (NYval_target_out == 0)) continue;
	  
      const int n_scat_max_target_out = min (n_scat_max , n_scat_max_p_target_out + n_scat_max_n_target_out);

      const int Z_target_out = prot_Y_data_target_out.get_N_nucleons ();
      const int N_target_out = neut_Y_data_target_out.get_N_nucleons ();
      
      const int S_target_out = prot_Y_data_target_out.get_hypernucleus_strangeness ();
      
      const int Ep_max_hw_target_out = prot_Y_data_target_out.get_E_max_hw ();
      const int En_max_hw_target_out = neut_Y_data_target_out.get_E_max_hw ();

      const int Ep_min_hw_target_out = prot_Y_data_target_out.get_E_min_hw ();
      const int En_min_hw_target_out = neut_Y_data_target_out.get_E_min_hw ();
      
      const int E_min_hw_target_out = Ep_min_hw_target_out + En_min_hw_target_out;

      const int E_max_hw_target_out = E_relative_max_hw + E_min_hw_target_out;

      const enum space_type space_target_out = space_determine (ZYval_target_out , NYval_target_out);

      const class correlated_state_str PSI_target_out (Z_target_out , N_target_out , BP_target_out , S_target_out , J_target_out , vector_index_target_out , E_target_out , NADA , NADA , NADA , false);

      const class GSM_vector_helper_class V_target_out_helper (space_target_out , inter , truncation_hw , truncation_ph ,
							       n_holes_max              , n_scat_max_target_out   , E_max_hw_target_out  , 
							       n_holes_max_p_target_out , n_scat_max_p_target_out , Ep_max_hw_target_out ,
							       n_holes_max_n_target_out , n_scat_max_n_target_out , En_max_hw_target_out , 
							       prot_Y_data_target_out , neut_Y_data_target_out , BP_target_out , M_target_out , true);

      class GSM_vector V_target_out (V_target_out_helper);

      if (THIS_PROCESS == MASTER_PROCESS) V_target_out.eigenvector_read_disk (PSI_target_out);

#ifdef UseMPI
      V_target_out.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      // "in" target state
      for (unsigned int iT_in = 0 ; iT_in < N_target_projectile_states ; iT_in++)
	{
	  const unsigned int BP_target_in = BP_target_tab(iT_in);

	  const unsigned int vector_index_target_in = vector_index_target_tab(iT_in);

	  const double J_target_in = J_target_tab(iT_in);

	  const double M_target_in = J_target_in;

	  const TYPE E_target_in = E_target_tab(iT_in);

	  const enum particle_type projectile_in = projectile_tab(iT_in);

	  const int Z_projectile_in = Z_cluster_determine (projectile_in);
	  const int N_projectile_in = N_cluster_determine (projectile_in);
      
	  const int S_projectile_in = particle_strangeness_determine (projectile_in);
      
	  const int Y_projectile_in = (S_projectile_in > 0) ? (1) : (0);

	  class baryons_data &prot_Y_data_target_in = prot_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);
	  class baryons_data &neut_Y_data_target_in = neut_Y_data_one_cluster_less_tab(Z_projectile_in , N_projectile_in , Y_projectile_in);

	  const int n_holes_max_p_target_in = prot_Y_data_target_in.get_n_holes_max ();
	  const int n_holes_max_n_target_in = neut_Y_data_target_in.get_n_holes_max ();
	  
	  const int n_scat_max_p_target_in = prot_Y_data_target_in.get_n_scat_max ();
	  const int n_scat_max_n_target_in = neut_Y_data_target_in.get_n_scat_max ();

	  const int ZYval_target_in = prot_Y_data_target_in.get_N_valence_baryons ();
	  const int NYval_target_in = neut_Y_data_target_in.get_N_valence_baryons ();
	  
	  if ((ZYval_target_in == 0) && (NYval_target_in == 0)) continue;
      
	  const int n_scat_max_target_in = min (n_scat_max , n_scat_max_p_target_in + n_scat_max_n_target_in);

	  const int Z_target_in = prot_Y_data_target_in.get_N_nucleons ();
	  const int N_target_in = neut_Y_data_target_in.get_N_nucleons ();

	  const int S_target_in = prot_Y_data_target_in.get_hypernucleus_strangeness ();
	  
	  const int Ep_max_hw_target_in = prot_Y_data_target_in.get_E_max_hw ();
	  const int En_max_hw_target_in = neut_Y_data_target_in.get_E_max_hw ();

	  const int Ep_min_hw_target_in = prot_Y_data_target_in.get_E_min_hw ();
	  const int En_min_hw_target_in = neut_Y_data_target_in.get_E_min_hw ();
      
	  const int E_min_hw_target_in = Ep_min_hw_target_in + En_min_hw_target_in;

	  const int E_max_hw_target_in = E_relative_max_hw + E_min_hw_target_in;

	  const enum space_type space_target_in = space_determine (ZYval_target_in , NYval_target_in);

	  const class correlated_state_str PSI_target_in (Z_target_in , N_target_in , BP_target_in , S_target_in , J_target_in , vector_index_target_in , E_target_in , NADA , NADA , NADA , false);

	  const class GSM_vector_helper_class V_target_in_helper (space_target_in , inter , truncation_hw , truncation_ph ,
								  n_holes_max             , n_scat_max_target_in   , E_max_hw_target_in  , 
								  n_holes_max_p_target_in , n_scat_max_p_target_in , Ep_max_hw_target_in ,
								  n_holes_max_n_target_in , n_scat_max_n_target_in , En_max_hw_target_in , 
								  prot_Y_data_target_in , neut_Y_data_target_in , BP_target_in , M_target_in , true);

	  // deltas (is it the same projectile)
	  if ((space_target_in == space_target_out) && (projectile_in == projectile_out))
	    {
	      class GSM_vector V_target_in (V_target_in_helper);

	      if (THIS_PROCESS == MASTER_PROCESS) V_target_in.eigenvector_read_disk (PSI_target_in);

#ifdef UseMPI
	      V_target_in.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

	      
	      if ((BP_target_in == BP_target_out) && (make_int (J_target_in - J_target_out) == 0))
		{
		  class baryons_data &prot_Y_data_target = prot_Y_data_target_in;
		  class baryons_data &neut_Y_data_target = neut_Y_data_target_in;
		  
		  const double J_target = J_target_in;

		  configuration_SD_in_space_one_jump::configuration_SD_in_out_in_space_one_jump_tables_alloc_calc (
														   false , true , false , false , false , false , 
														   V_target_in_helper , V_target_out_helper , 
														   dummy_helper , 
														   prot_Y_data_target , neut_Y_data_target);

		  // calculates cf_<J_Tf | multipole (T) | J_Ti>_ci	
	
		  const TYPE target_NBME = multipole_ME_calc_one_pair (L , is_it_HO_expansion , J_target , V_target_in , J_target , V_target_out);
    
		  if (THIS_PROCESS == MASTER_PROCESS) target_NBMEs(iT_in , iT_out) = target_NBME;
		}//deltas projectile
	    }//deltas space projectile
	}//loop iT_in
    }//loop iT_out
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) target_NBMEs.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
}












TYPE CC_multipoles_MEs::composite::CC_NBME_calc ( 
						 const int L , 
						 const bool is_it_HO_expansion , 
						 const bool is_it_nas_only , 
						 const class CC_target_projectile_composite_data &Tpc_data , 
						 const class array<class cluster_data> &cluster_projectile_data_tab , 
						 const class CC_Hamiltonian_data &CC_H_data , 
						 const class CC_state_class &CC_state , 
						 class baryons_data &prot_Y_data , 
						 class baryons_data &neut_Y_data , 
						 const class input_data_str &input_data_CC_Berggren , 
						 const class array<TYPE> &target_NBMEs)
{
  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();

  //================================== projectile ==================================//
  // for the non antisymetrized (nas) the CC_state_out/in are used
  // for the non antisymetrized + HO (nas_HO) the CC_state_out/in are projected in the HO basis

  // projection of the out and in states in the HO basis

  class CC_state_class CC_state_HO (CC_state);

  CC_state_HO.CC_HO_wfs_projection ();

  //===================================non antisymetrized (nas)==============================================================================

  // sum of the matrix elts for the projectile
  const TYPE projectile_NBME_nas = projectile_nas_NBME_calc (L , CC_state);

  // sum of the matrix elts for the target
  const TYPE target_NBME_nas = target_nas_NBME_calc (Tpc_data , CC_state , target_NBMEs);

  // calculation of <Jf | Rrms^2 | Ji> = sum_{cf , ci} ( cf_<Jf | Rrms^2 (p) | Ji>_ci + cf_<Jf | Rrms^2 (T) | Ji>_ci )
  // nas
  const TYPE total_NBME_nas = projectile_NBME_nas + target_NBME_nas;

  if (is_it_nas_only) return total_NBME_nas;

  // sum of the matrix elts for the projectile (HO)
  const TYPE projectile_NBME_nas_HO = projectile_nas_NBME_calc (L , CC_state_HO);

  // sum of the matrix elts for the target (nas_HO)
  const TYPE target_NBME_nas_HO = target_nas_NBME_calc (Tpc_data , CC_state_HO , target_NBMEs);

  // calculation of <Jf | Rrms^2 | Ji> = sum_{cf , ci} ( cf_<Jf | Rrms^2 (p) | Ji>_ci + cf_<Jf | Rrms^2 (T) | Ji>_ci )
  // nas and in HO basis
  const TYPE total_NBME_nas_HO = projectile_NBME_nas_HO + target_NBME_nas_HO;


  //================================== antisymetrized and HO projection (as_HO) ===================================//
  //===============================================================================================================//


  //================================== CC_HO overlaps (<u_c^{HO} | u_n>) ==================================//

  // for the composite state
  const class array<class vector_class<complex<double> > > &CC_HO_overlaps = CC_state.get_HO_overlaps ();

  //================================== calculation of the antisymetrized + HO ME ==================================//

  // <Jf | Rrms^2 | Ji>
  // antisymetrized andf in the HO basis
  const TYPE total_NBME_as_HO = target_projectile_as_HO_NBME_calc (is_it_one_baryon_COSM_case , L , is_it_HO_expansion , CC_H_data , CC_state ,
								   input_data_CC_Berggren , prot_Y_data , neut_Y_data , cluster_projectile_data_tab , CC_HO_overlaps);

  // final result
  const TYPE total_NBME = total_NBME_nas + (total_NBME_as_HO - total_NBME_nas_HO);

  return total_NBME;
}

