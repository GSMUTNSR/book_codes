#include "../CC_include/CC_include_def.h"

using namespace beta_transitions_common;
using namespace Wigner_signs;

using namespace CC_beta_transitions_MEs::radial;

//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_MEs::one_baryon::beta_suboperator_OBME_reduced_calc (
									      const enum beta_pm_type beta_pm ,
									      const enum radial_operator_type radial_operator ,
									      const enum beta_suboperator_type beta_suboperator ,
									      const double R_charge , 
									      const class CC_state_class &CC_state_in ,
									      const class CC_state_class &CC_state_out ,
									      const unsigned int ic_in ,
									      const unsigned int ic_out ,
									      class array<TYPE> &beta_suboperator_OBMEs_reduced)
{
  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);

  beta_suboperator_OBMEs_reduced(beta_suboperator_index) = 0.0;
 
  const unsigned int BP_Op = BP_beta_suboperator_determine (beta_suboperator);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);
    
  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();
  
  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) != BP_Op) return;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();
  
  const int Z_projectile_in = Z_cluster_determine (projectile_in);
  const int N_projectile_in = N_cluster_determine (projectile_in);
  
  const int Z_projectile_out = Z_cluster_determine (projectile_out);
  const int N_projectile_out = N_cluster_determine (projectile_out);

  if (Z_projectile_in != Z_IN_beta_determine (beta_pm , Z_projectile_out)) return;
  if (N_projectile_in != N_IN_beta_determine (beta_pm , N_projectile_out)) return;
  
  const double J_projectile_in = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();
  
  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);
  
  if ((abs (make_int (J_projectile_out - J_projectile_in)) > rank_Op) || (make_int (J_projectile_out + J_projectile_in) < rank_Op)) return;
   
  //--// calculations of the radial beta matrix element

  const TYPE radial_OBME = radial_integral_calc (radial_operator , R_charge , CC_state_in , CC_state_out , ic_in , ic_out);
  
  //--// here the angular part <lf jf || beta || li ji> is taken into account
  
  beta_suboperator_OBMEs_reduced(beta_suboperator_index) = beta_suboperator_OBME_reduced_calc (beta_suboperator , radial_OBME , LCM_projectile_in , J_projectile_in , LCM_projectile_out , J_projectile_out);
}







//--// return <uc_f lf jf || E_L || uc_i li ji>
void CC_beta_transitions_MEs::one_baryon::beta_suboperators_OBMEs_reduced_calc (
										const enum beta_type beta , 
										const enum beta_pm_type beta_pm ,
										const double R_charge ,
										const class CC_state_class &CC_state_in , 
										const class CC_state_class &CC_state_out , 
										const unsigned int ic_in , 
										const unsigned int ic_out , 
										class array<TYPE> &beta_suboperator_OBMEs_reduced)
{
  const unsigned int BP_Op = BP_beta_determine (beta);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      switch (beta)
	{
	case ALLOWED:
	  {
	    beta_suboperator_OBME_reduced_calc (beta_pm , OVERLAP , FERMI_ALLOWED        , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , OVERLAP , GAMOW_TELLER_ALLOWED , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	  } break;
	      
	case FIRST_FORBIDDEN:
	  {
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD , W_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD , U_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD , Z_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD , X_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD_COULOMB , W_FFBD_COULOMB , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD_COULOMB , U_FFBD_COULOMB , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , FFBD_COULOMB , X_FFBD_COULOMB , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	
	    beta_suboperator_OBME_reduced_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_V_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	    beta_suboperator_OBME_reduced_calc (beta_pm , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , R_charge , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_OBMEs_reduced);
	  } break;

	default: abort_all ();
	}
    }
}





