#include "../CC_include/CC_include_def.h"

using namespace angular_matrix_elements;

using namespace Wigner_signs;

using namespace CC_multipoles_MEs::radial;

//--// return <uc_f lf jf || beta || uc_i li ji>
TYPE CC_multipoles_MEs::OBME_calc (
				   const int L ,
				   const class CC_state_class &CC_state ,
				   const unsigned int ic_in ,
				   const unsigned int ic_out)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (LCM_projectile_in != LCM_projectile_out) return 0.0;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  if (make_int (J_projectile_in - J_projectile_out) != 0) return 0.0;

  const double angular_OBME = OBME_YL_square (L , LCM_projectile_in);

  //--// calculations of the radial multipole matrix element
  const TYPE radial_OBME = radial_integral_calc (R2L_RADIAL , L , CC_state , ic_in , ic_out);
  
  const TYPE OBME = angular_OBME*radial_OBME;
      
  return OBME;
}






