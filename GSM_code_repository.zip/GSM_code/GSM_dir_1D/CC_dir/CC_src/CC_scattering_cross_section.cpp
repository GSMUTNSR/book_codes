#include "../CC_include/CC_include_def.h"


using namespace string_routines;
using namespace Wigner_signs;
using namespace inputs_misc;
using namespace CC_common_routines;
using namespace CC_observables_common;
using namespace CC_waves_HF_MSDHF_potentials_calculations;








void CC_scattering_cross_section::iterative_calc (
						  const class input_data_str &input_data_CC_Berggren , 
						  const class interaction_class &inter_data_basis , 
						  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
						  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
						  const class CC_target_projectile_composite_data &Tpc_data , 
						  const class array<class cluster_data> &cluster_projectile_data_tab , 
						  class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
						  class baryons_data &prot_Y_data_CC_Berggren , 
						  class baryons_data &neut_Y_data_CC_Berggren , 
						  class baryons_data &prot_Y_data , 
						  class baryons_data &neut_Y_data , 
						  class TBMEs_class &TBMEs_pn , 
						  class TBMEs_class &TBMEs_cv , 
						  class array<double> &phase_shifts , 
						  class array<complex<double> > &T_matrix_values)
{
  cout.precision(15);

  const bool are_GSM_a_dagger_vectors_calculated = Tpc_data.get_are_GSM_a_dagger_vectors_calculated ();

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
    
  const bool is_it_pole_calculation = (CC_reaction_calculation == POLES);

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
  
  const unsigned int N_JPi_A = Tpc_data.get_N_JPi_A ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();
  
  const class array<complex<double> > &e_channels_tab = Tpc_data.get_e_channels_tab ();

  const int S = Tpc_data.get_S ();
  
  const unsigned int iT_entrance = (!is_it_pole_calculation) ? (Tpc_data.get_entrance_target_index ()) : (NADA);
  
  const double CM_to_work_frame_kinetic_factor = Tpc_data.get_CM_to_work_frame_kinetic_factor ();

  const double R = input_data_CC_Berggren.get_R ();

  const double R_real_max = input_data_CC_Berggren.get_R_real_max ();

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab ();

  const class array<unsigned int> &vector_index_A_tab = Tpc_data.get_vector_index_A_tab ();

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &N_entrance_channels_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  /* Coupled - channel calculations */

  const complex<double> e_entrance_channel = (!is_it_pole_calculation) ? (e_channels_tab(iT_entrance , 0)) : (NADA);

  const double K_CM = (!is_it_pole_calculation) ? (real_dc (e_entrance_channel)/CM_to_work_frame_kinetic_factor) : (NADA);

  //-- for K_CM=0 , the T_matrix element is put to zero

  const unsigned int iE_start = (!is_it_pole_calculation && (K_CM < 0.0)) ? (1) : (0);

  const double E_start = E_total_tab(iE_start);

  bool ME_storage = are_GSM_a_dagger_vectors_calculated;

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const unsigned int N_channels_JPi_A = N_channels_tab(iJPi_A);

      const unsigned int N_entrance_channels = N_entrance_channels_tab(iJPi_A);

      const unsigned int BP_A = BP_A_tab(iJPi_A);

      const unsigned int vector_index_A = vector_index_A_tab(iJPi_A);

      const double J_A = J_A_tab(iJPi_A);

      /* Tab of all channel - channels for the given composite state */

      class array<class CC_channel_class> channels_JPi_A_tab (N_channels_JPi_A);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP_A , J_A , vector_index_A , E_start , channels_JPi_A_tab);

      /* CC Hartree-Fock calculations */

      class HF_nucleons_data CC_prot_HF_data;
      class HF_nucleons_data CC_neut_HF_data;

      class baryons_data prot_Y_data_one_configuration_GSM;
      class baryons_data neut_Y_data_one_configuration_GSM;
      
      if (is_it_one_baryon_COSM_case)
	{
	  class baryons_data CC_prot_Y_data;
	  class baryons_data CC_neut_Y_data;

	  baryons_data_initialization (true , input_data_CC_Berggren , CC_prot_Y_data , CC_neut_Y_data);

	  const int lp_max = CC_prot_Y_data.get_lmax ();
	  const int ln_max = CC_neut_Y_data.get_lmax ();

	  class lj_table<bool> prot_OCM_valence_state_tab(0.5 , lp_max);
	  class lj_table<bool> neut_OCM_valence_state_tab(0.5 , ln_max);

	  OCM_valence_state_tab_fill (CC_prot_Y_data , prot_OCM_valence_state_tab);
	  OCM_valence_state_tab_fill (CC_neut_Y_data , neut_OCM_valence_state_tab);

	  is_it_OCM_HO_core_determine (input_data_CC_Berggren , CC_prot_Y_data , CC_neut_Y_data);

	  const class lj_table<int> &prot_nmin_lj_valence_tab = prot_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();
	  const class lj_table<int> &neut_nmin_lj_valence_tab = neut_HF_data_CC_Berggren.get_nmin_lj_valence_tab ();

	  prepare_CC_prot_neut_Y_data (channels_JPi_A_tab , false , prot_nmin_lj_valence_tab , neut_nmin_lj_valence_tab , prot_OCM_valence_state_tab , neut_OCM_valence_state_tab , CC_prot_Y_data , CC_neut_Y_data);
	  
	  CC_prot_HF_data.allocate (input_data_CC_Berggren , CC_prot_Y_data);
	  CC_neut_HF_data.allocate (input_data_CC_Berggren , CC_neut_Y_data);
	  
	  CC_state_calc_preparation (
				     prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , 
				     prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , CC_prot_HF_data , CC_neut_HF_data);
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << endl;

      /* CC - calculations */

      /* Calculation of the matrix elements and overlaps:
	 _ fr_orth_pot_HO: orthonormalized final potential in HO basis , 
	 _ fr_overlaps_HO: finite range overlap in HO basis , 
	 _ sqrt_O_Delta_sqrt_O_overlaps_HO: finite range of the overlap matrix to the power - 1/2 in HO basis multiplied by sqrt O before and after.get_ */

      class CC_Hamiltonian_data CC_H_data(N_channels_JPi_A , input_data_CC_Berggren);

      CC_H_data.dimension_matrices_independent_data_realloc_init (is_it_one_baryon_COSM_case , input_data_CC_Berggren , inter_data_basis , channels_JPi_A_tab , 
								  prot_Y_data , neut_Y_data , cluster_projectile_data_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , cluster_projectile_data_CC_Berggren_tab);	

      CC_H_data.corrective_factors_read (input_data_CC_Berggren);

      CC_H_data.HO_wfs_Gaussian_tables_calc (R , R_real_max , channels_JPi_A_tab , inter_data_basis);

      bool compute_matrices = true;

      for (unsigned int iE = iE_start ; iE < N_energies ; iE++) 
	{
	  if (!compute_matrices) ME_storage = false;

	  const double E = E_total_tab(iE);
	  
	  for (unsigned int ic_JPi_A = 0 ; ic_JPi_A < N_channels_JPi_A ; ic_JPi_A++) channels_JPi_A_tab(ic_JPi_A).E_dependent_values_change (E); 

	  for (unsigned int i_entrance = 0 ; (is_it_pole_calculation) ? (i_entrance <= 0) : (i_entrance < N_entrance_channels) ; i_entrance++)
	    {
	      CC_state_T_matrix_calc (iE , i_entrance , iJPi_A , compute_matrices , input_data_CC_Berggren , inter_data_basis , 
				      prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , 
				      Tpc_data , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , channels_JPi_A_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , 
				      ME_storage , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_prot_HF_data , CC_neut_HF_data , CC_H_data , phase_shifts , T_matrix_values);

	      compute_matrices = false;
	    }
	}

      ME_storage = are_GSM_a_dagger_vectors_calculated;

      if (is_it_one_baryon_COSM_case)
	{
	  HF_wave_function::waves_deallocate (CC_prot_HF_data);
	  HF_wave_function::waves_deallocate (CC_neut_HF_data);
	}
    }
}







void CC_scattering_cross_section::CC_state_T_matrix_calc (
							  const unsigned int iE , 
							  const unsigned int i_entrance , 
							  const unsigned int iJPi_A , 
							  const bool compute_matrices , 
							  const class input_data_str &input_data_CC_Berggren , 
							  const class interaction_class &inter_data_basis , 
							  const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
							  const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
							  const class baryons_data &prot_Y_data_one_configuration_GSM , 
							  const class baryons_data &neut_Y_data_one_configuration_GSM , 
							  const class CC_target_projectile_composite_data &Tpc_data , 
							  const class array<class cluster_data> &cluster_projectile_data_tab , 
							  class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
							  const class array<class CC_channel_class> &channels_JPi_A_tab , 
							  class baryons_data &prot_Y_data_CC_Berggren , 
							  class baryons_data &neut_Y_data_CC_Berggren , 
							  const bool ME_storage , 
							  class baryons_data &prot_Y_data , 
							  class baryons_data &neut_Y_data , 
							  class TBMEs_class &TBMEs_pn , 
							  class TBMEs_class &TBMEs_cv , 
							  class HF_nucleons_data &CC_prot_HF_data , 
							  class HF_nucleons_data &CC_neut_HF_data , 
							  class CC_Hamiltonian_data &CC_H_data , 
							  class array<double> &phase_shifts , 
							  class array<complex<double> > &T_matrix_values)
{
  cout.precision (6);
      
  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();
  
  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab ();

  const class array<unsigned int> &vector_index_A_tab = Tpc_data.get_vector_index_A_tab ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();
      
  const class array<int> &nmax_HO_lab_tab = inter_data_basis.get_nmax_HO_lab_tab ();

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const bool is_it_one_baryon_COSM_case = Tpc_data.get_is_it_one_baryon_COSM_case ();
      
  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
      
  const bool is_it_pole_calculation = (CC_reaction_calculation == POLES);

  const bool is_it_SGI_MSGI = is_it_SGI_MSGI_determine (inter);

  const unsigned int N_bef_R_uniform = prot_Y_data.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = prot_Y_data.get_N_aft_R_uniform ();

  const unsigned int N_bef_R_GL = prot_Y_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = prot_Y_data.get_N_aft_R_GL ();

  const unsigned int Nk_momentum_GL = input_data_CC_Berggren.get_Nk_momentum_GL ();
  
  const unsigned int Nk_momentum_uniform = input_data_CC_Berggren.get_Nk_momentum_uniform ();
  
  const int A = prot_Y_data.get_A ();
      
  const double R_real_max = prot_Y_data.get_R_real_max ();

  const double kmax_momentum = input_data_CC_Berggren.get_kmax_momentum ();

  const double R_Fermi_momentum = input_data_CC_Berggren.get_R_Fermi_momentum ();
  
  const double R = prot_Y_data.get_R ();

  const double R0_inter = inter_data_basis.get_R0 ();

  const double R0 = 1.27*cbrt (A);

  const double R0_matching_point = (is_it_SGI_MSGI) ? (R0_inter) : (R0);

  const unsigned int ic_JPi_A_entrance = (!is_it_pole_calculation) ? (entrance_JPi_channels_indices(iJPi_A , i_entrance)) : (NADA);
      
  const unsigned int BP_A = BP_A_tab(iJPi_A);

  const unsigned int vector_index_A = vector_index_A_tab(iJPi_A);

  const double J_A = J_A_tab(iJPi_A);

  const double M_A = J_A;

  const double radians_to_degrees_factor = 180.0/M_PI;

  const double E = E_total_tab(iE);

  const unsigned int N_channels_JPi_A = channels_JPi_A_tab.dimension (0);

  class CC_state_class CC_state(is_it_one_baryon_COSM_case , nmax_HO_lab_tab , cluster_projectile_data_tab , is_it_pole_calculation , true , N_channels_JPi_A ,
				ic_JPi_A_entrance , channels_JPi_A_tab , N_bef_R_uniform , N_aft_R_uniform , N_bef_R_GL , N_aft_R_GL , Nk_momentum_uniform , Nk_momentum_GL ,
				R , R0_matching_point , R_real_max , kmax_momentum , R_Fermi_momentum , A , BP_A , J_A , M_A , vector_index_A , E);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << "------------------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl;

      if (is_it_pole_calculation)
	{
	  cout << endl << "Calculation of pole state " << J_Pi_string (BP_A , J_A) << endl;
	  cout <<         "------------------------------" << endl << endl;
	}
      else
	{
	  const class CC_channel_class &entrance_channel = channels_JPi_A_tab(ic_JPi_A_entrance);

	  cout << endl << "Calculation of scattering state " << J_Pi_string (BP_A , J_A) << endl;
	  cout <<         "------------------------------------" << endl << endl;
	  
	  cout << "Entrance channel : " << entrance_channel << endl;
	  
	  cout << "Energy index : " << iE << endl;

	  if (inter == REALISTIC_INTERACTION)
	    cout << "E(CM) : " << E << " MeV" << endl;
	  else
	    cout << "E(COSM) : " << E << " MeV" << endl;
	}
    }

  CC_state_iterative_calc (Tpc_data , compute_matrices , ME_storage , input_data_CC_Berggren , inter_data_basis , 
			   prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , prot_Y_data_one_configuration_GSM , neut_Y_data_one_configuration_GSM , cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , 
			   prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , CC_prot_HF_data , CC_neut_HF_data , CC_H_data , CC_state);

  if (!is_it_pole_calculation)
    {
      const class CC_channel_class &entrance_channel = channels_JPi_A_tab(ic_JPi_A_entrance);

      if (THIS_PROCESS == MASTER_PROCESS) cout << "Entrance channel : " << entrance_channel << endl << endl;

      for (unsigned int ic_JPi_A = 0 ; ic_JPi_A < N_channels_JPi_A ; ic_JPi_A++)
	{
	  const double delta_radians_c = real_dc (CC_state.get_phase_shift (ic_JPi_A));

	  const double phase_shift_c = delta_radians_c*radians_to_degrees_factor;

	  const complex<double> T_matrix_value_c = CC_state.get_T_matrix_value (ic_JPi_A_entrance , ic_JPi_A);
	      
	  const class CC_channel_class &channel_c = channels_JPi_A_tab(ic_JPi_A);

	  const complex<double> e_c = channel_c.get_e_projectile ();
	  
	  T_matrix_values(iJPi_A , i_entrance , ic_JPi_A , iE) = T_matrix_value_c;

	  phase_shifts(iJPi_A , i_entrance , ic_JPi_A , iE) = phase_shift_c;	  

	  if ((THIS_PROCESS == MASTER_PROCESS) && (real_dc (e_c) > 0.0))
	    {
	      if (inter == REALISTIC_INTERACTION)
		cout << "Out channel : " << channel_c << " Energy(CM) : " << E << " MeV T-matrix value : " << T_matrix_value_c << " Phase shift : " << phase_shift_c << endl;
	      else
		cout << "Out channel : " << channel_c << " Energy(COSM) : " << E << " MeV T-matrix value : " << T_matrix_value_c << " Phase shift : " << phase_shift_c << endl;
	    }
	}
    }

  if (THIS_PROCESS == MASTER_PROCESS)
    cout << "------------------------------------------------------------------------------------------------------------------------------------------------------------------------" << endl << endl;

  cout.precision (15);
}







void CC_scattering_cross_section::tau_tab_calc (
						const bool print_detailed_information ,
						const double K_CM , 
						const class CC_target_projectile_composite_data &Tpc_data , 
						class array<double> &tau_tab)
{
  const double mass_entrance_projectile = Tpc_data.get_mass_entrance_projectile ();

  const double mass_target = Tpc_data.get_mass_target ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<TYPE > &E_target_tab = Tpc_data.get_E_target_tab ();

  const TYPE E_entrance_target = E_target_tab(iT_entrance);
  
  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();
	      
  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const TYPE E_target = E_target_tab(iT);
	  
	  const double Q = (iT != iT_entrance) ? (real_dc (E_entrance_target - E_target)) : (0.0);	  

	  const double K_CM_plus_Q = K_CM + Q;

	  const double inelastic_factor_not_entrance_channel = (K_CM_plus_Q >= 0.0) ? (sqrt (K_CM/K_CM_plus_Q)) : (0.0);

	  const double inelastic_factor = (iT != iT_entrance) ? (inelastic_factor_not_entrance_channel) : (1.0);

	  const double tau = inelastic_factor*mass_entrance_projectile/mass_target;

	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information && (tau > 1.0))
	    {	      
	      const string data_str = "Target index : " + make_string<unsigned int> (iT) + " K[CM] : " + make_string<double> (K_CM) + " Q[if] : " + make_string<double> (Q) + " tau : "  + make_string<double> (tau); 

	      const string sentence_str = "One has tau > 1 (M[target] < M[projectile]). The differential cross section in the laboratory frame has two components in the center of mass which cannot be separated. The associated result must be ignored.";

	      cout << data_str << " " << sentence_str << endl;
	    }

	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information && (tau == 0.0) && (iT != iT_entrance))
	    cout << "Target index : " << iT << " K[CM] : " << K_CM << " Q[if] : " << Q << " Note : This ensemble of channels is closed for inelastic scattering" << endl;

	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information && (tau == 0.0) && (iT == iT_entrance))
	    cout << "Target index : " << iT << " K[CM] : " << K_CM << " Q[if] : " << Q << " Note : This ensemble of channels is closed for elastic and inelastic scattering" << endl;

	  tau_tab(iT) = tau;
	}
    }
}







void CC_scattering_cross_section::theta_lab_tab_calc (
						      const class array<bool> &is_it_pole_target_tab , 
						      const class array<double> &tau_tab , 
						      const class array<double> &theta_CM_tab , 
						      class array<double> &theta_lab_tab)
{
  const unsigned int N_target_projectile_states = theta_lab_tab.dimension (0);

  const unsigned int N_theta = theta_lab_tab.dimension (1);

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const double tau = tau_tab(iT);

	  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
	    {
	      const double theta_CM = theta_CM_tab(i_theta);

	      const double cos_theta_CM = cos (theta_CM);

	      const double cos_theta_CM_plus_tau = cos_theta_CM + tau;

	      if ((abs (tau - 1.0) > precision) || (abs (cos_theta_CM + tau) > precision))
		{	      
		  const double cos_theta_lab = cos_theta_CM_plus_tau / sqrt (1.0 + 2.0 * tau * cos_theta_CM + tau * tau);
  
		  const double theta_lab = acos (cos_theta_lab);

		  theta_lab_tab(iT , i_theta) = theta_lab;
		}
	      else
		theta_lab_tab(iT , i_theta) = M_PI_2;
	    }
	}
    }
}










void CC_scattering_cross_section::F_Coulomb_entrance_target_tab_calc (
								      const complex<double> &k_entrance_channel , 
								      const complex<double> &eta_entrance_channel , 
								      const class array<bool> &is_it_pole_target_tab , 
								      const class array<double> &theta_lab_tab , 
								      class array<complex<double> > &F_Coulomb_entrance_target_tab)
{
  const unsigned int N_target_projectile_states = F_Coulomb_entrance_target_tab.dimension (0);

  const unsigned int N_theta = F_Coulomb_entrance_target_tab.dimension (1);

  const complex<double> I(0 , 1);

  const complex<double> factor_Coulomb_entrance_target = -0.5 * eta_entrance_channel/k_entrance_channel;

  const complex<double> sigma_zero_entrance_target = sigma_l_calc (0.0 , eta_entrance_channel);

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++) 
    {
      if (is_it_pole_target_tab(iT))
	{
	  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
	    {
	      const double theta_lab = theta_lab_tab(iT , i_theta);

	      const double half_theta_lab = 0.5 * theta_lab;

	      const double sin_half_theta_lab = sin (half_theta_lab);

	      const double sin_square_half_theta_lab = sin_half_theta_lab * sin_half_theta_lab;

	      const complex<double> exponential_factor = eta_entrance_channel * log (sin_square_half_theta_lab) - 2.0 * sigma_zero_entrance_target;	      

	      F_Coulomb_entrance_target_tab(iT , i_theta) = factor_Coulomb_entrance_target * exp (-I * exponential_factor)/sin_square_half_theta_lab;
	    }
	}
    }
}









void CC_scattering_cross_section::F_tab_Coulomb_part_calc (
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   const class array<complex<double> > &F_Coulomb_entrance_target_tab , 
							   class array<complex<double> > &F_tab)
{
  const unsigned int N_target_projectile_states = F_Coulomb_entrance_target_tab.dimension (0);

  const unsigned int N_theta = F_Coulomb_entrance_target_tab.dimension (1);

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const double J_entrance_target = J_target_tab(iT_entrance);

  const int M_entrance_target_number = make_int (2.0 * J_entrance_target + 1.0);

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const int M_intrinsic_entrance_projectile_number = make_int (2.0 * J_intrinsic_entrance_projectile + 1.0);

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const double J_target = J_target_tab(iT);

	  const int M_target_number = make_int (2 * J_target + 1.0);

	  const enum particle_type projectile = projectile_tab(iT);

	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

	  for (int iM_intrinsic_entrance_projectile = 0 ; iM_intrinsic_entrance_projectile < M_intrinsic_entrance_projectile_number ; iM_intrinsic_entrance_projectile++) 
	    {
	      const double M_intrinsic_entrance_projectile = iM_intrinsic_entrance_projectile - J_intrinsic_entrance_projectile;

	      for (int iM_entrance_target = 0 ; iM_entrance_target < M_entrance_target_number ; iM_entrance_target++) 
		for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
		  {
		    const double M_intrinsic_projectile = iM_intrinsic_projectile - J_intrinsic_projectile;

		    for (int iM_target = 0 ; iM_target < M_target_number ; iM_target++) 
		      {
			const double M_entrance_target = iM_entrance_target - J_entrance_target;

			const double M_target = iM_target - J_target;

			if ((iT == iT_entrance) && (rint (M_intrinsic_projectile - M_intrinsic_entrance_projectile) == 0.0) && (rint (M_target - M_entrance_target) == 0.0))
			  {
			    for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
			      F_tab(iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta) = F_Coulomb_entrance_target_tab(iT , i_theta);
			  }
		      }
		  }
	    }
	}
    }
}







void CC_scattering_cross_section::F_tab_nuclear_part_calc (
							   const class CC_target_projectile_composite_data &Tpc_data , 
							   const class array<double> &theta_lab_tab , 
							   const class array<complex<double> > &T_matrix_values , 
							   const unsigned int iE , 
							   const double K_CM ,
							   class array<complex<double> > &F_tab , 
							   class array<complex<double> > &F_tab_left , 
							   class array<complex<double> > &F_tab_right)
{
  const complex<double> I(0 , 1);

  const int S = Tpc_data.get_S ();
  
  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab ();

  const class array<unsigned int> &vector_index_A_tab = Tpc_data.get_vector_index_A_tab ();

  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const unsigned int N_target_projectile_states = theta_lab_tab.dimension (0);

  const unsigned int N_theta = theta_lab_tab.dimension (1);

  const unsigned int N_JPi_A = J_A_tab.dimension (0);

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const class array<unsigned int> &N_entrance_channels_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<TYPE > &E_target_tab = Tpc_data.get_E_target_tab ();

  const class array<complex<double> > &k_channels_tab = Tpc_data.get_k_channels_tab ();

  const class array<complex<double> > &eta_channels_tab = Tpc_data.get_eta_channels_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const TYPE E_entrance_target = E_target_tab(iT_entrance);

  const double J_entrance_target = J_target_tab(iT_entrance);

  const int M_entrance_target_number = make_int (2.0 * J_entrance_target + 1.0);

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const int M_intrinsic_entrance_projectile_number = make_int (2.0 * J_intrinsic_entrance_projectile + 1.0);

  const complex<double> k_entrance_channel = k_channels_tab(iT_entrance , iE);

  const complex<double> eta_entrance_channel = eta_channels_tab(iT_entrance , iE);

  const class array<unsigned int> &N_channels_per_target_projectile_tab = Tpc_data.get_N_channels_per_target_projectile_tab ();

  const class array<unsigned int> &JPi_channels_indices_per_target_projectile = Tpc_data.get_JPi_channels_indices_per_target_projectile ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{	
	  const enum particle_type projectile = projectile_tab(iT);

	  const TYPE E_target = E_target_tab(iT);

	  const double Q = real_dc (E_entrance_target - E_target);

	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  const int iM_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

	  if ((K_CM + Q) >= 0.0)
	    {
	      const double J_target = J_target_tab(iT);

	      const int M_target_number = make_int (2.0 * J_target + 1.0);

	      for (int iM_intrinsic_entrance_projectile = 0 ; iM_intrinsic_entrance_projectile < M_intrinsic_entrance_projectile_number ; iM_intrinsic_entrance_projectile++)
		{
		  const double M_intrinsic_entrance_projectile = iM_intrinsic_entrance_projectile - J_intrinsic_entrance_projectile;

		  for (int iM_entrance_target = 0 ; iM_entrance_target < M_entrance_target_number ; iM_entrance_target++)
		    {
		      const double M_entrance_target = iM_entrance_target - J_entrance_target;

		      const double M_A = M_entrance_target + M_intrinsic_entrance_projectile;

		      for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < iM_intrinsic_projectile_number ; iM_intrinsic_projectile++)
			{
			  const double M_intrinsic_projectile = iM_intrinsic_projectile - J_intrinsic_projectile;

			  for (int iM_target = 0 ; iM_target < M_target_number ; iM_target++)
			    {
			      const double M_target = iM_target - J_target;

			      const int MLCM_projectile = make_int (M_A - M_target - M_intrinsic_projectile);

			      const double MJ_projectile = M_intrinsic_projectile + MLCM_projectile;

			      const complex<double> exp_I_MLCM_projectile_phi_left  = exp ( I*MLCM_projectile*M_PI_2);
			      const complex<double> exp_I_MLCM_projectile_phi_right = exp (-I*MLCM_projectile*M_PI_2);

			      for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
				{
				  const unsigned int BP_A =  BP_A_tab(iJPi_A);

				  const unsigned int vector_index_A = vector_index_A_tab(iJPi_A);

				  const double J_A = J_A_tab(iJPi_A);

				  const unsigned int N_channels_per_target_projectile = N_channels_per_target_projectile_tab(iT , iJPi_A);

				  const unsigned int N_channels_JPi_A = N_channels_tab(iJPi_A);

				  class array<class CC_channel_class> channels_JPi_A_tab (N_channels_JPi_A);

				  JPi_channels_tab_BP_J_vector_index_fill (S , channels_tab , BP_A , J_A , vector_index_A , channels_JPi_A_tab);

				  if (make_int (J_A - abs (M_A)) >= 0)
				    {
				      const unsigned int N_entrance_channels = N_entrance_channels_tab(iJPi_A);

				      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
					{
					  const unsigned int ic_JPi_A_entrance = entrance_JPi_channels_indices(iJPi_A , i_entrance);

					  const class CC_channel_class &entrance_channel = channels_JPi_A_tab(ic_JPi_A_entrance);

					  const int LCM_entrance_projectile = entrance_channel.get_LCM_projectile ();

					  const double J_entrance_projectile = entrance_channel.get_J_projectile ();

					  const double J_intrinsic_entrance_projectile = entrance_channel.get_J_intrinsic_projectile ();

					  const complex<double> sigma_LCM_entrance_projectile = sigma_l_calc (LCM_entrance_projectile , eta_entrance_channel);
					  // Sum over LCM_entrance_projectile and J_entrance_proj

					  class array<complex<double> > Y_LCM_MLCM_CGs_sum       (N_theta);
					  class array<complex<double> > Y_LCM_MLCM_CGs_sum_left  (N_theta);
					  class array<complex<double> > Y_LCM_MLCM_CGs_sum_right (N_theta);

					  Y_LCM_MLCM_CGs_sum       = 0.0;
					  Y_LCM_MLCM_CGs_sum_left  = 0.0;
					  Y_LCM_MLCM_CGs_sum_right = 0.0;

					  for (unsigned int ic_target_projectile = 0 ; ic_target_projectile < N_channels_per_target_projectile ; ic_target_projectile++)
					    {
					      const unsigned int ic_JPi_A = JPi_channels_indices_per_target_projectile(iT , iJPi_A , ic_target_projectile);

					      const class CC_channel_class &channel = channels_JPi_A_tab(ic_JPi_A);

					      const int LCM_projectile = channel.get_LCM_projectile ();

					      const double J_projectile = channel.get_J_projectile ();

					      const complex<double> eta_projectile = channel.get_eta_projectile ();

					      if ((make_int (LCM_projectile - abs (MLCM_projectile)) >= 0) && (make_int (J_projectile - abs (MJ_projectile)) >= 0))
						{
						  const int LCM_projectile_difference = LCM_entrance_projectile - LCM_projectile;

						  const complex<double> sigma_LCM_projectile = sigma_l_calc (LCM_projectile , eta_projectile);

						  const complex<double> sum_sigmas = sigma_LCM_projectile + sigma_LCM_entrance_projectile;

						  const complex<double> exp_I_sum_sigmas = exp (I * sum_sigmas);

						  const complex<double> T_value = T_matrix_values(iJPi_A , i_entrance , ic_JPi_A , iE);

						  const double CG_CM_intrinsic_projectile = Clebsch_Gordan (LCM_projectile , MLCM_projectile , J_intrinsic_projectile , M_intrinsic_projectile , J_projectile , MJ_projectile);
						  
						  const double CG_target_projectile = Clebsch_Gordan (J_target , M_target , J_projectile , MJ_projectile , J_A , M_A);

						  const complex<double> Y_factor = pow (I , LCM_projectile_difference) * exp_I_sum_sigmas * CG_CM_intrinsic_projectile * CG_target_projectile * T_value;

						  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
						    {
						      const double theta_lab = theta_lab_tab(iT , i_theta);

						      const double cos_theta_lab = cos (theta_lab);

						      const double Y_theta_lab = spherical_harmonics::PYlm (LCM_projectile , MLCM_projectile , cos_theta_lab);

						      const complex<double> Y_theta_lab_left  = Y_theta_lab*exp_I_MLCM_projectile_phi_left;
						      const complex<double> Y_theta_lab_right = Y_theta_lab*exp_I_MLCM_projectile_phi_right;

						      Y_LCM_MLCM_CGs_sum(i_theta)       += Y_factor * Y_theta_lab;
						      Y_LCM_MLCM_CGs_sum_left(i_theta)  += Y_factor * Y_theta_lab_left;
						      Y_LCM_MLCM_CGs_sum_right(i_theta) += Y_factor * Y_theta_lab_right;
						    }
						}
					    }

					  /* Sum over le , je and J_A */
					  const double CG_CM_intrinsic_entrance_projectile = Clebsch_Gordan (LCM_entrance_projectile , 0.0 , 
													     J_intrinsic_entrance_projectile , M_intrinsic_entrance_projectile , 
													     J_entrance_projectile , M_intrinsic_entrance_projectile);
					  
					  const double CG_entrance_target_projectile = Clebsch_Gordan (J_entrance_target , M_entrance_target , J_entrance_projectile , M_intrinsic_entrance_projectile , J_A , M_A);

					  const complex<double> l_factor = sqrt (4.0 * M_PI * (2.0 * LCM_entrance_projectile + 1.0));

					  const complex<double> A_factor_0 = l_factor * CG_CM_intrinsic_entrance_projectile * CG_entrance_target_projectile;

					  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
					    {
					      F_tab      (iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta) += A_factor_0 * Y_LCM_MLCM_CGs_sum      (i_theta)/k_entrance_channel;
					      F_tab_left (iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta) += A_factor_0 * Y_LCM_MLCM_CGs_sum_left (i_theta)/k_entrance_channel;
					      F_tab_right(iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta) += A_factor_0 * Y_LCM_MLCM_CGs_sum_right(i_theta)/k_entrance_channel;
					    }
					}}}}}}}}}}
}






double CC_scattering_cross_section::k_spin_factor_ratios_calc (
							       const class input_data_str &input_data_CC_Berggren , 
							       const class CC_target_projectile_composite_data &Tpc_data ,
							       const complex<double> &k_entrance_channel ,
							       const enum particle_type projectile ,
							       const complex<double> &k_channel)
{
  const enum interaction_type inter = input_data_CC_Berggren.get_inter ();
  
  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_entrance_target = J_target_tab(iT_entrance);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const double spin_averaging_factor = 1.0/((2.0 * J_intrinsic_entrance_projectile + 1.0) * (2.0 * J_entrance_target + 1.0));

  const int Z = Tpc_data.get_Z ();
  const int N = Tpc_data.get_N ();

  const int Z_entrance_projectile = Z_cluster_determine (entrance_projectile);
  const int N_entrance_projectile = N_cluster_determine (entrance_projectile);

  const int Z_projectile = Z_cluster_determine (projectile);
  const int N_projectile = N_cluster_determine (projectile);

  const int Z_entrance_target = Z - Z_entrance_projectile;
  const int N_entrance_target = N - N_entrance_projectile;

  const int Z_target = Z - Z_projectile;
  const int N_target = N - N_projectile;

  const unsigned int prot_index = charge_baryon_index_determine (PROTON);
  const unsigned int neut_index = charge_baryon_index_determine (NEUTRON);
      
  const class array<double> &effective_masses_for_calc_p = input_data_CC_Berggren.get_effective_masses_for_calc_p ();
  const class array<double> &effective_masses_for_calc_n = input_data_CC_Berggren.get_effective_masses_for_calc_n ();
      
  const double prot_mass_for_calc = effective_masses_for_calc_p(prot_index);  
  const double neut_mass_for_calc = effective_masses_for_calc_n(neut_index);

  const double frozen_core_mass = input_data_CC_Berggren.get_frozen_core_mass ();
  
  const double mass_target = Tpc_data.get_mass_target ();

  const int S_projectile = particle_strangeness_determine (projectile);
  
  const int Y_charge = (S_projectile > 0) ? (particle_charge_determine (projectile)) : (NADA);

  const bool is_Y_charged = (S_projectile > 0) ? (Y_charge != 0) : (false);
  
  const unsigned int Y_index = (S_projectile > 0) ? (charge_baryon_index_determine (projectile)) : (0);

  const double Y_mass_for_calc = (is_Y_charged) ? (effective_masses_for_calc_p(Y_index)) : (effective_masses_for_calc_n(Y_index));
	  
  const double mass_projectile = mass_cluster_determine (projectile , prot_mass_for_calc , neut_mass_for_calc , Y_mass_for_calc); 

  const double kinetic_factor_entrance_projectile_work_frame = Tpc_data.get_kinetic_factor_entrance_projectile_work_frame ();

  const double kinetic_factor_projectile_work_frame = (inter == REALISTIC_INTERACTION) ? (kinetic_factor_calc (false , mass_target , mass_projectile)) : (kinetic_factor_calc (false , frozen_core_mass , mass_projectile));

  double k_spin_factor_ratios = spin_averaging_factor * real_dc (k_channel) / real_dc (k_entrance_channel) * kinetic_factor_entrance_projectile_work_frame / kinetic_factor_projectile_work_frame;
  
  if (Z_entrance_projectile > Z_projectile)
    {
      for (int i = Z_entrance_projectile ; i > Z_projectile ; i--) k_spin_factor_ratios *= i;

      for (int i = Z_target ; i > Z_entrance_target ; i--) k_spin_factor_ratios /= i;
    }
  else
    {
      for (int i = Z_entrance_target ; i > Z_target ; i--) k_spin_factor_ratios *= i;

      for (int i = Z_projectile ; i > Z_entrance_projectile ; i--) k_spin_factor_ratios /= i;
    }
  
  if (N_entrance_projectile > N_projectile)
    {
      for (int i = N_entrance_projectile ; i > N_projectile ; i--) k_spin_factor_ratios *= i;

      for (int i = N_target ; i > N_entrance_target ; i--) k_spin_factor_ratios /= i;
    }
  else
    {
      for (int i = N_entrance_target ; i > N_target ; i--) k_spin_factor_ratios *= i;

      for (int i = N_projectile ; i > N_entrance_projectile ; i--) k_spin_factor_ratios /= i;
    }
  
  return k_spin_factor_ratios;
}











void CC_scattering_cross_section::differential_cross_section_lab_tab_calc (
									   const class input_data_str &input_data_CC_Berggren , 
									   const class CC_target_projectile_composite_data &Tpc_data , 
									   const class array<complex<double> > &F_tab , 
									   const unsigned int iE , 
									   class array<double> &differential_cross_section_lab_tab)
{
  const unsigned int N_target_projectile_states = differential_cross_section_lab_tab.dimension (0);

  const unsigned int N_theta = differential_cross_section_lab_tab.dimension (1);

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<complex<double> > &k_channels_tab = Tpc_data.get_k_channels_tab ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_entrance_target = J_target_tab(iT_entrance);

  const int M_entrance_target_number = make_int (2.0 * J_entrance_target + 1.0);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const int M_intrinsic_entrance_projectile_number = make_int (2.0 * J_intrinsic_entrance_projectile + 1.0);

  const complex<double> k_entrance_channel = k_channels_tab(iT_entrance , iE);

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  differential_cross_section_lab_tab = 0.0;

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const complex<double> k_channel = k_channels_tab(iT , iE);

	  const enum particle_type projectile = projectile_tab(iT);

	  const double k_spin_factor_ratios = k_spin_factor_ratios_calc (input_data_CC_Berggren , Tpc_data , k_entrance_channel , projectile , k_channel);

	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  const double J_target = J_target_tab(iT);

	  const int M_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

	  const double M_target_number = make_int (2.0 * J_target + 1.0);

	  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++) 
	    {
	      double sum_f_theta_square = 0.0;

	      for (int iM_intrinsic_entrance_projectile = 0 ; iM_intrinsic_entrance_projectile < M_intrinsic_entrance_projectile_number ; iM_intrinsic_entrance_projectile++) 
		for (int iM_entrance_target = 0 ; iM_entrance_target < M_entrance_target_number ; iM_entrance_target++) 
		  for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < M_intrinsic_projectile_number ; iM_intrinsic_projectile++)
		    for (int iM_target = 0 ; iM_target < M_target_number ; iM_target++)
		      sum_f_theta_square += norm (F_tab(iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta));

	      differential_cross_section_lab_tab(iT , i_theta) = k_spin_factor_ratios * sum_f_theta_square;
	    }
	}
    }
}







void CC_scattering_cross_section::analyzing_power_tab_calc (
							    const class CC_target_projectile_composite_data &Tpc_data , 
							    const class array<complex<double> > &F_tab_left , 
							    const class array<complex<double> > &F_tab_right , 
							    class array<double> &analyzing_power_lab_tab)
{
  analyzing_power_lab_tab = 0.0;

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const unsigned int N_target_projectile_states = analyzing_power_lab_tab.dimension (0);

  const unsigned int N_theta = analyzing_power_lab_tab.dimension (1);

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const double J_entrance_target = J_target_tab(iT_entrance);

  const int M_entrance_target_number = make_int (2.0 * J_entrance_target + 1.0);

  const int M_intrinsic_entrance_projectile_number = make_int (2.0 * J_intrinsic_entrance_projectile + 1.0);

  const double analyzing_power_factor = (J_intrinsic_entrance_projectile + 1.0)/(3.0*J_intrinsic_entrance_projectile);

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const enum particle_type projectile = projectile_tab(iT);

	  const double J_intrinsic_projectile = J_intrinsic_cluster_determine (projectile);

	  const double J_target = J_target_tab(iT);

	  const int M_intrinsic_projectile_number = make_int (2.0*J_intrinsic_projectile + 1.0);

	  const int M_target_number = make_int (2.0 * J_target + 1.0);

	  for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++) 
	    {
	      double sum_f_theta_square_left  = 0.0;
	      double sum_f_theta_square_right = 0.0;

	      for (int iM_entrance_target = 0 ; iM_entrance_target < M_entrance_target_number ; iM_entrance_target++) 
		for (int iM_target = 0 ; iM_target < M_target_number ; iM_target++)
		  for (int iM_intrinsic_projectile = 0 ; iM_intrinsic_projectile < M_intrinsic_projectile_number ; iM_intrinsic_projectile++)
		    {
		      complex<double> entrance_projectile_F_amplitude_sum_left  = 0.0;
		      complex<double> entrance_projectile_F_amplitude_sum_right = 0.0;

		      for (int iM_intrinsic_entrance_projectile = 0 ; iM_intrinsic_entrance_projectile < M_intrinsic_entrance_projectile_number ; iM_intrinsic_entrance_projectile++)
			{
			  entrance_projectile_F_amplitude_sum_left  += F_tab_left (iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta);
			  entrance_projectile_F_amplitude_sum_right += F_tab_right(iT , iM_intrinsic_entrance_projectile , iM_entrance_target , iM_intrinsic_projectile , iM_target , i_theta);
			}

		      sum_f_theta_square_left  += norm (entrance_projectile_F_amplitude_sum_left);
		      sum_f_theta_square_right += norm (entrance_projectile_F_amplitude_sum_right);
		    }
		
	      analyzing_power_lab_tab(iT , i_theta) = analyzing_power_factor * (sum_f_theta_square_right - sum_f_theta_square_left) / (sum_f_theta_square_left + sum_f_theta_square_right);
	    }
	}
    }
}







void CC_scattering_cross_section::differential_cross_section_lab_to_CM_tab_calc (
										 const class CC_target_projectile_composite_data &Tpc_data , 
										 const double K_CM , 
										 const class array<double> &tau_tab , 
										 const class array<double> &theta_CM_tab , 
										 const class array<double> &differential_cross_section_lab_tab , 
										 class array<double> &differential_cross_section_CM_tab)
{	
  const unsigned int N_target_projectile_states = differential_cross_section_CM_tab.dimension (0);

  const unsigned int N_theta = differential_cross_section_CM_tab.dimension (1);

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<TYPE > &E_target_tab = Tpc_data.get_E_target_tab ();

  const TYPE E_entrance_target = E_target_tab(iT_entrance);

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  differential_cross_section_CM_tab = 0.0;

  for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
    {
      if (is_it_pole_target_tab(iT))
	{
	  const TYPE E_target = E_target_tab(iT);

	  const double Q = real_dc (E_entrance_target - E_target);

	  if ((K_CM + Q) >= 0.0)
	    {
	      const double tau = tau_tab(iT);

	      for (unsigned int i_theta = 0 ; i_theta < N_theta ; i_theta++)
		{
		  const double theta_CM = theta_CM_tab(i_theta);

		  const double cos_theta_CM = cos (theta_CM);		  

		  if ((abs (tau - 1.0) > precision) || (abs (cos_theta_CM + tau) > precision))
		    {	  
		      const double CM_angle_factor = 1 + 2.0 * tau * cos_theta_CM + tau * tau;

		      const double numerator = sqrt (CM_angle_factor) * CM_angle_factor;

		      const double denominator = abs (1.0 + tau * cos_theta_CM);

		      const double Jacobian_theta_CM = numerator / denominator;

		      differential_cross_section_CM_tab(iT , i_theta) = differential_cross_section_lab_tab(iT , i_theta) / Jacobian_theta_CM;
		    }
		  else
		    differential_cross_section_CM_tab(iT , i_theta) = differential_cross_section_lab_tab(iT , i_theta) / 0.002;
		}
	    }
	}
    }
}














// Excitation function here

void CC_scattering_cross_section::cross_section_analyzing_power_calc (
								      const class input_data_str &input_data_CC_Berggren , 
								      const class CC_target_projectile_composite_data &Tpc_data , 
								      const class array<complex<double> > &T_matrix_values , 
								      class array<double> &differential_cross_section_Coulomb_CM_vs_energy_tab , 
								      class array<double> &differential_cross_section_CM_vs_energy_tab , 
								      class array<double> &differential_cross_section_Coulomb_lab_vs_energy_tab , 
								      class array<double> &differential_cross_section_lab_vs_energy_tab , 
								      class array<double> &analyzing_power_vs_energy_tab)
{
  const bool print_detailed_information = input_data_CC_Berggren.get_print_detailed_information ();

  const double CM_to_work_frame_kinetic_factor = Tpc_data.get_CM_to_work_frame_kinetic_factor ();

  const class array<double> &E_total_tab = Tpc_data.get_E_total_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const class array<complex<double> > &k_channels_tab = Tpc_data.get_k_channels_tab ();

  const class array<complex<double> > &e_channels_tab = Tpc_data.get_e_channels_tab ();

  const class array<complex<double> > &eta_channels_tab = Tpc_data.get_eta_channels_tab ();

  const unsigned int N_channels = channels_tab.dimension (0);

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const unsigned int N_CM_angles = Tpc_data.get_N_CM_angles ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const class array<double> &J_target_tab = Tpc_data.get_J_target_tab ();

  const double J_entrance_target = J_target_tab(iT_entrance);

  const int M_entrance_target_number = make_int (2.0 * J_entrance_target + 1.0);

  const double JT_max = JT_max_determine (channels_tab);

  const int M_target_number_max = make_int (2.0 * JT_max + 1.0);

  const class array<enum particle_type> &projectile_tab = Tpc_data.get_projectile_tab ();

  const enum particle_type entrance_projectile = projectile_tab(iT_entrance);

  const double J_intrinsic_entrance_projectile = J_intrinsic_cluster_determine (entrance_projectile);

  const int M_intrinsic_entrance_projectile_number = make_int (2.0 * J_intrinsic_entrance_projectile + 1.0);

  const double J_intrinsic_projectile_max = Tpc_data.get_J_intrinsic_projectile_max ();

  const int M_intrinsic_projectile_max_number = make_int (2.0 * J_intrinsic_projectile_max + 1.0);

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  const class array<double> &CM_angles = Tpc_data.get_CM_angles ();

  class array<double> tau_tab(N_target_projectile_states);
    
  class array<double> theta_lab_tab(N_target_projectile_states , N_CM_angles);
  
  class array<complex<double> > F_Coulomb_entrance_target_tab(N_target_projectile_states , N_CM_angles);
      
  class array<complex<double> > F_Coulomb_tab(N_target_projectile_states , M_intrinsic_entrance_projectile_number , M_entrance_target_number , M_intrinsic_projectile_max_number , M_target_number_max , N_CM_angles);
  class array<complex<double> > F_tab        (N_target_projectile_states , M_intrinsic_entrance_projectile_number , M_entrance_target_number , M_intrinsic_projectile_max_number , M_target_number_max , N_CM_angles);
  class array<complex<double> > F_tab_left   (N_target_projectile_states , M_intrinsic_entrance_projectile_number , M_entrance_target_number , M_intrinsic_projectile_max_number , M_target_number_max , N_CM_angles);
  class array<complex<double> > F_tab_right  (N_target_projectile_states , M_intrinsic_entrance_projectile_number , M_entrance_target_number , M_intrinsic_projectile_max_number , M_target_number_max , N_CM_angles);
      
  class array<double> differential_cross_section_Coulomb_lab_tab                   (N_target_projectile_states , N_CM_angles);
  class array<double> differential_cross_section_Coulomb_CM_tab                    (N_target_projectile_states , N_CM_angles);
      
  class array<double> differential_cross_section_lab_tab                   (N_target_projectile_states , N_CM_angles);
  class array<double> differential_cross_section_CM_tab                    (N_target_projectile_states , N_CM_angles);
      
  class array<double> analyzing_power_tab(N_target_projectile_states , N_CM_angles);

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "Analyzing power formula correct if the incident beam has polarization k <= 1" << endl << endl;
      
  for (unsigned int iE = 0 ; iE < N_energies ; iE++) 
    {
      const complex<double> k_entrance_channel = k_channels_tab(iT_entrance , iE);

      const complex<double> e_entrance_channel = e_channels_tab(iT_entrance , iE);

      const complex<double> eta_entrance_channel = eta_channels_tab(iT_entrance , iE);

      const double K_CM = real_dc (e_entrance_channel)/CM_to_work_frame_kinetic_factor;

      const double E = E_total_tab(iE);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) channels_tab(ic).E_dependent_values_change (E);

      tau_tab_calc (print_detailed_information , K_CM , Tpc_data , tau_tab);

      theta_lab_tab_calc (is_it_pole_target_tab , tau_tab , CM_angles , theta_lab_tab);

      F_Coulomb_entrance_target_tab = 0.0;

      F_Coulomb_entrance_target_tab_calc (k_entrance_channel , eta_entrance_channel , is_it_pole_target_tab , theta_lab_tab , F_Coulomb_entrance_target_tab);

      F_Coulomb_tab = 0.0;

      F_tab_Coulomb_part_calc (Tpc_data , F_Coulomb_entrance_target_tab , F_Coulomb_tab);


      F_tab       = F_Coulomb_tab;
      F_tab_left  = F_Coulomb_tab;
      F_tab_right = F_Coulomb_tab;

      F_tab_nuclear_part_calc (Tpc_data , theta_lab_tab , T_matrix_values , iE , K_CM , F_tab , F_tab_left , F_tab_right);
      
      differential_cross_section_lab_tab_calc (input_data_CC_Berggren , Tpc_data , F_Coulomb_tab , iE , differential_cross_section_Coulomb_lab_tab);
      differential_cross_section_lab_tab_calc (input_data_CC_Berggren , Tpc_data , F_tab         , iE , differential_cross_section_lab_tab);
      
      differential_cross_section_lab_to_CM_tab_calc (Tpc_data , K_CM , tau_tab , CM_angles , differential_cross_section_Coulomb_lab_tab , differential_cross_section_Coulomb_CM_tab);
      differential_cross_section_lab_to_CM_tab_calc (Tpc_data , K_CM , tau_tab , CM_angles , differential_cross_section_lab_tab         , differential_cross_section_CM_tab);
      
      analyzing_power_tab_calc (Tpc_data , F_tab_left , F_tab_right , analyzing_power_tab);

      for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
	{
	  if (is_it_pole_target_tab(iT))
	    {
	      for (unsigned int i_theta = 0 ; i_theta < N_CM_angles ; i_theta++)
		{
		  differential_cross_section_Coulomb_CM_vs_energy_tab (iT , i_theta , iE) = differential_cross_section_Coulomb_CM_tab (iT , i_theta);
		  differential_cross_section_Coulomb_lab_vs_energy_tab(iT , i_theta , iE) = differential_cross_section_Coulomb_lab_tab(iT , i_theta);
		  
		  differential_cross_section_CM_vs_energy_tab (iT , i_theta , iE) = differential_cross_section_CM_tab (iT , i_theta);		  
		  differential_cross_section_lab_vs_energy_tab(iT , i_theta , iE) = differential_cross_section_lab_tab(iT , i_theta);
		  
		  analyzing_power_vs_energy_tab(iT , i_theta , iE) = analyzing_power_tab(iT , i_theta);
		}
	    }
	}
    }
}










void CC_scattering_cross_section::cross_section_analyzing_power_print (
								       const bool print_detailed_information ,
								       const class CC_target_projectile_composite_data &Tpc_data , 
								       const class array<double> &differential_cross_section_Coulomb_CM_vs_energy_tab , 
								       const class array<double> &differential_cross_section_CM_vs_energy_tab , 
								       const class array<double> &differential_cross_section_Coulomb_lab_vs_energy_tab , 
								       const class array<double> &differential_cross_section_lab_vs_energy_tab , 
								       const class array<double> &analyzing_power_vs_energy_tab)
{  
  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();
    
  const bool is_differential_cross_section_calculated = (CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION);

  const bool is_excitation_function_calculated = (CC_reaction_calculation == EXCITATION_FUNCTION);

  const unsigned int N_CM_angles = Tpc_data.get_N_CM_angles ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const unsigned int iT_entrance = Tpc_data.get_entrance_target_index ();

  const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

  const double CM_to_work_frame_kinetic_factor = Tpc_data.get_CM_to_work_frame_kinetic_factor ();

  const double radians_to_degrees_factor = 180.0/M_PI;

  const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

  const class array<double> &CM_angles = Tpc_data.get_CM_angles ();

  const class array<complex<double> > &e_channels_tab = Tpc_data.get_e_channels_tab ();

  if (is_differential_cross_section_calculated)
    {
      const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

      const complex<double> e_entrance_channel = e_channels_tab(iT_entrance , 0);

      const double K_CM = real_dc (e_entrance_channel)/CM_to_work_frame_kinetic_factor;

      class array<double> tau_tab(N_target_projectile_states);
    
      class array<double> theta_lab_tab(N_target_projectile_states , N_CM_angles);
  
      tau_tab_calc (print_detailed_information , K_CM , Tpc_data , tau_tab);
 
      theta_lab_tab_calc (is_it_pole_target_tab , tau_tab , CM_angles , theta_lab_tab);

      for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
	{
	  const string iT_entrance_iT_str_dat = make_string<unsigned int> (iT_entrance) + "_" + make_string<unsigned int> (iT) + ".dat";
	  
	  const string differential_cross_section_CM_file_name  = "scattering_differential_cross_section_CM_"  + iT_entrance_iT_str_dat;	  
	  const string differential_cross_section_lab_file_name = "scattering_differential_cross_section_lab_" + iT_entrance_iT_str_dat;	  
	  
	  const string analyzing_power_file_file_name = "analyzing_power_" + iT_entrance_iT_str_dat;
	  
	  ofstream differential_cross_section_CM_file(differential_cross_section_CM_file_name.c_str ());
	  ofstream differential_cross_section_lab_file(differential_cross_section_lab_file_name.c_str ());

	  ofstream analyzing_power_file(analyzing_power_file_file_name.c_str ());
      
	  differential_cross_section_CM_file.precision (15);
	  differential_cross_section_lab_file.precision (15);
      
	  analyzing_power_file.precision (15);

	  for (unsigned int i_theta = 0 ; i_theta < N_CM_angles ; i_theta++)
	    {
	      const double theta_CM_deg = CM_angles(i_theta)*radians_to_degrees_factor;

	      const double theta_lab_deg = theta_lab_tab(iT , i_theta)*radians_to_degrees_factor;
	      
	      const double differential_cross_section_Coulomb_in_CM = 10.0*differential_cross_section_Coulomb_CM_vs_energy_tab(iT , i_theta , 0);
	      const double differential_cross_section_in_CM         = 10.0*differential_cross_section_CM_vs_energy_tab        (iT , i_theta , 0);

	      const bool are_differential_cross_sections_non_zero_CM = ((differential_cross_section_Coulomb_in_CM != 0.0) && (differential_cross_section_in_CM != 0.0));

	      const double differential_cross_section_ratio_in_CM = (are_differential_cross_sections_non_zero_CM) ? (differential_cross_section_in_CM/differential_cross_section_Coulomb_in_CM) : (1.0);

	      const double differential_cross_section_Coulomb_in_lab = 10.0*differential_cross_section_Coulomb_lab_vs_energy_tab(iT , i_theta , 0);
	      const double differential_cross_section_in_lab         = 10.0*differential_cross_section_lab_vs_energy_tab        (iT , i_theta , 0);

	      const bool are_differential_cross_sections_non_zero_lab = ((differential_cross_section_Coulomb_in_lab != 0.0) && (differential_cross_section_in_lab != 0.0));

	      const double differential_cross_section_ratio_in_lab = (are_differential_cross_sections_non_zero_lab) ? (differential_cross_section_in_lab/differential_cross_section_Coulomb_in_lab) : (1.0);
	      
	      differential_cross_section_CM_file  << theta_CM_deg  << " " << differential_cross_section_in_CM  << " " << differential_cross_section_Coulomb_in_CM  << " " << differential_cross_section_ratio_in_CM  << endl;	      
	      differential_cross_section_lab_file << theta_lab_deg << " " << differential_cross_section_in_lab << " " << differential_cross_section_Coulomb_in_lab << " " << differential_cross_section_ratio_in_lab << endl;

	      const double analyzing_power_in_CM = analyzing_power_vs_energy_tab(iT , i_theta , 0);

	      analyzing_power_file << theta_CM_deg << " " << analyzing_power_in_CM << endl;
	    }
	}
    }

  if (is_excitation_function_calculated)
    {	
      const class array<bool> &is_it_pole_target_tab = Tpc_data.get_is_it_pole_target_tab ();

      const class array<double> &E_kinetic_total_system_CM_tab  = Tpc_data.get_E_kinetic_total_system_CM_tab ();
      
      const class array<double> &E_kinetic_projectile_lab_tab                = Tpc_data.get_E_kinetic_projectile_lab_tab ();
      const class array<double> &E_kinetic_target_lab_inverse_kinematics_tab = Tpc_data.get_E_kinetic_target_lab_inverse_kinematics_tab ();

      const complex<double> e_entrance_channel = e_channels_tab(iT_entrance , 0);
	      
      const double K_CM = real_dc (e_entrance_channel)/CM_to_work_frame_kinetic_factor;
	      
      class array<double> tau_tab(N_target_projectile_states);
    
      class array<double> theta_lab_tab(N_target_projectile_states , N_CM_angles);
  
      tau_tab_calc (print_detailed_information , K_CM , Tpc_data , tau_tab);

      theta_lab_tab_calc (is_it_pole_target_tab , tau_tab , CM_angles , theta_lab_tab);

      for (unsigned int iT = 0 ; iT < N_target_projectile_states ; iT++)
	{
	  if (is_it_pole_target_tab(iT))
	    {      	  
	      for (unsigned int i_theta = 0 ; i_theta < N_CM_angles ; i_theta++) 
		{
		  const string iT_entrance_iT_i_theta_str_dat = make_string<unsigned int> (iT_entrance) + "_" + make_string<unsigned int> (iT) + "_" + make_string<unsigned int> (i_theta) + ".dat";
	      
		  const double theta_CM_deg = CM_angles(i_theta)*radians_to_degrees_factor;

		  const double theta_lab_deg = theta_lab_tab(iT , i_theta)*radians_to_degrees_factor;
	      
		  const string excitation_function_file_CM_file_name  = "scattering_excitation_function_CM_"  + iT_entrance_iT_i_theta_str_dat;	  
		  const string excitation_function_file_lab_file_name = "scattering_excitation_function_lab_" + iT_entrance_iT_i_theta_str_dat;

		  ofstream excitation_function_file_CM(excitation_function_file_CM_file_name.c_str ());
		  ofstream excitation_function_file_lab(excitation_function_file_lab_file_name.c_str ());

		  excitation_function_file_CM.precision (15);
		  excitation_function_file_lab.precision (15);
	      
		  for (unsigned int iE = 0; iE < N_energies; iE++) 
		    {
		      const double E_kinetic_total_system_CM = E_kinetic_total_system_CM_tab(iE);
		      
		      const double E_kinetic_projectile_lab                = E_kinetic_projectile_lab_tab(iE);
		      const double E_kinetic_target_lab_inverse_kinematics = E_kinetic_target_lab_inverse_kinematics_tab(iE);

		      const double differential_cross_section_Coulomb_in_CM = 10.0*differential_cross_section_Coulomb_CM_vs_energy_tab(iT , i_theta , iE);
		      const double differential_cross_section_in_CM         = 10.0*differential_cross_section_CM_vs_energy_tab        (iT , i_theta , iE);
		      
		      const double differential_cross_section_Coulomb_in_lab = 10.0*differential_cross_section_Coulomb_lab_vs_energy_tab(iT , i_theta , iE);
		      const double differential_cross_section_in_lab         = 10.0*differential_cross_section_lab_vs_energy_tab        (iT , i_theta , iE);
		      
		      const double differential_cross_section_ratio_in_CM =
			((differential_cross_section_Coulomb_in_CM != 0.0) && (differential_cross_section_in_CM != 0.0))
			? (differential_cross_section_in_CM/differential_cross_section_Coulomb_in_CM)
			: (1.0);
		      
		      const double differential_cross_section_ratio_in_lab =
			((differential_cross_section_Coulomb_in_lab != 0.0) && (differential_cross_section_in_lab != 0.0))
			? (differential_cross_section_in_lab/differential_cross_section_Coulomb_in_lab)
			: (1.0);

		      excitation_function_file_CM << theta_CM_deg << " " << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab  << " " << E_kinetic_target_lab_inverse_kinematics << " "
						  << differential_cross_section_in_CM  << " "
						  << differential_cross_section_Coulomb_in_CM  << " "
						  << differential_cross_section_ratio_in_CM  << endl;
		      
		      excitation_function_file_lab << theta_lab_deg << " " << E_kinetic_projectile_lab  << " "
						   << differential_cross_section_in_lab << " "
						   << differential_cross_section_Coulomb_in_lab << " "
						   << differential_cross_section_ratio_in_lab << endl;
		    }
		}
	    }
	}
    }
}











void CC_scattering_cross_section::phase_shifts_print (
						      const class CC_target_projectile_composite_data &Tpc_data , 
						      const class array<double> &phase_shifts)
{
  const int S = Tpc_data.get_S ();
  
  const unsigned int N_JPi_A = Tpc_data.get_N_JPi_A ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  const class array<unsigned int> &entrance_JPi_channels_indices = Tpc_data.get_entrance_JPi_channels_indices ();
      
  const class array<double> &J_A_tab = Tpc_data.get_J_A_tab ();

  const class array<unsigned int> &BP_A_tab = Tpc_data.get_BP_A_tab ();

  const class array<unsigned int> &vector_index_A_tab = Tpc_data.get_vector_index_A_tab ();

  const class array<unsigned int> &N_channels_tab = Tpc_data.get_N_channels_tab ();

  const class array<unsigned int> &N_entrance_channels_tab = Tpc_data.get_N_entrance_channels_tab ();

  const class array<class CC_channel_class> &channels_tab = Tpc_data.get_channels_tab ();

  const class array<double> &E_kinetic_total_system_CM_tab  = Tpc_data.get_E_kinetic_total_system_CM_tab ();

  const class array<double> &E_kinetic_projectile_lab_tab                = Tpc_data.get_E_kinetic_projectile_lab_tab ();
  const class array<double> &E_kinetic_target_lab_inverse_kinematics_tab = Tpc_data.get_E_kinetic_target_lab_inverse_kinematics_tab ();

  for (unsigned int iJPi_A = 0 ; iJPi_A < N_JPi_A ; iJPi_A++)
    {
      const unsigned int N_channels_JPi_A = N_channels_tab(iJPi_A);

      const unsigned int N_entrance_channels = N_entrance_channels_tab(iJPi_A);

      const unsigned int BP_A = BP_A_tab(iJPi_A);

      const unsigned int vector_index_A = vector_index_A_tab(iJPi_A);

      const double J_A = J_A_tab(iJPi_A);

      /* Tab of all channel - channels for the given composite state */

      class array<class CC_channel_class> channels_JPi_A_tab (N_channels_JPi_A);

      JPi_channels_tab_BP_J_vector_index_E_fill (S , channels_tab , BP_A , J_A , vector_index_A , NADA , channels_JPi_A_tab);

      for (unsigned int i_entrance = 0 ; i_entrance < N_entrance_channels ; i_entrance++)
	{	     
	  const unsigned int ic_JPi_A_entrance = entrance_JPi_channels_indices(iJPi_A , i_entrance); 

	  const class CC_channel_class &entrance_channel = channels_JPi_A_tab(ic_JPi_A_entrance);

	  for (unsigned int ic_JPi_A = 0 ; ic_JPi_A < N_channels_JPi_A ; ic_JPi_A++)
	    {
	      const class CC_channel_class &channel_c = channels_JPi_A_tab(ic_JPi_A);

	      /*
		For deuteron only

		const int LCM_c = channel_c.get_LCM_projectile ();
		
		const int Jc = make_int (channel_c.get_J ());
	      */

	      const string file_name  = "Phase_shifts___in_" + entrance_channel.channel_string_for_file_name () + "___out_" + channel_c.channel_string_for_file_name () + ".dat";
	      
	      ofstream phase_shifts_file(file_name.c_str ());
	      
	      phase_shifts_file.precision (15);	      

	      for (unsigned int iE = 0 ; iE < N_energies ; iE++) 
		{
		  const double E_kinetic_total_system_CM  = E_kinetic_total_system_CM_tab(iE);
		  
		  const double E_kinetic_projectile_lab                = E_kinetic_projectile_lab_tab(iE);
		  const double E_kinetic_target_lab_inverse_kinematics = E_kinetic_target_lab_inverse_kinematics_tab(iE);

		  const double phase_shift = phase_shifts(iJPi_A , i_entrance , ic_JPi_A , iE);

		  /*
		    For deuteron only

		    if ((LCM_c == 0) && (Jc == 1))
		    {
		    const double phase_shift_corrected_for_modulo_180_degrees = (phase_shift > 0.0) ? (phase_shift - 180.0) : (phase_shift);

		    phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift_corrected_for_modulo_180_degrees << endl;

		    } 

		    if ((LCM_c == 1) && (Jc == 0))
		    {
		    const double phase_shift_corrected_for_modulo_180_degrees = ((phase_shift > 0.0) && (E_kinetic_projectile < 5.0)) ? (phase_shift - 180.0) : (phase_shift);

		    phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift_corrected_for_modulo_180_degrees << endl;
		    } 

		    if ((LCM_c == 2) && (Jc == 1))
		    {
		    const double phase_shift_corrected_for_modulo_180_degrees = ((phase_shift < -0.1) && (E_kinetic_projectile > 6)) ? (phase_shift + 180.0) : (phase_shift);
		      
		    phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift_corrected_for_modulo_180_degrees << endl;
		    }

		    if ((LCM_c == 2) && (Jc == 2))
		    {
		    const double phase_shift_corrected_for_modulo_180_degrees = ((phase_shift < -0.1) && (E_kinetic_projectile > 3.0)) ? (phase_shift + 180.0) : (phase_shift);

		    phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift_corrected_for_modulo_180_degrees << endl;
		    }
		  
		    if ((LCM_c == 2) && (Jc == 3))
		    {
		    const double phase_shift_corrected_for_modulo_180_degrees = (E_kinetic_projectile > 0.581) ? (phase_shift + 180.0) : (phase_shift);

		    phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift_corrected_for_modulo_180_degrees << endl;
		    }
		  */
		  
		  phase_shifts_file << E_kinetic_total_system_CM << " " << E_kinetic_projectile_lab << " " << E_kinetic_target_lab_inverse_kinematics << " " << phase_shift << endl;
		}
	    }
	}
    }
}








void CC_scattering_cross_section::calc_print (
					      const class input_data_str &input_data_CC_Berggren , 
					      const class interaction_class &inter_data_basis , 
					      const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
					      const class HF_nucleons_data &neut_HF_data_CC_Berggren , 
					      class baryons_data &prot_Y_data_CC_Berggren , 
					      class baryons_data &neut_Y_data_CC_Berggren , 
					      class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
					      class baryons_data &prot_Y_data , 
					      class baryons_data &neut_Y_data , 
					      class array<class cluster_data> &cluster_projectile_data_tab , 
					      class CC_target_projectile_composite_data &Tpc_data , 
					      class TBMEs_class &TBMEs_pn , 
					      class TBMEs_class &TBMEs_cv)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Energies and scattering cross sections" << endl;
      cout <<         "--------------------------------------" << endl << endl;
    }

  const bool print_detailed_information = input_data_CC_Berggren.get_print_detailed_information ();
  
  const unsigned int N_JPi_A = Tpc_data.get_N_JPi_A ();

  const unsigned int N_entrance_channels_max = Tpc_data.get_N_entrance_channels_max ();

  const unsigned int N_channels = Tpc_data.get_N_channels ();

  const unsigned int N_energies = Tpc_data.get_N_energies ();

  class array<complex<double> > T_matrix_values(N_JPi_A , N_entrance_channels_max , N_channels , N_energies);

  T_matrix_values = 0.0;

  class array<double> phase_shifts(N_JPi_A , N_entrance_channels_max , N_channels , N_energies); 

  phase_shifts = 0.0;

  const enum CC_reaction_calculation_type CC_reaction_calculation = Tpc_data.get_CC_reaction_calculation ();

  // Coupled - channel calculations
  iterative_calc (input_data_CC_Berggren , inter_data_basis , prot_HF_data_CC_Berggren , neut_HF_data_CC_Berggren , Tpc_data , 
		  cluster_projectile_data_tab , cluster_projectile_data_CC_Berggren_tab , prot_Y_data_CC_Berggren , neut_Y_data_CC_Berggren , 
		  prot_Y_data , neut_Y_data , TBMEs_pn , TBMEs_cv , phase_shifts , T_matrix_values);

  const bool is_differential_cross_section_calculated = (CC_reaction_calculation == DIFFERENTIAL_CROSS_SECTION);

  const bool is_excitation_function_calculated = (CC_reaction_calculation == EXCITATION_FUNCTION);

  if (is_differential_cross_section_calculated || is_excitation_function_calculated)
    {
      const unsigned int N_target_projectile_states = Tpc_data.get_N_target_projectile_states ();

      const unsigned int N_CM_angles = Tpc_data.get_N_CM_angles ();

      const unsigned int N_energies = Tpc_data.get_N_energies ();

      class array<double> differential_cross_section_Coulomb_CM_vs_energy_tab (N_target_projectile_states , N_CM_angles , N_energies);
      class array<double> differential_cross_section_Coulomb_lab_vs_energy_tab(N_target_projectile_states , N_CM_angles , N_energies);
      
      class array<double> differential_cross_section_CM_vs_energy_tab (N_target_projectile_states , N_CM_angles , N_energies);
      class array<double> differential_cross_section_lab_vs_energy_tab(N_target_projectile_states , N_CM_angles , N_energies);

      class array<double> analyzing_power_vs_energy_tab (N_target_projectile_states , N_CM_angles , N_energies);

      cross_section_analyzing_power_calc (input_data_CC_Berggren , Tpc_data , T_matrix_values , 
					  differential_cross_section_Coulomb_CM_vs_energy_tab  , differential_cross_section_CM_vs_energy_tab , 
					  differential_cross_section_Coulomb_lab_vs_energy_tab , differential_cross_section_lab_vs_energy_tab ,
					  analyzing_power_vs_energy_tab);

      if (THIS_PROCESS == MASTER_PROCESS)
	cross_section_analyzing_power_print (print_detailed_information , Tpc_data , 
					     differential_cross_section_Coulomb_CM_vs_energy_tab  , differential_cross_section_CM_vs_energy_tab , 
					     differential_cross_section_Coulomb_lab_vs_energy_tab , differential_cross_section_lab_vs_energy_tab ,
					     analyzing_power_vs_energy_tab);
    }

  if ((THIS_PROCESS == MASTER_PROCESS) && (CC_reaction_calculation == PHASE_SHIFTS)) phase_shifts_print (Tpc_data , phase_shifts);
}



