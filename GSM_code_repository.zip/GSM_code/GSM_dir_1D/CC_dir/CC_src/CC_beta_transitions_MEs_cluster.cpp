#include "../CC_include/CC_include_def.h"


using namespace Wigner_signs;
using namespace beta_transitions_common;
using namespace angular_matrix_elements;
using namespace inputs_misc;

using namespace CC_beta_transitions_MEs::radial;



void CC_beta_transitions_MEs::cluster::beta_suboperator_intrinsic_NBME_calc (
									     const enum beta_pm_type beta_pm ,
									     const bool is_it_HO_expansion , 
									     const class interaction_class &inter_data_basis ,  
									     const enum radial_operator_type radial_operator ,
									     const enum beta_suboperator_type beta_suboperator ,
									     const class correlated_state_str &PSI_cluster_qn_c ,  
									     const class correlated_state_str &PSI_cluster_qn_cp ,
									     const class GSM_vector &PSI_cluster_cp ,
									     class array<TYPE> &beta_suboperator_intrinsic_NBMEs)
{
  const class GSM_vector_helper_class &PSI_helper_cp =  PSI_cluster_cp.get_GSM_vector_helper ();
  
  const class baryons_data &prot_Y_data = PSI_helper_cp.get_prot_Y_data ();
  const class baryons_data &neut_Y_data = PSI_helper_cp.get_neut_Y_data ();

  const class baryons_data &data_c  = data_in_determine  (beta_pm , prot_Y_data , neut_Y_data);
  const class baryons_data &data_cp = data_out_determine (beta_pm , prot_Y_data , neut_Y_data);
    
  const unsigned int N_nlj_c  = data_c.get_N_nlj_baryon ();
  const unsigned int N_nlj_cp = data_cp.get_N_nlj_baryon ();
  
  const unsigned int N_nljm_c  = data_c.get_N_nljm_baryon ();
  const unsigned int N_nljm_cp = data_cp.get_N_nljm_baryon ();
  
  const double Jc  = PSI_cluster_qn_c.get_J ();
  const double Jcp = PSI_cluster_qn_cp.get_J ();
  
  const double Mc  = Jc;
  const double Mcp = Jcp;
  
  const unsigned int BP_Op = BP_beta_suboperator_determine (beta_suboperator);

  const unsigned int BP_in  = PSI_cluster_qn_c.get_BP ();
  const unsigned int BP_out = PSI_cluster_qn_cp.get_BP ();
  
  if (binary_parity_product (BP_in , BP_Op) != BP_out) return;
  
  const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);
  
  const int rank_Op_projection = make_int (Mcp - Mc);

  const int Z_projectile_in = PSI_cluster_qn_c.get_Z ();
  const int N_projectile_in = PSI_cluster_qn_c.get_N ();
  
  const int Z_projectile_out = PSI_cluster_qn_cp.get_Z ();
  const int N_projectile_out = PSI_cluster_qn_cp.get_N ();

  if (Z_projectile_in != Z_IN_beta_determine (beta_pm , Z_projectile_out)) return;
  if (N_projectile_in != N_IN_beta_determine (beta_pm , N_projectile_out)) return;
  
  const double J_projectile_in = PSI_cluster_qn_c.get_J ();

  const double J_projectile_out = PSI_cluster_qn_cp.get_J ();
  
  if ((abs (make_int (J_projectile_out - J_projectile_in)) > rank_Op) || (make_int (J_projectile_out + J_projectile_in) < rank_Op)) return;
    
  const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);
	  
  class array<TYPE> OBMEs_reduced(N_nlj_c , N_nlj_cp);

  class array<TYPE> OBMEs(N_nljm_c , N_nljm_cp);

  beta_suboperator_OBMEs_reduced_calc (is_it_HO_expansion , radial_operator , beta_suboperator , inter_data_basis , data_c , data_cp , OBMEs_reduced);
  
  OBMEs_dereduced_calc<TYPE> (rank_Op , rank_Op_projection , data_c , data_cp , OBMEs_reduced , OBMEs);

  const TYPE beta_suboperator_intrinsic_NBME = beta_transitions_NBMEs::calc (beta_pm ,  beta_suboperator , OBMEs , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp);	
  
  beta_suboperator_intrinsic_NBMEs(beta_suboperator_index) = beta_suboperator_intrinsic_NBME;
}







//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_MEs::cluster::beta_suboperators_intrinsic_NBMEs_calc (
									       const enum beta_type beta , 
									       const enum beta_pm_type beta_pm ,
									       const bool is_it_HO_expansion , 
									       const class interaction_class &inter_data_basis , 
									       const class correlated_state_str &PSI_cluster_qn_c ,  
									       const class correlated_state_str &PSI_cluster_qn_cp ,
									       const class GSM_vector &PSI_cluster_cp ,
									       class array<TYPE> &beta_suboperator_intrinsic_NBMEs)
{
  switch (beta)
    {
    case ALLOWED:
      {
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , OVERLAP , FERMI_ALLOWED        , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , OVERLAP , GAMOW_TELLER_ALLOWED , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
      } break;
    
    case FIRST_FORBIDDEN:
      {
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD , W_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD , U_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD , Z_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD , X_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
      
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD_COULOMB , W_FFBD_COULOMB , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD_COULOMB , U_FFBD_COULOMB , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , FFBD_COULOMB , X_FFBD_COULOMB , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
      
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , REDUCED_GRADIENT , XI_PRIME_V_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
	beta_suboperator_intrinsic_NBME_calc (beta_pm , is_it_HO_expansion , inter_data_basis , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , PSI_cluster_qn_c , PSI_cluster_qn_cp , PSI_cluster_cp , beta_suboperator_intrinsic_NBMEs);
      } break;
    
    default: abort_all ();
    }
}









//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_MEs::cluster::beta_suboperator_NBME_calc (
								   const enum beta_type beta ,
								   const enum radial_operator_type radial_operator ,
								   const enum beta_suboperator_type beta_suboperator , 
								   const class CC_target_projectile_composite_data &Tp_data,
								   const unsigned int ic ,
								   const unsigned int icp ,							
								   const class correlated_state_str &PSI_cluster_qn_c ,  
								   const class correlated_state_str &PSI_cluster_qn_cp ,
								   const class CC_state_class &CC_state_in , 
								   const class CC_state_class &CC_state_out , 
								   const unsigned int ic_in , 
								   const unsigned int ic_out,
								   class array<TYPE> &beta_suboperator_tab)
{
  const unsigned int BP_Op = BP_beta_determine (beta);
  
  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      const class array<TYPE> &beta_suboperator_intrinsic_NBMEs = Tp_data.get_beta_suboperator_intrinsic_NBMEs ();
      
      const int A = CC_state_in.get_A ();
      
      const double R_charge = R_charge_beta_calc (A);
      
      const unsigned int beta_suboperator_index = beta_suboperator_type_index_determine (beta_suboperator);
      
      switch (beta)
	{
	case ALLOWED:
	  {
	    const TYPE allowed_intrinsic_ME = beta_suboperator_intrinsic_NBMEs(ic , icp , beta_suboperator_index);

	    const TYPE allowed_CM_ME = radial_integral_calc (radial_operator , R_charge , CC_state_in , CC_state_out , ic_in , ic_out);

	    const TYPE allowed_ME = allowed_CM_ME*allowed_intrinsic_ME;

	    beta_suboperator_tab(beta_suboperator_index) = allowed_ME;
	  } break;
	      
	case FIRST_FORBIDDEN:
	  {
	    const enum beta_suboperator_type beta_intrinsic_suboperator = beta_intrinsic_suboperator_determine (beta_suboperator);
	    
	    const int rank_Op = rank_beta_suboperator_determine (beta_suboperator);

	    const int rank_intrinsic = rank_beta_suboperator_determine (beta_intrinsic_suboperator);

	    const int rank_CM = 1;		
  
	    const TYPE FFBD_intrinsic_ME = beta_suboperator_intrinsic_NBMEs(ic , icp , beta_suboperator_index);

	    const TYPE radial_FFBD_CM_ME = radial_integral_calc (radial_operator , R_charge , CC_state_in , CC_state_out , ic_in , ic_out);
	    
	    const double angular_part_FFBD_CM_ME = OBME_YL_reduced_in_l (rank_CM , LCM_projectile_in , LCM_projectile_out);

	    const TYPE FFBD_CM_ME = radial_FFBD_CM_ME*angular_part_FFBD_CM_ME;
	
	    const double J_intrinsic_in  = PSI_cluster_qn_c.get_J ();
	    const double J_intrinsic_out = PSI_cluster_qn_cp.get_J ();
	    
	    const double J_in  = CC_state_in.get_J ();
	    const double J_out = CC_state_out.get_J ();

	    const TYPE FFBD_ME = Oa_tensor_Ob_reduced_ME_calc (rank_CM , rank_intrinsic , rank_Op , LCM_projectile_in , J_intrinsic_in , J_in , LCM_projectile_out , J_intrinsic_out , J_out , FFBD_CM_ME , FFBD_intrinsic_ME);

	    beta_suboperator_tab(beta_suboperator_index) = FFBD_ME;
	  } break;

	default: abort_all ();
	}
    }
}






//--// return <uc_f lf jf || beta || uc_i li ji>
void CC_beta_transitions_MEs::cluster::beta_suboperators_NBMEs_calc (
								     const enum beta_type beta , 
								     const class CC_target_projectile_composite_data &Tpc_data,
								     const unsigned int ic ,
								     const unsigned int icp ,							
								     const class correlated_state_str &PSI_cluster_qn_c ,  
								     const class correlated_state_str &PSI_cluster_qn_cp ,
								     const class CC_state_class &CC_state_in , 
								     const class CC_state_class &CC_state_out , 
								     const unsigned int ic_in , 
								     const unsigned int ic_out , 
								     class array<TYPE> &beta_suboperator_tab)
{
  const unsigned int BP_Op = BP_beta_determine (beta);

  const class array<class CC_channel_class> &channels_tab_in  = CC_state_in.get_channels_tab ();
  const class array<class CC_channel_class> &channels_tab_out = CC_state_out.get_channels_tab ();

  const class CC_channel_class &channel_c_in  = channels_tab_in(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab_out(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (binary_parity_from_orbital_angular_momentum (LCM_projectile_in + LCM_projectile_out) == BP_Op)
    {
      switch (beta)
	{
	case ALLOWED:
	  {
	    beta_suboperator_NBME_calc (beta , OVERLAP , FERMI_ALLOWED        , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , OVERLAP , GAMOW_TELLER_ALLOWED , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	  } break;
	      
	case FIRST_FORBIDDEN:
	  {
	    beta_suboperator_NBME_calc (beta , FFBD , W_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , FFBD , U_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , FFBD , Z_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , FFBD , X_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	
	    beta_suboperator_NBME_calc (beta , FFBD_COULOMB , W_FFBD_COULOMB , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , FFBD_COULOMB , U_FFBD_COULOMB , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , FFBD_COULOMB , X_FFBD_COULOMB , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	
	    beta_suboperator_NBME_calc (beta , REDUCED_GRADIENT , XI_PRIME_V_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	    beta_suboperator_NBME_calc (beta , REDUCED_GRADIENT , XI_PRIME_Y_FFBD , Tpc_data , ic , icp , PSI_cluster_qn_c , PSI_cluster_qn_cp , CC_state_in , CC_state_out , ic_in , ic_out , beta_suboperator_tab);
	  } break;

	default: abort_all ();
	}
    }
}


