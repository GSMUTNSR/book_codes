#include "../CC_include/CC_include_def.h"

using namespace CC_common_routines;
using namespace CC_cluster_data_small_routines;


// HCM_two_channels_two_HO_calc
// ---------------------------
// Calculates the projectile center of mass Hamiltonian in harmonic oscillator basis for given (ic , NCM_HO_c;icp , NCM_HO_cp).

double CC_H_MEs_cluster::HCM_two_HO_calc (
					  const class array<class CC_channel_class> &channels_tab , 
					  const unsigned int ic , 
					  const int NCM_HO_c , 
					  const int NCM_HO_cp , 
					  const class array<class cluster_data> &cluster_projectile_data_tab)
{	
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type projectile_c = channel_c.get_projectile ();

  const class cluster_data &data_c = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);

  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

  const double J_projectile_c = channel_c.get_J_projectile ();

  const double ME_NCM_HO_c_Ho_NCM_HO_cp = CC_H_CM_OBMEs::cluster_CM::H_OBME_calc (LCM_projectile_c , J_projectile_c , NCM_HO_c , NCM_HO_cp , data_c);

  return ME_NCM_HO_c_Ho_NCM_HO_cp;
}






// Ho_two_HO_calc
// ---------------------------
// Calculates the non-antisymmetrized CC hamiltonian in harmonic oscillator basis for given (ic , NCM_HO_c;icp , NCM_HO_cp).

double CC_H_MEs_cluster::Ho_two_HO_calc (
					 const class array<class CC_channel_class> &channels_tab , 
					 const unsigned int ic , 
					 const int NCM_HO_c , 
					 const int NCM_HO_cp , 
					 const class array<class matrix<double> > &PCM_HCM_PCM_HO_submatrices)
{	
  const class CC_channel_class &channel_c = channels_tab(ic);

  const complex<double> E_Tc = channel_c.get_E_Tc ();

  const complex<double> E_intrinsic_projectile_c = channel_c.get_E_intrinsic_projectile_c ();

  const class matrix<double> &PCM_HCM_PCM_HO_submatrix_c = PCM_HCM_PCM_HO_submatrices(ic);

  const double OBME_CM_c_cp = PCM_HCM_PCM_HO_submatrix_c(NCM_HO_c , NCM_HO_cp);

  const double OBME = (NCM_HO_c == NCM_HO_cp) ? (OBME_CM_c_cp + real (E_Tc) + real (E_intrinsic_projectile_c)) : (OBME_CM_c_cp);
  
  return OBME;
}







double CC_H_MEs_cluster::Berggren_to_HO_two_channels_two_HO_calc (
								  const double CC_average_n_scat_target_projectile_max , 
								  const class array<class CC_channel_class> &channels_tab , 
								  const class array<bool> &is_it_forbidden_channel_tab ,  
								  const unsigned int ic , 
								  const unsigned int icp , 
								  const int NCM_HO_c , 
								  const int NCM_HO_cp , 
								  const class array<class cluster_data> &cluster_projectile_data_tab , 
								  const class array<unsigned int> &matrices_indices , 
								  const class matrix<complex<double> > &Berggren_matrix) 
{	
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type projectile_c  = channel_c.get_projectile ();
  const enum particle_type projectile_cp = channel_cp.get_projectile ();

  const int LCM_projectile_c  = channel_c.get_LCM_projectile ();
  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

  const double J_projectile_c  = channel_c.get_J_projectile ();
  const double J_projectile_cp = channel_cp.get_J_projectile ();

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const class cluster_data &data_c  = get_cluster_projectile_data (projectile_c  , cluster_projectile_data_tab);
  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

  const int A_projectile_c  = channel_c.get_A_projectile ();
  const int A_projectile_cp = channel_cp.get_A_projectile ();

  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c  = data_c.get_Nmax_cluster_projectile_CM_tab ();
  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

  const int Nmax_cluster_LCM_J_projectile_c  = Nmax_cluster_projectile_CM_tab_c (LCM_projectile_c  , J_projectile_c);
  const int Nmax_cluster_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

  const class nlj_table<bool> &cluster_CM_S_matrix_poles_c  = data_c.get_cluster_CM_S_matrix_poles ();
  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();

  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_c  = data_c.get_HO_overlaps_cluster_CM ();
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_cp = data_cp.get_HO_overlaps_cluster_CM ();

  complex<double> ME_NCM_HO_c_NCM_HO_cp_complex = 0.0;

  for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
    {
      const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

      const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

      if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	{	
	  const unsigned int index_in = matrices_indices(ic , NCM_c);
	  
	  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_c = HO_overlaps_cluster_CM_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const complex<double> HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_c = HO_overlaps_cluster_NCM_LCM_projectile_c(NCM_HO_c);

	  for (int NCM_cp = 0 ; NCM_cp <= Nmax_cluster_LCM_J_projectile_cp ; NCM_cp++) 
	    {	
	      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

	      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

	      if (!is_it_forbidden_channel_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
		{	
		  const unsigned int index_out = matrices_indices(icp , NCM_cp);

		  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_cp = HO_overlaps_cluster_CM_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		  const complex<double> HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_cp = HO_overlaps_cluster_NCM_LCM_projectile_cp(NCM_HO_cp);

		  ME_NCM_HO_c_NCM_HO_cp_complex += HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_c * Berggren_matrix(index_in , index_out) * HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_cp;
		}
	    }
	}
    }

  const double ME_NCM_HO_c_NCM_HO_cp = real (ME_NCM_HO_c_NCM_HO_cp_complex);

  return ME_NCM_HO_c_NCM_HO_cp;
}





// CC_H_MEs_cluster::potential_two_channels_two_HO_calc
// -------------------------------------------
// Calculates the finite-range potential V_ccp in harmonic oscillator basis for given (ic , NCM_HO_c;icp , NCM_HO_cp) , V being the finite-range potential , 
// = -\delta_{ccp} \sum _NCM_c <NCM_HO_c , c|NCM_c , c>.(e_NCM_c + E_Jc).<NCM_c , c|NCM_HO_cp , c>
// + \sum_{NCM_c , NCM_CM_cp} <NCM_HO_c , c|NCM_c , c> <a+_{NCM_c , c} \Psi_c | H | a+_{NCM_CM_cp , cp} \Psi_cp> <NCM_CM_cp , cp|NCM_HO_cp , cp>
//
// The <a+_{NCM_c , lc , jc} \Psi_c | H | a+_{NCM_cp , LCM_projectile_cp , jcp} \Psi_cp> are in &H_matrix given as a variable.

double CC_H_MEs_cluster::potential_two_channels_two_HO_calc (
							     const double CC_average_n_scat_target_projectile_max , 
							     const class array<class CC_channel_class> &channels_tab ,  
							     const class array<bool> &is_it_forbidden_channel_tab , 
							     const unsigned int ic , 
							     const unsigned int icp , 
							     const int NCM_HO_c , 
							     const int NCM_HO_cp , 
							     const class array<class cluster_data> &cluster_projectile_data_tab , 
							     const class array<unsigned int> &matrices_indices , 
							     const class matrix<complex<double> > &H_matrix , 
							     const class array<class matrix<double> > &PCM_HCM_PCM_HO_submatrices)
{	
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type projectile_c  = channel_c.get_projectile ();
  const enum particle_type projectile_cp = channel_cp.get_projectile ();

  const int LCM_projectile_c  = channel_c.get_LCM_projectile ();
  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

  const double J_projectile_c  = channel_c.get_J_projectile ();
  const double J_projectile_cp = channel_cp.get_J_projectile ();

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const int A_projectile_c  = channel_c.get_A_projectile ();
  const int A_projectile_cp = channel_cp.get_A_projectile ();

  const class cluster_data &data_c  = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);
  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c  = data_c.get_Nmax_cluster_projectile_CM_tab ();
  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

  const int Nmax_cluster_LCM_J_projectile_c  = Nmax_cluster_projectile_CM_tab_c (LCM_projectile_c  , J_projectile_c);
  const int Nmax_cluster_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

  const class nlj_table<bool> &cluster_CM_S_matrix_poles_c  = data_c.get_cluster_CM_S_matrix_poles ();
  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();

  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_c  = data_c.get_HO_overlaps_cluster_CM ();
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_cp = data_cp.get_HO_overlaps_cluster_CM ();

  complex<double> ME_NCM_HO_c_potential_NCM_HO_cp_complex = 0.0;

  for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
    {
      const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

      const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

      if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	{	
	  const unsigned int index_in = matrices_indices(ic , NCM_c);
	  
	  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_c = HO_overlaps_cluster_CM_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const complex<double> HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_c = HO_overlaps_cluster_NCM_LCM_projectile_c(NCM_HO_c);

	  for (int NCM_cp = 0 ; NCM_cp <= Nmax_cluster_LCM_J_projectile_cp ; NCM_cp++) 
	    {
	      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

	      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

	      if (!is_it_forbidden_channel_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
		{	
		  const unsigned int index_out = matrices_indices(icp , NCM_cp);

		  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_cp = HO_overlaps_cluster_CM_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		  const complex<double> HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_cp = HO_overlaps_cluster_NCM_LCM_projectile_cp(NCM_HO_cp);

		  ME_NCM_HO_c_potential_NCM_HO_cp_complex += HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_c * H_matrix(index_in , index_out) * HO_overlaps_cluster_NCM_LCM_projectile_NCM_HO_cp;
		}
	    }
	}
    }

  if (ic == icp) ME_NCM_HO_c_potential_NCM_HO_cp_complex -= Ho_two_HO_calc (channels_tab , ic , NCM_HO_c , NCM_HO_cp , PCM_HCM_PCM_HO_submatrices);

  const double ME_NCM_HO_c_potential_NCM_HO_cp = real (ME_NCM_HO_c_potential_NCM_HO_cp_complex);

  return ME_NCM_HO_c_potential_NCM_HO_cp;
}








// CC_H_MEs_cluster::overlap_related_matrix_two_channels_two_HO_calc
// --------------------------------------------
// Calculates the finite-range overlap O_finite_range_ccp in harmonic oscillator basis for given (ic , NCM_HO_c;icp , NCM_HO_cp)
// = -\delta_{ccp} \sum _NCM_c <NCM_HO_c , c|NCM_c , c>.<NCM_c , c|NCM_HO_cp , c> 
// + \sum_{NCM_c , NCM_CM_cp} <NCM_HO_c , c|NCM_c , c> <a+_{NCM_c , c} \Psi_c | a+_{NCM_CM_cp , cp} \Psi_cp> <NCM_CM_cp , cp|NCM_HO_cp , cp>
//
// The <a+_{NCM_c , lc , jc} \Psi_c | a+_{NCM_CM_cp , LCM_projectile_cp , jcp} \Psi_cp> are in &Ov_matrix given as a variable

double CC_H_MEs_cluster::finite_range_overlap_matrix_two_channels_two_HO_calc (
									       const double CC_average_n_scat_target_projectile_max , 
									       const class array<class CC_channel_class> &channels_tab , 
									       const class array<bool> &is_it_forbidden_channel_tab , 
									       const unsigned int ic , 
									       const unsigned int icp , 
									       const int NCM_HO_c , 
									       const int NCM_HO_cp , 
									       const class array<class cluster_data> &cluster_projectile_data_tab , 
									       const class array<unsigned int> &matrices_indices , 
									       const class matrix<complex<double> > &overlaps_matrix) 
{	
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type projectile_c  = channel_c.get_projectile ();
  const enum particle_type projectile_cp = channel_cp.get_projectile ();

  const int LCM_projectile_c  = channel_c.get_LCM_projectile ();
  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

  const double J_projectile_c  = channel_c.get_J_projectile ();
  const double J_projectile_cp = channel_cp.get_J_projectile ();

  const complex<double> average_n_scat_Tc  = channel_c.get_average_n_scat_Tc ();
  const complex<double> average_n_scat_Tcp = channel_cp.get_average_n_scat_Tc ();

  const double real_average_n_scat_Tc  = real (average_n_scat_Tc);
  const double real_average_n_scat_Tcp = real (average_n_scat_Tcp);

  const int A_projectile_c  = channel_c.get_A_projectile ();
  const int A_projectile_cp = channel_cp.get_A_projectile ();

  const class cluster_data &data_c  = get_cluster_projectile_data (projectile_c , cluster_projectile_data_tab);
  const class cluster_data &data_cp = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_tab);

  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_c  = data_c.get_Nmax_cluster_projectile_CM_tab ();
  const class lj_table<int> &Nmax_cluster_projectile_CM_tab_cp = data_cp.get_Nmax_cluster_projectile_CM_tab ();	

  const int Nmax_cluster_LCM_J_projectile_c  = Nmax_cluster_projectile_CM_tab_c (LCM_projectile_c  , J_projectile_c);
  const int Nmax_cluster_LCM_J_projectile_cp = Nmax_cluster_projectile_CM_tab_cp(LCM_projectile_cp , J_projectile_cp);

  const class nlj_table<bool> &cluster_CM_S_matrix_poles_c  = data_c.get_cluster_CM_S_matrix_poles ();
  const class nlj_table<bool> &cluster_CM_S_matrix_poles_cp = data_cp.get_cluster_CM_S_matrix_poles ();

  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_c  = data_c.get_HO_overlaps_cluster_CM ();
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_cp = data_cp.get_HO_overlaps_cluster_CM ();

  double ME_NCM_HO_c_overlap_NCM_HO_cp = 0.0;

  for (int NCM_c = 0 ; NCM_c <= Nmax_cluster_LCM_J_projectile_c ; NCM_c++) 
    {
      const bool S_matrix_pole_NCM_c = cluster_CM_S_matrix_poles_c(NCM_c , LCM_projectile_c , J_projectile_c);

      const double real_average_n_scat_c = (!S_matrix_pole_NCM_c) ? (real_average_n_scat_Tc + A_projectile_c) : (real_average_n_scat_Tc);

      if (!is_it_forbidden_channel_tab(ic , NCM_c) && (real_average_n_scat_c <= CC_average_n_scat_target_projectile_max))
	{	
	  const unsigned int index_in = matrices_indices(ic , NCM_c);

	  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_c = HO_overlaps_cluster_CM_c(NCM_c , LCM_projectile_c , J_projectile_c);

	  const complex<double> HO_overlaps_cluster_NCM_LCM_NCM_HO_c = HO_overlaps_cluster_NCM_LCM_projectile_c(NCM_HO_c);

	  for (int NCM_cp = 0 ; NCM_cp <= Nmax_cluster_LCM_J_projectile_cp ; NCM_cp++) 
	    {
	      const bool S_matrix_pole_NCM_cp = cluster_CM_S_matrix_poles_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

	      const double real_average_n_scat_cp = (!S_matrix_pole_NCM_cp) ? (real_average_n_scat_Tcp + A_projectile_cp) : (real_average_n_scat_Tcp);

	      if (!is_it_forbidden_channel_tab(icp , NCM_cp) && (real_average_n_scat_cp <= CC_average_n_scat_target_projectile_max))
		{	
		  const unsigned int index_out = matrices_indices(icp , NCM_cp);

		  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_cp = HO_overlaps_cluster_CM_cp(NCM_cp , LCM_projectile_cp , J_projectile_cp);

		  const complex<double> HO_overlaps_cluster_NCM_LCM_NCM_HO_cp = HO_overlaps_cluster_NCM_LCM_projectile_cp(NCM_HO_cp);

		  ME_NCM_HO_c_overlap_NCM_HO_cp += real (HO_overlaps_cluster_NCM_LCM_NCM_HO_c * overlaps_matrix(index_in , index_out) * HO_overlaps_cluster_NCM_LCM_NCM_HO_cp);

		  if ((ic == icp) && (NCM_c == NCM_cp)) ME_NCM_HO_c_overlap_NCM_HO_cp -= real (HO_overlaps_cluster_NCM_LCM_NCM_HO_c*HO_overlaps_cluster_NCM_LCM_NCM_HO_cp);
		}
	    }
	}
    }

  return ME_NCM_HO_c_overlap_NCM_HO_cp;
}







// Use of the HO matrix to make the elements really finite-range
// -------------------------------------------------------------

complex<double> CC_H_MEs_cluster::finite_range_orthogonalized_potential_two_channels_two_CC_Berggren_calc (
													   const class array<class CC_channel_class> &channels_tab , 
													   const unsigned int ic , 
													   const unsigned int icp , 
													   const unsigned int NCM_c , 
													   const unsigned int NCM_cp , 
													   const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab ,
													   const class array<class matrix<complex<double> > > &finite_range_orthogonalized_potential_HO_submatrices)
{
  const class CC_channel_class &channel_c  = channels_tab(ic);
  const class CC_channel_class &channel_cp = channels_tab(icp);

  const enum particle_type projectile_c  = channel_c.get_projectile ();
  const enum particle_type projectile_cp = channel_cp.get_projectile ();

  const int LCM_projectile_c  = channel_c.get_LCM_projectile ();
  const int LCM_projectile_cp = channel_cp.get_LCM_projectile ();

  const double J_projectile_c  = channel_c.get_J_projectile ();
  const double J_projectile_cp = channel_cp.get_J_projectile ();

  const class cluster_data &data_c_CC_Berggren  = get_cluster_projectile_data (projectile_c  , cluster_projectile_data_CC_Berggren_tab);
  const class cluster_data &data_cp_CC_Berggren = get_cluster_projectile_data (projectile_cp , cluster_projectile_data_CC_Berggren_tab);

  // Fermi is used here , as one has to put a cut function in equivalent potentials for them to go to zero at infinity
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_Fermi_cluster_CM_c_CC_Berggren = data_c_CC_Berggren.get_HO_overlaps_Fermi_cluster_CM ();
  
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_Fermi_cluster_CM_cp_CC_Berggren = data_cp_CC_Berggren.get_HO_overlaps_Fermi_cluster_CM ();

  const class matrix<complex<double> > &finite_range_orthogonalized_potential_HO_submatrix_c_cp = finite_range_orthogonalized_potential_HO_submatrices(ic , icp);

  const class vector_class<complex<double> > &HO_overlaps_Fermi_cluster_NCM_LCM_projectile_c_CC_Berggren  = HO_overlaps_Fermi_cluster_CM_c_CC_Berggren (NCM_c  , LCM_projectile_c  , J_projectile_c);
  const class vector_class<complex<double> > &HO_overlaps_Fermi_cluster_NCM_LCM_projectile_cp_CC_Berggren = HO_overlaps_Fermi_cluster_CM_cp_CC_Berggren(NCM_cp , LCM_projectile_cp , J_projectile_cp);

  const complex<double> ME_NCM_c_potential_NCM_cp = HO_overlaps_Fermi_cluster_NCM_LCM_projectile_c_CC_Berggren * (finite_range_orthogonalized_potential_HO_submatrix_c_cp * HO_overlaps_Fermi_cluster_NCM_LCM_projectile_cp_CC_Berggren);

  return ME_NCM_c_potential_NCM_cp;
}









complex<double> CC_H_MEs_cluster::OCM_potential_part_two_channels_two_CC_Berggren_calc (
											const class array<class CC_channel_class> &channels_tab , 
											const unsigned int ic , 
											const unsigned int NCM_c , 
											const unsigned int NCM_cp ,
											const complex<double> &E_CM_c ,
											const complex<double> &E_CM_cp ,
											const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 											
											const class array<class matrix<complex<double> > > &QCM_HO_submatrices ,											
											const class array<class matrix<complex<double> > > &QCM_HCM_QCM_HO_submatrices)
{
  const class CC_channel_class &channel_c = channels_tab(ic);

  const enum particle_type projectile_c = channel_c.get_projectile ();

  const int LCM_projectile_c = channel_c.get_LCM_projectile ();

  const double J_projectile_c = channel_c.get_J_projectile ();

  const class cluster_data &data_c_CC_Berggren = get_cluster_projectile_data (projectile_c , cluster_projectile_data_CC_Berggren_tab);

  // Fermi is used here , as one has to put a cut function in equivalent potentials for them to go to zero at infinity
  const class nlj_table<class vector_class<complex<double> > > &HO_overlaps_cluster_CM_c_CC_Berggren = data_c_CC_Berggren.get_HO_overlaps_cluster_CM ();

  const class matrix<complex<double> > &QCM_HO_submatrix_c = QCM_HO_submatrices(ic);

  const class matrix<complex<double> > &QCM_HCM_QCM_HO_submatrix_c = QCM_HCM_QCM_HO_submatrices(ic);

  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_cp_CC_Berggren = HO_overlaps_cluster_CM_c_CC_Berggren(NCM_cp , LCM_projectile_c , J_projectile_c);
  const class vector_class<complex<double> > &HO_overlaps_cluster_NCM_LCM_projectile_c_CC_Berggren  = HO_overlaps_cluster_CM_c_CC_Berggren(NCM_c  , LCM_projectile_c , J_projectile_c);

  const complex<double> ME_NCM_c_QCM_NCM_cp = HO_overlaps_cluster_NCM_LCM_projectile_c_CC_Berggren * (QCM_HO_submatrix_c * HO_overlaps_cluster_NCM_LCM_projectile_cp_CC_Berggren);
  
  const complex<double> ME_NCM_c_QCM_HCM_QCM_NCM_cp = HO_overlaps_cluster_NCM_LCM_projectile_c_CC_Berggren * (QCM_HCM_QCM_HO_submatrix_c * HO_overlaps_cluster_NCM_LCM_projectile_cp_CC_Berggren);

  const complex<double> ME_NCM_c_OCM_part_NCM_cp = ME_NCM_c_QCM_HCM_QCM_NCM_cp - ME_NCM_c_QCM_NCM_cp*(E_CM_c + E_CM_cp);

  return ME_NCM_c_OCM_part_NCM_cp;
}




