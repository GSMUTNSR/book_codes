#include "../CC_include/CC_include_def.h"

using namespace Wigner_signs;

using namespace CC_rms_radius_MEs::radial;

//--// return <uc_f lf jf || beta || uc_i li ji>
TYPE CC_rms_radius_MEs::one_baryon::OBME_calc (
					       const double rms_radius_factor ,
					       const class CC_state_class &CC_state ,
					       const unsigned int ic_in ,
					       const unsigned int ic_out)
{
  const class array<class CC_channel_class> &channels_tab = CC_state.get_channels_tab ();
  
  const class CC_channel_class &channel_c_in  = channels_tab(ic_in);
  const class CC_channel_class &channel_c_out = channels_tab(ic_out);

  const int LCM_projectile_in  = channel_c_in.get_LCM_projectile ();
  const int LCM_projectile_out = channel_c_out.get_LCM_projectile ();

  if (LCM_projectile_in != LCM_projectile_out) return 0.0;
  
  const enum particle_type projectile_in  = channel_c_in.get_projectile ();
  const enum particle_type projectile_out = channel_c_out.get_projectile ();

  if (projectile_in != projectile_out) return 0.0;
  
  const double J_projectile_in  = channel_c_in.get_J_projectile ();
  const double J_projectile_out = channel_c_out.get_J_projectile ();

  if (make_int (J_projectile_in - J_projectile_out) != 0) return 0.0;
  
  //--// calculations of the radial rms radius matrix element
  const TYPE radial_OBME = radial_integral_calc (R2_RADIAL , CC_state , ic_in , ic_out);

  const TYPE OBME = rms_radius_factor*radial_OBME;
      
  return OBME;
}






