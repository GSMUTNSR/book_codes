#ifndef CC_BETATRANSITIONSPOLES_H
#define CC_BETATRANSITIONSPOLES_H

namespace CC_beta_transitions_poles
{
  void data_father_alloc_calc (
			       const enum beta_pm_type beta_pm , 
			       const bool truncation_hw , 
			       const bool truncation_ph , 
			       const enum interaction_type inter , 
			       const class baryons_data &prot_Y_data_out , 
			       const class baryons_data &neut_Y_data_out , 
			       class baryons_data &prot_Y_data_in , 
			       class baryons_data &neut_Y_data_in);
  
  void beta_suboperator_intrinsic_MEs_calc (
					    const enum beta_type beta , 
					    const enum beta_pm_type beta_pm ,
					    const bool is_it_HO_expansion ,
					    const class interaction_class &inter_data_basis ,  
					    class array<class cluster_data> &cluster_projectile_data_tab , 
					    class CC_target_projectile_composite_data &Tpc_data);

  void beta_suboperators_NBMEs_calc (
				     const enum beta_type beta ,
				     const enum beta_pm_type beta_pm ,
				     const bool is_it_HO_expansion ,
				     const bool is_it_nas_only ,
				     const class CC_target_projectile_composite_data &Tpc_data , 
				     const class input_data_str &input_data_CC_Berggren , 
				     const class interaction_class &inter_data_basis ,
				     const class array<class cluster_data> &cluster_projectile_data_tab ,
				     const class CC_Hamiltonian_data &CC_H_data_in , 
				     const class CC_state_class &CC_state_in ,
				     const class CC_Hamiltonian_data &CC_H_data_out ,  
				     const class CC_state_class &CC_state_out , 
				     class baryons_data &prot_Y_data_out , 
				     class baryons_data &neut_Y_data_out ,
				     const class correlated_state_str &PSI_in_qn ,  
				     const class correlated_state_str &PSI_out_qn ,   
				     class array<TYPE> &beta_suboperator_NBMEs);
 
  void calc_print (
		   const input_data_str &input_data , 
		   const input_data_str &input_data_CC_Berggren , 
		   const class interaction_class &inter_data_basis ,
		   const class HF_nucleons_data &prot_HF_data_CC_Berggren , 
		   const class HF_nucleons_data &neut_HF_data_CC_Berggren ,
		   class baryons_data &prot_Y_data_CC_Berggren , 
		   class baryons_data &neut_Y_data_CC_Berggren , 
		   class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab , 
		   class baryons_data &prot_Y_data , 
		   class baryons_data &neut_Y_data , 
		   class array<class cluster_data> &cluster_projectile_data_tab , 
		   class CC_target_projectile_composite_data &Tpc_data , 
		   class TBMEs_class &TBMEs_pn);
}

#endif


