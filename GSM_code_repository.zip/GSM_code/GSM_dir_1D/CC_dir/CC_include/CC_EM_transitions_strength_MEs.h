#ifndef CC_EM_TRANSITIONS_STRENGTH_MES_H
#define CC_EM_TRANSITIONS_STRENGTH_MES_H

namespace CC_EM_transitions_strength_MEs
{ 	
  namespace radial
  {
    //--// return the radial part of <uc_f lf jf || E_L || uc_i li ji> before R
    void radial_OBMEs_calc (
			    const enum radial_operator_type radial_operator,
			    const int L,
			    const bool is_it_long_wavelength_approximation,
			    const bool is_it_Gauss_Legendre , 
			    const class CC_state_class &CC_state_in,
			    const class CC_state_class &CC_state_out,
			    const unsigned int ic_in,
			    const unsigned int ic_out,
			    class array<TYPE> &radial_OBMEs);
								  
  }

  namespace one_baryon
  {
    namespace electric
    {
      //--// calculates <uc_f lf jf || E_L || uc_i li ji>
      void OBMEs_reduced_calc (
			       const int L,
			       const bool is_it_long_wavelength_approximation,
			       const double effective_charge,
			       const bool is_it_Gauss_Legendre , 
			       const class CC_state_class &CC_state_in,
			       const class CC_state_class &CC_state_out,
			       const unsigned int ic_in,
			       const unsigned int ic_out,
			       class array<TYPE> &electric_OBMEs);
    }

    namespace magnetic
    {
      //--// calculates <uc_f lf jf || M_L || uc_i li ji>
      void OBMEs_reduced_calc (
			       const int L,
			       const bool is_it_long_wavelength_approximation,
			       const bool is_it_Gauss_Legendre , 
			       const class CC_state_class &CC_state_in,
			       const class CC_state_class &CC_state_out,
			       const unsigned int ic_in,
			       const unsigned int ic_out,
			       class array<TYPE> &magnetic_OBMEs);
    }

    //--// calculates <uc_f lf jf || M/E_L || uc_i li ji>
    
    void OBMEs_reduced_calc (
			     const enum EM_type EM,
			     const int L,
			     const bool is_it_long_wavelength_approximation,
			     const double effective_charge,
			     const bool is_it_Gauss_Legendre , 
			     const class CC_state_class &CC_state_in,
			     const class CC_state_class &CC_state_out,
			     const unsigned int ic_in,
			     const unsigned int ic_out,
			     class array<TYPE> &OBMEs_tab);
  }

  namespace cluster
  {
    void EM_suboperator_intrinsic_NBMEs_calc (
					      const enum EM_suboperator_type EM_suboperator , 
					      const TYPE &q , 
					      const int L , 
					      const bool is_it_longwavelength_approximation , 
					      const bool is_it_Gauss_Legendre , 
					      const class interaction_class &inter_data_basis ,  
					      const class cluster_data &data_c , 
					      const class cluster_data &data_cp , 
					      const class GSM_vector &PSI_cluster_c ,
					      const class GSM_vector &PSI_cluster_cp , 
					      class array<TYPE> &EM_suboperator_intrinsic_NBMEs_cluster_fixed_tab);
    
    namespace electric
    {
      void intrinsic_NBMEs_store (
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const unsigned int ic , 
				  const unsigned int icp ,
				  const int l_intrinsic , 
				  class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
				  class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab);

      void charge_ME_reduced_part_calc (
					const bool is_it_longwavelength_approximation ,
					const bool is_it_Gauss_Legendre , 
					const int l_intrinsic , 
					const int LCM ,
					const int L ,  
					const class CC_state_class &CC_state_in , 
					const class CC_state_class &CC_state_out , 
					const unsigned int ic_in , 
					const unsigned int ic_out , 
					const class array<TYPE> &ECH_all_intrinsic_NBME_tab , 
					const class array<TYPE> &ECH_intrinsic_NBME_jl_Yl_tab , 
					const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_over_r_Yl_tab , 
					const class array<TYPE> &ECH_intrinsic_NBME_hat_jl_Yl_tensor_e_tab , 
					class array<TYPE> &ECH_ME_reduced_part_tab);

      void current_ME_reduced_part_calc (
					 const bool is_it_longwavelength_approximation ,
					 const bool is_it_Gauss_Legendre , 
					 const int l_intrinsic , 
					 const int LCM , 
					 const int L , 
					 const class CC_state_class &CC_state_in , 
					 const class CC_state_class &CC_state_out , 
					 const unsigned int ic_in , 
					 const unsigned int ic_out , 
					 const class array<TYPE> &EC_all_intrinsic_NBME_tab , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_r_s_tab , 
					 const class array<TYPE> &EC_intrinsic_NBME_hat_jl_over_r_Yl_tensor_p_s_tab ,
					 class array<TYPE> &EC_ME_reduced_part_tab);

      void calc (
		 const int L , 
		 const bool is_it_longwavelength_approximation ,
		 const bool is_it_Gauss_Legendre , 
		 const class CC_target_projectile_composite_data &Tpc_data , 
		 const class array<class cluster_data> &cluster_projectile_data_tab , 
		 const unsigned int ic , 
		 const unsigned int icp , 
		 const class CC_state_class &CC_state_in , 
		 const class CC_state_class &CC_state_out , 
		 const unsigned int ic_in , 
		 const unsigned int ic_out , 
		 class array<TYPE> &electric_strength_tab);
    }

    namespace magnetic
    {
      void intrinsic_NBMEs_store (
				  const class CC_target_projectile_composite_data &Tpc_data , 
				  const unsigned int ic , 
				  const unsigned int icp , 
				  const int l_intrinsic , 
				  class array<TYPE> &MOLP1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
				  class array<TYPE> &MOLM1INT_intrinsic_NBME_grad_jl_Yl_r_tab ,
				  class array<TYPE> &MOLP1INT_intrinsic_NBME_grad_jl_Yl_p_tab ,
				  class array<TYPE> &MOLM1INT_intrinsic_NBME_grad_jl_Yl_p_tab ,
				  class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab);

      void orbital_gradient_ME_reduced_part_calc (
						  const int pm,
						  const bool is_it_longwavelength_approximation ,
						  const bool is_it_Gauss_Legendre , 
						  const int l_intrinsic , 
						  const int LCM , 
						  const int L , 
						  const class CC_state_class &CC_state_in , 
						  const class CC_state_class &CC_state_out , 
						  const unsigned int ic_in , 
						  const unsigned int ic_out , 
						  const class array<TYPE> &MO_all_intrinsic_NBME_tab , 
						  const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_tab , 
						  const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_r_tab , 
						  const class array<TYPE> &MO_intrinsic_NBME_grad_jl_Yl_p_tab ,
						  class array<TYPE> &orbital_ME_reduced_part_tab);

      void spin_gradient_ME_reduced_calc (
					  const int pm,
					  const bool is_it_longwavelength_approximation ,
					  const bool is_it_Gauss_Legendre , 
					  const int l_intrinsic , 
					  const int LCM , 
					  const int L , 
					  const class CC_state_class &CC_state_in , 
					  const class CC_state_class &CC_state_out , 
					  const unsigned int ic_in , 
					  const unsigned int ic_out , 
					  const class array<TYPE> &MS_all_intrinsic_NBME_tab ,
					  const class array<TYPE> &MS_intrinsic_NBME_jl_Yl_tensor_s_tab ,
					  class array<TYPE> &spin_ME_reduced_part_tab);

      void spin_s_scalar_e_ME_part_calc (
					 const bool is_it_longwavelength_approximation ,
					 const bool is_it_Gauss_Legendre , 
					 const int l_intrinsic , 
					 const int LCM , 
					 const int L , 
					 const class CC_state_class &CC_state_in , 
					 const class CC_state_class &CC_state_out , 
					 const unsigned int ic_in , 
					 const unsigned int ic_out , 
					 const class array<TYPE> &MSSCE_all_intrinsic_NBME_tab , 
					 const class array<TYPE> &MSSCE_intrinsic_NBME_hat_jl_over_r_Yl_tensor_s_tab ,
					 class array<TYPE> &spin_ME_reduced_part_tab);

      void calc (
		 const int L , 
		 const bool is_it_longwavelength_approximation ,
		 const bool is_it_Gauss_Legendre , 
		 const class CC_target_projectile_composite_data &Tpc_data , 
		 const class array<class cluster_data> &cluster_projectile_data_tab , 
		 const unsigned int ic , 
		 const unsigned int icp , 
		 const class CC_state_class &CC_state_in , 
		 const class CC_state_class &CC_state_out , 
		 const unsigned int ic_in , 
		 const unsigned int ic_out , 
		 class array<TYPE> &magnetic_strength_tab);
    }

    void calc (
	       const enum EM_type EM , 
	       const int L , 
	       const bool is_it_longwavelength_approximation ,
	       const bool is_it_Gauss_Legendre , 
	       const class CC_target_projectile_composite_data &Tpc_data , 
	       const class array<class cluster_data> &cluster_projectile_data_tab ,
	       const unsigned int ic , 
	       const unsigned int icp , 
	       const class CC_state_class &CC_state_in , 
	       const class CC_state_class &CC_state_out , 
	       const unsigned int ic_in , 
	       const unsigned int ic_out ,
	       class array<TYPE> &strength_tab);
  }


  namespace composite
  {
    // calculation of the antisymetrized + HO ME
    void target_projectile_as_HO_NBMEs_calc (
					     const bool is_it_one_baryon , 
					     const enum EM_type EM , 
					     const int L ,
					     const bool is_it_longwavelength_approximation , 
					     const bool is_it_Gauss_Legendre , 
					     const class CC_Hamiltonian_data &CC_H_data_in , 
					     const class CC_state_class &CC_state_in , 
					     const class CC_Hamiltonian_data &CC_H_data_out , 
					     const class CC_state_class &CC_state_out ,		
					     const class input_data_str &input_data_CC_Berggren , 
					     class baryons_data &prot_data , 
					     class baryons_data &neut_data ,
					     const class array<class cluster_data> &cluster_projectile_data_tab ,  
					     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_in , 
					     const class array<class vector_class<complex<double> > > &CC_HO_overlaps_out , 
					     class array<TYPE> &target_projectile_as_HO_strength_tab);
    
    // target nas
    // common to the non antisymetrized (nas) and for the non antisymetrized + HO (nas_HO)
    void target_nas_NBMEs_calc (
				const enum EM_type EM , 
				const int L , 
				const bool is_it_longwavelength_approximation , 
				const bool is_it_Gauss_Legendre , 
				const class CC_target_projectile_composite_data &Tpc_data , 
				const class CC_state_class &CC_state_in , 
				const class CC_state_class &CC_state_out , 
				const class array<TYPE> &target_reduced_NBMEs , 
				class array<TYPE> &target_nas_strength_tab);

    // projectile
    // for the non antisymmetrized (nas) NBME
    // the CC_state_out/in are used
    // common to nas and nas+HO
    void projectile_nas_NBMEs_calc (
				    const enum EM_type EM , 
				    const int L , 
				    const bool is_it_longwavelength_approximation ,
				    const bool is_it_Gauss_Legendre , 
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    const class CC_state_class &CC_state_in , 
				    const class CC_state_class &CC_state_out ,
				    const class array<class cluster_data> &cluster_projectile_data_tab , 
				    class array<TYPE> &projectile_nas_strength_tab);
    
    // cf_<J_Tf || M/E_L (T) || J_Ti>_ci NBMEs stored
    void target_reduced_NBMEs_calc (
				    const enum interaction_type inter ,
				    const enum EM_type EM ,
				    const TYPE &q , 
				    const int L ,  
				    const bool is_it_longwavelength_approximation , 
				    const bool is_it_Gauss_Legendre , 
				    const class CC_target_projectile_composite_data &Tpc_data , 
				    class array<class baryons_data> &prot_data_one_cluster_less_tab , 
				    class array<class baryons_data> &neut_data_one_cluster_less_tab ,
				    class array<TYPE> &target_reduced_strength_tab);
    
    void calc (
	       const enum EM_type EM ,
	       const int L , 
	       const bool is_it_longwavelength_approximation , 
	       const bool is_it_Gauss_Legendre , 
	       const class CC_target_projectile_composite_data &Tpc_data , 
	       const class array<class cluster_data> &cluster_projectile_data_tab , 
	       const bool is_it_nas_only , 
	       const class CC_Hamiltonian_data &CC_H_data_in , 
	       const class CC_state_class &CC_state_in , 
	       const class CC_Hamiltonian_data &CC_H_data_out , 
	       const class CC_state_class &CC_state_out ,		
	       class baryons_data &prot_data , 
	       class baryons_data &neut_data , 
	       const class input_data_str &input_data_CC_Berggren , 
	       const class array<TYPE> &target_reduced_NBMEs ,
	       class array<TYPE> &strength_tab);
  }
}

#endif


