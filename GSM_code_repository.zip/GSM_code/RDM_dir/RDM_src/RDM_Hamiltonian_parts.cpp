#include "../RDM_include/RDM_include_def.h"

using namespace string_routines;
using namespace correlated_state_routines;
using namespace inputs_misc;
using namespace RDM_rho_observables;


// OBMEs means one-body matrix elements
// ------------------------------------

// TBMEs means two-body matrix elements
// ------------------------------------

// NBMEs means N-body matrix elements
// ----------------------------------










// Routines calculating expectation values of the different parts of the Hamiltonian on an eigenvector |Psi>
// ---------------------------------------------------------------------------------------------------------
// The Hamiltonian is the sum of one-body kinetic part, two-body kinetic part (i.e. recoil), one-body and two-body nuclear and Coulomb parts and three-body like part (Minnesota only).
// They are all calculated one after the other and printed on screen.
//
// For this, OBMEs and TBMEs related to the considered Hamiltonian part are calculated and stored in OBMEs and TBMEs arrays and classes, then erasing previous OBMEs and TBMEs.
//
// The Hamiltonian part operator is applied to the eigenvector H[part]|Psi>,
// and the expectation value <Psi | H[part] | Psi> is then calculated and printed on screen.
//
// OBMEs of the initial Hamiltonian are stored and put back in OBMEs arrays.
// TBMEs of the initial Hamiltonian are recalculated and put back in TBMEs arrays at the end of the calculation.
//
// Variables
// ---------
// all_H_proton_neutron_one_jumps_recalculated: true if one recalculates all jumps <SDp' | a+(alpha) a(beta) | SDp> and <SDn' | a+(alpha) a(beta) | SDn> in the Hamiltonian not to have to store them, false if not
// inter_data: class containing data and HO matrix elements related to the used two-body interaction
// J: total angular momentum of the GSM eigenvector
// PSI_helper: structures containing information about the many-body body basis of |Psi>
// prot_data, neut_data: classes where all data related to protons and neutrons are stored
// TBMEs_prot, TBMEs_neut, TBMEs_pn: class storing J-coupled pp, nn and pn two-body matrix elements. They will contain the TBMEs of Hamiltonian parts.
// PSI: GSM eigenvector |Psi>
// space: PROTONS_ONLY if one has valence protons only, NEUTRONS_ONLY if one has valence neutrons only, PROTONS_NEUTRONS if one has valence protons and neutrons
// TBME_inter: type of the interaction used (FHT, realistic, ...)
// Zval, Nval: number of valence protons and neutrons
//
// prot_OBMEs_inter_set, neut_OBMEs_inter_set: array of arrays of proton and neutron one-body matrix elements for Hamiltonian, nuclear, kinetic and Coulomb operators
//                                             They will contain the OBMEs of Hamiltonian parts.
// 
// prot_OBMEs_inter, neut_OBMEs_inter: copies of the initial arrays of interaction OBMEs, to put back in prot_OBMEs_inter_set, neut_OBMEs_inter_set after a Hamiltonian part calculation is finished
// prot_OBMEs_kinetic/nuclear/Coulomb, neut_OBMEs_kinetic/nuclear/Coulomb: copies of OBMEs arrays of kinetic/nuclear/Coulomb parts, which are used for a Hamiltonian part calculation
//
// Tp/n_one_body, Tpp/nn/pn_recoil_no_sign, Hp/n_nuclear_one_body, Vpp, Vnn, Vpn, Hp_Coulomb_one_body, Vpp_Coulomb:
// Different Hamiltonian part operators of H_class type, for kinetic one-body, kinetic two-body, nuclear one-body, nuclear two-body, Coulomb one-body, Coulomb two-body
// "no_sign" means that the two-body recoil term has to be multiplied by -1 if one uses laboratory coordinates, and by 1 if one uses COSM.
//
// Tp/n_one_body_PSI, Tpp/nn/pn_recoil_no_sign_PSI, Hp/n_nuclear_one_body_PSI, Vpp_PSI, Vnn_PSI, Vpn_PSI, Hp_Coulomb_one_body_PSI, Vpp_Coulomb_PSI:
// GSM vectors resulting from the application of previous Hamiltonian part operators to |Psi>
//
// space: PROTONS_ONLY if one has valence protons only, NEUTRONS_ONLY if one has valence neutrons only, PROTONS_NEUTRONS if one has valence protons and neutrons.
// truncation_hw: true if one truncates in energy, given there in units of hbar omega, false if not 
// truncation_ph: true if one truncates with respect to hole number in core states or particle number in the continuum, false if not
// Z,N: number of protons and neutrons of the nucleus
// n_scat_max_p_in, n_scat_max_n_in, n_scat_max_mu_in: maximal number of nucleons in the continuum, for proton space and neutron space, and for the considered space
// Ep_max_hw_in, En_max_hw_in, Emu_max_hw_in: maximal truncation energy for proton space and neutron space, and for the considered space
// Jc_relative_max , Jn_relative_max: maximal relative total angular momentum of the Coulomb (c) or nuclear (n) interaction
// eigenstates_number: number of eigenstates which have been calculated
// RDM_Hamiltonian_parts_BP_tab, RDM_Hamiltonian_parts_J_tab, &RDM_Hamiltonian_parts_vector_index_tab: binary parities (see observables_basic_functions.cpp for definition), total angular momenta and vector indices of eigenvectors whose Hamiltonian parts expectation values must be calculated
// H_potential: potential used in the Hamiltonian
// Z_charge_basis_potential: charge used in the basis-generating potential
// BP, J, vector_index: BP, J, quantum numbers and vector index (0 for J-Pi ground state, 1 for J-Pi first excited state, ...) of |Psi> eigenvectors
// PSI_qn: class correlated_state_str containing data about the current GSM eigenvector, such as Z,N,BP,J ... (qn is quantum numbers)
// dummy_helper: dummy GSM_vector_helper_class class
// 

void RDM_Hamiltonian_parts::kinetic_one_body_calc_print (
							 const enum space_type space , 
							 const class interaction_class &inter_data ,
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data , 
							 class TBMEs_class &TBMEs_pn ,
							 const class RDM_PQG_class &Gamma_pp ,
							 const class RDM_PQG_class &Gamma_nn ,
							 const class RDM_PQG_class &Gamma_pn)
{  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
		
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_kinetic = prot_OBMEs_inter_set(ONE_BODY_KINETIC);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_kinetic;
	
	const TYPE Tp_NBME = average_E_calc (false ,  TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tp[one-body]|PSI>: " << Tp_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> neut_OBMEs_kinetic = neut_OBMEs_inter_set(ONE_BODY_KINETIC);

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_kinetic;

	const TYPE Tn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tn[one-body]|PSI>: " << Tn_NBME << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      { 
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_kinetic = prot_OBMEs_inter_set(ONE_BODY_KINETIC);
	const class array<TYPE> neut_OBMEs_kinetic = neut_OBMEs_inter_set(ONE_BODY_KINETIC);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_kinetic;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	const TYPE Tp_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tp[one-body]|PSI>: " << Tp_NBME << " MeV" << endl << endl;
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_kinetic;

	const TYPE Tn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tn[one-body]|PSI>: " << Tn_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::kinetic_recoil_calc_print (
						       const class input_data_str &input_data , 
						       const class interaction_class &inter_data , 
						       class nucleons_data &prot_data , 
						       class nucleons_data &neut_data , 
						       class TBMEs_class &TBMEs_pn , 
						       const class RDM_PQG_class &Gamma_pp ,
						       const class RDM_PQG_class &Gamma_nn ,
						       const class RDM_PQG_class &Gamma_pn)
{
  const enum space_type space = input_data.get_space ();
  						       
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const bool is_it_COSM = is_it_COSM_determine (TBME_inter);
  
  const int sign_inter = (!is_it_COSM) ? (-1) : (1);

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
		
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {	
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_data);

	const TYPE Tpp_recoil_NBME = sign_inter*average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpp[recoil]|PSI>: " << Tpp_recoil_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_data); 

	const TYPE Tnn_recoil_NBME = sign_inter*average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tnn[recoil]|PSI>: " << Tnn_recoil_NBME << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      {
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , prot_data);

	    const TYPE Tpp_recoil_NBME = sign_inter*average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpp[recoil]|PSI>: " << Tpp_recoil_NBME << " MeV" << endl << endl;
	    
	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , CM_KINETIC_INTERACTION , input_data , false , inter_data , neut_data); 
	    
	    const TYPE Tnn_recoil_NBME = sign_inter*average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tnn[recoil]|PSI>: " << Tnn_recoil_NBME << " MeV" << endl << endl;
	    
	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , CM_KINETIC_INTERACTION , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const TYPE Tpn_recoil_NBME = sign_inter*average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Tpn[recoil]|PSI>: " << Tpn_recoil_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::nuclear_one_body_calc_print (				
							 const enum space_type space , 
							 const class interaction_class &inter_data ,
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data , 
							 class TBMEs_class &TBMEs_pn , 
							 const class RDM_PQG_class &Gamma_pp ,
							 const class RDM_PQG_class &Gamma_nn ,
							 const class RDM_PQG_class &Gamma_pn)
{  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	const class array<TYPE> prot_OBMEs_nuclear = prot_OBMEs_inter_set(ONE_BODY_NUCLEAR);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_nuclear;

	const TYPE Hp_nuclear_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.nuclear[one-body]|PSI>: " << Hp_nuclear_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> neut_OBMEs_nuclear = neut_OBMEs_inter_set(ONE_BODY_NUCLEAR);

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_nuclear;

	const TYPE Hn_nuclear_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hn.nuclear[one-body]|PSI>: " << Hn_nuclear_NBME << " MeV" << endl << endl;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      { 
	TBMEs_pn.zero ();

	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_nuclear = prot_OBMEs_inter_set(ONE_BODY_NUCLEAR);
	const class array<TYPE> neut_OBMEs_nuclear = neut_OBMEs_inter_set(ONE_BODY_NUCLEAR);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_nuclear;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	const TYPE Hp_nuclear_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.nuclear[one-body]|PSI>: " << Hp_nuclear_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_nuclear;

	const TYPE Hn_nuclear_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hn.nuclear[one-body]|PSI>: " << Hn_nuclear_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::nuclear_two_body_calc_print (
							 const class input_data_str &input_data , 
							 const int Jn_relative_max , 
							 class interaction_class &inter_data , 
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data , 
							 class TBMEs_class &TBMEs_pn , 
							 const class RDM_PQG_class &Gamma_pp ,
							 const class RDM_PQG_class &Gamma_nn ,
							 const class RDM_PQG_class &Gamma_pn)
{
  const enum space_type space = input_data.get_space ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  const enum interaction_type nuclear_inter = nuclear_inter_determine (TBME_inter);

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  const double TBME_A_dependent_factor = TBME_A_dependent_factor_calc (input_data);
   
  inter_data.zero ();

  if (nuclear_inter == SGI)
    inter_data.SGI_radial_tables_calc ();
  else if ((nuclear_inter == FIT) || is_it_FHT_determine (nuclear_inter) || is_it_EFT_determine (nuclear_inter) ||
	   is_it_Minnesota_determine (nuclear_inter) || (nuclear_inter == REALISTIC_INTERACTION))
    inter_data.TBMEs_HO_lab_no_added_kinetic_part (false , Jn_relative_max , 0 , TBME_A_dependent_factor);
 
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_data);

	const TYPE Vpp_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[two-body]|PSI>: " << Vpp_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_data);

	const TYPE Vnn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[two-body]|PSI>: " << Vnn_NBME << " MeV" << endl << endl; 

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;       
      } break;

    case PROTONS_NEUTRONS:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set () , &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter) , neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	TBMEs_pn.zero ();

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , prot_data);

	    const TYPE Vpp_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
	    
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[two-body]|PSI>: " << Vpp_NBME << " MeV" << endl << endl; 
	    
	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , nuclear_inter , input_data , false , inter_data , neut_data);

	    const TYPE Vnn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[two-body]|PSI>: " << Vnn_NBME << " MeV" << endl << endl; 
	    
	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , nuclear_inter , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const TYPE Vpn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[two-body]|PSI>: " << Vpn_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::nuclear_three_body_calc_print (
							   const class input_data_str &input_data , 
							   class interaction_class &inter_data , 
							   class nucleons_data &prot_data , 
							   class nucleons_data &neut_data , 
							   class TBMEs_class &TBMEs_pn , 
							   const class RDM_PQG_class &Gamma_pp ,
							   const class RDM_PQG_class &Gamma_nn ,
							   const class RDM_PQG_class &Gamma_pn)
{ 
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();

  if (!is_it_Minnesota_determine (TBME_inter)) return;

  const enum space_type space = input_data.get_space ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  inter_data.zero ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();  

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_data);

	const TYPE Vpp_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[three-body]|PSI>: " << Vpp_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      {
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_data);

	const TYPE Vnn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[three-body]|PSI>: " << Vnn_NBME << " MeV" << endl << endl; 

	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;

    case PROTONS_NEUTRONS:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_three_body_like_add ();

	TBMEs_pn.zero ();

	if (Zval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , prot_data);

	    const TYPE Vpp_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
	    
	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.nuclear[three-body]|PSI>: " << Vpp_NBME << " MeV" << endl << endl; 
	    
	    TBMEs_prot.zero ();
	  }

	if (Nval >= 2)
	  {
	    coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , false , inter_data , neut_data);

	    const TYPE Vnn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	    if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hnn.nuclear[three-body]|PSI>: " << Vnn_NBME << " MeV" << endl << endl; 
	    
	    TBMEs_neut.zero ();
	  }

	coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , TBME_inter , input_data , prot_data , neut_data , false , inter_data , TBMEs_pn);

	const TYPE Vpn_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpn.nuclear[three-body]|PSI>: " << Vpn_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::Coulomb_one_body_calc_print (	
							 const enum space_type space ,
							 const class interaction_class &inter_data ,
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data , 
							 class TBMEs_class &TBMEs_pn , 
							 const class RDM_PQG_class &Gamma_pp ,
							 const class RDM_PQG_class &Gamma_nn ,
							 const class RDM_PQG_class &Gamma_pn)
{ 
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();
  
  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter) , prot_OBMEs_Coulomb = prot_OBMEs_inter_set(ONE_BODY_COULOMB);

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_Coulomb;

	const TYPE Hp_Coulomb_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.Coulomb[one-body]|PSI>: " << Hp_Coulomb_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: break;

    case PROTONS_NEUTRONS: 
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);

	const class array<TYPE> prot_OBMEs_Coulomb = prot_OBMEs_inter_set(ONE_BODY_COULOMB);

	TBMEs_pn.zero ();

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_Coulomb;

	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	const TYPE Hp_Coulomb_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hp.Coulomb[one-body]|PSI>: " << Hp_Coulomb_NBME << " MeV" << endl << endl;

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::Coulomb_two_body_calc_print (
							 const class input_data_str &input_data , 
							 const int Jc_relative_max , 
							 class interaction_class &inter_data , 
							 class nucleons_data &prot_data , 
							 class nucleons_data &neut_data , 
							 class TBMEs_class &TBMEs_pn , 
							 const class RDM_PQG_class &Gamma_pp ,
							 const class RDM_PQG_class &Gamma_nn ,
							 const class RDM_PQG_class &Gamma_pn)
{
  const enum space_type space = input_data.get_space ();
  
  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  class TBMEs_class &TBMEs_prot = prot_data.get_TBMEs ();
  class TBMEs_class &TBMEs_neut = neut_data.get_TBMEs ();
  
  if (Zval == 1) return;

  inter_data.zero ();
  
  if (Zval >= 2) TBMEs_prot.zero ();
  if (Nval >= 2) TBMEs_neut.zero ();  

  switch (space)
    {
    case PROTONS_ONLY:
      {
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	
	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_data);

	const TYPE Vpp_Coulomb_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.Coulomb[two-body]|PSI>: " << Vpp_Coulomb_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
      } break;

    case NEUTRONS_ONLY: 
      break;

    case PROTONS_NEUTRONS: 
      { 
	class OBMEs_inter_set_str &prot_OBMEs_inter_set = prot_data.get_OBMEs_inter_set ();
	class OBMEs_inter_set_str &neut_OBMEs_inter_set = neut_data.get_OBMEs_inter_set ();

	const class array<TYPE> prot_OBMEs_inter = prot_OBMEs_inter_set(TBME_inter);
	const class array<TYPE> neut_OBMEs_inter = neut_OBMEs_inter_set(TBME_inter);
	
	prot_OBMEs_inter_set(TBME_inter) = 0.0;
	neut_OBMEs_inter_set(TBME_inter) = 0.0;

	TBMEs_pn.zero ();

	inter_data.TBMEs_HO_Coulomb_lab_add (Jc_relative_max);

	coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , REALISTIC_INTERACTION , input_data , false , inter_data , prot_data);

	const TYPE Vpp_Coulomb_NBME = average_E_calc (false , TBME_inter , 0.0 , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	if (THIS_PROCESS == MASTER_PROCESS) cout << "<PSI|Hpp.Coulomb[two-body]|PSI>: " << Vpp_Coulomb_NBME << " MeV" << endl << endl; 

	prot_OBMEs_inter_set(TBME_inter) = prot_OBMEs_inter;
	neut_OBMEs_inter_set(TBME_inter) = neut_OBMEs_inter;  
      } break;
      
    default: abort_all ();
    }
}

void RDM_Hamiltonian_parts::calc_print (
					const class input_data_str &input_data , 
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn ,
					class interaction_class &inter_data , 
					class nucleons_data &prot_data ,
					class nucleons_data &neut_data , 
					class TBMEs_class &TBMEs_pn)
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Hamiltonian parts" << endl;
      cout <<         "-----------------" << endl << endl;
    }

  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();
  
  const enum space_type space = input_data.get_space ();

  const enum interaction_type TBME_inter = inter_data.get_TBME_inter ();
  
  const int Jn_relative_max = input_data.get_Jn_relative_max ();
  const int Jc_relative_max = input_data.get_Jc_relative_max ();

  const unsigned int eigenstates_number = input_data.get_Hamiltonian_parts_eigenstates_number ();

  const class array<unsigned int > &RDM_Hamiltonian_parts_BP_tab = input_data.get_Hamiltonian_parts_BP_tab ();

  const class array<double > &RDM_Hamiltonian_parts_J_tab = input_data.get_Hamiltonian_parts_J_tab ();

  const class array<unsigned int > &RDM_Hamiltonian_parts_vector_index_tab = input_data.get_Hamiltonian_parts_vector_index_tab ();

  const enum potential_type H_potential = prot_data.get_H_potential ();

  const int Z_charge_basis_potential = prot_data.get_Z_charge_basis_potential ();
  
  for (unsigned int eigenstates_index = 0 ; eigenstates_index < eigenstates_number ; eigenstates_index++)
    {
      const unsigned int BP = RDM_Hamiltonian_parts_BP_tab(eigenstates_index);

      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_Hamiltonian_parts::calc_print");
      
      const unsigned int vector_index = RDM_Hamiltonian_parts_vector_index_tab(eigenstates_index);

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_Hamiltonian_parts::calc_print");
      
      const double J = RDM_Hamiltonian_parts_J_tab(eigenstates_index);

      if (rint (J - RDM_J)!= 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_Hamiltonian_parts::calc_print");
            
      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << endl << endl;

      if ((H_potential != WS) || (space == NEUTRONS_ONLY) || (Z_charge_basis_potential == 0))
	{
	  kinetic_one_body_calc_print (space , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	}

      kinetic_recoil_calc_print (input_data , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

      nuclear_one_body_calc_print (space , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

      nuclear_two_body_calc_print (input_data , Jn_relative_max , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;

      if (is_it_Minnesota_determine (TBME_inter))
	{
	  nuclear_three_body_calc_print (input_data , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	}

      if (H_potential != WS)
	{
	  Coulomb_one_body_calc_print (space , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	}

      if (space == PROTONS_ONLY)
	{
	  Coulomb_two_body_calc_print (input_data , Jc_relative_max , inter_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);

	  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	}

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
    }
  
  inter_data.inter_data_calc (input_data);
  
  if (space != NEUTRONS_ONLY) coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , true , inter_data , prot_data);
  if (space != PROTONS_ONLY)  coupled_TBMEs::Berggren::TBMEs_pp_nn_calc (false , TBME_inter , input_data , true , inter_data , neut_data);

  if (space == PROTONS_NEUTRONS) coupled_TBMEs::Berggren::TBMEs_pn_calc (false , false , TBME_inter , input_data , prot_data , neut_data , true , inter_data , TBMEs_pn);
}


