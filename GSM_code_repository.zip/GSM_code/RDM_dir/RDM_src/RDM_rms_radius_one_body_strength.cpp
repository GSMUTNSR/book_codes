#include "../RDM_include/RDM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace rms_radius_one_body_strength_OBMEs;
using namespace correlated_state_routines;
using namespace RDM_rho_observables;



void RDM_rms_radius_one_body_strength::calc_one_strength (
							  const enum space_type space , 
							  const enum operator_type rms_radius_operator , 
							  const bool is_it_Gauss_Legendre ,
							  const class RDM_PQG_class &Gamma_pp ,
							  const class RDM_PQG_class &Gamma_nn ,
							  const class RDM_PQG_class &Gamma_pn ,
							  const class nucleons_data &prot_data ,
							  const class nucleons_data &neut_data ,
							  class array<TYPE> &rms_radius_one_body_strength_tab)
{  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();
  
  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
  
  const double mp = prot_data.get_effective_mass_for_calc ();
  const double mn = neut_data.get_effective_mass_for_calc ();

  class array<TYPE> OBMEs_prot(Np_nlj , Np_nlj , Nr);
  class array<TYPE> OBMEs_neut(Nn_nlj , Nn_nlj , Nr);

  if (space != NEUTRONS_ONLY)
    {
      const double factor_prot = rms_radius_one_body_factor_calc (rms_radius_operator , PROTON , mp , mn , Z , N);
  
      OBMEs_shells_calc (factor_prot , is_it_Gauss_Legendre , prot_data , OBMEs_prot);
    }
  
  if (space != PROTONS_ONLY)
    {
      const double factor_neut = rms_radius_one_body_factor_calc (rms_radius_operator , NEUTRON , mp , mn , Z , N);
  
      OBMEs_shells_calc (factor_neut , is_it_Gauss_Legendre , neut_data , OBMEs_neut);
    }
 
  class array<TYPE> prot_rms_radius_one_body_strength_tab(Nr);
  class array<TYPE> neut_rms_radius_one_body_strength_tab(Nr);
 
  scalar_strength_calc (OBMEs_prot ,  OBMEs_neut ,  prot_data , neut_data ,  Gamma_pp , Gamma_nn , Gamma_pn , prot_rms_radius_one_body_strength_tab , neut_rms_radius_one_body_strength_tab);

  rms_radius_one_body_strength_tab = prot_rms_radius_one_body_strength_tab + neut_rms_radius_one_body_strength_tab;
}










void RDM_rms_radius_one_body_strength::calc_store_one_strength (
								const enum space_type space ,
								const enum operator_type rms_radius_operator , 
								const bool is_it_Gauss_Legendre ,
								const class array<double> &r_bef_R_tab ,
								const class correlated_state_str &PSI_qn , 
								const class RDM_PQG_class &Gamma_pp ,
								const class RDM_PQG_class &Gamma_nn ,
								const class RDM_PQG_class &Gamma_pn ,
								const class nucleons_data &prot_data ,
								const class nucleons_data &neut_data)
{
  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();

  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  class array<TYPE> rms_radius_one_body_strength(Nr);

  calc_one_strength (space , rms_radius_operator , is_it_Gauss_Legendre , Gamma_pp , Gamma_nn , Gamma_pn , prot_data , neut_data , rms_radius_one_body_strength);

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

      const string particle_str = (rms_radius_operator == RMS_RADIUS_PROTON) ? ("proton") : ("neutron");

      const string rms_radius_one_body_strength_string = "rms_radius_one_body_strength_" + particle_str + "_" + PSI_qn_string + ".dat";

      ofstream rms_radius_one_body_strength_file(rms_radius_one_body_strength_string.c_str() , ios::out);

      rms_radius_one_body_strength_file.precision (15);

      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const double r = r_bef_R_tab(i);
	  
#ifdef TYPEisDOUBLECOMPLEX
	  rms_radius_one_body_strength_file << r << " " << real (rms_radius_one_body_strength(i)) << " " << imag (rms_radius_one_body_strength(i)) << endl;
#endif

#ifdef TYPEisDOUBLE
	  rms_radius_one_body_strength_file << r << " " << rms_radius_one_body_strength(i) << endl;
#endif	  
	}

      rms_radius_one_body_strength_file.close ();
    }
}






void RDM_rms_radius_one_body_strength::calc_store (
						   const class input_data_str &input_data , 
						   class nucleons_data &prot_data , 
						   class nucleons_data &neut_data ,
						   const class RDM_PQG_class &Gamma_pp ,
						   const class RDM_PQG_class &Gamma_nn ,
						   const class RDM_PQG_class &Gamma_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radius one-body strengths" << endl;
      cout <<         "-----------------------------" << endl << endl;
    }

  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();
  
  const enum space_type space = input_data.get_space ();
  
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();

  const unsigned int rms_radius_one_body_strength_number = input_data.get_rms_radius_one_body_strength_number ();

  const class array<unsigned int> &rms_radius_one_body_strength_BP_tab = input_data.get_rms_radius_one_body_strength_BP_tab ();
  
  const class array<double> &rms_radius_one_body_strength_J_tab = input_data.get_rms_radius_one_body_strength_J_tab ();

  const class array<unsigned int> &rms_radius_one_body_strength_vector_index_tab = input_data.get_rms_radius_one_body_strength_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_one_body_strength_particle_tab = input_data.get_rms_radius_one_body_strength_particle_tab ();

  const class array<bool> &rms_radius_one_body_strength_is_it_Gauss_Legendre_tab = input_data.get_rms_radius_one_body_strength_is_it_Gauss_Legendre_tab ();

  const unsigned int N_bef_R_GL = input_data.get_N_bef_R_GL ();

  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const double R = input_data.get_R ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  for (unsigned int rms_radius_one_body_strength_index = 0 ; rms_radius_one_body_strength_index < rms_radius_one_body_strength_number ; rms_radius_one_body_strength_index++)
    {
      const enum particle_type particle = rms_radius_one_body_strength_particle_tab[rms_radius_one_body_strength_index];

      const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);

      const bool is_it_Gauss_Legendre = rms_radius_one_body_strength_is_it_Gauss_Legendre_tab[rms_radius_one_body_strength_index];

      const unsigned int BP = rms_radius_one_body_strength_BP_tab[rms_radius_one_body_strength_index];
      
      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_rms_radius_one_body_strength::calc_print");

      const unsigned int vector_index = rms_radius_one_body_strength_vector_index_tab[rms_radius_one_body_strength_index];

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_rms_radius_one_body_strength::calc_print");

      const double J = rms_radius_one_body_strength_J_tab[rms_radius_one_body_strength_index];

      if (rint (J - RDM_J)!= 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_rms_radius_one_body_strength::calc_print");
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      const class correlated_state_str PSI_qn(Z , N , BP , J , vector_index , NADA , NADA , NADA , NADA , false);
	  
      calc_store_one_strength (space , rms_radius_operator , is_it_Gauss_Legendre , r_bef_R_tab , PSI_qn , Gamma_pp , Gamma_nn , Gamma_pn , prot_data , neut_data);

      if (THIS_PROCESS == MASTER_PROCESS) cout << "particle: " << particle << " rms radius one-body strength of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated." << endl;
    }
}


