#include "../RDM_include/RDM_include_def.h"






RDM_T2_prime_gradient_class::RDM_T2_prime_gradient_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL) ,
  T2_prime_ptr (NULL) {}




RDM_T2_prime_gradient_class::RDM_T2_prime_gradient_class (
							  const class RDM_T2_prime_class &T2_prime ,
							  const class nucleons_data &prot_data ,
							  const class nucleons_data &neut_data ,
							  const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 ,
							  const class array<double> &rho_prot_der_pp_tab ,
							  const class array<double> &rho_prot_der_pn_tab ,
							  const class array<double> &rho_neut_der_nn_tab ,
							  const class array<double> &rho_neut_der_pn_tab ,
							  const class RDM_PQG_class &Gamma_pp ,
							  const class RDM_PQG_class &Gamma_nn ,
							  const class RDM_PQG_class &Gamma_pn) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL) ,
  T2_prime_ptr (NULL)
{
  alloc_calc_store (T2_prime , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , Gamma_pp , Gamma_nn , Gamma_pn);
}






void RDM_T2_prime_gradient_class::alloc_calc_store (
						    const class RDM_T2_prime_class &T2_prime ,
						    const class nucleons_data &prot_data ,
						    const class nucleons_data &neut_data ,
						    const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 ,
						    const class array<double> &rho_prot_der_pp_tab ,
						    const class array<double> &rho_prot_der_pn_tab ,
						    const class array<double> &rho_neut_der_nn_tab ,
						    const class array<double> &rho_neut_der_pn_tab ,
						    const class RDM_PQG_class &Gamma_pp ,
						    const class RDM_PQG_class &Gamma_nn ,
						    const class RDM_PQG_class &Gamma_pn)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T2_prime_gradient_class cannot be allocated twice in RDM_T2_prime_gradient_class::allocate");
    
  space_pair = T2_prime.get_space_pair ();
  
  last_particle = T2_prime.get_last_particle ();
    
  prot_data_ptr = &prot_data;
  neut_data_ptr = &neut_data;
  
  Wigner_9j_hats_T2_ptr = &Wigner_9j_hats_T2;
  
  rho_prot_der_pp_tab_ptr = &rho_prot_der_pp_tab; 
  rho_prot_der_pn_tab_ptr = &rho_prot_der_pn_tab;  
  rho_neut_der_nn_tab_ptr = &rho_neut_der_nn_tab;   
  rho_neut_der_pn_tab_ptr = &rho_neut_der_pn_tab;  
    
  Gamma_pp_ptr = &Gamma_pp;
  Gamma_nn_ptr = &Gamma_nn;
  Gamma_pn_ptr = &Gamma_pn;

  T2_prime_ptr = &T2_prime;
      
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
  
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);    
  
  const unsigned int dimension_pp_BP_J_max =  matrix_dimensions_pp.max ();
  const unsigned int dimension_nn_BP_J_max =  matrix_dimensions_nn.max ();
  const unsigned int dimension_pn_BP_J_max =  matrix_dimensions_pn.max ();
  
  const unsigned int triangular_sup_pp_MEs_number_max = (dimension_pp_BP_J_max%2 == 0) ? ((dimension_pp_BP_J_max/2)*(dimension_pp_BP_J_max + 1)) : (dimension_pp_BP_J_max*((dimension_pp_BP_J_max + 1)/2));
  const unsigned int triangular_sup_nn_MEs_number_max = (dimension_nn_BP_J_max%2 == 0) ? ((dimension_nn_BP_J_max/2)*(dimension_nn_BP_J_max + 1)) : (dimension_nn_BP_J_max*((dimension_nn_BP_J_max + 1)/2));
  const unsigned int triangular_sup_pn_MEs_number_max = (dimension_pn_BP_J_max%2 == 0) ? ((dimension_pn_BP_J_max/2)*(dimension_pn_BP_J_max + 1)) : (dimension_pn_BP_J_max*((dimension_pn_BP_J_max + 1)/2));
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == PROTON))
    {
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , J_total_number);
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T2_prime_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
      T2_prime_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
      
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
      
      T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store ();
    }
  else if ((space_pair == NEUTRONS_ONLY) && (last_particle == NEUTRON))
    {
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , J_total_number);
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T2_prime_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
      T2_prime_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
      
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
      
      T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store ();	
    }
  else
    {
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , J_total_number);
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , J_total_number);
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T2_prime_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
      T2_prime_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
      T2_prime_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
	
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;

      T2_prime_ppn_pnn_pnp_nnp_gradient_block_matrices_alloc_calc_store ();
    }
  
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp.deallocate ();
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn.deallocate ();
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn.deallocate ();
    
  rho_prot_der_pp_tab_ptr = NULL;
  rho_prot_der_pn_tab_ptr = NULL;
  rho_neut_der_nn_tab_ptr = NULL;
  rho_neut_der_pn_tab_ptr = NULL;
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_9j_hats_T2_ptr = NULL;
  
  Gamma_pp_ptr = NULL;
  Gamma_nn_ptr = NULL;
  Gamma_pn_ptr = NULL;

  T2_prime_ptr = NULL;
}


RDM_T2_prime_gradient_class::RDM_T2_prime_gradient_class (const class RDM_T2_prime_gradient_class &X)
{
  allocate_fill (X);
}

RDM_T2_prime_gradient_class::~RDM_T2_prime_gradient_class () {}





void RDM_T2_prime_gradient_class::allocate_fill (const class RDM_T2_prime_gradient_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T2_prime_gradient_class cannot be allocated twice in RDM_T2_prime_gradient_class::allocate_fill");
  
  T2_prime_gradient_block_matrices_pp.allocate_fill_object_elements (X.T2_prime_gradient_block_matrices_pp);
  T2_prime_gradient_block_matrices_nn.allocate_fill_object_elements (X.T2_prime_gradient_block_matrices_nn);
  T2_prime_gradient_block_matrices_pn.allocate_fill_object_elements (X.T2_prime_gradient_block_matrices_pn);
  
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}



void RDM_T2_prime_gradient_class::deallocate ()
{  
  T2_prime_gradient_block_matrices_pp.deallocate ();
  T2_prime_gradient_block_matrices_nn.deallocate ();
  T2_prime_gradient_block_matrices_pn.deallocate ();
    
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
}


void RDM_T2_prime_gradient_class::operator = (const class RDM_T2_prime_gradient_class &X)
{
  T2_prime_gradient_block_matrices_pp = X.T2_prime_gradient_block_matrices_pp;
  T2_prime_gradient_block_matrices_nn = X.T2_prime_gradient_block_matrices_nn;
  T2_prime_gradient_block_matrices_pn = X.T2_prime_gradient_block_matrices_pn;
  
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}




void RDM_T2_prime_gradient_class::rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
											  const enum particle_type particle ,
											  const unsigned int BP ,
											  const int iJ ,
											  const unsigned int s0 ,
											  const unsigned int s1)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_pair_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T2_prime_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
      
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {			    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pair_tab(s0 , sp);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pair_tab(s1 , sp);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pair_table(s0 , sp);

      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);
      
      const int Jmin_s0_sp = Jmin_pair_table(s0 , sp) , Jmin_s1_sp = Jmin_pair_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pair_table(s0 , sp) , Jmax_s1_sp = Jmax_pair_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
            
      const bool are_s0_sp_equal = (s0 == sp);
      const bool are_s1_sp_equal = (s1 == sp);
              
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
      
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);
      
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	    }
	}
    }
}

void RDM_T2_prime_gradient_class::rho_term_der_pp_nn_fill_part (
								const enum particle_type particle ,
								const unsigned int BP ,
								const int iJ ,
								const unsigned int abc_index ,
								const unsigned int def_index ,
								const int ij01 ,
								const unsigned int s0 ,
								const unsigned int s1 ,
								const double factor)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<double> &rho_der_tab = (particle == PROTON) ? (get_rho_prot_der_pp_tab ()) : (get_rho_neut_der_nn_tab ());
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_pair_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T2_prime_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
  
  class array<class block_sparse_matrix<TYPE> > &T2_prime_gradient_block_matrices_pp_nn = get_T2_prime_gradient_block_matrices (Gamma_space);
    
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {		    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pair_tab(s0 , sp);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pair_tab(s1 , sp);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pair_table(s0 , sp);

      const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
      const int ijp = shell_qn_sp.get_ij ();
      
      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);
      
      const int Jmin_s0_sp = Jmin_pair_table(s0 , sp) , Jmin_s1_sp = Jmin_pair_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pair_table(s0 , sp) , Jmax_s1_sp = Jmax_pair_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
            
      const bool are_s0_sp_equal = (s0 == sp) , is_s0_smaller_than_sp = (s0 <= sp);
      const bool are_s1_sp_equal = (s1 == sp) , is_s1_smaller_than_sp = (s1 <= sp);
       
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
      
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);
      			
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      const int phase_s0_sp = (is_s0_smaller_than_sp) ? (1) : (((ij01 + ijp + Jp)%2 == 0) ? (1) : (-1));
	      const int phase_s1_sp = (is_s1_smaller_than_sp) ? (1) : (((ij01 + ijp + Jp)%2 == 0) ? (1) : (-1));
	      	      	  
	      const double rho_der_ME = rho_der_tab(Jp , s0 , sp , s1);
      
	      const double gradient_ME = (phase_s0_sp == phase_s1_sp) ? (factor*rho_der_ME) : (-factor*rho_der_ME);
	      	      
	      class block_sparse_matrix<TYPE> &T2_prime_gradient_block_matrix = T2_prime_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	      class sparse_matrix<TYPE> &T2_prime_gradient_matrix = T2_prime_gradient_block_matrix(BP + 2*iJ);
      
	      unsigned short int &ip_jp_index = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	      
	      T2_prime_gradient_matrix.get_row_index      (ip_jp_index) = abc_index;
	      T2_prime_gradient_matrix.get_column_index   (ip_jp_index) = def_index;
	      T2_prime_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;

	      ip_jp_index++;
	    }
	}
    }
}

  


void RDM_T2_prime_gradient_class::rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
											    const unsigned int BP ,
											    const int iJ ,
											    const unsigned int s0_p ,
											    const unsigned int s1_p)
{
  const class nucleons_data &neut_data = get_neut_data ();
    
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  

  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			   
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(s1_p , sp_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_pair_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_pair_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	}
    }
}




void RDM_T2_prime_gradient_class::rho_prot_term_der_pn_fill_part (
								  const unsigned int BP ,
								  const int iJ ,
								  const unsigned int abc_index ,
								  const unsigned int def_index ,
								  const unsigned int s0_p ,
								  const unsigned int s1_p ,
								  const double factor)
{
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<double> &rho_prot_der_pn_tab = get_rho_prot_der_pn_tab ();
  
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {		
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(s1_p , sp_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_pair_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_pair_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      	
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_prot_der_pn_tab(Jp , s0_p , sp_n , s1_p);
	  
	  class block_sparse_matrix<TYPE> &T2_prime_gradient_block_matrix_pn = T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &T2_prime_gradient_matrix_pn = T2_prime_gradient_block_matrix_pn(BP + 2*iJ);
      
	  unsigned short int &ip_jp_index = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
			  
	  T2_prime_gradient_matrix_pn.get_row_index      (ip_jp_index) = abc_index;
	  T2_prime_gradient_matrix_pn.get_column_index   (ip_jp_index) = def_index;
	  T2_prime_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }
}



void RDM_T2_prime_gradient_class::rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
											    const unsigned int BP ,
											    const int iJ ,
											    const unsigned int s0_n ,
											    const unsigned int s1_n)
{
  const class nucleons_data &prot_data = get_prot_data ();
    
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {		
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(sp_p , s1_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_pair_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_pair_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	}
    }
}




void RDM_T2_prime_gradient_class::rho_neut_term_der_pn_fill_part (
								  const unsigned int BP ,
								  const int iJ ,
								  const unsigned int abc_index ,
								  const unsigned int def_index ,
								  const unsigned int s0_n ,
								  const unsigned int s1_n ,
								  const double factor)
{
  const class nucleons_data &prot_data = get_prot_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<double> &rho_neut_der_pn_tab = get_rho_neut_der_pn_tab ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(sp_p , s1_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_pair_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_pair_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
	  
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_neut_der_pn_tab(Jp , s0_n , sp_p , s1_n);
	        
	  unsigned short int &ip_jp_index = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	      
	  class block_sparse_matrix<TYPE> &T2_prime_gradient_block_matrix_pn = T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &T2_prime_gradient_matrix_pn = T2_prime_gradient_block_matrix_pn(BP + 2*iJ);
	  
	  T2_prime_gradient_matrix_pn.get_row_index      (ip_jp_index) = abc_index;
	  T2_prime_gradient_matrix_pn.get_column_index   (ip_jp_index) = def_index;
	  T2_prime_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }     
}



void RDM_T2_prime_gradient_class::rho_term_der_part_determine (
							       const enum operation_type operation ,
							       const unsigned int BP ,
							       const int iJ ,
							       const unsigned int abc_index ,
							       const unsigned int def_index ,
							       const enum particle_type particle ,
							       const int ij01 ,
							       const unsigned int s0 , 
							       const unsigned int s1 ,
							       const double factor)
{
  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      {
	rho_term_der_pp_nn_non_trivial_zero_numbers_increments (particle , BP , iJ , s0 , s1);

	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_non_trivial_zero_numbers_increments (BP , iJ , s0 , s1); break;
	  case NEUTRON: rho_neut_term_der_pn_non_trivial_zero_numbers_increments (BP , iJ , s0 , s1); break;

	  default: abort_all ();
	  }
							    
      } break;

    case TABLES_FILL:
      {
	rho_term_der_pp_nn_fill_part (particle , BP , iJ , abc_index , def_index , ij01 , s0 , s1 , factor);
							    
	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_fill_part (BP , iJ , abc_index , def_index , s0 , s1 , factor); break;
	  case NEUTRON: rho_neut_term_der_pn_fill_part (BP , iJ , abc_index , def_index , s0 , s1 , factor); break;
								
	  default: abort_all ();
	  }
							    
      } break;

    default: abort_all ();
    }
}








void RDM_T2_prime_gradient_class::T2_prime_Gamma_term_der_part_determine (
									  const enum operation_type operation ,
									  const enum space_type Gamma_space , 
									  const unsigned int BP ,
									  const int iJ ,
									  const unsigned int abc_index ,
									  const unsigned int def_index ,
									  const unsigned int BPp ,
									  const int Jp ,
									  const unsigned int ip ,
									  const unsigned int jp ,
									  const double gradient_ME)
{
  const unsigned int ip_jp_min = min (ip , jp);
  const unsigned int ip_jp_max = max (ip , jp);
	      
  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);

  class array<unsigned short int> &T2_prime_gradient_block_matrices_non_trivial_zero_numbers_local = get_T2_prime_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
  
  switch (operation)
    {	    
    case DIMENSIONS_TABLES_CALC:
      {
	T2_prime_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
							    
      } break;

    case TABLES_FILL:
      {
	class array<class block_sparse_matrix<TYPE> > &T2_prime_gradient_block_matrices_local = get_T2_prime_gradient_block_matrices (Gamma_space);
	
	class block_sparse_matrix<TYPE> &T2_prime_gradient_block_matrix = T2_prime_gradient_block_matrices_local(BPp , Jp , ip_jp_upper_triangular_index);
	
	class sparse_matrix<TYPE> &T2_prime_gradient_matrix = T2_prime_gradient_block_matrix(BP + 2*iJ);
						
	unsigned short int &ip_jp_index = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
					
	T2_prime_gradient_matrix.get_row_index      (ip_jp_index) = abc_index;
	T2_prime_gradient_matrix.get_column_index   (ip_jp_index) = def_index;
	T2_prime_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;

	ip_jp_index++;
							    							    
      } break;

    default: abort_all ();
    }
}






void RDM_T2_prime_gradient_class::T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (
											       const enum operation_type operation ,
											       const enum space_type Gamma_space , 
											       const class array<unsigned int> &two_states_indices ,
											       const unsigned int BP ,
											       const int iJ ,
											       const unsigned int abc_index ,
											       const unsigned int def_index ,
											       const bool sa_sd_jb_je_equal ,
											       const bool sb_se_ja_jd_equal ,
											       const bool sa_se_jb_jd_equal ,
											       const bool sb_sd_ja_je_equal ,
											       const bool sc_sf_equal ,
											       const bool jc_jf_equal ,
											       const unsigned int BP_ab ,
											       const int Jab ,
											       const unsigned int ab_index ,
											       const int ijc ,
											       const double inv_delta_norm_ab , 
											       const double inv_delta_norm_phase_ab ,
											       const double inv_delta_norm_de ,
											       const unsigned int sc ,
											       const unsigned int sd ,
											       const unsigned int se ,
											       const unsigned int sf)
{
  const bool ad_be_jc_jf_equal = (sa_sd_jb_je_equal && sb_se_ja_jd_equal && jc_jf_equal);
  const bool ae_bd_jc_jf_equal = (sa_se_jb_jd_equal && sb_sd_ja_je_equal && jc_jf_equal);
  
  const double factor_ad_be_jc_jf = (ad_be_jc_jf_equal) ? (inv_delta_norm_de*inv_delta_norm_ab)       : (NADA);
  const double factor_ae_bd_jc_jf = (ae_bd_jc_jf_equal) ? (inv_delta_norm_de*inv_delta_norm_phase_ab) : (NADA);
    
  if (ad_be_jc_jf_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijc , sc , sf , factor_ad_be_jc_jf);
  if (ae_bd_jc_jf_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijc , sc , sf , factor_ae_bd_jc_jf);
  
  if (sc_sf_equal)
    {  
      const unsigned int de_index = two_states_indices(Jab , sd , se);
      
      T2_prime_Gamma_term_der_part_determine (operation , Gamma_space , BP , iJ , abc_index , def_index , BP_ab , Jab , ab_index , de_index , 1.0);
    }
}








// sab is sa or sb, sed is se or sd in function names.
// s0 is sa or sb.
// s1 is sb or sa.
// s2 is sd or se.
// s3 is se or sd.

void RDM_T2_prime_gradient_class::T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (
											    const enum operation_type operation , 
											    const enum space_type Gamma_space , 
											    const class array<unsigned int> &two_states_indices ,
											    const unsigned int BP ,
											    const int iJ ,
											    const unsigned int abc_index ,
											    const unsigned int def_index ,
											    const double inv_delta_norm_phase_ab ,
											    const double inv_delta_norm_de ,
											    const double inv_delta_norm_sc_s2 ,
											    const double inv_delta_norm_sf_s1 ,
											    const int phase_sab_sde , 
											    const int Jmin_sc_s2 , 
											    const int Jmax_sc_s2 , 
											    const int Jmin_sf_s1 , 
											    const int Jmax_sf_s1 , 
											    const unsigned int BP_sc_s2 ,
											    const int Jab ,
											    const int Jde ,
											    const int ij_s0 ,
											    const int ij_s1 ,
											    const int ijc ,
											    const int ij_s2 ,
											    const int ijf , 
											    const bool are_scf_proton_s12_neutron ,
											    const bool are_scf_neutron_s12_proton ,
											    const unsigned int s1 ,
											    const unsigned int sc ,
											    const unsigned int s2 ,
											    const unsigned int sf)
{
  const int Jmin_pair = max (Jmin_sc_s2 , Jmin_sf_s1);
  const int Jmax_pair = min (Jmax_sc_s2 , Jmax_sf_s1);

  if (Jmin_pair > Jmax_pair) return;
  
  const bool scf_s_same_particle = (!are_scf_proton_s12_neutron && !are_scf_neutron_s12_proton);
  
  const bool are_sc_s2_equal = (scf_s_same_particle && (sc == s2));
  const bool are_sf_s1_equal = (scf_s_same_particle && (sf == s1));

  const bool sc_s2_different_sf_s1_different = (!are_sc_s2_equal && !are_sf_s1_equal);
  
  const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 = get_Wigner_9j_hats_T2 ();
  
  const bool is_sc_smaller_than_s2 = is_sa_smaller_than_sb_determine (are_scf_proton_s12_neutron , are_scf_neutron_s12_proton , sc , s2);
  const bool is_sf_smaller_than_s1 = is_sa_smaller_than_sb_determine (are_scf_proton_s12_neutron , are_scf_neutron_s12_proton , sf , s1);
        
  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
    {	
      const bool is_J_pair_even = (J_pair%2 == 0);

      if (sc_s2_different_sf_s1_different || is_J_pair_even)
	{				  
	  const unsigned int sc_s2_index = (is_sc_smaller_than_s2) ? (two_states_indices(J_pair , sc , s2)) : (two_states_indices(J_pair , s2 , sc));
	  const unsigned int sf_s1_index = (is_sf_smaller_than_s1) ? (two_states_indices(J_pair , sf , s1)) : (two_states_indices(J_pair , s1 , sf));

	  const int phase_sc_s2 = (is_sc_smaller_than_s2) ? (1) : (((ijc + ij_s2 + J_pair)%2 == 0) ? (1) : (-1));
	  const int phase_sf_s1 = (is_sf_smaller_than_s1) ? (1) : (((ijf + ij_s1 + J_pair)%2 == 0) ? (1) : (-1));
	  
	  const double Wigner_9j_hats = (operation == TABLES_FILL) ? (Wigner_9j_hats_T2(ij_s1 , ij_s0 , ijc , ij_s2 , ijf , Jab , J_pair , Jde , iJ)) : (NADA);
	  
	  const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (-Wigner_9j_hats*inv_delta_norm_phase_ab*inv_delta_norm_de*phase_sab_sde/inv_delta_norm_sc_s2/inv_delta_norm_sf_s1) : (NADA);
	  
	  const double gradient_ME = (phase_sc_s2 == phase_sf_s1) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
	  
	  T2_prime_Gamma_term_der_part_determine (operation , Gamma_space , BP , iJ , abc_index , def_index , BP_sc_s2 , J_pair , sc_s2_index , sf_s1_index , gradient_ME);
	}
    }
}






void RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store (
												  const enum operation_type operation , 
												  const unsigned int BP ,
												  const int iJ)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store(no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store(no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store(no nn + p)");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &T2_matrix_dimensions = T2_prime.get_T2_matrix_dimensions ();
  
  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	{	
	  if (!is_it_in_space_tab(sa , sb , sc)) continue;
		  
	  const unsigned int BP_abc = BP_table(sa , sb , sc);

	  if (BP_abc == BP)
	    {
	      const bool are_sa_sb_equal = (sa == sb);
	
	      const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  		
	      const unsigned int ijc = shell_qn_sc.get_ij ();
			  			  	  		      
	      const unsigned int BP_ab = BP_pair_table(sa , sb);
			  
	      const int Jmin_ab = Jmin_pair_table(sa , sb);
	      const int Jmax_ab = Jmax_pair_table(sa , sb);
			 
	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;	
				  
	      for (unsigned int sg = 0 ; sg < N_nlj ; sg++)
		{		  
		  const class nlj_struct &shell_qn_sg = shells_qn(sg);
		      
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
			
		  if (ijg == iJ)
		    {
		      const unsigned int BP_gc = BP_pair_table(sg , sc);
		      
		      if (BP_gc == BP_ab)
			{		      
			  const double jg = shell_qn_sg.get_j ();

			  const double hat_jg = hat (jg);
						    
			  const double inv_delta_norm_gc = (sc == sg) ? (M_SQRT2) : (1.0);
		      
			  const bool are_sc_sg_equal = (sc == sg);

			  const bool ab_different_cg_different = (!are_sa_sb_equal && !are_sc_sg_equal);
		  
			  const int Jmin_gc = Jmin_pair_table(sg , sc);
			  const int Jmax_gc = Jmax_pair_table(sg , sc);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);
		  
			  const bool is_sg_smaller_than_sc = (sg <= sc);
			  
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const bool is_J_pair_even = (J_pair%2 == 0);
						  
			      if (ab_different_cg_different || is_J_pair_even)
				{
				  const unsigned int ab_index = two_states_indices(J_pair , sa , sb);
			      
				  const unsigned int abc_index = three_states_indices(J_pair , iJ , sa , sb , sc);
		      
				  const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc);
				  const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc);

				  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				    {			      
				      const unsigned int gc_index = (is_sg_smaller_than_sc) ? (two_states_indices(J_pair , sg , sc)) : (two_states_indices(J_pair , sc , sg));

				      const double hat_J_pair = hat (J_pair);
				      
				      const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);
				      
				      const int phase_gc = (is_sg_smaller_than_sc) ? (1) : (((ijg + ijc + J_pair)%2 == 0) ? (1) : (-1));
					  
				      const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (inv_delta_norm_gc*phase_abc*hat_J_pair/hat_jg) : (NADA);
					  
				      const double gradient_ME = (phase_gc == 1) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
					  
				      T2_prime_Gamma_term_der_part_determine (operation , space_pair , BP , iJ , abc_index , two_body_T2_prime_omega_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
				      T2_prime_Gamma_term_der_part_determine (operation , space_pair , BP , iJ , two_body_T2_prime_omega_index , abc_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
					  
				    }}}}
		      
		      two_body_T2_prime_omega_index++;
		      
		    }}}}
		
  unsigned int one_body_T2_prime_omega_index_in = T2_matrix_dimension;
	      
  for (unsigned int sh = 0 ; sh < N_nlj ; sh++)
    {
      const class nlj_struct &shell_qn_sh = shells_qn(sh);

      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
			  
      if (ijh == iJ)
	{
	  unsigned int one_body_T2_prime_omega_index_out = T2_matrix_dimension;
	      
	  for (unsigned int sg = 0 ; sg < N_nlj ; sg++)
	    {	  
	      const class nlj_struct &shell_qn_sg = shells_qn(sg);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
	      
	      const int lg = shell_qn_sg.get_l ();
		  
	      const int ijg = shell_qn_sg.get_ij ();
			  
	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_in  , one_body_T2_prime_omega_index_out , last_particle , ijg , sg , sh , 1.0);
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_out , one_body_T2_prime_omega_index_in  , last_particle , ijg , sg , sh , 1.0);
		    }
		  
		  one_body_T2_prime_omega_index_out++;
		}
	    }
		      
	  one_body_T2_prime_omega_index_in++;
	  
	}
    }
}






void RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_calc_store (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_calc_store (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_calc_store (no nn + p)");
    
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
        
  const double jmax = particles_data.get_jmax ();
      
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
            
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
      
	const bool is_J_smaller_than_jmax = (make_int (J - jmax) <= 0);
       
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	      {	
		if (!is_it_in_space_tab(sa , sb , sc)) continue;

		const unsigned int BP_abc = BP_table(sa , sb , sc);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa == sb);
	
		    const class nlj_struct &shell_qn_sa = shells_qn(sa);
		    const class nlj_struct &shell_qn_sb = shells_qn(sb);
		    const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  			  
		    const int ija = shell_qn_sa.get_ij ();
		    const int ijb = shell_qn_sb.get_ij ();
		    const int ijc = shell_qn_sc.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pair_table(sa , sb);
			  
		    const int Jmin_ab = Jmin_pair_table(sa , sb);
		    const int Jmax_ab = Jmax_pair_table(sa , sb);

		    const double inv_delta_norm_ab = (sa == sb) ? (M_SQRT1_2) : (1.0);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
	      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices(Jab , sa , sb);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa , sb , sc);
			      
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      			  
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  				      
				for (unsigned int se = 0 ; se < N_nlj ; se++)
				  for (unsigned int sd = 0 ; sd <= se ; sd++)
				    for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
				      {
					if (!is_it_in_space_tab(sd , se , sf)) continue;
				      
					const bool sa_sd_equal = (sa == sd) , sa_se_equal = (sa == se);
					const bool sb_sd_equal = (sb == sd) , sb_se_equal = (sb == se);
					const bool sc_sf_equal = (sc == sf);
				      
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd , se , sf);
					      
					    if (BP_def == BP)
					      {
						const class nlj_struct &shell_qn_sd = shells_qn(sd);
						const class nlj_struct &shell_qn_se = shells_qn(se);
						const class nlj_struct &shell_qn_sf = shells_qn(sf);
			  
						const int ijd = shell_qn_sd.get_ij ();
						const int ije = shell_qn_se.get_ij ();
						const int ijf = shell_qn_sf.get_ij ();
							  
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
						const bool jc_jf_equal = (ijc == ijf);
							  
						const bool are_sd_se_equal = (sd == se);
		    
						const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
						
						const unsigned int BP_cd = BP_pair_table(sc , sd);
						const unsigned int BP_ce = BP_pair_table(sc , se);
						const unsigned int BP_de = BP_pair_table(sd , se);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
						const int Jmin_cd = Jmin_pair_table(sc , sd);
						const int Jmax_cd = Jmax_pair_table(sc , sd);
					  
						const int Jmin_ce = Jmin_pair_table(sc , se);
						const int Jmax_ce = Jmax_pair_table(sc , se);
					  
						const int Jmin_de = Jmin_pair_table(sd , se);
						const int Jmax_de = Jmax_pair_table(sd , se);		    				    
		      			  
						const int Jmin_af = Jmin_pair_table(sa , sf);
						const int Jmax_af = Jmax_pair_table(sa , sf);
					      
						const int Jmin_bf = Jmin_pair_table(sb , sf);
						const int Jmax_bf = Jmax_pair_table(sb , sf);
					      
						const double inv_delta_norm_de = (sd == se) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_ce = (sc == se) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_fa = (sf == sa) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_cd = (sc == sd) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_fb = (sf == sb) ? (M_SQRT1_2) : (1.0);
						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd , se , sf);
							      		
							    if (BP_ab_de_equal && (Jab == Jde))
							      T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (operation , space_pair , two_states_indices , BP , iJ , abc_index , def_index ,
															   sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
															   BP_ab , Jab , ab_index , ijc , inv_delta_norm_ab , inv_delta_norm_phase_ab , inv_delta_norm_de , sc , sd , se , sf);
							      			
							    if (sa_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , two_states_indices , BP , iJ , abc_index , def_index ,
																       inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_ce , inv_delta_norm_fb ,
																       1 , Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																       false , false , sb , sc , se , sf);
							      
							    if (sb_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , two_states_indices , BP , iJ , abc_index , def_index ,
																       inv_delta_norm_phase_ab , inv_delta_norm_de , inv_delta_norm_ce , inv_delta_norm_fa , 
																       1 , Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																       false , false , sa , sc , se , sf);
																
							    if (sa_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , two_states_indices , BP , iJ , abc_index , def_index ,
																       inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_cd , inv_delta_norm_fb ,
																       phase_de , Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																       false , false , sb , sc , sd , sf);
																
							    if (sb_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , two_states_indices , BP , iJ , abc_index , def_index ,
																       inv_delta_norm_phase_ab , inv_delta_norm_de , inv_delta_norm_cd , inv_delta_norm_fa ,
																       phase_de , Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																       false , false , sa , sc , sd , sf);
							      												
							  }}}}}}}}}}}
	  
	if (is_J_smaller_than_jmax) T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store(operation , BP , iJ);
      }
}















void RDM_T2_prime_gradient_class::T2_prime_ppn_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != PROTONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T2_prime_gradient_class::T2_prime_ppn_gradient_block_matrices_calc_store");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
                    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	  for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	    {	
	      if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
		  
	      const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

	      if (BP_abc == BP)
		{
		  const bool are_sa_sb_equal = (sa_p == sb_p);
	
		  const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		  const class nlj_struct &shell_qn_sb_p = prot_shells_qn(sb_p);
		  const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  			  
		  const int ija = shell_qn_sa_p.get_ij ();
		  const int ijb = shell_qn_sb_p.get_ij ();
		  const int ijc = shell_qn_sc_n.get_ij ();
		 			  	  		      
		  const unsigned int BP_ab = BP_pp_pair_table(sa_p , sb_p);
			  
		  const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		  const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);
			  
		  const double inv_delta_norm_ab = (sa_p == sb_p) ? (M_SQRT1_2) : (1.0);
      
		  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		    {      	
		      const bool is_Jab_even = (Jab%2 == 0);
						  
		      if (!are_sa_sb_equal || is_Jab_even)
			{			
			  const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			  const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
	      
			  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			    {
			      const unsigned int ab_index = two_states_indices_pp(Jab , sa_p , sb_p);
			      
			      const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
			      
			      const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      
			      const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  			      
			      for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				  for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				    {
				      if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
				      
				      const bool sa_sd_equal = (sa_p == sd_p) , sa_se_equal = (sa_p == se_p);
				      const bool sb_sd_equal = (sb_p == sd_p) , sb_se_equal = (sb_p == se_p);
				      const bool sc_sf_equal = (sc_n == sf_n);
				      
				      if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					{
					  const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					  if (BP_def == BP)
					    {
					      const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					      const class nlj_struct &shell_qn_se = prot_shells_qn(se_p);
					      const class nlj_struct &shell_qn_sf = neut_shells_qn(sf_n);
			  
					      const int ijd = shell_qn_sd.get_ij ();
					      const int ije = shell_qn_se.get_ij ();
					      const int ijf = shell_qn_sf.get_ij ();
							  
					      const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
					      const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
					      const bool jc_jf_equal = (ijc == ijf);
							  
					      const bool are_sd_se_equal = (sd_p == se_p);
		    
					      const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
					      const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
							      
					      const unsigned int BP_cd = BP_pn_pair_table(sd_p , sc_n);
					      const unsigned int BP_ce = BP_pn_pair_table(se_p , sc_n);
					      const unsigned int BP_de = BP_pp_pair_table(sd_p , se_p);

					      const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
					      const int Jmin_cd = Jmin_pn_pair_table(sd_p , sc_n);
					      const int Jmax_cd = Jmax_pn_pair_table(sd_p , sc_n);
					  
					      const int Jmin_ce = Jmin_pn_pair_table(se_p , sc_n);
					      const int Jmax_ce = Jmax_pn_pair_table(se_p , sc_n);
					  
					      const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
					      const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);		    				    
		      			  
					      const int Jmin_af = Jmin_pn_pair_table(sa_p , sf_n);
					      const int Jmax_af = Jmax_pn_pair_table(sa_p , sf_n);
					      
					      const int Jmin_bf = Jmin_pn_pair_table(sb_p , sf_n);
					      const int Jmax_bf = Jmax_pn_pair_table(sb_p , sf_n);
					      
					      const double inv_delta_norm_de = (sd_p == se_p) ? (M_SQRT1_2) : (1.0);
						    
					      for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						{	     	
						  const bool is_Jde_even = (Jde%2 == 0);
						  
						  if (!are_sd_se_equal || is_Jde_even)
						    {
						      const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
						      const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
						      const int iJmin = max (iJmin_abc , iJmin_def);
						      const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						      if ((iJ >= iJmin) && (iJ <= iJmax))
							{	
							  const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							  const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);
			  					
							  if (BP_ab_de_equal && (Jab == Jde))
							    T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (operation , PROTONS_ONLY , two_states_indices_pp , BP , iJ , abc_index , def_index ,
															 sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
															 BP_ab , Jab , ab_index , ijc , inv_delta_norm_ab , inv_delta_norm_phase_ab , inv_delta_norm_de , sc_n , sd_p , se_p , sf_n);

							  if (sa_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1.0 , 1 , 
																     Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																     false , true , sb_p , sc_n , se_p , sf_n);
								
							  if (sb_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1.0 , 1 , 
																     Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																     false , true , sa_p , sc_n , se_p , sf_n);
								
							  if (sa_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1.0 , phase_de , 
																     Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																     false , true , sb_p , sc_n , sd_p , sf_n);
								
							  if (sb_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1.0 , phase_de ,
																     Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																     false , true , sa_p , sc_n , sd_p , sf_n);
							      									
							}}}}}}}}}}}
}




void RDM_T2_prime_gradient_class::T2_prime_nnp_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T2_prime_gradient_class::T2_prime_nnp_gradient_block_matrices_calc_store");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
                    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	    {	
	      if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
				      
	      const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

	      if (BP_abc == BP)
		{
		  const bool are_sa_sb_equal = (sa_n == sb_n);
		      
		  const class nlj_struct &shell_qn_sa_n = neut_shells_qn(sa_n);
		  const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		  const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		  const int ija = shell_qn_sa_n.get_ij ();
		  const int ijb = shell_qn_sb_n.get_ij ();
		  const int ijc = shell_qn_sc_p.get_ij ();
		 			  	  		      
		  const unsigned int BP_ab = BP_nn_pair_table(sa_n , sb_n);
			  
		  const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		  const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);

		  const double inv_delta_norm_ab = (sa_n == sb_n) ? (M_SQRT1_2) : (1.0);
      
		  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		    {      	
		      const bool is_Jab_even = (Jab%2 == 0);
						  
		      if (!are_sa_sb_equal || is_Jab_even)
			{
			  const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			  const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			    {
			      const unsigned int ab_index = two_states_indices_nn(Jab , sa_n , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			
			      const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      
			      const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  			      
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				  for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				    {
				      if (!is_it_in_space_tab(sd_n , se_n , sf_p)) continue;
		  
				      const bool sa_sd_equal = (sa_n == sd_n) , sa_se_equal = (sa_n == se_n);
				      const bool sb_sd_equal = (sb_n == sd_n) , sb_se_equal = (sb_n == se_n);
				      const bool sc_sf_equal = (sc_p == sf_p);
					  
				      if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					{
					  const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					  if (BP_def == BP)
					    {
					      const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
					      const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
					      const class nlj_struct &shell_qn_sf = prot_shells_qn(sf_p);
			  
					      const int ijd = shell_qn_sd.get_ij ();
					      const int ije = shell_qn_se.get_ij ();
					      const int ijf = shell_qn_sf.get_ij ();
							  
					      const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
					      const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
					      const bool jc_jf_equal = (ijc == ijf);
							  
					      const bool are_sd_se_equal = (sd_n == se_n);
		    
					      const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
					      const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
		      		 							      
					      const unsigned int BP_cd = BP_pn_pair_table(sc_p , sd_n);
					      const unsigned int BP_ce = BP_pn_pair_table(sc_p , se_n);
					      const unsigned int BP_de = BP_nn_pair_table(sd_n , se_n);

					      const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
					      const int Jmin_cd = Jmin_pn_pair_table(sc_p , sd_n);
					      const int Jmax_cd = Jmax_pn_pair_table(sc_p , sd_n);
					  
					      const int Jmin_ce = Jmin_pn_pair_table(sc_p , se_n);
					      const int Jmax_ce = Jmax_pn_pair_table(sc_p , se_n);
					  
					      const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
					      const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);		    				    
		      			  
					      const int Jmin_af = Jmin_pn_pair_table(sf_p , sa_n);
					      const int Jmax_af = Jmax_pn_pair_table(sf_p , sa_n);
					      
					      const int Jmin_bf = Jmin_pn_pair_table(sf_p , sb_n);
					      const int Jmax_bf = Jmax_pn_pair_table(sf_p , sb_n);
					      
					      const double inv_delta_norm_de = (sd_n == se_n) ? (M_SQRT1_2) : (1.0);
						    
					      for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						{	     	
						  const bool is_Jde_even = (Jde%2 == 0);
						  
						  if (!are_sd_se_equal || is_Jde_even)
						    {
						      const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
						      const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
						      const int iJmin = max (iJmin_abc , iJmin_def);
						      const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						      if ((iJ >= iJmin) && (iJ <= iJmax))
							{	
							  const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							  const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
			  						
							  if (BP_ab_de_equal && (Jab == Jde))
							    T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (operation , NEUTRONS_ONLY , two_states_indices_nn , BP , iJ , abc_index , def_index ,
															 sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
															 BP_ab , Jab , ab_index , ijc , inv_delta_norm_ab , inv_delta_norm_phase_ab , inv_delta_norm_de , sc_p , sd_n , se_n , sf_p);
							      
							  if (sa_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1.0 , 1 , 
																     Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																     true , false , sb_n , sc_p , se_n , sf_p);
								
							  if (sb_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1.0 , 1 , 
																     Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																     true , false , sa_n , sc_p , se_n , sf_p);
							      
							  if (sa_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1.0 , phase_de , 
																     Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																     true , false , sb_n , sc_p , sd_n , sf_p);
								
							  if (sb_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
																     inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1.0 , phase_de , 
																     Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																     true , false , sa_n , sc_p , sd_n , sf_p);

							}}}}}}}}}}}
}






void RDM_T2_prime_gradient_class::T2_prime_pnp_gradient_block_matrices_omega_part_calc_store(
											     const enum operation_type operation , 
											     const unsigned int BP ,
											     const int iJ)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != PROTON)) error_message_print_abort ("pn + p space only in RDM_T2_prime_gradient_class::T2_prime_gradient_block_matrices_pnp_omega_part_calc_store");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
    
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &T2_matrix_dimensions = T2_prime.get_T2_matrix_dimensions ();
  
  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	{	
	  if (!is_it_in_space_tab(sa_p , sb_n , sc_p)) continue;
				      
	  const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_p);

	  if (BP_abc == BP)
	    {	
	      const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
		  		
	      const unsigned int ijc = shell_qn_sc.get_ij ();
							  	  		      
	      const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
		      
	      const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
	      const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);

	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;	
				 
	      for (unsigned int sg_n = 0 ; sg_n < Nn_nlj ; sg_n++)
		{		  
		  const class nlj_struct &shell_qn_sg = neut_shells_qn(sg_n);
		  
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
			
		  if (ijg == iJ)
		    {		      
		      const unsigned int BP_gc = BP_pn_pair_table(sc_p , sg_n);
					
		      if (BP_gc == BP_ab)
			{			      	
			  const double jg = shell_qn_sg.get_j ();
			      
			  const double hat_jg = hat (jg);
			  
			  const int Jmin_gc = Jmin_pn_pair_table(sc_p , sg_n);
			  const int Jmax_gc = Jmax_pn_pair_table(sc_p , sg_n);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);
		      
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const unsigned int ab_index = two_states_indices_pn(J_pair , sa_p , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(J_pair , iJ , sa_p , sb_n , sc_p);
			
			      const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_p);
			      const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_p);

			      if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				{				      
				  const unsigned int gc_index = two_states_indices_pn(J_pair , sc_p , sg_n);

				  const double hat_J_pair = hat (J_pair);
				  
				  const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);
				  
				  const int phase_gc = ((ijg + ijc + J_pair)%2 == 0) ? (1) : (-1);
				      
				  const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (phase_abc*hat_J_pair/hat_jg) : (NADA);
				      
				  const double gradient_ME = (phase_gc == 1) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
				      
				  T2_prime_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , two_body_T2_prime_omega_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
				  T2_prime_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , iJ , two_body_T2_prime_omega_index , abc_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
				}}}
		      
		      two_body_T2_prime_omega_index++;
		      
		    }}}}
		  
  unsigned int one_body_T2_prime_omega_index_in = T2_matrix_dimension;
  
  for (unsigned int sh_n = 0 ; sh_n < Nn_nlj ; sh_n++)
    {
      const class nlj_struct &shell_qn_sh = neut_shells_qn(sh_n);
		    
      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
		    
      if (ijh == iJ)
	{
	  unsigned int one_body_T2_prime_omega_index_out = T2_matrix_dimension;
	      
	  for (unsigned int sg_n = 0 ; sg_n < Nn_nlj ; sg_n++)
	    {	  
	      const class nlj_struct &shell_qn_sg = neut_shells_qn(sg_n);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
	      
	      const int lg = shell_qn_sg.get_l ();
			  
	      const int ijg = shell_qn_sg.get_ij ();

	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_in  , one_body_T2_prime_omega_index_out , NEUTRON , ijg , sg_n , sh_n , 1.0);
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_out , one_body_T2_prime_omega_index_in  , NEUTRON , ijg , sg_n , sh_n , 1.0);
		    }
		  
		  one_body_T2_prime_omega_index_out++;
		}
	    }
		      
	  one_body_T2_prime_omega_index_in++;
	}
    }	
}
  


void RDM_T2_prime_gradient_class::T2_prime_pnp_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != PROTON)) error_message_print_abort ("pn + p space only in RDM_T2_prime_gradient_class::T2_prime_pnp_gradient_block_matrices_calc_store");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const double jn_max = neut_data.get_jmax ();
            
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
      
	const bool is_J_smaller_than_jn_max = (make_int (J - jn_max) <= 0);
       
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_p)) continue;
		  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_p);

		if (BP_abc == BP)
		  {
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_p.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
			  
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {			
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int ab_index = two_states_indices_pn(Jab , sa_p , sb_n);
			      
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_p);
			  
			    const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      				  			      
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				  {
				    if (!is_it_in_space_tab(sd_p , se_n , sf_p)) continue;
				  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_p == sf_p);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_p);
					      
					if (BP_def == BP)
					  {
					    const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
					    const class nlj_struct &shell_qn_sf = prot_shells_qn(sf_p);
			  
					    const int ijd = shell_qn_sd.get_ij ();
					    const int ije = shell_qn_se.get_ij ();
					    const int ijf = shell_qn_sf.get_ij ();
							  
					    const bool ja_jd_equal = (ija == ijd);
					    const bool jb_je_equal = (ijb == ije);
					    const bool jc_jf_equal = (ijc == ijf);
		    
					    const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					    const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
		      		 							      
					    const unsigned int BP_cd = BP_pp_pair_table(sc_p , sd_p);
					    const unsigned int BP_ce = BP_pn_pair_table(sc_p , se_n);
					    const unsigned int BP_de = BP_pn_pair_table(sd_p , se_n);

					    const bool BP_ab_de_equal = (BP_ab == BP_de);
											      
					    const int Jmin_cd = Jmin_pp_pair_table(sc_p , sd_p);
					    const int Jmax_cd = Jmax_pp_pair_table(sc_p , sd_p);
					  
					    const int Jmin_ce = Jmin_pn_pair_table(sc_p , se_n);
					    const int Jmax_ce = Jmax_pn_pair_table(sc_p , se_n);
					  
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);		    				    
		      			  
					    const int Jmin_af = Jmin_pp_pair_table(sa_p , sf_p);
					    const int Jmax_af = Jmax_pp_pair_table(sa_p , sf_p);
					      
					    const int Jmin_bf = Jmin_pn_pair_table(sf_p , sb_n);
					    const int Jmax_bf = Jmax_pn_pair_table(sf_p , sb_n);
					  
					    const double inv_delta_norm_fa = (sf_p == sa_p) ? (M_SQRT1_2) : (1.0);
					    const double inv_delta_norm_cd = (sc_p == sd_p) ? (M_SQRT1_2) : (1.0);
						    
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {	
						    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_p);
			  					
						    if (BP_ab_de_equal && (Jab == Jde))															
						      T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
														   sa_sd_jb_je_equal , sb_se_ja_jd_equal , false , false , sc_sf_equal , jc_jf_equal ,
														   BP_ab , Jab , ab_index , ijc , 1.0 , phase_ab , 1.0 , sc_p , sd_p , se_n , sf_p);
							  
						    if (sa_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
															       1.0 , 1.0 , 1.0 , 1.0 , 1 ,
															       Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
															       true , false , sb_n , sc_p , se_n , sf_p);

						    if (sb_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_ONLY , two_states_indices_pp , BP , iJ , abc_index , def_index ,
															       phase_ab , 1.0 , inv_delta_norm_cd , inv_delta_norm_fa , phase_de ,
															       Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
															       false , false , sa_p , sc_p , sd_p , sf_p);
						      														
						  }}}}}}}}}

	if (is_J_smaller_than_jn_max) T2_prime_pnp_gradient_block_matrices_omega_part_calc_store(operation , BP , iJ);
      }
}






void RDM_T2_prime_gradient_class::T2_prime_pnn_gradient_block_matrices_omega_part_calc_store(
											     const enum operation_type operation , 
											     const unsigned int BP ,
											     const int iJ)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_gradient_class::T2_prime_gradient_block_matrices_pnn_omega_part_calc_store");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
    
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &T2_matrix_dimensions = T2_prime.get_T2_matrix_dimensions ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	{	
	  if (!is_it_in_space_tab(sa_p , sb_n , sc_n)) continue;
				  
	  const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_n);

	  if (BP_abc == BP)
	    {	
	      const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
		  				
	      const int ijc = shell_qn_sc.get_ij ();
		    
	      const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
			  
	      const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
	      const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
					  
	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;
	      
	      for (unsigned int sg_p = 0 ; sg_p < Np_nlj ; sg_p++)
		{
		  const class nlj_struct &shell_qn_sg = prot_shells_qn(sg_p);
				  
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
					  
		  if (ijg == iJ)
		    {	
		      const unsigned int BP_gc = BP_pn_pair_table(sg_p , sc_n);

		      if (BP_gc == BP_ab)
			{				      
			  const double jg = shell_qn_sg.get_j ();
		  
			  const double hat_jg = hat (jg);			  
				
			  const int Jmin_gc = Jmin_pn_pair_table(sg_p , sc_n);
			  const int Jmax_gc = Jmax_pn_pair_table(sg_p , sc_n);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);	 	
		  
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const unsigned int ab_index = two_states_indices_pn(J_pair , sa_p , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(J_pair , iJ , sa_p , sb_n , sc_n);
			
			      const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_n);
			      const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_n);
			      
			      if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				{			      
				  const unsigned int gc_index = two_states_indices_pn(J_pair , sg_p , sc_n);
	        
				  const double hat_J_pair = hat (J_pair);
				  
				  const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);
				  
				  const double gradient_ME = (phase_abc == 1) ? (hat_J_pair/hat_jg) : (-hat_J_pair/hat_jg);
				      
				  T2_prime_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , two_body_T2_prime_omega_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
				  T2_prime_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , iJ , two_body_T2_prime_omega_index , abc_index , BP_ab , J_pair , ab_index , gc_index , gradient_ME);
				}}}
				      
		      two_body_T2_prime_omega_index++;
			  
		    }}}}

  unsigned int one_body_T2_prime_omega_index_in = T2_matrix_dimension;
	      
  for (unsigned int sh_p = 0 ; sh_p < Np_nlj ; sh_p++)
    {
      const class nlj_struct &shell_qn_sh = prot_shells_qn(sh_p);
		    
      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
		    
      if (ijh == iJ)
	{
	  unsigned int one_body_T2_prime_omega_index_out = T2_matrix_dimension;
	      
	  for (unsigned int sg_p = 0 ; sg_p < Np_nlj ; sg_p++)
	    {	  
	      const class nlj_struct &shell_qn_sg = prot_shells_qn(sg_p);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
	      
	      const int lg = shell_qn_sg.get_l ();
			  
	      const int ijg = shell_qn_sg.get_ij ();

	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_in  , one_body_T2_prime_omega_index_out , PROTON , ijg , sg_p , sh_p , 1.0);
		      rho_term_der_part_determine (operation , BP , iJ , one_body_T2_prime_omega_index_out , one_body_T2_prime_omega_index_in  , PROTON , ijg , sg_p , sh_p , 1.0);
		    }
		  
		  one_body_T2_prime_omega_index_out++;
		}
	    }
		      
	  one_body_T2_prime_omega_index_in++;  
	}
    }
}


   
void RDM_T2_prime_gradient_class::T2_prime_pnn_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_gradient_class::T2_prime_pnn_gradient_block_matrices_calc_store");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
        
  const double jp_max = prot_data.get_jmax ();
            
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &BP_table = T2_prime.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T2_prime.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T2_prime.get_iJmax_pair_last_particle_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T2_prime.get_three_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = T2_prime.get_is_it_in_space_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
            
	const bool is_J_smaller_than_jp_max = (make_int (J - jp_max) <= 0);
      
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_n)) continue;
		  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_n);

		if (BP_abc == BP)
		  {
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  			  
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_n.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
		      			  
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {			
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
	      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int ab_index = two_states_indices_pn(Jab , sa_p , sb_n);
			      
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_n);
			  
			    const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      				  			      
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				  {		
				    if (!is_it_in_space_tab(sd_p , se_n , sf_n)) continue;
				  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_n == sf_n);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_n);
					      
					if (BP_def == BP)
					  {
					    const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
					    const class nlj_struct &shell_qn_sf = neut_shells_qn(sf_n);
			  
					    const int ijd = shell_qn_sd.get_ij ();
					    const int ije = shell_qn_se.get_ij ();
					    const int ijf = shell_qn_sf.get_ij ();
							  
					    const bool ja_jd_equal = (ija == ijd);
					    const bool jb_je_equal = (ijb == ije);
						
					    const bool jc_jf_equal = (ijc == ijf);
		    
					    const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					    const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
					    
					    const unsigned int BP_cd = BP_pn_pair_table(sd_p , sc_n);
					    const unsigned int BP_ce = BP_nn_pair_table(sc_n , se_n);
					    const unsigned int BP_de = BP_pn_pair_table(sd_p , se_n);

					    const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
					    const int Jmin_cd = Jmin_pn_pair_table(sd_p , sc_n);
					    const int Jmax_cd = Jmax_pn_pair_table(sd_p , sc_n);
					  
					    const int Jmin_ce = Jmin_nn_pair_table(sc_n , se_n);
					    const int Jmax_ce = Jmax_nn_pair_table(sc_n , se_n);
					  
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);	
		      			  
					    const int Jmin_af = Jmin_pn_pair_table(sa_p , sf_n);
					    const int Jmax_af = Jmax_pn_pair_table(sa_p , sf_n);
					      
					    const int Jmin_bf = Jmin_nn_pair_table(sb_n , sf_n);
					    const int Jmax_bf = Jmax_nn_pair_table(sb_n , sf_n);
					  
					    const double inv_delta_norm_ce = (sc_n == se_n) ? (M_SQRT1_2) : (1.0);
					    const double inv_delta_norm_fb = (sf_n == sb_n) ? (M_SQRT1_2) : (1.0);
						    
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {	
						    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_n);
						     		
						    if (BP_ab_de_equal && (Jab == Jde))
						      T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
														   sa_sd_jb_je_equal , sb_se_ja_jd_equal , false , false , sc_sf_equal , jc_jf_equal ,
														   BP_ab , Jab , ab_index , ijc , 1.0 , phase_ab , 1.0 , sc_n , sd_p , se_n , sf_n);
							
						    if (sa_sd_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , NEUTRONS_ONLY , two_states_indices_nn , BP , iJ , abc_index , def_index ,
															       1.0 , 1.0 , inv_delta_norm_ce , inv_delta_norm_fb , 1 , 
															       Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
															       false , false , sb_n , sc_n , se_n , sf_n);
								
						    if (sb_se_equal) T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , two_states_indices_pn , BP , iJ , abc_index , def_index ,
															       phase_ab , 1.0 , 1.0 , 1.0 , phase_de ,
															       Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
															       false , true , sa_p , sc_n , sd_p , sf_n);
						      									
						  }}}}}}}}}

	if (is_J_smaller_than_jp_max) T2_prime_pnn_gradient_block_matrices_omega_part_calc_store(operation , BP , iJ);
      }
}











void RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_gradient_class::T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store (no nn + p)");
  
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &matrix_dimensions_pp_nn = Gamma_pp_nn.get_matrix_dimensions ();
  
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();

  const int Jmax_pp_nn_total_plus_one = matrix_dimensions_pp_nn.dimension (1);
  
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
  
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
    
  const int J_total_number = matrix_dimensions.dimension (1);
  
  class array<unsigned short int> &T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T2_prime_gradient_block_matrices_non_trivial_zero_numbers (space_pair);
  
  class array<class block_sparse_matrix<TYPE> > &T2_prime_gradient_block_matrices_pp_nn = get_T2_prime_gradient_block_matrices (space_pair);
 
  T2_prime_ppp_nnn_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
	      
  class array<unsigned int> T2_prime_block_matrix_dimensions(2*J_total_number);
    
  class array<unsigned int> T2_prime_block_matrix_non_trivial_zero_numbers(2*J_total_number);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      T2_prime_block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);
		  	    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T2_prime_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	    
	      const unsigned int non_trivial_zero_number_max = T2_prime_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T2_prime_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T2_prime_block_matrix_dimensions , T2_prime_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T2_prime_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);

	      const unsigned int non_trivial_zero_number_max = T2_prime_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T2_prime_block_matrix_dimensions , T2_prime_block_matrix_non_trivial_zero_numbers);
	    }
      }
	
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = 0;
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn    = 0;
  
  T2_prime_ppp_nnn_gradient_block_matrices_calc_store (TABLES_FILL);
  	    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);

	      class block_sparse_matrix<TYPE> &T2_prime_matrix_gradient_pp_nn = T2_prime_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T2_prime_matrix_gradient_pp_nn.is_it_filled ()) T2_prime_matrix_gradient_pp_nn.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T2_prime_matrix_gradient_pn = T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T2_prime_matrix_gradient_pn.is_it_filled ()) T2_prime_matrix_gradient_pn.make_it_consistent_no_zeros ();
	    }
      }
}








void RDM_T2_prime_gradient_class::T2_prime_ppn_pnn_pnp_nnp_gradient_block_matrices_alloc_calc_store () 
{  
  const bool is_it_ppn = ((space_pair == PROTONS_ONLY)     && (last_particle == NEUTRON));
  const bool is_it_pnn = ((space_pair == PROTONS_NEUTRONS) && (last_particle == NEUTRON));
  const bool is_it_pnp = ((space_pair == PROTONS_NEUTRONS) && (last_particle == PROTON));
  const bool is_it_nnp = ((space_pair == NEUTRONS_ONLY)    && (last_particle == PROTON));
  
  if (!is_it_ppn && !is_it_pnn && !is_it_pnp && !is_it_nnp) error_message_print_abort ("It is either ppn, pnn, pnp or nnp in RDM_T2_prime_gradient_class::T2_prime_ppn_pnn_pnp_nnp_gradient_block_matrices_alloc_calc_store");
  
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  const class RDM_T2_prime_class &T2_prime = get_T2_prime ();
    
  const class array<unsigned int> &matrix_dimensions = T2_prime.get_matrix_dimensions ();
    
  const int J_total_number = matrix_dimensions.dimension (1);
  
  if (is_it_ppn) T2_prime_ppn_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_pnn) T2_prime_pnn_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_pnp) T2_prime_pnp_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_nnp) T2_prime_nnp_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
  
  class array<unsigned int> T2_prime_block_matrix_dimensions(2*J_total_number);
    
  class array<unsigned int> T2_prime_block_matrix_non_trivial_zero_numbers(2*J_total_number);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      T2_prime_block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T2_prime_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	    
	      const unsigned int non_trivial_zero_number_max = T2_prime_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T2_prime_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index).allocate (T2_prime_block_matrix_dimensions , T2_prime_block_matrix_non_trivial_zero_numbers);
	    }
      }
      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T2_prime_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	    
	      const unsigned int non_trivial_zero_number_max = T2_prime_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T2_prime_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T2_prime_block_matrix_dimensions , T2_prime_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T2_prime_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);

	      const unsigned int non_trivial_zero_number_max = T2_prime_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T2_prime_block_matrix_dimensions , T2_prime_block_matrix_non_trivial_zero_numbers);
	    }
      }

  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
  T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;  
  
  if (is_it_ppn) T2_prime_ppn_gradient_block_matrices_calc_store (TABLES_FILL);
  if (is_it_pnn) T2_prime_pnn_gradient_block_matrices_calc_store (TABLES_FILL);
  if (is_it_pnp) T2_prime_pnp_gradient_block_matrices_calc_store (TABLES_FILL);
  if (is_it_nnp) T2_prime_nnp_gradient_block_matrices_calc_store (TABLES_FILL);

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      class block_sparse_matrix<TYPE> &T2_prime_matrix_gradient_pp = T2_prime_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T2_prime_matrix_gradient_pp.is_it_filled ()) T2_prime_matrix_gradient_pp.make_it_consistent_no_zeros ();  
	    }
      }
      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T2_prime_matrix_gradient_nn = T2_prime_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T2_prime_matrix_gradient_nn.is_it_filled ()) T2_prime_matrix_gradient_nn.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T2_prime_matrix_gradient_pn = T2_prime_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T2_prime_matrix_gradient_pn.is_it_filled ()) T2_prime_matrix_gradient_pn.make_it_consistent_no_zeros ();
	    }
      }
}
