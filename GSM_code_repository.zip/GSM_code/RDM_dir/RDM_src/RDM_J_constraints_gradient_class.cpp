#include "../RDM_include/RDM_include_def.h"



RDM_J_constraints_gradient_class::RDM_J_constraints_gradient_class () :
  particle (NO_PARTICLE) ,
  J (0) ,
  J_factor_vector_part (0) ,
  is_J_non_zero (false),
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_G_ptr (NULL) ,
  rho_der_pp_nn_tab_ptr (NULL) ,
  rho_der_pn_tab_ptr (NULL) ,
  Gamma_pp_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL)
{}

RDM_J_constraints_gradient_class::RDM_J_constraints_gradient_class (
								    const enum particle_type particle_c ,
								    const double J_c , 
								    const class nucleons_data &prot_data ,
								    const class nucleons_data &neut_data ,
								    const class array<double> &rho_der_pp_nn_tab ,
								    const class array<double> &rho_der_pn_tab ,
								    const class RDM_PQG_class &Gamma_pp_nn ,
								    const class RDM_PQG_class &Gamma_pn ,
								    const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G) :
  particle (NO_PARTICLE) ,
  J (0) ,
  J_factor_vector_part (0) ,
  is_J_non_zero (false),
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_G_ptr (NULL) ,
  rho_der_pp_nn_tab_ptr (NULL) ,
  rho_der_pn_tab_ptr (NULL) ,
  Gamma_pp_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL)
{
  alloc_calc_store (particle_c , J_c , prot_data , neut_data , rho_der_pp_nn_tab , rho_der_pn_tab , Gamma_pp_nn , Gamma_pn , Wigner_6j_hats_G);
}

RDM_J_constraints_gradient_class::RDM_J_constraints_gradient_class (const class RDM_J_constraints_gradient_class &X)
{
  allocate_fill (X);
}

void RDM_J_constraints_gradient_class::alloc_calc_store (
							 const enum particle_type particle_c ,
							 const double J_c , 
							 const class nucleons_data &prot_data ,
							 const class nucleons_data &neut_data ,
							 const class array<double> &rho_der_pp_nn_tab ,
							 const class array<double> &rho_der_pn_tab ,
							 const class RDM_PQG_class &Gamma_pp_nn ,
							 const class RDM_PQG_class &Gamma_pn ,
							 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_gradient_class cannot be allocated twice in RDM_J_constraints_gradient_class::allocate");
  
  particle = particle_c;
  
  J = J_c;
  
  J_factor_vector_part = -hat (1)/(J + 1.0);
  
  is_J_non_zero = (make_int (2.0*J) != 0);
        
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;
  
  Wigner_6j_hats_G_ptr = &Wigner_6j_hats_G;
  
  rho_der_pp_nn_tab_ptr = &rho_der_pp_nn_tab;
  
  rho_der_pn_tab_ptr = &rho_der_pn_tab;
  
  Gamma_pp_nn_ptr = &Gamma_pp_nn;

  Gamma_pn_ptr = &Gamma_pn;
	    
  const class array<unsigned int> &matrix_dimensions_pp_nn = Gamma_pp_nn.get_matrix_dimensions ();

  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_nn_total_plus_one = matrix_dimensions_pp_nn.dimension (1);

  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);

  const unsigned int dimension_pp_nn_BP_J_max = matrix_dimensions_pp_nn.max ();

  const unsigned int dimension_pn_BP_J_max = matrix_dimensions_pn.max ();
  
  const unsigned int triangular_sup_pp_nn_MEs_number_max = (dimension_pp_nn_BP_J_max%2 == 0) ? ((dimension_pp_nn_BP_J_max/2)*(dimension_pp_nn_BP_J_max + 1)) : (dimension_pp_nn_BP_J_max*((dimension_pp_nn_BP_J_max + 1)/2));

  const unsigned int triangular_sup_pn_MEs_number_max = (dimension_pn_BP_J_max%2 == 0) ? ((dimension_pn_BP_J_max/2)*(dimension_pn_BP_J_max + 1)) : (dimension_pn_BP_J_max*((dimension_pn_BP_J_max + 1)/2));
  
  J_constraints_gradient_non_trivial_zero_numbers_pp_nn.allocate (2 , Jmax_pp_nn_total_plus_one , triangular_sup_pp_nn_MEs_number_max);
  
  J_constraints_gradient_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
  
  J_constraints_gradient_scalar_part_pp_nn.allocate (2 , Jmax_pp_nn_total_plus_one , triangular_sup_pp_nn_MEs_number_max);
  J_constraints_gradient_vector_part_pp_nn.allocate (2 , Jmax_pp_nn_total_plus_one , triangular_sup_pp_nn_MEs_number_max);
  
  J_constraints_gradient_scalar_part_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
  J_constraints_gradient_vector_part_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
	
  J_constraints_gradient_non_trivial_zero_numbers_pp_nn = 0;
  
  J_constraints_gradient_non_trivial_zero_numbers_pn = 0;

  J_constraints_gradients_alloc_calc_store ();
    
  J_constraints_gradient_non_trivial_zero_numbers_pp_nn.deallocate ();

  J_constraints_gradient_non_trivial_zero_numbers_pn.deallocate ();
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;

  Wigner_6j_hats_G_ptr = NULL;
  
  rho_der_pp_nn_tab_ptr = NULL;

  rho_der_pn_tab_ptr = NULL;
  
  Gamma_pp_nn_ptr = NULL;
  
  Gamma_pn_ptr = NULL;
}


RDM_J_constraints_gradient_class::~RDM_J_constraints_gradient_class () {}




void RDM_J_constraints_gradient_class::allocate_fill (const class RDM_J_constraints_gradient_class &X)
{        
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_gradient_class cannot be allocated twice in RDM_J_constraints_gradient_class::allocate_fill");
  
  particle = X.particle;

  J = X.J;
  
  is_J_non_zero  = X.is_J_non_zero;
    
  J_factor_vector_part = X.J_factor_vector_part;
  
  J_constraints_gradient_scalar_part_pp_nn.allocate_fill_object_elements (X.J_constraints_gradient_scalar_part_pp_nn);
  J_constraints_gradient_vector_part_pp_nn.allocate_fill_object_elements (X.J_constraints_gradient_vector_part_pp_nn);

  J_constraints_gradient_scalar_part_pn.allocate_fill_object_elements (X.J_constraints_gradient_scalar_part_pn);
  J_constraints_gradient_vector_part_pn.allocate_fill_object_elements (X.J_constraints_gradient_vector_part_pn);
}



void RDM_J_constraints_gradient_class::deallocate ()
{        
  particle = NO_PARTICLE;
  
  J = 0;
  
  is_J_non_zero = false;
  
  J_factor_vector_part = 0;
  
  J_constraints_gradient_scalar_part_pp_nn.deallocate ();
  J_constraints_gradient_vector_part_pp_nn.deallocate ();

  J_constraints_gradient_scalar_part_pn.deallocate ();
  J_constraints_gradient_vector_part_pn.deallocate ();
}


void RDM_J_constraints_gradient_class::operator = (const class RDM_J_constraints_gradient_class &X)
{        
  particle = X.particle;
  
  J = X.J;
  
  J_factor_vector_part = X.J_factor_vector_part;
  
  J_constraints_gradient_scalar_part_pp_nn = X.J_constraints_gradient_scalar_part_pp_nn;
  J_constraints_gradient_vector_part_pp_nn = X.J_constraints_gradient_vector_part_pp_nn;

  J_constraints_gradient_scalar_part_pn = X.J_constraints_gradient_scalar_part_pn;
  J_constraints_gradient_vector_part_pn = X.J_constraints_gradient_vector_part_pn;
}


void RDM_J_constraints_gradient_class::rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
											       const unsigned int sa ,
											       const unsigned int sb)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data ());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pp_nn = get_Gamma_pp_nn ();
  
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
    
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {			   
      const unsigned int is_it_in_space = is_it_in_space_tab(sa , sp);

      if (!is_it_in_space) continue;
       
      const unsigned int BPp = BP_table(sa , sp);

      const unsigned sa_sp_min = min (sa , sp) , sb_sp_min = min (sb , sp);
      const unsigned sa_sp_max = max (sa , sp) , sb_sp_max = max (sb , sp);

      const int Jmin_sa_sp = Jmin_table(sa , sp) , Jmin_sb_sp = Jmin_table(sb , sp) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_table(sa , sp) , Jmax_sb_sp = Jmax_table(sb , sp) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      const bool are_sa_sp_equal = (sa == sp);
      const bool are_sb_sp_equal = (sb == sp);
      
      const bool sa_sp_different_sb_sp_different = (!are_sa_sp_equal && !are_sb_sp_equal);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || sa_sp_different_sb_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , sa_sp_min , sa_sp_max);
	      const unsigned int jp = two_states_indices(Jp , sb_sp_min , sb_sp_max);
      
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      J_constraints_gradient_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index)++;
	    }
	}
    }
}


void RDM_J_constraints_gradient_class::rho_term_der_pp_nn_fill_part (
								     const int ij ,
								     const unsigned int sa ,
								     const unsigned int sb ,
								     const double minus_hat_j_phase ,
								     const double OBME_jc_J_factor_vector_part_phase)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const class array<double> &rho_der_tab = get_rho_der_pp_nn_tab ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class RDM_PQG_class &Gamma_pp_nn = get_Gamma_pp_nn ();
    
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
      	      
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {		    
      const unsigned int is_it_in_space = is_it_in_space_tab(sa , sp);

      if (!is_it_in_space) continue;
      
      const unsigned int BPp = BP_table(sa , sp);

      const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
      const int ijp = shell_qn_sp.get_ij ();
      
      const unsigned sa_sp_min = min (sa , sp) , sb_sp_min = min (sb , sp);
      const unsigned sa_sp_max = max (sa , sp) , sb_sp_max = max (sb , sp);

      const int Jmin_sa_sp = Jmin_table(sa , sp) , Jmin_sb_sp = Jmin_table(sb , sp) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_table(sa , sp) , Jmax_sb_sp = Jmax_table(sb , sp) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      const bool are_sa_sp_equal = (sa == sp) , is_sa_smaller_than_sp = (sa <= sp);
      const bool are_sb_sp_equal = (sb == sp) , is_sb_smaller_than_sp = (sb <= sp);
            
      const bool sa_sp_different_sb_sp_different = (!are_sa_sp_equal && !are_sb_sp_equal);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || sa_sp_different_sb_sp_different)
	    {
	      const int phase_sa_sp = (is_sa_smaller_than_sp) ? (1) : (((ij + ijp + Jp)%2 == 0) ? (1) : (-1));
	      const int phase_sb_sp = (is_sb_smaller_than_sp) ? (1) : (((ij + ijp + Jp)%2 == 0) ? (1) : (-1));
	  
	      const unsigned int ip = two_states_indices(Jp , sa_sp_min , sa_sp_max);
	      const unsigned int jp = two_states_indices(Jp , sb_sp_min , sb_sp_max);
	  		
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      const double rho_der_ME = rho_der_tab(Jp , sa , sp , sb);
	      	      
	      unsigned short int &ip_jp_index = J_constraints_gradient_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (is_J_non_zero)
		{
		  const double gradient_ME_scalar_part = (phase_sa_sp == phase_sb_sp) ? (minus_hat_j_phase*rho_der_ME) : (-minus_hat_j_phase*rho_der_ME);
	      
		  class sparse_matrix<TYPE> &J_constraints_gradient_matrix_scalar_part = J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
		  
		  J_constraints_gradient_matrix_scalar_part.get_row_index      (ip_jp_index) = sa;
		  J_constraints_gradient_matrix_scalar_part.get_column_index   (ip_jp_index) = sb;
		  J_constraints_gradient_matrix_scalar_part.get_matrix_element (ip_jp_index) = gradient_ME_scalar_part;
		}
	      
	      const double gradient_ME_vector_part = (phase_sa_sp == phase_sb_sp) ? (OBME_jc_J_factor_vector_part_phase*rho_der_ME) : (-OBME_jc_J_factor_vector_part_phase*rho_der_ME);
	      
	      class sparse_matrix<TYPE> &J_constraints_gradient_matrix_vector_part = J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      J_constraints_gradient_matrix_vector_part.get_row_index      (ip_jp_index) = sa;
	      J_constraints_gradient_matrix_vector_part.get_column_index   (ip_jp_index) = sb;
	      J_constraints_gradient_matrix_vector_part.get_matrix_element (ip_jp_index) = gradient_ME_vector_part;
	      
	      ip_jp_index++;
	    }
	}
    }
}






void RDM_J_constraints_gradient_class::rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
												 const unsigned int sa_p , 
												 const unsigned int sb_p)
{    
  const class nucleons_data &neut_data = get_neut_data ();
    
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			    
      const unsigned int is_it_in_space = is_it_in_space_tab(sa_p , sp_n);

      if (!is_it_in_space) continue;
      
      const unsigned int BPp = BP_table(sa_p , sp_n);

      const int Jmin_sa_sp = Jmin_pn_table(sa_p , sp_n) , Jmin_sb_sp = Jmin_pn_table(sb_p , sp_n) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_pn_table(sa_p , sp_n) , Jmax_sb_sp = Jmax_pn_table(sb_p , sp_n) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sa_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sb_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  J_constraints_gradient_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index)++;
	}
    }
}



void RDM_J_constraints_gradient_class::rho_prot_term_der_pn_fill_part (
								       const unsigned int sa_p ,
								       const unsigned int sb_p ,
								       const double minus_hat_j_phase ,
								       const double OBME_jc_J_factor_vector_part_phase)
{
  const class nucleons_data &neut_data = get_neut_data ();
    
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<double> &rho_prot_der_pn_tab = get_rho_der_pn_tab ();
  
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    	  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			    
      const unsigned int is_it_in_space = is_it_in_space_tab(sa_p , sp_n);

      if (!is_it_in_space) continue;
							     
      const unsigned int BPp = BP_table(sa_p , sp_n);

      const int Jmin_sa_sp = Jmin_pn_table(sa_p , sp_n) , Jmin_sb_sp = Jmin_pn_table(sb_p , sp_n) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_pn_table(sa_p , sp_n) , Jmax_sb_sp = Jmax_pn_table(sb_p , sp_n) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      	  
	  const unsigned int ip = two_states_indices_pn(Jp , sa_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sb_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double rho_der_ME = rho_prot_der_pn_tab(Jp , sa_p , sp_n , sb_p);
	      
	  unsigned short int &ip_jp_index = J_constraints_gradient_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index);
			  
	  if (is_J_non_zero)
	    {
	      const double gradient_ME_scalar_part = minus_hat_j_phase*rho_der_ME;
	  
	      class sparse_matrix<TYPE> &J_constraints_gradient_matrix_scalar_part_pn = J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index);

	      J_constraints_gradient_matrix_scalar_part_pn.get_row_index      (ip_jp_index) = sa_p;
	      J_constraints_gradient_matrix_scalar_part_pn.get_column_index   (ip_jp_index) = sb_p;
	      J_constraints_gradient_matrix_scalar_part_pn.get_matrix_element (ip_jp_index) = gradient_ME_scalar_part;
	    }
	      
	  const double gradient_ME_vector_part = OBME_jc_J_factor_vector_part_phase*rho_der_ME;
	  	      
	  class sparse_matrix<TYPE> &J_constraints_gradient_matrix_vector_part_pn = J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  J_constraints_gradient_matrix_vector_part_pn.get_row_index      (ip_jp_index) = sa_p;
	  J_constraints_gradient_matrix_vector_part_pn.get_column_index   (ip_jp_index) = sb_p;
	  J_constraints_gradient_matrix_vector_part_pn.get_matrix_element (ip_jp_index) = gradient_ME_vector_part;

	  ip_jp_index++;
	}
    }
}







void RDM_J_constraints_gradient_class::rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
												 const unsigned int sa_n , 
												 const unsigned int sb_n)
{
  const class nucleons_data &prot_data = get_prot_data ();
    
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();  
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			  
      const unsigned int is_it_in_space = is_it_in_space_tab(sp_p , sa_n);

      if (!is_it_in_space) continue;
							     
      const unsigned int BPp = BP_table(sp_p , sa_n);

      const int Jmin_sa_sp = Jmin_pn_table(sp_p , sa_n) , Jmin_sb_sp = Jmin_pn_table(sp_p , sb_n) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_pn_table(sp_p , sa_n) , Jmax_sb_sp = Jmax_pn_table(sp_p , sb_n) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , sa_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , sb_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  J_constraints_gradient_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index)++;	      
	}
    }
}



void RDM_J_constraints_gradient_class::rho_neut_term_der_pn_fill_part (
								       const unsigned int sa_n ,
								       const unsigned int sb_n ,
								       const double minus_hat_j_phase ,
								       const double OBME_jc_J_factor_vector_part_phase)
{
  const class nucleons_data &prot_data = get_prot_data ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
   
  const class array<double> &rho_neut_der_pn_tab = get_rho_der_pn_tab ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
    
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			    
      const unsigned int is_it_in_space = is_it_in_space_tab(sp_p , sa_n);

      if (!is_it_in_space) continue;
      
      const unsigned int BPp = BP_table(sp_p , sa_n);

      const int Jmin_sa_sp = Jmin_pn_table(sp_p , sa_n) , Jmin_sb_sp = Jmin_pn_table(sp_p , sb_n) , Jp_min = max (Jmin_sa_sp , Jmin_sb_sp);
      const int Jmax_sa_sp = Jmax_pn_table(sp_p , sa_n) , Jmax_sb_sp = Jmax_pn_table(sp_p , sb_n) , Jp_max = min (Jmax_sa_sp , Jmax_sb_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      	  
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , sa_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , sb_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double rho_der_ME = rho_neut_der_pn_tab(Jp , sa_n , sp_p , sb_n);
	        
	  unsigned short int &ip_jp_index = J_constraints_gradient_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index);
			  	  
	  if (is_J_non_zero)
	    {
	      const double gradient_ME_scalar_part = minus_hat_j_phase*rho_der_ME;

	      class sparse_matrix<TYPE> &J_constraints_gradient_matrix_scalar_part_pn = J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	      J_constraints_gradient_matrix_scalar_part_pn.get_row_index      (ip_jp_index) = sa_n;
	      J_constraints_gradient_matrix_scalar_part_pn.get_column_index   (ip_jp_index) = sb_n;
	      J_constraints_gradient_matrix_scalar_part_pn.get_matrix_element (ip_jp_index) = gradient_ME_scalar_part;
	    }
	      	  
	  const double gradient_ME_vector_part = OBME_jc_J_factor_vector_part_phase*rho_der_ME;
	      
	  class sparse_matrix<TYPE> &J_constraints_gradient_matrix_vector_part_pn = J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  J_constraints_gradient_matrix_vector_part_pn.get_row_index      (ip_jp_index) = sa_n;
	  J_constraints_gradient_matrix_vector_part_pn.get_column_index   (ip_jp_index) = sb_n;
	  J_constraints_gradient_matrix_vector_part_pn.get_matrix_element (ip_jp_index) = gradient_ME_vector_part;

	  ip_jp_index++;
	}
    }     
}



void RDM_J_constraints_gradient_class::rho_term_der_part_determine (
								    const enum operation_type operation ,
								    const enum particle_type particle ,
								    const int ij ,
								    const unsigned int sa , 
								    const unsigned int sb ,
								    const double minus_hat_j_phase ,
								    const double OBME_jc_J_factor_vector_part_phase)
{

  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      {
	rho_term_der_pp_nn_non_trivial_zero_numbers_increments (sa , sb);

	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_non_trivial_zero_numbers_increments (sa , sb); break;
	  case NEUTRON: rho_neut_term_der_pn_non_trivial_zero_numbers_increments (sa , sb); break;

	  default: abort_all ();
	  }
							    
      } break;

    case TABLES_FILL:
      {
	rho_term_der_pp_nn_fill_part (ij , sa , sb , minus_hat_j_phase , OBME_jc_J_factor_vector_part_phase);
							    
	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_fill_part (sa , sb , minus_hat_j_phase , OBME_jc_J_factor_vector_part_phase); break;
	  case NEUTRON: rho_neut_term_der_pn_fill_part (sa , sb , minus_hat_j_phase , OBME_jc_J_factor_vector_part_phase); break;
								
	  default: abort_all ();
	  }
							    
      } break;

    default: abort_all ();
    }
}




void RDM_J_constraints_gradient_class::G_Gamma_term_der_part_determine (
									const enum operation_type operation ,
									const bool is_it_pn ,
									const unsigned int sa ,
									const unsigned int sb ,
									const unsigned int BPp ,
									const int Jp ,
									const unsigned int ip ,
									const unsigned int jp ,
									const double gradient_ME_vector_part)
{
  const unsigned int ip_jp_min = min (ip , jp);
  const unsigned int ip_jp_max = max (ip , jp);
	      
  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
  
  class array<unsigned short int> &J_constraints_gradient_non_trivial_zero_numbers_local = get_J_constraints_gradient_non_trivial_zero_numbers (is_it_pn);

  switch (operation)
    {	    
    case DIMENSIONS_TABLES_CALC:
      {
	J_constraints_gradient_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index)++;
							    
      } break;

    case TABLES_FILL:
      {	  	      									
	unsigned short int &ip_jp_index = J_constraints_gradient_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index);
			
	if (is_J_non_zero)
	  {
	    class array<class sparse_matrix<TYPE> > &J_constraints_gradient_scalar_part_local = get_J_constraints_gradient_scalar_part (is_it_pn);
	    
	    class sparse_matrix<TYPE> &J_constraints_gradient_matrix_scalar_part = J_constraints_gradient_scalar_part_local(BPp , Jp , ip_jp_upper_triangular_index);
	    
	    J_constraints_gradient_matrix_scalar_part.get_row_index      (ip_jp_index) = sa;
	    J_constraints_gradient_matrix_scalar_part.get_column_index   (ip_jp_index) = sb;
	    J_constraints_gradient_matrix_scalar_part.get_matrix_element (ip_jp_index) = 0.0;
	  }
	
	class array<class sparse_matrix<TYPE> > &J_constraints_gradient_vector_part_local = get_J_constraints_gradient_vector_part (is_it_pn);
	
	class sparse_matrix<TYPE> &J_constraints_gradient_matrix_vector_part = J_constraints_gradient_vector_part_local(BPp , Jp , ip_jp_upper_triangular_index);
	
	J_constraints_gradient_matrix_vector_part.get_row_index      (ip_jp_index) = sa;
	J_constraints_gradient_matrix_vector_part.get_column_index   (ip_jp_index) = sb;
	J_constraints_gradient_matrix_vector_part.get_matrix_element (ip_jp_index) = gradient_ME_vector_part;
	
	ip_jp_index++;
	
      } break;

    default: abort_all ();
    }
}



								







void RDM_J_constraints_gradient_class::J_constraints_pp_nn_gradient_calc_store (const enum operation_type operation)
{  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data ());
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    					
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class RDM_PQG_class &Gamma_pp_nn = get_Gamma_pp_nn ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pp_nn = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<int> &Jmin_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmax_table ();
      
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {	
	const class pair_str pair_ab(sa , sb);
      		
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (shells_qn , shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP = pair_ab.bp_determine (shells_qn , shells_qn);
	
	if (BP != 0) continue;
      		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	  
	if (Jmin_ab > 1) continue;
	
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sb = shells_qn(sb);
	  
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();

	const bool ja_jb_equal = (ija == ijb);
		
	const bool is_ja_minus_half_even = (ija%2 == 0);
		
	const double ja = shell_qn_sa.get_j ();
	    
	const double minus_hat_ja_phase = (is_ja_minus_half_even) ? (-hat (ja)) : (hat (ja));
	    
	const double J_factor_vector_part_phase = (is_ja_minus_half_even) ? (J_factor_vector_part) : (-J_factor_vector_part);
	
	for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	  {
	    const class nlj_struct &shell_qn_sc = shells_qn(sc);
	      
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int ijc = shell_qn_sc.get_ij ();
      
	    const class pair_str pair_ac(sa , sc);
      		
	    const unsigned int BPp = pair_ac.bp_determine (shells_qn , shells_qn);
		
	    const bool is_sa_smaller_than_sc = (sa <= sc);
	    const bool is_sc_smaller_than_sb = (sc <= sb);
		
	    const bool are_sa_sc_equal = (sa == sc);
	    const bool are_sc_sb_equal = (sc == sb);
		
	    const bool ac_different_cb_different = (!are_sa_sc_equal && !are_sc_sb_equal);
		
	    const double jc = shell_qn_sc.get_j ();
      
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);
	    	  	  
	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	    
	    const double delta_norm_ac = (sa == sc) ? (M_SQRT2) : (1.0);
	    const double delta_norm_cb = (sc == sb) ? (M_SQRT2) : (1.0);
				      			
	    const int Jp_min_bc = Jmin_table_Gamma_pp_nn(sb , sc);	
	    const int Jp_max_bc = Jmax_table_Gamma_pp_nn(sb , sc);
				      
	    const int Jp_min_ac = Jmin_table_Gamma_pp_nn(sa , sc);	
	    const int Jp_max_ac = Jmax_table_Gamma_pp_nn(sa , sc);
				      		
	    const int Jp_min = max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = min (Jp_max_bc , Jp_max_ac);
	  
	    if ((sb == sc) && ja_jb_equal) rho_term_der_part_determine (operation , particle , ija , sa , sb , minus_hat_ja_phase , OBME_jc_J_factor_vector_part_phase);
					    	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const bool is_Jp_even = (Jp%2 == 0);
      
		if (ac_different_cb_different || is_Jp_even)
		  {
		    const unsigned int ac_index = (is_sa_smaller_than_sc) ? (two_states_indices_Gamma_pp_nn(Jp , sa , sc)) : (two_states_indices_Gamma_pp_nn(Jp , sc , sa));
		    const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_Gamma_pp_nn(Jp , sc , sb)) : (two_states_indices_Gamma_pp_nn(Jp , sb , sc));

		    const int phase_ac = (is_sa_smaller_than_sc) ? (1) : (((ija + ijc + Jp)%2 == 0) ? (1) : (-1));
		    const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (((ijc + ijb + Jp)%2 == 0) ? (1) : (-1));
					  
		    const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp)) : (NADA);
					      
		    const double gradient_ME_vector_part_no_phase = (operation == TABLES_FILL) ? (-Wigner_6j_hats*delta_norm_ac*delta_norm_cb*OBME_jc_J_factor_vector_part_phase) : (NADA);
			
		    const double gradient_ME_vector_part = (phase_ac == phase_cb) ? (gradient_ME_vector_part_no_phase) : (-gradient_ME_vector_part_no_phase);
		      
		    G_Gamma_term_der_part_determine (operation , false , sa , sb , BPp , Jp , ac_index , cb_index , gradient_ME_vector_part);
		  }
	      }
	  }
      }
}





								







void RDM_J_constraints_gradient_class::J_constraints_prot_pn_gradient_calc_store (const enum operation_type operation)
{
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    					
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
    
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
        
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sb = prot_shells_qn(sb_p);
		      	
	const class pair_str pair_ab(sa_p , sb_p);
      		
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (prot_shells_qn , prot_shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP = pair_ab.bp_determine (prot_shells_qn , prot_shells_qn);
	
	if (BP != 0) continue;
      		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , prot_shells_qn);		
	  
	if (Jmin_ab > 1) continue;
	
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();  
  		
	const double J_factor_vector_part_phase = (ija%2 == 0) ? (J_factor_vector_part) : (-J_factor_vector_part);
	
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
      		      	  
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int ijc = shell_qn_sc.get_ij ();
      
	    const class pair_str pair_ac(sa_p , sc_n);
      		
	    const unsigned int BPp = pair_ac.bp_determine (prot_shells_qn , neut_shells_qn);
		
	    const double jc = shell_qn_sc.get_j ();
      
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);
	    
	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	    
	    const int Jp_min_bc = Jmin_table_Gamma_pn(sb_p , sc_n);	
	    const int Jp_max_bc = Jmax_table_Gamma_pn(sb_p , sc_n);

	    const int Jp_min_ac = Jmin_table_Gamma_pn(sa_p , sc_n);	
	    const int Jp_max_ac = Jmax_table_Gamma_pn(sa_p , sc_n);
	      	
	    const int Jp_min = max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = min (Jp_max_bc , Jp_max_ac);
				    	  					
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const unsigned int ac_index = two_states_indices_Gamma_pn(Jp , sa_p , sc_n);
		const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sb_p , sc_n);
			  		  
		const int phase_cb = ((ijc + ijb + Jp)%2 == 0) ? (1) : (-1);
			
		const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp)) : (NADA);
					
		const double gradient_ME_vector_part_no_phase = (operation == TABLES_FILL) ? (-Wigner_6j_hats*OBME_jc_J_factor_vector_part_phase) : (NADA);
			
		const double gradient_ME_vector_part = (phase_cb == 1) ? (gradient_ME_vector_part_no_phase) : (-gradient_ME_vector_part_no_phase);
			
		G_Gamma_term_der_part_determine (operation , true , sa_p , sb_p , BPp , Jp , ac_index , cb_index , gradient_ME_vector_part);
	      }
	  }
      }
}













void RDM_J_constraints_gradient_class::J_constraints_neut_pn_gradient_calc_store (const enum operation_type operation)
{  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
          
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
        
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
      
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
      
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {  	      		
	const class pair_str pair_ab(sa_n , sb_n);
      		
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (neut_shells_qn , neut_shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP = pair_ab.bp_determine (neut_shells_qn , neut_shells_qn);
	
	if (BP != 0) continue;
      			
	const int Jmin_ab = pair_ab.Jmin_determine (neut_shells_qn , neut_shells_qn);		
	  
	if (Jmin_ab > 1) continue;
  	  	        
	const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
	const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
	
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();
	
	const double J_factor_vector_part_phase = (ija%2 == 0) ? (J_factor_vector_part) : (-J_factor_vector_part);
	
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
      		      	
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int ijc = shell_qn_sc.get_ij ();
      		
	    const class pair_str pair_ac(sa_n , sc_p);
      		
	    const unsigned int BPp = pair_ac.bp_determine (neut_shells_qn , prot_shells_qn);
		
	    const double jc = shell_qn_sc.get_j ();
      
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);
	    
	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	    
	    const int Jp_min_bc = Jmin_table_Gamma_pn(sc_p , sb_n);	
	    const int Jp_max_bc = Jmax_table_Gamma_pn(sc_p , sb_n);

	    const int Jp_min_ac = Jmin_table_Gamma_pn(sc_p , sa_n);	
	    const int Jp_max_ac = Jmax_table_Gamma_pn(sc_p , sa_n);
	      	
	    const int Jp_min = max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = min (Jp_max_bc , Jp_max_ac);
					      	  	  	  			
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const unsigned int ac_index = two_states_indices_Gamma_pn(Jp , sc_p , sa_n);
		const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sc_p , sb_n);
	  
		const int phase_ca = ((ijc + ija + Jp)%2 == 0) ? (1) : (-1);
	    					  
		const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp)) : (NADA);
			
		const double gradient_ME_vector_part_no_phase = (operation == TABLES_FILL) ? (-Wigner_6j_hats*OBME_jc_J_factor_vector_part_phase) : (NADA);
			
		const double gradient_ME_vector_part = (phase_ca == 1) ? (gradient_ME_vector_part_no_phase) : (-gradient_ME_vector_part_no_phase);

		G_Gamma_term_der_part_determine (operation , true , sa_n , sb_n , BPp , Jp , ac_index , cb_index , gradient_ME_vector_part);
	      }
	  }
      }
}












void RDM_J_constraints_gradient_class::J_constraints_gradients_alloc_calc_store ()
{  
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data ());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int J_constraints_matrix_dimension = N_nlj;
    
  const class RDM_PQG_class &Gamma_pp_nn = get_Gamma_pp_nn ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions_pp_nn = Gamma_pp_nn.get_matrix_dimensions ();
  
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
  
  const int Jmax_pp_nn_total_plus_one = J_constraints_gradient_non_trivial_zero_numbers_pp_nn.dimension (1);
  
  const int Jmax_pn_total_plus_one = J_constraints_gradient_non_trivial_zero_numbers_pn.dimension (1);

  J_constraints_pp_nn_gradient_calc_store (DIMENSIONS_TABLES_CALC);
  
  switch (particle)
    {
    case PROTON:  J_constraints_prot_pn_gradient_calc_store (DIMENSIONS_TABLES_CALC); break;      
    case NEUTRON: J_constraints_neut_pn_gradient_calc_store (DIMENSIONS_TABLES_CALC); break;  
      
    default: abort_all ();
    }  
    		  	    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      const unsigned int J_constraints_matrix_non_trivial_zero_number = J_constraints_gradient_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	    
	      if (J_constraints_matrix_non_trivial_zero_number > 0)
		{
		  if (is_J_non_zero) J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (J_constraints_matrix_dimension , J_constraints_matrix_non_trivial_zero_number);
		  
		  J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (J_constraints_matrix_dimension , J_constraints_matrix_non_trivial_zero_number);
		}
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      const unsigned int J_constraints_matrix_non_trivial_zero_number = J_constraints_gradient_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index);
	    
	      if (J_constraints_matrix_non_trivial_zero_number > 0)
		{
		  if (is_J_non_zero) J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (J_constraints_matrix_dimension , J_constraints_matrix_non_trivial_zero_number);
		  
		  J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (J_constraints_matrix_dimension , J_constraints_matrix_non_trivial_zero_number);
		}
	    }
      }
	
  J_constraints_gradient_non_trivial_zero_numbers_pp_nn = 0;
  J_constraints_gradient_non_trivial_zero_numbers_pn    = 0;
	
  J_constraints_pp_nn_gradient_calc_store (TABLES_FILL);
  
  switch (particle)
    {
    case PROTON:  J_constraints_prot_pn_gradient_calc_store (TABLES_FILL); break;      
    case NEUTRON: J_constraints_neut_pn_gradient_calc_store (TABLES_FILL); break;  
      
    default: abort_all ();
    }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);

	      if (is_J_non_zero)
		{
		  class sparse_matrix<TYPE> &J_constraints_gradient_scalar_part_pp_nn_matrix = J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
		  
		  if (J_constraints_gradient_scalar_part_pp_nn_matrix.is_it_filled ()) J_constraints_gradient_scalar_part_pp_nn_matrix.make_it_consistent_no_zeros ();
		}
	      
	      class sparse_matrix<TYPE> &J_constraints_gradient_vector_part_pp_nn_matrix = J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);

	      if (J_constraints_gradient_vector_part_pp_nn_matrix.is_it_filled ()) J_constraints_gradient_vector_part_pp_nn_matrix.make_it_consistent_no_zeros ();
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      if (is_J_non_zero)
		{
		  class sparse_matrix<TYPE> &J_constraints_gradient_scalar_part_pn_matrix = J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index);

		  if (J_constraints_gradient_scalar_part_pn_matrix.is_it_filled ()) J_constraints_gradient_scalar_part_pn_matrix.make_it_consistent_no_zeros ();
		}
	      
	      class sparse_matrix<TYPE> &J_constraints_gradient_vector_part_pn_matrix = J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      	      
	      if (J_constraints_gradient_vector_part_pn_matrix.is_it_filled ()) J_constraints_gradient_vector_part_pn_matrix.make_it_consistent_no_zeros ();
	    }
      }
}


  


void RDM_J_constraints_gradient_class::fill_part (
						  const bool is_it_der_pn , 
						  const unsigned int BPp ,
						  const int Jp ,
						  const unsigned int ip_jp_upper_triangular_index , 
						  const RDM_J_constraints_gradient_class &A)
{
  if (!is_it_filled ()) return;
  
  if (!A.is_it_filled ()) return;

  if (is_it_der_pn)
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index) = A.J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
      
      J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index) = A.J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index);
    }
  else
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) = A.J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);

      J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) = A.J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
    }
}

  
  


void RDM_J_constraints_gradient_class::multiply_part (
						      const bool is_it_der_pn , 
						      const unsigned int BPp ,
						      const int Jp ,
						      const unsigned int ip_jp_upper_triangular_index , 
						      const TYPE &x)
{
  if (!is_it_filled ()) return;

  if (is_it_der_pn)
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index) *= x;
      
      J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index) *= x;
    }
  else
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) *= x;
      
      J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) *= x;
    }
}

  

void RDM_J_constraints_gradient_class::divide_part (
						    const bool is_it_der_pn , 
						    const unsigned int BPp ,
						    const int Jp ,
						    const unsigned int ip_jp_upper_triangular_index , 
						    const TYPE &x)
{
   if (!is_it_filled ()) return;

  if (is_it_der_pn)
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pn(BPp , Jp , ip_jp_upper_triangular_index) /= x;
      
      J_constraints_gradient_vector_part_pn(BPp , Jp , ip_jp_upper_triangular_index) /= x;
    }
  else
    {
      if (is_J_non_zero) J_constraints_gradient_scalar_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) /= x;

      J_constraints_gradient_vector_part_pp_nn(BPp , Jp , ip_jp_upper_triangular_index) /= x;
    }
}

  






TYPE Frobenius_scalar_product_matrix_gradient (
					       const bool is_it_der_pn , 
					       const unsigned int BPp ,
					       const int Jp ,
					       const unsigned int ip_jp_upper_triangular_index , 
					       const class RDM_J_constraints_class &A ,
					       const class RDM_J_constraints_gradient_class &B)
{
  if (!A.is_it_filled ()) return 0.0;
  if (!B.is_it_filled ()) return 0.0;
  
  const class matrix<TYPE> &A_matrix_scalar_part = A.J_constraints_matrix_scalar_part;
  const class matrix<TYPE> &A_matrix_vector_part = A.J_constraints_matrix_vector_part;
    
  const class array<class sparse_matrix<TYPE> > &B_J_constraints_gradient_scalar_part = (is_it_der_pn) ? (B.J_constraints_gradient_scalar_part_pn) : (B.J_constraints_gradient_scalar_part_pp_nn);
  const class array<class sparse_matrix<TYPE> > &B_J_constraints_gradient_vector_part = (is_it_der_pn) ? (B.J_constraints_gradient_vector_part_pn) : (B.J_constraints_gradient_vector_part_pp_nn);
  
  const class sparse_matrix<TYPE> &B_sparse_matrix_scalar_part = B_J_constraints_gradient_scalar_part(BPp , Jp , ip_jp_upper_triangular_index);
  const class sparse_matrix<TYPE> &B_sparse_matrix_vector_part = B_J_constraints_gradient_vector_part(BPp , Jp , ip_jp_upper_triangular_index);
  
  const unsigned int B_non_trivial_zero_number_scalar_part = B_sparse_matrix_scalar_part.get_non_trivial_zeros_number ();
  const unsigned int B_non_trivial_zero_number_vector_part = B_sparse_matrix_vector_part.get_non_trivial_zeros_number ();
  
  TYPE AB_scalar_product = 0.0;

  if (A.is_J_non_zero && A_matrix_scalar_part.is_it_filled () && B_sparse_matrix_scalar_part.is_it_filled ())
    {
      if (A.J_constraints_matrix_scalar_part.get_dimension () != B_sparse_matrix_scalar_part.get_dimension ()) error_message_print_abort ("A and B_sparse_matrix_scalar_part must have the same dimension in Frobenius_scalar_product_gradient");
  
      for (unsigned int index = 0 ; index < B_non_trivial_zero_number_scalar_part ; index++)
	{
	  const unsigned int i = B_sparse_matrix_scalar_part.get_row_index (index);
      
	  const unsigned int j = B_sparse_matrix_scalar_part.get_column_index (index);

	  const TYPE &B_ME = B_sparse_matrix_scalar_part.get_matrix_element (index);
      
	  AB_scalar_product += A_matrix_scalar_part(i , j)*B_ME;
	}
    }
  
  if (A_matrix_vector_part.is_it_filled () && B_sparse_matrix_vector_part.is_it_filled ())
    {
      if (A.J_constraints_matrix_vector_part.get_dimension () != B_sparse_matrix_vector_part.get_dimension ()) error_message_print_abort ("A and B_sparse_matrix_vector_part must have the same dimension in Frobenius_scalar_product_gradient");
  
      for (unsigned int index = 0 ; index < B_non_trivial_zero_number_vector_part ; index++)
	{
	  const unsigned int i = B_sparse_matrix_vector_part.get_row_index (index);
      
	  const unsigned int j = B_sparse_matrix_vector_part.get_column_index (index);

	  const TYPE &B_ME = B_sparse_matrix_vector_part.get_matrix_element (index);
      
	  AB_scalar_product += A_matrix_vector_part(i , j)*B_ME;
	}
    }
  
  return AB_scalar_product;
}


TYPE Frobenius_squared_norm_gradient (
				      const bool is_it_der_pn , 
				      const unsigned int BPp ,
				      const int Jp ,
				      const unsigned int ip_jp_upper_triangular_index ,
				      const class RDM_J_constraints_gradient_class &A)
{  
  if (!A.is_it_filled ()) return 0.0;
  
  const class array<class sparse_matrix<TYPE> > &J_constraints_gradient_vector_part = (is_it_der_pn) ? (A.J_constraints_gradient_vector_part_pn) : (A.J_constraints_gradient_vector_part_pp_nn);

  const class sparse_matrix<TYPE> &A_sparse_matrix_vector_part = J_constraints_gradient_vector_part(BPp , Jp , ip_jp_upper_triangular_index);
      
  const TYPE Frobenius_squared_norm_vector_part = A_sparse_matrix_vector_part.Frobenius_squared_norm ();
      
  if (A.is_J_non_zero)
    {
      const class array<class sparse_matrix<TYPE> > &J_constraints_gradient_scalar_part = (is_it_der_pn) ? (A.J_constraints_gradient_scalar_part_pn) : (A.J_constraints_gradient_scalar_part_pp_nn);
  
      const class sparse_matrix<TYPE> &A_sparse_matrix_scalar_part = J_constraints_gradient_scalar_part(BPp , Jp , ip_jp_upper_triangular_index);
  
      const TYPE Frobenius_squared_norm_scalar_part = A_sparse_matrix_scalar_part.Frobenius_squared_norm ();

      const TYPE Frobenius_squared_norm = Frobenius_squared_norm_scalar_part + Frobenius_squared_norm_vector_part;
    
      return Frobenius_squared_norm;
    }
  else
    return Frobenius_squared_norm_vector_part;
}



