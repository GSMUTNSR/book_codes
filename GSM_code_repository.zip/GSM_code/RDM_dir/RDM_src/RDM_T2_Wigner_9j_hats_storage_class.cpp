#include "../RDM_include/RDM_include_def.h"

using namespace correlated_state_routines;




RDM_T2_Wigner_9j_hats_storage_class::RDM_T2_Wigner_9j_hats_storage_class () {}





RDM_T2_Wigner_9j_hats_storage_class::RDM_T2_Wigner_9j_hats_storage_class (
									  const class nucleons_data &prot_data ,
									  const class nucleons_data &neut_data)
{
  alloc_calc_store (prot_data , neut_data);
}


RDM_T2_Wigner_9j_hats_storage_class::RDM_T2_Wigner_9j_hats_storage_class (const class RDM_T2_Wigner_9j_hats_storage_class &X)
{
  allocate_fill (X);
}

RDM_T2_Wigner_9j_hats_storage_class::~RDM_T2_Wigner_9j_hats_storage_class () {}




void RDM_T2_Wigner_9j_hats_storage_class::alloc_calc_store (
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_T2_Wigner_9j_hats_storage_class::alloc_calc_store");
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
  
  const int Jmax_pair = make_int (2.0*jmax);
  
  const int Jmax_pair_plus_one = Jmax_pair + 1;
  
  const double Jmax_total = Jmax_pair + jmax;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
                        
  three_states_indices.allocate (j_number , j_number , j_number , Jmax_pair_plus_one , J_total_number);
                
  three_states_indices = three_states_indices.dimension_total ();
  
  unsigned int three_states_dimension = 0;
      
  for (int ija = 0 ; ija < j_number ; ija++)
    for (int ijb = 0 ; ijb < j_number ; ijb++)
      {	  
	const int Jmin_ab = abs (ija - ijb);
	
	const int Jmax_ab = ija + ijb + 1;
	
	for (int ijc = 0 ; ijc < j_number ; ijc++)
	  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
	    {		    
	      const int iJmin_abc = (Jab <= ijc) ? (ijc - Jab) : (Jab - ijc - 1);
	
	      const int iJmax_abc = Jab + ijc;
	    
	      const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
	      for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
		{
		  const int iJ = iJ0 + iJmin_abc;
					  					  
		  three_states_indices(ija , ijb , ijc , Jab , iJ) = three_states_dimension++;
		}
	    }
      }
  
  Wigner_9j_hats_indices.allocate (j_number , j_number , Jmax_pair_plus_one , Jmax_pair_plus_one , three_states_dimension);
  
  Wigner_9j_hats_indices = Wigner_9j_hats_indices.dimension_total ();
  
  unsigned int dimension = 0;
  
  Wigner_9j_hats_indices_tabs_determine (DIMENSIONS_TABLES_CALC , prot_data , neut_data , dimension);

  Wigner_9j_hats_tab.allocate (dimension);

  dimension = 0;
  
  Wigner_9j_hats_tab = 0.0;

  Wigner_9j_hats_indices_tabs_determine (TABLES_FILL , prot_data , neut_data , dimension);
}





void RDM_T2_Wigner_9j_hats_storage_class::allocate_fill (const class RDM_T2_Wigner_9j_hats_storage_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_T2_Wigner_9j_hats_storage_class::allocate_fill");
  
  three_states_indices.allocate_fill (X.three_states_indices);
  
  Wigner_9j_hats_indices.allocate_fill (X.Wigner_9j_hats_indices);
    
  Wigner_9j_hats_tab.allocate_fill (X.Wigner_9j_hats_tab);
}





void RDM_T2_Wigner_9j_hats_storage_class::deallocate ()
{
  three_states_indices.deallocate ();
  
  Wigner_9j_hats_indices.deallocate ();
  
  Wigner_9j_hats_tab.deallocate ();
}








void RDM_T2_Wigner_9j_hats_storage_class::Wigner_9j_hats_indices_tabs_determine (
										 const enum operation_type operation ,
										 const class nucleons_data &prot_data ,
										 const class nucleons_data &neut_data ,
										 unsigned int &dimension)
{
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
                            
  for (int ija = 0 ; ija < j_number ; ija++)
    for (int ijb = 0 ; ijb < j_number ; ijb++)
      for (int ijc = 0 ; ijc < j_number ; ijc++)
	{	  
	  const double ja = ija + 0.5;
	  const double jb = ijb + 0.5;
	  const double jc = ijc + 0.5;
	  
	  const int Jmin_ab = abs (ija - ijb);
	
	  const int Jmax_ab = ija + ijb + 1;
	
	  const int ijd = ijb;
	      
	  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
	    {		    
	      const int iJmin_abc = (Jab <= ijc) ? (ijc - Jab) : (Jab - ijc - 1);
	
	      const int iJmax_abc = Jab + ijc;
	    
	      const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
	      for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
		{
		  const int iJ = iJ0 + iJmin_abc;

		  const double J = iJ + 0.5;
		  
		  const unsigned int abc_index = three_states_indices(ija , ijb , ijc , Jab , iJ);

		  for (int ije = 0 ; ije < j_number ; ije++)
		    for (int ijf = 0 ; ijf < j_number ; ijf++)
		      {		      
			const double je = ije + 0.5;
			const double jf = ijf + 0.5;
	  	  
			const int Jmin_ce_jc_je = abs (ijc - ije);
			const int Jmin_de_ja_je = abs (ijd - ije);
			    
			const int Jmax_ce_jc_je = ijc + ije + 1;
			const int Jmax_de_ja_je = ijd + ije + 1;
      
			const int Jmin_ce_ja_jf = abs (ija - ijf);
			const int Jmin_de_J_jf  = abs (iJ  - ijf);
	      
			const int Jmax_ce_ja_jf = ija + ijf + 1;
			const int Jmax_de_J_jf  = iJ  + ijf + 1;
	     
			const double Jmin_ce = max (Jmin_ce_jc_je , Jmin_ce_ja_jf);
			const double Jmax_ce = min (Jmax_ce_jc_je , Jmax_ce_ja_jf);
	      
			const double Jmin_de = max (Jmin_de_ja_je , Jmin_de_J_jf);
			const double Jmax_de = min (Jmax_de_ja_je , Jmax_de_J_jf);

			switch (operation)
			  {
			  case DIMENSIONS_TABLES_CALC:
			    {
			      for (int Jce = Jmin_ce ; Jce <= Jmax_ce ; Jce++)
				for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
				  Wigner_9j_hats_indices(ije , ijf , Jce , Jde , abc_index) = dimension++;
		    
			    } break;
 
			  case TABLES_FILL:
			    {
			      for (int Jce = Jmin_ce ; Jce <= Jmax_ce ; Jce++)
				for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
				  Wigner_9j_hats_tab(dimension++) = Wigner_9j (J , jf , Jde , jc , Jce , je , Jab , ja , jb)*(2*Jce + 1)*hat (Jde)*hat (Jab);
		  
			    } break;

			  default: abort_all ();
			  }}}}}
}








