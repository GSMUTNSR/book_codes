#include "../RDM_include/RDM_include_def.h"

using namespace inputs_misc;
using namespace RDM_rho_observables;
using namespace RDM_rho_observables_gradient;



// Calculations of one-dimensional dimensions and arrays of a (BP,J,index) array for parallelization
// -------------------------------------------------------------------------------------------------

unsigned int RDM_Hessian_vector_no_sigma::BPp_Jp_index_prime_dimension_calc (const class array<unsigned int> &matrix_dimensions)
{
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  unsigned int BPp_Jp_index_prime_dimension = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	const unsigned int N = (dimension_BPp_Jp%2 == 0) ? ((dimension_BPp_Jp/2)*(dimension_BPp_Jp + 1)) : (dimension_BPp_Jp*((dimension_BPp_Jp + 1)/2));

	BPp_Jp_index_prime_dimension += N;
      }

  return BPp_Jp_index_prime_dimension;
}



void RDM_Hessian_vector_no_sigma::BPp_Jp_index_prime_arrays_calc (
								  const class array<unsigned int> &matrix_dimensions ,
								  class array<unsigned int> &BPp_indices ,
								  class array<int> &Jp_indices ,
								  class array<unsigned int> &index_prime_indices)
{  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  unsigned int BPp_Jp_index_prime_index = 0;
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	const unsigned int N = (dimension_BPp_Jp%2 == 0) ? ((dimension_BPp_Jp/2)*(dimension_BPp_Jp + 1)) : (dimension_BPp_Jp*((dimension_BPp_Jp + 1)/2));

	for (unsigned int index_prime = 0 ; index_prime < N ; index_prime++)
	  {
	    BPp_indices(BPp_Jp_index_prime_index) = BPp;

	    Jp_indices(BPp_Jp_index_prime_index) = Jp;

	    index_prime_indices(BPp_Jp_index_prime_index) = index_prime;
	    
	    BPp_Jp_index_prime_index++;
	  }
      }

  const unsigned int N_random_tries = 5;

  for (unsigned int i = 0 ; i < N_random_tries ; i++)
    {  
      const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_index;
      
      for (unsigned int BPp_Jp_index_prime_index = 0 ; BPp_Jp_index_prime_index < BPp_Jp_index_prime_dimension  ; BPp_Jp_index_prime_index++)
	{
	  const unsigned random_BPp_Jp_index_prime_index = rand_int (BPp_Jp_index_prime_dimension);
	  
	  swap<unsigned int> (BPp_indices(BPp_Jp_index_prime_index) , BPp_indices(random_BPp_Jp_index_prime_index));
      
	  swap<int> (Jp_indices(BPp_Jp_index_prime_index) , Jp_indices(random_BPp_Jp_index_prime_index));
      
	  swap<unsigned int> (index_prime_indices(BPp_Jp_index_prime_index) , index_prime_indices(random_BPp_Jp_index_prime_index));
	}
    }
}



unsigned int RDM_Hessian_vector_no_sigma::dimension_part_calc (const class block_matrix<TYPE> &X)
{
  const unsigned int blocks_number = X.get_blocks_number ();

  unsigned int dimension = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &Xi = X(i);
      
      const unsigned int block_dimension = Xi.get_dimension ();

      dimension += (block_dimension*(block_dimension + 1))/2;
    }

  return dimension;
}



unsigned int RDM_Hessian_vector_no_sigma::dimension_calc (
							  const class block_matrix<TYPE> &X_pp ,
							  const class block_matrix<TYPE> &X_nn ,
							  const class block_matrix<TYPE> &X_pn ,
							  const class block_matrix<TYPE> &X_rho_pp ,
							  const class block_matrix<TYPE> &X_rho_nn)
{
  const unsigned int dimension = dimension_part_calc (X_pp) + dimension_part_calc (X_nn) + dimension_part_calc (X_pn) + dimension_part_calc (X_rho_pp) + dimension_part_calc (X_rho_nn);

  return dimension;
}




class matrix<TYPE> & RDM_Hessian_vector_no_sigma::matrix_pp_nn_pn_part_determine (
										  const bool is_it_rho , 
										  const enum space_type space ,
										  const unsigned int i_part ,
										  class block_matrix<TYPE> &Vpp , 
										  class block_matrix<TYPE> &Vnn , 
										  class block_matrix<TYPE> &Vpn , 
										  class block_matrix<TYPE> &Vpp_rho , 
										  class block_matrix<TYPE> &Vnn_rho)
{
  if (is_it_rho)
    {
      switch (space)
	{
	case PROTONS_ONLY:  return Vpp_rho(i_part);	  
	case NEUTRONS_ONLY: return Vnn_rho(i_part);	
      
	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROTONS_ONLY:     return Vpp(i_part);	  
	case NEUTRONS_ONLY:    return Vnn(i_part);	  
	case PROTONS_NEUTRONS: return Vpn(i_part);
      
	default: abort_all ();
	}
    }
  
  return Vpn(i_part);
}



const class matrix<TYPE> & RDM_Hessian_vector_no_sigma::matrix_pp_nn_pn_part_determine (
											const bool is_it_rho , 
											const enum space_type space ,
											const unsigned int i_part ,
											const class block_matrix<TYPE> &Vpp , 
											const class block_matrix<TYPE> &Vnn , 
											const class block_matrix<TYPE> &Vpn , 
											const class block_matrix<TYPE> &Vpp_rho , 
											const class block_matrix<TYPE> &Vnn_rho)
{
  if (is_it_rho)
    {
      switch (space)
	{
	case PROTONS_ONLY:  return Vpp_rho(i_part);	  
	case NEUTRONS_ONLY: return Vnn_rho(i_part);	
      
	default: abort_all ();
	}
    }
  else
    {
      switch (space)
	{
	case PROTONS_ONLY:     return Vpp(i_part);	  
	case NEUTRONS_ONLY:    return Vnn(i_part);	  
	case PROTONS_NEUTRONS: return Vpn(i_part);
      
	default: abort_all ();
	}
    }
  
  return Vpn(i_part);
}







void RDM_Hessian_vector_no_sigma::pp_nn_part_calc (
						   const enum particle_type particle ,
						   const class RDM_conditions_class &VX ,
						   const class RDM_conditions_gradient_class &A_Gamma_gradients ,
						   class block_matrix<TYPE> &HF_X_pp_nn , 
						   class block_matrix<TYPE> &HF_X_rho_pp_nn) 
{
  const enum particle_type particle_other_space = (particle == PROTON) ? (NEUTRON) : (PROTON);

  const enum space_type space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);

  const bool is_there_G_constraint = VX.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = VX.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = VX.get_is_there_T2_prime_constraint ();
  
  const bool is_there_CM_correction = VX.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = VX.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = VX.get_is_there_E_reference ();
  
  const TYPE Delta_pp_nn_pairs_number_dependent_term = VX.get_Delta_pairs_number_dependent_term (space);
  
  const TYPE Delta_J_dependent_term = VX.get_Delta_J_dependent_term ();
  
  const TYPE Delta_E_reference_dependent_term = VX.get_Delta_E_reference_dependent_term ();
    
  const TYPE Delta_Hcm_dependent_term = VX.get_Delta_Hcm_dependent_term ();
                
  const class array<double> &Delta_J_der_tab = A_Gamma_gradients.get_Delta_J_der_tab (space);
        
  const class block_matrix<TYPE> &Delta_E_reference_der_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (space);
        
  const class block_matrix<TYPE> &Delta_Hcm_der_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (space);
  
  const class RDM_PQG_class &P_pp_nn_dependent_term = VX.get_P_dependent_term (space);
  
  const class RDM_rho_coupled_modified_class &rho_coupled_modified_pp_nn_dependent_term = VX.get_rho_coupled_modified_dependent_term (particle);
  
  const class array<unsigned int> &matrix_dimensions = P_pp_nn_dependent_term.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;      
          
  const int jmax_ab_global = rho_coupled_modified_pp_nn_dependent_term.get_jmax_ab_global ();
  
  const class block_matrix<TYPE> &P_pp_nn_dependent_term_block_matrix = VX.get_P_dependent_term_block_matrix (space);
  const class block_matrix<TYPE> &Q_pp_nn_dependent_term_block_matrix = VX.get_Q_dependent_term_block_matrix (space);
  const class block_matrix<TYPE> &G_pp_nn_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (space , particle);
  
  const class RDM_J_constraints_class &J_constraints_pp_nn = VX.get_J_constraints_dependent_term (particle);
  
  const class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix = VX.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
    
  const class block_matrix<TYPE> &G_pn_np_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , particle_other_space);
  
  const class block_matrix<TYPE> &T1_ppp_nnn_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (space , particle);  

  const class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  const class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
  const class block_matrix<TYPE> &T2_prime_ppp_nnn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (space , particle);
    
  const class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  const class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  const class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
    
  const class block_matrix<TYPE> &rho_coupled_modified_pp_nn_dependent_term_block_matrix = VX.get_rho_coupled_modified_dependent_term_block_matrix (particle);
  
  const class RDM_QG_gradient_class &Q_pp_nn_gradient = A_Gamma_gradients.get_Q_gradient (space);
  
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_nn_gradient = A_Gamma_gradients.get_G_gradient (space            , particle);
  const class RDM_QG_gradient_class &G_pn_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , particle_other_space);
  
  const class RDM_J_constraints_gradient_class &J_constraints_pp_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (particle);
      
  const class RDM_T1_gradient_class &T1_ppp_nnn_gradient = A_Gamma_gradients.get_T1_gradient (space , particle);
    
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppp_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (space , particle);  
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);
  
  const class array<class block_sparse_matrix<TYPE> > &Q_pp_nn_der_pp_nn_block_matrices = Q_pp_nn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pp_nn_block_matrices = Q_pn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_nn_der_pp_nn_block_matrices = G_pp_nn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_np_der_pp_nn_block_matrices = G_pn_np_gradient.get_block_matrices (space);
      
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_nnn_der_pp_nn_block_matrices = T1_ppp_nnn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pp_nn_block_matrices = T1_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pp_nn_block_matrices = T1_nnp_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_nnn_der_pp_nn_block_matrices = T2_prime_ppp_nnn_gradient.get_block_matrices (space);
  		
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pp_nn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pp_nn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pp_nn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pp_nn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (space);

  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
  
  HF_X_pp_nn.zero ();
 
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
      
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {  
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);
	
	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    
	      const class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix = Q_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
  
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix = Q_pn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		
	      class matrix<TYPE> &HF_X_pp_nn_BPp_Jp = HF_X_pp_nn(BPp + 2*Jp);
	  
	      TYPE &HF_X_pp_nn_ME = HF_X_pp_nn_BPp_Jp(ip , jp);
	      
	      if (Q_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (Q_pp_nn_dependent_term_block_matrix , Q_pp_nn_der_pp_nn_block_matrix);
	      
	      if (is_there_G_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix = G_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix = G_pn_np_der_pp_nn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (G_pp_nn_dependent_term_block_matrix , G_pp_nn_der_pp_nn_block_matrix);
		  if (G_pn_np_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (G_pn_np_dependent_term_block_matrix , G_pn_np_der_pp_nn_block_matrix);
		}
	      
	      if (are_there_J_constraints) HF_X_pp_nn_ME += Frobenius_scalar_product_matrix_gradient (false , BPp , Jp , index_prime , J_constraints_pp_nn , J_constraints_pp_nn_gradient);
	      
	      if (Q_pn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (Q_pn_dependent_term_block_matrix , Q_pn_der_pp_nn_block_matrix);
	      
	      if (is_there_T1_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix = T1_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix = T1_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix = T1_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		
		  if (T1_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T1_ppp_nnn_dependent_term_block_matrix , T1_ppp_nnn_der_pp_nn_block_matrix);
		    
		  if (T1_ppn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T1_ppn_dependent_term_block_matrix , T1_ppn_der_pp_nn_block_matrix);
		  if (T1_nnp_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T1_nnp_dependent_term_block_matrix , T1_nnp_der_pp_nn_block_matrix);
		}
	      
	      if (is_there_T2_prime_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix = T2_prime_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix = T2_prime_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix = T2_prime_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix = T2_prime_pnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix = T2_prime_pnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T2_prime_ppp_nnn_dependent_term_block_matrix , T2_prime_ppp_nnn_der_pp_nn_block_matrix);
		    
		  if (T2_prime_ppn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T2_prime_ppn_dependent_term_block_matrix , T2_prime_ppn_der_pp_nn_block_matrix);
		  if (T2_prime_nnp_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T2_prime_nnp_dependent_term_block_matrix , T2_prime_nnp_der_pp_nn_block_matrix);		  
		  if (T2_prime_pnp_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T2_prime_pnp_dependent_term_block_matrix , T2_prime_pnp_der_pp_nn_block_matrix);
		  if (T2_prime_pnn_der_pp_nn_block_matrix.is_it_filled ()) HF_X_pp_nn_ME += Frobenius_scalar_product (T2_prime_pnn_dependent_term_block_matrix , T2_prime_pnn_der_pp_nn_block_matrix);
		}
	    }
	}
  
#ifdef UseMPI
      if (is_it_MPI_parallelized) HF_X_pp_nn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
  
    }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);

	const unsigned int BPp_Jp_index = BPp + 2*Jp;

	const TYPE Delta_pp_nn_pairs_number_dependent_term_times_der = Delta_pp_nn_pairs_number_dependent_term*(2*Jp + 1);
	
	const class matrix<TYPE> &Delta_E_reference_der_block_matrix_BPp_Jp = Delta_E_reference_der_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_block_matrix_BPp_Jp = Delta_Hcm_der_block_matrix(BPp_Jp_index);
		
	const class matrix<TYPE> &P_pp_nn_dependent_term_block_matrix_BPp_Jp = P_pp_nn_dependent_term_block_matrix(BPp_Jp_index);	
	
	class matrix<TYPE> &HF_X_pp_nn_BPp_Jp = HF_X_pp_nn(BPp_Jp_index);
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      TYPE &HF_X_pp_nn_ME = HF_X_pp_nn_BPp_Jp(ip , jp);

	      HF_X_pp_nn_ME += (ip == jp) ? (P_pp_nn_dependent_term_block_matrix_BPp_Jp(ip , ip)) : (2.0*P_pp_nn_dependent_term_block_matrix_BPp_Jp(ip , jp));
	      
	      if (is_there_E_reference) HF_X_pp_nn_ME += Delta_E_reference_dependent_term*Delta_E_reference_der_block_matrix_BPp_Jp(ip , jp);
	      
	      if (is_there_CM_correction) HF_X_pp_nn_ME += Delta_Hcm_dependent_term*Delta_Hcm_der_block_matrix_BPp_Jp(ip , jp);
	    }
	
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {
	    TYPE &HF_X_pp_nn_ME = HF_X_pp_nn_BPp_Jp(ip , ip);
	    
	    HF_X_pp_nn_ME += Delta_pp_nn_pairs_number_dependent_term_times_der;

	    HF_X_pp_nn_ME += Delta_J_dependent_term*Delta_J_der_tab(BPp , Jp , ip);
	  }
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    HF_X_pp_nn_BPp_Jp(jp , ip) = HF_X_pp_nn_BPp_Jp(ip , jp);
      }
  
  if (are_there_J_constraints && (jmax_ab_global > 0))
    {
      HF_X_rho_pp_nn.zero ();
  
      for (unsigned int bp = 0 ; bp <= 1 ; bp++)  
	for (int j = 0 ; j <= jmax_ab_global ; j++)
	  {	
	    const unsigned int bp_j_index = bp + 2*j;
	
	    const class matrix<TYPE> &rho_coupled_modified_pp_nn_dependent_term_block_matrix_bp_j = rho_coupled_modified_pp_nn_dependent_term_block_matrix(bp_j_index);
	
	    const unsigned int dimension_bp_j = rho_coupled_modified_pp_nn_dependent_term_block_matrix_bp_j.get_dimension ();
		
	    class matrix<TYPE> &HF_X_rho_pp_nn_bp_j = HF_X_rho_pp_nn(bp_j_index);
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index <= sb_bp_index ; sa_bp_index++)
		{
		  TYPE &HF_X_rho_pp_nn_ME = HF_X_rho_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	      
		  HF_X_rho_pp_nn_ME += (sa_bp_index == sb_bp_index) ? (rho_coupled_modified_pp_nn_dependent_term_block_matrix_bp_j(sa_bp_index , sa_bp_index)) : (2.0*rho_coupled_modified_pp_nn_dependent_term_block_matrix_bp_j(sa_bp_index , sb_bp_index));
	      
		  if (are_there_J_constraints) HF_X_rho_pp_nn_ME += Frobenius_scalar_product_matrix_rho_coupled_modified_gradient (j , sa_bp_index , sb_bp_index , J_constraints_pp_nn);
		}
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index < sb_bp_index ; sa_bp_index++)
		HF_X_rho_pp_nn_bp_j(sb_bp_index , sa_bp_index) = HF_X_rho_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	  }
    }
}















void RDM_Hessian_vector_no_sigma::pn_part_calc (
						const class RDM_conditions_class &VX ,		 
						const class RDM_conditions_gradient_class &A_Gamma_gradients , 
						class block_matrix<TYPE> &HF_X_pn)
{
  const class RDM_PQG_class &P_pn_dependent_term = VX.get_P_dependent_term (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &matrix_dimensions = P_pn_dependent_term.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const bool is_there_G_constraint = VX.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = VX.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = VX.get_is_there_T2_prime_constraint ();
  
  const bool is_there_CM_correction = VX.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = VX.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = VX.get_is_there_E_reference ();
  
  const TYPE Delta_pn_pairs_number_dependent_term = VX.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);
    
  const TYPE Delta_J_dependent_term = VX.get_Delta_J_dependent_term ();
      
  const TYPE average_T2_dependent_term = VX.get_average_T2_dependent_term ();
    
  const TYPE Delta_E_reference_dependent_term = VX.get_Delta_E_reference_dependent_term ();
    
  const TYPE Delta_Hcm_dependent_term = VX.get_Delta_Hcm_dependent_term ();
  					   
  const class array<double> &Delta_J_der_pn_tab = A_Gamma_gradients.get_Delta_J_der_tab (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &ba_from_ab_pn_indices = A_Gamma_gradients.get_ba_from_ab_pn_indices ();
  
  const class array<int> &average_T2_der_pn_tab = A_Gamma_gradients.get_average_T2_der_pn_tab ();
  
  const class block_matrix<TYPE> &Delta_E_reference_der_pn_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &P_pn_dependent_term_block_matrix = VX.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  const class block_matrix<TYPE> &Q_pp_dependent_term_block_matrix = VX.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  const class block_matrix<TYPE> &Q_nn_dependent_term_block_matrix = VX.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  const class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix = VX.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &G_pp_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  const class block_matrix<TYPE> &G_nn_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
  const class block_matrix<TYPE> &G_pn_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  const class block_matrix<TYPE> &G_np_dependent_term_block_matrix = VX.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);

  const class RDM_J_constraints_class &J_constraints_pp = VX.get_J_constraints_dependent_term (PROTON);
  const class RDM_J_constraints_class &J_constraints_nn = VX.get_J_constraints_dependent_term (NEUTRON);  
  
  const class block_matrix<TYPE> &T1_ppp_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  const class block_matrix<TYPE> &T1_nnn_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  const class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  const class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix = VX.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

  const class block_matrix<TYPE> &T2_prime_ppp_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  const class block_matrix<TYPE> &T2_prime_nnn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  const class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  const class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix = VX.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);

  const class RDM_QG_gradient_class &Q_pp_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_ONLY);
  const class RDM_QG_gradient_class &Q_nn_gradient = A_Gamma_gradients.get_Q_gradient (NEUTRONS_ONLY);
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_QG_gradient_class &G_nn_gradient = A_Gamma_gradients.get_G_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_QG_gradient_class &G_pn_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , NEUTRON);
  const class RDM_QG_gradient_class &G_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , PROTON);
    
  const class RDM_J_constraints_gradient_class &J_constraints_pp_gradient = A_Gamma_gradients.get_J_constraints_gradient (PROTON);
  const class RDM_J_constraints_gradient_class &J_constraints_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (NEUTRON);
  
  const class RDM_T1_gradient_class &T1_ppp_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , PROTON);
  const class RDM_T1_gradient_class &T1_nnn_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , NEUTRON);
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);

  const class RDM_T2_prime_gradient_class &T2_prime_ppp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  const class array<class block_sparse_matrix<TYPE> > &Q_pp_der_pn_block_matrices = Q_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_nn_der_pn_block_matrices = Q_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pn_block_matrices = Q_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_der_pn_block_matrices = G_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_nn_der_pn_block_matrices = G_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_der_pn_block_matrices = G_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_np_der_pn_block_matrices = G_np_gradient.get_block_matrices (PROTONS_NEUTRONS);
      
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_der_pn_block_matrices = T1_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnn_der_pn_block_matrices = T1_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pn_block_matrices = T1_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pn_block_matrices = T1_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);

  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_der_pn_block_matrices = T2_prime_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnn_der_pn_block_matrices = T2_prime_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (PROTONS_NEUTRONS);

  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
  
  HF_X_pn.zero ();
  
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
	    
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    
	      const class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix = Q_pp_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix = Q_nn_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix = Q_pn_der_pn_block_matrices(BPp , Jp , index_prime);

	      class matrix<TYPE> &HF_X_pn_BPp_Jp = HF_X_pn(BPp + 2*Jp);
	
	      TYPE &HF_X_pn_ME = HF_X_pn_BPp_Jp(ip , jp);
	      
	      if (Q_pp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (Q_pp_dependent_term_block_matrix , Q_pp_der_pn_block_matrix);
	      if (Q_nn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (Q_nn_dependent_term_block_matrix , Q_nn_der_pn_block_matrix);
	      if (Q_pn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (Q_pn_dependent_term_block_matrix , Q_pn_der_pn_block_matrix);
	      
	      if (is_there_G_constraint)
		{
		  const class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix = G_pp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix = G_nn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix = G_pn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix = G_np_der_pn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (G_pp_dependent_term_block_matrix , G_pp_der_pn_block_matrix);
		  if (G_nn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (G_nn_dependent_term_block_matrix , G_nn_der_pn_block_matrix);
		  if (G_pn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (G_pn_dependent_term_block_matrix , G_pn_der_pn_block_matrix);	      
		  if (G_np_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (G_np_dependent_term_block_matrix , G_np_der_pn_block_matrix);
		}
	      
	      if (are_there_J_constraints)
		{
		  HF_X_pn_ME += Frobenius_scalar_product_matrix_gradient (true , BPp , Jp , index_prime , J_constraints_pp , J_constraints_pp_gradient);
		  HF_X_pn_ME += Frobenius_scalar_product_matrix_gradient (true , BPp , Jp , index_prime , J_constraints_nn , J_constraints_nn_gradient);
		}
		
	      if (is_there_T1_constraint)
		{      	    
		  const class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix = T1_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix = T1_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix = T1_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix = T1_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
		
		  if (T1_ppp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T1_ppp_dependent_term_block_matrix , T1_ppp_der_pn_block_matrix);
		  if (T1_nnn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T1_nnn_dependent_term_block_matrix , T1_nnn_der_pn_block_matrix);
		  if (T1_ppn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T1_ppn_dependent_term_block_matrix , T1_ppn_der_pn_block_matrix);
		  if (T1_nnp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T1_nnp_dependent_term_block_matrix , T1_nnp_der_pn_block_matrix);
		}
	      
	      if (is_there_T2_prime_constraint)
		{      	    
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix = T2_prime_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix = T2_prime_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix = T2_prime_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix = T2_prime_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix = T2_prime_pnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix = T2_prime_pnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_ppp_dependent_term_block_matrix , T2_prime_ppp_der_pn_block_matrix);
		  if (T2_prime_nnn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_nnn_dependent_term_block_matrix , T2_prime_nnn_der_pn_block_matrix);
		  if (T2_prime_ppn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_ppn_dependent_term_block_matrix , T2_prime_ppn_der_pn_block_matrix);
		  if (T2_prime_nnp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_nnp_dependent_term_block_matrix , T2_prime_nnp_der_pn_block_matrix);		  
		  if (T2_prime_pnp_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_pnp_dependent_term_block_matrix , T2_prime_pnp_der_pn_block_matrix);
		  if (T2_prime_pnn_der_pn_block_matrix.is_it_filled ()) HF_X_pn_ME += Frobenius_scalar_product (T2_prime_pnn_dependent_term_block_matrix , T2_prime_pnn_der_pn_block_matrix);
		}
	    }
	}
  
#ifdef UseMPI
      if (is_it_MPI_parallelized) HF_X_pn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif

    }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	const unsigned int BPp_Jp_index = BPp + 2*Jp;
	
	const TYPE Delta_pn_pairs_number_dependent_term_times_der = Delta_pn_pairs_number_dependent_term*(2*Jp +1);
	
	const class matrix<TYPE> &Delta_E_reference_der_pn_block_matrix_BPp_Jp = Delta_E_reference_der_pn_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_pn_block_matrix_BPp_Jp = Delta_Hcm_der_pn_block_matrix(BPp_Jp_index);
		
	const class matrix<TYPE> &P_pn_dependent_term_block_matrix_BPp_Jp = P_pn_dependent_term_block_matrix(BPp_Jp_index);
	
	class matrix<TYPE> &HF_X_pn_BPp_Jp = HF_X_pn(BPp_Jp_index);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      TYPE &HF_X_pn_ME = HF_X_pn_BPp_Jp(ip , jp);

	      HF_X_pn_ME += (ip == jp) ? (P_pn_dependent_term_block_matrix_BPp_Jp(ip , ip)) : (2.0*P_pn_dependent_term_block_matrix_BPp_Jp(ip , jp));
	    	    
	      if (is_there_E_reference) HF_X_pn_ME += Delta_E_reference_dependent_term*Delta_E_reference_der_pn_block_matrix_BPp_Jp(ip , jp);
	    
	      if (is_there_CM_correction) HF_X_pn_ME += Delta_Hcm_dependent_term*Delta_Hcm_der_pn_block_matrix_BPp_Jp(ip , jp);

	      if (ba_from_ab_pn_indices(BPp , Jp , ip) == jp) HF_X_pn_ME += average_T2_dependent_term*average_T2_der_pn_tab(BPp , Jp , ip);
	    }
	
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {
	    TYPE &HF_X_pn_ME = HF_X_pn_BPp_Jp(ip , ip);	    
	    
	    HF_X_pn_ME += Delta_pn_pairs_number_dependent_term_times_der;

	    HF_X_pn_ME += Delta_J_dependent_term*Delta_J_der_pn_tab(BPp , Jp , ip);
	  }
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    HF_X_pn_BPp_Jp(jp , ip) = HF_X_pn_BPp_Jp(ip , jp);
      }
}















void RDM_Hessian_vector_no_sigma::apply (
					 const class block_matrix<TYPE> &X_pp ,
					 const class block_matrix<TYPE> &X_nn ,
					 const class block_matrix<TYPE> &X_pn ,
					 const class block_matrix<TYPE> &X_rho_pp ,
					 const class block_matrix<TYPE> &X_rho_nn ,
					 class RDM_conditions_class &V_Gamma ,
					 class RDM_conditions_class &X_Gamma ,
					 class RDM_conditions_class &helper_add ,
					 class RDM_conditions_gradient_class &A_Gamma_gradients ,
					 class block_matrix<TYPE> &Hes_X_pp , 	 
					 class block_matrix<TYPE> &Hes_X_nn , 	 
					 class block_matrix<TYPE> &Hes_X_pn ,
					 class block_matrix<TYPE> &Hes_X_rho_pp , 	 
					 class block_matrix<TYPE> &Hes_X_rho_nn) 	 
{
  class RDM_PQG_class &X_Gamma_pp = X_Gamma.get_P_dependent_term (PROTONS_ONLY);
  class RDM_PQG_class &X_Gamma_nn = X_Gamma.get_P_dependent_term (NEUTRONS_ONLY);
  class RDM_PQG_class &X_Gamma_pn = X_Gamma.get_P_dependent_term (PROTONS_NEUTRONS);
    
  class RDM_rho_coupled_modified_class &X_Gamma_rho_pp = X_Gamma.get_rho_coupled_modified_dependent_term (PROTON);
  class RDM_rho_coupled_modified_class &X_Gamma_rho_nn = X_Gamma.get_rho_coupled_modified_dependent_term (NEUTRON);
  
  X_Gamma_pp.block_matrix_fill (X_pp);
  X_Gamma_nn.block_matrix_fill (X_nn);
  X_Gamma_pn.block_matrix_fill (X_pn);
  
  X_Gamma_rho_pp.block_matrix_fill (X_rho_pp);
  X_Gamma_rho_nn.block_matrix_fill (X_rho_nn);
  
  X_Gamma_pp.double_counting_removal ();
  X_Gamma_nn.double_counting_removal ();
  X_Gamma_pn.double_counting_removal ();
  
  X_Gamma_rho_pp.double_counting_removal ();
  X_Gamma_rho_nn.double_counting_removal ();
  
  V_Gamma.A_Gamma_calc_linear_part (X_Gamma_pp , X_Gamma_nn , X_Gamma_pn , X_Gamma_rho_pp , X_Gamma_rho_nn , helper_add , A_Gamma_gradients);
      
  pp_nn_part_calc (PROTON  , V_Gamma , A_Gamma_gradients , Hes_X_pp , Hes_X_rho_pp);
  pp_nn_part_calc (NEUTRON , V_Gamma , A_Gamma_gradients , Hes_X_nn , Hes_X_rho_nn);
  
  pn_part_calc (V_Gamma , A_Gamma_gradients , Hes_X_pn);
}




