#include "../RDM_include/RDM_include_def.h"

using namespace MPI_2D_partitioning;
using namespace inputs_misc;
using namespace correlated_state_routines;
using namespace GSM_multipole_OBMEs_TBMEs;
using namespace RDM_rho_observables;


TYPE RDM_multipoles::GSM_multipole_pp_nn_calc (
					       const int L ,
					       const bool is_it_HO_expansion ,
					       const class array<class multipole_TBMEs_angular_table_str> &TBMEs_angular_tables ,
					       const class nucleons_data &particles_data ,
					       const class array<TYPE> &rho_tab ,
					       const class RDM_PQG_class &Gamma_pp_nn)
{      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
          
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
      
  const class block_matrix<TYPE> &Gamma_block_matrix_pp_nn = Gamma_pp_nn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
      
  TYPE GSM_multipole_pp_nn = 0.0;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);
  
	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
      
	const int ij = ija;

	const int hat_j_square = 2*ij + 2;
	
	const TYPE OBME_ac = coupled_OBME (L , is_it_HO_expansion , particles_data , sa , sc);
      
	GSM_multipole_pp_nn += OBME_ac*hat_j_square*rho_tab (sa , sc);
      }

  if (N_valence_nucleons == 1) return GSM_multipole_pp_nn;
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair_ab(sa , sb);
      	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (shells_qn , shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
		    
	const bool are_sa_sb_equal = (sa == sb);
	
	for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	  for (unsigned int sc = 0 ; sc <= sd ; sc++)
	    {
	      const class pair_str pair_cd(sc , sd);
      	
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (shells_qn , shells_qn);

	      if (are_there_frozen_states_cd) continue;
	      
	      const unsigned int BP_cd = pair_cd.bp_determine (shells_qn , shells_qn);
				
	      if (BP_ab != BP_cd) continue;

	      if (is_coupled_TBME_pp_nn_trivial_zero_determine (L , shells_qn , sa , sb , sc , sd)) continue;
	      
	      const unsigned int BP = BP_ab;
		
	      const int Jmin_cd = pair_cd.Jmin_determine (shells_qn , shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (shells_qn , shells_qn);
		      
	      const bool are_sc_sd_equal = (sc == sd);
	
	      const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);
	      
	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
          
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const bool is_J_even = (J%2 == 0);

		  if (is_J_even || ab_different_cd_different)
		    {
		      const class multipole_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
  
		      const class matrix<TYPE> &Gamma_matrix_pp_nn = Gamma_block_matrix_pp_nn(BP + 2*J);
	
		      const unsigned int ab_index = two_states_indices(J , sa , sb);
		      const unsigned int cd_index = two_states_indices(J , sc , sd);
		  
		      const TYPE Gamma_pp_nn_ME = Gamma_matrix_pp_nn(ab_index , cd_index);

		      const TYPE TBME_abcd_J = coupled_TBME_pp_nn_calc (L , is_it_HO_expansion , particles_data , TBMEs_angular_table_J , sa , sb , sc , sd);
  		      
		      GSM_multipole_pp_nn += (2*J + 1)*TBME_abcd_J*Gamma_pp_nn_ME;
		    }	
		}
	    }
      }
 
  return GSM_multipole_pp_nn;
}




















TYPE RDM_multipoles::GSM_multipole_pn_calc (
					    const int L ,
					    const bool is_it_HO_expansion ,
					    const class array<class multipole_TBMEs_angular_table_str> &TBMEs_angular_tables ,
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data , 
					    const class RDM_PQG_class &Gamma_pn)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;
            
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE GSM_multipole_pn = 0.0;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
      
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	    
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	    {
	      const class pair_str pair_cd(sc_p , sd_n);
      
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	      if (are_there_frozen_states_cd) continue;
	      
	      const unsigned int BP_cd = pair_cd.bp_determine (prot_shells_qn , neut_shells_qn);		
		
	      if (BP_ab != BP_cd) continue;
	      
	      if (is_coupled_TBME_pn_trivial_zero_determine (L , prot_shells_qn , neut_shells_qn , sa_p , sb_n , sc_p , sd_n)) continue;

	      const unsigned int BP = BP_ab;
	
	      const int Jmin_cd = pair_cd.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (prot_shells_qn , neut_shells_qn);

	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
        	                	
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const class multipole_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
		  
		  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
		  const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);	
		  const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
	
		  const TYPE Gamma_pn_ME = Gamma_matrix_pn(ab_index , cd_index);

		  const TYPE TBME_pn_abcd_J = coupled_TBME_pn_calc (L , is_it_HO_expansion , prot_data , neut_data , TBMEs_angular_table_J , sa_p , sb_n , sc_p , sd_n);
  
		  GSM_multipole_pn += (2*J + 1)*TBME_pn_abcd_J*Gamma_pn_ME;	    
		}
	    }
      }
  
  return GSM_multipole_pn;
}








TYPE RDM_multipoles::GSM_multipole_calc (
					 const int L ,
					 const bool is_it_HO_expansion ,
					 const class nucleons_data &prot_data ,
					 const class nucleons_data &neut_data , 
					 const class RDM_PQG_class &Gamma_pp ,
					 const class RDM_PQG_class &Gamma_nn ,
					 const class RDM_PQG_class &Gamma_pn)
{   
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
  
  const double jmax = max (jp_max , jn_max);

  const int Jmax = make_int (2.0*jmax);
  
  const int Jmax_plus_one = Jmax + 1;

  class array<class multipole_TBMEs_angular_table_str> TBMEs_angular_tables(Jmax_plus_one);

  for (int J = 0 ; J <= Jmax ; J++) TBMEs_angular_tables(J).allocate_calc_coupled (L , jmax , J);
	
  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);

  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);
  
  const TYPE GSM_multipole_prot = GSM_multipole_pp_nn_calc (L , is_it_HO_expansion , TBMEs_angular_tables , prot_data , rho_prot_tab , Gamma_pp);
  const TYPE GSM_multipole_neut = GSM_multipole_pp_nn_calc (L , is_it_HO_expansion , TBMEs_angular_tables , neut_data , rho_neut_tab , Gamma_nn);
  
  const TYPE GSM_multipole_pn = GSM_multipole_pn_calc (L , is_it_HO_expansion , TBMEs_angular_tables , prot_data , neut_data , Gamma_pn);
  
  const TYPE GSM_multipole_value = GSM_multipole_prot + GSM_multipole_neut + GSM_multipole_pn;
    
  return GSM_multipole_value;
}







void RDM_multipoles::calc_print (
				 const class input_data_str &input_data , 
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data ,
				 const class RDM_PQG_class &Gamma_pp ,
				 const class RDM_PQG_class &Gamma_nn ,
				 const class RDM_PQG_class &Gamma_pn)
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "GSM multipoles" << endl;
      cout <<         "--------------" << endl << endl;
    }
  
  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();
    
  const unsigned int GSM_multipoles_number = input_data.get_GSM_multipoles_number ();
  
  const class array<int> &GSM_multipoles_L_tab = input_data.get_GSM_multipoles_L_tab ();
  
  const class array<unsigned int> &GSM_multipoles_BP_tab = input_data.get_GSM_multipoles_BP_tab ();

  const class array<double> &GSM_multipoles_J_tab = input_data.get_GSM_multipoles_J_tab ();

  const class array<unsigned int> &GSM_multipoles_vector_index_tab = input_data.get_GSM_multipoles_vector_index_tab (); 
  
  const class array<bool> &GSM_multipoles_is_it_HO_expansion_tab = input_data.get_GSM_multipoles_is_it_HO_expansion_tab (); 
  
  for (unsigned int GSM_multipole_index = 0 ; GSM_multipole_index < GSM_multipoles_number ; GSM_multipole_index++)
    {
      const int L = GSM_multipoles_L_tab(GSM_multipole_index);
      
      const unsigned int BP = GSM_multipoles_BP_tab(GSM_multipole_index);
  
      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_multipoles::calc_print");
      
      const unsigned int vector_index = GSM_multipoles_vector_index_tab(GSM_multipole_index);

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_multipoles::calc_print");
  
      const double J = GSM_multipoles_J_tab(GSM_multipole_index);
      
      if (rint (J - RDM_J) != 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_multipoles::calc_print");
            
      const bool is_it_HO_expansion = GSM_multipoles_is_it_HO_expansion_tab(GSM_multipole_index);

      const TYPE GSM_multipole_ME = GSM_multipole_calc (L , is_it_HO_expansion , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);
 
      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  if (is_it_HO_expansion)
	    cout << "HO expansion , " << MULTIPOLE_RL_YL << "  L:" << L << "  ";
	  else
	    cout << "R cut , " << MULTIPOLE_RL_YL << "  L:" << L << "  ";

	  cout << J_Pi_vector_index_string (BP , J , vector_index) << "  expectation value : " << GSM_multipole_ME << endl;
	}
    }
}



