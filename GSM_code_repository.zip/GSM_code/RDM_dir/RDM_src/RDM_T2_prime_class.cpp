#include "../RDM_include/RDM_include_def.h"

using namespace correlated_state_routines;




RDM_T2_prime_class::RDM_T2_prime_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0),
  n_scat_max (0),
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_9j_hats_T2_ptr (NULL)
{}




RDM_T2_prime_class::RDM_T2_prime_class (
					const enum space_type space_pair_c ,
					const enum particle_type last_particle_c ,
					const bool truncation_hw_c ,
					const bool truncation_ph_c ,
					const int E_max_hw_c ,
					const int n_scat_max_c , 
					const class nucleons_data &prot_data ,
					const class nucleons_data &neut_data ,
					const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0),
  n_scat_max (0),
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_9j_hats_T2_ptr (NULL)
{
  allocate (space_pair_c , last_particle_c , truncation_hw_c , truncation_ph_c , E_max_hw_c , n_scat_max_c , prot_data , neut_data , Wigner_9j_hats_T2);
}


RDM_T2_prime_class::RDM_T2_prime_class (const class RDM_T2_prime_class &X)
{
  allocate_fill (X);
}

RDM_T2_prime_class::~RDM_T2_prime_class () {}



void RDM_T2_prime_class::allocate (
				   const enum space_type space_pair_c ,
				   const enum particle_type last_particle_c ,
				   const bool truncation_hw_c ,
				   const bool truncation_ph_c ,
				   const int E_max_hw_c ,
				   const int n_scat_max_c , 
				   const class nucleons_data &prot_data ,
				   const class nucleons_data &neut_data ,
				   const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T2_prime_class cannot be allocated twice in RDM_T2_prime_class::allocate");
  
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
  
  truncation_hw = truncation_hw_c;
  truncation_ph = truncation_ph_c;
  
  E_max_hw = E_max_hw_c;
  
  n_scat_max = n_scat_max_c;
  
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;
  
  Wigner_9j_hats_T2_ptr = &Wigner_9j_hats_T2;
  
  switch (space_pair)
    {
    case PROTONS_ONLY:
      {
	if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
	else if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_ppn_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_T2_prime_class::allocate (PROTONS_ONLY)");
	  
      } break;

    case NEUTRONS_ONLY:
      {
	if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
	else if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_nnp_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_T2_prime_class::allocate (NEUTRONS_ONLY)");
	  
      } break;

    case PROTONS_NEUTRONS:
      {
	if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_pnp_alloc_calc ();
	else if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_pnn_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_T2_prime_class::allocate (PROTONS_NEUTRONS)");
	  
      } break;

    default: error_message_print_abort ("The pair space in RDM_T2_prime_class is either protons only, neutrons only or protons-neutrons in RDM_T2_prime_class::allocate");
    }

  const int J_total_number = matrix_dimensions.dimension (1);
        
  class array<unsigned int> block_matrix_dimensions(2*J_total_number);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);
  
  block_matrix_abcdef.allocate (block_matrix_dimensions);
  
  zero ();
}





void RDM_T2_prime_class::allocate_fill (const class RDM_T2_prime_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T2_prime_class cannot be allocated twice in RDM_T2_prime_class::allocate_fill");
  
  matrix_dimensions.allocate_fill (X.matrix_dimensions);
  
  T2_matrix_dimensions.allocate_fill (X.T2_matrix_dimensions);
  
  three_states_indices.allocate_fill (X.three_states_indices);
          
  BP_table.allocate_fill (X.BP_table);
  
  iJmin_pair_last_particle_tab.allocate_fill (X.iJmin_pair_last_particle_tab);
  iJmax_pair_last_particle_tab.allocate_fill (X.iJmax_pair_last_particle_tab);
    
  is_it_in_space_tab.allocate_fill (X.is_it_in_space_tab);
  
  block_matrix_abcdef.allocate_fill (X.block_matrix_abcdef);
  
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
  
  truncation_hw = X.truncation_hw;
  truncation_ph = X.truncation_ph;
  
  E_max_hw = X.E_max_hw;
  
  n_scat_max = X.n_scat_max;
  
  prot_data_ptr = X.prot_data_ptr;
  neut_data_ptr = X.neut_data_ptr;
  
  Wigner_9j_hats_T2_ptr = X.Wigner_9j_hats_T2_ptr;
}



void RDM_T2_prime_class::deallocate ()
{
  matrix_dimensions.deallocate ();

  T2_matrix_dimensions.deallocate ();
  
  three_states_indices.deallocate ();
      
  BP_table.deallocate ();
       
  iJmin_pair_last_particle_tab.deallocate ();
  iJmax_pair_last_particle_tab.deallocate ();
    
  is_it_in_space_tab.deallocate ();
  
  block_matrix_abcdef.deallocate ();
  
  block_matrix_abcdef_eigenvalues.deallocate ();
  
  T_MPI.deallocate ();
  
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
  
  truncation_hw = false;
  truncation_ph = false;
			       
  E_max_hw = 0;
  
  n_scat_max = 0;
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_9j_hats_T2_ptr = NULL;
}



void RDM_T2_prime_class::block_matrix_fill (const class block_matrix<TYPE> &X)
{
  block_matrix_abcdef = X;
}

void RDM_T2_prime_class::operator = (const class RDM_T2_prime_class &X)
{
  block_matrix_abcdef = X.block_matrix_abcdef;
}

void RDM_T2_prime_class::operator += (const class RDM_T2_prime_class &X)
{
  block_matrix_abcdef += X.block_matrix_abcdef;
}

void RDM_T2_prime_class::operator -= (const class RDM_T2_prime_class &X)
{
  block_matrix_abcdef -= X.block_matrix_abcdef;
}

void RDM_T2_prime_class::add_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcdef.add_scalar_diagonal_part (x);
}

void RDM_T2_prime_class::remove_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcdef.remove_scalar_diagonal_part (x);
}

void RDM_T2_prime_class::operator *= (const TYPE &x)
{
  block_matrix_abcdef *= x;
}

void RDM_T2_prime_class::operator /= (const TYPE &x)
{
  block_matrix_abcdef /= x;
}

unsigned int RDM_T2_prime_class::get_block_symmetric_matrix_elements_number () const
{
  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();

  unsigned int block_symmetric_matrix_elements_number = 0;
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const unsigned int dimension_block = block_matrix_abcdef(i).get_dimension ();
      
      block_symmetric_matrix_elements_number += (dimension_block%2 == 0) ? ((dimension_block/2)*(dimension_block + 1)) : (dimension_block*((dimension_block + 1)/2));
    }
  
  return block_symmetric_matrix_elements_number;
}


double RDM_T2_prime_class::infinite_norm () const
{
  return block_matrix_abcdef.infinite_norm ();
}




void RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no nn + p)");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_two_shells = make_int (2.0*jmax);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
    
  const double Jmax_total = 3.0*jmax;
      
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  matrix_dimensions.allocate (2 , J_total_number);
  
  T2_matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (N_nlj , N_nlj , N_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_two_shells_plus_one , N_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_two_shells_plus_one , N_nlj);
    
  three_states_indices.allocate (Jmax_two_shells_plus_one , J_total_number , N_nlj , N_nlj , N_nlj);
  
  is_it_in_space_tab.allocate (N_nlj , N_nlj , N_nlj);
    
  T2_matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
    
  is_it_in_space_tab = false;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {
	const class pair_str pair(sa , sb);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (shells_qn , shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (shells_qn , shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (shells_qn , shells_qn);
	const int Jmax_pair = pair.Jmax_determine (shells_qn , shells_qn);
		
	const int E_pair_hw = pair.E_hw_determine (shells_qn , shells_qn);

	const int n_scat_pair = pair.n_scat_determine (shells_qn , shells_qn);
	
	for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	  {
	    const class nlj_struct &shell_qn_sc = shells_qn(sc);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_sc = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_sc);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa , sb , sc) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa , sb , sc) = BP;
	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_pair_sc = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_pair_sc = J_pair + ijc;
			    
		iJmin_pair_last_particle_tab(J_pair , sc) = iJmin_pair_sc;
		iJmax_pair_last_particle_tab(J_pair , sc) = iJmax_pair_sc;
	      }
	  }
      }

  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair(sa , sb);
	  
	const bool are_sa_sb_equal = (sa == sb);
	
	const int Jmin_pair = pair.Jmin_determine (shells_qn , shells_qn);
	const int Jmax_pair = pair.Jmax_determine (shells_qn , shells_qn);
	  	  
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {		      		  
	    if (!are_sa_sb_equal || (J_pair%2 == 0))
	      {
		for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
		  {
		    if (is_it_in_space_tab(sa , sb , sc))
		      {
			const unsigned int BP = BP_table(sa , sb , sc);
	  
			const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc);
			const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc);
		      
			const int J_number = iJmax_abc - iJmin_abc + 1;
		      
			for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			  {
			    const int iJ = iJ0 + iJmin_abc;
			  
			    three_states_indices(J_pair , iJ , sa , sb , sc) = T2_matrix_dimensions(BP , iJ)++;
			  }}}}}
      }

  matrix_dimensions = T2_matrix_dimensions;
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
	
	if (make_int (J - jmax) <= 0)
	  {
	    for (unsigned int s = 0 ; s < N_nlj ; s++)
	      {
		const class nlj_struct &shell_qn = shells_qn(s);
		
		const bool frozen_state = shell_qn.get_frozen_state ();

		if (frozen_state) continue;
	      
		const int ij = shell_qn.get_ij ();
		
		if (ij == iJ) matrix_dimensions(BP , iJ)++;
	      }
	  }
      }
}












void RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppn_alloc_calc ()
{
  if ((space_pair != PROTONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_ppn_alloc_calc");
                
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const int Jmax_pp = make_int (2.0*jp_max);
  
  const int Jmax_pp_plus_one = Jmax_pp + 1;
  
  const double Jmax_total = Jmax_pp + jn_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  matrix_dimensions.allocate (2 , J_total_number);
  
  T2_matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (Np_nlj , Np_nlj , Nn_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
      
  three_states_indices.allocate (Jmax_pp_plus_one , J_total_number , Np_nlj , Np_nlj , Nn_nlj);
          
  is_it_in_space_tab.allocate (Np_nlj , Np_nlj , Nn_nlj);
    
  T2_matrix_dimensions = 0;
        
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {
	const class pair_str pair(sa_p , sb_p);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (prot_shells_qn , prot_shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (prot_shells_qn , prot_shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , prot_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , prot_shells_qn);
		
	const int E_pair_hw = pair.E_hw_determine (prot_shells_qn , prot_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (prot_shells_qn , prot_shells_qn);
	
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_p , sb_p , sc_n) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa_p , sb_p , sc_n) = BP;
	    	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
			    
		iJmin_pair_last_particle_tab(J_pair , sc_n) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_n) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
    for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
      {	  
	const bool are_sa_sb_equal = (sa_p == sb_p);

	const class pair_str pair(sa_p , sb_p);	  
	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , prot_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , prot_shells_qn);
			
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {	
	    if (!are_sa_sb_equal || (J_pair%2 == 0))
	      {
		for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
		  {	   
		    if (is_it_in_space_tab(sa_p , sb_p , sc_n))
		      {   		
			const unsigned int BP = BP_table(sa_p , sb_p , sc_n);
	
			const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_n);	
			const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_n);

			const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
			for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			  {
			    const int iJ = iJ0 + iJmin_abc;
					  
			    three_states_indices(J_pair , iJ , sa_p , sb_p , sc_n) = T2_matrix_dimensions(BP , iJ)++;	      
			  }}}}}}
  
  matrix_dimensions = T2_matrix_dimensions;
}
  












void RDM_T2_prime_class::BP_J_tables_dimensions_indices_pnn_alloc_calc ()
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_pnn_alloc_calc");
                
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const int Jmax_pn = make_int (jp_max + jn_max);
  
  const int Jmax_pn_plus_one = Jmax_pn + 1;
  
  const double Jmax_total = Jmax_pn + jn_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  matrix_dimensions.allocate (2 , J_total_number);
  
  T2_matrix_dimensions.allocate (2 , J_total_number);
  
  BP_table.allocate (Np_nlj , Nn_nlj , Nn_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_pn_plus_one , Nn_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_pn_plus_one , Nn_nlj);
      
  three_states_indices.allocate (Jmax_pn_plus_one , J_total_number , Np_nlj , Nn_nlj , Nn_nlj);
          
  is_it_in_space_tab.allocate (Np_nlj , Nn_nlj , Nn_nlj);
    
  T2_matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (prot_shells_qn , neut_shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (prot_shells_qn , neut_shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
			
	const int E_pair_hw = pair.E_hw_determine (prot_shells_qn , neut_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (prot_shells_qn , neut_shells_qn);
	
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_p , sb_n , sc_n) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa_p , sb_n , sc_n) = BP;
	    	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
			    
		iJmin_pair_last_particle_tab(J_pair , sc_n) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_n) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
	  	  
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {		      	
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	  
		if (is_it_in_space_tab(sa_p , sb_n , sc_n))
		  {
		    const unsigned int BP = BP_table(sa_p , sb_n , sc_n);
	  
		    const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_n);	
		    const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_n);

		    const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
		    for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
		      {
			const int iJ = iJ0 + iJmin_abc;
					  
			three_states_indices(J_pair , iJ , sa_p , sb_n , sc_n) = T2_matrix_dimensions(BP , iJ)++;
		      }}}}
      }
  
  matrix_dimensions = T2_matrix_dimensions;
	
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {	
	const double J = iJ + 0.5;
      
	if (make_int (J - jp_max) <= 0)
	  {
	    for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
	      {
		const class nlj_struct &shell_qn = prot_shells_qn(sp);
		
		const bool frozen_state = shell_qn.get_frozen_state ();

		if (frozen_state) continue;
		
		const int ij = shell_qn.get_ij ();
		
		if (ij == iJ) matrix_dimensions(BP , iJ)++;
	      }
	  }
      }
}


















void RDM_T2_prime_class::BP_J_tables_dimensions_indices_pnp_alloc_calc ()
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != PROTON)) error_message_print_abort ("pp + n space only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_pnp_alloc_calc");
                
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const int Jmax_pp = make_int (2.0*jp_max);
  
  const int Jmax_pp_plus_one = Jmax_pp + 1;
  
  const double Jmax_total = Jmax_pp + jn_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  matrix_dimensions.allocate (2 , J_total_number);
  
  T2_matrix_dimensions.allocate (2 , J_total_number);
  
  BP_table.allocate (Np_nlj , Nn_nlj , Np_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
      
  three_states_indices.allocate (Jmax_pp_plus_one , J_total_number , Np_nlj , Nn_nlj , Np_nlj);
          
  is_it_in_space_tab.allocate (Np_nlj , Nn_nlj , Np_nlj);
    
  T2_matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (prot_shells_qn , neut_shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (prot_shells_qn , neut_shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
		
	const int E_pair_hw = pair.E_hw_determine (prot_shells_qn , neut_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (prot_shells_qn , neut_shells_qn);
	
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_p , sb_n , sc_p) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa_p , sb_n , sc_p) = BP;
	    	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
	    
		iJmin_pair_last_particle_tab(J_pair , sc_p) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_p) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
	  	  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
	  	  
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {		  
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {    	
		if (is_it_in_space_tab(sa_p , sb_n , sc_p))
		  {	  
		    const unsigned int BP = BP_table(sa_p , sb_n , sc_p);
	
		    const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_p);	
		    const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_p);

		    const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
		    for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
		      {
			const int iJ = iJ0 + iJmin_abc;
					  					  
			three_states_indices(J_pair , iJ , sa_p , sb_n , sc_p) = T2_matrix_dimensions(BP , iJ)++;	      
		      }}}}
      }
  
  matrix_dimensions = T2_matrix_dimensions;
							   
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {	
	const double J = iJ + 0.5;
	
	if (make_int (J - jn_max) <= 0)
	  {
	    for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
	      {
		const class nlj_struct &shell_qn = neut_shells_qn(sn);
		
		const bool frozen_state = shell_qn.get_frozen_state ();

		if (frozen_state) continue;
		
		const int ij = shell_qn.get_ij ();
		
		if (ij == iJ) matrix_dimensions(BP , iJ)++;
	      }
	  }
      }
}











void RDM_T2_prime_class::BP_J_tables_dimensions_indices_nnp_alloc_calc ()
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T2_prime_class::BP_J_tables_dimensions_indices_nnp_alloc_calc");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_nn = make_int (2.0*jn_max);
  
  const int Jmax_nn_plus_one = Jmax_nn + 1;
  
  const double Jmax_total = Jmax_nn + jp_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
                  
  matrix_dimensions.allocate (2 , J_total_number);
  
  T2_matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (Nn_nlj , Nn_nlj , Np_nlj);  
  
  iJmin_pair_last_particle_tab.allocate (Jmax_nn_plus_one , Np_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_nn_plus_one , Np_nlj);
        
  three_states_indices.allocate (Jmax_nn_plus_one , J_total_number , Nn_nlj , Nn_nlj , Np_nlj);
          
  is_it_in_space_tab.allocate (Nn_nlj , Nn_nlj , Np_nlj);
    
  T2_matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_n , sb_n);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (neut_shells_qn , neut_shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (neut_shells_qn , neut_shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (neut_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (neut_shells_qn , neut_shells_qn);
	
	const int E_pair_hw = pair.E_hw_determine (neut_shells_qn , neut_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (neut_shells_qn , neut_shells_qn);
	
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_n , sb_n , sc_p) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa_n , sb_n , sc_p) = BP;

	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		   
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
	    
		iJmin_pair_last_particle_tab(J_pair , sc_p) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_p) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
    for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
      {
	const bool are_sa_sb_equal = (sa_n == sb_n);
	
	const class pair_str pair(sa_n , sb_n);
	  	  
	const int Jmin_pair = pair.Jmin_determine (neut_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (neut_shells_qn , neut_shells_qn);
	  	  
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {	
	    if (!are_sa_sb_equal || (J_pair%2 == 0))
	      {
		for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
		  {	  
		    if (is_it_in_space_tab(sa_n , sb_n , sc_p))
		      {    	
			const unsigned int BP = BP_table(sa_n , sb_n , sc_p);
	
			const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_p);	
			const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_p);

			const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
			for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			  {
			    const int iJ = iJ0 + iJmin_abc;
					  
			    three_states_indices(J_pair , iJ , sa_n , sb_n , sc_p) = T2_matrix_dimensions(BP , iJ)++;
			  }}}}}
      }
  
  matrix_dimensions = T2_matrix_dimensions;
}












TYPE RDM_T2_prime_class::T2_prime_matrix_BP_J_ab_de_equal_part_calc (
								     const class array<TYPE> &rho_tab ,
								     const class RDM_PQG_class &Gamma_pp_nn ,
								     const unsigned int ab_index ,
								     const bool sa_sd_jb_je_equal ,
								     const bool sb_se_ja_jd_equal ,
								     const bool sa_se_jb_jd_equal ,
								     const bool sb_sd_ja_je_equal ,
								     const bool sc_sf_equal ,
								     const bool jc_jf_equal ,
								     const unsigned int BP_ab ,
								     const int Jab ,
								     const double inv_delta_norm_ab , 
								     const double inv_delta_norm_phase_ab ,
								     const double inv_delta_norm_de ,
								     const unsigned int sc ,
								     const unsigned int sd ,
								     const unsigned int se ,
								     const unsigned int sf)			      
{  
  TYPE T2_prime_block_matrices_BP_J_ME_part = 0.0;
  
  const bool ad_be_jc_jf_equal = (sa_sd_jb_je_equal && sb_se_ja_jd_equal && jc_jf_equal);
  const bool ae_bd_jc_jf_equal = (sa_se_jb_jd_equal && sb_sd_ja_je_equal && jc_jf_equal);
  
  if (ad_be_jc_jf_equal) T2_prime_block_matrices_BP_J_ME_part += rho_tab(sc , sf)*inv_delta_norm_de*inv_delta_norm_ab;
  if (ae_bd_jc_jf_equal) T2_prime_block_matrices_BP_J_ME_part += rho_tab(sc , sf)*inv_delta_norm_de*inv_delta_norm_phase_ab;

  if (sc_sf_equal)
    {
      const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
      const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
      const unsigned int de_index = two_states_indices(Jab , sd , se);
								      
      const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_ab + 2*Jab);
								      
      const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_matrix(ab_index , de_index);
								      
      T2_prime_block_matrices_BP_J_ME_part += Gamma_pp_nn_ME;
    }

  return T2_prime_block_matrices_BP_J_ME_part;
}








// sab is sa or sb, sed is se or sd in function names.
// s0 is sa or sb.
// s1 is sb or sa.
// s2 is sd or se.

TYPE RDM_T2_prime_class::T2_prime_matrix_sab_sde_equal_part_calc (
								  const class RDM_PQG_class &Gamma_pp_nn ,
								  const int iJ ,
								  const double inv_delta_norms_phase_ab ,
								  const int phase_sab_sde , 
								  const int Jmin_sc_s2 , 
								  const int Jmax_sc_s2 , 
								  const int Jmin_sf_s1 , 
								  const int Jmax_sf_s1 , 
								  const unsigned int BP_sc_s2 ,
								  const int Jab ,
								  const int Jde ,
								  const int ij_s0 ,
								  const int ij_s1 ,
								  const int ijc ,
								  const int ij_s2 ,
								  const int ijf , 
								  const bool are_scf_proton_s12_neutron ,
								  const bool are_scf_neutron_s12_proton ,
								  const unsigned int s1 ,
								  const unsigned int sc ,
								  const unsigned int s2 ,
								  const unsigned int sf)
{
  const int Jmin_pair = max (Jmin_sc_s2 , Jmin_sf_s1);
  const int Jmax_pair = min (Jmax_sc_s2 , Jmax_sf_s1);

  if (Jmin_pair > Jmax_pair) return 0.0;
  
  const bool scf_s_same_particle = (!are_scf_proton_s12_neutron && !are_scf_neutron_s12_proton);
  
  const bool are_sc_s2_equal = (scf_s_same_particle && (sc == s2));
  const bool are_sf_s1_equal = (scf_s_same_particle && (sf == s1));

  const bool sc_s2_different_sf_s1_different = (!are_sc_s2_equal && !are_sf_s1_equal);
  
  const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 = get_Wigner_9j_hats_T2 ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
  const bool is_sc_smaller_than_s2 = is_sa_smaller_than_sb_determine (are_scf_proton_s12_neutron , are_scf_neutron_s12_proton , sc , s2);
  const bool is_sf_smaller_than_s1 = is_sa_smaller_than_sb_determine (are_scf_proton_s12_neutron , are_scf_neutron_s12_proton , sf , s1);
  
  TYPE T2_prime_block_matrices_BP_J_ME_part = 0.0;

  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
    {
      const bool is_J_pair_even = (J_pair%2 == 0);

      if (sc_s2_different_sf_s1_different || is_J_pair_even)
	{
	  const double Wigner_9j_hats = Wigner_9j_hats_T2(ij_s1 , ij_s0 , ijc , ij_s2 , ijf , Jab , J_pair , Jde , iJ);
					  
	  const unsigned int sc_s2_index = (is_sc_smaller_than_s2) ? (two_states_indices(J_pair , sc , s2)) : (two_states_indices(J_pair , s2 , sc));
	  const unsigned int sf_s1_index = (is_sf_smaller_than_s1) ? (two_states_indices(J_pair , sf , s1)) : (two_states_indices(J_pair , s1 , sf));

	  const int phase_sc_s2 = (is_sc_smaller_than_s2) ? (1) : (((ijc + ij_s2 + J_pair)%2 == 0) ? (1) : (-1));
	  const int phase_sf_s1 = (is_sf_smaller_than_s1) ? (1) : (((ijf + ij_s1 + J_pair)%2 == 0) ? (1) : (-1));
									      
	  const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_sc_s2 + 2*J_pair);
								  	
	  const TYPE Gamma_pp_nn_ME = (phase_sc_s2 == phase_sf_s1) ? (Gamma_pp_nn_matrix(sc_s2_index , sf_s1_index)) : (-Gamma_pp_nn_matrix(sc_s2_index , sf_s1_index));
	  
	  T2_prime_block_matrices_BP_J_ME_part -= Wigner_9j_hats*Gamma_pp_nn_ME;
	}
    }

  T2_prime_block_matrices_BP_J_ME_part *= inv_delta_norms_phase_ab*phase_sab_sde;
								  
  return T2_prime_block_matrices_BP_J_ME_part;
}






void RDM_T2_prime_class::zero ()
{
  block_matrix_abcdef.zero ();
}



void RDM_T2_prime_class::T2_prime_ppp_nnn_matrix_omega_part_add (
								 const class array<TYPE> &rho_tab ,
								 const class RDM_PQG_class &Gamma_pp_nn ,
								 const unsigned int BP ,
								 const int iJ)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_block_matrices_ppp_nnn_omega_part_add (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_matrix_ppp_nnn_omega_part_add (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_matrix_ppp_nnn_omega_part_add (no nn + p)");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);
	  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
	  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	{	
	  if (!is_it_in_space_tab(sa , sb , sc)) continue;
		  
	  const unsigned int BP_abc = BP_table(sa , sb , sc);

	  if (BP_abc == BP)
	    {
	      const bool are_sa_sb_equal = (sa == sb);
	
	      const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  		
	      const unsigned int ijc = shell_qn_sc.get_ij ();
			  			  	  		      
	      const unsigned int BP_ab = BP_pair_table(sa , sb);
			  
	      const int Jmin_ab = Jmin_pair_table(sa , sb);
	      const int Jmax_ab = Jmax_pair_table(sa , sb);
			 
	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;	
				  
	      for (unsigned int sg = 0 ; sg < N_nlj ; sg++)
		{		  
		  const class nlj_struct &shell_qn_sg = shells_qn(sg);
		      
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
			
		  if (ijg == iJ)
		    {
		      const unsigned int BP_gc = BP_pair_table(sg , sc);
		      
		      if (BP_gc == BP_ab)
			{		      
			  const double jg = shell_qn_sg.get_j ();

			  const double hat_jg = hat (jg);
						    
			  const double inv_delta_norm_gc = (sc == sg) ? (M_SQRT2) : (1.0);
		      
			  const bool are_sc_sg_equal = (sc == sg);

			  const bool ab_different_cg_different = (!are_sa_sb_equal && !are_sc_sg_equal);			  
		  
			  const int Jmin_gc = Jmin_pair_table(sg , sc);
			  const int Jmax_gc = Jmax_pair_table(sg , sc);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);
		  
			  const bool is_sg_smaller_than_sc = (sg <= sc);
			  
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const bool is_J_pair_even = (J_pair%2 == 0);
						  
			      if (ab_different_cg_different || is_J_pair_even)
				{
				  const unsigned int ab_index = two_states_indices(J_pair , sa , sb);
			      
				  const unsigned int abc_index = three_states_indices(J_pair , iJ , sa , sb , sc);
		      
				  const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc);
				  const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc);

				  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				    {
				      const double hat_J_pair = hat (J_pair);
		      
				      const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);				  
		      
				      const unsigned int gc_index = (is_sg_smaller_than_sc) ? (two_states_indices(J_pair , sg , sc)) : (two_states_indices(J_pair , sc , sg));
		      
				      const int phase_gc = (is_sg_smaller_than_sc) ? (1) : (((ijg + ijc + J_pair)%2 == 0) ? (1) : (-1));
								      
				      const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_ab + 2*J_pair);
		      
				      const TYPE Gamma_pp_nn_ME_phase_abc = (phase_gc == phase_abc) ? (Gamma_pp_nn_matrix(ab_index , gc_index)) : (-Gamma_pp_nn_matrix(ab_index , gc_index));

				      const TYPE T2_prime_matrix_BP_J_ME = Gamma_pp_nn_ME_phase_abc*inv_delta_norm_gc*hat_J_pair/hat_jg;

				      T2_prime_matrix_BP_J(two_body_T2_prime_omega_index , abc_index) += T2_prime_matrix_BP_J_ME;
				      T2_prime_matrix_BP_J(abc_index , two_body_T2_prime_omega_index) += T2_prime_matrix_BP_J_ME;
				    }}}}
		      
		      two_body_T2_prime_omega_index++;
		      
		    }}}}
	    
  unsigned int one_body_index_T2_prime_in = T2_matrix_dimension;
	      
  for (unsigned int sh = 0 ; sh < N_nlj ; sh++)
    {
      const class nlj_struct &shell_qn_sh = shells_qn(sh);

      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
			  
      if (ijh == iJ)
	{
	  unsigned int one_body_index_T2_prime_out = T2_matrix_dimension;
	      
	  for (unsigned int sg = 0 ; sg < N_nlj ; sg++)
	    {	  
	      const class nlj_struct &shell_qn_sg = shells_qn(sg);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
      
	      const int lg = shell_qn_sg.get_l ();
		  
	      const int ijg = shell_qn_sg.get_ij ();
			  
	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      T2_prime_matrix_BP_J(one_body_index_T2_prime_in  , one_body_index_T2_prime_out) += rho_tab (sg , sh);
		      T2_prime_matrix_BP_J(one_body_index_T2_prime_out , one_body_index_T2_prime_in)  += rho_tab (sg , sh);
		    }
		  
		  one_body_index_T2_prime_out++;
		}
	    }
	  
	  one_body_index_T2_prime_in++;
	}
    }
}








void RDM_T2_prime_class::T2_prime_ppp_nnn_block_matrices_add (
							      const class array<TYPE> &rho_tab ,
							      const class RDM_PQG_class &Gamma_pp_nn)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_matrix_ppp_nnn_add (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_matrix_ppp_nnn_add (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::T2_prime_matrix_ppp_nnn_add (no nn + p)");
    
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
        
  const double jmax = particles_data.get_jmax ();
      
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
          
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
      
	const bool is_J_smaller_than_jmax = (make_int (J - jmax) <= 0); 

	class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	      {	
		if (!is_it_in_space_tab(sa , sb , sc)) continue;
		  
		const unsigned int BP_abc = BP_table(sa , sb , sc);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa == sb);
	
		    const class nlj_struct &shell_qn_sa = shells_qn(sa);
		    const class nlj_struct &shell_qn_sb = shells_qn(sb);
		    const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  			  
		    const int ija = shell_qn_sa.get_ij ();
		    const int ijb = shell_qn_sb.get_ij ();
		    const int ijc = shell_qn_sc.get_ij ();
			  	  		      
		    const unsigned int BP_ab = BP_pair_table(sa , sb);
			  
		    const int Jmin_ab = Jmin_pair_table(sa , sb);
		    const int Jmax_ab = Jmax_pair_table(sa , sb);

		    const double inv_delta_norm_ab = (sa == sb) ? (M_SQRT1_2) : (1.0);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
	      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices(Jab , sa , sb);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa , sb , sc);
				      
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      			  
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  				      
				for (unsigned int se = 0 ; se < N_nlj ; se++)
				  for (unsigned int sd = 0 ; sd <= se ; sd++)
				    for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
				      {
					if (!is_it_in_space_tab(sd , se , sf)) continue;
		  
					const bool sa_sd_equal = (sa == sd) , sa_se_equal = (sa == se);
					const bool sb_sd_equal = (sb == sd) , sb_se_equal = (sb == se);
					const bool sc_sf_equal = (sc == sf);
				      
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd , se , sf);
					      
					    if (BP_def == BP)
					      {
						const class nlj_struct &shell_qn_sd = shells_qn(sd);
						const class nlj_struct &shell_qn_se = shells_qn(se);
						const class nlj_struct &shell_qn_sf = shells_qn(sf);
			  
						const int ijd = shell_qn_sd.get_ij ();
						const int ije = shell_qn_se.get_ij ();
						const int ijf = shell_qn_sf.get_ij ();
							  
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
						const bool jc_jf_equal = (ijc == ijf);
							  
						const bool are_sd_se_equal = (sd == se);
		    
						const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
								      								      
						const unsigned int BP_cd = BP_pair_table(sc , sd);
						const unsigned int BP_ce = BP_pair_table(sc , se);
						const unsigned int BP_de = BP_pair_table(sd , se);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
						const int Jmin_cd = Jmin_pair_table(sc , sd);
						const int Jmax_cd = Jmax_pair_table(sc , sd);
					  
						const int Jmin_ce = Jmin_pair_table(sc , se);
						const int Jmax_ce = Jmax_pair_table(sc , se);
					  
						const int Jmin_de = Jmin_pair_table(sd , se);
						const int Jmax_de = Jmax_pair_table(sd , se);
					      
						const int Jmin_af = Jmin_pair_table(sa , sf);
						const int Jmax_af = Jmax_pair_table(sa , sf);
					      
						const int Jmin_bf = Jmin_pair_table(sb , sf);
						const int Jmax_bf = Jmax_pair_table(sb , sf);		    				    
		      			  
						const double inv_delta_norm_de = (sd == se) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_ce = (sc == se) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_fa = (sf == sa) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_cd = (sc == sd) ? (M_SQRT1_2) : (1.0);
						const double inv_delta_norm_fb = (sf == sb) ? (M_SQRT1_2) : (1.0);

						const double inv_delta_norms_phase_ab_sa_sd_equal = (sa_sd_equal) ? (inv_delta_norm_ab      *inv_delta_norm_de/inv_delta_norm_ce/inv_delta_norm_fb) : (NADA);
						const double inv_delta_norms_phase_ab_sb_sd_equal = (sb_sd_equal) ? (inv_delta_norm_phase_ab*inv_delta_norm_de/inv_delta_norm_ce/inv_delta_norm_fa) : (NADA);
						const double inv_delta_norms_phase_ab_sa_se_equal = (sa_se_equal) ? (inv_delta_norm_ab      *inv_delta_norm_de/inv_delta_norm_cd/inv_delta_norm_fb) : (NADA);
						const double inv_delta_norms_phase_ab_sb_se_equal = (sb_se_equal) ? (inv_delta_norm_phase_ab*inv_delta_norm_de/inv_delta_norm_cd/inv_delta_norm_fa) : (NADA);
						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd , se , sf);
			  							      
							    TYPE T2_prime_matrix_BP_J_ME = 0.0;
							      
							    if (BP_ab_de_equal && (Jab == Jde))
							      T2_prime_matrix_BP_J_ME += T2_prime_matrix_BP_J_ab_de_equal_part_calc (rho_tab , Gamma_pp_nn , ab_index ,
																     sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
																     BP_ab , Jab , inv_delta_norm_ab , inv_delta_norm_phase_ab ,
																     inv_delta_norm_de , sc , sd , se , sf);
							      
							    if (sa_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pp_nn , iJ , inv_delta_norms_phase_ab_sa_sd_equal , 1 ,
																		 Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																		 false , false , sb , sc , se , sf);
							      
							    if (sb_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pp_nn , iJ , inv_delta_norms_phase_ab_sb_sd_equal , 1 ,
																		 Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																		 false , false , sa , sc , se , sf);
																
							    if (sa_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pp_nn , iJ , inv_delta_norms_phase_ab_sa_se_equal , phase_de ,
																		 Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																		 false , false , sb , sc , sd , sf);
																
							    if (sb_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pp_nn , iJ , inv_delta_norms_phase_ab_sb_se_equal , phase_de , 
																		 Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																		 false , false , sa , sc , sd , sf);
							      
							    T2_prime_matrix_BP_J(abc_index , def_index) += T2_prime_matrix_BP_J_ME;
									
							  }}}}}}}}}}}
		
	if (is_J_smaller_than_jmax) T2_prime_ppp_nnn_matrix_omega_part_add (rho_tab , Gamma_pp_nn , BP , iJ);
      }
}















void RDM_T2_prime_class::T2_prime_ppn_block_matrices_add (
							  const class array<TYPE> &rho_neut_tab ,
							  const class RDM_PQG_class &Gamma_pp ,
							  const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != PROTONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T2_prime_class::T2_prime_matrix_ppn_add");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
                    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	  for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa_p == sb_p);
	
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_p = prot_shells_qn(sb_p);
		    const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  			  
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_p.get_ij ();
		    const int ijc = shell_qn_sc_n.get_ij ();
			  	  		      
		    const unsigned int BP_ab = BP_pp_pair_table(sa_p , sb_p);
			  
		    const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		    const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);

		    const double inv_delta_norm_ab = (sa_p == sb_p) ? (M_SQRT1_2) : (1.0);
		                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
			      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices_pp(Jab , sa_p , sb_p);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
	      
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  			      
				for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				  for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				    for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				      {
					if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
		  
					const bool sa_sd_equal = (sa_p == sd_p) , sa_se_equal = (sa_p == se_p);
					const bool sb_sd_equal = (sb_p == sd_p) , sb_se_equal = (sb_p == se_p);
					const bool sc_sf_equal = (sc_n == sf_n);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					    if (BP_def == BP)
					      {
						const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
						const class nlj_struct &shell_qn_se = prot_shells_qn(se_p);
						const class nlj_struct &shell_qn_sf = neut_shells_qn(sf_n);
			  
						const int ijd = shell_qn_sd.get_ij ();
						const int ije = shell_qn_se.get_ij ();
						const int ijf = shell_qn_sf.get_ij ();
							  
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
						const bool jc_jf_equal = (ijc == ijf);
							  
						const bool are_sd_se_equal = (sd_p == se_p);
		    
						const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
		      		 							      
						const unsigned int BP_cd = BP_pn_pair_table(sd_p , sc_n);
						const unsigned int BP_ce = BP_pn_pair_table(se_p , sc_n);
						const unsigned int BP_de = BP_pp_pair_table(sd_p , se_p);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
						const int Jmin_cd = Jmin_pn_pair_table(sd_p , sc_n);
						const int Jmax_cd = Jmax_pn_pair_table(sd_p , sc_n);
					  
						const int Jmin_ce = Jmin_pn_pair_table(se_p , sc_n);
						const int Jmax_ce = Jmax_pn_pair_table(se_p , sc_n);
					  
						const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
						const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);		    				    
		      			  
						const int Jmin_af = Jmin_pn_pair_table(sa_p , sf_n);
						const int Jmax_af = Jmax_pn_pair_table(sa_p , sf_n);
					      
						const int Jmin_bf = Jmin_pn_pair_table(sb_p , sf_n);
						const int Jmax_bf = Jmax_pn_pair_table(sb_p , sf_n);
					      
						const double inv_delta_norm_de = (sd_p == se_p) ? (M_SQRT1_2) : (1.0);
						    
						const double inv_delta_norms_phase_ab_sa_sde_equal = (sa_sd_equal || sa_se_equal) ? (inv_delta_norm_ab      *inv_delta_norm_de) : (NADA);
						const double inv_delta_norms_phase_ab_sb_sde_equal = (sb_sd_equal || sb_se_equal) ? (inv_delta_norm_phase_ab*inv_delta_norm_de) : (NADA);
												
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);
			  							      
							    TYPE T2_prime_matrix_BP_J_ME = 0.0;
								  
							    if (BP_ab_de_equal && (Jab == Jde))
							      T2_prime_matrix_BP_J_ME += T2_prime_matrix_BP_J_ab_de_equal_part_calc (rho_neut_tab , Gamma_pp , ab_index ,
																     sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
																     BP_ab , Jab , inv_delta_norm_ab , inv_delta_norm_phase_ab ,
																     inv_delta_norm_de , sc_n , sd_p , se_p , sf_n);

							    if (sa_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sa_sde_equal , 1 ,
																		 Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																		 false , true , sb_p , sc_n , se_p , sf_n);
								
							    if (sb_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sb_sde_equal , 1 ,
																		 Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																		 false , true , sa_p , sc_n , se_p , sf_n);
								
							    if (sa_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sa_sde_equal , phase_de , 
																		 Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																		 false , true , sb_p , sc_n , sd_p , sf_n);
								
							    if (sb_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sb_sde_equal , phase_de ,
																		 Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																		 false , true , sa_p , sc_n , sd_p , sf_n);
							      
							    T2_prime_matrix_BP_J(abc_index , def_index) += T2_prime_matrix_BP_J_ME;
									
							  }}}}}}}}}}}}
}



void RDM_T2_prime_class::T2_prime_nnp_block_matrices_add (
							  const class array<TYPE> &rho_prot_tab ,
							  const class RDM_PQG_class &Gamma_nn ,
							  const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T2_prime_class::T2_prime_matrix_nnp_add");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
                    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {	
		if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa_n == sb_n);
		      
		    const class nlj_struct &shell_qn_sa_n = neut_shells_qn(sa_n);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		    const int ija = shell_qn_sa_n.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_p.get_ij ();
			  	  		      
		    const unsigned int BP_ab = BP_nn_pair_table(sa_n , sb_n);
			  
		    const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		    const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);

		    const double inv_delta_norm_ab = (sa_n == sb_n) ? (M_SQRT1_2) : (1.0);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices_nn(Jab , sa_n , sb_n);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			      
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  			      
				for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				  for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				    for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				      {
					if (!is_it_in_space_tab(sd_n , se_n , sf_p)) continue;
		  
					const bool sa_sd_equal = (sa_n == sd_n) , sa_se_equal = (sa_n == se_n);
					const bool sb_sd_equal = (sb_n == sd_n) , sb_se_equal = (sb_n == se_n);
					const bool sc_sf_equal = (sc_p == sf_p);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					    if (BP_def == BP)
					      {
						const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
						const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
						const class nlj_struct &shell_qn_sf = prot_shells_qn(sf_p);
			  
						const int ijd = shell_qn_sd.get_ij ();
						const int ije = shell_qn_se.get_ij ();
						const int ijf = shell_qn_sf.get_ij ();
							  
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
						
						const bool jc_jf_equal = (ijc == ijf);
							  
						const bool are_sd_se_equal = (sd_n == se_n);
		    
						const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);						      
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
		      		 							      
						const unsigned int BP_cd = BP_pn_pair_table(sc_p , sd_n);
						const unsigned int BP_ce = BP_pn_pair_table(sc_p , se_n);
						const unsigned int BP_de = BP_nn_pair_table(sd_n , se_n);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
						const int Jmin_cd = Jmin_pn_pair_table(sc_p , sd_n);
						const int Jmax_cd = Jmax_pn_pair_table(sc_p , sd_n);
					  
						const int Jmin_ce = Jmin_pn_pair_table(sc_p , se_n);
						const int Jmax_ce = Jmax_pn_pair_table(sc_p , se_n);
					  
						const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
						const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);		    				    
		      			  
						const int Jmin_af = Jmin_pn_pair_table(sf_p , sa_n);
						const int Jmax_af = Jmax_pn_pair_table(sf_p , sa_n);
					      
						const int Jmin_bf = Jmin_pn_pair_table(sf_p , sb_n);
						const int Jmax_bf = Jmax_pn_pair_table(sf_p , sb_n);
					      
						const double inv_delta_norm_de = (sd_n == se_n) ? (M_SQRT1_2) : (1.0);
						    
						const double inv_delta_norms_phase_ab_sa_sde_equal = (sa_sd_equal || sa_se_equal) ? (inv_delta_norm_ab      *inv_delta_norm_de) : (NADA);
						const double inv_delta_norms_phase_ab_sb_sde_equal = (sb_sd_equal || sb_se_equal) ? (inv_delta_norm_phase_ab*inv_delta_norm_de) : (NADA);
						
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
			  							      
							    TYPE T2_prime_matrix_BP_J_ME = 0.0;
								  
							    if (BP_ab_de_equal && (Jab == Jde))
							      T2_prime_matrix_BP_J_ME += T2_prime_matrix_BP_J_ab_de_equal_part_calc (rho_prot_tab , Gamma_nn , ab_index ,
																     sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal , sc_sf_equal , jc_jf_equal ,
																     BP_ab , Jab , inv_delta_norm_ab , inv_delta_norm_phase_ab ,
																     inv_delta_norm_de , sc_p , sd_n , se_n , sf_p);
							      
							    if (sa_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ ,  inv_delta_norms_phase_ab_sa_sde_equal , 1 , 
																		 Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																		 true , false , sb_n , sc_p , se_n , sf_p);
								
							    if (sb_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sb_sde_equal , 1 , 
																		 Jmin_ce , Jmax_ce , Jmin_af , Jmax_af , BP_ce , Jab , Jde , ijb , ija , ijc , ije , ijf ,
																		 true , false , sa_n , sc_p , se_n , sf_p);
							      
							    if (sa_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sa_sde_equal , phase_de , 
																		 Jmin_cd , Jmax_cd , Jmin_bf , Jmax_bf , BP_cd , Jab , Jde , ija , ijb , ijc , ijd , ijf ,
																		 true , false , sb_n , sc_p , sd_n , sf_p);
								
							    if (sb_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , inv_delta_norms_phase_ab_sb_sde_equal , phase_de , 
																		 Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																		 true , false , sa_n , sc_p , sd_n , sf_p);
							  
							    T2_prime_matrix_BP_J(abc_index , def_index) += T2_prime_matrix_BP_J_ME;
							  
							  }}}}}}}}}}}}
}




void RDM_T2_prime_class::T2_prime_pnp_matrix_omega_part_add (
							     const class array<TYPE> &rho_neut_tab ,
							     const class RDM_PQG_class &Gamma_pn ,
							     const unsigned int BP ,
							     const int iJ)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != PROTON)) error_message_print_abort ("pn + p space only in RDM_T2_prime_class::T2_prime_matrix_pnp_omega_part_add");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);
	  
  class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
	  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	{	
	  if (!is_it_in_space_tab(sa_p , sb_n , sc_p)) continue;
				      
	  const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_p);

	  if (BP_abc == BP)
	    {	
	      const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
		  		
	      const unsigned int ijc = shell_qn_sc.get_ij ();
				      			  	  		      
	      const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
		      
	      const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
	      const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);

	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;	
				 
	      for (unsigned int sg_n = 0 ; sg_n < Nn_nlj ; sg_n++)
		{		  
		  const class nlj_struct &shell_qn_sg = neut_shells_qn(sg_n);
		  
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
			
		  if (ijg == iJ)
		    {		      
		      const unsigned int BP_gc = BP_pn_pair_table(sc_p , sg_n);
					
		      if (BP_gc == BP_ab)
			{			      	
			  const double jg = shell_qn_sg.get_j ();
			      
			  const double hat_jg = hat (jg);
			  
			  const int Jmin_gc = Jmin_pn_pair_table(sc_p , sg_n);
			  const int Jmax_gc = Jmax_pn_pair_table(sc_p , sg_n);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);
		      
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const unsigned int ab_index = two_states_indices_pn(J_pair , sa_p , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(J_pair , iJ , sa_p , sb_n , sc_p);
			
			      const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_p);
			      const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_p);

			      if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				{	
				  const double hat_J_pair = hat (J_pair);
		      
				  const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);
			      		      
				  const unsigned int gc_index = two_states_indices_pn(J_pair , sc_p , sg_n);
					  
				  const int phase_gc = ((ijg + ijc + J_pair)%2 == 0) ? (1) : (-1);
					      
				  const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BP_ab + 2*J_pair);
					  
				  const TYPE Gamma_pn_ME_phase_abc = (phase_gc == phase_abc) ? (Gamma_pn_matrix(ab_index , gc_index)) : (-Gamma_pn_matrix(ab_index , gc_index));
			      
				  const TYPE T2_prime_matrix_BP_J_ME = Gamma_pn_ME_phase_abc*hat_J_pair/hat_jg;
				  
				  T2_prime_matrix_BP_J(two_body_T2_prime_omega_index , abc_index) += T2_prime_matrix_BP_J_ME;
				  T2_prime_matrix_BP_J(abc_index , two_body_T2_prime_omega_index) += T2_prime_matrix_BP_J_ME;	
				}}}
		      
		      two_body_T2_prime_omega_index++;

		    }}}}
		  
  unsigned int one_body_index_T2_prime_in = T2_matrix_dimension;
	      
  for (unsigned int sh_n = 0 ; sh_n < Nn_nlj ; sh_n++)
    {
      const class nlj_struct &shell_qn_sh = neut_shells_qn(sh_n);
		    
      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
		    
      if (ijh == iJ)
	{
	  unsigned int one_body_index_T2_prime_out = T2_matrix_dimension;
	      
	  for (unsigned int sg_n = 0 ; sg_n < Nn_nlj ; sg_n++)
	    {	  
	      const class nlj_struct &shell_qn_sg = neut_shells_qn(sg_n);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
	      
	      const int lg = shell_qn_sg.get_l ();
			  
	      const int ijg = shell_qn_sg.get_ij ();

	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      T2_prime_matrix_BP_J(one_body_index_T2_prime_in  , one_body_index_T2_prime_out) += rho_neut_tab (sg_n , sh_n);
		      T2_prime_matrix_BP_J(one_body_index_T2_prime_out , one_body_index_T2_prime_in)  += rho_neut_tab (sg_n , sh_n);
		    }
		  
		  one_body_index_T2_prime_out++;
		}
	    }
	  
	  one_body_index_T2_prime_in++;
	}
    }
}







void RDM_T2_prime_class::T2_prime_pnp_block_matrices_add (
							  const class array<TYPE> &rho_prot_tab ,
							  const class array<TYPE> &rho_neut_tab ,
							  const class RDM_PQG_class &Gamma_pp ,
							  const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != PROTON)) error_message_print_abort ("pn + p space only in RDM_T2_prime_class::T2_prime_matrix_pnp_add");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
        
  const double jn_max = neut_data.get_jmax ();
              
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
          
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
      
	const bool is_J_smaller_than_jn_max = (make_int (J - jn_max) <= 0);      
	
	class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_p)) continue;
	  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_p);

		if (BP_abc == BP)
		  {
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_p.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
			  
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {		      				
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int ab_index = two_states_indices_pn(Jab , sa_p , sb_n);
			      
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_p);
			  
			    const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
			      
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				  {
				    if (!is_it_in_space_tab(sd_p , se_n , sf_p)) continue;
	  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_p == sf_p);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_p);
					      
					if (BP_def == BP)
					  {
					    const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
					    const class nlj_struct &shell_qn_sf = prot_shells_qn(sf_p);
			  
					    const int ijd = shell_qn_sd.get_ij ();
					    const int ije = shell_qn_se.get_ij ();
					    const int ijf = shell_qn_sf.get_ij ();
							  
					    const bool ja_jd_equal = (ija == ijd);
					    const bool jb_je_equal = (ijb == ije);
					    const bool jc_jf_equal = (ijc == ijf);
		    
					    const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					    const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
		      		 							      
					    const unsigned int BP_cd = BP_pp_pair_table(sc_p , sd_p);
					    const unsigned int BP_ce = BP_pn_pair_table(sc_p , se_n);
					    const unsigned int BP_de = BP_pn_pair_table(sd_p , se_n);

					    const bool BP_ab_de_equal = (BP_ab == BP_de);
											      
					    const int Jmin_cd = Jmin_pp_pair_table(sc_p , sd_p);
					    const int Jmax_cd = Jmax_pp_pair_table(sc_p , sd_p);
					  
					    const int Jmin_ce = Jmin_pn_pair_table(sc_p , se_n);
					    const int Jmax_ce = Jmax_pn_pair_table(sc_p , se_n);
					  
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);		    				    
		      			  
					    const int Jmin_af = Jmin_pp_pair_table(sa_p , sf_p);
					    const int Jmax_af = Jmax_pp_pair_table(sa_p , sf_p);
					      
					    const int Jmin_bf = Jmin_pn_pair_table(sf_p , sb_n);
					    const int Jmax_bf = Jmax_pn_pair_table(sf_p , sb_n);
					      
					    const double inv_delta_norm_fa = (sf_p == sa_p) ? (M_SQRT1_2) : (1.0);
					    const double inv_delta_norm_cd = (sc_p == sd_p) ? (M_SQRT1_2) : (1.0);
						    
					    const double inv_delta_norms_phase_ab_sb_se_equal = (sb_se_equal) ? (phase_ab/inv_delta_norm_cd/inv_delta_norm_fa) : (NADA);
						
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {	
						    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_p);
			  							      
						    TYPE T2_prime_matrix_BP_J_ME = 0.0;
								  
						    if (BP_ab_de_equal && (Jab == Jde))															
						      T2_prime_matrix_BP_J_ME += T2_prime_matrix_BP_J_ab_de_equal_part_calc (rho_prot_tab , Gamma_pn , ab_index ,
															     sa_sd_jb_je_equal , sb_se_ja_jd_equal , false , false , sc_sf_equal , jc_jf_equal ,
															     BP_ab , Jab , 1.0 , NADA , 1.0 , sc_p , sd_p , se_n , sf_p);
							  
						    if (sa_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , 1.0 , 1 ,
																	 Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																	 true , false , sb_n , sc_p , se_n , sf_p);

						    if (sb_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pp , iJ , inv_delta_norms_phase_ab_sb_se_equal , phase_de ,
																	 Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																	 false , false , sa_p , sc_p , sd_p , sf_p);
						      								      
						    T2_prime_matrix_BP_J(abc_index , def_index) += T2_prime_matrix_BP_J_ME;
										
						  }}}}}}}}}

	if (is_J_smaller_than_jn_max) T2_prime_pnp_matrix_omega_part_add (rho_neut_tab , Gamma_pn , BP , iJ);
      }
}












void RDM_T2_prime_class::T2_prime_pnn_matrix_omega_part_add (
							     const class array<TYPE> &rho_prot_tab ,
							     const class RDM_PQG_class &Gamma_pn ,
							     const unsigned int BP ,
							     const int iJ)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_class::T2_prime_matrix_pnn_omega_part_add");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const unsigned int Np_nlj = prot_shells_qn.dimension (0);
  const unsigned int Nn_nlj = neut_shells_qn.dimension (0);
  
  const unsigned int T2_matrix_dimension = T2_matrix_dimensions(BP , iJ);

  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
    
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
	  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	{	
	  if (!is_it_in_space_tab(sa_p , sb_n , sc_n)) continue;
				  
	  const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_n);

	  if (BP_abc == BP)
	    {	
	      const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
		  				
	      const int ijc = shell_qn_sc.get_ij ();
	    
	      const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
			  
	      const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
	      const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
					  
	      unsigned int two_body_T2_prime_omega_index = T2_matrix_dimension;
	      
	      for (unsigned int sg_p = 0 ; sg_p < Np_nlj ; sg_p++)
		{
		  const class nlj_struct &shell_qn_sg = prot_shells_qn(sg_p);
				  	
		  const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();
	      
		  if (frozen_state_sg) continue;
	      
		  const int ijg = shell_qn_sg.get_ij ();
					  
		  if (ijg == iJ)
		    {	
		      const unsigned int BP_gc = BP_pn_pair_table(sg_p , sc_n);

		      if (BP_gc == BP_ab)
			{				      
			  const double jg = shell_qn_sg.get_j ();
		  
			  const double hat_jg = hat (jg);			  
				
			  const int Jmin_gc = Jmin_pn_pair_table(sg_p , sc_n);
			  const int Jmax_gc = Jmax_pn_pair_table(sg_p , sc_n);

			  const int Jmin_pair = max (Jmin_ab , Jmin_gc);
			  const int Jmax_pair = min (Jmax_ab , Jmax_gc);	 	
		  
			  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
			    {
			      const unsigned int ab_index = two_states_indices_pn(J_pair , sa_p , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(J_pair , iJ , sa_p , sb_n , sc_n);
			
			      const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_n);
			      const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_n);
			      
			      if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				{					  
				  const double hat_J_pair = hat (J_pair);
				  
				  const int phase_abc = ((ijc + iJ + J_pair)%2 == 1) ? (1) : (-1);
		      			      
				  const unsigned int gc_index = two_states_indices_pn(J_pair , sg_p , sc_n);
		  
				  const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BP_ab + 2*J_pair);
		  
				  const TYPE Gamma_pn_ME = Gamma_pn_matrix(ab_index , gc_index);
			      
				  const TYPE T2_prime_matrix_BP_J_ME = (phase_abc == 1) ? (Gamma_pn_ME*hat_J_pair/hat_jg) : (-Gamma_pn_ME*hat_J_pair/hat_jg);
				  
				  T2_prime_matrix_BP_J(two_body_T2_prime_omega_index , abc_index) += T2_prime_matrix_BP_J_ME;
				  T2_prime_matrix_BP_J(abc_index , two_body_T2_prime_omega_index) += T2_prime_matrix_BP_J_ME;
				}}}
				      
		      two_body_T2_prime_omega_index++;
			  
		    }}}}
	      
  unsigned int one_body_T2_prime_omega_index_in = T2_matrix_dimension;
	      
  for (unsigned int sh_p = 0 ; sh_p < Np_nlj ; sh_p++)
    {
      const class nlj_struct &shell_qn_sh = prot_shells_qn(sh_p);
		    
      const bool frozen_state_sh = shell_qn_sh.get_frozen_state ();

      if (frozen_state_sh) continue;
      
      const int lh = shell_qn_sh.get_l ();
		  
      const int ijh = shell_qn_sh.get_ij ();
		    
      if (ijh == iJ)
	{
	  unsigned int one_body_T2_prime_omega_index_out = T2_matrix_dimension;
	      
	  for (unsigned int sg_p = 0 ; sg_p < Np_nlj ; sg_p++)
	    {	  
	      const class nlj_struct &shell_qn_sg = prot_shells_qn(sg_p);

	      const bool frozen_state_sg = shell_qn_sg.get_frozen_state ();

	      if (frozen_state_sg) continue;
	      
	      const int lg = shell_qn_sg.get_l ();
			  
	      const int ijg = shell_qn_sg.get_ij ();

	      if (ijg == ijh)
		{			
		  if (lg == lh)
		    {
		      T2_prime_matrix_BP_J(one_body_T2_prime_omega_index_in  , one_body_T2_prime_omega_index_out) += rho_prot_tab (sg_p , sh_p);
		      T2_prime_matrix_BP_J(one_body_T2_prime_omega_index_out , one_body_T2_prime_omega_index_in)  += rho_prot_tab (sg_p , sh_p);
		    }
		  
		  one_body_T2_prime_omega_index_out++;
		}
	    }
	  
	  one_body_T2_prime_omega_index_in++;  
	}
    }
}








   
void RDM_T2_prime_class::T2_prime_pnn_block_matrices_add (
							  const class array<TYPE> &rho_prot_tab ,
							  const class array<TYPE> &rho_neut_tab ,
							  const class RDM_PQG_class &Gamma_nn ,
							  const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != PROTONS_NEUTRONS) && (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_class::T2_prime_matrix_pnn_add");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
        
  const double jp_max = prot_data.get_jmax ();
            
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	const double J = iJ + 0.5;
            
	const bool is_J_smaller_than_jp_max = (make_int (J - jp_max) <= 0);
      
	class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  	  
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_n)) continue;
	  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_n);

		if (BP_abc == BP)
		  {
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  			  
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_n.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pn_pair_table(sa_p , sb_n);
			  
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
      
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {		      				
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
	      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int ab_index = two_states_indices_pn(Jab , sa_p , sb_n);
			      
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_n);
			  
			    const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
			      
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				  {		
				    if (!is_it_in_space_tab(sd_p , se_n , sf_n)) continue;
	  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_n == sf_n);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_n);
					      
					if (BP_def == BP)
					  {
					    const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    const class nlj_struct &shell_qn_se = neut_shells_qn(se_n);
					    const class nlj_struct &shell_qn_sf = neut_shells_qn(sf_n);
			  
					    const int ijd = shell_qn_sd.get_ij ();
					    const int ije = shell_qn_se.get_ij ();
					    const int ijf = shell_qn_sf.get_ij ();
							  
					    const bool ja_jd_equal = (ija == ijd);
					    const bool jb_je_equal = (ijb == ije);
						
					    const bool jc_jf_equal = (ijc == ijf);
		    
					    const bool sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					    const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
		      								      
					    const unsigned int BP_cd = BP_pn_pair_table(sd_p , sc_n);
					    const unsigned int BP_ce = BP_nn_pair_table(sc_n , se_n);
					    const unsigned int BP_de = BP_pn_pair_table(sd_p , se_n);

					    const bool BP_ab_de_equal = (BP_ab == BP_de);
									      
					    const int Jmin_cd = Jmin_pn_pair_table(sd_p , sc_n);
					    const int Jmax_cd = Jmax_pn_pair_table(sd_p , sc_n);
					  
					    const int Jmin_ce = Jmin_nn_pair_table(sc_n , se_n);
					    const int Jmax_ce = Jmax_nn_pair_table(sc_n , se_n);
					  
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);		    				    
		      			  
					    const int Jmin_af = Jmin_pn_pair_table(sa_p , sf_n);
					    const int Jmax_af = Jmax_pn_pair_table(sa_p , sf_n);
					      
					    const int Jmin_bf = Jmin_nn_pair_table(sb_n , sf_n);
					    const int Jmax_bf = Jmax_nn_pair_table(sb_n , sf_n);
					      
					    const double inv_delta_norm_ce = (sc_n == se_n) ? (M_SQRT1_2) : (1.0);
					    const double inv_delta_norm_fb = (sf_n == sb_n) ? (M_SQRT1_2) : (1.0);
						    
					    const double inv_delta_norms_phase_ab_sa_sd_equal = (sa_sd_equal) ? (1.0/inv_delta_norm_ce/inv_delta_norm_fb) : (NADA);
						
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {	
						    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_n);
			  							      
						    TYPE T2_prime_matrix_BP_J_ME = 0.0;
								  
						    if (BP_ab_de_equal && (Jab == Jde))
						      T2_prime_matrix_BP_J_ME += T2_prime_matrix_BP_J_ab_de_equal_part_calc (rho_neut_tab , Gamma_pn , ab_index ,  sa_sd_jb_je_equal , sb_se_ja_jd_equal , false , false , sc_sf_equal , jc_jf_equal , 
															     BP_ab , Jab , 1.0 , NADA , 1.0 , sc_n , sd_p , se_n , sf_n);
							
						    if (sa_sd_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_nn , iJ , inv_delta_norms_phase_ab_sa_sd_equal , 1 , 
																	 Jmin_ce , Jmax_ce , Jmin_bf , Jmax_bf , BP_ce , Jab , Jde , ija , ijb , ijc , ije , ijf ,
																	 false , false , sb_n , sc_n , se_n , sf_n);
								
						    if (sb_se_equal) T2_prime_matrix_BP_J_ME += T2_prime_matrix_sab_sde_equal_part_calc (Gamma_pn , iJ , phase_ab , phase_de ,
																	 Jmin_cd , Jmax_cd , Jmin_af , Jmax_af , BP_cd , Jab , Jde , ijb , ija , ijc , ijd , ijf ,
																	 false , true , sa_p , sc_n , sd_p , sf_n);
						      
						    T2_prime_matrix_BP_J(abc_index , def_index) += T2_prime_matrix_BP_J_ME;
									
						  }}}}}}}}}

	if (is_J_smaller_than_jp_max) T2_prime_pnn_matrix_omega_part_add (rho_prot_tab , Gamma_pn , BP , iJ);
      }
}




 


// The matrix elements of prime conditions are not printed as they are directly proportional to Gamma_pp_nn or rho.

void RDM_T2_prime_class::precision_T2_ppp_nnn_class_file_calc_print (
								     const int Z ,
								     const int N ,
								     const unsigned int RDM_BP ,
								     const double RDM_J ,
								     const unsigned int RDM_vector_index ,
								     const class RDM_PQG_class &Gamma_pp_nn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T2_prime_class::print_precision_T2_ppp_nnn_class_file_calc_print");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::print_precision_T2_ppp_nnn_class_file_calc_print (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::print_precision_T2_ppp_nnn_class_file_calc_print (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T2_prime_class::print_precision_T2_ppp_nnn_class_file_calc_print (no nn + p)");
    
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
            
  if (N_nlj == 0) return;
    
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (T2_RDM_PPP) : (T2_RDM_NNN);
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_two_shells = make_int (2.0*jmax);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
        
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
    
  const int J_total_number = matrix_dimensions.dimension (1);
        
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
    
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
  
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  const string ppp_nnn = (space_pair == PROTONS_ONLY) ? ("ppp") : ("nnn");
  
  ifstream infile(infile_name.c_str() , ios::binary);
    
  if (!infile) 
    {
      cout << "No file found for T2[" << ppp_nnn << "] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T2_ppp_nnn_RDM_array(N_nlj , N_nlj , N_nlj , Jmax_two_shells_plus_one , N_nlj , N_nlj , N_nlj , Jmax_two_shells_plus_one , J_total_number);

  T2_ppp_nnn_RDM_array.read_disk (infile_name);
  
  double T2_ppp_nnn_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)      
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	      {		
		if (!is_it_in_space_tab(sa , sb , sc)) continue;
		  
		const unsigned int BP_abc = BP_table(sa , sb , sc);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa == sb);
			  			  
		    const int Jmin_ab = Jmin_pair_table(sa , sb);
		    const int Jmax_ab = Jmax_pair_table(sa , sb);
				                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
			  
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa , sb , sc);
				      
				for (unsigned int se = 0 ; se < N_nlj ; se++)
				  for (unsigned int sd = 0 ; sd <= se ; sd++)
				    for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
				      {
					if (!is_it_in_space_tab(sd , se , sf)) continue;

					const bool sa_sd_equal = (sa == sd) , sa_se_equal = (sa == se);
					const bool sb_sd_equal = (sb == sd) , sb_se_equal = (sb == se);
					const bool sc_sf_equal = (sc == sf);
				      
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd , se , sf);
					      
					    if (BP_def == BP)
					      {
						const bool are_sd_se_equal = (sd == se);
		      					  
						const int Jmin_de = Jmin_pair_table(sd , se);
						const int Jmax_de = Jmax_pair_table(sd , se);		  
		      			  						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {						  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd , se , sf);
							  
							    T2_ppp_nnn_precision = max (T2_ppp_nnn_precision , abs (T2_prime_matrix_BP_J(abc_index , def_index) - T2_ppp_nnn_RDM_array(sa , sb , sc , Jab , sd , se , sf , Jde , iJ)));
								
							  }}}}}}}}}}}}

  cout << "T2[" << ppp_nnn << "] precision : " << T2_ppp_nnn_precision << endl;
}















void RDM_T2_prime_class::precision_T2_ppn_class_file_calc_print (
								 const int Z ,
								 const int N ,
								 const unsigned int RDM_BP ,
								 const double RDM_J ,
								 const unsigned int RDM_vector_index ,
								 const class RDM_PQG_class &Gamma_pp) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T2_prime_class::print_precision_T2_ppn_class_file_calc_print");
  
  if ((space_pair != PROTONS_ONLY) || (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T2_prime_class::print_precision_T2_ppn_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();

  if (Zval < 2) return;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jp_max = prot_data.get_jmax ();
    
  const int Jmax_two_shells = make_int (2.0*jp_max);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
              
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
          
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T2_RDM_PPN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
    
  if (!infile) 
    {
      cout << "No file found for T2[ppn] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T2_ppn_RDM_array(Np_nlj , Np_nlj , Nn_nlj , Jmax_two_shells_plus_one , Np_nlj , Np_nlj , Nn_nlj , Jmax_two_shells_plus_one , J_total_number);  
  
  T2_ppn_RDM_array.read_disk (infile_name);
  
  double T2_ppn_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)      
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	  for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa_p == sb_p);
		  			  			  			  
		    const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		    const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);			  
		                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
			      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
				      
				for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				  for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				    for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				      {
					if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
		  
					const bool sa_sd_equal = (sa_p == sd_p) , sa_se_equal = (sa_p == se_p);
					const bool sb_sd_equal = (sb_p == sd_p) , sb_se_equal = (sb_p == se_p);
					const bool sc_sf_equal = (sc_n == sf_n);
				      
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					    if (BP_def == BP)
					      {
						const bool are_sd_se_equal = (sd_p == se_p);
									  
						const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
						const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);	
		      			  						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {						  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);

							    T2_ppn_precision = max (T2_ppn_precision , abs (T2_prime_matrix_BP_J(abc_index , def_index) - T2_ppn_RDM_array(sa_p , sb_p , sc_n , Jab , sd_p , se_p , sf_n , Jde , iJ)));
							    
							  }}}}}}}}}}}}
  
  cout << "T2[ppn] precision : " << T2_ppn_precision << endl;
}



void RDM_T2_prime_class::precision_T2_nnp_class_file_calc_print (
								 const int Z ,
								 const int N ,
								 const unsigned int RDM_BP ,
								 const double RDM_J ,
								 const unsigned int RDM_vector_index ,
								 const class RDM_PQG_class &Gamma_nn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T2_prime_class::print_precision_T2_nnp_class_file_calc_print");
  
  if ((space_pair != NEUTRONS_ONLY) || (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T2_prime_class::print_precision_T2_nnp_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const int Nval = neut_data.get_N_valence_nucleons ();

  if (Nval < 2) return;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_two_shells = make_int (2.0*jn_max);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
            
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
          
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T2_RDM_NNP);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);

  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
    
  if (!infile) 
    {
      cout << "No file found for T2[nnp] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T2_nnp_RDM_array(Nn_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_plus_one , Nn_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_plus_one , J_total_number);
  
  T2_nnp_RDM_array.read_disk (infile_name);
  
  double T2_nnp_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)      
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {	
		if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

		if (BP_abc == BP)
		  {
		    const bool are_sa_sb_equal = (sa_n == sb_n);
			  	  		      			  
		    const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		    const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);
		                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {      	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
			      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			      
				for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				  for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				    for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				      {
					if (!is_it_in_space_tab(sd_n , se_n , sf_p)) continue;
		  
					const bool sa_sd_equal = (sa_n == sd_n) , sa_se_equal = (sa_n == se_n);
					const bool sb_sd_equal = (sb_n == sd_n) , sb_se_equal = (sb_n == se_n);
					const bool sc_sf_equal = (sc_p == sf_p);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					    if (BP_def == BP)
					      {
						const bool are_sd_se_equal = (sd_n == se_n);
					  
						const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
						const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);	
		      			  						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {						  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
			  							
							    T2_nnp_precision = max (T2_nnp_precision , abs (T2_prime_matrix_BP_J(abc_index , def_index) - T2_nnp_RDM_array(sa_n , sb_n , sc_p , Jab , sd_n , se_n , sf_p , Jde , iJ)));

							  }}}}}}}}}}}}
  
  cout << "T2[nnp] precision : " << T2_nnp_precision << endl;
}





void RDM_T2_prime_class::precision_T2_pnp_class_file_calc_print (
								 const int Z ,
								 const int N ,
								 const unsigned int RDM_BP ,
								 const double RDM_J ,
								 const unsigned int RDM_vector_index ,
								 const class RDM_PQG_class &Gamma_pn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T2_prime_class::print_precision_T2_pnp_class_file_calc_print");
  
  if ((space_pair != PROTONS_NEUTRONS) || (last_particle != PROTON)) error_message_print_abort ("pn + p space only in RDM_T2_prime_class::print_precision_T2_pnp_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
  
  const int Jmax_two_shells_pn = make_int (jp_max + jn_max);

  const int Jmax_two_shells_plus_one_pn = Jmax_two_shells_pn + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
      
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T2_RDM_PNP);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
    
  if (!infile) 
    {
      cout << "No file found for T2[pnp] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T2_pnp_RDM_array(Np_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_plus_one_pn , Np_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_plus_one_pn , J_total_number);
  
  T2_pnp_RDM_array.read_disk (infile_name);
  
  double T2_pnp_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)            
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {      
	const class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_p)) continue;
	  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_p);

		if (BP_abc == BP)
		  {		      
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);
		                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {			      			
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
			      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_p);
			  
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				  {
				    if (!is_it_in_space_tab(sd_p , se_n , sf_p)) continue;
	  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_p == sf_p);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_p);
					      
					if (BP_def == BP)
					  {
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);
		      			  						    
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {						  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_p);
			  					
						    T2_pnp_precision = max (T2_pnp_precision , abs (T2_prime_matrix_BP_J(abc_index , def_index) - T2_pnp_RDM_array(sa_p , sb_n , sc_p , Jab , sd_p , se_n , sf_p , Jde , iJ)));

						  }}}}}}}}}}
  
  cout << "T2[pnp] precision : " << T2_pnp_precision << endl;
}












   
void RDM_T2_prime_class::precision_T2_pnn_class_file_calc_print (
								 const int Z ,
								 const int N ,
								 const unsigned int RDM_BP ,
								 const double RDM_J ,
								 const unsigned int RDM_vector_index ,
								 const class RDM_PQG_class &Gamma_pn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T2_prime_class::print_precision_T2_pnn_class_file_calc_print");
  
  if ((space_pair != PROTONS_NEUTRONS) || (last_particle != NEUTRON)) error_message_print_abort ("pn + n space only in RDM_T2_prime_class::print_precision_T2_pnn_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
    
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
  
  const int Jmax_two_shells_pn = make_int (jp_max + jn_max);

  const int Jmax_two_shells_plus_one_pn = Jmax_two_shells_pn + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
      
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T2_RDM_PNN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
    
  if (!infile) 
    {
      cout << "No file found for T2[pnn] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T2_pnn_RDM_array(Np_nlj , Nn_nlj , Nn_nlj , Jmax_two_shells_plus_one_pn , Np_nlj , Nn_nlj , Nn_nlj , Jmax_two_shells_plus_one_pn , J_total_number);
  
  T2_pnn_RDM_array.read_disk (infile_name);
  
  double T2_pnn_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)                  
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {      
	const class matrix<TYPE> &T2_prime_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  	  
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {	
		if (!is_it_in_space_tab(sa_p , sb_n , sc_n)) continue;
	  
		const unsigned int BP_abc = BP_table(sa_p , sb_n , sc_n);

		if (BP_abc == BP)
		  {			  
		    const int Jmin_ab = Jmin_pn_pair_table(sa_p , sb_n);
		    const int Jmax_ab = Jmax_pn_pair_table(sa_p , sb_n);		  
		                  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {			
			const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
			      
			if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			  {
			    const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_n , sc_n);
			  
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				  {		
				    if (!is_it_in_space_tab(sd_p , se_n , sf_n)) continue;
	  
				    const bool sa_sd_equal = (sa_p == sd_p);
				    const bool sb_se_equal = (sb_n == se_n);
				    const bool sc_sf_equal = (sc_n == sf_n);
					  
				    if (sa_sd_equal || sb_se_equal || sc_sf_equal)
				      {
					const unsigned int BP_def = BP_table(sd_p , se_n , sf_n);
					      
					if (BP_def == BP)
					  {
					    const int Jmin_de = Jmin_pn_pair_table(sd_p , se_n);
					    const int Jmax_de = Jmax_pn_pair_table(sd_p , se_n);	
		      			  						    
					    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
					      {		      	
						const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
						const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
						const int iJmin = max (iJmin_abc , iJmin_def);
						const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						if ((iJ >= iJmin) && (iJ <= iJmax))
						  {						  
						    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_n , sf_n);
			  				
						    T2_pnn_precision = max (T2_pnn_precision , abs (T2_prime_matrix_BP_J(abc_index , def_index) - T2_pnn_RDM_array(sa_p , sb_n , sc_n , Jab , sd_p , se_n , sf_n , Jde , iJ)));
							      									
						  }}}}}}}}}}
  
  cout << "T2[pnn] precision : " << T2_pnn_precision << endl;
}





void RDM_T2_prime_class::make_it_positive_definite (
						    class block_matrix<TYPE> &P_transpose ,
						    class block_matrix<TYPE> &Dp_P_transpose)
{
  const unsigned int block_matrix_abcdef_dimension = block_matrix_abcdef.get_dimension ();

  if (block_matrix_abcdef_dimension == 0) return;
    
  P_transpose = block_matrix_abcdef;
  
  P_transpose.symmetrize ();

  if (!block_matrix_abcdef_eigenvalues.is_it_filled ()) block_matrix_abcdef_eigenvalues.allocate (block_matrix_abcdef_dimension);
  
  total_diagonalization::all_eigenpairs_Householder (P_transpose , block_matrix_abcdef_eigenvalues);
    
  if (real_dc (block_matrix_abcdef_eigenvalues(0)) >= 0.0) return;

  Dp_P_transpose = P_transpose;
  
  for (unsigned int i = 0 ; i < block_matrix_abcdef_dimension ; i++) Dp_P_transpose.multiply_scalar_row_vector (i , delta_positive_real_part (block_matrix_abcdef_eigenvalues(i)));
  
  class block_matrix<TYPE> &P = P_transpose;

  P.transpose ();

  block_matrix_multiplication (P , Dp_P_transpose , block_matrix_abcdef);
}




#ifdef UseMPI

void RDM_T2_prime_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  if (THIS_PROCESS == Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      T_MPI(index++) = block(ii , jj);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Bcast(send).");
    }
  
  T_MPI.MPI_Bcast (Send_process , MPI_C);
  
  if (THIS_PROCESS != Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Bcast(receive).");
    }
}

void RDM_T2_prime_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Reduce(send).");
      
  T_MPI.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  if (THIS_PROCESS == Recv_process)
    {      
      index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Reduce(receive).");
    }
}

void RDM_T2_prime_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Allreduce(send).");
  
  T_MPI.MPI_Allreduce (op , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Allreduce(receive).");
}

void RDM_T2_prime_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Allgatherv(send).");
  
  T_MPI.MPI_Allgatherv (group_processes_number , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T2_prime_class::MPI_Allgatherv(receive).");
}

#endif
