#include "../RDM_include/RDM_include_def.h"


using namespace string_routines;
using namespace correlated_state_routines;
using namespace RDM_rho_observables;

void RDM_rms_radius::calc_print (
				 const class input_data_str &input_data , 
				 const class nucleons_data &prot_data , 
				 const class nucleons_data &neut_data ,
				 const class RDM_PQG_class &Gamma_pp ,
				 const class RDM_PQG_class &Gamma_nn ,
				 const class RDM_PQG_class &Gamma_pn) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "rms radii" << endl;
      cout <<         "---------" << endl << endl;
    }

  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();
  
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
    
  const int prot_hole_states_number = prot_data.get_hole_states_number ();
  const int neut_hole_states_number = neut_data.get_hole_states_number ();
  
  const int Z_core = prot_data.get_Z_core ();
  const int N_core = prot_data.get_N_core ();
  
  const int Z_frozen_core = Z_core - prot_hole_states_number;
  const int N_frozen_core = N_core - neut_hole_states_number;

  const unsigned int rms_radius_number = input_data.get_rms_radius_number ();

  const class array<bool> &rms_radius_is_it_HO_expansion_tab = input_data.get_rms_radius_is_it_HO_expansion_tab (); 

  const class array<unsigned int> &rms_radius_BP_tab = input_data.get_rms_radius_BP_tab ();

  const class array<double> &rms_radius_J_tab = input_data.get_rms_radius_J_tab ();

  const class array<unsigned int> &rms_radius_vector_index_tab = input_data.get_rms_radius_vector_index_tab ();

  const class array<enum particle_type> &rms_radius_particle_tab = input_data.get_rms_radius_particle_tab ();

  const class array<double> &rms_radius_frozen_core_tab = input_data.get_rms_radius_frozen_core_tab ();

  for (unsigned int rms_radius_index = 0 ; rms_radius_index < rms_radius_number ; rms_radius_index++)
    {
      const bool is_it_HO_expansion = rms_radius_is_it_HO_expansion_tab(rms_radius_index);

      const string HO_expansion_string = (is_it_HO_expansion) ? ("HO expansion") : ("R cut"); 

      const unsigned int BP = rms_radius_BP_tab(rms_radius_index);

      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_rms_radius::calc_print");
      
      const unsigned int vector_index = rms_radius_vector_index_tab(rms_radius_index);

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_rms_radius::calc_print");

      const double J = rms_radius_J_tab(rms_radius_index);

      if (rint (J - RDM_J)!= 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_rms_radius::calc_print");
      
      const enum particle_type particle = rms_radius_particle_tab(rms_radius_index);

      const double rms_radius_frozen_core = rms_radius_frozen_core_tab(rms_radius_index);

      const enum operator_type rms_radius_operator = rms_radius_operator_determine (particle);
       
      const TYPE rms_radius_square_valence = average_CM_op_calc (rms_radius_operator , is_it_HO_expansion , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);
      
      const TYPE rms_radius = rms_radius_calc (rms_radius_operator , Z_frozen_core , N_frozen_core , Z , N , rms_radius_frozen_core , rms_radius_square_valence);

      if (THIS_PROCESS == MASTER_PROCESS) cout << J_Pi_vector_index_string (BP , J , vector_index) << ": " << particle << " rms radius with " << HO_expansion_string << ": " << rms_radius << " fm" << endl;
    }
}


