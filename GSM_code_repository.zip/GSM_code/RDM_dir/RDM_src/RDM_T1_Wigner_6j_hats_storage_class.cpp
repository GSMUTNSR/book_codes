#include "../RDM_include/RDM_include_def.h"




RDM_T1_Wigner_6j_hats_storage_class::RDM_T1_Wigner_6j_hats_storage_class () {}




RDM_T1_Wigner_6j_hats_storage_class::RDM_T1_Wigner_6j_hats_storage_class (
									  const class nucleons_data &prot_data ,
									  const class nucleons_data &neut_data)
{
  alloc_calc_store (prot_data , neut_data);
}


RDM_T1_Wigner_6j_hats_storage_class::RDM_T1_Wigner_6j_hats_storage_class (const class RDM_T1_Wigner_6j_hats_storage_class &X)
{
  allocate_fill (X);
}

RDM_T1_Wigner_6j_hats_storage_class::~RDM_T1_Wigner_6j_hats_storage_class () {}



void RDM_T1_Wigner_6j_hats_storage_class::alloc_calc_store (
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data)
{      
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_gradient_class cannot be allocated twice in RDM_T1_Wigner_6j_hats_storage_class::alloc_calc_store");
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
  
  const int Jmax_pair = make_int (2.0*jmax);
  
  const int Jmax_pair_plus_one = Jmax_pair + 1;
  
  const double Jmax_total = Jmax_pair + jmax;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
                    
  unsigned int dimension = 0;
  
  Wigner_6j_hats_indices.allocate (j_number , j_number , j_number , Jmax_pair_plus_one , Jmax_pair_plus_one , J_total_number);
	       
  Wigner_6j_hats_indices = Wigner_6j_hats_indices.dimension_total ();

  Wigner_6j_hats_indices_tabs_determine (DIMENSIONS_TABLES_CALC , prot_data , neut_data , dimension);
    
  Wigner_6j_hats_tab.allocate (dimension);

  dimension = 0;
  
  Wigner_6j_hats_tab = 0.0;
  
  Wigner_6j_hats_indices_tabs_determine (TABLES_FILL , prot_data , neut_data , dimension);
}






void RDM_T1_Wigner_6j_hats_storage_class::allocate_fill (const class RDM_T1_Wigner_6j_hats_storage_class &X)
{  
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_gradient_class cannot be allocated twice in RDM_T1_Wigner_6j_hats_storage_class::allocate_fill");
  
  Wigner_6j_hats_indices.allocate_fill (X.Wigner_6j_hats_indices);
    
  Wigner_6j_hats_tab.allocate_fill (X.Wigner_6j_hats_tab);
}





void RDM_T1_Wigner_6j_hats_storage_class::deallocate ()
{  
  Wigner_6j_hats_indices.deallocate ();
  
  Wigner_6j_hats_tab.deallocate ();
}






void RDM_T1_Wigner_6j_hats_storage_class::Wigner_6j_hats_indices_tabs_determine (
										 const enum operation_type operation ,
										 const class nucleons_data &prot_data ,
										 const class nucleons_data &neut_data ,
										 unsigned int &dimension)
{
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
  
  const int Jmax_pair = make_int (2.0*jmax);
  
  const int Jmax_pair_plus_one = Jmax_pair + 1;
  
  const double Jmax_total = Jmax_pair + jmax;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
        
  class array<double> Wigner_6j_subtable(Jmax_pair_plus_one);
  
  for (int ija = 0 ; ija < j_number ; ija++)
    for (int ijb = 0 ; ijb < j_number ; ijb++)
      for (int ijc = 0 ; ijc < j_number ; ijc++)
	{  	
	  const double ja = ija + 0.5;
	  const double jb = ijb + 0.5;
	  const double jc = ijc + 0.5;
	      
	  const int Jmin_ab = abs (ija - ijb);
	      
	  const int Jmax_ab = ija + ijb + 1;
	  
	  const int Jmin_bc_jb_jc = abs (ijb - ijc);
	  
	  const int Jmax_bc_jb_jc = ijb + ijc + 1;
	  
	  for (int iJ = 0 ; iJ < J_total_number ; iJ++)
	    {				
	      const double J = iJ + 0.5;
		      
	      const int Jmin_aJ = abs (ija - iJ);
	      	      
	      const int Jmax_aJ = ija + iJ  + 1;
	  	      
	      const int Jmin_bc = max (Jmin_bc_jb_jc , Jmin_aJ);
	      const int Jmax_bc = min (Jmax_bc_jb_jc , Jmax_aJ);
	      
	      switch (operation)
		{
		case DIMENSIONS_TABLES_CALC:
		  {
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      for (int Jbc = Jmin_bc ; Jbc <= Jmax_bc ; Jbc++)
			Wigner_6j_hats_indices(ija , ijb , ijc , Jab , Jbc , iJ) = dimension++;
			
		  } break;
 
		case TABLES_FILL:
		  {
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {
			if (Jmin_bc <= Jmax_bc) Wigner_signs::Wigner_6j_tab_calc (jc , jb , Jab , ja , J , Wigner_6j_subtable);

			for (int Jbc = Jmin_bc ; Jbc <= Jmax_bc ; Jbc++)
			  {
			    const unsigned int Jbc_index = make_uns_int (Jbc - Jmin_bc);
				
			    Wigner_6j_hats_tab(dimension++) = Wigner_6j_subtable(Jbc_index)*hat (Jab)*hat (Jbc);
			  }
		  
		      } break;

		    default: abort_all ();
		  }
		}
	    }
	}
}




