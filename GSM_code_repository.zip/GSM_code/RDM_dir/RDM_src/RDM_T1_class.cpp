#include "../RDM_include/RDM_include_def.h"

using namespace correlated_state_routines;


RDM_T1_class::RDM_T1_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0) ,
  n_scat_max (0) ,
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_6j_hats_T1_ptr (NULL)
{}




RDM_T1_class::RDM_T1_class (
			    const enum space_type space_pair_c ,
			    const enum particle_type last_particle_c ,
			    const bool truncation_hw_c ,
			    const bool truncation_ph_c ,
			    const int E_max_hw_c ,
			    const int n_scat_max_c , 
			    const class nucleons_data &prot_data ,
			    const class nucleons_data &neut_data ,
			    const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0),
  n_scat_max (0),
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_6j_hats_T1_ptr (NULL)
{
  allocate (space_pair_c , last_particle_c , truncation_hw_c , truncation_ph_c , E_max_hw_c , n_scat_max_c , prot_data , neut_data , Wigner_6j_hats_T1);
}


RDM_T1_class::RDM_T1_class (const class RDM_T1_class &X)
{
  allocate_fill (X);
}

RDM_T1_class::~RDM_T1_class () {}



void RDM_T1_class::allocate (
			     const enum space_type space_pair_c ,
			     const enum particle_type last_particle_c ,
			     const bool truncation_hw_c ,
			     const bool truncation_ph_c ,
			     const int E_max_hw_c ,
			     const int n_scat_max_c , 
			     const class nucleons_data &prot_data ,
			     const class nucleons_data &neut_data ,
			     const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_class cannot be allocated twice in RDM_T1_class::allocate");
  
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
  
  truncation_hw = truncation_hw_c;
  truncation_ph = truncation_ph_c;
			       
  E_max_hw = E_max_hw_c;
  
  n_scat_max = n_scat_max_c;
			       
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;
    
  Wigner_6j_hats_T1_ptr = &Wigner_6j_hats_T1;
    
  switch (space_pair)
    {
    case PROTONS_ONLY:
      {
	if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
	else if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_ppn_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_T1_class::allocate (PROTONS_ONLY)");
	  
      } break;

    case NEUTRONS_ONLY:
      {
	if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
	else if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_nnp_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_T1_class::allocate (NEUTRONS_ONLY)");
	  
      } break;

    default: error_message_print_abort ("The pair space in RDM_T1_class is either protons only or neutrons only in RDM_T1_class::allocate");
    }

  const int J_total_number = matrix_dimensions.dimension (1);
        
  class array<unsigned int> block_matrix_dimensions(2*J_total_number);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);
  
  block_matrix_abcdef.allocate (block_matrix_dimensions);
  
  zero ();
}






void RDM_T1_class::allocate_fill (const class RDM_T1_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_class cannot be allocated twice in RDM_T1_class::allocate_fill");
  
  matrix_dimensions.allocate_fill (X.matrix_dimensions);
  
  three_states_indices.allocate_fill (X.three_states_indices);
  
  BP_table.allocate_fill (X.BP_table);
      
  iJmin_pair_last_particle_tab.allocate_fill (X.iJmin_pair_last_particle_tab);
  iJmax_pair_last_particle_tab.allocate_fill (X.iJmax_pair_last_particle_tab);
  
  alpha_number_same_shell_tab.allocate_fill (X.alpha_number_same_shell_tab);
    
  J_states_components_same_shell.allocate_fill (X.J_states_components_same_shell);

  is_it_in_space_tab.allocate_fill (X.is_it_in_space_tab);
  
  block_matrix_abcdef.allocate_fill (X.block_matrix_abcdef);
  
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
  
  truncation_hw = X.truncation_hw;
  truncation_ph = X.truncation_ph;
  
  E_max_hw = X.E_max_hw;
  
  n_scat_max = X.n_scat_max;
  
  prot_data_ptr = X.prot_data_ptr;
  neut_data_ptr = X.neut_data_ptr;
  
  Wigner_6j_hats_T1_ptr = X.Wigner_6j_hats_T1_ptr;
}





void RDM_T1_class::deallocate ()
{
  matrix_dimensions.deallocate ();
  
  three_states_indices.deallocate ();
      
  BP_table.deallocate ();
  
  iJmin_pair_last_particle_tab.deallocate ();
  iJmax_pair_last_particle_tab.deallocate ();  
  
  alpha_number_same_shell_tab.deallocate ();
    
  J_states_components_same_shell.deallocate ();

  is_it_in_space_tab.deallocate ();
  
  block_matrix_abcdef.deallocate ();
  
  block_matrix_abcdef_eigenvalues.deallocate ();
  
  T_MPI.deallocate ();
  
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
    
  truncation_hw = false;
  truncation_ph = false;
			       
  E_max_hw = 0;
  
  n_scat_max = 0;
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_6j_hats_T1_ptr = NULL;
}


void RDM_T1_class::block_matrix_fill (const class block_matrix<TYPE> &X)
{
  block_matrix_abcdef = X;
}


void RDM_T1_class::operator = (const class RDM_T1_class &X)
{  
  block_matrix_abcdef = X.block_matrix_abcdef;
}

void RDM_T1_class::operator += (const class RDM_T1_class &X)
{
  block_matrix_abcdef += X.block_matrix_abcdef;
}

void RDM_T1_class::operator -= (const class RDM_T1_class &X)
{
  block_matrix_abcdef -= X.block_matrix_abcdef;
}

void RDM_T1_class::add_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcdef.add_scalar_diagonal_part (x);
}

void RDM_T1_class::remove_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcdef.remove_scalar_diagonal_part (x);
}

void RDM_T1_class::operator *= (const TYPE &x)
{
  block_matrix_abcdef *= x;
}

void RDM_T1_class::operator /= (const TYPE &x)
{
  block_matrix_abcdef /= x;
}

unsigned int RDM_T1_class::get_block_symmetric_matrix_elements_number () const
{
  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();

  unsigned int block_symmetric_matrix_elements_number = 0;
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const unsigned int dimension_block = block_matrix_abcdef(i).get_dimension ();
      
      block_symmetric_matrix_elements_number += (dimension_block%2 == 0) ? ((dimension_block/2)*(dimension_block + 1)) : (dimension_block*((dimension_block + 1)/2));
    }
  
  return block_symmetric_matrix_elements_number;
}


double RDM_T1_class::infinite_norm () const
{
  return block_matrix_abcdef.infinite_norm ();
}





// One uses [[ab]^Jab c]^J states. One can have a < b <= c or c < a <= b at this level as [[ab]^Jab c]^J states are antisymmetric.
// Reordering is done afterwards to have a <= b <= c in all cases. |a (bc)^Jbc> states have to be considered, which is handled by an additional phase.
//
// If a = b = c, one diagonalizes the overlaps of |(ab)^Jab c>^J on the shell to have antisymmetric states.
// Eigenvectors of non-zero norm are considered, of the form [abc]^{J,alpha}, where alpha is an index differenting J-coupled states.
// Thus, alpha plays the role of Jab or Jbc in other cases as a = b = c.
// As the number of alpha's is smaller than the number of Jab or Jbc, or equal, one can use the maximal dimensions obtained in other cases as a = b = c to define arrays.
// Hence, alpha is used at the same place as Jab or Jbc in arrays.

void RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc (no nn + p)");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_two_shells = make_int (2.0*jmax);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
    
  const int Jmax_two_shells_over_two_plus_one = Jmax_two_shells_plus_one/2 + 1;
      
  const double Jmax_total = 3.0*jmax;
      
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (N_nlj , N_nlj , N_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_two_shells_plus_one , N_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_two_shells_plus_one , N_nlj);
    
  three_states_indices.allocate (Jmax_two_shells_plus_one , J_total_number , N_nlj , N_nlj , N_nlj);
      
  alpha_number_same_shell_tab.allocate (N_nlj , J_total_number);
    
  J_states_components_same_shell.allocate (N_nlj , J_total_number , Jmax_two_shells_over_two_plus_one , Jmax_two_shells_over_two_plus_one);
      
  is_it_in_space_tab.allocate (N_nlj , N_nlj , N_nlj);
  
  matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();

  is_it_in_space_tab = false;
  
  for (unsigned int s0 = 0 ; s0 < N_nlj ; s0++)
    for (unsigned int s1 = 0 ; s1 < N_nlj ; s1++)
      {
	const class pair_str pair(s0 , s1);

	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (shells_qn , shells_qn);
		
	const unsigned int bp_pair = pair.bp_determine (shells_qn , shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (shells_qn , shells_qn);
	const int Jmax_pair = pair.Jmax_determine (shells_qn , shells_qn);

	const int E_pair_hw = pair.E_hw_determine (shells_qn , shells_qn);

	const int n_scat_pair = pair.n_scat_determine (shells_qn , shells_qn);
				
	for (unsigned int s2 = 0 ; s2 < N_nlj ; s2++)
	  {
	    const class nlj_struct &shell_qn_s2 = shells_qn(s2);

	    const bool frozen_state_s2 = shell_qn_s2.get_frozen_state ();
	    
	    const int l2 = shell_qn_s2.get_l ();
	    
	    const int ij2 = shell_qn_s2.get_ij ();
	  
	    const unsigned int bp_s2 = binary_parity_from_orbital_angular_momentum (l2);
	    	    
	    const int E_hw_s2 = shell_qn_s2.get_e_trunc ();
	    
	    const int n_scat_s2 = (shell_qn_s2.get_S_matrix_pole ()) ? (0) : (1);

	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_s2);

	    const unsigned int BP = binary_parity_product (bp_pair , bp_s2);

	    const int E_hw = E_pair_hw + E_hw_s2;

	    const int n_scat = n_scat_pair + n_scat_s2;

	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(s0 , s1 , s2) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	      
	    BP_table(s0 , s1 , s2) = BP;
	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_pair_s2 = (J_pair <= ij2) ? (ij2 - J_pair) : (J_pair - ij2 - 1);
	
		const int iJmax_pair_s2 = J_pair + ij2;
	    
		iJmin_pair_last_particle_tab(J_pair , s2) = iJmin_pair_s2;
		iJmax_pair_last_particle_tab(J_pair , s2) = iJmax_pair_s2;
	      }
	  }
      }

  BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc ();

  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const bool are_sa_sb_equal = (sa == sb);
	  
	for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	  {
	    if (is_it_in_space_tab(sa , sb , sc))
	      {
		const bool are_sb_sc_equal = (sb == sc);
	  
		const bool same_abc_shells = (are_sa_sb_equal && are_sb_sc_equal);
	  
		if (same_abc_shells) continue;
		  
		const bool is_sb_strictly_smaller_than_sc = (sb < sc);

		const bool is_sc_strictly_smaller_than_sa_equal_sb = (are_sa_sb_equal && (sc < sa));
		  
		if (is_sb_strictly_smaller_than_sc || is_sc_strictly_smaller_than_sa_equal_sb)
		  {	  	      
		    const unsigned int s0 = (is_sb_strictly_smaller_than_sc) ? (sa) : (sc);
		    const unsigned int s1 = (is_sb_strictly_smaller_than_sc) ? (sb) : (sa);
		    const unsigned int s2 = (is_sb_strictly_smaller_than_sc) ? (sc) : (sb);	
	      
		    const class pair_str pair(sa , sb);
	  
		    const unsigned int BP = BP_table(sa , sb , sc);
	  
		    const int Jmin_pair = pair.Jmin_determine (shells_qn , shells_qn);
		    const int Jmax_pair = pair.Jmax_determine (shells_qn , shells_qn);
	  	  
		    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
		      {		      	
			const bool is_J_pair_even = (J_pair%2 == 0);
						  
			if (!are_sa_sb_equal || is_J_pair_even)
			  {
			    const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc);
		      
			    const int J_number = iJmax_abc - iJmin_abc + 1;
		      
			    for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			      {
				const int iJ = iJ0 + iJmin_abc;
			  
				three_states_indices(J_pair , iJ , s0 , s1 , s2) = matrix_dimensions(BP , iJ)++;
			      }}}}}}}
}







void RDM_T1_class::zero ()
{
  block_matrix_abcdef.zero ();
}


void RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc (no nn + p)");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
            
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  alpha_number_same_shell_tab = 0;
  
  J_states_components_same_shell = 0.0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {      
      const unsigned int BP = BP_table(s , s , s);
	  
      const class nlj_struct &shell_qn = shells_qn(s);

      const double j = shell_qn.get_j ();

      const int Jmax_two_shells = make_int (2.0*j);
                  
      const double Jmax = Jmax_two_shells + j;

      const int J_number_max = make_int (Jmax - 0.5) + 1;

      class array<double> Wigner_6j_table(J_number_max);
      
      for (int iJ = 0 ; iJ < J_number_max ; iJ++)
	{
	  const double J = iJ + 0.5;
	  
	  const int Jab_min_no_parity = abs (make_int (J - j));
	  
	  const int Jab_max_J_no_parity = make_int (J + j);
	  
	  const int Jab_max_no_parity = min (Jab_max_J_no_parity , Jmax_two_shells);
	  
	  const int Jab_min = (Jab_min_no_parity%2 == 0) ? (Jab_min_no_parity) : (Jab_min_no_parity + 1);
	  const int Jab_max = (Jab_max_no_parity%2 == 0) ? (Jab_max_no_parity) : (Jab_max_no_parity - 1);

	  if (Jab_max >= Jab_min)
	    {	  
	      const int Jab_min_over_two = Jab_min/2;
	      const int Jab_max_over_two = Jab_max/2;
	  
	      const int Jab_number = Jab_max_over_two - Jab_min_over_two + 1;
      
	      class matrix<double> overlap_nas_matrix(Jab_number);

	      class array<double> overlap_nas_matrix_eigenvalues(Jab_number);
	  
	      for (int Jab_index = 0 ; Jab_index < Jab_number ; Jab_index++)
		{
		  const int Jab = 2*Jab_index + Jab_min;

		  const int Jab_index_Wigner_6j_table = Jab - Jab_min_no_parity;
		  
		  const double hat_Jab = hat (Jab);
	      
		  Wigner_signs::Wigner_6j_tab_calc (j , j , Jab , j , J , Wigner_6j_table);
		  
		  overlap_nas_matrix(Jab_index , Jab_index) = 0.5 + (2*Jab + 1)*Wigner_6j_table(Jab_index_Wigner_6j_table);

		  for (int Jab_prime_index = 0 ; Jab_prime_index < Jab_index ; Jab_prime_index++)
		    {
		      const int Jab_prime = 2*Jab_prime_index + Jab_min;
		      
		      const int Jab_prime_index_Wigner_6j_table = Jab_prime - Jab_min_no_parity;
		      
		      overlap_nas_matrix(Jab_index , Jab_prime_index) = overlap_nas_matrix(Jab_prime_index , Jab_index) = hat_Jab*hat (Jab_prime)*Wigner_6j_table(Jab_prime_index_Wigner_6j_table);
		    }
		}
	  
	      total_diagonalization::all_eigenpairs (overlap_nas_matrix , overlap_nas_matrix_eigenvalues);
	  
	      unsigned int &alpha_index = alpha_number_same_shell_tab(s , iJ);

	      for (int overlap_nas_eigenvalue_index = 0 ; overlap_nas_eigenvalue_index < Jab_number ; overlap_nas_eigenvalue_index++)
		{
		  const double overlap = overlap_nas_matrix_eigenvalues(overlap_nas_eigenvalue_index);
		  
		  if (abs (overlap) > precision)
		    {
		      const double normalization_factor = sqrt (1.0/overlap);
		  
		      const class vector_class<double> &overlap_nas_matrix_eigenvector = overlap_nas_matrix.eigenvector (overlap_nas_eigenvalue_index);
 
		      for (int Jab_over_two = Jab_min_over_two ; Jab_over_two <= Jab_max_over_two ; Jab_over_two++)
			{
			  const int Jab_index = Jab_over_two - Jab_min_over_two;
			  
			  J_states_components_same_shell(s , iJ , alpha_index , Jab_over_two) = overlap_nas_matrix_eigenvector(Jab_index)*normalization_factor;
			}
		      
		      three_states_indices(alpha_index , iJ , s , s , s) = matrix_dimensions(BP , iJ)++;
		      
		      alpha_index++;
		    }
		}
	    }
	}
    }
}









void RDM_T1_class::BP_J_tables_dimensions_indices_ppn_alloc_calc ()
{
  if ((space_pair != PROTONS_ONLY) || (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T1_class::BP_J_tables_dimensions_indices_ppn_alloc_calc");
                
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const int Jmax_pp = make_int (2.0*jp_max);
  
  const int Jmax_pp_plus_one = Jmax_pp + 1;
  
  const double Jmax_total = Jmax_pp + jn_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (Np_nlj , Np_nlj , Nn_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_pp_plus_one , Nn_nlj);
      
  three_states_indices.allocate (Jmax_pp_plus_one , J_total_number , Np_nlj , Np_nlj , Nn_nlj);

  is_it_in_space_tab.allocate (Np_nlj , Np_nlj , Nn_nlj);
  
  matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {
	const class pair_str pair(sa_p , sb_p);
			  
	const unsigned int bp_pair = pair.bp_determine (prot_shells_qn , prot_shells_qn);
	  
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (prot_shells_qn , prot_shells_qn);
	
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , prot_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , prot_shells_qn);
	
	const int E_pair_hw = pair.E_hw_determine (prot_shells_qn , prot_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (prot_shells_qn , prot_shells_qn);
	
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_p , sb_p , sc_n) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    	    
	    BP_table(sa_p , sb_p , sc_n) = BP;
	    	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		    
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
	    
		iJmin_pair_last_particle_tab(J_pair , sc_n) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_n) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
    for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
      {
	const class pair_str pair(sa_p , sb_p);
	  
	const bool are_sa_sb_equal = (sa_p == sb_p);
		  
	const int Jmin_pair = pair.Jmin_determine (prot_shells_qn , prot_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (prot_shells_qn , prot_shells_qn);
	
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {
	    const bool is_J_pair_even = (J_pair%2 == 0);
	    
	    if (!are_sa_sb_equal || is_J_pair_even)
	      {
		for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
		  {
		    if (is_it_in_space_tab(sa_p , sb_p , sc_n))
		      {
			const unsigned int BP = BP_table(sa_p , sb_p , sc_n);	  
	    
			const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_n);	
			const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_n);

			const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
			for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			  {
			    const int iJ = iJ0 + iJmin_abc;
							    
			    three_states_indices(J_pair , iJ , sa_p , sb_p , sc_n) = matrix_dimensions(BP , iJ)++;			    
			  }}}}}}
}
  










void RDM_T1_class::BP_J_tables_dimensions_indices_nnp_alloc_calc ()
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T1_class::BP_J_tables_dimensions_indices_nnp_alloc_calc");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_nn = make_int (2.0*jn_max);
  
  const int Jmax_nn_plus_one = Jmax_nn + 1;
  
  const double Jmax_total = Jmax_nn + jp_max;
  
  const int J_total_number = make_int (Jmax_total + 0.5);
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
                  
  matrix_dimensions.allocate (2 , J_total_number);

  BP_table.allocate (Nn_nlj , Nn_nlj , Np_nlj);  
    
  iJmin_pair_last_particle_tab.allocate (Jmax_nn_plus_one , Np_nlj);
  iJmax_pair_last_particle_tab.allocate (Jmax_nn_plus_one , Np_nlj);
        
  three_states_indices.allocate (Jmax_nn_plus_one , J_total_number , Nn_nlj , Nn_nlj , Np_nlj);

  is_it_in_space_tab.allocate (Nn_nlj , Nn_nlj , Np_nlj);
	    
  matrix_dimensions = 0;
      
  three_states_indices = three_states_indices.dimension_total ();
  
  is_it_in_space_tab = false;
  
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_n , sb_n);
		
	const bool are_there_frozen_states_pair = pair.are_there_frozen_states_determine  (neut_shells_qn , neut_shells_qn);
	
	const unsigned int bp_pair = pair.bp_determine (neut_shells_qn , neut_shells_qn);
	  
	const int Jmin_pair = pair.Jmin_determine (neut_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (neut_shells_qn , neut_shells_qn);
	
	const int E_pair_hw = pair.E_hw_determine (neut_shells_qn , neut_shells_qn);

	const int n_scat_pair = pair.n_scat_determine (neut_shells_qn , neut_shells_qn);
	
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	    
	    const int lc = shell_qn_sc.get_l ();
	    
	    const int ijc = shell_qn_sc.get_ij ();
	  
	    const unsigned int bp_c = binary_parity_from_orbital_angular_momentum (lc);
	    
	    const int E_sc_hw = shell_qn_sc.get_e_trunc ();
	    	    
	    const int n_scat_sc = (shell_qn_sc.get_S_matrix_pole ()) ? (0) : (1);
	    
	    const bool are_there_frozen_states = (are_there_frozen_states_pair || frozen_state_sc);
	    
	    const unsigned int BP = binary_parity_product (bp_pair , bp_c);
	      
	    const int E_hw = E_pair_hw + E_sc_hw;

	    const int n_scat = n_scat_pair + n_scat_sc;
	    
	    const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	    const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));

	    is_it_in_space_tab(sa_n , sb_n , sc_p) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    
	    BP_table(sa_n , sb_n , sc_p) = BP;
	    	    
	    for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	      {		   
		const int iJmin_ab_pair_c = (J_pair <= ijc) ? (ijc - J_pair) : (J_pair - ijc - 1);
  	
		const int iJmax_ab_pair_c = J_pair + ijc;
			    
		iJmin_pair_last_particle_tab(J_pair , sc_p) = iJmin_ab_pair_c;
		iJmax_pair_last_particle_tab(J_pair , sc_p) = iJmax_ab_pair_c;
	      }
	  }
      }
  
  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
    for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
      {
	const class pair_str pair(sa_n , sb_n);
	  
	const bool are_sa_sb_equal = (sa_n == sb_n);
	  
	const int Jmin_pair = pair.Jmin_determine (neut_shells_qn , neut_shells_qn);
	const int Jmax_pair = pair.Jmax_determine (neut_shells_qn , neut_shells_qn);
	  	  
	for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
	  {	      	
	    const bool is_J_pair_even = (J_pair%2 == 0);
	    
	    if (!are_sa_sb_equal || is_J_pair_even)
	      {
		for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
		  {
		    if (is_it_in_space_tab(sa_n , sb_n , sc_p))
		      {
			const unsigned int BP = BP_table(sa_n , sb_n , sc_p);
	  
			const int iJmin_abc = iJmin_pair_last_particle_tab(J_pair , sc_p);	
			const int iJmax_abc = iJmax_pair_last_particle_tab(J_pair , sc_p);

			const int J_number = iJmax_abc - iJmin_abc + 1;
	      	    	  
			for (int iJ0 = 0 ; iJ0 < J_number ; iJ0++)
			  {
			    const int iJ = iJ0 + iJmin_abc;
					  
			    three_states_indices(J_pair , iJ , sa_n , sb_n , sc_p) = matrix_dimensions(BP , iJ)++;
			  }}}}}}
}




TYPE RDM_T1_class::T1_matrix_sc_sf_equal_part_calc (
						    const class array<TYPE> &rho_tab ,
						    const class RDM_PQG_class &Gamma_pp_nn , 
						    const bool sa_sd_jb_je_equal ,
						    const bool sb_se_ja_jd_equal ,
						    const bool sa_se_jb_jd_equal ,
						    const bool sb_sd_ja_je_equal ,
						    const double inv_delta_norm_ab ,
						    const double inv_delta_norm_de ,
						    const double inv_delta_norm_phase_ab ,
						    const unsigned int ab_index ,
						    const int phase_de ,
						    const unsigned int BP_de ,
						    const int Jde ,
						    const unsigned int sa ,
						    const unsigned int sb ,
						    const unsigned int sd ,
						    const unsigned int se)			      
{
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
							
  TYPE T1_matrix_BP_J_ME_part = 0.0;
  
  if (sa_sd_jb_je_equal && sb_se_ja_jd_equal) T1_matrix_BP_J_ME_part += inv_delta_norm_de*inv_delta_norm_ab;
  if (sa_se_jb_jd_equal && sb_sd_ja_je_equal) T1_matrix_BP_J_ME_part += inv_delta_norm_de*inv_delta_norm_phase_ab;
  
  if (sb_se_ja_jd_equal) T1_matrix_BP_J_ME_part -= rho_tab(sa , sd)*inv_delta_norm_de*inv_delta_norm_ab;
  if (sa_se_jb_jd_equal) T1_matrix_BP_J_ME_part -= rho_tab(sb , sd)*inv_delta_norm_de*inv_delta_norm_phase_ab;
  
  if (sa_sd_jb_je_equal) T1_matrix_BP_J_ME_part -= rho_tab(sb , se)*inv_delta_norm_de*inv_delta_norm_ab;
  if (sb_sd_ja_je_equal) T1_matrix_BP_J_ME_part -= rho_tab(sa , se)*inv_delta_norm_de*inv_delta_norm_ab*phase_de;
  
  const unsigned int de_index = two_states_indices(Jde , sd , se);
  
  const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_de + 2*Jde);
  
  const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_matrix(ab_index , de_index);
  
  T1_matrix_BP_J_ME_part += Gamma_pp_nn_ME;

  return T1_matrix_BP_J_ME_part;
}



// sab is sa or sb, sed is se or sd in function names.
// s0 is sa or sb.
// s1 is sb or sa.
// s2 is sd or se.
// s3 is se or sd.


TYPE RDM_T1_class::T1_matrix_ppp_nnn_sab_sf_equal_part_calc (
							     const int iJ ,
							     const class array<TYPE> &rho_tab ,
							     const class RDM_PQG_class &Gamma_pp_nn ,
							     const bool sc_sd_j1_je_equal ,
							     const bool sc_se_j1_jd_equal ,
							     const bool s1_se_jc_jd_equal ,
							     const bool s1_sd_jc_je_equal ,
							     const double inv_delta_norm_ab ,
							     const double inv_delta_norm_ab_over_sc_s1 ,
							     const double inv_delta_norm_de ,
							     const int phase_de ,
							     const unsigned int BP_de ,
							     const int Jab ,
							     const int Jde ,
							     const int ij0 ,
							     const int ij1 ,
							     const int ijc ,
							     const unsigned int s1 ,
							     const unsigned int sc ,
							     const unsigned int sd ,
							     const unsigned int se ,
							     const int phase_sab_sf)
{
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  TYPE T1_matrix_BP_J_ME_part = 0.0;   
			
  const bool s1_se_cd_equal = (s1_se_jc_jd_equal && sc_sd_j1_je_equal);
  const bool s1_sd_ce_equal = (s1_sd_jc_je_equal && sc_se_j1_jd_equal);
  
  const bool is_Jde_even = (Jde%2 == 0);
  
  const bool are_sc_s1_equal = (sc == s1);
  
  const double Wigner_6j_hats_phase_sab_sf = (phase_sab_sf == 1) ? (Wigner_6j_hats_T1(ij0 , ij1 , ijc , Jab , Jde , iJ)) : (-Wigner_6j_hats_T1(ij0 , ij1 , ijc , Jab , Jde , iJ));
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const int Jmin_sc_s1 = Jmin_pair_table(sc , s1);
  const int Jmax_sc_s1 = Jmax_pair_table(sc , s1);

  if (s1_se_cd_equal) T1_matrix_BP_J_ME_part += Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab;
  if (s1_sd_ce_equal) T1_matrix_BP_J_ME_part += Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab;
  
  if (sc_sd_j1_je_equal) T1_matrix_BP_J_ME_part -= rho_tab(s1 , se)*Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab;
  if (sc_se_j1_jd_equal) T1_matrix_BP_J_ME_part -= rho_tab(s1 , sd)*Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab*phase_de;
  
  if (s1_se_jc_jd_equal) T1_matrix_BP_J_ME_part -= rho_tab(sc , sd)*Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab;
  if (s1_sd_jc_je_equal) T1_matrix_BP_J_ME_part -= rho_tab(sc , se)*Wigner_6j_hats_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab*phase_de;				
    
  if ((Jde >= Jmin_sc_s1) && (Jde <= Jmax_sc_s1) && (!are_sc_s1_equal || is_Jde_even))
    {
      const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
      const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
      		      
      const bool is_sc_smaller_than_s1 = (sc <= s1);
					  
      const unsigned int c_s1_index = (is_sc_smaller_than_s1) ? (two_states_indices(Jde , sc , s1)) : (two_states_indices(Jde , s1 , sc));
									  
      const unsigned int de_index = two_states_indices(Jde , sd , se);
					      
      const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_de + 2*Jde);
								    
      const int phase_c_s1 = (is_sc_smaller_than_s1) ? (1) : (((ijc + ij1 + Jde)%2 == 0) ? (1) : (-1));
      
      const TYPE Gamma_pp_nn_ME_phase = (phase_c_s1 == 1) ? (Gamma_pp_nn_matrix(c_s1_index , de_index)) : (-Gamma_pp_nn_matrix(c_s1_index , de_index));
  
      T1_matrix_BP_J_ME_part += Wigner_6j_hats_phase_sab_sf*Gamma_pp_nn_ME_phase*inv_delta_norm_ab_over_sc_s1;
    }
  
  return T1_matrix_BP_J_ME_part;
}


TYPE RDM_T1_class::T1_matrix_ppp_nnn_sc_sde_equal_part_calc (    
							     const int iJ ,
							     const class RDM_PQG_class &Gamma_pp_nn ,
							     const double inv_delta_norm_de ,
							     const double inv_delta_norm_s3_f ,
							     const int phase_sc_sde ,
							     const int Jmin_sf_s3 ,
							     const int Jmax_sf_s3 ,
							     const unsigned int ab_index ,
							     const unsigned int BP_ab ,
							     const int Jab ,
							     const int Jde ,
							     const int ij2 ,
							     const int ij3 ,
							     const int ijf , 
							     const unsigned int s3 ,
							     const unsigned int sf)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_matrix_ppp_nnn_sc_sde_equal_part_calc (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_matrix_ppp_nnn_sc_sde_equal_part_calc (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_matrix_ppp_nnn_sc_sde_equal_part_calc (no nn + p)");
  	
  const bool are_sf_s3_equal = (sf == s3);
  
  const bool is_Jab_even = (Jab%2 == 0);  
  
  if ((Jab >= Jmin_sf_s3) && (Jab <= Jmax_sf_s3) && (!are_sf_s3_equal || is_Jab_even))
    {
      const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
      const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
      const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
      const double Wigner_6j_hats = Wigner_6j_hats_T1(ij2 , ij3 , ijf , Jde , Jab , iJ);
					      						
      const bool is_sf_smaller_than_s3 = (sf <= s3);
					  
      const unsigned int f_s3_index = (is_sf_smaller_than_s3) ? (two_states_indices(Jab , sf , s3)) : (two_states_indices(Jab , s3 , sf));
									  					      
      const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BP_ab + 2*Jab);
								  		
      const int phase_f_s3 = (is_sf_smaller_than_s3) ? (1) : (((ijf + ij3 + Jab)%2 == 0) ? (1) : (-1));
									  
      const TYPE Gamma_pp_nn_ME_phase = (phase_f_s3 == phase_sc_sde) ? (Gamma_pp_nn_matrix(ab_index , f_s3_index)) : (-Gamma_pp_nn_matrix(ab_index , f_s3_index));
									  								    
      const TYPE T1_matrix_BP_J_ME_part = Wigner_6j_hats*Gamma_pp_nn_ME_phase*inv_delta_norm_de/inv_delta_norm_s3_f;

      return T1_matrix_BP_J_ME_part;
    }
  else
    return 0.0;
}





TYPE RDM_T1_class::T1_matrix_sab_sde_equal_part_calc (
						      const int iJ ,
						      const class RDM_PQG_class &Gamma ,
						      const double inv_delta_norm_phase_sab_over_sc_s1 ,
						      const double inv_delta_norm_de ,
						      const double inv_delta_norm_sf_s3 ,
						      const int phase_sde ,
						      const int Jmin_sc_s1 , 
						      const int Jmax_sc_s1 , 
						      const int Jmin_sf_s3 , 
						      const int Jmax_sf_s3 , 
						      const unsigned int BP_sc_s1 ,
						      const int Jab , 
						      const int Jde , 
						      const int ij0 ,
						      const int ij1 ,
						      const int ijc ,
						      const int ij2 ,
						      const int ij3 ,
						      const int ijf ,
						      const bool are_scf_proton_s_neutron ,
						      const bool are_scf_neutron_s_proton ,
						      const unsigned int s1 ,
						      const unsigned int sc ,
						      const unsigned int s3 ,
						      const unsigned int sf)
{
  const int Jmin_pair = max (Jmin_sc_s1 , Jmin_sf_s3);
  const int Jmax_pair = min (Jmax_sc_s1 , Jmax_sf_s3);
  
  if (Jmin_pair > Jmax_pair) return 0.0;
  
  const bool scf_s_same_particle = (!are_scf_proton_s_neutron && !are_scf_neutron_s_proton);
  
  const bool are_sc_s1_equal = (scf_s_same_particle && (sc == s1));
  const bool are_sf_s3_equal = (scf_s_same_particle && (sf == s3));

  const bool sc_s1_different_sf_s3_different = (!are_sc_s1_equal && !are_sf_s3_equal);
  
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  const class array<unsigned int> &two_states_indices = Gamma.get_two_states_indices ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix = Gamma.get_block_matrix ();
  
  const bool is_sc_smaller_than_s1 = is_sa_smaller_than_sb_determine (are_scf_proton_s_neutron , are_scf_neutron_s_proton , sc , s1);
  const bool is_sf_smaller_than_s3 = is_sa_smaller_than_sb_determine (are_scf_proton_s_neutron , are_scf_neutron_s_proton , sf , s3);

  TYPE T1_matrix_BP_J_ME_part = 0.0;
  
  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
    {
      const bool is_J_pair_even = (J_pair%2 == 0);

      if (sc_s1_different_sf_s3_different || is_J_pair_even)
	{
	  const unsigned int sc_s1_index = (is_sc_smaller_than_s1) ? (two_states_indices(J_pair , sc , s1)) : (two_states_indices(J_pair , s1 , sc));
	  const unsigned int sf_s3_index = (is_sf_smaller_than_s3) ? (two_states_indices(J_pair , sf , s3)) : (two_states_indices(J_pair , s3 , sf));
	  
	  const double Wigner_6j_hats_ab = Wigner_6j_hats_T1(ij0 , ij1 , ijc , Jab , J_pair , iJ);
	  const double Wigner_6j_hats_de = Wigner_6j_hats_T1(ij2 , ij3 , ijf , Jde , J_pair , iJ);
	  
	  const int phase_sc_s1 = (is_sc_smaller_than_s1) ? (1) : (((ijc + ij1 + J_pair)%2 == 0) ? (1) : (-1));
	  const int phase_sf_s3 = (is_sf_smaller_than_s3) ? (1) : (((ijf + ij3 + J_pair)%2 == 0) ? (1) : (-1));
	  
	  const int phase_sc_s1_sf_s3 = (phase_sc_s1 == phase_sf_s3) ? (1) : (-1);
	      
	  const class matrix<TYPE> &Gamma_matrix = Gamma_block_matrix(BP_sc_s1 + 2*J_pair);
									  
	  const TYPE Gamma_ME_phase = (phase_sc_s1_sf_s3 == phase_sde) ? (Gamma_matrix(sc_s1_index , sf_s3_index)) : (-Gamma_matrix(sc_s1_index , sf_s3_index));
								    
	  T1_matrix_BP_J_ME_part += Wigner_6j_hats_ab*Wigner_6j_hats_de*Gamma_ME_phase;
	}
    }
  
  T1_matrix_BP_J_ME_part *= inv_delta_norm_phase_sab_over_sc_s1*inv_delta_norm_de/inv_delta_norm_sf_s3;
   
  return T1_matrix_BP_J_ME_part;
}





void RDM_T1_class::T1_ppp_nnn_block_matrices_add (
						  const class array<TYPE> &rho_tab ,
						  const class RDM_PQG_class &Gamma_pp_nn)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_ppp_nnn_block_matrices_add (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_ppp_nnn_block_matrices_add (no pp + n)");      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T1_class::T1_ppp_nnn_block_matrices_add (no nn + p)");
   
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
    
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
              
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
        
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();

  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      {
	class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	      {
		if (!is_it_in_space_tab(sa , sb , sc)) continue;
		      
		const bool are_sa_sb_equal = (sa == sb);
		const bool are_sb_sc_equal = (sb == sc);
		const bool are_sa_sc_equal = (sa == sc);
		  
		const bool same_abc_shells = (are_sa_sb_equal && are_sb_sc_equal);
		  
		const bool is_sb_strictly_smaller_than_sc = (sb < sc);
			  
		const bool is_sc_strictly_smaller_than_sa_equal_sb = (are_sa_sb_equal && (sc < sa));
	    
		if (same_abc_shells || is_sb_strictly_smaller_than_sc || is_sc_strictly_smaller_than_sa_equal_sb)
		  {
		    const unsigned int BP_abc = BP_table(sa , sb , sc);

		    if (BP_abc == BP)
		      {
			const unsigned int alpha_indices_number_abc = (same_abc_shells) ? (alpha_number_same_shell_tab(sa , iJ)) : (1);
			  
			const unsigned int s0 = (is_sb_strictly_smaller_than_sc) ? (sa) : (sc);
			const unsigned int s1 = (is_sb_strictly_smaller_than_sc) ? (sb) : (sa);
			const unsigned int s2 = (is_sb_strictly_smaller_than_sc) ? (sc) : (sb);			  
			  
			const class nlj_struct &shell_qn_sa = shells_qn(sa);
			const class nlj_struct &shell_qn_sb = shells_qn(sb);
			const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  			  
			const int ija = shell_qn_sa.get_ij ();
			const int ijb = shell_qn_sb.get_ij ();
			const int ijc = shell_qn_sc.get_ij ();
		      
			const unsigned int BP_ab = BP_pair_table(sa , sb);
			const unsigned int BP_bc = BP_pair_table(sb , sc);
			const unsigned int BP_ac = BP_pair_table(sa , sc);
			  
			const int Jmin_ab = Jmin_pair_table(sa , sb);
			const int Jmax_ab = Jmax_pair_table(sa , sb);
			  
			const int Jmin_bc = Jmin_pair_table(sb , sc);
			const int Jmax_bc = Jmax_pair_table(sb , sc);			  

			const int Jmin_ac = Jmin_pair_table(sa , sc);
			const int Jmax_ac = Jmax_pair_table(sa , sc);
			
			const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
			const double inv_delta_norm_ac = (are_sa_sc_equal) ? (M_SQRT1_2) : (1.0);
			const double inv_delta_norm_cb = (are_sb_sc_equal) ? (M_SQRT1_2) : (1.0);
			  			  			
			const double inv_delta_norm_ab_over_cb = inv_delta_norm_ab/inv_delta_norm_cb;
			const double inv_delta_norm_ab_over_ac = inv_delta_norm_ab/inv_delta_norm_ac;
			  								    
			for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_indices_number_abc ; alpha_index_abc++)
			  {
			    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
			      {      	
				const bool is_Jab_even = (Jab%2 == 0);
						  
				if (!are_sa_sb_equal || is_Jab_even)
				  {			
				    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
				    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
	      
				    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				      {
					const unsigned int ab_index = two_states_indices(Jab , sa , sb);
			      
					const unsigned int abc_index = (same_abc_shells) ? (three_states_indices(alpha_index_abc , iJ , s0 , s0 , s0)) : (three_states_indices(Jab , iJ , s0 , s1 , s2));
				      
					const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
			      
					const double inv_delta_norm_phase_ab_over_ac = inv_delta_norm_ab_over_ac*phase_ab;
					  
					const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			    
					for (unsigned int se = 0 ; se < N_nlj ; se++)
					  for (unsigned int sd = 0 ; sd <= se ; sd++)
					    for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
					      {  		  
						if (!is_it_in_space_tab(sd , se , sf)) continue;
		  
						const bool are_sd_se_equal = (sd == se);
						const bool are_se_sf_equal = (se == sf);
						const bool are_sd_sf_equal = (sd == sf);
					  
						const bool same_def_shells = (are_sd_se_equal && are_se_sf_equal);
		  
						const bool is_se_strictly_smaller_than_sf = (se < sf);
					      
						const bool is_sf_strictly_smaller_than_sd_equal_se = (are_sd_se_equal && (sf < sd));
		  
						if (same_def_shells || is_se_strictly_smaller_than_sf || is_sf_strictly_smaller_than_sd_equal_se)
						  {
						    const bool sa_sd_equal = (sa == sd) , sb_sd_equal = (sb == sd) , sc_sd_equal = (sc == sd);
						    const bool sa_se_equal = (sa == se) , sb_se_equal = (sb == se) , sc_se_equal = (sc == se);
						    const bool sa_sf_equal = (sa == sf) , sb_sf_equal = (sb == sf) , sc_sf_equal = (sc == sf);
					  
						    if (sa_sd_equal || sb_sd_equal || sc_sd_equal || sa_se_equal || sb_se_equal || sc_se_equal || sa_sf_equal || sb_sf_equal || sc_sf_equal)
						      {						      
							const unsigned int BP_def = BP_table(sd , se , sf);
						      
							if (BP_def == BP)
							  {								      
							    const class nlj_struct &shell_qn_sd = shells_qn(sd);
							    const class nlj_struct &shell_qn_se = shells_qn(se);
							    const class nlj_struct &shell_qn_sf = shells_qn(sf);
			  
							    const int ijd = shell_qn_sd.get_ij ();
							    const int ije = shell_qn_se.get_ij ();
							    const int ijf = shell_qn_sf.get_ij ();
							    
							    const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd) , jc_jd_equal = (ijc == ijd);
							    const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije) , jc_je_equal = (ijc == ije);
							    const bool ja_jf_equal = (ija == ijf) , jb_jf_equal = (ijb == ijf) , jc_jf_equal = (ijc == ijf);
						  
							    const bool sc_sd_jb_je_equal = (sc_sd_equal && jb_je_equal) , sc_se_ja_jd_equal = (sc_se_equal && ja_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
							    const bool sb_se_jc_jd_equal = (sb_se_equal && jc_jd_equal) , sb_sd_jc_je_equal = (sb_sd_equal && jc_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
						      
							    const bool sc_sd_ja_je_equal = (sc_sd_equal && ja_je_equal) , sc_se_jb_jd_equal = (sc_se_equal && jb_jd_equal) , sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal);
							    const bool sa_se_jc_jd_equal = (sa_se_equal && jc_jd_equal) , sa_sd_jc_je_equal = (sa_sd_equal && jc_je_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
							    
							    const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
							    const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
							  
							    const bool be_cd_ja_jf = (sb_se_equal && sc_sd_equal && ja_jf_equal);
							    const bool ce_bd_ja_jf = (sc_se_equal && sb_sd_equal && ja_jf_equal);
							  
							    const bool ae_cd_jb_jf = (sa_se_equal && sc_sd_equal && jb_jf_equal);
							    const bool ce_ad_jb_jf = (sc_se_equal && sa_sd_equal && jb_jf_equal);
						      
							    const unsigned int alpha_indices_number_def = (same_def_shells) ? (alpha_number_same_shell_tab(sd , iJ)) : (1);
			  
							    const unsigned int s0p = (is_se_strictly_smaller_than_sf) ? (sd) : (sf);
							    const unsigned int s1p = (is_se_strictly_smaller_than_sf) ? (se) : (sd);
							    const unsigned int s2p = (is_se_strictly_smaller_than_sf) ? (sf) : (se);
		      		 
							    const unsigned int BP_de = BP_pair_table(sd , se);

							    const bool BP_ab_de_equal = (BP_ab == BP_de);
							  
							    const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
							    const int Jmin_de = Jmin_pair_table(sd , se);
							    const int Jmax_de = Jmax_pair_table(sd , se);		    				    
		      			  
							    const int Jmin_df = Jmin_pair_table(sd , sf);
							    const int Jmax_df = Jmax_pair_table(sd , sf);
							
							    const int Jmin_ef = Jmin_pair_table(se , sf);
							    const int Jmax_ef = Jmax_pair_table(se , sf);
							
							    const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
							    const double inv_delta_norm_ef = (are_se_sf_equal) ? (M_SQRT1_2) : (1.0);
							    const double inv_delta_norm_df = (are_sd_sf_equal) ? (M_SQRT1_2) : (1.0);
						    
							    for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_indices_number_def ; alpha_index_def++)
							      {
								for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
								  {	     	
								    const bool is_Jde_even = (Jde%2 == 0);
						  
								    if (!are_sd_se_equal || is_Jde_even)
								      {	
									const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
									const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
									const int iJmin = max (iJmin_abc , iJmin_def);
									const int iJmax = min (iJmax_abc , iJmax_def);
							    			  
									if ((iJ >= iJmin) && (iJ <= iJmax))
									  {	
									    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  
									    const unsigned int def_index = (same_def_shells) ? (three_states_indices(alpha_index_def , iJ , s0p , s0p , s0p)) : (three_states_indices(Jde , iJ , s0p , s1p , s2p));
								      
									    TYPE T1_matrix_BP_J_ME = 0.0;
									      
									    if (be_cd_ja_jf) T1_matrix_BP_J_ME -= rho_tab(sa , sf)*Wigner_6j_hats_T1(ija , ijb , ijc , Jab , Jde , iJ)*inv_delta_norm_ab*inv_delta_norm_de;
									    if (ce_bd_ja_jf) T1_matrix_BP_J_ME -= rho_tab(sa , sf)*Wigner_6j_hats_T1(ija , ijb , ijc , Jab , Jde , iJ)*inv_delta_norm_ab*inv_delta_norm_de*phase_de;

									    if (ae_cd_jb_jf) T1_matrix_BP_J_ME -= rho_tab(sb , sf)*Wigner_6j_hats_T1(ijb , ija , ijc , Jab , Jde , iJ)*inv_delta_norm_de*inv_delta_norm_phase_ab;
									    if (ce_ad_jb_jf) T1_matrix_BP_J_ME -= rho_tab(sb , sf)*Wigner_6j_hats_T1(ijb , ija , ijc , Jab , Jde , iJ)*inv_delta_norm_de*inv_delta_norm_phase_ab*phase_de;

									    if (Jab == Jde)
									      {
										if (be_ad_jc_jf) T1_matrix_BP_J_ME -= rho_tab(sc , sf)*inv_delta_norm_de*inv_delta_norm_ab;
										if (ae_bd_jc_jf) T1_matrix_BP_J_ME -= rho_tab(sc , sf)*inv_delta_norm_de*inv_delta_norm_phase_ab;

										if (sc_sf_equal_BP_ab_de_equal)
										  T1_matrix_BP_J_ME += T1_matrix_sc_sf_equal_part_calc (rho_tab , Gamma_pp_nn , sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
																	inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
																	ab_index , phase_de , BP_de , Jde , sa , sb , sd , se);
									      }
									  
									    if (sa_sf_equal) T1_matrix_BP_J_ME += T1_matrix_ppp_nnn_sab_sf_equal_part_calc (iJ , rho_tab , Gamma_pp_nn ,
																			    sc_sd_jb_je_equal , sc_se_jb_jd_equal , sb_se_jc_jd_equal , sb_sd_jc_je_equal ,
																			    inv_delta_norm_ab , inv_delta_norm_ab_over_cb , inv_delta_norm_de ,
																			    phase_de , BP_de , Jab , Jde , ija , ijb , ijc , sb , sc , sd , se , 1);
									  
									    if (sb_sf_equal) T1_matrix_BP_J_ME += T1_matrix_ppp_nnn_sab_sf_equal_part_calc (iJ , rho_tab , Gamma_pp_nn ,
																			    sc_sd_ja_je_equal , sc_se_ja_jd_equal , sa_se_jc_jd_equal , sa_sd_jc_je_equal ,
																			    inv_delta_norm_ab , inv_delta_norm_ab_over_ac , inv_delta_norm_de ,
																			    phase_de , BP_de , Jab , Jde , ijb , ija , ijc , sa , sc , sd , se , phase_ab);
									  
									    if (sc_sd_equal) T1_matrix_BP_J_ME += T1_matrix_ppp_nnn_sc_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_de , inv_delta_norm_ef , 1 , Jmin_ef , Jmax_ef , 
																			    ab_index , BP_ab , Jab , Jde , ijd , ije , ijf , se , sf);
								  
									    if (sc_se_equal) T1_matrix_BP_J_ME += T1_matrix_ppp_nnn_sc_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_de , inv_delta_norm_df , phase_de , Jmin_df , Jmax_df ,
																			    ab_index , BP_ab , Jab , Jde , ije , ijd , ijf , sd , sf);
								  
									    if (sa_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_ab_over_cb , inv_delta_norm_de , inv_delta_norm_ef , 1 ,
																		     Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc ,
																		     Jab , Jde , ija , ijb , ijc , ijd , ije , ijf , false , false , sb , sc , se , sf);
								
									    if (sb_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_phase_ab_over_ac , inv_delta_norm_de , inv_delta_norm_ef , 1 ,
																		     Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac ,
																		     Jab , Jde , ijb , ija , ijc , ijd , ije , ijf , false , false , sa , sc , se , sf);
								  
									    if (sa_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_ab_over_cb , inv_delta_norm_de , inv_delta_norm_df , phase_de ,
																		     Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc ,
																		     Jab , Jde , ija , ijb , ijc , ije , ijd , ijf , false , false , sb , sc , sd , sf);
									
									    if (sb_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pp_nn , inv_delta_norm_phase_ab_over_ac , inv_delta_norm_de ,
																		     inv_delta_norm_df , phase_de , Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac ,
																		     Jab , Jde , ijb , ija , ijc , ije , ijd , ijf , false , false , sa , sc , sd , sf);
								  									      
									    if (same_abc_shells) T1_matrix_BP_J_ME *= J_states_components_same_shell(s0  , iJ , alpha_index_abc , Jab/2);
									    if (same_def_shells) T1_matrix_BP_J_ME *= J_states_components_same_shell(s0p , iJ , alpha_index_def , Jde/2);
												  
									    T1_matrix_BP_J(abc_index , def_index) += T1_matrix_BP_J_ME;
						      
									  }}}}}}}}}}}}}}}}
}











void RDM_T1_class::T1_ppn_block_matrices_add (
					      const class array<TYPE> &rho_prot_tab ,
					      const class array<TYPE> &rho_neut_tab ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != PROTONS_ONLY) || (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T1_class::T1_ppn_block_matrices_add");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
            
  const int J_total_number = matrix_dimensions.dimension (1);
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();

  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)      
      {
	class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	  for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {		  
		if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
					      
		const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

		if (BP_abc == BP)
		  {		
		    const bool are_sa_sb_equal = (sa_p == sb_p);
		  
		    const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		    const class nlj_struct &shell_qn_sb_p = prot_shells_qn(sb_p);
		    const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  		
		    const int ija = shell_qn_sa_p.get_ij ();
		    const int ijb = shell_qn_sb_p.get_ij ();
		    const int ijc = shell_qn_sc_n.get_ij ();
		   			  	  		      
		    const unsigned int BP_ab = BP_pp_pair_table(sa_p , sb_p);
		    const unsigned int BP_bc = BP_pn_pair_table(sb_p , sc_n);
		    const unsigned int BP_ac = BP_pn_pair_table(sa_p , sc_n);
			  
		    const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		    const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);
			  
		    const int Jmin_bc = Jmin_pn_pair_table(sb_p , sc_n);
		    const int Jmax_bc = Jmax_pn_pair_table(sb_p , sc_n);
		    
		    const int Jmin_ac = Jmin_pn_pair_table(sa_p , sc_n);
		    const int Jmax_ac = Jmax_pn_pair_table(sa_p , sc_n);		

		    const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
		      					
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {	
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
	      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices_pp(Jab , sa_p , sb_p);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
				  
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
			      
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  
				for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				  for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				    for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				      {			
					if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
		  
					const bool sa_sd_equal = (sa_p == sd_p) , sb_sd_equal = (sb_p == sd_p);
					const bool sa_se_equal = (sa_p == se_p) , sb_se_equal = (sb_p == se_p);
				  
					const bool sc_sf_equal = (sc_n == sf_n);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					    if (BP_def == BP)
					      {								  
						const class nlj_struct &shell_qn_sd_p = prot_shells_qn(sd_p);
						const class nlj_struct &shell_qn_se_p = prot_shells_qn(se_p);
						const class nlj_struct &shell_qn_sf_n = neut_shells_qn(sf_n);
			  
						const int ijd = shell_qn_sd_p.get_ij ();
						const int ije = shell_qn_se_p.get_ij ();
						const int ijf = shell_qn_sf_n.get_ij ();
				      
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
							  
						const bool jc_jf_equal = (ijc == ijf);
						
						const bool are_sd_se_equal = (sd_p == se_p);
							  
						const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					      
						const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
						const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
		      								      
						const unsigned int BP_de = BP_pp_pair_table(sd_p , se_p);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
					      
						const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
						const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
						const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);
					      
						const int Jmin_df = Jmin_pn_pair_table(sd_p , sf_n);
						const int Jmax_df = Jmax_pn_pair_table(sd_p , sf_n);
					      
						const int Jmin_ef = Jmin_pn_pair_table(se_p , sf_n);
						const int Jmax_ef = Jmax_pn_pair_table(se_p , sf_n);		    				    
		      			  
						const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {		     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  									      
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);
			  							      
							    TYPE T1_matrix_BP_J_ME = 0.0;
								  
							    if (Jab == Jde)
							      {								  
								if (be_ad_jc_jf) T1_matrix_BP_J_ME -= rho_neut_tab(sc_n , sf_n)*inv_delta_norm_de*inv_delta_norm_ab;
								if (ae_bd_jc_jf) T1_matrix_BP_J_ME -= rho_neut_tab(sc_n , sf_n)*inv_delta_norm_de*inv_delta_norm_phase_ab;
								  								  
								if (sc_sf_equal_BP_ab_de_equal)
								  T1_matrix_BP_J_ME += T1_matrix_sc_sf_equal_part_calc (rho_prot_tab , Gamma_pp ,
															sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
															inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
															ab_index , phase_de , BP_de , Jde , sa_p , sb_p , sd_p , se_p);
								  
							      }
							      
							    if (sa_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1 ,
																     Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc ,
																     Jab , Jde , ija , ijb , ijc , ijd , ije , ijf , false , true , sb_p , sc_n , se_p , sf_n);
								
							    if (sb_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1 ,
																     Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac ,
																     Jab , Jde , ijb , ija , ijc , ijd , ije , ijf , false , true , sa_p , sc_n , se_p , sf_n);
								
							    if (sa_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_ab , inv_delta_norm_de , 1.0 , phase_de ,
																     Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc ,
																     Jab , Jde , ija , ijb , ijc , ije , ijd , ijf , false , true , sb_p , sc_n , sd_p , sf_n);
						      
							    if (sb_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , phase_de ,
																     Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac ,
																     Jab , Jde , ijb , ija , ijc , ije , ijd , ijf , false , true , sa_p , sc_n , sd_p , sf_n);
							      					  
							    T1_matrix_BP_J(abc_index , def_index) += T1_matrix_BP_J_ME;

							  }}}}}}}}}}}}
}











void RDM_T1_class::T1_nnp_block_matrices_add (
					      const class array<TYPE> &rho_prot_tab ,
					      const class array<TYPE> &rho_neut_tab ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn)
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T1_class::T1_nnp_block_matrices_add");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
            
  const int J_total_number = matrix_dimensions.dimension (1);
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
     
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();

  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)      
      {
	class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {		
		if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

		if (BP_abc == BP)
		  {		
		    const bool are_sa_sb_equal = (sa_n == sb_n);
		  
		    const class nlj_struct &shell_qn_sa_n = neut_shells_qn(sa_n);
		    const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		    const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		    const int ija = shell_qn_sa_n.get_ij ();
		    const int ijb = shell_qn_sb_n.get_ij ();
		    const int ijc = shell_qn_sc_p.get_ij ();
		      
		    const unsigned int BP_ab = BP_nn_pair_table(sa_n , sb_n);
		    const unsigned int BP_bc = BP_pn_pair_table(sc_p , sb_n);
		    const unsigned int BP_ac = BP_pn_pair_table(sc_p , sa_n);
			  
		    const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		    const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);
			  
		    const int Jmin_bc = Jmin_pn_pair_table(sc_p , sb_n);
		    const int Jmax_bc = Jmax_pn_pair_table(sc_p , sb_n);
		    
		    const int Jmin_ac = Jmin_pn_pair_table(sc_p , sa_n);
		    const int Jmax_ac = Jmax_pn_pair_table(sc_p , sa_n);	

		    const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
		      					
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int ab_index = two_states_indices_nn(Jab , sa_n , sb_n);
			      
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			      
				const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
			      			  
				const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
				      
				for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				  for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				    for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				      {
					if (!is_it_in_space_tab(se_n , sd_n , sf_p)) continue;
		  
					const bool sa_sd_equal = (sa_n == sd_n) , sb_sd_equal = (sb_n == sd_n);
					const bool sa_se_equal = (sa_n == se_n) , sb_se_equal = (sb_n == se_n);
				  
					const bool sc_sf_equal = (sc_p == sf_p);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					    if (BP_def == BP)
					      {		
						const class nlj_struct &shell_qn_sd_n = neut_shells_qn(sd_n);
						const class nlj_struct &shell_qn_se_n = neut_shells_qn(se_n);
						const class nlj_struct &shell_qn_sf_p = prot_shells_qn(sf_p);
			  
						const int ijd = shell_qn_sd_n.get_ij ();
						const int ije = shell_qn_se_n.get_ij ();
						const int ijf = shell_qn_sf_p.get_ij ();
					      
						const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
						const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
							  
						const bool jc_jf_equal = (ijc == ijf);
					      
						const bool are_sd_se_equal = (sd_n == se_n);

						const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
						const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					      
						const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
						const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
		      								      
						const unsigned int BP_de = BP_nn_pair_table(sd_n , se_n);

						const bool BP_ab_de_equal = (BP_ab == BP_de);
					      
						const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
						const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
						const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);
		      			  
						const int Jmin_df = Jmin_pn_pair_table(sf_p , sd_n);
						const int Jmax_df = Jmax_pn_pair_table(sf_p , sd_n);
					      
						const int Jmin_ef = Jmin_pn_pair_table(sf_p , se_n);
						const int Jmax_ef = Jmax_pn_pair_table(sf_p , se_n);
					      
						const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
						    
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {			     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {	
							    const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  							      
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
			  							      
							    TYPE T1_matrix_BP_J_ME = 0.0;
							
							    if (Jab == Jde)
							      {
								if (be_ad_jc_jf) T1_matrix_BP_J_ME -= rho_prot_tab(sc_p , sf_p)*inv_delta_norm_de*inv_delta_norm_ab;
								if (ae_bd_jc_jf) T1_matrix_BP_J_ME -= rho_prot_tab(sc_p , sf_p)*inv_delta_norm_de*inv_delta_norm_phase_ab;
	  
								if (sc_sf_equal_BP_ab_de_equal)
								  T1_matrix_BP_J_ME += T1_matrix_sc_sf_equal_part_calc (rho_neut_tab , Gamma_nn , sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
															inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
															ab_index , phase_de , BP_de , Jde , sa_n , sb_n , sd_n , se_n);
							      }
							  
							    if (sa_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1 ,
																     Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc ,
																     Jab , Jde , ija , ijb , ijc , ijd , ije , ijf , true , false , sb_n , sc_p , se_n , sf_p);
								
							    if (sb_sd_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1 ,
																     Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac ,
																     Jab , Jde , ijb , ija , ijc , ijd , ije , ijf , true , false , sa_n , sc_p , se_n , sf_p);
																
							    if (sa_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_ab , inv_delta_norm_de , 1.0 , phase_de ,
																     Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc ,
																     Jab , Jde , ija , ijb , ijc , ije , ijd , ijf , true , false , sb_n , sc_p , sd_n , sf_p);
						      
							    if (sb_se_equal) T1_matrix_BP_J_ME += T1_matrix_sab_sde_equal_part_calc (iJ , Gamma_pn , inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , phase_de ,
																     Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac ,
																     Jab , Jde , ijb , ija , ijc , ije , ijd , ijf , true , false , sa_n , sc_p , sd_n , sf_p);
							  
							    T1_matrix_BP_J(abc_index , def_index) += T1_matrix_BP_J_ME;
							  
							  }}}}}}}}}}}}
}









void RDM_T1_class::precision_T1_ppp_nnn_class_file_calc_print (
							       const int Z ,
							       const int N ,
							       const unsigned int RDM_BP ,
							       const double RDM_J ,
							       const unsigned int RDM_vector_index ,
							       const class RDM_PQG_class &Gamma_pp_nn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T1_class::print_precision_T1_ppp_nnn_class_file_calc_print");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::print_precision_T1_ppp_nnn_class_file_calc_print (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_class::print_precision_T1_ppp_nnn_class_file_calc_print (no pp + n)");  
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON))  error_message_print_abort ("Protons or neutrons only in RDM_T1_class::print_precision_T1_ppp_nnn_class_file_calc_print (no nn + p)");
   
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  if (N_nlj == 0) return;
    
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (T1_RDM_PPP) : (T1_RDM_NNN);
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_two_shells = make_int (2.0*jmax);
  
  const int Jmax_two_shells_plus_one = Jmax_two_shells + 1;
            
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
    
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;
  
  const string ppp_nnn = (space_pair == PROTONS_ONLY) ? ("ppp") : ("nnn");
  
  ifstream infile(infile_name.c_str() , ios::binary);
  
  if (!infile) 
    {
      cout << "No file found for T1[" << ppp_nnn << "] : precision test ignored " << endl;

      return;
    }  
  
  class array<TYPE> T1_ppp_nnn_RDM_array(N_nlj , N_nlj , N_nlj , Jmax_two_shells_plus_one , N_nlj , N_nlj , N_nlj , Jmax_two_shells_plus_one , J_total_number);

  T1_ppp_nnn_RDM_array.read_disk (infile_name);
  
  double T1_ppp_nnn_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	      {
		if (!is_it_in_space_tab(sa , sb , sc)) continue;
		      
		const bool are_sa_sb_equal = (sa == sb);
		const bool are_sb_sc_equal = (sb == sc);
		  
		const bool same_abc_shells = (are_sa_sb_equal && are_sb_sc_equal);
		  
		const bool is_sb_strictly_smaller_than_sc = (sb < sc);
			  
		const bool is_sc_strictly_smaller_than_sa_equal_sb = (are_sa_sb_equal && (sc < sa));
		 		  
		if (same_abc_shells || is_sb_strictly_smaller_than_sc || is_sc_strictly_smaller_than_sa_equal_sb)
		  {		  
		    const unsigned int BP_abc = BP_table(sa , sb , sc);

		    if (BP_abc == BP)
		      {
			const unsigned int alpha_indices_number_abc = (same_abc_shells) ? (alpha_number_same_shell_tab(sa , iJ)) : (1);
			  
			const unsigned int s0 = (is_sb_strictly_smaller_than_sc) ? (sa) : (sc);
			const unsigned int s1 = (is_sb_strictly_smaller_than_sc) ? (sb) : (sa);
			const unsigned int s2 = (is_sb_strictly_smaller_than_sc) ? (sc) : (sb);			  
			  									  
			const int Jmin_ab = Jmin_pair_table(sa , sb);
			const int Jmax_ab = Jmax_pair_table(sa , sb);
			  			
			for (unsigned int se = 0 ; se < N_nlj ; se++)
			  for (unsigned int sd = 0 ; sd <= se ; sd++)
			    for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
			      {  		  
				if (!is_it_in_space_tab(sd , se , sf)) continue;
		  
				const bool are_sd_se_equal = (sd == se);
				const bool are_se_sf_equal = (se == sf);
					  
				const bool same_def_shells = (are_sd_se_equal && are_se_sf_equal);
		  
				const bool is_se_strictly_smaller_than_sf = (se < sf);
					      
				const bool is_sf_strictly_smaller_than_sd_equal_se = (are_sd_se_equal && (sf < sd));
		  
				if (same_def_shells || is_se_strictly_smaller_than_sf || is_sf_strictly_smaller_than_sd_equal_se)
				  {		      
				    const bool sa_sd_equal = (sa == sd) , sb_sd_equal = (sb == sd) , sc_sd_equal = (sc == sd);
				    const bool sa_se_equal = (sa == se) , sb_se_equal = (sb == se) , sc_se_equal = (sc == se);
				    const bool sa_sf_equal = (sa == sf) , sb_sf_equal = (sb == sf) , sc_sf_equal = (sc == sf);
					  
				    if (sa_sd_equal || sb_sd_equal || sc_sd_equal || sa_se_equal || sb_se_equal || sc_se_equal || sa_sf_equal || sb_sf_equal || sc_sf_equal)
				      {					      
					const unsigned int BP_def = BP_table(sd , se , sf);
						      
					if (BP_def == BP)
					  {	
					    const unsigned int alpha_indices_number_def = (same_def_shells) ? (alpha_number_same_shell_tab(sd , iJ)) : (1);
			  
					    const unsigned int s0p = (is_se_strictly_smaller_than_sf) ? (sd) : (sf);
					    const unsigned int s1p = (is_se_strictly_smaller_than_sf) ? (se) : (sd);
					    const unsigned int s2p = (is_se_strictly_smaller_than_sf) ? (sf) : (se);
												      
					    const int Jmin_de = Jmin_pair_table(sd , se);
					    const int Jmax_de = Jmax_pair_table(sd , se);
					      
					    if (same_abc_shells && same_def_shells)
					      {
						for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_indices_number_abc ; alpha_index_abc++)
						  {
						    const unsigned int abc_index = three_states_indices(alpha_index_abc , iJ , s0  , s0  , s0);
									
						    for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_indices_number_def ; alpha_index_def++)
						      {
							const unsigned int def_index = three_states_indices(alpha_index_def , iJ , s0p , s0p , s0p);
								  
							T1_ppp_nnn_precision = max (T1_ppp_nnn_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_ppp_nnn_RDM_array(sa , sb , sc , alpha_index_abc , sd , se , sf , alpha_index_def , iJ)));
						      }}}
							      
					    if (same_abc_shells && !same_def_shells)
					      {					      
						for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_indices_number_abc ; alpha_index_abc++)
						  {
						    const unsigned int abc_index = three_states_indices(alpha_index_abc , iJ , s0  , s0  , s0);
									
						    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						      {	     	
							const bool is_Jde_even = (Jde%2 == 0);
						  
							if (!are_sd_se_equal || is_Jde_even)
							  {
							    const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
							    const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
												    			  
							    if ((iJ >= iJmin_def) && (iJ <= iJmax_def))
							      {
								const unsigned int def_index = three_states_indices(Jde , iJ , s0p , s1p , s2p);
								  
								T1_ppp_nnn_precision = max (T1_ppp_nnn_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_ppp_nnn_RDM_array(sa , sb , sc , alpha_index_abc , sd , se , sf , Jde , iJ)));
							      }}}}}

					    if (!same_abc_shells && same_def_shells)
					      {
						for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
						  {
						    const bool is_Jab_even = (Jab%2 == 0);
						  
						    if (!are_sa_sb_equal || is_Jab_even)
						      {
							const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
							const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
								  
							if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
							  {		
							    const unsigned int abc_index = three_states_indices(Jab , iJ , s0 , s1 , s2);
								      
							    for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_indices_number_def ; alpha_index_def++)
							      {
								const unsigned int def_index = three_states_indices(alpha_index_def , iJ , s0p , s0p , s0p);
							  
								T1_ppp_nnn_precision = max (T1_ppp_nnn_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_ppp_nnn_RDM_array(sa , sb , sc , Jab , sd , se , sf , alpha_index_def , iJ)));
								  									
							      }}}}}							      
					      
					    if (!same_abc_shells && !same_def_shells)
					      {					  
						for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
						  {
						    const bool is_Jab_even = (Jab%2 == 0);
						  
						    if (!are_sa_sb_equal || is_Jab_even)
						      {
							const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
							const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
			    
							if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
							  {					  
							    const unsigned int abc_index = three_states_indices(Jab , iJ , s0 , s1 , s2);

							    for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
							      {	     	
								const bool is_Jde_even = (Jde%2 == 0);
						  
								if (!are_sd_se_equal || is_Jde_even)
								  {
								    const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
								    const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
								    const int iJmin = max (iJmin_abc , iJmin_def);
								    const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
								    if ((iJ >= iJmin) && (iJ <= iJmax))
								      {						  
									const unsigned int def_index = three_states_indices(Jde , iJ , s0p , s1p , s2p);								      

									T1_ppp_nnn_precision = max (T1_ppp_nnn_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_ppp_nnn_RDM_array(sa , sb , sc , Jab , sd , se , sf , Jde , iJ)));
								  
								      }}}}}}}}}}}}}}}

  cout << "T1[" << ppp_nnn << "] precision : " << T1_ppp_nnn_precision << endl;
}











void RDM_T1_class::precision_T1_ppn_class_file_calc_print (
							   const int Z ,
							   const int N ,
							   const unsigned int RDM_BP ,
							   const double RDM_J ,
							   const unsigned int RDM_vector_index ,
							   const class RDM_PQG_class &Gamma_pp) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T1_class::print_precision_T1_ppn_class_file_calc_print");
  
  if ((space_pair != PROTONS_ONLY) || (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T1_class::print_precision_T1_ppn_class_file_calc_print");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();

  if (Zval < 2) return;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
      
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jp_max = prot_data.get_jmax ();
    
  const int Jmax_two_shells_pp = make_int (2.0*jp_max);
  
  const int Jmax_two_shells_pp_plus_one = Jmax_two_shells_pp + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
      
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T1_RDM_PPN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
  
  if (!infile) 
    {
      cout << "No file found for T1[ppn] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T1_ppn_RDM_array(Np_nlj , Np_nlj , Nn_nlj , Jmax_two_shells_pp_plus_one , Np_nlj , Np_nlj , Nn_nlj , Jmax_two_shells_pp_plus_one , J_total_number);  

  T1_ppn_RDM_array.read_disk (infile_name);
  
  double T1_ppn_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	  for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	      {		  
		if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
					      
		const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

		if (BP_abc == BP)
		  {		
		    const bool are_sa_sb_equal = (sa_p == sb_p);
		  			  			  
		    const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		    const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);
			  
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
			  			
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      {
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
			      
				for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				  for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				    for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				      {			
					if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
		  
					const bool sa_sd_equal = (sa_p == sd_p) , sb_sd_equal = (sb_p == sd_p);
					const bool sa_se_equal = (sa_p == se_p) , sb_se_equal = (sb_p == se_p);
				  
					const bool sc_sf_equal = (sc_n == sf_n);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					    if (BP_def == BP)
					      {	
						const bool are_sd_se_equal = (sd_p == se_p);
								
						const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
						const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);
					      
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {						  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);
			  					
							    T1_ppn_precision = max (T1_ppn_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_ppn_RDM_array(sa_p , sb_p , sc_n , Jab , sd_p , se_p , sf_n , Jde , iJ)));
							      
							  }}}}}}}}}}}}
  
  cout << "T1[ppn] precision : " << T1_ppn_precision << endl;
}











void RDM_T1_class::precision_T1_nnp_class_file_calc_print (
							   const int Z ,
							   const int N ,
							   const unsigned int RDM_BP ,
							   const double RDM_J ,
							   const unsigned int RDM_vector_index ,
							   const class RDM_PQG_class &Gamma_nn) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_T1_class::print_precision_T1_nnp_class_file_calc_print");
  
  if ((space_pair != NEUTRONS_ONLY) || (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T1_class::print_precision_T1_nnp_class_file_calc_print");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const int Nval = prot_data.get_N_valence_nucleons ();

  if (Nval < 2) return;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
      
  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_two_shells_nn = make_int (2.0*jn_max);
  
  const int Jmax_two_shells_nn_plus_one = Jmax_two_shells_nn + 1;
  
  const int J_total_number = matrix_dimensions.dimension (1);
           
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
        
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (T1_RDM_NNP);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);
  
  if (!infile) 
    {
      cout << "No file found for T1[nnp] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> T1_nnp_RDM_array(Nn_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_nn_plus_one , Nn_nlj , Nn_nlj , Np_nlj , Jmax_two_shells_nn_plus_one , J_total_number);  

  T1_nnp_RDM_array.read_disk (infile_name);
  
  double T1_nnp_precision = 0.0;
  
  for (int iJ = 0 ; iJ < J_total_number ; iJ++)
    for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
      {
	const class matrix<TYPE> &T1_matrix_BP_J = block_matrix_abcdef(BP + 2*iJ);
  
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	      {		
		if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
				      
		const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

		if (BP_abc == BP)
		  {		
		    const bool are_sa_sb_equal = (sa_n == sb_n);
		  			  	  		    
		    const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		    const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);
				      					
		    for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		      {
			const bool is_Jab_even = (Jab%2 == 0);
						  
			if (!are_sa_sb_equal || is_Jab_even)
			  {			
			    const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			    const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
				     	
			    if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			      { 
				const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			      
				for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				  for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				    for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				      {
					if (!is_it_in_space_tab(se_n , sd_n , sf_p)) continue;
		  
					const bool sa_sd_equal = (sa_n == sd_n) , sb_sd_equal = (sb_n == sd_n);
					const bool sa_se_equal = (sa_n == se_n) , sb_se_equal = (sb_n == se_n);
				  
					const bool sc_sf_equal = (sc_p == sf_p);
					  
					if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					  {
					    const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					    if (BP_def == BP)
					      {		
						const bool are_sd_se_equal = (sd_n == se_n);
								      
						const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
						const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);
		      			  
						for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						  {	     	
						    const bool is_Jde_even = (Jde%2 == 0);
						  
						    if (!are_sd_se_equal || is_Jde_even)
						      {
							const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
							const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
							const int iJmin = max (iJmin_abc , iJmin_def);
							const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
							if ((iJ >= iJmin) && (iJ <= iJmax))
							  {						  
							    const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
			  						
							    T1_nnp_precision = max (T1_nnp_precision , abs (T1_matrix_BP_J(abc_index , def_index) - T1_nnp_RDM_array(sa_n , sb_n , sc_p , Jab , sd_n , se_n , sf_p , Jde , iJ)));

							  }}}}}}}}}}}}
  
  cout << "T1[nnp] precision : " << T1_nnp_precision << endl;
}






void RDM_T1_class::make_it_positive_definite (
					       class block_matrix<TYPE> &P_transpose ,
					       class block_matrix<TYPE> &Dp_P_transpose)
{
  const unsigned int block_matrix_abcdef_dimension = block_matrix_abcdef.get_dimension ();

  if (block_matrix_abcdef_dimension == 0) return;
    
  P_transpose = block_matrix_abcdef;
  
  P_transpose.symmetrize ();

  if (!block_matrix_abcdef_eigenvalues.is_it_filled ()) block_matrix_abcdef_eigenvalues.allocate (block_matrix_abcdef_dimension);
  
  total_diagonalization::all_eigenpairs_Householder (P_transpose , block_matrix_abcdef_eigenvalues);
    
  if (real_dc (block_matrix_abcdef_eigenvalues(0)) >= 0.0) return;

  Dp_P_transpose = P_transpose;
  
  for (unsigned int i = 0 ; i < block_matrix_abcdef_dimension ; i++) Dp_P_transpose.multiply_scalar_row_vector (i , delta_positive_real_part (block_matrix_abcdef_eigenvalues(i)));
  
  class block_matrix<TYPE> &P = P_transpose;

  P.transpose ();

  block_matrix_multiplication (P , Dp_P_transpose , block_matrix_abcdef);
}




#ifdef UseMPI

void RDM_T1_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  if (THIS_PROCESS == Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      T_MPI(index++) = block(ii , jj);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Bcast(send).");
    }
  
  T_MPI.MPI_Bcast (Send_process , MPI_C);
  
  if (THIS_PROCESS != Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Bcast(receive).");
    }
}

void RDM_T1_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Reduce(send).");
    
  T_MPI.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  if (THIS_PROCESS == Recv_process)
    {      
      index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcdef(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Reduce(receive).");
    }
}

void RDM_T1_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Allreduce(send).");
  
  T_MPI.MPI_Allreduce (op , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Allreduce(receive).");
}

void RDM_T1_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcdef.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Allgatherv(send).");
  
  T_MPI.MPI_Allgatherv (group_processes_number , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcdef(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_T1_class::MPI_Allgatherv(receive).");
}

#endif
