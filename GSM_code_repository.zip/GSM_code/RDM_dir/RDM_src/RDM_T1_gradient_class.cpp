#include "../RDM_include/RDM_include_def.h"





RDM_T1_gradient_class::RDM_T1_gradient_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_T1_ptr (NULL) , 
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL) ,
  T1_ptr (NULL) {}




RDM_T1_gradient_class::RDM_T1_gradient_class (
					      const class RDM_T1_class &T1 ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_T1_ptr (NULL) , 
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL) ,
  T1_ptr (NULL)
{
  alloc_calc_store (T1 , prot_data , neut_data , Wigner_6j_hats_T1 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , Gamma_pp , Gamma_nn , Gamma_pn);
}



RDM_T1_gradient_class::RDM_T1_gradient_class (const class RDM_T1_gradient_class &X)
{
  allocate_fill (X);
}

RDM_T1_gradient_class::~RDM_T1_gradient_class () {}



void RDM_T1_gradient_class::alloc_calc_store (
					      const class RDM_T1_class &T1 ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_gradient_class cannot be allocated twice in RDM_T1_gradient_class::allocate");
    
  space_pair = T1.get_space_pair ();

  last_particle = T1.get_last_particle ();
  
  prot_data_ptr = &prot_data;
  neut_data_ptr = &neut_data;
  
  Wigner_6j_hats_T1_ptr = &Wigner_6j_hats_T1;
  
  rho_prot_der_pp_tab_ptr = &rho_prot_der_pp_tab; 
  rho_prot_der_pn_tab_ptr = &rho_prot_der_pn_tab;  
  rho_neut_der_nn_tab_ptr = &rho_neut_der_nn_tab;   
  rho_neut_der_pn_tab_ptr = &rho_neut_der_pn_tab;  
  
  Gamma_pp_ptr = &Gamma_pp;
  Gamma_nn_ptr = &Gamma_nn;
  Gamma_pn_ptr = &Gamma_pn;

  T1_ptr = &T1;
      
  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);

  const unsigned int dimension_pp_BP_J_max = matrix_dimensions_pp.max ();
  const unsigned int dimension_nn_BP_J_max = matrix_dimensions_nn.max ();
  const unsigned int dimension_pn_BP_J_max = matrix_dimensions_pn.max ();
  
  const unsigned int triangular_sup_pp_MEs_number_max = (dimension_pp_BP_J_max%2 == 0) ? ((dimension_pp_BP_J_max/2)*(dimension_pp_BP_J_max + 1)) : (dimension_pp_BP_J_max*((dimension_pp_BP_J_max + 1)/2));
  const unsigned int triangular_sup_nn_MEs_number_max = (dimension_nn_BP_J_max%2 == 0) ? ((dimension_nn_BP_J_max/2)*(dimension_nn_BP_J_max + 1)) : (dimension_nn_BP_J_max*((dimension_nn_BP_J_max + 1)/2));
  const unsigned int triangular_sup_pn_MEs_number_max = (dimension_pn_BP_J_max%2 == 0) ? ((dimension_pn_BP_J_max/2)*(dimension_pn_BP_J_max + 1)) : (dimension_pn_BP_J_max*((dimension_pn_BP_J_max + 1)/2));
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == PROTON))
    {
      T1_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , J_total_number);
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T1_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
      T1_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
      
      T1_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
      
      T1_ppp_nnn_gradient_block_matrices_alloc_calc_store ();
    }
  else if ((space_pair == NEUTRONS_ONLY) && (last_particle == NEUTRON))
    {
      T1_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , J_total_number);
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T1_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
      T1_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
      
      T1_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
      
      T1_ppp_nnn_gradient_block_matrices_alloc_calc_store ();	
    }
  else
    {
      T1_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , J_total_number);
      T1_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , J_total_number);
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , J_total_number);
      
      T1_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
      T1_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
      T1_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);
	
      T1_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
      T1_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
      T1_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;

      T1_ppn_nnp_gradient_block_matrices_alloc_calc_store ();
    }
  
  T1_gradient_block_matrices_non_trivial_zero_numbers_pp.deallocate ();
  T1_gradient_block_matrices_non_trivial_zero_numbers_nn.deallocate ();
  T1_gradient_block_matrices_non_trivial_zero_numbers_pn.deallocate ();
    
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_6j_hats_T1_ptr = NULL;
  
  rho_prot_der_pp_tab_ptr = NULL;
  rho_prot_der_pn_tab_ptr = NULL;
  rho_neut_der_nn_tab_ptr = NULL;
  rho_neut_der_pn_tab_ptr = NULL;
  
  Gamma_pp_ptr = NULL;
  Gamma_nn_ptr = NULL;
  Gamma_pn_ptr = NULL;
}








void RDM_T1_gradient_class::allocate_fill (const class RDM_T1_gradient_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_T1_gradient_class cannot be allocated twice in RDM_T1_gradient_class::allocate_fill");
  
  T1_gradient_block_matrices_pp.allocate_fill_object_elements (X.T1_gradient_block_matrices_pp);
  T1_gradient_block_matrices_nn.allocate_fill_object_elements (X.T1_gradient_block_matrices_nn);
  T1_gradient_block_matrices_pn.allocate_fill_object_elements (X.T1_gradient_block_matrices_pn);
      
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}



void RDM_T1_gradient_class::deallocate ()
{
  T1_gradient_block_matrices_pp.deallocate ();
  T1_gradient_block_matrices_nn.deallocate ();
  T1_gradient_block_matrices_pn.deallocate ();
     
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
}




void RDM_T1_gradient_class::operator = (const class RDM_T1_gradient_class &X)
{
  T1_gradient_block_matrices_pp = X.T1_gradient_block_matrices_pp;
  T1_gradient_block_matrices_nn = X.T1_gradient_block_matrices_nn;
  T1_gradient_block_matrices_pn = X.T1_gradient_block_matrices_pn;
      
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}




void RDM_T1_gradient_class::rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
										    const enum particle_type particle ,
										    const unsigned int BP ,
										    const int iJ ,
										    const unsigned int s0 ,
										    const unsigned int s1)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_pair_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T1_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
      
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {		
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pair_tab(s0 , sp);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pair_tab(s1 , sp);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pair_table(s0 , sp);

      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);

      const int Jmin_s0_sp = Jmin_pair_table(s0 , sp) , Jmin_s1_sp = Jmin_pair_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pair_table(s0 , sp) , Jmax_s1_sp = Jmax_pair_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      const bool are_s0_sp_equal = (s0 == sp);
      const bool are_s1_sp_equal = (s1 == sp);
            
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);
      
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	    }
	}
    }
}


void RDM_T1_gradient_class::rho_term_der_pp_nn_fill_part (
							  const enum particle_type particle ,
							  const unsigned int BP ,
							  const int iJ ,
							  const unsigned int abc_index ,
							  const unsigned int def_index ,
							  const int ij01 ,
							  const unsigned int s0 ,
							  const unsigned int s1 ,
							  const double factor)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data ());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
								     
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<double> &rho_der_tab = (particle == PROTON) ? (get_rho_prot_der_pp_tab ()) : (get_rho_neut_der_nn_tab ());
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_pair_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T1_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
  
  class array<class block_sparse_matrix<TYPE> > &T1_gradient_block_matrices_pp_nn = get_T1_gradient_block_matrices (Gamma_space);
    
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {		    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pair_tab(s0 , sp);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pair_tab(s1 , sp);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pair_table(s0 , sp);

      const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
      const int ij_sp = shell_qn_sp.get_ij ();
      
      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);

      const int Jmin_s0_sp = Jmin_pair_table(s0 , sp) , Jmin_s1_sp = Jmin_pair_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pair_table(s0 , sp) , Jmax_s1_sp = Jmax_pair_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      const bool are_s0_sp_equal = (s0 == sp) , is_s0_smaller_than_sp = (s0 <= sp);
      const bool are_s1_sp_equal = (s1 == sp) , is_s1_smaller_than_sp = (s1 <= sp);
      
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
      
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);
      			
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      const int phase_s0_sp = (is_s0_smaller_than_sp) ? (1) : (((ij01 + ij_sp + Jp)%2 == 0) ? (1) : (-1));
	      const int phase_s1_sp = (is_s1_smaller_than_sp) ? (1) : (((ij01 + ij_sp + Jp)%2 == 0) ? (1) : (-1)); 
	      
	      const double rho_der_ME = rho_der_tab(Jp , s0 , sp , s1);
	      
	      const double gradient_ME = (phase_s0_sp == phase_s1_sp) ? (factor*rho_der_ME) : (-factor*rho_der_ME);
	      
	      class block_sparse_matrix<TYPE> &T1_gradient_block_matrix = T1_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      class sparse_matrix<TYPE> &T1_gradient_matrix = T1_gradient_block_matrix(BP + 2*iJ);
	      
	      unsigned short int &ip_jp_index = T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	      
	      T1_gradient_matrix.get_row_index      (ip_jp_index) = abc_index;
	      T1_gradient_matrix.get_column_index   (ip_jp_index) = def_index;
	      T1_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;
	      
	      ip_jp_index++;
	    }
	}
    }
}


void RDM_T1_gradient_class::rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
										      const unsigned int BP ,
										      const int iJ ,
										      const unsigned int s0_p ,
										      const unsigned int s1_p)
{
  const class nucleons_data &neut_data = get_neut_data ();
    
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  

  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(s1_p , sp_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_pair_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_pair_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	}
    }
}



void RDM_T1_gradient_class::rho_prot_term_der_pn_fill_part (
							    const unsigned int BP ,
							    const int iJ ,
							    const unsigned int abc_index ,
							    const unsigned int def_index ,
							    const unsigned int s0_p ,
							    const unsigned int s1_p ,
							    const double factor)
{
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<double> &rho_prot_der_pn_tab = get_rho_prot_der_pn_tab ();
  
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			 
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(s1_p , sp_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_pair_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_pair_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      	
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_prot_der_pn_tab(Jp , s0_p , sp_n , s1_p);
	  
	  class block_sparse_matrix<TYPE> &T1_gradient_block_matrix_pn = T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &T1_gradient_matrix_pn = T1_gradient_block_matrix_pn(BP + 2*iJ);
      
	  unsigned short int &ip_jp_index = T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
			  
	  T1_gradient_matrix_pn.get_row_index      (ip_jp_index) = abc_index;
	  T1_gradient_matrix_pn.get_column_index   (ip_jp_index) = def_index;
	  T1_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }
}



void RDM_T1_gradient_class::rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
										      const unsigned int BP ,
										      const int iJ ,
										      const unsigned int s0_n ,
										      const unsigned int s1_n)
{
  const class nucleons_data &prot_data = get_prot_data ();
    
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {		
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(sp_p , s1_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_pair_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_pair_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	  
	  T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;
	}
    }
}



void RDM_T1_gradient_class::rho_neut_term_der_pn_fill_part (
							    const unsigned int BP ,
							    const int iJ ,
							    const unsigned int abc_index ,
							    const unsigned int def_index ,
							    const unsigned int s0_n ,
							    const unsigned int s1_n ,
							    const double factor)
{
  const class nucleons_data &prot_data = get_prot_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<bool> &is_it_in_space_pn_pair_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<double> &rho_neut_der_pn_tab = get_rho_neut_der_pn_tab ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			    
      const unsigned int is_it_in_space_pair_s0_sp = is_it_in_space_pn_pair_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_pair_s1_sp = is_it_in_space_pn_pair_tab(sp_p , s1_n);

      if (!is_it_in_space_pair_s0_sp || !is_it_in_space_pair_s1_sp) continue;
      
      const unsigned int BPp = BP_pn_pair_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_pair_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_pair_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_pair_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_pair_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
	  
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_neut_der_pn_tab(Jp , s0_n , sp_p , s1_n);
	      
	  class block_sparse_matrix<TYPE> &T1_gradient_block_matrix_pn = T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &T1_gradient_matrix_pn = T1_gradient_block_matrix_pn(BP + 2*iJ);
	        
	  unsigned short int &ip_jp_index = T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	  
	  T1_gradient_matrix_pn.get_row_index      (ip_jp_index) = abc_index;
	  T1_gradient_matrix_pn.get_column_index   (ip_jp_index) = def_index;
	  T1_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }     
}


void RDM_T1_gradient_class::rho_term_der_part_determine (
							 const enum operation_type operation ,
							 const unsigned int BP ,
							 const int iJ ,
							 const unsigned int abc_index ,
							 const unsigned int def_index ,
							 const enum particle_type particle ,
							 const int ij01 ,
							 const unsigned int s0 , 
							 const unsigned int s1 ,
							 const double factor)
{
  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      {
	rho_term_der_pp_nn_non_trivial_zero_numbers_increments (particle , BP , iJ , s0 , s1);

	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_non_trivial_zero_numbers_increments (BP , iJ , s0 , s1); break;
	  case NEUTRON: rho_neut_term_der_pn_non_trivial_zero_numbers_increments (BP , iJ , s0 , s1); break;

	  default: abort_all ();
	  }
							    
      } break;

    case TABLES_FILL:
      {
	rho_term_der_pp_nn_fill_part (particle , BP , iJ , abc_index , def_index , ij01 , s0 , s1 , factor);
							    
	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_fill_part (BP , iJ , abc_index , def_index , s0 , s1 , factor); break;
	  case NEUTRON: rho_neut_term_der_pn_fill_part (BP , iJ , abc_index , def_index , s0 , s1 , factor); break;
								
	  default: abort_all ();
	  }
							    
      } break;

    default: abort_all ();
    }
}








void RDM_T1_gradient_class::T1_Gamma_term_der_part_determine (
							      const enum operation_type operation ,
							      const enum space_type Gamma_space ,
							      const unsigned int BP ,
							      const int iJ ,
							      const unsigned int abc_index ,
							      const unsigned int def_index ,
							      const unsigned int BPp ,
							      const int Jp ,
							      const unsigned int ip ,
							      const unsigned int jp ,
							      const double gradient_ME)
{	   
  const unsigned int ip_jp_min = min (ip , jp);
  const unsigned int ip_jp_max = max (ip , jp);
	      
  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
  
  class array<unsigned short int> &T1_gradient_block_matrices_non_trivial_zero_numbers_local = get_T1_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
		          
  switch (operation)
    {	    
    case DIMENSIONS_TABLES_CALC:
      {
	T1_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ)++;

      } break;

    case TABLES_FILL:
      {
	class array<class block_sparse_matrix<TYPE> > &T1_gradient_block_matrices_local = get_T1_gradient_block_matrices (Gamma_space);
  
	class block_sparse_matrix<TYPE> &T1_gradient_block_matrix = T1_gradient_block_matrices_local(BPp , Jp , ip_jp_upper_triangular_index);
	  
	class sparse_matrix<TYPE> &T1_gradient_matrix = T1_gradient_block_matrix(BP + 2*iJ);
	  
	unsigned short int &ip_jp_index = T1_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
					
	T1_gradient_matrix.get_row_index      (ip_jp_index) = abc_index;
	T1_gradient_matrix.get_column_index   (ip_jp_index) = def_index;
	T1_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;

	ip_jp_index++;
					    							    
      } break;

    default: abort_all ();
    }
}







void RDM_T1_gradient_class::T1_gradient_block_matrices_sc_sf_equal_part_calc (
									      const enum operation_type operation ,
									      const unsigned int BP ,
									      const int iJ ,
									      const unsigned int abc_index ,
									      const unsigned int def_index , 
									      const bool sa_sd_jb_je_equal ,
									      const bool sb_se_ja_jd_equal ,
									      const bool sa_se_jb_jd_equal ,
									      const bool sb_sd_ja_je_equal ,
									      const double inv_delta_norm_ab ,
									      const double inv_delta_norm_de ,
									      const double inv_delta_norm_phase_ab ,
									      const int phase_de ,
									      const unsigned int BP_de , 
									      const int Jde ,
									      const unsigned int ab_index ,  
									      const int ija ,
									      const int ijb ,
									      const unsigned int sa ,
									      const unsigned int sb ,
									      const unsigned int sd ,
									      const unsigned int se ,
									      const double abcdef_factor)
{
  const enum particle_type particle = (space_pair == PROTONS_ONLY) ? (PROTON) : (NEUTRON);
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const unsigned int de_index = two_states_indices(Jde , sd , se);
  
  const double factor_sb_se_ja_jd_equal = (sb_se_ja_jd_equal) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_ab)       : (NADA);
  const double factor_sa_se_jb_jd_equal = (sa_se_jb_jd_equal) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_phase_ab) : (NADA);
  
  const double factor_sa_sd_jb_je_equal = (sa_sd_jb_je_equal) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_ab)          : (NADA);
  const double factor_sb_sd_ja_je_equal = (sb_sd_ja_je_equal) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_ab*phase_de) : (NADA);
        	
  if (sb_se_ja_jd_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ija , sa , sd , factor_sb_se_ja_jd_equal);
  if (sa_se_jb_jd_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ijb , sb , sd , factor_sa_se_jb_jd_equal);
  if (sa_sd_jb_je_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ijb , sb , se , factor_sa_sd_jb_je_equal);
  if (sb_sd_ja_je_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ija , sa , se , factor_sb_sd_ja_je_equal);
  
  T1_Gamma_term_der_part_determine (operation , space_pair , BP , iJ , abc_index , def_index , BP_de , Jde , ab_index , de_index , abcdef_factor);
}



// sab is sa or sb, sed is se or sd in function names.
// s0 is sa or sb.
// s1 is sb or sa.
// s2 is sd or se.
// s3 is se or sd.



void RDM_T1_gradient_class::T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (
										       const enum operation_type operation , 
										       const unsigned int BP ,
										       const int iJ ,
										       const unsigned int abc_index ,
										       const unsigned int def_index ,
										       const bool sc_sd_j1_je_equal ,
										       const bool sc_se_j1_jd_equal ,
										       const bool s1_se_jc_jd_equal ,
										       const bool s1_sd_jc_je_equal ,
										       const double inv_delta_norm_ab ,
										       const double inv_delta_norm_ab_over_sc_s1 ,
										       const double inv_delta_norm_de ,
										       const int phase_de ,
										       const unsigned int BP_de , 
										       const int Jab ,
										       const int Jde ,
										       const int ij0 ,
										       const int ij1 ,
										       const int ijc ,
										       const unsigned int s1 ,
										       const unsigned int sc ,
										       const unsigned int sd ,
										       const unsigned int se ,
										       const int phase_sab_sf ,
										       const double abcdef_factor)
{   
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (no nn + p)");
  			
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  const bool is_Jde_even = (Jde%2 == 0);
  
  const bool are_sc_s1_equal = (sc == s1);
  
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
    
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();
  
  const int Jmin_sc_s1 = Jmin_pair_table(sc , s1);
  const int Jmax_sc_s1 = Jmax_pair_table(sc , s1);
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
    
  const enum particle_type particle = last_particle;
  
  const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_T1(ij0 , ij1 , ijc , Jab , Jde , iJ)) : (NADA);
  
  const double Wigner_6j_hats_phase_sab_sf = (phase_sab_sf == 1) ? (Wigner_6j_hats) : (-Wigner_6j_hats);
  
  const double Wigner_6j_hats_abcdef_factor_phase_sab_sf = (operation == TABLES_FILL) ? (abcdef_factor*Wigner_6j_hats_phase_sab_sf) : (NADA);
      
  const double factor_sc_sd_j1_je_equal = (sc_sd_j1_je_equal) ? (-Wigner_6j_hats_abcdef_factor_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab)          : (NADA);
  const double factor_sc_se_j1_jd_equal = (sc_se_j1_jd_equal) ? (-Wigner_6j_hats_abcdef_factor_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab*phase_de) : (NADA);
  
  const double factor_s1_se_jc_jd_equal = (s1_se_jc_jd_equal) ? (-Wigner_6j_hats_abcdef_factor_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab)          : (NADA);
  const double factor_s1_sd_jc_je_equal = (s1_sd_jc_je_equal) ? (-Wigner_6j_hats_abcdef_factor_phase_sab_sf*inv_delta_norm_de*inv_delta_norm_ab*phase_de) : (NADA);
        	
  if (sc_sd_j1_je_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ij1 , s1 , se , factor_sc_sd_j1_je_equal);
  if (sc_se_j1_jd_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ij1 , s1 , sd , factor_sc_se_j1_jd_equal);
  if (s1_se_jc_jd_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ijc , sc , sd , factor_s1_se_jc_jd_equal);
  if (s1_sd_jc_je_equal) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , particle , ijc , sc , se , factor_s1_sd_jc_je_equal);
  			
  if ((Jde >= Jmin_sc_s1) && (Jde <= Jmax_sc_s1) && (!are_sc_s1_equal || is_Jde_even))
    {  
      const unsigned int de_index = two_states_indices(Jde , sd , se);

      const bool is_sc_smaller_than_s1 = (sc <= s1);
				
      const unsigned int c_s1_index = (is_sc_smaller_than_s1) ? (two_states_indices(Jde , sc , s1)) : (two_states_indices(Jde , s1 , sc));
      
      const int phase_c_s1 = (is_sc_smaller_than_s1) ? (1) : (((ijc + ij1 + Jde)%2 == 0) ? (1) : (-1));
			
      const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (Wigner_6j_hats_abcdef_factor_phase_sab_sf*inv_delta_norm_ab_over_sc_s1) : (NADA);
      
      const double gradient_ME = (phase_c_s1 == 1) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
        
      T1_Gamma_term_der_part_determine (operation , space_pair , BP , iJ , abc_index , def_index , BP_de , Jde , c_s1_index , de_index , gradient_ME);
    }
}



void RDM_T1_gradient_class::T1_gradient_block_matrices_ppp_nnn_sc_sde_equal_part_calc (
										       const enum operation_type operation ,
										       const unsigned int BP ,
										       const int iJ ,
										       const unsigned int abc_index ,
										       const unsigned int def_index ,
										       const double inv_delta_norm_de ,
										       const double inv_delta_norm_s3_f ,
										       const int phase_sc_sde , 
										       const int Jmin_sf_s3 , 
										       const int Jmax_sf_s3 , 
										       const unsigned int ab_index ,
										       const unsigned int BP_ab ,
										       const int Jab ,
										       const int Jde ,
										       const int ij2 ,
										       const int ij3 ,
										       const int ijf , 
										       const unsigned int s3 ,
										       const unsigned int sf ,
										       const double abcdef_factor)
{			
  const bool are_sf_s3_equal = (sf == s3);
  
  const bool is_Jab_even = (Jab%2 == 0);
  
  if ((Jab >= Jmin_sf_s3) && (Jab <= Jmax_sf_s3) && (!are_sf_s3_equal || is_Jab_even))
    {  
      const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
      const bool is_sf_smaller_than_s3 = (sf <= s3);
  
      const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
      const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();

      const unsigned int f_s3_index = (is_sf_smaller_than_s3) ? (two_states_indices(Jab , sf , s3)) : (two_states_indices(Jab , s3 , sf));

      const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_T1(ij2 , ij3 , ijf , Jde , Jab , iJ)) : (NADA);
        
      const int phase_f_s3 = (is_sf_smaller_than_s3) ? (1) : (((ijf + ij3 + Jab)%2 == 0) ? (1) : (-1));
      
      const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (Wigner_6j_hats*abcdef_factor*inv_delta_norm_de/inv_delta_norm_s3_f) : (NADA);
      
      const double gradient_ME = (phase_f_s3 == phase_sc_sde) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
      
      T1_Gamma_term_der_part_determine (operation , space_pair , BP , iJ , abc_index , def_index , BP_ab , Jab , ab_index , f_s3_index , gradient_ME);
    }
}



void RDM_T1_gradient_class::T1_gradient_block_matrices_sab_sde_equal_part_calc (
										const enum operation_type operation , 
										const enum space_type Gamma_space ,
										const unsigned int BP ,
										const int iJ ,
										const unsigned int abc_index ,
										const unsigned int def_index ,
										const class array<unsigned int> &two_states_indices ,
										const double inv_delta_norm_phase_sab_over_sc_s1 ,
										const double inv_delta_norm_de ,
										const double inv_delta_norm_sf_s3 ,
										const int phase_sde ,
										const int Jmin_sc_s1 , 
										const int Jmax_sc_s1 , 
										const int Jmin_sf_s3 , 
										const int Jmax_sf_s3 , 
										const unsigned int BP_sc_s1 ,
										const int Jab , 
										const int Jde , 
										const int ij0 ,
										const int ij1 ,
										const int ijc ,
										const int ij2 ,
										const int ij3 ,
										const int ijf ,
										const bool are_scf_proton_s_neutron ,
										const bool are_scf_neutron_s_proton ,
										const unsigned int s1 ,
										const unsigned int sc ,
										const unsigned int s3 ,
										const unsigned int sf ,
										const double abcdef_factor)
{	
  const int Jmin_pair = max (Jmin_sc_s1 , Jmin_sf_s3);
  const int Jmax_pair = min (Jmax_sc_s1 , Jmax_sf_s3);
  
  if (Jmin_pair > Jmax_pair) return;
      
  const bool scf_s_same_particle = (!are_scf_proton_s_neutron && !are_scf_neutron_s_proton);
  
  const bool are_sc_s1_equal = (scf_s_same_particle && (sc == s1));
  const bool are_sf_s3_equal = (scf_s_same_particle && (sf == s3));

  const bool sc_s1_different_sf_s3_different = (!are_sc_s1_equal && !are_sf_s3_equal);
  
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  const bool is_sc_smaller_than_s1 = is_sa_smaller_than_sb_determine (are_scf_proton_s_neutron , are_scf_neutron_s_proton , sc , s1);
  const bool is_sf_smaller_than_s3 = is_sa_smaller_than_sb_determine (are_scf_proton_s_neutron , are_scf_neutron_s_proton , sf , s3);
	    
  for (int J_pair = Jmin_pair ; J_pair <= Jmax_pair ; J_pair++)
    {		
      const bool is_J_pair_even = (J_pair%2 == 0);

      if (sc_s1_different_sf_s3_different || is_J_pair_even)
	{			
	  const unsigned int sc_s1_index = (is_sc_smaller_than_s1) ? (two_states_indices(J_pair , sc , s1)) : (two_states_indices(J_pair , s1 , sc));
	  const unsigned int sf_s3_index = (is_sf_smaller_than_s3) ? (two_states_indices(J_pair , sf , s3)) : (two_states_indices(J_pair , s3 , sf));

	  const double Wigner_6j_hats_ab = (operation == TABLES_FILL) ? (Wigner_6j_hats_T1(ij0 , ij1 , ijc , Jab , J_pair , iJ)) : (NADA);
	  const double Wigner_6j_hats_de = (operation == TABLES_FILL) ? (Wigner_6j_hats_T1(ij2 , ij3 , ijf , Jde , J_pair , iJ)) : (NADA);
														  	
	  const int phase_sc_s1 = (is_sc_smaller_than_s1) ? (1) : (((ijc + ij1 + J_pair)%2 == 0) ? (1) : (-1));
	  const int phase_sf_s3 = (is_sf_smaller_than_s3) ? (1) : (((ijf + ij3 + J_pair)%2 == 0) ? (1) : (-1));

	  const int phase_sc_s1_sf_s3 = (phase_sc_s1 == phase_sf_s3) ? (1) : (-1);
	  
	  const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (Wigner_6j_hats_ab*Wigner_6j_hats_de*abcdef_factor*inv_delta_norm_phase_sab_over_sc_s1*inv_delta_norm_de/inv_delta_norm_sf_s3) : (NADA);
	  
	  const double gradient_ME = (phase_sc_s1_sf_s3 == phase_sde) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
	  
	  T1_Gamma_term_der_part_determine (operation , Gamma_space , BP , iJ , abc_index , def_index , BP_sc_s1 , J_pair , sc_s1_index , sf_s3_index , gradient_ME);
	}
    }
}




void RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_calc_store (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_calc_store (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_calc_store (no nn + p)");
   
  const class nucleons_data &particles_data = (last_particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = get_Wigner_6j_hats_T1 ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
              
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
    
  const class array<unsigned int> &BP_pair_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_pair_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_pair_table = Gamma_pp_nn.get_Jmax_table ();

  const class RDM_T1_class &T1 = get_T1 ();
  
  const class array<unsigned int> &BP_table = T1.get_BP_table ();
  
  const class array<unsigned int> &alpha_number_same_shell_tab = T1.get_alpha_number_same_shell_tab ();
  
  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T1.get_three_states_indices ();
    
  const class array<bool> &is_it_in_space_tab = T1.get_is_it_in_space_tab ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T1.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T1.get_iJmax_pair_last_particle_tab ();
	      
  const class array<double> &J_states_components_same_shell = T1.get_J_states_components_same_shell ();
    
  const int J_total_number = matrix_dimensions.dimension (1);
       
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)   
      for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	for (unsigned int sa = 0 ; sa <= sb ; sa++)
	  for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	    {
	      if (!is_it_in_space_tab(sa , sb , sc)) continue;
		  
	      const bool are_sa_sb_equal = (sa == sb);
	      const bool are_sb_sc_equal = (sb == sc);
	      const bool are_sa_sc_equal = (sa == sc);
		  
	      const bool same_abc_shells = (are_sa_sb_equal && are_sb_sc_equal);
		  
	      const bool is_sb_strictly_smaller_than_sc = (sb < sc);
			  
	      const bool is_sc_strictly_smaller_than_sa_equal_sb = (are_sa_sb_equal && (sc < sa));
	    
	      if (same_abc_shells || is_sb_strictly_smaller_than_sc || is_sc_strictly_smaller_than_sa_equal_sb)
		{
		  const unsigned int BP_abc = BP_table(sa , sb , sc);

		  if (BP_abc == BP)
		    {
		      const unsigned int alpha_indices_number_abc = (same_abc_shells) ? (alpha_number_same_shell_tab(sa , iJ)) : (1);
			  
		      const unsigned int s0 = (is_sb_strictly_smaller_than_sc) ? (sa) : (sc);
		      const unsigned int s1 = (is_sb_strictly_smaller_than_sc) ? (sb) : (sa);
		      const unsigned int s2 = (is_sb_strictly_smaller_than_sc) ? (sc) : (sb);			  
			  
		      const class nlj_struct &shell_qn_sa = shells_qn(sa);
		      const class nlj_struct &shell_qn_sb = shells_qn(sb);
		      const class nlj_struct &shell_qn_sc = shells_qn(sc);
		  			  
		      const int ija = shell_qn_sa.get_ij ();
		      const int ijb = shell_qn_sb.get_ij ();
		      const int ijc = shell_qn_sc.get_ij ();
		
		      const unsigned int BP_ab = BP_pair_table(sa , sb);
		      const unsigned int BP_bc = BP_pair_table(sb , sc);
		      const unsigned int BP_ac = BP_pair_table(sa , sc);
			  
		      const int Jmin_ab = Jmin_pair_table(sa , sb);
		      const int Jmax_ab = Jmax_pair_table(sa , sb);
			  
		      const int Jmin_bc = Jmin_pair_table(sb , sc);
		      const int Jmax_bc = Jmax_pair_table(sb , sc);			  

		      const int Jmin_ac = Jmin_pair_table(sa , sc);
		      const int Jmax_ac = Jmax_pair_table(sa , sc);
			
		      const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
		      const double inv_delta_norm_ac = (are_sa_sc_equal) ? (M_SQRT1_2) : (1.0);
		      const double inv_delta_norm_cb = (are_sb_sc_equal) ? (M_SQRT1_2) : (1.0);
			  			    			  			  			  			
		      const double inv_delta_norm_ab_over_cb = inv_delta_norm_ab/inv_delta_norm_cb;
		      const double inv_delta_norm_ab_over_ac = inv_delta_norm_ab/inv_delta_norm_ac;
			  								    
		      for (unsigned int alpha_index_abc = 0 ; alpha_index_abc < alpha_indices_number_abc ; alpha_index_abc++)
			{
			  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
			    {
			      const bool is_Jab_even = (Jab%2 == 0);
						  
			      if (!are_sa_sb_equal || is_Jab_even)
				{
				  const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc);
				  const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc);
	      	
				  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
				    { 
				      const unsigned int ab_index = two_states_indices(Jab , sa , sb);
			      
				      const unsigned int abc_index = (same_abc_shells) ? (three_states_indices(alpha_index_abc , iJ , s0 , s0 , s0)) : (three_states_indices(Jab , iJ , s0 , s1 , s2));
			
				      const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      
				      const double inv_delta_norm_phase_ab_over_ac = inv_delta_norm_ab_over_ac*phase_ab;
			  			  
				      const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;

				      const double abc_factor = (same_abc_shells) ? (J_states_components_same_shell(s0 , iJ , alpha_index_abc , Jab/2)) : (1.0);

				      for (unsigned int se = 0 ; se < N_nlj ; se++)
					for (unsigned int sd = 0 ; sd <= se ; sd++)
					  for (unsigned int sf = 0 ; sf < N_nlj ; sf++)
					    {  		  
					      if (!is_it_in_space_tab(sd , se , sf)) continue;
					      
					      const bool are_sd_se_equal = (sd == se);
					      const bool are_se_sf_equal = (se == sf);
					      const bool are_sd_sf_equal = (sd == sf);
					  
					      const bool same_def_shells = (are_sd_se_equal && are_se_sf_equal);
		  
					      const bool is_se_strictly_smaller_than_sf = (se < sf);
					      
					      const bool is_sf_strictly_smaller_than_sd_equal_se = (are_sd_se_equal && (sf < sd));
		  
					      if (same_def_shells || is_se_strictly_smaller_than_sf || is_sf_strictly_smaller_than_sd_equal_se)
						{
						  const bool sa_sd_equal = (sa == sd) , sb_sd_equal = (sb == sd) , sc_sd_equal = (sc == sd);
						  const bool sa_se_equal = (sa == se) , sb_se_equal = (sb == se) , sc_se_equal = (sc == se);
						  const bool sa_sf_equal = (sa == sf) , sb_sf_equal = (sb == sf) , sc_sf_equal = (sc == sf);
					  
						  if (sa_sd_equal || sb_sd_equal || sc_sd_equal || sa_se_equal || sb_se_equal || sc_se_equal || sa_sf_equal || sb_sf_equal || sc_sf_equal)
						    {																						
						      const unsigned int BP_def = BP_table(sd , se , sf);
						      
						      if (BP_def == BP)
							{								      
							  const class nlj_struct &shell_qn_sd = shells_qn(sd);
							  const class nlj_struct &shell_qn_se = shells_qn(se);
							  const class nlj_struct &shell_qn_sf = shells_qn(sf);
			  
							  const int ijd = shell_qn_sd.get_ij ();
							  const int ije = shell_qn_se.get_ij ();
							  const int ijf = shell_qn_sf.get_ij ();
							  
							  const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd) , jc_jd_equal = (ijc == ijd);
							  const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije) , jc_je_equal = (ijc == ije);
							  const bool ja_jf_equal = (ija == ijf) , jb_jf_equal = (ijb == ijf) , jc_jf_equal = (ijc == ijf);
							  
							  const bool sc_sd_jb_je_equal = (sc_sd_equal && jb_je_equal) , sc_se_ja_jd_equal = (sc_se_equal && ja_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
							  const bool sb_se_jc_jd_equal = (sb_se_equal && jc_jd_equal) , sb_sd_jc_je_equal = (sb_sd_equal && jc_je_equal) , sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal);
						      
							  const bool sc_sd_ja_je_equal = (sc_sd_equal && ja_je_equal) , sc_se_jb_jd_equal = (sc_se_equal && jb_jd_equal) , sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal);
							  const bool sa_se_jc_jd_equal = (sa_se_equal && jc_jd_equal) , sa_sd_jc_je_equal = (sa_sd_equal && jc_je_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
							  										
							  const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
							  const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
							  
							  const bool be_cd_ja_jf = (sb_se_equal && sc_sd_equal && ja_jf_equal);
							  const bool ce_bd_ja_jf = (sc_se_equal && sb_sd_equal && ja_jf_equal);
							  
							  const bool ae_cd_jb_jf = (sa_se_equal && sc_sd_equal && jb_jf_equal);
							  const bool ce_ad_jb_jf = (sc_se_equal && sa_sd_equal && jb_jf_equal);
						      
							  const unsigned int alpha_indices_number_def = (same_def_shells) ? (alpha_number_same_shell_tab(sd , iJ)) : (1);
			  
							  const unsigned int s0p = (is_se_strictly_smaller_than_sf) ? (sd) : (sf);
							  const unsigned int s1p = (is_se_strictly_smaller_than_sf) ? (se) : (sd);
							  const unsigned int s2p = (is_se_strictly_smaller_than_sf) ? (sf) : (se);
							      
							  const unsigned int BP_de = BP_pair_table(sd , se);

							  const bool BP_ab_de_equal = (BP_ab == BP_de);
							  
							  const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
							  const int Jmin_de = Jmin_pair_table(sd , se);
							  const int Jmax_de = Jmax_pair_table(sd , se);		    				    
		      			    
							  const int Jmin_df = Jmin_pair_table(sd , sf);
							  const int Jmax_df = Jmax_pair_table(sd , sf);
							
							  const int Jmin_ef = Jmin_pair_table(se , sf);
							  const int Jmax_ef = Jmax_pair_table(se , sf);
							
							  const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
							  const double inv_delta_norm_ef = (are_se_sf_equal) ? (M_SQRT1_2) : (1.0);
							  const double inv_delta_norm_df = (are_sd_sf_equal) ? (M_SQRT1_2) : (1.0);
						    
							  for (unsigned int alpha_index_def = 0 ; alpha_index_def < alpha_indices_number_def ; alpha_index_def++)
							    {
							      for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
								{	     	
								  const bool is_Jde_even = (Jde%2 == 0);
								
								  if (!are_sd_se_equal || is_Jde_even)
								    {
								      const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf);
								      const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf);
					
								      const int iJmin = max (iJmin_abc , iJmin_def);
								      const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
								      if ((iJ >= iJmin) && (iJ <= iJmax))
									{	
									  const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  									      
									  const unsigned int def_index = (same_def_shells) ? (three_states_indices(alpha_index_def , iJ , s0p , s0p , s0p)) : (three_states_indices(Jde , iJ , s0p , s1p , s2p));

									  const double def_factor = (same_def_shells) ? (J_states_components_same_shell(s0p , iJ , alpha_index_def , Jde/2)) : (1.0);
										
									  const double abcdef_factor = (operation == TABLES_FILL) ? (abc_factor*def_factor) : (NADA);
									  
									  const double factor_be_cd_ja_jf = (be_cd_ja_jf) ? (-abcdef_factor*Wigner_6j_hats_T1(ija , ijb , ijc , Jab , Jde , iJ)*inv_delta_norm_ab*inv_delta_norm_de)          : (NADA);
									  const double factor_ce_bd_ja_jf = (ce_bd_ja_jf) ? (-abcdef_factor*Wigner_6j_hats_T1(ija , ijb , ijc , Jab , Jde , iJ)*inv_delta_norm_ab*inv_delta_norm_de*phase_de) : (NADA);
  
									  const double factor_ae_cd_jb_jf = (ae_cd_jb_jf) ? (-abcdef_factor*Wigner_6j_hats_T1(ijb , ija , ijc , Jab , Jde , iJ)*inv_delta_norm_de*inv_delta_norm_phase_ab)          : (NADA);
									  const double factor_ce_ad_jb_jf = (ce_ad_jb_jf) ? (-abcdef_factor*Wigner_6j_hats_T1(ijb , ija , ijc , Jab , Jde , iJ)*inv_delta_norm_de*inv_delta_norm_phase_ab*phase_de) : (NADA);
							    
									  if (be_cd_ja_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ija , sa , sf , factor_be_cd_ja_jf);
									  if (ce_bd_ja_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ija , sa , sf , factor_ce_bd_ja_jf);
									  if (ae_cd_jb_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijb , sb , sf , factor_ae_cd_jb_jf);
									  if (ce_ad_jb_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijb , sb , sf , factor_ce_ad_jb_jf);
									      
									  if (Jab == Jde)
									    {									    
									      const double factor_be_ad_jc_jf = (be_ad_jc_jf) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_ab)       : (NADA);
									      const double factor_ae_bd_jc_jf = (ae_bd_jc_jf) ? (-abcdef_factor*inv_delta_norm_de*inv_delta_norm_phase_ab) : (NADA);
									    									
									      if (be_ad_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijc , sc , sf , factor_be_ad_jc_jf);
									      if (ae_bd_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , last_particle , ijc , sc , sf , factor_ae_bd_jc_jf);
									      
									      if (sc_sf_equal_BP_ab_de_equal) T1_gradient_block_matrices_sc_sf_equal_part_calc (operation , BP , iJ , abc_index , def_index ,
																				sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
																				inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
																				phase_de , BP_de , Jde , ab_index , ija , ijb , sa , sb , sd , se , abcdef_factor);
									    }
									

									  if (sa_sf_equal) T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (operation , BP , iJ , abc_index , def_index , 
																		      sc_sd_jb_je_equal , sc_se_jb_jd_equal , sb_se_jc_jd_equal , sb_sd_jc_je_equal ,
																		      inv_delta_norm_ab , inv_delta_norm_ab_over_cb , inv_delta_norm_de ,
																		      phase_de , BP_de , Jab , Jde , ija , ijb , ijc , 
																		      sb , sc , sd , se , 1 , abcdef_factor);
									  
									  if (sb_sf_equal) T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (operation , BP , iJ , abc_index , def_index , 
																		      sc_sd_ja_je_equal , sc_se_ja_jd_equal , sa_se_jc_jd_equal , sa_sd_jc_je_equal ,
																		      inv_delta_norm_ab , inv_delta_norm_ab_over_ac , inv_delta_norm_de ,
																		      phase_de , BP_de , Jab , Jde , ijb , ija , ijc , 
																		      sa , sc , sd , se , phase_ab , abcdef_factor);
									  
									  if (sc_sd_equal) T1_gradient_block_matrices_ppp_nnn_sc_sde_equal_part_calc (operation , BP , iJ , abc_index , def_index , 
																		      inv_delta_norm_de , inv_delta_norm_ef , 1 , Jmin_ef , Jmax_ef , ab_index , BP_ab , Jab , Jde ,
																		      ijd , ije , ijf , se , sf , abcdef_factor);
								  
									  if (sc_se_equal) T1_gradient_block_matrices_ppp_nnn_sc_sde_equal_part_calc (operation , BP , iJ , abc_index , def_index , 
																		      inv_delta_norm_de , inv_delta_norm_df , phase_de , Jmin_df , Jmax_df , ab_index , BP_ab , Jab , Jde ,
																		      ije , ijd , ijf , sd , sf , abcdef_factor);
									
									  if (sa_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , BP , iJ , abc_index , def_index , two_states_indices , 
																	       inv_delta_norm_ab_over_cb , inv_delta_norm_de , inv_delta_norm_ef , 1 , 
																	       Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc , Jab , Jde , ija , ijb , ijc , ijd , ije , ijf ,
																	       false , false , sb , sc , se , sf , abcdef_factor);
								
									  if (sb_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , BP , iJ , abc_index , def_index , two_states_indices , 
																	       inv_delta_norm_phase_ab_over_ac , inv_delta_norm_de , inv_delta_norm_ef , 1 ,
																	       Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac , Jab , Jde , ijb , ija , ijc , ijd , ije , ijf ,
																	       false , false , sa , sc , se , sf , abcdef_factor);
								  
									  if (sa_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , BP , iJ , abc_index , def_index , two_states_indices , 
																	       inv_delta_norm_ab_over_cb , inv_delta_norm_de , inv_delta_norm_df , phase_de , 
																	       Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc , Jab , Jde , ija , ijb , ijc , ije , ijd , ijf ,
																	       false , false , sb , sc , sd , sf , abcdef_factor);
									
									  if (sb_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , space_pair , BP , iJ , abc_index , def_index , two_states_indices , 
																	       inv_delta_norm_phase_ab_over_ac , inv_delta_norm_de , inv_delta_norm_df , phase_de ,
																	       Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac , Jab , Jde , ijb , ija , ijc , ije , ijd , ijf ,
																	       false , false , sa , sc , sd , sf , abcdef_factor);
								  								      									
									}}}}}}}}}}}}}}}
} 











void RDM_T1_gradient_class::T1_ppn_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != PROTONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("pp + n space only in RDM_T1_gradient_class::T1_ppn_gradient_block_matrices_calc_store");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
                
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_pp_pair_table = Gamma_pp.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pp_pair_table = Gamma_pp.get_Jmin_table ();
  const class array<int> &Jmax_pp_pair_table = Gamma_pp.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T1_class &T1 = get_T1 ();
  
  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T1.get_three_states_indices ();
    
  const class array<bool> &is_it_in_space_tab = T1.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = T1.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T1.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T1.get_iJmax_pair_last_particle_tab ();
	      
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	for (unsigned int sa_p = 0 ; sa_p <= sb_p ; sa_p++)
	  for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	    {	
	      if (!is_it_in_space_tab(sa_p , sb_p , sc_n)) continue;
		  
	      const unsigned int BP_abc = BP_table(sa_p , sb_p , sc_n);

	      if (BP_abc == BP)
		{		
		  const bool are_sa_sb_equal = (sa_p == sb_p);
		  
		  const class nlj_struct &shell_qn_sa_p = prot_shells_qn(sa_p);
		  const class nlj_struct &shell_qn_sb_p = prot_shells_qn(sb_p);
		  const class nlj_struct &shell_qn_sc_n = neut_shells_qn(sc_n);
		  			  
		  const int ija = shell_qn_sa_p.get_ij ();
		  const int ijb = shell_qn_sb_p.get_ij ();
		  const int ijc = shell_qn_sc_n.get_ij ();
		   			  	  		      
		  const unsigned int BP_ab = BP_pp_pair_table(sa_p , sb_p);
		  const unsigned int BP_bc = BP_pn_pair_table(sb_p , sc_n);
		  const unsigned int BP_ac = BP_pn_pair_table(sa_p , sc_n);
			  
		  const int Jmin_ab = Jmin_pp_pair_table(sa_p , sb_p);
		  const int Jmax_ab = Jmax_pp_pair_table(sa_p , sb_p);
			  
		  const int Jmin_bc = Jmin_pn_pair_table(sb_p , sc_n);
		  const int Jmax_bc = Jmax_pn_pair_table(sb_p , sc_n);
		    
		  const int Jmin_ac = Jmin_pn_pair_table(sa_p , sc_n);
		  const int Jmax_ac = Jmax_pn_pair_table(sa_p , sc_n);			  

		  const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
		    
		  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		    {
		      const bool is_Jab_even = (Jab%2 == 0);
						  
		      if (!are_sa_sb_equal || is_Jab_even)
			{			
			  const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_n);
			  const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_n);
	      
			  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			    { 
			      const unsigned int ab_index = two_states_indices_pp(Jab , sa_p , sb_p);
			      
			      const unsigned int abc_index = three_states_indices(Jab , iJ , sa_p , sb_p , sc_n);
			    
			      const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      			  
			      const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  				      
			      for (unsigned int se_p = 0 ; se_p < Np_nlj ; se_p++)
				for (unsigned int sd_p = 0 ; sd_p <= se_p ; sd_p++)
				  for (unsigned int sf_n = 0 ; sf_n < Nn_nlj ; sf_n++)
				    {		
				      if (!is_it_in_space_tab(sd_p , se_p , sf_n)) continue;
				      
				      const bool sa_sd_equal = (sa_p == sd_p) , sb_sd_equal = (sb_p == sd_p);
				      const bool sa_se_equal = (sa_p == se_p) , sb_se_equal = (sb_p == se_p);
				  
				      const bool sc_sf_equal = (sc_n == sf_n);
					  
				      if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					{
					  const unsigned int BP_def = BP_table(sd_p , se_p , sf_n);
					      
					  if (BP_def == BP)
					    {	
					      const class nlj_struct &shell_qn_sd_p = prot_shells_qn(sd_p);
					      const class nlj_struct &shell_qn_se_p = prot_shells_qn(se_p);
					      const class nlj_struct &shell_qn_sf_n = neut_shells_qn(sf_n);
			  
					      const int ijd = shell_qn_sd_p.get_ij ();
					      const int ije = shell_qn_se_p.get_ij ();
					      const int ijf = shell_qn_sf_n.get_ij ();
					      
					      const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
					      const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
					      
					      const bool are_sd_se_equal = (sd_p == se_p);
							  
					      const bool jc_jf_equal = (ijc == ijf);
							  
					      const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
					      const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					      
					      const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
					      const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
					      		      		 
					      const unsigned int BP_de = BP_pp_pair_table(sd_p , se_p);

					      const bool BP_ab_de_equal = (BP_ab == BP_de);
					      
					      const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
					      const int Jmin_de = Jmin_pp_pair_table(sd_p , se_p);
					      const int Jmax_de = Jmax_pp_pair_table(sd_p , se_p);
		      			  
					      const int Jmin_df = Jmin_pn_pair_table(sd_p , sf_n);
					      const int Jmax_df = Jmax_pn_pair_table(sd_p , sf_n);
					      
					      const int Jmin_ef = Jmin_pn_pair_table(se_p , sf_n);
					      const int Jmax_ef = Jmax_pn_pair_table(se_p , sf_n);
					      
					      const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
					    
					      for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						{	     	
						  const bool is_Jde_even = (Jde%2 == 0);
						
						  if (!are_sd_se_equal || is_Jde_even)
						    {
						      const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_n);
						      const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_n);
					
						      const int iJmin = max (iJmin_abc , iJmin_def);
						      const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						      if ((iJ >= iJmin) && (iJ <= iJmax))
							{	
							  const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  									      
							  const unsigned int def_index = three_states_indices(Jde , iJ , sd_p , se_p , sf_n);
								 
							  if (Jab == Jde)
							    {	
							      const double factor_be_ad_jc_jf = (be_ad_jc_jf) ? (-inv_delta_norm_de*inv_delta_norm_ab)       : (NADA);
							      const double factor_ae_bd_jc_jf = (ae_bd_jc_jf) ? (-inv_delta_norm_de*inv_delta_norm_phase_ab) : (NADA);
									      							
							      if (be_ad_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , NEUTRON , ijc , sc_n , sf_n , factor_be_ad_jc_jf);
							      if (ae_bd_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , NEUTRON , ijc , sc_n , sf_n , factor_ae_bd_jc_jf);
								
							      if (sc_sf_equal_BP_ab_de_equal)
								T1_gradient_block_matrices_sc_sf_equal_part_calc (operation , BP , iJ , abc_index , def_index ,
														  sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
														  inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
														  phase_de , BP_de , Jde , ab_index , ija , ijb , sa_p , sb_p , sd_p , se_p , 1.0);
							    }
							    
							  if (sa_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1 ,
															       Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc , Jab , Jde , ija , ijb , ijc , ijd , ije , ijf ,
															       false , true , sb_p , sc_n , se_p , sf_n , 1.0);
								
							  if (sb_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1 , 
															       Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac , Jab , Jde , ijb , ija , ijc , ijd , ije , ijf ,
															       false , true , sa_p , sc_n , se_p , sf_n , 1.0);
							
							  if (sa_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_ab , inv_delta_norm_de , 1.0 , phase_de , 
															       Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc , Jab , Jde , ija , ijb , ijc , ije , ijd , ijf ,
															       false , true , sb_p , sc_n , sd_p , sf_n , 1.0);
						      	
							  if (sb_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , phase_de , 
															       Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac , Jab , Jde , ijb , ija , ijc , ije , ijd , ijf ,
															       false , true , sa_p , sc_n , sd_p , sf_n , 1.0);
							}}}}}}}}}}}
}











void RDM_T1_gradient_class::T1_nnp_gradient_block_matrices_calc_store (const enum operation_type operation)
{
  if ((space_pair != NEUTRONS_ONLY) && (last_particle != PROTON)) error_message_print_abort ("nn + p space only in RDM_T1_gradient_class::T1_nnp_gradient_block_matrices_calc_store");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
      
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
              
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_nn_pair_table = Gamma_nn.get_BP_table ();
  const class array<unsigned int> &BP_pn_pair_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_nn_pair_table = Gamma_nn.get_Jmin_table ();
  const class array<int> &Jmax_nn_pair_table = Gamma_nn.get_Jmax_table ();
  
  const class array<int> &Jmin_pn_pair_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_pair_table = Gamma_pn.get_Jmax_table ();
  
  const class RDM_T1_class &T1 = get_T1 ();
    
  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const class array<unsigned int> &three_states_indices = T1.get_three_states_indices ();
    
  const class array<bool> &is_it_in_space_tab = T1.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = T1.get_BP_table ();
  
  const class array<int> &iJmin_pair_last_particle_tab = T1.get_iJmin_pair_last_particle_tab ();
  const class array<int> &iJmax_pair_last_particle_tab = T1.get_iJmax_pair_last_particle_tab ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)       
      for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	for (unsigned int sa_n = 0 ; sa_n <= sb_n ; sa_n++)
	  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	    {		
	      if (!is_it_in_space_tab(sa_n , sb_n , sc_p)) continue;
		  
	      const unsigned int BP_abc = BP_table(sa_n , sb_n , sc_p);

	      if (BP_abc == BP)
		{		
		  const bool are_sa_sb_equal = (sa_n == sb_n);
		  
		  const class nlj_struct &shell_qn_sa_n = neut_shells_qn(sa_n);
		  const class nlj_struct &shell_qn_sb_n = neut_shells_qn(sb_n);
		  const class nlj_struct &shell_qn_sc_p = prot_shells_qn(sc_p);
		  			  
		  const int ija = shell_qn_sa_n.get_ij ();
		  const int ijb = shell_qn_sb_n.get_ij ();
		  const int ijc = shell_qn_sc_p.get_ij ();

		  const unsigned int BP_ab = BP_nn_pair_table(sa_n , sb_n);
		  const unsigned int BP_bc = BP_pn_pair_table(sc_p , sb_n);
		  const unsigned int BP_ac = BP_pn_pair_table(sc_p , sa_n);
			  
		  const int Jmin_ab = Jmin_nn_pair_table(sa_n , sb_n);
		  const int Jmax_ab = Jmax_nn_pair_table(sa_n , sb_n);
			  
		  const int Jmin_bc = Jmin_pn_pair_table(sc_p , sb_n);
		  const int Jmax_bc = Jmax_pn_pair_table(sc_p , sb_n);
		    
		  const int Jmin_ac = Jmin_pn_pair_table(sc_p , sa_n);
		  const int Jmax_ac = Jmax_pn_pair_table(sc_p , sa_n);			  

		  const double inv_delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT1_2) : (1.0);
		    
		  for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
		    {
		      const bool is_Jab_even = (Jab%2 == 0);
						  
		      if (!are_sa_sb_equal || is_Jab_even)
			{
			  const int iJmin_abc = iJmin_pair_last_particle_tab(Jab , sc_p);
			  const int iJmax_abc = iJmax_pair_last_particle_tab(Jab , sc_p);
	      
			  if ((iJ >= iJmin_abc) && (iJ <= iJmax_abc))
			    { 
			      const unsigned int ab_index = two_states_indices_nn(Jab , sa_n , sb_n);
			      
			      const unsigned int abc_index = three_states_indices(Jab , iJ , sa_n , sb_n , sc_p);
			    
			      const int phase_ab = ((ija + ijb + Jab)%2 == 0) ? (1) : (-1);
		      			      			  
			      const double inv_delta_norm_phase_ab = inv_delta_norm_ab*phase_ab;
			  				      
			      for (unsigned int se_n = 0 ; se_n < Nn_nlj ; se_n++)
				for (unsigned int sd_n = 0 ; sd_n <= se_n ; sd_n++)
				  for (unsigned int sf_p = 0 ; sf_p < Np_nlj ; sf_p++)
				    {
				      if (!is_it_in_space_tab(se_n , sd_n , sf_p)) continue;
				      
				      const bool sa_sd_equal = (sa_n == sd_n) , sb_sd_equal = (sb_n == sd_n);
				      const bool sa_se_equal = (sa_n == se_n) , sb_se_equal = (sb_n == se_n);
				  
				      const bool sc_sf_equal = (sc_p == sf_p);
					  
				      if (sa_sd_equal || sa_se_equal || sb_sd_equal || sb_se_equal || sc_sf_equal)
					{
					  const unsigned int BP_def = BP_table(sd_n , se_n , sf_p);
					      
					  if (BP_def == BP)
					    {					      					      
					      const class nlj_struct &shell_qn_sd_n = neut_shells_qn(sd_n);
					      const class nlj_struct &shell_qn_se_n = neut_shells_qn(se_n);
					      const class nlj_struct &shell_qn_sf_p = prot_shells_qn(sf_p);
			  
					      const int ijd = shell_qn_sd_n.get_ij ();
					      const int ije = shell_qn_se_n.get_ij ();
					      const int ijf = shell_qn_sf_p.get_ij ();
					      
					      const bool ja_jd_equal = (ija == ijd) , jb_jd_equal = (ijb == ijd);
					      const bool ja_je_equal = (ija == ije) , jb_je_equal = (ijb == ije);
							  
					      const bool jc_jf_equal = (ijc == ijf);
					      
					      const bool are_sd_se_equal = (sd_n == se_n);

					      const bool sb_se_ja_jd_equal = (sb_se_equal && ja_jd_equal) , sb_sd_ja_je_equal = (sb_sd_equal && ja_je_equal);
					      const bool sa_se_jb_jd_equal = (sa_se_equal && jb_jd_equal) , sa_sd_jb_je_equal = (sa_sd_equal && jb_je_equal);
					      
					      const bool be_ad_jc_jf = (sb_se_equal && sa_sd_equal && jc_jf_equal);
					      const bool ae_bd_jc_jf = (sa_se_equal && sb_sd_equal && jc_jf_equal);
		      								      
					      const unsigned int BP_de = BP_nn_pair_table(sd_n , se_n);

					      const bool BP_ab_de_equal = (BP_ab == BP_de);
					      
					      const bool sc_sf_equal_BP_ab_de_equal = (sc_sf_equal && BP_ab_de_equal);
									      
					      const int Jmin_de = Jmin_nn_pair_table(sd_n , se_n);
					      const int Jmax_de = Jmax_nn_pair_table(sd_n , se_n);	
		      			  
					      const int Jmin_df = Jmin_pn_pair_table(sf_p , sd_n);
					      const int Jmax_df = Jmax_pn_pair_table(sf_p , sd_n);
					      
					      const int Jmin_ef = Jmin_pn_pair_table(sf_p , se_n);
					      const int Jmax_ef = Jmax_pn_pair_table(sf_p , se_n);
					      
					      const double inv_delta_norm_de = (are_sd_se_equal) ? (M_SQRT1_2) : (1.0);
						    
					      for (int Jde = Jmin_de ; Jde <= Jmax_de ; Jde++)
						{	     	
						  const bool is_Jde_even = (Jde%2 == 0);
						
						  if (!are_sd_se_equal || is_Jde_even)
						    {
						      const int iJmin_def = iJmin_pair_last_particle_tab(Jde , sf_p);
						      const int iJmax_def = iJmax_pair_last_particle_tab(Jde , sf_p);
					
						      const int iJmin = max (iJmin_abc , iJmin_def);
						      const int iJmax = min (iJmax_abc , iJmax_def);	
							    			  
						      if ((iJ >= iJmin) && (iJ <= iJmax))
							{	
							  const int phase_de = ((ijd + ije + Jde)%2 == 0) ? (1) : (-1);
					  									      
							  const unsigned int def_index = three_states_indices(Jde , iJ , sd_n , se_n , sf_p);
							
							  if (Jab == Jde)
							    {			
							      const double factor_be_ad_jc_jf = (be_ad_jc_jf) ? (-inv_delta_norm_de*inv_delta_norm_ab)       : (NADA);
							      const double factor_ae_bd_jc_jf = (ae_bd_jc_jf) ? (-inv_delta_norm_de*inv_delta_norm_phase_ab) : (NADA);
							    
							      if (be_ad_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , PROTON , ijc , sc_p , sf_p , factor_be_ad_jc_jf);
							      if (ae_bd_jc_jf) rho_term_der_part_determine (operation , BP , iJ , abc_index , def_index , PROTON , ijc , sc_p , sf_p , factor_ae_bd_jc_jf);
							      							    
							      if (sc_sf_equal_BP_ab_de_equal) T1_gradient_block_matrices_sc_sf_equal_part_calc (operation , BP , iJ , abc_index , def_index ,
																		sa_sd_jb_je_equal , sb_se_ja_jd_equal , sa_se_jb_jd_equal , sb_sd_ja_je_equal ,
																		inv_delta_norm_ab , inv_delta_norm_de , inv_delta_norm_phase_ab ,
																		phase_de , BP_de , Jde , ab_index , ija , ijb , sa_n , sb_n , sd_n , se_n , 1.0);
							    }
							
							  if (sa_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_ab , inv_delta_norm_de , 1.0 , 1 ,
															       Jmin_bc , Jmax_bc , Jmin_ef , Jmax_ef , BP_bc , Jab , Jde , ija , ijb , ijc , ijd , ije , ijf ,
															       true , false , sb_n , sc_p , se_n , sf_p , 1.0);
								
							  if (sb_sd_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , 1 , 
															       Jmin_ac , Jmax_ac , Jmin_ef , Jmax_ef , BP_ac , Jab , Jde , ijb , ija , ijc , ijd , ije , ijf ,
															       true , false , sa_n , sc_p , se_n , sf_p , 1.0);
																
							  if (sa_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_ab , inv_delta_norm_de , 1.0 , phase_de , 
															       Jmin_bc , Jmax_bc , Jmin_df , Jmax_df , BP_bc , Jab , Jde , ija , ijb , ijc , ije , ijd , ijf ,
															       true , false , sb_n , sc_p , sd_n , sf_p , 1.0);
						      
							  if (sb_se_equal) T1_gradient_block_matrices_sab_sde_equal_part_calc (operation , PROTONS_NEUTRONS , BP , iJ , abc_index , def_index , two_states_indices_pn , 
															       inv_delta_norm_phase_ab , inv_delta_norm_de , 1.0 , phase_de , 
															       Jmin_ac , Jmax_ac , Jmin_df , Jmax_df , BP_ac , Jab , Jde , ijb , ija , ijc , ije , ijd , ijf ,
															       true , false , sa_n , sc_p , sd_n , sf_p , 1.0);
							}}}}}}}}}}}
}














void RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_alloc_calc_store ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_alloc_calc_store (no pn pair)");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_alloc_calc_store (no pp + n)");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Protons or neutrons only in RDM_T1_gradient_class::T1_ppp_nnn_gradient_block_matrices_alloc_calc_store (no nn + p)");
  
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
    
  const class array<unsigned int> &matrix_dimensions_pp_nn = Gamma_pp_nn.get_matrix_dimensions ();
  
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();

  const class RDM_T1_class &T1 = get_T1 ();

  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  const int Jmax_pp_nn_total_plus_one = matrix_dimensions_pp_nn.dimension (1);
  
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);

  class array<unsigned short int> &T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_T1_gradient_block_matrices_non_trivial_zero_numbers (space_pair);
  
  class array<class block_sparse_matrix<TYPE> > &T1_gradient_block_matrices_pp_nn = get_T1_gradient_block_matrices (space_pair);
 
  T1_ppp_nnn_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
	      
  class array<unsigned int> T1_block_matrix_dimensions(2*J_total_number);
    
  class array<unsigned int> T1_block_matrix_non_trivial_zero_numbers(2*J_total_number);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      T1_block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);
		  	      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);
	      
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      	
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T1_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	    	      
	      const unsigned int non_trivial_zero_number_max = T1_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T1_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T1_block_matrix_dimensions , T1_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T1_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
  
	      const unsigned int non_trivial_zero_number_max = T1_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T1_block_matrix_dimensions , T1_block_matrix_non_trivial_zero_numbers);
	    }
      }
	
  T1_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = 0;
  T1_gradient_block_matrices_non_trivial_zero_numbers_pn    = 0;
  
  T1_ppp_nnn_gradient_block_matrices_calc_store (TABLES_FILL);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);

	      class block_sparse_matrix<TYPE> &T1_matrix_gradient_pp_nn = T1_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T1_matrix_gradient_pp_nn.is_it_filled ()) T1_matrix_gradient_pp_nn.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T1_matrix_gradient_pn = T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T1_matrix_gradient_pn.is_it_filled ()) T1_matrix_gradient_pn.make_it_consistent_no_zeros ();
	    }
      }
}






void RDM_T1_gradient_class::T1_ppn_nnp_gradient_block_matrices_alloc_calc_store ()
{
  const bool is_it_ppn = ((space_pair == PROTONS_ONLY)  && (last_particle == NEUTRON));
  const bool is_it_nnp = ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON));
  
  if (!is_it_ppn && !is_it_nnp) error_message_print_abort ("It is either ppn or nnp in RDM_T1_gradient_class::T1_ppn_nnp_gradient_block_matrices_alloc_calc_store");
  
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const class RDM_T1_class &T1 = get_T1 ();

  const class array<unsigned int> &matrix_dimensions = T1.get_matrix_dimensions ();
  
  const int J_total_number = matrix_dimensions.dimension (1);
  
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  if (is_it_ppn) T1_ppn_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_nnp) T1_nnp_gradient_block_matrices_calc_store (DIMENSIONS_TABLES_CALC);

  class array<unsigned int> T1_block_matrix_dimensions(2*J_total_number);
    
  class array<unsigned int> T1_block_matrix_non_trivial_zero_numbers(2*J_total_number);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int iJ = 0 ; iJ < J_total_number ; iJ++)
      T1_block_matrix_dimensions(BP + 2*iJ) = matrix_dimensions(BP , iJ);

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T1_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T1_gradient_block_matrices_non_trivial_zero_numbers_pp(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	    
	      const unsigned int non_trivial_zero_number_max = T1_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T1_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index).allocate (T1_block_matrix_dimensions , T1_block_matrix_non_trivial_zero_numbers);
	    }
      }
      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T1_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T1_gradient_block_matrices_non_trivial_zero_numbers_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);
	      
	      const unsigned int non_trivial_zero_number_max = T1_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T1_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T1_block_matrix_dimensions , T1_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int iJ = 0 ; iJ < J_total_number ; iJ++)
		  T1_block_matrix_non_trivial_zero_numbers(BP + 2*iJ) = T1_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , iJ);

	      const unsigned int non_trivial_zero_number_max = T1_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (T1_block_matrix_dimensions , T1_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  T1_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
  T1_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
  T1_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
  
  if (is_it_ppn) T1_ppn_gradient_block_matrices_calc_store (TABLES_FILL);
  if (is_it_nnp) T1_nnp_gradient_block_matrices_calc_store (TABLES_FILL);

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      class block_sparse_matrix<TYPE> &T1_matrix_gradient_pp = T1_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T1_matrix_gradient_pp.is_it_filled ()) T1_matrix_gradient_pp.make_it_consistent_no_zeros ();  
	    }
      }
      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T1_matrix_gradient_nn = T1_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T1_matrix_gradient_nn.is_it_filled ()) T1_matrix_gradient_nn.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &T1_matrix_gradient_pn = T1_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (T1_matrix_gradient_pn.is_it_filled ()) T1_matrix_gradient_pn.make_it_consistent_no_zeros ();
	    }
      }
}
