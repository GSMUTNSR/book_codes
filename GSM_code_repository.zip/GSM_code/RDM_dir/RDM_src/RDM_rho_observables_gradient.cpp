#include "../RDM_include/RDM_include_def.h"

void RDM_rho_observables_gradient::rho_der_pp_nn_tabs_calc (
							    const int Aval , 
							    const class nucleons_data &particles_data ,
							    class array<double> &rho_der_tab)
{
  const int Aval_minus_one = Aval - 1;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    				  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  					
  rho_der_tab = 0.0;

  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
    
  if (N_valence_nucleons == 0) return;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {
	const class pair_str pair_ab(sa , sb);
      			
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);
	
	if (are_there_frozen_states_ab) continue;
      
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);	
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
	
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sb = shells_qn(sb);
	  
	const int la = shell_qn_sa.get_l ();
	  
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();

	const int hat_ja_square = 2*ija + 2;
	  
	const bool are_sa_sb_equal = (sa == sb);
	    
	const double delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT2) : (1.0);
			
	const double delta_norm_ab_over_Aval_minus_one = delta_norm_ab/Aval_minus_one;
	
	const double delta_norm_ab_over_Aval_minus_one_hat_ja_square = delta_norm_ab_over_Aval_minus_one/hat_ja_square;
	    	
	const bool is_sa_smaller_than_sb = (sa <= sb);  

	const unsigned int sd = sb;
	    
	for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	  {	    
	    const class pair_str pair_cd(sc , sd);
      			
	    const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (shells_qn , shells_qn);
	
	    if (are_there_frozen_states_cd) continue;
	
	    const int Jmin_cd = pair_cd.Jmin_determine (shells_qn , shells_qn);		
	    const int Jmax_cd = pair_cd.Jmax_determine (shells_qn , shells_qn);
	
	    const class nlj_struct &shell_qn_sc = shells_qn(sc);
	    
	    const int lc = shell_qn_sc.get_l ();
  
	    const int ijc = shell_qn_sc.get_ij ();

	    if ((la != lc) || (ija != ijc)) continue;
  	  
	    const int Jmin = max (Jmin_ab , Jmin_cd);
	    const int Jmax = min (Jmax_ab , Jmax_cd);
	    
	    const bool are_sc_sb_equal = (sc == sb);
		
	    const bool ab_different_cb_different = (!are_sa_sb_equal && !are_sc_sb_equal);
	
	    const bool is_sc_smaller_than_sb = (sc <= sb);
  
	    const double delta_norm_cb = (are_sc_sb_equal) ? (M_SQRT2) : (1.0);
	    	    
	    const double delta_norm_abcb_over_Aval_minus_one_hat_ja_square = delta_norm_ab_over_Aval_minus_one_hat_ja_square*delta_norm_cb;
	    	
	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		const bool is_J_even = (J%2 == 0);

		if (is_J_even || ab_different_cb_different)
		  {
		    const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (minus_one_pow (ijc + ijb + J));	    
		    const int phase_ab = (is_sa_smaller_than_sb) ? (1) : (minus_one_pow (ija + ijb + J));
	
		    const double delta_norm_abcb_over_Aval_minus_one_hat_ja_square_phase = (phase_ab == phase_cb) ? (delta_norm_abcb_over_Aval_minus_one_hat_ja_square) : (-delta_norm_abcb_over_Aval_minus_one_hat_ja_square);

		    const double rho_der_ME = (2*J + 1)*delta_norm_abcb_over_Aval_minus_one_hat_ja_square_phase;
	    
		    rho_der_tab(J , sa , sb , sc) = rho_der_ME;
		  }
	      }
	  }
      }
}






void RDM_rho_observables_gradient::rho_prot_der_pn_tab_calc (
							     const class nucleons_data &prot_data ,
							     const class nucleons_data &neut_data ,
							     class array<double> &rho_prot_der_pn_tab)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Nval + Zval;
  
  const int Aval_minus_one = Aval - 1;

  const double Aval_minus_one_inv = 1.0/Aval_minus_one;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  rho_prot_der_pn_tab = 0.0;
  
  if ((Zval == 0) || (Nval == 0)) return;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
		
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
      
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	
	const int la = shell_qn_sa.get_l ();
	
	const int ija = shell_qn_sa.get_ij ();

	const int hat_ja_square = 2*ija + 2;
	
	const double hat_ja_square_inv = 1.0/hat_ja_square;
	
	const double Aval_minus_one_hat_ja_square_inv = Aval_minus_one_inv*hat_ja_square_inv;
		
	const unsigned int sd_n = sb_n;
		    
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {  	    
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	
	    const int lc = shell_qn_sc.get_l ();
  
	    const int ijc = shell_qn_sc.get_ij ();

	    if ((la != lc) || (ija != ijc)) continue;  
	
	    const class pair_str pair_cd(sc_p , sd_n);
	    
	    const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	    if (are_there_frozen_states_cd) continue;
	
	    const int Jmin_cd = pair_cd.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	    const int Jmax_cd = pair_cd.Jmax_determine (prot_shells_qn , neut_shells_qn);
	  
	    const int Jmin = max (Jmin_ab , Jmin_cd);
	    const int Jmax = min (Jmax_ab , Jmax_cd);
	    	    
	    for (int J = Jmin ; J <= Jmax ; J++) rho_prot_der_pn_tab(J , sa_p , sb_n , sc_p) = (2*J + 1)*Aval_minus_one_hat_ja_square_inv;	    
	  }
      }
}







void RDM_rho_observables_gradient::rho_neut_der_pn_tab_calc (
							     const class nucleons_data &prot_data ,
							     const class nucleons_data &neut_data ,
							     class array<double> &rho_neut_der_pn_tab)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Nval + Zval;
  
  const int Aval_minus_one = Aval - 1;

  const double Aval_minus_one_inv = 1.0/Aval_minus_one;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  rho_neut_der_pn_tab = 0.0;
  
  if ((Zval == 0) || (Nval == 0)) return;

  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {
	const class pair_str pair_ab(sa_n , sb_p);
	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (neut_shells_qn , prot_shells_qn);
	
	if (are_there_frozen_states_ab) continue;
	
	const int Jmin_ab = pair_ab.Jmin_determine (neut_shells_qn , prot_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (neut_shells_qn , prot_shells_qn);
	
	const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);

	const int la = shell_qn_sa.get_l ();
	
	const int ija = shell_qn_sa.get_ij ();

	const int hat_ja_square = 2*ija + 2;
	
	const double hat_ja_square_inv = 1.0/hat_ja_square;
	
	const double Aval_minus_one_hat_ja_square_inv = Aval_minus_one_inv*hat_ja_square_inv;
	
	const unsigned int sd_p = sb_p;
	
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {  
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int lc = shell_qn_sc.get_l ();
  
	    const int ijc = shell_qn_sc.get_ij ();
  
	    if ((la != lc) || (ija != ijc)) continue;
  	    	    
	    const class pair_str pair_cd(sc_n , sd_p);
	    
	    const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (neut_shells_qn , prot_shells_qn);
	
	    if (are_there_frozen_states_cd) continue;
	
	    const int Jmin_cd = pair_cd.Jmin_determine (neut_shells_qn , prot_shells_qn);		
	    const int Jmax_cd = pair_cd.Jmax_determine (neut_shells_qn , prot_shells_qn);
	  
	    const int Jmin = max (Jmin_ab , Jmin_cd);
	    const int Jmax = min (Jmax_ab , Jmax_cd);
	    	    
	    for (int J = Jmin ; J <= Jmax ; J++) rho_neut_der_pn_tab(J , sa_n , sb_p , sc_n) = (2*J + 1)*Aval_minus_one_hat_ja_square_inv;
	  }
      }
}






void RDM_rho_observables_gradient::Delta_J_der_pp_nn_tabs_calc (
								const int Aval , 
								const class nucleons_data &particles_data ,
								const class RDM_PQG_class &Gamma_pp_nn , 
								const class array<double> &rho_der_tab , 
								class array<double> &Delta_J_der_tab)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    					
  const int Aval_minus_two = Aval - 2;
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();		
        
  Delta_J_der_tab = 0.0;
      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();
    
  if (N_valence_nucleons == 0) return;
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair_ab(sa , sb);
      			
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (shells_qn , shells_qn);
	
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);	
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
	
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sb = shells_qn(sb);
	  
	const int ija = shell_qn_sa.get_ij () , hat_ja_square = 2*ija + 2;
	const int ijb = shell_qn_sb.get_ij () , hat_jb_square = 2*ijb + 2;
	  
	const double ja = shell_qn_sa.get_j ();
	const double jb = shell_qn_sb.get_j ();
		  
	const bool are_sa_sb_equal = (sa == sb);
	
	const double Delta_ja_term = (are_sa_sb_equal) ? (0.5*Aval_minus_two*ja*(ja + 1.0)*hat_ja_square) : (Aval_minus_two*ja*(ja + 1.0)*hat_ja_square);
	const double Delta_jb_term = (are_sa_sb_equal) ? (0.5*Aval_minus_two*jb*(jb + 1.0)*hat_jb_square) : (Aval_minus_two*jb*(jb + 1.0)*hat_jb_square);
	
	const bool ab_different = !are_sa_sb_equal;
	
	for (int Jab = Jmin_ab ; Jab <= Jmax_ab ; Jab++)
	  {
	    const bool is_Jab_even = (Jab%2 == 0);

	    if (is_Jab_even || ab_different)
	      {	
		const double rho_der_abab = rho_der_tab(Jab , sa , sb , sa);
		const double rho_der_baba = rho_der_tab(Jab , sb , sa , sb);

		const unsigned int ab_index = two_states_indices(Jab , sa , sb);
		
		Delta_J_der_tab(BP_ab , Jab , ab_index) = (2*Jab + 1)*Jab*(Jab + 1) - Delta_ja_term*rho_der_abab - Delta_jb_term*rho_der_baba;
	      }
	  }		
      }
}



void RDM_rho_observables_gradient::Delta_J_der_pn_tab_calc (
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data ,
							    const class RDM_PQG_class &Gamma_pn ,  
							    const class array<double> &rho_prot_der_pn_tab , 
							    const class array<double> &rho_neut_der_pn_tab , 
							    class array<double> &Delta_J_der_pn_tab)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Nval + Zval;
  
  const int Aval_minus_two = Aval - 2;

  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
	  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
      
  Delta_J_der_pn_tab = 0.0;
    
  if ((Zval == 0) || (Nval == 0)) return;
    
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
	
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);

	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();

	const int hat_ja_square = 2*ija + 2;
	const int hat_jb_square = 2*ijb + 2;
	
	const double ja = shell_qn_sa.get_j ();
	const double jb = shell_qn_sb.get_j ();
		
	const double Delta_ja_term = Aval_minus_two*hat_ja_square*ja*(ja + 1.0);
	const double Delta_jb_term = Aval_minus_two*hat_jb_square*jb*(jb + 1.0);
		    	
	for (int J = Jmin_ab ; J <= Jmax_ab ; J++)
	  {
	    const int hat_J_square = 2*J + 1;
	    
	    const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
	
	    const double rho_prot_der_pn_abab = rho_prot_der_pn_tab(J , sa_p , sb_n , sa_p); 
	    const double rho_neut_der_pn_baba = rho_neut_der_pn_tab(J , sb_n , sa_p , sb_n); 
	        
	    Delta_J_der_pn_tab(BP , J , ab_index) = hat_J_square*J*(J + 1) - Delta_ja_term*rho_prot_der_pn_abab - Delta_jb_term*rho_neut_der_pn_baba;
	  }
      }  
}








void RDM_rho_observables_gradient::average_T2_der_pn_tab_calc (
							       const class nucleons_data &prot_data ,
							       const class nucleons_data &neut_data ,
							       const class RDM_PQG_class &Gamma_pn ,  
							       class array<unsigned int> &ba_from_ab_pn_indices ,
							       class array<int> &average_T2_der_pn_tab)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const int np_max = prot_data.get_nmax ();
  const int nn_max = neut_data.get_nmax ();
  
  const int lp_max = prot_data.get_lmax ();
  const int ln_max = neut_data.get_lmax ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
	  
  const class nlj_table<unsigned int> &prot_shells_indices = prot_data.get_shells_indices ();
  const class nlj_table<unsigned int> &neut_shells_indices = neut_data.get_shells_indices ();
      
  const class nlj_table<bool> &is_it_prot_valence_shell_tab = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_neut_valence_shell_tab = neut_data.get_is_it_valence_shell_tab ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  ba_from_ab_pn_indices = Np_nlj*Nn_nlj;
  
  average_T2_der_pn_tab = 0;

  if ((Zval == 0) || (Nval == 0)) return;
    
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
      	      
	const int na = shell_qn_sa.get_n ();
	const int nb = shell_qn_sb.get_n ();

	if (na > nn_max) continue;
	if (nb > np_max) continue;
      
	const int la = shell_qn_sa.get_l ();
	const int lb = shell_qn_sb.get_l ();
      
	if (la > ln_max) continue;
	if (lb > lp_max) continue;
	
	const double ja = shell_qn_sa.get_j ();
	const double jb = shell_qn_sb.get_j ();
      
	if (!is_it_neut_valence_shell_tab(na , la , ja)) continue;
	if (!is_it_prot_valence_shell_tab(nb , lb , jb)) continue;
      	
	const unsigned int sa_n = neut_shells_indices(na , la , ja);
	const unsigned int sb_p = prot_shells_indices(nb , lb , jb);
	
	const class pair_str pair_ab(sa_p , sb_n);
	
	const unsigned int BP = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
			    	
	for (int J = Jmin_ab ; J <= Jmax_ab ; J++)
	  {
	    const int hat_J_square = 2*J + 1;
	    
	    const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
	    const unsigned int ba_index = two_states_indices_pn(J , sb_p , sa_n);
		    
	    ba_from_ab_pn_indices(BP , J , ab_index) = ba_index;

	    const double gradient_ME = (ba_index == ab_index) ? (hat_J_square*minus_one_pow (Jmax_ab + J + 1)) : (2.0*hat_J_square*minus_one_pow (Jmax_ab + J + 1));
	    
	    average_T2_der_pn_tab(BP , J , ab_index) = gradient_ME;
	  }
      }  
}










void RDM_rho_observables_gradient::average_E_der_pp_nn_tab_calc (
								 const bool is_it_E_reference_condition , 
								 const enum interaction_type inter ,
								 const double H_renormalization_factor ,
								 const class nucleons_data &prot_data ,
								 const class nucleons_data &neut_data ,
								 const class array<double> &rho_der_tab ,
								 const class RDM_PQG_class &Gamma_pp_nn ,
								 class block_matrix<TYPE> &average_E_der_block_matrix)
{
  const enum space_type space = Gamma_pp_nn.get_space_pair ();
  
  const class nucleons_data &particles_data = (space == PROTONS_ONLY) ? (prot_data) : (neut_data);
    
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();

  const bool are_there_pp_nn_pairs = (N_valence_nucleons >= 2);
  
  const unsigned int N_nlj_all = particles_data.get_N_nlj ();
  
  const unsigned int N_nlj = (is_it_E_reference_condition) ? (particles_data.get_N_nlj_res ()) : (particles_data.get_N_nlj ());
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();  
  				
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  				   
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<TYPE> &OBMEs = OBMEs_inter_set(inter);
  
  const class TBMEs_class &TBMEs_pp_nn = particles_data.get_TBMEs ();

  average_E_der_block_matrix.zero ();
  
  if (N_valence_nucleons == 0) return;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
	
	const int ij = ija;
	
	const TYPE factor = (2*ij + 2)*OBMEs(sa , sc);
    
	for (unsigned int sp = 0 ; sp < N_nlj_all ; sp++)
	  {
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sa , sp);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sc , sp);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sa , sp);

	    const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
	    const int ijp = shell_qn_sp.get_ij ();
      
	    const unsigned sa_sp_min = min (sa , sp) , sc_sp_min = min (sc , sp);
	    const unsigned sa_sp_max = max (sa , sp) , sc_sp_max = max (sc , sp);
      
	    const int Jmin_sa_sp = Jmin_table(sa , sp) , Jmin_sc_sp = Jmin_table(sc , sp) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_table(sa , sp) , Jmax_sc_sp = Jmax_table(sc , sp) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
            
	    const bool are_sa_sp_equal = (sa == sp) , is_sa_smaller_than_sp = (sa <= sp);
	    const bool are_sc_sp_equal = (sc == sp) , is_sc_smaller_than_sp = (sc <= sp);
                     
	    const bool sa_sp_different_sc_sp_different = (!are_sa_sp_equal && !are_sc_sp_equal);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const bool is_Jp_even = (Jp%2 == 0);

		if (is_Jp_even || sa_sp_different_sc_sp_different)
		  {
		    const unsigned int ip = two_states_indices(Jp , sa_sp_min , sa_sp_max);
		    const unsigned int jp = two_states_indices(Jp , sc_sp_min , sc_sp_max);
	      	  	      	      
		    const int phase_sa_sp = (is_sa_smaller_than_sp) ? (1) : (((ija + ijp + Jp)%2 == 0) ? (1) : (-1));
		    const int phase_sc_sp = (is_sc_smaller_than_sp) ? (1) : (((ijc + ijp + Jp)%2 == 0) ? (1) : (-1));

		    const TYPE gradient_ME = (phase_sa_sp == phase_sc_sp) ? (factor*rho_der_tab(Jp , sa , sp , sc)) : (-factor*rho_der_tab(Jp , sa , sp , sc));
		    
		    class matrix<TYPE> &average_E_der_BP_J_matrix = average_E_der_block_matrix(BPp + 2*Jp);
		    
		    average_E_der_BP_J_matrix(ip , jp) += gradient_ME;
		    
		    if (ip != jp) average_E_der_BP_J_matrix(jp , ip) += gradient_ME;
		  }
	      }
	  }
      }
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	for (unsigned int sc = 0 ; sc <= sd ; sc++)
	  {      	
	    if (!is_it_in_space_tab(sa , sb)) continue;
	    if (!is_it_in_space_tab(sc , sd)) continue;
  
	    const unsigned int BP_ab = BP_table(sa , sb);
	    const unsigned int BP_cd = BP_table(sc , sd);
	    
	    if (BP_ab != BP_cd) continue;
	    
	    const unsigned int BP = BP_ab;
	      
	    const int Jmin_ab = Jmin_table(sa , sb) , Jmin_cd = Jmin_table(sc , sd) , Jmin = max (Jmin_ab , Jmin_cd);
	    const int Jmax_ab = Jmax_table(sa , sb) , Jmax_cd = Jmax_table(sc , sd) , Jmax = min (Jmax_ab , Jmax_cd);
		      		  	
	    const bool are_sa_sb_equal = (sa == sb);
	    const bool are_sc_sd_equal = (sc == sd);
	      
	    const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);
	      	      
	    for (int J = Jmin ; J <= Jmax ; J++)
	      {  		  
		const bool is_J_even = (J%2 == 0);

		if (is_J_even || ab_different_cd_different)
		  {	
		    const TYPE TBME_abcd_J = (are_there_pp_nn_pairs) ? (TBMEs_pp_nn(J , sa , sb , sc , sd)) : (0.0);
		  
		    const unsigned int ab_index = two_states_indices(J , sa , sb);
		    const unsigned int cd_index = two_states_indices(J , sc , sd);
		    		  		  
		    class matrix<TYPE> &average_E_der_BP_J_matrix = average_E_der_block_matrix(BP + 2*J);
		  
		    const TYPE gradient_ME = (2*J + 1)*H_renormalization_factor*TBME_abcd_J;
		    
		    average_E_der_BP_J_matrix(ab_index , cd_index) += gradient_ME;
		    
		    if (ab_index != cd_index) average_E_der_BP_J_matrix(cd_index , ab_index) += gradient_ME;
		  }
	      }
	  }
}





void RDM_rho_observables_gradient::average_E_der_pn_tab_calc (
							      const bool is_it_E_reference_condition , 
							      const enum interaction_type inter ,
							      const double H_renormalization_factor ,
							      const class nucleons_data &prot_data ,
							      const class nucleons_data &neut_data ,
							      const class TBMEs_class &TBMEs_pn ,   
							      const class array<double> &rho_prot_der_pn_tab ,
							      const class array<double> &rho_neut_der_pn_tab ,
							      const class RDM_PQG_class &Gamma_pn ,
							      class block_matrix<TYPE> &average_E_der_pn_block_matrix)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nlj_all = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj_all = neut_data.get_N_nlj ();
  
  const unsigned int Np_nlj = (is_it_E_reference_condition) ? (prot_data.get_N_nlj_res ()) : (prot_data.get_N_nlj ());
  const unsigned int Nn_nlj = (is_it_E_reference_condition) ? (neut_data.get_N_nlj_res ()) : (neut_data.get_N_nlj ());
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class OBMEs_inter_set_str &OBMEs_inter_prot_set = prot_data.get_OBMEs_inter_set ();
  const class OBMEs_inter_set_str &OBMEs_inter_neut_set = neut_data.get_OBMEs_inter_set ();
  
  const class array<TYPE> &OBMEs_prot = OBMEs_inter_prot_set(inter);
  const class array<TYPE> &OBMEs_neut = OBMEs_inter_neut_set(inter);
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  average_E_der_pn_block_matrix.zero ();
  
  if ((Zval == 0) || (Nval == 0)) return;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
      {
    	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
		
	const TYPE factor = (2*ija + 2)*OBMEs_prot(sa_p , sc_p);
	
	for (unsigned int sp_n = 0 ; sp_n < Nn_nlj_all ; sp_n++)
	  {			    
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sa_p , sp_n);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sc_p , sp_n);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sa_p , sp_n);

	    const int Jmin_sa_sp = Jmin_pn_table(sa_p , sp_n) , Jmin_sc_sp = Jmin_pn_table(sc_p , sp_n) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_pn_table(sa_p , sp_n) , Jmax_sc_sp = Jmax_pn_table(sc_p , sp_n) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {	      	  
		const unsigned int ip = two_states_indices_pn(Jp , sa_p , sp_n);
		const unsigned int jp = two_states_indices_pn(Jp , sc_p , sp_n);
      	      
		const TYPE gradient_ME = factor*rho_prot_der_pn_tab(Jp , sa_p , sp_n , sc_p);
	  	      
		class matrix<TYPE> &average_E_der_pn_BP_J_matrix = average_E_der_pn_block_matrix(BPp + 2*Jp);
		
		average_E_der_pn_BP_J_matrix(ip , jp) += gradient_ME;
		
		if (ip != jp) average_E_der_pn_BP_J_matrix(jp , ip) += gradient_ME;
	      }
	  }
      }

  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
      {
    	const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
	const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
		
	const TYPE factor = (2*ija + 2)*OBMEs_neut(sa_n , sc_n);
	
	for (unsigned int sp_p = 0 ; sp_p < Np_nlj_all ; sp_p++)
	  {			 
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sp_p , sa_n);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sp_p , sc_n);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sp_p , sa_n);

	    const int Jmin_sa_sp = Jmin_pn_table(sp_p , sa_n) , Jmin_sc_sp = Jmin_pn_table(sp_p , sc_n) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_pn_table(sp_p , sa_n) , Jmax_sc_sp = Jmax_pn_table(sp_p , sc_n) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {	      	  
		const unsigned int ip = two_states_indices_pn(Jp , sp_p , sa_n);
		const unsigned int jp = two_states_indices_pn(Jp , sp_p , sc_n);
      	      
		const TYPE gradient_ME = factor*rho_neut_der_pn_tab(Jp , sa_n , sp_p , sc_n);
	      
		class matrix<TYPE> &average_E_der_pn_BP_J_matrix = average_E_der_pn_block_matrix(BPp + 2*Jp);
		
		average_E_der_pn_BP_J_matrix(ip , jp) += gradient_ME;
		
		if (ip != jp) average_E_der_pn_BP_J_matrix(jp , ip) += gradient_ME;
	      }
	  }     
      }
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	  {      
	    if (!is_it_in_space_tab(sa_p , sb_n)) continue;
	    if (!is_it_in_space_tab(sc_p , sd_n)) continue;
	    
	    const unsigned int BP_ab = BP_table(sa_p , sb_n);
	    const unsigned int BP_cd = BP_table(sc_p , sd_n);
		
	    if (BP_ab != BP_cd) continue;

	    const unsigned int BP = BP_ab;
	      
	    const int Jmin_ab = Jmin_pn_table(sa_p , sb_n) , Jmin_cd = Jmin_pn_table(sc_p , sd_n) , Jmin = max (Jmin_ab , Jmin_cd);
	    const int Jmax_ab = Jmax_pn_table(sa_p , sb_n) , Jmax_cd = Jmax_pn_table(sc_p , sd_n) , Jmax = min (Jmax_ab , Jmax_cd);
			      	      	      		  
	    for (int J = Jmin ; J <= Jmax ; J++)
	      {		  
		const TYPE TBME_abcd_J = TBMEs_pn(J , sa_p , sb_n , sc_p , sd_n);
		  
		const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
		const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
		    		  		  
		class matrix<TYPE> &average_E_der_pn_BP_J_matrix = average_E_der_pn_block_matrix(BP + 2*J);
		  
		const TYPE gradient_ME = (2*J + 1)*H_renormalization_factor*TBME_abcd_J;
		    
		average_E_der_pn_BP_J_matrix(ab_index , cd_index) += gradient_ME;
		
		if (ab_index != cd_index) average_E_der_pn_BP_J_matrix(cd_index , ab_index) += gradient_ME;
	      }
	  }
}





void RDM_rho_observables_gradient::average_E_der_tabs_calc (
							    const bool is_it_E_reference_condition ,
							    const enum interaction_type inter ,
							    const double H_renormalization_factor , 
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data ,
							    const class TBMEs_class &TBMEs_pn ,
							    const class RDM_PQG_class &Gamma_pp ,
							    const class RDM_PQG_class &Gamma_nn ,
							    const class RDM_PQG_class &Gamma_pn ,
							    const class RDM_conditions_gradient_class &A_Gamma_gradients ,
							    class block_matrix<TYPE> &average_E_der_pp_block_matrix ,
							    class block_matrix<TYPE> &average_E_der_nn_block_matrix ,
							    class block_matrix<TYPE> &average_E_der_pn_block_matrix)
{
  if (is_it_E_reference_condition && (H_renormalization_factor != 1.0)) error_message_print_abort ("H_renormalization_factor must be equal to one if one calculates <Psi|H[ref]|Psi> in reference space, where <Psi|H[ref]|Psi> >= E[reference] (gradient)");
  
  const class array<double> &rho_prot_der_pp_tab = A_Gamma_gradients.get_rho_prot_der_tab (PROTONS_ONLY);
  const class array<double> &rho_prot_der_pn_tab = A_Gamma_gradients.get_rho_prot_der_tab (PROTONS_NEUTRONS);  
  const class array<double> &rho_neut_der_nn_tab = A_Gamma_gradients.get_rho_neut_der_tab (NEUTRONS_ONLY);
  const class array<double> &rho_neut_der_pn_tab = A_Gamma_gradients.get_rho_neut_der_tab (PROTONS_NEUTRONS);
  
  average_E_der_pp_nn_tab_calc (is_it_E_reference_condition , inter , H_renormalization_factor , prot_data , neut_data , rho_prot_der_pp_tab , Gamma_pp , average_E_der_pp_block_matrix);
  average_E_der_pp_nn_tab_calc (is_it_E_reference_condition , inter , H_renormalization_factor , prot_data , neut_data , rho_neut_der_nn_tab , Gamma_nn , average_E_der_nn_block_matrix);
  
  average_E_der_pn_tab_calc (is_it_E_reference_condition , inter , H_renormalization_factor , prot_data , neut_data , TBMEs_pn , rho_prot_der_pn_tab , rho_neut_der_pn_tab , Gamma_pn , average_E_der_pn_block_matrix);
}






void RDM_rho_observables_gradient::Delta_Hcm_der_pp_nn_tab_calc (
								 const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
								 const class nucleons_data &particles_data ,
								 const class array<double> &rho_der_tab ,
								 const class RDM_PQG_class &Gamma_pp_nn ,
								 class block_matrix<TYPE> &Delta_Hcm_der_block_matrix)
{
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
      
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
          
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();

  Delta_Hcm_der_block_matrix.zero ();
  
  if (N_valence_nucleons == 0) return;
    
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	
	const int ij = ija;
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;

	const TYPE OBME_ac = CM_OBMEs_TBMEs::coupled_OBME (HCM , true , particles_data , sa , sc);
		
	const TYPE factor = (2*ij + 2)*OBME_ac;
    
	for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
	  {		    
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sa , sp);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sc , sp);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sa , sp);

	    const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
	    const int ijp = shell_qn_sp.get_ij ();
      
	    const unsigned sa_sp_min = min (sa , sp) , sc_sp_min = min (sc , sp);
	    const unsigned sa_sp_max = max (sa , sp) , sc_sp_max = max (sc , sp);
      
	    const int Jmin_sa_sp = Jmin_table(sa , sp) , Jmin_sc_sp = Jmin_table(sc , sp) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_table(sa , sp) , Jmax_sc_sp = Jmax_table(sc , sp) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
            
	    const bool are_sa_sp_equal = (sa == sp) , is_sa_smaller_than_sp = (sa <= sp);
	    const bool are_sc_sp_equal = (sc == sp) , is_sc_smaller_than_sp = (sc <= sp);
                     
	    const bool sa_sp_different_sc_sp_different = (!are_sa_sp_equal && !are_sc_sp_equal);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const bool is_Jp_even = (Jp%2 == 0);

		if (is_Jp_even || sa_sp_different_sc_sp_different)
		  {
		    const unsigned int ip = two_states_indices(Jp , sa_sp_min , sa_sp_max);
		    const unsigned int jp = two_states_indices(Jp , sc_sp_min , sc_sp_max);
	      	  	      	      
		    const int phase_sa_sp = (is_sa_smaller_than_sp) ? (1) : (((ija + ijp + Jp)%2 == 0) ? (1) : (-1));
		    const int phase_sc_sp = (is_sc_smaller_than_sp) ? (1) : (((ijc + ijp + Jp)%2 == 0) ? (1) : (-1));

		    const TYPE gradient_ME = (phase_sa_sp == phase_sc_sp) ? (factor*rho_der_tab(Jp , sa , sp , sc)) : (-factor*rho_der_tab(Jp , sa , sp , sc));
		    
		    class matrix<TYPE> &Delta_Hcm_der_BP_J_matrix = Delta_Hcm_der_block_matrix(BPp + 2*Jp);
		  
		    Delta_Hcm_der_BP_J_matrix(ip , jp) += gradient_ME;
		    
		    if (ip != jp) Delta_Hcm_der_BP_J_matrix(jp , ip) += gradient_ME;
		  }
	      }
	  }
      }
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	for (unsigned int sc = 0 ; sc <= sd ; sc++)
	  {      	
	    if (!is_it_in_space_tab(sa , sb)) continue;
	    if (!is_it_in_space_tab(sc , sd)) continue;
	    
	    const unsigned int BP_ab = BP_table(sa , sb);
	    const unsigned int BP_cd = BP_table(sc , sd);
	    
	    if (BP_ab != BP_cd) continue;
	      
	    const bool is_coupled_TBME_pp_nn_trivial_zero = CM_OBMEs_TBMEs::is_coupled_TBME_pp_nn_trivial_zero_determine (shells_qn , sa , sb , sc , sd);

	    if (!is_coupled_TBME_pp_nn_trivial_zero)
	      {	    
		const unsigned int BP = BP_ab;
	    
		const int Jmin_ab = Jmin_table(sa , sb) , Jmin_cd = Jmin_table(sc , sd) , Jmin = max (Jmin_ab , Jmin_cd);
		const int Jmax_ab = Jmax_table(sa , sb) , Jmax_cd = Jmax_table(sc , sd) , Jmax = min (Jmax_ab , Jmax_cd);
		      		  	
		const bool are_sa_sb_equal = (sa == sb);
		const bool are_sc_sd_equal = (sc == sd);
	      
		const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);
	      	      		  
		for (int J = Jmin ; J <= Jmax ; J++)
		  {  		  
		    const bool is_J_even = (J%2 == 0);

		    if (is_J_even || ab_different_cd_different)
		      {		  	
			const class CM_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
		  	      	      		  
			const unsigned int ab_index = two_states_indices(J , sa , sb);
			const unsigned int cd_index = two_states_indices(J , sc , sd);
		    		  		  
			class matrix<TYPE> &Delta_Hcm_der_BP_J_matrix = Delta_Hcm_der_block_matrix(BP + 2*J);

			const TYPE TBME_abcd_J = CM_OBMEs_TBMEs::coupled_TBME_pp_nn_calc (HCM , true , particles_data , TBMEs_angular_table_J , sa , sb , sc , sd);
		  
			const TYPE gradient_ME = (2*J + 1)*TBME_abcd_J;
		    
			Delta_Hcm_der_BP_J_matrix(ab_index , cd_index) += gradient_ME;
		    
			if (ab_index != cd_index) Delta_Hcm_der_BP_J_matrix(cd_index , ab_index) += gradient_ME;
		      }
		  }
	      }
	  }
}





void RDM_rho_observables_gradient::Delta_Hcm_der_pn_tab_calc (
							      const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
							      const class nucleons_data &prot_data ,
							      const class nucleons_data &neut_data , 
							      const class array<double> &rho_prot_der_pn_tab ,
							      const class array<double> &rho_neut_der_pn_tab ,
							      const class RDM_PQG_class &Gamma_pn ,
							      class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
      
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  Delta_Hcm_der_pn_block_matrix.zero ();
  
  if ((Zval == 0) || (Nval == 0)) return;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
      {
    	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
		
	const TYPE OBME_prot_ac = CM_OBMEs_TBMEs::coupled_OBME (HCM , true , prot_data , sa_p , sc_p);
	
	const TYPE factor = (2*ija + 2)*OBME_prot_ac;
	
	for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
	  {		
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sa_p , sp_n);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sc_p , sp_n);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sa_p , sp_n);

	    const int Jmin_sa_sp = Jmin_pn_table(sa_p , sp_n) , Jmin_sc_sp = Jmin_pn_table(sc_p , sp_n) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_pn_table(sa_p , sp_n) , Jmax_sc_sp = Jmax_pn_table(sc_p , sp_n) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {	      	  
		const unsigned int ip = two_states_indices_pn(Jp , sa_p , sp_n);
		const unsigned int jp = two_states_indices_pn(Jp , sc_p , sp_n);
      	      
		const TYPE gradient_ME = factor*rho_prot_der_pn_tab(Jp , sa_p , sp_n , sc_p);
	  	      
		class matrix<TYPE> &Delta_Hcm_der_pn_BP_J_matrix = Delta_Hcm_der_pn_block_matrix(BPp + 2*Jp);
		
		Delta_Hcm_der_pn_BP_J_matrix(ip , jp) += gradient_ME;
		
		if (ip != jp) Delta_Hcm_der_pn_BP_J_matrix(jp , ip) += gradient_ME;
	      }
	  }
      }

  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
      {
    	const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
	const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
	      
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
	
	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
		
	const TYPE OBME_neut_ac = CM_OBMEs_TBMEs::coupled_OBME (HCM , true , neut_data , sa_n , sc_n);
	
	const TYPE factor = (2*ija + 2)*OBME_neut_ac;
	
	for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
	  {			  
	    const bool is_it_in_space_sa_sp = is_it_in_space_tab(sp_p , sa_n);
	    const bool is_it_in_space_sc_sp = is_it_in_space_tab(sp_p , sc_n);

	    if (!is_it_in_space_sa_sp || !is_it_in_space_sc_sp) continue;
	    
	    const unsigned int BPp = BP_table(sp_p , sa_n);

	    const int Jmin_sa_sp = Jmin_pn_table(sp_p , sa_n) , Jmin_sc_sp = Jmin_pn_table(sp_p , sc_n) , Jp_min = max (Jmin_sa_sp , Jmin_sc_sp);
	    const int Jmax_sa_sp = Jmax_pn_table(sp_p , sa_n) , Jmax_sc_sp = Jmax_pn_table(sp_p , sc_n) , Jp_max = min (Jmax_sa_sp , Jmax_sc_sp);
	  
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {	      	  
		const unsigned int ip = two_states_indices_pn(Jp , sp_p , sa_n);
		const unsigned int jp = two_states_indices_pn(Jp , sp_p , sc_n);
      	      
		const TYPE gradient_ME = factor*rho_neut_der_pn_tab(Jp , sa_n , sp_p , sc_n);
	      
		class matrix<TYPE> &Delta_Hcm_der_pn_BP_J_matrix = Delta_Hcm_der_pn_block_matrix(BPp + 2*Jp);
		
		Delta_Hcm_der_pn_BP_J_matrix(ip , jp) += gradient_ME;
		
		if (ip != jp) Delta_Hcm_der_pn_BP_J_matrix(jp , ip) += gradient_ME;
	      }
	  }     
      }

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	  {      
	    if (!is_it_in_space_tab(sa_p , sb_n)) continue;
	    if (!is_it_in_space_tab(sc_p , sd_n)) continue;
	    
	    const unsigned int BP_ab = BP_table(sa_p , sb_n);
	    const unsigned int BP_cd = BP_table(sc_p , sd_n);
		
	    if (BP_ab != BP_cd) continue;

	    const bool is_coupled_TBME_pn_trivial_zero = CM_OBMEs_TBMEs::is_coupled_TBME_pn_trivial_zero_determine (prot_shells_qn , neut_shells_qn , sa_p , sb_n , sc_p , sd_n);

	    if (!is_coupled_TBME_pn_trivial_zero)
	      {
		const unsigned int BP = BP_ab;
	      
		const int Jmin_ab = Jmin_pn_table(sa_p , sb_n) , Jmin_cd = Jmin_pn_table(sc_p , sd_n) , Jmin = max (Jmin_ab , Jmin_cd);
		const int Jmax_ab = Jmax_pn_table(sa_p , sb_n) , Jmax_cd = Jmax_pn_table(sc_p , sd_n) , Jmax = min (Jmax_ab , Jmax_cd);
		      	      	      		  
		for (int J = Jmin ; J <= Jmax ; J++)
		  {
		    const class CM_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
		    
		    const TYPE TBME_abcd_J = CM_OBMEs_TBMEs::coupled_TBME_pn_calc (HCM , true , prot_data , neut_data , TBMEs_angular_table_J , sa_p , sb_n , sc_p , sd_n);
		  
		    const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
		    const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
		    		  		  
		    class matrix<TYPE> &Delta_Hcm_der_pn_BP_J_matrix = Delta_Hcm_der_pn_block_matrix(BP + 2*J);
		  
		    const TYPE gradient_ME = (2*J + 1)*TBME_abcd_J;
		    
		    Delta_Hcm_der_pn_BP_J_matrix(ab_index , cd_index) += gradient_ME;
		
		    if (ab_index != cd_index) Delta_Hcm_der_pn_BP_J_matrix(cd_index , ab_index) += gradient_ME;
		  }
	      }
	  }
}





void RDM_rho_observables_gradient::Delta_Hcm_der_tabs_calc (
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data ,
							    const class RDM_PQG_class &Gamma_pp ,
							    const class RDM_PQG_class &Gamma_nn ,
							    const class RDM_PQG_class &Gamma_pn ,
							    const class RDM_conditions_gradient_class &A_Gamma_gradients ,
							    class block_matrix<TYPE> &Delta_Hcm_der_pp_block_matrix ,
							    class block_matrix<TYPE> &Delta_Hcm_der_nn_block_matrix ,
							    class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix)
{  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
  
  const double jmax = max (jp_max , jn_max);

  const int Jmax = make_int (2.0*jmax);
  
  const int Jmax_plus_one = Jmax + 1;

  class array<class CM_TBMEs_angular_table_str> TBMEs_angular_tables(Jmax_plus_one);

  for (int J = 0 ; J <= Jmax ; J++) TBMEs_angular_tables(J).allocate_calc_coupled (HCM , jmax , J);
  
  const class array<double> &rho_prot_der_pp_tab = A_Gamma_gradients.get_rho_prot_der_tab (PROTONS_ONLY);
  const class array<double> &rho_prot_der_pn_tab = A_Gamma_gradients.get_rho_prot_der_tab (PROTONS_NEUTRONS);  
  const class array<double> &rho_neut_der_nn_tab = A_Gamma_gradients.get_rho_neut_der_tab (NEUTRONS_ONLY);
  const class array<double> &rho_neut_der_pn_tab = A_Gamma_gradients.get_rho_neut_der_tab (PROTONS_NEUTRONS);
  
  Delta_Hcm_der_pp_nn_tab_calc (TBMEs_angular_tables , prot_data , rho_prot_der_pp_tab , Gamma_pp , Delta_Hcm_der_pp_block_matrix);
  Delta_Hcm_der_pp_nn_tab_calc (TBMEs_angular_tables , neut_data , rho_neut_der_nn_tab , Gamma_nn , Delta_Hcm_der_nn_block_matrix);
  
  Delta_Hcm_der_pn_tab_calc (TBMEs_angular_tables , prot_data , neut_data , rho_prot_der_pn_tab , rho_neut_der_pn_tab , Gamma_pn , Delta_Hcm_der_pn_block_matrix);
}





