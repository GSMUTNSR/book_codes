#include "../RDM_include/RDM_include_def.h"

using namespace RDM_rho_observables;



void RDM_observables_HO::calculation (
				      const class input_data_str &input_data ,
				      const class RDM_PQG_class &Gamma_pp ,
				      const class RDM_PQG_class &Gamma_nn ,
				      const class RDM_PQG_class &Gamma_pn ,
				      const class nucleons_data &prot_data ,
				      const class nucleons_data &neut_data) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Observables" << endl;
      cout <<         "-----------" << endl << endl;

      all_shells_occupation_calc_print (PROTON  , prot_data , neut_data , Gamma_pp , Gamma_pn);
      all_shells_occupation_calc_print (NEUTRON , prot_data , neut_data , Gamma_nn , Gamma_pn);
  
      all_partial_wave_occupation_calc_print (PROTON  , prot_data , neut_data , Gamma_pp , Gamma_pn);
      all_partial_wave_occupation_calc_print (NEUTRON , prot_data , neut_data , Gamma_nn , Gamma_pn);
    }
  
  const bool are_there_GSM_multipoles = input_data.get_are_there_GSM_multipoles ();
  
  if (are_there_GSM_multipoles) RDM_multipoles::calc_print (input_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);        
}




