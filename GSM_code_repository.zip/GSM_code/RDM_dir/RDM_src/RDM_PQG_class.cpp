#include "../RDM_include/RDM_include_def.h"

using namespace correlated_state_routines;




RDM_PQG_class::RDM_PQG_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0) ,
  n_scat_max (0) ,
  is_it_P (false) ,
  is_it_Q (false) ,
  is_it_G (false) ,  
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_6j_hats_G_ptr (NULL)
{}

RDM_PQG_class::RDM_PQG_class (
			      const enum space_type space_pair_c ,
			      const enum particle_type last_particle_c ,
			      const bool truncation_hw_c ,
			      const bool truncation_ph_c ,
			      const int E_max_hw_c ,
			      const int n_scat_max_c , 
			      const bool is_it_P_c , 
			      const bool is_it_Q_c , 
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0) ,
  n_scat_max (0) ,
  is_it_P (false) ,
  is_it_Q (false) ,
  is_it_G (false) ,  
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_6j_hats_G_ptr (NULL)
{
  allocate (space_pair_c , last_particle_c , truncation_hw_c , truncation_ph_c , E_max_hw_c , n_scat_max_c , is_it_P_c , is_it_Q_c , prot_data , neut_data);
}


RDM_PQG_class::RDM_PQG_class (
			      const enum space_type space_pair_c ,
			      const enum particle_type last_particle_c ,
			      const bool truncation_hw_c ,
			      const bool truncation_ph_c ,
			      const int E_max_hw_c ,
			      const int n_scat_max_c , 
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data ,
			      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  truncation_hw (false) ,
  truncation_ph (false) ,
  E_max_hw (0) ,
  n_scat_max (0) ,
  is_it_P (false) ,
  is_it_Q (false) ,
  is_it_G (false) ,  
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL) ,
  Wigner_6j_hats_G_ptr (NULL)
{
  allocate (space_pair_c , last_particle_c , truncation_hw_c , truncation_ph_c , E_max_hw_c , n_scat_max_c , prot_data , neut_data , Wigner_6j_hats_G);
}


RDM_PQG_class::RDM_PQG_class (const class RDM_PQG_class &X)
{
  allocate_fill (X);
}


RDM_PQG_class::~RDM_PQG_class () {}



void RDM_PQG_class::allocate (
			      const enum space_type space_pair_c ,
			      const enum particle_type last_particle_c ,
			      const bool truncation_hw_c ,
			      const bool truncation_ph_c ,
			      const int E_max_hw_c ,
			      const int n_scat_max_c , 
			      const bool is_it_P_c , 
			      const bool is_it_Q_c , 
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_PQG_class::allocate");
    
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
  
  truncation_hw = truncation_hw_c;
  truncation_ph = truncation_ph_c;
			       
  E_max_hw = E_max_hw_c;
  
  n_scat_max = n_scat_max_c;
  
  is_it_P = is_it_P_c;
  is_it_Q = is_it_Q_c;
  is_it_G = false;
				
  if (is_it_P && (truncation_hw || truncation_ph)) error_message_print_abort ("No truncation with P in RDM_PQG_class::allocate");
  
  if (!is_it_P && !is_it_Q && !is_it_G) error_message_print_abort ("It is Q or G in RDM_PQG_class::allocate");
  
  if ((space_pair == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in RDM_PQG_class::allocate");
  if ((space_pair == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in RDM_PQG_class::allocate");

  if ((space_pair == PROTONS_NEUTRONS) && (last_particle == PROTON)) error_message_print_abort ("The last particle is neutron with proton-neutron P and Q in RDM_PQG_class::allocate");
  
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;

  Wigner_6j_hats_G_ptr = NULL;
    
  switch (space_pair)
    {
    case PROTONS_ONLY:  BP_J_tables_dimensions_indices_pp_nn_alloc_calc (); break;
    case NEUTRONS_ONLY: BP_J_tables_dimensions_indices_pp_nn_alloc_calc (); break;
      
    case PROTONS_NEUTRONS: BP_J_tables_dimensions_indices_pn_alloc_calc (); break;
      	  
    default: abort_all ();
    }

  const int Jmax_total_plus_one = matrix_dimensions.dimension (1);
        
  class array<unsigned int> block_matrix_dimensions(2*Jmax_total_plus_one);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J < Jmax_total_plus_one ; J++)
      block_matrix_dimensions(BP + 2*J) = matrix_dimensions(BP , J);
  
  block_matrix_abcd.allocate (block_matrix_dimensions);

  zero ();

  const unsigned int total_dimension = block_matrix_dimensions.sum ();

  block_matrix_abcd_array_helper.allocate (total_dimension);
}







void RDM_PQG_class::allocate (
			      const enum space_type space_pair_c ,
			      const enum particle_type last_particle_c ,
			      const bool truncation_hw_c ,
			      const bool truncation_ph_c ,
			      const int E_max_hw_c ,
			      const int n_scat_max_c , 
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data ,
			      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_PQG_class::allocate");
    
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
  
  truncation_hw = truncation_hw_c;
  truncation_ph = truncation_ph_c;
			       
  E_max_hw = E_max_hw_c;
  
  n_scat_max = n_scat_max_c;

  is_it_P = false;
  is_it_Q = false;
  is_it_G = true;
		  
  if ((space_pair == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in RDM_PQG_class::allocate");
  if ((space_pair == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in RDM_PQG_class::allocate");
  
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;

  Wigner_6j_hats_G_ptr = &Wigner_6j_hats_G;
    
  switch (space_pair)
    {
    case PROTONS_ONLY:  BP_J_tables_dimensions_indices_pp_nn_alloc_calc (); break;
    case NEUTRONS_ONLY: BP_J_tables_dimensions_indices_pp_nn_alloc_calc (); break;
      
    case PROTONS_NEUTRONS:
      {
	if (last_particle == PROTON)
	  BP_J_tables_dimensions_indices_np_alloc_calc ();
	else if (last_particle == NEUTRON)
	  BP_J_tables_dimensions_indices_pn_alloc_calc ();
	else
	  error_message_print_abort ("The last particle is proton or neutron in RDM_PQG_class::allocate in proton-neutron space_pair");
	  
      } break;

    default: abort_all ();
    }

  const int Jmax_total_plus_one = matrix_dimensions.dimension (1);
        
  class array<unsigned int> block_matrix_dimensions(2*Jmax_total_plus_one);

  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J < Jmax_total_plus_one ; J++)
      block_matrix_dimensions(BP + 2*J) = matrix_dimensions(BP , J);
  
  block_matrix_abcd.allocate (block_matrix_dimensions);

  zero ();

  const unsigned int total_dimension = block_matrix_dimensions.sum ();

  block_matrix_abcd_array_helper.allocate (total_dimension);
}






void RDM_PQG_class::allocate_fill (const class RDM_PQG_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_PQG_class::allocate_fill");
  
  matrix_dimensions.allocate_fill (X.matrix_dimensions);
  
  two_states_indices.allocate_fill (X.two_states_indices);
    
  BP_table.allocate_fill (X.BP_table);
      
  Jmin_table.allocate_fill (X.Jmin_table);
  Jmax_table.allocate_fill (X.Jmax_table);
  
  is_it_in_space_tab.allocate_fill (X.is_it_in_space_tab);
  
  block_matrix_abcd.allocate_fill (X.block_matrix_abcd);

  block_matrix_abcd_array_helper.allocate_fill (X.block_matrix_abcd_array_helper);
        
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
  
  truncation_hw = X.truncation_hw;
  truncation_ph = X.truncation_ph;
  
  E_max_hw = X.E_max_hw;
  
  n_scat_max = X.n_scat_max;
  
  is_it_P = X.is_it_P;
  is_it_Q = X.is_it_Q;
  is_it_G = X.is_it_G;
  
  prot_data_ptr = X.prot_data_ptr;
  neut_data_ptr = X.neut_data_ptr;
  
  Wigner_6j_hats_G_ptr = X.Wigner_6j_hats_G_ptr;
}



void RDM_PQG_class::deallocate ()
{
  matrix_dimensions.deallocate ();
  
  two_states_indices.deallocate ();
      
  BP_table.deallocate ();
  
  Jmin_table.deallocate ();
  Jmax_table.deallocate ();
  
  is_it_in_space_tab.deallocate ();
  
  block_matrix_abcd.deallocate ();

  block_matrix_abcd_array_helper.deallocate ();
    
  T_MPI.deallocate ();
  
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
    
  truncation_hw = false;
  truncation_ph = false;
			       
  E_max_hw = 0;
  
  n_scat_max = 0;
  
  is_it_P = false;
  is_it_Q = false;
  is_it_G = false;
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_6j_hats_G_ptr = NULL;
}



void RDM_PQG_class::block_matrix_fill (const class block_matrix<TYPE> &X)
{
  block_matrix_abcd = X;
}

void RDM_PQG_class::random_positive_definite ()
{
  block_matrix_abcd.symmetric_random_matrix ();

  block_matrix_abcd /= block_matrix_abcd.get_dimension ();
  
  block_matrix_abcd.add_scalar_diagonal_part (1.0);
  
  block_matrix_abcd *= 0.001;
}

void RDM_PQG_class::operator = (const class RDM_PQG_class &X)
{
  block_matrix_abcd = X.block_matrix_abcd;
}


void RDM_PQG_class::operator += (const class RDM_PQG_class &X)
{
  block_matrix_abcd += X.block_matrix_abcd;
}

void RDM_PQG_class::operator -= (const class RDM_PQG_class &X)
{
  block_matrix_abcd -= X.block_matrix_abcd;
}

void RDM_PQG_class::add_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcd.add_scalar_diagonal_part (x);
}

void RDM_PQG_class::remove_scalar_diagonal_part (const TYPE &x)
{
  block_matrix_abcd.remove_scalar_diagonal_part (x);
}

void RDM_PQG_class::operator *= (const TYPE &x)
{
  block_matrix_abcd *= x;
}

void RDM_PQG_class::operator /= (const TYPE &x)
{
  block_matrix_abcd /= x;
}

void RDM_PQG_class::zero ()
{
  block_matrix_abcd.zero ();
}

void RDM_PQG_class::identity ()
{
  block_matrix_abcd.identity ();
}

void RDM_PQG_class::double_counting_scaling ()
{
  block_matrix_abcd *= 0.5;

  block_matrix_abcd.diagonal_part (block_matrix_abcd_array_helper);
  
  block_matrix_abcd.add_array_diagonal_part (block_matrix_abcd_array_helper);
}

void RDM_PQG_class::double_counting_removal ()
{
  block_matrix_abcd.diagonal_part (block_matrix_abcd_array_helper);

  block_matrix_abcd *= 2.0;

  block_matrix_abcd.remove_array_diagonal_part (block_matrix_abcd_array_helper);
}



unsigned int RDM_PQG_class::get_block_symmetric_matrix_elements_number () const
{
  const unsigned int blocks_number = block_matrix_abcd.get_blocks_number ();

  unsigned int block_symmetric_matrix_elements_number = 0;
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const unsigned int dimension_block = block_matrix_abcd(i).get_dimension ();
      
      block_symmetric_matrix_elements_number += (dimension_block%2 == 0) ? ((dimension_block/2)*(dimension_block + 1)) : (dimension_block*((dimension_block + 1)/2));
    }
  
  return block_symmetric_matrix_elements_number;
}


double RDM_PQG_class::infinite_norm () const
{
  return block_matrix_abcd.infinite_norm ();
}


void RDM_PQG_class::BP_J_tables_dimensions_indices_pp_nn_alloc_calc ()
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::BP_J_tables_dimensions_indices_pp_nn_alloc_calc");

  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_total = make_int (2.0*jmax);
      
  const int Jmax_total_plus_one = Jmax_total + 1;
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
          
  matrix_dimensions.allocate (2 , Jmax_total_plus_one);

  BP_table.allocate (N_nlj , N_nlj);  
  
  Jmin_table.allocate (N_nlj , N_nlj);
  Jmax_table.allocate (N_nlj , N_nlj);
  
  two_states_indices.allocate (Jmax_total_plus_one , N_nlj , N_nlj);
      
  is_it_in_space_tab.allocate (N_nlj , N_nlj);
  
  matrix_dimensions = 0;
    
  two_states_indices = two_states_indices.dimension_total ();
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {
	const class pair_str pair(sa , sb);
	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine  (shells_qn , shells_qn);
	
	const int E_hw = pair.E_hw_determine (shells_qn , shells_qn);

	const int n_scat = pair.n_scat_determine (shells_qn , shells_qn);
	
	const unsigned int BP = pair.bp_determine (shells_qn , shells_qn);
	
	const int Jmin = pair.Jmin_determine (shells_qn , shells_qn);
	const int Jmax = pair.Jmax_determine (shells_qn , shells_qn);
		
	const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));
	    
	is_it_in_space_tab(sa , sb) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	    	    
	BP_table(sa , sb) = BP;
		
	Jmin_table(sa , sb) = Jmin;
	Jmax_table(sa , sb) = Jmax;
      }

  if (is_it_P || is_it_Q)
    {
      for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	for (unsigned int sa = 0 ; sa <= sb ; sa++)
	  {
	    const unsigned int BP = BP_table(sa , sb);
	
	    const int Jmin = Jmin_table(sa , sb);
	    const int Jmax = Jmax_table(sa , sb);
	
	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		if (is_it_in_space_tab(sa , sb) && ((sa != sb) || (J%2 == 0))) two_states_indices(J , sa , sb) = matrix_dimensions(BP , J)++;
	      }
	  }
    }

  if (is_it_G)
    {
      for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  {
	    const unsigned int BP = BP_table(sa , sb);
	
	    const int Jmin = Jmin_table(sa , sb);
	    const int Jmax = Jmax_table(sa , sb);
	
	    for (int J = Jmin ; J <= Jmax ; J++)
	      {
		if (is_it_in_space_tab(sa , sb)) two_states_indices(J , sa , sb) = matrix_dimensions(BP , J)++;
	      }
	  }
    }
}













void RDM_PQG_class::BP_J_tables_dimensions_indices_pn_alloc_calc ()
{
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::BP_J_tables_dimensions_indices_pn_alloc_calc");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_total = make_int (jp_max + jn_max);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
              
  matrix_dimensions.allocate (2 , Jmax_total_plus_one);

  two_states_indices.allocate (Jmax_total_plus_one , Np_nlj , Nn_nlj);
  
  is_it_in_space_tab.allocate (Np_nlj , Nn_nlj);
  
  BP_table.allocate (Np_nlj , Nn_nlj);
    
  Jmin_table.allocate (Np_nlj , Nn_nlj);
  Jmax_table.allocate (Np_nlj , Nn_nlj);
      
  matrix_dimensions = 0;
      
  two_states_indices = two_states_indices.dimension_total ();
      
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine  (prot_shells_qn , neut_shells_qn);
	
	const int E_hw = pair.E_hw_determine (prot_shells_qn , neut_shells_qn);

	const int n_scat = pair.n_scat_determine (prot_shells_qn , neut_shells_qn);
	
	const unsigned int BP = pair.bp_determine (prot_shells_qn , neut_shells_qn);
	
	const int Jmin = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);
	const int Jmax = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
		
	const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));
					    
	is_it_in_space_tab(sa_p , sb_n) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
		
	BP_table(sa_p , sb_n) = BP;
	
	Jmin_table(sa_p , sb_n) = Jmin;
	Jmax_table(sa_p , sb_n) = Jmax;
	
	for (int J = Jmin ; J <= Jmax ; J++)
	  {
	    if (is_it_in_space_tab(sa_p , sb_n)) two_states_indices(J , sa_p , sb_n) = matrix_dimensions(BP , J)++;
	  }
      }
}




void RDM_PQG_class::BP_J_tables_dimensions_indices_np_alloc_calc ()
{
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::BP_J_tables_dimensions_indices_pn_alloc_calc");
      
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
    
  const int Jmax_total = make_int (jp_max + jn_max);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
              
  matrix_dimensions.allocate (2 , Jmax_total_plus_one);

  two_states_indices.allocate (Jmax_total_plus_one , Nn_nlj , Np_nlj);
  
  is_it_in_space_tab.allocate (Nn_nlj , Np_nlj);
  
  BP_table.allocate (Nn_nlj , Np_nlj);
    
  Jmin_table.allocate (Nn_nlj , Np_nlj);
  Jmax_table.allocate (Nn_nlj , Np_nlj);
      
  matrix_dimensions = 0;
      
  two_states_indices = two_states_indices.dimension_total ();
      
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {
	const class pair_str pair(sa_n , sb_p);
	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine  (neut_shells_qn , prot_shells_qn);
	
	const int E_hw = pair.E_hw_determine (neut_shells_qn , prot_shells_qn);

	const int n_scat = pair.n_scat_determine (neut_shells_qn , prot_shells_qn);
	
	const unsigned int BP = pair.bp_determine (neut_shells_qn , prot_shells_qn);
	
	const int Jmin = pair.Jmin_determine (neut_shells_qn , prot_shells_qn);
	const int Jmax = pair.Jmax_determine (neut_shells_qn , prot_shells_qn);
		
	const bool is_hw_condition_verified = (!truncation_hw || (E_hw <= E_max_hw));
	const bool is_ph_condition_verified = (!truncation_ph || (n_scat <= n_scat_max));
	    
	is_it_in_space_tab(sa_n , sb_p) = (!are_there_frozen_states && is_hw_condition_verified && is_ph_condition_verified);
	
	BP_table(sa_n , sb_p) = BP;
		
	Jmin_table(sa_n , sb_p) = Jmin;
	Jmax_table(sa_n , sb_p) = Jmax;
	
	for (int J = Jmin ; J <= Jmax ; J++)
	  {
	    if (is_it_in_space_tab(sa_n , sb_p)) two_states_indices(J , sa_n , sb_p) = matrix_dimensions(BP , J)++;
	  }
      }
}
  













void RDM_PQG_class::Q_pp_nn_block_matrices_add (
						const class array<TYPE> &rho_tab ,
						const class RDM_PQG_class &Gamma_pp_nn)
{
  if (!is_it_Q) error_message_print_abort ("One calculates Q in RDM_PQG_class::Q_pp_nn_block_matrices_add");

  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::Q_pp_nn_block_matrices_add");
  
  if (Gamma_pp_nn.get_space_pair () != space_pair) error_message_print_abort ("Gamma_pp_nn and Q must be both pp, nn or pn/np in RDM_PQG_class::Q_pp_nn_block_matrices_add");
    
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pp_nn = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      {
	const bool is_J_even = (J%2 == 0);
  
	const class matrix<TYPE> &Gamma_matrix_BP_J = Gamma_pp_nn_block_matrix(BP + 2*J);
	
	class matrix<TYPE> &Q_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    {
	      if (is_it_in_space_tab(sa , sb) && ((sa != sb) || is_J_even))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);

		  if (BP_ab == BP)
		    {
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
			  
			  const unsigned int ab_index_Gamma_pp_nn = two_states_indices_Gamma_pp_nn(J , sa , sb);
	 
			  const class nlj_struct &shell_qn_sa = shells_qn(sa);
			  const class nlj_struct &shell_qn_sb = shells_qn(sb);
  
			  const int ija = shell_qn_sa.get_ij ();
			  const int ijb = shell_qn_sb.get_ij ();
		      
			  const int phase_ab = (ija + ijb + J)%2 == 0 ? (1) : (-1);
		      
			  const double inv_delta_norm_ab = (sa == sb) ? (M_SQRT1_2) : (1.0);
		      
			  const double inv_delta_norm_ab_square = (sa == sb) ? (0.5) : (1.0);
		      
			  const double inv_delta_norm_ab_square_phase_ab = phase_ab*inv_delta_norm_ab_square;
			
			  for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			    for (unsigned int sc = 0 ; sc <= sd ; sc++)
			      {
				if (is_it_in_space_tab(sc , sd) && ((sc != sd) || is_J_even))
				  {
				    const class nlj_struct &shell_qn_sc = shells_qn(sc);
				    const class nlj_struct &shell_qn_sd = shells_qn(sd);
  
				    const int ijc = shell_qn_sc.get_ij ();
				    const int ijd = shell_qn_sd.get_ij ();
						
				    const bool sa_sc_jb_jd_equal = ((sa == sc) && (ijb == ijd));
				    const bool sb_sd_ja_jc_equal = ((sb == sd) && (ija == ijc));
				    const bool sa_sd_jb_jc_equal = ((sa == sd) && (ijb == ijc));
				    const bool sb_sc_ja_jd_equal = ((sb == sc) && (ija == ijd));

				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const double inv_delta_norm_cd = (sc == sd) ? (M_SQRT1_2) : (1.0);
						    
					    const unsigned int cd_index = two_states_indices(J , sc , sd);
	
					    const unsigned int cd_index_Gamma_pp_nn = two_states_indices_Gamma_pp_nn(J , sc , sd);
			  
					    TYPE Q_matrix_BP_J_ME = Gamma_matrix_BP_J(ab_index_Gamma_pp_nn , cd_index_Gamma_pp_nn);
					    					      
					    if (sa_sc_jb_jd_equal && sb_sd_ja_jc_equal) Q_matrix_BP_J_ME += inv_delta_norm_ab_square;
					    if (sa_sd_jb_jc_equal && sb_sc_ja_jd_equal) Q_matrix_BP_J_ME += inv_delta_norm_ab_square_phase_ab;
					
					    if (sa_sc_jb_jd_equal) Q_matrix_BP_J_ME -= inv_delta_norm_ab*inv_delta_norm_cd*rho_tab(sb , sd);
					    if (sb_sd_ja_jc_equal) Q_matrix_BP_J_ME -= inv_delta_norm_ab*inv_delta_norm_cd*rho_tab(sa , sc);
					    
					    if (sa_sd_jb_jc_equal) Q_matrix_BP_J_ME -= inv_delta_norm_ab*inv_delta_norm_cd*rho_tab(sb , sc)*minus_one_pow (ijc + ijd + J);
					    if (sb_sc_ja_jd_equal) Q_matrix_BP_J_ME -= inv_delta_norm_ab*inv_delta_norm_cd*rho_tab(sa , sd)*minus_one_pow (ijc + ijd + J);
								      
					    Q_matrix_BP_J(ab_index , cd_index) += Q_matrix_BP_J_ME;
				    
					  }}}}}}}}}
}






void RDM_PQG_class::Q_pn_block_matrices_add (
					     const class array<TYPE> &rho_prot_tab ,
					     const class array<TYPE> &rho_neut_tab ,
					     const class RDM_PQG_class &Gamma_pn)
{
  if (!is_it_Q) error_message_print_abort ("One calculates Q in RDM_PQG_class::Q_pn_block_matrices_add");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::Q_pn_block_matrices_add");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::Q_pn_block_matrices_add");
  
  if (Gamma_pn.get_space_pair () != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in Gamma_pn in RDM_PQG_class::Q_pn_block_matrices_add");
    
  if (Gamma_pn.get_last_particle () == PROTON) error_message_print_abort ("Neutron is the last particle in Gamma_pn in RDM_PQG_class::Q_pn_block_matrices_add");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
          
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
    
  add_scalar_diagonal_part (1.0);
	
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	const class matrix<TYPE> &Gamma_matrix_BP_J = Gamma_pn_block_matrix(BP + 2*J);
	
	class matrix<TYPE> &Q_matrix_BP_J = block_matrix_abcd(BP + 2*J);
  
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
			  const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
  
			  const int ija = shell_qn_sa.get_ij ();
			  const int ijb = shell_qn_sb.get_ij ();
			    
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
			  
			  const unsigned int ab_index_Gamma_pn = two_states_indices_Gamma_pn(J , sa_p , sb_n);
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
				    const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
  
				    const int ijc = shell_qn_sc.get_ij ();
				    const int ijd = shell_qn_sd.get_ij ();
				
				    const bool sa_sc_jb_jd_equal = ((sa_p == sc_p) && (ijb == ijd));
				    const bool sb_sd_ja_jc_equal = ((sb_n == sd_n) && (ija == ijc));
				
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);
  		      					
					    const unsigned int cd_index_Gamma_pn = two_states_indices_Gamma_pn(J , sc_p , sd_n);

					    TYPE Q_Gamma_BP_J_ME = Gamma_matrix_BP_J(ab_index_Gamma_pn , cd_index_Gamma_pn);
					    
					    if (sa_sc_jb_jd_equal) Q_Gamma_BP_J_ME -= rho_neut_tab(sb_n , sd_n);
					    if (sb_sd_ja_jc_equal) Q_Gamma_BP_J_ME -= rho_prot_tab(sa_p , sc_p);      
					    					    
					    Q_matrix_BP_J(ab_index , cd_index) += Q_Gamma_BP_J_ME;
					    
					  }}}}}}}}}
}




void RDM_PQG_class::G_pp_nn_block_matrices_add (
						const class array<TYPE> &rho_tab ,
						const class RDM_PQG_class &Gamma_pp_nn)
{
  if (!is_it_G) error_message_print_abort ("One calculates G in RDM_PQG_class::G_pp_nn_block_matrices_add");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::G_pp_nn_block_matrices_add");
    
  if (Gamma_pp_nn.get_space_pair () != space_pair) error_message_print_abort ("Gamma_pp_nn and Q must be both pp, nn or pn/np in RDM_PQG_class::G_pp_nn_block_matrices_add");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
    
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pp_nn = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_table_Gamma_pp_nn = Gamma_pp_nn.get_BP_table ();

  const class array<int> &Jmin_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      {      	
	class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	    {
	      if (is_it_in_space_tab(sa , sb))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
		    
			  const class nlj_struct &shell_qn_sa = shells_qn(sa);
			  const class nlj_struct &shell_qn_sb = shells_qn(sb);
  										  
			  const int ija = shell_qn_sa.get_ij ();
			  const int ijb = shell_qn_sb.get_ij ();
			
			  for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
			    for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			      {
				if (is_it_in_space_tab(sc , sd))
				  {
				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc , sd);

					    const unsigned int BPp = BP_table_Gamma_pp_nn(sa , sd);
					
					    const class nlj_struct &shell_qn_sc = shells_qn(sc);
					    const class nlj_struct &shell_qn_sd = shells_qn(sd);
					    				      
					    const int ijc = shell_qn_sc.get_ij ();
					    const int ijd = shell_qn_sd.get_ij ();
	      
					    const double delta_norm_ad = (sa == sd) ? (M_SQRT2) : (1.0);
					    const double delta_norm_cb = (sc == sb) ? (M_SQRT2) : (1.0);

					    const bool is_sa_smaller_than_sd = (sa <= sd);
					    const bool is_sc_smaller_than_sb = (sc <= sb);
					      
					    const bool are_sa_sd_equal = (sa == sd);
					    const bool are_sc_sb_equal = (sc == sb);

					    const bool ad_different_cb_different = (!are_sa_sd_equal && !are_sc_sb_equal);
					      
					    const int Jp_min_bc = Jmin_table_Gamma_pp_nn(sb , sc);	
					    const int Jp_max_bc = Jmax_table_Gamma_pp_nn(sb , sc);
				      
					    const int Jp_min_ad = Jmin_table_Gamma_pp_nn(sa , sd);	
					    const int Jp_max_ad = Jmax_table_Gamma_pp_nn(sa , sd);
				      
					    const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					    const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					  
					    TYPE G_matrix_BP_J_ME = ((sb == sd) && (ija == ijc)) ? (rho_tab(sa , sc)) : (0.0);
						  
					    TYPE G_matrix_BP_J_ME_part = 0.0;
					
					    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					      {
						const bool is_Jp_even = (Jp%2 == 0);
      
						if (ad_different_cb_different || is_Jp_even)
						  {
						    const unsigned int ad_index = (is_sa_smaller_than_sd) ? (two_states_indices_Gamma_pp_nn(Jp , sa , sd)) : (two_states_indices_Gamma_pp_nn(Jp , sd , sa));
						    const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_Gamma_pp_nn(Jp , sc , sb)) : (two_states_indices_Gamma_pp_nn(Jp , sb , sc));

						    const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BPp + 2*Jp);
			  
						    const int phase_ad = (is_sa_smaller_than_sd) ? (1) : (((ija + ijd + Jp)%2 == 0) ? (1) : (-1));
						    const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (((ijc + ijb + Jp)%2 == 0) ? (1) : (-1));
					  
						    const TYPE Gamma_pp_nn_ME = (phase_ad == phase_cb) ? (Gamma_pp_nn_matrix(ad_index , cb_index)) : (-Gamma_pp_nn_matrix(ad_index , cb_index));
					    
						    const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp);
		  
						    G_matrix_BP_J_ME_part -= Gamma_pp_nn_ME*Wigner_6j_hats;
						  }
					      } 

					    G_matrix_BP_J_ME_part *= delta_norm_ad*delta_norm_cb;
					      
					    G_matrix_BP_J_ME += G_matrix_BP_J_ME_part;
						  
					    G_matrix_BP_J(ab_index , cd_index) += G_matrix_BP_J_ME;
					      
					  }}}}}}}}}
}











void RDM_PQG_class::G_pn_block_matrices_add (
					     const class array<TYPE> &rho_prot_tab ,
					     const class RDM_PQG_class &Gamma_pn)
{
  if (!is_it_G) error_message_print_abort ("One calculates G in RDM_PQG_class::G_pn_block_matrices_add");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::G_pn_block_matrices_add");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::G_pn_block_matrices_add");
  
  if (Gamma_pn.get_space_pair () != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in Gamma_pn in RDM_PQG_class::G_pn_block_matrices_add");
    
  if (Gamma_pn.get_last_particle () == PROTON) error_message_print_abort ("Neutron is the last particle in Gamma_pn in RDM_PQG_class::G_pn_block_matrices_add");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
    
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_table_Gamma_pn = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
        
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      {      		
	class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
		    
			  const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
			  const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
  		      
			  const int ija = shell_qn_sa.get_ij ();
			  const int ijb = shell_qn_sb.get_ij ();
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);
			    
				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);
					    
					    const unsigned int BPp = BP_table_Gamma_pn(sa_p , sd_n);
 
					    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
					    const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
					    
					    const int ijc = shell_qn_sc.get_ij ();
					    const int ijd = shell_qn_sd.get_ij ();
				      
					    const int Jp_min_bc = Jmin_table_Gamma_pn(sc_p , sb_n);	
					    const int Jp_max_bc = Jmax_table_Gamma_pn(sc_p , sb_n);

					    const int Jp_min_ad = Jmin_table_Gamma_pn(sa_p , sd_n);	
					    const int Jp_max_ad = Jmax_table_Gamma_pn(sa_p , sd_n);
	      	
					    const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					    const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					      
					    TYPE G_matrix_BP_J_ME = ((sb_n == sd_n) && (ija == ijc)) ? (rho_prot_tab(sa_p , sc_p)) : (0.0);
						  
					    TYPE G_matrix_BP_J_ME_part = 0.0;
					
					    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					      {
						const unsigned int ad_index = two_states_indices_Gamma_pn(Jp , sa_p , sd_n);
						const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sc_p , sb_n);

						const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BPp + 2*Jp);
			  
						const TYPE Gamma_pn_ME = Gamma_pn_matrix(ad_index , cb_index);

						const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp);
		  		  
						G_matrix_BP_J_ME_part -= Gamma_pn_ME*Wigner_6j_hats;
					      }
						
					    G_matrix_BP_J_ME += G_matrix_BP_J_ME_part;
						
					    G_matrix_BP_J(ab_index , cd_index) += G_matrix_BP_J_ME;
					
					  }}}}}}}}}
}





void RDM_PQG_class::G_np_block_matrices_add (
					     const class array<TYPE> &rho_neut_tab ,
					     const class RDM_PQG_class &Gamma_pn)
{
  if (!is_it_G) error_message_print_abort ("One calculates G in RDM_PQG_class::G_np_block_matrices_add");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::G_np_block_matrices_add");
    
  if (last_particle == NEUTRON) error_message_print_abort ("Proton is the last particle in RDM_PQG_class::G_np_block_matrices_add");
  
  if (Gamma_pn.get_space_pair () != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in Gamma_pn in RDM_PQG_class::G_np_block_matrices_add");
    
  if (Gamma_pn.get_last_particle () == PROTON) error_message_print_abort ("Neutron is the last particle in Gamma_pn in RDM_PQG_class::G_np_block_matrices_add");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
    
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_table_Gamma_pn = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
          
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 	    
    for (int J = 0 ; J <= Jmax_total ; J++)
      {      	
	class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
      
	for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
	  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	    {
	      if (is_it_in_space_tab(sa_n , sb_p))
		{
		  const unsigned int BP_ab = BP_table(sa_n , sb_p);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_n , sb_p);	
		      const int Jmax_ab = Jmax_table(sa_n , sb_p);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_n , sb_p);
		      
			  const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
			  const class nlj_struct &shell_qn_sb = prot_shells_qn(sb_p);
  
			  const int ija = shell_qn_sa.get_ij ();
			  const int ijb = shell_qn_sb.get_ij ();
			
			  for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      {
				if (is_it_in_space_tab(sc_n , sd_p))
				  {
				    const unsigned int BP_cd = BP_table(sc_n , sd_p);
			    
				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_n , sd_p);	
					const int Jmax_cd = Jmax_table(sc_n , sd_p);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_n , sd_p);
	
					    const unsigned int BPp = BP_table_Gamma_pn(sd_p , sa_n);
					
					    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
					    const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    
					    const int ijc = shell_qn_sc.get_ij ();
					    const int ijd = shell_qn_sd.get_ij ();
				      
					    const int Jp_min_bc = Jmin_table_Gamma_pn(sb_p , sc_n);
					    const int Jp_max_bc = Jmax_table_Gamma_pn(sb_p , sc_n);

					    const int Jp_min_ad = Jmin_table_Gamma_pn(sd_p , sa_n);
					    const int Jp_max_ad = Jmax_table_Gamma_pn(sd_p , sa_n);

					    const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					    const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					      
					    const int phase_abcd = ((ija + ijb + ijc + ijd)%2 == 0) ? (1) : (-1);
							
					    TYPE G_matrix_BP_J_ME = ((sb_p == sd_p) && (ija == ijc)) ? (rho_neut_tab(sa_n , sc_n)) : (0.0);
						  					  	
					    TYPE G_matrix_BP_J_ME_part = 0.0;
										
					    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					      {
						const unsigned int ad_index = two_states_indices_Gamma_pn(Jp , sd_p , sa_n);
						const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sb_p , sc_n);

						const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BPp + 2*Jp);
			  
						const TYPE Gamma_pn_ME = (phase_abcd == 1) ? (Gamma_pn_matrix(ad_index , cb_index)) : (-Gamma_pn_matrix(ad_index , cb_index));
					    
						const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp);
		  
						G_matrix_BP_J_ME_part -= Gamma_pn_ME*Wigner_6j_hats;
					      }
					  			
					    G_matrix_BP_J_ME += G_matrix_BP_J_ME_part;
						
					    G_matrix_BP_J(ab_index , cd_index) += G_matrix_BP_J_ME;
					
					  }}}}}}}}}
}






void RDM_PQG_class::read_P_pp_nn_from_file (
					    const int Z ,
					    const int N ,
					    const unsigned int RDM_BP ,
					    const double RDM_J ,
					    const unsigned int RDM_vector_index)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::read_P_pp_nn_from_file");
  
  if (!is_it_P) error_message_print_abort ("One reads P in RDM_PQG_class::read_P_pp_nn_from_file");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::read_P_pp_nn_from_file");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  if (N_nlj == 0) return;
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (P_RDM_PP) : (P_RDM_NN);
      
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
    
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  class array<TYPE> P_pp_nn_RDM_array(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_total_plus_one);
  
  P_pp_nn_RDM_array.read_disk (infile_name);
	
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int J = 0 ; J <= Jmax_total ; J++)
      {
	const bool is_J_even = (J%2 == 0);
   
	class matrix<TYPE> &P_matrix_BP_J = block_matrix_abcd(BP + 2*J);
		
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    {
	      if (is_it_in_space_tab(sa , sb) && ((sa != sb) || is_J_even))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);
			  
		  if (BP_ab == BP)
		    {
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
			
			  for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			    for (unsigned int sc = 0 ; sc <= sd ; sc++)
			      {
				if (is_it_in_space_tab(sc , sd) && ((sc != sd) || is_J_even))
				  {
				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc , sd);

					    P_matrix_BP_J(ab_index , cd_index) = P_pp_nn_RDM_array(sa , sb , sc , sd , J);
				
					  }}}}}}}}}
}













void RDM_PQG_class::read_P_pn_from_file (
					 const int Z ,
					 const int N ,
					 const unsigned int RDM_BP ,
					 const double RDM_J ,
					 const unsigned int RDM_vector_index)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class:read_P_pn_from_file");
  
  if (!is_it_P) error_message_print_abort ("One reads P in RDM_PQG_class::read_P_pn_from_file");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class:read_P_pn_from_file");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::read_P_pn_from_file");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int Jmax_total_plus_one = Jmax_total + 1;
              
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (P_RDM_PN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  class array<TYPE> P_pn_RDM_array(Np_nlj , Nn_nlj , Np_nlj , Nn_nlj , Jmax_total_plus_one);
  
  P_pn_RDM_array.read_disk (infile_name);
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	class matrix<TYPE> &P_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);		      
					    					    
					    P_matrix_BP_J(ab_index , cd_index) = P_pn_RDM_array(sa_p , sb_n , sc_p , sd_n , J);
								      
					  }}}}}}}}}
}








void RDM_PQG_class::copy_P_pp_nn_to_file (
					  const int Z ,
					  const int N ,
					  const unsigned int RDM_BP ,
					  const double RDM_J ,
					  const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::copy_P_pp_nn_to_file");
  
  if (!is_it_P) error_message_print_abort ("One copies P in RDM_PQG_class::copy_P_pp_nn_to_file");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::copy_P_pp_nn_to_file");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  if (N_nlj == 0) return;
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (P_RDM_PP) : (P_RDM_NN);
      
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
      
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string outfile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  class array<TYPE> P_pp_nn_RDM_array(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_total_plus_one);

  P_pp_nn_RDM_array = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int J = 0 ; J <= Jmax_total ; J++)
      {
	const bool is_J_even = (J%2 == 0);
   
	const class matrix<TYPE> &P_matrix_BP_J = block_matrix_abcd(BP + 2*J);
		
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    {
	      if (is_it_in_space_tab(sa , sb) && ((sa != sb) || is_J_even))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);
			  
		  if (BP_ab == BP)
		    {
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
			
			  for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			    for (unsigned int sc = 0 ; sc <= sd ; sc++)
			      {
				if (is_it_in_space_tab(sc , sd) && ((sc != sd) || is_J_even))
				  {
				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc , sd);

					    P_pp_nn_RDM_array(sa , sb , sc , sd , J) = P_matrix_BP_J(ab_index , cd_index);
				
					  }}}}}}}}}
  
  P_pp_nn_RDM_array.copy_disk (outfile_name);
}








void RDM_PQG_class::copy_P_pn_to_file (
				       const int Z ,
				       const int N ,
				       const unsigned int RDM_BP ,
				       const double RDM_J ,
				       const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::copy_P_pn_to_file");
  
  if (!is_it_P) error_message_print_abort ("One copies P in RDM_PQG_class::copy_P_pn_to_file");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::copy_P_pn_to_file");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::copy_P_pn_to_file");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int Jmax_total_plus_one = Jmax_total + 1;
              
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (P_RDM_PN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string outfile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  class array<TYPE> P_pn_RDM_array(Np_nlj , Nn_nlj , Np_nlj , Nn_nlj , Jmax_total_plus_one);

  P_pn_RDM_array = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	const class matrix<TYPE> &P_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);		      
					    					    
					    P_pn_RDM_array(sa_p , sb_n , sc_p , sd_n , J) = P_matrix_BP_J(ab_index , cd_index);
								      
					  }}}}}}}}}
  
  P_pn_RDM_array.copy_disk (outfile_name);
}







void RDM_PQG_class::precision_Q_pp_nn_class_file_calc_print (
							     const int Z ,
							     const int N ,
							     const unsigned int RDM_BP ,
							     const double RDM_J ,
							     const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::print_precision_Q_pp_nn_class_file_calc_print");
  
  if (!is_it_Q) error_message_print_abort ("One considers Q in RDM_PQG_class::print_precision_Q_pp_nn_class_file_calc_print");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class::print_precision_Q_pp_nn_class_file_calc_print");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Proton is the last particle in RDM_PQG_class::print_precision_Q_pp_nn_class_file_calc_print with protons only");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::print_precision_Q_pp_nn_class_file_calc_print with neutrons only");
      
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  if (N_nlj == 0) return;
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (Q_RDM_PP) : (Q_RDM_NN);
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
        
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;
  
  ifstream infile(infile_name.c_str() , ios::binary);

  if (!infile) 
    {
      cout << "No file found for Q[" << space_pair << "] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> Q_pp_nn_RDM_array(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_total_plus_one);

  Q_pp_nn_RDM_array.read_disk (infile_name);

  double Q_pp_nn_precision = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      {
	const bool is_J_even = (J%2 == 0);
      
	const class matrix<TYPE> &Q_matrix_BP_J = block_matrix_abcd(BP + 2*J);
		
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  for (unsigned int sa = 0 ; sa <= sb ; sa++)
	    {
	      if (is_it_in_space_tab(sa , sb) && ((sa != sb) || is_J_even))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);
			  
		  if (BP_ab == BP)
		    {
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{			    
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
	 					
			  for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			    for (unsigned int sc = 0 ; sc <= sd ; sc++)
			      {
				if (is_it_in_space_tab(sc , sd) && ((sc != sd) || is_J_even))
				  {
				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc , sd);

					    Q_pp_nn_precision = max (Q_pp_nn_precision , abs (Q_matrix_BP_J(ab_index , cd_index) - Q_pp_nn_RDM_array(sa , sb , sc , sd , J)));
						  
					  }}}}}}}}}
  
  cout << "Q[" << space_pair << "] precision : " << Q_pp_nn_precision << endl;
}








void RDM_PQG_class::precision_Q_pn_class_file_calc_print (
							  const int Z ,
							  const int N ,
							  const unsigned int RDM_BP ,
							  const double RDM_J ,
							  const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::print_precision_Q_pn_class_file_calc_print");
  
  if (!is_it_Q) error_message_print_abort ("One considers Q in RDM_PQG_class::print_precision_Q_pn_class_file_calc_print");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::print_precision_Q_pn_class_file_calc_print");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::print_precision_Q_pn_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int Jmax_total_plus_one = Jmax_total + 1;

  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (Q_RDM_PN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);

  if (!infile) 
    {
      cout << "No file found for Q[pn] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> Q_pn_RDM_array(Np_nlj , Nn_nlj , Np_nlj , Nn_nlj , Jmax_total_plus_one);
  
  Q_pn_RDM_array.read_disk (infile_name);
  
  double Q_pn_precision = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	const class matrix<TYPE> &Q_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);	
					    
					    Q_pn_precision = max (Q_pn_precision , abs (Q_matrix_BP_J(ab_index , cd_index) - Q_pn_RDM_array(sa_p , sb_n , sc_p , sd_n , J)));
					      					    
					  }}}}}}}}}
  
  cout << "Q[pn] precision : " << Q_pn_precision << endl;
}












void RDM_PQG_class::precision_G_pp_nn_class_file_calc_print (
							     const int Z ,
							     const int N ,
							     const unsigned int RDM_BP ,
							     const double RDM_J ,
							     const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class_class::print_precision_G_pp_nn_class_file_calc_print");
  
  if (!is_it_G) error_message_print_abort ("One considers G in RDM_PQG_class::print_precision_G_pp_nn_class_file_calc_print");
  
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_PQG_class_class::print_precision_G_pp_nn_class_file_calc_print");
  
  if ((space_pair == PROTONS_ONLY) && (last_particle == NEUTRON)) error_message_print_abort ("Proton is the last particle in RDM_PQG_class_class::print_precision_G_pp_nn_class_file_calc_print with protons only");
      
  if ((space_pair == NEUTRONS_ONLY) && (last_particle == PROTON)) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class_class::print_precision_G_pp_nn_class_file_calc_print with neutrons only");
  
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  if (N_nlj == 0) return;
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = (space_pair == PROTONS_ONLY) ? (G_RDM_PP) : (G_RDM_NN);
  
  const double jmax = particles_data.get_jmax ();
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;
        
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);

  if (!infile) 
    {
      cout << "No file found for G[" << space_pair << "] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> G_pp_nn_RDM_array(N_nlj , N_nlj , N_nlj , N_nlj , Jmax_total_plus_one);

  G_pp_nn_RDM_array.read_disk (infile_name);
	
  double G_pp_nn_precision = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      {
	const class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
		
	for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	    {
	      if (is_it_in_space_tab(sa , sb))
		{
		  const unsigned int BP_ab = BP_table(sa , sb);
			  
		  if (BP_ab == BP)
		    {
		      const int Jmin_ab = Jmin_table(sa , sb);	
		      const int Jmax_ab = Jmax_table(sa , sb);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{			    
			  const unsigned int ab_index = two_states_indices(J , sa , sb);
			
			  for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
			    for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			      {
				if (is_it_in_space_tab(sc , sd))
				  {
				    const unsigned int BP_cd = BP_table(sc , sd);

				    if (BP_cd == BP)
				      {						  
					const int Jmin_cd = Jmin_table(sc , sd);	
					const int Jmax_cd = Jmax_table(sc , sd);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc , sd);

					    G_pp_nn_precision = max (G_pp_nn_precision , abs (G_matrix_BP_J(ab_index , cd_index) - G_pp_nn_RDM_array(sa , sb , sc , sd , J)));
					      				
					  }}}}}}}}}

  cout << "G[" << space_pair << "] precision : " << G_pp_nn_precision << endl;
}








void RDM_PQG_class::precision_G_pn_class_file_calc_print (
							  const int Z ,
							  const int N ,
							  const unsigned int RDM_BP ,
							  const double RDM_J ,
							  const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::print_precision_G_pn_class_file_calc_print");
  
  if (!is_it_G) error_message_print_abort ("One considers G in RDM_PQG_class::print_precision_G_pn_class_file_calc_print");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::print_precision_G_pn_class_file_calc_print");
    
  if (last_particle != NEUTRON) error_message_print_abort ("Neutron is the last particle in RDM_PQG_class::print_precision_G_pn_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int Jmax_total_plus_one = Jmax_total + 1;
              
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (G_RDM_PN);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);

  if (!infile) 
    {
      cout << "No file found for G[pn] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> G_pn_RDM_array(Np_nlj , Nn_nlj , Np_nlj , Nn_nlj , Jmax_total_plus_one);
  
  G_pn_RDM_array.read_disk (infile_name);
  
  double G_pn_precision = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	const class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	    {
	      if (is_it_in_space_tab(sa_p , sb_n))
		{
		  const unsigned int BP_ab = BP_table(sa_p , sb_n);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		      const int Jmax_ab = Jmax_table(sa_p , sb_n);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
			
			  for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			    for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			      {
				if (is_it_in_space_tab(sc_p , sd_n))
				  {
				    const unsigned int BP_cd = BP_table(sc_p , sd_n);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_p , sd_n);	
					const int Jmax_cd = Jmax_table(sc_p , sd_n);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);
				    
					    G_pn_precision = max (G_pn_precision , abs (G_matrix_BP_J(ab_index , cd_index) - G_pn_RDM_array(sa_p , sb_n , sc_p , sd_n , J)));
				    					    
					  }}}}}}}}}
  
  cout << "G[pn] precision : " << G_pn_precision << endl;
}









void RDM_PQG_class::precision_G_np_class_file_calc_print (
							  const int Z ,
							  const int N ,
							  const unsigned int RDM_BP ,
							  const double RDM_J ,
							  const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_PQG_class::print_precision_G_np_class_file_calc_print");
  
  if (!is_it_G) error_message_print_abort ("One considers G in RDM_PQG_class::print_precision_G_np_class_file_calc_print");
  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_PQG_class::print_precision_G_np_class_file_calc_print");
    
  if (last_particle != PROTON) error_message_print_abort ("Proton is the last particle in RDM_PQG_class::print_precision_G_np_class_file_calc_print");
    
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  if ((Np_nlj == 0) || (Nn_nlj == 0)) return;
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int Jmax_total_plus_one = Jmax_total + 1;
              
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (G_RDM_NP);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;

  ifstream infile(infile_name.c_str() , ios::binary);

  if (!infile) 
    {
      cout << "No file found for G[np] : precision test ignored " << endl;

      return;
    }
  
  class array<TYPE> G_np_RDM_array(Nn_nlj , Np_nlj , Nn_nlj , Np_nlj , Jmax_total_plus_one);
  
  G_np_RDM_array.read_disk (infile_name);
  
  double G_np_precision = 0.0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      {	
	const class matrix<TYPE> &G_matrix_BP_J = block_matrix_abcd(BP + 2*J);
    
	for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
	  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	    {
	      if (is_it_in_space_tab(sa_n , sb_p))
		{
		  const unsigned int BP_ab = BP_table(sa_n , sb_p);

		  if (BP_ab == BP)
		    {	
		      const int Jmin_ab = Jmin_table(sa_n , sb_p);	
		      const int Jmax_ab = Jmax_table(sa_n , sb_p);

		      if ((J >= Jmin_ab) && (J <= Jmax_ab))
			{
			  const unsigned int ab_index = two_states_indices(J , sa_n , sb_p);
			
			  for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
			    for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			      {
				if (is_it_in_space_tab(sc_n , sd_p))
				  {
				    const unsigned int BP_cd = BP_table(sc_n , sd_p);

				    if (BP_cd == BP)
				      {
					const int Jmin_cd = Jmin_table(sc_n , sd_p);	
					const int Jmax_cd = Jmax_table(sc_n , sd_p);

					const int Jmin = max (Jmin_ab , Jmin_cd);
					const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					if ((J >= Jmin) && (J <= Jmax))
					  {
					    const unsigned int cd_index = two_states_indices(J , sc_n , sd_p);
				    
					    G_np_precision = max (G_np_precision , abs (G_matrix_BP_J(ab_index , cd_index) - G_np_RDM_array(sa_n , sb_p , sc_n , sd_p , J)));
				    					    
					  }}}}}}}}}
  
  cout << "G[np] precision : " << G_np_precision << endl;
}







void RDM_PQG_class::make_it_positive_definite (
					       class block_matrix<TYPE> &P_transpose ,
					       class block_matrix<TYPE> &Dp_P_transpose)
{
  const unsigned int block_matrix_abcd_dimension = block_matrix_abcd.get_dimension ();

  if (block_matrix_abcd_dimension == 0) return;
    
  P_transpose = block_matrix_abcd;
  
  class array<TYPE> &block_matrix_abcd_eigenvalues = block_matrix_abcd_array_helper;

  P_transpose.symmetrize ();
    
  total_diagonalization::all_eigenpairs_Householder (P_transpose , block_matrix_abcd_eigenvalues);

  if (real_dc (block_matrix_abcd_eigenvalues(0)) >= 0.0) return;

  Dp_P_transpose = P_transpose;
  
  for (unsigned int i = 0 ; i < block_matrix_abcd_dimension ; i++) Dp_P_transpose.multiply_scalar_row_vector (i , delta_positive_real_part (block_matrix_abcd_eigenvalues(i)));
  
  class block_matrix<TYPE> &P = P_transpose;

  P.transpose ();

  block_matrix_multiplication (P , Dp_P_transpose , block_matrix_abcd);
}



#ifdef UseMPI

void RDM_PQG_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcd.get_blocks_number ();

  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  if (THIS_PROCESS == Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcd(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      T_MPI(index++) = block(ii , jj);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Bcast(send).");
    }
  
  T_MPI.MPI_Bcast (Send_process , MPI_C);
  
  if (THIS_PROCESS != Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcd(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Bcast(receive).");
    }
}

void RDM_PQG_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcd.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcd(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Reduce(send).");
  
  T_MPI.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  if (THIS_PROCESS == Recv_process)
    {      
      index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = block_matrix_abcd(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Reduce(receive).");
    }
}

void RDM_PQG_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcd.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcd(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Allreduce(send).");
  
  T_MPI.MPI_Allreduce (op , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcd(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Allreduce(receive).");
}

void RDM_PQG_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = block_matrix_abcd.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcd(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Allgatherv(send).");
  
  T_MPI.MPI_Allgatherv (group_processes_number , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = block_matrix_abcd(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_PQG_class::MPI_Allgatherv(receive).");
}

#endif




