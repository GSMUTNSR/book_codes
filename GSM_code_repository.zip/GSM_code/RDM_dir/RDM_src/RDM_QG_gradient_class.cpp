#include "../RDM_include/RDM_include_def.h"


// The trivial Gamma term is not included in Q.


RDM_QG_gradient_class::RDM_QG_gradient_class () :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_G_ptr (NULL) , 
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  QG_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL)
{}

RDM_QG_gradient_class::RDM_QG_gradient_class (
					      const enum space_type space_pair_c ,
					      const enum particle_type last_particle_c ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &QG ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_G_ptr (NULL) , 
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  QG_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL)
{
  alloc_calc_store (space_pair_c , last_particle_c , prot_data , neut_data , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , QG , Gamma_pp , Gamma_nn , Gamma_pn);
}

RDM_QG_gradient_class::RDM_QG_gradient_class (
					      const enum space_type space_pair_c ,
					      const enum particle_type last_particle_c ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &QG ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn) :
  space_pair (NO_SPACE) ,
  last_particle (NO_PARTICLE) ,
  prot_data_ptr (NULL) , 
  neut_data_ptr (NULL) , 
  Wigner_6j_hats_G_ptr (NULL) , 
  rho_prot_der_pp_tab_ptr (NULL) ,
  rho_prot_der_pn_tab_ptr (NULL) ,
  rho_neut_der_nn_tab_ptr (NULL) ,
  rho_neut_der_pn_tab_ptr (NULL) ,
  QG_ptr (NULL) ,
  Gamma_pp_ptr (NULL) ,
  Gamma_nn_ptr (NULL) ,
  Gamma_pn_ptr (NULL)
{
  alloc_calc_store (space_pair_c , last_particle_c , prot_data , neut_data , Wigner_6j_hats_G , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , QG , Gamma_pp , Gamma_nn , Gamma_pn);
}

void RDM_QG_gradient_class::alloc_calc_store (
					      const enum space_type space_pair_c ,
					      const enum particle_type last_particle_c ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &QG ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn) 
{
  if (is_it_filled ()) error_message_print_abort ("RDM_QG_gradient_class cannot be allocated twice in RDM_QG_gradient_class::allocate");
  
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
	    
  if ((space_pair == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in RDM_QG_gradient_class::allocate");
  if ((space_pair == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in RDM_QG_gradient_class::allocate");
    
  prot_data_ptr = &prot_data;
  neut_data_ptr = &neut_data;
  
  Wigner_6j_hats_G_ptr = NULL;
    
  rho_prot_der_pp_tab_ptr = &rho_prot_der_pp_tab; 
  rho_prot_der_pn_tab_ptr = &rho_prot_der_pn_tab;  
  rho_neut_der_nn_tab_ptr = &rho_neut_der_nn_tab;   
  rho_neut_der_pn_tab_ptr = &rho_neut_der_pn_tab;    

  QG_ptr = &QG;
  
  Gamma_pp_ptr = &Gamma_pp;
  Gamma_nn_ptr = &Gamma_nn;
  Gamma_pn_ptr = &Gamma_pn;
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  const unsigned int dimension_pp_BP_J_max =  matrix_dimensions_pp.max ();
  const unsigned int dimension_nn_BP_J_max =  matrix_dimensions_nn.max ();
  const unsigned int dimension_pn_BP_J_max =  matrix_dimensions_pn.max ();
  
  const unsigned int triangular_sup_pp_MEs_number_max = (dimension_pp_BP_J_max%2 == 0) ? ((dimension_pp_BP_J_max/2)*(dimension_pp_BP_J_max + 1)) : (dimension_pp_BP_J_max*((dimension_pp_BP_J_max + 1)/2));
  const unsigned int triangular_sup_nn_MEs_number_max = (dimension_nn_BP_J_max%2 == 0) ? ((dimension_nn_BP_J_max/2)*(dimension_nn_BP_J_max + 1)) : (dimension_nn_BP_J_max*((dimension_nn_BP_J_max + 1)/2));
  const unsigned int triangular_sup_pn_MEs_number_max = (dimension_pn_BP_J_max%2 == 0) ? ((dimension_pn_BP_J_max/2)*(dimension_pn_BP_J_max + 1)) : (dimension_pn_BP_J_max*((dimension_pn_BP_J_max + 1)/2));
	
  switch (space_pair)
    {
    case PROTONS_ONLY:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , Jmax_pp_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_pp_total_plus_one);
	
	QG_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
	
	QG_pp_nn_block_matrices_gradients_alloc_calc_store (true , false);
      } break;
      
    case NEUTRONS_ONLY:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , Jmax_nn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_nn_total_plus_one);
	
	QG_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
  
	QG_pp_nn_block_matrices_gradients_alloc_calc_store (true , false);
      } break;

    case PROTONS_NEUTRONS:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	
	QG_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
	QG_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
	
	QG_pn_np_block_matrices_gradients_alloc_calc_store (true , false);
	
      } break;
      
    default: abort_all ();
    }
  
  QG_gradient_block_matrices_non_trivial_zero_numbers_pp.deallocate ();
  QG_gradient_block_matrices_non_trivial_zero_numbers_nn.deallocate ();
  QG_gradient_block_matrices_non_trivial_zero_numbers_pn.deallocate ();
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_6j_hats_G_ptr = NULL;
  
  rho_prot_der_pp_tab_ptr = NULL;
  rho_prot_der_pn_tab_ptr = NULL;
  rho_neut_der_nn_tab_ptr = NULL;
  rho_neut_der_pn_tab_ptr = NULL;

  QG_ptr = NULL;
  
  Gamma_pp_ptr = NULL;
  Gamma_nn_ptr = NULL;
  Gamma_pn_ptr = NULL;
}





void RDM_QG_gradient_class::alloc_calc_store (
					      const enum space_type space_pair_c ,
					      const enum particle_type last_particle_c ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G ,
					      const class array<double> &rho_prot_der_pp_tab ,
					      const class array<double> &rho_prot_der_pn_tab ,
					      const class array<double> &rho_neut_der_nn_tab ,
					      const class array<double> &rho_neut_der_pn_tab ,
					      const class RDM_PQG_class &QG ,
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn) 
{
  if (is_it_filled ()) error_message_print_abort ("RDM_QG_gradient_class cannot be allocated twice in RDM_QG_gradient_class::allocate");
  
  space_pair = space_pair_c;
  
  last_particle = last_particle_c;
	    
  if ((space_pair == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in RDM_QG_gradient_class::allocate");
  if ((space_pair == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in RDM_QG_gradient_class::allocate");
    
  prot_data_ptr = &prot_data;
  neut_data_ptr = &neut_data;
  
  Wigner_6j_hats_G_ptr = &Wigner_6j_hats_G;
    
  rho_prot_der_pp_tab_ptr = &rho_prot_der_pp_tab; 
  rho_prot_der_pn_tab_ptr = &rho_prot_der_pn_tab;  
  rho_neut_der_nn_tab_ptr = &rho_neut_der_nn_tab;   
  rho_neut_der_pn_tab_ptr = &rho_neut_der_pn_tab;    

  QG_ptr = &QG;
  
  Gamma_pp_ptr = &Gamma_pp;
  Gamma_nn_ptr = &Gamma_nn;
  Gamma_pn_ptr = &Gamma_pn;
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  const unsigned int dimension_pp_BP_J_max = matrix_dimensions_pp.max ();
  const unsigned int dimension_nn_BP_J_max = matrix_dimensions_nn.max ();
  const unsigned int dimension_pn_BP_J_max = matrix_dimensions_pn.max ();
  
  const unsigned int triangular_sup_pp_MEs_number_max = (dimension_pp_BP_J_max%2 == 0) ? ((dimension_pp_BP_J_max/2)*(dimension_pp_BP_J_max + 1)) : (dimension_pp_BP_J_max*((dimension_pp_BP_J_max + 1)/2));
  const unsigned int triangular_sup_nn_MEs_number_max = (dimension_nn_BP_J_max%2 == 0) ? ((dimension_nn_BP_J_max/2)*(dimension_nn_BP_J_max + 1)) : (dimension_nn_BP_J_max*((dimension_nn_BP_J_max + 1)/2));
  const unsigned int triangular_sup_pn_MEs_number_max = (dimension_pn_BP_J_max%2 == 0) ? ((dimension_pn_BP_J_max/2)*(dimension_pn_BP_J_max + 1)) : (dimension_pn_BP_J_max*((dimension_pn_BP_J_max + 1)/2));
	
  switch (space_pair)
    {
    case PROTONS_ONLY:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , Jmax_pp_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_pp_total_plus_one);
	
	QG_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
	
	QG_pp_nn_block_matrices_gradients_alloc_calc_store (false , true);
      } break;
      
    case NEUTRONS_ONLY:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , Jmax_nn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_nn_total_plus_one);
	
	QG_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
  
	QG_pp_nn_block_matrices_gradients_alloc_calc_store (false , true);
      } break;

    case PROTONS_NEUTRONS:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max , 2 , Jmax_pn_total_plus_one);
	
	QG_gradient_block_matrices_pp.allocate (2 , Jmax_pp_total_plus_one , triangular_sup_pp_MEs_number_max);
	QG_gradient_block_matrices_nn.allocate (2 , Jmax_nn_total_plus_one , triangular_sup_nn_MEs_number_max);
	QG_gradient_block_matrices_pn.allocate (2 , Jmax_pn_total_plus_one , triangular_sup_pn_MEs_number_max);

	QG_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
	QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
	
	QG_pn_np_block_matrices_gradients_alloc_calc_store (false , true);
	
      } break;
      
    default: abort_all ();
    }
  
  QG_gradient_block_matrices_non_trivial_zero_numbers_pp.deallocate ();
  QG_gradient_block_matrices_non_trivial_zero_numbers_nn.deallocate ();
  QG_gradient_block_matrices_non_trivial_zero_numbers_pn.deallocate ();
  
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;
  
  Wigner_6j_hats_G_ptr = NULL;
  
  rho_prot_der_pp_tab_ptr = NULL;
  rho_prot_der_pn_tab_ptr = NULL;
  rho_neut_der_nn_tab_ptr = NULL;
  rho_neut_der_pn_tab_ptr = NULL;

  QG_ptr = NULL;
  
  Gamma_pp_ptr = NULL;
  Gamma_nn_ptr = NULL;
  Gamma_pn_ptr = NULL;  
}

RDM_QG_gradient_class::RDM_QG_gradient_class (const class RDM_QG_gradient_class &X)
{
  allocate_fill (X);
}

RDM_QG_gradient_class::~RDM_QG_gradient_class () {}





void RDM_QG_gradient_class::allocate_fill (const class RDM_QG_gradient_class &X)
{        
  if (is_it_filled ()) error_message_print_abort ("RDM_QG_gradient_class cannot be allocated twice in RDM_QG_gradient_class::allocate_fill");
  
  QG_gradient_block_matrices_pp.allocate_fill_object_elements (X.QG_gradient_block_matrices_pp);
  QG_gradient_block_matrices_nn.allocate_fill_object_elements (X.QG_gradient_block_matrices_nn);
  QG_gradient_block_matrices_pn.allocate_fill_object_elements (X.QG_gradient_block_matrices_pn);
    
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}



void RDM_QG_gradient_class::deallocate ()
{        
  QG_gradient_block_matrices_pp.deallocate ();
  QG_gradient_block_matrices_nn.deallocate ();
  QG_gradient_block_matrices_pn.deallocate ();
    
  space_pair = NO_SPACE;
  
  last_particle = NO_PARTICLE;
}




void RDM_QG_gradient_class::operator = (const class RDM_QG_gradient_class &X)
{        
  QG_gradient_block_matrices_pp = X.QG_gradient_block_matrices_pp;
  QG_gradient_block_matrices_nn = X.QG_gradient_block_matrices_nn;
  QG_gradient_block_matrices_pn = X.QG_gradient_block_matrices_pn;
    
  space_pair = X.space_pair;
  
  last_particle = X.last_particle;
}



void RDM_QG_gradient_class::rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
										    const enum particle_type particle ,
										    const unsigned int BP ,
										    const int J ,
										    const unsigned int s0 ,
										    const unsigned int s1)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data ());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &QG_gradient_block_matrices_non_trivial_zero_numbers = get_QG_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
  
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {			    
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(s0 , sp);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(s1 , sp);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
      
      const unsigned int BPp = BP_table(s0 , sp);

      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);
      
      const int Jmin_s0_sp = Jmin_table(s0 , sp) , Jmin_s1_sp = Jmin_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_table(s0 , sp) , Jmax_s1_sp = Jmax_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
            
      const bool are_s0_sp_equal = (s0 == sp);
      const bool are_s1_sp_equal = (s1 == sp);
              
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
      
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);

	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      QG_gradient_block_matrices_non_trivial_zero_numbers(BPp , Jp , ip_jp_upper_triangular_index , BP , J)++;
	    }
	}
    }
}







void RDM_QG_gradient_class::rho_term_der_pp_nn_fill_part (
							  const enum particle_type particle ,
							  const unsigned int BP ,
							  const int J ,
							  const unsigned int ab_index ,
							  const unsigned int cd_index ,
							  const int ij01 ,
							  const unsigned int s0 ,
							  const unsigned int s1 ,
							  const double factor)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (get_prot_data ()) : (get_neut_data());
  
  const enum space_type Gamma_space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const class array<double> &rho_der_tab = (particle == PROTON) ? (get_rho_prot_der_pp_tab ()) : (get_rho_neut_der_nn_tab ());
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<bool> &is_it_in_space_tab = Gamma_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Gamma_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  class array<unsigned short int> &QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_QG_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);
  
  class array<class block_sparse_matrix<TYPE> > &QG_gradient_block_matrices_pp_nn = get_QG_gradient_block_matrices (Gamma_space);
    
  for (unsigned int sp = 0 ; sp < N_nlj ; sp++)
    {		    
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(s0 , sp);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(s1 , sp);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
      
      const unsigned int BPp = BP_table(s0 , sp);

      const class nlj_struct &shell_qn_sp = shells_qn(sp);
			  
      const int ijp = shell_qn_sp.get_ij ();
      
      const unsigned s0_sp_min = min (s0 , sp) , s1_sp_min = min (s1 , sp);
      const unsigned s0_sp_max = max (s0 , sp) , s1_sp_max = max (s1 , sp);
      
      const int Jmin_s0_sp = Jmin_table(s0 , sp) , Jmin_s1_sp = Jmin_table(s1 , sp) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_table(s0 , sp) , Jmax_s1_sp = Jmax_table(s1 , sp) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
            
      const bool are_s0_sp_equal = (s0 == sp) , is_s0_smaller_than_sp = (s0 <= sp);
      const bool are_s1_sp_equal = (s1 == sp) , is_s1_smaller_than_sp = (s1 <= sp);
       
      const bool s0_sp_different_s1_sp_different = (!are_s0_sp_equal && !are_s1_sp_equal);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const bool is_Jp_even = (Jp%2 == 0);

	  if (is_Jp_even || s0_sp_different_s1_sp_different)
	    {
	      const unsigned int ip = two_states_indices(Jp , s0_sp_min , s0_sp_max);
	      const unsigned int jp = two_states_indices(Jp , s1_sp_min , s1_sp_max);
	      	  
	      const unsigned int ip_jp_min = min (ip , jp);
	      const unsigned int ip_jp_max = max (ip , jp);
	      
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	      const int phase_s0_sp = (is_s0_smaller_than_sp) ? (1) : (((ij01 + ijp + Jp)%2 == 0) ? (1) : (-1));
	      const int phase_s1_sp = (is_s1_smaller_than_sp) ? (1) : (((ij01 + ijp + Jp)%2 == 0) ? (1) : (-1));
	      
	      const double rho_der_ME = rho_der_tab(Jp , s0 , sp , s1);
      
	      const double gradient_ME = (phase_s0_sp == phase_s1_sp) ? (factor*rho_der_ME) : (-factor*rho_der_ME);
		  
	      class block_sparse_matrix<TYPE> &QG_gradient_block_matrix = QG_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	      class sparse_matrix<TYPE> &QG_gradient_matrix = QG_gradient_block_matrix(BP + 2*J);
      
	      unsigned short int &ip_jp_index = QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
	      
	      QG_gradient_matrix.get_row_index      (ip_jp_index) = ab_index;
	      QG_gradient_matrix.get_column_index   (ip_jp_index) = cd_index;
	      QG_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;
	      
	      ip_jp_index++;
	    }
	}
    }
}






void RDM_QG_gradient_class::rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
										      const unsigned int BP ,
										      const int J ,
										      const unsigned int s0_p ,
										      const unsigned int s1_p)
{  
  const class nucleons_data &neut_data = get_neut_data ();
    
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {		
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(s1_p , sp_n);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
      
      const unsigned int BPp = BP_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J)++;
	}
    }
}



void RDM_QG_gradient_class::rho_prot_term_der_pn_fill_part (
							    const unsigned int BP ,
							    const int J ,
							    const unsigned int ab_index ,
							    const unsigned int cd_index ,
							    const unsigned int s0_p ,
							    const unsigned int s1_p ,
							    const double factor)
{
  const class nucleons_data &neut_data = get_neut_data ();
    
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<double> &rho_prot_der_pn_tab = get_rho_prot_der_pn_tab ();
  
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    	  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_n = 0 ; sp_n < Nn_nlj ; sp_n++)
    {			 
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(s0_p , sp_n);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(s1_p , sp_n);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
      
      const unsigned int BPp = BP_table(s0_p , sp_n);

      const int Jmin_s0_sp = Jmin_pn_table(s0_p , sp_n) , Jmin_s1_sp = Jmin_pn_table(s1_p , sp_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_table(s0_p , sp_n) , Jmax_s1_sp = Jmax_pn_table(s1_p , sp_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      	  
	  const unsigned int ip = two_states_indices_pn(Jp , s0_p , sp_n);
	  const unsigned int jp = two_states_indices_pn(Jp , s1_p , sp_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_prot_der_pn_tab(Jp , s0_p , sp_n , s1_p);
	  	      
	  class block_sparse_matrix<TYPE> &QG_gradient_block_matrix_pn = QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &QG_gradient_matrix_pn = QG_gradient_block_matrix_pn(BP + 2*J);
      
	  unsigned short int &ip_jp_index = QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
			  
	  QG_gradient_matrix_pn.get_row_index      (ip_jp_index) = ab_index;
	  QG_gradient_matrix_pn.get_column_index   (ip_jp_index) = cd_index;
	  QG_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }
}







void RDM_QG_gradient_class::rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
										      const unsigned int BP ,
										      const int J ,
										      const unsigned int s0_n ,
										      const unsigned int s1_n)
{
  const class nucleons_data &prot_data = get_prot_data ();
    
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			    
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(sp_p , s1_n);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
            
      const unsigned int BPp = BP_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J)++;	      
	}
    }
}



void RDM_QG_gradient_class::rho_neut_term_der_pn_fill_part (
							    const unsigned int BP ,
							    const int J ,
							    const unsigned int ab_index ,
							    const unsigned int cd_index ,
							    const unsigned int s0_n ,
							    const unsigned int s1_n ,
							    const double factor)
{
  const class nucleons_data &prot_data = get_prot_data ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();  
  
  const class array<bool> &is_it_in_space_tab = Gamma_pn.get_is_it_in_space_tab ();
  
  const class array<double> &rho_neut_der_pn_tab = get_rho_neut_der_pn_tab ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
    
  const class array<unsigned int> &BP_table = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_pn_table = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_pn_table = Gamma_pn.get_Jmax_table ();
  
  for (unsigned int sp_p = 0 ; sp_p < Np_nlj ; sp_p++)
    {			    
      const unsigned int is_it_in_space_s0_sp = is_it_in_space_tab(sp_p , s0_n);
      const unsigned int is_it_in_space_s1_sp = is_it_in_space_tab(sp_p , s1_n);

      if (!is_it_in_space_s0_sp || !is_it_in_space_s1_sp) continue;
      
      const unsigned int BPp = BP_table(sp_p , s0_n);

      const int Jmin_s0_sp = Jmin_pn_table(sp_p , s0_n) , Jmin_s1_sp = Jmin_pn_table(sp_p , s1_n) , Jp_min = max (Jmin_s0_sp , Jmin_s1_sp);
      const int Jmax_s0_sp = Jmax_pn_table(sp_p , s0_n) , Jmax_s1_sp = Jmax_pn_table(sp_p , s1_n) , Jp_max = min (Jmax_s0_sp , Jmax_s1_sp);
	  
      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	{	      	  
	  const unsigned int ip = two_states_indices_pn(Jp , sp_p , s0_n);
	  const unsigned int jp = two_states_indices_pn(Jp , sp_p , s1_n);
      
	  const unsigned int ip_jp_min = min (ip , jp);
	  const unsigned int ip_jp_max = max (ip , jp);
	      
	  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      
	  const double gradient_ME = factor*rho_neut_der_pn_tab(Jp , s0_n , sp_p , s1_n);
	      
	  class block_sparse_matrix<TYPE> &QG_gradient_block_matrix_pn = QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	  
	  class sparse_matrix<TYPE> &QG_gradient_matrix_pn = QG_gradient_block_matrix_pn(BP + 2*J);
      
	  unsigned short int &ip_jp_index = QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
			  
	  QG_gradient_matrix_pn.get_row_index      (ip_jp_index) = ab_index;
	  QG_gradient_matrix_pn.get_column_index   (ip_jp_index) = cd_index;
	  QG_gradient_matrix_pn.get_matrix_element (ip_jp_index) = gradient_ME;

	  ip_jp_index++;
	}
    }     
}


void RDM_QG_gradient_class::rho_term_der_part_determine (
							 const enum operation_type operation ,
							 const unsigned int BP ,
							 const int J ,
							 const unsigned int ab_index ,
							 const unsigned int cd_index ,
							 const enum particle_type particle ,
							 const int ij01 ,
							 const unsigned int s0 , 
							 const unsigned int s1 ,
							 const double factor)
{
  switch (operation)
    {
    case DIMENSIONS_TABLES_CALC:
      {
	rho_term_der_pp_nn_non_trivial_zero_numbers_increments (particle , BP , J , s0 , s1);

	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_non_trivial_zero_numbers_increments (BP , J , s0 , s1); break;
	  case NEUTRON: rho_neut_term_der_pn_non_trivial_zero_numbers_increments (BP , J , s0 , s1); break;

	  default: abort_all ();
	  }
							    
      } break;

    case TABLES_FILL:
      {
	rho_term_der_pp_nn_fill_part (particle , BP , J , ab_index , cd_index , ij01 , s0 , s1 , factor);
							    
	switch (particle)
	  {
	  case PROTON:  rho_prot_term_der_pn_fill_part (BP , J , ab_index , cd_index , s0 , s1 , factor); break;
	  case NEUTRON: rho_neut_term_der_pn_fill_part (BP , J , ab_index , cd_index , s0 , s1 , factor); break;
								
	  default: abort_all ();
	  }
							    
      } break;

    default: abort_all ();
    }
}








void RDM_QG_gradient_class::QG_Gamma_term_der_part_determine (
							      const enum operation_type operation ,
							      const enum space_type Gamma_space , 
							      const unsigned int BP ,
							      const int J ,
							      const unsigned int ab_index ,
							      const unsigned int cd_index ,
							      const unsigned int BPp ,
							      const int Jp ,
							      const unsigned int ip ,
							      const unsigned int jp ,
							      const double gradient_ME)
{
  const unsigned int ip_jp_min = min (ip , jp);
  const unsigned int ip_jp_max = max (ip , jp);
	      
  const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip_jp_min , ip_jp_max);
	      	      
  class array<unsigned short int> &QG_gradient_block_matrices_non_trivial_zero_numbers_local = get_QG_gradient_block_matrices_non_trivial_zero_numbers (Gamma_space);

  switch (operation)
    {	    
    case DIMENSIONS_TABLES_CALC:
      {
	QG_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , J)++;
							    
      } break;

    case TABLES_FILL:
      {
	class array<class block_sparse_matrix<TYPE> > &QG_gradient_block_matrices_local = get_QG_gradient_block_matrices (Gamma_space);
	
	class block_sparse_matrix<TYPE> &QG_gradient_block_matrix = QG_gradient_block_matrices_local(BPp , Jp , ip_jp_upper_triangular_index);
	
	class sparse_matrix<TYPE> &QG_gradient_matrix = QG_gradient_block_matrix(BP + 2*J);

	unsigned short int &ip_jp_index = QG_gradient_block_matrices_non_trivial_zero_numbers_local(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
						
	QG_gradient_matrix.get_row_index      (ip_jp_index) = ab_index;
	QG_gradient_matrix.get_column_index   (ip_jp_index) = cd_index;
	QG_gradient_matrix.get_matrix_element (ip_jp_index) = gradient_ME;
		  
	ip_jp_index++;
	
      } break;

    default: abort_all ();
    }
}



								


void RDM_QG_gradient_class::Q_pp_nn_block_matrices_gradients_calc_store (const enum operation_type operation)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_QG_gradient_class::Q_pp_nn_block_matrices_gradients_calc_store");
      
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
      
  const class RDM_PQG_class &Q_pp_nn = get_QG ();

  const class array<bool> &is_it_in_space_tab = Q_pp_nn.get_is_it_in_space_tab ();
      
  const class array<unsigned int> &BP_table = Q_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = Q_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = Q_pp_nn.get_Jmax_table ();
  
  const class array<unsigned int> &two_states_indices = Q_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &matrix_dimensions = Q_pp_nn.get_matrix_dimensions ();
  
  const enum particle_type particle = particles_data.get_particle ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  for (int J = 0 ; J <= Jmax_total ; J++)
    {
      const bool is_J_even = (J%2 == 0);
  
      for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
	{  
	  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	    for (unsigned int sa = 0 ; sa <= sb ; sa++)
	      {
		if (is_it_in_space_tab(sa , sb) && ((sa != sb) || is_J_even))
		  {
		    const unsigned int BP_ab = BP_table(sa , sb);

		    if (BP_ab == BP)
		      {
			const int Jmin_ab = Jmin_table(sa , sb);	
			const int Jmax_ab = Jmax_table(sa , sb);

			if ((J >= Jmin_ab) && (J <= Jmax_ab))
			  {
			    const unsigned int ab_index = two_states_indices(J , sa , sb);
		  
			    const class nlj_struct &shell_qn_sa = shells_qn(sa);
			    const class nlj_struct &shell_qn_sb = shells_qn(sb);
  
			    const int ija = shell_qn_sa.get_ij ();
			    const int ijb = shell_qn_sb.get_ij ();
		      
			    const double inv_delta_norm_ab = (sa == sb) ? (M_SQRT1_2) : (1.0);
		      		      		      		      
			    for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			      for (unsigned int sc = 0 ; sc <= sd ; sc++)
				{
				  if (is_it_in_space_tab(sc , sd) && ((sc != sd) || is_J_even))
				    {
				      const class nlj_struct &shell_qn_sc = shells_qn(sc);
				      const class nlj_struct &shell_qn_sd = shells_qn(sd);
  
				      const int ijc = shell_qn_sc.get_ij ();
				      const int ijd = shell_qn_sd.get_ij ();
						  
				      const bool sa_sc_jb_jd_equal = ((sa == sc) && (ijb == ijd));
				      const bool sb_sd_ja_jc_equal = ((sb == sd) && (ija == ijc));
				      const bool sa_sd_jb_jc_equal = ((sa == sd) && (ijb == ijc));
				      const bool sb_sc_ja_jd_equal = ((sb == sc) && (ija == ijd));

				      const unsigned int BP_cd = BP_table(sc , sd);

				      if (BP_cd == BP)
					{
					  const int Jmin_cd = Jmin_table(sc , sd);	
					  const int Jmax_cd = Jmax_table(sc , sd);

					  const int Jmin = max (Jmin_ab , Jmin_cd);
					  const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
					  if ((J >= Jmin) && (J <= Jmax))
					    {
					      const unsigned int cd_index = two_states_indices(J , sc , sd);
					      
					      if (sa_sc_jb_jd_equal || sb_sd_ja_jc_equal || sa_sd_jb_jc_equal || sb_sc_ja_jd_equal)
						{
						  const double inv_delta_norm_cd = (sc == sd) ? (M_SQRT1_2) : (1.0);

						  const double factor_sa_sc_jb_jd_equal = (sa_sc_jb_jd_equal) ? (-inv_delta_norm_ab*inv_delta_norm_cd)                               : (NADA);
						  const double factor_sb_sd_ja_jc_equal = (sb_sd_ja_jc_equal) ? (-inv_delta_norm_ab*inv_delta_norm_cd)                               : (NADA);
						  const double factor_sa_sd_jb_jc_equal = (sa_sd_jb_jc_equal) ? (-inv_delta_norm_ab*inv_delta_norm_cd*minus_one_pow (ijc + ijd + J)) : (NADA);
						  const double factor_sb_sc_ja_jd_equal = (sb_sc_ja_jd_equal) ? (-inv_delta_norm_ab*inv_delta_norm_cd*minus_one_pow (ijc + ijd + J)) : (NADA);
						  
						  if (sa_sc_jb_jd_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , particle , ijb , sb , sd , factor_sa_sc_jb_jd_equal);
						  if (sb_sd_ja_jc_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , particle , ija , sa , sc , factor_sb_sd_ja_jc_equal);
						  if (sa_sd_jb_jc_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , particle , ijb , sb , sc , factor_sa_sd_jb_jc_equal);
						  if (sb_sc_ja_jd_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , particle , ija , sa , sd , factor_sb_sc_ja_jd_equal);
						}
					      
					      QG_Gamma_term_der_part_determine (operation , space_pair , BP , J , ab_index , cd_index , BP , J , ab_index , cd_index , 1.0);
					      
					    }}}}}}}}}}
}









void RDM_QG_gradient_class::Q_pn_block_matrices_gradients_calc_store (const enum operation_type operation)
{
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_QG_gradient_class::Q_gradient_block_matrices_pn_calc_store");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_QG_gradient_class::Q_gradient_block_matrices_pn_calc_store");

  const class RDM_PQG_class &Q_pn = get_QG ();
      
  const class array<unsigned int> &matrix_dimensions_pn = Q_pn.get_matrix_dimensions ();
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const int Jmax_total = matrix_dimensions_pn.dimension (1) - 1;
      
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class array<unsigned int> &two_states_indices_pn = Q_pn.get_two_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = Q_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = Q_pn.get_BP_table ();
  
  const class array<int> &Jmin_table = Q_pn.get_Jmin_table ();
  const class array<int> &Jmax_table = Q_pn.get_Jmax_table ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J <= Jmax_total ; J++)
      for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  {
	    if (is_it_in_space_tab(sa_p , sb_n))
	      {
		const unsigned int BP_ab = BP_table(sa_p , sb_n);

		if (BP_ab == BP)
		  {	
		    const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		    const int Jmax_ab = Jmax_table(sa_p , sb_n);

		    if ((J >= Jmin_ab) && (J <= Jmax_ab))
		      {
			const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
		    
			const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
			const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
  
			const unsigned int ija = shell_qn_sa.get_ij ();
			const unsigned int ijb = shell_qn_sb.get_ij ();
		      		      		      
			for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			    {
			      if (is_it_in_space_tab(sc_p , sd_n))
				{
				  const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
				  const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
					  
				  const unsigned int ijc = shell_qn_sc.get_ij ();
				  const unsigned int ijd = shell_qn_sd.get_ij ();
				      
				  const bool sa_sc_jb_jd_equal = ((sa_p == sc_p) && (ijb == ijd));
				  const bool sb_sd_ja_jc_equal = ((sb_n == sd_n) && (ija == ijc));
			  
				  const unsigned int BP_cd = BP_table(sc_p , sd_n);

				  if (BP_cd == BP)
				    {
				      const int Jmin_cd = Jmin_table(sc_p , sd_n);	
				      const int Jmax_cd = Jmax_table(sc_p , sd_n);

				      const int Jmin = max (Jmin_ab , Jmin_cd);
				      const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
				      if ((J >= Jmin) && (J <= Jmax))
					{
					  const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);

					  if (sa_sc_jb_jd_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , NEUTRON , ijb , sb_n , sd_n , -1.0);
					  if (sb_sd_ja_jc_equal) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , PROTON  , ija , sa_p , sc_p , -1.0);
				  
					  QG_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , J , ab_index , cd_index , BP , J , ab_index , cd_index , 1.0);

					}}}}}}}}
}


























void RDM_QG_gradient_class::G_pp_nn_block_matrices_gradients_calc_store (const enum operation_type operation)
{
  if (space_pair == PROTONS_NEUTRONS) error_message_print_abort ("Protons or neutrons only in RDM_QG_gradient_class::G_pp_nn_block_matrices_gradients_calc_store");
    
  const class nucleons_data &particles_data = (space_pair == PROTONS_ONLY) ? (get_prot_data ()) : (get_neut_data());
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const class RDM_PQG_class &G_pp_nn = get_QG ();
  
  const enum particle_type particle = last_particle;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  const class array<unsigned int> &two_states_indices = G_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &matrix_dimensions = G_pp_nn.get_matrix_dimensions ();
  
  const class array<bool> &is_it_in_space_tab = G_pp_nn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = G_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table = G_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table = G_pp_nn.get_Jmax_table ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (particle == PROTON) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class array<unsigned int> &two_states_indices_Gamma_pp_nn = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_table_Gamma_pp_nn = Gamma_pp_nn.get_BP_table ();
  
  const class array<int> &Jmin_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmax_table ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
      
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++) 
    for (int J = 0 ; J <= Jmax_total ; J++)
      for (unsigned int sa = 0 ; sa < N_nlj ; sa++) 
	for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	  {
	    if (is_it_in_space_tab(sa , sb))
	      {
		const unsigned int BP_ab = BP_table(sa , sb);

		if (BP_ab == BP)
		  {	
		    const int Jmin_ab = Jmin_table(sa , sb);	
		    const int Jmax_ab = Jmax_table(sa , sb);

		    if ((J >= Jmin_ab) && (J <= Jmax_ab))
		      {
			const unsigned int ab_index = two_states_indices(J , sa , sb);
		    
			const class nlj_struct &shell_qn_sa = shells_qn(sa);
			const class nlj_struct &shell_qn_sb = shells_qn(sb);
  					
			const int ija = shell_qn_sa.get_ij ();
			const int ijb = shell_qn_sb.get_ij ();
			  
			for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
			  for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
			    {
			      if (is_it_in_space_tab(sc , sd))
				{
				  const unsigned int BP_cd = BP_table(sc , sd);

				  if (BP_cd == BP)
				    {
				      const int Jmin_cd = Jmin_table(sc , sd);	
				      const int Jmax_cd = Jmax_table(sc , sd);

				      const int Jmin = max (Jmin_ab , Jmin_cd);
				      const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
				      if ((J >= Jmin) && (J <= Jmax))
					{
					  const unsigned int cd_index = two_states_indices(J , sc , sd);
	
					  const unsigned int BPp = BP_table_Gamma_pp_nn(sa , sd);
												
					  const class nlj_struct &shell_qn_sc = shells_qn(sc);
					  const class nlj_struct &shell_qn_sd = shells_qn(sd);
					    
					  const int ijc = shell_qn_sc.get_ij ();
					  const int ijd = shell_qn_sd.get_ij ();
					      
					  const double delta_norm_ad = (sa == sd) ? (M_SQRT2) : (1.0);
					  const double delta_norm_cb = (sc == sb) ? (M_SQRT2) : (1.0);

					  const bool is_sa_smaller_than_sd = (sa <= sd);
					  const bool is_sc_smaller_than_sb = (sc <= sb);

					  const bool are_sa_sd_equal = (sa == sd);
					  const bool are_sc_sb_equal = (sc == sb);

					  const bool ad_different_cb_different = (!are_sa_sd_equal && !are_sc_sb_equal);
											
					  const int Jp_min_bc = Jmin_table_Gamma_pp_nn(sb , sc);	
					  const int Jp_max_bc = Jmax_table_Gamma_pp_nn(sb , sc);

					  const int Jp_min_ad = Jmin_table_Gamma_pp_nn(sa , sd);	
					  const int Jp_max_ad = Jmax_table_Gamma_pp_nn(sa , sd);
				    
					  const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					  const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					      
					  if ((sb == sd) && (ija == ijc)) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , particle , ija , sa , sc , 1.0);
					    						  
					  for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					    {
					      const bool is_Jp_even = (Jp%2 == 0);
      
					      if (ad_different_cb_different || is_Jp_even)
						{
						  const unsigned int ad_index = (is_sa_smaller_than_sd) ? (two_states_indices_Gamma_pp_nn(Jp , sa , sd)) : (two_states_indices_Gamma_pp_nn(Jp , sd , sa));
						  const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_Gamma_pp_nn(Jp , sc , sb)) : (two_states_indices_Gamma_pp_nn(Jp , sb , sc));
						
						  const int phase_ad = (is_sa_smaller_than_sd) ? (1) : (((ija + ijd + Jp)%2 == 0) ? (1) : (-1));
						  const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (((ijc + ijb + Jp)%2 == 0) ? (1) : (-1));
						  
						  const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp)) : (NADA);
					      
						  const double gradient_ME_no_phase = (operation == TABLES_FILL) ? (-Wigner_6j_hats*delta_norm_ad*delta_norm_cb) : (NADA);
						      
						  const double gradient_ME = (phase_ad == phase_cb) ? (gradient_ME_no_phase) : (-gradient_ME_no_phase);
						
						  QG_Gamma_term_der_part_determine (operation , space_pair , BP , J , ab_index , cd_index , BPp , Jp , ad_index , cb_index , gradient_ME);
						      
						}}}}}}}}}}
}












void RDM_QG_gradient_class::G_pn_block_matrices_gradients_calc_store (const enum operation_type operation)
{
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_QG_gradient_class::G_pn_block_matrices_gradients_calc_store");
    
  if (last_particle == PROTON) error_message_print_abort ("Neutron is the last particle in RDM_QG_gradient_class::G_pn_block_matrices_gradients_calc_store");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class RDM_PQG_class &G_pn = get_QG ();
    
  const class array<unsigned int> &matrix_dimensions = G_pn.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
        
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
      
  const class array<unsigned int> &two_states_indices = G_pn.get_two_states_indices ();
  
  const class array<bool> &is_it_in_space_tab = G_pn.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = G_pn.get_BP_table ();
  
  const class array<int> &Jmin_table = G_pn.get_Jmin_table ();
  const class array<int> &Jmax_table = G_pn.get_Jmax_table ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
  
  const class array<unsigned int> &BP_table_Gamma_pn = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)
      for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
	for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
	  {
	    if (is_it_in_space_tab(sa_p , sb_n))
	      {
		const unsigned int BP_ab = BP_table(sa_p , sb_n);

		if (BP_ab == BP)
		  {	
		    const int Jmin_ab = Jmin_table(sa_p , sb_n);	
		    const int Jmax_ab = Jmax_table(sa_p , sb_n);

		    if ((J >= Jmin_ab) && (J <= Jmax_ab))
		      {
			const unsigned int ab_index = two_states_indices(J , sa_p , sb_n);
		    
			const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
			const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
  		      		      
			const int ija = shell_qn_sa.get_ij ();
			const int ijb = shell_qn_sb.get_ij ();
		      		      		   
			for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
			  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
			    {
			      if (is_it_in_space_tab(sc_p , sd_n))
				{
				  const unsigned int BP_cd = BP_table(sc_p , sd_n);
			    
				  if (BP_cd == BP)
				    {
				      const int Jmin_cd = Jmin_table(sc_p , sd_n);	
				      const int Jmax_cd = Jmax_table(sc_p , sd_n);

				      const int Jmin = max (Jmin_ab , Jmin_cd);
				      const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
				      if ((J >= Jmin) && (J <= Jmax))
					{
					  const unsigned int cd_index = two_states_indices(J , sc_p , sd_n);
							
					  const unsigned int BPp = BP_table_Gamma_pn(sa_p , sd_n);
					
					  const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
					  const class nlj_struct &shell_qn_sd = neut_shells_qn(sd_n);
					    
					  const int ijc = shell_qn_sc.get_ij ();
					  const int ijd = shell_qn_sd.get_ij ();
					  
					  const int Jp_min_bc = Jmin_table_Gamma_pn(sc_p , sb_n);	
					  const int Jp_max_bc = Jmax_table_Gamma_pn(sc_p , sb_n);

					  const int Jp_min_ad = Jmin_table_Gamma_pn(sa_p , sd_n);	
					  const int Jp_max_ad = Jmax_table_Gamma_pn(sa_p , sd_n);
	      	
					  const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					  const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					      
					  if ((sb_n == sd_n) && (ija == ijc)) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , PROTON , ija , sa_p , sc_p , 1.0);
					
					  for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					    {
					      const unsigned int ad_index = two_states_indices_Gamma_pn(Jp , sa_p , sd_n);
					      const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sc_p , sb_n);
			  
					      const double gradient_ME = (operation == TABLES_FILL) ? (-Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp)) : (NADA);
					  		  								
					      QG_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , J , ab_index , cd_index , BPp , Jp , ad_index , cb_index , gradient_ME);
					      
					    }}}}}}}}}
}







 


void RDM_QG_gradient_class::G_np_block_matrices_gradients_calc_store (const enum operation_type operation)
{
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_QG_gradient_class::G_gradient_matrix_np_calc_store");
    
  if (last_particle == NEUTRON) error_message_print_abort ("Proton is the last particle in RDM_QG_gradient_class::G_gradient_matrix_np_calc_store");
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = get_Wigner_6j_hats_G ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const class RDM_PQG_class &G_np = get_QG ();
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions = G_np.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
      
  const class array<bool> &is_it_in_space_tab = G_np.get_is_it_in_space_tab ();
  
  const class array<unsigned int> &BP_table = G_np.get_BP_table ();
  
  const class array<int> &Jmin_table = G_np.get_Jmin_table ();
  const class array<int> &Jmax_table = G_np.get_Jmax_table ();
  
  const class array<unsigned int> &BP_table_Gamma_pn = Gamma_pn.get_BP_table ();
  
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
    
  const class array<unsigned int> &two_states_indices = G_np.get_two_states_indices ();
  
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
        	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)  
    for (int J = 0 ; J <= Jmax_total ; J++)	
      for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
	for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
	  {
	    if (is_it_in_space_tab(sa_n , sb_p))
	      {
		const unsigned int BP_ab = BP_table(sa_n , sb_p);

		if (BP_ab == BP)
		  {	
		    const int Jmin_ab = Jmin_table(sa_n , sb_p);	
		    const int Jmax_ab = Jmax_table(sa_n , sb_p);

		    if ((J >= Jmin_ab) && (J <= Jmax_ab))
		      {
			const unsigned int ab_index = two_states_indices(J , sa_n , sb_p);
		    
			const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
			const class nlj_struct &shell_qn_sb = prot_shells_qn(sb_p);
  
			const int ija = shell_qn_sa.get_ij ();
			const int ijb = shell_qn_sb.get_ij ();
		      
			for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
			  for (unsigned int sd_p = 0 ; sd_p < Np_nlj ; sd_p++)
			    {
			      if (is_it_in_space_tab(sc_n , sd_p))
				{
				  const unsigned int BP_cd = BP_table(sc_n , sd_p);
			    
				  if (BP_cd == BP)
				    {
				      const int Jmin_cd = Jmin_table(sc_n , sd_p);	
				      const int Jmax_cd = Jmax_table(sc_n , sd_p);

				      const int Jmin = max (Jmin_ab , Jmin_cd);
				      const int Jmax = min (Jmax_ab , Jmax_cd);	
	      
				      if ((J >= Jmin) && (J <= Jmax))
					{
					  const unsigned int cd_index = two_states_indices(J , sc_n , sd_p);
							
					  const unsigned int BPp = BP_table_Gamma_pn(sd_p , sa_n);
					
					  const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
					  const class nlj_struct &shell_qn_sd = prot_shells_qn(sd_p);
					    
					  const int ijc = shell_qn_sc.get_ij ();
					  const int ijd = shell_qn_sd.get_ij ();
							
					  const int Jp_min_bc = Jmin_table_Gamma_pn(sb_p , sc_n);
					  const int Jp_max_bc = Jmax_table_Gamma_pn(sb_p , sc_n);

					  const int Jp_min_ad = Jmin_table_Gamma_pn(sd_p , sa_n);
					  const int Jp_max_ad = Jmax_table_Gamma_pn(sd_p , sa_n);

					  const int Jp_min = max (Jp_min_bc , Jp_min_ad);
					  const int Jp_max = min (Jp_max_bc , Jp_max_ad);
					      
					  const int phase_abcd = ((ija + ijb + ijc + ijd)%2 == 0) ? (1) : (-1);
				      
					  if ((sb_p == sd_p) && (ija == ijc)) rho_term_der_part_determine (operation , BP , J , ab_index , cd_index , NEUTRON , ija , sa_n , sc_n , 1.0);
				      										
					  for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
					    {
					      const unsigned int ad_index = two_states_indices_Gamma_pn(Jp , sd_p , sa_n);
					      const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sb_p , sc_n);
			  			
					      const double Wigner_6j_hats = (operation == TABLES_FILL) ? (Wigner_6j_hats_G(ija , ijb , ijc , ijd , J , Jp)) : (NADA);
					  
					      const double gradient_ME = (phase_abcd == 1) ? (-Wigner_6j_hats) : (Wigner_6j_hats);
					  
					      QG_Gamma_term_der_part_determine (operation , PROTONS_NEUTRONS , BP , J , ab_index , cd_index , BPp , Jp , ad_index , cb_index , gradient_ME);

					    }}}}}}}}}

}














void RDM_QG_gradient_class::QG_pp_nn_block_matrices_gradients_alloc_calc_store (
										const bool is_it_Q ,
										const bool is_it_G)
{  
  if (!is_it_Q && !is_it_G) error_message_print_abort ("It is Q or G in RDM_QG_gradient_class::QG_pp_nn_block_matrices_gradients_alloc_calc_store");
          
  class array<unsigned short int> &QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = get_QG_gradient_block_matrices_non_trivial_zero_numbers (space_pair);
  
  class array<class block_sparse_matrix<TYPE> > &QG_gradient_block_matrices_pp_nn = get_QG_gradient_block_matrices (space_pair);
  
  const class RDM_PQG_class &QG = get_QG ();
  
  const class array<unsigned int> &matrix_dimensions = QG.get_matrix_dimensions ();
  
  const class RDM_PQG_class &Gamma_pp_nn = (space_pair == PROTONS_ONLY) ? (get_Gamma_pp ()) : (get_Gamma_nn ());
  
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions_pp_nn = Gamma_pp_nn.get_matrix_dimensions ();
  
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
  
  const int Jmax_pp_nn_total_plus_one = QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn.dimension (1);
  
  const int Jmax_pn_total_plus_one = QG_gradient_block_matrices_non_trivial_zero_numbers_pn.dimension (1);
  
  if (is_it_Q) Q_pp_nn_block_matrices_gradients_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_G) G_pp_nn_block_matrices_gradients_calc_store (DIMENSIONS_TABLES_CALC);
  
  class array<unsigned int> QG_block_matrix_dimensions(2*Jmax_pp_nn_total_plus_one);
    
  class array<unsigned int> QG_block_matrix_non_trivial_zero_numbers(2*Jmax_pp_nn_total_plus_one);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J < Jmax_pp_nn_total_plus_one ; J++)
      QG_block_matrix_dimensions(BP + 2*J) = matrix_dimensions(BP , J);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int J = 0 ; J < Jmax_pp_nn_total_plus_one ; J++)		  
		  QG_block_matrix_non_trivial_zero_numbers(BP + 2*J) = QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
	      
	      const unsigned int non_trivial_zero_number_max = QG_block_matrix_non_trivial_zero_numbers.max ();
	      
	      if (non_trivial_zero_number_max > 0) QG_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (QG_block_matrix_dimensions , QG_block_matrix_non_trivial_zero_numbers);      
	    }
      }
	      
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int J = 0 ; J < Jmax_pp_nn_total_plus_one ; J++)		  
		  QG_block_matrix_non_trivial_zero_numbers(BP + 2*J) = QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);
	      
	      const unsigned int non_trivial_zero_number_max = QG_block_matrix_non_trivial_zero_numbers.max ();
	    
	      if (non_trivial_zero_number_max > 0) QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (QG_block_matrix_dimensions , QG_block_matrix_non_trivial_zero_numbers);
	    }
      }
	
  QG_gradient_block_matrices_non_trivial_zero_numbers_pp_nn = 0;
  QG_gradient_block_matrices_non_trivial_zero_numbers_pn    = 0;
	
  if (is_it_Q) Q_pp_nn_block_matrices_gradients_calc_store (TABLES_FILL);
  if (is_it_G) G_pp_nn_block_matrices_gradients_calc_store (TABLES_FILL);
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);

	      class block_sparse_matrix<TYPE> &QG_gradient_matrix_pp_nn = QG_gradient_block_matrices_pp_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      	      
	      if (QG_gradient_matrix_pp_nn.is_it_filled ()) QG_gradient_matrix_pp_nn.make_it_consistent_no_zeros ();	      
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &QG_gradient_matrix_pn = QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (QG_gradient_matrix_pn.is_it_filled ()) QG_gradient_matrix_pn.make_it_consistent_no_zeros ();
	    }
      }
}






void RDM_QG_gradient_class::QG_pn_np_block_matrices_gradients_alloc_calc_store (
										const bool is_it_Q ,
										const bool is_it_G)
{  
  if (space_pair != PROTONS_NEUTRONS) error_message_print_abort ("Both protons and neutrons are used in RDM_QG_gradient_class::QG_pn_np_block_matrices_gradients_alloc_calc_store");
    
  if (!is_it_Q && !is_it_G) error_message_print_abort ("It is Q or G in QG_pn_np_block_matrices_gradients_alloc_calc_store");
  
  const bool is_it_pn = (last_particle == NEUTRON);
  const bool is_it_np = (last_particle == PROTON);
      
  if (is_it_Q && !is_it_pn) error_message_print_abort ("It is Q with pn in RDM_QG_gradient_class::QG_pn_np_block_matrices_gradients_alloc_calc_store");
    
  const class RDM_PQG_class &QG = get_QG ();
  
  const class array<unsigned int> &matrix_dimensions = QG.get_matrix_dimensions ();
  
  const class RDM_PQG_class &Gamma_pp = get_Gamma_pp ();
  const class RDM_PQG_class &Gamma_nn = get_Gamma_nn ();
  const class RDM_PQG_class &Gamma_pn = get_Gamma_pn ();
  
  const class array<unsigned int> &matrix_dimensions_pp = Gamma_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = Gamma_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = Gamma_pn.get_matrix_dimensions ();
    
  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);
  
  if (is_it_Q)             Q_pn_block_matrices_gradients_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_G && is_it_pn) G_pn_block_matrices_gradients_calc_store (DIMENSIONS_TABLES_CALC);
  if (is_it_G && is_it_np) G_np_block_matrices_gradients_calc_store (DIMENSIONS_TABLES_CALC);
    
  class array<unsigned int> QG_block_matrix_dimensions(2*Jmax_pn_total_plus_one);
    
  class array<unsigned int> QG_block_matrix_non_trivial_zero_numbers(2*Jmax_pn_total_plus_one);
    	    
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    for (int J = 0 ; J < Jmax_pn_total_plus_one ; J++)
      QG_block_matrix_dimensions(BP + 2*J) = matrix_dimensions(BP , J);
		  	    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int J = 0 ; J < Jmax_pn_total_plus_one ; J++)		  
		  QG_block_matrix_non_trivial_zero_numbers(BP + 2*J) = QG_gradient_block_matrices_non_trivial_zero_numbers_pp(BPp , Jp , ip_jp_upper_triangular_index , BP , J);

	      const unsigned int non_trivial_zero_number_max = QG_block_matrix_non_trivial_zero_numbers.max ();
	    
	      if (non_trivial_zero_number_max > 0) QG_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index).allocate (QG_block_matrix_dimensions , QG_block_matrix_non_trivial_zero_numbers);
	    }
      }	
  		  	    
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int J = 0 ; J < Jmax_pn_total_plus_one ; J++)		  
		  QG_block_matrix_non_trivial_zero_numbers(BP + 2*J) = QG_gradient_block_matrices_non_trivial_zero_numbers_nn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);

	      const unsigned int non_trivial_zero_number_max = QG_block_matrix_non_trivial_zero_numbers.max ();
	    
	      if (non_trivial_zero_number_max > 0) QG_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index).allocate (QG_block_matrix_dimensions , QG_block_matrix_non_trivial_zero_numbers);
	    }
      }
	  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      for (unsigned int BP = 0 ; BP <= 1 ; BP++)
		for (int J = 0 ; J < Jmax_pn_total_plus_one ; J++)		  
		  QG_block_matrix_non_trivial_zero_numbers(BP + 2*J) = QG_gradient_block_matrices_non_trivial_zero_numbers_pn(BPp , Jp , ip_jp_upper_triangular_index , BP , J);

	      const unsigned int non_trivial_zero_number_max = QG_block_matrix_non_trivial_zero_numbers.max ();
	    
	      if (non_trivial_zero_number_max > 0) QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index).allocate (QG_block_matrix_dimensions , QG_block_matrix_non_trivial_zero_numbers);
	    }
      }
  
  QG_gradient_block_matrices_non_trivial_zero_numbers_pp = 0;
  QG_gradient_block_matrices_non_trivial_zero_numbers_nn = 0;
  QG_gradient_block_matrices_non_trivial_zero_numbers_pn = 0;
  
  if (is_it_Q)             Q_pn_block_matrices_gradients_calc_store (TABLES_FILL);
  if (is_it_G && is_it_pn) G_pn_block_matrices_gradients_calc_store (TABLES_FILL);
  if (is_it_G && is_it_np) G_np_block_matrices_gradients_calc_store (TABLES_FILL);

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pp_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pp(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
		  
	      class block_sparse_matrix<TYPE> &QG_gradient_matrix_pp = QG_gradient_block_matrices_pp(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (QG_gradient_matrix_pp.is_it_filled ()) QG_gradient_matrix_pp.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_nn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_nn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &QG_gradient_matrix_nn = QG_gradient_block_matrices_nn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (QG_gradient_matrix_nn.is_it_filled ()) QG_gradient_matrix_nn.make_it_consistent_no_zeros ();  
	    }
      }
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)
    for (int Jp = 0 ; Jp < Jmax_pn_total_plus_one ; Jp++)
      {		
	const unsigned int dimension_BPp_Jp = matrix_dimensions_pn(BPp , Jp);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {	    
	      const unsigned int ip_jp_upper_triangular_index = upper_triangular_index_calc (ip , jp);
	      
	      class block_sparse_matrix<TYPE> &QG_gradient_matrix_pn = QG_gradient_block_matrices_pn(BPp , Jp , ip_jp_upper_triangular_index);
	      
	      if (QG_gradient_matrix_pn.is_it_filled ()) QG_gradient_matrix_pn.make_it_consistent_no_zeros ();
	    }
      }
}
