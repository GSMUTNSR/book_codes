#include "../RDM_include/RDM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace density_OBMEs;
using namespace correlated_state_routines;
using namespace RDM_rho_observables;


// OBMEs means one-body matrix elements
// ------------------------------------



// See GSM_density_OBMEs.cpp for the calculation of OBMEs
// ------------------------------------------------------


// Calculation of the density for one pair of many-body states <Psi[out] | rho(r/k) | Psi[in]> or the density of a fixed state |Psi> <Psi | rho(r/k) | Psi>
// -------------------------------------------------------------------------------------------------------------------------------------------------------
//
// calc_one_pair
// -------------
// One calculates the density <Psi[out] | rho(r/k) | Psi[in]> for fixed states |Psi[in]> and |Psi[out]> for all r radii or k momenta.
//
// calc_store_one_state
// --------------------
// One calculates the density of a fixed state |Psi> <Psi | rho(r/k) | Psi> for all r radii.
// It is stored in disk in a file whose name looks like density_0+_0.dat .
//
// calc_store
// ----------
// Eigenvectors are read from disk and calc_store_one_state is called for the density associated to these eigenvectors.
//
//
// Variables
// ---------
// is_it_radial: true if one calculates a radial density, false if one calculates a momentum density
//
// is_it_Gauss_Legendre: true if one calculates on the [0:R] radial grid or [0:kmax_momentum] momentum grid with Gauss-Legendre radii or momenta,
//                       false if one calculates on the [0:R] radial grid or [0:kmax_momentum] momentum grid with the uniform distribution of radii
//
// PSI_IN, PSI_OUT, PSI: in and out GSM vectors |Psi[in]> and |Psi[out]>, GSM_vector |Psi>
// prot_data, neut_data, data: classes containing data related to protons or neutrons
// density_tab: array of <Psi[out] | rho(r/k) | Psi[in]> values function of radius index
//
// PSI_helper_IN, PSI_helper_OUT, PSI_helper: structures containing information about the many-body body basis of |Psi[in]>, |Psi[out]>, |Psi> 
//                                             necessary to calculate the basis Slater determinant indices. GSM vector components are excluded.
//
// dummy_helper: dummy structure used in configuration_SD_in_out_in_space_one_jump_tables_alloc_calc
// space: PROTONS_ONLY if one has valence protons only, NEUTRONS_ONLY if one has valence neutrons only, PROTONS_NEUTRONS if one has valence protons and neutrons.
// Np_nljm, Nn_nljm: number of proton or neutron states, for which n,l,j,m are fixed.
// N_bef_R_GL, N_bef_R_uniform, Nr: number of radii, which is N_bef_R_GL if is_it_Gauss_Legendre is true or N_bef_R_uniform if is_it_Gauss_Legendre is false
// Nk_momentum_GL, Nk_momentum_uniform, Nk: number of momenta, which is Nk_momentum_GL if is_it_Gauss_Legendre is true or Nk_momentum_uniform if is_it_Gauss_Legendre is false
// N_uniform, N_GL:  N_bef_R_uniform (is_it_radial true) or Nk_momentum_uniform  (is_it_radial false), N_bef_R_GL (is_it_radial true) or Nk_momentum_GL (is_it_radial false), 
// Nrk: Nr if is_it_radial is true, Nk if it is false
// OBMEs_prot, OBMEs_neut: array of proton and neutron OBMEs of rho(r/k)
// r_bef_R_tab: radii on the [0:R] radial grid, with R the rotation point
// kmax_momentum: maximal momentum considered for wave functions in momentum space
// step_momentum_uniform: step on [0:kmax_momentum] for the uniformly spaced grid
// k_tab: momenta on the [0:kmax_momentum] momentum grid
// PSI_qn: class correlated_state_str containing data about the current GSM eigenvector, such as Z,N,BP,J ... (qn is quantum numbers)
// PSI_qn_string: string describing the state |Psi> to be used in a file name (qn is quantum numbers)
// density_string, density_file: name if the file and file where one stored rho(r/k)
// rk, rk2, density_rk, density_rk_rk2: radius, its square, density, density times r^2 or k^2
// inter: type of the interaction used (FHT, realistic, ...)
// truncation_hw: true if one truncates in energy, given there in units of hbar omega, false if not 
// truncation_ph: true if one truncates with respect to hole number in core states or particle number in the continuum, false if not
// Z, N: number of protons and neutrons of the nucleus
// n_scat_max, n_scat_max_p, n_scat_max_n: maximal number of nucleons in the continuum, for full space, proton space and neutron space
// E_max_hw, Ep_max_hw, En_max_hw: maximal truncation energy for full space, proton space and neutron space
// density_number: number of densities to calculate, one for each eigenvector
// density_BP_tab, density_J_tab, density_vector_index_tab: binary parities (see observables_basic_functions.cpp for definition), total angular momenta and vector indices of eigenvectors, function of density index
// density_is_it_radial_tab: array of booleans equal to true if one calculates a radial density, false if one calculates a momentum density
// density_is_it_Gauss_Legendre_tab: array of booleans equal to true if one calculates on the [0:R] radial grid with Gauss-Legendre radii, false if one calculates on the [0:R] radial grid with the uniform distribution of radii
// kmax_momentum: maximal momentum considered for wave functions in momentum space
// step_momentum_uniform: step on [0:kmax_momentum] for the uniformly spaced grid
// k_tab: momenta on the [0:kmax_momentum] momentum grid
// R, step_bef_R_uniform: radial step on the uniform grid on [0:R], with R the rotation point
// r_bef_R_tab_GL, w_bef_R_tab_GL: Gauss-Legendre radii and weights on the [0:R] radial grid
// r_bef_R_tab_uniform: array of radii on the uniform grid on [0:R]
// k_tab_GL, wk_tab_GL: Gauss-Legendre momenta  and weights on the [0:kmax_momentum] momentum grid
// k_tab_uniform: array of momenta on the uniform grid on [0:kmax_momentum]
// r_bef_R_tab: r_bef_R_tab_GL or r_bef_R_tab_uniform, whether one uses Gauss-Legendre or not
// k_tab: k_tab_GL or k_tab_uniform, whether one uses Gauss-Legendre or not
// rk_tab: r_bef_R_tab for a radial density, k_tab for a momentum density
// BP, vector_index, J, M: binary parity (see observables_basic_functions.cpp for definition), vector index, total angular momentum and its projection, taken equal to the latter for simplicity, of eigenvectors
// input_data: class where all data coming from the input file are stored






void RDM_density::calc_store_density (
				      const enum space_type space , 
				      const bool is_it_radial ,
				      const bool is_it_Gauss_Legendre ,
				      const class array<double> &rk_tab ,
				      const class nucleons_data &prot_data ,
				      const class nucleons_data &neut_data ,
				      const class correlated_state_str &PSI_qn , 
				      const class RDM_PQG_class &Gamma_pp ,
				      const class RDM_PQG_class &Gamma_nn ,
				      const class RDM_PQG_class &Gamma_pn)
{
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
	
  const unsigned int N_bef_R_GL  = prot_data.get_N_bef_R_GL ();
  const unsigned int N_bef_R_uniform = prot_data.get_N_bef_R_uniform ();
  
  const unsigned int Nk_momentum_GL  = prot_data.get_Nk_momentum_GL ();
  const unsigned int Nk_momentum_uniform = prot_data.get_Nk_momentum_uniform ();
  
  const unsigned int Nr = (is_it_Gauss_Legendre) ? (N_bef_R_GL) : (N_bef_R_uniform);

  const unsigned int Nk = (is_it_Gauss_Legendre) ? (Nk_momentum_GL) : (Nk_momentum_uniform);
    
  const unsigned int Nrk = (is_it_radial) ? (Nr) : (Nk);
  
  class array<TYPE> prot_density_tab(Nrk);
  class array<TYPE> neut_density_tab(Nrk);
    
  class array<TYPE> OBMEs_prot(Np_nlj , Np_nlj , Nrk);
  class array<TYPE> OBMEs_neut(Nn_nlj , Nn_nlj , Nrk);

  if (space != NEUTRONS_ONLY) OBMEs_shells_calc (is_it_radial , is_it_Gauss_Legendre , prot_data , OBMEs_prot);
  if (space != PROTONS_ONLY)  OBMEs_shells_calc (is_it_radial , is_it_Gauss_Legendre , neut_data , OBMEs_neut);

  scalar_strength_calc (OBMEs_prot ,  OBMEs_neut ,  prot_data , neut_data ,  Gamma_pp , Gamma_nn , Gamma_pn , prot_density_tab , neut_density_tab);
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      const class array<TYPE> density_tab = prot_density_tab + neut_density_tab;
  
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
      const string density_string = (is_it_radial) ? ("radial_density_" + PSI_qn_string + ".dat") : ("momentum_density_" + PSI_qn_string + ".dat");

      ofstream density_file(density_string.c_str() , ios::out);

      density_file.precision (15);

      for (unsigned int i = 0 ; i < Nrk ; i++)
	{
	  const double rk = rk_tab(i);

	  const double rk2 = rk*rk;
	  
	  const TYPE density_rk = density_tab(i);

	  const TYPE density_rk_rk2 = density_rk*rk2;
	  
#ifdef TYPEisDOUBLECOMPLEX
	  density_file << rk << " " << real (density_rk) << " " << imag (density_rk) << " " << real (density_rk_rk2) << " " << imag (density_rk_rk2) << endl;
#endif
	  
#ifdef TYPEisDOUBLE
	  density_file << rk << " " << density_rk << " " << density_rk_rk2 << endl;
#endif
	}

      density_file.close ();

      const TYPE density_norm_test = radial_momentum_density_norm_with_splines (rk_tab , density_tab);

      if (space == PROTONS_NEUTRONS)
	{
	  const string prot_density_string = (is_it_radial) ? ("proton_radial_density_"  + PSI_qn_string + ".dat") : ("proton_momentum_density_"  + PSI_qn_string + ".dat");
	  const string neut_density_string = (is_it_radial) ? ("neutron_radial_density_" + PSI_qn_string + ".dat") : ("neutron_momentum_density_" + PSI_qn_string + ".dat");
      
	  ofstream prot_density_file(prot_density_string.c_str() , ios::out);
	  ofstream neut_density_file(neut_density_string.c_str() , ios::out);

	  prot_density_file.precision (15);
	  neut_density_file.precision (15);

	  for (unsigned int i = 0 ; i < Nrk ; i++)
	    {
	      const double rk = rk_tab(i);

	      const double rk2 = rk*rk;
	  
	      const TYPE prot_density_rk = prot_density_tab(i);
	      const TYPE neut_density_rk = neut_density_tab(i);

	      const TYPE prot_density_rk_rk2 = prot_density_rk*rk2;
	      const TYPE neut_density_rk_rk2 = neut_density_rk*rk2;
	      
#ifdef TYPEisDOUBLECOMPLEX
	      prot_density_file << rk << " " << real (prot_density_rk) << " " << imag (prot_density_rk) << " " << real (prot_density_rk_rk2) << " " << imag (prot_density_rk_rk2) << endl;
	      neut_density_file << rk << " " << real (neut_density_rk) << " " << imag (neut_density_rk) << " " << real (neut_density_rk_rk2) << " " << imag (neut_density_rk_rk2) << endl;
#endif
	  
#ifdef TYPEisDOUBLE
	      prot_density_file << rk << " " << prot_density_rk << " " << prot_density_rk_rk2 << endl;
	      neut_density_file << rk << " " << neut_density_rk << " " << neut_density_rk_rk2 << endl;
#endif
	    }
	  
	  prot_density_file.close ();
	  neut_density_file.close ();
	  
	  const TYPE prot_density_norm_test = radial_momentum_density_norm_with_splines (rk_tab , prot_density_tab);
	  const TYPE neut_density_norm_test = radial_momentum_density_norm_with_splines (rk_tab , neut_density_tab);
      
	  cout << "Total   density norm (from splines) : " << density_norm_test      << endl;
	  cout << "Proton  density norm (from splines) : " << prot_density_norm_test << endl;
	  cout << "Neutron density norm (from splines) : " << neut_density_norm_test << endl;
	}
      else
	cout << "Density norm (from splines) : " << density_norm_test << endl;
	
    }
}








void RDM_density::calc_store (
			      const class input_data_str &input_data , 
			      const class nucleons_data &prot_data , 
			      const class nucleons_data &neut_data ,
			      const class RDM_PQG_class &Gamma_pp ,
			      const class RDM_PQG_class &Gamma_nn ,
			      const class RDM_PQG_class &Gamma_pn)
{ 
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Densities" << endl;
      cout <<         "---------" << endl << endl;
    }

  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();

  const enum space_type space = input_data.get_space ();
  
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
  
  const unsigned int density_number = input_data.get_density_number ();
  
  const class array<unsigned int> &density_BP_tab = input_data.get_density_BP_tab ();

  const class array<double> &density_J_tab = input_data.get_density_J_tab ();

  const class array<unsigned int> &density_vector_index_tab = input_data.get_density_vector_index_tab ();

  const class array<bool> &density_is_it_radial_tab = input_data.get_density_is_it_radial_tab ();

  const class array<bool> &density_is_it_Gauss_Legendre_tab = input_data.get_density_is_it_Gauss_Legendre_tab ();

  const unsigned int N_bef_R_GL  = input_data.get_N_bef_R_GL ();
  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL  = input_data.get_Nk_momentum_GL ();
  const unsigned int Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();
  
  const double R = input_data.get_R ();
  
  const double kmax_momentum = input_data.get_kmax_momentum ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  const double step_momentum_uniform = input_data.get_step_momentum_uniform ();
  
  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;
  
  class array<double> k_tab_GL(Nk_momentum_GL);
  class array<double> wk_tab_GL(Nk_momentum_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  class array<double> k_tab_uniform(Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;
  
  for (unsigned int density_index = 0 ; density_index < density_number ; density_index++)
    {
      const unsigned int BP = density_BP_tab(density_index);

      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_density::calc_print");
      
      const unsigned int vector_index = density_vector_index_tab(density_index);

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_density::calc_print");
      
      const double J = density_J_tab(density_index);
      
      if (rint (J - RDM_J)!= 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_density::calc_print");
      
      const bool is_it_radial = density_is_it_radial_tab(density_index);

      const bool is_it_Gauss_Legendre = density_is_it_Gauss_Legendre_tab(density_index);
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);
      
      const class array<double> &rk_tab = (is_it_radial) ? (r_bef_R_tab) : (k_tab);      
      
      const class correlated_state_str PSI_qn(Z , N , BP , J , vector_index , NADA , NADA , NADA , NADA , false);
      
      calc_store_density (space , is_it_radial , is_it_Gauss_Legendre , rk_tab , prot_data , neut_data , PSI_qn , Gamma_pp , Gamma_nn , Gamma_pn);

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  const string radial_momentum_str = (is_it_radial) ? ("Radial") : ("Momentum");
	  
	  cout << radial_momentum_str << " density of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated." << endl << endl;
	}	
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}


