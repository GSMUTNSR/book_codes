#include "../RDM_include/RDM_include_def.h"

using namespace RDM_Hessian_vector_no_sigma;
using namespace RDM_rho_observables_gradient;






void RDM_F_gradient::F_der_pp_nn_calc (
				       const enum particle_type particle ,
				       const class block_matrix<TYPE> &average_E_der_pp_nn_block_matrix ,
				       const class RDM_conditions_class &Lambda_plus_sigma_X_minus_A_Gamma ,
				       const class RDM_conditions_gradient_class &A_Gamma_gradients , 	
				       class block_matrix<TYPE> &F_der_pp_nn , 				 
				       class block_matrix<TYPE> &F_der_rho_pp_nn)
{
  const enum particle_type particle_other_space = (particle == PROTON) ? (NEUTRON) : (PROTON);

  const enum space_type space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const bool is_there_G_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_T2_prime_constraint ();
  
  const bool is_there_CM_correction = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = Lambda_plus_sigma_X_minus_A_Gamma.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_E_reference ();
  
  const TYPE Delta_pp_nn_pairs_number_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_pairs_number_dependent_term (space);
  
  const TYPE Delta_J_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_J_dependent_term ();
  
  const TYPE Delta_E_reference_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_E_reference_dependent_term ();
    
  const TYPE Delta_Hcm_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_Hcm_dependent_term ();
                
  const class array<double> &Delta_J_der_tab = A_Gamma_gradients.get_Delta_J_der_tab (space);
  
  const class block_matrix<TYPE> &Delta_E_reference_der_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (space);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (space);
        
  const class RDM_PQG_class &P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_P_dependent_term (space);
        
  const class RDM_rho_coupled_modified_class &rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_rho_coupled_modified_dependent_term (particle);
  
  const class block_matrix<TYPE> &rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma.get_block_matrix ();
  
  const class array<unsigned int> &matrix_dimensions = P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;      
          
  const int jmax_ab_global = rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma.get_jmax_ab_global ();
  
  const class block_matrix<TYPE> &P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_P_dependent_term_block_matrix (space);
  const class block_matrix<TYPE> &Q_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_Q_dependent_term_block_matrix (space);
  const class block_matrix<TYPE> &G_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (space , particle);
  
  const class RDM_J_constraints_class &J_constraints_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_J_constraints_dependent_term (particle);
  
  const class block_matrix<TYPE> &Q_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &G_pn_np_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , particle_other_space);
  
  const class block_matrix<TYPE> &T1_ppp_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (space , particle);  

  const class block_matrix<TYPE> &T1_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  const class block_matrix<TYPE> &T1_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
  const class block_matrix<TYPE> &T2_prime_ppp_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (space , particle);
    
  const class block_matrix<TYPE> &T2_prime_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  const class block_matrix<TYPE> &T2_prime_pnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  const class block_matrix<TYPE> &T2_prime_pnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
    
  const class RDM_QG_gradient_class &Q_pp_nn_gradient = A_Gamma_gradients.get_Q_gradient (space);
  
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_nn_gradient = A_Gamma_gradients.get_G_gradient (space            , particle);
  const class RDM_QG_gradient_class &G_pn_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , particle_other_space);
  
  const class RDM_J_constraints_gradient_class &J_constraints_pp_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (particle);
      
  const class RDM_T1_gradient_class &T1_ppp_nnn_gradient = A_Gamma_gradients.get_T1_gradient (space , particle);
    
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppp_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (space , particle);  
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  const class array<class block_sparse_matrix<TYPE> > &Q_pp_nn_der_pp_nn_block_matrices = Q_pp_nn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pp_nn_block_matrices = Q_pn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_nn_der_pp_nn_block_matrices = G_pp_nn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_np_der_pp_nn_block_matrices = G_pn_np_gradient.get_block_matrices (space);
        
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_nnn_der_pp_nn_block_matrices = T1_ppp_nnn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pp_nn_block_matrices = T1_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pp_nn_block_matrices = T1_nnp_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_nnn_der_pp_nn_block_matrices = T2_prime_ppp_nnn_gradient.get_block_matrices (space);
  		
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pp_nn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pp_nn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pp_nn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pp_nn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (space);
	
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
  
  F_der_pp_nn.zero ();
  
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
		    	      
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    
	      const class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix = Q_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
  
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix = Q_pn_der_pp_nn_block_matrices(BPp , Jp , index_prime);

	      class matrix<TYPE> &F_der_pp_nn_BPp_Jp = F_der_pp_nn(BPp + 2*Jp);
	  
	      TYPE &F_der_pp_nn_ME = F_der_pp_nn_BPp_Jp(ip , jp);
	      
	      if (Q_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (Q_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , Q_pp_nn_der_pp_nn_block_matrix);
	      	    	      
	      if (are_there_J_constraints) F_der_pp_nn_ME -= Frobenius_scalar_product_matrix_gradient (false , BPp , Jp , index_prime , J_constraints_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma , J_constraints_pp_nn_gradient);
	    	    
	      if (Q_pn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (Q_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , Q_pn_der_pp_nn_block_matrix);	      
	    
	      if (is_there_G_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix = G_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix = G_pn_np_der_pp_nn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (G_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_pp_nn_der_pp_nn_block_matrix);
		  if (G_pn_np_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (G_pn_np_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_pn_np_der_pp_nn_block_matrix);
		}
	      
	      if (is_there_T1_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix = T1_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix = T1_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix = T1_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
	      
		  if (T1_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T1_ppp_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_ppp_nnn_der_pp_nn_block_matrix);
		    
		  if (T1_ppn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T1_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_ppn_der_pp_nn_block_matrix);
		  if (T1_nnp_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T1_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_nnp_der_pp_nn_block_matrix);
		}
	      
	      if (is_there_T2_prime_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix = T2_prime_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix = T2_prime_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix = T2_prime_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix = T2_prime_pnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix = T2_prime_pnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);

		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T2_prime_ppp_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_ppp_nnn_der_pp_nn_block_matrix);
		    
		  if (T2_prime_ppn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T2_prime_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_ppn_der_pp_nn_block_matrix);
		  if (T2_prime_nnp_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T2_prime_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_nnp_der_pp_nn_block_matrix);		  
		  if (T2_prime_pnp_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T2_prime_pnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_pnp_der_pp_nn_block_matrix);
		  if (T2_prime_pnn_der_pp_nn_block_matrix.is_it_filled ()) F_der_pp_nn_ME -= Frobenius_scalar_product (T2_prime_pnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_pnn_der_pp_nn_block_matrix);
		}		
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) F_der_pp_nn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	
	const unsigned int BPp_Jp_index = BPp + 2*Jp;
	
	const TYPE Lambda_plus_sigma_X_minus_A_Gamma_Delta_pp_nn_pairs_number_MEs = Delta_pp_nn_pairs_number_Lambda_plus_sigma_X_minus_A_Gamma*(2*Jp + 1);
	    	
	const class matrix<TYPE> &P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp = P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_E_reference_der_block_matrix_BPp_Jp = Delta_E_reference_der_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_block_matrix_BPp_Jp = Delta_Hcm_der_block_matrix(BPp_Jp_index);
	
	class matrix<TYPE> &F_der_pp_nn_BPp_Jp = F_der_pp_nn(BPp_Jp_index);
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      TYPE &F_der_pp_nn_ME = F_der_pp_nn_BPp_Jp(ip , jp);
	      
	      F_der_pp_nn_ME -= (ip == jp) ? (P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp(ip , jp)) : (2.0*P_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp(ip , jp));
	      
	      if (is_there_E_reference) F_der_pp_nn_ME -= Delta_E_reference_Lambda_plus_sigma_X_minus_A_Gamma*Delta_E_reference_der_block_matrix_BPp_Jp(ip , jp);
	    	      
	      if (is_there_CM_correction) F_der_pp_nn_ME -= Delta_Hcm_Lambda_plus_sigma_X_minus_A_Gamma*Delta_Hcm_der_block_matrix_BPp_Jp(ip , jp);
	      
	    }
	
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {	    
	    TYPE &F_der_pp_nn_ME = F_der_pp_nn_BPp_Jp(ip , ip);
	    
	    F_der_pp_nn_ME -= Lambda_plus_sigma_X_minus_A_Gamma_Delta_pp_nn_pairs_number_MEs;

	    F_der_pp_nn_ME -= Delta_J_Lambda_plus_sigma_X_minus_A_Gamma*Delta_J_der_tab(BPp , Jp , ip);
	  }
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    F_der_pp_nn_BPp_Jp(jp , ip) = F_der_pp_nn_BPp_Jp(ip , jp);
      }

  F_der_pp_nn += average_E_der_pp_nn_block_matrix;

  if (are_there_J_constraints && (jmax_ab_global > 0))
    {
      F_der_rho_pp_nn.zero ();
  
      for (unsigned int bp = 0 ; bp <= 1 ; bp++)  
	for (int j = 0 ; j <= jmax_ab_global ; j++)
	  {	
	    const unsigned int bp_j_index = bp + 2*j;
	
	    const class matrix<TYPE> &rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_bp_j = rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix(bp_j_index);
	
	    const unsigned int dimension_bp_j = rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_bp_j.get_dimension ();
		
	    class matrix<TYPE> &F_der_rho_pp_nn_bp_j = F_der_rho_pp_nn(bp_j_index);
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index <= sb_bp_index ; sa_bp_index++)
		{
		  TYPE &F_der_rho_pp_nn_ME = F_der_rho_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	      
		  F_der_rho_pp_nn_ME -= (sa_bp_index == sb_bp_index)
		    ? (    rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_bp_j(sa_bp_index , sb_bp_index))
		    : (2.0*rho_coupled_modified_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma_bp_j(sa_bp_index , sb_bp_index));
	      
		  F_der_rho_pp_nn_ME -= Frobenius_scalar_product_matrix_rho_coupled_modified_gradient (j , sa_bp_index , sb_bp_index , J_constraints_pp_nn_Lambda_plus_sigma_X_minus_A_Gamma);
		}
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index < sb_bp_index ; sa_bp_index++)
		F_der_rho_pp_nn_bp_j(sb_bp_index , sa_bp_index) = F_der_rho_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	  }
    }
}










void RDM_F_gradient::F_der_pn_calc (
				    const class block_matrix<TYPE> &average_E_der_pn_block_matrix ,
				    const class RDM_conditions_class &Lambda_plus_sigma_X_minus_A_Gamma ,
				    const class RDM_conditions_gradient_class &A_Gamma_gradients , 			
				    class block_matrix<TYPE> &F_der_pn)
{
  const class RDM_PQG_class &P_pn_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_P_dependent_term (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &matrix_dimensions = P_pn_Lambda_plus_sigma_X_minus_A_Gamma.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const bool is_there_G_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_T2_prime_constraint ();
  
  const bool is_there_CM_correction = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_CM_correction ();

  const bool are_there_J_constraints = Lambda_plus_sigma_X_minus_A_Gamma.get_are_there_J_constraints ();
    
  const bool is_there_E_reference = Lambda_plus_sigma_X_minus_A_Gamma.get_is_there_E_reference ();
  
  const TYPE Delta_pn_pairs_number_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);

  const TYPE Delta_J_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_J_dependent_term ();
  
  const TYPE average_T2_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_average_T2_dependent_term ();
    
  const TYPE Delta_E_reference_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_E_reference_dependent_term ();
    
  const TYPE Delta_Hcm_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_Delta_Hcm_dependent_term ();
    					   
  const class array<double> &Delta_J_der_pn_tab = A_Gamma_gradients.get_Delta_J_der_tab (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &ba_from_ab_pn_indices = A_Gamma_gradients.get_ba_from_ab_pn_indices ();
  
  const class array<int> &average_T2_der_pn_tab = A_Gamma_gradients.get_average_T2_der_pn_tab ();
  
  const class block_matrix<TYPE> &Delta_E_reference_der_pn_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (PROTONS_NEUTRONS);
    
  const class block_matrix<TYPE> &P_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  const class block_matrix<TYPE> &Q_pp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  const class block_matrix<TYPE> &Q_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  const class block_matrix<TYPE> &Q_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &G_pp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  const class block_matrix<TYPE> &G_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
  const class block_matrix<TYPE> &G_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  const class block_matrix<TYPE> &G_np_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);

  const class RDM_J_constraints_class &J_constraints_pp_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_J_constraints_dependent_term (PROTON);
  const class RDM_J_constraints_class &J_constraints_nn_Lambda_plus_sigma_X_minus_A_Gamma = Lambda_plus_sigma_X_minus_A_Gamma.get_J_constraints_dependent_term (NEUTRON);    
  
  const class block_matrix<TYPE> &T1_ppp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  const class block_matrix<TYPE> &T1_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  const class block_matrix<TYPE> &T1_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  const class block_matrix<TYPE> &T1_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

  const class block_matrix<TYPE> &T2_prime_ppp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  const class block_matrix<TYPE> &T2_prime_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  const class block_matrix<TYPE> &T2_prime_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  const class block_matrix<TYPE> &T2_prime_pnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  const class block_matrix<TYPE> &T2_prime_pnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix = Lambda_plus_sigma_X_minus_A_Gamma.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);

  const class RDM_QG_gradient_class &Q_pp_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_ONLY);
  const class RDM_QG_gradient_class &Q_nn_gradient = A_Gamma_gradients.get_Q_gradient (NEUTRONS_ONLY);
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_QG_gradient_class &G_nn_gradient = A_Gamma_gradients.get_G_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_QG_gradient_class &G_pn_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , NEUTRON);
  const class RDM_QG_gradient_class &G_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , PROTON);
    
  const class RDM_J_constraints_gradient_class &J_constraints_pp_gradient = A_Gamma_gradients.get_J_constraints_gradient (PROTON);
  const class RDM_J_constraints_gradient_class &J_constraints_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (NEUTRON);
  
  const class RDM_T1_gradient_class &T1_ppp_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , PROTON);
  const class RDM_T1_gradient_class &T1_nnn_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , NEUTRON);
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);

  const class RDM_T2_prime_gradient_class &T2_prime_ppp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  const class array<class block_sparse_matrix<TYPE> > &Q_pp_der_pn_block_matrices = Q_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_nn_der_pn_block_matrices = Q_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pn_block_matrices = Q_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_der_pn_block_matrices = G_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_nn_der_pn_block_matrices = G_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_der_pn_block_matrices = G_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_np_der_pn_block_matrices = G_np_gradient.get_block_matrices (PROTONS_NEUTRONS);
      
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_der_pn_block_matrices = T1_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnn_der_pn_block_matrices = T1_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pn_block_matrices = T1_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pn_block_matrices = T1_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);

  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_der_pn_block_matrices = T2_prime_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnn_der_pn_block_matrices = T2_prime_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
  
  F_der_pn.zero ();
  
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
		    	      
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    
	      const class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix = Q_pp_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix = Q_nn_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix = Q_pn_der_pn_block_matrices(BPp , Jp , index_prime);
	      		
	      class matrix<TYPE> &F_der_pn_BPp_Jp = F_der_pn(BPp + 2*Jp);
	  
	      TYPE &F_der_pn_ME = F_der_pn_BPp_Jp(ip , jp);
	      
	      if (Q_pp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (Q_pp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , Q_pp_der_pn_block_matrix);
	      if (Q_nn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (Q_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , Q_nn_der_pn_block_matrix);
	      if (Q_pn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (Q_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , Q_pn_der_pn_block_matrix);
	    
	      if (is_there_G_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix = G_pp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix = G_nn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix = G_pn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix = G_np_der_pn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (G_pp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_pp_der_pn_block_matrix);	    
		  if (G_nn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (G_nn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_nn_der_pn_block_matrix);	    
		  if (G_pn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (G_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_pn_der_pn_block_matrix);	    
		  if (G_np_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (G_np_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , G_np_der_pn_block_matrix);
		}
	      
	      if (are_there_J_constraints)
		{
		  F_der_pn_ME -= Frobenius_scalar_product_matrix_gradient (true , BPp , Jp , index_prime , J_constraints_pp_Lambda_plus_sigma_X_minus_A_Gamma , J_constraints_pp_gradient);	    	    
		  F_der_pn_ME -= Frobenius_scalar_product_matrix_gradient (true , BPp , Jp , index_prime , J_constraints_nn_Lambda_plus_sigma_X_minus_A_Gamma , J_constraints_nn_gradient);	
		}
		
	      if (is_there_T1_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix = T1_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix = T1_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix = T1_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix = T1_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
		
		  if (T1_ppp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T1_ppp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_ppp_der_pn_block_matrix);		
		  if (T1_nnn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T1_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_nnn_der_pn_block_matrix);		
		  if (T1_ppn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T1_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_ppn_der_pn_block_matrix);		
		  if (T1_nnp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T1_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T1_nnp_der_pn_block_matrix);
		}
	      
	      if (is_there_T2_prime_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix = T2_prime_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix = T2_prime_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix = T2_prime_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix = T2_prime_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix = T2_prime_pnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix = T2_prime_pnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_ppp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_ppp_der_pn_block_matrix);		
		  if (T2_prime_nnn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_nnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_nnn_der_pn_block_matrix);		
		  if (T2_prime_ppn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_ppn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_ppn_der_pn_block_matrix);		
		  if (T2_prime_nnp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_nnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_nnp_der_pn_block_matrix);		
		  if (T2_prime_pnp_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_pnp_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_pnp_der_pn_block_matrix);		
		  if (T2_prime_pnn_der_pn_block_matrix.is_it_filled ()) F_der_pn_ME -= Frobenius_scalar_product (T2_prime_pnn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix , T2_prime_pnn_der_pn_block_matrix);
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) F_der_pn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	const unsigned int BPp_Jp_index = BPp + 2*Jp;
	
	const class matrix<TYPE> &Delta_E_reference_der_pn_block_matrix_BPp_Jp = Delta_E_reference_der_pn_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_pn_block_matrix_BPp_Jp = Delta_Hcm_der_pn_block_matrix(BPp_Jp_index);
		
	const class matrix<TYPE> &P_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp = P_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix(BPp_Jp_index);
	
	class matrix<TYPE> &F_der_pn_BPp_Jp = F_der_pn(BPp_Jp_index);

	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip <= jp ; ip++)
	    {
	      TYPE &F_der_pn_ME = F_der_pn_BPp_Jp(ip , jp);
	    
	      F_der_pn_ME -= (ip == jp) ? (P_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp(ip , ip)) : (2.0*P_pn_Lambda_plus_sigma_X_minus_A_Gamma_block_matrix_BPp_Jp(ip , jp));
	      
	      if (is_there_E_reference) F_der_pn_ME -= Delta_E_reference_Lambda_plus_sigma_X_minus_A_Gamma*Delta_E_reference_der_pn_block_matrix_BPp_Jp(ip , jp);
	    
	      if (is_there_CM_correction) F_der_pn_ME -= Delta_Hcm_Lambda_plus_sigma_X_minus_A_Gamma*Delta_Hcm_der_pn_block_matrix_BPp_Jp(ip , jp);
	      
	      if (ba_from_ab_pn_indices(BPp , Jp , ip) == jp) F_der_pn_ME -= average_T2_Lambda_plus_sigma_X_minus_A_Gamma*average_T2_der_pn_tab(BPp , Jp , ip);	      
	    }
	
	const TYPE Lambda_plus_sigma_X_minus_A_Gamma_Delta_pn_pairs_number_MEs = Delta_pn_pairs_number_Lambda_plus_sigma_X_minus_A_Gamma*(2*Jp + 1);
	    
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {	    	    
	    TYPE &F_der_pn_ME = F_der_pn_BPp_Jp(ip , ip);

	    F_der_pn_ME -= Lambda_plus_sigma_X_minus_A_Gamma_Delta_pn_pairs_number_MEs;
	    
	    F_der_pn_ME -= Delta_J_Lambda_plus_sigma_X_minus_A_Gamma*Delta_J_der_pn_tab(BPp , Jp , ip);
	  }	
	    
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    F_der_pn_BPp_Jp(jp , ip) = F_der_pn_BPp_Jp(ip , jp);
      }
	
  F_der_pn += average_E_der_pn_block_matrix;
}






void RDM_F_gradient::all_F_der_calc (
				     const enum interaction_type inter ,
				     const class nucleons_data &prot_data ,
				     const class nucleons_data &neut_data , 
				     const class TBMEs_class &TBMEs_pn ,
				     const class RDM_PQG_class &Gamma_pp ,
				     const class RDM_PQG_class &Gamma_nn ,
				     const class RDM_PQG_class &Gamma_pn ,
				     const class RDM_conditions_class &A_Gamma ,
				     const class RDM_conditions_class &X ,
				     const class RDM_conditions_class &Lambda ,
				     const class RDM_conditions_gradient_class &A_Gamma_gradients ,
				     const double sigma , 
				     class RDM_conditions_class &B_Gamma ,
				     class block_matrix<TYPE> &average_E_der_pp_block_matrix ,
				     class block_matrix<TYPE> &average_E_der_nn_block_matrix ,
				     class block_matrix<TYPE> &average_E_der_pn_block_matrix , 				 
				     class block_matrix<TYPE> &F_der_pp ,
				     class block_matrix<TYPE> &F_der_nn ,		 
				     class block_matrix<TYPE> &F_der_pn , 				 
				     class block_matrix<TYPE> &F_der_rho_pp , 				 
				     class block_matrix<TYPE> &F_der_rho_nn)
{
  const double H_renormalization_factor = A_Gamma.get_H_renormalization_factor ();
  
  B_Gamma  = X;
  B_Gamma -= A_Gamma;
  B_Gamma *= sigma;
  B_Gamma += Lambda;      
	   	        
  average_E_der_tabs_calc (false , inter , H_renormalization_factor , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , A_Gamma_gradients , average_E_der_pp_block_matrix , average_E_der_nn_block_matrix , average_E_der_pn_block_matrix);
      
  F_der_pp_nn_calc (PROTON  , average_E_der_pp_block_matrix , B_Gamma , A_Gamma_gradients , F_der_pp , F_der_rho_pp);
  F_der_pp_nn_calc (NEUTRON , average_E_der_nn_block_matrix , B_Gamma , A_Gamma_gradients , F_der_nn , F_der_rho_nn);
  
  F_der_pn_calc (average_E_der_pn_block_matrix , B_Gamma , A_Gamma_gradients , F_der_pn);	  
}



