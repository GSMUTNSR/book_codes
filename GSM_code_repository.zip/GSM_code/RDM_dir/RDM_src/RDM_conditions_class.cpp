#include "../RDM_include/RDM_include_def.h"

using namespace RDM_Hessian_vector_no_sigma;
using namespace RDM_rho_observables;
using namespace RDM_optimization_augmented_Lagrangian;

RDM_conditions_class::RDM_conditions_class () :
  inter (NO_INTERACTION) ,
  TBMEs_pn_ptr (NULL) ,
  RDM_matrix_constraint (NO_RDM_CONSTRAINT) ,  
  is_there_G_constraint (false) ,  
  is_there_T1_constraint (false) ,  
  is_there_T2_prime_constraint (false) ,  
  is_there_CM_correction (false) ,  
  is_there_isospin_constraint (false) ,  
  are_there_J_constraints (false) ,
  is_there_E_reference (false) ,  
  J (0.0) ,
  E_reference (0.0) ,
  H_renormalization_factor (0.0) ,
  are_there_pp_pairs (false) ,
  are_there_nn_pairs (false) ,  
  are_there_pn_pairs (false) ,   
  Delta_pp_pairs_number_dependent_term (0.0) ,
  Delta_nn_pairs_number_dependent_term (0.0) ,  
  Delta_pn_pairs_number_dependent_term (0.0) ,  
  Delta_J_dependent_term (0.0) , 
  Delta_Hcm_dependent_term (0.0) ,
  average_T2_dependent_term (0.0) ,
  Delta_E_reference_dependent_term (0.0) ,
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL)
{}
    
RDM_conditions_class::RDM_conditions_class (
					    const enum interaction_type inter_c ,
					    const class TBMEs_class &TBMEs_pn ,
					    const enum RDM_matrix_constraint_type RDM_matrix_constraint_c ,
					    const bool is_there_CM_correction_c ,
					    const bool is_there_isospin_constraint_c ,
					    const bool are_there_J_constraints_c ,
					    const bool is_there_E_reference_c ,
					    const bool truncation_hw ,
					    const bool truncation_ph ,
					    const int E_max_hw ,
					    const int n_scat_max ,
					    const double J_c , 
					    const TYPE E_reference_c ,
					    const double H_renormalization_factor_c ,
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data) :
  inter (NO_INTERACTION) ,
  TBMEs_pn_ptr (NULL) ,
  RDM_matrix_constraint (NO_RDM_CONSTRAINT) ,  
  is_there_G_constraint (false) ,  
  is_there_T1_constraint (false) ,  
  is_there_T2_prime_constraint (false) ,  
  is_there_CM_correction (false) ,
  is_there_isospin_constraint (false) ,
  are_there_J_constraints (false) ,
  is_there_E_reference (false) ,
  J (0.0) ,
  E_reference (0.0) ,
  H_renormalization_factor (0.0) ,
  are_there_pp_pairs (false) ,
  are_there_nn_pairs (false) , 
  are_there_pn_pairs (false) ,   
  Delta_pp_pairs_number_dependent_term (0.0) ,
  Delta_nn_pairs_number_dependent_term (0.0) , 
  Delta_pn_pairs_number_dependent_term (0.0) ,   
  Delta_J_dependent_term (0.0) ,   
  Delta_Hcm_dependent_term (0.0) , 
  average_T2_dependent_term (0.0) , 
  Delta_E_reference_dependent_term (0.0) ,
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL)
{
  allocate (inter_c , TBMEs_pn , RDM_matrix_constraint_c , is_there_CM_correction_c , is_there_isospin_constraint_c , are_there_J_constraints_c , is_there_E_reference_c ,
	    truncation_hw , truncation_ph , E_max_hw , n_scat_max , J_c , E_reference_c , H_renormalization_factor_c , prot_data , neut_data);
}

RDM_conditions_class::RDM_conditions_class (const class RDM_conditions_class &X) :
  inter (NO_INTERACTION) ,
  TBMEs_pn_ptr (NULL) ,
  RDM_matrix_constraint (NO_RDM_CONSTRAINT) ,   
  is_there_G_constraint (false) ,  
  is_there_T1_constraint (false) ,  
  is_there_T2_prime_constraint (false) ,  
  is_there_CM_correction (false) , 
  is_there_isospin_constraint (false) , 
  are_there_J_constraints (false) ,
  is_there_E_reference (false) ,
  J (0.0) ,
  E_reference (0.0) ,
  H_renormalization_factor (0.0) ,
  are_there_pp_pairs (false) ,
  are_there_nn_pairs (false) ,  
  are_there_pn_pairs (false) ,     
  Delta_pp_pairs_number_dependent_term (0.0) ,
  Delta_nn_pairs_number_dependent_term (0.0) ,  
  Delta_pn_pairs_number_dependent_term (0.0) ,  
  Delta_J_dependent_term (0.0) ,    
  Delta_Hcm_dependent_term (0.0) ,  
  average_T2_dependent_term (0.0) ,
  Delta_E_reference_dependent_term (0.0) ,
  prot_data_ptr (NULL) ,
  neut_data_ptr (NULL)
{
  allocate_fill (X);
}

void RDM_conditions_class::allocate (
				     const enum interaction_type inter_c ,
				     const class TBMEs_class &TBMEs_pn ,
				     const enum RDM_matrix_constraint_type RDM_matrix_constraint_c ,
				     const bool is_there_CM_correction_c ,
				     const bool is_there_isospin_constraint_c ,
				     const bool are_there_J_constraints_c ,
				     const bool is_there_E_reference_c ,
				     const bool truncation_hw ,
				     const bool truncation_ph ,
				     const int E_max_hw ,
				     const int n_scat_max , 
				     const double J_c ,
				     const TYPE E_reference_c ,
				     const double H_renormalization_factor_c ,
				     const class nucleons_data &prot_data ,
				     const class nucleons_data &neut_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_conditions_class::allocate");
  
  inter = inter_c;
  
  TBMEs_pn_ptr = &TBMEs_pn;
				       
  RDM_matrix_constraint = RDM_matrix_constraint_c;

  is_there_G_constraint = is_there_G_constraint_determine (RDM_matrix_constraint);
  
  is_there_T1_constraint = is_there_T1_constraint_determine (RDM_matrix_constraint);
  
  is_there_T2_prime_constraint = is_there_T2_prime_constraint_determine (RDM_matrix_constraint);
  
  is_there_CM_correction = is_there_CM_correction_c;
  
  is_there_isospin_constraint = is_there_isospin_constraint_c;

  are_there_J_constraints = are_there_J_constraints_c;

  is_there_E_reference = is_there_E_reference_c;
				       
  J = J_c;
  				       
  E_reference = E_reference_c;
  
  H_renormalization_factor = H_renormalization_factor_c;
  
  prot_data_ptr = &prot_data;  
  neut_data_ptr = &neut_data;
    
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
  
  are_there_pp_pairs = (Zval >= 2);
  are_there_nn_pairs = (Nval >= 2);
    
  are_there_pn_pairs = ((Zval >= 1) && (Nval >= 1));
  
  if (are_there_J_constraints)
    {
      rho_pp_coupled_modified_dependent_term.allocate (are_there_J_constraints , J , prot_data);
      rho_nn_coupled_modified_dependent_term.allocate (are_there_J_constraints , J , neut_data);
      
      J_constraints_pp_dependent_term.allocate (PROTON  , J , prot_data , neut_data);
      J_constraints_nn_dependent_term.allocate (NEUTRON , J , prot_data , neut_data);      
    }

  Wigner_6j_hats_G.alloc_calc_store (prot_data , neut_data);
  
  P_pp_dependent_term.allocate (PROTONS_ONLY     , PROTON  , false , false , E_max_hw , n_scat_max , true , false , prot_data , neut_data);
  P_nn_dependent_term.allocate (NEUTRONS_ONLY    , NEUTRON , false , false , E_max_hw , n_scat_max , true , false , prot_data , neut_data);
  P_pn_dependent_term.allocate (PROTONS_NEUTRONS , NEUTRON , false , false , E_max_hw , n_scat_max , true , false , prot_data , neut_data);
  
  Q_pp_dependent_term.allocate (PROTONS_ONLY     , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , false , true , prot_data , neut_data);
  Q_nn_dependent_term.allocate (NEUTRONS_ONLY    , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , false , true , prot_data , neut_data);
  Q_pn_dependent_term.allocate (PROTONS_NEUTRONS , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , false , true , prot_data , neut_data);

  if (is_there_G_constraint)
    {
      G_pp_dependent_term.allocate (PROTONS_ONLY     , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_G);
      G_nn_dependent_term.allocate (NEUTRONS_ONLY    , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_G);
      G_pn_dependent_term.allocate (PROTONS_NEUTRONS , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_G);
      G_np_dependent_term.allocate (PROTONS_NEUTRONS , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_G);
    }
  
  if (is_there_T1_constraint)
    {
      Wigner_6j_hats_T1.alloc_calc_store (prot_data , neut_data);
      
      T1_ppp_dependent_term.allocate (PROTONS_ONLY  , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_T1);
      T1_nnn_dependent_term.allocate (NEUTRONS_ONLY , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_T1);
      T1_ppn_dependent_term.allocate (PROTONS_ONLY  , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_T1);
      T1_nnp_dependent_term.allocate (NEUTRONS_ONLY , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_6j_hats_T1);
    }
  
  if (is_there_T2_prime_constraint)
    {  
      Wigner_9j_hats_T2.alloc_calc_store (prot_data , neut_data);

      T2_prime_ppp_dependent_term.allocate (PROTONS_ONLY     , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
      T2_prime_nnn_dependent_term.allocate (NEUTRONS_ONLY    , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
      T2_prime_ppn_dependent_term.allocate (PROTONS_ONLY     , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
      T2_prime_nnp_dependent_term.allocate (NEUTRONS_ONLY    , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
      T2_prime_pnp_dependent_term.allocate (PROTONS_NEUTRONS , PROTON  , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
      T2_prime_pnn_dependent_term.allocate (PROTONS_NEUTRONS , NEUTRON , truncation_hw , truncation_ph , E_max_hw , n_scat_max , prot_data , neut_data , Wigner_9j_hats_T2);
    }
}


void RDM_conditions_class::allocate_fill (const class RDM_conditions_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_PQG_class cannot be allocated twice in RDM_conditions_class::allocate_fill");
  
  inter = X.inter;
  
  TBMEs_pn_ptr = X.TBMEs_pn_ptr;
  
  RDM_matrix_constraint = X.RDM_matrix_constraint;
  
  is_there_G_constraint = X.is_there_G_constraint;
  
  is_there_T1_constraint = X.is_there_T1_constraint;
  
  is_there_T2_prime_constraint = X.is_there_T2_prime_constraint;
  
  is_there_CM_correction = X.is_there_CM_correction;
  
  is_there_isospin_constraint = X.is_there_isospin_constraint;

  are_there_J_constraints = X.are_there_J_constraints;

  is_there_E_reference = X.is_there_E_reference;
  
  J = X.J;
    
  E_reference = X.E_reference;
  
  H_renormalization_factor = X.H_renormalization_factor;
  
  prot_data_ptr = X.prot_data_ptr;
  neut_data_ptr = X.neut_data_ptr;
  
  are_there_pp_pairs = X.are_there_pp_pairs;
  are_there_nn_pairs = X.are_there_nn_pairs;
  are_there_pn_pairs = X.are_there_pn_pairs;
  
  Delta_pp_pairs_number_dependent_term = X.Delta_pp_pairs_number_dependent_term;
  Delta_nn_pairs_number_dependent_term = X.Delta_nn_pairs_number_dependent_term;
  Delta_pn_pairs_number_dependent_term = X.Delta_pn_pairs_number_dependent_term;
    
  Delta_J_dependent_term = X.Delta_J_dependent_term;
  
  Delta_Hcm_dependent_term = X.Delta_Hcm_dependent_term;

  average_T2_dependent_term = X.average_T2_dependent_term;
  
  Delta_E_reference_dependent_term = X.Delta_E_reference_dependent_term;
    
  rho_pp_coupled_modified_dependent_term.allocate_fill (X.rho_pp_coupled_modified_dependent_term);
  rho_nn_coupled_modified_dependent_term.allocate_fill (X.rho_nn_coupled_modified_dependent_term);
  
  J_constraints_pp_dependent_term.allocate_fill (X.J_constraints_pp_dependent_term);
  J_constraints_nn_dependent_term.allocate_fill (X.J_constraints_nn_dependent_term);
  
  Wigner_6j_hats_G.allocate_fill (X.Wigner_6j_hats_G);
  
  Wigner_6j_hats_T1.allocate_fill (X.Wigner_6j_hats_T1);
  
  Wigner_9j_hats_T2.allocate_fill (X.Wigner_9j_hats_T2);
  
  P_pp_dependent_term.allocate_fill (X.P_pp_dependent_term);
  P_nn_dependent_term.allocate_fill (X.P_nn_dependent_term);
  P_pn_dependent_term.allocate_fill (X.P_pn_dependent_term);
  
  Q_pp_dependent_term.allocate_fill (X.Q_pp_dependent_term);
  Q_nn_dependent_term.allocate_fill (X.Q_nn_dependent_term);
  Q_pn_dependent_term.allocate_fill (X.Q_pn_dependent_term);
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.allocate_fill (X.G_pp_dependent_term);
      G_nn_dependent_term.allocate_fill (X.G_nn_dependent_term);
      G_pn_dependent_term.allocate_fill (X.G_pn_dependent_term);
      G_np_dependent_term.allocate_fill (X.G_np_dependent_term);
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.allocate_fill (X.T1_ppp_dependent_term);
      T1_nnn_dependent_term.allocate_fill (X.T1_nnn_dependent_term);
      T1_ppn_dependent_term.allocate_fill (X.T1_ppn_dependent_term);
      T1_nnp_dependent_term.allocate_fill (X.T1_nnp_dependent_term);
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term.allocate_fill (X.T2_prime_ppp_dependent_term);
      T2_prime_nnn_dependent_term.allocate_fill (X.T2_prime_nnn_dependent_term);
      T2_prime_ppn_dependent_term.allocate_fill (X.T2_prime_ppn_dependent_term);
      T2_prime_nnp_dependent_term.allocate_fill (X.T2_prime_nnp_dependent_term); 
      T2_prime_pnp_dependent_term.allocate_fill (X.T2_prime_pnp_dependent_term); 
      T2_prime_pnn_dependent_term.allocate_fill (X.T2_prime_pnn_dependent_term);
    }
}

void RDM_conditions_class::deallocate ()
{
  inter = NO_INTERACTION;
  
  TBMEs_pn_ptr = NULL;
  
  RDM_matrix_constraint = NO_RDM_CONSTRAINT;
  
  is_there_G_constraint = false;
  
  is_there_T1_constraint = false;
  
  is_there_T2_prime_constraint = false;
  
  is_there_CM_correction = false;
  
  is_there_isospin_constraint = false;
  
  are_there_J_constraints = false;
  
  is_there_E_reference = false;
  
  J = 0.0;
  
  E_reference = 0.0;
  
  H_renormalization_factor = 0.0;
		   
  prot_data_ptr = NULL;
  neut_data_ptr = NULL;

  are_there_pp_pairs = false;
  are_there_nn_pairs = false;
  are_there_pn_pairs = false;
  
  Delta_pp_pairs_number_dependent_term = 0.0;
  Delta_nn_pairs_number_dependent_term = 0.0;
  Delta_pn_pairs_number_dependent_term = 0.0;
  
  Delta_J_dependent_term = 0.0;
  
  Delta_Hcm_dependent_term = 0.0;

  average_T2_dependent_term = 0.0;
  
  Delta_E_reference_dependent_term = 0.0;
  
  Wigner_6j_hats_G.deallocate ();
  
  Wigner_6j_hats_T1.deallocate ();
  
  Wigner_9j_hats_T2.deallocate ();
  
  P_pp_dependent_term.deallocate ();
  P_nn_dependent_term.deallocate ();
  P_pn_dependent_term.deallocate ();
  
  Q_pp_dependent_term.deallocate ();
  Q_nn_dependent_term.deallocate ();
  Q_pn_dependent_term.deallocate ();
  
  G_pp_dependent_term.deallocate ();
  G_nn_dependent_term.deallocate ();
  G_pn_dependent_term.deallocate ();
  G_np_dependent_term.deallocate ();
  
  rho_pp_coupled_modified_dependent_term.deallocate ();
  rho_nn_coupled_modified_dependent_term.deallocate ();
  
  J_constraints_pp_dependent_term.deallocate ();
  J_constraints_nn_dependent_term.deallocate ();
  
  T1_ppp_dependent_term.deallocate ();
  T1_nnn_dependent_term.deallocate ();
  T1_ppn_dependent_term.deallocate ();
  T1_nnp_dependent_term.deallocate ();
  
  T2_prime_ppp_dependent_term.deallocate ();
  T2_prime_nnn_dependent_term.deallocate ();
  T2_prime_ppn_dependent_term.deallocate ();
  T2_prime_nnp_dependent_term.deallocate ();
  T2_prime_pnp_dependent_term.deallocate ();
  T2_prime_pnn_dependent_term.deallocate ();
}




void RDM_conditions_class::zero ()
{
  Delta_pp_pairs_number_dependent_term = 0.0;
  Delta_nn_pairs_number_dependent_term = 0.0;
  Delta_pn_pairs_number_dependent_term = 0.0;
  
  Delta_J_dependent_term = 0.0;
  
  Delta_Hcm_dependent_term = 0.0;

  average_T2_dependent_term = 0.0;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term = 0.0;
    
  if (are_there_J_constraints)
    {  
      rho_pp_coupled_modified_dependent_term.zero ();
      rho_nn_coupled_modified_dependent_term.zero ();
      
      J_constraints_pp_dependent_term.zero ();
      J_constraints_nn_dependent_term.zero ();
    }
  
  P_pp_dependent_term.zero ();
  P_nn_dependent_term.zero ();
  P_pn_dependent_term.zero ();
  
  Q_pp_dependent_term.zero ();
  Q_nn_dependent_term.zero ();
  Q_pn_dependent_term.zero ();
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.zero ();
      G_nn_dependent_term.zero ();
      G_pn_dependent_term.zero ();
      G_np_dependent_term.zero ();
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.zero ();
      T1_nnn_dependent_term.zero ();
      T1_ppn_dependent_term.zero ();
      T1_nnp_dependent_term.zero ();
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term.zero ();
      T2_prime_nnn_dependent_term.zero ();
      T2_prime_ppn_dependent_term.zero ();
      T2_prime_nnp_dependent_term.zero ();
      T2_prime_pnp_dependent_term.zero ();
      T2_prime_pnn_dependent_term.zero ();
    }
}








void RDM_conditions_class::operator = (const class RDM_conditions_class &X)
{
  Delta_pp_pairs_number_dependent_term = X.Delta_pp_pairs_number_dependent_term;
  Delta_nn_pairs_number_dependent_term = X.Delta_nn_pairs_number_dependent_term;
  Delta_pn_pairs_number_dependent_term = X.Delta_pn_pairs_number_dependent_term;
  
  Delta_J_dependent_term = X.Delta_J_dependent_term;

  if (is_there_CM_correction) Delta_Hcm_dependent_term = X.Delta_Hcm_dependent_term;
    
  average_T2_dependent_term = X.average_T2_dependent_term;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term = X.Delta_E_reference_dependent_term;
  
  if (are_there_J_constraints)
    {    
      rho_pp_coupled_modified_dependent_term = X.rho_pp_coupled_modified_dependent_term;
      rho_nn_coupled_modified_dependent_term = X.rho_nn_coupled_modified_dependent_term;
      
      J_constraints_pp_dependent_term = X.J_constraints_pp_dependent_term;
      J_constraints_nn_dependent_term = X.J_constraints_nn_dependent_term;
    }
  
  P_pp_dependent_term = X.P_pp_dependent_term;
  P_nn_dependent_term = X.P_nn_dependent_term;
  P_pn_dependent_term = X.P_pn_dependent_term;
  
  Q_pp_dependent_term = X.Q_pp_dependent_term;
  Q_nn_dependent_term = X.Q_nn_dependent_term;
  Q_pn_dependent_term = X.Q_pn_dependent_term;
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term = X.G_pp_dependent_term;
      G_nn_dependent_term = X.G_nn_dependent_term;
      G_pn_dependent_term = X.G_pn_dependent_term;
      G_np_dependent_term = X.G_np_dependent_term;
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term = X.T1_ppp_dependent_term;
      T1_nnn_dependent_term = X.T1_nnn_dependent_term;
      T1_ppn_dependent_term = X.T1_ppn_dependent_term;
      T1_nnp_dependent_term = X.T1_nnp_dependent_term;
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term = X.T2_prime_ppp_dependent_term;
      T2_prime_nnn_dependent_term = X.T2_prime_nnn_dependent_term;
      T2_prime_ppn_dependent_term = X.T2_prime_ppn_dependent_term;
      T2_prime_nnp_dependent_term = X.T2_prime_nnp_dependent_term; 
      T2_prime_pnp_dependent_term = X.T2_prime_pnp_dependent_term; 
      T2_prime_pnn_dependent_term = X.T2_prime_pnn_dependent_term;
    }
}





void RDM_conditions_class::operator += (const class RDM_conditions_class &X)
{
  Delta_pp_pairs_number_dependent_term += X.Delta_pp_pairs_number_dependent_term;
  Delta_nn_pairs_number_dependent_term += X.Delta_nn_pairs_number_dependent_term;
  Delta_pn_pairs_number_dependent_term += X.Delta_pn_pairs_number_dependent_term;
  
  Delta_J_dependent_term += X.Delta_J_dependent_term;

  if (is_there_CM_correction) Delta_Hcm_dependent_term += X.Delta_Hcm_dependent_term;

  average_T2_dependent_term += X.average_T2_dependent_term;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term += X.Delta_E_reference_dependent_term;
  
  if (are_there_J_constraints)
    {  
      rho_pp_coupled_modified_dependent_term += X.rho_pp_coupled_modified_dependent_term;
      rho_nn_coupled_modified_dependent_term += X.rho_nn_coupled_modified_dependent_term;
      
      J_constraints_pp_dependent_term += X.J_constraints_pp_dependent_term;
      J_constraints_nn_dependent_term += X.J_constraints_nn_dependent_term;
    }
  
  P_pp_dependent_term += X.P_pp_dependent_term;
  P_nn_dependent_term += X.P_nn_dependent_term;
  P_pn_dependent_term += X.P_pn_dependent_term;
  
  Q_pp_dependent_term += X.Q_pp_dependent_term;
  Q_nn_dependent_term += X.Q_nn_dependent_term;
  Q_pn_dependent_term += X.Q_pn_dependent_term;
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term += X.G_pp_dependent_term;
      G_nn_dependent_term += X.G_nn_dependent_term;
      G_pn_dependent_term += X.G_pn_dependent_term;
      G_np_dependent_term += X.G_np_dependent_term;
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term += X.T1_ppp_dependent_term;
      T1_nnn_dependent_term += X.T1_nnn_dependent_term;
      T1_ppn_dependent_term += X.T1_ppn_dependent_term;
      T1_nnp_dependent_term += X.T1_nnp_dependent_term;
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term += X.T2_prime_ppp_dependent_term;
      T2_prime_nnn_dependent_term += X.T2_prime_nnn_dependent_term;
      T2_prime_ppn_dependent_term += X.T2_prime_ppn_dependent_term;
      T2_prime_nnp_dependent_term += X.T2_prime_nnp_dependent_term; 
      T2_prime_pnp_dependent_term += X.T2_prime_pnp_dependent_term; 
      T2_prime_pnn_dependent_term += X.T2_prime_pnn_dependent_term;
    }
}





void RDM_conditions_class::operator -= (const class RDM_conditions_class &X)
{
  Delta_pp_pairs_number_dependent_term -= X.Delta_pp_pairs_number_dependent_term;
  Delta_nn_pairs_number_dependent_term -= X.Delta_nn_pairs_number_dependent_term;
  Delta_pn_pairs_number_dependent_term -= X.Delta_pn_pairs_number_dependent_term;
  
  Delta_J_dependent_term -= X.Delta_J_dependent_term;

  if (is_there_CM_correction) Delta_Hcm_dependent_term -= X.Delta_Hcm_dependent_term;
  
  average_T2_dependent_term -= X.average_T2_dependent_term;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term -= X.Delta_E_reference_dependent_term;
  
  if (are_there_J_constraints)
    {    
      rho_pp_coupled_modified_dependent_term -= X.rho_pp_coupled_modified_dependent_term;
      rho_nn_coupled_modified_dependent_term -= X.rho_nn_coupled_modified_dependent_term;
  
      J_constraints_pp_dependent_term -= X.J_constraints_pp_dependent_term;
      J_constraints_nn_dependent_term -= X.J_constraints_nn_dependent_term;
    }
  
  P_pp_dependent_term -= X.P_pp_dependent_term;
  P_nn_dependent_term -= X.P_nn_dependent_term;
  P_pn_dependent_term -= X.P_pn_dependent_term;
  
  Q_pp_dependent_term -= X.Q_pp_dependent_term;
  Q_nn_dependent_term -= X.Q_nn_dependent_term;
  Q_pn_dependent_term -= X.Q_pn_dependent_term;
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term -= X.G_pp_dependent_term;
      G_nn_dependent_term -= X.G_nn_dependent_term;
      G_pn_dependent_term -= X.G_pn_dependent_term;
      G_np_dependent_term -= X.G_np_dependent_term;
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term -= X.T1_ppp_dependent_term;
      T1_nnn_dependent_term -= X.T1_nnn_dependent_term;
      T1_ppn_dependent_term -= X.T1_ppn_dependent_term;
      T1_nnp_dependent_term -= X.T1_nnp_dependent_term;
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term -= X.T2_prime_ppp_dependent_term;
      T2_prime_nnn_dependent_term -= X.T2_prime_nnn_dependent_term;
      T2_prime_ppn_dependent_term -= X.T2_prime_ppn_dependent_term;
      T2_prime_nnp_dependent_term -= X.T2_prime_nnp_dependent_term; 
      T2_prime_pnp_dependent_term -= X.T2_prime_pnp_dependent_term; 
      T2_prime_pnn_dependent_term -= X.T2_prime_pnn_dependent_term;
    }
}






void RDM_conditions_class::add_scalar_diagonal_part (const TYPE &x)
{
  Delta_pp_pairs_number_dependent_term += x;
  Delta_nn_pairs_number_dependent_term += x;
  Delta_pn_pairs_number_dependent_term += x;
  
  Delta_J_dependent_term += x;

  if (is_there_CM_correction) Delta_Hcm_dependent_term += x;
  
  average_T2_dependent_term += x;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term += x;
  
  if (are_there_J_constraints)
    {    
      rho_pp_coupled_modified_dependent_term.add_scalar_diagonal_part (x);
      rho_nn_coupled_modified_dependent_term.add_scalar_diagonal_part (x);
  
      J_constraints_pp_dependent_term += x;
      J_constraints_nn_dependent_term += x;
    }
  
  P_pp_dependent_term.add_scalar_diagonal_part (x);
  P_nn_dependent_term.add_scalar_diagonal_part (x);
  P_pn_dependent_term.add_scalar_diagonal_part (x);
  
  Q_pp_dependent_term.add_scalar_diagonal_part (x);
  Q_nn_dependent_term.add_scalar_diagonal_part (x);
  Q_pn_dependent_term.add_scalar_diagonal_part (x);
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.add_scalar_diagonal_part (x);
      G_nn_dependent_term.add_scalar_diagonal_part (x);
      G_pn_dependent_term.add_scalar_diagonal_part (x);
      G_np_dependent_term.add_scalar_diagonal_part (x);
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.add_scalar_diagonal_part (x);
      T1_nnn_dependent_term.add_scalar_diagonal_part (x);
      T1_ppn_dependent_term.add_scalar_diagonal_part (x);
      T1_nnp_dependent_term.add_scalar_diagonal_part (x);
    }
  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.add_scalar_diagonal_part (x);
      T2_prime_nnn_dependent_term.add_scalar_diagonal_part (x);
      T2_prime_ppn_dependent_term.add_scalar_diagonal_part (x);
      T2_prime_nnp_dependent_term.add_scalar_diagonal_part (x);
      T2_prime_pnp_dependent_term.add_scalar_diagonal_part (x);
      T2_prime_pnn_dependent_term.add_scalar_diagonal_part (x);
    }
}





void RDM_conditions_class::remove_scalar_diagonal_part (const TYPE &x)
{
  Delta_pp_pairs_number_dependent_term -= x;
  Delta_nn_pairs_number_dependent_term -= x;
  Delta_pn_pairs_number_dependent_term -= x;
  
  Delta_J_dependent_term -= x;

  if (is_there_CM_correction) Delta_Hcm_dependent_term -= x;
  
  average_T2_dependent_term -= x;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term -= x;
  
  if (are_there_J_constraints)
    {  
      rho_pp_coupled_modified_dependent_term.remove_scalar_diagonal_part (x);
      rho_nn_coupled_modified_dependent_term.remove_scalar_diagonal_part (x);
  
      J_constraints_pp_dependent_term -= x;
      J_constraints_nn_dependent_term -= x;
    }
  
  P_pp_dependent_term.remove_scalar_diagonal_part (x);
  P_nn_dependent_term.remove_scalar_diagonal_part (x);
  P_pn_dependent_term.remove_scalar_diagonal_part (x);
  
  Q_pp_dependent_term.remove_scalar_diagonal_part (x);
  Q_nn_dependent_term.remove_scalar_diagonal_part (x);
  Q_pn_dependent_term.remove_scalar_diagonal_part (x);
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.remove_scalar_diagonal_part (x);
      G_nn_dependent_term.remove_scalar_diagonal_part (x);
      G_pn_dependent_term.remove_scalar_diagonal_part (x);
      G_np_dependent_term.remove_scalar_diagonal_part (x);
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.remove_scalar_diagonal_part (x);
      T1_nnn_dependent_term.remove_scalar_diagonal_part (x);
      T1_ppn_dependent_term.remove_scalar_diagonal_part (x);
      T1_nnp_dependent_term.remove_scalar_diagonal_part (x);
    }
  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.remove_scalar_diagonal_part (x);
      T2_prime_nnn_dependent_term.remove_scalar_diagonal_part (x);
      T2_prime_ppn_dependent_term.remove_scalar_diagonal_part (x);
      T2_prime_nnp_dependent_term.remove_scalar_diagonal_part (x);
      T2_prime_pnp_dependent_term.remove_scalar_diagonal_part (x);
      T2_prime_pnn_dependent_term.remove_scalar_diagonal_part (x);
    }
}




void RDM_conditions_class::operator *= (const TYPE &x)
{
  Delta_pp_pairs_number_dependent_term *= x;
  Delta_nn_pairs_number_dependent_term *= x;
  Delta_pn_pairs_number_dependent_term *= x;
  
  Delta_J_dependent_term *= x;

  if (is_there_CM_correction) Delta_Hcm_dependent_term *= x;
  
  average_T2_dependent_term *= x;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term *= x;
  
  if (are_there_J_constraints)
    {    
      rho_pp_coupled_modified_dependent_term *= x;
      rho_nn_coupled_modified_dependent_term *= x;
  
      J_constraints_pp_dependent_term *= x;
      J_constraints_nn_dependent_term *= x;
    }
  
  P_pp_dependent_term *= x;
  P_nn_dependent_term *= x;
  P_pn_dependent_term *= x;
  
  Q_pp_dependent_term *= x;
  Q_nn_dependent_term *= x;
  Q_pn_dependent_term *= x;
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term *= x;
      G_nn_dependent_term *= x;
      G_pn_dependent_term *= x;
      G_np_dependent_term *= x;
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term *= x;
      T1_nnn_dependent_term *= x;
      T1_ppn_dependent_term *= x;
      T1_nnp_dependent_term *= x;
    }
  
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term *= x;
      T2_prime_nnn_dependent_term *= x;
      T2_prime_ppn_dependent_term *= x;
      T2_prime_nnp_dependent_term *= x;
      T2_prime_pnp_dependent_term *= x;
      T2_prime_pnn_dependent_term *= x;
    }
}






void RDM_conditions_class::operator /= (const TYPE &x)
{
  Delta_pp_pairs_number_dependent_term /= x;
  Delta_nn_pairs_number_dependent_term /= x;
  Delta_pn_pairs_number_dependent_term /= x;
  
  Delta_J_dependent_term /= x;

  if (is_there_CM_correction) Delta_Hcm_dependent_term /= x;
  
  average_T2_dependent_term /= x;
  
  if (is_there_E_reference) Delta_E_reference_dependent_term /= x;
  
  if (are_there_J_constraints)
    {    
      rho_pp_coupled_modified_dependent_term /= x;
      rho_nn_coupled_modified_dependent_term /= x;
  
      J_constraints_pp_dependent_term /= x;
      J_constraints_nn_dependent_term /= x;
    }
  
  P_pp_dependent_term /= x;
  P_nn_dependent_term /= x;
  P_pn_dependent_term /= x;
  
  Q_pp_dependent_term /= x;
  Q_nn_dependent_term /= x;
  Q_pn_dependent_term /= x;
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term /= x;
      G_nn_dependent_term /= x;
      G_pn_dependent_term /= x;
      G_np_dependent_term /= x;
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term /= x;
      T1_nnn_dependent_term /= x;
      T1_ppn_dependent_term /= x;
      T1_nnp_dependent_term /= x;
    }
  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term /= x;
      T2_prime_nnn_dependent_term /= x;
      T2_prime_ppn_dependent_term /= x;
      T2_prime_nnp_dependent_term /= x;
      T2_prime_pnp_dependent_term /= x;
      T2_prime_pnn_dependent_term /= x;
    }
}



double RDM_conditions_class::infinite_norm () const
{
  double infinite_norm_value = 0.0;
  
  infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_pp_pairs_number_dependent_term));
  infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_nn_pairs_number_dependent_term));
  infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_pn_pairs_number_dependent_term));
  
  infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_J_dependent_term));
  
  if (is_there_CM_correction) infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_Hcm_dependent_term));
  
  infinite_norm_value = max (infinite_norm_value , inf_norm (average_T2_dependent_term));
    
  if (is_there_E_reference) infinite_norm_value = max (infinite_norm_value , inf_norm (Delta_E_reference_dependent_term));
  
  if (are_there_J_constraints)
    {  
      infinite_norm_value = max (infinite_norm_value , rho_pp_coupled_modified_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , rho_nn_coupled_modified_dependent_term.infinite_norm ());
  
      infinite_norm_value = max (infinite_norm_value , J_constraints_pp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , J_constraints_nn_dependent_term.infinite_norm ());
    }
  
  infinite_norm_value = max (infinite_norm_value , P_pp_dependent_term.infinite_norm ());
  infinite_norm_value = max (infinite_norm_value , P_nn_dependent_term.infinite_norm ());
  infinite_norm_value = max (infinite_norm_value , P_pn_dependent_term.infinite_norm ());
  
  infinite_norm_value = max (infinite_norm_value , Q_pp_dependent_term.infinite_norm ());
  infinite_norm_value = max (infinite_norm_value , Q_nn_dependent_term.infinite_norm ());
  infinite_norm_value = max (infinite_norm_value , Q_pn_dependent_term.infinite_norm ());
  
  if (is_there_G_constraint)
    {
      infinite_norm_value = max (infinite_norm_value , G_pp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , G_nn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , G_pn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , G_np_dependent_term.infinite_norm ());
    }
  
  if (is_there_T1_constraint)
    {    
      infinite_norm_value = max (infinite_norm_value , T1_ppp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T1_nnn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T1_ppn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T1_nnp_dependent_term.infinite_norm ());
    }
      
  if (is_there_T2_prime_constraint)
    {  
      infinite_norm_value = max (infinite_norm_value , T2_prime_ppp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T2_prime_nnn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T2_prime_ppn_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T2_prime_nnp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T2_prime_pnp_dependent_term.infinite_norm ());
      infinite_norm_value = max (infinite_norm_value , T2_prime_pnn_dependent_term.infinite_norm ());
    }
  
  return infinite_norm_value;
}




void RDM_conditions_class::A_Gamma_add (
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn , 
					const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
					const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified)
{
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
    
  const class TBMEs_class &TBMEs_pn = get_TBMEs_pn ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);
  
  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);
  
  Delta_pp_pairs_number_dependent_term += Delta_pp_nn_pairs_number_calc (prot_data , Gamma_pp);
  Delta_nn_pairs_number_dependent_term += Delta_pp_nn_pairs_number_calc (neut_data , Gamma_nn);
 
  Delta_pn_pairs_number_dependent_term += Delta_pn_pairs_number_calc (prot_data , neut_data , Gamma_pn);
  
  Delta_J_dependent_term += Delta_J_calc (prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn , J);
  
  if (is_there_CM_correction) Delta_Hcm_dependent_term += average_CM_op_calc (HCM , true , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);

  average_T2_dependent_term += average_T2_calc (prot_data , neut_data , Gamma_pn);

  if (is_there_E_reference) Delta_E_reference_dependent_term += average_E_calc (true , inter , E_reference , 1.0 , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
      
  if (are_there_J_constraints)
    {
      rho_pp_coupled_modified_dependent_term += rho_pp_coupled_modified;
      rho_nn_coupled_modified_dependent_term += rho_nn_coupled_modified;
  
      J_constraints_pp_dependent_term.J_constraints_matrix_add (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_pp_coupled_modified , Wigner_6j_hats_G);
      J_constraints_nn_dependent_term.J_constraints_matrix_add (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_nn_coupled_modified , Wigner_6j_hats_G);
    }
  
  P_pp_dependent_term += Gamma_pp;
  P_nn_dependent_term += Gamma_nn;
  P_pn_dependent_term += Gamma_pn;

  Q_pp_dependent_term.Q_pp_nn_block_matrices_add (rho_prot_tab , Gamma_pp);
  Q_nn_dependent_term.Q_pp_nn_block_matrices_add (rho_neut_tab , Gamma_nn);
  
  Q_pn_dependent_term.Q_pn_block_matrices_add (rho_prot_tab , rho_neut_tab , Gamma_pn);
  
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.G_pp_nn_block_matrices_add (rho_prot_tab , Gamma_pp);
      G_nn_dependent_term.G_pp_nn_block_matrices_add (rho_neut_tab , Gamma_nn);
  
      G_pn_dependent_term.G_pn_block_matrices_add (rho_prot_tab , Gamma_pn);
      G_np_dependent_term.G_np_block_matrices_add (rho_neut_tab , Gamma_pn);
    }
  
  if (is_there_T1_constraint)
    {    
      T1_ppp_dependent_term.T1_ppp_nnn_block_matrices_add (rho_prot_tab , Gamma_pp);
      T1_nnn_dependent_term.T1_ppp_nnn_block_matrices_add (rho_neut_tab , Gamma_nn);
      
      T1_ppn_dependent_term.T1_ppn_block_matrices_add (rho_prot_tab , rho_neut_tab , Gamma_pp , Gamma_pn);
      T1_nnp_dependent_term.T1_nnp_block_matrices_add (rho_prot_tab , rho_neut_tab , Gamma_nn , Gamma_pn);
    }
      
  if (is_there_T2_prime_constraint)
    {  
      T2_prime_ppp_dependent_term.T2_prime_ppp_nnn_block_matrices_add (rho_prot_tab , Gamma_pp);
      T2_prime_nnn_dependent_term.T2_prime_ppp_nnn_block_matrices_add (rho_neut_tab , Gamma_nn);
  
      T2_prime_ppn_dependent_term.T2_prime_ppn_block_matrices_add (rho_neut_tab , Gamma_pp , Gamma_pn);
      T2_prime_nnp_dependent_term.T2_prime_nnp_block_matrices_add (rho_prot_tab , Gamma_nn , Gamma_pn);
  
      T2_prime_pnp_dependent_term.T2_prime_pnp_block_matrices_add (rho_prot_tab , rho_neut_tab , Gamma_pp , Gamma_pn);
      T2_prime_pnn_dependent_term.T2_prime_pnn_block_matrices_add (rho_prot_tab , rho_neut_tab , Gamma_nn , Gamma_pn);
    }
}



void RDM_conditions_class::A_Gamma_calc (
					 const class RDM_PQG_class &Gamma_pp ,
					 const class RDM_PQG_class &Gamma_nn ,
					 const class RDM_PQG_class &Gamma_pn , 
					 const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
					 const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified)
{
  zero ();

  A_Gamma_add (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified);
}





void RDM_conditions_class::A_Gamma_add_pp_nn_linear_part (
							  const enum particle_type particle , 
							  const class RDM_PQG_class &Gamma_pp_nn ,
							  const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
							  class RDM_conditions_class &helper_add ,
							  class RDM_conditions_gradient_class &A_Gamma_gradients)
{
  const enum particle_type particle_other_space = (particle == PROTON) ? (NEUTRON) : (PROTON);

  const enum space_type space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const class array<unsigned int> &matrix_dimensions = Gamma_pp_nn.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;

  const int jmax_ab_global = rho_pp_nn_coupled_modified.get_jmax_ab_global ();
  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();
  
  const class block_matrix<TYPE> &rho_pp_nn_coupled_modified_block_matrix = rho_pp_nn_coupled_modified.get_block_matrix ();
  
  const class array<double> &Delta_J_der_tab = A_Gamma_gradients.get_Delta_J_der_tab (space);
        
  const class block_matrix<TYPE> &Delta_E_reference_der_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (space);
        
  const class block_matrix<TYPE> &Delta_Hcm_der_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (space);
            
  class RDM_QG_gradient_class &Q_pp_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_Q_gradient (space);
  
  class RDM_QG_gradient_class &Q_pn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  class RDM_QG_gradient_class &G_pp_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (space            , particle);
  class RDM_QG_gradient_class &G_pn_np_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , particle_other_space);
        
  class RDM_J_constraints_gradient_class &J_constraints_pp_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_J_constraints_gradient (particle);
  
  class RDM_T1_gradient_class &T1_ppp_nnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (space , particle);
    
  class RDM_T1_gradient_class &T1_ppn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  class RDM_T1_gradient_class &T1_nnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);
  
  class RDM_T2_prime_gradient_class &T2_prime_ppp_nnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (space , particle);  
  
  class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  class array<class block_sparse_matrix<TYPE> > &Q_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients = Q_pp_nn_gradient_A_Gamma_gradients.get_block_matrices (space);
  
  class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pp_nn_block_matrices_A_Gamma_gradients = Q_pn_gradient_A_Gamma_gradients.get_block_matrices (space);
  
  class array<class block_sparse_matrix<TYPE> > &G_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients = G_pp_nn_gradient_A_Gamma_gradients.get_block_matrices (space);
  class array<class block_sparse_matrix<TYPE> > &G_pn_np_der_pp_nn_block_matrices_A_Gamma_gradients = G_pn_np_gradient_A_Gamma_gradients.get_block_matrices (space);
      
  class array<class block_sparse_matrix<TYPE> > &T1_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients = T1_ppp_nnn_gradient_A_Gamma_gradients.get_block_matrices (space);
  
  class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pp_nn_block_matrices_A_Gamma_gradients = T1_ppn_gradient_A_Gamma_gradients.get_block_matrices (space);
  class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pp_nn_block_matrices_A_Gamma_gradients = T1_nnp_gradient_A_Gamma_gradients.get_block_matrices (space);
  
  class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients = T2_prime_ppp_nnn_gradient_A_Gamma_gradients.get_block_matrices (space);
  		
  class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pp_nn_block_matrices_A_Gamma_gradients = T2_prime_ppn_gradient_A_Gamma_gradients.get_block_matrices (space);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pp_nn_block_matrices_A_Gamma_gradients = T2_prime_nnp_gradient_A_Gamma_gradients.get_block_matrices (space);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pp_nn_block_matrices_A_Gamma_gradients = T2_prime_pnp_gradient_A_Gamma_gradients.get_block_matrices (space);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pp_nn_block_matrices_A_Gamma_gradients = T2_prime_pnn_gradient_A_Gamma_gradients.get_block_matrices (space);
      
  class block_matrix<TYPE> &Q_pp_nn_dependent_term_block_matrix_helper_add = helper_add.get_Q_dependent_term_block_matrix (space);
  
  class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix_helper_add = helper_add.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
    
  class RDM_J_constraints_class &J_constraints_pp_nn_dependent_term_helper_add = helper_add.get_J_constraints_dependent_term (particle);
	  
  class block_matrix<TYPE> &G_pp_nn_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (space , particle);
  class block_matrix<TYPE> &G_pn_np_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , particle_other_space);
	  
  class block_matrix<TYPE> &T1_ppp_nnn_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (space , particle);  

  class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
  class block_matrix<TYPE> &T2_prime_ppp_nnn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (space , particle);
    
  class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
	  		  
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
           
  if (BPp_Jp_index_prime_dimension > 0)
    {      
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
  
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);
	
	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	  
	      const class matrix<TYPE> &Gamma_pp_nn_BPp_Jp = Gamma_pp_nn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_BPp_Jp(ip , jp);

	      if (Gamma_pp_nn_ME == 0.0) continue;
	      	      	    	  
	      class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
	      class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;	 
	  
	      if (Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
	      
	      if (is_there_G_constraint)
		{
		  class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = G_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients = G_pn_np_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	           
		  if (G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		  if (G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		}
	      
	      if (are_there_J_constraints) J_constraints_pp_nn_gradient_A_Gamma_gradients.multiply_part (false , BPp , Jp , index_prime , Gamma_pp_nn_ME);
	    
	      if (is_there_T1_constraint)
		{    
		  class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T1_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
		  if (T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
	  
		  if (T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;		  
		  if (T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		}
      
	      if (is_there_T2_prime_constraint)
		{ 
		  class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  

		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
	  
		  if (T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;		  
		  if (T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		  if (T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		  if (T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients *= Gamma_pp_nn_ME;
		}
	    }
  
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);
	
	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	  
	      const class matrix<TYPE> &Gamma_pp_nn_BPp_Jp = Gamma_pp_nn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_BPp_Jp(ip , jp);

	      if (Gamma_pp_nn_ME == 0.0) continue;
	      	      	    	  
	      const class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_nn_dependent_term_block_matrix_helper_add += Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients;	  
	  
	      if (Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_dependent_term_block_matrix_helper_add += Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients;
	      	  
	      if (is_there_G_constraint)
		{		
		  const class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = G_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients = G_pn_np_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_nn_dependent_term_block_matrix_helper_add += G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients;
		  if (G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_np_dependent_term_block_matrix_helper_add += G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients;
		}
  
	      if (are_there_J_constraints) J_constraints_pp_nn_dependent_term_helper_add.add_gradient_part (false , BPp , Jp , index_prime , J_constraints_pp_nn_gradient_A_Gamma_gradients);
	      
	      if (is_there_T1_constraint)
		{    
		  const class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T1_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
		  if (T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_nnn_dependent_term_block_matrix_helper_add += T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients;
		  	  
		  if (T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_dependent_term_block_matrix_helper_add += T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients;	      
		  if (T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_dependent_term_block_matrix_helper_add += T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients;
		}
      
	      if (is_there_T2_prime_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);		  

		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_nnn_dependent_term_block_matrix_helper_add += T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients;
	  
		  if (T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_dependent_term_block_matrix_helper_add += T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_dependent_term_block_matrix_helper_add += T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients;
		  if (T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_dependent_term_block_matrix_helper_add += T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_dependent_term_block_matrix_helper_add += T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients;
		}
	    }	

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);
	
	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	  
	      const class matrix<TYPE> &Gamma_pp_nn_BPp_Jp = Gamma_pp_nn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_BPp_Jp(ip , jp);

	      if (Gamma_pp_nn_ME == 0.0) continue;
	      	      	    	  
	      class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
	      class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients = Q_pn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;	
	  
	      if (Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
	            
	      if (is_there_G_constraint)
		{
		  class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients = G_pp_nn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients = G_pn_np_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_nn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		  if (G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_np_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		}
  
	      if (are_there_J_constraints) J_constraints_pp_nn_gradient_A_Gamma_gradients.divide_part (false , BPp , Jp , index_prime , Gamma_pp_nn_ME);
	    
	      if (is_there_T1_constraint)
		{    
		  class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T1_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T1_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
		  if (T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
	  
		  if (T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;		  
		  if (T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		}
      
	      if (is_there_T2_prime_constraint)
		{ 
		  class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppp_nnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		    
		  class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pp_nn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);

		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_nnn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
	  
		  if (T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;		  
		  if (T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		  if (T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		  if (T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_der_pp_nn_block_matrix_A_Gamma_gradients /= Gamma_pp_nn_ME;
		}
	    }
	}     
    }
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      TYPE &Delta_pp_nn_pairs_number_dependent_term_helper_add = helper_add.get_Delta_pairs_number_dependent_term (space);
  
      TYPE &Delta_J_dependent_term_helper_add = helper_add.get_Delta_J_dependent_term ();
  
      TYPE &Delta_E_reference_dependent_term_helper_add = helper_add.get_Delta_E_reference_dependent_term ();
  
      TYPE &Delta_Hcm_dependent_term_helper_add = helper_add.get_Delta_Hcm_dependent_term ();
  
      class block_matrix<TYPE> &P_pp_nn_dependent_term_block_matrix_helper_add = helper_add.get_P_dependent_term_block_matrix (space);
      
      class block_matrix<TYPE> &rho_pp_nn_coupled_modified_dependent_term_block_matrix_helper_add = helper_add.get_rho_coupled_modified_dependent_term_block_matrix (particle);
  
      for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
	for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
	  {	
	    const unsigned int BPp_Jp_index = BPp + 2*Jp;
	    
	    const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	      
	    const int hat_Jp_square = 2*Jp + 1;

	    const class matrix<TYPE> &Delta_E_reference_der_block_matrix_BPp_Jp = Delta_E_reference_der_block_matrix(BPp_Jp_index);
	
	    const class matrix<TYPE> &Delta_Hcm_der_block_matrix_BPp_Jp = Delta_Hcm_der_block_matrix(BPp_Jp_index);
			
	    const class matrix<TYPE> &Gamma_pp_nn_BPp_Jp = Gamma_pp_nn_block_matrix(BPp_Jp_index);	  

	    if (is_there_E_reference || is_there_CM_correction)
	      {
		for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
		  for (unsigned int ip = 0 ; ip <= jp ; ip++)
		    {
		      const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_BPp_Jp(ip , jp);
	
		      if (is_there_E_reference) Delta_E_reference_dependent_term_helper_add += Gamma_pp_nn_ME*Delta_E_reference_der_block_matrix_BPp_Jp(ip , jp);
	      
		      if (is_there_CM_correction) Delta_Hcm_dependent_term_helper_add += Gamma_pp_nn_ME*Delta_Hcm_der_block_matrix_BPp_Jp(ip , jp);
		    }
	      }
	    
	    for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	      {
		const TYPE Gamma_pp_nn_ME = Gamma_pp_nn_BPp_Jp(ip , ip);
	    
		Delta_pp_nn_pairs_number_dependent_term_helper_add += Gamma_pp_nn_ME*hat_Jp_square;

		Delta_J_dependent_term_helper_add += Gamma_pp_nn_ME*Delta_J_der_tab(BPp , Jp , ip);
	      }
	  }

      if (are_there_J_constraints && (jmax_ab_global > 0))
	{
	  for (unsigned int bp = 0 ; bp <= 1 ; bp++)  
	    for (int j = 0 ; j <= 1 ; j++)
	      {	
		const unsigned int bp_j_index = bp + 2*j;
	
		const class matrix<TYPE> &rho_pp_nn_coupled_modified_bp_j = rho_pp_nn_coupled_modified_block_matrix(bp_j_index);
	
		const unsigned int dimension_bp_j = rho_pp_nn_coupled_modified_bp_j.get_dimension ();
			
		for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
		  for (unsigned int sa_bp_index = 0 ; sa_bp_index <= sb_bp_index ; sa_bp_index++)
		    {
		      const TYPE rho_pp_nn_coupled_modified_ME = rho_pp_nn_coupled_modified_bp_j(sa_bp_index , sb_bp_index);
	      
		      J_constraints_pp_nn_dependent_term_helper_add.add_rho_coupled_modified_gradient_part (j , sa_bp_index , sb_bp_index , rho_pp_nn_coupled_modified_ME);
		    }
	      }
  
	  rho_pp_nn_coupled_modified_dependent_term_block_matrix_helper_add = rho_pp_nn_coupled_modified_block_matrix;
	}
      
      P_pp_nn_dependent_term_block_matrix_helper_add = Gamma_pp_nn_block_matrix;
    }
}














void RDM_conditions_class::A_Gamma_add_pn_linear_part (
						       const class RDM_PQG_class &Gamma_pn ,
						       class RDM_conditions_class &helper_add ,
						       class RDM_conditions_gradient_class &A_Gamma_gradients)
{
  const class array<unsigned int> &matrix_dimensions = Gamma_pn.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
    
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
  
  const class array<double> &Delta_J_der_pn_tab = A_Gamma_gradients.get_Delta_J_der_tab (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &ba_from_ab_pn_indices = A_Gamma_gradients.get_ba_from_ab_pn_indices ();
  
  const class array<int> &average_T2_der_pn_tab = A_Gamma_gradients.get_average_T2_der_pn_tab ();
  
  const class block_matrix<TYPE> &Delta_E_reference_der_pn_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (PROTONS_NEUTRONS);
        
  class RDM_QG_gradient_class &Q_pp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_Q_gradient (PROTONS_ONLY);
  class RDM_QG_gradient_class &Q_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_Q_gradient (NEUTRONS_ONLY);
  class RDM_QG_gradient_class &Q_pn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  class RDM_QG_gradient_class &G_pp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (PROTONS_ONLY     , PROTON);
  class RDM_QG_gradient_class &G_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (NEUTRONS_ONLY    , NEUTRON);
  class RDM_QG_gradient_class &G_pn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , NEUTRON);
  class RDM_QG_gradient_class &G_np_gradient_A_Gamma_gradients = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , PROTON);

  class RDM_J_constraints_gradient_class &J_constraints_pp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_J_constraints_gradient (PROTON);
  class RDM_J_constraints_gradient_class &J_constraints_nn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_J_constraints_gradient (NEUTRON);
  
  class RDM_T1_gradient_class &T1_ppp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , PROTON);
  class RDM_T1_gradient_class &T1_nnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , NEUTRON);
  class RDM_T1_gradient_class &T1_ppn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  class RDM_T1_gradient_class &T1_nnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);

  class RDM_T2_prime_gradient_class &T2_prime_ppp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , PROTON);
  class RDM_T2_prime_gradient_class &T2_prime_nnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , NEUTRON);
  class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient_A_Gamma_gradients = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  class array<class block_sparse_matrix<TYPE> > &Q_pp_der_pn_block_matrices_A_Gamma_gradients = Q_pp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &Q_nn_der_pn_block_matrices_A_Gamma_gradients = Q_nn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pn_block_matrices_A_Gamma_gradients = Q_pn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  
  class array<class block_sparse_matrix<TYPE> > &G_pp_der_pn_block_matrices_A_Gamma_gradients = G_pp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &G_nn_der_pn_block_matrices_A_Gamma_gradients = G_nn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &G_pn_der_pn_block_matrices_A_Gamma_gradients = G_pn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &G_np_der_pn_block_matrices_A_Gamma_gradients = G_np_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);

  class array<class block_sparse_matrix<TYPE> > &T1_ppp_der_pn_block_matrices_A_Gamma_gradients = T1_ppp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T1_nnn_der_pn_block_matrices_A_Gamma_gradients = T1_nnn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);  
  class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pn_block_matrices_A_Gamma_gradients = T1_ppn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pn_block_matrices_A_Gamma_gradients = T1_nnp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  
  class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_der_pn_block_matrices_A_Gamma_gradients = T2_prime_ppp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_nnn_der_pn_block_matrices_A_Gamma_gradients = T2_prime_nnn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);  		
  class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pn_block_matrices_A_Gamma_gradients = T2_prime_ppn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pn_block_matrices_A_Gamma_gradients = T2_prime_nnp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pn_block_matrices_A_Gamma_gradients = T2_prime_pnp_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
  class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pn_block_matrices_A_Gamma_gradients = T2_prime_pnn_gradient_A_Gamma_gradients.get_block_matrices (PROTONS_NEUTRONS);
    
  class RDM_J_constraints_class &J_constraints_pp_dependent_term_helper_add = helper_add.get_J_constraints_dependent_term (PROTON);
  class RDM_J_constraints_class &J_constraints_nn_dependent_term_helper_add = helper_add.get_J_constraints_dependent_term (NEUTRON);
  
  class block_matrix<TYPE> &Q_pp_dependent_term_block_matrix_helper_add = helper_add.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &Q_nn_dependent_term_block_matrix_helper_add = helper_add.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix_helper_add = helper_add.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  class block_matrix<TYPE> &G_pp_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &G_nn_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
  class block_matrix<TYPE> &G_pn_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  class block_matrix<TYPE> &G_np_dependent_term_block_matrix_helper_add = helper_add.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
	      
  class block_matrix<TYPE> &T1_ppp_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  class block_matrix<TYPE> &T1_nnn_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix_helper_add = helper_add.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

  class block_matrix<TYPE> &T2_prime_ppp_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &T2_prime_nnn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);
  class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix_helper_add = helper_add.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
		  
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
        
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  	  
      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
	    
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif      
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	      	
	      const class matrix<TYPE> &Gamma_pn_BPp_Jp = Gamma_pn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pn_ME = Gamma_pn_BPp_Jp(ip , jp);

	      if (Gamma_pn_ME == 0.0) continue;
    
	      class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix_A_Gamma_gradients = Q_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix_A_Gamma_gradients = Q_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix_A_Gamma_gradients = Q_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
	      if (Q_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_nn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
	      if (Q_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
	      
	      if (is_there_G_constraint)
		{
		  class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix_A_Gamma_gradients = G_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix_A_Gamma_gradients = G_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix_A_Gamma_gradients = G_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix_A_Gamma_gradients = G_np_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
		  if (G_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_nn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
		  if (G_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
		  if (G_np_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_np_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
	  	}
	      
	      if (are_there_J_constraints)
		{
		  J_constraints_pp_gradient_A_Gamma_gradients.multiply_part (true , BPp , Jp , index_prime , Gamma_pn_ME);
		  J_constraints_nn_gradient_A_Gamma_gradients.multiply_part (true , BPp , Jp , index_prime , Gamma_pn_ME);
		}
	  
	      if (is_there_T1_constraint)
		{    
		  class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix_A_Gamma_gradients = T1_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix_A_Gamma_gradients = T1_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix_A_Gamma_gradients = T1_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix_A_Gamma_gradients = T1_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
		  if (T1_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T1_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	  
		  if (T1_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T1_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
	        }
      
	      if (is_there_T2_prime_constraint)
		{ 
		  class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	  
		  if (T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;	      
		  if (T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients *= Gamma_pn_ME;
		}
	    }

	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	      	
	      const class matrix<TYPE> &Gamma_pn_BPp_Jp = Gamma_pn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pn_ME = Gamma_pn_BPp_Jp(ip , jp);

	      if (Gamma_pn_ME == 0.0) continue;
	          
	      const class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix_A_Gamma_gradients = Q_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix_A_Gamma_gradients = Q_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix_A_Gamma_gradients = Q_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_dependent_term_block_matrix_helper_add += Q_pp_der_pn_block_matrix_A_Gamma_gradients;
	      if (Q_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_nn_dependent_term_block_matrix_helper_add += Q_nn_der_pn_block_matrix_A_Gamma_gradients;
	      if (Q_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_dependent_term_block_matrix_helper_add += Q_pn_der_pn_block_matrix_A_Gamma_gradients;
	      
	      if (is_there_G_constraint)
		{
		  const class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix_A_Gamma_gradients = G_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix_A_Gamma_gradients = G_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix_A_Gamma_gradients = G_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix_A_Gamma_gradients = G_np_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_dependent_term_block_matrix_helper_add += G_pp_der_pn_block_matrix_A_Gamma_gradients;
		  if (G_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_nn_dependent_term_block_matrix_helper_add += G_nn_der_pn_block_matrix_A_Gamma_gradients;
		  if (G_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_dependent_term_block_matrix_helper_add += G_pn_der_pn_block_matrix_A_Gamma_gradients;
		  if (G_np_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_np_dependent_term_block_matrix_helper_add += G_np_der_pn_block_matrix_A_Gamma_gradients;
		}
  
	      if (are_there_J_constraints)
		{
		  J_constraints_pp_dependent_term_helper_add.add_gradient_part (true , BPp , Jp , index_prime , J_constraints_pp_gradient_A_Gamma_gradients);
		  J_constraints_nn_dependent_term_helper_add.add_gradient_part (true , BPp , Jp , index_prime , J_constraints_nn_gradient_A_Gamma_gradients);
		}
	  
	      if (is_there_T1_constraint)
		{    
		  const class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix_A_Gamma_gradients = T1_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix_A_Gamma_gradients = T1_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix_A_Gamma_gradients = T1_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix_A_Gamma_gradients = T1_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
  
		  if (T1_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_dependent_term_block_matrix_helper_add += T1_ppp_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T1_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnn_dependent_term_block_matrix_helper_add += T1_nnn_der_pn_block_matrix_A_Gamma_gradients;	  
		  if (T1_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_dependent_term_block_matrix_helper_add += T1_ppn_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T1_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_dependent_term_block_matrix_helper_add += T1_nnp_der_pn_block_matrix_A_Gamma_gradients;
	        }
      
	      if (is_there_T2_prime_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_dependent_term_block_matrix_helper_add += T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnn_dependent_term_block_matrix_helper_add += T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients;	  
		  if (T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_dependent_term_block_matrix_helper_add += T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_dependent_term_block_matrix_helper_add += T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_dependent_term_block_matrix_helper_add += T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients;	      
		  if (T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_dependent_term_block_matrix_helper_add += T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients;
		}
	    }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif      
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	    	      	
	      const class matrix<TYPE> &Gamma_pn_BPp_Jp = Gamma_pn_block_matrix(BPp + 2*Jp);
	  
	      const TYPE Gamma_pn_ME = Gamma_pn_BPp_Jp(ip , jp);

	      if (Gamma_pn_ME == 0.0) continue;
    
	      class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix_A_Gamma_gradients = Q_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix_A_Gamma_gradients = Q_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix_A_Gamma_gradients = Q_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
	      if (Q_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
	      if (Q_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_nn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
	      if (Q_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) Q_pn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
	      
	      if (is_there_G_constraint)
		{
		  class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix_A_Gamma_gradients = G_pp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix_A_Gamma_gradients = G_nn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix_A_Gamma_gradients = G_pn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix_A_Gamma_gradients = G_np_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		  if (G_nn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_nn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		  if (G_pn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_pn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		  if (G_np_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) G_np_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		}
  
	      if (are_there_J_constraints)
		{
		  J_constraints_pp_gradient_A_Gamma_gradients.divide_part (true , BPp , Jp , index_prime , Gamma_pn_ME);
		  J_constraints_nn_gradient_A_Gamma_gradients.divide_part (true , BPp , Jp , index_prime , Gamma_pn_ME);
		}
	  
	      if (is_there_T1_constraint)
		{    
		  class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix_A_Gamma_gradients = T1_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix_A_Gamma_gradients = T1_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix_A_Gamma_gradients = T1_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix_A_Gamma_gradients = T1_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (T1_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T1_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	  
		  if (T1_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_ppn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T1_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T1_nnp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		}
      
	      if (is_there_T2_prime_constraint)
		{  
		  class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_ppn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_nnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnp_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients = T2_prime_pnn_der_pn_block_matrices_A_Gamma_gradients(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	  
		  if (T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_ppn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_nnp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnp_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;	      
		  if (T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients.is_it_filled ()) T2_prime_pnn_der_pn_block_matrix_A_Gamma_gradients /= Gamma_pn_ME;
		}
	    }
	}
    }
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      TYPE &Delta_pn_pairs_number_dependent_term_helper_add = helper_add.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);
  
      TYPE &Delta_J_dependent_term_helper_add = helper_add.get_Delta_J_dependent_term ();
  
      TYPE &Delta_E_reference_dependent_term_helper_add = helper_add.get_Delta_E_reference_dependent_term ();
  
      TYPE &Delta_Hcm_dependent_term_helper_add = helper_add.get_Delta_Hcm_dependent_term ();
  
      TYPE &average_T2_dependent_term_helper_add=  helper_add.get_average_T2_dependent_term ();
      
      class block_matrix<TYPE> &P_pn_dependent_term_block_matrix_helper_add = helper_add.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

      for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
	for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
	  {	
	    const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	    const int hat_Jp_square = 2*Jp + 1;

	    const class matrix<TYPE> &Delta_E_reference_der_pn_block_matrix_BPp_Jp = Delta_E_reference_der_pn_block_matrix(BPp + 2*Jp);
	
	    const class matrix<TYPE> &Delta_Hcm_der_pn_block_matrix_BPp_Jp = Delta_Hcm_der_pn_block_matrix(BPp + 2*Jp);
			
	    const class matrix<TYPE> &Gamma_pn_BPp_Jp = Gamma_pn_block_matrix(BPp + 2*Jp);

	    for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	      for (unsigned int ip = 0 ; ip <= jp ; ip++)
		{
		  const TYPE Gamma_pn_ME = Gamma_pn_BPp_Jp(ip , jp);
	    	    
		  if (is_there_E_reference) Delta_E_reference_dependent_term_helper_add += Gamma_pn_ME*Delta_E_reference_der_pn_block_matrix_BPp_Jp(ip , jp);
	    
		  if (is_there_CM_correction) Delta_Hcm_dependent_term_helper_add += Gamma_pn_ME*Delta_Hcm_der_pn_block_matrix_BPp_Jp(ip , jp);

		  if (ba_from_ab_pn_indices(BPp , Jp , ip) == jp) average_T2_dependent_term_helper_add += Gamma_pn_ME*average_T2_der_pn_tab(BPp , Jp , ip);
		}
	
	    for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	      {
		const TYPE Gamma_pn_ME = Gamma_pn_BPp_Jp(ip , ip);
	    	    
		Delta_pn_pairs_number_dependent_term_helper_add += Gamma_pn_ME*hat_Jp_square;

		Delta_J_dependent_term_helper_add += Gamma_pn_ME*Delta_J_der_pn_tab(BPp , Jp , ip);
	      }
	  }
      
      P_pn_dependent_term_block_matrix_helper_add = Gamma_pn_block_matrix;
    }
}











void RDM_conditions_class::A_Gamma_add_linear_part (
						    const class RDM_PQG_class &Gamma_pp ,
						    const class RDM_PQG_class &Gamma_nn ,
						    const class RDM_PQG_class &Gamma_pn ,
						    const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
						    const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
						    class RDM_conditions_class &helper_add ,
						    class RDM_conditions_gradient_class &A_Gamma_gradients)
{
  class RDM_conditions_class &A_Gamma = *this;
  
  helper_add.zero ();
  
  A_Gamma_add_pp_nn_linear_part (PROTON  , Gamma_pp , rho_pp_coupled_modified , helper_add , A_Gamma_gradients);
  A_Gamma_add_pp_nn_linear_part (NEUTRON , Gamma_nn , rho_nn_coupled_modified , helper_add , A_Gamma_gradients);

  A_Gamma_add_pn_linear_part (Gamma_pn , helper_add , A_Gamma_gradients);
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized) helper_add.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      
#endif
  
  A_Gamma += helper_add;     
}


void RDM_conditions_class::A_Gamma_calc_linear_part (
						     const class RDM_PQG_class &Gamma_pp ,
						     const class RDM_PQG_class &Gamma_nn ,
						     const class RDM_PQG_class &Gamma_pn ,
						     const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
						     const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
						     class RDM_conditions_class &helper_add ,
						     class RDM_conditions_gradient_class &A_Gamma_gradients)
{
  zero ();

  A_Gamma_add_linear_part (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified , helper_add , A_Gamma_gradients);
}



void RDM_conditions_class::A_Gamma_add (
					const class RDM_conditions_class &A_Gamma_zero ,
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn ,
					const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
					const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
					class RDM_conditions_class &helper_add ,
					class RDM_conditions_gradient_class &A_Gamma_gradients)
{ 
  class RDM_conditions_class &A_Gamma = *this;

  A_Gamma += A_Gamma_zero;
  
  A_Gamma_add_linear_part (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified , helper_add , A_Gamma_gradients);
}


  


void RDM_conditions_class::A_Gamma_calc (
					 const class RDM_conditions_class &A_Gamma_zero ,
					 const class RDM_PQG_class &Gamma_pp ,
					 const class RDM_PQG_class &Gamma_nn ,
					 const class RDM_PQG_class &Gamma_pn ,
					 const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
					 const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
					 class RDM_conditions_class &helper_add ,
					 class RDM_conditions_gradient_class &A_Gamma_gradients)
{
  class RDM_conditions_class &A_Gamma = *this;
  
  A_Gamma = A_Gamma_zero;

  A_Gamma_add_linear_part (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified , helper_add , A_Gamma_gradients);
}











void RDM_conditions_class::transpose ()
{
  class block_matrix<TYPE> &P_pp_dependent_term_block_matrix = get_P_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &P_nn_dependent_term_block_matrix = get_P_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &P_pn_dependent_term_block_matrix = get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  class block_matrix<TYPE> &Q_pp_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &Q_nn_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  P_pp_dependent_term_block_matrix.transpose ();
  P_nn_dependent_term_block_matrix.transpose ();
  P_pn_dependent_term_block_matrix.transpose ();

  Q_pp_dependent_term_block_matrix.transpose ();
  Q_nn_dependent_term_block_matrix.transpose ();
  Q_pn_dependent_term_block_matrix.transpose ();
  
  if (is_there_G_constraint)
    {
      class block_matrix<TYPE> &G_pp_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
      class block_matrix<TYPE> &G_nn_dependent_term_block_matrix = get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
      class block_matrix<TYPE> &G_pn_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      class block_matrix<TYPE> &G_np_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  
      G_pp_dependent_term_block_matrix.transpose ();
      G_nn_dependent_term_block_matrix.transpose ();
      G_pn_dependent_term_block_matrix.transpose ();
      G_np_dependent_term_block_matrix.transpose ();
    }
    
  if (are_there_J_constraints)
    {
      class block_matrix<TYPE> &rho_pp_coupled_modified_dependent_term_block_matrix = get_rho_coupled_modified_dependent_term_block_matrix (PROTON);
      class block_matrix<TYPE> &rho_nn_coupled_modified_dependent_term_block_matrix = get_rho_coupled_modified_dependent_term_block_matrix (NEUTRON);

      rho_pp_coupled_modified_dependent_term_block_matrix.transpose ();
      rho_nn_coupled_modified_dependent_term_block_matrix.transpose ();
    }
  
  if (is_there_T1_constraint)
    {    
      class block_matrix<TYPE> &T1_ppp_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      class block_matrix<TYPE> &T1_nnn_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

      T1_ppp_dependent_term_block_matrix.transpose ();
      T1_nnn_dependent_term_block_matrix.transpose ();
      T1_ppn_dependent_term_block_matrix.transpose ();
      T1_nnp_dependent_term_block_matrix.transpose ();
    }
      
  if (is_there_T2_prime_constraint)
    {  
      class block_matrix<TYPE> &T2_prime_ppp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      class block_matrix<TYPE> &T2_prime_nnn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
      class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
      class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      
      T2_prime_ppp_dependent_term_block_matrix.transpose ();
      T2_prime_nnn_dependent_term_block_matrix.transpose ();
      T2_prime_ppn_dependent_term_block_matrix.transpose ();
      T2_prime_nnp_dependent_term_block_matrix.transpose ();
      
      T2_prime_pnp_dependent_term_block_matrix.transpose ();
      T2_prime_pnn_dependent_term_block_matrix.transpose ();
    }
}






void RDM_conditions_class::symmetrize ()
{
  class block_matrix<TYPE> &P_pp_dependent_term_block_matrix = get_P_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &P_nn_dependent_term_block_matrix = get_P_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &P_pn_dependent_term_block_matrix = get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  class block_matrix<TYPE> &Q_pp_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &Q_nn_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &Q_pn_dependent_term_block_matrix = get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  P_pp_dependent_term_block_matrix.symmetrize ();
  P_nn_dependent_term_block_matrix.symmetrize ();
  P_pn_dependent_term_block_matrix.symmetrize ();

  Q_pp_dependent_term_block_matrix.symmetrize ();
  Q_nn_dependent_term_block_matrix.symmetrize ();
  Q_pn_dependent_term_block_matrix.symmetrize ();
    
  if (is_there_G_constraint)
    {
      class block_matrix<TYPE> &G_pp_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
      class block_matrix<TYPE> &G_nn_dependent_term_block_matrix = get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
      class block_matrix<TYPE> &G_pn_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      class block_matrix<TYPE> &G_np_dependent_term_block_matrix = get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  
      G_pp_dependent_term_block_matrix.symmetrize ();
      G_nn_dependent_term_block_matrix.symmetrize ();
      G_pn_dependent_term_block_matrix.symmetrize ();
      G_np_dependent_term_block_matrix.symmetrize ();
    }
  
  if (are_there_J_constraints)
    {  
      class block_matrix<TYPE> &rho_pp_coupled_modified_dependent_term_block_matrix = get_rho_coupled_modified_dependent_term_block_matrix (PROTON);
      class block_matrix<TYPE> &rho_nn_coupled_modified_dependent_term_block_matrix = get_rho_coupled_modified_dependent_term_block_matrix (NEUTRON);

      rho_pp_coupled_modified_dependent_term_block_matrix.symmetrize ();
      rho_nn_coupled_modified_dependent_term_block_matrix.symmetrize ();
    }
  
  if (is_there_T1_constraint)
    {    
      class block_matrix<TYPE> &T1_ppp_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      class block_matrix<TYPE> &T1_nnn_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      class block_matrix<TYPE> &T1_ppn_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      class block_matrix<TYPE> &T1_nnp_dependent_term_block_matrix = get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

      T1_ppp_dependent_term_block_matrix.symmetrize ();
      T1_nnn_dependent_term_block_matrix.symmetrize ();
      T1_ppn_dependent_term_block_matrix.symmetrize ();
      T1_nnp_dependent_term_block_matrix.symmetrize ();
    }
      
  if (is_there_T2_prime_constraint)
    {  
      class block_matrix<TYPE> &T2_prime_ppp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      class block_matrix<TYPE> &T2_prime_nnn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      class block_matrix<TYPE> &T2_prime_ppn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      class block_matrix<TYPE> &T2_prime_nnp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
      class block_matrix<TYPE> &T2_prime_pnp_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
      class block_matrix<TYPE> &T2_prime_pnn_dependent_term_block_matrix = get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      
      T2_prime_ppp_dependent_term_block_matrix.symmetrize ();
      T2_prime_nnn_dependent_term_block_matrix.symmetrize ();
      T2_prime_ppn_dependent_term_block_matrix.symmetrize ();
      T2_prime_nnp_dependent_term_block_matrix.symmetrize ();
      
      T2_prime_pnp_dependent_term_block_matrix.symmetrize ();
      T2_prime_pnn_dependent_term_block_matrix.symmetrize ();
    }
}




void RDM_conditions_class::impose_positive_definiteness_zero_conditions_rho_N_representability (
												class RDM_conditions_class &P_transpose ,
												class RDM_conditions_class &Dp_P_transpose)
{
  const unsigned int Nmax_RDM_matrix_conditions = 22;
  
  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const double abs_Tz = 0.5*abs (Nval - Zval);
  
  const double T2_min = abs_Tz*(abs_Tz + 1.0);
  
  Delta_pp_pairs_number_dependent_term = 0.0;
  Delta_nn_pairs_number_dependent_term = 0.0;
  Delta_pn_pairs_number_dependent_term = 0.0;
  
  Delta_J_dependent_term = 0.0;
    
  if (is_there_CM_correction) Delta_Hcm_dependent_term = 0.0;
  
  if (are_there_J_constraints)
    {      
      J_constraints_pp_dependent_term.zero ();
      J_constraints_nn_dependent_term.zero ();
    }

  if (is_there_isospin_constraint || (real_dc (average_T2_dependent_term) < T2_min)) average_T2_dependent_term = T2_min;
  
  if (is_there_E_reference && (real_dc (Delta_E_reference_dependent_term) < 0.0)) Delta_E_reference_dependent_term = 0.0;
  
  class block_matrix<TYPE> &P_pp_P_transpose_block_matrix = P_transpose.get_P_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &P_nn_P_transpose_block_matrix = P_transpose.get_P_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &P_pn_P_transpose_block_matrix = P_transpose.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  class block_matrix<TYPE> &Q_pp_P_transpose_block_matrix = P_transpose.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &Q_nn_P_transpose_block_matrix = P_transpose.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &Q_pn_P_transpose_block_matrix = P_transpose.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  class block_matrix<TYPE> &G_pp_P_transpose_block_matrix = P_transpose.get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &G_nn_P_transpose_block_matrix = P_transpose.get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
  class block_matrix<TYPE> &G_pn_P_transpose_block_matrix = P_transpose.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  class block_matrix<TYPE> &G_np_P_transpose_block_matrix = P_transpose.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  
  class block_matrix<TYPE> &T1_ppp_P_transpose_block_matrix = P_transpose.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  class block_matrix<TYPE> &T1_nnn_P_transpose_block_matrix = P_transpose.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  class block_matrix<TYPE> &T1_ppn_P_transpose_block_matrix = P_transpose.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  class block_matrix<TYPE> &T1_nnp_P_transpose_block_matrix = P_transpose.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
  class block_matrix<TYPE> &T2_prime_ppp_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &T2_prime_nnn_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);
  class block_matrix<TYPE> &T2_prime_ppn_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  class block_matrix<TYPE> &T2_prime_nnp_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  class block_matrix<TYPE> &T2_prime_pnp_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  class block_matrix<TYPE> &T2_prime_pnn_P_transpose_block_matrix = P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  
  class block_matrix<TYPE> &rho_pp_coupled_modified_P_transpose_block_matrix = P_transpose.get_rho_uncoupled_dependent_term_block_matrix (PROTON);
  class block_matrix<TYPE> &rho_nn_coupled_modified_P_transpose_block_matrix = P_transpose.get_rho_uncoupled_dependent_term_block_matrix (NEUTRON);
  
  class block_matrix<TYPE> &P_pp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_P_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &P_nn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_P_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &P_pn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);

  class block_matrix<TYPE> &Q_pp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  class block_matrix<TYPE> &Q_nn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  class block_matrix<TYPE> &Q_pn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  class block_matrix<TYPE> &G_pp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_G_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &G_nn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_G_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);    
  class block_matrix<TYPE> &G_pn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  class block_matrix<TYPE> &G_np_Dp_P_transpose_block_matrix = Dp_P_transpose.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
    
  class block_matrix<TYPE> &T1_ppp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  class block_matrix<TYPE> &T1_nnn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  class block_matrix<TYPE> &T1_ppn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
  class block_matrix<TYPE> &T1_nnp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
  class block_matrix<TYPE> &T2_prime_ppp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , PROTON);
  class block_matrix<TYPE> &T2_prime_nnn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , NEUTRON);
  class block_matrix<TYPE> &T2_prime_ppn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY     , NEUTRON);
  class block_matrix<TYPE> &T2_prime_nnp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY    , PROTON);  
  class block_matrix<TYPE> &T2_prime_pnp_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
  class block_matrix<TYPE> &T2_prime_pnn_Dp_P_transpose_block_matrix = Dp_P_transpose.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);

  class block_matrix<TYPE> &rho_pp_coupled_modified_Dp_P_transpose_block_matrix = Dp_P_transpose.get_rho_uncoupled_dependent_term_block_matrix (PROTON);
  class block_matrix<TYPE> &rho_nn_coupled_modified_Dp_P_transpose_block_matrix = Dp_P_transpose.get_rho_uncoupled_dependent_term_block_matrix (NEUTRON);

#ifdef UseOpenMP
#pragma omp parallel default(shared) if (is_it_OpenMP_parallelized)
#endif
  for (unsigned int i_RDM = 0 ; i_RDM < Nmax_RDM_matrix_conditions ; i_RDM++)
    {
      const unsigned int i_thread = OpenMP_thread_number_determine ();

      if (i_thread == i_RDM%NUMBER_OF_THREADS)
	{	      
	  if (i_RDM == 0) P_pp_dependent_term.make_it_positive_definite (P_pp_P_transpose_block_matrix , P_pp_Dp_P_transpose_block_matrix);
	  if (i_RDM == 1) P_nn_dependent_term.make_it_positive_definite (P_nn_P_transpose_block_matrix , P_nn_Dp_P_transpose_block_matrix);
	  if (i_RDM == 2) P_pn_dependent_term.make_it_positive_definite (P_pn_P_transpose_block_matrix , P_pn_Dp_P_transpose_block_matrix);
	  
	  if (i_RDM == 3) Q_pp_dependent_term.make_it_positive_definite (Q_pp_P_transpose_block_matrix , Q_pp_Dp_P_transpose_block_matrix);
	  if (i_RDM == 4) Q_nn_dependent_term.make_it_positive_definite (Q_nn_P_transpose_block_matrix , Q_nn_Dp_P_transpose_block_matrix);
	  if (i_RDM == 5) Q_pn_dependent_term.make_it_positive_definite (Q_pn_P_transpose_block_matrix , Q_pn_Dp_P_transpose_block_matrix);
	  
	  if (is_there_G_constraint)
	    {
	      if (i_RDM == 6) G_pp_dependent_term.make_it_positive_definite (G_pp_P_transpose_block_matrix , G_pp_Dp_P_transpose_block_matrix);
	      if (i_RDM == 7) G_nn_dependent_term.make_it_positive_definite (G_nn_P_transpose_block_matrix , G_nn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 8) G_pn_dependent_term.make_it_positive_definite (G_pn_P_transpose_block_matrix , G_pn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 9) G_np_dependent_term.make_it_positive_definite (G_np_P_transpose_block_matrix , G_np_Dp_P_transpose_block_matrix);
	    }
   
	  if (is_there_T1_constraint)
	    {
	      if (i_RDM == 10) T1_ppp_dependent_term.make_it_positive_definite (T1_ppp_P_transpose_block_matrix , T1_ppp_Dp_P_transpose_block_matrix);
	      if (i_RDM == 11) T1_nnn_dependent_term.make_it_positive_definite (T1_nnn_P_transpose_block_matrix , T1_nnn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 12) T1_ppn_dependent_term.make_it_positive_definite (T1_ppn_P_transpose_block_matrix , T1_ppn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 13) T1_nnp_dependent_term.make_it_positive_definite (T1_nnp_P_transpose_block_matrix , T1_nnp_Dp_P_transpose_block_matrix);
	    }
	  
	  if (is_there_T2_prime_constraint)
	    { 
	      if (i_RDM == 14) T2_prime_ppp_dependent_term.make_it_positive_definite (T2_prime_ppp_P_transpose_block_matrix , T2_prime_ppp_Dp_P_transpose_block_matrix);
	      if (i_RDM == 15) T2_prime_nnn_dependent_term.make_it_positive_definite (T2_prime_nnn_P_transpose_block_matrix , T2_prime_nnn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 16) T2_prime_ppn_dependent_term.make_it_positive_definite (T2_prime_ppn_P_transpose_block_matrix , T2_prime_ppn_Dp_P_transpose_block_matrix);
	      if (i_RDM == 17) T2_prime_nnp_dependent_term.make_it_positive_definite (T2_prime_nnp_P_transpose_block_matrix , T2_prime_nnp_Dp_P_transpose_block_matrix);
	      if (i_RDM == 18) T2_prime_pnp_dependent_term.make_it_positive_definite (T2_prime_pnp_P_transpose_block_matrix , T2_prime_pnp_Dp_P_transpose_block_matrix);
	      if (i_RDM == 19) T2_prime_pnn_dependent_term.make_it_positive_definite (T2_prime_pnn_P_transpose_block_matrix , T2_prime_pnn_Dp_P_transpose_block_matrix);
	    }
	  
	  if (are_there_J_constraints)
	    {      
	      if (i_RDM == 20) rho_pp_coupled_modified_dependent_term.make_it_N_representable (rho_pp_coupled_modified_P_transpose_block_matrix , rho_pp_coupled_modified_Dp_P_transpose_block_matrix);
	      if (i_RDM == 21) rho_nn_coupled_modified_dependent_term.make_it_N_representable (rho_nn_coupled_modified_P_transpose_block_matrix , rho_nn_coupled_modified_Dp_P_transpose_block_matrix);
	    }
	}
    }
}











TYPE RDM_conditions_class::Frobenius_squared_norm () const
{
  const class RDM_conditions_class &A = *this;

  const TYPE Frobenius_squared_norm_value = Frobenius_scalar_product (A , A);
  
  return Frobenius_squared_norm_value;
}




TYPE RDM_conditions_class::Frobenius_norm () const
{  
  const class RDM_conditions_class &A = *this;

  const TYPE Frobenius_squared_norm_value = Frobenius_scalar_product (A , A);
  
  const TYPE Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
  
  return Frobenius_norm_value;
}





void RDM_conditions_class::print_precisions_GSM_RDM_class_file (
								const enum space_type space , 
								const int Z ,
								const int N ,
								const unsigned int RDM_BP ,
								const double RDM_J ,
								const unsigned int RDM_vector_index) const
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Master process only in RDM_conditions_class::print_precisions_GSM_RDM_class_file");

  const class nucleons_data &prot_data = get_prot_data ();
  const class nucleons_data &neut_data = get_neut_data ();
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
      
  const unsigned int Np_nlj_res = prot_data.get_N_nlj_res ();
  const unsigned int Nn_nlj_res = neut_data.get_N_nlj_res ();

  cout << endl << "Comparison of SM and RDM formulas" << endl;
  cout         << "---------------------------------" << endl << endl;
  						      
  if (are_there_pp_pairs) cout << "Delta[pp pairs] precision : " << abs (Delta_pp_pairs_number_dependent_term) << endl;
  if (are_there_nn_pairs) cout << "Delta[nn pairs] precision : " << abs (Delta_nn_pairs_number_dependent_term) << endl;
  
  if (are_there_pn_pairs) cout << "Delta[pn pairs] precision : " << abs (Delta_pn_pairs_number_dependent_term) << endl;
      
  cout << endl;
    
  cout << "J^2 precision : " << abs (Delta_J_dependent_term) << endl << endl;

  if (is_there_E_reference && (Np_nlj == Np_nlj_res) && (Nn_nlj == Nn_nlj_res)) cout << "E precision : " << abs (Delta_E_reference_dependent_term) << endl << endl;
  
  if (is_there_CM_correction) cout << "Hcm precision : " << abs (Delta_Hcm_dependent_term) << endl << endl;

  if (are_there_J_constraints)
    {        
      if (space != NEUTRONS_ONLY) cout << "J.constraints[pp] precision : " << J_constraints_pp_dependent_term.infinite_norm () << endl;
      if (space != PROTONS_ONLY)  cout << "J.constraints[nn] precision : " << J_constraints_nn_dependent_term.infinite_norm () << endl << endl;
    }
 
  if (space == PROTONS_NEUTRONS)
    {
      const TYPE average_T = (-1.0 + sqrt (1.0 + 4.0*average_T2_dependent_term))/2.0;
   
      cout << "<T> = " << average_T << endl << endl; 
    }
  
  if (space != NEUTRONS_ONLY) Q_pp_dependent_term.precision_Q_pp_nn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
  if (space != PROTONS_ONLY)  Q_nn_dependent_term.precision_Q_pp_nn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
  
  if (space == PROTONS_NEUTRONS) Q_pn_dependent_term.precision_Q_pn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
  
  cout << endl;
  
  if (is_there_G_constraint)
    {
      if (space != NEUTRONS_ONLY) G_pp_dependent_term.precision_G_pp_nn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
      if (space != PROTONS_ONLY)  G_nn_dependent_term.precision_G_pp_nn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
  
      if (space == PROTONS_NEUTRONS) G_pn_dependent_term.precision_G_pn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
      if (space == PROTONS_NEUTRONS) G_np_dependent_term.precision_G_np_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index);
	  
      cout << endl;
    }
	    
  if (is_there_T1_constraint)
    {      
      if (space != NEUTRONS_ONLY) T1_ppp_dependent_term.precision_T1_ppp_nnn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pp_dependent_term);
      if (space != PROTONS_ONLY)  T1_nnn_dependent_term.precision_T1_ppp_nnn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_nn_dependent_term);
      
      if (space == PROTONS_NEUTRONS) T1_ppn_dependent_term.precision_T1_ppn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pp_dependent_term);
      if (space == PROTONS_NEUTRONS) T1_nnp_dependent_term.precision_T1_nnp_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_nn_dependent_term);
  
      cout << endl;
    }
	  
  if (is_there_T2_prime_constraint)
    {  
      if (space != NEUTRONS_ONLY) T2_prime_ppp_dependent_term.precision_T2_ppp_nnn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pp_dependent_term);
      if (space != PROTONS_ONLY)  T2_prime_nnn_dependent_term.precision_T2_ppp_nnn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_nn_dependent_term);
      
      if (space == PROTONS_NEUTRONS) T2_prime_ppn_dependent_term.precision_T2_ppn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pp_dependent_term);
      if (space == PROTONS_NEUTRONS) T2_prime_nnp_dependent_term.precision_T2_nnp_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_nn_dependent_term);
      if (space == PROTONS_NEUTRONS) T2_prime_pnp_dependent_term.precision_T2_pnp_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pn_dependent_term);
      if (space == PROTONS_NEUTRONS) T2_prime_pnn_dependent_term.precision_T2_pnn_class_file_calc_print (Z , N , RDM_BP , RDM_J , RDM_vector_index , P_pn_dependent_term);

      cout << endl;
    }
}







void RDM_conditions_class::print_gradient_direct_formulas_precisions (
								      const enum space_type space , 
								      const class RDM_conditions_gradient_class &A_Gamma_gradients ,
								      const class RDM_PQG_class &Gamma_pp ,
								      const class RDM_PQG_class &Gamma_nn ,
								      const class RDM_PQG_class &Gamma_pn ,
								      const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
								      const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified)
{     
  class RDM_conditions_class &A_Gamma = *this;
  
  class RDM_PQG_class Gamma_pp_zero = Gamma_pp;
  class RDM_PQG_class Gamma_nn_zero = Gamma_nn;
  class RDM_PQG_class Gamma_pn_zero = Gamma_pn;

  class RDM_rho_coupled_modified_class rho_pp_coupled_modified_zero = rho_pp_coupled_modified;
  class RDM_rho_coupled_modified_class rho_nn_coupled_modified_zero = rho_nn_coupled_modified;
  
  Gamma_pp_zero.zero ();
  Gamma_nn_zero.zero ();
  Gamma_pn_zero.zero ();
    
  rho_pp_coupled_modified_zero.zero ();
  rho_nn_coupled_modified_zero.zero ();
  
  class RDM_conditions_class A_Gamma_zero = A_Gamma;

  A_Gamma_zero.A_Gamma_calc (Gamma_pp_zero , Gamma_nn_zero , Gamma_pn_zero , rho_pp_coupled_modified_zero , rho_nn_coupled_modified_zero);
  
  class RDM_conditions_class helper_add = A_Gamma;
    
  class RDM_conditions_gradient_class helper_product = A_Gamma_gradients;
  
  A_Gamma_calc (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified);
  
  A_Gamma *= -1.0;
  
  A_Gamma_add (A_Gamma_zero , Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified , helper_add , helper_product);

  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      cout << endl << "Comparison of gradient and direct formulas" << endl;
      cout         << "------------------------------------------" << endl << endl;
  
      if (are_there_pp_pairs) cout << "Delta[pp pairs] precision : " << abs (Delta_pp_pairs_number_dependent_term) << endl;
      if (are_there_nn_pairs) cout << "Delta[nn pairs] precision : " << abs (Delta_nn_pairs_number_dependent_term) << endl;
  
      if (are_there_pn_pairs) cout << "Delta[pn pairs] precision : " << abs (Delta_pn_pairs_number_dependent_term) << endl;
      
      cout << endl;
    
      cout << "J^2 precision : " << abs (Delta_J_dependent_term) << endl << endl;
  
      if (is_there_E_reference) cout << "E[reference] precision : " << abs (Delta_E_reference_dependent_term) << endl << endl;
  
      if (is_there_CM_correction) cout << "Hcm precision : " << abs (Delta_Hcm_dependent_term) << endl << endl;

      if (are_there_J_constraints)
	{
	  if (space != NEUTRONS_ONLY) cout << "J.constraints[pp] precision : " << J_constraints_pp_dependent_term.infinite_norm () << endl;
	  if (space != PROTONS_ONLY)  cout << "J.constraints[nn] precision : " << J_constraints_nn_dependent_term.infinite_norm () << endl << endl;  
	}
 
      if (space == PROTONS_NEUTRONS) cout << "<T^2> precision : " << abs (average_T2_dependent_term) << endl << endl;	    
	      
      if (space != NEUTRONS_ONLY) cout << "Q[pp] precision : " << Q_pp_dependent_term.infinite_norm () << endl;
      if (space != PROTONS_ONLY)  cout << "Q[nn] precision : " << Q_nn_dependent_term.infinite_norm () << endl; 
  
      if (space == PROTONS_NEUTRONS) cout << "Q[pn] precision : " << Q_pn_dependent_term.infinite_norm () << endl;
  
      cout << endl;
  
      if (is_there_G_constraint)
	{
	  if (space != NEUTRONS_ONLY) cout << "G[pp] precision : " << G_pp_dependent_term.infinite_norm () << endl;
	  if (space != PROTONS_ONLY)  cout << "G[nn] precision : " << G_nn_dependent_term.infinite_norm () << endl;
  
	  if (space == PROTONS_NEUTRONS) cout << "G[pn] precision : " << G_pn_dependent_term.infinite_norm () << endl;
	  if (space == PROTONS_NEUTRONS) cout << "G[np] precision : " << G_np_dependent_term.infinite_norm () << endl;
  
	  cout << endl;
	}
      
      if (is_there_T1_constraint)
	{
	  if (space != NEUTRONS_ONLY) cout << "T1[ppp] precision : " << T1_ppp_dependent_term.infinite_norm () << endl;
	  if (space != PROTONS_ONLY)  cout << "T1[nnn] precision : " << T1_nnn_dependent_term.infinite_norm () << endl;

	  if (space == PROTONS_NEUTRONS) cout << "T1[ppn] precision : " << T1_ppn_dependent_term.infinite_norm () << endl;
	  if (space == PROTONS_NEUTRONS) cout << "T1[nnp] precision : " << T1_nnp_dependent_term.infinite_norm () << endl;
  
	  cout << endl;
  	}
	  
      if (is_there_T2_prime_constraint)
	{ 
	  if (space != NEUTRONS_ONLY) cout << "T2[ppp] precision : " << T2_prime_ppp_dependent_term.infinite_norm () << endl;
	  if (space != PROTONS_ONLY)  cout << "T2[nnn] precision : " << T2_prime_nnn_dependent_term.infinite_norm () << endl;
      
	  if (space == PROTONS_NEUTRONS) cout << "T2[ppn] precision : " << T2_prime_ppn_dependent_term.infinite_norm () << endl;
	  if (space == PROTONS_NEUTRONS) cout << "T2[nnp] precision : " << T2_prime_nnp_dependent_term.infinite_norm () << endl;
	  if (space == PROTONS_NEUTRONS) cout << "T2[pnp] precision : " << T2_prime_pnp_dependent_term.infinite_norm () << endl;
	  if (space == PROTONS_NEUTRONS) cout << "T2[pnn] precision : " << T2_prime_pnn_dependent_term.infinite_norm () << endl;

	  cout << endl;
	}
    }
 
  cout << endl;
}












TYPE Frobenius_scalar_product (
			       const class RDM_conditions_class &A ,
			       const class RDM_conditions_class &B)
{
  TYPE AB_Frobenius_scalar_product = 0.0;

  const bool is_there_CM_correction = A.get_is_there_CM_correction ();

  const bool are_there_J_constraints = A.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = A.get_is_there_E_reference ();
  
  const bool is_there_G_constraint = A.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = A.get_is_there_T1_constraint ();
  
  const bool is_there_T2_prime_constraint = A.get_is_there_T2_prime_constraint ();
    
  const TYPE A_Delta_pp_pairs_number_dependent_term = A.get_Delta_pairs_number_dependent_term (PROTONS_ONLY);
  const TYPE B_Delta_pp_pairs_number_dependent_term = B.get_Delta_pairs_number_dependent_term (PROTONS_ONLY);
  
  const TYPE A_Delta_nn_pairs_number_dependent_term = A.get_Delta_pairs_number_dependent_term (NEUTRONS_ONLY);
  const TYPE B_Delta_nn_pairs_number_dependent_term = B.get_Delta_pairs_number_dependent_term (NEUTRONS_ONLY);
  
  const TYPE A_Delta_pn_pairs_number_dependent_term = A.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);
  const TYPE B_Delta_pn_pairs_number_dependent_term = B.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);
  
  const TYPE A_Delta_J_dependent_term = A.get_Delta_J_dependent_term ();  
  const TYPE B_Delta_J_dependent_term = B.get_Delta_J_dependent_term ();
  
  const TYPE A_average_T2_dependent_term = A.get_average_T2_dependent_term ();
  const TYPE B_average_T2_dependent_term = B.get_average_T2_dependent_term ();
  
  const TYPE A_Delta_E_reference_dependent_term = A.get_Delta_E_reference_dependent_term ();
  const TYPE B_Delta_E_reference_dependent_term = B.get_Delta_E_reference_dependent_term ();
     
  AB_Frobenius_scalar_product += A_Delta_pp_pairs_number_dependent_term*B_Delta_pp_pairs_number_dependent_term;
  AB_Frobenius_scalar_product += A_Delta_nn_pairs_number_dependent_term*B_Delta_nn_pairs_number_dependent_term;
  AB_Frobenius_scalar_product += A_Delta_pn_pairs_number_dependent_term*B_Delta_pn_pairs_number_dependent_term;
  
  AB_Frobenius_scalar_product += A_Delta_J_dependent_term*B_Delta_J_dependent_term;

  AB_Frobenius_scalar_product += A_average_T2_dependent_term*B_average_T2_dependent_term;
  
  if (is_there_E_reference) AB_Frobenius_scalar_product += A_Delta_E_reference_dependent_term*B_Delta_E_reference_dependent_term;
  
  if (is_there_CM_correction)
    {  
      const TYPE A_Delta_Hcm_dependent_term = A.get_Delta_Hcm_dependent_term ();  
      const TYPE B_Delta_Hcm_dependent_term = B.get_Delta_Hcm_dependent_term ();
    
      AB_Frobenius_scalar_product += A_Delta_Hcm_dependent_term*B_Delta_Hcm_dependent_term;
    }
  
  if (are_there_J_constraints)
    {
      const class RDM_J_constraints_class &A_J_constraints_pp_dependent_term = A.get_J_constraints_dependent_term (PROTON);
      const class RDM_J_constraints_class &B_J_constraints_pp_dependent_term = B.get_J_constraints_dependent_term (PROTON);
      
      const class RDM_J_constraints_class &A_J_constraints_nn_dependent_term = A.get_J_constraints_dependent_term (NEUTRON);
      const class RDM_J_constraints_class &B_J_constraints_nn_dependent_term = B.get_J_constraints_dependent_term (NEUTRON);
        
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_J_constraints_pp_dependent_term , B_J_constraints_pp_dependent_term);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_J_constraints_nn_dependent_term , B_J_constraints_nn_dependent_term);
      
      const class block_matrix<TYPE> &A_rho_pp_coupled_modified_dependent_term_block_matrix = A.get_rho_coupled_modified_dependent_term_block_matrix (PROTON);
      const class block_matrix<TYPE> &B_rho_pp_coupled_modified_dependent_term_block_matrix = B.get_rho_coupled_modified_dependent_term_block_matrix (PROTON);
      
      const class block_matrix<TYPE> &A_rho_nn_coupled_modified_dependent_term_block_matrix = A.get_rho_coupled_modified_dependent_term_block_matrix (NEUTRON);  
      const class block_matrix<TYPE> &B_rho_nn_coupled_modified_dependent_term_block_matrix = B.get_rho_coupled_modified_dependent_term_block_matrix (NEUTRON);
      
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_rho_pp_coupled_modified_dependent_term_block_matrix , B_rho_pp_coupled_modified_dependent_term_block_matrix);  
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_rho_nn_coupled_modified_dependent_term_block_matrix , B_rho_nn_coupled_modified_dependent_term_block_matrix);
    }
  
  const class block_matrix<TYPE> &A_P_pp_dependent_term_block_matrix = A.get_P_dependent_term_block_matrix (PROTONS_ONLY);
  const class block_matrix<TYPE> &B_P_pp_dependent_term_block_matrix = B.get_P_dependent_term_block_matrix (PROTONS_ONLY);
  
  const class block_matrix<TYPE> &A_P_nn_dependent_term_block_matrix = A.get_P_dependent_term_block_matrix (NEUTRONS_ONLY);
  const class block_matrix<TYPE> &B_P_nn_dependent_term_block_matrix = B.get_P_dependent_term_block_matrix (NEUTRONS_ONLY);

  const class block_matrix<TYPE> &A_Q_pp_dependent_term_block_matrix = A.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  const class block_matrix<TYPE> &B_Q_pp_dependent_term_block_matrix = B.get_Q_dependent_term_block_matrix (PROTONS_ONLY);
  
  const class block_matrix<TYPE> &A_Q_nn_dependent_term_block_matrix = A.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  const class block_matrix<TYPE> &B_Q_nn_dependent_term_block_matrix = B.get_Q_dependent_term_block_matrix (NEUTRONS_ONLY);
  
  const class block_matrix<TYPE> &A_P_pn_dependent_term_block_matrix = A.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);
  const class block_matrix<TYPE> &B_P_pn_dependent_term_block_matrix = B.get_P_dependent_term_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &A_Q_pn_dependent_term_block_matrix = A.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);
  const class block_matrix<TYPE> &B_Q_pn_dependent_term_block_matrix = B.get_Q_dependent_term_block_matrix (PROTONS_NEUTRONS);

  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_P_pp_dependent_term_block_matrix , B_P_pp_dependent_term_block_matrix);
  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_P_nn_dependent_term_block_matrix , B_P_nn_dependent_term_block_matrix);
  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_P_pn_dependent_term_block_matrix , B_P_pn_dependent_term_block_matrix);
  
  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_Q_pp_dependent_term_block_matrix , B_Q_pp_dependent_term_block_matrix);
  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_Q_nn_dependent_term_block_matrix , B_Q_nn_dependent_term_block_matrix);
  AB_Frobenius_scalar_product += Frobenius_scalar_product (A_Q_pn_dependent_term_block_matrix , B_Q_pn_dependent_term_block_matrix);

  if (is_there_G_constraint)
    {
      const class block_matrix<TYPE> &A_G_pp_dependent_term_block_matrix = A.get_G_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      const class block_matrix<TYPE> &B_G_pp_dependent_term_block_matrix = B.get_G_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
  
      const class block_matrix<TYPE> &A_G_nn_dependent_term_block_matrix = A.get_G_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      const class block_matrix<TYPE> &B_G_nn_dependent_term_block_matrix = B.get_G_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
  
      const class block_matrix<TYPE> &A_G_pn_dependent_term_block_matrix = A.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);  
      const class block_matrix<TYPE> &B_G_pn_dependent_term_block_matrix = B.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
  
      const class block_matrix<TYPE> &A_G_np_dependent_term_block_matrix = A.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);  
      const class block_matrix<TYPE> &B_G_np_dependent_term_block_matrix = B.get_G_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
    
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_G_pp_dependent_term_block_matrix , B_G_pp_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_G_nn_dependent_term_block_matrix , B_G_nn_dependent_term_block_matrix);  
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_G_pn_dependent_term_block_matrix , B_G_pn_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_G_np_dependent_term_block_matrix , B_G_np_dependent_term_block_matrix);
    }
      
  if (is_there_T1_constraint)
    {
      const class block_matrix<TYPE> &A_T1_ppp_dependent_term_block_matrix = A.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      const class block_matrix<TYPE> &B_T1_ppp_dependent_term_block_matrix = B.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      
      const class block_matrix<TYPE> &A_T1_nnn_dependent_term_block_matrix = A.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      const class block_matrix<TYPE> &B_T1_nnn_dependent_term_block_matrix = B.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      
      const class block_matrix<TYPE> &A_T1_ppn_dependent_term_block_matrix = A.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      const class block_matrix<TYPE> &B_T1_ppn_dependent_term_block_matrix = B.get_T1_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      
      const class block_matrix<TYPE> &A_T1_nnp_dependent_term_block_matrix = A.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);      
      const class block_matrix<TYPE> &B_T1_nnp_dependent_term_block_matrix = B.get_T1_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);

      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T1_ppp_dependent_term_block_matrix , B_T1_ppp_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T1_nnn_dependent_term_block_matrix , B_T1_nnn_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T1_ppn_dependent_term_block_matrix , B_T1_ppn_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T1_nnp_dependent_term_block_matrix , B_T1_nnp_dependent_term_block_matrix);
    }
  
  if (is_there_T2_prime_constraint)
    {       
      const class block_matrix<TYPE> &A_T2_prime_ppp_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      const class block_matrix<TYPE> &B_T2_prime_ppp_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , PROTON);
      
      const class block_matrix<TYPE> &A_T2_prime_nnn_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);      
      const class block_matrix<TYPE> &B_T2_prime_nnn_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , NEUTRON);
      
      const class block_matrix<TYPE> &A_T2_prime_ppn_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      const class block_matrix<TYPE> &B_T2_prime_ppn_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY  , NEUTRON);
      
      const class block_matrix<TYPE> &A_T2_prime_nnp_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
      const class block_matrix<TYPE> &B_T2_prime_nnp_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY , PROTON);
  
      const class block_matrix<TYPE> &A_T2_prime_pnp_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
      const class block_matrix<TYPE> &B_T2_prime_pnp_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , PROTON);
      
      const class block_matrix<TYPE> &A_T2_prime_pnn_dependent_term_block_matrix = A.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      const class block_matrix<TYPE> &B_T2_prime_pnn_dependent_term_block_matrix = B.get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS , NEUTRON);
      
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_ppp_dependent_term_block_matrix , B_T2_prime_ppp_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_nnn_dependent_term_block_matrix , B_T2_prime_nnn_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_ppn_dependent_term_block_matrix , B_T2_prime_ppn_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_nnp_dependent_term_block_matrix , B_T2_prime_nnp_dependent_term_block_matrix);
      
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_pnp_dependent_term_block_matrix , B_T2_prime_pnp_dependent_term_block_matrix);
      AB_Frobenius_scalar_product += Frobenius_scalar_product (A_T2_prime_pnn_dependent_term_block_matrix , B_T2_prime_pnn_dependent_term_block_matrix);
    }
      
  return AB_Frobenius_scalar_product;
}

 

#ifdef UseMPI

void RDM_conditions_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int N_const = 7;
  
  TYPE T_const[] = {Delta_pp_pairs_number_dependent_term , Delta_nn_pairs_number_dependent_term , Delta_pn_pairs_number_dependent_term , Delta_J_dependent_term , Delta_Hcm_dependent_term , average_T2_dependent_term , Delta_E_reference_dependent_term};

  MPI_helper::Bcast (N_const , T_const , Send_process , MPI_C);

  if (THIS_PROCESS != Send_process)
    {      
      Delta_pp_pairs_number_dependent_term = T_const[0];
      Delta_nn_pairs_number_dependent_term = T_const[1];
      Delta_pn_pairs_number_dependent_term = T_const[2];
  
      Delta_J_dependent_term = T_const[3];

      if (is_there_CM_correction) Delta_Hcm_dependent_term = T_const[4];

      average_T2_dependent_term = T_const[5];

      if (is_there_E_reference) Delta_E_reference_dependent_term = T_const[6];
    }

  P_pp_dependent_term.MPI_Bcast (Send_process , MPI_C);
  P_nn_dependent_term.MPI_Bcast (Send_process , MPI_C);
  P_pn_dependent_term.MPI_Bcast (Send_process , MPI_C);
  
  Q_pp_dependent_term.MPI_Bcast (Send_process , MPI_C);
  Q_nn_dependent_term.MPI_Bcast (Send_process , MPI_C);
  Q_pn_dependent_term.MPI_Bcast (Send_process , MPI_C);
     
  if (is_there_G_constraint)
    { 
      G_pp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      G_nn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      G_pn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      G_np_dependent_term.MPI_Bcast (Send_process , MPI_C);
    }
      
  if (are_there_J_constraints)
    {      
      rho_pp_coupled_modified_dependent_term.MPI_Bcast (Send_process , MPI_C);
      rho_nn_coupled_modified_dependent_term.MPI_Bcast (Send_process , MPI_C);
  
      J_constraints_pp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      J_constraints_nn_dependent_term.MPI_Bcast (Send_process , MPI_C);
    }
     
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T1_nnn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T1_ppn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T1_nnp_dependent_term.MPI_Bcast (Send_process , MPI_C);
    }
	  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T2_prime_nnn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T2_prime_ppn_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T2_prime_nnp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T2_prime_pnp_dependent_term.MPI_Bcast (Send_process , MPI_C);
      T2_prime_pnn_dependent_term.MPI_Bcast (Send_process , MPI_C);
    }
}

void RDM_conditions_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int N_const = 7;
  
  TYPE T_const[] = {Delta_pp_pairs_number_dependent_term , Delta_nn_pairs_number_dependent_term , Delta_pn_pairs_number_dependent_term , Delta_J_dependent_term , Delta_Hcm_dependent_term , average_T2_dependent_term , Delta_E_reference_dependent_term};

  MPI_helper::Reduce (N_const , T_const , op , Recv_process , process , MPI_C);

  if (THIS_PROCESS == Recv_process)
    {      
      Delta_pp_pairs_number_dependent_term = T_const[0];
      Delta_nn_pairs_number_dependent_term = T_const[1];
      Delta_pn_pairs_number_dependent_term = T_const[2];
  
      Delta_J_dependent_term = T_const[3];

      if (is_there_CM_correction) Delta_Hcm_dependent_term = T_const[4];

      average_T2_dependent_term = T_const[5];

      if (is_there_E_reference) Delta_E_reference_dependent_term = T_const[6];
    }

  P_pp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  P_nn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  P_pn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  Q_pp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  Q_nn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  Q_pn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
     
  if (is_there_G_constraint)
    { 
      G_pp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      G_nn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      G_pn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      G_np_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
    }
      
  if (are_there_J_constraints)
    {
      rho_pp_coupled_modified_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      rho_nn_coupled_modified_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
  
      J_constraints_pp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      J_constraints_nn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
    }
     
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T1_nnn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T1_ppn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T1_nnp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
    }
	  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T2_prime_nnn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T2_prime_ppn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T2_prime_nnp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T2_prime_pnp_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
      T2_prime_pnn_dependent_term.MPI_Reduce (op , Recv_process , process , MPI_C);
    }
}


void RDM_conditions_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int N_const = 7;
  
  TYPE T_const[] = {Delta_pp_pairs_number_dependent_term , Delta_nn_pairs_number_dependent_term , Delta_pn_pairs_number_dependent_term , Delta_J_dependent_term , Delta_Hcm_dependent_term , average_T2_dependent_term , Delta_E_reference_dependent_term};

  MPI_helper::Allreduce (N_const , T_const , op , MPI_C);

  Delta_pp_pairs_number_dependent_term = T_const[0];
  Delta_nn_pairs_number_dependent_term = T_const[1];
  Delta_pn_pairs_number_dependent_term = T_const[2];
  
  Delta_J_dependent_term = T_const[3];

  if (is_there_CM_correction) Delta_Hcm_dependent_term = T_const[4];

  average_T2_dependent_term = T_const[5];

  if (is_there_E_reference) Delta_E_reference_dependent_term = T_const[6];
  
  P_pp_dependent_term.MPI_Allreduce (op , MPI_C);
  P_nn_dependent_term.MPI_Allreduce (op , MPI_C);
  P_pn_dependent_term.MPI_Allreduce (op , MPI_C);
  
  Q_pp_dependent_term.MPI_Allreduce (op , MPI_C);
  Q_nn_dependent_term.MPI_Allreduce (op , MPI_C);
  Q_pn_dependent_term.MPI_Allreduce (op , MPI_C);
     
  if (is_there_G_constraint)
    { 
      G_pp_dependent_term.MPI_Allreduce (op , MPI_C);
      G_nn_dependent_term.MPI_Allreduce (op , MPI_C);
      G_pn_dependent_term.MPI_Allreduce (op , MPI_C);
      G_np_dependent_term.MPI_Allreduce (op , MPI_C);
    }
      
  if (are_there_J_constraints)
    {
      rho_pp_coupled_modified_dependent_term.MPI_Allreduce (op , MPI_C);
      rho_nn_coupled_modified_dependent_term.MPI_Allreduce (op , MPI_C);
  
      J_constraints_pp_dependent_term.MPI_Allreduce (op , MPI_C);
      J_constraints_nn_dependent_term.MPI_Allreduce (op , MPI_C);
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.MPI_Allreduce (op , MPI_C);
      T1_nnn_dependent_term.MPI_Allreduce (op , MPI_C);
      T1_ppn_dependent_term.MPI_Allreduce (op , MPI_C);
      T1_nnp_dependent_term.MPI_Allreduce (op , MPI_C);
    }
	  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.MPI_Allreduce (op , MPI_C);
      T2_prime_nnn_dependent_term.MPI_Allreduce (op , MPI_C);
      T2_prime_ppn_dependent_term.MPI_Allreduce (op , MPI_C);
      T2_prime_nnp_dependent_term.MPI_Allreduce (op , MPI_C);
      T2_prime_pnp_dependent_term.MPI_Allreduce (op , MPI_C);
      T2_prime_pnn_dependent_term.MPI_Allreduce (op , MPI_C);
    }
}


void RDM_conditions_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int N_const = 7;
  
  TYPE T_const[] = {Delta_pp_pairs_number_dependent_term , Delta_nn_pairs_number_dependent_term , Delta_pn_pairs_number_dependent_term , Delta_J_dependent_term , Delta_Hcm_dependent_term , average_T2_dependent_term , Delta_E_reference_dependent_term};

  MPI_helper::Allgatherv (N_const , T_const , group_processes_number , MPI_C);

  Delta_pp_pairs_number_dependent_term = T_const[0];
  Delta_nn_pairs_number_dependent_term = T_const[1];
  Delta_pn_pairs_number_dependent_term = T_const[2];
  
  Delta_J_dependent_term = T_const[3];

  if (is_there_CM_correction) Delta_Hcm_dependent_term = T_const[4];

  average_T2_dependent_term = T_const[5];

  if (is_there_E_reference) Delta_E_reference_dependent_term = T_const[6];

  P_pp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  P_nn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  P_pn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  
  Q_pp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  Q_nn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  Q_pn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      
  if (is_there_G_constraint)
    {
      G_pp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      G_nn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      G_pn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      G_np_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
    }
      
  if (are_there_J_constraints)
    {
      rho_pp_coupled_modified_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      rho_nn_coupled_modified_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
  
      J_constraints_pp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      J_constraints_nn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
    }
  
  if (is_there_T1_constraint)
    {
      T1_ppp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T1_nnn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T1_ppn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T1_nnp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
    }
	  
  if (is_there_T2_prime_constraint)
    { 
      T2_prime_ppp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T2_prime_nnn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T2_prime_ppn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T2_prime_nnp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T2_prime_pnp_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
      T2_prime_pnn_dependent_term.MPI_Allgatherv (group_processes_number , MPI_C);
    }
}

#endif

