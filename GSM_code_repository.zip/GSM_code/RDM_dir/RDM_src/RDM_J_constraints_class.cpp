#include "../RDM_include/RDM_include_def.h"

using namespace correlated_state_routines;
using namespace RDM_rho_observables;




RDM_J_constraints_class::RDM_J_constraints_class () :
  particle (NO_PARTICLE) ,
  J (0) ,
  J_factor_vector_part (0) ,
  is_J_non_zero (false) {}

RDM_J_constraints_class::RDM_J_constraints_class (
						  const enum particle_type particle_c ,
						  const double J_c , 
						  const class nucleons_data &prot_data ,
						  const class nucleons_data &neut_data)
  : particle (NO_PARTICLE) ,
    J (0) ,
    J_factor_vector_part (0) ,
    is_J_non_zero (false)
{
  allocate (particle_c , J_c , prot_data , neut_data);
}



RDM_J_constraints_class::RDM_J_constraints_class (const class RDM_J_constraints_class &X)
{
  allocate_fill (X);
}

RDM_J_constraints_class::~RDM_J_constraints_class () {}



void RDM_J_constraints_class::allocate (
					const enum particle_type particle_c ,
					const double J_c , 
					const class nucleons_data &prot_data ,
					const class nucleons_data &neut_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_J_constraints_class::allocate");
 
  particle = particle_c;

  J = J_c;
    
  J_factor_vector_part = -hat (1)/(J + 1.0);
    
  is_J_non_zero = (make_int (2.0*J) != 0);
  
  const class nucleons_data &particles_data = (particle == PROTON) ? (prot_data) : (neut_data);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  J_constraints_matrix_scalar_part.allocate (N_nlj);
  J_constraints_matrix_vector_part.allocate (N_nlj);

  zero ();
}





void RDM_J_constraints_class::allocate_fill (const class RDM_J_constraints_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_J_constraints_class::allocate_fill");
  
  particle = X.particle;
    
  J = X.J;
  
  J_factor_vector_part = X.J_factor_vector_part;
  
  is_J_non_zero = X.is_J_non_zero;
  
  J_constraints_matrix_scalar_part.allocate_fill (X.J_constraints_matrix_scalar_part);
  J_constraints_matrix_vector_part.allocate_fill (X.J_constraints_matrix_vector_part);
}



void RDM_J_constraints_class::deallocate ()
{
  particle = NO_PARTICLE;
    
  J = 0;
  
  J_factor_vector_part = 0;
  
  is_J_non_zero = false;
  
  J_constraints_matrix_scalar_part.deallocate ();
  J_constraints_matrix_vector_part.deallocate ();
  
  T_MPI.deallocate ();
}




void RDM_J_constraints_class::J_constraints_matrix_add (
							const class nucleons_data &prot_data ,
							const class nucleons_data &neut_data,
							const class RDM_PQG_class &Gamma_pp_nn ,
							const class RDM_PQG_class &Gamma_pn ,
							const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
							const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{
  const class nucleons_data &particles_data = (particle == PROTON) ? (prot_data) : (neut_data);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
            
  class array<TYPE> rho_tab(N_nlj , N_nlj);
    
  switch (particle)
    {
    case PROTON:  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
    case NEUTRON: rho_neut_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
      
    default: abort_all ();
    }
  
  zero ();
  
  J_constraints_matrix_pp_nn_part_add (particles_data , rho_tab , Gamma_pp_nn , rho_pp_nn_coupled_modified , Wigner_6j_hats_G);
	
  switch (particle)
    {
    case PROTON:  J_constraints_matrix_prot_pn_part_add (prot_data , neut_data , Gamma_pn , Wigner_6j_hats_G); break;      
    case NEUTRON: J_constraints_matrix_neut_pn_part_add (prot_data , neut_data , Gamma_pn , Wigner_6j_hats_G); break;
      
    default: abort_all ();
    }
}







void RDM_J_constraints_class::operator = (const class RDM_J_constraints_class &X)
{
  J_constraints_matrix_scalar_part = X.J_constraints_matrix_scalar_part;  
  J_constraints_matrix_vector_part = X.J_constraints_matrix_vector_part;  
}

void RDM_J_constraints_class::operator += (const class RDM_J_constraints_class &X)
{
  J_constraints_matrix_scalar_part += X.J_constraints_matrix_scalar_part;  
  J_constraints_matrix_vector_part += X.J_constraints_matrix_vector_part;  
}

void RDM_J_constraints_class::operator -= (const class RDM_J_constraints_class &X)
{
  J_constraints_matrix_scalar_part -= X.J_constraints_matrix_scalar_part;  
  J_constraints_matrix_vector_part -= X.J_constraints_matrix_vector_part;  
}

void RDM_J_constraints_class::operator = (const TYPE &x)
{
  J_constraints_matrix_scalar_part = x;
  J_constraints_matrix_vector_part = x;
}

void RDM_J_constraints_class::operator += (const TYPE &x)
{
  J_constraints_matrix_scalar_part += x;
  J_constraints_matrix_vector_part += x;
}

void RDM_J_constraints_class::operator -= (const TYPE &x)
{
  J_constraints_matrix_scalar_part -= x;
  J_constraints_matrix_vector_part -= x;
}

void RDM_J_constraints_class::operator *= (const TYPE &x)
{
  J_constraints_matrix_scalar_part *= x;
  J_constraints_matrix_vector_part *= x;
}

void RDM_J_constraints_class::operator /= (const TYPE &x)
{
  J_constraints_matrix_scalar_part /= x;
  J_constraints_matrix_vector_part /= x;
}

void RDM_J_constraints_class::zero ()
{
  J_constraints_matrix_scalar_part = 0.0;
  J_constraints_matrix_vector_part = 0.0;
}



unsigned int RDM_J_constraints_class::get_symmetric_matrix_elements_number () const
{
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();

  const unsigned int symmetric_matrix_elements_number_scalar_part = (dimension_scalar_part%2 == 0) ? ((dimension_scalar_part/2)*(dimension_scalar_part + 1)) : (dimension_scalar_part*((dimension_scalar_part + 1)/2));
  const unsigned int symmetric_matrix_elements_number_vector_part = (dimension_vector_part%2 == 0) ? ((dimension_vector_part/2)*(dimension_vector_part + 1)) : (dimension_vector_part*((dimension_vector_part + 1)/2));
      
  const unsigned int symmetric_matrix_elements_number = symmetric_matrix_elements_number_scalar_part + symmetric_matrix_elements_number_vector_part;

  return symmetric_matrix_elements_number;
}





TYPE RDM_J_constraints_class::Frobenius_squared_norm () const
{
  return (J_constraints_matrix_scalar_part.Frobenius_squared_norm () + J_constraints_matrix_vector_part.Frobenius_squared_norm ());
}

double RDM_J_constraints_class::infinite_norm () const
{  
  return (max (J_constraints_matrix_scalar_part.infinite_norm () , J_constraints_matrix_vector_part.infinite_norm ()));
}



void RDM_J_constraints_class::J_constraints_matrix_pp_nn_part_add (
								   const class nucleons_data &particles_data ,
								   const class array<TYPE> &rho_tab ,
								   const class RDM_PQG_class &Gamma_pp_nn ,
								   const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
								   const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    					
  const unsigned int N_nlj = particles_data.get_N_nlj ();
                
  const class array<unsigned int> &two_states_indices_Gamma_pp_nn = Gamma_pp_nn.get_two_states_indices ();
  
  const class array<int> &Jmin_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pp_nn = Gamma_pp_nn.get_Jmax_table ();
  
  const class block_matrix<TYPE> &Gamma_pp_nn_block_matrix = Gamma_pp_nn.get_block_matrix ();

  const class array<unsigned int> &shells_indices_fixed_parity = rho_pp_nn_coupled_modified.get_shells_indices_fixed_parity ();

  const class block_matrix<TYPE> &rho_coupled_modified_block_matrix = rho_pp_nn_coupled_modified.get_block_matrix ();
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
      {	
	const class pair_str pair_ab(sa , sb);
	
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (shells_qn , shells_qn);
	
	if (are_there_frozen_states) continue;
      
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sb = shells_qn(sb);
	
	const int la = shell_qn_sa.get_l ();
	const int lb = shell_qn_sb.get_l ();

	const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);
	const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);
	
	if (bp_a != bp_b) continue;
      		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	  
	if (Jmin_ab > 1) continue;

	const unsigned int bp = bp_a;
  	
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();
			    
	const bool ja_jb_equal = (ija == ijb);

	const bool is_ja_minus_half_even = (ija%2 == 0);
	    	
	const double ja = shell_qn_sa.get_j ();
	    
	const double hat_ja_phase = (is_ja_minus_half_even) ? (hat (ja)) : (-hat (ja));
	
	const double J_factor_vector_part_phase = (is_ja_minus_half_even) ? (J_factor_vector_part) : (-J_factor_vector_part);
	
	const unsigned int sa_bp_index = (is_J_non_zero) ? (shells_indices_fixed_parity(bp , sa)) : (NADA);
	const unsigned int sb_bp_index = (is_J_non_zero) ? (shells_indices_fixed_parity(bp , sb)) : (NADA);
	  
	if (is_J_non_zero && ja_jb_equal)
	  {
	    const class matrix<TYPE> &rho_coupled_modified_block_matrix_scalar_part = rho_coupled_modified_block_matrix(bp);

	    J_constraints_matrix_scalar_part(sa , sb) = rho_coupled_modified_block_matrix_scalar_part(sa_bp_index , sb_bp_index) - rho_tab(sa , sb)*hat_ja_phase;
	  }
	
	const class matrix<TYPE> dummy_matrix;
		    
	const class matrix<TYPE> &rho_coupled_modified_block_matrix_vector_part = (is_J_non_zero) ? (rho_coupled_modified_block_matrix(bp + 2)) : (dummy_matrix);
		    	
	TYPE J_constraints_matrix_vector_part_ME_pp_nn = (is_J_non_zero) ? (rho_coupled_modified_block_matrix_vector_part(sa_bp_index , sb_bp_index)) : (0.0);
  
	for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
	  {
	    const class nlj_struct &shell_qn_sc = shells_qn(sc);
	      
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	
	    const int ijc = shell_qn_sc.get_ij ();
      
	    const class pair_str pair_ac(sa , sc);
      		
	    const unsigned int BPp = pair_ac.bp_determine (shells_qn , shells_qn);
	
	    const bool is_sa_smaller_than_sc = (sa <= sc);
	    const bool is_sc_smaller_than_sb = (sc <= sb);
		  
	    const bool are_sa_sc_equal = (sa == sc);
	    const bool are_sc_sb_equal = (sc == sb);
		
	    const bool ac_different_cb_different = (!are_sa_sc_equal && !are_sc_sb_equal);
					      
	    const double jc = shell_qn_sc.get_j ();
	    
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);

	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	  	  
	    const double delta_norm_ac = (sa == sc) ? (M_SQRT2) : (1.0);
	    const double delta_norm_cb = (sc == sb) ? (M_SQRT2) : (1.0);
				
	    const int Jp_min_bc = Jmin_table_Gamma_pp_nn(sb , sc);	
	    const int Jp_max_bc = Jmax_table_Gamma_pp_nn(sb , sc);
				      
	    const int Jp_min_ac = Jmin_table_Gamma_pp_nn(sa , sc);	
	    const int Jp_max_ac = Jmax_table_Gamma_pp_nn(sa , sc);
				      		
	    const int Jp_min = ::max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = ::min (Jp_max_bc , Jp_max_ac);
	  
	    TYPE G_ME = ((sb == sc) && ja_jb_equal) ? (rho_tab(sa , sc)) : (0.0);
				
	    TYPE G_ME_part = 0.0;
	  	
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
 	      {
		const bool is_Jp_even = (Jp%2 == 0);
      
		if (ac_different_cb_different || is_Jp_even)
		  {
		    const unsigned int ac_index = (is_sa_smaller_than_sc) ? (two_states_indices_Gamma_pp_nn(Jp , sa , sc)) : (two_states_indices_Gamma_pp_nn(Jp , sc , sa));
		    const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_Gamma_pp_nn(Jp , sc , sb)) : (two_states_indices_Gamma_pp_nn(Jp , sb , sc));

		    const class matrix<TYPE> &Gamma_pp_nn_matrix = Gamma_pp_nn_block_matrix(BPp + 2*Jp);
			  
		    const int phase_ac = (is_sa_smaller_than_sc) ? (1) : (((ija + ijc + Jp)%2 == 0) ? (1) : (-1));
		    const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (((ijc + ijb + Jp)%2 == 0) ? (1) : (-1));
					  
		    const TYPE Gamma_pp_nn_ME = (phase_ac == phase_cb) ? (Gamma_pp_nn_matrix(ac_index , cb_index)) : (-Gamma_pp_nn_matrix(ac_index , cb_index));
					    
		    const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp);
		  
		    G_ME_part -= Gamma_pp_nn_ME*Wigner_6j_hats;
		  }
	      }
	    
	    G_ME_part *= delta_norm_ac*delta_norm_cb;

	    G_ME += G_ME_part;
	  
	    J_constraints_matrix_vector_part_ME_pp_nn += G_ME*OBME_jc_J_factor_vector_part_phase;
	  }
	  	
	J_constraints_matrix_vector_part(sa , sb) += J_constraints_matrix_vector_part_ME_pp_nn;
      }
}














void RDM_J_constraints_class::J_constraints_matrix_prot_pn_part_add (
								     const class nucleons_data &prot_data ,
								     const class nucleons_data &neut_data ,
								     const class RDM_PQG_class &Gamma_pn ,
								     const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    					
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
    
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
  
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
        
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
      {	
	const class pair_str pair_ab(sa_p , sb_p);
      		
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (prot_shells_qn , prot_shells_qn);

	if (are_there_frozen_states) continue;
	
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sb = prot_shells_qn(sb_p);
	
	const int la = shell_qn_sa.get_l ();
	const int lb = shell_qn_sb.get_l ();

	const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);
	const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);
	
	if (bp_a != bp_b) continue;
      		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , prot_shells_qn);		
	  
	if (Jmin_ab > 1) continue;
	
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();  
		
	const double J_factor_vector_part_phase = (ija%2 == 0) ? (J_factor_vector_part) : (-J_factor_vector_part);
		
	TYPE J_constraints_matrix_vector_part_ME_pn = 0.0;
  
	for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
	  {
	    const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);
      		      	  
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int ijc = shell_qn_sc.get_ij ();
      
	    const class pair_str pair_ac(sa_p , sc_n);
      		
	    const unsigned int BPp = pair_ac.bp_determine (prot_shells_qn , neut_shells_qn);
	
	    const double jc = shell_qn_sc.get_j ();
      
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);
	  	  
	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	    
	    const int Jp_min_bc = Jmin_table_Gamma_pn(sb_p , sc_n);	
	    const int Jp_max_bc = Jmax_table_Gamma_pn(sb_p , sc_n);

	    const int Jp_min_ac = Jmin_table_Gamma_pn(sa_p , sc_n);	
	    const int Jp_max_ac = Jmax_table_Gamma_pn(sa_p , sc_n);
	      	
	    const int Jp_min = max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = min (Jp_max_bc , Jp_max_ac);
	  
	    TYPE G_ME = 0.0;
					
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const unsigned int ac_index = two_states_indices_Gamma_pn(Jp , sa_p , sc_n);
		const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sb_p , sc_n);

		const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BPp + 2*Jp);
			  
		const int phase_cb = ((ijc + ijb + Jp) %2 == 0) ? (1) : (-1);
					  
		const TYPE Gamma_pn_ME = (phase_cb == 1) ? (Gamma_pn_matrix(ac_index , cb_index)) : (-Gamma_pn_matrix(ac_index , cb_index));
					    
		const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp);
		  
		G_ME -= Gamma_pn_ME*Wigner_6j_hats;
	      }
		
	    J_constraints_matrix_vector_part_ME_pn += G_ME*OBME_jc_J_factor_vector_part_phase;
	  }
	
	J_constraints_matrix_vector_part(sa_p , sb_p) += J_constraints_matrix_vector_part_ME_pn;
      }
}











void RDM_J_constraints_class::J_constraints_matrix_neut_pn_part_add (
								     const class nucleons_data &prot_data ,
								     const class nucleons_data &neut_data ,
								     const class RDM_PQG_class &Gamma_pn ,
								     const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G)
{    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
      
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
    
  const class array<int> &Jmin_table_Gamma_pn = Gamma_pn.get_Jmin_table ();
  const class array<int> &Jmax_table_Gamma_pn = Gamma_pn.get_Jmax_table ();
      
  const class array<unsigned int> &two_states_indices_Gamma_pn = Gamma_pn.get_two_states_indices ();
  
  const class block_matrix<TYPE> &Gamma_pn_block_matrix = Gamma_pn.get_block_matrix ();
      
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {  
	const class pair_str pair_ab(sa_n , sb_n);
      		
	const bool are_there_frozen_states = pair_ab.are_there_frozen_states_determine  (neut_shells_qn , neut_shells_qn);

	if (are_there_frozen_states) continue;
	
	const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
	const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
	
	const int la = shell_qn_sa.get_l ();
	const int lb = shell_qn_sb.get_l ();

	const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);
	const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);
		
	if (bp_a != bp_b) continue;
      		
	const int Jmin_ab = pair_ab.Jmin_determine (neut_shells_qn , neut_shells_qn);		
	  
	if (Jmin_ab > 1) continue;
		
	const int ija = shell_qn_sa.get_ij ();
	const int ijb = shell_qn_sb.get_ij ();
	    
	const double J_factor_vector_part_phase = (ija%2 == 0) ? (J_factor_vector_part) : (-J_factor_vector_part);
	
	TYPE J_constraints_matrix_vector_part_ME_pn = 0.0;
    
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  {
	    const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);
      		      	
	    const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();

	    if (frozen_state_sc) continue;
	    
	    const int ijc = shell_qn_sc.get_ij ();
      		
	    const class pair_str pair_ac(sa_n , sc_p);
      		
	    const unsigned int BPp = pair_ac.bp_determine (neut_shells_qn , prot_shells_qn);
	
	    const double jc = shell_qn_sc.get_j ();
      
	    const double OBME_jc = angular_matrix_elements::OBME_j_reduced (jc);
	        		
	    const double OBME_jc_J_factor_vector_part_phase = OBME_jc*J_factor_vector_part_phase;
	    
	    const int Jp_min_bc = Jmin_table_Gamma_pn(sc_p , sb_n);	
	    const int Jp_max_bc = Jmax_table_Gamma_pn(sc_p , sb_n);

	    const int Jp_min_ac = Jmin_table_Gamma_pn(sc_p , sa_n);	
	    const int Jp_max_ac = Jmax_table_Gamma_pn(sc_p , sa_n);
	      	
	    const int Jp_min = max (Jp_min_bc , Jp_min_ac);
	    const int Jp_max = min (Jp_max_bc , Jp_max_ac);
					  	  
	    TYPE G_ME = 0.0;
	  	  			
	    for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
	      {
		const unsigned int ac_index = two_states_indices_Gamma_pn(Jp , sc_p , sa_n);
		const unsigned int cb_index = two_states_indices_Gamma_pn(Jp , sc_p , sb_n);

		const class matrix<TYPE> &Gamma_pn_matrix = Gamma_pn_block_matrix(BPp + 2*Jp);
			  
		const int phase_ca = ((ijc + ija + Jp) %2 == 0) ? (1) : (-1);
					  
		const TYPE Gamma_pn_ME = (phase_ca == 1) ? (Gamma_pn_matrix(ac_index , cb_index)) : (-Gamma_pn_matrix(ac_index , cb_index));
					    
		const double Wigner_6j_hats = Wigner_6j_hats_G(ija , ijb , ijc , ijc , 1 , Jp);
		  
		G_ME -= Gamma_pn_ME*Wigner_6j_hats;
	      }

	    J_constraints_matrix_vector_part_ME_pn += G_ME*OBME_jc_J_factor_vector_part_phase;
	  }
	
	J_constraints_matrix_vector_part(sa_n , sb_n) += J_constraints_matrix_vector_part_ME_pn;
      }
}




void RDM_J_constraints_class::add_gradient_part (
						 const bool is_it_der_pn , 
						 const unsigned int BPp ,
						 const int Jp ,
						 const unsigned int ip_jp_upper_triangular_index , 
						 const class RDM_J_constraints_gradient_class &B)
{
  if (!B.is_it_filled ()) return;
  
  if (!is_it_filled ()) return;
  
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();
    
  const class array<class sparse_matrix<TYPE> > &B_J_constraints_gradient_scalar_part = (is_it_der_pn) ? (B.J_constraints_gradient_scalar_part_pn) : (B.J_constraints_gradient_scalar_part_pp_nn);
  const class array<class sparse_matrix<TYPE> > &B_J_constraints_gradient_vector_part = (is_it_der_pn) ? (B.J_constraints_gradient_vector_part_pn) : (B.J_constraints_gradient_vector_part_pp_nn);
  
  const class sparse_matrix<TYPE> &B_sparse_matrix_scalar_part = B_J_constraints_gradient_scalar_part(BPp , Jp , ip_jp_upper_triangular_index);
  const class sparse_matrix<TYPE> &B_sparse_matrix_vector_part = B_J_constraints_gradient_vector_part(BPp , Jp , ip_jp_upper_triangular_index); 
 
  if (B_sparse_matrix_scalar_part.is_it_filled ())
    {
      if (dimension_scalar_part != B_sparse_matrix_scalar_part.get_dimension ()) error_message_print_abort ("J_constraints_matrix_scalar_part and B_sparse_matrix must have the same dimension in RDM_J_constraints_class::add_gradient_part");

      const unsigned int B_non_trivial_zero_number_scalar_part = B_sparse_matrix_scalar_part.get_non_trivial_zeros_number ();
  
      for (unsigned int index = 0 ; index < B_non_trivial_zero_number_scalar_part ; index++)
	{
	  const unsigned int i = B_sparse_matrix_scalar_part.get_row_index (index);
      
	  const unsigned int j = B_sparse_matrix_scalar_part.get_column_index (index);

	  const TYPE B_ME = B_sparse_matrix_scalar_part.get_matrix_element (index);
      
	  J_constraints_matrix_scalar_part(i , j) += B_ME;
	}
    }
  
  if (B_sparse_matrix_vector_part.is_it_filled ())
    {
      if (dimension_vector_part != B_sparse_matrix_vector_part.get_dimension ()) error_message_print_abort ("J_constraints_matrix_vector_part and B_sparse_matrix must have the same dimension in RDM_J_constraints_class::add_gradient_part");

      const unsigned int B_non_trivial_zero_number_vector_part = B_sparse_matrix_vector_part.get_non_trivial_zeros_number ();
  
      for (unsigned int index = 0 ; index < B_non_trivial_zero_number_vector_part ; index++)
	{
	  const unsigned int i = B_sparse_matrix_vector_part.get_row_index (index);
      
	  const unsigned int j = B_sparse_matrix_vector_part.get_column_index (index);

	  const TYPE B_ME = B_sparse_matrix_vector_part.get_matrix_element (index);
      
	  J_constraints_matrix_vector_part(i , j) += B_ME;
	}
    }
}




TYPE Frobenius_scalar_product (
			       const class RDM_J_constraints_class &A ,
			       const class RDM_J_constraints_class &B)				 
{
  if (!A.is_it_filled ()) return 0.0;
  if (!B.is_it_filled ()) return 0.0;
  
  const class matrix<TYPE> &A_matrix_scalar_part = A.J_constraints_matrix_scalar_part;
  const class matrix<TYPE> &B_matrix_scalar_part = B.J_constraints_matrix_scalar_part;
  
  const class matrix<TYPE> &A_matrix_vector_part = A.J_constraints_matrix_vector_part;
  const class matrix<TYPE> &B_matrix_vector_part = B.J_constraints_matrix_vector_part;

  const TYPE Frobenius_scalar_product_matrix_scalar_part = (A_matrix_scalar_part.is_it_filled () && B_matrix_scalar_part.is_it_filled ()) ? (Frobenius_scalar_product (A_matrix_scalar_part , B_matrix_scalar_part)) : (0.0);
  const TYPE Frobenius_scalar_product_matrix_vector_part = (A_matrix_vector_part.is_it_filled () && B_matrix_vector_part.is_it_filled ()) ? (Frobenius_scalar_product (A_matrix_vector_part , B_matrix_vector_part)) : (0.0);

  const TYPE Frobenius_scalar_product = Frobenius_scalar_product_matrix_scalar_part + Frobenius_scalar_product_matrix_vector_part;

  return Frobenius_scalar_product;
}








void RDM_J_constraints_class::add_rho_coupled_modified_gradient_part (
								      const int j ,
								      const unsigned int sa_bp_index ,
								      const unsigned int sb_bp_index ,
								      const TYPE &x)
{
  if (!is_J_non_zero || !is_it_filled ()) return;

  if (sa_bp_index == sb_bp_index)
    {
      switch (j)
	{
	case 0: J_constraints_matrix_scalar_part(sa_bp_index , sb_bp_index) += x; break;
	case 1: J_constraints_matrix_vector_part(sa_bp_index , sb_bp_index) += x; break;
      
	default: break;
	}
    }
  else
    {
      switch (j)
	{
	case 0:
	  {
	    J_constraints_matrix_scalar_part(sa_bp_index , sb_bp_index) += x;
	    J_constraints_matrix_scalar_part(sb_bp_index , sa_bp_index) += x;
	  } break;
      
	case 1:
	  {
	    J_constraints_matrix_vector_part(sa_bp_index , sb_bp_index) += x;
	    J_constraints_matrix_vector_part(sb_bp_index , sa_bp_index) += x;
	  } break;
      
	default: break;
	}
    }
}



TYPE Frobenius_scalar_product_matrix_rho_coupled_modified_gradient (
								    const int j ,
								    const unsigned int sa_bp_index ,
								    const unsigned int sb_bp_index , 
								    const class RDM_J_constraints_class &A)
{
  if (!A.is_J_non_zero || !A.is_it_filled ()) return 0.0;

  switch (j)
    {
    case 0:
      {	
	const class matrix<TYPE> &A_matrix_scalar_part = A.J_constraints_matrix_scalar_part;

	if (!A_matrix_scalar_part.is_it_filled ()) return 0.0;

	const TYPE A_matrix_scalar_part_ME = A_matrix_scalar_part(sa_bp_index , sb_bp_index);

	return ((sa_bp_index == sb_bp_index) ? (A_matrix_scalar_part_ME) : (2.0*A_matrix_scalar_part_ME));
      }
      
    case 1:
      {	
	const class matrix<TYPE> &A_matrix_vector_part = A.J_constraints_matrix_vector_part;

	if (!A_matrix_vector_part.is_it_filled ()) return 0.0;

	const TYPE A_matrix_vector_part_ME = A_matrix_vector_part(sa_bp_index , sb_bp_index);

	return ((sa_bp_index == sb_bp_index) ? (A_matrix_vector_part_ME) : (2.0*A_matrix_vector_part_ME));
      }

    default: return 0.0;
    }
}






#ifdef UseMPI

void RDM_J_constraints_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();
    
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  if (THIS_PROCESS == Send_process)
    {
      unsigned int index = 0;
      
      for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = J_constraints_matrix_scalar_part(ii , jj);
      
      for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = J_constraints_matrix_vector_part(ii , jj);
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Bcast(send).");
    }
  
  T_MPI.MPI_Bcast (Send_process , MPI_C);
  
  if (THIS_PROCESS != Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  J_constraints_matrix_scalar_part(ii , jj) = J_constraints_matrix_scalar_part(jj , ii) = T_MPI(index++);
      
      for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  J_constraints_matrix_vector_part(ii , jj) = J_constraints_matrix_vector_part(jj , ii) = T_MPI(index++);
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Bcast(receive).");
    }
}

void RDM_J_constraints_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();
    
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  unsigned int index = 0;
      
  for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_scalar_part(ii , jj);
      
  for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_vector_part(ii , jj);
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Reduce(send).");
  
  T_MPI.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  if (THIS_PROCESS == Recv_process)
    {
      index = 0;
      
      for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  J_constraints_matrix_scalar_part(ii , jj) = J_constraints_matrix_scalar_part(jj , ii) = T_MPI(index++);
      
      for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  J_constraints_matrix_vector_part(ii , jj) = J_constraints_matrix_vector_part(jj , ii) = T_MPI(index++);
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Reduce(receive).");
    }
}

void RDM_J_constraints_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();
    
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  unsigned int index = 0;
      
  for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_scalar_part(ii , jj);
      
  for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_vector_part(ii , jj);
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Allreduce(send).");
  
  T_MPI.MPI_Allreduce (op , MPI_C);

  index = 0;
  
  for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      J_constraints_matrix_scalar_part(ii , jj) = J_constraints_matrix_scalar_part(jj , ii) = T_MPI(index++);
      
  for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      J_constraints_matrix_vector_part(ii , jj) = J_constraints_matrix_vector_part(jj , ii) = T_MPI(index++);
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Allreduce(receive).");
}

void RDM_J_constraints_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int dimension_scalar_part = J_constraints_matrix_scalar_part.get_dimension ();
  const unsigned int dimension_vector_part = J_constraints_matrix_vector_part.get_dimension ();
    
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  unsigned int index = 0;
      
  for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_scalar_part(ii , jj);
      
  for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      T_MPI(index++) = J_constraints_matrix_vector_part(ii , jj);

  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Allgatherv(send).");
  
  T_MPI.MPI_Allgatherv (group_processes_number , MPI_C);

  index = 0;
  
  for (unsigned int ii = 0 ; ii < dimension_scalar_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      J_constraints_matrix_scalar_part(ii , jj) = J_constraints_matrix_scalar_part(jj , ii) = T_MPI(index++);
      
  for (unsigned int ii = 0 ; ii < dimension_vector_part ; ii++)
    for (unsigned int jj = 0 ; jj <= ii ; jj++)
      J_constraints_matrix_vector_part(ii , jj) = J_constraints_matrix_vector_part(jj , ii) = T_MPI(index++);
            
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_J_constraints_class::MPI_Allgatherv(receive).");
}

#endif



