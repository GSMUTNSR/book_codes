#include "../RDM_include/RDM_include_def.h"

using namespace inputs_misc;

using namespace RDM_Hessian_vector_no_sigma;

void RDM_Hessian_linear_system_LU_Cholesky::LU_Cholesky_column_pp_nn_pn_part_store (
										    const class block_matrix<TYPE> &HV_part ,
										    const unsigned int i ,
										    unsigned int &j ,
										    class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma)
{
  const unsigned int blocks_number_part = HV_part.get_blocks_number ();
  
  for (unsigned int i_part = 0 ; i_part < blocks_number_part ; i_part++)
    {
      class matrix<TYPE> &HVi_part = HV_part(i_part);
      
      const unsigned int block_dimension_part = HVi_part.get_dimension ();
      
      for (unsigned int ii_part = 0 ; ii_part < block_dimension_part ; ii_part++)
	for (unsigned int jj_part = 0 ; jj_part <= ii_part ; jj_part++)
	  LU_Cholesky_Hessian_matrix_no_sigma(i , j++) = HVi_part(ii_part , jj_part);            
    }
}








void RDM_Hessian_linear_system_LU_Cholesky::LU_Cholesky_Hessian_matrix_indices_alloc_calc (
											   const class block_matrix<TYPE> &Vpp , 
											   const class block_matrix<TYPE> &Vnn , 
											   const class block_matrix<TYPE> &Vpn , 
											   const class block_matrix<TYPE> &Vpp_rho , 
											   const class block_matrix<TYPE> &Vnn_rho , 
											   class array<bool> &is_it_rho_tab , 
											   class array<enum space_type> &spaces , 
											   class array<unsigned short int> &i_part_indices , 
											   class array<unsigned short int> &ii_indices , 
											   class array<unsigned short int> &jj_indices)
{
  const unsigned int Hessian_vector_dimension = dimension_calc (Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho);
  
  const unsigned int blocks_number_pp = Vpp.get_blocks_number ();
  const unsigned int blocks_number_nn = Vnn.get_blocks_number ();
  const unsigned int blocks_number_pn = Vpn.get_blocks_number ();

  const unsigned int blocks_number_rho_pp = Vpp_rho.get_blocks_number ();
  const unsigned int blocks_number_rho_nn = Vnn_rho.get_blocks_number ();
  
  is_it_rho_tab.allocate (Hessian_vector_dimension);

  spaces.allocate (Hessian_vector_dimension);
  
  i_part_indices.allocate (Hessian_vector_dimension);
  
  ii_indices.allocate (Hessian_vector_dimension);
  jj_indices.allocate (Hessian_vector_dimension);

  is_it_rho_tab = false;
  
  spaces = NO_SPACE;
  
  i_part_indices = OUT_OF_RANGE;
  
  ii_indices = OUT_OF_RANGE;
  jj_indices = OUT_OF_RANGE;
										     
  unsigned int i = 0;

  for (unsigned int ipp = 0 ; ipp < blocks_number_pp ; ipp++)
    {
      class matrix<TYPE> &Vipp = Vpp(ipp);
      
      const unsigned int block_dimension = Vipp.get_dimension ();
      
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  {
	    spaces(i) = PROTONS_ONLY;
  
	    i_part_indices(i) = ipp;
      
	    ii_indices(i) = ii;
	    jj_indices(i) = jj;
      
	    i++;
	  }
    }
  
  for (unsigned int inn = 0 ; inn < blocks_number_nn ; inn++)
    {
      class matrix<TYPE> &Vinn = Vnn(inn);
      
      const unsigned int block_dimension = Vinn.get_dimension ();
      
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  {
	    spaces(i) = NEUTRONS_ONLY;
	    
	    i_part_indices(i) = inn;
      
	    ii_indices(i) = ii;
	    jj_indices(i) = jj;
      
	    i++;
	  }
    }

  for (unsigned int ipn = 0 ; ipn < blocks_number_pn ; ipn++)
    {
      class matrix<TYPE> &Vipn = Vpn(ipn);
      
      const unsigned int block_dimension = Vipn.get_dimension ();
      
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  {
	    spaces(i) = PROTONS_NEUTRONS;
	    
	    i_part_indices(i) = ipn;
      
	    ii_indices(i) = ii;
	    jj_indices(i) = jj;
      
	    i++;
	  }
    }

  for (unsigned int ipp = 0 ; ipp < blocks_number_rho_pp ; ipp++)
    {
      class matrix<TYPE> &Vipp_rho = Vpp_rho(ipp);
      
      const unsigned int block_dimension = Vipp_rho.get_dimension ();
      
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  {
	    is_it_rho_tab(i) = true;
	    
	    spaces(i) = PROTONS_ONLY;
  
	    i_part_indices(i) = ipp;
      
	    ii_indices(i) = ii;
	    jj_indices(i) = jj;
      
	    i++;
	  }
    }
  
  for (unsigned int inn = 0 ; inn < blocks_number_rho_nn ; inn++)
    {
      class matrix<TYPE> &Vinn_rho = Vnn_rho(inn);
      
      const unsigned int block_dimension = Vinn_rho.get_dimension ();
      
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  {
	    is_it_rho_tab(i) = true;
	    
	    spaces(i) = NEUTRONS_ONLY;
	    
	    i_part_indices(i) = inn;
      
	    ii_indices(i) = ii;
	    jj_indices(i) = jj;
      
	    i++;
	  }
    }
  
  if (i != Hessian_vector_dimension) error_message_print_abort ("Problem with the indices of the LU/Cholesky decomposition of the Hessian matrix in RDM_Hessian_linear_system_LU_Cholesky::LU_Cholesky_Hessian_matrix_indices_calc");
}











void RDM_Hessian_linear_system_LU_Cholesky::matrix_no_sigma_alloc_calc_store (
									      const class input_data_str &input_data , 
									      class RDM_conditions_class &V_Gamma ,
									      class RDM_conditions_class &X_Gamma ,
									      class RDM_conditions_class &helper_add ,
									      class RDM_conditions_gradient_class &A_Gamma_gradients ,
									      class block_matrix<TYPE> &Vpp , 
									      class block_matrix<TYPE> &Vnn , 
									      class block_matrix<TYPE> &Vpn , 
									      class block_matrix<TYPE> &Vpp_rho , 
									      class block_matrix<TYPE> &Vnn_rho , 
									      class block_matrix<TYPE> &HVpp , 
									      class block_matrix<TYPE> &HVnn , 
									      class block_matrix<TYPE> &HVpn , 
									      class block_matrix<TYPE> &HVpp_rho , 
									      class block_matrix<TYPE> &HVnn_rho , 
									      class array<bool> &is_it_rho_tab , 
									      class array<enum space_type> &spaces , 
									      class array<unsigned short int> &i_part_indices , 
									      class array<unsigned short int> &ii_indices , 
									      class array<unsigned short int> &jj_indices ,
									      class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma)
{
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const unsigned int Hessian_vector_dimension = dimension_calc (Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho);
  
  LU_Cholesky_Hessian_matrix_indices_alloc_calc (Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho , is_it_rho_tab , spaces , i_part_indices , ii_indices , jj_indices);
  
  LU_Cholesky_Hessian_matrix_no_sigma.allocate (Hessian_vector_dimension);
  
  Vpp.zero ();
  Vnn.zero ();
  Vpn.zero ();

  Vpp_rho.zero ();  
  Vnn_rho.zero ();
  
  for (unsigned int i = 0 ; i < Hessian_vector_dimension ; i++)
    {
      const bool is_it_rho = is_it_rho_tab(i);
      
      const enum space_type space = spaces(i);
      
      const unsigned int i_part = i_part_indices(i);
      
      const unsigned int ii = ii_indices(i);
      const unsigned int jj = jj_indices(i);
      
      class matrix<TYPE> &V_part = matrix_pp_nn_pn_part_determine (is_it_rho , space , i_part , Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho);

      V_part(ii , jj) = V_part(jj , ii) = (ii == jj) ? (1.0) : (0.5);
      
      apply (Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho , V_Gamma , X_Gamma , helper_add , A_Gamma_gradients , HVpp , HVnn , HVpn , HVpp_rho , HVnn_rho);
      
      unsigned int j = 0;
      
      LU_Cholesky_column_pp_nn_pn_part_store (HVpp , i , j , LU_Cholesky_Hessian_matrix_no_sigma);
      LU_Cholesky_column_pp_nn_pn_part_store (HVnn , i , j , LU_Cholesky_Hessian_matrix_no_sigma);
      LU_Cholesky_column_pp_nn_pn_part_store (HVpn , i , j , LU_Cholesky_Hessian_matrix_no_sigma);
	    
      LU_Cholesky_column_pp_nn_pn_part_store (HVpp_rho , i , j , LU_Cholesky_Hessian_matrix_no_sigma);
      LU_Cholesky_column_pp_nn_pn_part_store (HVnn_rho , i , j , LU_Cholesky_Hessian_matrix_no_sigma);
          
      if (j != Hessian_vector_dimension) error_message_print_abort ("Problem with the LU/Cholesky decomposition of the Hessian matrix in RDM_Hessian_linear_system_LU_Cholesky::LU_Cholesky_calc (j)");
      
      V_part(ii , jj) = V_part(jj , ii) = 0.0;
	  
      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "Column " << i << " of the Hessian matrix calculated" << endl;
    }
  
  LU_Cholesky_Hessian_matrix_no_sigma.symmetrize ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;

  LU_Cholesky_Hessian_matrix_no_sigma.Cholesky_decompose ();

  if (THIS_PROCESS == MASTER_PROCESS)
    {
      if (LU_Cholesky_Hessian_matrix_no_sigma.is_it_Cholesky_decomposed ())
	cout << "Cholesky decomposition of the Hessian matrix calculated" << endl << endl;
      else
	cout << "Cholesky decomposition of the Hessian matrix failed: LU decomposition done instead." << endl << endl;     
    }
  
  if (!LU_Cholesky_Hessian_matrix_no_sigma.is_it_Cholesky_decomposed ())
    {
      LU_Cholesky_Hessian_matrix_no_sigma.LU_decompose ();
      
      if (!LU_Cholesky_Hessian_matrix_no_sigma.is_it_LU_decomposed ())
	error_message_print_abort ("LU decomposition of the Hessian matrix failed.");
      else if (THIS_PROCESS == MASTER_PROCESS)
	cout << "LU decomposition of the Hessian matrix calculated" << endl << endl;
    }
}













void RDM_Hessian_linear_system_LU_Cholesky::linear_system_solve (
								 const double sigma ,
								 const class block_matrix<TYPE> &Bpp , 
								 const class block_matrix<TYPE> &Bnn , 
								 const class block_matrix<TYPE> &Bpn ,
								 const class block_matrix<TYPE> &Bpp_rho , 
								 const class block_matrix<TYPE> &Bnn_rho , 
								 const class array<bool> &is_it_rho_tab , 
								 const class array<enum space_type> &spaces , 
								 const class array<unsigned short int> &i_part_indices , 
								 const class array<unsigned short int> &ii_indices , 
								 const class array<unsigned short int> &jj_indices ,
								 class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma ,
								 class vector_class<TYPE> &B_LU_Cholesky ,
								 class vector_class<TYPE> &X_LU_Cholesky ,
								 class RDM_PQG_class &Delta_Gamma_pp ,
								 class RDM_PQG_class &Delta_Gamma_nn ,	
								 class RDM_PQG_class &Delta_Gamma_pn ,
								 class RDM_rho_coupled_modified_class &Delta_rho_pp ,
								 class RDM_rho_coupled_modified_class &Delta_rho_nn)
{  
  const unsigned int Hessian_vector_dimension = LU_Cholesky_Hessian_matrix_no_sigma.get_dimension ();
  
  class block_matrix<TYPE> &Xpp = Delta_Gamma_pp.get_block_matrix ();
  class block_matrix<TYPE> &Xnn = Delta_Gamma_nn.get_block_matrix ();
  class block_matrix<TYPE> &Xpn = Delta_Gamma_pn.get_block_matrix ();
    
  class block_matrix<TYPE> &Xpp_rho = Delta_rho_pp.get_block_matrix ();
  class block_matrix<TYPE> &Xnn_rho = Delta_rho_nn.get_block_matrix ();
  
  for (unsigned int i = 0 ; i < Hessian_vector_dimension ; i++)
    {
      const bool is_it_rho = is_it_rho_tab(i);
      
      const enum space_type space = spaces(i);
      
      const unsigned int i_part = i_part_indices(i);
      
      const unsigned int ii = ii_indices(i);
      const unsigned int jj = jj_indices(i);

      const class matrix<TYPE> &B_part = matrix_pp_nn_pn_part_determine (is_it_rho , space , i_part , Bpp , Bnn , Bpn , Bpp_rho , Bnn_rho);
      
      B_LU_Cholesky(i) = B_part(ii , jj);
    }
   
  linear_system_solution_calc<TYPE> (LU_Cholesky_Hessian_matrix_no_sigma , B_LU_Cholesky , X_LU_Cholesky);
  
  for (unsigned int i = 0 ; i < Hessian_vector_dimension ; i++)
    {
      const bool is_it_rho = is_it_rho_tab(i);
      
      const enum space_type space = spaces(i);
      
      const unsigned int i_part = i_part_indices(i);
      
      const unsigned int ii = ii_indices(i);
      const unsigned int jj = jj_indices(i);
            
      class matrix<TYPE> &X_part = matrix_pp_nn_pn_part_determine (is_it_rho , space , i_part , Xpp , Xnn , Xpn , Xpp_rho , Xnn_rho);
      
      X_part(ii , jj) = X_part(jj , ii) = X_LU_Cholesky(i);
    }
  
  Xpp /= sigma;
  Xnn /= sigma;
  Xpn /= sigma;
  
  Xpp_rho /= sigma;
  Xnn_rho /= sigma;  
}



