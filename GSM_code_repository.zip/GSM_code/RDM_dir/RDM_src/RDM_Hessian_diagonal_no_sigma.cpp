#include "../RDM_include/RDM_include_def.h"

using namespace RDM_Hessian_vector_no_sigma;
using namespace RDM_rho_observables;
using namespace RDM_rho_observables_gradient;







void RDM_Hessian_diagonal_no_sigma::Hessian_diagonal_no_sigma_pp_nn_part_calc (
									       const enum particle_type particle ,
									       const class RDM_conditions_class &A_Gamma ,
									       const class RDM_conditions_gradient_class &A_Gamma_gradients , 				 
									       class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pp_nn , 				 
									       class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_pp_nn)
{
  const enum particle_type particle_other_space = (particle == PROTON) ? (NEUTRON) : (PROTON);

  const enum space_type space = (particle == PROTON) ? (PROTONS_ONLY) : (NEUTRONS_ONLY);
  
  const bool is_there_G_constraint = A_Gamma.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = A_Gamma.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = A_Gamma.get_is_there_T2_prime_constraint ();
  
  const bool is_there_CM_correction = A_Gamma.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = A_Gamma.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = A_Gamma.get_is_there_E_reference ();
              
  const class array<double> &Delta_J_der_tab = A_Gamma_gradients.get_Delta_J_der_tab (space);
  
  const class block_matrix<TYPE> &Delta_E_reference_der_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (space);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (space); 
              
  const class RDM_QG_gradient_class &Q_pp_nn_gradient = A_Gamma_gradients.get_Q_gradient (space);
  
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_nn_gradient = A_Gamma_gradients.get_G_gradient (space            , particle);
  const class RDM_QG_gradient_class &G_pn_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , particle_other_space);
  
  const class RDM_J_constraints_gradient_class &J_constraints_pp_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (particle);
      
  const class RDM_T1_gradient_class &T1_ppp_nnn_gradient = A_Gamma_gradients.get_T1_gradient (space , particle);
    
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppp_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (space , particle);  
  
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  const class array<class block_sparse_matrix<TYPE> > &Q_pp_nn_der_pp_nn_block_matrices = Q_pp_nn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pp_nn_block_matrices = Q_pn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_nn_der_pp_nn_block_matrices = G_pp_nn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_np_der_pp_nn_block_matrices = G_pn_np_gradient.get_block_matrices (space);
      
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_nnn_der_pp_nn_block_matrices = T1_ppp_nnn_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pp_nn_block_matrices = T1_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pp_nn_block_matrices = T1_nnp_gradient.get_block_matrices (space);
  
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_nnn_der_pp_nn_block_matrices = T2_prime_ppp_nnn_gradient.get_block_matrices (space);
  		
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pp_nn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pp_nn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pp_nn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (space);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pp_nn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (space);
      
  const class RDM_PQG_class &P_pp_nn = A_Gamma.get_P_dependent_term (space);

  const class RDM_rho_coupled_modified_class &rho_coupled_modified_pp_nn = A_Gamma.get_rho_coupled_modified_dependent_term (particle);
  
  const class block_matrix<TYPE> &rho_coupled_modified_pp_nn_block_matrix = rho_coupled_modified_pp_nn.get_block_matrix ();
  
  const class array<unsigned int> &matrix_dimensions = P_pp_nn.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const int jmax_ab_global = rho_coupled_modified_pp_nn.get_jmax_ab_global ();
  
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);

  Hessian_diagonal_no_sigma_pp_nn.zero ();
  
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
	  	      
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
		
	      const class block_sparse_matrix<TYPE> &Q_pp_nn_der_pp_nn_block_matrix = Q_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
  
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pp_nn_block_matrix = Q_pn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
	    
	      class matrix<TYPE> &Hessian_diagonal_no_sigma_pp_nn_BPp_Jp = Hessian_diagonal_no_sigma_pp_nn(BPp + 2*Jp);
	
	      TYPE &Hessian_diagonal_no_sigma_pp_nn_ME = Hessian_diagonal_no_sigma_pp_nn_BPp_Jp(ip , jp);
		
	      if (Q_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += Q_pp_nn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
	  		
	      if (are_there_J_constraints) Hessian_diagonal_no_sigma_pp_nn_ME += Frobenius_squared_norm_gradient (false , BPp , Jp , index_prime , J_constraints_pp_nn_gradient);
	  
	      if (Q_pn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += Q_pn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
	 
	      if (is_there_G_constraint)
		{		
		  const class block_sparse_matrix<TYPE> &G_pp_nn_der_pp_nn_block_matrix = G_pp_nn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_np_der_pp_nn_block_matrix = G_pn_np_der_pp_nn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pn_np_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += G_pn_np_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		  if (G_pp_nn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += G_pp_nn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		}
	      
	      if (is_there_T1_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T1_ppp_nnn_der_pp_nn_block_matrix = T1_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pp_nn_block_matrix = T1_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pp_nn_block_matrix = T1_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  
		  if (T1_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T1_ppp_nnn_der_pp_nn_block_matrix.Frobenius_squared_norm ();

		  if (T1_ppn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T1_ppn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		  if (T1_nnp_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T1_nnp_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		}
	      
	      if (is_there_T2_prime_constraint)
		{  
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_nnn_der_pp_nn_block_matrix = T2_prime_ppp_nnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		    
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pp_nn_block_matrix = T2_prime_ppn_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pp_nn_block_matrix = T2_prime_nnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pp_nn_block_matrix = T2_prime_pnp_der_pp_nn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pp_nn_block_matrix = T2_prime_pnn_der_pp_nn_block_matrices(BPp , Jp , index_prime);

		  if (T2_prime_ppp_nnn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T2_prime_ppp_nnn_der_pp_nn_block_matrix.Frobenius_squared_norm ();

		  if (T2_prime_ppn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T2_prime_ppn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_nnp_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T2_prime_nnp_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_pnp_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T2_prime_pnp_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_pnn_der_pp_nn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pp_nn_ME += T2_prime_pnn_der_pp_nn_block_matrix.Frobenius_squared_norm ();
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) Hessian_diagonal_no_sigma_pp_nn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
  
  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);

	const unsigned int BPp_Jp_index = BPp + 2*Jp;
	
	const int Delta_pp_nn_pairs_number_dependent_term_part_der = 2*Jp + 1;
	
	const TYPE Delta_pp_nn_pairs_number_dependent_term_part_der_square = Delta_pp_nn_pairs_number_dependent_term_part_der*Delta_pp_nn_pairs_number_dependent_term_part_der;
	    
	const class matrix<TYPE> &Delta_E_reference_der_block_matrix_BPp_Jp = Delta_E_reference_der_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_block_matrix_BPp_Jp = Delta_Hcm_der_block_matrix(BPp_Jp_index);
		
	class matrix<TYPE> &Hessian_diagonal_no_sigma_pp_nn_BPp_Jp = Hessian_diagonal_no_sigma_pp_nn(BPp_Jp_index);
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    {
	      const TYPE Delta_E_reference_dependent_term_part = (is_there_E_reference) ? (Delta_E_reference_der_block_matrix_BPp_Jp(ip , jp)) : (NADA);
	    
	      const TYPE Delta_Hcm_dependent_term_part = (is_there_CM_correction) ? (Delta_Hcm_der_block_matrix_BPp_Jp(ip , jp)) : (NADA);
	      	      
	      TYPE &Hessian_diagonal_no_sigma_pp_nn_ME = Hessian_diagonal_no_sigma_pp_nn_BPp_Jp(ip , jp);
		
	      Hessian_diagonal_no_sigma_pp_nn_ME += 4.0;
		
	      if (is_there_E_reference) Hessian_diagonal_no_sigma_pp_nn_ME += Delta_E_reference_dependent_term_part*Delta_E_reference_dependent_term_part;
	      
	      if (is_there_CM_correction) Hessian_diagonal_no_sigma_pp_nn_ME += Delta_Hcm_dependent_term_part*Delta_Hcm_dependent_term_part;
	    }
	    
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {	    
	    const TYPE Delta_J_dependent_term_part = Delta_J_der_tab(BPp , Jp , ip);	    

	    const TYPE Delta_E_reference_dependent_term_part = (is_there_E_reference) ? (Delta_E_reference_der_block_matrix_BPp_Jp(ip , ip)) : (NADA);
	    
	    const TYPE Delta_Hcm_dependent_term_part = (is_there_CM_correction) ? (Delta_Hcm_der_block_matrix_BPp_Jp(ip , ip)) : (NADA);
			      
	    TYPE &Hessian_diagonal_no_sigma_pp_nn_ME = Hessian_diagonal_no_sigma_pp_nn_BPp_Jp(ip , ip);
	      	    
	    Hessian_diagonal_no_sigma_pp_nn_ME += 1.0;
	    
	    Hessian_diagonal_no_sigma_pp_nn_ME += Delta_pp_nn_pairs_number_dependent_term_part_der_square;

	    Hessian_diagonal_no_sigma_pp_nn_ME += Delta_J_dependent_term_part*Delta_J_dependent_term_part;
		
	    if (is_there_E_reference) Hessian_diagonal_no_sigma_pp_nn_ME += Delta_E_reference_dependent_term_part*Delta_E_reference_dependent_term_part;
	    
	    if (is_there_CM_correction) Hessian_diagonal_no_sigma_pp_nn_ME += Delta_Hcm_dependent_term_part*Delta_Hcm_dependent_term_part;	    
	  }
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    Hessian_diagonal_no_sigma_pp_nn_BPp_Jp(jp , ip) = Hessian_diagonal_no_sigma_pp_nn_BPp_Jp(ip , jp);	
      }

  if (are_there_J_constraints && (jmax_ab_global > 0))
    {
      Hessian_diagonal_rho_no_sigma_pp_nn.zero ();
  
      for (unsigned int bp = 0 ; bp <= 1 ; bp++)  
	for (int j = 0 ; j <= jmax_ab_global ; j++)
	  {	
	    const unsigned int bp_j_index = bp + 2*j;
	
	    const class matrix<TYPE> &rho_coupled_modified_pp_nn_block_matrix_bp_j = rho_coupled_modified_pp_nn_block_matrix(bp_j_index);
	
	    const unsigned int dimension_bp_j = rho_coupled_modified_pp_nn_block_matrix_bp_j.get_dimension ();
		
	    class matrix<TYPE> &Hessian_diagonal_rho_no_sigma_pp_nn_bp_j = Hessian_diagonal_rho_no_sigma_pp_nn(bp_j_index);
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index < sb_bp_index ; sa_bp_index++)
		{
		  TYPE &Hessian_diagonal_rho_no_sigma_pp_nn_ME = Hessian_diagonal_rho_no_sigma_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	      
		  Hessian_diagonal_rho_no_sigma_pp_nn_ME += 4.0;
	      
		  if (are_there_J_constraints) Hessian_diagonal_rho_no_sigma_pp_nn_ME += 4.0;
		}
	
	    for (unsigned int sa_bp_index = 0 ; sa_bp_index < dimension_bp_j ; sa_bp_index++)
	      {	    
		TYPE &Hessian_diagonal_rho_no_sigma_pp_nn_ME = Hessian_diagonal_rho_no_sigma_pp_nn_bp_j(sa_bp_index , sa_bp_index);

		Hessian_diagonal_rho_no_sigma_pp_nn_ME += 1.0;
	    
		if (are_there_J_constraints) Hessian_diagonal_rho_no_sigma_pp_nn_ME += 1.0;
	      }
	
	    for (unsigned int sb_bp_index = 0 ; sb_bp_index < dimension_bp_j ; sb_bp_index++)
	      for (unsigned int sa_bp_index = 0 ; sa_bp_index < sb_bp_index ; sa_bp_index++)
		Hessian_diagonal_rho_no_sigma_pp_nn_bp_j(sb_bp_index , sa_bp_index) = Hessian_diagonal_rho_no_sigma_pp_nn_bp_j(sa_bp_index , sb_bp_index);
	  }
    }
}















void RDM_Hessian_diagonal_no_sigma::Hessian_diagonal_no_sigma_pn_part_calc  (
									     const class RDM_conditions_class &A_Gamma ,
									     const class RDM_conditions_gradient_class &A_Gamma_gradients , 			
									     class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pn)
{  
  const bool is_there_G_constraint = A_Gamma.get_is_there_G_constraint ();
  
  const bool is_there_T1_constraint = A_Gamma.get_is_there_T1_constraint ();

  const bool is_there_T2_prime_constraint = A_Gamma.get_is_there_T2_prime_constraint ();
    
  const bool is_there_CM_correction = A_Gamma.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = A_Gamma.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = A_Gamma.get_is_there_E_reference ();
      
  const class array<double> &Delta_J_der_pn_tab = A_Gamma_gradients.get_Delta_J_der_tab (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &ba_from_ab_pn_indices = A_Gamma_gradients.get_ba_from_ab_pn_indices ();
  
  const class array<int> &average_T2_der_pn_tab = A_Gamma_gradients.get_average_T2_der_pn_tab ();
  
  const class block_matrix<TYPE> &Delta_E_reference_der_pn_block_matrix = A_Gamma_gradients.get_Delta_E_reference_der_block_matrix (PROTONS_NEUTRONS);
  
  const class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix = A_Gamma_gradients.get_Delta_Hcm_der_block_matrix (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &Q_pp_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_ONLY);
  const class RDM_QG_gradient_class &Q_nn_gradient = A_Gamma_gradients.get_Q_gradient (NEUTRONS_ONLY);
  const class RDM_QG_gradient_class &Q_pn_gradient = A_Gamma_gradients.get_Q_gradient (PROTONS_NEUTRONS);
  
  const class RDM_QG_gradient_class &G_pp_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_QG_gradient_class &G_nn_gradient = A_Gamma_gradients.get_G_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_QG_gradient_class &G_pn_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , NEUTRON);
  const class RDM_QG_gradient_class &G_np_gradient = A_Gamma_gradients.get_G_gradient (PROTONS_NEUTRONS , PROTON);
    
  const class RDM_J_constraints_gradient_class &J_constraints_pp_gradient = A_Gamma_gradients.get_J_constraints_gradient (PROTON);
  const class RDM_J_constraints_gradient_class &J_constraints_nn_gradient = A_Gamma_gradients.get_J_constraints_gradient (NEUTRON);
  
  const class RDM_T1_gradient_class &T1_ppp_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , PROTON);
  const class RDM_T1_gradient_class &T1_nnn_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , NEUTRON);
  const class RDM_T1_gradient_class &T1_ppn_gradient = A_Gamma_gradients.get_T1_gradient (PROTONS_ONLY  , NEUTRON);
  const class RDM_T1_gradient_class &T1_nnp_gradient = A_Gamma_gradients.get_T1_gradient (NEUTRONS_ONLY , PROTON);

  const class RDM_T2_prime_gradient_class &T2_prime_ppp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_ppn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_ONLY     , NEUTRON);
  const class RDM_T2_prime_gradient_class &T2_prime_nnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (NEUTRONS_ONLY    , PROTON);  
  const class RDM_T2_prime_gradient_class &T2_prime_pnp_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , PROTON);
  const class RDM_T2_prime_gradient_class &T2_prime_pnn_gradient = A_Gamma_gradients.get_T2_prime_gradient (PROTONS_NEUTRONS , NEUTRON);

  const class array<class block_sparse_matrix<TYPE> > &Q_pp_der_pn_block_matrices = Q_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_nn_der_pn_block_matrices = Q_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &Q_pn_der_pn_block_matrices = Q_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  
  const class array<class block_sparse_matrix<TYPE> > &G_pp_der_pn_block_matrices = G_pp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_nn_der_pn_block_matrices = G_nn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_pn_der_pn_block_matrices = G_pn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &G_np_der_pn_block_matrices = G_np_gradient.get_block_matrices (PROTONS_NEUTRONS);
      
  const class array<class block_sparse_matrix<TYPE> > &T1_ppp_der_pn_block_matrices = T1_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnn_der_pn_block_matrices = T1_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_ppn_der_pn_block_matrices = T1_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T1_nnp_der_pn_block_matrices = T1_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);

  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppp_der_pn_block_matrices = T2_prime_ppp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnn_der_pn_block_matrices = T2_prime_nnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_ppn_der_pn_block_matrices = T2_prime_ppn_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_nnp_der_pn_block_matrices = T2_prime_nnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnp_der_pn_block_matrices = T2_prime_pnp_gradient.get_block_matrices (PROTONS_NEUTRONS);
  const class array<class block_sparse_matrix<TYPE> > &T2_prime_pnn_der_pn_block_matrices = T2_prime_pnn_gradient.get_block_matrices (PROTONS_NEUTRONS);
      	      
  const class RDM_PQG_class &P_pn = A_Gamma.get_P_dependent_term (PROTONS_NEUTRONS);
  
  const class array<unsigned int> &matrix_dimensions = P_pn.get_matrix_dimensions ();
  
  const int Jmax_total = matrix_dimensions.dimension (1) - 1;
  
  const unsigned int BPp_Jp_index_prime_dimension = BPp_Jp_index_prime_dimension_calc (matrix_dimensions);
    
  Hessian_diagonal_no_sigma_pn.zero ();
  
  if (BPp_Jp_index_prime_dimension > 0)
    {
      class array<unsigned int> BPp_indices(BPp_Jp_index_prime_dimension);
  
      class array<int> Jp_indices(BPp_Jp_index_prime_dimension);

      class array<unsigned int> index_prime_indices(BPp_Jp_index_prime_dimension);

      BPp_Jp_index_prime_arrays_calc (matrix_dimensions , BPp_indices , Jp_indices , index_prime_indices);
  
      const unsigned int first_BPp_Jp_index_prime_index = basic_first_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
      const unsigned int last_BPp_Jp_index_prime_index = basic_last_index_determine_for_MPI (BPp_Jp_index_prime_dimension , NUMBER_OF_PROCESSES , THIS_PROCESS);

      const bool is_process_active = is_process_active_for_MPI (BPp_Jp_index_prime_dimension , THIS_PROCESS);
	  	      
      if (is_process_active)
	{
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
	  for (unsigned int BPp_Jp_index_prime_index = first_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index <= last_BPp_Jp_index_prime_index ; BPp_Jp_index_prime_index++)
	    {
	      const unsigned int BPp = BPp_indices(BPp_Jp_index_prime_index);

	      const int Jp = Jp_indices(BPp_Jp_index_prime_index);
	  
	      const unsigned int index_prime = index_prime_indices(BPp_Jp_index_prime_index);

	      const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  	  
	      const unsigned int ip = row_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);
	
	      const unsigned int jp = column_index_from_upper_triangular_index_calc (dimension_BPp_Jp , index_prime);

	      const class block_sparse_matrix<TYPE> &Q_pp_der_pn_block_matrix = Q_pp_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_nn_der_pn_block_matrix = Q_nn_der_pn_block_matrices(BPp , Jp , index_prime);
	      const class block_sparse_matrix<TYPE> &Q_pn_der_pn_block_matrix = Q_pn_der_pn_block_matrices(BPp , Jp , index_prime);
	      		
	      class matrix<TYPE> &Hessian_diagonal_no_sigma_pn_BPp_Jp = Hessian_diagonal_no_sigma_pn(BPp + 2*Jp);
	
	      TYPE &Hessian_diagonal_no_sigma_pn_ME = Hessian_diagonal_no_sigma_pn_BPp_Jp(ip , jp);
	      
	      if (Q_pp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += Q_pp_der_pn_block_matrix.Frobenius_squared_norm ();
	      if (Q_nn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += Q_nn_der_pn_block_matrix.Frobenius_squared_norm ();
	      if (Q_pn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += Q_pn_der_pn_block_matrix.Frobenius_squared_norm ();
	  
	      if (is_there_G_constraint)
		{
		  const class block_sparse_matrix<TYPE> &G_pp_der_pn_block_matrix = G_pp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_nn_der_pn_block_matrix = G_nn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_pn_der_pn_block_matrix = G_pn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &G_np_der_pn_block_matrix = G_np_der_pn_block_matrices(BPp , Jp , index_prime);
	      
		  if (G_pp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += G_pp_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (G_nn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += G_nn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (G_pn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += G_pn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (G_np_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += G_np_der_pn_block_matrix.Frobenius_squared_norm ();
		}
	      
	      if (are_there_J_constraints)
		{
		  Hessian_diagonal_no_sigma_pn_ME += Frobenius_squared_norm_gradient (true , BPp , Jp , index_prime , J_constraints_pp_gradient);
		  Hessian_diagonal_no_sigma_pn_ME += Frobenius_squared_norm_gradient (true , BPp , Jp , index_prime , J_constraints_nn_gradient);
		}

	      if (is_there_T1_constraint)
		{
		  const class block_sparse_matrix<TYPE> &T1_ppp_der_pn_block_matrix = T1_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnn_der_pn_block_matrix = T1_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_ppn_der_pn_block_matrix = T1_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T1_nnp_der_pn_block_matrix = T1_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
	      
		  if (T1_ppp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T1_ppp_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T1_nnn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T1_nnn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T1_ppn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T1_ppn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T1_nnp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T1_nnp_der_pn_block_matrix.Frobenius_squared_norm ();
		}
				
	      if (is_there_T2_prime_constraint)
		{	      
		  const class block_sparse_matrix<TYPE> &T2_prime_ppp_der_pn_block_matrix = T2_prime_ppp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnn_der_pn_block_matrix = T2_prime_nnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_ppn_der_pn_block_matrix = T2_prime_ppn_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_nnp_der_pn_block_matrix = T2_prime_nnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnp_der_pn_block_matrix = T2_prime_pnp_der_pn_block_matrices(BPp , Jp , index_prime);
		  const class block_sparse_matrix<TYPE> &T2_prime_pnn_der_pn_block_matrix = T2_prime_pnn_der_pn_block_matrices(BPp , Jp , index_prime);
		  
		  if (T2_prime_ppp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_ppp_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_nnn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_nnn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_ppn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_ppn_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_nnp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_nnp_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_pnp_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_pnp_der_pn_block_matrix.Frobenius_squared_norm ();
		  if (T2_prime_pnn_der_pn_block_matrix.is_it_filled ()) Hessian_diagonal_no_sigma_pn_ME += T2_prime_pnn_der_pn_block_matrix.Frobenius_squared_norm ();
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized) Hessian_diagonal_no_sigma_pn.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif

  for (unsigned int BPp = 0 ; BPp <= 1 ; BPp++)  
    for (int Jp = 0 ; Jp <= Jmax_total ; Jp++)
      {	
	const unsigned int dimension_BPp_Jp = matrix_dimensions(BPp , Jp);
	  
	const unsigned int BPp_Jp_index = BPp + 2*Jp;
		
	const TYPE Delta_pn_pairs_number_dependent_term_part_der = 2*Jp + 1;
	    
	const TYPE Delta_pn_pairs_number_dependent_term_part_der_square = Delta_pn_pairs_number_dependent_term_part_der*Delta_pn_pairs_number_dependent_term_part_der;
	
	const class matrix<TYPE> &Delta_E_reference_der_pn_block_matrix_BPp_Jp = Delta_E_reference_der_pn_block_matrix(BPp_Jp_index);
	
	const class matrix<TYPE> &Delta_Hcm_der_pn_block_matrix_BPp_Jp = Delta_Hcm_der_pn_block_matrix(BPp_Jp_index);
	
	class matrix<TYPE> &Hessian_diagonal_no_sigma_pn_BPp_Jp = Hessian_diagonal_no_sigma_pn(BPp_Jp_index);
	
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    {
	      const bool is_there_average_T2_der_pn_ME = (ba_from_ab_pn_indices(BPp , Jp , ip) == jp);
	      
	      const TYPE Delta_E_reference_dependent_term_part = (is_there_E_reference) ? (Delta_E_reference_der_pn_block_matrix_BPp_Jp(ip , jp)) : (NADA);
	    
	      const TYPE Delta_Hcm_dependent_term_part = (is_there_CM_correction) ? (Delta_Hcm_der_pn_block_matrix_BPp_Jp(ip , jp)) : (NADA);
	      
	      const TYPE average_T2_dependent_term_part = (is_there_average_T2_der_pn_ME) ? (average_T2_der_pn_tab(BPp , Jp , ip)) : (NADA);
			      	      
	      TYPE &Hessian_diagonal_no_sigma_pn_ME = Hessian_diagonal_no_sigma_pn_BPp_Jp(ip , jp);
		
	      Hessian_diagonal_no_sigma_pn_ME += 4.0;
	      
	      if (is_there_E_reference) Hessian_diagonal_no_sigma_pn_ME += Delta_E_reference_dependent_term_part*Delta_E_reference_dependent_term_part;
	    
	      if (is_there_CM_correction) Hessian_diagonal_no_sigma_pn_ME += Delta_Hcm_dependent_term_part*Delta_Hcm_dependent_term_part;
	      
	      if (is_there_average_T2_der_pn_ME) Hessian_diagonal_no_sigma_pn_ME += average_T2_dependent_term_part*average_T2_dependent_term_part;
	    }
	    
	for (unsigned int ip = 0 ; ip < dimension_BPp_Jp ; ip++)
	  {	    	    
	    const bool is_there_average_T2_der_pn_ME = (ba_from_ab_pn_indices(BPp , Jp , ip) == ip);
	      
	    const TYPE Delta_J_dependent_term_part = Delta_J_der_pn_tab(BPp , Jp , ip);
	    	    	    
	    const TYPE Delta_E_reference_dependent_term_part = (is_there_E_reference) ? (Delta_E_reference_der_pn_block_matrix_BPp_Jp(ip , ip)) : (NADA);
	    
	    const TYPE Delta_Hcm_dependent_term_part = (is_there_CM_correction) ? (Delta_Hcm_der_pn_block_matrix_BPp_Jp(ip , ip)) : (NADA);
		
	    const TYPE average_T2_dependent_term_part = (is_there_average_T2_der_pn_ME) ? (average_T2_der_pn_tab(BPp , Jp , ip)) : (NADA);
	      	    
	    TYPE &Hessian_diagonal_no_sigma_pn_ME = Hessian_diagonal_no_sigma_pn_BPp_Jp(ip , ip);
	    
	    Hessian_diagonal_no_sigma_pn_ME += 1.0;
	    
	    Hessian_diagonal_no_sigma_pn_ME += Delta_pn_pairs_number_dependent_term_part_der_square;
	
	    Hessian_diagonal_no_sigma_pn_ME += Delta_J_dependent_term_part*Delta_J_dependent_term_part;
	    	    
	    if (is_there_E_reference) Hessian_diagonal_no_sigma_pn_ME += Delta_E_reference_dependent_term_part*Delta_E_reference_dependent_term_part;
	    
	    if (is_there_CM_correction) Hessian_diagonal_no_sigma_pn_ME += Delta_Hcm_dependent_term_part*Delta_Hcm_dependent_term_part;
	    
	    if (is_there_average_T2_der_pn_ME) Hessian_diagonal_no_sigma_pn_ME += average_T2_dependent_term_part*average_T2_dependent_term_part;
	  }
	  
	for (unsigned int jp = 0 ; jp < dimension_BPp_Jp ; jp++)
	  for (unsigned int ip = 0 ; ip < jp ; ip++)
	    Hessian_diagonal_no_sigma_pn_BPp_Jp(jp , ip) = Hessian_diagonal_no_sigma_pn_BPp_Jp(ip , jp);
      }
}






void RDM_Hessian_diagonal_no_sigma::Hessian_diagonal_no_sigma_pp_nn_pn_calc (
									     const class RDM_conditions_class &A_Gamma ,
									     const class RDM_conditions_gradient_class &A_Gamma_gradients  , 				 
									     class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pp ,
									     class block_matrix<TYPE> &Hessian_diagonal_no_sigma_nn ,
									     class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pn ,				 
									     class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_pp ,
									     class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_nn)
{
  Hessian_diagonal_no_sigma_pp_nn_part_calc (PROTON  , A_Gamma , A_Gamma_gradients , Hessian_diagonal_no_sigma_pp , Hessian_diagonal_rho_no_sigma_pp);
  Hessian_diagonal_no_sigma_pp_nn_part_calc (NEUTRON , A_Gamma , A_Gamma_gradients , Hessian_diagonal_no_sigma_nn , Hessian_diagonal_rho_no_sigma_nn);
        
  Hessian_diagonal_no_sigma_pn_part_calc (A_Gamma , A_Gamma_gradients , Hessian_diagonal_no_sigma_pn);
}
