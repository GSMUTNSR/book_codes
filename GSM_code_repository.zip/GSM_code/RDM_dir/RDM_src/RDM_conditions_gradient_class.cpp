#include "../RDM_include/RDM_include_def.h"

using namespace RDM_rho_observables_gradient;

RDM_conditions_gradient_class::RDM_conditions_gradient_class () {}

RDM_conditions_gradient_class::RDM_conditions_gradient_class (
							      const enum interaction_type inter ,
							      const class TBMEs_class &TBMEs_pn ,
							      const class nucleons_data &prot_data ,
							      const class nucleons_data &neut_data ,
							      const class RDM_conditions_class &RDM_conditions)
{
  alloc_calc_store (inter , TBMEs_pn , prot_data , neut_data , RDM_conditions);
}

RDM_conditions_gradient_class::RDM_conditions_gradient_class (const class RDM_conditions_gradient_class &X)
{
  allocate_fill (X);
}

void RDM_conditions_gradient_class::allocate_fill (const class RDM_conditions_gradient_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_conditions_gradient_class::allocate_fill");
  
  rho_prot_der_pp_tab.allocate_fill (X.rho_prot_der_pp_tab);
  rho_prot_der_pn_tab.allocate_fill (X.rho_prot_der_pn_tab);
  
  rho_neut_der_nn_tab.allocate_fill (X.rho_neut_der_nn_tab);
  rho_neut_der_pn_tab.allocate_fill (X.rho_neut_der_pn_tab);
      
  Delta_J_der_pp_tab.allocate_fill (X.Delta_J_der_pp_tab);
  Delta_J_der_nn_tab.allocate_fill (X.Delta_J_der_nn_tab);
  Delta_J_der_pn_tab.allocate_fill (X.Delta_J_der_pn_tab);
    
  ba_from_ab_pn_indices.allocate_fill (X.ba_from_ab_pn_indices);

  average_T2_der_pn_tab.allocate_fill (X.average_T2_der_pn_tab);
  
  Delta_E_reference_der_pp_block_matrix.allocate_fill (X.Delta_E_reference_der_pp_block_matrix);
  Delta_E_reference_der_nn_block_matrix.allocate_fill (X.Delta_E_reference_der_nn_block_matrix);
  Delta_E_reference_der_pn_block_matrix.allocate_fill (X.Delta_E_reference_der_pn_block_matrix);
    
  Delta_Hcm_der_pp_block_matrix.allocate_fill (X.Delta_Hcm_der_pp_block_matrix);
  Delta_Hcm_der_nn_block_matrix.allocate_fill (X.Delta_Hcm_der_nn_block_matrix);
  Delta_Hcm_der_pn_block_matrix.allocate_fill (X.Delta_Hcm_der_pn_block_matrix);
    
  Q_pp_gradient.allocate_fill (X.Q_pp_gradient);
  Q_nn_gradient.allocate_fill (X.Q_nn_gradient);
  Q_pn_gradient.allocate_fill (X.Q_pn_gradient);
  
  G_pp_gradient.allocate_fill (X.G_pp_gradient);
  G_nn_gradient.allocate_fill (X.G_nn_gradient);
  G_pn_gradient.allocate_fill (X.G_pn_gradient);
  G_np_gradient.allocate_fill (X.G_np_gradient);
  
  J_constraints_pp_gradient.allocate_fill (X.J_constraints_pp_gradient);
  J_constraints_nn_gradient.allocate_fill (X.J_constraints_nn_gradient);
  
  T1_ppp_gradient.allocate_fill (X.T1_ppp_gradient);
  T1_nnn_gradient.allocate_fill (X.T1_nnn_gradient);
  T1_ppn_gradient.allocate_fill (X.T1_ppn_gradient);
  T1_nnp_gradient.allocate_fill (X.T1_nnp_gradient);
  
  T2_prime_ppp_gradient.allocate_fill (X.T2_prime_ppp_gradient);
  T2_prime_nnn_gradient.allocate_fill (X.T2_prime_nnn_gradient);
  T2_prime_ppn_gradient.allocate_fill (X.T2_prime_ppn_gradient);
  T2_prime_nnp_gradient.allocate_fill (X.T2_prime_nnp_gradient); 
  T2_prime_pnp_gradient.allocate_fill (X.T2_prime_pnp_gradient); 
  T2_prime_pnn_gradient.allocate_fill (X.T2_prime_pnn_gradient); 
}

void RDM_conditions_gradient_class::operator = (const class RDM_conditions_gradient_class &X)
{
  rho_prot_der_pp_tab = X.rho_prot_der_pp_tab;
  rho_prot_der_pn_tab = X.rho_prot_der_pn_tab;
  
  rho_neut_der_nn_tab = X.rho_neut_der_nn_tab;
  rho_neut_der_pn_tab = X.rho_neut_der_pn_tab;
      
  Delta_J_der_pp_tab = X.Delta_J_der_pp_tab;
  Delta_J_der_nn_tab = X.Delta_J_der_nn_tab;
  Delta_J_der_pn_tab = X.Delta_J_der_pn_tab;
    
  ba_from_ab_pn_indices = X.ba_from_ab_pn_indices;

  average_T2_der_pn_tab = X.average_T2_der_pn_tab;
  
  Delta_E_reference_der_pp_block_matrix = X.Delta_E_reference_der_pp_block_matrix;
  Delta_E_reference_der_nn_block_matrix = X.Delta_E_reference_der_nn_block_matrix;
  Delta_E_reference_der_pn_block_matrix = X.Delta_E_reference_der_pn_block_matrix;
  
  Delta_Hcm_der_pp_block_matrix = X.Delta_Hcm_der_pp_block_matrix;
  Delta_Hcm_der_nn_block_matrix = X.Delta_Hcm_der_nn_block_matrix;
  Delta_Hcm_der_pn_block_matrix = X.Delta_Hcm_der_pn_block_matrix;
    
  Q_pp_gradient = X.Q_pp_gradient;
  Q_nn_gradient = X.Q_nn_gradient;
  Q_pn_gradient = X.Q_pn_gradient;
  
  G_pp_gradient = X.G_pp_gradient;
  G_nn_gradient = X.G_nn_gradient;
  G_pn_gradient = X.G_pn_gradient;
  G_np_gradient = X.G_np_gradient;
  
  J_constraints_pp_gradient = X.J_constraints_pp_gradient;
  J_constraints_nn_gradient = X.J_constraints_nn_gradient;
  
  T1_ppp_gradient = X.T1_ppp_gradient;
  T1_nnn_gradient = X.T1_nnn_gradient;
  T1_ppn_gradient = X.T1_ppn_gradient;
  T1_nnp_gradient = X.T1_nnp_gradient;
  
  T2_prime_ppp_gradient = X.T2_prime_ppp_gradient;
  T2_prime_nnn_gradient = X.T2_prime_nnn_gradient;
  T2_prime_ppn_gradient = X.T2_prime_ppn_gradient;
  T2_prime_nnp_gradient = X.T2_prime_nnp_gradient; 
  T2_prime_pnp_gradient = X.T2_prime_pnp_gradient; 
  T2_prime_pnn_gradient = X.T2_prime_pnn_gradient; 
}

void RDM_conditions_gradient_class::deallocate ()
{
  rho_prot_der_pp_tab.deallocate ();
  rho_prot_der_pn_tab.deallocate ();
  
  rho_neut_der_nn_tab.deallocate ();
  rho_neut_der_pn_tab.deallocate ();
      
  Delta_J_der_pp_tab.deallocate ();
  Delta_J_der_nn_tab.deallocate ();
  Delta_J_der_pn_tab.deallocate ();
  
  ba_from_ab_pn_indices.deallocate ();
  
  average_T2_der_pn_tab.deallocate ();
  
  Delta_E_reference_der_pp_block_matrix.deallocate ();
  Delta_E_reference_der_nn_block_matrix.deallocate ();
  Delta_E_reference_der_pn_block_matrix.deallocate ();
  
  Delta_Hcm_der_pp_block_matrix.deallocate ();
  Delta_Hcm_der_nn_block_matrix.deallocate ();
  Delta_Hcm_der_pn_block_matrix.deallocate ();
    
  Q_pp_gradient.deallocate ();
  Q_nn_gradient.deallocate ();
  Q_pn_gradient.deallocate ();
  
  G_pp_gradient.deallocate ();
  G_nn_gradient.deallocate ();
  G_pn_gradient.deallocate ();
  G_np_gradient.deallocate ();
  
  J_constraints_pp_gradient.deallocate ();
  J_constraints_nn_gradient.deallocate ();
  
  T1_ppp_gradient.deallocate ();
  T1_nnn_gradient.deallocate ();
  T1_ppn_gradient.deallocate ();
  T1_nnp_gradient.deallocate ();
  
  T2_prime_ppp_gradient.deallocate ();
  T2_prime_nnn_gradient.deallocate ();
  T2_prime_ppn_gradient.deallocate ();
  T2_prime_nnp_gradient.deallocate ();
  T2_prime_pnp_gradient.deallocate ();
  T2_prime_pnn_gradient.deallocate ();
}



void RDM_conditions_gradient_class::alloc_calc_store (
						      const enum interaction_type inter ,
						      const class TBMEs_class &TBMEs_pn ,
						      const class nucleons_data &prot_data ,
						      const class nucleons_data &neut_data ,
						      const class RDM_conditions_class &RDM_conditions)
{	
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_conditions_gradient_class::alloc_calc_store");
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Zval + Nval;

  const enum RDM_matrix_constraint_type RDM_matrix_constraint = RDM_conditions.get_RDM_matrix_constraint ();
  
  const bool is_there_CM_correction = RDM_conditions.get_is_there_CM_correction ();
  
  const bool are_there_J_constraints = RDM_conditions.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = RDM_conditions.get_is_there_E_reference ();
  
  const class RDM_PQG_class &P_pp = RDM_conditions.get_P_dependent_term (PROTONS_ONLY);
  const class RDM_PQG_class &P_nn = RDM_conditions.get_P_dependent_term (NEUTRONS_ONLY);
  const class RDM_PQG_class &P_pn = RDM_conditions.get_P_dependent_term (PROTONS_NEUTRONS);
  
  const class RDM_PQG_class &Q_pp = RDM_conditions.get_Q_dependent_term (PROTONS_ONLY);
  const class RDM_PQG_class &Q_nn = RDM_conditions.get_Q_dependent_term (NEUTRONS_ONLY);
  const class RDM_PQG_class &Q_pn = RDM_conditions.get_Q_dependent_term (PROTONS_NEUTRONS);
  
  const class RDM_PQG_class &G_pp = RDM_conditions.get_G_dependent_term (PROTONS_ONLY      , PROTON);
  const class RDM_PQG_class &G_nn = RDM_conditions.get_G_dependent_term (NEUTRONS_ONLY     , NEUTRON);
  const class RDM_PQG_class &G_pn = RDM_conditions.get_G_dependent_term (PROTONS_NEUTRONS  , NEUTRON);
  const class RDM_PQG_class &G_np = RDM_conditions.get_G_dependent_term (PROTONS_NEUTRONS  , PROTON);
				  		      
  const class array<unsigned int> &matrix_dimensions_pp = P_pp.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_nn = P_nn.get_matrix_dimensions ();
  const class array<unsigned int> &matrix_dimensions_pn = P_pn.get_matrix_dimensions ();

  const int Jmax_pp_total_plus_one = matrix_dimensions_pp.dimension (1);
  const int Jmax_nn_total_plus_one = matrix_dimensions_nn.dimension (1);
  const int Jmax_pn_total_plus_one = matrix_dimensions_pn.dimension (1);

  const unsigned int matrix_dimension_max_pp = matrix_dimensions_pp.max ();
  const unsigned int matrix_dimension_max_nn = matrix_dimensions_nn.max ();
  const unsigned int matrix_dimension_max_pn = matrix_dimensions_pn.max ();
  
  const bool is_there_G_constraint = is_there_G_constraint_determine (RDM_matrix_constraint);
  
  const bool is_there_T1_constraint = is_there_T1_constraint_determine (RDM_matrix_constraint);
  
  const bool is_there_T2_prime_constraint = is_there_T2_prime_constraint_determine (RDM_matrix_constraint);
  
  rho_prot_der_pp_tab.allocate (Jmax_pp_total_plus_one , Np_nlj , Np_nlj , Np_nlj);
  rho_prot_der_pn_tab.allocate (Jmax_pn_total_plus_one , Np_nlj , Nn_nlj , Np_nlj);
  
  rho_neut_der_nn_tab.allocate (Jmax_nn_total_plus_one , Nn_nlj , Nn_nlj , Nn_nlj);
  rho_neut_der_pn_tab.allocate (Jmax_pn_total_plus_one , Nn_nlj , Np_nlj , Nn_nlj);
      
  Delta_J_der_pp_tab.allocate (2 , Jmax_pp_total_plus_one , matrix_dimension_max_pp);
  Delta_J_der_nn_tab.allocate (2 , Jmax_nn_total_plus_one , matrix_dimension_max_nn);
  Delta_J_der_pn_tab.allocate (2 , Jmax_pn_total_plus_one , matrix_dimension_max_pn);
  
  ba_from_ab_pn_indices.allocate (2 , Jmax_pn_total_plus_one , matrix_dimension_max_pn);
  
  average_T2_der_pn_tab.allocate (2 , Jmax_pn_total_plus_one , matrix_dimension_max_pn);
    
  const int two_Jmax_pp_total_plus_one = 2*Jmax_pp_total_plus_one;
  const int two_Jmax_nn_total_plus_one = 2*Jmax_nn_total_plus_one;
  const int two_Jmax_pn_total_plus_one = 2*Jmax_pn_total_plus_one;
  
  class array<unsigned int> block_matrix_dimensions_pp(two_Jmax_pp_total_plus_one);
  class array<unsigned int> block_matrix_dimensions_nn(two_Jmax_nn_total_plus_one);
  class array<unsigned int> block_matrix_dimensions_pn(two_Jmax_pn_total_plus_one);

  class array<unsigned int> block_matrix_zero_dimensions_pp(two_Jmax_pp_total_plus_one);
  class array<unsigned int> block_matrix_zero_dimensions_nn(two_Jmax_nn_total_plus_one);
  class array<unsigned int> block_matrix_zero_dimensions_pn(two_Jmax_pn_total_plus_one);
      
  block_matrix_zero_dimensions_pp = 0;
  block_matrix_zero_dimensions_nn = 0;
  block_matrix_zero_dimensions_pn = 0;
  
  for (unsigned int BP = 0 ; BP <= 1 ; BP++)
    {
      for (int J = 0 ; J < Jmax_pp_total_plus_one ; J++) block_matrix_dimensions_pp(BP + 2*J) = matrix_dimensions_pp(BP , J);
      for (int J = 0 ; J < Jmax_nn_total_plus_one ; J++) block_matrix_dimensions_nn(BP + 2*J) = matrix_dimensions_nn(BP , J);
      for (int J = 0 ; J < Jmax_pn_total_plus_one ; J++) block_matrix_dimensions_pn(BP + 2*J) = matrix_dimensions_pn(BP , J);
    }

  if (is_there_E_reference)
    {
      Delta_E_reference_der_pp_block_matrix.allocate (block_matrix_dimensions_pp);
      Delta_E_reference_der_nn_block_matrix.allocate (block_matrix_dimensions_nn);
      Delta_E_reference_der_pn_block_matrix.allocate (block_matrix_dimensions_pn);
    }
  else
    {    
      Delta_E_reference_der_pp_block_matrix.allocate (block_matrix_zero_dimensions_pp);
      Delta_E_reference_der_nn_block_matrix.allocate (block_matrix_zero_dimensions_nn);
      Delta_E_reference_der_pn_block_matrix.allocate (block_matrix_zero_dimensions_pn);
    }
  
  rho_der_pp_nn_tabs_calc (Aval , prot_data , rho_prot_der_pp_tab);
  rho_der_pp_nn_tabs_calc (Aval , neut_data , rho_neut_der_nn_tab);
  
  Delta_J_der_pp_nn_tabs_calc (Aval , prot_data , P_pp , rho_prot_der_pp_tab , Delta_J_der_pp_tab);
  Delta_J_der_pp_nn_tabs_calc (Aval , neut_data , P_nn , rho_neut_der_nn_tab , Delta_J_der_nn_tab);

  rho_prot_der_pn_tab_calc (prot_data , neut_data , rho_prot_der_pn_tab);
  rho_neut_der_pn_tab_calc (prot_data , neut_data , rho_neut_der_pn_tab);
  
  Delta_J_der_pn_tab_calc (prot_data , neut_data , P_pn , rho_prot_der_pn_tab , rho_neut_der_pn_tab , Delta_J_der_pn_tab);

  average_T2_der_pn_tab_calc (prot_data , neut_data , P_pn , ba_from_ab_pn_indices , average_T2_der_pn_tab);

  if (is_there_E_reference) average_E_der_tabs_calc (true , inter , 1.0 , prot_data , neut_data , TBMEs_pn , P_pp , P_nn , P_pn , *this , Delta_E_reference_der_pp_block_matrix , Delta_E_reference_der_nn_block_matrix , Delta_E_reference_der_pn_block_matrix);
  
  if (is_there_CM_correction)
    {
      Delta_Hcm_der_pp_block_matrix.allocate (block_matrix_dimensions_pp);
      Delta_Hcm_der_nn_block_matrix.allocate (block_matrix_dimensions_nn);
      Delta_Hcm_der_pn_block_matrix.allocate (block_matrix_dimensions_pn);
  
      Delta_Hcm_der_tabs_calc (prot_data , neut_data , P_pp , P_nn , P_pn , *this , Delta_Hcm_der_pp_block_matrix , Delta_Hcm_der_nn_block_matrix , Delta_Hcm_der_pn_block_matrix);
    }
  else
    {   
      Delta_Hcm_der_pp_block_matrix.allocate (block_matrix_zero_dimensions_pp);
      Delta_Hcm_der_nn_block_matrix.allocate (block_matrix_zero_dimensions_nn);
      Delta_Hcm_der_pn_block_matrix.allocate (block_matrix_zero_dimensions_pn);
    }
  
  const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G = RDM_conditions.get_Wigner_6j_hats_G ();
  
  if (are_there_J_constraints)
    {
      const double J = RDM_conditions.get_J ();
      
      J_constraints_pp_gradient.alloc_calc_store (PROTON  , J , prot_data , neut_data , rho_prot_der_pp_tab , rho_prot_der_pn_tab , P_pp , P_pn , Wigner_6j_hats_G);
      J_constraints_nn_gradient.alloc_calc_store (NEUTRON , J , prot_data , neut_data , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_nn , P_pn , Wigner_6j_hats_G);
    }
      
  Q_pp_gradient.alloc_calc_store (PROTONS_ONLY     , PROTON  , prot_data , neut_data , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , Q_pp , P_pp , P_nn , P_pn);
  Q_nn_gradient.alloc_calc_store (NEUTRONS_ONLY    , NEUTRON , prot_data , neut_data , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , Q_nn , P_pp , P_nn , P_pn);
  Q_pn_gradient.alloc_calc_store (PROTONS_NEUTRONS , NEUTRON , prot_data , neut_data , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , Q_pn , P_pp , P_nn , P_pn);

  if (is_there_G_constraint)
    {
      G_pp_gradient.alloc_calc_store (PROTONS_ONLY     , PROTON  , prot_data , neut_data , Wigner_6j_hats_G , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , G_pp , P_pp , P_nn , P_pn);
      G_nn_gradient.alloc_calc_store (NEUTRONS_ONLY    , NEUTRON , prot_data , neut_data , Wigner_6j_hats_G , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , G_nn , P_pp , P_nn , P_pn);
      G_pn_gradient.alloc_calc_store (PROTONS_NEUTRONS , NEUTRON , prot_data , neut_data , Wigner_6j_hats_G , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , G_pn , P_pp , P_nn , P_pn);
      G_np_gradient.alloc_calc_store (PROTONS_NEUTRONS , PROTON  , prot_data , neut_data , Wigner_6j_hats_G , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , G_np , P_pp , P_nn , P_pn);
    }
  
  if (is_there_T1_constraint)
    {
      const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 = RDM_conditions.get_Wigner_6j_hats_T1 ();

      const class RDM_T1_class &T1_ppp = RDM_conditions.get_T1_dependent_term (PROTONS_ONLY  , PROTON);
      const class RDM_T1_class &T1_nnn = RDM_conditions.get_T1_dependent_term (NEUTRONS_ONLY , NEUTRON);
      const class RDM_T1_class &T1_ppn = RDM_conditions.get_T1_dependent_term (PROTONS_ONLY  , NEUTRON);
      const class RDM_T1_class &T1_nnp = RDM_conditions.get_T1_dependent_term (NEUTRONS_ONLY , PROTON);

      T1_ppp_gradient.alloc_calc_store (T1_ppp , prot_data , neut_data , Wigner_6j_hats_T1 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
      T1_nnn_gradient.alloc_calc_store (T1_nnn , prot_data , neut_data , Wigner_6j_hats_T1 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
      T1_ppn_gradient.alloc_calc_store (T1_ppn , prot_data , neut_data , Wigner_6j_hats_T1 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
      T1_nnp_gradient.alloc_calc_store (T1_nnp , prot_data , neut_data , Wigner_6j_hats_T1 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
    }
  
  if (is_there_T2_prime_constraint)
    {
      const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 = RDM_conditions.get_Wigner_9j_hats_T2 ();
  
      const class RDM_T2_prime_class &T2_prime_ppp = RDM_conditions.get_T2_prime_dependent_term (PROTONS_ONLY     , PROTON);
      const class RDM_T2_prime_class &T2_prime_nnn = RDM_conditions.get_T2_prime_dependent_term (NEUTRONS_ONLY    , NEUTRON);
      const class RDM_T2_prime_class &T2_prime_ppn = RDM_conditions.get_T2_prime_dependent_term (PROTONS_ONLY     , NEUTRON);
      const class RDM_T2_prime_class &T2_prime_nnp = RDM_conditions.get_T2_prime_dependent_term (NEUTRONS_ONLY    , PROTON);  
      const class RDM_T2_prime_class &T2_prime_pnp = RDM_conditions.get_T2_prime_dependent_term (PROTONS_NEUTRONS , PROTON);
      const class RDM_T2_prime_class &T2_prime_pnn = RDM_conditions.get_T2_prime_dependent_term (PROTONS_NEUTRONS , NEUTRON);
    
      T2_prime_ppp_gradient.alloc_calc_store (T2_prime_ppp , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
      T2_prime_nnn_gradient.alloc_calc_store (T2_prime_nnn , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
      T2_prime_ppn_gradient.alloc_calc_store (T2_prime_ppn , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn); 
      T2_prime_nnp_gradient.alloc_calc_store (T2_prime_nnp , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn); 
      T2_prime_pnp_gradient.alloc_calc_store (T2_prime_pnp , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn); 
      T2_prime_pnn_gradient.alloc_calc_store (T2_prime_pnn , prot_data , neut_data , Wigner_9j_hats_T2 , rho_prot_der_pp_tab , rho_prot_der_pn_tab , rho_neut_der_nn_tab , rho_neut_der_pn_tab , P_pp , P_nn , P_pn);
    }
}
