#include "../RDM_include/RDM_include_def.h"

// MPI transfer is sometimes done here even if is_it_parallelized is false as disk access cannot be done by many processes at the same time

using namespace string_routines;
using namespace correlation_density_TBMEs;
using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace correlated_state_routines;
using namespace inputs_misc;





void RDM_correlation_density::correlation_density_pp_nn_calc (
							      const bool is_it_HO_expansion , 
							      const class interaction_class &inter_data , 
							      const class array<TYPE> &rk_OBMEs ,
							      const class multipolar_expansion_str &multipolar_expansion ,
							      const class Psigma_str &Psigma ,
							      const class array<double> theta12_Dirac_multipolar_tab ,
							      const class nucleons_data &particles_data ,
							      const class RDM_PQG_class &Gamma , 
							      class array<TYPE> &angular_densities_tab , 
							      class array<TYPE> &density_tab)
{
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return;
  
  const unsigned int N_RKmax = density_tab.dimension (0);
  
  const unsigned int theta_number = density_tab.dimension (1);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
      
  const class block_matrix<TYPE> &Gamma_block_matrix = Gamma.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma.get_two_states_indices ();
      
  class array<TYPE> angular_densities_TBMEs_two_J_plus_one_Gamma_ME(2 , theta_number);

  class array<TYPE> density_TBMEs_two_J_plus_one_Gamma_ME(N_RKmax , theta_number);
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair_ab(sa , sb);
      	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (shells_qn , shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
	      
	const bool are_sa_sb_equal = (sa == sb);
	
	for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	  for (unsigned int sc = 0 ; sc <= sd ; sc++)
	    {
	      const class pair_str pair_cd(sc , sd);
      	
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (shells_qn , shells_qn);

	      if (are_there_frozen_states_cd) continue;
	      
	      const unsigned int BP_cd = pair_cd.bp_determine (shells_qn , shells_qn);
				
	      if (BP_ab != BP_cd) continue;

	      const unsigned int BP = BP_ab;
		
	      const int Jmin_cd = pair_cd.Jmin_determine (shells_qn , shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (shells_qn , shells_qn);

	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
	      	
	      const bool are_sc_sd_equal = (sc == sd);
	
	      const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);
	      
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const bool is_J_even = (J%2 == 0);

		  if (is_J_even || ab_different_cd_different)
		    {
		      const class matrix<TYPE> &Gamma_matrix = Gamma_block_matrix(BP + 2*J);
	
		      const unsigned int ab_index = two_states_indices(J , sa , sb);
		      const unsigned int cd_index = two_states_indices(J , sc , sd);
		  
		      const TYPE Gamma_ME = Gamma_matrix(ab_index , cd_index);

		      const TYPE two_J_plus_one_Gamma_ME = (2*J + 1)*Gamma_ME;
		  
		      correlation_density_TBMEs::coupled_TBMEs_pp_nn_calc (is_it_HO_expansion , J , inter_data , particles_data , rk_OBMEs , pair_ab , pair_cd ,
									   theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma , angular_densities_TBMEs_two_J_plus_one_Gamma_ME , density_TBMEs_two_J_plus_one_Gamma_ME);
		  
		      angular_densities_TBMEs_two_J_plus_one_Gamma_ME *= two_J_plus_one_Gamma_ME;
		  
		      density_TBMEs_two_J_plus_one_Gamma_ME *= two_J_plus_one_Gamma_ME;
   
		      angular_densities_tab += angular_densities_TBMEs_two_J_plus_one_Gamma_ME;
		  
		      density_tab += density_TBMEs_two_J_plus_one_Gamma_ME;
		    }	
		}
	    }
      }
}



















void RDM_correlation_density::correlation_density_pn_calc (
							   const bool is_it_HO_expansion , 
							   const class interaction_class &inter_data ,
							   const class array<TYPE> &rk_OBMEs_prot ,
							   const class array<TYPE> &rk_OBMEs_neut ,
							   const class multipolar_expansion_str &multipolar_expansion ,
							   const class Psigma_str &Psigma ,
							   const class array<double> theta12_Dirac_multipolar_tab , 
							   const class nucleons_data &prot_data ,
							   const class nucleons_data &neut_data , 
							   const class RDM_PQG_class &Gamma_pn , 
							   class array<TYPE> &angular_densities_tab , 
							   class array<TYPE> &density_tab)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return;
            
  const unsigned int N_RKmax = density_tab.dimension (0);
  
  const unsigned int theta_number = density_tab.dimension (1);
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  class array<TYPE> angular_densities_TBMEs_two_J_plus_one_Gamma_ME(2 , theta_number);

  class array<TYPE> density_TBMEs_two_J_plus_one_Gamma_ME(N_RKmax , theta_number);

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
      
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	    
	const class pair_str pair_in(sa_p , sb_n);
	
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	    {
	      const class pair_str pair_cd(sc_p , sd_n);
      
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	      if (are_there_frozen_states_cd) continue;
	      
	      const unsigned int BP_cd = pair_cd.bp_determine (prot_shells_qn , neut_shells_qn);		
		
	      if (BP_ab != BP_cd) continue;

	      const unsigned int BP = BP_ab;
	
	      const int Jmin_cd = pair_cd.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (prot_shells_qn , neut_shells_qn);

	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
	      
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP  + 2*J);
	
		  const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);	
		  const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
	
		  const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , cd_index);
		  
		  const TYPE two_J_plus_one_Gamma_ME = (2*J + 1)*Gamma_ME;
		  
		  correlation_density_TBMEs::coupled_TBMEs_pn_calc (is_it_HO_expansion , J , inter_data , prot_data , neut_data , rk_OBMEs_prot , rk_OBMEs_neut , pair_ab , pair_cd ,
								    theta12_Dirac_multipolar_tab , multipolar_expansion , Psigma , angular_densities_TBMEs_two_J_plus_one_Gamma_ME , density_TBMEs_two_J_plus_one_Gamma_ME);
		  
		  angular_densities_TBMEs_two_J_plus_one_Gamma_ME *= two_J_plus_one_Gamma_ME;
		  
		  density_TBMEs_two_J_plus_one_Gamma_ME *= two_J_plus_one_Gamma_ME;
   
		  angular_densities_tab += angular_densities_TBMEs_two_J_plus_one_Gamma_ME;
		  
		  density_tab += density_TBMEs_two_J_plus_one_Gamma_ME;
		}      
	    }
      }
}








void RDM_correlation_density::correlation_density_calc ( 
							const bool is_it_radial ,
							const bool is_it_Gauss_Legendre , 
							const bool is_it_HO_expansion ,
							const class interaction_class &inter_data ,
							const class nucleons_data &prot_data ,
							const class nucleons_data &neut_data , 
							const class RDM_PQG_class &Gamma_pp ,
							const class RDM_PQG_class &Gamma_nn ,
							const class RDM_PQG_class &Gamma_pn , 
							const class array<double> &theta_tab ,
							class array<TYPE> &angular_densities_pp_tab , 
							class array<TYPE> &angular_densities_nn_tab , 
							class array<TYPE> &angular_densities_pn_tab , 
							class array<TYPE> &density_pp_tab , 
							class array<TYPE> &density_nn_tab , 
							class array<TYPE> &density_pn_tab)
{     
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const unsigned int N_RKmax = density_pp_tab.dimension (0);
  
  const unsigned int theta_number = density_pp_tab.dimension (1);
  
  const int lp_max = prot_data.get_lmax ();
  const int ln_max = neut_data.get_lmax ();

  const int lmax = max (lp_max , ln_max);

  const int two_lmax = 2*lmax;
  
  const int two_lmax_plus_one = two_lmax + 1;
  
  const double j_max = lmax + 0.5;
  
  class array<TYPE> rk_OBMEs_prot(Np_nlj , Np_nlj , N_RKmax);
  class array<TYPE> rk_OBMEs_neut(Nn_nlj , Nn_nlj , N_RKmax);
  
  radial_OBMEs_calc (is_it_radial , is_it_Gauss_Legendre , prot_data , rk_OBMEs_prot);
  radial_OBMEs_calc (is_it_radial , is_it_Gauss_Legendre , neut_data , rk_OBMEs_neut);
  
  const class multipolar_expansion_str multipolar_expansion(j_max);

  const class Psigma_str Psigma(j_max);
  
  class array<double> theta12_Dirac_multipolar_tab(two_lmax_plus_one , theta_number);

  theta12_Dirac_multipolar_calc (theta_tab , theta12_Dirac_multipolar_tab);
  
  angular_densities_pp_tab = 0.0;
  angular_densities_nn_tab = 0.0;
  angular_densities_pn_tab = 0.0;

  density_pp_tab = 0.0;
  density_nn_tab = 0.0;
  density_pn_tab = 0.0;
  
  correlation_density_pp_nn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_prot , multipolar_expansion , Psigma , theta12_Dirac_multipolar_tab , prot_data , Gamma_pp , angular_densities_pp_tab , density_pp_tab);
  correlation_density_pp_nn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_neut , multipolar_expansion , Psigma , theta12_Dirac_multipolar_tab , neut_data , Gamma_nn , angular_densities_nn_tab , density_nn_tab);
  
  correlation_density_pn_calc (is_it_HO_expansion , inter_data , rk_OBMEs_prot , rk_OBMEs_neut , multipolar_expansion , Psigma , theta12_Dirac_multipolar_tab , prot_data , neut_data , Gamma_pn , angular_densities_pn_tab , density_pn_tab);
}













void RDM_correlation_density::calc_store_density (
						  const bool is_it_radial ,
						  const bool is_it_Gauss_Legendre , 
						  const bool is_it_HO_expansion , 
						  const class interaction_class &inter_data ,  
						  const class array<double> &rk_tab ,
						  const class array<double> &theta_tab ,
						  const class correlated_state_str &PSI_qn , 
						  const class RDM_PQG_class &Gamma_pp ,
						  const class RDM_PQG_class &Gamma_nn ,
						  const class RDM_PQG_class &Gamma_pn , 
						  const class nucleons_data &prot_data , 
						  const class nucleons_data &neut_data) 
{
  const unsigned int N_RKmax = rk_tab.dimension (0);

  const unsigned int theta_number = theta_tab.dimension (0);

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Zval + Nval;
  
  class array<TYPE> angular_densities_pp_tab(2 , theta_number);
  class array<TYPE> angular_densities_nn_tab(2 , theta_number);
  class array<TYPE> angular_densities_pn_tab(2 , theta_number);

  class array<TYPE> density_pp_tab(N_RKmax , theta_number);
  class array<TYPE> density_nn_tab(N_RKmax , theta_number);
  class array<TYPE> density_pn_tab(N_RKmax , theta_number);

  correlation_density_calc (is_it_radial , is_it_Gauss_Legendre , is_it_HO_expansion , inter_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn , theta_tab ,
			    angular_densities_pp_tab , angular_densities_nn_tab , angular_densities_pn_tab , density_pp_tab , density_nn_tab , density_pn_tab);
  
  const class array<TYPE> angular_densities_tab = angular_densities_pp_tab + angular_densities_nn_tab + angular_densities_pn_tab;

  const class array<TYPE> density_tab = density_pp_tab + density_nn_tab + density_pn_tab;
  
  if (THIS_PROCESS == MASTER_PROCESS)
    {  
      const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);

      if ((Zval >= 1) && (Nval >= 1) && (Aval >= 3))
        {
	  if (Zval >= 2) correlation_density_files_store (is_it_radial , PSI_qn_string , "pp" , rk_tab , theta_tab , angular_densities_pp_tab , density_pp_tab);
	  if (Nval >= 2) correlation_density_files_store (is_it_radial , PSI_qn_string , "nn" , rk_tab , theta_tab , angular_densities_nn_tab , density_nn_tab);
	  
	  if ((Zval >= 1) && (Nval >= 1)) correlation_density_files_store (is_it_radial , PSI_qn_string , "pn" , rk_tab , theta_tab , angular_densities_pn_tab , density_pn_tab);
	}

      correlation_density_files_store (is_it_radial , PSI_qn_string , "total" , rk_tab , theta_tab , angular_densities_tab , density_tab);
      
      class array<TYPE> angular_density_tab(theta_number);
        
      for (unsigned int it = 0 ; it < theta_number ; it++) angular_density_tab(it) = angular_densities_tab(0 , it) + angular_densities_tab(1 , it);
  
      const TYPE angular_density_norm_test = angular_density_norm_with_splines (theta_tab , angular_density_tab);
      
      cout << "Angular density norm (from splines) : " << angular_density_norm_test << endl;
    }
}







void RDM_correlation_density::calc_store (
					  const class input_data_str &input_data , 
					  const class interaction_class &inter_data , 
					  const class nucleons_data &prot_data , 
					  const class nucleons_data &neut_data ,
					  const class RDM_PQG_class &Gamma_pp ,
					  const class RDM_PQG_class &Gamma_nn ,
					  const class RDM_PQG_class &Gamma_pn)
{  
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Correlation densities" << endl;
      cout <<         "---------------------" << endl << endl;
    }

  const unsigned int RDM_BP = input_data.get_RDM_BP ();

  const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
  const double RDM_J = input_data.get_RDM_J ();
	  
  const int Z = prot_data.get_N_nucleons ();
  const int N = neut_data.get_N_nucleons ();
    
  const unsigned int theta_number = input_data.get_correlation_density_theta_number ();

  const bool is_correlation_density_theta_value_imposed = input_data.get_is_correlation_density_theta_value_imposed ();
  
  const double correlation_density_imposed_theta_value = input_data.get_correlation_density_imposed_theta_value ();
  
  const unsigned int correlation_density_number = input_data.get_correlation_density_number ();

  const class array<unsigned int> &correlation_density_BP_tab = input_data.get_correlation_density_BP_tab ();

  const class array<double> &correlation_density_J_tab = input_data.get_correlation_density_J_tab ();
  
  const class array<double> &correlation_density_RKmax_tab = input_data.get_correlation_density_RKmax_tab ();

  const class array<unsigned int> &correlation_density_vector_index_tab = input_data.get_correlation_density_vector_index_tab ();

  const class array<bool> &correlation_density_is_it_radial_tab = input_data.get_correlation_density_is_it_radial_tab ();
  
  const class array<bool> &correlation_density_is_it_Gauss_Legendre_tab = input_data.get_correlation_density_is_it_Gauss_Legendre_tab ();

  const class array<bool> &correlation_density_is_it_HO_expansion_tab = input_data.get_correlation_density_is_it_HO_expansion_tab ();

  const unsigned int N_bef_R_GL  = input_data.get_N_bef_R_GL ();
  const unsigned int N_bef_R_uniform = input_data.get_N_bef_R_uniform ();

  const unsigned int Nk_momentum_GL  = input_data.get_Nk_momentum_GL ();
  const unsigned int Nk_momentum_uniform = input_data.get_Nk_momentum_uniform ();

  const double R = input_data.get_R ();
  
  const double kmax_momentum = input_data.get_kmax_momentum ();

  const double step_bef_R_uniform = input_data.get_step_bef_R_uniform ();
  
  const double step_momentum_uniform = input_data.get_step_momentum_uniform ();

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> r_bef_R_tab_uniform(N_bef_R_uniform);
  
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  class array<double> k_tab_GL(Nk_momentum_GL);
  class array<double> wk_tab_GL(Nk_momentum_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);

  class array<double> k_tab_uniform(Nk_momentum_uniform);
  
  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;
  
  class array<double> theta_tab_GL(theta_number);
  class array<double> w_theta_tab_GL(theta_number);
  
  class array<double> theta_tab_uniform(theta_number);

  if (is_correlation_density_theta_value_imposed)
    {
      theta_tab_GL(0) = theta_tab_uniform(0) = correlation_density_imposed_theta_value;

      w_theta_tab_GL(0) = 1.0;
    }
  else
    {
      const double step_theta_uniform = M_PI/static_cast<double> (theta_number - 1);
  
      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , M_PI , theta_tab_GL , w_theta_tab_GL);
  
      for (unsigned int it = 0 ; it < theta_number ; it++) theta_tab_uniform(it) = it*step_theta_uniform;
    }
    
  for (unsigned int correlation_density_index = 0 ; correlation_density_index < correlation_density_number ; correlation_density_index++)
    {
      const unsigned int BP = correlation_density_BP_tab(correlation_density_index);

      if (BP != RDM_BP) error_message_print_abort ("BP must be equal to BP[RDM] in RDM_correlation_density::calc_store");
      
      const unsigned int vector_index = correlation_density_vector_index_tab(correlation_density_index);

      if (vector_index != RDM_vector_index) error_message_print_abort ("vector_index must be equal to vector_index[RDM] in RDM_correlation_density::calc_store");

      const double J = correlation_density_J_tab(correlation_density_index);
      
      if (rint (J - RDM_J) != 0) error_message_print_abort ("J must be equal to J[RDM] in RDM_correlation_density::calc_store");

      const double RKmax = correlation_density_RKmax_tab(correlation_density_index);

      const bool is_it_radial = correlation_density_is_it_radial_tab(correlation_density_index);
      
      const bool is_it_Gauss_Legendre = correlation_density_is_it_Gauss_Legendre_tab(correlation_density_index);

      const bool is_it_HO_expansion = correlation_density_is_it_HO_expansion_tab(correlation_density_index);
      
      const class array<double> &theta_tab = (is_it_Gauss_Legendre) ? (theta_tab_GL) : (theta_tab_uniform);
      
      const class array<double> &r_bef_R_tab = (is_it_Gauss_Legendre) ? (r_bef_R_tab_GL) : (r_bef_R_tab_uniform);

      const class array<double> &k_tab = (is_it_Gauss_Legendre) ? (k_tab_GL) : (k_tab_uniform);
      
      const class array<double> &rk_tab_init = (is_it_radial) ? (r_bef_R_tab) : (k_tab);

      const unsigned int iRK_closest = rk_tab_init.closest_value_index_determine (RKmax);
      
      const unsigned int N_RKmax = (rk_tab_init(iRK_closest) > RKmax) ? (iRK_closest) : (iRK_closest + 1);

      const string radial_momentum_str = (is_it_radial) ? ("Radial") : ("Momentum");
      
      if (N_RKmax > 0)
	{
	  const class correlated_state_str PSI_qn(Z , N , BP , J , vector_index , NADA , NADA , NADA , NADA , false);
      
	  class array<double> rk_tab(N_RKmax);

	  for (unsigned int i = 0 ; i < N_RKmax ; i++) rk_tab(i) = rk_tab_init(i);
	  
	  calc_store_density (is_it_radial , is_it_Gauss_Legendre , is_it_HO_expansion , inter_data , rk_tab , theta_tab , PSI_qn , Gamma_pp , Gamma_nn , Gamma_pn , prot_data , neut_data);
	  
	  if (THIS_PROCESS == MASTER_PROCESS)	      
	    cout << radial_momentum_str << " correlation density of " << J_Pi_vector_index_string (BP , J , vector_index) << " calculated." << endl << endl;
	}
      else if (THIS_PROCESS == MASTER_PROCESS)
	cout << radial_momentum_str << " correlation density of " << J_Pi_vector_index_string (BP , J , vector_index) << " not calculated: no points on grid" << endl << endl;
    }

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
}

