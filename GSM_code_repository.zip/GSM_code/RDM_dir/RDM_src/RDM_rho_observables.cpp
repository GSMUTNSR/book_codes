#include "../RDM_include/RDM_include_def.h"


TYPE RDM_rho_observables::rho_ME_prot_calc (
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data ,
					    const class RDM_PQG_class &Gamma_pp ,
					    const class RDM_PQG_class &Gamma_pn ,
					    const unsigned int sa_p ,
					    const unsigned int sc_p)
{						
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
    						
  const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
  const class nlj_struct &shell_qn_sc = prot_shells_qn(sc_p);

  const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
  const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
  const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
  const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

  if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) return 0.0;

  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Nval + Zval;
      
  const class block_matrix<TYPE> &Gamma_block_matrix_pp = Gamma_pp.get_block_matrix ();
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
      
  const class array<unsigned int> &two_states_indices_pp = Gamma_pp.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
    
  const int ij = ija;
  
  TYPE rho_ME_prot = 0.0;
  
  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
    {
      const class pair_str pair(sa_p , sb_p);
      
      const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , prot_shells_qn);

      if (are_there_frozen_states) continue;
      
      const unsigned int BP = pair.bp_determine (prot_shells_qn , prot_shells_qn);
		
      const int Jmin = pair.Jmin_determine (prot_shells_qn , prot_shells_qn);		
      const int Jmax = pair.Jmax_determine (prot_shells_qn , prot_shells_qn);
      
      const class nlj_struct &shell_qn_sb = prot_shells_qn(sb_p);
      
      const int ijb = shell_qn_sb.get_ij ();
	      		
      const bool are_sa_sb_equal = (sa_p == sb_p);
      const bool are_sc_sb_equal = (sc_p == sb_p);
      
      const double delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT2) : (1.0);
      const double delta_norm_cb = (are_sc_sb_equal) ? (M_SQRT2) : (1.0);
			
      const bool is_sa_smaller_than_sb = (sa_p <= sb_p);
      const bool is_sc_smaller_than_sb = (sc_p <= sb_p);				

      const bool ab_different_cb_different = (!are_sa_sb_equal && !are_sc_sb_equal);
      
      TYPE rho_ME_prot_part = 0.0;
  
      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const bool is_J_even = (J%2 == 0);

	  if (is_J_even || ab_different_cb_different)
	    {
	      const class matrix<TYPE> &Gamma_matrix_pp = Gamma_block_matrix_pp(BP + 2*J);
	
	      const unsigned int ab_index = (is_sa_smaller_than_sb) ? (two_states_indices_pp(J , sa_p , sb_p)) : (two_states_indices_pp(J , sb_p , sa_p));
	      const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_pp(J , sc_p , sb_p)) : (two_states_indices_pp(J , sb_p , sc_p));
	  	
	      const int phase_ab = (is_sa_smaller_than_sb) ? (1) : (minus_one_pow (ija + ijb + J));
	      const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (minus_one_pow (ijc + ijb + J));
						      
	      const TYPE Gamma_ME = (phase_ab == phase_cb) ? (Gamma_matrix_pp(ab_index , cb_index)) : (-Gamma_matrix_pp(ab_index , cb_index));

	      rho_ME_prot_part += (2*J + 1)*Gamma_ME;
	    }
	}
      
      rho_ME_prot_part *= delta_norm_ab*delta_norm_cb;

      rho_ME_prot += rho_ME_prot_part;
    }

  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
    {
      const class pair_str pair(sa_p , sb_n);
      
      const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

      if (are_there_frozen_states) continue;
      
      const unsigned int BP = pair.bp_determine (prot_shells_qn , neut_shells_qn);
		
      const int Jmin = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);		
      const int Jmax = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
            	      	
      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
	  const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
	  const unsigned int cb_index = two_states_indices_pn(J , sc_p , sb_n);
	
	  const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , cb_index);

	  rho_ME_prot += (2*J + 1)*Gamma_ME;
	}      
    }

  rho_ME_prot /= (Aval - 1)*(2*ij + 2);

  return rho_ME_prot;
}










TYPE RDM_rho_observables::rho_ME_neut_calc (
					    const class nucleons_data &prot_data ,
					    const class nucleons_data &neut_data ,
					    const class RDM_PQG_class &Gamma_nn ,
					    const class RDM_PQG_class &Gamma_pn , 
					    const unsigned int sa_n ,
					    const unsigned int sc_n)
{  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
      
  const class nlj_struct &shell_qn_sa = neut_shells_qn(sa_n);
  const class nlj_struct &shell_qn_sc = neut_shells_qn(sc_n);

  const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
  const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
  const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
  const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

  if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) return 0.0;

  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Nval + Zval;
      
  const class block_matrix<TYPE> &Gamma_block_matrix_nn = Gamma_nn.get_block_matrix ();
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
      
  const class array<unsigned int> &two_states_indices_nn = Gamma_nn.get_two_states_indices ();
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
    
  const int ij = ija;
    
  TYPE rho_ME_neut = 0.0;
  
  for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
    {
      const class pair_str pair(sa_n , sb_n);
      
      const bool are_there_frozen_states = pair.are_there_frozen_states_determine (neut_shells_qn , neut_shells_qn);

      if (are_there_frozen_states) continue;
      
      const unsigned int BP = pair.bp_determine (neut_shells_qn , neut_shells_qn);
		
      const int Jmin = pair.Jmin_determine (neut_shells_qn , neut_shells_qn);		
      const int Jmax = pair.Jmax_determine (neut_shells_qn , neut_shells_qn);
      
      const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
	      
      const int ijb = shell_qn_sb.get_ij ();
  
      const bool are_sa_sb_equal = (sa_n == sb_n);
      const bool are_sc_sb_equal = (sc_n == sb_n);
      
      const double delta_norm_ab = (are_sa_sb_equal) ? (M_SQRT2) : (1.0);
      const double delta_norm_cb = (are_sc_sb_equal) ? (M_SQRT2) : (1.0);
			
      const bool is_sa_smaller_than_sb = (sa_n <= sb_n);
      const bool is_sc_smaller_than_sb = (sc_n <= sb_n);
      
      const bool ab_different_cb_different = (!are_sa_sb_equal && !are_sc_sb_equal);
      
      TYPE rho_ME_neut_part = 0.0;
  
      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const bool is_J_even = (J%2 == 0);
	  
	  if (is_J_even || ab_different_cb_different)
	    {
	      const class matrix<TYPE> &Gamma_matrix_nn = Gamma_block_matrix_nn(BP + 2*J);
	
	      const unsigned int ab_index = (is_sa_smaller_than_sb) ? (two_states_indices_nn(J , sa_n , sb_n)) : (two_states_indices_nn(J , sb_n , sa_n));
	      const unsigned int cb_index = (is_sc_smaller_than_sb) ? (two_states_indices_nn(J , sc_n , sb_n)) : (two_states_indices_nn(J , sb_n , sc_n));
	  	
	      const int phase_ab = (is_sa_smaller_than_sb) ? (1) : (minus_one_pow (ija + ijb + J));
	      const int phase_cb = (is_sc_smaller_than_sb) ? (1) : (minus_one_pow (ijc + ijb + J));
						      
	      const TYPE Gamma_ME = (phase_ab == phase_cb) ? (Gamma_matrix_nn(ab_index , cb_index)) : (-Gamma_matrix_nn(ab_index , cb_index));

	      rho_ME_neut_part += (2*J + 1)*Gamma_ME;
	    }
	}
      
      rho_ME_neut_part *= delta_norm_ab*delta_norm_cb;

      rho_ME_neut += rho_ME_neut_part;
    }
  
  for (unsigned int sb_p = 0 ; sb_p < Np_nlj ; sb_p++)
    {
      const class pair_str pair(sb_p , sa_n);
      
      const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

      if (are_there_frozen_states) continue;
      
      const unsigned int BP = pair.bp_determine (prot_shells_qn , neut_shells_qn);
		
      const int Jmin = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);		
      const int Jmax = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
            	      	      
      for (int J = Jmin ; J <= Jmax ; J++)
	{
	  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
	  const unsigned int ab_index = two_states_indices_pn(J , sb_p , sa_n);
	  const unsigned int cb_index = two_states_indices_pn(J , sb_p , sc_n);
	
	  const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , cb_index); //no phase as (-1)^(ja + jb - J).(-1)^(jc + jb - J) = 1

	  rho_ME_neut += (2*J + 1)*Gamma_ME;
	}      
    }

  rho_ME_neut /= (Aval - 1)*(2*ij + 2);

  return rho_ME_neut;
}










void RDM_rho_observables::rho_prot_tab_calc (
					     const class nucleons_data &prot_data ,
					     const class nucleons_data &neut_data ,
					     const class RDM_PQG_class &Gamma_pp , 
					     const class RDM_PQG_class &Gamma_pn , 
					     class array<TYPE> &rho_prot_tab)
{
  const unsigned int Np_nlj = rho_prot_tab.dimension (0);
     		
  rho_prot_tab = 0.0;
  
  const int Zval = prot_data.get_N_valence_nucleons ();
    
  if (Zval == 0) return;
  
  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
      rho_prot_tab(sa_p , sc_p) = rho_ME_prot_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , sa_p , sc_p);
}









void RDM_rho_observables::rho_neut_tab_calc (
					     const class nucleons_data &prot_data ,
					     const class nucleons_data &neut_data ,
					     const class RDM_PQG_class &Gamma_nn, 
					     const class RDM_PQG_class &Gamma_pn, 
					     class array<TYPE> &rho_neut_tab)
{
  const unsigned int Nn_nlj = rho_neut_tab.dimension (0);
      
  rho_neut_tab = 0.0;

  const int Nval = neut_data.get_N_valence_nucleons ();
    
  if (Nval == 0) return;
  
  for (unsigned int sa_n = 0 ; sa_n < Nn_nlj ; sa_n++)
    for (unsigned int sc_n = 0 ; sc_n < Nn_nlj ; sc_n++)
      rho_neut_tab(sa_n , sc_n) = rho_ME_neut_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , sa_n , sc_n);
}







TYPE RDM_rho_observables::Delta_pp_nn_pairs_number_calc (
							 const class nucleons_data &particles_data ,
							 const class RDM_PQG_class &Gamma_pp_nn)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();  
    
  const class block_matrix<TYPE> &Gamma_block_matrix_pp_nn = Gamma_pp_nn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
  
  TYPE Delta_pp_nn_pairs_number = -(N_valence_nucleons*(N_valence_nucleons - 1))/2;

  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair(sa , sb);
      
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP_prime = pair.bp_determine (shells_qn , shells_qn);
		
	const int J_prime_min = pair.Jmin_determine (shells_qn , shells_qn);		
	const int J_prime_max = pair.Jmax_determine (shells_qn , shells_qn);

	const bool ab_different = (sa != sb);
	
	for (int J_prime = J_prime_min ; J_prime <= J_prime_max ; J_prime++)
	  {
	    const bool is_J_prime_even = (J_prime%2 == 0);

	    if (is_J_prime_even || ab_different)
	      {
		const class matrix<TYPE> &Gamma_matrix_pp_nn = Gamma_block_matrix_pp_nn(BP_prime + 2*J_prime);
	
		const unsigned int ab_index = two_states_indices(J_prime , sa , sb);
	  							      
		const TYPE Gamma_ME = Gamma_matrix_pp_nn(ab_index , ab_index);

		Delta_pp_nn_pairs_number += (2*J_prime + 1)*Gamma_ME;
	      }
	  }      
      }
  
  return Delta_pp_nn_pairs_number;
}






TYPE RDM_rho_observables::Delta_pn_pairs_number_calc (
						      const class nucleons_data &prot_data ,
						      const class nucleons_data &neut_data ,
						      const class RDM_PQG_class &Gamma_pn)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE Delta_pn_pairs_number = -Zval*Nval;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
      
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP_prime = pair.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int J_prime_min = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int J_prime_max = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
            	            	
	for (int J_prime = J_prime_min ; J_prime <= J_prime_max ; J_prime++)
	  {
	    const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP_prime + 2*J_prime);
	
	    const unsigned int ab_index = two_states_indices_pn(J_prime , sa_p , sb_n);
	
	    const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , ab_index);

	    Delta_pn_pairs_number += (2*J_prime + 1)*Gamma_ME;
	  }      
      }
  
  return Delta_pn_pairs_number;
}










TYPE RDM_rho_observables::Delta_J_pp_nn_calc (
					      const int Aval , 
					      const class nucleons_data &particles_data ,
					      const class array<TYPE> &rho_tab ,
					      const class RDM_PQG_class &Gamma)
{  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const int Aval_minus_two = Aval - 2;
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();  
    
  const class block_matrix<TYPE> &Gamma_block_matrix = Gamma.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma.get_two_states_indices ();
  
  TYPE Delta_J_pp_nn = 0.0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
          
      const bool frozen_state = shell_qn.get_frozen_state ();

      if (frozen_state) continue;
	
      const double j = shell_qn.get_j ();
      
      const int ij = shell_qn.get_ij ();

      const int hat_j_square = 2*ij + 2;
	
      Delta_J_pp_nn -= Aval_minus_two*j*(j + 1.0)*hat_j_square*rho_tab(s , s);
    }
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair(sa , sb);
      	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP_prime = pair.bp_determine (shells_qn , shells_qn);
		
	const int J_prime_min = pair.Jmin_determine (shells_qn , shells_qn);		
	const int J_prime_max = pair.Jmax_determine (shells_qn , shells_qn);
        
	const bool ab_different = (sa != sb);
	      
	for (int J_prime = J_prime_min ; J_prime <= J_prime_max ; J_prime++)
	  {
	    const bool is_J_prime_even = (J_prime%2 == 0);

	    if (is_J_prime_even || ab_different)
	      {
		const class matrix<TYPE> &Gamma_matrix = Gamma_block_matrix(BP_prime + 2*J_prime);
	
		const unsigned int ab_index = two_states_indices(J_prime , sa , sb);
	  							      
		const TYPE Gamma_ME = Gamma_matrix(ab_index , ab_index);

		Delta_J_pp_nn += ((2*J_prime + 1)*J_prime*(J_prime + 1))*Gamma_ME;
	      }
	  }      
      }
  
  return Delta_J_pp_nn;
}








TYPE RDM_rho_observables::Delta_J_pn_calc (
					   const class nucleons_data &prot_data ,
					   const class nucleons_data &neut_data ,
					   const class RDM_PQG_class &Gamma_pn)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE Delta_J_pn = 0.0;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair(sa_p , sb_n);
      
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP_prime = pair.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int J_prime_min = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int J_prime_max = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);
            	            	            	
	for (int J_prime = J_prime_min ; J_prime <= J_prime_max ; J_prime++)
	  {
	    const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP_prime + 2*J_prime);
	
	    const unsigned int ab_index = two_states_indices_pn(J_prime , sa_p , sb_n);
	
	    const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , ab_index);

	    Delta_J_pn += ((2*J_prime + 1)*J_prime*(J_prime + 1))*Gamma_ME;
	  }      
      }
  
  return Delta_J_pn;
}








TYPE RDM_rho_observables::Delta_J_calc (					  
					const class nucleons_data &prot_data ,
					const class nucleons_data &neut_data ,
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn , 
					const double J)
{
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);

  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);
  
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  const int Aval = Zval + Nval;
  
  const TYPE Delta_J_prot = Delta_J_pp_nn_calc (Aval , prot_data , rho_prot_tab , Gamma_pp);
  const TYPE Delta_J_neut = Delta_J_pp_nn_calc (Aval , neut_data , rho_neut_tab , Gamma_nn);
  
  const TYPE Delta_J_pn = Delta_J_pn_calc (prot_data , neut_data , Gamma_pn);
  
  const TYPE Delta_J = Delta_J_prot + Delta_J_neut + Delta_J_pn - J*(J + 1.0);
    
  return Delta_J;
}











TYPE RDM_rho_observables::average_T2_calc (
					   const class nucleons_data &prot_data ,
					   const class nucleons_data &neut_data ,
					   const class RDM_PQG_class &Gamma_pn)
{
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
          
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();
    
  const double Tz = 0.5*(Nval - Zval);
  
  const double Tz_Tz_plus_one = Tz*(Tz + 1.0);

  if ((Zval == 0) || (Nval == 0)) return abs (Tz_Tz_plus_one);

  const int np_max = prot_data.get_nmax ();
  const int nn_max = neut_data.get_nmax ();
  
  const int lp_max = prot_data.get_lmax ();
  const int ln_max = neut_data.get_lmax ();
    
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class nlj_table<unsigned int> &prot_shells_indices = prot_data.get_shells_indices ();
  const class nlj_table<unsigned int> &neut_shells_indices = neut_data.get_shells_indices ();
      
  const class nlj_table<bool> &is_it_prot_valence_shell_tab = prot_data.get_is_it_valence_shell_tab ();
  const class nlj_table<bool> &is_it_neut_valence_shell_tab = neut_data.get_is_it_valence_shell_tab ();
      
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
  
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE average_T2 = Zval + Tz_Tz_plus_one;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class nlj_struct &shell_qn_sa = prot_shells_qn(sa_p);
	const class nlj_struct &shell_qn_sb = neut_shells_qn(sb_n);
      	      
	const int na = shell_qn_sa.get_n ();
	const int nb = shell_qn_sb.get_n ();

	if (na > nn_max) continue;
	if (nb > np_max) continue;
      
	const int la = shell_qn_sa.get_l ();
	const int lb = shell_qn_sb.get_l ();
      
	if (la > ln_max) continue;
	if (lb > lp_max) continue;
        	
	const double ja = shell_qn_sa.get_j ();
	const double jb = shell_qn_sb.get_j ();
      
	if (!is_it_neut_valence_shell_tab(na , la , ja)) continue;
	if (!is_it_prot_valence_shell_tab(nb , lb , jb)) continue;
      	
	const unsigned int sa_n = neut_shells_indices(na , la , ja);
	const unsigned int sb_p = prot_shells_indices(nb , lb , jb);
	            
	const class pair_str pair(sa_p , sb_n);
	
	const bool are_there_frozen_states = pair.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states) continue;
	
	const unsigned int BP = pair.bp_determine (prot_shells_qn , neut_shells_qn);
  
	const int Jmin_ab = pair.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair.Jmax_determine (prot_shells_qn , neut_shells_qn);

	for (int J = Jmin_ab ; J <= Jmax_ab ; J++)
	  {
	    const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
	    const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);
	    const unsigned int ba_index = two_states_indices_pn(J , sb_p , sa_n);
	
	    const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , ba_index);

	    const int phase_ab = minus_one_pow (Jmax_ab + J);

	    (phase_ab == 1) ? (average_T2 -= (2*J + 1)*Gamma_ME) : (average_T2 += (2*J + 1)*Gamma_ME);
	  }
      }

  return average_T2;
}










TYPE RDM_rho_observables::average_E_pp_nn_calc (
						const bool is_it_E_reference_condition ,
						const enum interaction_type inter ,
						const double H_renormalization_factor ,
						const class nucleons_data &particles_data ,
						const class array<TYPE> &rho_tab ,
						const class RDM_PQG_class &Gamma_pp_nn)
{      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const unsigned int N_nlj = (is_it_E_reference_condition) ? (particles_data.get_N_nlj_res ()) : (particles_data.get_N_nlj ());
  
  const class OBMEs_inter_set_str &OBMEs_inter_set = particles_data.get_OBMEs_inter_set ();
  
  const class array<TYPE> &OBMEs = OBMEs_inter_set(inter);
  
  const class TBMEs_class &TBMEs = particles_data.get_TBMEs ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
      
  const class block_matrix<TYPE> &Gamma_block_matrix_pp_nn = Gamma_pp_nn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma_pp_nn.get_two_states_indices ();
    
  TYPE average_E_pp_nn_one_body = 0.0;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);
  
	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
      
	const int ij = ija;

	const int hat_j_square = 2*ij + 2;
      
	average_E_pp_nn_one_body += OBMEs(sa , sc)*hat_j_square*rho_tab (sa , sc);
      }
  
  if (N_valence_nucleons == 1) return average_E_pp_nn_one_body;
  
  TYPE average_E_pp_nn_two_body = 0.0;
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair_ab(sa , sb);
      	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (shells_qn , shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
	
	const bool are_sa_sb_equal = (sa == sb);
      
	for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	  for (unsigned int sc = 0 ; sc <= sd ; sc++)
	    {
	      const class pair_str pair_cd(sc , sd);
      	
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (shells_qn , shells_qn);

	      if (are_there_frozen_states_cd) continue;
	
	      const unsigned int BP_cd = pair_cd.bp_determine (shells_qn , shells_qn);
				
	      if (BP_ab != BP_cd) continue;

	      const unsigned int BP = BP_ab;
		
	      const int Jmin_cd = pair_cd.Jmin_determine (shells_qn , shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (shells_qn , shells_qn);

	      const bool are_sc_sd_equal = (sc == sd);
	
	      const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);
      
	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
          
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const bool is_J_even = (J%2 == 0);

		  if (is_J_even || ab_different_cd_different)
		    {
		      const class matrix<TYPE> &Gamma_matrix_pp_nn = Gamma_block_matrix_pp_nn(BP + 2*J);
	
		      const unsigned int ab_index = two_states_indices(J , sa , sb);
		      const unsigned int cd_index = two_states_indices(J , sc , sd);
		  
		      const TYPE Gamma_pp_nn_ME = Gamma_matrix_pp_nn(ab_index , cd_index);

		      const TYPE TBME_abcd_J = TBMEs(J , sa , sb , sc , sd);
  
		      average_E_pp_nn_two_body += (2*J + 1)*TBME_abcd_J*Gamma_pp_nn_ME;
		    }
		}
	    }
      }  

  const TYPE average_E_pp_nn = average_E_pp_nn_one_body + H_renormalization_factor*average_E_pp_nn_two_body;
  
  return average_E_pp_nn;
}




















TYPE RDM_rho_observables::average_E_pn_calc (
					     const bool is_it_E_reference_condition , 
					     const double H_renormalization_factor ,
					     const class nucleons_data &prot_data ,
					     const class nucleons_data &neut_data , 
					     const class TBMEs_class &TBMEs_pn ,
					     const class RDM_PQG_class &Gamma_pn)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;
            
  const unsigned int Np_nlj = (is_it_E_reference_condition) ? (prot_data.get_N_nlj_res ()) : (prot_data.get_N_nlj ());
  const unsigned int Nn_nlj = (is_it_E_reference_condition) ? (neut_data.get_N_nlj_res ()) : (neut_data.get_N_nlj ());
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE average_E_pn = 0.0;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
      
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	    
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	    {
	      const class pair_str pair_cd(sc_p , sd_n);
      
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	      if (are_there_frozen_states_cd) continue;
	
	      const unsigned int BP_cd = pair_cd.bp_determine (prot_shells_qn , neut_shells_qn);		
		
	      if (BP_ab != BP_cd) continue;

	      const unsigned int BP = BP_ab;
	
	      const int Jmin_cd = pair_cd.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (prot_shells_qn , neut_shells_qn);

	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
        	                	
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
		  const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);	
		  const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
	
		  const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , cd_index);

		  const TYPE TBME_pn_abcd_J = TBMEs_pn(J , sa_p , sb_n , sc_p , sd_n);
		  
		  average_E_pn += (2*J + 1)*TBME_pn_abcd_J*Gamma_ME;	    
		}      
	    }
      }
  
  average_E_pn *= H_renormalization_factor;
    
  return average_E_pn;
}








TYPE RDM_rho_observables::average_E_calc (
					  const bool is_it_E_reference_condition , 
					  const enum interaction_type inter ,
					  const TYPE E_reference ,
					  const double H_renormalization_factor ,
					  const class nucleons_data &prot_data ,
					  const class nucleons_data &neut_data , 
					  const class TBMEs_class &TBMEs_pn ,
					  const class RDM_PQG_class &Gamma_pp ,
					  const class RDM_PQG_class &Gamma_nn ,
					  const class RDM_PQG_class &Gamma_pn)
{
  if (!is_it_E_reference_condition && (E_reference != 0.0)) error_message_print_abort ("E[reference] must be equal to zero unless one calculates <Psi|H[ref]|Psi> in reference space, where <Psi|H[ref]|Psi> >= E[reference]");
  
  if (is_it_E_reference_condition && (H_renormalization_factor != 1.0)) error_message_print_abort ("H_renormalization_factor must be equal to one if one calculates <Psi|H[ref]|Psi> in reference space, where <Psi|H[ref]|Psi> >= E[reference]");
  
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);

  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);
  
  const TYPE average_E_pp = average_E_pp_nn_calc (is_it_E_reference_condition , inter , H_renormalization_factor , prot_data , rho_prot_tab , Gamma_pp);
  const TYPE average_E_nn = average_E_pp_nn_calc (is_it_E_reference_condition , inter , H_renormalization_factor , neut_data , rho_neut_tab , Gamma_nn);
  
  const TYPE average_E_pn = average_E_pn_calc (is_it_E_reference_condition , H_renormalization_factor , prot_data , neut_data , TBMEs_pn , Gamma_pn);
    
  const TYPE average_E = average_E_pp + average_E_nn + average_E_pn - E_reference;
    
  return average_E;
}









TYPE RDM_rho_observables::average_CM_op_pp_nn_calc (
						    const enum operator_type CM_operator_inter ,
						    const bool is_it_HO_expansion ,
						    const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
						    const class nucleons_data &particles_data ,
						    const class array<TYPE> &rho_tab ,
						    const class RDM_PQG_class &Gamma)
{      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
      
  const class block_matrix<TYPE> &Gamma_block_matrix = Gamma.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices = Gamma.get_two_states_indices ();
    
  TYPE average_CM_op_pp_nn = 0.0;
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);
  
	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
	
	const int ij = ija;

	const TYPE OBME_ac = CM_OBMEs_TBMEs::coupled_OBME (CM_operator_inter , is_it_HO_expansion , particles_data , sa , sc);
      
	average_CM_op_pp_nn += OBME_ac*(2*ij + 2)*rho_tab (sa , sc);
      }
  
  for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
    for (unsigned int sa = 0 ; sa <= sb ; sa++)
      {
	const class pair_str pair_ab(sa , sb);
      	
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (shells_qn , shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (shells_qn , shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (shells_qn , shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (shells_qn , shells_qn);
	
	const bool are_sa_sb_equal = (sa == sb);
	
	for (unsigned int sd = 0 ; sd < N_nlj ; sd++)
	  for (unsigned int sc = 0 ; sc <= sd ; sc++)
	    {
	      const class pair_str pair_cd(sc , sd);
      	
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (shells_qn , shells_qn);

	      if (are_there_frozen_states_cd) continue;
	
	      const unsigned int BP_cd = pair_cd.bp_determine (shells_qn , shells_qn);
				
	      if (BP_ab != BP_cd) continue;

	      if (CM_OBMEs_TBMEs::is_coupled_TBME_pp_nn_trivial_zero_determine (shells_qn , sa , sb , sc , sd)) continue;
	      
	      const unsigned int BP = BP_ab;
		
	      const int Jmin_cd = pair_cd.Jmin_determine (shells_qn , shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (shells_qn , shells_qn);

	      const bool are_sc_sd_equal = (sc == sd);
	      
	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);

	      const bool ab_different_cd_different = (!are_sa_sb_equal && !are_sc_sd_equal);

	      TYPE average_CM_op_part = 0.0;
  
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const bool is_J_even = (J%2 == 0);
		  
		  if (is_J_even || ab_different_cd_different)
		    {
		      const class CM_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
  
		      const class matrix<TYPE> &Gamma_matrix = Gamma_block_matrix(BP + 2*J);
	
		      const unsigned int ab_index = two_states_indices(J , sa , sb);
		      const unsigned int cd_index = two_states_indices(J , sc , sd);
		  
		      const TYPE Gamma_ME = Gamma_matrix(ab_index , cd_index);

		      const TYPE TBME_abcd_J = CM_OBMEs_TBMEs::coupled_TBME_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , particles_data , TBMEs_angular_table_J , sa , sb , sc , sd);
  
		      average_CM_op_part += (2*J + 1)*TBME_abcd_J*Gamma_ME;
		    }
		}
	
	      average_CM_op_pp_nn += average_CM_op_part;
	    }
      }
  
  return average_CM_op_pp_nn;
}




















TYPE RDM_rho_observables::average_CM_op_pn_calc (
						 const enum operator_type CM_operator_inter ,
						 const bool is_it_HO_expansion ,
						 const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
						 const class nucleons_data &prot_data ,
						 const class nucleons_data &neut_data , 
						 const class RDM_PQG_class &Gamma_pn)
{
  const int Zval = prot_data.get_N_valence_nucleons ();
  const int Nval = neut_data.get_N_valence_nucleons ();

  if ((Zval == 0) || (Nval == 0)) return 0.0;
            
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const class array<class nlj_struct> &prot_shells_qn = prot_data.get_shells_quantum_numbers ();
  const class array<class nlj_struct> &neut_shells_qn = neut_data.get_shells_quantum_numbers ();
  
  const class block_matrix<TYPE> &Gamma_block_matrix_pn = Gamma_pn.get_block_matrix ();
    
  const class array<unsigned int> &two_states_indices_pn = Gamma_pn.get_two_states_indices ();
  
  TYPE average_CM_op_pn = 0.0;

  for (unsigned int sa_p = 0 ; sa_p < Np_nlj ; sa_p++)
    for (unsigned int sb_n = 0 ; sb_n < Nn_nlj ; sb_n++)
      {
	const class pair_str pair_ab(sa_p , sb_n);
      
	const bool are_there_frozen_states_ab = pair_ab.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	if (are_there_frozen_states_ab) continue;
	
	const unsigned int BP_ab = pair_ab.bp_determine (prot_shells_qn , neut_shells_qn);
		
	const int Jmin_ab = pair_ab.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	const int Jmax_ab = pair_ab.Jmax_determine (prot_shells_qn , neut_shells_qn);
	    
	for (unsigned int sc_p = 0 ; sc_p < Np_nlj ; sc_p++)
	  for (unsigned int sd_n = 0 ; sd_n < Nn_nlj ; sd_n++)
	    {
	      const class pair_str pair_cd(sc_p , sd_n);
      
	      const bool are_there_frozen_states_cd = pair_cd.are_there_frozen_states_determine (prot_shells_qn , neut_shells_qn);

	      if (are_there_frozen_states_cd) continue;
	
	      const unsigned int BP_cd = pair_cd.bp_determine (prot_shells_qn , neut_shells_qn);		
		
	      if (BP_ab != BP_cd) continue;

	      if (CM_OBMEs_TBMEs::is_coupled_TBME_pn_trivial_zero_determine (prot_shells_qn , neut_shells_qn , sa_p , sb_n , sc_p , sd_n)) continue;
	      
	      const unsigned int BP = BP_ab;
	
	      const int Jmin_cd = pair_cd.Jmin_determine (prot_shells_qn , neut_shells_qn);		
	      const int Jmax_cd = pair_cd.Jmax_determine (prot_shells_qn , neut_shells_qn);

	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);
        	                	
	      for (int J = Jmin ; J <= Jmax ; J++)
		{
		  const class CM_TBMEs_angular_table_str &TBMEs_angular_table_J = TBMEs_angular_tables(J);
		  
		  const class matrix<TYPE> &Gamma_matrix_pn = Gamma_block_matrix_pn(BP + 2*J);
	
		  const unsigned int ab_index = two_states_indices_pn(J , sa_p , sb_n);	
		  const unsigned int cd_index = two_states_indices_pn(J , sc_p , sd_n);
	
		  const TYPE Gamma_ME = Gamma_matrix_pn(ab_index , cd_index);

		  const TYPE TBME_pn_abcd_J = CM_OBMEs_TBMEs::coupled_TBME_pn_calc (CM_operator_inter , is_it_HO_expansion , prot_data , neut_data , TBMEs_angular_table_J , sa_p , sb_n , sc_p , sd_n);
  
		  average_CM_op_pn += (2*J + 1)*TBME_pn_abcd_J*Gamma_ME;	    
		}      
	    }
      }
  
  return average_CM_op_pn;
}








TYPE RDM_rho_observables::average_CM_op_calc (
					      const enum operator_type CM_operator_inter ,
					      const bool is_it_HO_expansion ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data , 
					      const class RDM_PQG_class &Gamma_pp ,
					      const class RDM_PQG_class &Gamma_nn ,
					      const class RDM_PQG_class &Gamma_pn)
{   
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();
  
  const double jmax = max (jp_max , jn_max);

  const int Jmax = make_int (2.0*jmax);
  
  const int Jmax_plus_one = Jmax + 1;

  class array<class CM_TBMEs_angular_table_str> TBMEs_angular_tables(Jmax_plus_one);

  for (int J = 0 ; J <= Jmax ; J++) TBMEs_angular_tables(J).allocate_calc_coupled (CM_operator_inter , jmax , J);
	
  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);

  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);
  
  const TYPE average_CM_op_prot = average_CM_op_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , TBMEs_angular_tables , prot_data , rho_prot_tab , Gamma_pp);
  const TYPE average_CM_op_neut = average_CM_op_pp_nn_calc (CM_operator_inter , is_it_HO_expansion , TBMEs_angular_tables , neut_data , rho_neut_tab , Gamma_nn);
  
  const TYPE average_CM_op_pn = average_CM_op_pn_calc (CM_operator_inter , is_it_HO_expansion , TBMEs_angular_tables , prot_data , neut_data , Gamma_pn);
  
  const TYPE average_CM_op = average_CM_op_prot + average_CM_op_neut + average_CM_op_pn;
    
  return average_CM_op;
}













TYPE RDM_rho_observables::shell_occupation_calc (
						 const class nucleons_data &particles_data ,
						 const class array<TYPE> &rho_tab ,
						 const class nlj_struct &shell_nlj)
{
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
	
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();  
          
  TYPE shell_occupation = 0.0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);

      const bool frozen_state = shell_qn.get_frozen_state ();
      
      if (frozen_state) continue;
	
      if (same_nlj (shell_nlj , shell_qn))
	{
	  const int ij = shell_qn.get_ij ();
	      
	  shell_occupation += (2*ij + 2)*rho_tab (s , s);
	}
    }
  
  return shell_occupation;
}





void RDM_rho_observables::all_shells_occupation_calc_print (
							    const enum particle_type particle ,
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data , 
							    const class RDM_PQG_class &Gamma_pp_nn ,
							    const class RDM_PQG_class &Gamma_pn)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_rho_observables::all_shells_occupation_calc_print");
  
  const class nucleons_data &particles_data = (particle == PROTON) ? (prot_data) : (neut_data);
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
	
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  class array<TYPE> rho_tab(N_nlj , N_nlj);

  switch (particle)
    {
    case PROTON:  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
    case NEUTRON: rho_neut_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
      
    default: abort_all ();
    }
  
  cout << endl << particle << " shells occupations" << endl;

  cout << "----------------------------" << endl << endl;
	  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);
          
      const TYPE shell_occupation = shell_occupation_calc (particles_data , rho_tab , shell_qn);

      if (inf_norm (shell_occupation) > precision) cout << particle << " " << shell_qn << " occupation : " << shell_occupation << endl;
    }

  cout << endl;
}





TYPE RDM_rho_observables::partial_wave_occupation_calc (
							const class nucleons_data &particles_data ,
							const class array<TYPE> &rho_tab ,
							const int l ,
							const double j)
{
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return 0.0;
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
            
  TYPE partial_wave_occupation = 0.0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn = shells_qn(s);

      const bool frozen_state_s = shell_qn.get_frozen_state ();
      
      if (frozen_state_s) continue;
      
      const int ls = shell_qn.get_l ();
      
      const double js = shell_qn.get_j ();

      if (same_lj (l , j , ls , js))
	{
	  const int ij = shell_qn.get_ij ();
	      
	  partial_wave_occupation += (2*ij + 2)*rho_tab (s , s);
	}
    }
  
  return partial_wave_occupation;
}






void RDM_rho_observables::all_partial_wave_occupation_calc_print (
								  const enum particle_type particle ,
								  const class nucleons_data &prot_data ,
								  const class nucleons_data &neut_data , 
								  const class RDM_PQG_class &Gamma_pp_nn ,
								  const class RDM_PQG_class &Gamma_pn)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_rho_observables::all_partial_wave_occupation_calc_print");
  
  const class nucleons_data &particles_data = (particle == PROTON) ? (prot_data) : (neut_data);
  
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return;

  const int lmax = particles_data.get_lmax ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
	
  class array<TYPE> rho_tab(N_nlj , N_nlj);

  switch (particle)
    {
    case PROTON:  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
    case NEUTRON: rho_neut_tab_calc (prot_data , neut_data , Gamma_pp_nn , Gamma_pn , rho_tab); break;
      
    default: abort_all ();
    }
  
  cout << endl << particle << " partial wave occupations" << endl;

  cout << "----------------------------------" << endl << endl;
  
  for (int l = 0 ; l <= lmax ; l++)
    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
      {
	const TYPE partial_wave_occupation = partial_wave_occupation_calc (particles_data , rho_tab , l , j);
	
	if (inf_norm (partial_wave_occupation) > precision) cout << particle << " " << angular_state (l , j) << " occupation : " << partial_wave_occupation << endl;
      }

  cout << endl;
}











void RDM_rho_observables::scalar_strength_pp_nn_calc (
						      const class array<TYPE> &OBMEs , 
						      const class nucleons_data &particles_data ,
						      const class array<TYPE> &rho_tab ,
						      class array<TYPE> &scalar_strength_tab)
{      
  const int N_valence_nucleons = particles_data.get_N_valence_nucleons ();  
    
  if (N_valence_nucleons == 0) return;
  
  const unsigned int Nr = scalar_strength_tab.dimension (0);
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
    
  class array<TYPE> OBMEs_two_j_plus_one_rho_ME(Nr);
  
  for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
    for (unsigned int sc = 0 ; sc < N_nlj ; sc++)
      {
	const class nlj_struct &shell_qn_sa = shells_qn(sa);
	const class nlj_struct &shell_qn_sc = shells_qn(sc);
  
	const bool frozen_state_sa = shell_qn_sa.get_frozen_state ();
	const bool frozen_state_sc = shell_qn_sc.get_frozen_state ();
  	
	const int la = shell_qn_sa.get_l () , ija = shell_qn_sa.get_ij ();
	const int lc = shell_qn_sc.get_l () , ijc = shell_qn_sc.get_ij ();

	if ((la != lc) || (ija != ijc) || frozen_state_sa || frozen_state_sc) continue;
	
	const int ij = ija;

	const TYPE two_j_plus_one_rho_ac = (2*ij + 2)*rho_tab (sa , sc);
	
	for (unsigned int i = 0 ; i < Nr ; i++) OBMEs_two_j_plus_one_rho_ME(i) = OBMEs(sa , sc , i);

	OBMEs_two_j_plus_one_rho_ME *= two_j_plus_one_rho_ac;
      
	scalar_strength_tab += OBMEs_two_j_plus_one_rho_ME;
      }
}











void RDM_rho_observables::scalar_strength_calc (
						const class array<TYPE> &OBMEs_prot , 
						const class array<TYPE> &OBMEs_neut , 
						const class nucleons_data &prot_data ,
						const class nucleons_data &neut_data , 
						const class RDM_PQG_class &Gamma_pp ,
						const class RDM_PQG_class &Gamma_nn ,
						const class RDM_PQG_class &Gamma_pn ,
						class array<TYPE> &scalar_strength_prot_tab ,
						class array<TYPE> &scalar_strength_neut_tab)
{   
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();
	
  class array<TYPE> rho_prot_tab(Np_nlj , Np_nlj);
  class array<TYPE> rho_neut_tab(Nn_nlj , Nn_nlj);

  rho_prot_tab_calc (prot_data , neut_data , Gamma_pp , Gamma_pn , rho_prot_tab);
  rho_neut_tab_calc (prot_data , neut_data , Gamma_nn , Gamma_pn , rho_neut_tab);

  scalar_strength_prot_tab = 0.0;
  scalar_strength_neut_tab = 0.0;
  
  scalar_strength_pp_nn_calc (OBMEs_prot , prot_data , rho_prot_tab , scalar_strength_prot_tab);
  scalar_strength_pp_nn_calc (OBMEs_neut , neut_data , rho_neut_tab , scalar_strength_neut_tab);
}








