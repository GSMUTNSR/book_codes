#include "../RDM_include/RDM_include_def.h"

RDM_G_Wigner_6j_hats_storage_class::RDM_G_Wigner_6j_hats_storage_class () {}

RDM_G_Wigner_6j_hats_storage_class::RDM_G_Wigner_6j_hats_storage_class (
									const class nucleons_data &prot_data ,
									const class nucleons_data &neut_data)
{
  alloc_calc_store (prot_data , neut_data);
}


RDM_G_Wigner_6j_hats_storage_class::RDM_G_Wigner_6j_hats_storage_class (const class RDM_G_Wigner_6j_hats_storage_class &X)
{
  allocate_fill (X);
}


RDM_G_Wigner_6j_hats_storage_class::~RDM_G_Wigner_6j_hats_storage_class () {}


void RDM_G_Wigner_6j_hats_storage_class::alloc_calc_store (
							   const class nucleons_data &prot_data ,
							   const class nucleons_data &neut_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_G_Wigner_6j_hats_storage_class::alloc_calc_store");
  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;

  class array<unsigned int> two_states_J_dimensions(Jmax_total_plus_one);

  class array<double> Wigner_6j_hats_subtable(Jmax_total_plus_one);
  
  Wigner_6j_hats_indices.allocate (j_number , j_number , j_number , j_number , Jmax_total_plus_one , Jmax_total_plus_one);

  Wigner_6j_hats_indices = Wigner_6j_hats_indices.dimension_total ();

  unsigned int dimension = 0;

  Wigner_6j_hats_indices_tabs_determine (DIMENSIONS_TABLES_CALC , prot_data , neut_data , dimension);
    
  Wigner_6j_hats_tab.allocate (dimension);

  dimension = 0;
  
  Wigner_6j_hats_tab = 0.0;
  
  Wigner_6j_hats_indices_tabs_determine (TABLES_FILL , prot_data , neut_data , dimension);
}



void RDM_G_Wigner_6j_hats_storage_class::Wigner_6j_hats_indices_tabs_determine (
										const enum operation_type operation ,
										const class nucleons_data &prot_data ,
										const class nucleons_data &neut_data ,
										unsigned int &dimension)
{  
  const double jp_max = prot_data.get_jmax ();
  const double jn_max = neut_data.get_jmax ();

  const double jmax = max (jp_max , jn_max);
  
  const int j_number = make_int (jmax + 0.5);
  
  const int Jmax_total = make_int (2.0*jmax);
  
  const int Jmax_total_plus_one = Jmax_total + 1;

  class array<double> Wigner_6j_subtable(Jmax_total_plus_one);
  
  for (int ija = 0 ; ija < j_number ; ija++)
    for (int ijb = 0 ; ijb < j_number ; ijb++)
      {
	const int Jmin_ab = abs (ija - ijb);

	const int Jmax_ab = ija + ijb + 1;
      
	const double ja = ija + 0.5;
	const double jb = ijb + 0.5;
	
	for (int ijc = 0 ; ijc < j_number ; ijc++)
	  for (int ijd = 0 ; ijd < j_number ; ijd++)
	    {
	      const double jc = ijc + 0.5;
	      const double jd = ijd + 0.5;
	      
	      const int Jmin_cd = abs (ijc - ijd);

	      const int Jmax_cd = ijc + ijd + 1;
	
	      const int Jp_min_bc = abs (ijb - ijc);
	      const int Jp_min_ad = abs (ija - ijd);
	
	      const int Jp_max_bc = ijb + ijc + 1;
	      const int Jp_max_ad = ija + ijd + 1;
			    
	      const int Jp_min = max (Jp_min_bc , Jp_min_ad);
	      const int Jp_max = min (Jp_max_bc , Jp_max_ad);
	      
	      const int Jmin = max (Jmin_ab , Jmin_cd);
	      const int Jmax = min (Jmax_ab , Jmax_cd);

	      switch (operation)
		{
		case DIMENSIONS_TABLES_CALC:
		  {
		    for (int J = Jmin ; J <= Jmax ; J++)
		      for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
			Wigner_6j_hats_indices(ija , ijb , ijc , ijd , J , Jp) = dimension++;

		  } break;
  
		case TABLES_FILL:
		  {
		    for (int J = Jmin ; J <= Jmax ; J++)
		      {
			if (Jp_min <= Jp_max) Wigner_signs::Wigner_6j_tab_calc (jc , jb , J , ja , jd , Wigner_6j_subtable);
		    
			for (int Jp = Jp_min ; Jp <= Jp_max ; Jp++)
			  {		  
			    const unsigned int Jp_index = make_uns_int (Jp - Jp_min);
		  	  
			    Wigner_6j_hats_tab(dimension++) = Wigner_6j_subtable(Jp_index)*(2*Jp + 1);
			  }
		      }	
		  } break;
		      
		default: abort_all ();
		}
	    }
      }
}





void RDM_G_Wigner_6j_hats_storage_class::allocate_fill (const class RDM_G_Wigner_6j_hats_storage_class &X)
{  
  if (is_it_filled ()) error_message_print_abort ("RDM_J_constraints_class cannot be allocated twice in RDM_G_Wigner_6j_hats_storage_class::allocate_fill");
  
  Wigner_6j_hats_indices.allocate_fill (X.Wigner_6j_hats_indices);
    
  Wigner_6j_hats_tab.allocate_fill (X.Wigner_6j_hats_tab);
}






void RDM_G_Wigner_6j_hats_storage_class::deallocate ()
{
  Wigner_6j_hats_indices.deallocate ();
  
  Wigner_6j_hats_indices.deallocate ();
  
  Wigner_6j_hats_tab.deallocate ();
}



