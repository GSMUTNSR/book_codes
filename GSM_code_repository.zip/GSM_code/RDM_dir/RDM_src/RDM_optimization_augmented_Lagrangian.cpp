#include "../RDM_include/RDM_include_def.h"

using namespace RDM_rho_observables;
using namespace RDM_rho_observables_gradient;
using namespace RDM_F_gradient;
using namespace RDM_Hessian_diagonal_no_sigma;










void RDM_optimization_augmented_Lagrangian::RDM_print_calc_observables_test_conditions (
											const enum space_type space , 
											const enum interaction_type inter ,
											const class nucleons_data &prot_data ,
											const class nucleons_data &neut_data , 
											const class TBMEs_class &TBMEs_pn ,
											const class RDM_PQG_class &Gamma_pp ,
											const class RDM_PQG_class &Gamma_nn ,
											const class RDM_PQG_class &Gamma_pn ,
											const class RDM_conditions_class &A_Gamma ,
											const double J , 
											const TYPE F ,
											const double F_der_norm ,
											const double X_minus_A_Gamma_norm)
{
  const double H_renormalization_factor = A_Gamma.get_H_renormalization_factor ();
    
  const TYPE Delta_pp_pairs_number = A_Gamma.get_Delta_pairs_number_dependent_term (PROTONS_ONLY);
  const TYPE Delta_nn_pairs_number = A_Gamma.get_Delta_pairs_number_dependent_term (NEUTRONS_ONLY);
  const TYPE Delta_pn_pairs_number = A_Gamma.get_Delta_pairs_number_dependent_term (PROTONS_NEUTRONS);
  
  const bool is_it_COSM = is_it_COSM_determine (inter);
  
  const bool are_there_J_constraints = A_Gamma.get_are_there_J_constraints ();
  
  const bool is_there_E_reference = A_Gamma.get_is_there_E_reference ();
  
  const TYPE Delta_Hcm = (!is_it_COSM) ? (average_CM_op_calc (HCM , true , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn)) : (NADA);
  
  const TYPE Delta_E_reference_dependent_term = (is_there_E_reference) ? (A_Gamma.get_Delta_E_reference_dependent_term ()) : (NADA);
  
  const TYPE Delta_J = A_Gamma.get_Delta_J_dependent_term ();
  
  const TYPE average_T2 = A_Gamma.get_average_T2_dependent_term ();
  
  const class RDM_J_constraints_class &J_constraints_pp = A_Gamma.get_J_constraints_dependent_term (PROTON);
  const class RDM_J_constraints_class &J_constraints_nn = A_Gamma.get_J_constraints_dependent_term (NEUTRON);
  
  const double J_constraints_pp_infinite_norm = J_constraints_pp.infinite_norm ();
  const double J_constraints_nn_infinite_norm = J_constraints_nn.infinite_norm ();
	  	  
  const TYPE average_E_H_renormalized = average_E_calc (false , inter , 0.0 , H_renormalization_factor , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
  const TYPE average_E                = average_E_calc (false , inter , 0.0 , 1.0                      , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
  
  cout << "J                 : " << J_string (J) << endl;
  cout << "E[H.renormalized] : " << average_E_H_renormalized << " MeV"  << endl;
  cout << "E[H.initial]      : " << average_E                << " MeV"  << endl;
	
  if (space != NEUTRONS_ONLY) cout << "Delta[pp pairs]   : " << Delta_pp_pairs_number << endl;
  if (space != PROTONS_ONLY)  cout << "Delta[nn pairs]   : " << Delta_nn_pairs_number << endl;

  if (space == PROTONS_NEUTRONS) cout << "Delta[pn pairs]   : " << Delta_pn_pairs_number << endl;

  if (are_there_J_constraints)
    {
      if (space != NEUTRONS_ONLY) cout << "Delta[J]-G[pp]    : " << J_constraints_pp_infinite_norm << endl;
      if (space != PROTONS_ONLY)  cout << "Delta[J]-G[nn]    : " << J_constraints_nn_infinite_norm << endl;
    }
      
  cout << "Delta[J]          : " << Delta_J << endl;

  if (space == PROTONS_NEUTRONS) cout << "<T^2>             : " << average_T2 << endl;
      
  if (!is_it_COSM) cout << "<Hcm>             : " << Delta_Hcm << " MeV"  << endl;

  if (is_there_E_reference) cout << "Delta[E.subspace] : " << Delta_E_reference_dependent_term << " MeV"  << endl;
  
  cout << "F                 : " << F << endl;      
  cout << "||grad[F]||       : " << F_der_norm << endl;
  cout << "||X - A.Gamma||   : " << X_minus_A_Gamma_norm << endl << endl << endl << endl;
}






TYPE RDM_optimization_augmented_Lagrangian::F_calc (
						    const enum interaction_type inter ,
						    const class nucleons_data &prot_data ,
						    const class nucleons_data &neut_data , 
						    const class TBMEs_class &TBMEs_pn ,
						    const class RDM_PQG_class &Gamma_pp ,
						    const class RDM_PQG_class &Gamma_nn ,
						    const class RDM_PQG_class &Gamma_pn ,
						    const class RDM_conditions_class &X_minus_A_Gamma ,
						    const class RDM_conditions_class &Lambda_plus_half_sigma_X_minus_A_Gamma)
{
  const double H_renormalization_factor = X_minus_A_Gamma.get_H_renormalization_factor ();
  
  const TYPE average_E_H_renormalized = average_E_calc (false , inter , 0.0 , H_renormalization_factor , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn);
    
  const TYPE F_Lambda_X_minus_A_Gamma_term = Frobenius_scalar_product (Lambda_plus_half_sigma_X_minus_A_Gamma , X_minus_A_Gamma);
            
  const TYPE F = average_E_H_renormalized + F_Lambda_X_minus_A_Gamma_term;

  return F;  
}






void RDM_optimization_augmented_Lagrangian::BiCG_linear_system_solve_test (
									   const class input_data_str &input_data ,
									   const double sigma ,
									   const double constant_shift ,
									   class block_matrix<TYPE> &Bpp , 
									   class block_matrix<TYPE> &Bnn , 
									   class block_matrix<TYPE> &Bpn , 
									   class block_matrix<TYPE> &Bpp_rho , 
									   class block_matrix<TYPE> &Bnn_rho , 
									   class RDM_conditions_class &V_Gamma ,
									   class RDM_conditions_class &X_Gamma ,
									   class RDM_conditions_class &helper_add ,
									   class RDM_conditions_gradient_class &A_Gamma_gradients ,
									   class RDM_PQG_class &Delta_Gamma_pp ,
									   class RDM_PQG_class &Delta_Gamma_nn ,	
									   class RDM_PQG_class &Delta_Gamma_pn ,
									   class RDM_rho_coupled_modified_class &Delta_rho_pp ,
									   class RDM_rho_coupled_modified_class &Delta_rho_nn)
{	    
  const unsigned int iter_max = 5000;
  
  const bool print_detailed_information = input_data.get_print_detailed_information ();
  
  const double test_vector_solution = input_data.get_test_vector_solution ();

  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information)
    {
      cout << "Calculation of Hessian linear system solution with BiCG" << endl;
      cout << "-------------------------------------------------------" << endl << endl;
    }

  class block_matrix<TYPE> &Xpp = Delta_Gamma_pp.get_block_matrix ();
  class block_matrix<TYPE> &Xnn = Delta_Gamma_nn.get_block_matrix ();
  class block_matrix<TYPE> &Xpn = Delta_Gamma_pn.get_block_matrix ();

  class block_matrix<TYPE> &Xpp_rho = Delta_rho_pp.get_block_matrix ();
  class block_matrix<TYPE> &Xnn_rho = Delta_rho_nn.get_block_matrix ();
  
  class block_matrix<TYPE> Ppp = Xpp , Spp = Xpp , Upp = Xpp , Vpp = Xpp;
  class block_matrix<TYPE> Pnn = Xnn , Snn = Xnn , Unn = Xnn , Vnn = Xnn;
  class block_matrix<TYPE> Ppn = Xpn , Spn = Xpn , Upn = Xpn , Vpn = Xpn;
  
  class block_matrix<TYPE> Ppp_rho = Xpp_rho , Spp_rho = Xpp_rho , Upp_rho = Xpp_rho , Vpp_rho = Xpp_rho;
  class block_matrix<TYPE> Pnn_rho = Xnn_rho , Snn_rho = Xnn_rho , Unn_rho = Xnn_rho , Vnn_rho = Xnn_rho;
  
  Xpp = Bpp;
  Xnn = Bnn;
  Xpn = Bpn;
      
  Xpp_rho = Bpp_rho;
  Xnn_rho = Bnn_rho;
  
  class block_matrix<TYPE> AXpp = Xpp , AXnn = Xnn , AXpn = Xpn , AXpp_rho = Xpp_rho , AXnn_rho = Xnn_rho;
	  
  RDM_Hessian_vector_no_sigma::apply (Xpp , Xnn , Xpn , Xpp_rho , Xnn_rho , V_Gamma , X_Gamma , helper_add , A_Gamma_gradients , AXpp , AXnn , AXpn , AXpp_rho , AXnn_rho);
    
  Ppp = Xpp , Pnn = Xnn , Ppn = Xpn , Ppp_rho = Xpp_rho , Pnn_rho = Xnn_rho;

  Ppp *= constant_shift , Pnn *= constant_shift , Ppn *= constant_shift , Ppp_rho *= constant_shift , Pnn_rho *= constant_shift;

  AXpp += Ppp , AXnn += Pnn , AXpn += Ppn , AXpp_rho += Ppp_rho , AXnn_rho += Pnn_rho;
  
  class block_matrix<TYPE> Rpp = Bpp , Rnn = Bnn , Rpn = Bpn , Rpp_rho = Bpp_rho , Rnn_rho = Bnn_rho;

  Rpp -= AXpp , Rnn -= AXnn , Rpn -= AXpn , Rpp_rho -= AXpp_rho , Rnn_rho -= AXnn_rho;

  const double test_norm_AX_pp_nn = max (Rpp.infinite_norm () , Rnn.infinite_norm ());
  
  const double test_norm_AX_pp_nn_pn = max (test_norm_AX_pp_nn , Rpn.infinite_norm ());
  
  const double test_norm_AX_rho = max (Rpp_rho.infinite_norm () , Rnn_rho.infinite_norm ());
       
  const double test_norm_AX = max (test_norm_AX_pp_nn_pn , test_norm_AX_rho);
  
  if (test_norm_AX < test_vector_solution)
    {      
      Xpp /= sigma , Xnn /= sigma , Xpn /= sigma , Xpp_rho /= sigma , Xnn_rho /= sigma;
      
      return;
    }
  
  Bpp = Rpp , Bnn = Rnn , Bpn = Rpn , Bpp_rho = Rpp_rho , Bnn_rho = Rnn_rho;
  
  Vpp.zero () , Vnn.zero () , Vpn.zero () , Vpp_rho.zero () , Vnn_rho.zero ();
  Ppp.zero () , Pnn.zero () , Ppn.zero () , Ppp_rho.zero () , Pnn_rho.zero ();

  TYPE alpha = 1.0 , omega = 1.0 , rho_bef = 1.0;
  
  for (unsigned int i = 0 ; i < iter_max ; i++) 	
    {      
      const TYPE rho = Frobenius_scalar_product (Bpp , Rpp) + Frobenius_scalar_product (Bnn , Rnn) + Frobenius_scalar_product (Bpn , Rpn) + Frobenius_scalar_product (Bpp_rho , Rpp_rho) + Frobenius_scalar_product (Bnn_rho , Rnn_rho);

      const TYPE beta = (rho/rho_bef)*(alpha/omega);

      Spp  = Vpp   , Snn  = Vnn   , Spn  = Vpn   , Spp_rho  = Vpp_rho , Snn_rho  = Vnn_rho;
      Spp *= omega , Snn *= omega , Spn *= omega , Spp_rho *= omega   , Snn_rho *= omega;
      
      Upp  = Ppp , Unn  = Pnn , Upn  = Ppn , Upp_rho  = Ppp_rho , Unn_rho  = Pnn_rho;
      Upp -= Spp , Unn -= Snn , Upn -= Spn , Upp_rho -= Spp_rho , Unn_rho -= Snn_rho;
      
      Spp  = Upp  , Snn  = Unn  , Spn  = Upn  , Spp_rho  = Upp_rho , Snn_rho  = Unn_rho;
      Spp *= beta , Snn *= beta , Spn *= beta , Spp_rho *= beta    , Snn_rho *= beta;

      Ppp  = Rpp , Pnn  = Rnn , Ppn  = Rpn , Ppp_rho  = Rpp_rho , Pnn_rho  = Rnn_rho;
      Ppp += Spp , Pnn += Snn , Ppn += Spn , Ppp_rho += Spp_rho , Pnn_rho += Snn_rho;
      
      RDM_Hessian_vector_no_sigma::apply (Ppp , Pnn , Ppn , Ppp_rho , Pnn_rho , V_Gamma , X_Gamma , helper_add , A_Gamma_gradients , Vpp , Vnn , Vpn , Vpp_rho , Vnn_rho);
    
      Spp = Ppp , Snn = Pnn , Spn = Ppn , Spp_rho = Ppp_rho , Snn_rho = Pnn_rho;

      Spp *= constant_shift , Snn *= constant_shift , Spn *= constant_shift , Spp_rho *= constant_shift , Snn_rho *= constant_shift;

      Vpp += Spp , Vnn += Snn , Vpn += Spn;
  
      const TYPE Frobenius_scalar_product_BV = Frobenius_scalar_product (Bpp , Vpp) + Frobenius_scalar_product (Bnn , Vnn) + Frobenius_scalar_product (Bpn , Vpn) + Frobenius_scalar_product (Bpp_rho , Vpp_rho) + Frobenius_scalar_product (Bnn_rho , Vnn_rho);
      
      alpha = rho/Frobenius_scalar_product_BV;

      Spp  = Ppp   , Snn  = Pnn   , Spn  = Ppn   , Spp_rho  = Ppp_rho , Snn_rho  = Pnn_rho;
      Spp *= alpha , Snn *= alpha , Spn *= alpha , Spp_rho *= alpha   , Snn_rho *= alpha;

      Xpp += Spp , Xnn += Snn , Xpn += Spn , Xpp_rho += Spp_rho , Xnn_rho += Snn_rho;

      Upp  = Vpp   , Unn  = Vnn   , Upn  = Vpn   , Upp_rho  = Vpp_rho , Unn_rho  = Vnn_rho;
      Upp *= alpha , Unn *= alpha , Upn *= alpha , Upp_rho *= alpha   , Unn_rho *= alpha;

      AXpp += Upp , AXnn += Unn , AXpn += Upn , AXpp_rho += Upp_rho , AXnn_rho += Unn_rho;

      Spp  = AXpp , Snn  = AXnn , Spn  = AXpn , Spp_rho  = AXpp_rho , Snn_rho  = AXnn_rho;
      Spp -= Bpp  , Snn -= Bnn  , Spn -= Bpn  , Spp_rho -= Bpp_rho  , Snn_rho -= Bnn_rho;
      
      const double Res_inf_norm_1_pp_nn = max (Spp.infinite_norm () , Snn.infinite_norm ());
  
      const double Res_inf_norm_1_pp_nn_pn = max (Res_inf_norm_1_pp_nn , Spn.infinite_norm ());
          
      const double Res_inf_norm_1_rho = max (Spp_rho.infinite_norm () , Snn_rho.infinite_norm ());
      
      const double Res_inf_norm_1 = max (Res_inf_norm_1_pp_nn_pn , Res_inf_norm_1_rho);
      
      if (Res_inf_norm_1 < test_vector_solution)
	{
	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "BiCG iteration : " << i << " test : " << Res_inf_norm_1 << endl << endl;
      	  
	  Xpp /= sigma , Xnn /= sigma , Xpn /= sigma , Xpp_rho /= sigma , Xnn_rho /= sigma;
  
	  return;
	}
      
      Spp  = Rpp , Snn  = Rnn , Spn  = Rpn , Spp_rho  = Rpp_rho , Snn_rho  = Rnn_rho;
      Spp -= Upp , Snn -= Unn , Spn -= Upn , Spp_rho -= Upp_rho , Snn_rho -= Unn_rho;

      RDM_Hessian_vector_no_sigma::apply (Spp , Snn , Spn , Spp_rho , Snn_rho , V_Gamma , X_Gamma , helper_add , A_Gamma_gradients , Rpp , Rnn , Rpn , Rpp_rho , Rnn_rho);
      
      Upp = Spp , Unn = Snn , Upn = Spn , Upp_rho = Spp_rho , Unn_rho = Snn_rho;

      Upp *= constant_shift , Unn *= constant_shift , Upn *= constant_shift , Upp_rho *= constant_shift , Unn_rho *= constant_shift;

      Rpp += Upp , Rnn += Unn , Rpn += Upn , Rpp_rho += Upp_rho , Rnn_rho += Unn_rho;

      const TYPE Frobenius_scalar_product_RS = Frobenius_scalar_product (Rpp , Spp) + Frobenius_scalar_product (Rnn , Snn) + Frobenius_scalar_product (Rpn , Spn) + Frobenius_scalar_product (Rpp_rho , Spp_rho) + Frobenius_scalar_product (Rnn_rho , Snn_rho);

      const TYPE Frobenius_squared_norm_R = Frobenius_scalar_product (Rpp , Rpp) + Frobenius_scalar_product (Rnn , Rnn) + Frobenius_scalar_product (Rpn , Rpn) + Frobenius_scalar_product (Rpp_rho , Rpp_rho) + Frobenius_scalar_product (Rnn_rho , Rnn_rho);
            
      omega = Frobenius_scalar_product_RS/Frobenius_squared_norm_R;

      Upp  = Spp   , Unn  = Snn   , Upn  = Spn   , Upp_rho  = Spp_rho , Unn_rho  = Snn_rho;
      Upp *= omega , Unn *= omega , Upn *= omega , Upp_rho *= omega   , Unn_rho *= omega;

      Xpp += Upp , Xnn += Unn , Xpn += Upn , Xpp_rho += Upp_rho , Xnn_rho += Unn_rho;

      Upp  = Rpp   , Unn  = Rnn   , Upn  = Rpn   , Upp_rho  = Rpp_rho , Unn_rho  = Rnn_rho;
      Upp *= omega , Unn *= omega , Upn *= omega , Upp_rho *= omega   , Unn_rho *= omega;

      AXpp += Upp , AXnn += Unn , AXpn += Upn , AXpp_rho += Upp_rho , AXnn_rho += Unn_rho; 
      
      const double Res_inf_norm_2_pp_nn = max (Upp.infinite_norm () , Unn.infinite_norm ());
  
      const double Res_inf_norm_2_pp_nn_pn = max (Res_inf_norm_2_pp_nn , Upn.infinite_norm ());
          
      const double Res_inf_norm_2_rho = max (Upp_rho.infinite_norm () , Unn_rho.infinite_norm ());
      
      const double Res_inf_norm_2 = max (Res_inf_norm_2_pp_nn_pn , Res_inf_norm_2_rho);
      
      if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << "BiCG iteration : " << i << " test : " << Res_inf_norm_2 << endl;
      
      if (Res_inf_norm_2 < test_vector_solution)
	{
	  if ((THIS_PROCESS == MASTER_PROCESS) && print_detailed_information) cout << endl;
  
	  Xpp /= sigma , Xnn /= sigma , Xpn /= sigma , Xpp_rho /= sigma , Xnn_rho /= sigma;
      
	  return;
	}
      
      Rpp  = Spp , Rnn  = Snn , Rpn  = Spn , Rpp_rho  = Spp_rho , Rnn_rho  = Snn_rho;
      Rpp -= Upp , Rnn -= Unn , Rpn -= Upn , Rpp_rho -= Upp_rho , Rnn_rho -= Unn_rho;
      
      rho_bef = rho;                  
    }
  
  error_message_print_abort ("Too many iterations in the Hessian BiCG method in the augmented Lagrangian optimization");
}








void RDM_optimization_augmented_Lagrangian::E_minimization (
							    const class input_data_str &input_data , 
							    const class nucleons_data &prot_data ,
							    const class nucleons_data &neut_data , 
							    const class TBMEs_class &TBMEs_pn ,
							    class RDM_PQG_class &Gamma_pp ,
							    class RDM_PQG_class &Gamma_nn ,
							    class RDM_PQG_class &Gamma_pn ,
							    class RDM_rho_coupled_modified_class &rho_coupled_modified_pp ,
							    class RDM_rho_coupled_modified_class &rho_coupled_modified_nn)
{
  const unsigned int iter_max = 50000;
    
  const enum space_type space = input_data.get_space ();

  const enum interaction_type inter = input_data.get_inter ();

  const bool truncation_hw = input_data.get_truncation_hw ();
  const bool truncation_ph = input_data.get_truncation_ph ();
  
  const int E_max_hw = input_data.get_E_max_hw();

  const int n_scat_max = input_data.get_n_scat_max ();
		
  const bool is_it_BiCG = input_data.get_RDM_is_it_BiCG ();
      
  const enum RDM_matrix_constraint_type RDM_matrix_constraint = input_data.get_RDM_matrix_constraint ();

  const bool J_constrained = input_data.get_RDM_are_there_J_constraints ();

  const bool CM_corrected = input_data.get_RDM_is_there_CM_correction ();
  
  const bool T_constrained = input_data.get_RDM_is_there_isospin_constraint ();

  const double E_minimization_precision = input_data.get_RDM_E_minimization_precision ();

  const double sigma_init = input_data.get_RDM_sigma_init ();
		   
  const double multiplicative_sigma_step = input_data.get_RDM_multiplicative_sigma_step ();
  
  const double smallness_factor = input_data.get_RDM_smallness_factor ();
						 
  const double J = input_data.get_RDM_J ();

  const bool is_there_E_ref = input_data.get_RDM_is_there_E_reference ();
  
  const TYPE E_ref = input_data.get_RDM_E_reference ();
  
  const double x = input_data.get_RDM_Hamiltonian_renormalization_factor ();
        
  class RDM_PQG_class Delta_Gamma_pp = Gamma_pp;
  class RDM_PQG_class Delta_Gamma_nn = Gamma_nn;
  class RDM_PQG_class Delta_Gamma_pn = Gamma_pn;
  
  class RDM_rho_coupled_modified_class Delta_rho_pp = rho_coupled_modified_pp;
  class RDM_rho_coupled_modified_class Delta_rho_nn = rho_coupled_modified_nn;
  
  class block_matrix<TYPE> F_der_pp = Gamma_pp.get_block_matrix () , Vstore_pp = F_der_pp , HVpp = F_der_pp;
  class block_matrix<TYPE> F_der_nn = Gamma_nn.get_block_matrix () , Vstore_nn = F_der_nn , HVnn = F_der_nn;
  class block_matrix<TYPE> F_der_pn = Gamma_pn.get_block_matrix () , Vstore_pn = F_der_pn , HVpn = F_der_pn;

  class block_matrix<TYPE> F_der_rho_pp = rho_coupled_modified_pp.get_block_matrix () , Vstore_rho_pp = F_der_rho_pp , HVpp_rho = F_der_rho_pp;
  class block_matrix<TYPE> F_der_rho_nn = rho_coupled_modified_nn.get_block_matrix () , Vstore_rho_nn = F_der_rho_nn , HVnn_rho = F_der_rho_nn;
  
  class RDM_conditions_class A_Gamma_zero(inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class A_Gamma     (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class B_Gamma     (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class C_Gamma     (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class Lambda      (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class X           (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);
  class RDM_conditions_class helper_add  (inter , TBMEs_pn , RDM_matrix_constraint , CM_corrected , T_constrained , J_constrained , is_there_E_ref , truncation_hw , truncation_ph , E_max_hw , n_scat_max , J , E_ref , x , prot_data , neut_data);

  class RDM_conditions_gradient_class A_Gamma_gradients(inter , TBMEs_pn , prot_data , neut_data , A_Gamma);
	
  const unsigned int Hessian_vector_dimension = RDM_Hessian_vector_no_sigma::dimension_calc (F_der_pp , F_der_nn , F_der_pn , F_der_rho_pp , F_der_rho_nn);
      
  if (THIS_PROCESS == MASTER_PROCESS)
    {       
      cout << endl << "Augmented Lagrangian method" << endl;

      cout << "---------------------------" << endl << endl;
	  
      cout << "Hessian matrix dimension : " << Hessian_vector_dimension << endl << endl;
    }
  
  class array<bool> is_it_rho_tab;
  class array<enum space_type> spaces;
  class array<unsigned short int> i_part_indices;
  class array<unsigned short int> ii_indices; 
  class array<unsigned short int> jj_indices;
  
  class matrix<TYPE> LU_Cholesky_Hessian_matrix_no_sigma;

  class vector_class<TYPE> B_LU_Cholesky;
  class vector_class<TYPE> X_LU_Cholesky;
  
  if (!is_it_BiCG)
    {
      RDM_Hessian_linear_system_LU_Cholesky::matrix_no_sigma_alloc_calc_store (input_data , B_Gamma , C_Gamma , helper_add , A_Gamma_gradients , Vstore_pp , Vstore_nn , Vstore_pn , Vstore_rho_pp , Vstore_rho_nn ,
									       HVpp , HVnn , HVpn , HVpp_rho , HVnn_rho , is_it_rho_tab , spaces , i_part_indices , ii_indices , jj_indices , LU_Cholesky_Hessian_matrix_no_sigma);

      B_LU_Cholesky.allocate (Hessian_vector_dimension);
      X_LU_Cholesky.allocate (Hessian_vector_dimension);      
    }
  
  Delta_Gamma_pp.zero ();
  Delta_Gamma_nn.zero ();
  Delta_Gamma_pn.zero ();
            
  Delta_rho_pp.zero ();
  Delta_rho_nn.zero ();
  
  A_Gamma_zero.A_Gamma_calc (Delta_Gamma_pp , Delta_Gamma_nn , Delta_Gamma_pn , Delta_rho_pp , Delta_rho_nn);
        
  double sigma = sigma_init;
        
  double test = 1E6;

  unsigned int iter = 0;
    
  A_Gamma.A_Gamma_calc (A_Gamma_zero , Gamma_pp , Gamma_nn , Gamma_pn , rho_coupled_modified_pp , rho_coupled_modified_nn , helper_add , A_Gamma_gradients);
            
  X = A_Gamma;
  
  Lambda.zero ();
    
  B_Gamma.zero ();
      
  while ((test > E_minimization_precision) && (iter++ < iter_max))
    {
      const double constant_shift = 0.5*test;
      
      if (THIS_PROCESS == MASTER_PROCESS)
	{            
      	  cout << endl << "Iteration " << iter << endl;

	  cout << "----------------------------" << endl << endl;
	}
      
      all_F_der_calc (inter , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , A_Gamma , X , Lambda , A_Gamma_gradients ,
		      sigma , B_Gamma , Vstore_pp , Vstore_nn , Vstore_pn , F_der_pp , F_der_nn , F_der_pn , F_der_rho_pp , F_der_rho_nn);
             
      if (is_it_BiCG)
	{
	  Delta_Gamma_pp.double_counting_scaling ();
	  Delta_Gamma_nn.double_counting_scaling ();
	  Delta_Gamma_pn.double_counting_scaling ();
      
	  Delta_rho_pp.double_counting_scaling ();
	  Delta_rho_nn.double_counting_scaling ();
	  
	  BiCG_linear_system_solve_test (input_data , sigma , constant_shift , F_der_pp ,  F_der_nn , F_der_pn , F_der_rho_pp ,  F_der_rho_nn ,
					 B_Gamma , C_Gamma , helper_add , A_Gamma_gradients , Delta_Gamma_pp , Delta_Gamma_nn , Delta_Gamma_pn , Delta_rho_pp , Delta_rho_nn);
	  
	  Delta_Gamma_pp.double_counting_removal ();
	  Delta_Gamma_nn.double_counting_removal ();
	  Delta_Gamma_pn.double_counting_removal ();
	  
	  Delta_rho_pp.double_counting_removal ();
	  Delta_rho_nn.double_counting_removal ();
	}
      else
	RDM_Hessian_linear_system_LU_Cholesky::linear_system_solve (sigma , F_der_pp ,  F_der_nn , F_der_pn , F_der_rho_pp ,  F_der_rho_nn , 
								    is_it_rho_tab , spaces , i_part_indices , ii_indices , jj_indices , LU_Cholesky_Hessian_matrix_no_sigma , B_LU_Cholesky , X_LU_Cholesky ,
								    Delta_Gamma_pp , Delta_Gamma_nn , Delta_Gamma_pn , Delta_rho_pp , Delta_rho_nn);       

      Gamma_pp -= Delta_Gamma_pp;
      Gamma_nn -= Delta_Gamma_nn;
      Gamma_pn -= Delta_Gamma_pn;
    
      rho_coupled_modified_pp -= Delta_rho_pp;
      rho_coupled_modified_nn -= Delta_rho_nn;
	  
      A_Gamma.A_Gamma_calc (A_Gamma_zero , Gamma_pp , Gamma_nn , Gamma_pn , rho_coupled_modified_pp , rho_coupled_modified_nn , helper_add , A_Gamma_gradients);

      all_F_der_calc (inter , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , A_Gamma , X , Lambda , A_Gamma_gradients , sigma ,
		      B_Gamma , Vstore_pp , Vstore_nn , Vstore_pn , F_der_pp , F_der_nn , F_der_pn , F_der_rho_pp ,  F_der_rho_nn);
      
      const double F_der_norm_bef_X_positive_definite_pp_nn = max (F_der_pp.infinite_norm () , F_der_nn.infinite_norm ());
  
      const double F_der_norm_bef_X_positive_definite_pp_nn_pn = max (F_der_norm_bef_X_positive_definite_pp_nn , F_der_pn.infinite_norm ());
            
      const double F_der_norm_bef_X_positive_definite_rho = max (F_der_rho_pp.infinite_norm () , F_der_rho_nn.infinite_norm ());
      
      const double F_der_norm_bef_X_positive_definite = max (F_der_norm_bef_X_positive_definite_pp_nn_pn , F_der_norm_bef_X_positive_definite_rho);
      
      B_Gamma = Lambda;
      B_Gamma /= sigma;
      
      X  = A_Gamma;
      X -= B_Gamma;
      
      X.impose_positive_definiteness_zero_conditions_rho_N_representability (B_Gamma , C_Gamma);
	
      all_F_der_calc (inter , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , A_Gamma , X , Lambda , A_Gamma_gradients ,
		      sigma , B_Gamma , Vstore_pp , Vstore_nn , Vstore_pn , F_der_pp , F_der_nn , F_der_pn , F_der_rho_pp ,  F_der_rho_nn);
      	           
      const double F_der_norm_aft_X_positive_definite_pp_nn = max (F_der_pp.infinite_norm () , F_der_nn.infinite_norm ());
  
      const double F_der_norm_aft_X_positive_definite_pp_nn_pn = max (F_der_norm_aft_X_positive_definite_pp_nn , F_der_pn.infinite_norm ());
            
      const double F_der_norm_aft_X_positive_definite_rho = max (F_der_rho_pp.infinite_norm () , F_der_rho_nn.infinite_norm ());
      
      const double F_der_norm_aft_X_positive_definite = max (F_der_norm_aft_X_positive_definite_pp_nn_pn , F_der_norm_aft_X_positive_definite_rho);
      
      const double F_der_norm = smallness_factor*F_der_norm_aft_X_positive_definite;
            
      B_Gamma  = X;
      B_Gamma -= A_Gamma;

      const double X_minus_A_Gamma_norm = B_Gamma.infinite_norm ();
      
      C_Gamma = B_Gamma;

      // Initial formulas is with 1/2 sigma. Modification afterwards from Jianguo's tests.
      // C_Gamma *= 0.5*sigma;
      
      C_Gamma *= sigma;
      
      C_Gamma += Lambda;
      	  
      const TYPE F = F_calc (inter , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , B_Gamma , C_Gamma);
      
      C_Gamma  = B_Gamma;
      C_Gamma *= sigma;
      
      Lambda += C_Gamma;
            
      if (F_der_norm > 10*X_minus_A_Gamma_norm)
	sigma /= multiplicative_sigma_step;
      else if (F_der_norm < 0.1*X_minus_A_Gamma_norm)
	sigma *= multiplicative_sigma_step;
            
      if (THIS_PROCESS == MASTER_PROCESS)
	{	  
	  cout << "Conditions and observables " << endl;
	  cout << "---------------------------" << endl << endl;
	  
	  cout << "sigma : " << sigma << endl << endl;
	  
	  cout << "grad[F] precision before X >= 0 : " << F_der_norm_bef_X_positive_definite << endl;
	  cout << "grad[F] precision after  X >= 0 : " << F_der_norm_aft_X_positive_definite << endl << endl;
	        
	  RDM_print_calc_observables_test_conditions (space , inter , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , A_Gamma , J , F , F_der_norm , X_minus_A_Gamma_norm);            
	}
 	  
      test = max (F_der_norm , X_minus_A_Gamma_norm);
        
      if (iter == iter_max) error_message_print_abort ("Too many iterations for the Newton method in the augmented Lagrangian optimization");
    }
}




