#include "../RDM_include/RDM_include_def.h"


using namespace inputs_misc;
using namespace Wigner_signs;
using namespace correlated_state_routines;


RDM_rho_coupled_modified_class::RDM_rho_coupled_modified_class ()
  : jmax_ab_global (0) ,
    particles_data_ptr (NULL) {}

RDM_rho_coupled_modified_class::RDM_rho_coupled_modified_class (const bool are_there_J_constraints , const double J , const class nucleons_data &particles_data)
  : jmax_ab_global (0) ,
    particles_data_ptr (NULL)
{
  allocate (are_there_J_constraints , J , particles_data);
}



RDM_rho_coupled_modified_class::RDM_rho_coupled_modified_class (const class RDM_rho_coupled_modified_class &X)
{
  allocate_fill (X);
}

RDM_rho_coupled_modified_class::~RDM_rho_coupled_modified_class () {}



void RDM_rho_coupled_modified_class::allocate (const bool are_there_J_constraints , const double J , const class nucleons_data &particles_data)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_rho_coupled_modified_class cannot be allocated twice in RDM_rho_coupled_modified_class::allocate");

  particles_data_ptr = &particles_data;

  const unsigned int N_nlj = particles_data.get_N_nlj ();
  
  if (N_nlj == 0) return;

  if (!are_there_J_constraints) return;
    
  const int two_J = make_int (2.0*J);
  		
  const double jmax = particles_data.get_jmax ();
  
  const int two_jmax = make_int (2.0*jmax); 
    
  jmax_ab_global = min (two_jmax , two_J);

  if (jmax_ab_global == 0) return;
  
  const double m_max = particles_data.get_m_max ();
  
  const int two_m_max = particles_data.get_two_m_max ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const int jmax_ab_global_plus_one = jmax_ab_global + 1;
  
  const int two_m_max_plus_one = two_m_max + 1;
 
  CGs.allocate_calc (m_max);
    
  const unsigned int N_nlj_positive_parity = N_nlj_fixed_parity_determine (0 , shells_qn);
  const unsigned int N_nlj_negative_parity = N_nlj_fixed_parity_determine (1 , shells_qn);

  const unsigned int N_nlj_fixed_parity_tab[2] = {N_nlj_positive_parity , N_nlj_negative_parity};
  
  shells_indices_fixed_parity.allocate (2 , N_nlj);
  
  class array<unsigned int> shell_index_fixed_parity_tab(2);
  
  shell_index_fixed_parity_tab = 0;
  
  for (unsigned int s = 0 ; s < N_nlj ; s++)
    {
      const class nlj_struct &shell_qn_s = shells_qn(s);
      
      const int l = shell_qn_s.get_l ();

      const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
      
      shells_indices_fixed_parity(bp , s) = shell_index_fixed_parity_tab(bp)++;
    }
  
  class array<unsigned int> block_matrix_dimensions_coupled(2*jmax_ab_global_plus_one);

  class array<unsigned int> block_matrix_dimensions_uncoupled(2*two_m_max_plus_one);
  
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    {
      for (int j = 0 ; j <= jmax_ab_global ; j++) block_matrix_dimensions_coupled(bp + 2*j) = N_nlj_fixed_parity_tab[bp];
  
      for (int im = 0 ; im <= two_m_max ; im++) block_matrix_dimensions_uncoupled(bp + 2*im) = N_nlj_fixed_parity_tab[bp];
    }
  
  rho_coupled_modified_block_matrix.allocate (block_matrix_dimensions_coupled);
    
  rho_uncoupled_block_matrix.allocate (block_matrix_dimensions_uncoupled);
  
  zero ();
  
  const unsigned int dimension_rho_coupled_modified = rho_coupled_modified_block_matrix.get_dimension ();
  
  rho_coupled_modified_block_matrix_array_helper.allocate (dimension_rho_coupled_modified);
}





void RDM_rho_coupled_modified_class::allocate_fill (const class RDM_rho_coupled_modified_class &X)
{
  if (is_it_filled ()) error_message_print_abort ("RDM_rho_coupled_modified_class cannot be allocated twice in RDM_rho_coupled_modified_class::allocate_fill");
    
  particles_data_ptr = X.particles_data_ptr;
  
  jmax_ab_global = X.jmax_ab_global;
    
  CGs.allocate_fill (X.CGs);
    
  rho_coupled_modified_block_matrix.allocate_fill (X.rho_coupled_modified_block_matrix);
    
  rho_uncoupled_block_matrix.allocate_fill (X.rho_uncoupled_block_matrix);
  
  shells_indices_fixed_parity.allocate_fill (X.shells_indices_fixed_parity);

  rho_coupled_modified_block_matrix_array_helper.allocate_fill (X.rho_coupled_modified_block_matrix_array_helper);
}





void RDM_rho_coupled_modified_class::deallocate ()
{  
  particles_data_ptr = NULL;
  
  jmax_ab_global = 0;
  
  CGs.deallocate ();
        
  rho_coupled_modified_block_matrix.deallocate ();
    
  rho_uncoupled_block_matrix.deallocate ();
  
  shells_indices_fixed_parity.deallocate ();
  
  rho_uncoupled_block_matrix_eigenvalues.deallocate ();
  
  rho_coupled_modified_block_matrix_array_helper.deallocate ();
  
  T_MPI.deallocate ();
}







void RDM_rho_coupled_modified_class::block_matrix_fill (const class block_matrix<TYPE> &X)
{
  rho_coupled_modified_block_matrix = X;
}

void RDM_rho_coupled_modified_class::random_positive_definite ()
{
  rho_uncoupled_block_matrix.symmetric_random_matrix ();

  rho_uncoupled_block_matrix /= rho_uncoupled_block_matrix.get_dimension ();
  
  rho_uncoupled_block_matrix.add_scalar_diagonal_part (1.0);
  
  rho_uncoupled_block_matrix *= 0.001;

  rho_coupled_modified_from_rho_uncoupled ();
}

void RDM_rho_coupled_modified_class::operator = (const class RDM_rho_coupled_modified_class &X)
{
  rho_coupled_modified_block_matrix = X.rho_coupled_modified_block_matrix;
}

void RDM_rho_coupled_modified_class::operator += (const class RDM_rho_coupled_modified_class &X)
{
  rho_coupled_modified_block_matrix += X.rho_coupled_modified_block_matrix;
}

void RDM_rho_coupled_modified_class::operator -= (const class RDM_rho_coupled_modified_class &X)
{
  rho_coupled_modified_block_matrix -= X.rho_coupled_modified_block_matrix;
}

void RDM_rho_coupled_modified_class::add_scalar_diagonal_part (const TYPE &x)
{
  rho_coupled_modified_block_matrix.add_scalar_diagonal_part (x);
}

void RDM_rho_coupled_modified_class::remove_scalar_diagonal_part (const TYPE &x)
{
  rho_coupled_modified_block_matrix.remove_scalar_diagonal_part (x);
}

void RDM_rho_coupled_modified_class::operator *= (const TYPE &x)
{
  rho_coupled_modified_block_matrix *= x;
}

void RDM_rho_coupled_modified_class::operator /= (const TYPE &x)
{
  rho_coupled_modified_block_matrix /= x;
}

void RDM_rho_coupled_modified_class::zero ()
{
  rho_coupled_modified_block_matrix.zero ();
}

void RDM_rho_coupled_modified_class::identity ()
{
  rho_coupled_modified_block_matrix.identity ();
}

void RDM_rho_coupled_modified_class::double_counting_scaling ()
{
  rho_coupled_modified_block_matrix *= 0.5;

  rho_coupled_modified_block_matrix.diagonal_part (rho_coupled_modified_block_matrix_array_helper);
  
  rho_coupled_modified_block_matrix.add_array_diagonal_part (rho_coupled_modified_block_matrix_array_helper);
}

void RDM_rho_coupled_modified_class::double_counting_removal ()
{
  rho_coupled_modified_block_matrix.diagonal_part (rho_coupled_modified_block_matrix_array_helper);

  rho_coupled_modified_block_matrix *= 2.0;

  rho_coupled_modified_block_matrix.remove_array_diagonal_part (rho_coupled_modified_block_matrix_array_helper);
}



unsigned int RDM_rho_coupled_modified_class::get_block_symmetric_matrix_elements_number () const
{
  const unsigned int blocks_number = rho_coupled_modified_block_matrix.get_blocks_number ();

  unsigned int block_symmetric_matrix_elements_number = 0;
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const unsigned int dimension_block = rho_coupled_modified_block_matrix(i).get_dimension ();
      
      block_symmetric_matrix_elements_number += (dimension_block%2 == 0) ? ((dimension_block/2)*(dimension_block + 1)) : (dimension_block*((dimension_block + 1)/2));
    }
  
  return block_symmetric_matrix_elements_number;
}


TYPE RDM_rho_coupled_modified_class::Frobenius_squared_norm () const
{
  return rho_coupled_modified_block_matrix.Frobenius_squared_norm ();
}

double RDM_rho_coupled_modified_class::infinite_norm () const
{
  return rho_coupled_modified_block_matrix.infinite_norm ();
}




void RDM_rho_coupled_modified_class::rho_coupled_modified_from_rho_uncoupled ()
{
  const class nucleons_data &particles_data = get_particles_data ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const double m_max = particles_data.get_m_max ();
    
  const int m_max_minus_half = particles_data.get_m_max_minus_half ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  rho_coupled_modified_block_matrix.zero ();
  
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int j = 0 ; j <= jmax_ab_global ; j++)
      {
	class matrix<TYPE> &rho_coupled_modified_block_matrix_bp_j = rho_coupled_modified_block_matrix(bp + 2*j);
	
	for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	  {
	    const class nlj_struct &shell_qn_sa = shells_qn(sa);

	    const int la = shell_qn_sa.get_l ();

	    const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);

	    if (bp_a != bp) continue;
		
	    const unsigned int sa_fixed_parity = shells_indices_fixed_parity (bp , sa);
  
	    const double ja = shell_qn_sa.get_j ();
		
	    const int ija = shell_qn_sa.get_ij ();
      
	    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	      {
		const class nlj_struct &shell_qn_sb = shells_qn(sb);
		
		const int lb = shell_qn_sb.get_l ();

		const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);

		if (bp_b != bp) continue;
	  	    
		const int ijb = shell_qn_sb.get_ij ();
	      	      
		const int jmin_ab = abs (ijb - ija);
	      
		const int jmax_ab = ija + ijb + 1;
	      
		if ((j < jmin_ab) || (j > jmax_ab)) continue;

		const unsigned int sb_fixed_parity = shells_indices_fixed_parity (bp , sb);
		
		const double jb = shell_qn_sb.get_j ();
		
		const int ij = min (ija , ijb);
		
		const int ja_plus_jb = ija + ijb + 1;
		
		const int ja_plus_jb_mod_two = ja_plus_jb%2;
	
		const int im_min = -ij + m_max_minus_half;
		const int im_max =  ij + m_max_minus_half + 1;

		for (int im = im_min ; im <= im_max ; im++)
		  {
		    const int m_plus_half = im - m_max_minus_half;
		    
		    const double m = im - m_max;
			  
		    const class matrix<TYPE> &rho_uncoupled_block_matrix_bp_m = rho_uncoupled_block_matrix(bp + 2*im);

		    const double CG_phase = (ja_plus_jb_mod_two == m_plus_half%2) ? (CGs(ja , m , jb , -m , j , 0)) : (-CGs(ja , m , jb , -m , j , 0));

		    rho_coupled_modified_block_matrix_bp_j(sa_fixed_parity , sb_fixed_parity) += CG_phase*rho_uncoupled_block_matrix_bp_m(sa_fixed_parity , sb_fixed_parity);
		  }	      
	      }      
	  }
      }
}





void RDM_rho_coupled_modified_class::rho_uncoupled_from_rho_coupled_modified ()
{  
  const class nucleons_data &particles_data = get_particles_data ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
    
  const double m_max = particles_data.get_m_max ();
  
  const int two_m_max = particles_data.get_two_m_max ();
    
  const int m_max_minus_half = particles_data.get_m_max_minus_half ();
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();

  rho_uncoupled_block_matrix.zero ();
  
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int im = 0 ; im <= two_m_max ; im++)
      {
	const double m = im - m_max;
	
	const int m_plus_half = im - m_max_minus_half;
	
	const int m_plus_half_mod_two = m_plus_half%2;
	    
	class matrix<TYPE> &rho_uncoupled_block_block_matrix_bp_m = rho_uncoupled_block_matrix(bp + 2*im);
		  
	for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	  {
	    const class nlj_struct &shell_qn_sa = shells_qn(sa);

	    const int la = shell_qn_sa.get_l ();

	    const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);

	    if (bp_a != bp) continue;
		
	    const unsigned int sa_fixed_parity = shells_indices_fixed_parity (bp , sa);
	    
	    const double ja = shell_qn_sa.get_j ();
	    
	    const int ija = shell_qn_sa.get_ij ();

	    if ((m_plus_half < -ija) || (m_plus_half > ija + 1)) continue;
		    
	    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	      {
		const class nlj_struct &shell_qn_sb = shells_qn(sb);

		const int lb = shell_qn_sb.get_l ();

		const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);
	      			
		if (bp_b != bp) continue;
	    
		const int ijb = shell_qn_sb.get_ij ();
		
		if ((m_plus_half < -ijb) || (m_plus_half > ijb + 1)) continue;
	  
		const unsigned int sb_fixed_parity = shells_indices_fixed_parity (bp , sb);
	    
		const double jb = shell_qn_sb.get_j ();
		
		const int jmin_ab = abs (ijb - ija);
	      
		const int jmax_ab_local = ija + ijb + 1;
		
		const int jmax_ab = min (jmax_ab_local , jmax_ab_global);
	      
		const int ja_plus_jb = ija + ijb + 1;
		
		for (int j = jmin_ab ; j <= jmax_ab ; j++)
		  {			  
		    const class matrix<TYPE> &rho_coupled_modified_block_matrix_bp_j = rho_coupled_modified_block_matrix(bp + 2*j);

		    const double CG_phase = (ja_plus_jb%2 == m_plus_half_mod_two) ? (CGs(ja , m , jb , -m , j , 0)) : (-CGs(ja , m , jb , -m , j , 0));
		    
		    rho_uncoupled_block_block_matrix_bp_m(sa_fixed_parity , sb_fixed_parity) += CG_phase*rho_coupled_modified_block_matrix_bp_j(sa_fixed_parity , sb_fixed_parity);
		  }	      
	      }      
	  }
      }
}





void RDM_rho_coupled_modified_class::make_it_N_representable (
							      class block_matrix<TYPE> &P_transpose ,
							      class block_matrix<TYPE> &Dp_P_transpose)
{  
  if (jmax_ab_global == 0) return;

  const unsigned int dimension_rho_uncoupled = rho_uncoupled_block_matrix.get_dimension ();

  if (dimension_rho_uncoupled == 0) return;

  rho_uncoupled_from_rho_coupled_modified ();
  
  const unsigned int dimension_rho_uncoupled_minus_one = dimension_rho_uncoupled - 1;
    
  P_transpose = rho_uncoupled_block_matrix;
  
  P_transpose.symmetrize ();
  
  if (!rho_uncoupled_block_matrix_eigenvalues.is_it_filled ()) rho_uncoupled_block_matrix_eigenvalues.allocate (dimension_rho_uncoupled);
  
  total_diagonalization::all_eigenpairs_Householder (P_transpose , rho_uncoupled_block_matrix_eigenvalues);
  
  if ((real_dc (rho_uncoupled_block_matrix_eigenvalues(0)) >= 0.0) && (real_dc (rho_uncoupled_block_matrix_eigenvalues(dimension_rho_uncoupled_minus_one)) <= 1.0)) return;

  Dp_P_transpose = P_transpose;
  
  for (unsigned int i = 0 ; i < dimension_rho_uncoupled ; i++) Dp_P_transpose.multiply_scalar_row_vector (i , delta_real_part_inside_01 (rho_uncoupled_block_matrix_eigenvalues(i)));
  
  class block_matrix<TYPE> &P = P_transpose;

  P.transpose ();

  block_matrix_multiplication (P , Dp_P_transpose , rho_uncoupled_block_matrix);
  
  rho_coupled_modified_from_rho_uncoupled ();
}




void RDM_rho_coupled_modified_class::read_from_file (
						     const int Z ,
						     const int N ,
						     const unsigned int RDM_BP ,
						     const double RDM_J ,
						     const unsigned int RDM_vector_index)
{
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in RDM_rho_coupled_modified_class::read_from_file");
        
  const class nucleons_data &particles_data = get_particles_data ();
  
  const unsigned int N_nlj = particles_data.get_N_nlj ();
      
  if (N_nlj == 0) return;

  const enum particle_type particle = particles_data.get_particle ();
  
  const enum dagger_tilde_operator_type dagger_tilde_operator = (particle == PROTON) ? (RHO_COUPLED_REDUCED_RDM_PP) : (RHO_COUPLED_REDUCED_RDM_NN);
  
  const class array<class nlj_struct> &shells_qn = particles_data.get_shells_quantum_numbers ();
  
  const class correlated_state_str PSI_qn(Z , N , RDM_BP , RDM_J , RDM_vector_index , NADA , NADA , NADA , NADA , false);
  
  const string dagger_tilde_operator_string = dagger_tilde_operator_for_file_name (dagger_tilde_operator);
  
  const string PSI_qn_string  = PSI_quantum_numbers_string_for_file_name (PSI_qn);
      
  const string infile_name = STORAGE_DIR + dagger_tilde_operator_string + "_" + PSI_qn_string;
  
  const int jmax_ab_global_plus_one = jmax_ab_global + 1;
  
  class array<TYPE> rho_coupled_reduced_RDM_array(N_nlj , N_nlj , jmax_ab_global_plus_one);
  
  rho_coupled_reduced_RDM_array.read_disk (infile_name);
    
  for (unsigned int bp = 0 ; bp <= 1 ; bp++)
    for (int j = 0 ; j <= jmax_ab_global ; j++)
      {
	const class matrix<TYPE> &rho_coupled_modified_block_matrix_bp_j = rho_coupled_modified_block_matrix(bp + 2*j);
	
	for (unsigned int sa = 0 ; sa < N_nlj ; sa++)
	  {
	    const class nlj_struct &shell_qn_sa = shells_qn(sa);

	    const int la = shell_qn_sa.get_l ();

	    const unsigned int bp_a = binary_parity_from_orbital_angular_momentum (la);

	    if (bp_a != bp) continue;
		
	    const unsigned int sa_fixed_parity = shells_indices_fixed_parity (bp , sa);
  
	    const int ija = shell_qn_sa.get_ij ();

	    const int phase = minus_one_pow (ija);
      
	    for (unsigned int sb = 0 ; sb < N_nlj ; sb++)
	      {
		const class nlj_struct &shell_qn_sb = shells_qn(sb);

		const int lb = shell_qn_sb.get_l ();

		const unsigned int bp_b = binary_parity_from_orbital_angular_momentum (lb);

		if (bp_b != bp) continue;
	  
		const unsigned int sb_fixed_parity = shells_indices_fixed_parity (bp , sb);
	    
		const int ijb = shell_qn_sb.get_ij ();
	      	      
		const int jmin_ab = abs (ijb - ija);
	      
		const int jmax_ab = ija + ijb + 1;
	      
		if ((j < jmin_ab) || (j > jmax_ab)) continue;

		const TYPE rho_coupled_reduced_ME = rho_coupled_reduced_RDM_array(sa , sb , j);
		
		rho_coupled_modified_block_matrix_bp_j(sa_fixed_parity , sb_fixed_parity) = phase*ME_dereduced (rho_coupled_reduced_ME , j , 0 , RDM_J , RDM_J , RDM_J , RDM_J);
	      }      
	  }
      }
}




#ifdef UseMPI

void RDM_rho_coupled_modified_class::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = rho_coupled_modified_block_matrix.get_blocks_number ();

  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  if (THIS_PROCESS == Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      T_MPI(index++) = block(ii , jj);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Bcast(send).");
    }
  
  T_MPI.MPI_Bcast (Send_process , MPI_C);
  
  if (THIS_PROCESS != Send_process)
    {      
      unsigned int index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Bcast(receive).");
    }
}

void RDM_rho_coupled_modified_class::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = rho_coupled_modified_block_matrix.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Reduce(send).");
  
  T_MPI.MPI_Reduce (op , Recv_process , process , MPI_C);
  
  if (THIS_PROCESS == Recv_process)
    {      
      index = 0;
      
      for (unsigned int i = 0 ; i < blocks_number ; i++)
	{
	  const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

	  const unsigned int block_dimension = block.get_dimension ();
	  
	  for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	    for (unsigned int jj = 0 ; jj <= ii ; jj++)
	      block(ii , jj) = block(jj , ii) = T_MPI(index++);
	}
      
      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Reduce(receive).");
    }
}

void RDM_rho_coupled_modified_class::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = rho_coupled_modified_block_matrix.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Allreduce(send).");
  
  T_MPI.MPI_Allreduce (op , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Allreduce(receive).");
}

void RDM_rho_coupled_modified_class::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int N = (!T_MPI.is_it_filled ()) ? (get_block_symmetric_matrix_elements_number ()) : (T_MPI.dimension (0));

  const unsigned int blocks_number = rho_coupled_modified_block_matrix.get_blocks_number ();
    
  unsigned int index = 0;
      
  if (!T_MPI.is_it_filled ()) T_MPI.allocate (N);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  T_MPI(index++) = block(ii , jj);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Allgatherv(send).");
  
  T_MPI.MPI_Allgatherv (group_processes_number , MPI_C);
  
  index = 0;
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<TYPE> &block = rho_coupled_modified_block_matrix(i);

      const unsigned int block_dimension = block.get_dimension ();
	  
      for (unsigned int ii = 0 ; ii < block_dimension ; ii++)
	for (unsigned int jj = 0 ; jj <= ii ; jj++)
	  block(ii , jj) = block(jj , ii) = T_MPI(index++);
    }
      
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in RDM_rho_coupled_modified_class::MPI_Allgatherv(receive).");
}

#endif




