#include "../RDM_include/RDM_include_def.h"

using namespace RDM_rho_observables;





void RDM_observables::calculation (
				   const class input_data_str &input_data ,
				   const class RDM_PQG_class &Gamma_pp ,
				   const class RDM_PQG_class &Gamma_nn ,
				   const class RDM_PQG_class &Gamma_pn ,
				   class interaction_class &inter_data ,
				   class TBMEs_class &TBMEs_pn ,  
				   class nucleons_data &prot_data ,
				   class nucleons_data &neut_data) 
{
  if (THIS_PROCESS == MASTER_PROCESS)
    {
      cout << endl << "Observables" << endl;
      cout <<         "-----------" << endl << endl;
          
      all_shells_occupation_calc_print (PROTON  , prot_data , neut_data , Gamma_pp , Gamma_pn);
      all_shells_occupation_calc_print (NEUTRON , prot_data , neut_data , Gamma_nn , Gamma_pn);
      
      all_partial_wave_occupation_calc_print (PROTON  , prot_data , neut_data , Gamma_pp , Gamma_pn);
      all_partial_wave_occupation_calc_print (NEUTRON , prot_data , neut_data , Gamma_nn , Gamma_pn);
    }
  
  const bool are_there_GSM_multipoles                = input_data.get_are_there_GSM_multipoles ();
  const bool are_there_densities                     = input_data.get_are_there_densities ();
  const bool are_there_correlation_densities         = input_data.get_are_there_correlation_densities ();
  const bool are_there_rms_radii                     = input_data.get_are_there_rms_radii ();
  const bool are_there_rms_radius_one_body_strengths = input_data.get_are_there_rms_radius_one_body_strengths ();
  const bool are_there_Hamiltonian_parts             = input_data.get_are_there_Hamiltonian_parts ();

  const bool are_there_calculations = (are_there_GSM_multipoles || are_there_densities || are_there_correlation_densities || are_there_rms_radii || are_there_rms_radius_one_body_strengths || are_there_Hamiltonian_parts);
  
  if (are_there_calculations)
    {              
      if (are_there_GSM_multipoles) RDM_multipoles::calc_print (input_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);
      
      if (are_there_densities) RDM_density::calc_store (input_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);

      if (are_there_correlation_densities) RDM_correlation_density::calc_store (input_data , inter_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);

      if (are_there_rms_radii) RDM_rms_radius::calc_print (input_data , prot_data , neut_data , Gamma_pp , Gamma_nn , Gamma_pn);

      if (are_there_rms_radius_one_body_strengths) RDM_rms_radius_one_body_strength::calc_store (input_data  , prot_data , neut_data, Gamma_pp , Gamma_nn , Gamma_pn);

      if (are_there_Hamiltonian_parts) RDM_Hamiltonian_parts::calc_print (input_data , Gamma_pp , Gamma_nn , Gamma_pn , inter_data , prot_data , neut_data , TBMEs_pn);
    }
}




