#ifndef RDMHAMILTONIANPARTS_H
#define RDMHAMILTONIANPARTS_H

namespace RDM_Hamiltonian_parts
{
  void kinetic_one_body_calc_print (
				    const enum space_type space , 
				    const class interaction_class &inter_data ,
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn ,
				    const class RDM_PQG_class &Gamma_pp ,
				    const class RDM_PQG_class &Gamma_nn ,
				    const class RDM_PQG_class &Gamma_pn);

  void kinetic_recoil_calc_print (
				  const class input_data_str &input_data , 
				  const class interaction_class &inter_data , 
				  class nucleons_data &prot_data , 
				  class nucleons_data &neut_data , 
				  class TBMEs_class &TBMEs_pn , 
				  const class RDM_PQG_class &Gamma_pp ,
				  const class RDM_PQG_class &Gamma_nn ,
				  const class RDM_PQG_class &Gamma_pn);

  void nuclear_one_body_calc_print (			
				    const enum space_type space , 		
				    const class interaction_class &inter_data ,
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn , 
				    const class RDM_PQG_class &Gamma_pp ,
				    const class RDM_PQG_class &Gamma_nn ,
				    const class RDM_PQG_class &Gamma_pn);

  void nuclear_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jn_relative_max , 
				    class interaction_class &inter_data , 
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn , 
				    const class RDM_PQG_class &Gamma_pp ,
				    const class RDM_PQG_class &Gamma_nn ,
				    const class RDM_PQG_class &Gamma_pn);

  void nuclear_three_body_calc_print (
				      const class input_data_str &input_data ,
				      class interaction_class &inter_data , 
				      class nucleons_data &prot_data , 
				      class nucleons_data &neut_data , 
				      class TBMEs_class &TBMEs_pn , 
				      const class RDM_PQG_class &Gamma_pp ,
				      const class RDM_PQG_class &Gamma_nn ,
				      const class RDM_PQG_class &Gamma_pn);

  void Coulomb_one_body_calc_print (		
				    const enum space_type space ,				     
				    const class interaction_class &inter_data ,
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn , 
				    const class RDM_PQG_class &Gamma_pp ,
				    const class RDM_PQG_class &Gamma_nn ,
				    const class RDM_PQG_class &Gamma_pn);

  void Coulomb_two_body_calc_print (
				    const class input_data_str &input_data , 
				    const int Jc_relative_max , 
				    class interaction_class &inter_data , 
				    class nucleons_data &prot_data , 
				    class nucleons_data &neut_data , 
				    class TBMEs_class &TBMEs_pn , 
				    const class RDM_PQG_class &Gamma_pp ,
				    const class RDM_PQG_class &Gamma_nn ,
				    const class RDM_PQG_class &Gamma_pn);

  void calc_print (
		   const class input_data_str &input_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn , 
		   class interaction_class &inter_data , 
		   class nucleons_data &prot_data ,
		   class nucleons_data &neut_data , 
		   class TBMEs_class &TBMEs_pn);
}


#endif
