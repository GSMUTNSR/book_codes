#ifndef RDMPQGCLASS_H
#define RDMPQGCLASS_H

class RDM_PQG_class
{
public:
  
  RDM_PQG_class ();

  RDM_PQG_class (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const bool is_it_P_c , 
		 const bool is_it_Q_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data);
  
  RDM_PQG_class (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data ,
		 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);

  RDM_PQG_class (const class RDM_PQG_class &X);
  
  ~RDM_PQG_class ();

  void allocate (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const bool is_it_P_c , 
		 const bool is_it_Q_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data);
  
  void allocate (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data ,
		 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);

  void allocate_fill (const class RDM_PQG_class &X);

  void deallocate ();
  
  enum space_type get_space_pair () const
  {
    return space_pair;
  }
  
  enum particle_type get_last_particle () const
  {
    return last_particle;
  }

  bool get_is_it_P () const
  {
    return is_it_P;
  }
  
  bool get_is_it_Q () const
  {
    return is_it_Q;
  }
  
  bool get_is_it_G () const
  {
    return is_it_G;
  }
  
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }
  
  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }
    
  const class array<unsigned int> & get_matrix_dimensions () const
  {
    return matrix_dimensions;
  }
  
  const class array<unsigned int> & get_two_states_indices () const
  {
    return two_states_indices;
  }
	
  const class array<unsigned int> & get_BP_table () const
  {
    return BP_table;
  }
      
  const class array<int> & get_Jmin_table () const
  {
    return Jmin_table;
  }
  
  const class array<int> & get_Jmax_table () const
  {
    return Jmax_table;
  }
  
  const class array<bool> & get_is_it_in_space_tab () const
  {
    return is_it_in_space_tab;
  }
  
  const class block_matrix<TYPE> & get_block_matrix () const
  {
    return block_matrix_abcd;
  }
  
  class block_matrix<TYPE> & get_block_matrix ()
  {
    return block_matrix_abcd;
  }
    
  bool is_it_filled () const
  {
    return (block_matrix_abcd.is_it_filled ());
  }
  
  void block_matrix_fill (const class block_matrix<TYPE> &X);
  
  void random_positive_definite ();
  
  void operator = (const class RDM_PQG_class &X);
  
  void operator += (const class RDM_PQG_class &X);
  void operator -= (const class RDM_PQG_class &X);
  
  void add_scalar_diagonal_part (const TYPE &x);
  
  void remove_scalar_diagonal_part (const TYPE &x);
  
  void operator *= (const TYPE &x);
  void operator /= (const TYPE &x);
  
  void double_counting_scaling ();
  
  void double_counting_removal ();
  
  unsigned int get_block_symmetric_matrix_elements_number () const;
  
  double infinite_norm () const;
  
  void zero ();
  
  void identity ();
  
  void Q_pp_nn_block_matrices_add (
				   const class array<TYPE> &rho_tab ,
				   const class RDM_PQG_class &Gamma);
  
  void Q_pn_block_matrices_add(
			       const class array<TYPE> &rho_prot_tab ,
			       const class array<TYPE> &rho_neut_tab ,
			       const class RDM_PQG_class &Gamma_pn);

  void G_pp_nn_block_matrices_add (
				   const class array<TYPE> &rho_tab ,
				   const class RDM_PQG_class &Gamma);
  
  void G_pn_block_matrices_add (
				const class array<TYPE> &rho_prot_tab ,
				const class RDM_PQG_class &Gamma_pn);
  
  void G_np_block_matrices_add (
				const class array<TYPE> &rho_neut_tab ,
				const class RDM_PQG_class &Gamma_pn);  
  
  void read_P_pp_nn_from_file (
			       const int Z ,
			       const int N ,
			       const unsigned int RDM_BP ,
			       const double RDM_J ,
			       const unsigned int RDM_vector_index);
  
  void read_P_pn_from_file (
			    const int Z ,
			    const int N ,
			    const unsigned int RDM_BP ,
			    const double RDM_J ,
			    const unsigned int RDM_vector_index);
  
  void copy_P_pp_nn_to_file (
			     const int Z ,
			     const int N ,
			     const unsigned int RDM_BP ,
			     const double RDM_J ,
			     const unsigned int RDM_vector_index) const;
  
  void copy_P_pn_to_file (
			  const int Z ,
			  const int N ,
			  const unsigned int RDM_BP ,
			  const double RDM_J ,
			  const unsigned int RDM_vector_index) const;
  
  void precision_Q_pp_nn_class_file_calc_print (
						const int Z ,
						const int N ,
						const unsigned int RDM_BP ,
						const double RDM_J ,
						const unsigned int RDM_vector_index) const;
  
  void precision_Q_pn_class_file_calc_print (
					     const int Z ,
					     const int N ,
					     const unsigned int RDM_BP ,
					     const double RDM_J ,
					     const unsigned int RDM_vector_index) const;
  
  void precision_G_pp_nn_class_file_calc_print (
						const int Z ,
						const int N ,
						const unsigned int RDM_BP ,
						const double RDM_J ,
						const unsigned int RDM_vector_index) const;
  
  void precision_G_pn_class_file_calc_print (
					     const int Z ,
					     const int N ,
					     const unsigned int RDM_BP ,
					     const double RDM_J ,
					     const unsigned int RDM_vector_index) const;
  
  void precision_G_np_class_file_calc_print (
					     const int Z ,
					     const int N ,
					     const unsigned int RDM_BP ,
					     const double RDM_J ,
					     const unsigned int RDM_vector_index) const;
  
  void make_it_positive_definite (
				  class block_matrix<TYPE> &P_transpose ,
				  class block_matrix<TYPE> &Dp_P_transpose);
    
#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif

  private:
 
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class RDM_G_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_G () const
  {
    return *Wigner_6j_hats_G_ptr;
  }
       
  void BP_J_tables_dimensions_indices_pp_nn_alloc_calc ();

  void BP_J_tables_dimensions_indices_pn_alloc_calc ();
  void BP_J_tables_dimensions_indices_np_alloc_calc ();
  
  enum space_type space_pair;
  
  enum particle_type last_particle;

  bool truncation_hw;
  bool truncation_ph;
  
  int E_max_hw;

  int n_scat_max;
  
  bool is_it_P;
  bool is_it_Q;
  bool is_it_G;
  
  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
  
  const class RDM_G_Wigner_6j_hats_storage_class *Wigner_6j_hats_G_ptr;
			      
  class array<unsigned int> matrix_dimensions;
  
  class array<unsigned int> two_states_indices;
	
  class array<unsigned int> BP_table;
      
  class array<int> Jmin_table;
  class array<int> Jmax_table;
    
  class array<bool> is_it_in_space_tab;
  
  class block_matrix<TYPE> block_matrix_abcd;
  
  class array<TYPE> block_matrix_abcd_array_helper;
  
  class array<TYPE> T_MPI;
};

#endif



