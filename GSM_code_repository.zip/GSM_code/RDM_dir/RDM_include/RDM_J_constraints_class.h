#ifndef RDMJCONSTRAINTSCLASS_H
#define RDMJCONSTRAINTSCLASS_H

class RDM_J_constraints_gradient_class;
			
class RDM_J_constraints_class
{
public:
  
  RDM_J_constraints_class ();

  RDM_J_constraints_class (
			   const enum particle_type particle_c ,
			   const double J_c , 
			   const class nucleons_data &prot_data ,
			   const class nucleons_data &neut_data);
  
  RDM_J_constraints_class (const class RDM_J_constraints_class &X);
  
  ~RDM_J_constraints_class ();

  void allocate (
		 const enum particle_type particle_c ,
		 const double J_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data);
  
  void allocate_fill (const class RDM_J_constraints_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (particle != NO_PARTICLE);
  }
  
  void J_constraints_matrix_add (
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data ,
				 const class RDM_PQG_class &Gamma_pp_nn ,
				 const class RDM_PQG_class &Gamma_pn ,
				 const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
				 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);
    
  void operator =  (const class RDM_J_constraints_class &X);
  void operator += (const class RDM_J_constraints_class &X);
  void operator -= (const class RDM_J_constraints_class &X);
  
  void operator = (const TYPE &x);
  
  void operator += (const TYPE &x);
  void operator -= (const TYPE &x);
  
  void operator *= (const TYPE &x);
  void operator /= (const TYPE &x);
  
  void zero ();

  TYPE Frobenius_squared_norm () const;
  
  unsigned int get_symmetric_matrix_elements_number () const;
  
  double infinite_norm () const;
  
  void add_gradient_part (
			  const bool is_it_der_pn , 
			  const unsigned int BPp ,
			  const int Jp ,
			  const unsigned int ip_jp_upper_triangular_index , 
			  const class RDM_J_constraints_gradient_class &B);
  
  void add_rho_coupled_modified_gradient_part (
					       const int j ,
					       const unsigned int sa_bp_index ,
					       const unsigned int sb_bp_index ,
					       const TYPE &x);
  
  friend TYPE Frobenius_scalar_product (
					const class RDM_J_constraints_class &A ,
					const class RDM_J_constraints_class &B);
  
  friend TYPE Frobenius_scalar_product_matrix_gradient (
							const bool is_it_der_pn , 
							const unsigned int BPp ,
							const int Jp ,
							const unsigned int ip_jp_upper_triangular_index , 
							const class RDM_J_constraints_class &A ,
							const class RDM_J_constraints_gradient_class &B);

  friend TYPE Frobenius_scalar_product_matrix_rho_coupled_modified_gradient (
									     const int j ,
									     const unsigned int sa_bp_index ,
									     const unsigned int sb_bp_index , 
									     const class RDM_J_constraints_class &A);

#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif
							  
private:
  
  enum particle_type particle;
  
  double J;
  
  double J_factor_vector_part;

  bool is_J_non_zero;
  
  void J_constraints_matrix_pp_nn_part_add (
					    const class nucleons_data &particles_data ,
					    const class array<TYPE> &rho_tab ,
					    const class RDM_PQG_class &Gamma_pp_nn ,
					    const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
					    const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);
  
  void J_constraints_matrix_prot_pn_part_add (
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_PQG_class &Gamma_pn ,
					      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);
  
  void J_constraints_matrix_neut_pn_part_add (
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      const class RDM_PQG_class &Gamma_pn ,
					      const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);
        
  class matrix<TYPE> J_constraints_matrix_scalar_part;
  class matrix<TYPE> J_constraints_matrix_vector_part;
  
  class array<TYPE> T_MPI;
};

#endif



