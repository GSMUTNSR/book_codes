#ifndef RDMCONDITIONSGRADIENTCLASS_H
#define RDMCONDITIONSGRADIENTCLASS_H

class RDM_conditions_gradient_class
{
public:

  RDM_conditions_gradient_class ();
    
  RDM_conditions_gradient_class (
				 const enum interaction_type inter ,
				 const class TBMEs_class &TBMEs_pn ,
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data ,
				 const class RDM_conditions_class &RDM_conditions);
  
  RDM_conditions_gradient_class (const class RDM_conditions_gradient_class &X);

  void allocate_fill (const class RDM_conditions_gradient_class &X);
  
  void operator = (const class RDM_conditions_gradient_class &X);

  void deallocate ();
    
  void alloc_calc_store (
			 const enum interaction_type inter ,
			 const class TBMEs_class &TBMEs_pn ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_conditions_class &RDM_conditions);
      
  bool is_it_filled () const
  {
    return (rho_prot_der_pp_tab.is_it_filled () || rho_neut_der_nn_tab.is_it_filled ());
  }
  
  const class array<double> & get_rho_prot_der_tab (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return rho_prot_der_pp_tab;
      case PROTONS_NEUTRONS: return rho_prot_der_pn_tab;
	  
      default: abort_all ();
      }

    return rho_prot_der_pp_tab;
  }
  
  const class array<double> & get_rho_neut_der_tab (const enum space_type space) const
  {
    switch (space)
      {
      case NEUTRONS_ONLY:    return rho_neut_der_nn_tab;
      case PROTONS_NEUTRONS: return rho_neut_der_pn_tab;
	  
      default: abort_all ();
      }

    return rho_neut_der_nn_tab;
  }

  const class array<double> & get_Delta_J_der_tab (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_J_der_pp_tab;
      case NEUTRONS_ONLY:    return Delta_J_der_nn_tab;
      case PROTONS_NEUTRONS: return Delta_J_der_pn_tab;
	  
      default: abort_all ();
      }

    return Delta_J_der_pp_tab;
  }
      
  const class array<unsigned int> & get_ba_from_ab_pn_indices () const
  {
    return ba_from_ab_pn_indices;
  }
  
  const class array<int> & get_average_T2_der_pn_tab () const
  {
    return average_T2_der_pn_tab;
  }      
      
  const class block_matrix<TYPE> & get_Delta_E_reference_der_block_matrix (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_E_reference_der_pp_block_matrix;
      case NEUTRONS_ONLY:    return Delta_E_reference_der_nn_block_matrix;
      case PROTONS_NEUTRONS: return Delta_E_reference_der_pn_block_matrix;
	  
      default: abort_all ();
      }

    return Delta_E_reference_der_pp_block_matrix;
  }
  
  const class block_matrix<TYPE> & get_Delta_Hcm_der_block_matrix (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_Hcm_der_pp_block_matrix;
      case NEUTRONS_ONLY:    return Delta_Hcm_der_nn_block_matrix;
      case PROTONS_NEUTRONS: return Delta_Hcm_der_pn_block_matrix;
	  
      default: abort_all ();
      }

    return Delta_Hcm_der_pp_block_matrix;
  }
    
  const class RDM_QG_gradient_class & get_Q_gradient (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_gradient;	  
      case NEUTRONS_ONLY:    return Q_nn_gradient;	    
      case PROTONS_NEUTRONS: return Q_pn_gradient;
	  
      default: abort_all ();
      }

    return Q_pp_gradient;
  }
    
  const class RDM_QG_gradient_class & get_G_gradient (const enum space_type space , const enum particle_type last_particle) const
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_gradient");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_gradient");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_gradient;
      case NEUTRONS_ONLY: return G_nn_gradient;
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_gradient;
	  else if (last_particle == NEUTRON)
	    return G_pn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_gradient in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_gradient;
  }
  
  const class RDM_J_constraints_gradient_class & get_J_constraints_gradient (const enum particle_type particle) const
  {
    switch (particle)
      {
      case PROTON:  return J_constraints_pp_gradient;
      case NEUTRON: return J_constraints_nn_gradient;
      
      default: abort_all ();
      }
      
    return J_constraints_pp_gradient;
  }
  
  const class RDM_T1_gradient_class & get_T1_gradient (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_gradient;
	  else if (last_particle == NEUTRON)
	    return T1_ppn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_gradient (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_gradient;
	  else if (last_particle == PROTON)
	    return T1_nnp_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_gradient (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in T1_RDM_class is either protons only or neutrons only in get_T1_gradient");
      }
    return T1_ppp_gradient;
  }
    
  const class RDM_T2_prime_gradient_class & get_T2_prime_gradient (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_gradient;
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_gradient;
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_gradient;
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in T2_prime_RDM_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_gradient");
      }
    
    return T2_prime_ppp_gradient;
  }

  class array<double> & get_rho_prot_der_tab (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return rho_prot_der_pp_tab;
      case PROTONS_NEUTRONS: return rho_prot_der_pn_tab;
	  
      default: abort_all ();
      }

    return rho_prot_der_pp_tab;
  }
  
  class array<double> & get_rho_neut_der_tab (const enum space_type space)
  {
    switch (space)
      {
      case NEUTRONS_ONLY:    return rho_neut_der_nn_tab;
      case PROTONS_NEUTRONS: return rho_neut_der_pn_tab;
	  
      default: abort_all ();
      }

    return rho_neut_der_nn_tab;
  }

  class array<double> & get_Delta_J_der_tab (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_J_der_pp_tab;
      case NEUTRONS_ONLY:    return Delta_J_der_nn_tab;
      case PROTONS_NEUTRONS: return Delta_J_der_pn_tab;
	  
      default: abort_all ();
      }

    return Delta_J_der_pp_tab;
  }
      
  class array<unsigned int> & get_ba_from_ab_pn_indices ()
  {
    return ba_from_ab_pn_indices;
  }
  
  class array<int> & get_average_T2_der_pn_tab ()
  {
    return average_T2_der_pn_tab;
  }      
      
  class block_matrix<TYPE> & get_Delta_E_reference_der_block_matrix (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_E_reference_der_pp_block_matrix;
      case NEUTRONS_ONLY:    return Delta_E_reference_der_nn_block_matrix;
      case PROTONS_NEUTRONS: return Delta_E_reference_der_pn_block_matrix;
	  
      default: abort_all ();
      }

    return Delta_E_reference_der_pp_block_matrix;
  }
  
  class block_matrix<TYPE> & get_Delta_Hcm_der_block_matrix (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_Hcm_der_pp_block_matrix;
      case NEUTRONS_ONLY:    return Delta_Hcm_der_nn_block_matrix;
      case PROTONS_NEUTRONS: return Delta_Hcm_der_pn_block_matrix;
	  
      default: abort_all ();
      }

    return Delta_Hcm_der_pp_block_matrix;
  }
    
  class RDM_QG_gradient_class & get_Q_gradient (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_gradient;	  
      case NEUTRONS_ONLY:    return Q_nn_gradient;	    
      case PROTONS_NEUTRONS: return Q_pn_gradient;
	  
      default: abort_all ();
      }

    return Q_pp_gradient;
  }
    
  class RDM_QG_gradient_class & get_G_gradient (const enum space_type space , const enum particle_type last_particle)
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_gradient");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_gradient");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_gradient;
      case NEUTRONS_ONLY: return G_nn_gradient;
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_gradient;
	  else if (last_particle == NEUTRON)
	    return G_pn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_gradient in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_gradient;
  }
  
  class RDM_J_constraints_gradient_class & get_J_constraints_gradient (const enum particle_type particle)
  {
    switch (particle)
      {
      case PROTON:  return J_constraints_pp_gradient;
      case NEUTRON: return J_constraints_nn_gradient;
      
      default: abort_all ();
      }
      
    return J_constraints_pp_gradient;
  }
  
  class RDM_T1_gradient_class & get_T1_gradient (const enum space_type space_pair , const enum particle_type last_particle)
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_gradient;
	  else if (last_particle == NEUTRON)
	    return T1_ppn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_gradient (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_gradient;
	  else if (last_particle == PROTON)
	    return T1_nnp_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_gradient (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in T1_RDM_class is either protons only or neutrons only in get_T1_gradient");
      }
    return T1_ppp_gradient;
  }
    
  class RDM_T2_prime_gradient_class & get_T2_prime_gradient (const enum space_type space_pair , const enum particle_type last_particle)
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_gradient;
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_gradient;
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_gradient;
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_gradient;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_gradient (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in T2_prime_RDM_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_gradient");
      }
    
    return T2_prime_ppp_gradient;
  }
      
private:
    
  class array<double> rho_prot_der_pp_tab;    
  class array<double> rho_prot_der_pn_tab;
    
  class array<double> rho_neut_der_nn_tab;    
  class array<double> rho_neut_der_pn_tab;
        
  class array<double> Delta_J_der_pp_tab;  
  class array<double> Delta_J_der_nn_tab;  
  class array<double> Delta_J_der_pn_tab;
    
  class array<unsigned int> ba_from_ab_pn_indices;
    
  class array<int> average_T2_der_pn_tab;   
  
  class block_matrix<TYPE> Delta_E_reference_der_pp_block_matrix;  
  class block_matrix<TYPE> Delta_E_reference_der_nn_block_matrix;  
  class block_matrix<TYPE> Delta_E_reference_der_pn_block_matrix;
  
  class block_matrix<TYPE> Delta_Hcm_der_pp_block_matrix;  
  class block_matrix<TYPE> Delta_Hcm_der_nn_block_matrix;  
  class block_matrix<TYPE> Delta_Hcm_der_pn_block_matrix;
  
  class RDM_QG_gradient_class Q_pp_gradient;
  class RDM_QG_gradient_class Q_nn_gradient;
  class RDM_QG_gradient_class Q_pn_gradient;
  
  class RDM_QG_gradient_class G_pp_gradient;
  class RDM_QG_gradient_class G_nn_gradient;
  class RDM_QG_gradient_class G_pn_gradient;
  class RDM_QG_gradient_class G_np_gradient;
  
  class RDM_J_constraints_gradient_class J_constraints_pp_gradient;
  class RDM_J_constraints_gradient_class J_constraints_nn_gradient;
  
  class RDM_T1_gradient_class T1_ppp_gradient;
  class RDM_T1_gradient_class T1_nnn_gradient;
  class RDM_T1_gradient_class T1_ppn_gradient;
  class RDM_T1_gradient_class T1_nnp_gradient;
  
  class RDM_T2_prime_gradient_class T2_prime_ppp_gradient;
  class RDM_T2_prime_gradient_class T2_prime_nnn_gradient;
  class RDM_T2_prime_gradient_class T2_prime_ppn_gradient; 
  class RDM_T2_prime_gradient_class T2_prime_nnp_gradient; 
  class RDM_T2_prime_gradient_class T2_prime_pnn_gradient; 
  class RDM_T2_prime_gradient_class T2_prime_pnp_gradient;
};






    
#endif
