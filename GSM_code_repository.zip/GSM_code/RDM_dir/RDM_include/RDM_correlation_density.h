#ifndef RDMCORRELATIONDENSITY_H
#define RDMCORRELATIONDENSITY_H

namespace RDM_correlation_density
{
  void correlation_density_pp_nn_calc (
				       const bool is_it_HO_expansion , 
				       const class interaction_class &inter_data , 
				       const class array<TYPE> &rk_OBMEs ,
				       const class multipolar_expansion_str &multipolar_expansion ,
				       const class Psigma_str &Psigma ,
				       const class array<double> theta12_Dirac_multipolar_tab ,
				       const class nucleons_data &particles_data ,
				       const class RDM_PQG_class &Gamma , 
				       class array<TYPE> &angular_densities_tab , 
				       class array<TYPE> &density_tab);

  void correlation_density_pn_calc (
				    const bool is_it_HO_expansion , 
				    const class interaction_class &inter_data ,
				    const class array<TYPE> &rk_OBMEs_prot ,
				    const class array<TYPE> &rk_OBMEs_neut ,
				    const class multipolar_expansion_str &multipolar_expansion ,
				    const class Psigma_str &Psigma ,
				    const class array<double> theta12_Dirac_multipolar_tab , 
				    const class nucleons_data &prot_data ,
				    const class nucleons_data &neut_data , 
				    const class RDM_PQG_class &Gamma_pn , 
				    class array<TYPE> &angular_densities_tab , 
				    class array<TYPE> &density_tab);

  void correlation_density_calc ( 
				 const bool is_it_radial ,
				 const bool is_it_Gauss_Legendre , 
				 const bool is_it_HO_expansion ,
				 const class interaction_class &inter_data ,
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data , 
				 const class RDM_PQG_class &Gamma_pp ,
				 const class RDM_PQG_class &Gamma_nn ,
				 const class RDM_PQG_class &Gamma_pn , 
				 const class array<double> &theta_tab ,
				 class array<TYPE> &angular_densities_pp_tab , 
				 class array<TYPE> &angular_densities_nn_tab , 
				 class array<TYPE> &angular_densities_pn_tab , 
				 class array<TYPE> &density_pp_tab , 
				 class array<TYPE> &density_nn_tab , 
				 class array<TYPE> &density_pn_tab);

  void calc_store_density (
			   const bool is_it_radial ,
			   const bool is_it_Gauss_Legendre , 
			   const bool is_it_HO_expansion , 
			   const class interaction_class &inter_data ,  
			   const class array<double> &rk_tab ,
			   const class array<double> &theta_tab ,
			   const class correlated_state_str &PSI_qn , 
			   const class RDM_PQG_class &Gamma_pp ,
			   const class RDM_PQG_class &Gamma_nn ,
			   const class RDM_PQG_class &Gamma_pn , 
			   const class nucleons_data &prot_data , 
			   const class nucleons_data &neut_data);
 
  void calc_store (
		   const class input_data_str &input_data , 
		   const class interaction_class &inter_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn);
}

#endif
