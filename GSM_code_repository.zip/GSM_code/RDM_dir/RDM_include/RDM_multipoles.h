#ifndef RDMMULTIPOLES_H
#define RDMMULTIPOLES_H

namespace RDM_multipoles
{
  TYPE GSM_multipole_pp_nn_calc (
				 const int L ,
				 const bool is_it_HO_expansion ,
				 const class array<class multipole_TBMEs_angular_table_str> &TBMEs_angular_tables ,
				 const class nucleons_data &particles_data ,
				 const class array<TYPE> &rho_tab ,
				 const class RDM_PQG_class &Gamma);
 
  TYPE GSM_multipole_pn_calc (
			      const int L ,
			      const bool is_it_HO_expansion ,
			      const class array<class multipole_TBMEs_angular_table_str> &TBMEs_angular_tables ,
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data , 
			      const class RDM_PQG_class &Gamma_pn);

  TYPE GSM_multipole_calc (
			   const int L ,
			   const bool is_it_HO_expansion ,
			   const class nucleons_data &prot_data ,
			   const class nucleons_data &neut_data , 
			   const class RDM_PQG_class &Gamma_pp ,
			   const class RDM_PQG_class &Gamma_nn ,
			   const class RDM_PQG_class &Gamma_pn);
 
  void calc_print (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn);
}

#endif

