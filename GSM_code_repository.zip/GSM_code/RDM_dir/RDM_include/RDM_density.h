#ifndef RDMDENSITY_H
#define RDMDENSITY_H

namespace RDM_density
{
  void calc_store_density (
			   const enum space_type space , 
			   const bool is_it_radial ,
			   const bool is_it_Gauss_Legendre ,
			   const class array<double> &rk_tab ,
			   const class nucleons_data &prot_data ,
			   const class nucleons_data &neut_data ,
			   const class correlated_state_str &PSI_qn , 
			   const class RDM_PQG_class &Gamma_pp ,
			   const class RDM_PQG_class &Gamma_nn ,
			   const class RDM_PQG_class &Gamma_pn);

  void calc_store (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn);
}

#endif
