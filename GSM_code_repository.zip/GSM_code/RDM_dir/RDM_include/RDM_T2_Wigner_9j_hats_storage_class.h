#ifndef RDMT2WIGNER9JSTORAGECLASS_H
#define RDMT2WIGNER9JSTORAGECLASS_H


class RDM_T2_Wigner_9j_hats_storage_class
{
public:
  
  RDM_T2_Wigner_9j_hats_storage_class ();

  RDM_T2_Wigner_9j_hats_storage_class (
				       const class nucleons_data &prot_data ,
				       const class nucleons_data &neut_data);

  RDM_T2_Wigner_9j_hats_storage_class (const class RDM_T2_Wigner_9j_hats_storage_class &X);
  
  ~RDM_T2_Wigner_9j_hats_storage_class ();

  void alloc_calc_store (
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data);

  void allocate_fill (const class RDM_T2_Wigner_9j_hats_storage_class &X);

  void deallocate ();
            
  bool is_it_filled () const
  {
    return (Wigner_9j_hats_tab.is_it_filled ());
  }
      
  double operator () (
		      const int ija ,
		      const int ijb ,
		      const int ijc ,
		      const int ije ,
		      const int ijf ,
		      const int Jab ,
		      const int Jce ,
		      const int Jde ,
		      const int iJ) const
  {
    const unsigned int abc_index = three_states_indices(ija , ijb , ijc , Jab , iJ);

    if (abc_index == three_states_indices.dimension_total ()) return 0.0;
  
    const unsigned int index = Wigner_9j_hats_indices(ije , ijf , Jce , Jde , abc_index);

    if (index == Wigner_9j_hats_indices.dimension_total ()) return 0.0;
  
    const double Wigner_9j_hats = Wigner_9j_hats_tab(index);

    return Wigner_9j_hats;
  }

  
private:
  
  void Wigner_9j_hats_indices_tabs_determine (
					      const enum operation_type operation ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      unsigned int &dimension);
  
  class array<unsigned int> three_states_indices;
  
  class array<unsigned int> Wigner_9j_hats_indices;
  
  class array<double> Wigner_9j_hats_tab;
};

#endif
