#ifndef RDMRHOCOUPLEDREDUCEDMODIFIEDCLASS_H
#define RDMRHOCOUPLEDREDUCEDMODIFIEDCLASS_H
			
class RDM_rho_coupled_modified_class
{
public:
  
  RDM_rho_coupled_modified_class ();

  RDM_rho_coupled_modified_class (const bool are_there_J_constraints , const double J , const class nucleons_data &particles_data);
  
  RDM_rho_coupled_modified_class (const class RDM_rho_coupled_modified_class &X);
  
  ~RDM_rho_coupled_modified_class ();

  void allocate (const bool are_there_J_constraints , const double J , const class nucleons_data &particles_data);
  
  void allocate_fill (const class RDM_rho_coupled_modified_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (particles_data_ptr != NULL);
  }
  
  int get_jmax_ab_global () const
  {
    return jmax_ab_global;
  }
  
  const class block_matrix<TYPE> & get_block_matrix () const
  {
    return rho_coupled_modified_block_matrix;
  }
  
  class block_matrix<TYPE> & get_block_matrix ()
  {
    return rho_coupled_modified_block_matrix;
  }
  
  const class block_matrix<TYPE> & get_rho_uncoupled_block_matrix () const
  {
    return rho_uncoupled_block_matrix;
  }
  
  class block_matrix<TYPE> & get_rho_uncoupled_block_matrix ()
  {
    return rho_uncoupled_block_matrix;
  }    
    
  const class array<unsigned int> & get_shells_indices_fixed_parity () const
  {
    return shells_indices_fixed_parity;
  }
  
  void block_matrix_fill (const class block_matrix<TYPE> &X);
  
  void random_positive_definite ();
  
  void operator = (const class RDM_rho_coupled_modified_class &X);
  
  void operator += (const class RDM_rho_coupled_modified_class &X);
  void operator -= (const class RDM_rho_coupled_modified_class &X);
  
  void add_scalar_diagonal_part (const TYPE &x);

  void remove_scalar_diagonal_part (const TYPE &x);
  
  void operator *= (const TYPE &x);
  void operator /= (const TYPE &x);

  void zero ();

  void identity ();
  
  void double_counting_scaling ();
  
  void double_counting_removal ();
  
  unsigned int get_block_symmetric_matrix_elements_number () const;
  
  TYPE Frobenius_squared_norm () const;
    
  double infinite_norm () const;

  void make_it_N_representable (
				class block_matrix<TYPE> &P_transpose ,
				class block_matrix<TYPE> &Dp_P_transpose);
  
  void read_from_file (
		       const int Z ,
		       const int N ,
		       const unsigned int RDM_BP ,
		       const double RDM_J ,
		       const unsigned int RDM_vector_index);
  
#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif
							  
private:
  
  const class nucleons_data & get_particles_data () const
  {
    return *particles_data_ptr;
  }
  
  void rho_coupled_modified_from_rho_uncoupled ();
  
  void rho_uncoupled_from_rho_coupled_modified ();

  enum particle_type particle;  

  int jmax_ab_global;
  
  const class nucleons_data *particles_data_ptr;
  
  class CG_str CGs;
  
  class array<unsigned int> shells_indices_fixed_parity;
  
  class block_matrix<TYPE> rho_coupled_modified_block_matrix;
  
  class block_matrix<TYPE> rho_uncoupled_block_matrix;
  
  class array<TYPE> rho_uncoupled_block_matrix_eigenvalues;
  
  class array<TYPE> rho_coupled_modified_block_matrix_array_helper;
  
  class array<TYPE> T_MPI;
};


#endif


