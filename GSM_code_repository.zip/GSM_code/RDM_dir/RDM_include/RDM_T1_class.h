#ifndef RDMT1CLASS_H
#define RDMT1CLASS_H

class RDM_T1_class
{
public:
  
  RDM_T1_class ();

  RDM_T1_class (
		const enum space_type space_pair_c ,
		const enum particle_type last_particle_c ,
		const bool truncation_hw_c ,
		const bool truncation_ph_c ,
		const int E_max_hw_c ,
		const int n_scat_max_c , 
		const class nucleons_data &prot_data ,
		const class nucleons_data &neut_data ,
		const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats);

  RDM_T1_class (const class RDM_T1_class &X);
  
  ~RDM_T1_class ();

  void allocate (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data ,
		 const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats);

  void allocate_fill (const class RDM_T1_class &X);

  void deallocate ();
        
  enum space_type get_space_pair () const
  {
    return space_pair;
  }
  
  enum particle_type get_last_particle () const
  {
    return last_particle;
  }
    
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }
  
  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }
    
  const class array<unsigned int> & get_matrix_dimensions () const
  {
    return matrix_dimensions;
  }
  
  const class array<unsigned int> & get_three_states_indices () const
  {
    return three_states_indices;
  }
	
  const class array<unsigned int> & get_BP_table () const
  {
    return BP_table;
  }
        
  const class array<int> & get_iJmin_pair_last_particle_tab () const
  {
    return iJmin_pair_last_particle_tab;
  }
    
  const class array<int> & get_iJmax_pair_last_particle_tab () const
  {
    return iJmax_pair_last_particle_tab;
  }
  
  const class array<unsigned int> & get_alpha_number_same_shell_tab () const
  {
    return alpha_number_same_shell_tab;
  }
    
  const class array<double> & get_J_states_components_same_shell () const
  {
    return J_states_components_same_shell;
  }
  
  const class array<bool> & get_is_it_in_space_tab () const
  {
    return is_it_in_space_tab;
  }
  
  const class block_matrix<TYPE> & get_block_matrix () const
  {
    return block_matrix_abcdef;
  }
    
  class block_matrix<TYPE> & get_block_matrix ()
  {
    return block_matrix_abcdef;
  }
    
  bool is_it_filled () const
  {
    return (block_matrix_abcdef.is_it_filled ());
  }
  
  void block_matrix_fill (const class block_matrix<TYPE> &X);
  
  void operator = (const class RDM_T1_class &X);
  
  void operator += (const class RDM_T1_class &X);
  void operator -= (const class RDM_T1_class &X);
  
  void add_scalar_diagonal_part (const TYPE &x);
  
  void remove_scalar_diagonal_part (const TYPE &x);
  
  void operator *= (const TYPE &x);
  void operator /= (const TYPE &x);

  unsigned int get_block_symmetric_matrix_elements_number () const;
  
  double infinite_norm () const;
  
  void zero ();
  
  void T1_ppp_nnn_block_matrices_add (
				      const class array<TYPE> &rho_tab ,
				      const class RDM_PQG_class &Gamma);

  void T1_ppn_block_matrices_add (
				  const class array<TYPE> &rho_prot_tab ,
				  const class array<TYPE> &rho_neut_tab ,
				  const class RDM_PQG_class &Gamma_pp ,
				  const class RDM_PQG_class &Gamma_pn);
  
  void T1_nnp_block_matrices_add (
				  const class array<TYPE> &rho_prot_tab ,
				  const class array<TYPE> &rho_neut_tab ,
				  const class RDM_PQG_class &Gamma_nn ,
				  const class RDM_PQG_class &Gamma_pn);
  
  void precision_T1_ppp_nnn_class_file_calc_print (
						   const int Z ,
						   const int N ,
						   const unsigned int RDM_BP ,
						   const double RDM_J ,
						   const unsigned int RDM_vector_index ,
						   const class RDM_PQG_class &Gamma) const;
  
  void precision_T1_ppn_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_pp) const;
  
  void precision_T1_nnp_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_nn) const;

  void make_it_positive_definite (
				  class block_matrix<TYPE> &P_transpose ,
				  class block_matrix<TYPE> &Dp_P_transpose);
  
#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif
    
private:
  
  void BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
  
  void BP_J_tables_dimensions_indices_ppp_nnn_same_shell_calc ();
  
  void BP_J_tables_dimensions_indices_ppn_alloc_calc ();
  
  void BP_J_tables_dimensions_indices_nnp_alloc_calc ();

  TYPE T1_matrix_sc_sf_equal_part_calc (
					const class array<TYPE> &rho_tab ,
					const class RDM_PQG_class &Gamma ,
					const bool sa_sd_equal ,
					const bool sb_se_equal ,
					const bool sa_se_equal ,
					const bool sb_sd_equal ,
					const double inv_delta_norm_ab ,
					const double inv_delta_norm_phase_ab ,
					const double inv_delta_norm_de ,
					const unsigned int ab_index ,
					const int phase_de ,
					const unsigned int BP_de ,
					const int Jde ,
					const unsigned int sa ,
					const unsigned int sb ,
					const unsigned int sd ,
					const unsigned int se);
  
  TYPE T1_matrix_ppp_nnn_sab_sf_equal_part_calc (
						 const int iJ ,
						 const class array<TYPE> &rho_tab ,
						 const class RDM_PQG_class &Gamma_pp_nn ,
						 const bool sc_sd_j1_je_equal ,
						 const bool sc_se_j1_jd_equal ,
						 const bool s1_se_jc_jd_equal ,
						 const bool s1_sd_jc_je_equal ,
						 const double inv_delta_norm_ab ,
						 const double inv_delta_norm_ab_over_sc_s1 ,
						 const double inv_delta_norm_de ,
						 const int phase_de ,
						 const unsigned int BP_de ,
						 const int Jab ,
						 const int Jde ,
						 const int ij0 ,
						 const int ij1 ,
						 const int ijc ,
						 const unsigned int s1 ,
						 const unsigned int sc ,
						 const unsigned int sd ,
						 const unsigned int se ,
						 const int phase_sab_sf);

  TYPE T1_matrix_ppp_nnn_sc_sde_equal_part_calc (
						 const int iJ ,
						 const class RDM_PQG_class &Gamma ,
						 const double inv_delta_norm_de ,
						 const double inv_delta_norm_s3_f ,
						 const int phase_sc_sde ,
						 const int Jmin_sf_s3 ,
						 const int Jmax_sf_s3 ,
						 const unsigned int ab_index ,
						 const unsigned int BP_ab ,
						 const int Jab ,
						 const int Jde ,
						 const int ij2 ,
						 const int ij3 ,
						 const int ijf , 
						 const unsigned int s3 ,
						 const unsigned int sf);
  
  TYPE T1_matrix_sab_sde_equal_part_calc (
					  const int iJ ,
					  const class RDM_PQG_class &Gamma ,
					  const double inv_delta_norm_phase_sab_over_sc_s1 ,
					  const double inv_delta_norm_de ,
					  const double inv_delta_norm_sf_s3 ,
					  const int phase_sde ,
					  const int Jmin_sc_s1 , 
					  const int Jmax_sc_s1 ,  
					  const int Jmin_sf_s3 , 
					  const int Jmax_sf_s3 , 
					  const unsigned int BP_sc_s1 ,
					  const int Jab , 
					  const int Jde , 
					  const int ij0 ,
					  const int ij1 ,
					  const int ijc ,
					  const int ij2 ,
					  const int ij3 ,
					  const int ijf ,
					  const bool are_scf_proton_s_neutron ,
					  const bool are_scf_neutron_s_proton ,
					  const unsigned int s1 ,
					  const unsigned int sc ,
					  const unsigned int s3 ,
					  const unsigned int sf);
 
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
    
  const class RDM_T1_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_T1 () const
  {
    return *Wigner_6j_hats_T1_ptr;
  }
  
  enum space_type space_pair;
  
  enum particle_type last_particle;

  bool truncation_hw;
  bool truncation_ph;
  
  int E_max_hw;

  int n_scat_max;

  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
    
  const class RDM_T1_Wigner_6j_hats_storage_class *Wigner_6j_hats_T1_ptr;
  
  class array<unsigned int> matrix_dimensions;
  
  class array<unsigned int> three_states_indices;
	
  class array<unsigned int> BP_table;
        
  class array<int> iJmin_pair_last_particle_tab;
  class array<int> iJmax_pair_last_particle_tab;
  
  class array<unsigned int> alpha_number_same_shell_tab;
    
  class array<double> J_states_components_same_shell;
  
  class array<bool> is_it_in_space_tab;
  
  class block_matrix<TYPE> block_matrix_abcdef;
  
  class array<TYPE> block_matrix_abcdef_eigenvalues;
  
  class array<TYPE> T_MPI;
};




#endif



