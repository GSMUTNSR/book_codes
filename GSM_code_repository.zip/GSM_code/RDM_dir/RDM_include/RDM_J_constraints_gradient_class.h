#ifndef RDMJCONSTRAINTSGRADIENTCLASS_H
#define RDMJCONSTRAINTSGRADIENTCLASS_H


class RDM_J_constraints_gradient_class
{
public:
  
  RDM_J_constraints_gradient_class ();

  RDM_J_constraints_gradient_class (
				    const enum particle_type particle_c ,
				    const double J_c , 
				    const class nucleons_data &prot_data ,
				    const class nucleons_data &neut_data ,
				    const class array<double> &rho_der_pp_nn_tab ,
				    const class array<double> &rho_der_pn_tab ,
				    const class RDM_PQG_class &Gamma_pp_nn ,
				    const class RDM_PQG_class &Gamma_pn ,
				    const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);
  
  RDM_J_constraints_gradient_class (const class RDM_J_constraints_gradient_class &X);
  
  ~RDM_J_constraints_gradient_class ();

  void alloc_calc_store (
			 const enum particle_type particle_c ,
			 const double J_c , 
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class array<double> &rho_der_pp_nn_tab ,
			 const class array<double> &rho_der_pn_tab ,
			 const class RDM_PQG_class &Gamma_pp_nn ,
			 const class RDM_PQG_class &Gamma_pn ,
			 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G);

  void allocate_fill (const class RDM_J_constraints_gradient_class &X);

  void deallocate ();

  void operator = (const class RDM_J_constraints_gradient_class &X);
  
  bool is_it_filled () const
  {
    return (particle != NO_PARTICLE);
  }
  
  void fill_part (
		  const bool is_it_der_pn , 
		  const unsigned int BPp ,
		  const int Jp ,
		  const unsigned int ip_jp_upper_triangular_index , 
		  const RDM_J_constraints_gradient_class &A);

  void multiply_part (
		      const bool is_it_der_pn , 
		      const unsigned int BPp ,
		      const int Jp ,
		      const unsigned int ip_jp_upper_triangular_index , 
		      const TYPE &x);
  
  void divide_part (
		    const bool is_it_der_pn , 
		    const unsigned int BPp ,
		    const int Jp ,
		    const unsigned int ip_jp_upper_triangular_index , 
		    const TYPE &x);
    
  friend TYPE Frobenius_scalar_product_matrix_gradient (
							const bool is_it_der_pn , 
							const unsigned int BPp ,
							const int Jp ,
							const unsigned int ip_jp_upper_triangular_index , 
							const class RDM_J_constraints_class &A ,
							const class RDM_J_constraints_gradient_class &B);
  
  friend TYPE Frobenius_squared_norm_gradient (
					       const bool is_it_der_pn , 
					       const unsigned int BPp ,
					       const int Jp ,
					       const unsigned int ip_jp_upper_triangular_index ,
					       const class RDM_J_constraints_gradient_class &A);
  
  friend void RDM_J_constraints_class::add_gradient_part (
							  const bool is_it_der_pn , 
							  const unsigned int BPp ,
							  const int Jp ,
							  const unsigned int ip_jp_upper_triangular_index , 
							  const class RDM_J_constraints_gradient_class &B);
  
private:  
 
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
   
  const class RDM_G_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_G () const
  {
    return *Wigner_6j_hats_G_ptr;
  }
  
  const class array<double> & get_rho_der_pp_nn_tab () const
  {
    return *rho_der_pp_nn_tab_ptr;
  }
  
  const class array<double> & get_rho_der_pn_tab () const
  {
    return *rho_der_pn_tab_ptr;
  }
      
  const class RDM_PQG_class & get_Gamma_pp_nn () const
  {
    return *Gamma_pp_nn_ptr;
  } 
    
  const class RDM_PQG_class & get_Gamma_pn () const
  {
    return *Gamma_pn_ptr;
  }
  
  class array<unsigned short int> & get_J_constraints_gradient_non_trivial_zero_numbers (const bool is_it_pn)
  {
    if (is_it_pn)
      return J_constraints_gradient_non_trivial_zero_numbers_pn;
    else
      return J_constraints_gradient_non_trivial_zero_numbers_pp_nn;
  }
  
  class array<class sparse_matrix<TYPE> > & get_J_constraints_gradient_scalar_part (const bool is_it_pn)
  {
    if (is_it_pn)
      return J_constraints_gradient_scalar_part_pn;
    else
      return J_constraints_gradient_scalar_part_pp_nn;    
  }
  
  class array<class sparse_matrix<TYPE> > & get_J_constraints_gradient_vector_part (const bool is_it_pn)
  {
    if (is_it_pn)
      return J_constraints_gradient_vector_part_pn;
    else
      return J_constraints_gradient_vector_part_pp_nn;    
  }
  
  void rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
							       const unsigned int sa ,
							       const unsigned int sb);

  void rho_term_der_pp_nn_fill_part (
				     const int ij ,
				     const unsigned int sa , 
				     const unsigned int sb ,
				     const double minus_hat_j_phase ,
				     const double OBME_jc_J_factor_vector_part_phase);
  
  void rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int sa_p , 
								 const unsigned int sb_p);

  
  void rho_prot_term_der_pn_fill_part (
				       const unsigned int sa_p ,
				       const unsigned int sb_p ,
				       const double minus_hat_j_phase ,
				       const double OBME_jc_J_factor_vector_part_phase);
  
  void rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int sa_n , 
								 const unsigned int sb_n);
  
  void rho_neut_term_der_pn_fill_part (
				       const unsigned int sa_n ,
				       const unsigned int sb_n ,
				       const double minus_hat_j_phase ,
				       const double OBME_jc_J_factor_vector_part_phase);
  
  void rho_term_der_part_determine (
				    const enum operation_type operation ,
				    const enum particle_type particle ,
				    const int ij ,
				    const unsigned int sa , 
				    const unsigned int sb ,
				    const double minus_hat_j_phase ,
				    const double OBME_jc_J_factor_vector_part_phase);

  void G_Gamma_term_der_part_determine (
					const enum operation_type operation ,
					const bool is_it_pn ,
					const unsigned int sa ,
					const unsigned int sb ,
					const unsigned int BPp ,
					const int Jp ,
					const unsigned int ac_index ,
					const unsigned int cb_index ,
					const double gradient_ME_vector_part);

  void J_constraints_pp_nn_gradient_calc_store (const enum operation_type operation);

  void J_constraints_prot_pn_gradient_calc_store (const enum operation_type operation);
  void J_constraints_neut_pn_gradient_calc_store (const enum operation_type operation);
  
  void J_constraints_gradients_alloc_calc_store ();

  enum particle_type particle;
  
  double J;
  
  double J_factor_vector_part;

  bool is_J_non_zero;
  
  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
    
  const class RDM_G_Wigner_6j_hats_storage_class *Wigner_6j_hats_G_ptr;
  
  const class array<double> *rho_der_pp_nn_tab_ptr; 

  const class array<double> *rho_der_pn_tab_ptr;
  
  const class RDM_PQG_class *Gamma_pp_nn_ptr;
  
  const class RDM_PQG_class *Gamma_pn_ptr;
  
  class array<unsigned short int> J_constraints_gradient_non_trivial_zero_numbers_pp_nn;
  
  class array<unsigned short int> J_constraints_gradient_non_trivial_zero_numbers_pn;
  
  class array<class sparse_matrix<TYPE> > J_constraints_gradient_scalar_part_pp_nn;
  class array<class sparse_matrix<TYPE> > J_constraints_gradient_vector_part_pp_nn;
  
  class array<class sparse_matrix<TYPE> > J_constraints_gradient_scalar_part_pn;
  class array<class sparse_matrix<TYPE> > J_constraints_gradient_vector_part_pn;
};
  
TYPE Frobenius_scalar_product_matrix_gradient (
					       const bool is_it_der_pn , 
					       const unsigned int BPp ,
					       const int Jp ,
					       const unsigned int ip_jp_upper_triangular_index , 
					       const class RDM_J_constraints_class &A ,
					       const class RDM_J_constraints_gradient_class &B);

TYPE Frobenius_squared_norm_gradient (
				      const bool is_it_der_pn , 
				      const unsigned int BPp ,
				      const int Jp ,
				      const unsigned int ip_jp_upper_triangular_index ,
				      const class RDM_J_constraints_gradient_class &A);
#endif



