#ifndef RDMT2PRIMEGRADIENTCLASS_H
#define RDMT2PRIMEGRADIENTCLASS_H


class RDM_T2_prime_gradient_class
{
public:
  
  RDM_T2_prime_gradient_class ();

  RDM_T2_prime_gradient_class (
			       const class RDM_T2_prime_class &T2_prime ,
			       const class nucleons_data &prot_data ,
			       const class nucleons_data &neut_data ,
			       const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 ,
			       const class array<double> &rho_prot_der_pp_tab ,
			       const class array<double> &rho_prot_der_pn_tab ,
			       const class array<double> &rho_neut_der_nn_tab ,
			       const class array<double> &rho_neut_der_pn_tab ,
			       const class RDM_PQG_class &Gamma_pp ,
			       const class RDM_PQG_class &Gamma_nn ,
			       const class RDM_PQG_class &Gamma_pn);

  RDM_T2_prime_gradient_class (const class RDM_T2_prime_gradient_class &X);
  
  ~RDM_T2_prime_gradient_class ();

  void alloc_calc_store (
			 const class RDM_T2_prime_class &T2_prime ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats_T2 ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);

  void allocate_fill (const class RDM_T2_prime_gradient_class &X);

  void deallocate ();
    
  bool is_it_filled () const
  {
    return (T2_prime_gradient_block_matrices_pp.is_it_filled () || T2_prime_gradient_block_matrices_nn.is_it_filled ()) || T2_prime_gradient_block_matrices_pn.is_it_filled ();
  }
  
  void operator = (const class RDM_T2_prime_gradient_class &X);
  
  const class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return T2_prime_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T2_prime_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T2_prime_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T2_prime_gradient_block_matrices_pp;
  }
  
  class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return T2_prime_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T2_prime_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T2_prime_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T2_prime_gradient_block_matrices_pp;
  }
        
private:  
   
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class RDM_T2_Wigner_9j_hats_storage_class & get_Wigner_9j_hats_T2 () const
  {
    return *Wigner_9j_hats_T2_ptr;
  }       
      
  const class array<double> & get_rho_prot_der_pp_tab () const
  {
    return *rho_prot_der_pp_tab_ptr;
  }
  
  const class array<double> & get_rho_prot_der_pn_tab () const
  {
    return *rho_prot_der_pn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_nn_tab () const
  {
    return *rho_neut_der_nn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_pn_tab () const
  {
    return *rho_neut_der_pn_tab_ptr;
  }
  
  const class RDM_PQG_class & get_Gamma_pp () const
  {
    return *Gamma_pp_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_nn () const
  {
    return *Gamma_nn_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_pn () const
  {
    return *Gamma_pn_ptr;
  } 
  
  const class RDM_T2_prime_class & get_T2_prime () const
  {
    return *T2_prime_ptr;
  }
  
  class array<unsigned short int> & get_T2_prime_gradient_block_matrices_non_trivial_zero_numbers (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp;
      case NEUTRONS_ONLY:    return T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn;
      case PROTONS_NEUTRONS: return T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn;

      default: abort_all ();
      }
    
    return T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp;
  }
  
  class array<class block_sparse_matrix<TYPE> > & get_T2_prime_gradient_block_matrices (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T2_prime_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T2_prime_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T2_prime_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T2_prime_gradient_block_matrices_pp;
  }
  
  void rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
							       const enum particle_type particle ,
							       const unsigned int BP ,
							       const int iJ ,
							       const unsigned int s0 ,
							       const unsigned int s1);

  void rho_term_der_pp_nn_fill_part (
				     const enum particle_type particle ,
				     const unsigned int BP ,
				     const int iJ ,
				     const unsigned int abc_index ,
				     const unsigned int def_index ,
				     const int ij01 ,
				     const unsigned int s0 ,
				     const unsigned int s1 ,
				     const double factor);

  void rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int iJ ,
								 const unsigned int s0_p ,
								 const unsigned int s1_p);

  void rho_prot_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int iJ ,
				       const unsigned int abc_index ,
				       const unsigned int def_index ,
				       const unsigned int s0_p ,
				       const unsigned int s1_p ,
				       const double factor);

  void rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int iJ ,
								 const unsigned int s0_n ,
								 const unsigned int s1_n);

  void rho_neut_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int iJ ,
				       const unsigned int abc_index ,
				       const unsigned int def_index ,
				       const unsigned int s0_n ,
				       const unsigned int s1_n ,
				       const double factor);
  
  void rho_term_der_part_determine (
				    const enum operation_type operation ,
				    const unsigned int BP ,
				    const int iJ ,
				    const unsigned int abc_index ,
				    const unsigned int def_index ,
				    const enum particle_type particle ,
				    const int ij01 ,
				    const unsigned int s0 , 
				    const unsigned int s1 ,
				    const double factor);
  
  void T2_prime_Gamma_term_der_part_determine (
					       const enum operation_type operation ,
					       const enum space_type Gamma_space , 
					       const unsigned int BP ,
					       const int iJ ,
					       const unsigned int abc_index ,
					       const unsigned int def_index ,
					       const unsigned int BPp ,
					       const int Jp ,
					       const unsigned int ip ,
					       const unsigned int jp ,
					       const double gradient_ME);

  void T2_prime_gradient_block_matrices_BP_J_ab_de_equal_part_calc (
								    const enum operation_type operation ,
								    const enum space_type Gamma_space , 
								    const class array<unsigned int> &two_states_indices ,
								    const unsigned int BP ,
								    const int iJ ,
								    const unsigned int abc_index ,
								    const unsigned int def_index ,
								    const bool sa_sd_jb_je_equal ,
								    const bool sb_se_ja_jd_equal ,
								    const bool sa_se_jb_jd_equal ,
								    const bool sb_sd_ja_je_equal ,
								    const bool sc_sf_equal ,
								    const bool jc_jf_equal ,
								    const unsigned int BP_ab ,
								    const int Jab ,
								    const unsigned int ab_index ,
								    const int ijc ,
								    const double inv_delta_norm_ab , 
								    const double inv_delta_norm_phase_ab ,
								    const double inv_delta_norm_de ,
								    const unsigned int sc ,
								    const unsigned int sd ,
								    const unsigned int se ,
								    const unsigned int sf);

  void T2_prime_gradient_block_matrices_sab_sde_equal_part_calc (
								 const enum operation_type operation , 
								 const enum space_type Gamma_space , 
								 const class array<unsigned int> &two_states_indices ,
								 const unsigned int BP ,
								 const int iJ ,
								 const unsigned int abc_index ,
								 const unsigned int def_index ,
								 const double inv_delta_norm_phase_ab ,
								 const double inv_delta_norm_de ,
								 const double inv_delta_norm_sc_s2 ,
								 const double inv_delta_norm_sf_s1 ,
								 const int phase_sab_sde , 
								 const int Jmin_sc_s2 , 
								 const int Jmax_sc_s2 , 
								 const int Jmin_sf_s1 , 
								 const int Jmax_sf_s1 , 
								 const unsigned int BP_sc_s2 ,
								 const int Jab ,
								 const int Jde ,
								 const int ij_s0 ,
								 const int ij_s1 ,
								 const int ijc ,
								 const int ij_s2 ,
								 const int ijf , 
								 const bool are_scf_proton_s12_neutron ,
								 const bool are_scf_neutron_s12_proton ,
								 const unsigned int s1 ,
								 const unsigned int sc ,
								 const unsigned int s2 ,
								 const unsigned int sf);

  void T2_prime_ppp_nnn_gradient_block_matrices_omega_part_calc_store (
								       const enum operation_type operation , 
								       const unsigned int BP ,
								       const int iJ);

  void T2_prime_ppp_nnn_gradient_block_matrices_calc_store (const enum operation_type operation);

  void T2_prime_ppn_gradient_block_matrices_calc_store (const enum operation_type operation);

  void T2_prime_pnn_gradient_block_matrices_omega_part_calc_store (
								   const enum operation_type operation , 
								   const unsigned int BP ,
								   const int iJ);

  void T2_prime_pnn_gradient_block_matrices_calc_store (const enum operation_type operation);

  void T2_prime_pnp_gradient_block_matrices_omega_part_calc_store (
								   const enum operation_type operation , 
								   const unsigned int BP ,
								   const int iJ);
  
  void T2_prime_pnp_gradient_block_matrices_calc_store (const enum operation_type operation);

  void T2_prime_nnp_gradient_block_matrices_calc_store (const enum operation_type operation);

  void T2_prime_ppp_nnn_gradient_block_matrices_alloc_calc_store ();

  void T2_prime_ppn_pnn_pnp_nnp_gradient_block_matrices_alloc_calc_store ();
  
  enum space_type space_pair;
  
  enum particle_type last_particle;

  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;

  const class RDM_T2_Wigner_9j_hats_storage_class *Wigner_9j_hats_T2_ptr;
				 
  const class array<double> *rho_prot_der_pp_tab_ptr; 
  const class array<double> *rho_prot_der_pn_tab_ptr;
  const class array<double> *rho_neut_der_nn_tab_ptr;  
  const class array<double> *rho_neut_der_pn_tab_ptr;

  const class RDM_PQG_class *Gamma_pp_ptr;
  const class RDM_PQG_class *Gamma_nn_ptr;
  const class RDM_PQG_class *Gamma_pn_ptr;
    
  const class RDM_T2_prime_class *T2_prime_ptr;
  
  class array<unsigned short int> T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pp;
  class array<unsigned short int> T2_prime_gradient_block_matrices_non_trivial_zero_numbers_nn;
  class array<unsigned short int> T2_prime_gradient_block_matrices_non_trivial_zero_numbers_pn;
  
  class array<class block_sparse_matrix<TYPE> > T2_prime_gradient_block_matrices_pp;
  class array<class block_sparse_matrix<TYPE> > T2_prime_gradient_block_matrices_nn;
  class array<class block_sparse_matrix<TYPE> > T2_prime_gradient_block_matrices_pn;
};

#endif



