#ifndef RDMRMSRADIUS_H
#define RDMRMSRADIUS_H

namespace RDM_rms_radius
{
  void calc_print (
		   const class input_data_str &input_data , 
		   const class nucleons_data &prot_data , 
		   const class nucleons_data &neut_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn);
}

#endif
