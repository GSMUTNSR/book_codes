#ifndef RDMT1GRADIENTCLASS_H
#define RDMT1GRADIENTCLASS_H


class RDM_T1_gradient_class
{
public:
  
  RDM_T1_gradient_class ();

  RDM_T1_gradient_class (
			 const class RDM_T1_class &T1 ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);

  RDM_T1_gradient_class (const class RDM_T1_gradient_class &X);
  
  ~RDM_T1_gradient_class ();

  void alloc_calc_store (
			 const class RDM_T1_class &T1 ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_T1_Wigner_6j_hats_storage_class &Wigner_6j_hats_T1 ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);

  void allocate_fill (const class RDM_T1_gradient_class &X);

  void deallocate ();

  bool is_it_filled () const
  {
    return (T1_gradient_block_matrices_pp.is_it_filled () || T1_gradient_block_matrices_nn.is_it_filled () || T1_gradient_block_matrices_pn.is_it_filled ());
  }
  
  void operator = (const class RDM_T1_gradient_class &X);
  
  enum space_type get_space_pair () const
  {
    return space_pair;
  }
  
  enum particle_type get_last_particle () const
  {
    return last_particle;
  }
  
  const class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type Gamma_space) const
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T1_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T1_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T1_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T1_gradient_block_matrices_pp;
  }
     
  class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T1_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T1_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T1_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T1_gradient_block_matrices_pp;
  }
     
private:

  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class RDM_T1_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_T1 () const
  {
    return *Wigner_6j_hats_T1_ptr;
  }       
   
  const class array<double> & get_rho_prot_der_pp_tab () const
  {
    return *rho_prot_der_pp_tab_ptr;
  }
  
  const class array<double> & get_rho_prot_der_pn_tab () const
  {
    return *rho_prot_der_pn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_nn_tab () const
  {
    return *rho_neut_der_nn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_pn_tab () const
  {
    return *rho_neut_der_pn_tab_ptr;
  }
  
  const class RDM_PQG_class & get_Gamma_pp () const
  {
    return *Gamma_pp_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_nn () const
  {
    return *Gamma_nn_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_pn () const
  {
    return *Gamma_pn_ptr;
  } 
  
  const class RDM_T1_class & get_T1 () const
  {
    return *T1_ptr;
  }
  
  class array<unsigned short int> & get_T1_gradient_block_matrices_non_trivial_zero_numbers (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T1_gradient_block_matrices_non_trivial_zero_numbers_pp;
      case NEUTRONS_ONLY:    return T1_gradient_block_matrices_non_trivial_zero_numbers_nn;
      case PROTONS_NEUTRONS: return T1_gradient_block_matrices_non_trivial_zero_numbers_pn;

      default: abort_all ();
      }
    
    return T1_gradient_block_matrices_non_trivial_zero_numbers_pp;
  }
  
  class array<class block_sparse_matrix<TYPE> > & get_T1_gradient_block_matrices (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return T1_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return T1_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return T1_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return T1_gradient_block_matrices_pp;
  }
  
  void rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
							       const enum particle_type particle ,
							       const unsigned int BP ,
							       const int iJ ,
							       const unsigned int s0 ,
							       const unsigned int s1);

  void rho_term_der_pp_nn_fill_part (
				     const enum particle_type particle ,
				     const unsigned int BP ,
				     const int iJ ,
				     const unsigned int abc_index ,
				     const unsigned int def_index ,
				     const int ij01 ,
				     const unsigned int s0 ,
				     const unsigned int s1 ,
				     const double factor);

  void rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int iJ ,
								 const unsigned int s0_p ,
								 const unsigned int s1_p);

  void rho_prot_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int iJ ,
				       const unsigned int abc_index ,
				       const unsigned int def_index ,
				       const unsigned int s0_p ,
				       const unsigned int s1_p ,
				       const double factor);

  void rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int iJ ,
								 const unsigned int s0_n ,
								 const unsigned int s1_n);
  
  void rho_neut_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int iJ ,
				       const unsigned int abc_index ,
				       const unsigned int def_index ,
				       const unsigned int s0_n ,
				       const unsigned int s1_n ,
				       const double factor);

  void rho_term_der_part_determine (
				    const enum operation_type operation ,
				    const unsigned int BP ,
				    const int iJ ,
				    const unsigned int abc_index ,
				    const unsigned int def_index ,
				    const enum particle_type particle ,
				    const int ij01 ,
				    const unsigned int s0 , 
				    const unsigned int s1 ,
				    const double factor);
  
  void T1_Gamma_term_der_part_determine (
					 const enum operation_type operation ,
					 const enum space_type Gamma_space ,
					 const unsigned int BP ,
					 const int iJ ,
					 const unsigned int abc_index ,
					 const unsigned int def_index ,
					 const unsigned int BPp ,
					 const int Jp ,
					 const unsigned int ip ,
					 const unsigned int jp ,
					 const double gradient_ME);

  void T1_gradient_block_matrices_sc_sf_equal_part_calc (
							 const enum operation_type operation ,
							 const unsigned int BP ,
							 const int iJ ,
							 const unsigned int abc_index ,
							 const unsigned int def_index , 
							 const bool sa_sd_jb_je_equal ,
							 const bool sb_se_ja_jd_equal ,
							 const bool sa_se_jb_jd_equal ,
							 const bool sb_sd_ja_je_equal ,
							 const double inv_delta_norm_ab ,
							 const double inv_delta_norm_de ,
							 const double inv_delta_norm_phase_ab ,
							 const int phase_de ,
							 const unsigned int BP_de , 
							 const int Jde , 
							 const unsigned int ab_index ,  
							 const int ija ,
							 const int ijb ,
							 const unsigned int sa ,
							 const unsigned int sb ,
							 const unsigned int sd ,
							 const unsigned int se ,
							 const double abcdef_factor);
  
  void T1_gradient_block_matrices_ppp_nnn_sab_sf_equal_part_calc (
								  const enum operation_type operation , 
								  const unsigned int BP ,
								  const int iJ ,
								  const unsigned int abc_index ,
								  const unsigned int def_index ,
								  const bool sc_sd_j1_je_equal ,
								  const bool sc_se_j1_jd_equal ,
								  const bool s1_se_jc_jd_equal ,
								  const bool s1_sd_jc_je_equal ,
								  const double inv_delta_norm_ab ,
								  const double inv_delta_norm_ab_over_sc_s1 ,
								  const double inv_delta_norm_de ,
								  const int phase_de ,
								  const unsigned int BP_de , 
								  const int Jab ,
								  const int Jde ,
								  const int ij0 ,
								  const int ij1 ,
								  const int ijc ,
								  const unsigned int s1 ,
								  const unsigned int sc ,
								  const unsigned int sd ,
								  const unsigned int se ,
								  const int phase_sab_sf ,
								  const double abcdef_factor);
  
  void T1_gradient_block_matrices_ppp_nnn_sc_sde_equal_part_calc (
								  const enum operation_type operation , 
								  const unsigned int BP ,
								  const int iJ ,
								  const unsigned int abc_index ,
								  const unsigned int def_index ,
								  const double inv_delta_norm_de ,
								  const double inv_delta_norm_s3_f ,
								  const int phase_sc_sde , 
								  const int Jmin_sf_s3 , 
								  const int Jmax_sf_s3 , 
								  const unsigned int ab_index ,
								  const unsigned int BP_ab ,
								  const int Jab ,
								  const int Jde ,
								  const int ij2 ,
								  const int ij3 ,
								  const int ijf , 
								  const unsigned int s3 ,
								  const unsigned int sf ,
								  const double abcdef_factor);

  void T1_gradient_block_matrices_sab_sde_equal_part_calc (
							   const enum operation_type operation ,
							   const enum space_type Gamma_space ,
							   const unsigned int BP ,
							   const int iJ ,
							   const unsigned int abc_index ,
							   const unsigned int def_index ,
							   const class array<unsigned int> &two_states_indices ,
							   const double inv_delta_norm_phase_sab_over_sc_s1 ,
							   const double inv_delta_norm_de ,
							   const double inv_delta_norm_sf_s3 ,
							   const int phase_sde ,
							   const int Jmin_sc_s1 , 
							   const int Jmax_sc_s1 ,  
							   const int Jmin_sf_s3 , 
							   const int Jmax_sf_s3 , 
							   const unsigned int BP_sc_s1 ,
							   const int Jab , 
							   const int Jde , 
							   const int ij0 ,
							   const int ij1 ,
							   const int ijc ,
							   const int ij2 ,
							   const int ij3 ,
							   const int ijf ,
							   const bool are_scf_proton_s_neutron ,
							   const bool are_scf_neutron_s_proton ,
							   const unsigned int s1 ,
							   const unsigned int sc ,
							   const unsigned int s3 ,
							   const unsigned int sf ,
							   const double abcdef_factor);
  
  void T1_ppp_nnn_gradient_block_matrices_calc_store (const enum operation_type operation);

  
  void T1_ppn_gradient_block_matrices_calc_store (const enum operation_type operation);

  
  void T1_nnp_gradient_block_matrices_calc_store (const enum operation_type operation);

  
  void T1_ppp_nnn_gradient_block_matrices_alloc_calc_store ();

  
  void T1_ppn_nnp_gradient_block_matrices_alloc_calc_store ();
  
  enum space_type space_pair;
  
  enum particle_type last_particle;

  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
    
  const class RDM_T1_Wigner_6j_hats_storage_class *Wigner_6j_hats_T1_ptr;
  
  const class array<double> *rho_prot_der_pp_tab_ptr; 
  const class array<double> *rho_prot_der_pn_tab_ptr;
  const class array<double> *rho_neut_der_nn_tab_ptr;  
  const class array<double> *rho_neut_der_pn_tab_ptr;

  const class RDM_PQG_class *Gamma_pp_ptr;
  const class RDM_PQG_class *Gamma_nn_ptr;
  const class RDM_PQG_class *Gamma_pn_ptr;
  
  const class RDM_T1_class *T1_ptr;
    
  class array<unsigned short int> T1_gradient_block_matrices_non_trivial_zero_numbers_pp;
  class array<unsigned short int> T1_gradient_block_matrices_non_trivial_zero_numbers_nn;
  class array<unsigned short int> T1_gradient_block_matrices_non_trivial_zero_numbers_pn;
  
  class array<class block_sparse_matrix<TYPE> > T1_gradient_block_matrices_pp;
  class array<class block_sparse_matrix<TYPE> > T1_gradient_block_matrices_nn;
  class array<class block_sparse_matrix<TYPE> > T1_gradient_block_matrices_pn;
};

#endif



