#ifndef RDMT2PRIMECLASS_H
#define RDMT2PRIMECLASS_H

class RDM_T2_prime_class
{
public:
  
  RDM_T2_prime_class ();

  RDM_T2_prime_class (
		      const enum space_type space_pair_c ,
		      const enum particle_type last_particle_c ,
		      const bool truncation_hw_c ,
		      const bool truncation_ph_c ,
		      const int E_max_hw_c ,
		      const int n_scat_max_c , 
		      const class nucleons_data &prot_data ,
		      const class nucleons_data &neut_data ,
		      const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats);

  RDM_T2_prime_class (const class RDM_T2_prime_class &X);

  ~RDM_T2_prime_class ();

  void allocate (
		 const enum space_type space_pair_c ,
		 const enum particle_type last_particle_c ,
		 const bool truncation_hw_c ,
		 const bool truncation_ph_c ,
		 const int E_max_hw_c ,
		 const int n_scat_max_c , 
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data ,
		 const class RDM_T2_Wigner_9j_hats_storage_class &Wigner_9j_hats);

  void allocate_fill (const class RDM_T2_prime_class &X);

  void deallocate ();
            
  enum space_type get_space_pair () const
  {
    return space_pair;
  }
  
  enum particle_type get_last_particle () const
  {
    return last_particle;
  }
  
  bool get_truncation_hw () const
  {
    return truncation_hw;
  }
  
  bool get_truncation_ph () const
  {
    return truncation_ph;
  }
  
  int get_E_max_hw () const
  {
    return E_max_hw;
  }
  
  int get_n_scat_max () const
  {
    return n_scat_max;
  }
  
  const class array<unsigned int> & get_matrix_dimensions () const
  {
    return matrix_dimensions;
  }
  
  const class array<unsigned int> & get_T2_matrix_dimensions () const
  {
    return T2_matrix_dimensions;
  }
  
  const class array<unsigned int> & get_three_states_indices () const
  {
    return three_states_indices;
  }
	
  const class array<unsigned int> & get_BP_table () const
  {
    return BP_table;
  }
        
  const class array<int> & get_iJmin_pair_last_particle_tab () const
  {
    return iJmin_pair_last_particle_tab;
  }
    
  const class array<int> & get_iJmax_pair_last_particle_tab () const
  {
    return iJmax_pair_last_particle_tab;
  }
    
  const class array<bool> & get_is_it_in_space_tab () const
  {
    return is_it_in_space_tab;
  }
  
  const class block_matrix<TYPE> & get_block_matrix () const
  {
    return block_matrix_abcdef;
  }
    
  class block_matrix<TYPE> & get_block_matrix ()
  {
    return block_matrix_abcdef;
  }

  bool is_it_filled () const
  {
    return (block_matrix_abcdef.is_it_filled ());
  }
  
  void block_matrix_fill (const class block_matrix<TYPE> &X);
  
  void operator = (const class RDM_T2_prime_class &X);
  
  void operator += (const class RDM_T2_prime_class &X);
  void operator -= (const class RDM_T2_prime_class &X);
  
  void add_scalar_diagonal_part (const TYPE &x);
  
  void remove_scalar_diagonal_part (const TYPE &x);
  
  void operator *= (const TYPE &x);
  void operator /= (const TYPE &x);

  unsigned int get_block_symmetric_matrix_elements_number () const;
  
  double infinite_norm () const;
  
  void zero ();
  
  void T2_prime_ppp_nnn_block_matrices_add (
					    const class array<TYPE> &rho_tab ,
					    const class RDM_PQG_class &Gamma);
  
  void T2_prime_ppn_block_matrices_add (
					const class array<TYPE> &rho_neut_tab ,
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_pn);
  
  void T2_prime_nnp_block_matrices_add (
					const class array<TYPE> &rho_prot_tab ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn);
  
  void T2_prime_pnp_block_matrices_add (
					const class array<TYPE> &rho_prot_tab ,
					const class array<TYPE> &rho_neut_tab ,
					const class RDM_PQG_class &Gamma_pp ,
					const class RDM_PQG_class &Gamma_pn);

  void T2_prime_pnn_block_matrices_add (
					const class array<TYPE> &rho_prot_tab ,
					const class array<TYPE> &rho_neut_tab ,
					const class RDM_PQG_class &Gamma_nn ,
					const class RDM_PQG_class &Gamma_pn);
    
  void precision_T2_ppp_nnn_class_file_calc_print (
						   const int Z ,
						   const int N ,
						   const unsigned int RDM_BP ,
						   const double RDM_J ,
						   const unsigned int RDM_vector_index ,
						   const class RDM_PQG_class &Gamma) const;

  void precision_T2_ppn_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_pp) const;
  
  void precision_T2_nnp_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_nn) const;
  
  void precision_T2_pnp_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_pn) const;  

  void precision_T2_pnn_class_file_calc_print (
					       const int Z ,
					       const int N ,
					       const unsigned int RDM_BP ,
					       const double RDM_J ,
					       const unsigned int RDM_vector_index ,
					       const class RDM_PQG_class &Gamma_pn) const;
  
  void make_it_positive_definite (
				  class block_matrix<TYPE> &P_transpose ,
				  class block_matrix<TYPE> &Dp_P_transpose);
  
#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif
  
private:
  
  void BP_J_tables_dimensions_indices_ppp_nnn_alloc_calc ();
    
  void BP_J_tables_dimensions_indices_ppn_alloc_calc ();
  
  void BP_J_tables_dimensions_indices_pnn_alloc_calc ();
  
  void BP_J_tables_dimensions_indices_pnp_alloc_calc ();
  
  void BP_J_tables_dimensions_indices_nnp_alloc_calc ();

  TYPE T2_prime_matrix_BP_J_ab_de_equal_part_calc (
						   const class array<TYPE> &rho_tab ,
						   const class RDM_PQG_class &Gamma ,
						   const unsigned int ab_index ,
						   const bool sa_sd_jb_je_equal ,
						   const bool sb_se_ja_jd_equal ,
						   const bool sa_se_jb_jd_equal ,
						   const bool sb_sd_ja_je_equal ,
						   const bool sc_sf_equal ,
						   const bool jc_jf_equal ,
						   const unsigned int BP_ab ,
						   const int Jab ,
						   const double inv_delta_norm_ab , 
						   const double inv_delta_norm_phase_ab ,
						   const double inv_delta_norm_de ,
						   const unsigned int sc ,
						   const unsigned int sd ,
						   const unsigned int se ,
						   const unsigned int sf);

  TYPE T2_prime_matrix_sab_sde_equal_part_calc (
						const class RDM_PQG_class &Gamma ,
						const int iJ ,
						const double inv_delta_norms_phase_ab ,
						const int phase_sab_sde , 
						const int Jmin_sc_s2 , 
						const int Jmax_sc_s2 , 
						const int Jmin_sf_s1 , 
						const int Jmax_sf_s1 , 
						const unsigned int BP_sc_s2 ,
						const int Jab ,
						const int Jde ,
						const int ij_s0 ,						  
						const int ij_s1 ,
						const int ijc ,
						const int ij_s2 ,
						const int ijf , 
						const bool are_scf_proton_s12_neutron ,
						const bool are_scf_neutron_s12_proton ,
						const unsigned int s1 ,
						const unsigned int sc ,
						const unsigned int s2 ,
						const unsigned int sf);
  
  void T2_prime_ppp_nnn_matrix_omega_part_add (
					       const class array<TYPE> &rho_tab ,
					       const class RDM_PQG_class &Gamma ,
					       const unsigned int BP ,
					       const int iJ);
 
  void T2_prime_pnp_matrix_omega_part_add (
					   const class array<TYPE> &rho_neut_tab ,
					   const class RDM_PQG_class &Gamma_pn ,
					   const unsigned int BP ,
					   const int iJ);
  
  void T2_prime_pnn_matrix_omega_part_add (
					   const class array<TYPE> &rho_prot_tab ,
					   const class RDM_PQG_class &Gamma_pn ,
					   const unsigned int BP ,
					   const int iJ);
  
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class RDM_T2_Wigner_9j_hats_storage_class & get_Wigner_9j_hats_T2 () const
  {
    return *Wigner_9j_hats_T2_ptr;
  }
  
  enum space_type space_pair;
  
  enum particle_type last_particle;

  bool truncation_hw;
  bool truncation_ph;
  
  int E_max_hw;

  int n_scat_max;

  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
    
  const class RDM_T2_Wigner_9j_hats_storage_class *Wigner_9j_hats_T2_ptr;
  
  class array<unsigned int> matrix_dimensions;
  
  class array<unsigned int> T2_matrix_dimensions;
  
  class array<unsigned int> three_states_indices;
	
  class array<unsigned int> BP_table;

  class array<int> iJmin_pair_last_particle_tab;
  class array<int> iJmax_pair_last_particle_tab;
  
  class array<unsigned int> alpha_number_same_shell_tab;
    
  class array<double> J_states_components_same_shell;
  
  class array<bool> is_it_in_space_tab;
  
  class block_matrix<TYPE> block_matrix_abcdef;
  
  class array<TYPE> block_matrix_abcdef_eigenvalues;
  
  class array<TYPE> T_MPI;
};




#endif



