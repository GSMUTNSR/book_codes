#ifndef RDMGWIGNER6JHATSSTORAGECLASS_H
#define RDMGWIGNER6JHATSSTORAGECLASS_H

class RDM_G_Wigner_6j_hats_storage_class
{
public:
  
  RDM_G_Wigner_6j_hats_storage_class ();

  RDM_G_Wigner_6j_hats_storage_class (
				      const class nucleons_data &prot_data ,
				      const class nucleons_data &neut_data);

  RDM_G_Wigner_6j_hats_storage_class (const class RDM_G_Wigner_6j_hats_storage_class &X);
  
  ~RDM_G_Wigner_6j_hats_storage_class ();

  void alloc_calc_store (
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data);

  void allocate_fill (const class RDM_G_Wigner_6j_hats_storage_class &X);

  void deallocate ();
  
  bool is_it_filled () const
  {
    return (Wigner_6j_hats_tab.is_it_filled ());
  }
    
  double operator () (
		      const int ija ,
		      const int ijb ,
		      const int ijc ,
		      const int ijd ,
		      const int J ,
		      const int Jp) const
  {
    const unsigned int index = Wigner_6j_hats_indices(ija , ijb , ijc , ijd , J , Jp);
    
    if (index == Wigner_6j_hats_indices.dimension_total ()) return 0.0;
 
    const double Wigner_6j_hats = Wigner_6j_hats_tab(index);

    return Wigner_6j_hats;
  }

private:
  
  void Wigner_6j_hats_indices_tabs_determine (
					      const enum operation_type operation ,
					      const class nucleons_data &prot_data ,
					      const class nucleons_data &neut_data ,
					      unsigned int &dimension);
  
  class array<unsigned int> Wigner_6j_hats_indices;
  
  class array<double> Wigner_6j_hats_tab;
};

#endif



