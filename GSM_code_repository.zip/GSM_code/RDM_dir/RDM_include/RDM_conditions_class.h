#ifndef RDMCONDITIONSCLASS_H
#define RDMCONDITIONSCLASS_H

class RDM_conditions_class
{
public:
    
  RDM_conditions_class ();
    
  RDM_conditions_class (
			const enum interaction_type inter_c ,
			const class TBMEs_class &TBMEs_pn ,
			const enum RDM_matrix_constraint_type RDM_matrix_constraint_c ,
			const bool is_there_CM_correction_c ,
			const bool is_there_isospin_constraint_c ,
			const bool are_there_J_constraints_c ,
			const bool is_there_E_reference_c ,
			const bool truncation_hw ,
			const bool truncation_ph ,
			const int E_max_hw ,
			const int n_scat_max , 
			const double J_c ,
			const TYPE E_reference_c ,
			const double H_renormalization_factor_c ,
			const class nucleons_data &prot_data ,
			const class nucleons_data &neut_data);
  
  RDM_conditions_class (const class RDM_conditions_class &X);
    
  void allocate (
		 const enum interaction_type inter_c ,
		 const class TBMEs_class &TBMEs_pn ,
		 const enum RDM_matrix_constraint_type RDM_matrix_constraint_c ,
		 const bool is_there_CM_correction_c ,
		 const bool is_there_isospin_constraint_c ,
		 const bool are_there_J_constraints_c ,
		 const bool is_there_E_reference_c ,
		 const bool truncation_hw ,
		 const bool truncation_ph ,
		 const int E_max_hw ,
		 const int n_scat_max , 
		 const double J_c ,
		 const TYPE E_reference_c ,
		 const double H_renormalization_factor_c ,
		 const class nucleons_data &prot_data ,
		 const class nucleons_data &neut_data);
  
  void allocate_fill (const class RDM_conditions_class &X);
  
  void deallocate ();
      
  enum interaction_type get_inter () const
  {
    return inter;
  }
		
  const class TBMEs_class & get_TBMEs_pn () const
  {
    return *TBMEs_pn_ptr;
  }
      
  enum RDM_matrix_constraint_type get_RDM_matrix_constraint () const
  {
    return RDM_matrix_constraint;
  }
  
  bool get_is_there_G_constraint () const
  {
    return is_there_G_constraint;
  }
  
  bool get_is_there_T1_constraint () const
  {
    return is_there_T1_constraint;
  }
  
  bool get_is_there_T2_prime_constraint () const
  {
    return is_there_T2_prime_constraint;
  }
  
  bool get_is_there_CM_correction () const
  {
    return is_there_CM_correction;
  }
  
  bool get_is_there_isospin_constraint () const
  {
    return is_there_isospin_constraint;
  }
  
  bool get_are_there_J_constraints () const
  {
    return are_there_J_constraints;
  }
  
  bool get_is_there_E_reference () const
  {
    return is_there_E_reference;
  }
  
  double get_J () const
  {
    return J;
  }
  
  TYPE get_E_reference () const
  {
    return E_reference;
  }
  
  double get_H_renormalization_factor () const
  {
    return H_renormalization_factor;
  }
  
  bool get_are_there_pairs (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return are_there_pp_pairs;
      case NEUTRONS_ONLY:    return are_there_nn_pairs;
      case PROTONS_NEUTRONS: return are_there_pn_pairs;
	  
      default: abort_all ();
      }

    return are_there_pp_pairs;
  }
  
  const TYPE & get_Delta_pairs_number_dependent_term (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_pp_pairs_number_dependent_term;
      case NEUTRONS_ONLY:    return Delta_nn_pairs_number_dependent_term;
      case PROTONS_NEUTRONS: return Delta_pn_pairs_number_dependent_term;
	  
      default: abort_all ();
      }

    return Delta_pp_pairs_number_dependent_term;
  }
    
  const TYPE & get_Delta_J_dependent_term () const
  {
    return Delta_J_dependent_term;
  }
     
  const TYPE & get_Delta_Hcm_dependent_term () const
  {
    return Delta_Hcm_dependent_term;
  }
     
  const TYPE & get_average_T2_dependent_term () const
  {
    return average_T2_dependent_term;
  }
     
  const TYPE & get_Delta_E_reference_dependent_term () const
  {
    return Delta_E_reference_dependent_term;
  }
     
  const class RDM_PQG_class & get_P_dependent_term (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return P_pp_dependent_term;	  
      case NEUTRONS_ONLY:    return P_nn_dependent_term;	    
      case PROTONS_NEUTRONS: return P_pn_dependent_term;
	  
      default: abort_all ();
      }

    return P_pp_dependent_term;
  }
  
  const class RDM_PQG_class & get_Q_dependent_term (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_dependent_term;	  
      case NEUTRONS_ONLY:    return Q_nn_dependent_term;	    
      case PROTONS_NEUTRONS: return Q_pn_dependent_term;
	  
      default: abort_all ();
      }

    return Q_pp_dependent_term;
  }
    
  const class RDM_PQG_class & get_G_dependent_term (const enum space_type space , const enum particle_type last_particle) const
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_dependent_term");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_dependent_term");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_dependent_term;
      case NEUTRONS_ONLY: return G_nn_dependent_term;
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_dependent_term;
	  else if (last_particle == NEUTRON)
	    return G_pn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_dependent_term in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_dependent_term;
  }
  
  
  const class RDM_J_constraints_class & get_J_constraints_dependent_term (const enum particle_type particle) const
  {
    switch (particle)
      {
      case PROTON:  return J_constraints_pp_dependent_term;
      case NEUTRON: return J_constraints_nn_dependent_term;
	  
      default: abort_all ();
      }

    return J_constraints_pp_dependent_term;
  }
  
  const class RDM_T1_class & get_T1_dependent_term (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T1_ppn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_dependent_term;
	  else if (last_particle == PROTON)
	    return T1_nnp_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T1_class is either protons only or neutrons only in get_T1_dependent_term");
      }
    return T1_ppp_dependent_term;
  }
    
  const class RDM_T2_prime_class & get_T2_prime_dependent_term (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_dependent_term;
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T2_prime_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_dependent_term");
      }

    return T2_prime_ppp_dependent_term;
  }
       
  const class RDM_rho_coupled_modified_class & get_rho_coupled_modified_dependent_term (const enum particle_type particle) const
  {
    switch (particle)
      {
      case PROTON:  return rho_pp_coupled_modified_dependent_term;	  
      case NEUTRON: return rho_nn_coupled_modified_dependent_term;	    
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term;
  }
  
  const class block_matrix<TYPE> & get_P_dependent_term_block_matrix (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return P_pp_dependent_term.get_block_matrix ();	  
      case NEUTRONS_ONLY:    return P_nn_dependent_term.get_block_matrix ();	    
      case PROTONS_NEUTRONS: return P_pn_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return P_pp_dependent_term.get_block_matrix ();
  }
  
  const class block_matrix<TYPE> & get_Q_dependent_term_block_matrix (const enum space_type space) const
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_dependent_term.get_block_matrix ();	  
      case NEUTRONS_ONLY:    return Q_nn_dependent_term.get_block_matrix ();	    
      case PROTONS_NEUTRONS: return Q_pn_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return Q_pp_dependent_term.get_block_matrix ();
  }
    
  const class block_matrix<TYPE> & get_G_dependent_term_block_matrix (const enum space_type space , const enum particle_type last_particle) const
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_dependent_term");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_dependent_term");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_dependent_term.get_block_matrix ();
      case NEUTRONS_ONLY: return G_nn_dependent_term.get_block_matrix ();
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return G_pn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_dependent_term in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_dependent_term.get_block_matrix ();
  }
  
  const class block_matrix<TYPE> & get_T1_dependent_term_block_matrix (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T1_ppn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term_block_matrix (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_dependent_term.get_block_matrix ();
	  else if (last_particle == PROTON)
	    return T1_nnp_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term_block_matrix (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T1_class is either protons only or neutrons only in get_T1_dependent_term_block_matrix");
      }
    return T1_ppp_dependent_term.get_block_matrix ();
  }
    
  const class block_matrix<TYPE> & get_T2_prime_dependent_term_block_matrix (const enum space_type space_pair , const enum particle_type last_particle) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_dependent_term.get_block_matrix ();
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T2_prime_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_dependent_term_block_matrix");
      }
    
    return T2_prime_ppp_dependent_term.get_block_matrix ();
  }
     
  const class block_matrix<TYPE> & get_rho_coupled_modified_dependent_term_block_matrix (const enum particle_type particle) const
  {
    switch (particle)
      {
      case PROTON:  return rho_pp_coupled_modified_dependent_term.get_block_matrix ();
      case NEUTRON: return rho_nn_coupled_modified_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term.get_block_matrix ();
  }
  
  const class block_matrix<TYPE> & get_rho_uncoupled_dependent_term_block_matrix (const enum particle_type particle) const
  {
    switch (particle)
      {
      case PROTON:  return rho_pp_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
      case NEUTRON: return rho_nn_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
  }  
  
  const class RDM_G_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_G () const
  {
    return Wigner_6j_hats_G;
  }
  
  const class RDM_T1_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_T1 () const
  {
    return Wigner_6j_hats_T1;
  }
  
  const class RDM_T2_Wigner_9j_hats_storage_class & get_Wigner_9j_hats_T2 () const
  {
    return Wigner_9j_hats_T2;
  }
  
  TYPE & get_Delta_pairs_number_dependent_term (const enum space_type space)
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Delta_pp_pairs_number_dependent_term;
      case NEUTRONS_ONLY:    return Delta_nn_pairs_number_dependent_term;
      case PROTONS_NEUTRONS: return Delta_pn_pairs_number_dependent_term;
	  
      default: abort_all ();
      }

    return Delta_pp_pairs_number_dependent_term;
  }
    
  TYPE & get_Delta_J_dependent_term ()
  {
    return Delta_J_dependent_term;
  }
     
  TYPE & get_Delta_Hcm_dependent_term ()
  {
    return Delta_Hcm_dependent_term;
  }
     
  TYPE & get_average_T2_dependent_term ()
  {
    return average_T2_dependent_term;
  }
     
  TYPE & get_Delta_E_reference_dependent_term ()
  {
    return Delta_E_reference_dependent_term;
  }
  
  class RDM_PQG_class & get_P_dependent_term (const enum space_type space) 
  {
    switch (space)
      {
      case PROTONS_ONLY:     return P_pp_dependent_term;	  
      case NEUTRONS_ONLY:    return P_nn_dependent_term;	    
      case PROTONS_NEUTRONS: return P_pn_dependent_term;
	  
      default: abort_all ();
      }

    return P_pp_dependent_term;
  }
  
  class RDM_PQG_class & get_Q_dependent_term (const enum space_type space) 
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_dependent_term;	  
      case NEUTRONS_ONLY:    return Q_nn_dependent_term;	    
      case PROTONS_NEUTRONS: return Q_pn_dependent_term;
	  
      default: abort_all ();
      }

    return Q_pp_dependent_term;
  }
    
  class RDM_PQG_class & get_G_dependent_term (const enum space_type space , const enum particle_type last_particle) 
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_dependent_term");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_dependent_term");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_dependent_term;
      case NEUTRONS_ONLY: return G_nn_dependent_term;
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_dependent_term;
	  else if (last_particle == NEUTRON)
	    return G_pn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_dependent_term in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_dependent_term;
  }
  
  class RDM_J_constraints_class & get_J_constraints_dependent_term (const enum particle_type particle)
  {
    switch (particle)
      {
      case PROTON:  return J_constraints_pp_dependent_term;
      case NEUTRON: return J_constraints_nn_dependent_term;
	  
      default: abort_all ();
      }

    return J_constraints_pp_dependent_term;
  }
  
  class RDM_T1_class & get_T1_dependent_term (const enum space_type space_pair , const enum particle_type last_particle) 
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T1_ppn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_dependent_term;
	  else if (last_particle == PROTON)
	    return T1_nnp_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T1_class is either protons only or neutrons only in get_T1_dependent_term");
      }
    return T1_ppp_dependent_term;
  }
    
  class RDM_T2_prime_class & get_T2_prime_dependent_term (const enum space_type space_pair , const enum particle_type last_particle) 
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_dependent_term;
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_dependent_term;
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_dependent_term;
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T2_prime_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_dependent_term");
      }
    
    return T2_prime_ppp_dependent_term;
  }
      
  class RDM_rho_coupled_modified_class & get_rho_coupled_modified_dependent_term (const enum particle_type particle)
  {
    switch (particle)
      {
      case PROTON:     return rho_pp_coupled_modified_dependent_term;	  
      case NEUTRON:    return rho_nn_coupled_modified_dependent_term;	    
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term;
  }
       
  class block_matrix<TYPE> & get_P_dependent_term_block_matrix (const enum space_type space) 
  {
    switch (space)
      {
      case PROTONS_ONLY:     return P_pp_dependent_term.get_block_matrix ();	  
      case NEUTRONS_ONLY:    return P_nn_dependent_term.get_block_matrix ();	    
      case PROTONS_NEUTRONS: return P_pn_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return P_pp_dependent_term.get_block_matrix ();
  }
  
  class block_matrix<TYPE> & get_Q_dependent_term_block_matrix (const enum space_type space) 
  {
    switch (space)
      {
      case PROTONS_ONLY:     return Q_pp_dependent_term.get_block_matrix ();	  
      case NEUTRONS_ONLY:    return Q_nn_dependent_term.get_block_matrix ();	    
      case PROTONS_NEUTRONS: return Q_pn_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return Q_pp_dependent_term.get_block_matrix ();
  }
    
  class block_matrix<TYPE> & get_G_dependent_term_block_matrix (const enum space_type space , const enum particle_type last_particle) 
  {
    if ((space == PROTONS_ONLY)  && (last_particle != PROTON))  error_message_print_abort ("The last particle is proton if one has only protons in get_G_dependent_term");
    if ((space == NEUTRONS_ONLY) && (last_particle != NEUTRON)) error_message_print_abort ("The last particle is neutron if one has only neutrons in get_G_dependent_term");
    
    switch (space)
      {
      case PROTONS_ONLY:  return G_pp_dependent_term.get_block_matrix ();
      case NEUTRONS_ONLY: return G_nn_dependent_term.get_block_matrix ();
      
      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return G_np_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return G_pn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_G_dependent_term in proton-neutron space");
	  
	} break;

      default: abort_all ();
      }
      
    return G_pp_dependent_term.get_block_matrix ();
  }
    
  class block_matrix<TYPE> & get_T1_dependent_term_block_matrix (const enum space_type space_pair , const enum particle_type last_particle) 
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T1_ppp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T1_ppn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term_block_matrix (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T1_nnn_dependent_term.get_block_matrix ();
	  else if (last_particle == PROTON)
	    return T1_nnp_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T1_dependent_term_block_matrix (NEUTRONS_ONLY)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T1_class is either protons only or neutrons only in get_T1_dependent_term_block_matrix");
      }
    return T1_ppp_dependent_term.get_block_matrix ();
  }
    
  class block_matrix<TYPE> & get_T2_prime_dependent_term_block_matrix (const enum space_type space_pair , const enum particle_type last_particle) 
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:
	{
	  if (last_particle == PROTON)
	    return T2_prime_ppp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T2_prime_ppn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (PROTONS_ONLY)");
	  
	} break;

      case NEUTRONS_ONLY:
	{
	  if (last_particle == NEUTRON)
	    return T2_prime_nnn_dependent_term.get_block_matrix ();
	  else if (last_particle == PROTON)
	    return T2_prime_nnp_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (NEUTRONS_ONLY)");
	  
	} break;

      case PROTONS_NEUTRONS:
	{
	  if (last_particle == PROTON)
	    return T2_prime_pnp_dependent_term.get_block_matrix ();
	  else if (last_particle == NEUTRON)
	    return T2_prime_pnn_dependent_term.get_block_matrix ();
	  else
	    error_message_print_abort ("The last particle is proton or neutron in get_T2_prime_dependent_term_block_matrix (PROTONS_NEUTRONS)");
	  
	} break;

      default: error_message_print_abort ("The pair space in RDM_T2_prime_class is either protons only, neutrons only or protons-neutrons in get_T2_prime_dependent_term_block_matrix");
      }

    return T2_prime_ppp_dependent_term.get_block_matrix ();
  }
       
  class block_matrix<TYPE> & get_rho_coupled_modified_dependent_term_block_matrix (const enum particle_type particle)
  {
    switch (particle)
      {
      case PROTON:  return rho_pp_coupled_modified_dependent_term.get_block_matrix ();
      case NEUTRON: return rho_nn_coupled_modified_dependent_term.get_block_matrix ();
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term.get_block_matrix ();
  }
  
  class block_matrix<TYPE> & get_rho_uncoupled_dependent_term_block_matrix (const enum particle_type particle)
  {
    switch (particle)
      {
      case PROTON:  return rho_pp_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
      case NEUTRON: return rho_nn_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
	  
      default: abort_all ();
      }

    return rho_pp_coupled_modified_dependent_term.get_rho_uncoupled_block_matrix ();
  }
  
  bool is_it_filled () const
  {
    return (inter != NO_INTERACTION);
  }
    
  void calc (
	     const class RDM_PQG_class &Gamma_pp ,
	     const class RDM_PQG_class &Gamma_nn ,
	     const class RDM_PQG_class &Gamma_pn);
  
  void zero ();
  
  void operator = (const class RDM_conditions_class &X);
  
  void operator += (const class RDM_conditions_class &X);
  void operator -= (const class RDM_conditions_class &X);
  
  void add_scalar_diagonal_part (const TYPE &x);
  
  void remove_scalar_diagonal_part (const TYPE &x);

  void operator *= (const TYPE &x);  
  void operator /= (const TYPE &x);
  
  double infinite_norm () const;
  
  void A_Gamma_add (
		    const class RDM_PQG_class &Gamma_pp ,
		    const class RDM_PQG_class &Gamma_nn ,
		    const class RDM_PQG_class &Gamma_pn , 
		    const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
		    const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified);
  
  void A_Gamma_calc (
		     const class RDM_PQG_class &Gamma_pp ,
		     const class RDM_PQG_class &Gamma_nn ,
		     const class RDM_PQG_class &Gamma_pn , 
		     const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
		     const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified);
  
  void A_Gamma_add_pp_nn_linear_part (
				      const enum particle_type particle , 
				      const class RDM_PQG_class &Gamma_pp_nn ,
				      const class RDM_rho_coupled_modified_class &rho_pp_nn_coupled_modified ,
				      class RDM_conditions_class &helper_add ,
				      class RDM_conditions_gradient_class &A_Gamma_gradients);
  
  void A_Gamma_add_pn_linear_part (
				   const class RDM_PQG_class &Gamma_pn ,
				   class RDM_conditions_class &helper_add ,
				   class RDM_conditions_gradient_class &A_Gamma_gradients);
  
  void A_Gamma_add_linear_part (
				const class RDM_PQG_class &Gamma_pp ,
				const class RDM_PQG_class &Gamma_nn ,
				const class RDM_PQG_class &Gamma_pn ,
				const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
				const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
				class RDM_conditions_class &helper_add ,
				class RDM_conditions_gradient_class &A_Gamma_gradients);
  
  void A_Gamma_calc_linear_part (
				 const class RDM_PQG_class &Gamma_pp ,
				 const class RDM_PQG_class &Gamma_nn ,
				 const class RDM_PQG_class &Gamma_pn ,
				 const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
				 const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
				 class RDM_conditions_class &helper_add ,
				 class RDM_conditions_gradient_class &A_Gamma_gradients);
  
  void A_Gamma_add (
		    const class RDM_conditions_class &A_Gamma_zero ,
		    const class RDM_PQG_class &Gamma_pp ,
		    const class RDM_PQG_class &Gamma_nn ,
		    const class RDM_PQG_class &Gamma_pn ,
		    const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
		    const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
		    class RDM_conditions_class &helper_add ,
		    class RDM_conditions_gradient_class &A_Gamma_gradients);
  
  void A_Gamma_calc (
		     const class RDM_conditions_class &A_Gamma_zero ,
		     const class RDM_PQG_class &Gamma_pp ,
		     const class RDM_PQG_class &Gamma_nn ,
		     const class RDM_PQG_class &Gamma_pn ,
		     const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
		     const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified ,
		     class RDM_conditions_class &helper_add ,
		     class RDM_conditions_gradient_class &A_Gamma_gradients);
    
  void transpose ();
  
  void symmetrize ();
    
  void impose_positive_definiteness_zero_conditions_rho_N_representability (
									    class RDM_conditions_class &P_transpose ,
									    class RDM_conditions_class &Dp_P_transpose);
  
  TYPE Frobenius_squared_norm () const;
  
  TYPE Frobenius_norm () const;
  
  void print_precisions_GSM_RDM_class_file (
					    const enum space_type space , 
					    const int Z ,
					    const int N ,
					    const unsigned int RDM_BP ,
					    const double RDM_J ,
					    const unsigned int RDM_vector_index) const;
  
  void print_gradient_direct_formulas_precisions (
						  const enum space_type space , 
						  const class RDM_conditions_gradient_class &A_Gamma_gradients ,
						  const class RDM_PQG_class &Gamma_pp ,
						  const class RDM_PQG_class &Gamma_nn ,
						  const class RDM_PQG_class &Gamma_pn ,
						  const class RDM_rho_coupled_modified_class &rho_pp_coupled_modified ,
						  const class RDM_rho_coupled_modified_class &rho_nn_coupled_modified);
  
#ifdef UseMPI
  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);
#endif
	
private:
  
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
    
  enum interaction_type inter;
  
  const class TBMEs_class *TBMEs_pn_ptr;
		   
  enum RDM_matrix_constraint_type RDM_matrix_constraint;
  
  bool is_there_G_constraint;
  bool is_there_T1_constraint;
  bool is_there_T2_prime_constraint;
  
  bool is_there_CM_correction;
  
  bool is_there_isospin_constraint;
  
  bool are_there_J_constraints;
  
  bool is_there_E_reference;

  double J;
    
  TYPE E_reference;

  double H_renormalization_factor;

  bool are_there_pp_pairs;
  bool are_there_nn_pairs;
  bool are_there_pn_pairs;
  
  TYPE Delta_pp_pairs_number_dependent_term;
  TYPE Delta_nn_pairs_number_dependent_term;  
  TYPE Delta_pn_pairs_number_dependent_term;
  
  TYPE Delta_J_dependent_term;
  
  TYPE Delta_Hcm_dependent_term;
  
  TYPE average_T2_dependent_term;
  
  TYPE Delta_E_reference_dependent_term;
  
  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;

  class RDM_G_Wigner_6j_hats_storage_class Wigner_6j_hats_G;
  
  class RDM_T1_Wigner_6j_hats_storage_class Wigner_6j_hats_T1;

  class RDM_T2_Wigner_9j_hats_storage_class Wigner_9j_hats_T2;
  
  class RDM_PQG_class P_pp_dependent_term;
  class RDM_PQG_class P_nn_dependent_term;
  class RDM_PQG_class P_pn_dependent_term;
  
  class RDM_PQG_class Q_pp_dependent_term;
  class RDM_PQG_class Q_nn_dependent_term;
  class RDM_PQG_class Q_pn_dependent_term;
  
  class RDM_PQG_class G_pp_dependent_term;
  class RDM_PQG_class G_nn_dependent_term;
  class RDM_PQG_class G_pn_dependent_term;
  class RDM_PQG_class G_np_dependent_term;
  
  class RDM_T1_class T1_ppp_dependent_term;
  class RDM_T1_class T1_nnn_dependent_term;
  class RDM_T1_class T1_ppn_dependent_term;
  class RDM_T1_class T1_nnp_dependent_term;
  
  class RDM_J_constraints_class J_constraints_pp_dependent_term;
  class RDM_J_constraints_class J_constraints_nn_dependent_term;
  
  class RDM_T2_prime_class T2_prime_ppp_dependent_term;
  class RDM_T2_prime_class T2_prime_nnn_dependent_term;
  class RDM_T2_prime_class T2_prime_ppn_dependent_term; 
  class RDM_T2_prime_class T2_prime_nnp_dependent_term;
  class RDM_T2_prime_class T2_prime_pnp_dependent_term; 
  class RDM_T2_prime_class T2_prime_pnn_dependent_term;

  class RDM_rho_coupled_modified_class rho_pp_coupled_modified_dependent_term;
  class RDM_rho_coupled_modified_class rho_nn_coupled_modified_dependent_term;
};

TYPE Frobenius_scalar_product (
			       const class RDM_conditions_class &A ,
			       const class RDM_conditions_class &B);

#endif

