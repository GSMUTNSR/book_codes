#ifndef RDMOBSERVABLES_H
#define RDMOBSERVABLES_H

namespace RDM_observables
{
  void calculation (
		    const class input_data_str &input_data ,
		    const class RDM_PQG_class &Gamma_pp ,
		    const class RDM_PQG_class &Gamma_nn ,
		    const class RDM_PQG_class &Gamma_pn ,
		    class interaction_class &inter_data ,
		    class TBMEs_class &TBMEs_pn ,  
		    class nucleons_data &prot_data ,
		    class nucleons_data &neut_data);
}

#endif




