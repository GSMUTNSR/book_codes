#ifndef RDMRMSRADIUSONEBODYSTRENGTH_H
#define RDMRMSRADIUSONEBODYSTRENGTH_H

namespace RDM_rms_radius_one_body_strength
{
  void calc_one_strength (
			  const enum space_type space , 
			  const enum operator_type rms_radius_operator , 
			  const bool is_it_Gauss_Legendre ,
			  const class RDM_PQG_class &Gamma_pp ,
			  const class RDM_PQG_class &Gamma_nn ,
			  const class RDM_PQG_class &Gamma_pn ,
			  const class nucleons_data &prot_data ,
			  const class nucleons_data &neut_data ,
			  class array<TYPE> &rms_radius_one_body_strength_tab);

  void calc_store_one_strength (
				const enum space_type space ,
				const enum operator_type rms_radius_operator , 
				const bool is_it_Gauss_Legendre ,
				const class array<double> &r_bef_R_tab ,
				const class correlated_state_str &PSI_qn , 
				const class RDM_PQG_class &Gamma_pp ,
				const class RDM_PQG_class &Gamma_nn ,
				const class RDM_PQG_class &Gamma_pn ,
				const class nucleons_data &prot_data ,
				const class nucleons_data &neut_data);
 
  void calc_store (
		   const class input_data_str &input_data , 
		   class nucleons_data &prot_data , 
		   class nucleons_data &neut_data ,
		   const class RDM_PQG_class &Gamma_pp ,
		   const class RDM_PQG_class &Gamma_nn ,
		   const class RDM_PQG_class &Gamma_pn);
}

#endif
