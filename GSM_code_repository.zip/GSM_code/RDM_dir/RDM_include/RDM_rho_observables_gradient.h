#ifndef RDMRHOOBSERVABLESGRADIENT_H
#define RDMRHOOBSERVABLESGRADIENT_H

namespace RDM_rho_observables_gradient
{
  void rho_der_pp_nn_tabs_calc (
				const int Aval , 
				const class nucleons_data &particles_data ,
				class array<double> &rho_der_tab);

  void rho_prot_der_pn_tab_calc (
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data ,
				 class array<double> &rho_prot_der_pn_tab);
 
  void rho_neut_der_pn_tab_calc (
				 const class nucleons_data &prot_data ,
				 const class nucleons_data &neut_data ,
				 class array<double> &rho_neut_der_pn_tab);
 
  
  void Delta_J_der_pp_nn_tabs_calc (
				    const int Aval , 
				    const class nucleons_data &particles_data ,
				    const class RDM_PQG_class &Gamma_pp_nn ,  
				    const class array<double> &rho_der_tab , 
				    class array<double> &Delta_J_der_tab);
  
  void Delta_J_der_pn_tab_calc (
				const class nucleons_data &prot_data ,
				const class nucleons_data &neut_data ,
				const class RDM_PQG_class &Gamma_pn ,  
				const class array<double> &rho_prot_der_pn_tab , 
				const class array<double> &rho_neut_der_pn_tab , 
				class array<double> &Delta_J_der_pn_tab);
  
  void average_T2_der_pn_tab_calc (
				   const class nucleons_data &prot_data ,
				   const class nucleons_data &neut_data ,
				   const class RDM_PQG_class &Gamma_pn ,
				   class array<unsigned int> &ba_from_ab_pn_indices ,
				   class array<int> &average_T2_der_pn_tab);
  
  void average_E_der_pp_nn_tab_calc (
				     const bool is_it_E_reference_condition , 
				     const enum interaction_type inter ,
				     const double H_renormalization_factor ,
				     const class nucleons_data &prot_data ,
				     const class nucleons_data &neut_data ,
				     const class array<double> &rho_der_tab ,
				     const class RDM_PQG_class &Gamma_pp_nn ,
				     class block_matrix<TYPE> &average_E_der_block_matrix);

  void average_E_der_pn_tab_calc (
				  const bool is_it_E_reference_condition , 
				  const enum interaction_type inter ,
				  const double H_renormalization_factor ,
				  const class nucleons_data &prot_data ,
				  const class nucleons_data &neut_data ,
				  const class TBMEs_class &TBMEs_pn ,   
				  const class array<double> &rho_prot_der_pn_tab ,
				  const class array<double> &rho_neut_der_pn_tab ,
				  const class RDM_PQG_class &Gamma_pn ,
				  class block_matrix<TYPE> &average_E_der_pn_block_matrix);
  
  void average_E_der_tabs_calc (
				const bool is_it_E_reference_condition , 
				const enum interaction_type inter ,
				const double H_renormalization_factor ,
				const class nucleons_data &prot_data ,
				const class nucleons_data &neut_data ,
				const class TBMEs_class &TBMEs_pn ,
				const class RDM_PQG_class &Gamma_pp ,
				const class RDM_PQG_class &Gamma_nn ,
				const class RDM_PQG_class &Gamma_pn ,
				const class RDM_conditions_gradient_class &A_Gamma_gradients ,
				class block_matrix<TYPE> &average_E_der_pp_block_matrix ,
				class block_matrix<TYPE> &average_E_der_nn_block_matrix ,
				class block_matrix<TYPE> &average_E_der_pn_block_matrix);
  
  void Delta_Hcm_der_pp_nn_tab_calc (
				     const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
				     const class nucleons_data &particles_data ,
				     const class array<double> &rho_der_tab ,
				     const class RDM_PQG_class &Gamma_pp_nn ,
				     class block_matrix<TYPE> &Delta_Hcm_der_block_matrix);
 
  void Delta_Hcm_der_pn_tab_calc (
				  const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
				  const class nucleons_data &prot_data ,
				  const class nucleons_data &neut_data , 
				  const class array<double> &rho_prot_der_pn_tab ,
				  const class array<double> &rho_neut_der_pn_tab ,
				  const class RDM_PQG_class &Gamma_pn ,
				  class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix);
 
  void Delta_Hcm_der_tabs_calc (
				const class nucleons_data &prot_data ,
				const class nucleons_data &neut_data ,
				const class RDM_PQG_class &Gamma_pp ,
				const class RDM_PQG_class &Gamma_nn ,
				const class RDM_PQG_class &Gamma_pn ,
				const class RDM_conditions_gradient_class &A_Gamma_gradients ,
				class block_matrix<TYPE> &Delta_Hcm_der_pp_block_matrix ,
				class block_matrix<TYPE> &Delta_Hcm_der_nn_block_matrix ,
				class block_matrix<TYPE> &Delta_Hcm_der_pn_block_matrix);
}

#endif
