#ifndef RDMOPTIMIZATIONAUGMENTEDLAGRANGIAN_H
#define RDMOPTIMIZATIONAUGMENTEDLAGRANGIAN_H

namespace RDM_optimization_augmented_Lagrangian
{ 
  void RDM_print_calc_observables_test_conditions (
						   const enum space_type space , 
						   const enum interaction_type inter ,
						   const class nucleons_data &prot_data ,
						   const class nucleons_data &neut_data , 
						   const class TBMEs_class &TBMEs_pn ,
						   const class RDM_PQG_class &Gamma_pp ,
						   const class RDM_PQG_class &Gamma_nn ,
						   const class RDM_PQG_class &Gamma_pn ,
						   const class RDM_conditions_class &A_Gamma ,
						   const double J , 
						   const TYPE F ,
						   const double F_der_norm ,
						   const double X_minus_A_Gamma_norm);

  TYPE F_calc (
	       const enum interaction_type inter ,
	       const class nucleons_data &prot_data ,
	       const class nucleons_data &neut_data , 
	       const class TBMEs_class &TBMEs_pn ,
	       const class RDM_PQG_class &Gamma_pp ,
	       const class RDM_PQG_class &Gamma_nn ,
	       const class RDM_PQG_class &Gamma_pn ,
	       const class RDM_conditions_class &X_minus_A_Gamma ,
	       const class RDM_conditions_class &Lambda_plus_half_sigma_X_minus_A_Gamma);
 
  void BiCG_linear_system_solve_test (
				      const class input_data_str &input_data ,
				      const double sigma ,
				      const double constant_shift ,
				      class block_matrix<TYPE> &Bpp , 
				      class block_matrix<TYPE> &Bnn , 
				      class block_matrix<TYPE> &Bpn , 
				      class block_matrix<TYPE> &Bpp_rho , 
				      class block_matrix<TYPE> &Bnn_rho , 
				      class RDM_conditions_class &V_Gamma ,
				      class RDM_conditions_class &X_Gamma ,
				      class RDM_conditions_class &helper_add ,
				      class RDM_conditions_gradient_class &A_Gamma_gradients ,
				      class RDM_PQG_class &Delta_Gamma_pp ,
				      class RDM_PQG_class &Delta_Gamma_nn ,	
				      class RDM_PQG_class &Delta_Gamma_pn ,
				      class RDM_rho_coupled_modified_class &Delta_rho_pp ,
				      class RDM_rho_coupled_modified_class &Delta_rho_nn);
  
  void E_minimization (
		       const class input_data_str &input_data , 
		       const class nucleons_data &prot_data ,
		       const class nucleons_data &neut_data , 
		       const class TBMEs_class &TBMEs_pn ,
		       class RDM_PQG_class &Gamma_pp ,
		       class RDM_PQG_class &Gamma_nn ,
		       class RDM_PQG_class &Gamma_pn ,
		       class RDM_rho_coupled_modified_class &rho_coupled_modified_pp ,
		       class RDM_rho_coupled_modified_class &rho_coupled_modified_nn);
}

#endif




