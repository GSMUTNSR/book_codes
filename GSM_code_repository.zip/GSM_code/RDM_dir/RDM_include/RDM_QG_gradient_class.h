#ifndef RDMQGGRADIENTCLASS_H
#define RDMQGGRADIENTCLASS_H


class RDM_QG_gradient_class
{
public:
  
  RDM_QG_gradient_class ();

  RDM_QG_gradient_class (
			 const enum space_type space_pair_c ,
			 const enum particle_type last_particle_c ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &QG ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);
  RDM_QG_gradient_class (
			 const enum space_type space_pair_c ,
			 const enum particle_type last_particle_c ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &QG ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);
  
  
  RDM_QG_gradient_class (const class RDM_QG_gradient_class &X);

  ~RDM_QG_gradient_class ();

  void alloc_calc_store (
			 const enum space_type space_pair_c ,
			 const enum particle_type last_particle_c ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &QG ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);

  void alloc_calc_store (
			 const enum space_type space_pair_c ,
			 const enum particle_type last_particle_c ,
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_G_Wigner_6j_hats_storage_class &Wigner_6j_hats_G ,
			 const class array<double> &rho_prot_der_pp_tab ,
			 const class array<double> &rho_prot_der_pn_tab ,
			 const class array<double> &rho_neut_der_nn_tab ,
			 const class array<double> &rho_neut_der_pn_tab ,
			 const class RDM_PQG_class &QG ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn);

  void allocate_fill (const class RDM_QG_gradient_class &X);

  void deallocate ();
    
  bool is_it_filled () const
  {
    return (QG_gradient_block_matrices_pp.is_it_filled () || QG_gradient_block_matrices_nn.is_it_filled () || QG_gradient_block_matrices_pn.is_it_filled ());
  }
  
  void operator = (const class RDM_QG_gradient_class &X);
  
  const class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type space_pair) const
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:     return QG_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return QG_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return QG_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return QG_gradient_block_matrices_pp;
  }        
  
  class array<class block_sparse_matrix<TYPE> > & get_block_matrices (const enum space_type space_pair)
  {
    switch (space_pair)
      {
      case PROTONS_ONLY:     return QG_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return QG_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return QG_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return QG_gradient_block_matrices_pp;
  }        
  
private:  
 
  const class nucleons_data & get_prot_data () const
  {
    return *prot_data_ptr;
  }
  
  const class nucleons_data & get_neut_data () const
  {
    return *neut_data_ptr;
  }
  
  const class RDM_G_Wigner_6j_hats_storage_class & get_Wigner_6j_hats_G () const
  {
    return *Wigner_6j_hats_G_ptr;
  }       
   
  const class array<double> & get_rho_prot_der_pp_tab () const
  {
    return *rho_prot_der_pp_tab_ptr;
  }
  
  const class array<double> & get_rho_prot_der_pn_tab () const
  {
    return *rho_prot_der_pn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_nn_tab () const
  {
    return *rho_neut_der_nn_tab_ptr;
  }
  
  const class array<double> & get_rho_neut_der_pn_tab () const
  {
    return *rho_neut_der_pn_tab_ptr;
  }
  
  const class RDM_PQG_class & get_QG () const
  {
    return *QG_ptr;
  }
  
  const class RDM_PQG_class & get_Gamma_pp () const
  {
    return *Gamma_pp_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_nn () const
  {
    return *Gamma_nn_ptr;
  } 
  
  const class RDM_PQG_class & get_Gamma_pn () const
  {
    return *Gamma_pn_ptr;
  }
  
  class array<unsigned short int> & get_QG_gradient_block_matrices_non_trivial_zero_numbers (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return QG_gradient_block_matrices_non_trivial_zero_numbers_pp;
      case NEUTRONS_ONLY:    return QG_gradient_block_matrices_non_trivial_zero_numbers_nn;
      case PROTONS_NEUTRONS: return QG_gradient_block_matrices_non_trivial_zero_numbers_pn;

      default: abort_all ();
      }
    
    return QG_gradient_block_matrices_non_trivial_zero_numbers_pp;
  }
  
  class array<class block_sparse_matrix<TYPE> > & get_QG_gradient_block_matrices (const enum space_type Gamma_space)
  {
    switch (Gamma_space)
      {
      case PROTONS_ONLY:     return QG_gradient_block_matrices_pp;
      case NEUTRONS_ONLY:    return QG_gradient_block_matrices_nn;
      case PROTONS_NEUTRONS: return QG_gradient_block_matrices_pn;

      default: abort_all ();
      }
    
    return QG_gradient_block_matrices_pp;
  }
  
  void rho_term_der_pp_nn_non_trivial_zero_numbers_increments (
							       const enum particle_type particle ,
							       const unsigned int BP ,
							       const int J ,
							       const unsigned int s0 ,
							       const unsigned int s1);

  void rho_term_der_pp_nn_fill_part (
				     const enum particle_type particle ,
				     const unsigned int BP ,
				     const int J ,
				     const unsigned int ab_index ,
				     const unsigned int cd_index ,
				     const int ij01 ,
				     const unsigned int s0 ,
				     const unsigned int s1 ,
				     const double factor);

  void rho_prot_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int J ,
								 const unsigned int s0_p ,
								 const unsigned int s1_p);
  
  void rho_prot_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int J ,
				       const unsigned int ab_index ,
				       const unsigned int cd_index ,
				       const unsigned int s0_p ,
				       const unsigned int s1_p ,
				       const double factor);

  void rho_neut_term_der_pn_non_trivial_zero_numbers_increments (
								 const unsigned int BP ,
								 const int J ,
								 const unsigned int s0_n ,
								 const unsigned int s1_n);

  void rho_neut_term_der_pn_fill_part (
				       const unsigned int BP ,
				       const int J ,
				       const unsigned int ab_index ,
				       const unsigned int cd_index ,
				       const unsigned int s0_n ,
				       const unsigned int s1_n ,
				       const double factor);
  
  void rho_term_der_part_determine (
				    const enum operation_type operation ,
				    const unsigned int BP ,
				    const int J ,
				    const unsigned int ab_index ,
				    const unsigned int cd_index ,
				    const enum particle_type particle ,
				    const int ij01 ,
				    const unsigned int s0 , 
				    const unsigned int s1 ,
				    const double factor);

  void QG_Gamma_term_der_part_determine (
					 const enum operation_type operation ,
					 const enum space_type Gamma_space , 
					 const unsigned int BP ,
					 const int J ,
					 const unsigned int ab_index ,
					 const unsigned int cd_index ,
					 const unsigned int BP_prime ,
					 const int J_prime ,
					 const unsigned int ip ,
					 const unsigned int jp ,
					 const double gradient_ME);

  void Q_pp_nn_block_matrices_gradients_calc_store (const enum operation_type operation);

  void Q_pn_block_matrices_gradients_calc_store (const enum operation_type operation);

  void G_pp_nn_block_matrices_gradients_calc_store (const enum operation_type operation);

  void G_pn_block_matrices_gradients_calc_store (const enum operation_type operation);
  
  void G_np_block_matrices_gradients_calc_store (const enum operation_type operation);

  void QG_pp_nn_block_matrices_gradients_alloc_calc_store (
							   const bool is_it_Q ,
							   const bool is_it_G);
  
  void QG_pn_np_block_matrices_gradients_alloc_calc_store (
							   const bool is_it_Q ,
							   const bool is_it_G);
  
  enum space_type space_pair;
  
  enum particle_type last_particle;
    
  const class nucleons_data *prot_data_ptr;
  const class nucleons_data *neut_data_ptr;
  
  const class RDM_G_Wigner_6j_hats_storage_class *Wigner_6j_hats_G_ptr;
  
  const class array<double> *rho_prot_der_pp_tab_ptr; 
  const class array<double> *rho_prot_der_pn_tab_ptr;
  const class array<double> *rho_neut_der_nn_tab_ptr;  
  const class array<double> *rho_neut_der_pn_tab_ptr;

  const class RDM_PQG_class *QG_ptr;
  
  const class RDM_PQG_class *Gamma_pp_ptr;
  const class RDM_PQG_class *Gamma_nn_ptr;
  const class RDM_PQG_class *Gamma_pn_ptr;
  
  class array<unsigned short int> QG_gradient_block_matrices_non_trivial_zero_numbers_pp;
  class array<unsigned short int> QG_gradient_block_matrices_non_trivial_zero_numbers_nn;
  class array<unsigned short int> QG_gradient_block_matrices_non_trivial_zero_numbers_pn;
  
  class array<class block_sparse_matrix<TYPE> > QG_gradient_block_matrices_pp;
  class array<class block_sparse_matrix<TYPE> > QG_gradient_block_matrices_nn;
  class array<class block_sparse_matrix<TYPE> > QG_gradient_block_matrices_pn;
};

#endif



