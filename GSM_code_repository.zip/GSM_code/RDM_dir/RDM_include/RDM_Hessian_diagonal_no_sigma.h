#ifndef RDMHESSIANDIAGONALNOSIGMA_H
#define RDMHESSIANDIAGONALNOSIGMA_H

namespace RDM_Hessian_diagonal_no_sigma
{
  void Hessian_diagonal_no_sigma_pp_nn_part_calc (
						  const enum particle_type particle ,
						  const class RDM_conditions_class &A_Gamma ,
						  const class RDM_conditions_gradient_class &A_Gamma_gradients , 				 
						  class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pp_nn , 				 
						  class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_pp_nn);
  
  void Hessian_diagonal_no_sigma_pn_part_calc  (
						const class RDM_conditions_class &A_Gamma ,
						const class RDM_conditions_gradient_class &A_Gamma_gradients , 			
						class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pn);
  
  void Hessian_diagonal_no_sigma_pp_nn_pn_calc (
						const class RDM_conditions_class &A_Gamma ,
						const class RDM_conditions_gradient_class &A_Gamma_gradients  , 				 
						class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pp,
						class block_matrix<TYPE> &Hessian_diagonal_no_sigma_nn ,
						class block_matrix<TYPE> &Hessian_diagonal_no_sigma_pn ,				 
						class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_pp ,
						class block_matrix<TYPE> &Hessian_diagonal_rho_no_sigma_nn); 
}

#endif




