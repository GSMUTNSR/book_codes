#ifndef RDMHESSIANLINEARSYSTEMLUCHOLESKY
#define RDMHESSIANLINEARSYSTEMLUCHOLESKY

namespace RDM_Hessian_linear_system_LU_Cholesky
{
  void LU_Cholesky_column_pp_nn_pn_part_store (
					       const class block_matrix<TYPE> &HV_part ,
					       const unsigned int i ,
					       unsigned int &j ,
					       class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma);
     
  void LU_Cholesky_Hessian_matrix_indices_alloc_calc (
						      const class block_matrix<TYPE> &Vpp , 
						      const class block_matrix<TYPE> &Vnn , 
						      const class block_matrix<TYPE> &Vpn , 
						      const class block_matrix<TYPE> &Vpp_rho , 
						      const class block_matrix<TYPE> &Vnn_rho , 
						      class array<bool> &is_it_rho_tab , 
						      class array<enum space_type> &spaces , 
						      class array<unsigned short int> &i_part_indices , 
						      class array<unsigned short int> &ii_indices , 
						      class array<unsigned short int> &jj_indices);
 
  void matrix_no_sigma_alloc_calc_store (
					 const class input_data_str &input_data , 
					 class RDM_conditions_class &V_Gamma ,
					 class RDM_conditions_class &X_Gamma ,
					 class RDM_conditions_class &helper_add ,
					 class RDM_conditions_gradient_class &A_Gamma_gradients ,
					 class block_matrix<TYPE> &Vpp , 
					 class block_matrix<TYPE> &Vnn , 
					 class block_matrix<TYPE> &Vpn , 
					 class block_matrix<TYPE> &Vpp_rho , 
					 class block_matrix<TYPE> &Vnn_rho , 
					 class block_matrix<TYPE> &HVpp , 
					 class block_matrix<TYPE> &HVnn , 
					 class block_matrix<TYPE> &HVpn , 
					 class block_matrix<TYPE> &HVpp_rho , 
					 class block_matrix<TYPE> &HVnn_rho , 
					 class array<bool> &is_it_rho_tab , 
					 class array<enum space_type> &spaces , 
					 class array<unsigned short int> &i_part_indices , 
					 class array<unsigned short int> &ii_indices , 
					 class array<unsigned short int> &jj_indices ,
					 class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma);
 
  void linear_system_solve (
			    const double sigma ,
			    const class block_matrix<TYPE> &Bpp , 
			    const class block_matrix<TYPE> &Bnn , 
			    const class block_matrix<TYPE> &Bpn ,
			    const class block_matrix<TYPE> &Bpp_rho , 
			    const class block_matrix<TYPE> &Bnn_rho , 
			    const class array<bool> &is_it_rho_tab , 
			    const class array<enum space_type> &spaces , 
			    const class array<unsigned short int> &i_part_indices , 
			    const class array<unsigned short int> &ii_indices , 
			    const class array<unsigned short int> &jj_indices ,
			    class matrix<TYPE> &LU_Cholesky_Hessian_matrix_no_sigma ,
			    class vector_class<TYPE> &B_LU_Cholesky ,
			    class vector_class<TYPE> &X_LU_Cholesky ,
			    class RDM_PQG_class &Delta_Gamma_pp ,
			    class RDM_PQG_class &Delta_Gamma_nn ,	
			    class RDM_PQG_class &Delta_Gamma_pn ,
			    class RDM_rho_coupled_modified_class &Delta_rho_pp ,
			    class RDM_rho_coupled_modified_class &Delta_rho_nn);
}

#endif




