#ifndef RDMRHOOBSERVABLES_H
#define RDMRHOOBSERVABLES_H

namespace RDM_rho_observables
{
  TYPE rho_ME_prot_calc (
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_PQG_class &Gamma_pp ,
			 const class RDM_PQG_class &Gamma_pn , 
			 const unsigned int sa_p ,
			 const unsigned int sc_p);

  TYPE rho_ME_neut_calc (
			 const class nucleons_data &prot_data ,
			 const class nucleons_data &neut_data ,
			 const class RDM_PQG_class &Gamma_nn ,
			 const class RDM_PQG_class &Gamma_pn , 
			 const unsigned int sa_n ,
			 const unsigned int sc_n);

  void rho_prot_tab_calc (
			  const class nucleons_data &prot_data ,
			  const class nucleons_data &neut_data ,
			  const class RDM_PQG_class &Gamma_pp , 
			  const class RDM_PQG_class &Gamma_pn , 
			  class array<TYPE> &rho_prot_tab);
 
  void rho_neut_tab_calc (
			  const class nucleons_data &prot_data ,
			  const class nucleons_data &neut_data ,
			  const class RDM_PQG_class &Gamma_nn, 
			  const class RDM_PQG_class &Gamma_pn, 
			  class array<TYPE> &rho_neut_tab);

  TYPE Delta_pp_nn_pairs_number_calc (
				      const class nucleons_data &particles_data ,
				      const class RDM_PQG_class &Gamma);

  TYPE Delta_pn_pairs_number_calc (
				   const class nucleons_data &prot_data ,
				   const class nucleons_data &neut_data ,
				   const class RDM_PQG_class &Gamma_pn);
 
  TYPE Delta_J_pp_nn_calc (
			   const int Aval , 
			   const class nucleons_data &particles_data ,
			   const class array<TYPE> &rho_tab ,
			   const class RDM_PQG_class &Gamma);
  
  TYPE Delta_J_pn_calc (
			const class nucleons_data &prot_data , 
			const class nucleons_data &neut_data , 
			const class RDM_PQG_class &Gamma_pn);

  TYPE Delta_J_calc (
		     const class nucleons_data &prot_data , 
		     const class nucleons_data &neut_data , 
		     const class RDM_PQG_class &Gamma_pp ,
		     const class RDM_PQG_class &Gamma_nn ,
		     const class RDM_PQG_class &Gamma_pn ,
		     const double J);

  TYPE average_T2_calc (
			const class nucleons_data &prot_data , 
			const class nucleons_data &neut_data , 
			const class RDM_PQG_class &Gamma_pn);

  TYPE average_E_pp_nn_calc (
			     const bool is_it_E_reference_condition ,
			     const enum interaction_type inter , 
			     const double H_renormalization_factor ,
			     const class nucleons_data &particles_data ,
			     const class array<TYPE> &rho_tab ,
			     const class RDM_PQG_class &Gamma);

  TYPE average_E_pn_calc (
			  const bool is_it_E_reference_condition , 
			  const double H_renormalization_factor ,
			  const class nucleons_data &prot_data , 
			  const class nucleons_data &neut_data ,
			  const class TBMEs_class &TBMEs_pn ,
			  const class RDM_PQG_class &Gamma_pn); 

  TYPE average_E_calc (
		       const bool is_it_E_reference_condition , 
		       const enum interaction_type inter ,
		       const TYPE E_reference ,
		       const double H_renormalization_factor ,
		       const class nucleons_data &prot_data ,
		       const class nucleons_data &neut_data , 
		       const class TBMEs_class &TBMEs_pn ,
		       const class RDM_PQG_class &Gamma_pp ,
		       const class RDM_PQG_class &Gamma_nn ,
		       const class RDM_PQG_class &Gamma_pn);

  TYPE average_CM_op_pp_nn_calc (
				 const enum operator_type CM_operator_inter ,
				 const bool is_it_HO_expansion ,
				 const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
				 const class nucleons_data &particles_data ,
				 const class array<TYPE> &rho_tab ,
				 const class RDM_PQG_class &Gamma);

  TYPE average_CM_op_pn_calc (
			      const enum operator_type CM_operator_inter ,
			      const bool is_it_HO_expansion ,
			      const class array<class CM_TBMEs_angular_table_str> &TBMEs_angular_tables ,
			      const class nucleons_data &prot_data ,
			      const class nucleons_data &neut_data ,
			      const class RDM_PQG_class &Gamma_pn);

  TYPE average_CM_op_calc (
			   const enum operator_type CM_operator_inter ,
			   const bool is_it_HO_expansion ,
			   const class nucleons_data &prot_data ,
			   const class nucleons_data &neut_data , 
			   const class RDM_PQG_class &Gamma_pp ,
			   const class RDM_PQG_class &Gamma_nn ,
			   const class RDM_PQG_class &Gamma_pn);
  
  TYPE shell_occupation_calc (
			      const class nucleons_data &particles_data ,
			      const class array<TYPE> &rho_tab ,
			      const class nlj_struct &shell_nlj);

  void all_shells_occupation_calc_print (
					 const enum particle_type particle ,
					 const class nucleons_data &prot_data ,
					 const class nucleons_data &neut_data , 
					 const class RDM_PQG_class &Gamma_pp_nn ,
					 const class RDM_PQG_class &Gamma_pn);
 
  TYPE partial_wave_occupation_calc (
				     const class nucleons_data &particles_data ,
				     const class array<TYPE> &rho_tab ,
				     const int l ,
				     const double j);


  void all_partial_wave_occupation_calc_print (
					       const enum particle_type particle ,
					       const class nucleons_data &prot_data ,
					       const class nucleons_data &neut_data , 
					       const class RDM_PQG_class &Gamma_pp_nn ,
					       const class RDM_PQG_class &Gamma_pn);
 
  void scalar_strength_pp_nn_calc (
				   const class array<TYPE> &OBMEs , 
				   const class nucleons_data &particles_data ,
				   const class array<TYPE> &rho_tab ,
				   class array<TYPE> &scalar_strength_tab);
  
  void scalar_strength_calc (
			     const class array<TYPE> &OBMEs_prot , 
			     const class array<TYPE> &OBMEs_neut , 
			     const class nucleons_data &prot_data ,
			     const class nucleons_data &neut_data , 
			     const class RDM_PQG_class &Gamma_pp ,
			     const class RDM_PQG_class &Gamma_nn ,
			     const class RDM_PQG_class &Gamma_pn ,
			     class array<TYPE> &scalar_strength_prot_tab ,
			     class array<TYPE> &scalar_strength_neut_tab);
}

#endif




