#ifndef RDMHESSIANVECTORNOSIGMA_H
#define RDMHESSIANVECTORNOSIGMA_H

namespace RDM_Hessian_vector_no_sigma
{
  unsigned int BPp_Jp_index_prime_dimension_calc (const class array<unsigned int> &matrix_dimensions);
  
  void BPp_Jp_index_prime_arrays_calc (
				       const class array<unsigned int> &matrix_dimensions ,
				       class array<unsigned int> &BPp_indices ,
				       class array<int> &Jp_indices ,
				       class array<unsigned int> &index_prime_indices);
 
  unsigned int dimension_part_calc (const class block_matrix<TYPE> &X);

  unsigned int dimension_calc (
			       const class block_matrix<TYPE> &X_pp ,
			       const class block_matrix<TYPE> &X_nn ,
			       const class block_matrix<TYPE> &X_pn ,
			       const class block_matrix<TYPE> &X_rho_pp ,
			       const class block_matrix<TYPE> &X_rho_nn);
  
  class matrix<TYPE> & matrix_pp_nn_pn_part_determine (
						       const bool is_it_rho , 
						       const enum space_type space ,
						       const unsigned int i_part ,
						       class block_matrix<TYPE> &Vpp , 
						       class block_matrix<TYPE> &Vnn , 
						       class block_matrix<TYPE> &Vpn , 
						       class block_matrix<TYPE> &Vpp_rho , 
						       class block_matrix<TYPE> &Vnn_rho);
 
  const class matrix<TYPE> & matrix_pp_nn_pn_part_determine (
							     const bool is_it_rho , 
							     const enum space_type space ,
							     const unsigned int i_part ,
							     const class block_matrix<TYPE> &Vpp , 
							     const class block_matrix<TYPE> &Vnn , 
							     const class block_matrix<TYPE> &Vpn , 
							     const class block_matrix<TYPE> &Vpp_rho , 
							     const class block_matrix<TYPE> &Vnn_rho);
  
  void pp_nn_part_calc (
			const enum particle_type particle ,
			const class RDM_conditions_class &VX ,
			const class RDM_conditions_gradient_class &A_Gamma_gradients ,
			class block_matrix<TYPE> &HF_X_pp_nn , 
			class block_matrix<TYPE> &HF_X_rho_pp_nn);
  
  void pn_part_calc  (
		      const class RDM_conditions_class &VX ,
		      const class RDM_conditions_gradient_class &A_Gamma_gradients ,
		      class block_matrix<TYPE> &HF_X_pn);

  void apply (
	      const class block_matrix<TYPE> &X_pp ,
	      const class block_matrix<TYPE> &X_nn ,
	      const class block_matrix<TYPE> &X_pn ,
	      const class block_matrix<TYPE> &X_rho_pp ,
	      const class block_matrix<TYPE> &X_rho_nn ,
	      class RDM_conditions_class &V_Gamma ,
	      class RDM_conditions_class &X_Gamma ,
	      class RDM_conditions_class &helper_add ,
	      class RDM_conditions_gradient_class &A_Gamma_gradients ,
	      class block_matrix<TYPE> &Hes_X_pp , 	 
	      class block_matrix<TYPE> &Hes_X_nn , 	 
	      class block_matrix<TYPE> &Hes_X_pn ,
	      class block_matrix<TYPE> &Hes_X_rho_pp , 	 
	      class block_matrix<TYPE> &Hes_X_rho_nn);
}

#endif




