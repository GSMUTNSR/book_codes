#ifndef RDMOBSERVABLESHO_H
#define RDMOBSERVABLESHO_H

namespace RDM_observables_HO
{
  void calculation (
		    const class input_data_str &input_data ,
		    const class RDM_PQG_class &Gamma_pp ,
		    const class RDM_PQG_class &Gamma_nn ,
		    const class RDM_PQG_class &Gamma_pn ,
		    const class nucleons_data &prot_data ,
		    const class nucleons_data &neut_data);
}

#endif




