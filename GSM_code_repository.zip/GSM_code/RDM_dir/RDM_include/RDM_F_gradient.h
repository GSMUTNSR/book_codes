#ifndef RDMFGRADIENT_H
#define RDMFGRADIENT_H

namespace RDM_F_gradient
{
  void F_der_pp_nn_calc (
			 const enum particle_type particle ,
			 const class block_matrix<TYPE> &average_E_der_pp_nn_block_matrix ,
			 const class RDM_conditions_class &Lambda_plus_sigma_X_minus_A_Gamma ,
			 const class RDM_conditions_gradient_class &A_Gamma_gradients , 				 
			 class block_matrix<TYPE> &F_der_pp_nn , 				 
			 class block_matrix<TYPE> &F_der_rho_pp_nn);
  
  void F_der_pn_calc (
		      const class block_matrix<TYPE> &average_E_der_pn_block_matrix ,
		      const class RDM_conditions_class &Lambda_plus_sigma_X_minus_A_Gamma ,
		      const class RDM_conditions_gradient_class &A_Gamma_gradients , 			
		      class block_matrix<TYPE> &F_der_pn);

  void all_F_der_calc (
		       const enum interaction_type inter ,
		       const class nucleons_data &prot_data ,
		       const class nucleons_data &neut_data , 
		       const class TBMEs_class &TBMEs_pn ,
		       const class RDM_PQG_class &Gamma_pp ,
		       const class RDM_PQG_class &Gamma_nn ,
		       const class RDM_PQG_class &Gamma_pn ,
		       const class RDM_conditions_class &A_Gamma ,
		       const class RDM_conditions_class &X ,
		       const class RDM_conditions_class &Lambda ,
		       const class RDM_conditions_gradient_class &A_Gamma_gradients ,
		       const double sigma , 
		       class RDM_conditions_class &B_Gamma ,
		       class block_matrix<TYPE> &average_E_der_pp_block_matrix ,
		       class block_matrix<TYPE> &average_E_der_nn_block_matrix ,
		       class block_matrix<TYPE> &average_E_der_pn_block_matrix , 				 
		       class block_matrix<TYPE> &F_der_pp ,
		       class block_matrix<TYPE> &F_der_nn ,		 
		       class block_matrix<TYPE> &F_der_pn , 				 
		       class block_matrix<TYPE> &F_der_rho_pp , 				 
		       class block_matrix<TYPE> &F_der_rho_nn);
}

#endif




