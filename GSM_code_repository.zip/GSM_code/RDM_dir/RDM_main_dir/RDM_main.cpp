#include "../RDM_include/RDM_include_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum called_code_type called_code = RDM_CODE; 

using namespace inputs_misc;

#ifdef UseMPI
int main (int argc , char ** argv) 
{  
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    print_array_vector_test_status<int> ();

    //--// dummy variables
    
    class array<class input_data_str> dummy_input_data_tab;

    class input_data_str dummy_input_data;
    
    //--// 
    
    class array<double> SPE_coefficients;

    class array<double> TBME_coefficients;

    class array<string> file_names;

    //================================== input data and nucleons data ==================================//
    
    class input_data_str input_data;

    call_common_routines::input_data_read_MPI_transfer (SPE_coefficients , TBME_coefficients , file_names , input_data , dummy_input_data , dummy_input_data_tab);
    
    const enum space_type space = input_data.get_space ();
	
    const bool truncation_hw_init = input_data.get_truncation_hw ();
    const bool truncation_ph_init = input_data.get_truncation_ph ();
    
    const int n_scat_max_p_init = input_data.get_n_scat_max_p ();
    const int n_scat_max_n_init = input_data.get_n_scat_max_n ();
    const int n_scat_max_init   = input_data.get_n_scat_max ();
  
    //--// initialization of the classes which contain information on protons and neutrons
    
    class nucleons_data prot_data;
    class nucleons_data neut_data;

    nucleons_data_initialization (true , input_data , prot_data , neut_data);
     
    //================================== OBMEs and TBMEs read from files  ==================================//
    
    //--// initialization of the classes which contain the OBMEs and TBMEs (fitted interactions stored in files or SU(3) interaction only)

    const enum interaction_type inter = input_data.get_inter ();

    const enum potential_type basis_potential = input_data.get_basis_potential ();
  
    const bool is_it_fit_or_SU3 = ((inter == FIT) || (inter == SU3_INTERACTION));

    const bool is_it_HO_fit_or_SU3 = ((basis_potential == HO_POTENTIAL) && is_it_fit_or_SU3);
  
    const unsigned int files_number = input_data.get_files_number ();
    
    class array<class array<class JT_coupled_TBME> > JT_TBMEs_tables(files_number);

    if (is_it_HO_fit_or_SU3) OBMEs_TBMEs::standard_HO_SM::h_JT_TBMEs_alloc_fill (true , input_data , SPE_coefficients , TBME_coefficients , file_names , prot_data , neut_data , JT_TBMEs_tables);
    
    //================================== Berggren one-body basis ==================================//

    //--// initialization of the tables containing the one-body basis

    Berggren_basis::single_particle_indices_radial_wfs_prot_neut_alloc_calc (true , input_data , prot_data , neut_data);
    
    space_truncation_data_best_hbar_omega_calc (true , input_data , prot_data , neut_data);
            
    //================================== basis interaction and HF potentials ==================================//
    
    //--// class which contains information on the interaction for the basis

    class interaction_class inter_data_basis (true , true , false , input_data);

    if (!is_it_fit_or_SU3) inter_data_basis.inter_data_calc (input_data);
    
    //--// classes which contain information on protons and neutrons in the HF potential
    
    class HF_nucleons_data prot_HF_data(input_data , prot_data);
    class HF_nucleons_data neut_HF_data(input_data , neut_data);

    if (basis_potential == MSDHF)
      MSDHF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
    else
      HF_potentials::potentials_shells_OBMEs_realloc_calc (true , input_data , inter_data_basis , prot_HF_data , neut_HF_data , prot_data , neut_data);
      
    prot_HF_data.deallocate ();
    neut_HF_data.deallocate ();
    
    //================================== GSM interaction  ==================================//

    //--// class which contains information on the interaction

    class interaction_class inter_data(true , false , false , input_data);

    if (!is_it_HO_fit_or_SU3) inter_data.inter_data_calc (input_data);

    //================================== suppression of particle-hole and hbar omega truncationa for TBMEs calculation ==================================//

    input_data.set_truncation_hw (false);
    input_data.set_truncation_ph (false);

    input_data.all_n_scat_max_modification (space , false , prot_data , neut_data);
    
    prot_data.set_n_scat_max (input_data.get_n_scat_max_p ());
    neut_data.set_n_scat_max (input_data.get_n_scat_max_n ());
    
    //================================== OBMEs, TBMEs  ==================================//
    
    if (!is_it_HO_fit_or_SU3) all_HO_GHF_overlaps_prot_neut_alloc_calc (input_data , prot_data , neut_data);
    
    //--// initialization of the class which contains proton-neutron TBMEs
    class TBMEs_class TBMEs_pn;
  
    OBMEs_TBMEs::all_OBMEs_TBMEs_alloc_calc (true , false , JT_TBMEs_tables , inter_data_basis , inter_data , input_data , prot_data , neut_data , TBMEs_pn);
    
    hole_double_counting::prot_neut_OBMEs_no_natural_orbitals_calc_store_remove (false , input_data , prot_data , neut_data , TBMEs_pn);
    
    //================================== particle-hole and hbar omega truncations restored for Q,G,T1,T2' with RDM ==================================//
    
    input_data.set_truncation_hw (truncation_hw_init);
    input_data.set_truncation_ph (truncation_ph_init);
    
    input_data.set_n_scat_max_p (n_scat_max_p_init);
    input_data.set_n_scat_max_n (n_scat_max_n_init);
    input_data.set_n_scat_max   (n_scat_max_init);
    
    input_data.all_n_scat_max_modification (space , truncation_ph_init , prot_data , neut_data);
    
    prot_data.set_n_scat_max (input_data.get_n_scat_max_p ());
    neut_data.set_n_scat_max (input_data.get_n_scat_max_n ());
    
    //================================== Calculation of energies with RDM optimizations : augmented Lagrangian methods ==================================//
	 
    const int Z = input_data.get_Z ();
    const int N = input_data.get_N ();
	
    const unsigned int RDM_BP = input_data.get_RDM_BP ();

    const unsigned int RDM_vector_index = input_data.get_RDM_vector_index ();
	
    const double RDM_J = input_data.get_RDM_J ();

    const bool are_there_J_constraints = input_data.get_RDM_are_there_J_constraints ();

    const bool is_RDM_J_non_zero = (make_int (2.0*RDM_J) != 0);
	
    const bool RDM_Gamma_init_from_file = input_data.get_RDM_Gamma_init_from_file ();
    
    class RDM_PQG_class Gamma_pp(PROTONS_ONLY     , PROTON  , false , false , NADA , NADA , true , false , prot_data , neut_data);
    class RDM_PQG_class Gamma_nn(NEUTRONS_ONLY    , NEUTRON , false , false , NADA , NADA , true , false , prot_data , neut_data);
    class RDM_PQG_class Gamma_pn(PROTONS_NEUTRONS , NEUTRON , false , false , NADA , NADA , true , false , prot_data , neut_data);
    
    class RDM_rho_coupled_modified_class rho_pp_coupled_modified(are_there_J_constraints , RDM_J , prot_data);
    class RDM_rho_coupled_modified_class rho_nn_coupled_modified(are_there_J_constraints , RDM_J , neut_data);
    
    if (RDM_Gamma_init_from_file)
      {
	const bool print_detailed_information = input_data.get_print_detailed_information ();
	
	const enum space_type space = input_data.get_space ();
	
	const bool truncation_hw = input_data.get_truncation_hw ();
	const bool truncation_ph = input_data.get_truncation_ph ();
  
	const int E_max_hw = input_data.get_E_max_hw();

	const int n_scat_max = input_data.get_n_scat_max ();
  
	const RDM_matrix_constraint_type RDM_matrix_constraint = input_data.get_RDM_matrix_constraint ();

	const bool is_there_CM_correction = input_data.get_RDM_is_there_CM_correction ();
	
	const bool is_there_isospin_constraint = input_data.get_RDM_is_there_isospin_constraint ();
	
	const bool is_there_E_reference = input_data.get_RDM_is_there_E_reference ();
  
	const double RDM_E_reference = input_data.get_RDM_E_reference ();
	
	const double RDM_Hamiltonian_renormalization_factor = input_data.get_RDM_Hamiltonian_renormalization_factor ();
  
	class RDM_conditions_class A_Gamma(inter , TBMEs_pn , RDM_matrix_constraint , is_there_CM_correction , is_there_isospin_constraint , are_there_J_constraints , is_there_E_reference , 
					   truncation_hw , truncation_ph , E_max_hw , n_scat_max , RDM_J , RDM_E_reference , RDM_Hamiltonian_renormalization_factor , prot_data , neut_data);
	
	if (THIS_PROCESS == MASTER_PROCESS)
	  {
	    Gamma_pp.read_P_pp_nn_from_file (Z , N , RDM_BP , RDM_J , RDM_vector_index);
	    Gamma_nn.read_P_pp_nn_from_file (Z , N , RDM_BP , RDM_J , RDM_vector_index);
	    
	    Gamma_pn.read_P_pn_from_file (Z , N , RDM_BP , RDM_J , RDM_vector_index);

	    if (are_there_J_constraints && is_RDM_J_non_zero)
	      {
		rho_pp_coupled_modified.read_from_file (Z , N , RDM_BP , RDM_J , RDM_vector_index);
		rho_nn_coupled_modified.read_from_file (Z , N , RDM_BP , RDM_J , RDM_vector_index);
	      }
	  }  

#ifdef UseMPI
  
	if (is_it_MPI_parallelized)
	  {
	    Gamma_pp.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	    Gamma_nn.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	    Gamma_pn.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	    
	    if (are_there_J_constraints && is_RDM_J_non_zero)
	      {
		rho_pp_coupled_modified.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
		rho_nn_coupled_modified.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
	      }
	  }
  
#endif
		    
	if (print_detailed_information)
	  {
	    A_Gamma.A_Gamma_calc (Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified);
	    
	    if (THIS_PROCESS == MASTER_PROCESS) A_Gamma.print_precisions_GSM_RDM_class_file (space , Z , N , RDM_BP , RDM_J , RDM_vector_index);
	    
	    const class RDM_conditions_gradient_class A_Gamma_gradients(inter , TBMEs_pn , prot_data , neut_data , A_Gamma);
	    
	    A_Gamma.print_gradient_direct_formulas_precisions (space , A_Gamma_gradients , Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified);
	  }
      }    
    else
      {	
	Gamma_pp.random_positive_definite ();
	Gamma_nn.random_positive_definite ();
	Gamma_pn.random_positive_definite ();
	
	if (are_there_J_constraints && is_RDM_J_non_zero)
	  {
	    rho_pp_coupled_modified.random_positive_definite ();
	    rho_nn_coupled_modified.random_positive_definite ();
	  }
      }
      	
    RDM_optimization_augmented_Lagrangian::E_minimization (input_data , prot_data , neut_data , TBMEs_pn , Gamma_pp , Gamma_nn , Gamma_pn , rho_pp_coupled_modified , rho_nn_coupled_modified);
      
    //================================== Calculation of observables with RDM ==================================//
    
    RDM_observables::calculation (input_data , Gamma_pp , Gamma_nn , Gamma_pn , inter_data , TBMEs_pn , prot_data , neut_data);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


