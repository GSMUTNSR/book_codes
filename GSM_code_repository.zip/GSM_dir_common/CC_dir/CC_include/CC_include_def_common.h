#ifndef CC_INCLUDE_DEF_COMMON_H
#define CC_INCLUDE_DEF_COMMON_H

#include "../../../numlib/numlib_def/numlib_def.h"

#include "../../GSM_dir/GSM_include/GSM_include_def_common.h"

#include "CC_basis_states_backward.h"
#include "CC_basis_states_forward.h"
#include "CC_channel_class.h"
#include "CC_HO_wave_functions.h"
#include "CC_common_routines.h"
#include "CC_Jost_matrix.h"
#include "CC_system_integration.h"
#include "CC_target_projectile_composite_data.h"
#endif


