#include "../CC_include/CC_include_def_common.h"


/* -------------------------------------------------------------------------------------------------------------------
   ELEMENTS FOR CLASS CC_bwd_basis_state
   ---------------------------------------------------------------------------------------------------------------------*/

CC_bwd_basis_state::CC_bwd_basis_state () :
  S_matrix_pole (false) ,
  N_channels (0) , 	
  N_bef_R_uniform (0) , 
  N_bef_R_GL (0) , 
  ic_entrance (0) ,
  ib (0) , 
  R (0.0) , 
  matching_point (0.0) ,
  R_max (0.0) , 
  step_bef_R_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0), 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0)
{}

CC_bwd_basis_state::CC_bwd_basis_state (
					const bool S_matrix_pole_c , 
					const unsigned int N_channels_c ,
					const unsigned int ic_entrance_c , 
					const unsigned int ib_c , 
					const class array<class CC_channel_class> &channels_tab_c , 
					const unsigned int N_bef_R_uniform_c , 
					const unsigned int N_bef_R_GL_c , 
					const double R_c , 
					const double matching_point_c , 
					const double R_real_max_c) :
  S_matrix_pole (false) ,
  N_channels (0) , 	
  N_bef_R_uniform (0) , 
  N_bef_R_GL (0) , 
  ic_entrance (0) ,
  ib (0) , 
  R (0.0) , 
  matching_point (0.0) ,
  R_max (0.0) , 
  step_bef_R_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0), 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0)
{
  allocate (S_matrix_pole_c , N_channels_c , ic_entrance_c , ib_c , channels_tab_c , N_bef_R_uniform_c , N_bef_R_GL_c , R_c , matching_point_c , R_real_max_c);
}

CC_bwd_basis_state::CC_bwd_basis_state (const class CC_bwd_basis_state &X) :
  S_matrix_pole (false) ,
  N_channels (0) , 	
  N_bef_R_uniform (0) , 
  N_bef_R_GL (0) , 
  ic_entrance (0) ,
  ib (0) , 
  R (0.0) , 
  matching_point (0.0) ,
  R_max (0.0) , 
  step_bef_R_uniform (0.0) ,
  N_bef_mp_uniform (0) , 
  N_aft_mp_uniform (0), 
  N_bef_mp_GL (0) ,
  N_aft_mp_GL (0) ,
  N_bef_mp_GL_SGI_MSGI (0) ,
  N_aft_mp_GL_SGI_MSGI (0)
{
  allocate_fill (X);
}



void CC_bwd_basis_state::allocate (
				   const bool S_matrix_pole_c , 
				   const unsigned int N_channels_c , 
				   const unsigned int ic_entrance_c , 
				   const unsigned int ib_c , 
				   const class array<class CC_channel_class> &channels_tab_c , 
				   const unsigned int N_bef_R_uniform_c , 
				   const unsigned int N_bef_R_GL_c , 
				   const double R_c , 
				   const double matching_point_c , 
				   const double R_real_max_c) 
{
  S_matrix_pole = S_matrix_pole_c; 

  N_channels = N_channels_c; 	

  N_bef_R_uniform = N_bef_R_uniform_c; 

  N_bef_R_GL = N_bef_R_GL_c; 

  ic_entrance = ic_entrance_c; 

  ib = ib_c; 

  R = R_c; 

  matching_point = matching_point_c; 

  R_max = R_real_max_c; 

  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform - 1); 

  N_bef_mp_uniform = make_uns_int (floor (matching_point/step_bef_R_uniform)) + 1; 

  N_aft_mp_uniform = N_bef_R_uniform - N_bef_mp_uniform;
    
  channels_tab.allocate_fill (channels_tab_c);

  r_aft_mp_bef_R_tab_uniform.allocate (N_aft_mp_uniform);

  for (unsigned int i = 0 ; i < N_aft_mp_uniform ; i++) r_aft_mp_bef_R_tab_uniform(i) = step_bef_R_uniform*(i+N_bef_mp_uniform);

  class array<double> r_bef_R (N_bef_R_GL);
  class array<double> weights_bef_R (N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R , weights_bef_R);

  unsigned int iGL = 0;

  while ((iGL < N_bef_R_GL) && (r_bef_R(iGL) <= matching_point)) iGL++;

  N_bef_mp_GL = iGL;

  N_aft_mp_GL = N_bef_R_GL - N_bef_mp_GL;	

  r_aft_mp_bef_R_tab_GL.allocate (N_aft_mp_GL);

  for (unsigned int i = 0 ; i < N_aft_mp_GL ; i++) r_aft_mp_bef_R_tab_GL(i) = r_bef_R(i+N_bef_mp_GL);

  const double R_SGI_MSGI = 2.*matching_point;

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_SGI_MSGI , r_bef_R , weights_bef_R);

  unsigned int iGL_SGI_MSGI = 0;

  while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R(iGL_SGI_MSGI) <= matching_point)) iGL_SGI_MSGI++;

  N_bef_mp_GL_SGI_MSGI = iGL_SGI_MSGI;

  N_aft_mp_GL_SGI_MSGI = N_bef_R_GL - N_bef_mp_GL_SGI_MSGI;

  r_aft_mp_bef_R_tab_GL_SGI_MSGI.allocate (N_aft_mp_GL_SGI_MSGI);

  for (unsigned int i = 0 ; i < N_aft_mp_GL_SGI_MSGI ; i++) r_aft_mp_bef_R_tab_GL_SGI_MSGI(i) = r_bef_R(i+N_bef_mp_GL_SGI_MSGI);

  CC_bwd_wf_tab_uniform.allocate  (N_channels , N_aft_mp_uniform); 
  CC_bwd_dwf_tab_uniform.allocate (N_channels , N_aft_mp_uniform); 

  CC_bwd_wf_tab_GL.allocate  (N_channels , N_aft_mp_GL); 
  CC_bwd_dwf_tab_GL.allocate (N_channels , N_aft_mp_GL); 

  CC_bwd_wf_tab_GL_SGI_MSGI.allocate  (N_channels , N_aft_mp_GL_SGI_MSGI); 
  CC_bwd_dwf_tab_GL_SGI_MSGI.allocate (N_channels , N_aft_mp_GL_SGI_MSGI); 

  CC_bwd_wf_tab_uniform  = INFINITE;
  CC_bwd_dwf_tab_uniform = INFINITE;

  CC_bwd_wf_tab_GL  = INFINITE;
  CC_bwd_dwf_tab_GL = INFINITE;
  
  CC_bwd_wf_tab_GL_SGI_MSGI  = INFINITE;
  CC_bwd_dwf_tab_GL_SGI_MSGI = INFINITE;

  CC_bwd_wf_mp_tab.allocate  (N_channels);
  CC_bwd_dwf_mp_tab.allocate (N_channels);

  CC_bwd_wf_mp_tab  = INFINITE;
  CC_bwd_dwf_mp_tab = INFINITE;
}






void CC_bwd_basis_state::allocate_fill (const class CC_bwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  N_bef_R_uniform = X.N_bef_R_uniform; 

  N_bef_R_GL = X.N_bef_R_GL; 

  ic_entrance = X.ic_entrance; 

  ib = X.ib; 

  R = X.R; 

  matching_point = X.matching_point; 

  R_max = X.R_max; 

  step_bef_R_uniform = X.step_bef_R_uniform; 

  N_bef_mp_uniform = X.N_bef_mp_uniform; 
  N_aft_mp_uniform = X.N_aft_mp_uniform;

  N_bef_mp_GL = X.N_bef_mp_GL;
  N_aft_mp_GL = X.N_aft_mp_GL;	

  channels_tab.allocate_fill (X.channels_tab);

  r_aft_mp_bef_R_tab_uniform.allocate_fill (X.r_aft_mp_bef_R_tab_uniform);
  r_aft_mp_bef_R_tab_GL.allocate_fill  (X.r_aft_mp_bef_R_tab_GL);

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;
  N_aft_mp_GL_SGI_MSGI = X.N_aft_mp_GL_SGI_MSGI;

  r_aft_mp_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.r_aft_mp_bef_R_tab_GL_SGI_MSGI);

  CC_bwd_wf_tab_uniform.allocate_fill  (X.CC_bwd_wf_tab_uniform);
  CC_bwd_dwf_tab_uniform.allocate_fill (X.CC_bwd_dwf_tab_uniform);

  CC_bwd_wf_tab_GL.allocate_fill  (X.CC_bwd_wf_tab_GL);
  CC_bwd_dwf_tab_GL.allocate_fill (X.CC_bwd_dwf_tab_GL);

  CC_bwd_wf_tab_GL_SGI_MSGI.allocate_fill  (X.CC_bwd_wf_tab_GL_SGI_MSGI);
  CC_bwd_dwf_tab_GL_SGI_MSGI.allocate_fill (X.CC_bwd_dwf_tab_GL_SGI_MSGI);

  CC_bwd_wf_mp_tab.allocate_fill  (X.CC_bwd_wf_mp_tab);
  CC_bwd_dwf_mp_tab.allocate_fill (X.CC_bwd_dwf_mp_tab);
}



void CC_bwd_basis_state::deallocate ()
{
  channels_tab.deallocate ();

  r_aft_mp_bef_R_tab_uniform.deallocate ();

  r_aft_mp_bef_R_tab_GL.deallocate ();
  r_aft_mp_bef_R_tab_GL_SGI_MSGI.deallocate ();

  CC_bwd_wf_tab_uniform.deallocate ();
  CC_bwd_dwf_tab_uniform.deallocate ();

  CC_bwd_wf_tab_GL.deallocate ();
  CC_bwd_dwf_tab_GL.deallocate ();

  CC_bwd_wf_tab_GL_SGI_MSGI.deallocate ();
  CC_bwd_dwf_tab_GL_SGI_MSGI.deallocate ();

  CC_bwd_wf_mp_tab.deallocate ();
  CC_bwd_dwf_mp_tab.deallocate ();

  S_matrix_pole = false;

  N_channels = 0; 	

  N_bef_R_uniform = 0; 

  N_bef_R_GL = 0; 

  ic_entrance = 0;

  ib = 0; 

  R = 0.0; 

  matching_point = 0.0;

  R_max = 0.0; 

  step_bef_R_uniform = 0.0;

  N_bef_mp_uniform = 0; 
  N_aft_mp_uniform = 0;

  N_bef_mp_GL = 0;
  N_aft_mp_GL = 0;
}





void CC_bwd_basis_state::zero ()
{
  CC_bwd_wf_tab_uniform  = 0.0;
  CC_bwd_dwf_tab_uniform = 0.0;

  CC_bwd_wf_tab_GL  = 0.0;
  CC_bwd_dwf_tab_GL = 0.0;

  CC_bwd_wf_tab_GL_SGI_MSGI  = 0.0;
  CC_bwd_dwf_tab_GL_SGI_MSGI = 0.0;

  CC_bwd_wf_mp_tab  = 0.0;
  CC_bwd_dwf_mp_tab = 0.0;
}


void CC_bwd_basis_state::Uplus_asymptotic_conditions_calc (
							   const complex<double> &Cplus_b , 
							   class vector_class <complex<double> > &UR , 
							   class vector_class <complex<double> > &dUR) const 
{
  UR  = 0.0;
  dUR = 0.0;

  const class CC_channel_class &channel_b = channels_tab(ib);

  const int lb = channel_b.get_LCM_projectile ();

  const int Z_Tb_charge = channel_b.get_Z_Tc_charge ();

  const double kinetic_factor_b = channel_b.get_kinetic_factor_projectile ();

  const complex<double> kb = channel_b.get_k_projectile ();

  const complex<double> eta_b = channel_b.get_eta_projectile ();

  const bool is_it_bound_case = (S_matrix_pole && (real (kb) == 0.0));

  complex<double>  UR_b = 0.0;
  complex<double> dUR_b = 0.0;
  
  if (kb == 0)
    {
      const enum particle_type projectile_b = channel_b.get_projectile ();
      
      const int projectile_b_charge = particle_charge_determine (projectile_b);
	      
      const int Z_Tb_charge_times_projectile_b_charge = Z_Tb_charge*projectile_b_charge;
	      
      const double lb_term = 2.0*lb + 0.5;
      
      const complex<double> Ilb_term (0. , lb_term);

      const complex<double> norm_kb_is_zero = exp (Ilb_term*M_PI_2);

      const complex<double> two_I_sqrt_V_Coul_b (0.0 , 2.0*sqrt (kinetic_factor_b*Z_Tb_charge_times_projectile_b_charge*Coulomb_constant));

      class Coulomb_wave_functions cwf_zero_kb (true , lb_term , 0.0);

      wf_dwf_k_is_zero (lb , Z_Tb_charge_times_projectile_b_charge , two_I_sqrt_V_Coul_b , norm_kb_is_zero , cwf_zero_kb , R , UR_b , dUR_b);
    }
  else
    {
      class Coulomb_wave_functions cwf_b (true , lb , eta_b);

      if (is_it_bound_case)
	{
	  cwf_b.Wm_kz_dWm_kz (kb , R , UR_b , dUR_b);

	  UR_b = real (UR_b);
	  dUR_b = real (dUR_b);
	}
      else
	cwf_b.H_kz_dH_kz (1 , kb , R , UR_b , dUR_b);
    }

  UR(ib) = Cplus_b*UR_b;
  dUR(ib) = Cplus_b*dUR_b;
}






void CC_bwd_basis_state::Uminus_asymptotic_conditions_calc (
							    class vector_class <complex<double> > &UR , 
							    class vector_class <complex<double> > &dUR) const
{
  if (ic_entrance != ib) error_message_print_abort ("ic_entrance not equal to ib");
  
  if (S_matrix_pole) error_message_print_abort ("Scattering states only in Uminus_asymptotic_conditions_calc.");

  const class CC_channel_class &entrance_channel = channels_tab(ic_entrance);

  const int entrance_LCM_projectile = entrance_channel.get_LCM_projectile ();

  const complex<double> k_projectile_entrance = entrance_channel.get_k_projectile ();

  const complex<double> eta_projectile_entrance = entrance_channel.get_eta_projectile ();

  UR  = 0.0;
  dUR = 0.0;

  complex<double>  UR_entrance;
  complex<double> dUR_entrance;

  class Coulomb_wave_functions cwf_entrance(true , entrance_LCM_projectile , eta_projectile_entrance);

  cwf_entrance.H_kz_dH_kz (-1 , k_projectile_entrance , R , UR_entrance , dUR_entrance);

  UR(ic_entrance) =  UR_entrance;
  dUR(ic_entrance) = dUR_entrance;
}






void CC_bwd_basis_state::backward_integration_before_R (							
							const bool is_it_entrance_channel_only ,			
							const bool is_it_Uminus , 
							const complex<double> &Cplus_b , 
							class CC_system_integration &SI) 
{
  zero ();
  
  const unsigned int N_aft_mp_uniform_minus_one = N_aft_mp_uniform - 1;
  const unsigned int N_aft_mp_uniform_minus_two = N_aft_mp_uniform - 2;

  const double r_aft_mp = N_bef_mp_uniform*step_bef_R_uniform;

  class vector_class<complex<double> >  UR(N_channels);
  class vector_class<complex<double> > dUR(N_channels);

  if (is_it_Uminus)
    Uminus_asymptotic_conditions_calc (UR , dUR);
  else
    Uplus_asymptotic_conditions_calc (Cplus_b , UR , dUR);

  class vector_class<complex<double> > U_aft    = UR , dU_aft    = dUR;
  class vector_class<complex<double> > U        = UR , dU        = dUR;
  class vector_class<complex<double> > U_tab_GL = UR , dU_tab_GL = dUR;

  const double r_aft_mp_bef_R_last = r_aft_mp_bef_R_tab_uniform(N_aft_mp_uniform_minus_one);

  SI(R , UR , dUR , r_aft_mp_bef_R_last , U_aft , dU_aft);

  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  CC_bwd_wf_tab_uniform (ic , N_aft_mp_uniform_minus_one) =  U_aft(ic);
	  CC_bwd_dwf_tab_uniform(ic , N_aft_mp_uniform_minus_one) = dU_aft(ic);
	}
    }
  
  unsigned int iGL = N_aft_mp_GL - 1;

  unsigned int iGL_SGI_MSGI = N_aft_mp_GL_SGI_MSGI - 1;

  for (unsigned int i = N_aft_mp_uniform_minus_two ; i < N_aft_mp_uniform_minus_one ; i--)
    {
      const double r_next = r_aft_mp_bef_R_tab_uniform(i + 1);

      const double r = r_aft_mp_bef_R_tab_uniform(i);

      SI(r_next , U_aft , dU_aft , r , U , dU);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      CC_bwd_wf_tab_uniform (ic , i) =  U(ic);
	      CC_bwd_dwf_tab_uniform(ic , i) = dU(ic);
	    }
	}
      
      while ((iGL < N_aft_mp_GL) && (r_aft_mp_bef_R_tab_GL(iGL) <= r_next) && (r_aft_mp_bef_R_tab_GL(iGL) >= r))
	{
	  const double r_tab_GL = r_aft_mp_bef_R_tab_GL(iGL);
	  
	  SI(r_next , U_aft , dU_aft , r_tab_GL , U_tab_GL , dU_tab_GL);

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	    {
	      CC_bwd_wf_tab_GL (ic , iGL) =  U_tab_GL(ic);
	      CC_bwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
	    }

	  iGL--;
	}

      while ((iGL_SGI_MSGI < N_aft_mp_GL_SGI_MSGI) && (r_aft_mp_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r_next) && (r_aft_mp_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) >= r))
	{
	  const double r_tab_GL_SGI_MSGI = r_aft_mp_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
	  
	  SI(r_next , U_aft , dU_aft , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL);

	  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	    {
	      CC_bwd_wf_tab_GL_SGI_MSGI(ic  , iGL_SGI_MSGI) =  U_tab_GL(ic);
	      CC_bwd_dwf_tab_GL_SGI_MSGI(ic , iGL_SGI_MSGI) = dU_tab_GL(ic);
	    }

	  iGL_SGI_MSGI--;
	}

      U_aft =  U;
      dU_aft = dU;
    }

  SI(r_aft_mp , U_aft , dU_aft , matching_point , U , dU);
	
  for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
    {
      if (!is_it_entrance_channel_only || (ic == ic_entrance))
	{
	  CC_bwd_wf_mp_tab (ic) =  U(ic);
	  CC_bwd_dwf_mp_tab(ic) = dU(ic);
	}
    }
  
  while (iGL < N_aft_mp_GL)
    {
      const double r_tab_GL = r_aft_mp_bef_R_tab_GL(iGL);
      
      SI (r_aft_mp , U_aft , dU_aft , r_tab_GL , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      CC_bwd_wf_tab_GL (ic , iGL) =  U_tab_GL(ic);
	      CC_bwd_dwf_tab_GL(ic , iGL) = dU_tab_GL(ic);
	    }
	}
      
      iGL--;
    } 

  while (iGL_SGI_MSGI < N_aft_mp_GL_SGI_MSGI)
    {
      const double r_tab_GL_SGI_MSGI = r_aft_mp_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
      
      SI(r_aft_mp , U_aft , dU_aft , r_tab_GL_SGI_MSGI , U_tab_GL , dU_tab_GL);

      for (unsigned int ic = 0 ; ic < N_channels ; ic++) 
	{
	  if (!is_it_entrance_channel_only || (ic == ic_entrance))
	    {
	      CC_bwd_wf_tab_GL_SGI_MSGI (ic , iGL_SGI_MSGI) =  U_tab_GL(ic);
	      CC_bwd_dwf_tab_GL_SGI_MSGI(ic , iGL_SGI_MSGI) = dU_tab_GL(ic);
	    }
	}
      
      iGL_SGI_MSGI--;
    }
}






void CC_bwd_basis_state::change_channels (const complex<double> &E) 
{
  for (unsigned int ic = 0 ; ic < N_channels ; ic++)
    channels_tab(ic).E_dependent_values_change (E);
}



class CC_bwd_basis_state & CC_bwd_basis_state::operator= (const class CC_bwd_basis_state &X)
{
  S_matrix_pole = X.S_matrix_pole; 

  N_channels = X.N_channels; 

  N_bef_R_uniform = X.N_bef_R_uniform; 

  N_bef_R_GL = X.N_bef_R_GL; 

  ic_entrance = X.ic_entrance; 

  ib = X.ib; 

  R = X.R; 

  matching_point = X.matching_point; 

  R_max = X.R_max; 

  step_bef_R_uniform = X.step_bef_R_uniform; 

  N_bef_mp_uniform = X.N_bef_mp_uniform; 
  N_aft_mp_uniform = X.N_aft_mp_uniform;

  N_bef_mp_GL = X.N_bef_mp_GL;
  N_aft_mp_GL = X.N_aft_mp_GL;	

  N_bef_mp_GL_SGI_MSGI = X.N_bef_mp_GL_SGI_MSGI;
  N_aft_mp_GL_SGI_MSGI = X.N_aft_mp_GL_SGI_MSGI;

  channels_tab = X.channels_tab;

  r_aft_mp_bef_R_tab_uniform = X.r_aft_mp_bef_R_tab_uniform;

  r_aft_mp_bef_R_tab_GL = X.r_aft_mp_bef_R_tab_GL;

  r_aft_mp_bef_R_tab_GL_SGI_MSGI = X.r_aft_mp_bef_R_tab_GL_SGI_MSGI;

  CC_bwd_wf_tab_uniform  = X.CC_bwd_wf_tab_uniform;
  CC_bwd_dwf_tab_uniform = X.CC_bwd_dwf_tab_uniform;

  CC_bwd_wf_tab_GL  = X.CC_bwd_wf_tab_GL;
  CC_bwd_dwf_tab_GL = X.CC_bwd_dwf_tab_GL;
  
  CC_bwd_wf_tab_GL_SGI_MSGI  = X.CC_bwd_wf_tab_GL_SGI_MSGI;
  CC_bwd_dwf_tab_GL_SGI_MSGI = X.CC_bwd_dwf_tab_GL_SGI_MSGI;

  CC_bwd_wf_mp_tab  = X.CC_bwd_wf_mp_tab;
  CC_bwd_dwf_mp_tab = X.CC_bwd_dwf_mp_tab;

  return *this;
}



bool CC_bwd_basis_state::is_it_filled () const
{
  return (N_bef_R_uniform > 0);
}





double used_memory_calc (const class CC_bwd_basis_state &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.channels_tab) + used_memory_calc (T.r_aft_mp_bef_R_tab_uniform) + used_memory_calc (T.r_aft_mp_bef_R_tab_GL) + used_memory_calc (T.r_aft_mp_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_bwd_wf_tab_uniform) + used_memory_calc (T.CC_bwd_dwf_tab_uniform) + used_memory_calc (T.CC_bwd_wf_tab_GL) + used_memory_calc (T.CC_bwd_dwf_tab_GL) + used_memory_calc (T.CC_bwd_wf_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_bwd_dwf_tab_GL_SGI_MSGI) + used_memory_calc (T.CC_bwd_wf_mp_tab) + used_memory_calc (T.CC_bwd_dwf_mp_tab) - (sizeof (T.channels_tab) + sizeof (T.r_aft_mp_bef_R_tab_uniform) + sizeof (T.r_aft_mp_bef_R_tab_GL) + sizeof (T.r_aft_mp_bef_R_tab_GL_SGI_MSGI) + sizeof (T.CC_bwd_wf_tab_uniform) + sizeof (T.CC_bwd_dwf_tab_uniform) + sizeof (T.CC_bwd_wf_tab_GL) + sizeof (T.CC_bwd_dwf_tab_GL) + sizeof (T.CC_bwd_wf_tab_GL_SGI_MSGI) + sizeof (T.CC_bwd_dwf_tab_GL_SGI_MSGI) + sizeof (T.CC_bwd_wf_mp_tab) + sizeof (T.CC_bwd_dwf_mp_tab))/1000000.0;
  
  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}


