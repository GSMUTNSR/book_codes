#ifndef GSMTBMEINTEREXPANSION_H
#define GSMTBMEINTEREXPANSION_H

// TYPE is double or complex
// -------------------------

namespace TBME_inter_expansion_set
{
  complex<double> two_body_overlap_pp_nn_calc (
					       const unsigned int bin_phase ,
					       const bool same_lj_s0_s1 ,
					       const bool same_s0_s1 , 
					       const complex<double> &overlap_s0_a ,
					       const complex<double> &overlap_s1_a , 
					       const complex<double> &overlap_s0_b ,
					       const complex<double> &overlap_s1_b , 
					       const unsigned int a ,
					       const unsigned int b);

  void J_TBMEs_mixed_inter_pp_nn_calc (
				       const bool is_there_cout ,
				       const enum interaction_read_type inter_read , 
				       const enum space_type TBME_space , 
				       const bool is_it_cluster_CM_HO_basis_calculation , 
				       const class nucleons_data &particles_data , 
				       const class interaction_class &inter_data , 
				       class TBMEs_class &J_TBMEs_mixed_inter);

  TYPE TBME_J_pp_nn_antisymmetrized (
				     const int J , 
				     const unsigned int s0 ,
				     const unsigned int s1 ,
				     const unsigned int s2 ,
				     const unsigned int s3 , 
				     const class array<class vector_class<complex<double> > > &inter_overlaps , 
				     const class array<class nlj_struct> &shells_qn , 
				     const class interaction_class &inter_data , 
				     const class TBMEs_class &J_TBMEs_mixed_inter);

  void J_TBMEs_mixed_inter_pn_calc (
				    const bool is_there_cout , 
				    const enum interaction_read_type inter_read , 
				    const class nucleons_data &prot_data , 
				    const class nucleons_data &neut_data , 
				    const int n_scat_max , 
				    const class interaction_class &inter_data , 
				    class TBMEs_class &J_TBMEs_mixed_inter);

  TYPE TBME_J_pn (
		  const int J , 
		  const unsigned int s0 ,
		  const unsigned int s1 ,
		  const unsigned int s2 ,
		  const unsigned int s3 , 
		  const class array<class vector_class<complex<double> > > &inter_overlaps_prot , 
		  const class array<class vector_class<complex<double> > > &inter_overlaps_neut , 
		  const class array<class nlj_struct> &shells_qn_prot , 
		  const class array<class nlj_struct> &shells_qn_neut , 
		  const class interaction_class &inter_data , 
		  const class TBMEs_class &J_TBMEs_mixed_inter);
}

#endif


