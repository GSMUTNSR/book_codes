#include "../GSM_include/GSM_include_def_common.h"

using namespace Wigner_signs;


// TYPE is double or complex
// -------------------------

// TBME is for two-body matrix element
// -----------------------------------

// MSGI is for Modified Surface Gaussian Interaction
// -------------------------------------------------


// Calculation of the radial one-body matrix element associated to the Gaussian form factor
// ----------------------------------------------------------------------------------------
// One calculates <wf_out | F_Gaussian | wf_in> where F_Gaussian is the Gaussian form factor of the MSGI interaction: 
// F_Gaussian(r) = exp (-(r-R0)^2/mu^2) . Fermi_like_function (2.R0 - 1 , 0.25 , r) (see basic_maths.cpp for the definition of the cut function Fermi_like_function).
// The cut function had been added for stability as calculations were diverging first using only a Gaussian factor.

TYPE TBME_MSGI_set::radial_integral_calc (
					  const class array<double> &Gaussian_tab_weight_GL , 
					  const class spherical_state &wf_in , 
					  const class spherical_state &wf_out)
{
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

  const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL_SGI_MSGI ();
  
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL_SGI_MSGI ();

  complex<double> radial_integral = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) radial_integral += wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*Gaussian_tab_weight_GL(i);  
  
#ifdef TYPEisDOUBLECOMPLEX  
  return radial_integral;
#endif
  
#ifdef TYPEisDOUBLE
  return real (radial_integral);
#endif
}

void TBME_MSGI_set::pp_nn_radial_integral_calc (
						const class nucleons_data &particles_data , 
						const class interaction_class &inter_data , 
						class array<TYPE> &radial_OBMEs)
{
  const unsigned int N_nlj = particles_data.get_N_nlj ();

  const unsigned int N_bef_R_GL = particles_data.get_N_bef_R_GL ();

  const class array<class spherical_state> &shells = particles_data.get_shells ();

  const double R0 = inter_data.get_R0 ();

  const double mu = inter_data.get_mu ();

  const double two_R0 = 2.0*R0;

  const double two_R0_minus_one = two_R0 - 1.0;

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , two_R0 , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> Gaussian_tab_weight_GL(N_bef_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double r_minus_R0_over_mu = (r - R0)/mu;
      
      Gaussian_tab_weight_GL(i) = exp (-r_minus_R0_over_mu*r_minus_R0_over_mu)*Fermi_like_function (two_R0_minus_one , 0.25 , r)*w;
    }

  for (unsigned int s_in = 0 ; s_in < N_nlj ; s_in++)
    for (unsigned int s_out = 0 ; s_out < N_nlj ; s_out++)
      {
	const class spherical_state &wf_in = shells(s_in);
	const class spherical_state &wf_out = shells(s_out);
	
	radial_OBMEs(s_in , s_out) = radial_integral_calc (Gaussian_tab_weight_GL , wf_in , wf_out);
      }
}

void TBME_MSGI_set::pn_radial_integral_calc (
					     const class nucleons_data &prot_data , 
					     const class nucleons_data &neut_data , 
					     const class interaction_class &inter_data , 
					     class array<TYPE> &radial_OBMEs)
{
  const unsigned int Np_nlj = prot_data.get_N_nlj ();
  const unsigned int Nn_nlj = neut_data.get_N_nlj ();

  const unsigned int N_bef_R_GL = prot_data.get_N_bef_R_GL ();
  
  const class array<class spherical_state> &shells_prot = prot_data.get_shells ();
  const class array<class spherical_state> &shells_neut = neut_data.get_shells ();

  const double R0 = inter_data.get_R0 ();

  const double mu = inter_data.get_mu ();

  const double two_R0 = 2.0*R0;

  const double two_R0_minus_one = two_R0 - 1.0;

  class array<double> r_bef_R_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_tab_GL(N_bef_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , two_R0 , r_bef_R_tab_GL , w_bef_R_tab_GL);

  class array<double> Gaussian_tab_weight_GL(N_bef_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double r_minus_R0_over_mu = (r - R0)/mu;
      
      Gaussian_tab_weight_GL(i) = exp (-r_minus_R0_over_mu*r_minus_R0_over_mu)*Fermi_like_function (two_R0_minus_one , 0.25 , r)*w;
    } 

  for (unsigned int sp = 0 ; sp < Np_nlj ; sp++)
    for (unsigned int sn = 0 ; sn < Nn_nlj ; sn++)
      {
	const class spherical_state &wfp = shells_prot(sp);
	const class spherical_state &wfn = shells_neut(sn);
	
	radial_OBMEs(sp , sn) = radial_integral_calc (Gaussian_tab_weight_GL , wfp , wfn);
      }
}








// Calculation of the non-antisymmetrized HO TBME coupled to J of recoil
// ---------------------------------------------------------------------
// The TBME < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J is that of the kinetic Hamiltonian coming from recoil in COSM, i.e. \sum_{i<j} pi.pj/M_core .
// It is coupled to J but not antisymmetrized.
// It is equal to zero if s0 and s2 have same parity, so that one first checks this case and zero is returned then.
// One uses the Wigner Eckhart theorem for scalar operators (see Wigner_signs.cpp) to calculate pi.pj TBMEs.
// There is a minus sign in the returned value as p = -i.hbar.grad .


TYPE TBME_MSGI_set::TBME_pi_pj_J (
				  const int J , 
				  const class array<TYPE> &reduced_grad_02_tab , 
				  const class array<TYPE> &reduced_grad_13_tab , 
				  const unsigned int s0 ,
				  const unsigned int s1 ,
				  const unsigned int s2 ,
				  const unsigned int s3 , 
				  const class spherical_state &wf0 , 
				  const class spherical_state &wf1 , 
				  const class spherical_state &wf2 , 
				  const class spherical_state &wf3)
{
  const int l0 = wf0.get_l ();
  const int l2 = wf2.get_l ();
  
  if ((l0 + l2)%2 == 0) return 0.0;

  const TYPE reduced_grad_02 = reduced_grad_02_tab(s0 , s2);
  const TYPE reduced_grad_13 = reduced_grad_13_tab(s1 , s3);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();
  const double j2 = wf2.get_j ();
  const double j3 = wf3.get_j ();
  
  const TYPE TBME = -Oa_scalar_Ob_ME_calc (1 , j0 , j1 , J , j2 , j3 , J , reduced_grad_02 , reduced_grad_13);

  return TBME;
}





// Calculation of the non-antisymmetrized TBME coupled to J of MSGI
// ----------------------------------------------------------------
// One has V_MSGI(\vec{r},\vec{r'}) = V0_MSGI(Pi,J) F_Gaussian(r) F_Gaussian(r') \sum_l (4Pi/(2l+1)) (Yl(1) . Yl(2))
// with F_Gaussian(r) = exp (-(r-R0)^2/mu^2) . Fermi_like_function (2.R0 - 1 , 0.25 , r) (see basic_maths.cpp for the definition of the cut function Fermi_like_function).
// and with V0_MSGI(BP,J) being a coupling constant depending on parity, the total angular momentum of the two nucleons and their isospin.
//
// One calculates here either the direct or exchange part of the TBME of V_MSGI(\vec{r},\vec{r'}) for either protons only, neutrons only or proton-neutron <s2 s3 | V_MSGI | s0 s1>.
// The recoil term induced by the COSM formalism <s2 s3 | (pi.pj)/M_core | s0 s1> is also added at the end if demanded.

TYPE TBME_MSGI_set::TBME_J (
			    const bool is_there_recoil ,
			    const int J , 
			    const unsigned int s0 ,
			    const unsigned int s1 ,
			    const unsigned int s2 ,
			    const unsigned int s3 , 
			    const class spherical_state &wf0 , 
			    const class spherical_state &wf1 , 
			    const class spherical_state &wf2 , 
			    const class spherical_state &wf3 , 
			    const class array<TYPE> &radial_OBMEs_02_tab , 
			    const class array<TYPE> &radial_OBMEs_13_tab , 
			    const class array<TYPE> &reduced_grad_02_tab , 
			    const class array<TYPE> &reduced_grad_13_tab , 
			    const class interaction_class &inter_data , 
			    const class multipolar_expansion_str &multipolar_expansion)
{  
  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();
  const double j2 = wf2.get_j ();
  const double j3 = wf3.get_j ();
  
  const int l0 = wf0.get_l ();
  const int l1 = wf1.get_l ();
  const int l2 = wf2.get_l ();
  const int l3 = wf3.get_l ();

  const enum particle_type particle_0 = wf0.get_particle ();
  const enum particle_type particle_1 = wf1.get_particle ();
  
  const bool is_it_pn_direct   = (particle_0 == PROTON)  && (particle_1 == NEUTRON);
  const bool is_it_pn_exchange = (particle_0 == NEUTRON) && (particle_1 == PROTON);

  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l0 + l1);
  
  const double angular_TBME = multipolar_expansion.angular_TBME_MSGI_J (l0 , j0 , l1 , j1 , l2 , j2 , l3 , j3 , J);

  const double coupling_constant = inter_data.Gaussian_coupling_constant (bp , J , is_it_pn_direct , is_it_pn_exchange);

  const TYPE radial_product = (is_it_pn_exchange) ? (radial_OBMEs_02_tab(s2 , s0)*radial_OBMEs_13_tab(s1 , s3)) : (radial_OBMEs_02_tab(s0 , s2)*radial_OBMEs_13_tab(s1 , s3));
  
  const TYPE MSGI_result_no_recoil = coupling_constant*angular_TBME*radial_product;
  
  const TYPE MSGI_result_recoil = (is_there_recoil && !is_it_pn_exchange) ? (TBME_pi_pj_J (J , reduced_grad_02_tab , reduced_grad_13_tab , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3)) : (0.0);
  
  const TYPE MSGI_result = MSGI_result_no_recoil + MSGI_result_recoil;

  return MSGI_result;
} 










// Calculation of the antisymmetrized TBME coupled to J of MSGI for protons and neutrons and proton-neutron TBME coupled to J of MSGI
// ----------------------------------------------------------------------------------------------------------------------------------
// The TBME is antisymmetrized for protons only or neutrons only.
//
// If s0 != s1 and s2 != s3, the antisymmetrized TBME is equal to TBME_direct - (-1)^(j0 + j1 - J) TBME_exchange, with
// its direct and exchange parts TBME_direct and TBME_exchange equal to < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J and < s2 s3 | pi.pj (hbar^2 / M) | s1 s0 >_J.

// If s0 = s1 or s2 = s3 or both, one checks if J + T is odd (here T=1). If it is even, zero is returned.
// If not, the antisymmetrized TBME is equal to 2 . (1/sqrt(1 + delta_s0_s1)) . (1/sqrt(1 + delta_s2_s3)) < s2 s3 | pi.pj (hbar^2 / M) | s0 s1 >_J, which is returned.
//
// The proton-neutron TBME coupled to J is not antisymmetrized but is calculated with a direct and exchange part, as one can have isospin exchange.
// Hence, it is first calculated in isospin formalism, where it is antisymmetrized, and is then considered in proton-neutron formalism, where it is not antisymmetrized.

TYPE TBME_MSGI_set::TBME_J_pp_nn_antisymmetrized (
						  const bool is_there_recoil ,
						  const int J , 
						  const unsigned int s0 ,
						  const unsigned int s1 ,
						  const unsigned int s2 ,
						  const unsigned int s3 , 
						  const class array<class spherical_state> &shells , 
						  const class array<TYPE> &radial_OBMEs , 
						  const class array<TYPE> &reduced_grad_tab , 
						  const class interaction_class &inter_data , 
						  const class multipolar_expansion_str &multipolar_expansion)
{
  const int T = 1;

  const class spherical_state &wf0 = shells(s0);
  const class spherical_state &wf1 = shells(s1);
  const class spherical_state &wf2 = shells(s2);
  const class spherical_state &wf3 = shells(s3);

  if (s2 == s3)
    { 
      if ((J + T)%2 == 0) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;

      const double antisymmetry_norm_out = (s0 == s1) ? (M_SQRT1_2) : (1.0);

      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const TYPE TBME = antisymmetry_norm*TBME_J (is_there_recoil , J , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3 , radial_OBMEs , radial_OBMEs , reduced_grad_tab , reduced_grad_tab , inter_data , multipolar_expansion);
      
      return TBME;
    }

  if (s0 == s1)
    { 
      if ((J + T)%2 == 0) return 0.0;

      const TYPE TBME = M_SQRT2*TBME_J (is_there_recoil , J , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3 , radial_OBMEs , radial_OBMEs , reduced_grad_tab , reduced_grad_tab , inter_data , multipolar_expansion);

      return TBME;
    }

  const TYPE TBME_direct   = TBME_J (is_there_recoil , J , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3 , radial_OBMEs , radial_OBMEs , reduced_grad_tab , reduced_grad_tab , inter_data , multipolar_expansion);
  const TYPE TBME_exchange = TBME_J (is_there_recoil , J , s1 , s0 , s2 , s3 , wf1 , wf0 , wf2 , wf3 , radial_OBMEs , radial_OBMEs , reduced_grad_tab , reduced_grad_tab , inter_data , multipolar_expansion);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();

  const TYPE TBME = TBME_direct - minus_one_pow (j0 + j1 - J)*TBME_exchange;

  return TBME;
}

TYPE TBME_MSGI_set::TBME_J_pn (
			       const bool is_there_recoil ,
			       const int J , 
			       const unsigned int s0 ,
			       const unsigned int s1 ,
			       const unsigned int s2 ,
			       const unsigned int s3 , 
			       const class array<class spherical_state> &shells_prot , 
			       const class array<class spherical_state> &shells_neut , 
			       const class array<TYPE> &radial_OBMEs_pp , 
			       const class array<TYPE> &radial_OBMEs_nn , 
			       const class array<TYPE> &radial_OBMEs_pn , 
			       const class array<TYPE> &reduced_grad_prot_tab , 
			       const class array<TYPE> &reduced_grad_neut_tab , 
			       const class interaction_class &inter_data , 
			       const class multipolar_expansion_str &multipolar_expansion)
{
  const class spherical_state &wf0 = shells_prot(s0);
  const class spherical_state &wf1 = shells_neut(s1);
  
  const class spherical_state &wf2 = shells_prot(s2);
  const class spherical_state &wf3 = shells_neut(s3);

  const TYPE TBME_direct   = TBME_J (is_there_recoil , J , s0 , s1 , s2 , s3 , wf0 , wf1 , wf2 , wf3 , radial_OBMEs_pp , radial_OBMEs_nn , reduced_grad_prot_tab , reduced_grad_neut_tab , inter_data , multipolar_expansion);
  const TYPE TBME_exchange = TBME_J (is_there_recoil , J , s1 , s0 , s2 , s3 , wf1 , wf0 , wf2 , wf3 , radial_OBMEs_pn , radial_OBMEs_pn , reduced_grad_prot_tab , reduced_grad_neut_tab , inter_data , multipolar_expansion);

  const double j0 = wf0.get_j ();
  const double j1 = wf1.get_j ();

  const TYPE TBME = TBME_direct - minus_one_pow (j0 + j1 - J)*TBME_exchange;

  return TBME;
}


