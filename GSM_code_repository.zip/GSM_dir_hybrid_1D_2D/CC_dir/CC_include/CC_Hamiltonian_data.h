#ifndef CC_HAMILTONIAN_DATA_H
#define CC_HAMILTONIAN_DATA_H

/* CC_Hamiltonian_data (class)
 */

class CC_Hamiltonian_data
{
public:
  
  CC_Hamiltonian_data ();
  
  CC_Hamiltonian_data (const unsigned int N_channels_c , const class input_data_str &input_data_CC_Berggren);

  CC_Hamiltonian_data (const class CC_Hamiltonian_data &X);
  
  void allocate (const unsigned int N_channels_c , const class input_data_str &input_data_CC_Berggren);

  void allocate_fill (const class CC_Hamiltonian_data &X);

  void deallocate (); 

  unsigned int get_N_channels () const
  {
    return N_channels;
  }
  
  unsigned int get_N_restarts () const
  {
    return N_restarts;
  }

  unsigned int get_Davidson_max_dimension () const
  {
    return Davidson_max_dimension;
  }

  double get_Davidson_eigenvector_precision () const
  {
    return Davidson_eigenvector_precision;
  }

  double get_relative_SVD_precision () const
  {
    return relative_SVD_precision;
  }

  double get_R_cut_function () const
  {
    return R_cut_function;
  }

  double get_d_cut_function () const
  {
    return d_cut_function;
  }

  double get_Ueq_regularizor () const
  {
    return Ueq_regularizor;
  }

  double get_CC_average_n_scat_target_projectile_max () const
  {
    return CC_average_n_scat_target_projectile_max;
  }
    
  void set_dimension_matrices_pole_approximation (const unsigned int dimension_matrices_pole_approximation_c)
  {
    dimension_matrices_pole_approximation = dimension_matrices_pole_approximation_c;
  }

  unsigned int get_dimension_matrices_pole_approximation () const
  {
    return dimension_matrices_pole_approximation;
  }

  void set_dimension_matrices (const unsigned int dimension_matrices_c)
  {
    dimension_matrices = dimension_matrices_c;
  }

  unsigned int get_dimension_matrices () const
  {
    return dimension_matrices;
  }

  void set_dimension_matrices_HO (const unsigned int dimension_matrices_HO_c)
  {
    dimension_matrices_HO = dimension_matrices_HO_c;
  }

  unsigned int get_dimension_matrices_HO () const
  {
    return dimension_matrices_HO;
  }

  void set_dimension_matrices_pole_approximation_CC_Berggren (const unsigned int dimension_matrices_pole_approximation_CC_Berggren_c)
  {
    dimension_matrices_pole_approximation_CC_Berggren = dimension_matrices_pole_approximation_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_pole_approximation_CC_Berggren () const
  {
    return dimension_matrices_pole_approximation_CC_Berggren;
  }

  void set_dimension_matrices_partial_pole_approximation_CC_Berggren (const unsigned int dimension_matrices_partial_pole_approximation_CC_Berggren_c)
  {
    dimension_matrices_partial_pole_approximation_CC_Berggren = dimension_matrices_partial_pole_approximation_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_partial_pole_approximation_CC_Berggren () const
  {
    return dimension_matrices_partial_pole_approximation_CC_Berggren;
  }

  void set_dimension_matrices_CC_Berggren (const unsigned int dimension_matrices_CC_Berggren_c)
  {
    dimension_matrices_CC_Berggren = dimension_matrices_CC_Berggren_c;
  }

  unsigned int get_dimension_matrices_CC_Berggren () const
  {
    return dimension_matrices_CC_Berggren;
  }
  
  class multipolar_expansion_str & get_multipolar_expansion () 
  {
    return multipolar_expansion;
  }

  const class multipolar_expansion_str & get_multipolar_expansion () const
  {
    return multipolar_expansion;
  }

  class CG_str & get_CGs () 
  {
    return CGs;
  }

  const class CG_str & get_CGs () const
  {
    return CGs;
  }
  
  class array<double> & get_HO_wfs_bef_R_tab_uniform () 
  {
    return HO_wfs_bef_R_tab_uniform;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_uniform () const
  {
    return HO_wfs_bef_R_tab_uniform;
  }

  class array<double> & get_HO_wfs_bef_R_tab_GL () 
  {
    return HO_wfs_bef_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_bef_R_tab_GL () const
  {
    return HO_wfs_bef_R_tab_GL;
  }

  class array<double> & get_HO_wfs_aft_R_tab_GL () 
  {
    return HO_wfs_aft_R_tab_GL;
  }

  const class array<double> & get_HO_wfs_aft_R_tab_GL () const
  {
    return HO_wfs_aft_R_tab_GL;
  }

  class array<double> & get_Gaussian_table_GL () 
  {
    return Gaussian_table_GL;
  }

  const class array<double> & get_Gaussian_table_GL () const
  {
    return Gaussian_table_GL;
  }

  class array<double> & get_CC_corrective_factors_tab () 
  {
    return CC_corrective_factors_tab;
  }

  const class array<double> & get_CC_corrective_factors_tab () const
  {
    return CC_corrective_factors_tab;
  }

  class array<class matrix<complex<double> > > & get_QCM_HO_submatrices () 
  {
    return QCM_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_QCM_HO_submatrices () const
  {
    return QCM_HO_submatrices;
  }
  
  class array<class matrix<complex<double> > > & get_QCM_HCM_QCM_HO_submatrices () 
  {
    return QCM_HCM_QCM_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_QCM_HCM_QCM_HO_submatrices () const
  {
    return QCM_HCM_QCM_HO_submatrices;
  }
  
  class array<class matrix<double> > & get_PCM_HCM_PCM_HO_submatrices () 
  {
    return PCM_HCM_PCM_HO_submatrices;
  }

  const class array<class matrix<double> > & get_PCM_HCM_PCM_HO_submatrices () const
  {
    return PCM_HCM_PCM_HO_submatrices;
  }
  
  class array<class matrix<complex<double> > > & get_finite_range_orthogonalized_potential_HO_submatrices () 
  {
    return finite_range_orthogonalized_potential_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_finite_range_orthogonalized_potential_HO_submatrices () const
  {
    return finite_range_orthogonalized_potential_HO_submatrices;
  }

  class array<class matrix<complex<double> > > & get_finite_range_overlaps_HO_submatrices () 
  {
    return finite_range_overlaps_HO_submatrices;
  }
  
  const class array<class matrix<complex<double> > > & get_finite_range_overlaps_HO_submatrices () const
  {
    return finite_range_overlaps_HO_submatrices;
  }

  class array<class matrix<complex<double> > > & get_finite_range_potential_HO_submatrices () 
  {
    return finite_range_potential_HO_submatrices;
  }
  
  const class array<class matrix<complex<double> > > & get_finite_range_potential_HO_submatrices () const
  {
    return finite_range_potential_HO_submatrices;
  }

  class array<class matrix<complex<double> > > & get_Delta_HO_submatrices () 
  {
    return Delta_HO_submatrices;
  }

  const class array<class matrix<complex<double> > > & get_Delta_HO_submatrices () const
  {
    return Delta_HO_submatrices;
  }

  class array<bool> & get_is_it_forbidden_channel_tab () 
  {
    return is_it_forbidden_channel_tab;
  }

  const class array<bool> & get_is_it_forbidden_channel_tab () const
  {
    return is_it_forbidden_channel_tab;
  }

  class array<bool> & get_is_it_forbidden_channel_CC_Berggren_tab () 
  {
    return is_it_forbidden_channel_CC_Berggren_tab;
  }

  const class array<bool> & get_is_it_forbidden_channel_CC_Berggren_tab () const
  {
    return is_it_forbidden_channel_CC_Berggren_tab;
  }

  class array<unsigned int> & get_matrices_indices () 
  {
    return matrices_indices;
  }

  const class array<unsigned int> & get_matrices_indices () const
  {
    return matrices_indices;
  }

  class array<unsigned int> & get_matrices_indices_HO () 
  {
    return matrices_indices_HO;
  }

  const class array<unsigned int> & get_matrices_indices_HO () const
  {
    return matrices_indices_HO;
  }

  class array<unsigned int> & get_matrices_indices_CC_Berggren () 
  {
    return matrices_indices_CC_Berggren;
  }

  const class array<unsigned int> & get_matrices_indices_CC_Berggren () const
  {
    return matrices_indices_CC_Berggren;
  }

  class matrix<double> & get_finite_range_overlaps_HO_matrices () 
  {
    return finite_range_overlaps_HO_matrix;
  }

  const class matrix<double> & get_finite_range_overlaps_HO_matrices () const
  {
    return finite_range_overlaps_HO_matrix;
  }

  class matrix<double> & get_finite_range_potential_HO_matrices () 
  {
    return finite_range_potential_HO_matrix;
  }

  const class matrix<double> & get_finite_range_potential_HO_matrices () const
  {
    return finite_range_potential_HO_matrix;
  }

  class matrix<double> & get_Ho_HO_matrices () 
  {
    return Ho_HO_matrix;
  }

  const class matrix<double> & get_Ho_HO_matrices () const
  {
    return Ho_HO_matrix;
  }

  class matrix<double> & get_finite_range_orthogonalized_potential_HO_matrices () 
  {
    return finite_range_orthogonalized_potential_HO_matrix;
  }

  const class matrix<double> & get_finite_range_orthogonalized_potential_HO_matrices () const
  {
    return finite_range_orthogonalized_potential_HO_matrix;
  }

  class matrix<double> & get_overlaps_HO_matrices () 
  {
    return overlaps_HO_matrix;
  }

  const class matrix<double> & get_overlaps_HO_matrices () const
  {
    return overlaps_HO_matrix;
  }

  class matrix<double> & get_sqrt_overlaps_HO_matrices () 
  {
    return sqrt_overlaps_HO_matrix;
  }

  const class matrix<double> & get_sqrt_overlaps_HO_matrices () const
  {
    return sqrt_overlaps_HO_matrix;
  }

  class matrix<double> & get_sqrt_inv_overlaps_HO_matrices () 
  {
    return sqrt_inv_overlaps_HO_matrix;
  }

  const class matrix<double> & get_sqrt_inv_overlaps_HO_matrices () const
  {
    return sqrt_inv_overlaps_HO_matrix;
  }

  class matrix<double> & get_H_HO_matrices () 
  {
    return H_HO_matrix;
  }

  const class matrix<double> & get_H_HO_matrices () const
  {
    return H_HO_matrix;
  }

  class matrix<double> & get_H_Delta_plus_Delta_H_HO_matrices () 
  {
    return H_Delta_plus_Delta_H_HO_matrix;
  }

  const class matrix<double> & get_H_Delta_plus_Delta_H_HO_matrices () const
  {
    return H_Delta_plus_Delta_H_HO_matrix;
  }

  class matrix<double> & get_Delta_H_Delta_HO_matrices () 
  {
    return Delta_H_Delta_HO_matrix;
  }

  const class matrix<double> & get_Delta_H_Delta_HO_matrices () const
  {
    return Delta_H_Delta_HO_matrix;
  }

  class matrix<double> & get_Delta_HO_matrices () 
  {
    return Delta_HO_matrix;
  }

  const class matrix<double> & get_Delta_HO_matrices () const
  {
    return Delta_HO_matrix;
  }

  class matrix<complex<double> > & get_overlaps_matrix_pole_approximation () 
  {
    return overlaps_matrix_pole_approximation;
  }

  const class matrix<complex<double> > & get_overlaps_matrix_pole_approximation () const
  {
    return overlaps_matrix_pole_approximation;
  }

  class matrix<complex<double> > & get_H_matrix_pole_approximation () 
  {
    return H_matrix_pole_approximation;
  }

  const class matrix<complex<double> > & get_H_matrix_pole_approximation () const
  {
    return H_matrix_pole_approximation;
  }

  class matrix<complex<double> > & get_overlaps_matrix () 
  {
    return overlaps_matrix;
  }

  const class matrix<complex<double> > & get_overlaps_matrix () const
  {
    return overlaps_matrix;
  }

  class matrix<complex<double> > & get_H_matrix () 
  {
    return H_matrix;
  }

  const class matrix<complex<double> > & get_H_matrix () const
  {
    return H_matrix;
  }

  class matrix<complex<double> > & get_orthogonalized_H_matrix_CC_Berggren () 
  {
    return orthogonalized_H_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_matrix_CC_Berggren () const
  {
    return orthogonalized_H_matrix_CC_Berggren;
  }

  class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;
  }

  class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren;
  }

  const class matrix<complex<double> > & get_orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren;
  }

  class array<complex<double> > & get_orthogonalized_H_tridiagonalized_diagonal_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;
  }

  const class array<complex<double> > & get_orthogonalized_H_tridiagonalized_diagonal_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;
  }

  class array<complex<double> > & get_orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren () 
  {
    return orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren;
  }

  const class array<complex<double> > & get_orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren () const
  {
    return orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren;
  }

  class array<complex<double> > & get_Ueq_tab () 
  {
    return Ueq_tab;
  }

  const class array<complex<double> > & get_Ueq_tab () const
  {
    return Ueq_tab;
  }

  class array<complex<double> > & get_source_tab () 
  {
    return source_tab;
  }

  const class array<complex<double> > & get_source_tab () const
  {
    return source_tab;
  }

  void submatrices_realloc_one_nucleon_init (
					     const class array<class CC_channel_class> &channels_tab , 
					     const class array<int> &nmax_HO_lab_tab);

  void submatrices_realloc_cluster_init (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab); 

  void dimension_matrices_independent_data_realloc_init (
							 const bool is_it_one_nucleon_COSM_case , 
							 const class input_data_str &input_data_CC_Berggren , 
							 const class interaction_class &inter_data_basis , 
							 const class array<class CC_channel_class> &channels_tab , 
							 const class nucleons_data &prot_data , 
							 const class nucleons_data &neut_data , 
							 const class array<class cluster_data> &cluster_projectile_data_tab , 
							 const class nucleons_data &prot_data_CC_Berggren , 
							 const class nucleons_data &neut_data_CC_Berggren , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void dimensions_matrices_one_nucleon_calc (
					     const class interaction_class &inter_data_basis , 
					     const class nucleons_data &prot_data , 
					     const class nucleons_data &neut_data , 
					     const class nucleons_data &prot_data_CC_Berggren , 
					     const class nucleons_data &neut_data_CC_Berggren , 
					     const class array<class CC_channel_class> &channels_tab);

  void dimensions_matrices_cluster_calc (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab); 

  void dimension_matrices_dependent_data_realloc_init ();

  void all_matrices_indices_one_nucleon_calc (
					      const class interaction_class &inter_data_basis , 
					      const class nucleons_data &prot_data , 
					      const class nucleons_data &neut_data , 
					      const class nucleons_data &prot_data_CC_Berggren , 
					      const class nucleons_data &neut_data_CC_Berggren ,  
					      const class array<class CC_channel_class> &channels_tab);

  void all_matrices_indices_cluster_calc (
					  const class array<class CC_channel_class> &channels_tab , 
					  const class array<class cluster_data> &cluster_projectile_data_tab , 
					  const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void is_it_forbidden_channel_CC_Berggren_tab_one_nucleon_determine (
								      const class array<class CC_channel_class> &channels_tab , 
								      const class nucleons_data &prot_data , 
								      const class nucleons_data &neut_data );

  void is_it_forbidden_channel_CC_Berggren_tab_cluster_determine  (
								   const class array<class CC_channel_class> &channels_tab , 
								   const class array<class cluster_data> &cluster_projectile_data_tab);

  void HO_wfs_Gaussian_tables_calc (
				    const double R , 
				    const double R_max , 
				    const class array<class CC_channel_class> &channels_tab , 
				    const class interaction_class &inter_data_basis);
  
  void corrective_factors_read (const class input_data_str &input_data_CC_Berggren);

  void overlaps_H_HO_matrices_calc ();

  void H_overlaps_matrices_copy_disk (const unsigned int BP , const double J) const;

  void H_tridiagonalized_copy_disk (const unsigned int BP , const double J) const;

  void HO_submatrices_one_nucleon_fill (
					const class array<class CC_channel_class> &channels_tab , 
					const class interaction_class &inter_data_basis);

  void HO_submatrices_cluster_fill (
				    const class array<class CC_channel_class> &channels_tab , 
				    const class array<class cluster_data> &cluster_projectile_data_tab);

  void H_overlaps_matrices_read_from_file (const unsigned int BP , const double J);

  void H_tridiagonalized_read_from_file (const unsigned int BP , const double J);

#ifdef UseMPI
  void H_overlaps_matrices_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
  void H_overlaps_matrices_MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);

  void H_tridiagonalized_MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);
#endif

  void overlaps_H_matrices_diagonalization_test (const unsigned int BP , const double J) const;

  void finite_range_overlaps_potential_Ho_HO_matrices_one_nucleon_calc (
									const class array<class CC_channel_class> &channels_tab , 
									const class interaction_class &inter_data_basis , 
									const class HF_nucleons_data &prot_HF_data , 
									const class HF_nucleons_data &neut_HF_data , 
									const class nucleons_data &prot_data_one_configuration_GSM , 
									const class nucleons_data &neut_data_one_configuration_GSM , 
									const class nucleons_data &prot_data , 
									const class nucleons_data &neut_data , 
									const class nucleons_data &prot_data_CC_Berggren , 
									const class nucleons_data &neut_data_CC_Berggren);

  void finite_range_overlaps_potential_Ho_HO_matrices_cluster_calc (
								    const class array<class CC_channel_class> &channels_tab , 
								    const class array<class cluster_data> &cluster_projectile_data_tab);

  void Delta_H_HO_matrices_one_nucleon_calc (
					     const class array<class CC_channel_class> &channels_tab , 
					     const class nucleons_data &prot_data , 
					     const class nucleons_data &neut_data , 
					     const class interaction_class &inter_data_basis);

  void Delta_H_HO_matrices_cluster_calc (
					 const class array<class CC_channel_class> &channels_tab , 
					 const class array<class cluster_data> &cluster_projectile_data_tab);

  void PCM_function_HO_matrices_cluster_calc (
					      const class array<class CC_channel_class> &channels_tab , 
					      const class array<class cluster_data> &cluster_projectile_data_tab);

  void orthogonalized_H_tridiagonalization_CC_Berggren ();

  friend double used_memory_calc (const class CC_Hamiltonian_data &T);
  
private:

  unsigned int N_channels;
  unsigned int N_restarts;
  unsigned int Davidson_max_dimension;

  double Davidson_eigenvector_precision;

  double relative_SVD_precision;

  double R_cut_function;
  double d_cut_function;
  
  double Ueq_regularizor;

  double CC_average_n_scat_target_projectile_max;

  unsigned int dimension_matrices_pole_approximation;
  unsigned int dimension_matrices;
  unsigned int dimension_matrices_HO;

  unsigned int dimension_matrices_pole_approximation_CC_Berggren;
  unsigned int dimension_matrices_partial_pole_approximation_CC_Berggren;
  unsigned int dimension_matrices_CC_Berggren;
  
  class multipolar_expansion_str multipolar_expansion;

  class CG_str CGs;

  class array<double> HO_wfs_bef_R_tab_uniform;
  class array<double> HO_wfs_bef_R_tab_GL;
  class array<double> HO_wfs_aft_R_tab_GL;
  class array<double> Gaussian_table_GL;
  class array<double> CC_corrective_factors_tab;

  class array<class matrix<complex<double> > > QCM_HO_submatrices;
  class array<class matrix<complex<double> > > QCM_HCM_QCM_HO_submatrices;
  
  class array<class matrix<double> > PCM_HCM_PCM_HO_submatrices;
    
  class array<class matrix<complex<double> > > finite_range_orthogonalized_potential_HO_submatrices;
  class array<class matrix<complex<double> > > finite_range_overlaps_HO_submatrices;
  class array<class matrix<complex<double> > > finite_range_potential_HO_submatrices;
  class array<class matrix<complex<double> > > Delta_HO_submatrices;

  class array<bool> is_it_forbidden_channel_tab;
  class array<bool> is_it_forbidden_channel_CC_Berggren_tab;

  class array<unsigned int> matrices_indices;
  class array<unsigned int> matrices_indices_HO;
  class array<unsigned int> matrices_indices_CC_Berggren;

  class matrix<double> finite_range_overlaps_HO_matrix;
  class matrix<double> finite_range_potential_HO_matrix;
  class matrix<double> Ho_HO_matrix;
  class matrix<double> finite_range_orthogonalized_potential_HO_matrix;
  
  class matrix<double> overlaps_HO_matrix;
  class matrix<double> sqrt_overlaps_HO_matrix;
  class matrix<double> sqrt_inv_overlaps_HO_matrix;
  class matrix<double> H_HO_matrix;
  class matrix<double> H_Delta_plus_Delta_H_HO_matrix;
  class matrix<double> Delta_H_Delta_HO_matrix;
  class matrix<double> Delta_HO_matrix;

  class matrix<complex<double> > overlaps_matrix_pole_approximation;
  class matrix<complex<double> > H_matrix_pole_approximation;
  class matrix<complex<double> > overlaps_matrix;
  class matrix<complex<double> > H_matrix;
  class matrix<complex<double> > orthogonalized_H_matrix_CC_Berggren;
  class matrix<complex<double> > orthogonalized_H_tridiagonalized_P_matrix_CC_Berggren;
  class matrix<complex<double> > orthogonalized_H_tridiagonalized_P_transpose_matrix_CC_Berggren;

  class array<complex<double> > orthogonalized_H_tridiagonalized_diagonal_CC_Berggren;
  class array<complex<double> > orthogonalized_H_tridiagonalized_off_diagonal_CC_Berggren;
  class array<complex<double> > Ueq_tab;
  class array<complex<double> > source_tab;

  void matrices_indices_pole_approximation_one_nucleon_calc (
							     const class nucleons_data &prot_data , 
							     const class nucleons_data &neut_data , 
							     const class nucleons_data &prot_data_CC_Berggren , 
							     const class nucleons_data &neut_data_CC_Berggren , 
							     const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_partial_pole_approximation_CC_Berggren_one_nucleon_calc (
										 const class nucleons_data &prot_data_CC_Berggren , 
										 const class nucleons_data &neut_data_CC_Berggren , 
										 const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_one_nucleon_calc (
					  const class interaction_class &inter_data_basis , 
					  const class nucleons_data &prot_data , 
					  const class nucleons_data &neut_data , 
					  const class nucleons_data &prot_data_CC_Berggren , 
					  const class nucleons_data &neut_data_CC_Berggren , 
					  const class array<class CC_channel_class> &channels_tab);

  void matrices_indices_pole_approximation_cluster_calc (
							 const class array<class CC_channel_class> &channels_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_tab , 
							 const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void matrices_indices_partial_pole_approximation_CC_Berggren_cluster_calc (
									     const class array<class CC_channel_class> &channels_tab , 
									     const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void matrices_indices_cluster_calc (
				      const class array<class CC_channel_class> &channels_tab , 
				      const class array<class cluster_data> &cluster_projectile_data_tab , 
				      const class array<class cluster_data> &cluster_projectile_data_CC_Berggren_tab);

  void original_to_HO_matrix_one_nucleon_calc (
					       const class array<class CC_channel_class> &channels_tab , 
					       const class nucleons_data &prot_data , 
					       const class nucleons_data &neut_data , 
					       const class interaction_class &inter_data_basis , 
					       const class matrix<complex<double> > &original_matrix , 
					       class matrix<double> &HO_matrix);		

  void original_to_HO_matrix_cluster_calc (
					   const class array<class CC_channel_class> &channels_tab , 
					   const class array<class cluster_data> &cluster_projectile_data_tab , 
					   const class matrix<complex<double> > &original_matrix , 
					   class matrix<double> &HO_matrix);
};



#endif


