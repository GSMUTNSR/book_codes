#ifndef CC_OVERLAPFUNCTIONCOMPOSITE_H
#define CC_OVERLAPFUNCTIONCOMPOSITE_H

namespace CC_overlap_function_composite
{
  void target_projectile_as_HO_NBMEs_calc (
					   const bool is_it_one_nucleon_COSM_case , 
					   const enum spectroscopic_factor_type SF ,
					   const enum nucleus_type nucleus , 
					   const enum particle_type projectile ,
					   const double b_HO , 
					   const int NCM_HO_max_projectile ,
					   const int LCM_projectile ,
					   const bool is_it_Gauss_Legendre , 
					   const class CC_Hamiltonian_data &CC_H_data , 
					   const class CC_state_class &CC_state , 
					   const class input_data_str &input_data_CC_Berggren , 
					   class nucleons_data &prot_data_out , 
					   class nucleons_data &neut_data_out ,
					   class array<class cluster_data> &cluster_projectile_data_tab , 
					   const class array<class vector_class<complex<double> > > &CC_HO_overlaps , 
					   const class correlated_state_str &PSI_in_qn , 
					   const class correlated_state_str &PSI_out_qn , 
					   const class correlated_state_str &PSI_projectile_qn , 
					   const class array<double> &r_tab , 
					   class array<TYPE> &target_projectile_as_HO_overlap_function_tab);

  void projectile_nas_NBMEs_calc (
				  const enum spectroscopic_factor_type SF , 
				  const enum particle_type projectile , 
				  const int LCM_projectile , 
				  const bool is_it_Gauss_Legendre , 
				  const class CC_state_class &CC_state ,
				  const class correlated_state_str &PSI_in_qn , 
				  const class correlated_state_str &PSI_out_qn , 
				  const class correlated_state_str &PSI_projectile_qn , 
				  class array<TYPE> &projectile_nas_overlap_function_tab);
  
  void calc (
	     const bool is_it_one_nucleon_COSM_case , 
	     const enum spectroscopic_factor_type SF , 
	     const enum nucleus_type nucleus , 
	     const enum particle_type projectile ,
	     const double b_HO , 
	     const int NCM_HO_max_projectile ,
	     const int LCM_projectile ,
	     const bool is_it_Gauss_Legendre , 
	     const bool is_it_nas_only , 
	     const class CC_Hamiltonian_data &CC_H_data , 
	     const class CC_state_class &CC_state , 
	     class nucleons_data &prot_data_out , 
	     class nucleons_data &neut_data_out , 
	     class array<class cluster_data> &cluster_projectile_data_tab ,
	     const class input_data_str &input_data_CC_Berggren , 
	     const class correlated_state_str &PSI_in_qn , 
	     const class correlated_state_str &PSI_out_qn , 
	     const class correlated_state_str &PSI_projectile_qn , 
	     const class array<double> &r_tab , 
	     class array<TYPE> &overlap_function_tab);
}

#endif


