#ifndef GSMSCALARDENSITYMATRIX_H
#define GSMSCALARDENSITYMATRIX_H

// TYPE is double or complex
// -------------------------

namespace scalar_density_matrix
{
  void diagonal_parts_pp_nn_fixed_configuration_calc (
						      const class nucleons_data &data , 
						      const class configuration &C ,
						      class nlj_table<int> &diagonal_parts_fixed_iC);

  void components_parts_one_jump_mu_calc (
					  const class nucleons_data &data , 
					  const class jumps_data_out_to_in_str &one_jump_mu , 
					  const class array<bool> &is_configuration_accepted_tab , 
					  const class array<unsigned long int> &total_PSI_IN_indices_one_jump_mu ,
					  const class GSM_vector &PSI ,
					  class lj_table<TYPE> &components_parts_one_jump_mu);

  void diagonal_parts_calc (
			    const class nlj_table<int> &diagonal_parts_fixed_iC ,
			    const TYPE &PSI_out_component ,
			    const TYPE &PSI_out_component_TRS_factor ,
			    class lj_table<class matrix<TYPE> > &scalar_density_matrices_fixed_iC);
  
  void one_jump_mu_part_calc (
			      const class lj_table<TYPE> &components_parts_one_jump_mu ,
			      const TYPE &PSI_out_component_TRS_factor ,
			      class lj_table<class matrix<TYPE> > &scalar_density_matrices_fixed_iC);
  
  void pp_nn_diagonal_parts_calc (
				  const class GSM_vector &PSI ,
				  const class GSM_vector &PSI_full ,
				  class lj_table<class matrix<TYPE> > &scalar_density_matrices);

  void pp_nn_one_jump_parts_calc (
				  const class GSM_vector &PSI ,
				  const class GSM_vector &PSI_full ,
				  class lj_table<class matrix<TYPE> > &scalar_density_matrices);

  void diagonal_parts_pn_prot_part_calc (
					 const class GSM_vector &PSI ,
					 const class GSM_vector &PSI_full ,
					 class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices);

  void diagonal_parts_pn_neut_part_calc (
					 const class GSM_vector &PSI ,
					 const class GSM_vector &PSI_full ,
					 class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices);

  void one_jump_p_parts_pn_calc (
				 const class GSM_vector &PSI ,
				 const class GSM_vector &PSI_full ,
				 class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices);

  void one_jump_n_parts_pn_calc (
				 const class GSM_vector &PSI ,
				 const class GSM_vector &PSI_full ,
				 class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices);

  void calc (
	     const class GSM_vector &PSI , 
	     const class GSM_vector &PSI_full ,
	     class lj_table<class matrix<TYPE> > &prot_scalar_density_matrices ,
	     class lj_table<class matrix<TYPE> > &neut_scalar_density_matrices);
}

#endif


