#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);

    const double precision_der = 1E-5;
    
    const int A = 4;

    const int Z_charge = 2;

    const int n = 0;
    const int l = 2;
    
    const double target_mass = 4;

    const double R = 15;

    const double Rmp = 5;

    const double Rmax = 50;

    const double k = 0.1;

    const double nu_mass = 1;

    const double j = l + 0.5;

    const unsigned int N_GL = 100;
    const unsigned int N_uniform = 600;

    const double d = 0.65;
    const double R0 = 2.0;
    const double Vo = 47.0;
    const double Vso = 7.5;
    const double Rc = 2.0;

    class potentials_effective_mass T;
    class potentials_effective_mass T_d_p   , T_d_m;
    class potentials_effective_mass T_R0_p  , T_R0_m;
    class potentials_effective_mass T_Vo_p  , T_Vo_m;
    class potentials_effective_mass T_Vso_p , T_Vso_m;
    class potentials_effective_mass T_Rc_p  , T_Rc_m;

    T.get_WS_analytic_potential ().initialize (false , d , R0 , Vo , Vso , PROTON , Z_charge , Rc , l , j);

    T_d_p.get_WS_analytic_potential ().initialize (false , d*(1.0 + precision_der) , R0 , Vo , Vso , PROTON , Z_charge , Rc , l , j);
    T_d_m.get_WS_analytic_potential ().initialize (false , d*(1.0 - precision_der) , R0 , Vo , Vso , PROTON , Z_charge , Rc , l , j);

    T_R0_p.get_WS_analytic_potential ().initialize (false , d , R0*(1.0 + precision_der) , Vo , Vso , PROTON , Z_charge , Rc , l , j);
    T_R0_m.get_WS_analytic_potential ().initialize (false , d , R0*(1.0 - precision_der) , Vo , Vso , PROTON , Z_charge , Rc , l , j);

    T_Vo_p.get_WS_analytic_potential ().initialize (false , d , R0 , Vo*(1.0 + precision_der) , Vso , PROTON , Z_charge , Rc , l , j);
    T_Vo_m.get_WS_analytic_potential ().initialize (false , d , R0 , Vo*(1.0 - precision_der) , Vso , PROTON , Z_charge , Rc , l , j);

    T_Vso_p.get_WS_analytic_potential ().initialize (false , d , R0 , Vo , Vso*(1.0 + precision_der) , PROTON , Z_charge , Rc , l , j);
    T_Vso_m.get_WS_analytic_potential ().initialize (false , d , R0 , Vo , Vso*(1.0 - precision_der) , PROTON , Z_charge , Rc , l , j);
	
    T_Rc_p.get_WS_analytic_potential ().initialize (false , d , R0 , Vo , Vso , PROTON , Z_charge , Rc*(1.0 + precision_der) , l , j);
    T_Rc_m.get_WS_analytic_potential ().initialize (false , d , R0 , Vo , Vso , PROTON , Z_charge , Rc*(1.0 - precision_der) , l , j);

    class spherical_state u(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    class spherical_state u_d_p(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);
    class spherical_state u_d_m(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    class spherical_state u_R0_p(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);
    class spherical_state u_R0_m(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    class spherical_state u_Vo_p(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);
    class spherical_state u_Vo_m(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    class spherical_state u_Vso_p(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);
    class spherical_state u_Vso_m(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    class spherical_state u_Rc_p(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);
    class spherical_state u_Rc_m(false , true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , Rmp , Rmax , 0.0 , 0.0 , false , PROTON , n , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

    T.initialize_constants (WS_ANALYTIC , u.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    
    T_d_p.initialize_constants (WS_ANALYTIC , u_d_p.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_d_m.initialize_constants (WS_ANALYTIC , u_d_m.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    
    T_R0_p.initialize_constants (WS_ANALYTIC , u_R0_p.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_R0_m.initialize_constants (WS_ANALYTIC , u_R0_m.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_Vo_p.initialize_constants (WS_ANALYTIC , u_Vo_p.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_Vo_m.initialize_constants (WS_ANALYTIC , u_Vo_m.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    
    T_Vso_p.initialize_constants (WS_ANALYTIC , u_Vso_p.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_Vso_m.initialize_constants (WS_ANALYTIC , u_Vso_m.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    
    T_Rc_p.initialize_constants (WS_ANALYTIC , u_Rc_p.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
    T_Rc_m.initialize_constants (WS_ANALYTIC , u_Rc_m.get_kinetic_factor () , NADA , l , Z_charge , j , k , u.get_eta () , NADA);
	
    const unsigned int N_parameters_to_fit = 5;
    
    class array<enum WS_parameter_type> WS_parameters_from_fit_index(N_parameters_to_fit);

    WS_parameters_from_fit_index(0) = D_PROTON;
    WS_parameters_from_fit_index(1) = R0_PROTON;
    WS_parameters_from_fit_index(2) = VO_PROTON;
    WS_parameters_from_fit_index(3) = VSO_PROTON;
    WS_parameters_from_fit_index(4) = R_CHARGE_PROTON;

    u.wave_calculation (true , T , true);
    
    class spherical_state_partial_derivatives u_partial_derivative(T.get_WS_analytic_potential () , WS_parameters_from_fit_index , u);

    u_partial_derivative.wave_partial_derivatives_calculation ();

    u_d_p.wave_calculation (true , T_d_p , true);
    u_d_m.wave_calculation (true , T_d_m , true);

    u_R0_p.wave_calculation (true , T_R0_p , true);
    u_R0_m.wave_calculation (true , T_R0_m , true);

    u_Vo_p.wave_calculation (true , T_Vo_p , true);
    u_Vo_m.wave_calculation (true , T_Vo_m , true);

    u_Vso_p.wave_calculation (true , T_Vso_p , true);
    u_Vso_m.wave_calculation (true , T_Vso_m , true);

    u_Rc_p.wave_calculation (true , T_Rc_p , true);
    u_Rc_m.wave_calculation (true , T_Rc_m , true);

    // By definition of du/dx ,   u(x + eps , r) ~ C0(u).r^(l+1) ,  with C0(u) the constant provided by the initial WS potential.
    // However, all u states are normalized so that 2.Pi.C+.C- = 1.
    // Hence, one does not have du/dx ~ (u(x + eps) - u(x - eps))/(2.eps) for eps -> 0 with previously calculated u(x +/- eps) without modification of their normalization.
    // It is sufficient to replace the C0(u(x +/ eps)) issued from 2.Pi.C+.C- = 1 normalization by C0(u) so that du/dx ~ (u(x + eps) - u(x - eps))/(2.eps) with previously calculated u(x +/- eps).
    // This justifies the renormalization effected below.
    
    u_d_p.normalization (u.get_C0 () / u_d_p.get_C0 ());
    u_d_m.normalization (u.get_C0 () / u_d_m.get_C0 ());

    u_R0_p.normalization (u.get_C0 () / u_R0_p.get_C0 ());
    u_R0_m.normalization (u.get_C0 () / u_R0_m.get_C0 ());

    u_Vo_p.normalization (u.get_C0 () / u_Vo_p.get_C0 ());
    u_Vo_m.normalization (u.get_C0 () / u_Vo_m.get_C0 ());

    u_Vso_p.normalization (u.get_C0 () / u_Vso_p.get_C0 ());
    u_Vso_m.normalization (u.get_C0 () / u_Vso_m.get_C0 ());

    u_Rc_p.normalization (u.get_C0 () / u_Rc_p.get_C0 ());
    u_Rc_m.normalization (u.get_C0 () / u_Rc_m.get_C0 ());
    
    const class array<complex<double> > &wf_der_tab_uniform = u_partial_derivative.get_wf_bef_R_der_tab_uniform ();
    
    const class array<complex<double> > &dwf_der_tab_uniform = u_partial_derivative.get_dwf_bef_R_der_tab_uniform ();

    const class array<complex<double> > &d2wf_der_tab_uniform = u_partial_derivative.get_d2wf_bef_R_der_tab_uniform ();
    
    const class array<complex<double> > &wf_d_p_tab_uniform = u_d_p.get_wf_bef_R_tab_uniform ();
    const class array<complex<double> > &wf_d_m_tab_uniform = u_d_m.get_wf_bef_R_tab_uniform ();

    const class array<complex<double> > &dwf_d_p_tab_uniform = u_d_p.get_dwf_bef_R_tab_uniform ();
    const class array<complex<double> > &dwf_d_m_tab_uniform = u_d_m.get_dwf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &d2wf_d_p_tab_uniform = u_d_p.get_d2wf_bef_R_tab_uniform ();
    const class array<complex<double> > &d2wf_d_m_tab_uniform = u_d_m.get_d2wf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &wf_R0_p_tab_uniform = u_R0_p.get_wf_bef_R_tab_uniform ();
    const class array<complex<double> > &wf_R0_m_tab_uniform = u_R0_m.get_wf_bef_R_tab_uniform ();

    const class array<complex<double> > &dwf_R0_p_tab_uniform = u_R0_p.get_dwf_bef_R_tab_uniform ();
    const class array<complex<double> > &dwf_R0_m_tab_uniform = u_R0_m.get_dwf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &d2wf_R0_p_tab_uniform = u_R0_p.get_d2wf_bef_R_tab_uniform ();
    const class array<complex<double> > &d2wf_R0_m_tab_uniform = u_R0_m.get_d2wf_bef_R_tab_uniform ();

    const class array<complex<double> > &wf_Vo_p_tab_uniform = u_Vo_p.get_wf_bef_R_tab_uniform ();
    const class array<complex<double> > &wf_Vo_m_tab_uniform = u_Vo_m.get_wf_bef_R_tab_uniform ();

    const class array<complex<double> > &dwf_Vo_p_tab_uniform = u_Vo_p.get_dwf_bef_R_tab_uniform ();
    const class array<complex<double> > &dwf_Vo_m_tab_uniform = u_Vo_m.get_dwf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &d2wf_Vo_p_tab_uniform = u_Vo_p.get_d2wf_bef_R_tab_uniform ();
    const class array<complex<double> > &d2wf_Vo_m_tab_uniform = u_Vo_m.get_d2wf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &wf_Vso_p_tab_uniform = u_Vso_p.get_wf_bef_R_tab_uniform ();
    const class array<complex<double> > &wf_Vso_m_tab_uniform = u_Vso_m.get_wf_bef_R_tab_uniform ();

    const class array<complex<double> > &dwf_Vso_p_tab_uniform = u_Vso_p.get_dwf_bef_R_tab_uniform ();
    const class array<complex<double> > &dwf_Vso_m_tab_uniform = u_Vso_m.get_dwf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &d2wf_Vso_p_tab_uniform = u_Vso_p.get_d2wf_bef_R_tab_uniform ();
    const class array<complex<double> > &d2wf_Vso_m_tab_uniform = u_Vso_m.get_d2wf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &wf_Rc_p_tab_uniform = u_Rc_p.get_wf_bef_R_tab_uniform ();
    const class array<complex<double> > &wf_Rc_m_tab_uniform = u_Rc_m.get_wf_bef_R_tab_uniform ();

    const class array<complex<double> > &dwf_Rc_p_tab_uniform = u_Rc_p.get_dwf_bef_R_tab_uniform ();
    const class array<complex<double> > &dwf_Rc_m_tab_uniform = u_Rc_m.get_dwf_bef_R_tab_uniform ();
    
    const class array<complex<double> > &d2wf_Rc_p_tab_uniform = u_Rc_p.get_d2wf_bef_R_tab_uniform ();
    const class array<complex<double> > &d2wf_Rc_m_tab_uniform = u_Rc_m.get_d2wf_bef_R_tab_uniform ();
    
    const double two_precision_der = 2.0*precision_der;
    
    double test_wfs_partial_der_uniform = 0.0;

    for (unsigned int i = 0 ; i < N_uniform ; i++)
      {
	test_wfs_partial_der_uniform += inf_norm (wf_der_tab_uniform(0 , i)   - (wf_d_p_tab_uniform(i)   -   wf_d_m_tab_uniform(i))/d/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (dwf_der_tab_uniform(0 , i)  - (dwf_d_p_tab_uniform(i)  -  dwf_d_m_tab_uniform(i))/d/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (d2wf_der_tab_uniform(0 , i) - (d2wf_d_p_tab_uniform(i) - d2wf_d_m_tab_uniform(i))/d/two_precision_der);

	test_wfs_partial_der_uniform += inf_norm (wf_der_tab_uniform(1 , i)   - (wf_R0_p_tab_uniform(i)   -   wf_R0_m_tab_uniform(i))/R0/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (dwf_der_tab_uniform(1 , i)  - (dwf_R0_p_tab_uniform(i)  -  dwf_R0_m_tab_uniform(i))/R0/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (d2wf_der_tab_uniform(1 , i) - (d2wf_R0_p_tab_uniform(i) - d2wf_R0_m_tab_uniform(i))/R0/two_precision_der);

	test_wfs_partial_der_uniform += inf_norm (wf_der_tab_uniform(2 , i)   - (wf_Vo_p_tab_uniform(i)   -   wf_Vo_m_tab_uniform(i))/Vo/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (dwf_der_tab_uniform(2 , i)  - (dwf_Vo_p_tab_uniform(i)  -  dwf_Vo_m_tab_uniform(i))/Vo/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (d2wf_der_tab_uniform(2 , i) - (d2wf_Vo_p_tab_uniform(i) - d2wf_Vo_m_tab_uniform(i))/Vo/two_precision_der);

	test_wfs_partial_der_uniform += inf_norm (wf_der_tab_uniform(3 , i)   - (wf_Vso_p_tab_uniform(i)   -   wf_Vso_m_tab_uniform(i))/Vso/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (dwf_der_tab_uniform(3 , i)  - (dwf_Vso_p_tab_uniform(i)  -  dwf_Vso_m_tab_uniform(i))/Vso/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (d2wf_der_tab_uniform(3 , i) - (d2wf_Vso_p_tab_uniform(i) - d2wf_Vso_m_tab_uniform(i))/Vso/two_precision_der);

	test_wfs_partial_der_uniform += inf_norm (wf_der_tab_uniform(4 , i)   - (wf_Rc_p_tab_uniform(i)   -   wf_Rc_m_tab_uniform(i))/Rc/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (dwf_der_tab_uniform(4 , i)  - (dwf_Rc_p_tab_uniform(i)  -  dwf_Rc_m_tab_uniform(i))/Rc/two_precision_der);
	test_wfs_partial_der_uniform += inf_norm (d2wf_der_tab_uniform(4 , i) - (d2wf_Rc_p_tab_uniform(i) - d2wf_Rc_m_tab_uniform(i))/Rc/two_precision_der);
      }

    test_wfs_partial_der_uniform /= 15.0*N_uniform;

    const class array<complex<double> > &wf_der_tab_GL = u_partial_derivative.get_wf_bef_R_der_tab_GL ();
    
    const class array<complex<double> > &dwf_der_tab_GL = u_partial_derivative.get_dwf_bef_R_der_tab_GL ();

    const class array<complex<double> > &d2wf_der_tab_GL = u_partial_derivative.get_d2wf_bef_R_der_tab_GL ();
    
    const class array<complex<double> > &wf_d_p_tab_GL = u_d_p.get_wf_bef_R_tab_GL ();
    const class array<complex<double> > &wf_d_m_tab_GL = u_d_m.get_wf_bef_R_tab_GL ();

    const class array<complex<double> > &dwf_d_p_tab_GL = u_d_p.get_dwf_bef_R_tab_GL ();
    const class array<complex<double> > &dwf_d_m_tab_GL = u_d_m.get_dwf_bef_R_tab_GL ();
    
    const class array<complex<double> > &d2wf_d_p_tab_GL = u_d_p.get_d2wf_bef_R_tab_GL ();
    const class array<complex<double> > &d2wf_d_m_tab_GL = u_d_m.get_d2wf_bef_R_tab_GL ();
    
    const class array<complex<double> > &wf_R0_p_tab_GL = u_R0_p.get_wf_bef_R_tab_GL ();
    const class array<complex<double> > &wf_R0_m_tab_GL = u_R0_m.get_wf_bef_R_tab_GL ();

    const class array<complex<double> > &dwf_R0_p_tab_GL = u_R0_p.get_dwf_bef_R_tab_GL ();
    const class array<complex<double> > &dwf_R0_m_tab_GL = u_R0_m.get_dwf_bef_R_tab_GL ();
    
    const class array<complex<double> > &d2wf_R0_p_tab_GL = u_R0_p.get_d2wf_bef_R_tab_GL ();
    const class array<complex<double> > &d2wf_R0_m_tab_GL = u_R0_m.get_d2wf_bef_R_tab_GL ();
    
    const class array<complex<double> > &wf_Vo_p_tab_GL = u_Vo_p.get_wf_bef_R_tab_GL ();
    const class array<complex<double> > &wf_Vo_m_tab_GL = u_Vo_m.get_wf_bef_R_tab_GL ();

    const class array<complex<double> > &dwf_Vo_p_tab_GL = u_Vo_p.get_dwf_bef_R_tab_GL ();
    const class array<complex<double> > &dwf_Vo_m_tab_GL = u_Vo_m.get_dwf_bef_R_tab_GL ();
    
    const class array<complex<double> > &d2wf_Vo_p_tab_GL = u_Vo_p.get_d2wf_bef_R_tab_GL ();
    const class array<complex<double> > &d2wf_Vo_m_tab_GL = u_Vo_m.get_d2wf_bef_R_tab_GL ();
    
    const class array<complex<double> > &wf_Vso_p_tab_GL = u_Vso_p.get_wf_bef_R_tab_GL ();
    const class array<complex<double> > &wf_Vso_m_tab_GL = u_Vso_m.get_wf_bef_R_tab_GL ();

    const class array<complex<double> > &dwf_Vso_p_tab_GL = u_Vso_p.get_dwf_bef_R_tab_GL ();
    const class array<complex<double> > &dwf_Vso_m_tab_GL = u_Vso_m.get_dwf_bef_R_tab_GL ();
    
    const class array<complex<double> > &d2wf_Vso_p_tab_GL = u_Vso_p.get_d2wf_bef_R_tab_GL ();
    const class array<complex<double> > &d2wf_Vso_m_tab_GL = u_Vso_m.get_d2wf_bef_R_tab_GL ();
    
    const class array<complex<double> > &wf_Rc_p_tab_GL = u_Rc_p.get_wf_bef_R_tab_GL ();
    const class array<complex<double> > &wf_Rc_m_tab_GL = u_Rc_m.get_wf_bef_R_tab_GL ();

    const class array<complex<double> > &dwf_Rc_p_tab_GL = u_Rc_p.get_dwf_bef_R_tab_GL ();
    const class array<complex<double> > &dwf_Rc_m_tab_GL = u_Rc_m.get_dwf_bef_R_tab_GL ();
    
    const class array<complex<double> > &d2wf_Rc_p_tab_GL = u_Rc_p.get_d2wf_bef_R_tab_GL ();
    const class array<complex<double> > &d2wf_Rc_m_tab_GL = u_Rc_m.get_d2wf_bef_R_tab_GL ();

    double test_wfs_partial_der_GL = 0.0;

    for (unsigned int i = 0 ; i < N_GL ; i++)
      {
	test_wfs_partial_der_GL += inf_norm (wf_der_tab_GL(0 , i)   - (wf_d_p_tab_GL(i)   -   wf_d_m_tab_GL(i))/d/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (dwf_der_tab_GL(0 , i)  - (dwf_d_p_tab_GL(i)  -  dwf_d_m_tab_GL(i))/d/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (d2wf_der_tab_GL(0 , i) - (d2wf_d_p_tab_GL(i) - d2wf_d_m_tab_GL(i))/d/two_precision_der);

	test_wfs_partial_der_GL += inf_norm (wf_der_tab_GL(1 , i)   - (wf_R0_p_tab_GL(i)   -   wf_R0_m_tab_GL(i))/R0/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (dwf_der_tab_GL(1 , i)  - (dwf_R0_p_tab_GL(i)  -  dwf_R0_m_tab_GL(i))/R0/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (d2wf_der_tab_GL(1 , i) - (d2wf_R0_p_tab_GL(i) - d2wf_R0_m_tab_GL(i))/R0/two_precision_der);

	test_wfs_partial_der_GL += inf_norm (wf_der_tab_GL(2 , i)   - (wf_Vo_p_tab_GL(i)   -   wf_Vo_m_tab_GL(i))/Vo/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (dwf_der_tab_GL(2 , i)  - (dwf_Vo_p_tab_GL(i)  -  dwf_Vo_m_tab_GL(i))/Vo/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (d2wf_der_tab_GL(2 , i) - (d2wf_Vo_p_tab_GL(i) - d2wf_Vo_m_tab_GL(i))/Vo/two_precision_der);

	test_wfs_partial_der_GL += inf_norm (wf_der_tab_GL(3 , i)   - (wf_Vso_p_tab_GL(i)   -   wf_Vso_m_tab_GL(i))/Vso/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (dwf_der_tab_GL(3 , i)  - (dwf_Vso_p_tab_GL(i)  -  dwf_Vso_m_tab_GL(i))/Vso/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (d2wf_der_tab_GL(3 , i) - (d2wf_Vso_p_tab_GL(i) - d2wf_Vso_m_tab_GL(i))/Vso/two_precision_der);

	test_wfs_partial_der_GL += inf_norm (wf_der_tab_GL(4 , i)   - (wf_Rc_p_tab_GL(i)   -   wf_Rc_m_tab_GL(i))/Rc/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (dwf_der_tab_GL(4 , i)  - (dwf_Rc_p_tab_GL(i)  -  dwf_Rc_m_tab_GL(i))/Rc/two_precision_der);
	test_wfs_partial_der_GL += inf_norm (d2wf_der_tab_GL(4 , i) - (d2wf_Rc_p_tab_GL(i) - d2wf_Rc_m_tab_GL(i))/Rc/two_precision_der);
      }

    test_wfs_partial_der_GL /= 15.0*N_GL;

    const double test_wfs_partial_der = 0.5*(test_wfs_partial_der_uniform + test_wfs_partial_der_GL);

    if (THIS_PROCESS == MASTER_PROCESS) cout << "Wave functions partial derivatives precision : " << test_wfs_partial_der << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

