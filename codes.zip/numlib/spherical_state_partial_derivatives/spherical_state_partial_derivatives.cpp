#include "../numlib_def/numlib_def.h"

using namespace string_routines;



// du/dx(r) is the derivative of u(r) with respect to x=(d , R0, Vo , Vso, R_charge), renormalized so that u(r) ~ C0(init).r^(l+1) for all x, C0(init) being the constant provided by the initial WS potential.



// Standard copy constructor  
// ------------------------

spherical_state_partial_derivatives::spherical_state_partial_derivatives () :
  N_parameters_to_fit (0) ,
  n (0) ,
  l (0) ,
  j (0.0) , 
  particle (NO_PARTICLE) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  R0 (0.0) ,
  step_bef_R_uniform (0.0) ,
  N_bef_R_GL (0) ,
  N_bef_R_uniform (0) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  C0 (0.0)
{}
  
spherical_state_partial_derivatives::spherical_state_partial_derivatives (
									  const class WS_analytic_class &WS_potential_c , 
									  const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
									  const class spherical_state &s) :
  N_parameters_to_fit (0) ,
  n (0) ,
  l (0) ,
  j (0.0) , 
  particle (NO_PARTICLE) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  R0 (0.0) ,
  step_bef_R_uniform (0.0) ,
  N_bef_R_GL (0) ,
  N_bef_R_uniform (0) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  C0 (0.0)
{
  allocate (WS_potential_c , WS_parameters_from_fit_index , s);
}

// Standard copy constructor  
// ------------------------

spherical_state_partial_derivatives::spherical_state_partial_derivatives (const class spherical_state_partial_derivatives &X) :
  N_parameters_to_fit (0) ,
  n (0) ,
  l (0) ,
  j (0.0) , 
  particle (NO_PARTICLE) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  R0 (0.0) ,
  step_bef_R_uniform (0.0) ,
  N_bef_R_GL (0) ,
  N_bef_R_uniform (0) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  C0 (0.0)
{
  allocate_fill (X);
}


// Destructor for compiler  
// ------------------------

spherical_state_partial_derivatives::~spherical_state_partial_derivatives () {}

// Constants definition and tables allocation/allocation copy/deallocation
// -----------------------------------------------------------------------

void spherical_state_partial_derivatives::allocate (
						    const class WS_analytic_class &WS_potential_c , 
						    const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
						    const class spherical_state &s)
{
  if (is_it_filled ()) error_message_print_abort ("spherical_state_partial_derivatives cannot be allocated twice in spherical_state_partial_derivatives::allocate");

  N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0); 
  n = s.get_n (); 
  l = s.get_l (); 
  j = s.get_j (); 
  particle = s.get_particle (); 
  A = s.get_A (); 
  Z_charge = s.get_Z_charge (); 
  R = s.get_R (); 
  R0 = s.get_R0 (); 
  step_bef_R_uniform = s.get_step_bef_R_uniform (); 
  N_bef_R_GL = s.get_N_bef_R_GL (); 
  N_bef_R_uniform = s.get_N_bef_R_uniform (); 
  kinetic_factor = s.get_kinetic_factor (); 
  k = s.get_k (); 
  eta = s.get_eta (); 
  C0 = s.get_C0 ();
  WS_potential.initialize (WS_potential_c);

  if (s.get_S_matrix_pole ()) error_message_print_abort ("Class spherical_state_partial_derivatives only for scattering states.");
  if (s.get_potential () != WS_ANALYTIC) error_message_print_abort ("Class spherical_state_partial_derivatives only with WS analytic potential.");

  r_bef_R_tab_uniform.allocate_fill (s.get_r_bef_R_tab_uniform ());

  r_bef_R_tab_GL.allocate_fill (s.get_r_bef_R_tab_GL ());
  w_bef_R_tab_GL.allocate_fill (s.get_w_bef_R_tab_GL ());

  Cplus_der_tab.allocate (N_parameters_to_fit);
  Cminus_der_tab.allocate (N_parameters_to_fit);
  CF_der_tab.allocate (N_parameters_to_fit);
  CG_der_tab.allocate (N_parameters_to_fit);

  Cplus_der_tab = INFINITE;
  Cminus_der_tab = INFINITE;
  CF_der_tab = INFINITE;
  CG_der_tab = INFINITE;

  wf_bef_R_der_tab_uniform.allocate (N_parameters_to_fit , N_bef_R_uniform);
  dwf_bef_R_der_tab_uniform.allocate (N_parameters_to_fit , N_bef_R_uniform);
  d2wf_bef_R_der_tab_uniform.allocate (N_parameters_to_fit , N_bef_R_uniform);

  wf_bef_R_der_tab_uniform = INFINITE;
  dwf_bef_R_der_tab_uniform = INFINITE;
  d2wf_bef_R_der_tab_uniform = INFINITE;

  wf_bef_R_der_tab_GL.allocate (N_parameters_to_fit , N_bef_R_GL);
  dwf_bef_R_der_tab_GL.allocate (N_parameters_to_fit , N_bef_R_GL);
  d2wf_bef_R_der_tab_GL.allocate (N_parameters_to_fit , N_bef_R_GL);

  wf_bef_R_der_tab_GL = INFINITE;
  dwf_bef_R_der_tab_GL = INFINITE;
  d2wf_bef_R_der_tab_GL = INFINITE;

  WS_partial_der_r0_tab.allocate (N_parameters_to_fit);
	
  WS_partial_der_r0_tab = 0.0;

  wf_der_tab.allocate (N_parameters_to_fit);
  dwf_der_tab.allocate (N_parameters_to_fit);
  source_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  wf_der_tab = INFINITE;
  dwf_der_tab = INFINITE;
  source_bef_R_tab_uniform = INFINITE;

  source_der_tab_uniform.allocate (N_parameters_to_fit , N_bef_R_uniform);

  source_der_tab_uniform = 0.0;

  const double r0 = 0.005*sqrt (l*(l+1.0));

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);

      WS_partial_der_r0_tab(fit_index) = WS_potential.derivative_calc (WS_parameter , r0);
    }

  const class array<complex<double> > &wf_bef_R_tab_uniform = s.get_wf_bef_R_tab_uniform ();

  for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);
      
      const complex<double> &wf_r = wf_bef_R_tab_uniform(i);

      for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	{
	  const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);

	  source_der_tab_uniform(fit_index , i) = WS_potential.derivative_calc (WS_parameter , r)*wf_r;
	}
    }
}







void spherical_state_partial_derivatives::allocate_fill (const class spherical_state_partial_derivatives &X)
{
  if (is_it_filled ()) error_message_print_abort ("spherical_state_partial_derivatives cannot be allocated twice in spherical_state_partial_derivatives::allocate_fill");

  N_parameters_to_fit = X.N_parameters_to_fit; 
  n = X.n; 
  l = X.l; 
  j = X.j; 
  particle = X.particle; 
  A = X.A; 
  Z_charge = X.Z_charge; 
  R = X.R; 
  R0 = X.R0; 
  step_bef_R_uniform = X.step_bef_R_uniform; 
  N_bef_R_GL = X.N_bef_R_GL; 
  N_bef_R_uniform = X.N_bef_R_uniform; 
  kinetic_factor = X.kinetic_factor; 
  k = X.k; 
  eta = X.eta; 
  C0 = X.C0;
  WS_potential.initialize (X.WS_potential);
  
  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  Cplus_der_tab.allocate_fill (X.Cplus_der_tab);
  Cminus_der_tab.allocate_fill (X.Cminus_der_tab);
  CF_der_tab.allocate_fill (X.CF_der_tab);
  CG_der_tab.allocate_fill (X.CG_der_tab);

  wf_bef_R_der_tab_uniform.allocate_fill (X.wf_bef_R_der_tab_uniform);
  dwf_bef_R_der_tab_uniform.allocate_fill (X.dwf_bef_R_der_tab_uniform);
  d2wf_bef_R_der_tab_uniform.allocate_fill (X.d2wf_bef_R_der_tab_uniform);

  wf_bef_R_der_tab_GL.allocate_fill (X.wf_bef_R_der_tab_GL);
  dwf_bef_R_der_tab_GL.allocate_fill (X.dwf_bef_R_der_tab_GL);
  d2wf_bef_R_der_tab_GL.allocate_fill (X.d2wf_bef_R_der_tab_GL);

  WS_partial_der_r0_tab.allocate_fill (X.WS_partial_der_r0_tab);

  wf_der_tab.allocate_fill (X.wf_der_tab);
  dwf_der_tab.allocate_fill (X.dwf_der_tab);
  source_bef_R_tab_uniform.allocate_fill (X.source_bef_R_tab_uniform);

  source_der_tab_uniform.allocate_fill (X.source_der_tab_uniform);
}



void spherical_state_partial_derivatives::deallocate ()
{
  r_bef_R_tab_uniform.deallocate ();

  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();

  Cplus_der_tab.deallocate ();
  Cminus_der_tab.deallocate ();
  CF_der_tab.deallocate ();
  CG_der_tab.deallocate ();

  wf_bef_R_der_tab_uniform.deallocate ();
  dwf_bef_R_der_tab_uniform.deallocate ();
  d2wf_bef_R_der_tab_uniform.deallocate ();

  wf_bef_R_der_tab_GL.deallocate ();
  dwf_bef_R_der_tab_GL.deallocate ();
  d2wf_bef_R_der_tab_GL.deallocate ();

  WS_partial_der_r0_tab.deallocate ();

  wf_der_tab.deallocate ();
  dwf_der_tab.deallocate ();
  source_bef_R_tab_uniform.deallocate ();

  source_der_tab_uniform.deallocate ();

  N_parameters_to_fit = 0;
  n = 0;
  l = 0;
  j = 0.0; 
  particle = NO_PARTICLE;
  A = 0;
  Z_charge = 0;
  R = 0.0;
  R0 = 0.0;
  step_bef_R_uniform = 0.0;
  N_bef_R_GL = 0;
  N_bef_R_uniform = 0;
  kinetic_factor = 0.0;
  k = 0.0;
  eta = 0.0;
  C0 = 0.0;
}




// Boundary conditions of wave function partial derivatives for r~0
// ----------------------------------------------------------------
// Approximating the Schrodinger equation of the du/dx partial derivative by du''/dx(r) = l(l + 1)/r^2 du/dx(r) + C0.kinetic_factor.r^(l + 1).dWS/dx(r0) for r ~ 0,
// one obtains du/dx(r) ~ A r^(l + 1) + B.r^(l + 3) for r ~ 0. As u(r) ~ C0(init).r^(l + 1) for r ~ 0 and C0(init) does not depend on x, A = 0.
// Thus, du/dx(r) ~ [C0.kinetic_factor/(4l + 6)].dWS/dx(r0).r^(l + 3).
// This value is used for r <= r0 as well as its derivative.
// r0 is used instead of 0 to avoid infinities, which arise due to the spin-orbit potential. 
//
// Variables:
// ----------
// l_plus_two , l_plus_three: l + 2 , l + 3
// WS_der_tab_zero: table containing previous partial derivatives.
// C0_kinetic_factor_l_term : C0.kinetic_factor/(4.l + 6)
// C0_kinetic_factor_r_pow_term , C0_kinetic_factor_r_pow_term_der_r : C0.kinetic_factor.r^(l + 3)/(4.l + 6) , C0.kinetic_factor.(l + 3).r^(l + 2)/(4.l + 6) , 
// wf_der_tab_zero: table containing the wave function partial derivatives in r

void spherical_state_partial_derivatives::values_close_to_zero_calc (const double r) const
{
  const double l_plus_two = l + 2.0 , l_plus_three = l + 3.0;
  
  const complex<double> C0_kinetic_factor_l_term = C0*kinetic_factor/(4.0*l + 6.0);
  const complex<double> C0_kinetic_factor_r_pow_term = C0_kinetic_factor_l_term*pow (r , l_plus_three);
  const complex<double> C0_kinetic_factor_r_pow_term_der_r = C0_kinetic_factor_l_term*l_plus_three*pow (r , l_plus_two);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++) 
    {
      const double WS_partial_der_r0 = WS_partial_der_r0_tab(fit_index);

      wf_der_tab(fit_index)  = C0_kinetic_factor_r_pow_term*WS_partial_der_r0;
      dwf_der_tab(fit_index) = C0_kinetic_factor_r_pow_term_der_r*WS_partial_der_r0;
    }
}




// Calculation of the part of the wave function partial derivatives for E complex between 0 and R.
//------------------------------------------------------------------------------------------------
// One integrates the derivative of the Schrodinger equation with respct to each WS parameter from r0 to R:
// du''/dx(r) = [l(l+1)/r^2 + v(r) - k^2] du/dx(r) + dv/dx(r).u(r), where v(r) = V(r).kinetic_factor and x is the WS parameter d, Vo, Vso, R0, R_charge
// One approximates V(r) by V(r0) for r <= r0 so that du/dx(r) = C0.kinetic_factor.dWS/dx(r0).r^(l+3)/(4l + 6) (see above).
// The wave function and derivative at the Gaussian points are also calculated by direct integration. 
//
// Variables:
// ----------
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// r0 : r0 = 0.005.sqrt (l*(l+1.0))
// r_GL : r of Gauss-Legendre table
// r_previous : the radius just before r in the grid , so one integrates from r_previous to r to gain speed and stability.
// iGL : index of the Gaussian points.

void spherical_state_partial_derivatives::forward_integration_before_R ()
{
  const double r0 = 0.005*sqrt (l*(l+1.0));

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);

      if (r <= r0)
	{
	  values_close_to_zero_calc (r);

	  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++) 
	    {
	      wf_bef_R_der_tab_uniform(fit_index , i) = wf_der_tab(fit_index);
	      dwf_bef_R_der_tab_uniform(fit_index , i) = dwf_der_tab(fit_index);
	    }
	}
    }

  unsigned int iGL_close_to_zero = 0;

  while (r_bef_R_tab_GL(iGL_close_to_zero) <= r0)
    {
      const double r_GL = r_bef_R_tab_GL(iGL_close_to_zero);
      
      values_close_to_zero_calc (r_GL);

      for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	{ 
	  wf_bef_R_der_tab_GL(fit_index , iGL_close_to_zero) = wf_der_tab(fit_index);
	  dwf_bef_R_der_tab_GL(fit_index , iGL_close_to_zero) = dwf_der_tab(fit_index);
	}

      iGL_close_to_zero++;
    }

  values_close_to_zero_calc (r0);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++) 
    {
      const complex<double> u0_partial_der = wf_der_tab(fit_index) , du0_partial_der = dwf_der_tab(fit_index);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_bef_R_tab_uniform(i) = source_der_tab_uniform(fit_index , i);

      class potentials_effective_mass T;
      T.initialize_constants (WS_ANALYTIC_PARTIAL_DERIVATIVE , kinetic_factor , NADA , l , Z_charge , j , k , eta , NADA);

      class WS_analytic_class &T_WS_analytic_potential = T.get_WS_analytic_potential ();
      class splines_class<complex<double> > &T_source = T.get_source ();
      
      T_WS_analytic_potential.initialize (WS_potential);
      T_source.allocate_calc (r_bef_R_tab_uniform , source_bef_R_tab_uniform , 0.0 , 0.0);

      const class ODE_integration ODE_partial_der(&T , &potentials_effective_mass_F_z_u); 

      unsigned int iGL = iGL_close_to_zero;

      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	{
	  const double r_previous = r_bef_R_tab_uniform(i-1) , r = r_bef_R_tab_uniform(i);

	  if (r > r0)
	    {
	      (r_previous < r0)
		? (ODE_partial_der (r0 , u0_partial_der , du0_partial_der , r , wf_bef_R_der_tab_uniform(fit_index , i) , dwf_bef_R_der_tab_uniform(fit_index , i)))	
		: (ODE_partial_der (r_previous , wf_bef_R_der_tab_uniform(fit_index , i-1) , dwf_bef_R_der_tab_uniform(fit_index , i-1) , r , wf_bef_R_der_tab_uniform(fit_index , i) , dwf_bef_R_der_tab_uniform(fit_index , i)));

	      while ((iGL < N_bef_R_GL) && (r_bef_R_tab_GL(iGL) >= r_previous) && (r_bef_R_tab_GL(iGL) <= r))
		{
		  const double r_GL = r_bef_R_tab_GL(iGL);

		  (r_previous < r0) 
		    ? (ODE_partial_der (r0 , u0_partial_der , du0_partial_der , r_GL , wf_bef_R_der_tab_GL(fit_index , iGL) , dwf_bef_R_der_tab_GL(fit_index , iGL)))	
		    : (ODE_partial_der (r_previous , wf_bef_R_der_tab_uniform(fit_index , i-1) , dwf_bef_R_der_tab_uniform(fit_index , i-1) , r_GL , wf_bef_R_der_tab_GL(fit_index , iGL) , dwf_bef_R_der_tab_GL(fit_index , iGL)));	
		  iGL++;
		} 
	    }
	}
    }
}






// Calculation of dC+/dx , dC/dx- , dCF/dx , dCG/dx and du/dx(R) , du'/dx(R) 
// -------------------------------------------------------------------------
// du/dx[z] = dC+/dx.H+[kz] + dC-/dx.H-[kz] = dCF/dx.F[kz] + dCG/dx.G[kz] ,
// with z=R+(r-R).exp_Itheta in [R:+oo[ and x is the WS parameter d, Vo, Vso, R0, R_charge.
//
// Scattering state :
//-------------------
// To calculate the constants , one uses : 
// _du[R]/dx = wf_bef_R_der_tab_uniform(fit_index)[N];
// _du'[R]/dx = dwf_bef_R_der_tab_uniform(fit_index)[N]. 
// As one knows that du[z]/dx = dCF/dx.F[kz] + dCG/dx.G[kz] , knowing du/dx , F , G and their derivatives in R , 
// one has to solve a linear system to have dCF/dx and dCG/dx.
// Then , dC+/dx = [dCG/dx - i dCF/dx]/2 and dC-/dx = [dCG/dx + i.dCF/dx]/2 , using the fact that H+ , H- , G are normalized properly (see H+_H-.c++).
//
// Variables:
// ----------
// N_bef_R_uniform_m1 : Nbef_R_tab_uniform - 1
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// cwf : class Coulomb_wave_functions to calculate the Coulomb wave functions in R.
// F , dF , G , dG : Coulomb wave functions (and derivative) regular and irregular in R.
// Det : determinant of the linear system to solve to know CF and CG.

void spherical_state_partial_derivatives::Cplus_Cminus_CF_CG_der_tab_calc ()
{
  class Coulomb_wave_functions cwf(true , l , eta);

  complex<double> F , dF , G , dG;
  cwf.F_kz_dF_kz (k , R , F , dF);
  cwf.G_kz_dG_kz (k , R , G , dG);

  const unsigned int N_bef_R_uniform_m1 = N_bef_R_uniform - 1;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const complex<double>  u_partial_der_R =  wf_bef_R_der_tab_uniform(fit_index , N_bef_R_uniform_m1);
      const complex<double> du_partial_der_R = dwf_bef_R_der_tab_uniform(fit_index , N_bef_R_uniform_m1);

      const complex<double> Det = dF*G - F*dG;

      CF_der_tab(fit_index) =  (du_partial_der_R*G - u_partial_der_R*dG)/Det;
      CG_der_tab(fit_index) = -(du_partial_der_R*F - u_partial_der_R*dF)/Det;

      const complex<double> CF_partial_der = CF_der_tab(fit_index);
      const complex<double> CG_partial_der = CG_der_tab(fit_index);

      const complex<double> I_CF_partial_der(-imag (CF_partial_der) , real (CF_partial_der));

      Cplus_der_tab(fit_index)  = 0.5*(CG_partial_der - I_CF_partial_der);
      Cminus_der_tab(fit_index) = 0.5*(CG_partial_der + I_CF_partial_der);
    }
}



// Calculation of the second derivative of the wave function on [0:R].
// -------------------------------------------------------------------
// du''/dx is calculated with the Schroedinger equation differentiated with respect to x for r > 0
// and du''/dx(0) = 0 as C0 is that of the u(r) function and hence is independent of x.
//
// Variables:
// ----------
// llp1 : l(l+1)
// E : energy of the state.
// r_bef_R_tab_uniform : tables of radii : r = i.step_bef_R_uniform on [0:R].
// full_effective_mass : interpolated table giving the effective mass on [0:R] in MeV^(-1) fm^{-2}.
// source_bef_R_tab_uniform : source in the Schrodinger equation differentiated with respect to x, equal to dV(r)/dx.u(r), for r = i.step_bef_R_uniform on [0:R].
// source_splines; splines of source_bef_R_tab_uniform

void spherical_state_partial_derivatives::d2wf_partial_derivatives_calc_before_R ()
{
  const double llp1 = l*(l+1);
  const complex<double> E = k*k/kinetic_factor;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++) 
    { 
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) source_bef_R_tab_uniform(i) = source_der_tab_uniform(fit_index , i);

      const class splines_class<complex<double> > source_splines(r_bef_R_tab_uniform , source_bef_R_tab_uniform , 0.0 , 0.0);

      d2wf_bef_R_der_tab_uniform(fit_index , 0) = 0.0;

      for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = r_bef_R_tab_uniform(i);
	  d2wf_bef_R_der_tab_uniform(fit_index , i) = (llp1/(r*r) + kinetic_factor*(WS_potential(r) - E))*wf_bef_R_der_tab_uniform(fit_index , i) + kinetic_factor*source_splines(r);
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  d2wf_bef_R_der_tab_GL(fit_index , i) = (llp1/(r*r) + kinetic_factor*(WS_potential(r) - E))*wf_bef_R_der_tab_GL(fit_index , i) + kinetic_factor*source_splines(r);
	}
    }
}



// Calculation of the derivatives of the wave function du/dx(r) with respect to x = d, Vo, Vso, R0, R_charge
// ---------------------------------------------------------------------------------------------------------

void spherical_state_partial_derivatives::wave_partial_derivatives_calculation ()
{
  forward_integration_before_R ();

  Cplus_Cminus_CF_CG_der_tab_calc ();

  if (imag (k) == 0.0)
    {
      for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	{
	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
	    wf_bef_R_der_tab_uniform(fit_index , i) = real (wf_bef_R_der_tab_uniform(fit_index , i)) , dwf_bef_R_der_tab_uniform(fit_index , i) = real (dwf_bef_R_der_tab_uniform(fit_index , i));

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	    wf_bef_R_der_tab_GL(fit_index , i) = real (wf_bef_R_der_tab_GL(fit_index , i)) , dwf_bef_R_der_tab_GL(fit_index , i) = real (dwf_bef_R_der_tab_GL(fit_index , i));
	}
    }

  d2wf_partial_derivatives_calc_before_R ();
}





// Copy the derivatives of the wave function du/dx(r) with respect to x = d, Vo, Vso, R0, R_charge to a file
// ---------------------------------------------------------------------------------------------------------
// 
void spherical_state_partial_derivatives::copy_to_file_for_figure (const string debut_file_name , const bool is_it_Gauss_Legendre) const
{
  string file_name = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + make_string<int> (make_int(2.0*j)) + "_partial_derivatives_";

  if (is_it_Gauss_Legendre)
    file_name += "Gauss_Legendre.dat";
  else
    file_name += "uniform_grid.dat";

  ofstream out_file(file_name.c_str ());
  out_file.precision (15);

  if (is_it_Gauss_Legendre)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  out_file << r_bef_R_tab_GL(i) << " ";

	  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	    { 
	      out_file << real (wf_bef_R_der_tab_GL(fit_index , i)) << " " << imag (wf_bef_R_der_tab_GL(fit_index , i)) << " "
		       << real (dwf_bef_R_der_tab_GL(fit_index , i)) << " " << imag (dwf_bef_R_der_tab_GL(fit_index , i)) << " "
		       << real (d2wf_bef_R_der_tab_GL(fit_index , i)) << " " << imag (d2wf_bef_R_der_tab_GL(fit_index , i)) << " ";
	    }

	  out_file << endl;
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  out_file << r_bef_R_tab_uniform(i) << " ";

	  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	    { 
	      out_file << real (wf_bef_R_der_tab_uniform(fit_index , i)) << " " << imag (wf_bef_R_der_tab_uniform(fit_index , i)) << " "
		       << real (dwf_bef_R_der_tab_uniform(fit_index , i)) << " " << imag (dwf_bef_R_der_tab_uniform(fit_index , i)) << " "
		       << real (d2wf_bef_R_der_tab_uniform(fit_index , i)) << " " << imag (d2wf_bef_R_der_tab_uniform(fit_index , i)) << " ";
	    }

	  out_file << endl;
	}
    }
}




