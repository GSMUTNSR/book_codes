#ifndef SPHERICAL_STATE_PARTIAL_DERIVATIVES_H
#define SPHERICAL_STATE_PARTIAL_DERIVATIVES_H


// Class containing all information about a spherical one body state partial derivative
// -----------------------------------------------------------------------------------
// The parameter d,  R0,  Vo, Vso or R_charge is denoted by x.


class spherical_state_partial_derivatives
{
public:

  // Default constructor
  // -------------------

  spherical_state_partial_derivatives ();

  // Normal constructor,  where the tables have to be allocated and calculated.
  // --------------------------------------------------------------------------

  spherical_state_partial_derivatives (
				       const class WS_analytic_class &WS_potential_c , 
				       const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
				       const class spherical_state &s);

  // Copy constructor
  // ----------------

  spherical_state_partial_derivatives (const class spherical_state_partial_derivatives &X);

  // Destructor for compiler  
  // ------------------------

  ~spherical_state_partial_derivatives ();
  
  void allocate (
		 const class WS_analytic_class &WS_potential_c , 
		 const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
		 const class spherical_state &s);

  void allocate_fill (const class spherical_state_partial_derivatives &X);

  void deallocate ();
  
  unsigned int get_N_parameters_to_fit () const
  {
    return N_parameters_to_fit;
  }

  int get_n () const
  {
    return n;
  }

  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  int get_A () const
  {
    return A;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  double get_kinetic_factor () const
  {
    return kinetic_factor;
  }

  complex<double> get_k () const
  {
    return k;
  }

  complex<double> get_eta () const
  {
    return eta;
  }

  complex<double> get_C0 () const
  {
    return C0;
  }

  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_Cplus_der_tab () const
  {
    return Cplus_der_tab;
  }

  const class array<complex<double> > & get_Cminus_der_tab () const
  {
    return Cminus_der_tab;
  }

  const class array<complex<double> > & get_CF_der_tab () const
  {
    return CF_der_tab;
  }

  const class array<complex<double> > & get_CG_der_tab () const
  {
    return CG_der_tab;
  }
  
  const class array<complex<double> > & get_wf_bef_R_der_tab_GL () const
  {
    return wf_bef_R_der_tab_GL;
  }
  
  const class array<complex<double> > & get_dwf_bef_R_der_tab_GL () const
  {
    return dwf_bef_R_der_tab_GL;
  }
  
  const class array<complex<double> > & get_d2wf_bef_R_der_tab_GL () const
  {
    return d2wf_bef_R_der_tab_GL;
  }

  const class array<complex<double> > & get_wf_bef_R_der_tab_uniform () const
  {
    return wf_bef_R_der_tab_uniform;
  }
  
  const class array<complex<double> > & get_dwf_bef_R_der_tab_uniform () const
  {
    return dwf_bef_R_der_tab_uniform;
  }
  
  const class array<complex<double> > & get_d2wf_bef_R_der_tab_uniform () const
  {
    return d2wf_bef_R_der_tab_uniform;
  }

  const class WS_analytic_class & get_WS_potential () const
  {
    return WS_potential;
  }

  const class array<double> & get_WS_partial_der_r0_tab () const
  {
    return WS_partial_der_r0_tab;
  }

  const class array<complex<double> > & get_source_der_tab_uniform () const
  {
    return source_der_tab_uniform;
  }

  const class array<complex<double> > & get_wf_der_tab () const
  {
    return wf_der_tab;
  }

  const class array<complex<double> > & get_dwf_der_tab () const
  {
    return dwf_der_tab;
  }

  const class array<complex<double> > & get_source_bef_R_tab_uniform () const
  {
    return source_bef_R_tab_uniform;
  }

  bool is_it_filled () const
  {
    return (N_bef_R_uniform > 0);
  }
  
  void wave_partial_derivatives_calculation ();  

  void copy_to_file_for_figure (const string debut_file_name , const bool is_it_Gauss_Legendre) const;
  
private:

  unsigned int N_parameters_to_fit;     // Number of WS parameters to fit

  int n , l;                            // radial and orbital quantum number
  double j;                             // total spin.
  enum particle_type particle;          // PROTON ,  NEUTRON or DIPROTON.
  int A , Z_charge;                     // nucleons number and charge.
  double R , R0;                        // R : rotation point
                                        // R0 of the WS potential for the SGI interaction.

  double step_bef_R_uniform;                // step_bef_R = R/(N_bef_R_uniform-1)

  unsigned int N_bef_R_GL;              // Number of Gaussian points of the wave function on [0:R]
  unsigned int N_bef_R_uniform;         // uniform number of points for direct integration

  double kinetic_factor;                // 2mu/hbar^2
  complex<double> k , eta;              // E = k^2/(2mu/hbar^2) and Sommerfeld parameter = (2mu/hbar^2)*Z*Coulomb_constant/2/k.

  complex<double> C0;                   // Coeffcient so that u(r) ~ C0.r^(l+1) for r~0

  class array<double> r_bef_R_tab_uniform;              // Uniformly distributed abscissas before R : r = i.step_bef_R_tab_uniform ,  i in [0:N_bef_R_tab_uniform-1]
  class array<double> r_bef_R_tab_GL , w_bef_R_tab_GL;  // Gaussian abscissas and weights before R : r in ]0:R[.

  // Tables refer to the WS potential partial derivatives with respect to d ,  R0 ,  Vo ,  Vso ,  R_charge respectively

  class array<complex<double> > Cplus_der_tab , Cminus_der_tab , CF_der_tab , CG_der_tab;  // Coefficients of H+ and H- when du(r)/dx = C+.H+(k.r) + C-.H-(k.r).
  // Coefficients of F and G when du(r)/dx = CF.F(k.r) + CG.G(k.r)

  class array<complex<double> > wf_bef_R_der_tab_GL;       // wave function on [0:R] with Gaussian points.
  class array<complex<double> > dwf_bef_R_der_tab_GL;      // wave function derivative on [0:R] with Gaussian points .
  class array<complex<double> > d2wf_bef_R_der_tab_GL;     // wave function second derivative on [0:R] with Gaussian points .

  class array<complex<double> > wf_bef_R_der_tab_uniform;      // wave function on [0:R] with with N_bef_R_tab_uniform points.
  class array<complex<double> > dwf_bef_R_der_tab_uniform;     // wave function derivative on [0:R] with with N_bef_R_tab_uniform points .
  class array<complex<double> > d2wf_bef_R_der_tab_uniform;    // wave function second derivative on [0:R] with with N_bef_R_tab_uniform points .

  class WS_analytic_class WS_potential;                    // WS_analytic_class potential pointer on WS potential parameters

  class array<double> WS_partial_der_r0_tab;               // WS derivatives close to zero
  class array<complex<double> > source_der_tab_uniform;    // Tables containing the source terms equal to -dWS/dx(r).u(r) with N_bef_R_tab_uniform points
  class array<complex<double> > wf_der_tab , dwf_der_tab;  // wave function work tables.
  class array<complex<double> > source_bef_R_tab_uniform;  // source work table.

  void values_close_to_zero_calc (const double r) const;

  void forward_integration_before_R ();
  void Cplus_Cminus_CF_CG_der_tab_calc ();
  void d2wf_partial_derivatives_calc_before_R ();
};




#endif
