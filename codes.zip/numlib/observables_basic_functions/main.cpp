#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const int Z_target = 5;
    
    const double p_mass = 1.09*proton_mass;
    
    const complex<double> z(1 , 2) , k(1.0 , -0.1);

    const int Z_OUT = 8 , N_OUT = 9;

    if (inf_norm (kinetic_factor_calc (false , 1.0 , p_mass) - two_amu_over_hbar_square/(1.0/p_mass + 1.0) ) > precision)
      error_message_print_abort ("Problem with kinetic_factor_calc");	

    if (inf_norm (kinetic_factor_calc (false , 0.0 , p_mass) - two_amu_over_hbar_square*p_mass) > precision)
      error_message_print_abort ("Problem with kinetic_factor_calc (no recoil)");

    if (inf_norm (eta_calc (false , PROTON , Z_target , two_amu_over_hbar_square , k) - particle_charge_determine (PROTON)*Z_target * Coulomb_constant * two_amu_over_hbar_square * 0.5/k) > precision)
      error_message_print_abort ("Problem with eta_calc (1)");
    
    if (inf_norm (eta_calc (true , DIPROTON , 1 , two_amu_over_hbar_square , k) - Coulomb_constant * two_amu_over_hbar_square * 0.5/k) > precision)
      error_message_print_abort ("Problem with eta_calc (2)");
    
    const complex<double> k0(1 , 1) , k1(1 , -1) , k2(-1 , -1) , k3(-1 , 1);

    if (optimal_angle_index (k0) != 0) error_message_print_abort ("Problem with optimal_angle_index"); 
    if (optimal_angle_index (k1) != 1) error_message_print_abort ("Problem with optimal_angle_index");
    if (optimal_angle_index (k2) != 2) error_message_print_abort ("Problem with optimal_angle_index"); 
    if (optimal_angle_index (k3) != 3) error_message_print_abort ("Problem with optimal_angle_index");

    cout << "Z_OUT : " << Z_OUT << " N_OUT : " << N_OUT << endl << endl;
        
    cout << endl;
    cout << "beta+ , Z_in : " << Z_IN_beta_determine (BETA_PLUS  , Z_OUT) << endl;
    cout << "beta- , Z_in : " << Z_IN_beta_determine (BETA_MINUS , Z_OUT) << endl;

    cout << endl;
    cout << "beta+ , N_in : " << N_IN_beta_determine (BETA_PLUS  , N_OUT) << endl;
    cout << "beta- , N_in : " << N_IN_beta_determine (BETA_MINUS , N_OUT) << endl;
	
    cout << endl;
    cout << "beta+ sign : " << beta_sign_determine (BETA_PLUS)  << endl;
    cout << "beta- sign : " << beta_sign_determine (BETA_MINUS) << endl;

    cout << endl;
    cout << "BP E1 : " << BP_EM_determine (ELECTRIC , 1) << endl;
    cout << "BP M1 : " << BP_EM_determine (MAGNETIC , 1) << endl;

    cout << endl;
    cout << "BP E2 : " << BP_EM_determine (ELECTRIC , 2) << endl;
    cout << "BP M2 : " << BP_EM_determine (MAGNETIC , 2) << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

