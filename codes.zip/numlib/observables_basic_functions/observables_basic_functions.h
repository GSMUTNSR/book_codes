#ifndef OBSERVABLESBASICFUNCTIONS_H 
#define OBSERVABLESBASICFUNCTIONS_H

// Binary parity (BP) is used all over the code.
// One has: BP = Pi%2 and Pi = (-1)^BP, so that Pi = (1,-1) <=> BP = (0,1).
// The interest of introducing binary parity is that BP can be used as array index.
// The "^" (XOR) operator is used as a multiplication.
// Indeed, one has : 0 ^ 0 = 0 , 1 ^ 1 = 0 , 0 ^ 1 = 1 and 1 ^ 0 = 1, so that multiplication with (-1,1) becomes XOR with (0,1)


// Opposite binary parity
// ----------------------
// It returns the binary parity of the initial parity multiplied by -1.
// Hence, it returns 1 if BP = 0 and 0 if BP = 1.

inline unsigned int opposite_binary_parity (const unsigned int BP)
{
  return (BP ^ 1);
}

// Binary parity from the product of two parities
// ----------------------------------------------
// The product of two parities is 1 if they are equal and -1 if they are different.
// Its binary parity comes forward from the XOR operator.

inline unsigned int binary_parity_product (const unsigned int BP1 , const unsigned int BP2)
{
  return (BP1 ^ BP2);
}

// Binary parity from orbital angular momentum
// -------------------------------------------
// The parity of a state build from several orbital angular momenta l1, ..., ln is (-1)^(l1 + ... + ln) .
// One denotes l as l1 + ... + ln.
// The remainder of division by 2 of l is 0 is it is even and 1 if it is odd.
// It is then the binary parity associated to l.

inline unsigned int binary_parity_from_orbital_angular_momentum (const int l)
{
  return (l%2);
}

// Parity from binary parity
// -------------------------
int parity_from_binary_parity (const unsigned int BP);

// Binary parity from parity
// -------------------------
unsigned int binary_parity_from_parity (const int Parity);

//                      ^
// Quick calculation of J = sqrt[2.J + 1].
// ---------------------------------------
double hat (const double j);


// Optimal angle search. 
// ---------------------
unsigned int optimal_angle_index (const complex<double> &k);


// Quantum numbers of projectile and target
// ----------------------------------------

// Number of protons , neutrons , nucleons and mass of projectile, projectile from its properties
int Z_projectile_determine (const enum particle_type particle);
int N_projectile_determine (const enum particle_type particle);
int A_projectile_determine (const enum particle_type particle);

double mass_projectile_determine (const enum particle_type particle , const double prot_mass_for_calc , const double neut_mass_for_calc);

//Returns true or false according to the S-matrix pole character of the cluster

bool S_matrix_pole_projectile_determine (const enum particle_type particle);

//Intrinsic total angular momentum, isospin, binary parity and vector index of projectile. Intrinsic spin for two-particle systems is also provided.

unsigned int BP_intrinsic_projectile_determine (const enum particle_type particle);

double J_intrinsic_projectile_determine (const enum particle_type particle);

unsigned int vector_index_intrinsic_projectile_determine (const enum particle_type particle);

int S_two_body_projectile_determine (const unsigned int BP , const int T);

double S_projectile_determine (const enum particle_type particle);
double T_projectile_determine (const enum particle_type particle);

double Jmax_intrinsic_projectile_determine ();

// Number of protons , neutrons , nucleons and mass of target
int Z_target_determine (const int Z , const enum particle_type particle);
int N_target_determine (const int N , const enum particle_type particle);

int A_target_determine (const int Z , const int N , const enum particle_type particle);

double mass_target_determine (const int Z , const int N , const enum particle_type particle , const double prot_mass_for_calc , const double neut_mass_for_calc);

// Check if a particle is inside a cluster
bool is_particle_in_cluster (const enum particle_type particle , const enum particle_type cluster);

// Determination of the charge of particle
int particle_charge_determine (const enum particle_type particle);

// Check if a cluster partial wave exists, i.e. if \vec{J_cluster} = \vec{LCM_cluster} + \vec{J_intrinsic_cluster}
bool is_partial_wave_angular_coupling_possible_determine (const enum particle_type particle , const int LCM , const double J);
  
// Calculation of kinetic_factor=2mu/hbar^2 , with mu the reduced mass. 
// --------------------------------------------------------------------
double kinetic_factor_calc (const bool is_it_electron , const double mass_modif , const double nucleon_mass_for_calc);

// Calculation of the Sommerfeld parameter \eta for the Coulomb wave function. 
// ---------------------------------------------------------------------------

complex<double> eta_calc (
			  const bool is_it_relative , 
			  const enum particle_type particle , 
			  const int Z_target , 
			  const double kinetic_factor , 
			  const complex<double> &k);





// Calculation of the reduced mass of a two-nucleon system
// -------------------------------------------------------

double two_nucleon_reduced_mass_calc (
				      const enum particle_type particle ,
				      const double prot_mass_for_calc , 
				      const double neut_mass_for_calc);


// Simple functions for spectroscopic factor
// -----------------------------------------

// Number of nucleons of the father nucleus
int N_nucleons_IN_spectroscopic_factor_determine (
						  const int N_nucleons_OUT ,
						  const int N_nucleons_projectile ,
						  const enum spectroscopic_factor_type SF);

// Determination of the m of the captured or emitted particle for spectroscopic factor or overlap function
double spectroscopic_factor_projectile_m_projection_calc (const enum spectroscopic_factor_type SF , const double M_IN , const double M_OUT);










// Simple functions providing with the rank or parity of an operator
// -----------------------------------------------------------------

// Determination of the binary parity of a tensor operator
unsigned int Op_BP_determine (const enum operator_type Op);

// Determination of the rank of a tensor operator
int Op_rank_determine (const enum operator_type Op);

// Determination of the standard coordinate of an operator of rank J
int Op_standard_coordinate_determine (const enum operator_type Op);

// Determination of the constant transforming an operator to its spherical tensor component
double Op_spherical_tensor_constant_determine (const enum operator_type Op);

// Determination of the constant transforming two rank-k spherical tensors coupled to zero to a scalar product
double tensor_to_scalar_product_constant_determine (const double k);



// Simple functions for rms radius
// -------------------------------

// rms radius factor associated to the r^2 one-body matrix element
double rms_radius_one_body_factor_calc (
					const enum operator_type rms_radius_op , 
					const enum particle_type particle , 
					const double mp , 
					const double mn , 
					const int Z , 
					const int N);


// rms radius factor associated to the ri.rj one-body matrix element
double rms_radius_two_body_sqrt_factor_pp_nn_calc (
						   const enum operator_type rms_radius_op , 
						   const enum particle_type particle , 
						   const double mp , 
						   const double mn , 
						   const int Z , 
						   const int N);

double rms_radius_two_body_sqrt_factor_pn_calc (
						const enum operator_type rms_radius_op , 
						const double mp , 
						const double mn , 
						const int Z , 
						const int N);



// rms radius factor of the CM part of a cluster state
double rms_radius_CM_factor_calc (
				  const enum operator_type rms_radius_op ,
				  const enum particle_type cluster ,
				  const double mp , 
				  const double mn , 
				  const int Z , 
				  const int N);


// rms radius from core Rrms and Rrms^2 of valence part
double rms_radius_calc (
			const enum operator_type rms_radius_op , 
			const int Z_core ,
			const int N_core ,
			const int Z ,
			const int N ,
			const double rms_radius_core , 
			const double rms_radius_square_valence);

complex<double> rms_radius_calc (
				 const enum operator_type rms_radius_op , 
				 const int Z_core ,
				 const int N_core ,
				 const int Z ,
				 const int N ,
				 const double rms_radius_core , 
				 const complex<double> rms_radius_square_valence);

// Contour definition
// ------------------

complex<double> contour_k_calc     (const double power , const double d , const double kr_start , const complex<double> k_peak , const double kr_max , const double kr);
complex<double> contour_k_calc_der (const double power , const double d , const double kr_start , const complex<double> k_peak , const double kr_max , const double kr);



// Decimal logarithm of the width of a one-body state calculated with the current approximation formula in keV
// -----------------------------------------------------------------------------------------------------------
// One has u(r) ~ C+ H+[l , eta](kr) with standard Coulomb wave function normalization and r in the asymptotic region

double log10_width_from_current_formula_calc (
					      const double kinetic_factor ,
					      const complex<double> &log10_Cplus ,
					      const double real_k);

// Width of a one-body state calculated with the current approximation formula in keV
// ----------------------------------------------------------------------------------
// One has u(r) ~ C+ H+[l , eta](kr) with standard Coulomb wave function normalization and r in the asymptotic region

double width_from_current_formula_calc (
					const double kinetic_factor ,
					const complex<double> &Cplus ,
					const double real_k);



// Print width calculated from the cirrebnt formula by using logarithms in case it underflows
// ------------------------------------------------------------------------------------------

void print_width_from_current_formula (const double log10_width_from_current_formula);



// Calculation of the orbital and spin gyromagnetic ratios of the proton or neutron
// --------------------------------------------------------------------------------
// The orbital gyromagnetic ratio of the proton is 1, that of the neutron is 0.
// The spin gyromagnetic ratio of the proton is 5.5857 is that of the neutron is -3.8263 .
//
// Variables
// ---------
// particle : proton or neutron

double mu_l_determine (const enum particle_type particle);
double mu_s_determine (const enum particle_type particle);




// Check if two partial waves, shell or many-body states quantum numbers are identical

bool same_lj (const int l1 , const double j1 , const int l2 , const double j2);

bool same_lj (const int l1 , const int jr1 , const double j1 , const int l2 , const int jr2 , const double j2);

bool same_nlj (const int n1 , const int l1 , const double j1 , const int n2 , const int l2 , const double j2);

bool same_nlj (const int n1 , const int l1 , const int jr1 , const double j1 , const int n2 , const int l2 , const int jr2 , const double j2);

bool same_BP_J (const unsigned int BP1 , const int    J1 , const unsigned int BP2 , const int    J2);
bool same_BP_J (const unsigned int BP1 , const double J1 , const unsigned int BP2 , const double J2);

bool same_BP_J_vector_index (const unsigned int BP1 , const int    J1 , const unsigned int vector_index_1 , const unsigned int BP2 , const int J2    , const unsigned int vector_index_2);
bool same_BP_J_vector_index (const unsigned int BP1 , const double J1 , const unsigned int vector_index_1 , const unsigned int BP2 , const double J2 , const unsigned int vector_index_2);

bool same_BP_M (const unsigned int BP1 , const int    M1 , const unsigned int BP2 , const int    M2);
bool same_BP_M (const unsigned int BP1 , const double M1 , const unsigned int BP2 , const double M2);

bool same_BP_M_vector_index (const unsigned int BP1 , const int    M1 , const unsigned int vector_index_1 , const unsigned int BP2 , const int M2    , const unsigned int vector_index_2);
bool same_BP_M_vector_index (const unsigned int BP1 , const double M1 , const unsigned int vector_index_1 , const unsigned int BP2 , const double M2 , const unsigned int vector_index_2);


// Basic ordering of both protons and neutrons.
// One has : proton <= neutron.
// Otherwise, one uses the state indices: sa <= sb.

bool is_sa_smaller_than_sb_determine (
				      const bool are_sa_proton_sb_neutron ,
				      const bool are_sa_neutron_sb_proton ,
				      const unsigned int sa ,
				      const unsigned int sb);

bool is_sa_larger_than_sb_determine (
				     const bool are_sa_proton_sb_neutron ,
				     const bool are_sa_neutron_sb_proton ,
				     const unsigned int sa ,
				     const unsigned int sb);

// Calculation of the ground state irrep (lambda,mu) quantum numbers and associated ground state energy in the frame of the SU(3) Hamiltonian 

int lambda_SU3_irrep_0hw_determine (const int Nval);
int lambda_SU3_irrep_1hw_determine (const int Nval);
int lambda_SU3_irrep_2hw_determine (const int Nval);
int lambda_SU3_irrep_3hw_determine (const int Nval);
int lambda_SU3_irrep_4hw_determine (const int Nval);
int lambda_SU3_irrep_6hw_determine (const int Nval);
int lambda_SU3_irrep_7hw_determine (const int Nval);

int lambda_SU3_irrep_determine (const int N , const int Nval);
int     mu_SU3_irrep_determine (const int N , const int Nval);

double SU3_leading_irrep_energy_calc (
				      const int Zval ,
				      const int Nval ,
				      const int N_prot , 
				      const int N_neut , 
				      const int L); 
#endif
