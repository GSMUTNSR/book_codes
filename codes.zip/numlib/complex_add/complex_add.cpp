#include "../numlib_def/numlib_def.h"


double inf_norm (const complex<double> &z)
{
  const double Re_z = real (z) , abs_Re_z = abs (Re_z);
  const double Im_z = imag (z) , abs_Im_z = abs (Im_z);

  const double inf_norm_z = max (abs_Re_z , abs_Im_z);
  
  return inf_norm_z;
}



bool finite (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  const bool finite_x = finite (x);
  const bool finite_y = finite (y);
  
  const bool finite_z = (finite_x && finite_y);
  
  return finite_z;
}






template <> double generate_scalar<double> (const double x , const double y)
{
  if (y != 0.0) error_message_print_abort ("Imaginary part has to be equal to zero in generate_scalar<double>");
  
  return x;
}




template <> complex<double> generate_scalar<complex<double> > (const double x , const double y)
{
  return complex<double> (x , y);
}











complex<double> z_log_z (const complex<double> &z)
{
  const complex<double> z_log_z_value = ((z != 0.0) ? (z * log (z)) : (0.0));
  
  return z_log_z_value;
}


complex<double> expm1 (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((abs (x) >= 1.0) || (abs (y) >= 1.0))
    {
      const complex<double> expm1_z = exp (z) - 1.0;
      
      return expm1_z;
    }

  const double half_y = 0.5 * y;
  
  const double expm1_x = expm1 (x);
  
  const double exp_x = 1.0 + expm1_x;
  
  const double two_exp_x = 2.0 * exp_x;
  
  const double sin_y_over_two = sin (half_y);
  
  const double sin_y_over_two_square = sin_y_over_two * sin_y_over_two;
  
  const double sin_y = sin (y);

  const double Re_expm1_z = expm1_x - two_exp_x * sin_y_over_two_square;
  
  const double Im_expm1_z = exp_x * sin_y;
  
  return complex<double> (Re_expm1_z , Im_expm1_z);
}




complex<double> log1p (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((abs (x) >= 1.0) || (abs (y) >= 1.0))
    {
      const complex<double> log1p_z = log (1.0 + z);
      
      return log1p_z;
    }

  const double xp1 = 1.0 + x;

  const double log1p_x = log1p (x);

  const double y_over_xp1 = y/xp1;

  const double y_over_xp1_square = y_over_xp1 * y_over_xp1;

  const double log1p_y_over_xp1_square = log1p (y_over_xp1_square);

  const double half_log1p_y_over_xp1_square = 0.5*log1p_y_over_xp1_square; 

  const double Re_log1p_z = log1p_x + half_log1p_y_over_xp1_square;

  const double Im_log1p_z = atan2 (y , xp1);

  return complex<double> (Re_log1p_z , Im_log1p_z);
}


// Cbrt function with its cut on ]-oo:0[
// ------------------------------------- - 

complex<double> cbrt (const complex<double> &z)
{
  if (imag (z) == 0.0)
    {
      const double x = real (z);

      return cbrt (x);
    }
  
  const double r = abs (z);

  const double theta = arg (z);

  const double cbrt_r = cbrt (r);

  const double theta_over_three = 0.3333333333333333 * theta;

  return polar (cbrt_r , theta_over_three);
}


complex<double> hypot (const complex<double> &z1 , const complex<double> &z2)
{
  const double inf_norm_z1 = inf_norm (z1);
  const double inf_norm_z2 = inf_norm (z2);
  
  const double max_inf_norm = max (inf_norm_z1 , inf_norm_z2);

  if ((max_inf_norm > SQRT_SMALL) && (max_inf_norm < SQRT_INFINITE))
    {
      const complex<double> norm_z1_z2 = z1*z1 + z2*z2;
      
      const complex<double> hypot_z1_z2 = sqrt (norm_z1_z2);
        
      return hypot_z1_z2;
    }
  else
    {
      const double one_over_max_inf_norm = 1.0/max_inf_norm;

      const complex<double> z1_renorm = z1*one_over_max_inf_norm;
      const complex<double> z2_renorm = z2*one_over_max_inf_norm;

      const complex<double> norm_z1_z2_renorm = z1_renorm*z1_renorm + z2_renorm*z2_renorm;
      
      const complex<double> hypot_z1_z2 = max_inf_norm*sqrt (norm_z1_z2_renorm);
      
      return hypot_z1_z2;
    }
}


// Sqrt function with its cut on ]-i.oo:0[
// --------------------------------------- - 

complex<double> sqrt_mod (const complex<double> &z)
{
  if (real (z) >= 0.0) 
    {
      return sqrt (z);
    }
  else
    {
      const complex<double> sqrt_mz = sqrt (-z);

      const double Re_sqrt_mz = real (sqrt_mz);
      const double Im_sqrt_mz = imag (sqrt_mz);
  
      return complex<double> (-Im_sqrt_mz , Re_sqrt_mz);
    }
}

complex<double> acosh (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (x >= 1.0))
    {
      return acosh (x);
    }

  const complex<double> z2 = z*z;
  
  const complex<double> z2_minus_one = z2 - 1.0;
  
  const complex<double> sqrt_z2_minus_one = sqrt (z2_minus_one);
  
  const complex<double> z_plus_sqrt_z2_minus_one = z + sqrt_z2_minus_one;
      
  return log (z_plus_sqrt_z2_minus_one);
}

complex<double> asinh (const complex<double> &z)
{
  if (imag (z) == 0.0)
    {
      const double x = real (z);
      
      return asinh (x);
    }

  const complex<double> z2 = z*z;

  const complex<double> z2_plus_one = z2 + 1.0;
  
  const complex<double> sqrt_z2_plus_one = sqrt (z2_plus_one);
  
  const complex<double> one_plus_sqrt_z2_plus_one = 1.0 + sqrt_z2_plus_one;
  
  const complex<double> z_plus_z2_over_sqrt_z2_plus_one = z + z2/one_plus_sqrt_z2_plus_one;
  
  return log1p (z_plus_z2_over_sqrt_z2_plus_one);
}

complex<double> atanh (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);
  
  if ((y == 0.0) && (abs (x) <= 1.0))
    {
      return atanh (x);
    }

  const complex<double> two_z = 2.0*z;

  const complex<double> one_minus_z = 1.0 - z;

  const complex<double> two_z_over_one_minus_z = two_z/one_minus_z;

  const complex<double> log1p_two_z_over_one_minus_z = log1p (two_z_over_one_minus_z);

  const complex<double> half_log1p_two_z_over_one_minus_z = 0.5 * log1p_two_z_over_one_minus_z;
  
  return half_log1p_two_z_over_one_minus_z;
}







complex<double> acos (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (abs (x) <= 1.0))
    {
      return acos (x);
    }

  const complex<double> one_minus_z2 = 1.0 - z*z;

  const complex<double> sqrt_one_minus_z2 = sqrt (one_minus_z2);

  const double Re_sqrt_one_minus_z2 = real (sqrt_one_minus_z2);
  const double Im_sqrt_one_minus_z2 = imag (sqrt_one_minus_z2);
  
  const complex<double> I_sqrt_one_minus_z2(-Im_sqrt_one_minus_z2 , Re_sqrt_one_minus_z2);
  
  const complex<double> z_plus_I_sqrt_one_minus_z2 = z + I_sqrt_one_minus_z2;

  const complex<double> log_z_plus_I_sqrt_one_minus_z2 = log (z_plus_I_sqrt_one_minus_z2);

  const double Re_log_z_plus_I_sqrt_one_minus_z2 = real (log_z_plus_I_sqrt_one_minus_z2);
  const double Im_log_z_plus_I_sqrt_one_minus_z2 = imag (log_z_plus_I_sqrt_one_minus_z2);
  
  return complex<double> (Im_log_z_plus_I_sqrt_one_minus_z2 , -Re_log_z_plus_I_sqrt_one_minus_z2);
}


complex<double> asin (const complex<double> &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (abs (x) <= 1.0))
    {
      return asin (x);
    }
  
  const complex<double> Iz(-y , x);

  const complex<double> asinh_z = asinh (Iz);

  const double Re_asinh_z = real (asinh_z);
  const double Im_asinh_z = imag (asinh_z);
  
  return complex<double> (Im_asinh_z , -Re_asinh_z);
}


complex<double> atan (const complex<double> &z)
{
  if (imag (z) == 0.0)
    {
      const double x = real (z);
      
      return atan (x);
    }

  const double x = real (z);
  const double y = imag (z);
  
  const complex<double> Iz(-y , x);

  const complex<double> atanh_z = atanh (Iz);
  
  const double Re_atanh_z = real (atanh_z);
  const double Im_atanh_z = imag (atanh_z);
  
  return complex<double> (Im_atanh_z , -Re_atanh_z);
}

