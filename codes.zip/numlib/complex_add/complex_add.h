#ifndef COMPLEX_ADD_H
#define COMPLEX_ADD_H

inline double norm_c (const complex<double> &x)
{
  return norm (x);
}

inline double real_dc (const double x)
{
  return x;
}

inline double real_dc (const complex<double> &x)
{
  return real (x);
}

inline double imag_dc (const double)
{
  return 0.0;
}

inline double imag_dc (const complex<double> &x)
{
  return imag (x);
}

inline double conj_dc (const double x)
{
  return x;
}

inline complex<double> conj_dc (const complex<double> &x)
{
  return conj (x);
}

inline double norm_dc (const double x)
{
  return x*x;
}

inline double norm_dc (const complex<double> &x)
{
  return norm (x);
}

inline double inf_norm (const double x)
{
  return abs (x);
}

inline double sqrt_mod (const double x)
{
  return sqrt (x);
}

double inf_norm (const complex<double> &z);

bool finite (const complex<double> &z);

template <typename SCALAR_TYPE>
SCALAR_TYPE generate_scalar (const double x , const double y);

template <> double generate_scalar<double> (const double x , const double y);

template <> complex<double> generate_scalar<complex<double> > (const double x , const double y);





inline complex<double> operator + (const complex<double> &z , const int n)
{
  return (z + static_cast<double> (n));
}

inline complex<double> operator - (const complex<double> &z , const int n)
{
  return (z - static_cast<double> (n));
}

inline complex<double> operator * (const complex<double> &z , const int n)
{
  return (z * static_cast<double> (n));
}

inline complex<double> operator / (const complex<double> &z , const int n)
{
  return (z/static_cast<double> (n));
}







inline complex<double> operator + (const int n , const complex<double> &z)
{
  return (static_cast<double> (n) + z);
}

inline complex<double> operator - (const int n , const complex<double> &z)
{
  return (static_cast<double> (n) - z);
}

inline complex<double> operator * (const int n , const complex<double> &z)
{
  return (static_cast<double> (n) * z);
}

inline complex<double> operator / (const int n , const complex<double> &z)
{
  return (static_cast<double> (n)/z);
}








inline complex<double> operator + (const complex<double> &z , const unsigned int n)
{
  return (z + static_cast<double> (n));
}

inline complex<double> operator - (const complex<double> &z , const unsigned int n)
{
  return (z - static_cast<double> (n));
}

inline complex<double> operator * (const complex<double> &z , const unsigned int n)
{
  return (z * static_cast<double> (n));
}

inline complex<double> operator / (const complex<double> &z , const unsigned int n)
{
  return (z/static_cast<double> (n));
}











inline complex<double> operator + (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n) + z);
}

inline complex<double> operator - (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n) - z);
}

inline complex<double> operator * (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n) * z);
}

inline complex<double> operator / (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n)/z);
}





inline bool operator == (const complex<double> &z , const int n)
{
  return (z == static_cast<double> (n));
}

inline bool operator != (const complex<double> &z , const int n)
{
  return (z != static_cast<double> (n));
}

inline bool operator == (const int n , const complex<double> &z)
{
  return (static_cast<double> (n) == z);
}

inline bool operator != (const int n , const complex<double> &z)
{
  return (static_cast<double> (n) != z);
}







inline bool operator == (const complex<double> &z , const unsigned int n)
{
  return (z == static_cast<double> (n));
}

inline bool operator != (const complex<double> &z , const unsigned int n)
{
  return (z != static_cast<double> (n));
}

inline bool operator == (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n) == z);
}

inline bool operator != (const unsigned int n , const complex<double> &z)
{
  return (static_cast<double> (n) != z);
}




complex<double> z_log_z (const complex<double> &z);

complex<double> expm1 (const complex<double> &z);

complex<double> log1p (const complex<double> &z);

complex<double> cbrt (const complex<double> &z);

complex<double> hypot (const complex<double> &z1 , const complex<double> &z2);

complex<double> sqrt_mod (const complex<double> &z);

complex<double> acosh (const complex<double> &z);

complex<double> asinh (const complex<double> &z);

complex<double> atanh (const complex<double> &z);

complex<double> acos (const complex<double> &z);

complex<double> asin (const complex<double> &z);

complex<double> atan (const complex<double> &z);

#endif


