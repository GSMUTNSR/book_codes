#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif
    
    OpenMP_initialization ();
    
    for (int i = -2 ; i <= 2 ; i++)
      for (int j = -2 ; j <= 2 ; j++)
	{
	  const complex<double> a(0.03 + i , 0.01*j);
	  const complex<double> b(-0.01 + i , -0.02*j);

	  if (abs (inf_norm (a) - max (inf_norm (real (a)) , inf_norm (imag (a))))) error_message_print_abort ("Problem with inf_norm");

	  if (inf_norm (norm (a) - real (a)*real (a) - imag (a)*imag (a)) > precision) error_message_print_abort ("Problem with norm");
	  
	  if (inf_norm (hypot (a , b) - sqrt (a*a + b*b)) > precision) error_message_print_abort ("Problem with hypot");

	  if (inf_norm (hypot (2000.0*SQRT_INFINITE*a , 2000.0*SQRT_INFINITE*b) - 2000.0*SQRT_INFINITE*sqrt (a*a + b*b)) > 2000.0*SQRT_INFINITE*precision) error_message_print_abort ("Problem with hypot");

	  if (inf_norm (hypot (0.005*SQRT_SMALL*a , 0.005*SQRT_SMALL*b) - 0.005*SQRT_SMALL*sqrt (a*a + b*b)) > 0.005*SQRT_SMALL*precision) error_message_print_abort ("Problem with hypot");	  
  
	  if (!finite (a)) error_message_print_abort ("Problem with finite (regular case)");

	  if (finite (complex<double> (a/0.0))) error_message_print_abort ("Problem with finite (irregular case)");

	  if (inf_norm (expm1 (a) - exp (a) + 1.0) > precision) error_message_print_abort ("Problem with expm1"); 
	  if (inf_norm (log1p (a) - log (1.0 + a)) > precision) error_message_print_abort ("Problem with log1p"); 

	  if (inf_norm (cos (acos (a)) - a) > precision) error_message_print_abort ("Problem with acos"); 
	  if (inf_norm (sin (asin (a)) - a) > precision) error_message_print_abort ("Problem with asin"); 
	  if (inf_norm (tan (atan (a)) - a) > precision) error_message_print_abort ("Problem with atan"); 

	  if (inf_norm (sqrt_mod (complex<double> (-2.0 ,  1E-15)) - complex<double> (0.0 , M_SQRT2)) > precision) error_message_print_abort ("Problem with sqrt_mod (-2 + i.eps)");
	  if (inf_norm (sqrt_mod (complex<double> (-2.0 , -1E-15)) - complex<double> (0.0 , M_SQRT2)) > precision) error_message_print_abort ("Problem with sqrt_mod (-2 - i.eps)");

	  if (inf_norm (sqrt_mod (complex<double> (1E-15  , -1.0)) - complex<double> (M_SQRT1_2 , -M_SQRT1_2)) > precision) error_message_print_abort ("Problem with sqrt_mod (-i + eps)");
	  if (inf_norm (sqrt_mod (complex<double> (-1E-15 , -1.0)) - complex<double> (-M_SQRT1_2 , M_SQRT1_2)) > precision) error_message_print_abort ("Problem with sqrt_mod (-i - eps)");
	  
	  if (inf_norm (cosh (acosh (a)) - a) > precision) error_message_print_abort ("Problem with acosh"); 
	  if (inf_norm (sinh (asinh (a)) - a) > precision) error_message_print_abort ("Problem with asinh"); 
	  if (inf_norm (tanh (atanh (a)) - a) > precision) error_message_print_abort ("Problem with atanh"); 

	  if (inf_norm (cbrt (a)*cbrt (a)*cbrt (a) - a) > precision) error_message_print_abort ("Problem with cbrt"); 

	  const int n = 2;

	  const unsigned int m = 3;

	  complex<double> dn = n;

	  if (dn != n) error_message_print_abort ("Problem with complex , int != (1)");
	  if (n != dn) error_message_print_abort ("Problem with int , complex != (1)");

	  if (!(dn == n)) error_message_print_abort ("Problem with complex , int == (1)");
	  if (!(n == dn)) error_message_print_abort ("Problem with int , complex == (1)");

	  dn = a;

	  if (dn == n) error_message_print_abort ("Problem with complex , int != (2)");
	  if (n == dn) error_message_print_abort ("Problem with int , complex != (2)");

	  if (!(dn != n)) error_message_print_abort ("Problem with complex , int == (2)");
	  if (!(n != dn)) error_message_print_abort ("Problem with int , complex == (2)");

	  dn = dn + n;
	  dn = dn - n;
	  dn = dn*n;
	  dn = dn/n;

	  if (inf_norm (dn - a) > precision) error_message_print_abort ("Problem with int = , + , - , * or / (complex , int)");

	  complex<double> dm = m;

	  if (dm != m) error_message_print_abort ("Problem with complex , unsigned int != (1)");
	  if (m != dm) error_message_print_abort ("Problem with unsigned int , complex != (1)");

	  if (!(dm == m)) error_message_print_abort ("Problem with complex , unsigned int == (1)");
	  if (!(m == dm)) error_message_print_abort ("Problem with unsigned int , complex == (1)");

	  dm = a;

	  if (dm == m) error_message_print_abort ("Problem with complex , unsigned int != (2)");
	  if (m == dm) error_message_print_abort ("Problem with unsigned int , complex != (2)");

	  if (!(dm != m)) error_message_print_abort ("Problem with complex , unsigned int == (2)");
	  if (!(m != dm)) error_message_print_abort ("Problem with unsigned int , complex == (2)");

	  dm = dm + m;
	  dm = dm - m;
	  dm = dm*m;
	  dm = dm/m;

	  if (inf_norm (dm - a) > precision) error_message_print_abort ("Problem with int = , + , - , * or / (complex , unsigned int)");

	  complex<double> en = a;

	  en = n - en;
	  en = n + en;

	  if (inf_norm (en - 2*n + a) > precision) error_message_print_abort ("Problem with int + or - (int , complex)");

	  en = a;
	  en = n*en;
	  en = n/en;

	  if (inf_norm (en - 1.0/a) > precision) error_message_print_abort ("Problem with * or / (int , complex)");

	  complex<double> em = a;

	  em = m - em;
	  em = m + em;

	  if (inf_norm (em - 2*m + a) > precision) error_message_print_abort ("Problem with + or - (unsigned int , complex)");

	  em = a;
	  em = m*em;
	  em = m/em;

	  if (inf_norm (em - 1.0/a) > precision) error_message_print_abort ("Problem with * or / (unsigned int , complex)");
	}

    cout << "All tests for complex numbers are correct."<<endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
