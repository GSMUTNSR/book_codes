#ifndef BASICMATHS_H
#define BASICMATHS_H

// sign function
// -------------
int SIGN (const double x);

// z.log (z) function
// ------------------
// returns z.log (z) if z != 0 and 0 if z = 0

double z_log_z (const double z);


// integer from double.
// --------------------
int make_int (const double x_int);


// unsigned integer from double.
// ---------------------------- - 
unsigned int make_uns_int (const double x_int);

// unsigned short integer from double.
// ---------------------------------- - 
unsigned int make_uns_short_int (const double x_int);



// unsigned char from double.
// --------------------------
unsigned char make_uns_char (const double x_int);


// -1 pow integer
// --------------
int minus_one_pow (const unsigned int x_int);

int minus_one_pow (const int x_int);

int minus_one_pow (const double x_int);





// Calculation of the increment (3^k - 1)/2 for Shell's method search , quick for for N < 21523360
// -----------------------------------------------------------------------------------------------
unsigned int Shell_method_increment_determine (const unsigned int N);



// Memory of basic types in Mb
// ---------------------------

double used_memory_calc (const void * x);

double used_memory_calc (const bool &x);

double used_memory_calc (const signed char &x);

double used_memory_calc (const wchar_t &x);

double used_memory_calc (const unsigned char &x);

double used_memory_calc (const unsigned short int &x);

double used_memory_calc (const unsigned int &x);

double used_memory_calc (const unsigned long int &x);

double used_memory_calc (const char &x);

double used_memory_calc (const short int &x);

double used_memory_calc (const int &x);

double used_memory_calc (const long int &x);

double used_memory_calc (const float &x);

double used_memory_calc (const double &x);

double used_memory_calc (const long double &x);

double used_memory_calc (const complex<float> &x);

double used_memory_calc (const complex<double> &x);

double used_memory_calc (const complex<long double> &x);

double used_memory_calc (const string &x);


// Fermi - like function and derivatives
// ---------------------------------- - 
// One has this function to smoothly and analyticaly cut functions.
// for integrations of integrals and differentials equations.
// The function is 1/[1 + exp[5.[x - x0]/d]].
// If 5.[x - x0]/d >= 110 , one approximates the Fermi function by exp[ - 5.[x - x0]/d] to avoid overflow.
// double and complex x can be used.
//
// Variables and special values:
// ---------------------------- - 
// x0 : point where the Fermi function is 1/2.
// d : diffuseness
// a , exp_5a : [x - x0]/d , exp (5.a)
// b : 5/d
// fx , dfx , d2fx: Fermi function and first , second derivative

double Fermi_like_function (const double x0 , const double d , const double x);

double Fermi_like_function_der (const double x0 , const double d , const double x);

double Fermi_like_function_2der (const double x0 , const double d , const double x);

double Fermi_like_function_3der (const double x0 , const double d , const double x);


complex<double> Fermi_like_function (const double x0 , const double d , const complex<double> &x);

complex<double> Fermi_like_function_der (const double x0 , const double d , const complex<double> &x);

complex<double> Fermi_like_function_2der (const double x0 , const double d , const complex<double> &x);

complex<double> Fermi_like_function_3der (const double x0 , const double d , const complex<double> &x);




// Approximate derivative F'(x0) calculated from x1, x2, F(x1), F(x2)
// ------------------------------------------------------------------
// A three-point approximation is done from x0, x1, x2, F(x0), F(x1), F(x2), which provides F'(x0)
// double and complex versions are provided
//
// Variables:
// ---------
// x1, F1: first point on the line, F(x1)
// x2, F2: second point on the line, F(x1)
// x0, F0: point where the approximate derivative is calculated, F(x0)

double three_point_derivative (
			       const double x0 , const double F0 ,
			       const double x1 , const double F1 ,
			       const double x2 , const double F2);

complex<double> three_point_derivative (
					const complex<double> &x0 , const complex<double> &F0 ,
					const complex<double> &x1 , const complex<double> &F1 ,
					const complex<double> &x2 , const complex<double> &F2);









// Roots of a polynomial of degree 2,3,4
// -------------------------------------
// I coded the analytical formulas for roots of polynomials of degree 2,3,4 for both numerical and pedagogical interests.
// They are usually precise, except if roots are too close or degenerate for degree 3,4, in which case one has a relative precision of 10^(-4,-5) typically.
// The use of Newton method is then recommended if one uses formulas for degree 3,4, as is done for the study of exceptional points of complex matrices of dimension 3.







// Roots of a polynomial of degree two
// -----------------------------------
// One has P(x) = x^2 + b.x + c .
// In the real case, a discriminant smaller than 10^(-13) relatively to b and c in modulus is considered as negligible, where one considers that the two roots and real and equal, and otherwise non zero.
// The c=0 and general cases are treated afterwards.
// In the complex case, one considers only the c=0 and general cases,
// Roots are x0 and x1, with |x0|oo >= |x1|oo.
// Standard analytical formulas are used.
// Double and complex versions are available.
// Numerical cancellation is minimized.


void roots_polynomial_degree_two (
				  const double b , 
				  const double c ,
				  double &x0 , 
				  double &x1);






void roots_polynomial_degree_two (
				  const complex<double> &b , 
				  const complex<double> &c ,
				  complex<double> &x0 , 
				  complex<double> &x1);








// Roots of a polynomial of degree three
// -------------------------------------
// One has P(x) = x^3 + a.x^2 + b.x + c .
// Roots are x0, x1 and x2.
// The c=0 case is treated first.
// Standard analytical formulas are used with Q(x) = x^3 + p.x + q, obtained after the Tschirnaus transformation of P(x).
// Cases for which p=0 and q=0 are treated separately.
// The second-degree resolvent of the cubic equation is z^2 + ar.z + br with ar = q and br = -p^3/27.
// Its solution of largest infinite norm is used for numerical stability.
// The root of P(x) of smallest infinite norm is recalculated from x0.x1.x2 = -c for stability.
// Complex version only.
// Numerical cancellation is minimized.



complex<double> resolvent_root_polynomial_degree_three_calc (
							     const complex<double> &ar ,
							     const complex<double> &br);




void roots_polynomial_degree_three (
				    const complex<double> &a , 
				    const complex<double> &b , 
				    const complex<double> &c ,
				    complex<double> &x0 , 
				    complex<double> &x1 , 
				    complex<double> &x2);










// Roots of a polynomial of degree four
// ------------------------------------
// One has P(x) = x^4 + a.x^3 + b.x^2 + c.x + d .
// Roots are x0, x1, x2 and x3.
// The d=0 case is treated first.
// Standard analytical formulas are used with Q(x) = x^4 + p.x^2 + q.x + r, obtained after the Tschirnaus transformation of P(x).
// Cases for which q=0 and r=0 are treated separately.
// Complex version only.
// The third-degree resolvent of the quartic equation is m^3 + ar.m^2 + br.m + cr with ar = p, br = p^2/4 - r and cr = -q^2/8.
// Its solution of largest infinite norm is used for numerical stability.
// The root of P(x) of smallest infinite norm is recalculated from x0.x1.x2.x3 = d for stability.
// Numerical cancellation is minimized.


complex<double> resolvent_root_polynomial_degree_four_calc (
							    const complex<double> &ar ,
							    const complex<double> &br ,
							    const complex<double> &cr);




void roots_polynomial_degree_four (
				   const complex<double> &a , 
				   const complex<double> &b , 
				   const complex<double> &c ,
				   const complex<double> &d ,
				   complex<double> &x0 , 
				   complex<double> &x1 , 
				   complex<double> &x2 , 
				   complex<double> &x3);






// Dispersion of a statistical value from its statistical sum and sum of squares
// -----------------------------------------------------------------------------
// It is sigma = sqrt[(\sum_{i=1}^{N} (x_i - <x>)^2)/(N - 1)] for N >= 2, with <x> = (\sum_{i=1}^{N} x_i)/N.
// sigma = 0 for N <= 1 by definition.
// It is calculated from the statistical sum S = \sum_{i=1}^{N} x_i and the statistical squares sum SQ = \sum_{i=1}^{N} (x_i)^2.
// One has then: sigma = sqrt[(SQ - (S^2)/N)/(N-1)].

double statistical_sigma_calc (
			       const unsigned int N ,
			       const double statistical_sum ,
			       const double statistical_squares_sum);







// Determination of the first and last index to consider in a table when parallel computation is used
// --------------------------------------------------------------------------------------------------
// One considers a one-dimensional table of N elements to be calculated. They have to be distributed as evenly as possible among the available processes.
//
// This routine is supposed to be used by all processes independently of each other.
// The process is an MPI process , OpenMP is not considered here.
//
// If the table dimension is smaller than the number of processes , each process smaller than table dimension considers one table component : first.index = last.index = process. 
// The remaining processes must not be used , so that N is returned in this case. 
// The boolean function is_process_active_for_MPI returns true in the first case and false in the last case.
// 
// If the table dimension is larger than the number of processes , one considers x = N/Nprocesses. 
// The first n processes will have x + 1 elements and the last Nprocesses - n processes will have x elements. One has n = N - x.Nprocesses.
// 
// If process is smaller than n , first.index = (x + 1).process and last.index = first.index + x.
// If process is equal to n , first.index = process + x.process and last.index = first.index + x - 1.
// If process is larger than n , first.index = n + x.process and last.index = first.index + x - 1.
//
// The function basic_process_dimension_determine_for_MPI return the number of elements to treat by the process , which is x , x + 1 , or zero if the process is inactive.
//
// Variables
// -------- - 
// N : table dimension
// process : considered process index to determine indices
// group_processes_number : number of processes considered in the routine.
// x : N/group_processes_number , 
// n : N-x.group_processes_number , 

unsigned long int basic_first_index_determine_for_MPI (const unsigned long int N , const unsigned int group_processes_number , const unsigned int process);




unsigned long int basic_last_index_determine_for_MPI (const unsigned long int N , const unsigned int group_processes_number , const unsigned int process);




// Determination if an MPI process is active according to the dimension of the table
// ---------------------------------------------------------------------------------
// One returns true if one does not use MPI parallelization as all nodes calculate independently in this case.
// They must not be idle then.
// Otherwise, if the dimension of the table is smaller then the number of MPI ranks, the last nodes have to be idle.

bool is_process_active_for_MPI (const unsigned long int N , const unsigned int process);



// Determination of the number of elements (process dimension) that an active process has to handle for MPI transfer
// -----------------------------------------------------------------------------------------------------------------
// N is returned without MPI parallelization as all nodes work independently therein.

unsigned int basic_process_dimension_determine_for_MPI  (
							 const unsigned long int N ,
							 const unsigned int group_processes_number ,
							 const unsigned int process);



// Determination of the active process for MPI transfer according to the value of its index
// ----------------------------------------------------------------------------------------
// It is the process for which the considered index lies between the process first index and the process last index of a given table.

unsigned int basic_active_process_determine_for_MPI (
						     const unsigned long int N ,
						     const unsigned int group_processes_number ,
						     const unsigned long int index);



// Indices for Richardson interpolation array
// ------------------------------------------
// One uses an array of 28 values to interpolate with the Richardson extrapolation, indexed by n <= 7 and i < n
// Indices are hard coded here.

unsigned int Richardson_interpolation_index (const unsigned int n , const unsigned int i);


// Automatic calculation of k peak in Berggren basis contours for HFB calculations
// -------------------------------------------------------------------------------
complex<double> k_peak_calc (const complex<double> &k_res , const double kmax);


// Calculation of the A-dependent factor equal to 1 + A_dependent_factor_core_potential.(N-Z)/A
// --------------------------------------------------------------------------------------------
double A_dependent_factor_core_potential_calc (const enum particle_type particle , const int Z , const int A , const double A_dependence_alpha_core_potential);


// Calculation of the A-dependent factor equal to ((A(core) + 2)/A)^A_dependence_exponent 
// --------------------------------------------------------------------------------------
double TBME_A_dependent_factor_calc (const int A_core , const int A , const double A_dependence_exponent);


// One-dimensional index of an upper triangular matrix of dimension N
// ------------------------------------------------------------------
// It is: 0 1 3 6 10 ...
//          2 4 7 11 ...
//            5 8 12 ...
//              9 13 ...
//                14 ...
//
// One must have i <= j.
// The formula is ij_index = i + j(j+1)/2.
//
// One can also calculate the (i,j) indices associated to the upper triangular index ij_index.

// For this, one uses bisection, knowing that 0 <= j <= N-1.
// One looks for j_debut and j_end so that:
// upper_triangular_index_calc (0 , j_debut) - ij_index <= 0
// upper_triangular_index_calc (0 , j_end) - ij_index >= 0.
// Thus, j = j_end if upper_triangular_index_calc (0 , j_end) == ij_index and j = j_debut otherwise.
//
// i0 means that one uses i=0 in the bisection search.
// The upper triangular indices for i=0, j=j_debut/j_middle/j_end are denoted i0_j_debut/j_middle/j_end_index.
//
// i is immediate from ij_index and j.
//
// No tests are made in routines.

unsigned int upper_triangular_index_calc (const unsigned int i , const unsigned int j);

unsigned int row_index_from_upper_triangular_index_calc (const unsigned int N , const unsigned int ij_index);

unsigned int column_index_from_upper_triangular_index_calc (const unsigned int N , const unsigned int ij_index);


// Returns zero if a given complex number has a negative real part. The initial complex number is returned if the real part is positive or zero. 

double delta_positive_real_part (const double x);

complex<double> delta_positive_real_part (const complex<double> &x);



#endif
