#include "../numlib_def/numlib_def.h"

// sign function
// -------------
int SIGN (const double x)
{
  return ((x < 0) ? (-1) : (1));
}

// z.log (z) function
// ------------------
// returns z.log (z) if z != 0 and 0 if z = 0

double z_log_z (const double z)
{
  return (z != 0.0) ? (z * log (z)) : (0.0);
}


// integer from double.
// --------------------
int make_int (const double x_int)
{ 
  return static_cast<int> (rint (x_int));
}


// unsigned integer from double.
// ---------------------------- - 
unsigned int make_uns_int (const double x_int)
{
  return static_cast<unsigned int> (rint (x_int));
}

// unsigned short integer from double.
// ---------------------------------- - 
unsigned int make_uns_short_int (const double x_int)
{
  return static_cast<unsigned short int> (rint (x_int));
}



// unsigned char from double.
// --------------------------
unsigned char make_uns_char (const double x_int)
{
  return static_cast<unsigned char> (rint (x_int));
}


// -1 pow integer
// --------------
int minus_one_pow (const unsigned int x_int)
{
  return ((x_int % 2 == 0) ? (1) : (-1));
}

int minus_one_pow (const int x_int)
{
  return ((x_int % 2 == 0) ? (1) : (-1));
}


int minus_one_pow (const double x_int)
{
  return ((make_int (x_int) % 2 == 0) ? (1) : (-1));
}





// Calculation of the increment (3^k - 1)/2 for Shell's method search , quick for for N < 21523360
// -----------------------------------------------------------------------------------------------
unsigned int Shell_method_increment_determine (const unsigned int N)
{
  if (N < 4)        return 4;
  if (N < 13)       return 13;
  if (N < 40)       return 40;
  if (N < 121)      return 121;
  if (N < 364)      return 364;
  if (N < 1093)     return 1093;
  if (N < 3280)     return 3280;
  if (N < 9841)     return 9841;
  if (N < 29524)    return 29524;
  if (N < 88573)    return 88573;
  if (N < 265720)   return 265720;
  if (N < 797161)   return 797161;
  if (N < 2391484)  return 2391484;
  if (N < 7174453)  return 7174453;
  if (N < 21523360) return 21523360;

  unsigned int inc = 21523360;

  do 
    {
      inc *= 3;
      inc ++ ;
    } 
  while (inc <= N);

  return inc;
}



// Memory of basic types in Mb
// ---------------------------

double used_memory_calc (const void * x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const bool &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const signed char &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const wchar_t &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const unsigned char &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const unsigned short int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const unsigned int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const unsigned long int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const char &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const short int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const long int &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const float &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const double &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const long double &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const complex<float> &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const complex<double> &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const complex<long double> &x)
{
  return sizeof (x)/1000000.0;
}

double used_memory_calc (const string &x)
{
  return (sizeof (x) + x.length ()*sizeof (char))/1000000.0;
}


// Fermi - like function and derivatives
// ---------------------------------- - 
// One has this function to smoothly and analyticaly cut functions.
// for integrations of integrals and differentials equations.
// The function is 1/[1 + exp[5.[x - x0]/d]].
// If 5.[x - x0]/d >= 110 , one approximates the Fermi function by exp[ - 5.[x - x0]/d] to avoid overflow.
// double and complex x can be used.
//
// Variables and special values:
// ---------------------------- - 
// x0 : point where the Fermi function is 1/2.
// d : diffuseness
// a , exp_5a : [x - x0]/d , exp (5.a)
// b : 5/d
// fx , dfx , d2fx: Fermi function and first , second derivative

double Fermi_like_function (const double x0 , const double d , const double x)
{
  const double a = (x - x0)/d;

  if (a < 110)
    return 1.0/(1.0 + exp (5.0 * a));
  else 
    return exp (-5.0 * a);
}

double Fermi_like_function_der (const double x0 , const double d , const double x)
{
  const double a = (x - x0)/d , b = 5.0/d;

  if (a < 110)
    {
      const double exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a);

      return (- exp_5a * b * fx * fx);
    }
  else
    return (- b * exp (-5.0 * a));
}

double Fermi_like_function_2der (const double x0 , const double d , const double x)
{
  const double a = (x - x0)/d , b = 5.0/d;

  if (a < 110)
    {
      const double exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a) , dfx = - exp_5a * b * fx * fx;

      return (- exp_5a * b * fx * (2.0 * dfx + b * fx)); 
    }
  else 
    return (b * b * exp (-5.0 * a));
}

double Fermi_like_function_3der (const double x0 , const double d , const double x)
{
  const double a = (x - x0)/d , b = 5.0/d;

  if (a < 110)
    {
      const double exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a) , dfx = - exp_5a * b * fx * fx , d2fx = - exp_5a * b * fx * (2.0 * dfx + b * fx);

      return (b*(d2fx - 2.0 * exp_5a * (b * dfx * fx + d2fx * fx + dfx * dfx)));
    }
  else 
    return (- b * b * b * exp (-5.0 * a));
}


complex<double> Fermi_like_function (const double x0 , const double d , const complex<double> &x)
{
  const complex<double> a = (x - x0)/d;

  if (real (a) < 110)
    return 1.0/(1.0 + exp (5.0 * a));
  else 
    return exp (-5.0 * a);
}

complex<double> Fermi_like_function_der (const double x0 , const double d , const complex<double> &x)
{
  const complex<double> a = (x - x0)/d;
  
  const double b = 5.0/d;

  if (real (a) < 110)
    {
      const complex<double> exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a);

      return (- exp_5a * b * fx * fx);
    }
  else
    return (- b * exp (-5.0 * a));
}

complex<double> Fermi_like_function_2der (const double x0 , const double d , const complex<double> &x)
{
  const complex<double> a = (x - x0)/d;
  
  const double b = 5.0/d;

  if (real (a) < 110)
    {
      const complex<double> exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a) , dfx = - exp_5a * b * fx * fx;

      return (- exp_5a * b * fx * (2.0 * dfx + b * fx)); 
    }
  else 
    return (b * b * exp (-5.0 * a));
}

complex<double> Fermi_like_function_3der (const double x0 , const double d , const complex<double> &x)
{
  const complex<double> a = (x - x0)/d , b = 5.0/d;

  if (real (a) < 110)
    {
      const complex<double> exp_5a = exp (5.0 * a) , fx = 1.0/(1.0 + exp_5a) , dfx = - exp_5a * b * fx * fx , d2fx = - exp_5a * b * fx * (2.0 * dfx + b * fx);

      return (b*(d2fx - 2.0 * exp_5a * (b * dfx * fx + d2fx * fx + dfx * dfx)));
    }
  else 
    return (- b * b * b * exp (-5.0 * a));
}




// Approximate derivative F'(x0) calculated from x1, x2, F(x1), F(x2)
// ------------------------------------------------------------------
// A three-point approximation is done from x0, x1, x2, F(x0), F(x1), F(x2), which provides F'(x0)
// double and complex versions are provided
//
// Variables:
// ---------
// x1, F1: first point on the line, F(x1)
// x2, F2: second point on the line, F(x1)
// x0, F0: point where the approximate derivative is calculated, F(x0)

double three_point_derivative (
			       const double x0 , const double F0 ,
			       const double x1 , const double F1 ,
			       const double x2 , const double F2)
{
  const double dx1 = x1 - x0;
  const double dx2 = x2 - x0;

  const double dF0 = (dx2*dx2*F1 - dx1*dx1*F2 - (dx2*dx2 - dx1*dx1)*F0)/((dx2 - dx1)*dx1*dx2);

  return dF0;
}

complex<double> three_point_derivative (
					const complex<double> &x0 , const complex<double> &F0 ,
					const complex<double> &x1 , const complex<double> &F1 ,
					const complex<double> &x2 , const complex<double> &F2)
{
  const complex<double> dx1 = x1 - x0;
  const complex<double> dx2 = x2 - x0;

  const complex<double> dF0 = (dx2*dx2*F1 - dx1*dx1*F2 - (dx2*dx2 - dx1*dx1)*F0)/((dx2 - dx1)*dx1*dx2);

  return dF0;
}









// Roots of a polynomial of degree 2,3,4
// -------------------------------------
// I coded the analytical formulas for roots of polynomials of degree 2,3,4 for both numerical and pedagogical interests.
// They are usually precise, except if roots are too close or degenerate for degree 3,4, in which case one has a relative precision of 10^(-4,-5) typically.
// The use of Newton method is then recommended if one uses formulas for degree 3,4, as is done for the study of exceptional points of complex matrices of dimension 3.







// Roots of a polynomial of degree two
// -----------------------------------
// One has P(x) = x^2 + b.x + c .
// In the real case, a discriminant smaller than 10^(-13) relatively to b and c in modulus is considered as negligible, where one considers that the two roots and real and equal, and otherwise non zero.
// The c=0 and general cases are treated afterwards.
// In the complex case, one considers only the c=0 and general cases,
// Roots are x0 and x1, with |x0|oo >= |x1|oo.
// Standard analytical formulas are used.
// Double and complex versions are available.
// Numerical cancellation is minimized.


void roots_polynomial_degree_two (
				  const double b , 
				  const double c ,
				  double &x0 , 
				  double &x1)
{
  if (c == 0.0)
    {
      x0 = -b;
      
      x1 = 0.0;
      
      return;
    }
  
  const double Delta = b*b - 4.0*c;

  const double max_abs_bc = max (abs (b) , abs (c));

  const double eps_max_abs_bc = 1E-13*max_abs_bc;
  
  if (Delta < -eps_max_abs_bc) error_message_print_abort ("Roots are complex in roots_polynomial_degree_two (double)");
 
  if (Delta < eps_max_abs_bc)
    {
      x0 = x1 = -0.5*b;
      
      return;
    }
  
  const double sqrt_Delta = sqrt (Delta);

  const double minus_b_plus_Delta  = -b + sqrt_Delta;
  const double minus_b_minus_Delta = -b - sqrt_Delta;
    
  x0 = (inf_norm (minus_b_plus_Delta) > inf_norm (minus_b_minus_Delta)) ? (0.5*minus_b_plus_Delta) : (0.5*minus_b_minus_Delta);

  x1 = c/x0;
}






void roots_polynomial_degree_two (
				  const complex<double> &b , 
				  const complex<double> &c ,
				  complex<double> &x0 , 
				  complex<double> &x1)
{
  if (c == 0.0)
    {
      x0 = -b;
      
      x1 = 0.0;
      
      return;
    }

  const complex<double> Delta = b*b - 4.0*c;

  const complex<double> sqrt_Delta = sqrt (Delta);
  
  const complex<double> minus_b_plus_Delta  = -b + sqrt_Delta;
  const complex<double> minus_b_minus_Delta = -b - sqrt_Delta;
    
  x0 = (inf_norm (minus_b_plus_Delta) > inf_norm (minus_b_minus_Delta)) ? (0.5*minus_b_plus_Delta) : (0.5*minus_b_minus_Delta);

  x1 = c/x0;
}








// Roots of a polynomial of degree three
// -------------------------------------
// One has P(x) = x^3 + a.x^2 + b.x + c .
// Roots are x0, x1 and x2.
// The c=0 case is treated first.
// Standard analytical formulas are used with Q(x) = x^3 + p.x + q, obtained after the Tschirnaus transformation of P(x).
// Cases for which p=0 and q=0 are treated separately.
// The second-degree resolvent of the cubic equation is z^2 + ar.z + br with ar = q and br = -p^3/27.
// Its solution of largest infinite norm is used for numerical stability.
// The root of P(x) of smallest infinite norm is recalculated from x0.x1.x2 = -c for stability.
// Complex version only.
// Numerical cancellation is minimized.



complex<double> resolvent_root_polynomial_degree_three_calc (
							     const complex<double> &ar ,
							     const complex<double> &br)
{
  complex<double> x0 = 0.0;

  complex<double> dummy = 0.0;

  roots_polynomial_degree_two (ar , br , x0 , dummy);

  return x0;
}





void roots_polynomial_degree_three (
				    const complex<double> &a , 
				    const complex<double> &b , 
				    const complex<double> &c ,
				    complex<double> &x0 , 
				    complex<double> &x1 , 
				    complex<double> &x2)
{
  if (c == 0.0)
    {
      x0 = 0.0;

      roots_polynomial_degree_two (a , b , x1 , x2);
      
      return;
    }

  const double one_third = 0.3333333333333333;

  const double one_over_twenty_seven = 3.7037037037037037E-2;
  const double two_over_twenty_seven = 7.4074074074074074E-2;
  
  const complex<double> j (-0.5 ,  0.8660254037844386);
  const complex<double> j2(-0.5 , -0.8660254037844386);
  
  const complex<double> a2 = a*a;
  const complex<double> a3 = a2*a;

  const complex<double> a_over_three = a*one_third;
  
  const complex<double> p = -a2*one_third + b;

  const complex<double> q = two_over_twenty_seven*a3 - a*b*one_third + c;

  if (q == 0.0)
    {
      const complex<double> y0 = 0.0;
      const complex<double> y1 = sqrt (-p);
      const complex<double> y2 = -y1;

      x0 = y0 - a_over_three;
      x1 = y1 - a_over_three;
      x2 = y2 - a_over_three;
      
      return;
    }

  if (p == 0.0)
    {
      const complex<double> y0 = cbrt (-q);

      const complex<double> y1 = j*y0;
      const complex<double> y2 = j2*y0;

      x0 = y0 - a_over_three;
      x1 = y1 - a_over_three;
      x2 = y2 - a_over_three;
      
      return;
    }

  const complex<double> ar = q;
  
  const complex<double> br = -p*p*p*one_over_twenty_seven;
  
  const complex<double> u_cube = resolvent_root_polynomial_degree_three_calc (ar , br);

  const complex<double> u = cbrt (u_cube);
  
  const complex<double> v = -p*one_third/u;

  const complex<double> y0 = u + v;

  const complex<double> y1 = j*u + j2*v;

  const complex<double> y2 = j2*u + j*v;

  x0 = y0 - a_over_three;
  x1 = y1 - a_over_three;
  x2 = y2 - a_over_three;

  const double inf_norm_x0 = inf_norm (x0);
  const double inf_norm_x1 = inf_norm (x1);
  const double inf_norm_x2 = inf_norm (x2);

  if ((inf_norm_x0 <= inf_norm_x1) && (inf_norm_x0 <= inf_norm_x2))
    x0 = -c/(x1*x2);
  else if ((inf_norm_x1 <= inf_norm_x0) && (inf_norm_x1 <= inf_norm_x2))
    x1 = -c/(x0*x2);
  else
    x2 = -c/(x0*x1);
}









// Roots of a polynomial of degree four
// ------------------------------------
// One has P(x) = x^4 + a.x^3 + b.x^2 + c.x + d .
// Roots are x0, x1, x2 and x3.
// The d=0 case is treated first.
// Standard analytical formulas are used with Q(x) = x^4 + p.x^2 + q.x + r, obtained after the Tschirnaus transformation of P(x).
// Cases for which q=0 and r=0 are treated separately.
// Complex version only.
// The third-degree resolvent of the quartic equation is m^3 + ar.m^2 + br.m + cr with ar = p, br = p^2/4 - r and cr = -q^2/8.
// Its solution of largest infinite norm is used for numerical stability.
// The root of P(x) of smallest infinite norm is recalculated from x0.x1.x2.x3 = d for stability.
// Numerical cancellation is minimized.


complex<double> resolvent_root_polynomial_degree_four_calc (
							    const complex<double> &ar ,
							    const complex<double> &br ,
							    const complex<double> &cr)
{
  complex<double> x0 = 0.0;
  complex<double> x1 = 0.0;
  complex<double> x2 = 0.0;

  roots_polynomial_degree_three (ar , br , cr , x0 , x1 , x2);

  const double inf_norm_x0 = inf_norm (x0);
  const double inf_norm_x1 = inf_norm (x1);
  const double inf_norm_x2 = inf_norm (x2); 
      
  if ((inf_norm_x0 > inf_norm_x1) && (inf_norm_x0 > inf_norm_x2))
    return x0;
  else if ((inf_norm_x1 > inf_norm_x0) && (inf_norm_x1 > inf_norm_x2))
    return x1;
  else
    return x2;
}




void roots_polynomial_degree_four (
				   const complex<double> &a , 
				   const complex<double> &b , 
				   const complex<double> &c ,
				   const complex<double> &d ,
				   complex<double> &x0 , 
				   complex<double> &x1 , 
				   complex<double> &x2 , 
				   complex<double> &x3)
{ 
  if (d == 0.0)
    {
      x0 = 0.0;

      roots_polynomial_degree_three (a , b , c , x1 , x2 , x3);
      
      return;
    }

  const complex<double> a_over_four = 0.25*a;

  const complex<double> a2 = a*a; 
  const complex<double> a3 = a*a2; 
  const complex<double> a4 = a*a3;
  
  const complex<double> p = b - 0.375*a2;

  const complex<double> q = 0.125*a3 - 0.5*a*b + c;

  const complex<double> r = -0.01171875*a4 + d - 0.25*a*c + 0.0625*a2*b;

  if (r == 0.0)
    {
      const complex<double> y0 = 0.0;

      complex<double> y1 , y2 , y3;
    
      roots_polynomial_degree_three (0.0 , p , q , y1 , y2 , y3);

      x0 = y0 - a_over_four;
      x1 = y1 - a_over_four;
      x2 = y2 - a_over_four;
      x3 = y3 - a_over_four;

      return;
    }

  if (q == 0.0)
    {
      complex<double> y0_2 = 0.0;
      complex<double> y2_2 = 0.0;	

      roots_polynomial_degree_two (p , r , y0_2 , y2_2);

      const complex<double> y0 = sqrt (y0_2) , y1 = -y0;
      const complex<double> y2 = sqrt (y2_2) , y3 = -y2;
    
      x0 = y0 - a_over_four;
      x1 = y1 - a_over_four;
      x2 = y2 - a_over_four;
      x3 = y3 - a_over_four;

      return;
    }

  const complex<double> p2 = p*p;
  const complex<double> q2 = q*q;
  
  const complex<double> ar = p;

  const complex<double> br = 0.25*p2 - r; 
  
  const complex<double> cr = -0.125*q2;

  const complex<double> m = resolvent_root_polynomial_degree_four_calc (ar , br , cr);

  const complex<double> S2 = 0.5*m;
  
  const complex<double> S = sqrt (S2);
  
  const complex<double> minus_four_S2_minus_two_p = -4.0*S2 - 2.0*p;
  
  const complex<double> q_over_S = q/S;
      
  const complex<double> Delta_plus  = minus_four_S2_minus_two_p + q_over_S , half_sqrt_Delta_plus  = 0.5*sqrt (Delta_plus);
  const complex<double> Delta_minus = minus_four_S2_minus_two_p - q_over_S , half_sqrt_Delta_minus = 0.5*sqrt (Delta_minus);
    
  const complex<double> y0 = -S + half_sqrt_Delta_plus  , y1 = -S - half_sqrt_Delta_plus;
  const complex<double> y2 =  S + half_sqrt_Delta_minus , y3 =  S - half_sqrt_Delta_minus;
      
  x0 = y0 - a_over_four;
  x1 = y1 - a_over_four;
  x2 = y2 - a_over_four;
  x3 = y3 - a_over_four;

  const double inf_norm_x0 = inf_norm (x0);
  const double inf_norm_x1 = inf_norm (x1);
  const double inf_norm_x2 = inf_norm (x2);
  const double inf_norm_x3 = inf_norm (x3);

  if ((inf_norm_x0 <= inf_norm_x1) && (inf_norm_x0 <= inf_norm_x2) && (inf_norm_x0 <= inf_norm_x3))
    x0 = d/(x1*x2*x3);
  else if ((inf_norm_x1 <= inf_norm_x0) && (inf_norm_x1 <= inf_norm_x2) && (inf_norm_x1 <= inf_norm_x3))
    x1 = d/(x0*x2*x3);
  else if ((inf_norm_x2 <= inf_norm_x0) && (inf_norm_x2 <= inf_norm_x1) && (inf_norm_x2 <= inf_norm_x3))
    x2 = d/(x0*x1*x3);
  else
    x3 = d/(x0*x1*x2);
}






// Dispersion of a statistical value from its statistical sum and sum of squares
// -----------------------------------------------------------------------------
// It is sigma = sqrt[(\sum_{i=1}^{N} (x_i - <x>)^2)/(N - 1)] for N >= 2, with <x> = (\sum_{i=1}^{N} x_i)/N.
// sigma = 0 for N <= 1 by definition.
// It is calculated from the statistical sum S = \sum_{i=1}^{N} x_i and the statistical squares sum SQ = \sum_{i=1}^{N} (x_i)^2.
// One has then: sigma = sqrt[(SQ - (S^2)/N)/(N-1)].

double statistical_sigma_calc (
			       const unsigned int N ,
			       const double statistical_sum ,
			       const double statistical_squares_sum)
{
  if (N <= 1) return 0.0;
    
  const double statistical_sigma = sqrt (abs (statistical_squares_sum - statistical_sum*statistical_sum/N)/(N - 1.0));

  return statistical_sigma;
}







// Determination of the first and last index to consider in a table when parallel computation is used
// --------------------------------------------------------------------------------------------------
// One considers a one-dimensional table of N elements to be calculated. They have to be distributed as evenly as possible among the available processes.
//
// This routine is supposed to be used by all processes independently of each other.
// The process is an MPI process , OpenMP is not considered here.
//
// If the table dimension is smaller than the number of processes , each process smaller than table dimension considers one table component : first.index = last.index = process. 
// The remaining processes must not be used , so that N is returned in this case. 
// The boolean function is_process_active_for_MPI returns true in the first case and false in the last case.
// 
// If the table dimension is larger than the number of processes , one considers x = N/Nprocesses. 
// The first n processes will have x + 1 elements and the last Nprocesses - n processes will have x elements. One has n = N - x.Nprocesses.
// 
// If process is smaller than n , first.index = (x + 1).process and last.index = first.index + x.
// If process is equal to n , first.index = process + x.process and last.index = first.index + x - 1.
// If process is larger than n , first.index = n + x.process and last.index = first.index + x - 1.
//
// The function basic_process_dimension_determine_for_MPI return the number of elements to treat by the process , which is x , x + 1 , or zero if the process is inactive.
//
// Variables
// -------- - 
// N : table dimension
// process : considered process index to determine indices
// group_processes_number : number of processes considered in the routine.
// x : N/group_processes_number , 
// n : N-x.group_processes_number , 

unsigned long int basic_first_index_determine_for_MPI (const unsigned long int N , const unsigned int group_processes_number , const unsigned int process)
{
  if (!is_it_MPI_parallelized) return 0;

  if (N <= group_processes_number)
    {
      const unsigned int first_index = (process < N) ? (process) : (N);

      return first_index;
    }
  else
    {
      const unsigned int x = N/group_processes_number , n = N%group_processes_number;

      const unsigned long int first_index = (process < n) ? (process + x * process) : (n + x * process);

      return first_index;
    }
}




unsigned long int basic_last_index_determine_for_MPI (const unsigned long int N , const unsigned int group_processes_number , const unsigned int process)
{
  if (!is_it_MPI_parallelized) return (N - 1);

  if (N <= group_processes_number)
    {
      const unsigned int last_index = (process < N) ? (process) : (N);

      return last_index;
    }
  else
    {
      const unsigned int x = N/group_processes_number , n = N%group_processes_number;

      const unsigned long int last_index = (process < n) ? (process + x * process + x) : (n + x * process + (x - 1));

      return last_index;
    }
}




// Determination if an MPI process is active according to the dimension of the table
// ---------------------------------------------------------------------------------
// One returns true if one does not use MPI parallelization as all nodes calculate independently in this case.
// They must not be idle then.
// Otherwise, if the dimension of the table is smaller then the number of MPI ranks, the last nodes have to be idle.

bool is_process_active_for_MPI (
				const unsigned long int N ,
				const unsigned int process)
{
  if (!is_it_MPI_parallelized) return true;

  return (process < N);
}



// Determination of the number of elements (process dimension) that an active process has to handle for MPI transfer
// -----------------------------------------------------------------------------------------------------------------
// N is returned without MPI parallelization as all nodes work independently therein.

unsigned int basic_process_dimension_determine_for_MPI  (
							 const unsigned long int N ,
							 const unsigned int group_processes_number ,
							 const unsigned int process)
{
  if (!is_it_MPI_parallelized) 
    return N;
  else if (process >= N)
    return 0;
  else if (N <= group_processes_number) 
    return 1;
  else
    {
      const unsigned int x = N/group_processes_number , n = N%group_processes_number;

      const unsigned int process_dimension = (process < n) ? (x + 1) : (x);

      return process_dimension;
    }
}



// Determination of the active process for MPI transfer according to the value of its index
// ----------------------------------------------------------------------------------------
// It is the process for which the considered index lies between the process first index and the process last index of a given table.

unsigned int basic_active_process_determine_for_MPI (
						     const unsigned long int N ,
						     const unsigned int group_processes_number ,
						     const unsigned long int index)
{
  unsigned int active_process = group_processes_number;

  for (unsigned int process = 0 ; process < group_processes_number ; process++)
    {
      const unsigned long int debut_index = basic_first_index_determine_for_MPI (N , group_processes_number , process);
      const unsigned long int last_index = basic_last_index_determine_for_MPI (N , group_processes_number , process);

      if ((index >= debut_index) && (index <= last_index)) active_process = process;
    }

  if (active_process == group_processes_number) error_message_print_abort ("Wrong process value in basic_active_process_determine_for_MPI.");

  return active_process;
}



// Indices for Richardson interpolation array
// ------------------------------------------
// One uses an array of 28 values to interpolate with the Richardson extrapolation, indexed by n <= 7 and i < n
// Indices are hard coded here.

unsigned int Richardson_interpolation_index (const unsigned int n , const unsigned int i)
{
  switch (n)
    {
    case 1: 
      {
	switch (i)
	  {
	  case 0: return 0;
	  default: abort_all ();
	  }
      } break;

    case 2: 
      {
	switch (i)
	  {
	  case 0: return 1;
	  case 1: return 2;
	  default: abort_all ();
	  }
      } break;

    case 3: 
      {
	switch (i)
	  {
	  case 0: return 3;
	  case 1: return 4;
	  case 2: return 5;
	  default: abort_all ();
	  }
      } break;

    case 4: 
      {
	switch (i)
	  {
	  case 0: return 6;
	  case 1: return 7;
	  case 2: return 8;
	  case 3: return 9;
	  default: abort_all ();
	  }
      } break;

    case 5: 
      {
	switch (i)
	  {
	  case 0: return 10;
	  case 1: return 11;
	  case 2: return 12;
	  case 3: return 13;
	  case 4: return 14;
	  default: abort_all ();
	  }
      } break;

    case 6: 
      {
	switch (i)
	  {
	  case 0: return 15;
	  case 1: return 16;
	  case 2: return 17;
	  case 3: return 18;
	  case 4: return 19;
	  case 5: return 20;
	  default: abort_all ();
	  }
      } break;

    case 7: 
      {
	switch (i)
	  {
	  case 0: return 21;
	  case 1: return 22;
	  case 2: return 23;
	  case 3: return 24;
	  case 4: return 25;
	  case 5: return 26;
	  case 6: return 27;
	  default: abort_all ();
	  }
      } break;

    default: abort_all ();
    }
   
  return NADA;
}

// Automatic calculation of k peak in Berggren basis contours for HFB calculations
// -------------------------------------------------------------------------------
complex<double> k_peak_calc (const complex<double> &k_res , const double kmax)
{
  if (real (k_res) == 0.0)
    return 0.333333333333333*kmax;
  else 
    {
      const double Re_k_peak = real (k_res) , abs_Im_k_peak = min (max (5.0*abs (imag (k_res)) , 0.1) , Re_k_peak);

      return complex<double> (Re_k_peak , -0.99999*abs_Im_k_peak);
    }
}


// Calculation of the A-dependent factor equal to 1 + A_dependent_factor_core_potential.(N-Z)/A
// --------------------------------------------------------------------------------------------
double A_dependent_factor_core_potential_calc (const enum particle_type particle , const int Z , const int A , const double A_dependence_alpha_core_potential)
{
  if (A_dependence_alpha_core_potential == 0.0) return 1.0;

  if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron only in A_dependent_factor_core_potential_calc");

  const int N = A - Z;

  const int sign = (particle == PROTON) ? (1) : (-1);
  
  const double A_dependent_factor_core_potential = 1.0 + A_dependence_alpha_core_potential*sign*(N - Z)/static_cast<double> (A);
  
  return A_dependent_factor_core_potential;
}



// Calculation of the A-dependent factor equal to ((A(core) + 2)/A)^A_dependence_exponent 
// --------------------------------------------------------------------------------------
double TBME_A_dependent_factor_calc (const int A_core , const int A , const double A_dependence_exponent)
{
  if (A_dependence_exponent == 0.0) return 1.0;

  const double TBME_A_dependent_factor = pow ((A_core + 2.0)/static_cast<double> (A) , A_dependence_exponent);
  
  return TBME_A_dependent_factor;
}



// One-dimensional index of an upper triangular matrix of dimension N
// ------------------------------------------------------------------
// It is: 0 1 3 6 10 ...
//          2 4 7 11 ...
//            5 8 12 ...
//              9 13 ...
//                14 ...
//
// One must have i <= j.
// The formula is ij_index = i + j(j+1)/2.
//
// One can also calculate the (i,j) indices associated to the upper triangular index ij_index.

// For this, one uses bisection, knowing that 0 <= j <= N-1.
// One looks for j_debut and j_end so that:
// upper_triangular_index_calc (0 , j_debut) - ij_index <= 0
// upper_triangular_index_calc (0 , j_end) - ij_index >= 0.
// Thus, j = j_end if upper_triangular_index_calc (0 , j_end) == ij_index and j = j_debut otherwise.
//
// i0 means that one uses i=0 in the bisection search.
// The upper triangular indices for i=0, j=j_debut/j_middle/j_end are denoted i0_j_debut/j_middle/j_end_index.
//
// i is immediate from ij_index and j.
//
// No tests are made in routines.

unsigned int upper_triangular_index_calc (const unsigned int i , const unsigned int j)
{
  const unsigned int ij_index = (j%2 == 0) ? (i + (j/2)*(j + 1)) : (i + j*((j + 1)/2));

  return ij_index;
}

unsigned int row_index_from_upper_triangular_index_calc (const unsigned int N , const unsigned int ij_index)
{
  const unsigned int j = column_index_from_upper_triangular_index_calc (N , ij_index);

  const unsigned int i = (j%2 == 0) ? (ij_index - (j/2)*(j + 1)) : (ij_index - j*((j + 1)/2));
  
  return i;
}

unsigned int column_index_from_upper_triangular_index_calc (const unsigned int N , const unsigned int ij_index)
{
  unsigned int j_debut = 0;
  
  unsigned int j_end = N - 1;
    
  bool is_i0_j_debut_index_larger_than_ij_index = false;
     
  do
    {
      const unsigned int j_middle = j_debut + (j_end - j_debut)/2;

      const bool is_i0_j_middle_index_larger_than_ij_index = (upper_triangular_index_calc (0 , j_middle) >= ij_index);
            
      if (is_i0_j_debut_index_larger_than_ij_index != is_i0_j_middle_index_larger_than_ij_index)
	j_end = j_middle;
      else
	{
	  j_debut = j_middle;
	  
	  is_i0_j_debut_index_larger_than_ij_index = is_i0_j_middle_index_larger_than_ij_index;
	}
    }
  while (j_end - j_debut > 1);

  const unsigned int i0_j_end_index = upper_triangular_index_calc (0 , j_end);

  if (ij_index >= i0_j_end_index)
    return j_end;
  else
    return j_debut;
}





// Returns zero if a given complex number has a negative real part. The initial complex number is returned if the real part is positive or zero. 

double delta_positive_real_part (const double x)
{
  const double x_plus = max (x , 0.0);

  return x_plus;
}

complex<double> delta_positive_real_part (const complex<double> &x)
{
  if (real (x) >= 0.0)
    return x;
  else
    return 0.0;
}


