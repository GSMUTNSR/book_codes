#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
    cout << "Memory test" << endl;
    cout << "-----------" << endl;
   
    const int *const p = NULL;
    
    const bool x0 = true;

    const signed char x1 = 0;

    const wchar_t x2 = 0;

    const unsigned char x3 = 0;

    const unsigned short int x4 = 0;

    const unsigned int x5 = 0;

    const unsigned long int x6 = 0;

    const char x7 = 0;

    const short int x8 = 0;

    const int x9 = 0;

    const long int x10 = 0;

    const float x11 = M_PI;

    const double x12 = M_PI;

    const long double x13 = M_PI;

    const complex<float> x14(M_PI,M_PI);

    const complex<double> x15(M_PI,M_PI);

    const complex<long double> x16(M_PI,M_PI);

    const string x17 = "abcdef";
    
    cout << "bool size:" <<  sizeof (bool) << endl;
    cout << "wchar_t size:" <<  sizeof (wchar_t) << endl << endl;
    cout << "char size:" <<  sizeof (char) << endl;
    cout << "short int size:" <<  sizeof (short int) << endl;
    cout << "int size:" <<  sizeof (int) << endl;
    cout << "long int size:" <<  sizeof (long int) << endl;
    cout << "long long int size:" <<  sizeof (long long int) << endl << endl;
    cout << "unsigned char size:" <<  sizeof (unsigned char) << endl;
    cout << "unsigned short int size:" <<  sizeof (unsigned short int) << endl;
    cout << "unsigned int size:" <<  sizeof (unsigned int) << endl;
    cout << "unsigned long int size:" <<  sizeof (unsigned long int) << endl;
    cout << "unsigned long long int size:" <<  sizeof (unsigned long long int) << endl << endl;
    cout << "float size:" <<  sizeof (float) << endl;
    cout << "double size:" <<  sizeof (double) << endl;
    cout << "long double size:" <<  sizeof (long double) << endl << endl;
    cout << "complex float size:" <<  sizeof (complex<float>) << endl;
    cout << "complex double size:" <<  sizeof (complex<double>) << endl;
    cout << "complex long double size:" <<  sizeof (complex<long double>) << endl;

    cout << endl;

    cout << "pointer              : "  << used_memory_calc (p)   << endl;
    cout << "bool                 : "  << used_memory_calc (x0)  << endl;
    cout << "signed char          : "  << used_memory_calc (x1)  << endl;
    cout << "wchar_t              : "  << used_memory_calc (x2)  << endl;
    cout << "unsigned char        : "  << used_memory_calc (x3)  << endl;
    cout << "unsigned short int   : "  << used_memory_calc (x4)  << endl;
    cout << "unsigned int         : "  << used_memory_calc (x5)  << endl;
    cout << "unsigned long int    : "  << used_memory_calc (x6)  << endl;
    cout << "char                 : "  << used_memory_calc (x7)  << endl;
    cout << "short int            : "  << used_memory_calc (x8)  << endl;
    cout << "int                  : "  << used_memory_calc (x9)  << endl;
    cout << "long int             : "  << used_memory_calc (x10) << endl;
    cout << "float                : "  << used_memory_calc (x11) << endl;
    cout << "double               : "  << used_memory_calc (x12) << endl;
    cout << "long double          : "  << used_memory_calc (x13) << endl;
    cout << "complex<float>       : "  << used_memory_calc (x14) << endl;
    cout << "complex<double>      : "  << used_memory_calc (x15) << endl;
    cout << "complex<long double> : "  << used_memory_calc (x16) << endl;
    cout << "string               : "  << used_memory_calc (x17) << endl;

    cout << endl;

    if (SIGN(-2) != -1)         error_message_print_abort ("Problem with SIGN = -1 (int)");
    if (SIGN(5) != 1)           error_message_print_abort ("Problem with SIGN =  1 (int)");	
    if (SIGN(-M_PI) != -1)      error_message_print_abort ("Problem with SIGN = -1 (double)");
    if (SIGN(3.56 + M_PI) != 1) error_message_print_abort ("Problem with SIGN =  1 (double)");

    const double R0 = 3.04;

    const double d = 0.65;
    const double r = 1.76;
    
    const complex<double> z(1 , 2);
    
    const complex<double> k(1.0 , -0.1);

    if (inf_norm (z_log_z (z) - z*log(z)) > precision) error_message_print_abort ("Problem with z_log_z");
    
    if (inf_norm (z_log_z (0.0)) > precision) error_message_print_abort ("Problem with z_log_z");

    if (make_int (-1.0) != -1) error_message_print_abort ("Problem with make_int");

    if (make_uns_int (1.0) != 1) error_message_print_abort ("Problem with make_uns_int");

    if (make_uns_short_int (1.0) != 1) error_message_print_abort ("Problem with make_uns_short_int");

    if (make_uns_char (1.0) != 1) error_message_print_abort ("Problem with make_uns_char");

    if (minus_one_pow (-5.0) != -1) error_message_print_abort ("Problem with minus_one_pow");

    if (minus_one_pow (6.0) != 1) error_message_print_abort ("Problem with minus_one_pow");

    for (int i = 0 ; i <= 21 ; i++)
      {
	const double j = 0.5*i;
	if (inf_norm (hat (j) - sqrt (2.0*j + 1.0)) > precision) error_message_print_abort ("Problem with hat");
      }

    if (inf_norm (Fermi_like_function_der (R0 , d , r) - (Fermi_like_function (R0 , d , r + sqrt_precision) - Fermi_like_function (R0 , d , r - sqrt_precision))/(2.0*sqrt_precision) ) > sqrt_precision)
      error_message_print_abort ("Problem with Fermi_like_function or Fermi_like_function_der");

    if (inf_norm (Fermi_like_function_2der (R0 , d , r) - (Fermi_like_function_der (R0 , d , r + sqrt_precision) - Fermi_like_function_der (R0 , d , r - sqrt_precision))/(2.0*sqrt_precision) ) > sqrt_precision)
      error_message_print_abort ("Problem with Fermi_like_function_der or Fermi_like_function_2der");  

    if (inf_norm (Fermi_like_function_3der (R0 , d , r) - (Fermi_like_function_2der (R0 , d , r + sqrt_precision) - Fermi_like_function_2der (R0 , d , r - sqrt_precision))/(2.0*sqrt_precision) ) > sqrt_precision)
      error_message_print_abort ("Problem with Fermi_like_function_2der or Fermi_like_function_3der");  
    
    double x0_d = 1.33;
    double F0_d = M_PI;
    
    double x1_d = 2.56;
    double F1_d = M_PI + 3.45;
    
    double x2_d = 5.67;
    double F2_d = M_PI + 5.87;
      
    const double dx1_d = x1_d - x0_d;
    const double dx2_d = x2_d - x0_d;
  
    if (inf_norm (three_point_derivative (x0_d , F0_d , x1_d , F1_d , x2_d , F2_d) - (dx2_d*dx2_d*F1_d - dx1_d*dx1_d*F2_d - (dx2_d*dx2_d - dx1_d*dx1_d)*F0_d)/((dx2_d - dx1_d)*dx1_d*dx2_d)) > precision)
      error_message_print_abort ("Problem with three_point_derivative (double)");
  
    complex<double> x0_c(1.33 , 0.6);
    complex<double> F0_c(M_PI , 7.867);
    
    complex<double> x1_c(2.56        , 4.56);
    complex<double> F1_c(M_PI + 3.45 , 5.87);

    complex<double> x2_c(5.67        , 3.76);    
    complex<double> F2_c(M_PI + 5.87 , 4.76);

    complex<double> x3_c = 0.0;
    
    const complex<double> dx1_c = x1_c - x0_c;
    const complex<double> dx2_c = x2_c - x0_c;
    
    if (inf_norm (three_point_derivative (x0_c , F0_c , x1_c , F1_c , x2_c , F2_c) - (dx2_c*dx2_c*F1_c - dx1_c*dx1_c*F2_c - (dx2_c*dx2_c - dx1_c*dx1_c)*F0_c)/((dx2_c - dx1_c)*dx1_c*dx2_c)) > precision)
      error_message_print_abort ("Problem with three_point_derivative (complex)");
 
    const double b =  4.0;
    const double c = -5.0;

    const double c_for_zero_Delta = 0.25*b*b + 1E-14;
    
    roots_polynomial_degree_two (b , c , x0_d , x1_d);
    
    if (inf_norm (x0_d*x0_d + b*x0_d + c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_two (double)");
    if (inf_norm (x1_d*x1_d + b*x1_d + c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_two (double)");
    
    roots_polynomial_degree_two (b , 0.0 , x0_d , x1_d);
    
    if (inf_norm (x0_d*x0_d + b*x0_d) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_two (c=0 double)");
    if (inf_norm (x1_d*x1_d + b*x1_d) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_two (c=0 double)");

    roots_polynomial_degree_two (b , c_for_zero_Delta , x0_d , x1_d);
    
    if (inf_norm (x0_d*x0_d + b*x0_d + c_for_zero_Delta) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_two (Delta=0 double)");
    if (inf_norm (x1_d*x1_d + b*x1_d + c_for_zero_Delta) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_two (Delta=0 double)");
    
    const complex<double> a_c(2.0  , -0.6);
    const complex<double> b_c(4.0  , -0.2);
    const complex<double> c_c(-5.0 , -0.3);
    const complex<double> d_c(-3.2 ,  0.7);

    const complex<double> b_for_p_zero_c = a_c*a_c/3.0;

    const complex<double> c_for_q_zero_c = -7.4074074074074074E-2*a_c*a_c*a_c + a_c*b_c/3.0;

    const complex<double> c_for_q_zero_quartic_c = -0.125*a_c*a_c*a_c + 0.5*a_c*b_c;

    const complex<double> d_for_r_zero_quartic_c = 0.01171875*a_c*a_c*a_c*a_c + 0.25*a_c*c_c - 0.0625*a_c*a_c*b_c;
    
    roots_polynomial_degree_two (b_c , c_c , x0_c , x1_c);
    
    if (inf_norm (x0_c*x0_c + b_c*x0_c + c_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_two (complex)");
    if (inf_norm (x1_c*x1_c + b_c*x1_c + c_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_two (complex)");

    roots_polynomial_degree_two (b_c , 0.0 , x0_c , x1_c);
    
    if (inf_norm (x0_c*x0_c + b_c*x0_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_two (c=0 complex)");
    if (inf_norm (x1_c*x1_c + b_c*x1_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_two (c=0 complex)");

    roots_polynomial_degree_three (a_c , b_c , c_c , x0_c , x1_c , x2_c);
    
    if (inf_norm (x0_c*x0_c*x0_c + a_c*x0_c*x0_c + b_c*x0_c + c_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_three");
    if (inf_norm (x1_c*x1_c*x1_c + a_c*x1_c*x1_c + b_c*x1_c + c_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_three");
    if (inf_norm (x2_c*x2_c*x2_c + a_c*x2_c*x2_c + b_c*x2_c + c_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_three");

    roots_polynomial_degree_three (a_c , b_c , 0.0 , x0_c , x1_c , x2_c);
    
    if (inf_norm (x0_c*x0_c*x0_c + a_c*x0_c*x0_c + b_c*x0_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_three (c=0)");
    if (inf_norm (x1_c*x1_c*x1_c + a_c*x1_c*x1_c + b_c*x1_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_three (c=0)");
    if (inf_norm (x2_c*x2_c*x2_c + a_c*x2_c*x2_c + b_c*x2_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_three (c=0)");

    roots_polynomial_degree_three (a_c , b_for_p_zero_c , c_c , x0_c , x1_c , x2_c);
    
    if (inf_norm (x0_c*x0_c*x0_c + a_c*x0_c*x0_c + b_for_p_zero_c*x0_c + c_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_three (p=0)");
    if (inf_norm (x1_c*x1_c*x1_c + a_c*x1_c*x1_c + b_for_p_zero_c*x1_c + c_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_three (p=0)");
    if (inf_norm (x2_c*x2_c*x2_c + a_c*x2_c*x2_c + b_for_p_zero_c*x2_c + c_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_three (p=0)");
       
    roots_polynomial_degree_three (a_c , b_c , c_for_q_zero_c , x0_c , x1_c , x2_c);
    
    if (inf_norm (x0_c*x0_c*x0_c + a_c*x0_c*x0_c + b_c*x0_c + c_for_q_zero_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_three (q=0)");
    if (inf_norm (x1_c*x1_c*x1_c + a_c*x1_c*x1_c + b_c*x1_c + c_for_q_zero_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_three (q=0)");
    if (inf_norm (x2_c*x2_c*x2_c + a_c*x2_c*x2_c + b_c*x2_c + c_for_q_zero_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_three (q=0)");
       
    roots_polynomial_degree_four (a_c , b_c , c_c , d_c , x0_c , x1_c , x2_c , x3_c);
    
    if (inf_norm (x0_c*x0_c*x0_c*x0_c + a_c*x0_c*x0_c*x0_c + b_c*x0_c*x0_c + c_c*x0_c + d_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_four");
    if (inf_norm (x1_c*x1_c*x1_c*x1_c + a_c*x1_c*x1_c*x1_c + b_c*x1_c*x1_c + c_c*x1_c + d_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_four");
    if (inf_norm (x2_c*x2_c*x2_c*x2_c + a_c*x2_c*x2_c*x2_c + b_c*x2_c*x2_c + c_c*x2_c + d_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_four");
    if (inf_norm (x3_c*x3_c*x3_c*x3_c + a_c*x3_c*x3_c*x3_c + b_c*x3_c*x3_c + c_c*x3_c + d_c) > precision) error_message_print_abort ("Problem with x3 in roots_polynomial_degree_four");

    roots_polynomial_degree_four (a_c , b_c , c_c , 0.0 , x0_c , x1_c , x2_c , x3_c);
    
    if (inf_norm (x0_c*x0_c*x0_c*x0_c + a_c*x0_c*x0_c*x0_c + b_c*x0_c*x0_c + c_c*x0_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_four (d=0)");
    if (inf_norm (x1_c*x1_c*x1_c*x1_c + a_c*x1_c*x1_c*x1_c + b_c*x1_c*x1_c + c_c*x1_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_four (d=0)");
    if (inf_norm (x2_c*x2_c*x2_c*x2_c + a_c*x2_c*x2_c*x2_c + b_c*x2_c*x2_c + c_c*x2_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_four (d=0)");
    if (inf_norm (x3_c*x3_c*x3_c*x3_c + a_c*x3_c*x3_c*x3_c + b_c*x3_c*x3_c + c_c*x3_c) > precision) error_message_print_abort ("Problem with x3 in roots_polynomial_degree_four (d=0)");

    roots_polynomial_degree_four (a_c , b_c , c_for_q_zero_quartic_c , d_c , x0_c , x1_c , x2_c , x3_c);
    
    if (inf_norm (x0_c*x0_c*x0_c*x0_c + a_c*x0_c*x0_c*x0_c + b_c*x0_c*x0_c + c_for_q_zero_quartic_c*x0_c + d_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_four (q=0)");
    if (inf_norm (x1_c*x1_c*x1_c*x1_c + a_c*x1_c*x1_c*x1_c + b_c*x1_c*x1_c + c_for_q_zero_quartic_c*x1_c + d_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_four (q=0)");
    if (inf_norm (x2_c*x2_c*x2_c*x2_c + a_c*x2_c*x2_c*x2_c + b_c*x2_c*x2_c + c_for_q_zero_quartic_c*x2_c + d_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_four (q=0)");
    if (inf_norm (x3_c*x3_c*x3_c*x3_c + a_c*x3_c*x3_c*x3_c + b_c*x3_c*x3_c + c_for_q_zero_quartic_c*x3_c + d_c) > precision) error_message_print_abort ("Problem with x3 in roots_polynomial_degree_four (q=0)");
    
    roots_polynomial_degree_four (a_c , b_c , c_c , d_for_r_zero_quartic_c , x0_c , x1_c , x2_c , x3_c);
    
    if (inf_norm (x0_c*x0_c*x0_c*x0_c + a_c*x0_c*x0_c*x0_c + b_c*x0_c*x0_c + c_c*x0_c + d_for_r_zero_quartic_c) > precision) error_message_print_abort ("Problem with x0 in roots_polynomial_degree_four (r=0)");
    if (inf_norm (x1_c*x1_c*x1_c*x1_c + a_c*x1_c*x1_c*x1_c + b_c*x1_c*x1_c + c_c*x1_c + d_for_r_zero_quartic_c) > precision) error_message_print_abort ("Problem with x1 in roots_polynomial_degree_four (r=0)");
    if (inf_norm (x2_c*x2_c*x2_c*x2_c + a_c*x2_c*x2_c*x2_c + b_c*x2_c*x2_c + c_c*x2_c + d_for_r_zero_quartic_c) > precision) error_message_print_abort ("Problem with x2 in roots_polynomial_degree_four (r=0)");
    if (inf_norm (x3_c*x3_c*x3_c*x3_c + a_c*x3_c*x3_c*x3_c + b_c*x3_c*x3_c + c_c*x3_c + d_for_r_zero_quartic_c) > precision) error_message_print_abort ("Problem with x3 in roots_polynomial_degree_four (r=0)");

    const unsigned int N = 10;

    for (unsigned int j = 0 ; j < N ; j++)
      for (unsigned int i = 0 ; i <= j ; i++)
	{
	  const unsigned int ij_index = upper_triangular_index_calc (i , j);
	  
	  if (i != row_index_from_upper_triangular_index_calc (N , ij_index)) error_message_print_abort ("Problem with upper_triangular_index_calc or row_index_from_upper_triangular_index_calc");
	  
	  if (j != column_index_from_upper_triangular_index_calc (N , ij_index)) error_message_print_abort ("Problem with upper_triangular_index_calc or column_index_from_upper_triangular_index_calc");	  
	}
        

    cout << "All tests are successful" << endl; 
        
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

