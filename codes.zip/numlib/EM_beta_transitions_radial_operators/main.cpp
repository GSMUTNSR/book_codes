#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    const unsigned int nmax = 1100;

    const int A = 8;

    const int Z_daughter = 3;

    const double W0 = 16;

    const enum beta_pm_type beta_pm = BETA_PLUS;
    	
    double Fermi_integral_quasi_exact = 0.0;

    const unsigned int N = 4000;
    
    class array<double> W_tab_large(N);
    
    class array<double> W_weights_tab_large(N);
	
    Gauss_Legendre::abscissas_weights_tables_calc (1.0 , W0 , W_tab_large , W_weights_tab_large);
      
    for (unsigned int i = 0 ; i < N ; i++) Fermi_integral_quasi_exact += beta_transitions_Fermi_integrand_part_calc (beta_pm , A , Z_daughter , W0 , W_tab_large(i))*W_weights_tab_large(i);
    
    for (unsigned int n = 0 ; n <= nmax ; n += N/100)
      {
	if (n == 0) continue;
	
	class array<double> Fermi_integrand_tab(n);

	class array<double> W_tab(n);

	class array<double> W_weights_tab(n);
	
	Gauss_Legendre::abscissas_weights_tables_calc (1.0 , W0 , W_tab , W_weights_tab);

	double Fermi_integral = 0.0;
	  
	for (unsigned int i = 0 ; i < n ; i++) Fermi_integral += beta_transitions_Fermi_integrand_part_calc (beta_pm , A , Z_daughter , W0 , W_tab(i))*W_weights_tab(i);

	cout << n << " " << Fermi_integral << " " << abs (1.0 - Fermi_integral/Fermi_integral_quasi_exact) << endl;
      }
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

