#include "../numlib_def/numlib_def.h"

using namespace string_routines;
using namespace angular_matrix_elements;


// Simple functions for EM transitions
// -----------------------------------

// EM suboperator binary parity determine
unsigned int BP_EM_suboperator_determine (
					  const enum EM_suboperator_type EM_suboperator ,
					  const int L)
{
  switch (EM_suboperator)
    {
    case ELECTRIC_CHARGE                                      : return binary_parity_from_orbital_angular_momentum (L);
    case ELECTRIC_CHARGE_YL                                   : return binary_parity_from_orbital_angular_momentum (L);
    case ELECTRIC_CHARGE_YL_TENSOR_E                          : return binary_parity_from_orbital_angular_momentum (L + 1);
    case ELECTRIC_CURRENT                                     : return binary_parity_from_orbital_angular_momentum (L);
    case ELECTRIC_CURRENT_YL_TENSOR_S                         : return binary_parity_from_orbital_angular_momentum (L);
    case MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1                 : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1                 : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_GRADIENT_BESSEL_LP1                    : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_GRADIENT_BESSEL_LM1                    : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1 : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1 : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_S_SCALAR_E                             : return binary_parity_from_orbital_angular_momentum (L + 1);
    case MAGNETIC_SPIN_YL_TENSOR_S                            : return binary_parity_from_orbital_angular_momentum (L);
    default: abort_all ();
    }

  return NADA;
}

// EM binary parity determine
unsigned int BP_EM_determine (
			      const enum EM_type EM ,
			      const int L)
{
  switch (EM)
    {
    case ELECTRIC : return binary_parity_from_orbital_angular_momentum (L);
    case MAGNETIC : return binary_parity_from_orbital_angular_momentum (L + 1);
    default       : abort_all ();
    }

  return NADA;
}






// Calculation of F and F' by power series.
// ----------------------------------------
// One calculates here the Riccati-Bessel functions and derivatives with power series
// It is used only when |x| <= 1,to avoid numerical inaccuracies.
//
// F(x) = Cl.x^(l + 1).\sum a[n],n in [0: + oo[,where :
// a[0] = 1.0.
// a[1] = 0.0
// a[n] = (- a[n - 2].(x^2))/(n.(n + 2l + 1)),n >= 2.
//
// The x = 0 case is treated first.
// Cl is the Gamow factor equal to 2^l Gamma (l+1)/Gamma (2l+2) .
//
// Variables
// ---------
// l: orbital angular momentum
// x : variable of the Riccati-Bessel function
// F,dF : regular wave function and derivative
// l_plus_one, l_plus_two, two_l_plus_one: l+1, l+2, 2l + 1
// Cl: Gamow factor for normalization, equal to 2^l Gamma (l+1)/Gamma (2l+2) 
// x_square : x^2
// n : index of the power series term. It begins at two.
// an,an_minus_one,an_minus_two : a[n],a[n - 1],a[n - 2].
// an_n_plus_l_plus_one: an.(n + l + 1)
// test: The test of convergence is |(n + l -1).a[n - 2]|oo + |(n + l).a[n - 1]|oo, as one of the two can be zero even before convergence.
// Cl_x_pow_l_plus_one: Cl.x^(l+1)

void EM_transitions_F_power_series (
				    const int l , 
				    const complex<double> &z , 
				    complex<double> &F , 
				    complex<double> &dF)
{
  const int l_plus_one = l + 1;
  const int l_plus_two = l + 2;
  const int two_l_plus_one = 2*l + 1;

  const double Cl = pow (2.0 , l)*exp (lgamma (l_plus_one) - lgamma (two_l_plus_one + 1));

  if (z == 0.0)
    {
      F = 0.0;
      dF = (l == 0) ? (Cl) : (0.0);
      return;
    }

  const complex<double> z_square = z*z;

  int n = 2;
  complex<double> an_minus_two = 1.0;
  complex<double> an_minus_one = 0.0;

  F = an_minus_two + an_minus_one;

  dF = l_plus_one*an_minus_two + l_plus_two*an_minus_one;

  double test = 0.0;

  do 
    {
      const double n_plus_l = n+l;
      
      const complex<double> an = (-an_minus_two*z_square)/(n*(n + two_l_plus_one));
      
      const complex<double> an_n_plus_l_plus_one = an*(n_plus_l + 1);

      F += an;
      dF += an_n_plus_l_plus_one;

      n++;
      an_minus_two = an_minus_one;
      an_minus_one = an;
      test = inf_norm (an_minus_two) + inf_norm (an_minus_one);
    }
  while (test > precision);

  const complex<double> Cl_x_pow_l_plus_one = Cl*pow (z , l_plus_one);

  F *= Cl_x_pow_l_plus_one;
  dF *= Cl_x_pow_l_plus_one/z;
}





// Calculation of th Hankel functions H(omega) and dH(omega)/dz (scaled) with asymptotic series
// --------------------------------------------------------------------------------------------
// H[omega](z) = exp[i.omega.[z - l.Pi/2]].S[omega](z) for Re[z] >= 0.
// H[omega]'(z) = exp[i.omega.[z - l.Pi/2]].[S[omega]'(z) + i.omega.(1 - eta/z).S[omega](z)] for Re[z] >= 0.
//
// S[omega](z) is the terminating asymptotic series and S[omega]'(z) its derivative calculated in asymptotic_series.
//
// Variables
// ---------
// l: orbital angular momentum
// omega : 1 if one calculates H+(z) and H+'(z), -1 if one calculates H-(z) and H-'(z).
// x : variable of the Hankel function
// H_omega_scaled, dH_omega_scaled : H[omega](z).exp(-i.omega.z) and H[omega]'(z).exp(-i.omega.z).
// one_over_x : 1/x.
// ll_plus_one : l.(l + 1);
// sum, dsum : {S[omega](z), S[-omega](z)} and {S[omega]'(z), S[-omega]'(z)}
// an: term of the asymptotic series S[omega](z)
// n_plus_one: n + 1, with n the index of the term of the asymptotic series S[omega](z)
// omega_one_over_two_I_n_plus_one: omega/(2i(n+1))
// Fn: factor of the next term of the asymptotic series S[omega](z) equal to (n(n+1) - l(l+1))/x . omega/(2i(n+1))
// I_omega : i.omega
// exp_phase_shift : exp (-i.omega.l.Pi/2)

void EM_transitions_asymptotic_expansion_H_omega_scaled (
							 const int l , 
							 const int omega , 
							 const complex<double> &z , 
							 complex<double> &H_omega_scaled , 
							 complex<double> &dH_omega_scaled)
{
  const complex<double> one_over_z = 1.0/z;
  
  const int ll_plus_one = l*(l + 1);
  
  complex<double> sum = 1.0 , dsum = 0.0 , an = 1.0;

  for (int n = 0 ; n < l ; n++)
    {
      const double n_plus_one = n + 1.0;
      
      const complex<double> omega_one_over_two_I_n_plus_one = (omega == 1) ? (complex<double> (0 , -0.5/n_plus_one)) : (complex<double> (0 , 0.5/n_plus_one));
      
      const complex<double> Fn = one_over_z*(n*n_plus_one - ll_plus_one)*omega_one_over_two_I_n_plus_one;

      an *= Fn;
      sum += an;
      dsum -= (n+1)*an*one_over_z;
    }

  const complex<double> I_omega(0 , omega);
  
  const complex<double> exp_phase_shift = exp (-I_omega*l*M_PI_2);

  H_omega_scaled = sum*exp_phase_shift;
  
  dH_omega_scaled = (dsum + sum*I_omega)*exp_phase_shift;
}


// Calculation of F and F'
// -----------------------
// One calculates here the Riccati-Bessel functions and derivatives.  
// One uses power series if |x| <= 1 and terminating asymptotic series otherwise.
// The method is stable for all x parameters
//
// Variables
// ---------
// l: orbital angular momentum
// x : variable of the Riccati-Bessel function
// F,dF : regular wave function and derivative
// H_plus_scaled, dH_plus_scaled : H+(z).exp(-i.z) and H+'(z).exp(-i.z)
// H_minus_scaled, dH_minus_scaled : H-(z).exp(i.z) and H-'(z).exp(i.z)
// one_over_two_I, Ix: 1/(2i), i.x
// exp_Ix, exp_minus_Ix: exp (i.x), exp (-i.x)

void EM_transitions_F_dF (
			  const int l , 
			  const complex<double> &z , 
			  complex<double> &F , 
			  complex<double> &dF)
{
  if (abs (z) <= 1) 
    EM_transitions_F_power_series (l , z , F , dF);
  else
    { 
      complex<double> Hplus_scaled  , dHplus_scaled;
      complex<double> Hminus_scaled , dHminus_scaled;
      
      EM_transitions_asymptotic_expansion_H_omega_scaled (l ,  1 , z , Hplus_scaled , dHplus_scaled);
      EM_transitions_asymptotic_expansion_H_omega_scaled (l , -1 , z , Hminus_scaled , dHminus_scaled);

      const complex<double> one_over_two_I(0.0 , -0.5) , Iz(-imag (z) , real(z));
      
      const complex<double> exp_Iz = exp (Iz);
      
      const complex<double> exp_minus_Iz = 1.0/exp_Iz;

      F  = (Hplus_scaled*exp_Iz   - Hminus_scaled*exp_minus_Iz)*one_over_two_I;
      dF = (dHplus_scaled*exp_Iz - dHminus_scaled*exp_minus_Iz)*one_over_two_I;
    }
}

// Calculation of the radial form factor of the electromagnetic transition
// -----------------------------------------------------------------------
// One calculates here the radial form factor entering electromagnetic transition for a fixed part of it (electric charge, current, or magnetic orbital or spin part with [Y(L +/- 1) x l or s]^L)
// Normed means that one multiplies Bessel functions by the factor equal to (2L + 1)!!/(L + 1)/(q^L).
//
// Here are radial the suboperators formulas with and without long-wavelength approximation.
// One first writes the formula without long-wavelength approximation.
// Long-wavelength approximation is written second (after ------). One writes 0 if the term vanishes with long-wavelength approximation.
// LP1 and LM1 mean L+1 and L-1, as it is this orbital angular momentum which enters spherical harmonics in the considered suboperator.
// A few suboperators enter only GSM-CC for cluster radiative capture. It is precised.
//
// OVERLAP: 1 (GSM-CC cluster radiative capture)
//
// RICCATI_BESSEL: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . \hat{jL}(qr) , with r=r_int
//
// RICCATI_BESSEL_R: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . r . \hat{jL}(qr) , with r=r_int
//
// RICCATI_BESSEL_OVER_R: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . \hat{jL}(qr)/r , with r=r_int
//
// BESSEL_R: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . r . \hat{jL}(qr), with r=r_int
//
// ELECTRIC_CURRENT_RADIAL
// (2L+1)!!/(q^L . (L+1)) . \hat{jL}(qr)/r ------ 0 
//
// MAGNETIC_SPIN_S_SCALAR_E_RADIAL (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . q . \hat{jL}(qr) ------ 0 , with r=r_int
//
// GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1: 
// (2L+1)!!/(q^L . (L+1)) . (q.(L(L+1)/((qr)^2) - 1) \hat{jL}(qr) - L.\hat{jL'}(qr))/r ------ 0
//
// GRADIENT_BESSEL_LP1: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . (\hat{jL'}(qr) - (L+1).\hat{jL}(qr)/qr)/r ------ 0 , with r=r_int
//
// RICCATI_BESSEL_DERIVATIVE: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . \hat{jL'}(qr)/r ------ r^L , with r=r_int
//
// ELECTRIC_CHARGE_RADIAL:
// (2L+1)!!/(q^L . (L+1)) . [\hat{jL'}(qr) + (qr)/2 \hat{jL}(qr)] ------ r^L
//
// BESSEL: (GSM-CC cluster radiative capture)
// (2L+1)!!/(q^L . (L+1)) . \hat{jL}(qr)/(qr) ------ r^L/(L+1) , with r=r_int
//
// GRADIENT_BESSEL_LM1:
// (2L+1)!!/(q^L . (L+1)) . (\hat{jL'}(qr) + L.\hat{jL}(qr)/qr)/r ------ r^(L-1) . (2L+1)/(L+1) 
//
// GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1: 
// (2L+1)!!/(q^L . (L+1)) . (q.(L(L+1)/((qr)^2) - 1) \hat{jL}(qr) + (L+1).\hat{jL'}(qr))/r ------ r^(L-1) . (2L+1)
// 
//
// Variables
// ---------
// radial_operator: considered electromagnetic transition radial operator. It has to be consistent with electromagnetic-transition radial integration.
// q: linear momentum of the emitted photon. It is equal to (E_in - E_out)/(hbar c), with E_in and E_out the energies of the in and out many-body states. One takes q->0 with long-wavelength approximation.
// L: orbital angular momentum of the electromagnetic transition (L=1 for M1, E1, L=2 for E2 ...)
// is_it_longwavelength_approximation: true if long-wavelength approximation is used, false if not
// factor: (2L + 1)!!/(L + 1)/(q^L)
// Bessel: class Coulomb_wave_functions to calculate Bessel functions
// r: radius 

complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator , 
						const complex<double> &q , 
						const int L , 
						const bool is_it_longwavelength_approximation ,
						const complex<double> &z ,
						const complex<double> &normed_JL ,
						const complex<double> &normed_dJL)
{
  const complex<double> qz = q*z;

  switch (radial_operator)
    {
    case OVERLAP                                : return 1.0;
      
    case RICCATI_BESSEL                         : return (!is_it_longwavelength_approximation) ? (normed_JL)   : (0.0);
    case RICCATI_BESSEL_R                       : return (!is_it_longwavelength_approximation) ? (normed_JL*z) : (0.0);
    case RICCATI_BESSEL_OVER_R                  : return (!is_it_longwavelength_approximation) ? (normed_JL/z) : (0.0);   
    case MAGNETIC_SPIN_S_SCALAR_E_RADIAL        : return (!is_it_longwavelength_approximation) ? (q*normed_JL) : (0.0);
    case BESSEL_R                               : return (!is_it_longwavelength_approximation) ? (normed_JL*z) : (0.0);
    case ELECTRIC_CURRENT_RADIAL                : return (!is_it_longwavelength_approximation) ? (normed_JL/z) : (0.0);
      
    case GRADIENT_BESSEL_LP1                    : return (!is_it_longwavelength_approximation) ? ((normed_dJL - (L+1)*normed_JL/qz)/z) : (0.0);
    case GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1 : return (!is_it_longwavelength_approximation) ? (q*(L*(L+1)/(qz*qz) - 1)*normed_JL - L*normed_dJL/z) : (0.0);
      
    case RICCATI_BESSEL_DERIVATIVE              : return (!is_it_longwavelength_approximation) ? (normed_dJL)                    : (pow (z , L));
    case BESSEL                                 : return (!is_it_longwavelength_approximation) ? (normed_JL/qz)                  : (pow (z , L)/(L+1));
    case ELECTRIC_CHARGE_RADIAL                 : return (!is_it_longwavelength_approximation) ? (normed_dJL + 0.5*qz*normed_JL) : (pow (z , L));
      
    case GRADIENT_BESSEL_LM1                    : return (!is_it_longwavelength_approximation) ? ((normed_dJL + L*normed_JL/qz)/z)                        : (pow (z , L-1)*(2*L+1.0)/(L+1.0));
    case GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1 : return (!is_it_longwavelength_approximation) ? (q*(L*(L+1)/(qz*qz) - 1)*normed_JL + (L+1)*normed_dJL/z) : (pow (z , L-1)*(2*L+1.0));
      
    default                                     : abort_all ();
    }

  return NADA;
}


double EM_transitions_radial_operator (
				       const enum radial_operator_type radial_operator , 
				       const double q , 
				       const int L , 
				       const bool is_it_longwavelength_approximation ,
				       const double factor , 
				       const double z)
{
  return real (EM_transitions_radial_operator (radial_operator , complex<double> (q) , L , is_it_longwavelength_approximation , complex<double> (factor), complex<double> (z)));
}



complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator , 
						const complex<double> &q , 
						const int L , 
						const bool is_it_longwavelength_approximation ,
						const complex<double> &factor , 
						const complex<double> &z)
{
  const complex<double> qz = q*z;

  complex<double> normed_JL  = 0.0;
  complex<double> normed_dJL = 0.0;

  if (!is_it_longwavelength_approximation) 
    {
      EM_transitions_F_dF (L , qz , normed_JL , normed_dJL);

      normed_JL  *= factor;
      normed_dJL *= factor;
    }

  return EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , z , normed_JL , normed_dJL);
}



double EM_transitions_radial_operator (
				       const enum radial_operator_type radial_operator ,
				       const double q , 
				       const int L ,  
				       const bool is_it_longwavelength_approximation , 
				       const double factor , 
				       class Coulomb_wave_functions &Bessel , 
				       const double z)

{
  return real (EM_transitions_radial_operator (radial_operator , complex<double> (q) , L , is_it_longwavelength_approximation , complex<double> (factor), Bessel , complex<double> (z)));
}


complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator ,
						const complex<double> &q , 
						const int L ,  
						const bool is_it_longwavelength_approximation , 
						const complex<double> &factor , 
						class Coulomb_wave_functions &Bessel , 
						const complex<double> &z)

{
  const complex<double> qz = q*z;

  complex<double> normed_JL  = 0.0;
  complex<double> normed_dJL = 0.0;

  if (!is_it_longwavelength_approximation) 
    {
      Bessel.F_dF (qz , normed_JL , normed_dJL);

      normed_JL *= factor;
      normed_dJL *= factor;
    }
  
  return EM_transitions_radial_operator (radial_operator , q , L , is_it_longwavelength_approximation , z , normed_JL , normed_dJL);
}





// Calculation of electric and magnetic reduced one-body matrix element with and without long-wavelength approximation
// -------------------------------------------------------------------------------------------------------------------
// The radial matrix element has been already calculated. It it multiplied by its angular part here.
// Electric and magnetic operators are separated in their different parts here, called suboperators.
// Long-wavelength approximation can be used or not.
// One-body matrix elements are always reduced in j.
//
// Here are the suboperators formulas with and without long-wavelength approximation.
// One first writes the formula without long-wavelength approximation.
// Long-wavelength approximation is written second (after ------). One writes 0 if the term vanishes with long-wavelength approximation.
// LP1 and LM1 mean L+1 and L-1, as it is this orbital angular momentum which enters spherical harmonics in the considered suboperator.
// A few suboperators enter only GSM-CC for cluster radiative capture. It is precised.
// Lc is an additional quantum number for cluster radiative capture in GSM-CC. It must not be used otherwise.
//
// double and complex versions are provided.
//
// ELECTRIC_CHARGE
// effective_charge . YL . (2L+1)!!/(q^L . (L+1)) [\hat{jL'}(qr) + (qr)/2 \hat{jL}(qr)] ------ effective_charge . YL . r^L
//
// ELECTRIC_CHARGE_YL (GSM-CC cluster radiative capture)
// effective_charge . YL . (2L+1)!!/(q^L . (L+1)) [\hat{jL'}(qr) + (qr)/2 \hat{jL}(qr)] ------ effective_charge . YL . r^L , with r=r_int
//
// ELECTRIC_CHARGE_YL_TENSOR_E (GSM-CC cluster radiative capture)
// sqrt(4Pi /3) [YLc x Y1]^L . (2L+1)!!/(q^L . (L+1)) [\hat{jL'}(qr) + (qr)/2 \hat{jL}(qr)] ------ effective_charge . YL . r^L, with r=r_int (e is  sqrt(4Pi /3) Y1)
//
// ELECTRIC_CURRENT
// mu_s . (\vec{l} . \vec{s}) . YL . (2L+1)!!/(q^L . (L+1)) \hat{jL}(qr)/r ------ 0 
//
// ELECTRIC_CURRENT_YL_TENSOR_S (GSM-CC cluster radiative capture)
// mu_s . [YLc x s]^L . (2L+1)!!/(q^L . (L+1)) \hat{jL}(qr) ------ 0  , with r=r_int
//
// MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1
// -2 . mu_l . sqrt ((L + 1)/(2L + 1)) . [Y(L+1) x l]^L . (2L+1)!!/(q^L . (L+1)) . (\hat{jL'}(qr) - (L+1).\hat{jL}(qr)/qr)/r ------ 0 
//
// MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1
//  2 . mu_l . sqrt (L/(2L + 1)) . [Y(L-1) x l]^L . (2L+1)!!/(q^L . (L+1)) . (\hat{jL'}(qr) + L.\hat{jL}(qr)/qr)/r ------ 2 . mu_l . sqrt (L.(2L + 1))/(L+1) . [Y(L-1) x l]^L . r^(L-1)
//
// MAGNETIC_SPIN_GRADIENT_BESSEL_LP1 (GSM-CC cluster radiative capture)
// -mu_s . sqrt ((L + 1)/(2L + 1)) . [Y(L+1) x s]^L . (\hat{jL'}(qr) - (L+1).\hat{jL}(qr)/qr)/r ------ 0 , with r=r_int
//
// MAGNETIC_SPIN_GRADIENT_BESSEL_LM1 (GSM-CC cluster radiative capture) 
// mu_s . sqrt (L/(2L + 1)) . [Y(L-1) x s]^L . (\hat{jL'}(qr) +L.\hat{jL}(qr)/qr)/r ------ mu_s . sqrt (L.(2L + 1))/(L+1) . [Y(L-1) x s]^L . r^(L-1) , with r=r_int
// 
// MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1
// -mu_s . sqrt ((L + 1)/(2L + 1)) . [Y(L+1) x s]^L . (2L+1)!!/(q^L . (L+1)) . ((L(L+1)/((qr)^2) - 1) \hat{jL}(qr) - L.\hat{jL'}(qr))/r ------ 0
//
// MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1
// mu_s . sqrt (L/(2L + 1)) . [Y(L-1) x s]^L . (2L+1)!!/(q^L . (L+1)) . ((L(L+1)/((qr)^2) - 1) \hat{jL}(qr) + (L+1).\hat{jL'}(qr))/r ------ mu_s . sqrt (L.(2L + 1)) . [Y(L-1) x s]^L . r^(L-1)
//
// MAGNETIC_SPIN_S_SCALAR_E (GSM-CC cluster radiative capture)
// mu_s . (\vec{s} . \vec{e}) . YL . (2L+1)!!/(q^L . (L+1)) . q . \hat{jL}(qr) ------ 0 , with r=r_int
//
// MAGNETIC_SPIN_YL_TENSOR_S (GSM-CC cluster radiative capture)
// mu_s . [YLc x s]^L . \hat{jL}(qr)/r ------ 0 , with r=r_int
//
// Variables
// ---------
// EM_suboperator: part of operator entering electromagnetic transitions. They are detailed above.
// L: orbital angular momentum of the electromagnetic transition (L=1 for M1, E1, L=2 for E2 ...)
// Lc: additional orbital angular momentum of cluster radiative capture in GSM-CC. They are induced by recoupling formulas between LCM and l_int.
// particle: proton or neutron
// effective_charge: effective charge for electric transitions. It is not used in magnetic transitions.
// radial_OBME: radial integral of the one-body matrix element of the radial operator written above.
// l_in, j_in, l_out, j_out: orbital and total angular momenta for the in and out states of the matrix element
// mu_l, mu_s: orbital and spin gyromagnetic ratios of the particle
// Y1_norm_factor: sqrt(4Pi /3) (e is sqrt(4Pi /3) Y1)
// YL_reduced, YLc_tensor_e_reduced, YLc_tensor_s_reduced: reduced matrix elements <j_out || YL || j_in>,  <j_out || [YLc x e]^L || j_in>,  <j_out || [YLc x s]^L || j_in>
// l_scalar_s_out: (\vec{l} . \vec{s}) applied to the out state. It is (j_out.(j_out + 1) - l_out.(l_out + 1) - s(s+1))/2
// current_reduced_angular: reduced matrix elements <j_out || (\vec{l} . \vec{s}) YL || j_in>
// YLP1_tensor_l_reduced, YLM1_tensor_l_reduced: reduced matrix elements <j_out || [Y(L+1) x l]^L || j_in>, <j_out || [Y(L-1) x l]^L || j_in>
// YLP1_tensor_s_reduced, YLM1_tensor_s_reduced: reduced matrix elements <j_out || [Y(L+1) x s]^L || j_in>, <j_out || [Y(L-1) x s]^L || j_in>
// l_expansion: l issued from the l expansion inserted between (\vec{s} . \vec{e}) and YL used to calculate the matrix element <j_out || (\vec{s} . \vec{e}) . YL || j_in>.
//              It is equal to l_out+1 if j_out = l_out + 1/2 and l_out - 1 if j_out = l_out - 1/2.
// s_scalar_e_reduced_part: <l_out j_out || (\vec{s} . \vec{e}) . YL || l_expansion j_out> matrix element issued from the l expansion inserted between (\vec{s} . \vec{e}) and YL
// OBME: total one-body matrix element <j_out || EM || j_in> in all cases. Returned value.


double EM_suboperator_angular_OBME_reduced_effective_charge_calc (
								  const enum EM_suboperator_type EM_suboperator , 
								  const int L , 
								  const int Lc , 
								  const enum particle_type particle , 
								  const double effective_charge , 
								  const int l_in , 
								  const double j_in , 
								  const int l_out , 
								  const double j_out)
{
  const double mu_l = mu_l_determine (particle);
  const double mu_s = mu_s_determine (particle);
	
  switch (EM_suboperator)
    {      
    case ELECTRIC_CHARGE:
      {
	const double YL_reduced = OBME_YL_reduced_in_j (L , l_in , j_in , l_out , j_out);
	
	const double OBME = YL_reduced*effective_charge;
				
	return OBME;
      }

    case ELECTRIC_CHARGE_YL:
      {
	const double YL_reduced = OBME_YL_reduced_in_j (L , l_in , j_in , l_out , j_out);
	
	const double OBME = YL_reduced*effective_charge;

	return OBME;
      }

    case ELECTRIC_CHARGE_YL_TENSOR_E:
      {
	const double Y1_norm_factor = 2.046653415892977;
	
	const double YLc_tensor_e_reduced = Y1_norm_factor*YL1_tensor_YL2_reduced_in_j (Lc , 1 , L , l_in , j_in , l_out , j_out);
	
	const double OBME = YLc_tensor_e_reduced*effective_charge;

	return OBME;
      }

    case ELECTRIC_CURRENT:
      {
	const double YL_reduced = OBME_YL_reduced_in_j (L , l_in , j_in , l_out , j_out);
	
	const double l_scalar_s_out = (j_out*(j_out + 1) - l_out*(l_out + 1) - 0.75)*0.5;
	
	const double current_reduced_angular = YL_reduced*l_scalar_s_out;
	
	const double OBME = mu_s*current_reduced_angular;

	return OBME;
      }

    case ELECTRIC_CURRENT_YL_TENSOR_S:
      {
	const double YLc_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , Lc , l_in , j_in , l_out , j_out);
	
	const double OBME = mu_s*YLc_tensor_s_reduced;

	return OBME;
      }

    case MAGNETIC_ORBITAL_GRADIENT_BESSEL_LP1:
      {
	const double YLP1_tensor_l_reduced = OBME_YL_tensor_l_reduced_in_j (L , L + 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = -2.0*half_nuclear_magneton*mu_l*sqrt ((L + 1.0)/(2.0*L + 1.0))*YLP1_tensor_l_reduced;

	return OBME;
      }

    case MAGNETIC_ORBITAL_GRADIENT_BESSEL_LM1:
      {
	const double YLM1_tensor_l_reduced = OBME_YL_tensor_l_reduced_in_j (L , L - 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = 2.0*half_nuclear_magneton*mu_l*sqrt (L/(2.0*L + 1.0))*YLM1_tensor_l_reduced;
	
	return OBME;
      }

    case MAGNETIC_SPIN_GRADIENT_BESSEL_LP1:
      {
	const double YLP1_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , L + 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = -half_nuclear_magneton*mu_s*sqrt ((L + 1.0)/(2.0*L + 1.0))*YLP1_tensor_s_reduced;

	return OBME;
      }

    case MAGNETIC_SPIN_GRADIENT_BESSEL_LM1:
      {
	const double YLM1_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , L - 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = half_nuclear_magneton*mu_s*sqrt (L/(2.0*L + 1.0))*YLM1_tensor_s_reduced;

	return OBME;
      }

    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LP1:
      {
	const double YLP1_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , L + 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = -half_nuclear_magneton*mu_s*sqrt ((L + 1.0)/(2.0*L + 1.0))*YLP1_tensor_s_reduced;

	return OBME;
      }

    case MAGNETIC_SPIN_GRADIENT_RICCATI_BESSEL_DERIVATIVE_LM1:
      {
	const double YLM1_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , L - 1 , l_in , j_in , l_out , j_out);
	
	const double OBME = half_nuclear_magneton*mu_s*sqrt (L/(2.0*L + 1.0))*YLM1_tensor_s_reduced;

	return OBME;
      }

    case MAGNETIC_SPIN_S_SCALAR_E:
      {
	const int l_expansion = (rint (j_out - l_out - 0.5) == 0.0) ? (l_out + 1) : (l_out - 1);

	const double s_scalar_e_reduced_part = OBME_s_scalar_e_reduced_in_j (l_expansion , j_out , l_out , j_out);
	
	const double YL_reduced_part = OBME_YL_reduced_in_j (L , l_in , j_in , l_expansion , j_out);

	const double OBME = half_nuclear_magneton*mu_s*s_scalar_e_reduced_part*YL_reduced_part/hat (j_out);

	return OBME;
      }

    case MAGNETIC_SPIN_YL_TENSOR_S:
      {
	const double YL_tensor_s_reduced = OBME_YL_tensor_s_reduced_in_j (L , Lc , l_in , j_in , l_out , j_out);
	
	const double OBME = half_nuclear_magneton*mu_s*YL_tensor_s_reduced;

	return OBME;
      }

    default: abort_all ();
    }

  return NADA;
}







double EM_suboperator_OBME_reduced_calc (
					 const enum EM_suboperator_type EM_suboperator , 
					 const int L , 
					 const int Lc , 
					 const enum particle_type particle , 
					 const double effective_charge , 
					 const double radial_OBME , 
					 const int l_in , 
					 const double j_in , 
					 const int l_out , 
					 const double j_out)
{
  const double angular_OBME = EM_suboperator_angular_OBME_reduced_effective_charge_calc (EM_suboperator , L , Lc , particle , effective_charge , l_in , j_in , l_out , j_out);
  
  const double OBME = angular_OBME*radial_OBME;
				
  return OBME;
}









complex<double> EM_suboperator_OBME_reduced_calc (
						  const enum EM_suboperator_type EM_suboperator , 
						  const int L , 
						  const int Lc , 
						  const enum particle_type particle , 
						  const double effective_charge , 
						  const complex<double> &radial_OBME , 
						  const int l_in , 
						  const double j_in , 
						  const int l_out , 
						  const double j_out)
{
  const double angular_OBME = EM_suboperator_angular_OBME_reduced_effective_charge_calc (EM_suboperator , L , Lc , particle , effective_charge , l_in , j_in , l_out , j_out);
  
  const complex<double> OBME = angular_OBME*radial_OBME;
				
  return OBME;
}









// Simple functions for beta transitions
// -------------------------------------

// beta suboperator binary parity determine
unsigned int BP_beta_suboperator_determine (const enum beta_suboperator_type beta_suboperator)
{
  switch (beta_suboperator)
    {
    case FERMI_ALLOWED        : return 0;
    case GAMOW_TELLER_ALLOWED : return 0;

    case W_FFBD               : return 1;
    case U_FFBD               : return 1;
    case Z_FFBD               : return 1;
    case X_FFBD               : return 1;

    case W_FFBD_COULOMB       : return 1;
    case U_FFBD_COULOMB       : return 1;
    case X_FFBD_COULOMB       : return 1;

    case XI_PRIME_V_FFBD      : return 1;
    case XI_PRIME_Y_FFBD      : return 1;

    case SPIN_RADIAL_WUZ_FFBD        : return 0;
    case RADIAL_X_FFBD               : return 0;
    case SPIN_RADIAL_XI_PRIME_V_FFBD : return 0;
    case RADIAL_XI_PRIME_Y_FFBD      : return 0;

    default: abort_all ();
    }

  return NADA;
}

// beta suboperator rank determine
int rank_beta_suboperator_determine (const enum beta_suboperator_type beta_suboperator)
{
  switch (beta_suboperator)
    {
    case FERMI_ALLOWED        : return 0;
    case GAMOW_TELLER_ALLOWED : return 1;

    case W_FFBD               : return 0;
    case U_FFBD               : return 1;
    case Z_FFBD               : return 2;
    case X_FFBD               : return 1;

    case W_FFBD_COULOMB       : return 0;
    case U_FFBD_COULOMB       : return 1;
    case X_FFBD_COULOMB       : return 1;

    case XI_PRIME_V_FFBD      : return 0;
    case XI_PRIME_Y_FFBD      : return 1;

    case SPIN_RADIAL_WUZ_FFBD        : return 1;
    case RADIAL_X_FFBD               : return 0;
    case SPIN_RADIAL_XI_PRIME_V_FFBD : return 1;
    case RADIAL_XI_PRIME_Y_FFBD      : return 0;

    default: abort_all ();
    }

  return NADA;
}

// beta suboperator constant from relativistic formulas determine
double relativity_constant_beta_suboperator_determine (
						       const enum beta_pm_type beta_pm ,
						       const enum beta_suboperator_type beta_suboperator)
{
  const double SQRT3 = 1.7320508075688773;

  const double beta_ga_gv_sign = beta_sign_determine (beta_pm);

  const double lambda = beta_ga_gv_sign*ga_over_gv_vacuum;
  
  switch (beta_suboperator)
    {
    case FERMI_ALLOWED        : return 1.0;
    case GAMOW_TELLER_ALLOWED : return ga_over_gv;

    case W_FFBD               : return lambda*SQRT3;
    case U_FFBD               : return lambda*M_SQRT2;
    case Z_FFBD               : return -2.0*lambda;
    case X_FFBD               : return -1.0;

    case XI_PRIME_V_FFBD      : return -lambda*SQRT3;
    case XI_PRIME_Y_FFBD      : return 1.0;

    default: abort_all ();
    }

  return NADA;
}

// beta binary parity determine
unsigned int BP_beta_determine (const enum beta_type beta)
{
  switch (beta)
    {
    case ALLOWED         : return 0;

    case FIRST_FORBIDDEN : return 1;

    default              : abort_all ();
    }

  return NADA;
}

//charge radius entering beta transition matrix element
double R_charge_beta_calc (const double A)
{
  const double log_A = log (A);

  const double log_A_square = log_A*log_A;

  const double A_minus_1p76 = A - 1.76;

  const double r0 = 1.614 - 0.1067*log_A + 0.005456*log_A_square + 6.112/(A_minus_1p76*A_minus_1p76);

  const double R_charge = r0*cbrt (A);

  return R_charge;
}

//constant entering beta transition matrix element
double lambda_beta_calc (const double A)
{
  const double lambda = cbrt (A)/Compton_wavelength_electron;

  return lambda;
}

//constant entering beta transition matrix element
double gamma_1_beta_calc (const double Z_daughter)
{
  const double gamma_1 = sqrt (1.0 - fine_struct_const*fine_struct_const*Z_daughter*Z_daughter);

  return gamma_1;
}

//constant entering beta transition matrix element
double xi_beta_calc (const double Z_daughter , const double R_charge)
{
  const double xi = 0.5*fine_struct_const*Z_daughter/R_charge;

  return xi;
}

//Coulomb correction function entering beta transition matrix element (double)
double F_Coulomb_correction_beta_calc (
				       const double R_charge ,
				       const double r)
{
  if (r <= R_charge)
    {
      const double r_over_R_charge = r/R_charge , F_Coulomb_correction_r = 1.0 - 0.2*r_over_R_charge*r_over_R_charge;

      return F_Coulomb_correction_r;
    }
  else
    {
      const double R_charge_over_r = R_charge/r , F_Coulomb_correction_r = R_charge_over_r*(1.0 - 0.2*R_charge_over_r*R_charge_over_r);

      return F_Coulomb_correction_r;
    }
}

//Coulomb correction function entering beta transition matrix element (asymptotic , complex)
complex<double> F_Coulomb_correction_asymptotic_beta_calc (
							   const double R_charge ,
							   const complex<double> &z)
{
  const complex<double> R_charge_over_z = R_charge/z;

  const complex<double> F_Coulomb_correction_z = R_charge_over_z*(1.0 - 0.2*R_charge_over_z*R_charge_over_z);

  return F_Coulomb_correction_z;
}





int Z_IN_beta_determine (
			 const enum beta_pm_type beta_pm ,
			 const int Z_OUT)
{
  switch (beta_pm)
    {
    case BETA_PLUS  : return (Z_OUT + 1);
    case BETA_MINUS : return (Z_OUT - 1);
    default         : abort_all ();
    }

  return NADA;
}

int N_IN_beta_determine (
			 const enum beta_pm_type beta_pm ,
			 const int N_OUT)
{
  switch (beta_pm)
    {
    case BETA_PLUS  : return (N_OUT - 1);
    case BETA_MINUS : return (N_OUT + 1);
    default         : abort_all ();
    }

  return NADA;
}

int beta_sign_determine (const enum beta_pm_type beta_pm)
{
  switch (beta_pm)
    {
    case BETA_PLUS  : return 1;
    case BETA_MINUS : return -1;
    default         : abort_all ();
    }

  return NADA;
}








// Calculation of the radial form factor of the beta transition
// ------------------------------------------------------------
// It is 1 if it is only overlap, as is the case for allowed beta decay, 
// I.r if one has first-forbidden beta decay without Coulomb correction and I.r times this correction with Coulomb correction (see observables_basic_functions.cpp)
// It can be calculated for real or complex (asymptotic region, for complex scaling for example) radii. In the latter case, r is denoted as z.
// The tau operator of the Behrens-Buhring formulas removes the sqrt(2) dependence of the C constant when reducing only in angular momentum.
//
// Variables
// ---------
// radial_operator: considered beta decay radial operator. It has to be consistent with beta-decay radial integration.
// R_charge: charge radius used in the Coulomb correction of first-forbidden beta decay 
// r, z: real or complex radius considered in the radial integral
// F_Coulomb_correction_r, F_Coulomb_correction_z: Coulomb correction of first-forbidden beta decay 
// z_F_Coulomb_correction_z: z.F_Coulomb_correction_z


complex<double> beta_transitions_radial_operator (
						  const enum radial_operator_type radial_operator , 
						  const double R_charge , 
						  const complex<double> &z)
{
  switch (radial_operator)
    {
    case OVERLAP:
      {
	return 1.0;
      }

    case FFBD:
      {
	return z;
      }

    case FFBD_COULOMB:
      {
	const complex<double> F_Coulomb_correction_z = F_Coulomb_correction_asymptotic_beta_calc (R_charge , z);

	const complex<double> z_F_Coulomb_correction_z = z*F_Coulomb_correction_z;

	return z_F_Coulomb_correction_z;
      }

    default: error_message_print_abort ("beta_transitions_radial_operator_z can handle overlap and FFBD Coulomb/not Coulomb corrected radial operators only");
    }

  return NADA;
}

double beta_transitions_radial_operator (
					 const enum radial_operator_type radial_operator , 
					 const double R_charge , 
					 const double z)
{
  return real (beta_transitions_radial_operator (radial_operator , R_charge , complex<double> (z)));
}







// Calculation of the beta transition matrix element for a given suboperator
// -------------------------------------------------------------------------
// Beta transitions are functions of several operators.
// One consider a single operator here, such as Fermi or Gamow-Teller for allowed beta decay,
// or x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction for first-forbidden beta decay.
// The imaginary unit occurring in matrix elements of first-forbidden beta decay is suppressed as it is only a global phase.
// All matrix elements are dimensionless.
//
// double and complex versions are provided.
//
// Variables
// ---------
// beta_suboperator: type of beta suboperator, such as Fermi or Gamow-Teller, x, w, u, z, xi, xi'y and xi'v, with or without Coulomb correction
// radial_OBME: radial one-body matrix element
// l_in, j_in, l_out, j_out: orbital and total angular momenta for the in and out states of the matrix element
// two_sqrt_four_Pi_over_three, sqrt_four_Pi_over_three: 2 sqrt(4 Pi/3), sqrt(4 Pi/3)
// xi_constants_factor: square of the Compton wavelength of the electron times mass of electron for xi'v and xi'u
// wuxz_constants_factor: mass of electron over hbar.c for w,u,x,z and w',u',x' (with Coulomb correction)
// angular_part: reduced angular matrix element of the considered beta_suboperator
// reduced_OBME: total one-body matrix element, product of its angular and radial parts


double beta_suboperator_angular_OBME_reduced_unit_constants_calc (
								  const enum beta_suboperator_type beta_suboperator , 
								  const int l_in , 
								  const double j_in , 
								  const int l_out , 
								  const double j_out)
{
  const double two_sqrt_four_Pi_over_three = 4.093306831785954;

  const double sqrt_four_Pi_over_three = 2.046653415892977;
        
  switch (beta_suboperator)
    {
    case FERMI_ALLOWED:
      {
	const double OBME = (same_lj (l_in , j_in , l_out , j_out)) ? (hat (j_in)) : (0.0);

	return OBME;
      }

    case GAMOW_TELLER_ALLOWED:
      {
	const double OBME = OBME_sigma_reduced_in_j (l_in , j_in , l_out , j_out);

	return OBME;
      }

    case W_FFBD:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (0 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case U_FFBD:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (1 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case Z_FFBD:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (2 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case X_FFBD:
      {
	const double angular_part = sqrt_four_Pi_over_three*OBME_YL_reduced_in_j (1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case W_FFBD_COULOMB:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (0 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case U_FFBD_COULOMB:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (1 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case X_FFBD_COULOMB:
      {
	const double angular_part = sqrt_four_Pi_over_three*OBME_YL_reduced_in_j (1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case XI_PRIME_V_FFBD:
      {
	const double angular_part = two_sqrt_four_Pi_over_three*OBME_YL_tensor_s_reduced_in_j (0 , 1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part*Compton_wavelength_electron*electron_mass/amu;
	
	return reduced_OBME;
      }

    case XI_PRIME_Y_FFBD:
      {
	const double angular_part = sqrt_four_Pi_over_three*OBME_YL_reduced_in_j (1 , l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part*Compton_wavelength_electron*electron_mass/amu;

	return reduced_OBME;
      }

    case SPIN_RADIAL_WUZ_FFBD:
      {
	const double angular_part = sqrt_four_Pi_over_three*OBME_sigma_reduced_in_j (l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case RADIAL_X_FFBD:
      {
	const double reduced_OBME = sqrt_four_Pi_over_three/Compton_wavelength_electron;

	return reduced_OBME;
      }

    case SPIN_RADIAL_XI_PRIME_V_FFBD:
      {
	const double angular_part = sqrt_four_Pi_over_three*OBME_sigma_reduced_in_j (l_in , j_in , l_out , j_out);

	const double reduced_OBME = angular_part*Compton_wavelength_electron*electron_mass/amu;

	return reduced_OBME;
      }

    case RADIAL_XI_PRIME_Y_FFBD:
      {
	const double reduced_OBME = sqrt_four_Pi_over_three*Compton_wavelength_electron*electron_mass/amu;

	return reduced_OBME;
      }

    default: abort_all ();
    }

  return NADA;
}







double beta_suboperator_OBME_reduced_calc (
					   const enum beta_suboperator_type beta_suboperator , 
					   const double radial_OBME ,
					   const int l_in , 
					   const double j_in , 
					   const int l_out , 
					   const double j_out)
{
  const double angular_OBME = beta_suboperator_angular_OBME_reduced_unit_constants_calc (beta_suboperator , l_in , j_in , l_out , j_out);
  
  const double OBME = angular_OBME*radial_OBME;
				
  return OBME;
}



complex<double> beta_suboperator_OBME_reduced_calc (
						    const enum beta_suboperator_type beta_suboperator , 
						    const complex<double> &radial_OBME ,
						    const int l_in , 
						    const double j_in , 
						    const int l_out , 
						    const double j_out)
{
  const double angular_OBME = beta_suboperator_angular_OBME_reduced_unit_constants_calc (beta_suboperator , l_in , j_in , l_out , j_out);
  
  const complex<double> OBME = angular_OBME*radial_OBME;
				
  return OBME;
}










// Calculation of the functions entering first-forbidden beta decay formulas
// -------------------------------------------------------------------------
// Notations are standard. See theory of beta decay for explanations.
// beta_transitions_Fermi_integrand_part_calc calculates the part of the Fermi integrand which is independent of k,ka,kb,kc.
// The integral over available phase space energies is done with Gauss-Legendre integration, using N=1000 points to insure virtually full numerical precision.
// F(Z,W) ~ beta_sign.2.Pi.alpha.Z[daughter]/(exp (beta_sign.2.Pi.alpha.Z[daughter]) - 1.0) for large W
 
double beta_transitions_Fermi_integrand_part_calc (
						   const enum beta_pm_type beta_pm , 
						   const int A , 
						   const int Z_daughter , 
						   const double W0 , 
						   const double W)
{
  const double R_charge = R_charge_beta_calc (A);

  const double lambda = lambda_beta_calc (A);

  const double R_charge_lambda = R_charge*lambda;

  const double gamma_1 = gamma_1_beta_calc (Z_daughter);

  const int beta_sign = beta_sign_determine (beta_pm);

  const double p = sqrt (W*W - 1.0);

  const double W0_minus_W = W0 - W;
      
  const double y = -beta_sign*fine_struct_const*Z_daughter*W/p; //It is -beta_sign ...

  const double FZW1 = 2.0*(1.0 + gamma_1)*pow (2.0*p*R_charge_lambda , -2.0*(1.0 - gamma_1));

  const complex<double> gamma_1_plus_Iy(gamma_1 , y);
  
  const double FZW2 = exp (2.0*real (log_Gamma (gamma_1_plus_Iy) - lgamma (2.0*gamma_1 + 1.0)) + M_PI*y);

  const double FZW = FZW1*FZW2;

  const double Fermi_integrand_part = FZW*W*p*W0_minus_W*W0_minus_W;
  
  return Fermi_integrand_part;
}






double beta_transitions_f_allowed_calc (
					const enum beta_pm_type beta_pm , 
					const int A , 
					const int Z_daughter , 
					const double W0)
{
  const unsigned int N = 1000;

  class array<double> W_GL_tab(N);
  
  class array<double> W_GL_weight_tab(N);

  Gauss_Legendre::abscissas_weights_tables_calc (1.0 , W0 , W_GL_tab , W_GL_weight_tab);

  double f = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double W = W_GL_tab(i);

      const double weight = W_GL_weight_tab(i);

      const double Fermi_integrand_part = beta_transitions_Fermi_integrand_part_calc (beta_pm , A , Z_daughter , W0 , W);

      f += Fermi_integrand_part*weight;
    }

  return f;
}







double beta_transitions_f_first_forbidden_calc (
						const enum beta_pm_type beta_pm , 
						const int A , 
						const int Z_daughter , 
						const double W0 , 
						const double k , 
						const double ka , 
						const double kb , 
						const double kc)
{
  return real (beta_transitions_f_first_forbidden_calc (beta_pm , A , Z_daughter , W0 , complex<double> (k) , complex<double> (ka) , complex<double> (kb) , complex<double> (kc)));
}




complex<double> beta_transitions_f_first_forbidden_calc (
							 const enum beta_pm_type beta_pm , 
							 const int A , 
							 const int Z_daughter , 
							 const double W0 , 
							 const complex<double> &k , 
							 const complex<double> &ka , 
							 const complex<double> &kb , 
							 const complex<double> &kc)
{
  const unsigned int N = 1000;

  class array<double> W_GL_tab(N);
  
  class array<double> W_GL_weight_tab(N);

  Gauss_Legendre::abscissas_weights_tables_calc (1.0 , W0 , W_GL_tab , W_GL_weight_tab);

  complex<double> f = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double W = W_GL_tab(i);

      const double weight = W_GL_weight_tab(i);

      const double Fermi_integrand_part = beta_transitions_Fermi_integrand_part_calc (beta_pm , A , Z_daughter , W0 , W);

      f += Fermi_integrand_part*(k + ka*W + kb/W + kc*W*W)*weight;
    }

  return f;
}






double beta_transitions_k_calc (
				const int A , 
				const int Z_daughter , 
				const double W0 , 
				const double w , 
				const double w_prime , 
				const double x , 
				const double x_prime , 
				const double u , 
				const double u_prime , 
				const double z , 
				const double xi_prime_v , 
				const double xi_prime_y)
{
  return real (beta_transitions_k_calc (A ,
					Z_daughter ,
					W0 ,
					complex<double> (w) , complex<double> (w_prime) ,
					complex<double> (x) , complex<double> (x_prime) ,
					complex<double> (u) , complex<double> (u_prime) ,
					complex<double> (z) ,
					complex<double> (xi_prime_v) ,
					complex<double> (xi_prime_y)));
}

complex<double> beta_transitions_k_calc (
					 const int A , 
					 const int Z_daughter , 
					 const double W0 , 
					 const complex<double> &w , const complex<double> &w_prime , 
					 const complex<double> &x , const complex<double> &x_prime , 
					 const complex<double> &u , const complex<double> &u_prime , 
					 const complex<double> &z , 
					 const complex<double> &xi_prime_v , 
					 const complex<double> &xi_prime_y)
{
  const double R_charge = R_charge_beta_calc (A);
  
  const double gamma_1 = gamma_1_beta_calc (Z_daughter);
  
  const double xi = xi_beta_calc (Z_daughter , R_charge);

  const double mu_1 = 1.0;

  const double lambda_2 = 1.0;

  const complex<double> V = xi_prime_v + xi*w_prime;
  const complex<double> Y = xi_prime_y - xi*(u_prime + x_prime);

  const complex<double> zeta_0 = V + w*W0/3.0;
  const complex<double> zeta_1 = Y + (u - x)*W0/3.0;

  const complex<double> k_part1 = zeta_0*zeta_0 + w*w/9.0 + zeta_1*zeta_1 + (x + u)*(x + u)/9.0;
  
  const complex<double> k_part2 = -mu_1*gamma_1*u*(x + u)*4.0/9.0 + W0*W0*(2.0*x + u)*(2.0*x + u)/18.0;

  const complex<double> k_part3 = -lambda_2*(2.0*x - u)*(2.0*x - u)/18.0 + z*z*(W0*W0 - lambda_2)/12.0;

  const complex<double> k = k_part1 + k_part2 + k_part3;

  return k;
}




double beta_transitions_ka_calc (
				 const int A , 
				 const int Z_daughter , 
				 const double W0 , 
				 const double x , const double x_prime , 
				 const double u , const double u_prime , 
				 const double z , 
				 const double xi_prime_y)
{
  return real (beta_transitions_ka_calc (A ,
					 Z_daughter ,
					 W0 ,
					 complex<double> (x) , complex<double> (x_prime) ,
					 complex<double> (u) , complex<double> (u_prime) ,
					 complex<double> (z) ,
					 complex<double> (xi_prime_y)));
}

complex<double> beta_transitions_ka_calc (
					  const int A , 
					  const int Z_daughter , 
					  const double W0 , 
					  const complex<double> &x , const complex<double> &x_prime , 
					  const complex<double> &u , const complex<double> &u_prime , 
					  const complex<double> &z , 
					  const complex<double> &xi_prime_y)
{
  const double R_charge = R_charge_beta_calc (A);

  const double xi = xi_beta_calc (Z_daughter , R_charge);

  const complex<double> Y = xi_prime_y - xi*(u_prime + x_prime);

  const complex<double> ka = -u*Y*4.0/3.0 + W0*(4.0*x*x + 5.0*u*u)/9.0 - z*z*W0/6.0;

  return ka;
}





double beta_transitions_kb_calc (
				 const int A , 
				 const int Z_daughter , 
				 const double W0 , 
				 const double w , const double w_prime , 
				 const double x , const double x_prime , 
				 const double u , const double u_prime , 
				 const double xi_prime_v , 
				 const double xi_prime_y)
{
  return real (beta_transitions_kb_calc (A ,
					 Z_daughter ,
					 W0 ,
					 complex<double> (w) , complex<double> (w_prime) ,
					 complex<double> (x) , complex<double> (x_prime) ,
					 complex<double> (u) , complex<double> (u_prime) ,
					 complex<double> (xi_prime_v), 
					 complex<double> (xi_prime_y)));
}


complex<double> beta_transitions_kb_calc (
					  const int A , 
					  const int Z_daughter , 
					  const double W0 , 
					  const complex<double> &w , const complex<double> &w_prime , 
					  const complex<double> &x , const complex<double> &x_prime , 
					  const complex<double> &u , const complex<double> &u_prime , 
					  const complex<double> &xi_prime_v , 
					  const complex<double> &xi_prime_y)
{
  const double R_charge = R_charge_beta_calc (A);
  
  const double gamma_1 = gamma_1_beta_calc (Z_daughter);
  
  const double xi = xi_beta_calc (Z_daughter , R_charge);
  
  const double mu_1 = 1.0;

  const complex<double> V = xi_prime_v + xi*w_prime;
  const complex<double> Y = xi_prime_y - xi*(u_prime + x_prime);

  const complex<double> zeta_0 = V + w*W0/3.0;
  const complex<double> zeta_1 = Y + (u - x)*W0/3.0;

  const complex<double> kb = mu_1*gamma_1*(-zeta_0*w + zeta_1*(x + u))*2.0/3.0;

  return kb;
}



double beta_transitions_kc_calc (
				 const double x ,
				 const double u ,
				 const double z)
{
  return real (beta_transitions_kc_calc (complex<double> (x) , complex<double> (u) , complex<double> (z)));
}



complex<double> beta_transitions_kc_calc (
					  const complex<double> &x , 
					  const complex<double> &u , 
					  const complex<double> &z)
{
  const double lambda_2 = 1.0;

  const complex<double> kc = (u*u*8.0 + (2.0*x + u)*(2.0*x + u) + (2.0*x - u)*(2.0*x - u)*lambda_2)/18.0 + z*z*(1.0 + lambda_2)/12.0;

  return kc;
}






