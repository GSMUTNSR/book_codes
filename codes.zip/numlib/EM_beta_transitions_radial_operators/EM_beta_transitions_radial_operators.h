#ifndef EMBETATRANSITIONSRADIALOPERATORS_H
#define EMBETATRANSITIONSRADIALOPERATORS_H


// Simple functions for EM transitions
// -----------------------------------

unsigned int BP_EM_suboperator_determine (const enum EM_suboperator_type EM_suboperator , const int L);

unsigned int BP_EM_determine (const enum EM_type EM , const int L);


// Calculation of the radial form factor of the electromagnetic transition
// -----------------------------------------------------------------------

void EM_transitions_F_power_series (
				    const int l , 
				    const complex<double> &z , 
				    complex<double> &F , 
				    complex<double> &dF);

void EM_transitions_asymptotic_expansion_H_omega_scaled (
							 const int l , 
							 const int omega , 
							 const complex<double> &z , 
							 complex<double> &H_omega_scaled , 
							 complex<double> &dH_omega_scaled);


void EM_transitions_F_dF (
			  const int l , 
			  const complex<double> &z , 
			  complex<double> &F , 
			  complex<double> &dF);

complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator , 
						const complex<double> &q , 
						const int L , 
						const bool is_it_longwavelength_approximation ,
						const complex<double> &z ,
						const complex<double> &normed_JL ,
						const complex<double> &normed_dJL);

double EM_transitions_radial_operator (
				       const enum radial_operator_type radial_operator ,
				       const double q , 
				       const int L ,  
				       const bool is_it_longwavelength_approximation , 
				       const double factor , 
				       const double z);

complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator ,
						const complex<double> &q , 
						const int L ,  
						const bool is_it_longwavelength_approximation , 
						const complex<double> &factor , 
						const complex<double> &z);

double EM_transitions_radial_operator (
				       const enum radial_operator_type radial_operator ,
				       const double q , 
				       const int L ,  
				       const bool is_it_longwavelength_approximation , 
				       const double factor , 
				       class Coulomb_wave_functions &Bessel , 
				       const double z);

complex<double> EM_transitions_radial_operator (
						const enum radial_operator_type radial_operator ,
						const complex<double> &q , 
						const int L ,  
						const bool is_it_longwavelength_approximation , 
						const complex<double> &factor , 
						class Coulomb_wave_functions &Bessel , 
						const complex<double> &z);

// Calculation of electric and magnetic reduced one-body matrix element with and without long-wavelength approximation
// -------------------------------------------------------------------------------------------------------------------

double EM_suboperator_angular_OBME_reduced_effective_charge_calc (
								  const enum EM_suboperator_type EM_suboperator , 
								  const int L , 
								  const int Lc , 
								  const enum particle_type particle , 
								  const double effective_charge , 
								  const int l_in , 
								  const double j_in , 
								  const int l_out , 
								  const double j_out);

double EM_suboperator_OBME_reduced_calc (
					 const enum EM_suboperator_type EM_suboperator , 
					 const int L , 
					 const int Lc , 
					 const enum particle_type particle , 
					 const double effective_charge , 
					 const double radial_OBME , 
					 const int l_in , 
					 const double j_in , 
					 const int l_out , 
					 const double j_out);

complex<double> EM_suboperator_OBME_reduced_calc (
						  const enum EM_suboperator_type EM_suboperator , 
						  const int L , 
						  const int Lc , 
						  const enum particle_type particle , 
						  const double effective_charge , 
						  const complex<double> &radial_OBME , 
						  const int l_in , 
						  const double j_in , 
						  const int l_out , 
						  const double j_out);


// Simple functions for beta transitions
// -------------------------------------

// beta suboperator binary parity determine
unsigned int BP_beta_suboperator_determine (const enum beta_suboperator_type beta_suboperator);

// beta suboperator rank determine
int rank_beta_suboperator_determine (const enum beta_suboperator_type beta_suboperator);

// beta suboperator constant from relativistic formulas determine
double relativity_constant_beta_suboperator_determine (const enum beta_pm_type beta_pm , const enum beta_suboperator_type beta_suboperator);

// beta binary parity determine
unsigned int BP_beta_determine (const enum beta_type beta);

//charge radius entering beta transition matrix element
double R_charge_beta_calc (const double A);

//constant entering beta transition matrix element
double lambda_beta_calc (const double A);

//constant entering beta transition matrix element
double gamma_1_beta_calc (const double Z_daughter);

//constant entering beta transition matrix element
double xi_beta_calc (const double Z_daughter , const double R_charge);

//Coulomb correction function entering beta transition matrix element  (double)
double F_Coulomb_correction_beta_calc (const double R_charge , const double r);

//Coulomb correction function entering beta transition matrix element (asymptotic , complex)
complex<double> F_Coulomb_correction_asymptotic_beta_calc (const double R_charge , const complex<double> &z);

// Z father nucleus determine
int Z_IN_beta_determine (const enum beta_pm_type beta_pm , const int Z_OUT);

// N father nucleus determine
int N_IN_beta_determine (const enum beta_pm_type beta_pm , const int N_OUT);

// Sign of beta +/- transition determine
int beta_sign_determine (const enum beta_pm_type beta_pm);

// Calculation of the radial form factor of the beta transition
// ------------------------------------------------------------

complex<double> beta_transitions_radial_operator (
						  const enum radial_operator_type radial_operator , 
						  const double R_charge , 
						  const complex<double> &z);

double beta_transitions_radial_operator (
					 const enum radial_operator_type radial_operator , 
					 const double R_charge , 
					 const double z);


// Calculation of the beta transition matrix element for a given suboperator
// -------------------------------------------------------------------------

double beta_suboperator_angular_OBME_reduced_unit_constants_calc (
								  const enum beta_suboperator_type beta_suboperator , 
								  const int l_in , 
								  const double j_in , 
								  const int l_out , 
								  const double j_out);

double beta_suboperator_OBME_reduced_calc (
					   const enum beta_suboperator_type beta_suboperator , 
					   const double radial_OBME , 
					   const int l_in , 
					   const double j_in , 
					   const int l_out , 
					   const double j_out);

complex<double> beta_suboperator_OBME_reduced_calc (
						    const enum beta_suboperator_type beta_suboperator , 
						    const complex<double> &radial_OBME , 
						    const int l_in , 
						    const double j_in , 
						    const int l_out , 
						    const double j_out);

// Calculation of the functions entering first-forbidden beta decay formulas
// -------------------------------------------------------------------------

double beta_transitions_Fermi_integrand_part_calc (
						   const enum beta_pm_type beta_pm , 
						   const int A , 
						   const int Z_daughter , 
						   const double W0 , 
						   const double W);

double beta_transitions_f_allowed_calc (
					const enum beta_pm_type beta_pm , 
					const int A , 
					const int Z_daughter , 
					const double W0);

double beta_transitions_f_first_forbidden_calc (
						const enum beta_pm_type beta_pm , 
						const int A , 
						const int Z_daughter , 
						const double W0 , 
						const double k , 
						const double ka , 
						const double kb , 
						const double kc);

complex<double> beta_transitions_f_first_forbidden_calc (
							 const enum beta_pm_type beta_pm , 
							 const int A , 
							 const int Z_daughter , 
							 const double W0 , 
							 const complex<double> &k , 
							 const complex<double> &ka , 
							 const complex<double> &kb , 
							 const complex<double> &kc);

double beta_transitions_k_calc (
				const int A , 
				const int Z_daughter , 
				const double W0 , 
				const double w , 
				const double w_prime , 
				const double x , 
				const double x_prime , 
				const double u , 
				const double u_prime , 
				const double z , 
				const double xi_prime_v , 
				const double xi_prime_y);

complex<double> beta_transitions_k_calc (
					 const int A , 
					 const int Z_daughter , 
					 const double W0 , 
					 const complex<double> &w , const complex<double> &w_prime , 
					 const complex<double> &x , const complex<double> &x_prime , 
					 const complex<double> &u , const complex<double> &u_prime , 
					 const complex<double> &z , 
					 const complex<double> &xi_prime_v , 
					 const complex<double> &xi_prime_y);

double beta_transitions_ka_calc (
				 const int A , 
				 const int Z_daughter , 
				 const double W0 , 
				 const double x , const double x_prime , 
				 const double u , const double u_prime , 
				 const double z , 
				 const double xi_prime_y);

complex<double> beta_transitions_ka_calc (
					  const int A , 
					  const int Z_daughter , 
					  const double W0 , 
					  const complex<double> &x , const complex<double> &x_prime , 
					  const complex<double> &u , const complex<double> &u_prime , 
					  const complex<double> &z , 
					  const complex<double> &xi_prime_y);

double beta_transitions_kb_calc (
				 const int A , 
				 const int Z_daughter , 
				 const double W0 , 
				 const double w , const double w_prime , 
				 const double x , const double x_prime , 
				 const double u , const double u_prime , 
				 const double xi_prime_v , 
				 const double xi_prime_y);

complex<double> beta_transitions_kb_calc (
					  const int A , 
					  const int Z_daughter , 
					  const double W0 , 
					  const complex<double> &w , const complex<double> &w_prime , 
					  const complex<double> &x , const complex<double> &x_prime , 
					  const complex<double> &u , const complex<double> &u_prime , 
					  const complex<double> &xi_prime_v , 
					  const complex<double> &xi_prime_y);

double beta_transitions_kc_calc (
				 const double x ,
				 const double u ,
				 const double z);

complex<double> beta_transitions_kc_calc (
					  const complex<double> &x , 
					  const complex<double> &u , 
					  const complex<double> &z);

#endif
