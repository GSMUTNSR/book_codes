#ifndef SPARSEMATRIX_HPP
#define SPARSEMATRIX_HPP

// Class describing a sparse square matrix type.
// ---------------------------------------------
// SCALAR_TYPE must be double or complex.
// One cannot mix double and complex in general. Convert double to complex when necessary.
// The number of non zero matrix elements is fixed, but the rows and columns of the non-zero matrix elements can be changed by the user.
// One can check rather quickly that the used scheme is consistent, i.e. that the same matrix element is not present twice (see is_it_consistent).
//
// Symmetry is not taken into account for symmetric/antisymmetric/hermitian matrices.
// Indeed, the parallelization of matrix-matrix multiplication (see matrices.hpp) would become too cumbersome to code, which would only provide with a gain in memory of about 2.
// As the matrix is sparse by definition, one can reasonably consider that this optimization is not necessary.
// Check for symmetry/antisymmetry/hermiticity is not done either, as it is very costly, of the order of the square of the number non-zero matrix elements.
// Moreover, it is not necessary here, as symmetry/antisymmetry/hermiticity check is important for diagonalization or LU/Cholesky decomposition, which cannot be used here.
// Added to that, one can solve linear systems involving sparse matrices with linear_system_solution_biconjugate_gradient_stabilized (see matrices_add.cpp), where symmetry/antisymmetry/hermiticity is not required.

// Many temporaries are created in the binary operators +,-,*,/ ...
// Unless dimensions are small (100-200 or less typically), routines are not often called (10,000 times or more typically) and the number of non-zeros is small,
// one should not use routines creating temporaries unless one is sure that it creates no time/memory lag, as in "const class sparse_matrix<double> A = B+C;" for example.
// Nevertheless, binary operators are very practical in small applications or to test codes, for example.
// In any case, it is always possible to avoid temporaries using operator =, +=, -=, *=, /= ...

template <typename SCALAR_TYPE>
class matrix;

template <typename SCALAR_TYPE>
class sparse_matrix
{
public:

  sparse_matrix () :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {}

  explicit sparse_matrix (
			  const unsigned int dimension_c , 
			  const unsigned int non_trivial_zeros_number_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate (dimension_c , non_trivial_zeros_number_c);
  }

  explicit sparse_matrix (
			  const unsigned int dimension_row_c , 
			  const unsigned int dimension_column_c , 
			  const unsigned int non_trivial_zeros_number_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate (dimension_row_c , dimension_column_c , non_trivial_zeros_number_c);
  }


  explicit sparse_matrix (
			  const unsigned int dimension_c , 
			  const class array<unsigned int> &row_indices_c , 
			  const class array<unsigned int> &column_indices_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (dimension_c , row_indices_c , column_indices_c);
  }


  explicit sparse_matrix (
			  const unsigned int dimension_row_c , 
			  const unsigned int dimension_column_c , 
			  const class array<unsigned int> &row_indices_c , 
			  const class array<unsigned int> &column_indices_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (dimension_row_c , dimension_column_c , row_indices_c , column_indices_c);
  }

  explicit sparse_matrix (
			  const unsigned int dimension_c , 
			  const class array<unsigned int> &row_indices_c , 
			  const class array<unsigned int> &column_indices_c , 
			  const class array<SCALAR_TYPE> &matrix_elements_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (dimension_c , row_indices_c , column_indices_c , matrix_elements_c);
  }

  explicit sparse_matrix (
			  const unsigned int dimension_row_c , 
			  const unsigned int dimension_column_c , 
			  const class array<unsigned int> &row_indices_c , 
			  const class array<unsigned int> &column_indices_c , 
			  const class array<SCALAR_TYPE> &matrix_elements_c) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (dimension_row_c , dimension_column_c , row_indices_c , column_indices_c , matrix_elements_c);
  }

  sparse_matrix (const class sparse_matrix &X) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (X);
  }
  
  sparse_matrix (const class matrix<SCALAR_TYPE> &X) :
    dimension_row (0) ,
    dimension_column (0) ,
    non_trivial_zeros_number (0) ,
    row_indices (NULL) , 
    column_indices (NULL) , 
    matrix_elements (NULL)
  {
    allocate_fill (X);
  }


  ~sparse_matrix ()
  {
    delete [] row_indices;
    
    delete [] column_indices;
    
    delete [] matrix_elements;
  }

  void allocate (
		 const unsigned int dimension_c , 
		 const unsigned int non_trivial_zeros_number_c)

  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate (1)");
    
    dimension_row = dimension_column = dimension_c;

    non_trivial_zeros_number = non_trivial_zeros_number_c;

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
  }

  void allocate (
		 const unsigned int dimension_row_c , 
		 const unsigned int dimension_column_c , 
		 const unsigned int non_trivial_zeros_number_c)
  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate (2)");
    
    dimension_row = dimension_row_c;

    dimension_column = dimension_column_c;

    non_trivial_zeros_number = non_trivial_zeros_number_c;

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
  }

  void allocate_fill (
		      const unsigned int dimension_c , 
		      const class array<unsigned int> &row_indices_c , 
		      const class array<unsigned int> &column_indices_c) 

  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (1)");
						  
    dimension_row = dimension_column = dimension_c;
    
    non_trivial_zeros_number = row_indices_c.dimension (0);

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
    
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	row_indices[index] = row_indices_c[index];
	
	column_indices[index] = column_indices_c[index];	
      }
  }

  void allocate_fill (
		      const unsigned int dimension_row_c , 
		      const unsigned int dimension_column_c , 
		      const class array<unsigned int> &row_indices_c , 
		      const class array<unsigned int> &column_indices_c) 

  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (2)");
	
    dimension_row = dimension_row_c;

    dimension_column = dimension_column_c;

    non_trivial_zeros_number = row_indices_c.dimension (0);

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
    
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	row_indices[index] = row_indices_c[index];
	
	column_indices[index] = column_indices_c[index];	
      }
  }

  void allocate_fill (
		      const unsigned int dimension_c , 
		      const class array<unsigned int> &row_indices_c , 
		      const class array<unsigned int> &column_indices_c , 
		      const class array<SCALAR_TYPE> &matrix_elements_c) 

  {   
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (3)");
						  
    dimension_row = dimension_column = dimension_c;

    non_trivial_zeros_number = row_indices_c.dimension (0);
    
    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
    
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	row_indices[index] = row_indices_c[index];
	
	column_indices[index] = column_indices_c[index];
	
	matrix_elements[index] = matrix_elements_c[index];
      }
  }

  void allocate_fill (
		      const unsigned int dimension_row_c , 
		      const unsigned int dimension_column_c , 
		      const class array<unsigned int> &row_indices_c , 
		      const class array<unsigned int> &column_indices_c , 
		      const class array<SCALAR_TYPE> &matrix_elements_c) 

  { 
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (4)");

    dimension_row = dimension_row_c;

    dimension_column = dimension_column_c;

    non_trivial_zeros_number = row_indices_c.dimension (0);

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
    
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	row_indices[index] = row_indices_c[index];
	
	column_indices[index] = column_indices_c[index];
	
	matrix_elements[index] = matrix_elements_c[index];
      }
  }

  void allocate_fill (const class sparse_matrix &X)
  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (5)");
    
    dimension_row = X.dimension_row;

    dimension_column = X.dimension_column;

    non_trivial_zeros_number = X.non_trivial_zeros_number;

    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);
    
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	row_indices[index] = X.row_indices[index];
	
	column_indices[index] = X.column_indices[index];
	
	matrix_elements[index] = X.matrix_elements[index];
      }
  }

  void allocate_fill (const class matrix<SCALAR_TYPE> &X)
  {
    if (is_it_filled ()) error_message_print_abort ("A sparse matrix cannot be allocated twice in sparse_matrix::allocate_fill (6)");

    dimension_row = X.get_dimension_row ();

    dimension_column = X.get_dimension_column ();

    non_trivial_zeros_number = 0.0;
    
    for (unsigned int i = 0 ; i < dimension_row ; i++)
      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  if (X(i , j) != 0.0) non_trivial_zeros_number++;
	}
    
    row_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    column_indices = (non_trivial_zeros_number > 0) ? (new unsigned int [non_trivial_zeros_number]) : (NULL);

    matrix_elements = (non_trivial_zeros_number > 0) ? (new SCALAR_TYPE [non_trivial_zeros_number]) : (NULL);

    unsigned int index = 0;
    
    for (unsigned int i = 0 ; i < dimension_row ; i++)
      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  const SCALAR_TYPE &Xij = X(i , j);
	  
	  if (Xij != 0.0)
	    {
	      row_indices[index] = i;
	      
	      column_indices[index] = j;

	      matrix_elements[index] = Xij;

	      index++;
	    }
	}
    
  }


  void deallocate ()
  {
    delete [] row_indices;

    delete [] column_indices;

    delete [] matrix_elements;

    dimension_row = 0;

    dimension_column = 0;

    non_trivial_zeros_number = 0;
    
    row_indices = NULL;

    column_indices = NULL;

    matrix_elements = NULL;
  }

  // put all matrix elements to zero
  void zero ();
  
  // dimension of the square matrix.
  unsigned int get_dimension () const
  {
    if (dimension_row != dimension_column) error_message_print_abort ("get_dimension () is used with sparse square matrices only.");
     
    return dimension_row;
  }

  // row dimension of the matrix.
  unsigned int get_dimension_row () const
  {
    return dimension_row;
  }

  // column dimension of the matrix.
  unsigned int get_dimension_column () const
  {
    return dimension_column;
  }

  // non trivial zero matrix elements number of the matrix.
  unsigned int get_non_trivial_zeros_number () const
  {
    return non_trivial_zeros_number;
  }

  bool is_it_filled () const
  {
    return (dimension_row > 0);
  }

  // Check if the indices of non trivial zeros are sorted or not.
  bool are_indices_matrix_sorted () const;
  
  // Sort the matrix so that i + dimension_column.j increases. This allows to deal with same occurrences of (i,j) quickly
  void indices_matrix_sort ();
  
  // The matrix is reallocated so that it has no zero matrix elements.
  // Of course, nothing is done if there are no zero matrix elements.
  void remove_zeros ();
  
  // An (i,j) occurence should occur only once in a sparse matrix.
  // One returns true if it is the case and false if not.
  bool is_it_consistent () const;


  // One makes the matrix consistent by remving (i,j) repetitions and summing matrix elements of same (i,j) in its first occurrence.
  // The matrix is reallocated afterwards so that ir is consistent (unless nothing changes).
  // One can also remove zeros at the same time.
  void make_it_consistent ();  
  void make_it_consistent_no_zeros ();  

  class sparse_matrix& operator += (const class sparse_matrix &);
  class sparse_matrix& operator -= (const class sparse_matrix &);

  class sparse_matrix& operator *= (const SCALAR_TYPE &);
  class sparse_matrix& operator /= (const SCALAR_TYPE &);

  const class sparse_matrix& operator = (const class sparse_matrix &);

  SCALAR_TYPE matrix_element_determine (const unsigned int i , const unsigned int j) const;
  
  SCALAR_TYPE min () const;
  SCALAR_TYPE max () const;

  SCALAR_TYPE sum () const;
  
  void transpose ();
  void conjugate ();
  void dagger ();
  
  SCALAR_TYPE trace () const;

  SCALAR_TYPE Frobenius_squared_norm () const;
  
  SCALAR_TYPE Frobenius_norm () const;
  
  double Frobenius_squared_norm_hermitian () const;
  
  double Frobenius_norm_hermitian () const;
  
  double infinite_norm () const;

  bool is_it_real () const;
  bool is_it_diagonal () const;

  void random_matrix ();
  void pseudo_random_matrix ();

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI  (const unsigned int group_processes_number , const unsigned int process) const;

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);

  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);

  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);

  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);

  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif 



  void diagonal_part (class array<SCALAR_TYPE> &) const;

  // The following routines do not change the number of non-trivially zero matrix elements.
  // Adding a non-zero scalar to the diagonal is impossible in general for example.
  
  void zero_diagonal_part ();
  
  void multiply_scalar_diagonal_part (const SCALAR_TYPE &x);
  void divide_scalar_diagonal_part (const SCALAR_TYPE &x);
  
  void multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void divide_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  
  //indices of the rows of the sparse_matrix
  unsigned int & get_row_index (const unsigned int index) const
  {
    return row_indices[index];
  }

  //indices of the columns of the sparse_matrix
  unsigned int & get_column_index (const unsigned int index) const
  {
    return column_indices[index];
  }

  // components of the sparse_matrix
  SCALAR_TYPE & get_matrix_element (const unsigned int index) const
  {
    return matrix_elements[index];
  }
  
  template <typename C>
  friend double used_memory_calc (const class sparse_matrix<C> &T);
  
private:
  
  // Sort the matrix so that i + dimension_column.j increases. This allows to deal with same occurrences of (i,j) quickly
  void indices_matrix_sort (
			    const int low ,
			    const int high);
  
  // row dimension of the matrix.
  unsigned int dimension_row;

  // column dimension of the matrix.
  unsigned int dimension_column;

  // number of non trivially zero matrix elements of the sparse matrix
  unsigned int non_trivial_zeros_number;

  //indices of the rows of the sparse_matrix
  unsigned int * row_indices;

  //indices of the columns of the sparse_matrix
  unsigned int * column_indices;

  // components of the sparse_matrix
  SCALAR_TYPE * matrix_elements;
};


// put all matrix elements to zero
template <typename SCALAR_TYPE> 
void sparse_matrix<SCALAR_TYPE>::zero ()
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] = 0.0;
}

  

// Check if the indices of non trivial zeros are sorted or not.

template <typename SCALAR_TYPE> 
bool sparse_matrix<SCALAR_TYPE>::are_indices_matrix_sorted () const
{
  unsigned int i_bef = row_indices[0];

  unsigned int j_bef = column_indices[0];

  unsigned int index_ij_bef = j_bef + dimension_column*i_bef;
      
  for (unsigned int index = 1 ; index < non_trivial_zeros_number ; index++)
    {	
      const unsigned int i = row_indices[index];
      
      const unsigned int j = column_indices[index];
      
      const unsigned int index_ij = j + dimension_column*i;
      
      if (index_ij > index_ij_bef) return false;

      i_bef = i;
      j_bef = j;

      index_ij_bef = index_ij;
    }

  return true;
}



// Sort the matrix so that i + dimension_column.j increases. This allows to deal with same occurrences of (i,j) quickly

template <typename SCALAR_TYPE> 
void sparse_matrix<SCALAR_TYPE>::indices_matrix_sort (
						      const int low ,
						      const int high)
{
  const int pivot_index = low + (high - low)/2;
  
  int i_sort = low;
  int j_sort = high;

  const unsigned int pivot = column_indices[pivot_index] + dimension_column*row_indices[pivot_index];
 
  do
    {
      while (column_indices[i_sort] + dimension_column*row_indices[i_sort] < pivot) i_sort++;
      while (column_indices[j_sort] + dimension_column*row_indices[j_sort] > pivot) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<unsigned int> (row_indices[i_sort] , row_indices[j_sort]);
	  
	  swap<unsigned int> (column_indices[i_sort] , column_indices[j_sort]);
	  
	  swap<SCALAR_TYPE> (matrix_elements[i_sort] , matrix_elements[j_sort]);
	  	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) indices_matrix_sort (low , j_sort);

  if (i_sort < high) indices_matrix_sort (i_sort , high);
}

template <typename SCALAR_TYPE> 
void sparse_matrix<SCALAR_TYPE>::indices_matrix_sort ()
{
  indices_matrix_sort (0 , non_trivial_zeros_number - 1);
}


// The matrix is reallocated so that it has no zero matrix elements.
// Of cuurse, nothing is done if there are no zero matrix elements.

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::remove_zeros ()
{
  unsigned int new_non_trivial_zeros_number = 0;

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      if (matrix_elements[index] != 0.0) new_non_trivial_zeros_number++;
    }    
  
  if (new_non_trivial_zeros_number == non_trivial_zeros_number) return;
  
  class array<unsigned int> new_row_indices(new_non_trivial_zeros_number); 

  class array<unsigned int> new_column_indices(new_non_trivial_zeros_number);
  
  class array<SCALAR_TYPE> new_matrix_elements(new_non_trivial_zeros_number);

  unsigned int new_index = 0;
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const SCALAR_TYPE matrix_element = matrix_elements[index];
      
      if (matrix_element != 0.0)
	{
	  new_row_indices(new_index) = row_indices[index];
	  
	  new_column_indices(new_index) = column_indices[index];

	  new_matrix_elements(new_index) = matrix_element;

	  new_index++;
	}
    }

  const unsigned int dimension_row_copy = dimension_row;
  
  const unsigned int dimension_column_copy = dimension_column;

  deallocate ();
  
  allocate_fill (dimension_row_copy , dimension_column_copy , new_row_indices , new_column_indices , new_matrix_elements); 
}






// An (i,j) occurence should occur only once in a sparse matrix.
// One returns true if it is the case and false if not.
// One uses a single array with (i,j) represented as i + dimension_column.j and one orders the array.
// If one has two identical numbers next to each other, it is not consistent.
// The cost to check is then O(N log(N)), with N = non_trivial_zeros_number.


template <typename SCALAR_TYPE>
bool sparse_matrix<SCALAR_TYPE>::is_it_consistent () const
{
  if (non_trivial_zeros_number <= 1) return true;

  if (are_indices_matrix_sorted ())
    {
      unsigned int i_bef = row_indices[0];

      unsigned int j_bef = column_indices[0];

      unsigned int index_ij_bef = j_bef + dimension_column*i_bef;
      
      for (unsigned int index = 1 ; index < non_trivial_zeros_number ; index++)
	{	
	  const unsigned int i = row_indices[index];
      
	  const unsigned int j = column_indices[index];
      
	  const unsigned int index_ij = j + dimension_column*i;
      
	  if (index_ij == index_ij_bef) return false;

	  i_bef = i;
	  j_bef = j;

	  index_ij_bef = index_ij;
	}
    }
  else
    {
      class array<unsigned int> T_check(non_trivial_zeros_number);
  
      for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
	{	
	  const unsigned int i = row_indices[index];

	  const unsigned int j = column_indices[index];

	  T_check[index] = j + dimension_column*i;
	}

  
      T_check.quick_sort (0 , non_trivial_zeros_number - 1);
  
      for (unsigned int index = 1 ; index < non_trivial_zeros_number ; index++)
	{	
	  if (T_check(index) == T_check(index-1)) return false;
	}
    }

  return true;
}






// One makes the matrix consistent by remving (i,j) repetitions and summing matrix elements of same (i,j) in its first occurrence.
// The matrix is reallocated afterwards so that it is consistent (unless nothing changes).
// One can also remove zeros at the same time.

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::make_it_consistent ()
{
  if (non_trivial_zeros_number == 0) return;

  if (!are_indices_matrix_sorted ()) indices_matrix_sort ();
    
  class array<bool> is_it_index_to_keep_tab(non_trivial_zeros_number);

  is_it_index_to_keep_tab = true;
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {	      
      if (is_it_index_to_keep_tab(index))
	{
	  const unsigned int i = row_indices[index];

	  const unsigned int j = column_indices[index];

	  SCALAR_TYPE &matrix_element = matrix_elements[index];
      
	  unsigned int index_prime = index + 1;
	  
	  while ((index_prime < non_trivial_zeros_number) && (row_indices[index_prime] == i) && (column_indices[index_prime] == j))
	    {
	      matrix_element += matrix_elements[index_prime];
	      
	      is_it_index_to_keep_tab[index_prime] = false;
	      
	      index_prime++;
	    }
	}
    }
  
  unsigned int new_non_trivial_zeros_number = 0;

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      if (is_it_index_to_keep_tab(index)) new_non_trivial_zeros_number++;
    }    
  
  if (new_non_trivial_zeros_number == non_trivial_zeros_number) return;
  
  class array<unsigned int> new_row_indices(new_non_trivial_zeros_number); 

  class array<unsigned int> new_column_indices(new_non_trivial_zeros_number);
  
  class array<SCALAR_TYPE> new_matrix_elements(new_non_trivial_zeros_number);

  unsigned int new_index = 0;
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      if (is_it_index_to_keep_tab(index))
	{
	  new_row_indices(new_index) = row_indices[index];
	  
	  new_column_indices(new_index) = column_indices[index];

	  new_matrix_elements(new_index) = matrix_elements[index];

	  new_index++;
	}
    }

  const unsigned int dimension_row_copy = dimension_row;
  
  const unsigned int dimension_column_copy = dimension_column;

  deallocate ();
  
  allocate_fill (dimension_row_copy , dimension_column_copy , new_row_indices , new_column_indices , new_matrix_elements); 
}




template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::make_it_consistent_no_zeros ()
{
  if (non_trivial_zeros_number == 0) return;

  if (!are_indices_matrix_sorted ()) indices_matrix_sort ();
      
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {	
      SCALAR_TYPE &matrix_element = matrix_elements[index];
      
      if (matrix_element != 0.0)
	{
	  const unsigned int i = row_indices[index];

	  const unsigned int j = column_indices[index];
      
	  unsigned int index_prime = index + 1;
	  
	  while ((index_prime < non_trivial_zeros_number) && (row_indices[index_prime] == i) && (column_indices[index_prime] == j))
	    {
	      SCALAR_TYPE &matrix_element_prime = matrix_elements[index_prime];
	      
	      matrix_element += matrix_element_prime;
	      
	      matrix_element_prime = 0.0;
	      
	      index_prime++;
	    }
	}
    }

  remove_zeros ();
}





// The matrices and vectors must have the same dimensions and same sparsity scheme. No test is made.


// Value of a matrix element from its row and column indices
// ---------------------------------------------------------
// One implicity assumes that A is fixed.
// Then, A(i , j) is returned.
// If i and j are not found in row_indices and column_indices, zero is returned.
// One does not assume that (i,j) pairs are ordered, so that one does not use bisection to find (i,j).
// In fact, this routine is meant to be used for testing.
// It is indeed faster to use get_row_index, get_column_index and get_matrix_element instead.

template <typename SCALAR_TYPE>
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::matrix_element_determine (const unsigned int i , const unsigned int j) const
{	
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int ii = row_indices[index];

      const unsigned int jj = column_indices[index];

      if ((i == ii) && (j == jj)) return matrix_elements[index];
    }

  return 0.0;
}



// Minimal and maximal values of matrix
// ------------------------------------

template <typename SCALAR_TYPE>
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::min () const
{
  if (non_trivial_zeros_number == 0) return 0.0;
  
  SCALAR_TYPE matrix_elements_min = matrix_elements[0];
  
  for (unsigned int index = 1 ; index < non_trivial_zeros_number ; index++) matrix_elements_min = ::min (matrix_elements_min ,  matrix_elements[index]);

  return matrix_elements_min;
}

template <typename SCALAR_TYPE>
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::max () const
{
  if (non_trivial_zeros_number == 0) return 0.0;
  
  SCALAR_TYPE matrix_elements_max = matrix_elements[0];
  
  for (unsigned int index = 1 ; index < non_trivial_zeros_number ; index++) matrix_elements_max = ::max (matrix_elements_max ,  matrix_elements[index]);

  return matrix_elements_max;
}


// Sum of matrix elements
// ----------------------
// Product of matrix elements is not coded as it is not zero only if the matrix is full.

template <typename SCALAR_TYPE>
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::sum () const
{
  SCALAR_TYPE matrix_elements_sum = 0.0;
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements_sum += matrix_elements[index];

  return matrix_elements_sum;
}


// "=" overloading.
// ----------------
template <typename SCALAR_TYPE>
const class sparse_matrix<SCALAR_TYPE> & sparse_matrix<SCALAR_TYPE>::operator = (const class sparse_matrix<SCALAR_TYPE> &A)
{ 
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      row_indices[index] = A.row_indices[index];
      
      column_indices[index] = A.column_indices[index];
      
      matrix_elements[index] = A.matrix_elements[index];
    }
    
  return *this;
}





// "+=" overloading.
// ----------------

// No test is made to check sparsity scheme inside loops, i.e. that element have the same row and column index.

template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> & sparse_matrix<SCALAR_TYPE>::operator += (const class sparse_matrix<SCALAR_TYPE> &A)
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] += A.matrix_elements[index];
  
  return *this;
}



// "-=" overloading.
// ----------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> & sparse_matrix<SCALAR_TYPE>::operator -= (const class sparse_matrix<SCALAR_TYPE>& A)
{ 
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] -= A.matrix_elements[index];
  
  return *this;
}



// "*=" overloading : M times SCALAR_TYPE.
// ---------------------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> & sparse_matrix<SCALAR_TYPE>::operator *= (const SCALAR_TYPE &x)
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] *= x;

  return *this;  
}





// "/=" overloading: M over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> & sparse_matrix<SCALAR_TYPE>::operator /= (const SCALAR_TYPE &x)
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] /= x;

  return *this;  
}


template <typename SCALAR_TYPE>
unsigned int sparse_matrix<SCALAR_TYPE>::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_first_index_determine_for_MPI (non_trivial_zeros_number , group_processes_number , process);
}

template <typename SCALAR_TYPE>
unsigned int sparse_matrix<SCALAR_TYPE>::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  return basic_last_index_determine_for_MPI (non_trivial_zeros_number , group_processes_number , process);
}

template <typename SCALAR_TYPE>
unsigned int sparse_matrix<SCALAR_TYPE>::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  return basic_active_process_determine_for_MPI (non_trivial_zeros_number , group_processes_number , index);
}


#ifdef UseMPI

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  MPI_helper::Send<unsigned int> (non_trivial_zeros_number , row_indices , Recv_process , tag , MPI_C);

  MPI_helper::Send<unsigned int> (non_trivial_zeros_number , column_indices , Recv_process , tag , MPI_C);

  MPI_helper::Send<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , Recv_process , tag , MPI_C);
}

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  MPI_helper::Recv<unsigned int> (non_trivial_zeros_number , row_indices , Send_process , tag , MPI_C);

  MPI_helper::Recv<unsigned int> (non_trivial_zeros_number , column_indices , Send_process , tag , MPI_C);

  MPI_helper::Recv<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , Send_process , tag , MPI_C);
}

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  MPI_helper::Sendrecv_replace<unsigned int> (non_trivial_zeros_number , row_indices , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);

  MPI_helper::Sendrecv_replace<unsigned int> (non_trivial_zeros_number , column_indices , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);

  MPI_helper::Sendrecv_replace<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  MPI_helper::Bcast<unsigned int> (non_trivial_zeros_number , row_indices , Send_process , MPI_C);

  MPI_helper::Bcast<unsigned int> (non_trivial_zeros_number , column_indices , Send_process , MPI_C);

  MPI_helper::Bcast<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , Send_process , MPI_C);  
}

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  MPI_helper::Reduce<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements ,  op , Recv_process , process , MPI_C);
}


template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  MPI_helper::Allreduce<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , op , MPI_C);
}

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  MPI_helper::Allgatherv<SCALAR_TYPE> (non_trivial_zeros_number , matrix_elements , group_processes_number , MPI_C);
}

#endif




// "+" overloading.
// ----------------
template <typename SCALAR_TYPE>  
class sparse_matrix<SCALAR_TYPE> operator + (const class sparse_matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> operator - (const class sparse_matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times SCALAR_TYPE.
// --------------------------------------
template <typename SCALAR_TYPE>  
class  sparse_matrix<SCALAR_TYPE> operator * (const class sparse_matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x)
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M *= x;

  return M;
}



// "*" overloading : SCALAR_TYPE times A.
// --------------------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> operator * (const SCALAR_TYPE &x , const class sparse_matrix<SCALAR_TYPE> &A) 
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE>  
class sparse_matrix<SCALAR_TYPE> operator / (const class sparse_matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x) 
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M /= x;

  return M;
}




// Frobenius squared norm: Tr(A A^T) or Tr (A A^\dagger) (hermitian)


template <typename SCALAR_TYPE> 
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::Frobenius_squared_norm () const
{  
  if (get_dimension_row () != get_dimension_column ()) error_message_print_abort ("Row and column dimension of A must be equal for Frobenius norm (sparse)");
  
  if (non_trivial_zeros_number == 0) return 0.0;

  const unsigned int index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (non_trivial_zeros_number - 1);
		
  const bool is_index_end_smaller_than_non_trivial_zeros_number = (index_end < non_trivial_zeros_number);
      
  double Re_Frobenius_squared_norm = 0.0;
  double Im_Frobenius_squared_norm = 0.0;
  
  if (is_index_end_smaller_than_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_Frobenius_squared_norm,Im_Frobenius_squared_norm)
#endif
      for (unsigned int index = index_debut ; index <= index_end ; index++)
	{
	  const SCALAR_TYPE &Vik = matrix_elements[index];
	      
	  const SCALAR_TYPE Vik_square = Vik*Vik;
	  
	  Re_Frobenius_squared_norm += real_dc (Vik_square);
	  Im_Frobenius_squared_norm += imag_dc (Vik_square);
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_Frobenius_squared_norm , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_Frobenius_squared_norm , MPI_SUM , MPI_COMM_WORLD);
#endif
  
  const SCALAR_TYPE Frobenius_squared_norm_value = generate_scalar<SCALAR_TYPE> (Re_Frobenius_squared_norm , Im_Frobenius_squared_norm);
          
  return Frobenius_squared_norm_value;  
}



template <typename SCALAR_TYPE> 
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::Frobenius_norm () const
{
  const SCALAR_TYPE Frobenius_squared_norm_value = Frobenius_squared_norm ();
    
  const SCALAR_TYPE Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}






template <typename SCALAR_TYPE> 
double sparse_matrix<SCALAR_TYPE>::Frobenius_squared_norm_hermitian () const
{  
  if (get_dimension_row () != get_dimension_column ()) error_message_print_abort ("Row and column dimension of A must be equal for Hermitian Frobenius norm (sparse)");
  
  if (non_trivial_zeros_number == 0) return 0.0;

  const unsigned int index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (non_trivial_zeros_number - 1);
		
  const bool is_index_end_smaller_than_non_trivial_zeros_number = (index_end < non_trivial_zeros_number);
      
  double Frobenius_squared_norm_value = 0.0;
  
  if (is_index_end_smaller_than_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Frobenius_squared_norm_value)
#endif
      for (unsigned int index = index_debut ; index <= index_end ; index++)
	{
	  const SCALAR_TYPE &Vik = matrix_elements[index];
	      	  
	  Frobenius_squared_norm_value += norm_dc (Vik);
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Frobenius_squared_norm_value , MPI_SUM , MPI_COMM_WORLD);
#endif
          
  return Frobenius_squared_norm_value;
}





template <typename SCALAR_TYPE> 
double sparse_matrix<SCALAR_TYPE>::Frobenius_norm_hermitian () const
{
  const double Frobenius_squared_norm_value = Frobenius_squared_norm_hermitian ();
    
  const double Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}








// Infinite norm.
// --------------
// It is the largest component |M(i , j)|oo

template <typename SCALAR_TYPE>
double sparse_matrix<SCALAR_TYPE>::infinite_norm () const 
{
  double norm = 0.0;

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const double inf_norm_matrix_element = inf_norm (matrix_elements[index]);

      if (!finite (inf_norm_matrix_element)) return inf_norm_matrix_element;

      if (norm < inf_norm_matrix_element) norm = inf_norm_matrix_element;
    }

  return norm;
}





// Check if A is a real matrix
// ---------------------------
template <typename SCALAR_TYPE>
bool sparse_matrix<SCALAR_TYPE>::is_it_real () const 
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      if (imag_dc (matrix_elements[index]) != 0.0) return false;
    }

  return true;
}


// Conversion of one scalar type to another
// ----------------------------------------
template <typename IN_SCALAR_TYPE , typename OUT_SCALAR_TYPE>
class sparse_matrix<OUT_SCALAR_TYPE> convert (const class sparse_matrix<IN_SCALAR_TYPE> &M_in)
{  
  const unsigned int Nr = M_in.get_dimension_row ();
  const unsigned int Nc = M_in.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = M_in.get_non_trivial_zeros_number ();
  
  class sparse_matrix<OUT_SCALAR_TYPE> M_out(Nr , Nc , non_trivial_zeros_number);

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      M_out.get_row_index (index) = M_in.get_row_index (index);

      M_out.get_column_index (index) = M_in.get_column_index (index);
      
      M_out.get_matrix_element (index) = M_in.get_matrix_element (index);
    }

  return M_out;
}


// Check if A is diagonal
// ----------------------
template <typename SCALAR_TYPE>
bool sparse_matrix<SCALAR_TYPE>::is_it_diagonal () const 
{
  if (dimension_row != dimension_column) error_message_print_abort ("is_it_diagonal member function is used with sparse square matrices only.");

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = row_indices[index];
      
      const unsigned int j = column_indices[index];

      if ((i != j) && (matrix_elements[index] != 0.0)) return false;
    }

  return true;
}








// Unary +
// -------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> operator + (const class sparse_matrix<SCALAR_TYPE> &A)
{
  return A;
}




// Unary -
// -------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> operator - (const class sparse_matrix<SCALAR_TYPE> &A)
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  const unsigned int non_trivial_zeros_number = M.get_non_trivial_zeros_number ();

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) M.get_matrix_element (index) = -M.get_matrix_element (index);

  return M;
}





// Matrix transpose
// ----------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::transpose ()
{	
  if (dimension_row != dimension_column) error_message_print_abort ("transpose member function is used with sparse square matrices only. Use external transpose function for non square sparse matrices.");

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = row_indices[index];

      const unsigned int j = column_indices[index];

      row_indices[index] = j;

      column_indices[index] = i;
    }
}




// Matrix conjugate.
// -----------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::conjugate ()
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      matrix_elements[index] = conj (matrix_elements[index]);
    }
}




// Matrix hermitian conjugate
// --------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::dagger ()
{
  if (dimension_row != dimension_column) error_message_print_abort ("dagger member function is used with sparse square matrices only. Use external dagger function for non square sparse matrices.");

  transpose ();
  conjugate ();
}




// Matrix transpose returned.
// --------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> transpose (const class sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = A.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
  
  class sparse_matrix<SCALAR_TYPE> M(Nc , Nr , non_trivial_zeros_number);
 
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      M.get_row_index (index) = A.get_column_index (index);

      M.get_column_index (index) = A.get_row_index (index);
      
      M.get_matrix_element (index) = A.get_matrix_element (index) ;
    }

  return M;
}



// Matrix conjugate returned.
// --------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> conj (const class sparse_matrix<SCALAR_TYPE> &A)
{
  class sparse_matrix<SCALAR_TYPE> M = A;

  M.conjugate ();

  return M;
}




// Matrix hermitian conjugate returned.
// ------------------------------------
template <typename SCALAR_TYPE>
class sparse_matrix<SCALAR_TYPE> dagger (const class sparse_matrix<SCALAR_TYPE> &A)
{
  class sparse_matrix<SCALAR_TYPE> M = transpose (A);
  
  M.conjugate ();
  
  return M;
}




// Matrix real part returned
// -------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class sparse_matrix<SCALAR_TYPE> real (const class sparse_matrix<COMPLEX_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();
  const unsigned int Nc = M.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = M.get_non_trivial_zeros_number ();
  
  class sparse_matrix<SCALAR_TYPE> Re_M(Nr , Nc , non_trivial_zeros_number);

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      Re_M.get_row_index (index) = M.get_row_index (index);

      Re_M.get_column_index (index) = M.get_column_index (index);
      
      Re_M.get_matrix_element (index) = real_dc (M.get_matrix_element (index));
    }
  
  return Re_M;
}





// Matrix imaginary part returned
// ------------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class sparse_matrix<SCALAR_TYPE> imag (const class sparse_matrix<COMPLEX_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();
  const unsigned int Nc = M.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = M.get_non_trivial_zeros_number ();
  
  class sparse_matrix<SCALAR_TYPE> Im_M(Nr , Nc , non_trivial_zeros_number);

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      Im_M.get_row_index (index) = M.get_row_index (index);

      Im_M.get_column_index (index) = M.get_column_index (index);
      
      Im_M.get_matrix_element (index) = imag_dc (M.get_matrix_element (index));
    }
  
  return Im_M;
}




// Complex matrix returned from real and/or imaginary parts
// --------------------------------------------------------

template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class sparse_matrix<COMPLEX_TYPE> complex_matrix (const class sparse_matrix<SCALAR_TYPE> &Re_M)
{
  const unsigned int Nr = Re_M.get_dimension_row ();
  const unsigned int Nc = Re_M.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = Re_M.get_non_trivial_zeros_number ();
  
  class sparse_matrix<COMPLEX_TYPE> M(Nr , Nc , non_trivial_zeros_number);

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      M.get_row_index (index) = Re_M.get_row_index (index);

      M.get_column_index (index) = Re_M.get_column_index (index);
      
      M.get_matrix_element (index) = Re_M.get_matrix_element (index);
    }
  
  return M;
}




// Complex matrix returned from real and imaginary parts
// -----------------------------------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class sparse_matrix<COMPLEX_TYPE> complex_matrix (const class sparse_matrix<SCALAR_TYPE> &Re_M , const class sparse_matrix<SCALAR_TYPE> &Im_M)
{
  if (Re_M.get_dimension_row () != Im_M.get_dimension_row ()) error_message_print_abort ("Re_M and Im_M must have the same number of rows in complex_matrix (sparse)");

  if (Re_M.get_dimension_column () != Im_M.get_dimension_column ()) error_message_print_abort ("Re_M and Im_M must have the same number of columns in complex_matrix (sparse)");
  
  if (Re_M.get_non_trivial_zeros_number () != Im_M.get_non_trivial_zeros_number ()) error_message_print_abort ("Re_M and Im_M must have the same number of non trivial zeros in complex_matrix (sparse)");
  
  const unsigned int Nr = Re_M.get_dimension_row ();
  const unsigned int Nc = Re_M.get_dimension_column ();

  const unsigned int non_trivial_zeros_number = Re_M.get_non_trivial_zeros_number ();
  
  class sparse_matrix<COMPLEX_TYPE> M(Nr , Nc , non_trivial_zeros_number);

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      M.get_row_index (index) = Re_M.get_row_index (index);

      M.get_column_index (index) = Re_M.get_column_index (index);
      
      M.get_matrix_element (index) = COMPLEX_TYPE (Re_M.get_matrix_element (index) , Im_M.get_matrix_element (index));
    }
  
  return M;
}






// Trace of the matrix
// -------------------
template <typename SCALAR_TYPE>
SCALAR_TYPE sparse_matrix<SCALAR_TYPE>::trace () const
{
  if (dimension_row != dimension_column) error_message_print_abort ("trace member function is used with sparse square matrices only.");

  SCALAR_TYPE trace_value = 0.0;

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = row_indices[index];

      const unsigned int j = column_indices[index];

      if (i == j) trace_value += matrix_elements[index];
    }

  return trace_value;
}




// Diagonal part of the matrix
// ---------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::diagonal_part (class array<SCALAR_TYPE> &diagonal_array) const
{
  if (dimension_row != dimension_column) error_message_print_abort ("diagonal_part for sparse square matrices only.");

  diagonal_array = 0.0;

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) diagonal_array(i) = matrix_elements[index];
    }
}


// put a scalar to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::zero_diagonal_part ()
{
  if (dimension_row != dimension_column) error_message_print_abort ("put diagonal_part to zero for square matrices only.");
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) matrix_elements[index] = 0.0;
    }
}

// multiply a scalar to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::multiply_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  if (dimension_row != dimension_column) error_message_print_abort ("multiply a scalar to diagonal_part for square matrices only.");
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) matrix_elements[index] *= x;
    }
}


// divide the diagonal by a scalar
// -------------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::divide_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  if (dimension_row != dimension_column) error_message_print_abort ("divide the diagonal_part by a scalar for square matrices only.");
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) matrix_elements[index] /= x;
    }
}




// multiply an array to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  if (dimension_row != dimension_column) error_message_print_abort ("multiply an array to diagonal_part for square matrices only.");
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) matrix_elements[index] *= T(i);
    }
}


// divide the diagonal by an array
// -------------------------------
template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::divide_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  if (dimension_row != dimension_column) error_message_print_abort ("divide the diagonal_part by an array for square matrices only.");
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned i = row_indices[index];
      
      const unsigned j = column_indices[index];

      if (i == j) matrix_elements[index] /= T(i);
    }
}


// V=AX.
// -----
template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> operator * (const class sparse_matrix<SCALAR_TYPE> &A , const class vector_class<SCALAR_TYPE> &X)
{	
  if (A.get_dimension_column () != X.get_dimension ()) error_message_print_abort ("Column dimension of A and dimension of X must be equal for sparse matrix-vector multiplication.");

  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();

  const unsigned int Nr = A.get_dimension_row ();

  class vector_class<SCALAR_TYPE> V(Nr);  

  V = 0.0;

  if (A_non_trivial_zeros_number == 0) return V;

  const unsigned int index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (A_non_trivial_zeros_number - 1);
  
  if (index_end < A_non_trivial_zeros_number)
    {
      class array<class vector_class<SCALAR_TYPE> > V_tab(NUMBER_OF_THREADS);  

      for (unsigned int thread = 0 ; thread < NUMBER_OF_THREADS ; thread++)
	{
	  class vector_class<SCALAR_TYPE> &V_thread = V_tab(thread);

	  V_thread.allocate (Nr);

	  V_thread = 0.0;
	}
 
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int index = index_debut ; index <= index_end ; index++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	
	  class vector_class<SCALAR_TYPE> &V_thread = V_tab(i_thread);
	  {
	    const unsigned int i = A.get_row_index (index);

	    const unsigned int j = A.get_column_index (index);

	    const SCALAR_TYPE &Aij = A.get_matrix_element (index);

	    V_thread(i) += Aij*X(j);
	  }
	}
  
      for (unsigned int thread = 0 ; thread < NUMBER_OF_THREADS ; thread++) V += V_tab(thread);
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) V.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif

  return V;
}







//  M << print overload.
// ---------------------
template <typename SCALAR_TYPE>
ostream & operator << (ostream &os , const class sparse_matrix<SCALAR_TYPE> &M)
{
  const unsigned int non_trivial_zeros_number = M.get_non_trivial_zeros_number ();
  
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      os << M.get_row_index (index) << " " << M.get_column_index (index) << " " << M.get_matrix_element (index) << endl;
    }

  return os;
}




//  M >> get overload.
// -------------------
template <typename SCALAR_TYPE>
istream & operator >> (istream &is , class sparse_matrix<SCALAR_TYPE> &M)
{
  const unsigned int non_trivial_zeros_number = M.get_non_trivial_zeros_number ();

  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      is >> M.get_row_index (index) >> M.get_column_index (index) >> M.get_matrix_element (index);
    }

  return is;
}




//  Matrix randomly initialized.
// -----------------------------
// The sparsity scheme does not change, i.e. trivially zero matrix elements remain equal to zero.

template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::random_matrix ()
{
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++) matrix_elements[index] = random_number<SCALAR_TYPE> () - 0.5;
}


template <typename SCALAR_TYPE>
void sparse_matrix<SCALAR_TYPE>::pseudo_random_matrix ()
{
  seed (0);

  random_matrix ();
  
  seed ();
}




template <typename SCALAR_TYPE>
double used_memory_calc (const class sparse_matrix<SCALAR_TYPE> &T)
{
  const double used_memory = (sizeof (T) + T.non_trivial_zeros_number*(2*sizeof (unsigned int) + sizeof (SCALAR_TYPE)))/1000000.0;
  
  return used_memory;
}






template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product (
				      const class sparse_matrix<SCALAR_TYPE> &A ,
				      const class sparse_matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Frobenius scalar product (A sparse , B sparse)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A and B must be equal for Frobenius scalar product (A sparse , B sparse)");
  
  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
  const unsigned int B_non_trivial_zeros_number = B.get_non_trivial_zeros_number ();
  
  if ((A_non_trivial_zeros_number == 0) || (B_non_trivial_zeros_number == 0)) return 0.0;
    
  const unsigned int B_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int B_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (B_non_trivial_zeros_number - 1);
		
  const bool is_B_index_end_smaller_than_B_non_trivial_zeros_number = (B_index_end < B_non_trivial_zeros_number);
      
  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;
  
  if (is_B_index_end_smaller_than_B_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int A_index = 0 ; A_index < A_non_trivial_zeros_number ; A_index++)
	{
	  const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	  const unsigned int i = A.get_row_index (A_index);
	      
	  const unsigned int k = A.get_column_index (A_index);
	  
	  for (unsigned int B_index = B_index_debut ; B_index <= B_index_end ; B_index++)
	    {
	      if ((B.get_row_index (B_index) == i) && (B.get_column_index (B_index) == k))
		{
		  const SCALAR_TYPE &Bik = B.get_matrix_element (B_index);
		  
		  const SCALAR_TYPE Aik_Bik = Aik*Bik;
	  
		  Re_scalar_product += real_dc (Aik_Bik);
		  Im_scalar_product += imag_dc (Aik_Bik);
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif
  
  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);
  
  return scalar_product;
}





template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product_hermitian (
						const class sparse_matrix<SCALAR_TYPE> &A ,
						const class sparse_matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Hermitian Frobenius scalar product (A sparse , B sparse)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A and B must be equal for Hermitian Frobenius scalar product (A sparse , B sparse)");
 
  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
  const unsigned int B_non_trivial_zeros_number = B.get_non_trivial_zeros_number ();
  
  if ((A_non_trivial_zeros_number == 0) || (B_non_trivial_zeros_number == 0)) return 0.0;
    
  const unsigned int B_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int B_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (B_non_trivial_zeros_number - 1);
		
  const bool is_B_index_end_smaller_than_B_non_trivial_zeros_number = (B_index_end < B_non_trivial_zeros_number);
      
  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;
  
  if (is_B_index_end_smaller_than_B_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int A_index = 0 ; A_index < A_non_trivial_zeros_number ; A_index++)
	{
	  const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	  const unsigned int i = A.get_row_index (A_index);
	      
	  const unsigned int k = A.get_column_index (A_index);
	  
	  for (unsigned int B_index = B_index_debut ; B_index <= B_index_end ; B_index++)
	    {
	      if ((B.get_row_index (B_index) == i) && (B.get_column_index (B_index) == k))
		{
		  const SCALAR_TYPE &Bik = B.get_matrix_element (B_index);
		  
		  const SCALAR_TYPE Aik_Bik = Aik*conj (Bik);
	  
		  Re_scalar_product += real_dc (Aik_Bik);
		  Im_scalar_product += imag_dc (Aik_Bik);
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif
  
  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);
  
  return scalar_product;
}








#endif
