#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void tests_1 ()
{
  const unsigned int Nr = 1000;
  const unsigned int Nc = 1100;
      
  const double zero_probability = 0.1;
      
  class matrix<complex<double> > M_full(Nr , Nc);

  M_full.random_matrix ();

  M_full.put_zeros_with_probability (zero_probability);
            
  class sparse_matrix<complex<double> > M = M_full;

  if (!M.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class sparse_matrix (1)");
      	
  class vector_class<complex<double> > X(Nc);

  for (unsigned int i = 0 ; i < Nc ; i++) X(i) = complex<double> (cos (i) , sin(i));

  X.normalization ();

  const class vector_class<complex<double> > B = M*X;

  const class vector_class<complex<double> > B_from_full = M_full*X;
  
  const class vector_class<complex<double> > Res = B - B_from_full;
      
  if (Res.infinite_norm () > precision) error_message_print_abort ("Problem with operator matrix times vector in class sparse_matrix");
}







	
void tests_2 ()
{	
  const unsigned int Nr = 200;
  const unsigned int Nc = 200;
    
  const double zero_probability = 0.2;
      
  class matrix<complex<double> > M_full(Nr , Nc);

  M_full.random_matrix ();

  M_full.put_zeros_with_probability (zero_probability);

  M_full(0 , 0) = complex<double> (1 , 0.01);
            
  class sparse_matrix<complex<double> > M = M_full;

  if (!M.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class sparse_matrix (2)");
      
  if (M.is_it_real ()) error_message_print_abort ("Problem in class sparse_matrix with is_it_real");
    
  M.random_matrix ();
  
  M *= complex<double> (4 , 6);

  const complex<double> a(4.7 , 3.8) , b(7.8 , -3.9) , c(2.4 , -1.2);

  class sparse_matrix<complex<double> > A = b*M;
  
  class sparse_matrix<complex<double> > B = A;
  
  A += a*M;
  A -= a*M;

  A *= b;
  A /= b;

  A -= b*M;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with = , += , -= , *= or /=");

  A = b*M;

  A = A + a*M;
  A = A - a*M;

  A = A*b;
  A = A/b;

  A = A - b*M;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with = , + , - , * or /");

  A = M + B;

  A *= b;
  A /= b;

  A = A - M - B;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with = , += , -= , *= or /=");

  B = -A;

  M = B + A;

  if (M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with unary -");

  M *= a;

  A = M;

  A.transpose ();

  B = transpose (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in transpose");

  M.random_matrix ();

  M *= a;

  A = M;

  A.conjugate ();

  B = conj (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with conjugate"); 

  M.random_matrix ();

  M *= a;

  A = M;

  A.dagger ();

  B = dagger (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with dagger"); 

  const class sparse_matrix<double> Re_M = real<double , complex<double> > (M);
  const class sparse_matrix<double> Im_M = imag<double , complex<double> > (M);

  const class sparse_matrix<complex<double> > M_test = complex_matrix<double , complex<double> > (Re_M , Im_M);

  A = M - M_test;	

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with real , imag or complex_sparse_matrix");

  if (!Re_M.is_it_real ()) error_message_print_abort ("Problem in class sparse_matrix with is_it_real");
    
  const unsigned int N = 23;
    
  class sparse_matrix<unsigned int> C(N , N);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      C.get_row_index (i) = i;

      C.get_column_index (i) = i;

      C.get_matrix_element (i) = 1;
    }
    
  if (!C.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class sparse_matrix (3)");

  class array<unsigned int> diag_tab(Nr);

  C.diagonal_part (diag_tab);
    
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (diag_tab(i) != 1) error_message_print_abort ("Problem in class sparse_matrix with diagonal_part");
    }
    
  const unsigned int T = C.trace ();

  if (T != N) error_message_print_abort ("Problem in class sparse_matrix with trace");

  class sparse_matrix<double> C_double = convert<unsigned int , double> (C);

  for (unsigned int i = 0 ; i < N ; i++) C_double.get_matrix_element (i) -= 1;

  if (C_double.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class sparse_matrix with convert"); 

  class array<complex<double> > A_diagonal_init(Nr);

  A.diagonal_part (A_diagonal_init);
      
  A.multiply_scalar_diagonal_part (a);

  A.divide_scalar_diagonal_part (a);
    
  for (unsigned int i = 0 ; i < N ; i++)
    if (inf_norm (A.matrix_element_determine (i , i) - A_diagonal_init(i)) > 1E-13)
      error_message_print_abort ("Problem in class sparse_matrix with multiply/divide_scalar_diagonal_part");
    
  A.zero_diagonal_part ();
    
  for (unsigned int i = 0 ; i < N ; i++)
    if (A.matrix_element_determine (i , i) != 0.0)
      error_message_print_abort ("Problem in class sparse_matrix with zero_diagonal_part");
    
  C.random_matrix ();

  const double C_min = C.min ();
  const double C_max = C.max ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (C.get_matrix_element (i) < C_min) error_message_print_abort ("Problem in class sparse_matrix with min (member class)");
      if (C.get_matrix_element (i) > C_max) error_message_print_abort ("Problem in class sparse_matrix with max (member class)");
    }
}









void tests_3 ()
{
  const unsigned int Nr = 12;
  const unsigned int Nc = 17;
    
  const unsigned int Nnz = 10;
    
  class sparse_matrix<complex<double> > A_sp(Nr , Nc , Nnz);

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      {
	if (index < Nnz)
	  {
	    A_sp.get_row_index (index) = i;
	    
	    A_sp.get_column_index (index) = j;
	  }
	
	index++;	
      }
  
  A_sp.random_matrix ();
  
  class array<unsigned int> row_indices(6); 

  class array<unsigned int> column_indices(6);
    
  class array<double> matrix_elements(6);

  row_indices(0) = 0 , column_indices(0) = 0 , matrix_elements(0) = 1;
  row_indices(1) = 0 , column_indices(1) = 0 , matrix_elements(1) = 3;
  row_indices(2) = 0 , column_indices(2) = 2 , matrix_elements(2) = 0;
  row_indices(3) = 1 , column_indices(3) = 2 , matrix_elements(3) = 5;
  row_indices(4) = 1 , column_indices(4) = 2 , matrix_elements(4) = 7;
  row_indices(5) = 1 , column_indices(5) = 0 , matrix_elements(5) = 0;
              
  class sparse_matrix<double> M_sp(3 , 5 , row_indices , column_indices , matrix_elements);
    
  cout << "Initial matrix" << endl << M_sp << endl;

  cout << "Is the matrix consistent:" << M_sp.is_it_consistent () << endl;

  M_sp.make_it_consistent ();
    
  cout << endl << "Matrix made consistent " << endl << M_sp << endl;
    
  cout << "Is the matrix consistent:" << M_sp.is_it_consistent () << endl;
    
  M_sp.remove_zeros ();
      
  cout << endl << "Matrix with zeros removed" << endl << M_sp << endl;
    
  class sparse_matrix<double> Ap_sp(3 , 5 , row_indices , column_indices , matrix_elements);
    
  Ap_sp.indices_matrix_sort ();
    
  Ap_sp.make_it_consistent_no_zeros ();
    
  cout << "Matrix made consistent no zeros " << endl << Ap_sp << endl;
  
  const complex<double> A_sum = A_sp.sum ();
  
  complex<double> A_sum_try = 0.0;
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      A_sum_try += A_sp.matrix_element_determine (i , j);
  
  if (inf_norm (A_sum - A_sum_try ) > precision) error_message_print_abort ("Problem in class sparse_matrix with sum");
}








#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  MPI_parallelization_linear_algebra_enabled ();

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    OpenMP_parallelization_linear_algebra_enabled ();

#ifdef UseOpenMP
    OpenMP_set_threads_number (4);
#endif

    tests_1 ();
    
    OpenMP_parallelization_linear_algebra_disabled ();

    MPI_parallelization_linear_algebra_disabled ();
      
    tests_2 ();
    tests_3 ();
        
    if (THIS_PROCESS == MASTER_PROCESS) cout << "All sparse_matrix class tests here are correct (other tests are done in the matrices directory)." << endl; 

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

