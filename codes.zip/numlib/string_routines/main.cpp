#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    clog << "------ angular_state (i , d) ------" << endl;

    int i = 2;

    double d = 2.3;

    clog << angular_state (i , d) << endl;

    clog << "------ angular_state_for_file_name (i , d) ------" << endl;
    clog << angular_state_for_file_name (i , d) << endl;

    clog << "------ determine_n (s) ------" << endl;

    string s = "0d5/2";

    clog << determine_n (s) << endl;

    clog << "------ determine_l (s) ------" << endl;
    clog << determine_l (s) << endl;

    clog << "------ determine_j (s) ------" << endl;
    clog << determine_j (s) << endl;

    clog << "------ determine_half_integer_J (s) ------" << endl;
    clog << determine_half_integer_J (s) << endl;

    clog << "------ determine_integer_J (s) ------" << endl;
    //clog << determine_integer_J (s) << endl;

    clog << "------ determine_J (s) ------" << endl;
    clog << determine_J (s) << endl;

    clog << "------ determine_half_integer_T (s) ------" << endl;
    //clog << determine_half_integer_T (s) << endl;

    clog << "------ determine_integer_T (s) ------" << endl;
    //clog << determine_integer_T (s) << endl;

    clog << "------ determine_T (s) ------" << endl;
    //clog << determine_T (s) << endl;

    clog << "------ determine_Binary_Parity (s) ------" << endl;
    //clog << determine_Binary_Parity (s) << endl;

    clog << "------ bool_determination (s) ------" << endl;
    //clog << bool_determination (s) << endl;

    clog << "------ word_check (s) ------" << endl;
    //word_check (s);

    clog << "------ quantum_numbers_read (u , i , u) ------" << endl;
    //	unsigned int u = 1;
    //quantum_numbers_read (u , i , u);

    clog << "------ quantum_numbers_read (u , d , u) ------" << endl;
    //quantum_numbers_read (u , d , u);

    clog << make_string_length ("this" , 10) << endl;

#ifdef UseMPI    
    MPI_helper::Finalize ();
#endif

  }







