#include "../numlib_def/numlib_def.h"

extern string STORAGE_DIR;

// Routines reading M quantum number
// ---------------------------------
// One can read an M-projection in the code written as 0+, 0-, 1/2+, 1/2-, or 0+, 0- , 1I2+, 1I2- for input file name.
// Strictly negative values of M are not considered.
// Routines are the same as for J, but I use different routines to make clear that I read M and not J.



string string_routines::angular_state (const int l , const double j)
{
  const int two_j = make_int (2.0*j);

  const bool is_j_integer = (two_j%2 == 0);

  const string l_str = make_string<int> (l);

  if (is_j_integer)
    {
      const int j_int = make_int (j);

      const string j_str = make_string<int> (j_int);

      switch (l)
	{
	case  0: return ("s" + j_str); 
	case  1: return ("p" + j_str); 
	case  2: return ("d" + j_str);
	case  3: return ("f" + j_str);
	case  4: return ("g" + j_str);
	case  5: return ("h" + j_str);
	case  6: return ("i" + j_str);
	case  7: return ("j" + j_str);
	case  8: return ("k" + j_str);
	case  9: return ("l" + j_str);
	case 10: return ("m" + j_str);
	case 11: return ("n" + j_str);
	case 12: return ("o" + j_str);
	case 13: return ("q" + j_str);
	case 14: return ("r" + j_str);
	case 15: return ("t" + j_str);
	case 16: return ("u" + j_str);
	case 17: return ("v" + j_str);
	case 18: return ("w" + j_str);
	case 19: return ("x" + j_str);
	case 20: return ("y" + j_str);
	case 21: return ("z" + j_str);
	case 22: return ("a" + j_str);
	case 23: return ("b" + j_str);
	case 24: return ("c" + j_str);
	case 25: return ("e" + j_str);
	case 26: return ("A" + j_str);
	case 27: return ("B" + j_str);
	case 28: return ("C" + j_str);
	case 29: return ("D" + j_str);
	case 30: return ("E" + j_str);
	case 31: return ("F" + j_str);
	case 32: return ("G" + j_str);
	case 33: return ("H" + j_str);
	case 34: return ("I" + j_str);
	case 35: return ("J" + j_str);
	case 36: return ("K" + j_str);
	case 37: return ("L" + j_str);
	case 38: return ("M" + j_str);
	case 39: return ("N" + j_str);
	case 40: return ("O" + j_str);
	case 41: return ("P" + j_str);
	case 42: return ("Q" + j_str);
	case 43: return ("R" + j_str);
	case 44: return ("S" + j_str);
	case 45: return ("T" + j_str);
	case 46: return ("U" + j_str);
	case 47: return ("V" + j_str);
	case 48: return ("W" + j_str);
	case 49: return ("X" + j_str);
	case 50: return ("Y" + j_str);
	case 51: return ("Z" + j_str);
	default: return ("l=" + l_str + " j=" + j_str);
	} 
    } 
  else
    {
      const string two_j_str = make_string<int> (two_j) + "/2";

      switch (l)
	{
	case  0: return ("s" + two_j_str);
	case  1: return ("p" + two_j_str);
	case  2: return ("d" + two_j_str);
	case  3: return ("f" + two_j_str);
	case  4: return ("g" + two_j_str);
	case  5: return ("h" + two_j_str);
	case  6: return ("i" + two_j_str);
	case  7: return ("j" + two_j_str);
	case  8: return ("k" + two_j_str);
	case  9: return ("l" + two_j_str);
	case 10: return ("m" + two_j_str);
	case 11: return ("n" + two_j_str);
	case 12: return ("o" + two_j_str);
	case 13: return ("q" + two_j_str);
	case 14: return ("r" + two_j_str);
	case 15: return ("t" + two_j_str);
	case 16: return ("u" + two_j_str);
	case 17: return ("v" + two_j_str);
	case 18: return ("w" + two_j_str);
	case 19: return ("x" + two_j_str);
	case 20: return ("y" + two_j_str);
	case 21: return ("z" + two_j_str);
	case 22: return ("a" + two_j_str);
	case 23: return ("b" + two_j_str);
	case 24: return ("c" + two_j_str);
	case 25: return ("e" + two_j_str);
	case 26: return ("A" + two_j_str);
	case 27: return ("B" + two_j_str);
	case 28: return ("C" + two_j_str);
	case 29: return ("D" + two_j_str);
	case 30: return ("E" + two_j_str);
	case 31: return ("F" + two_j_str);
	case 32: return ("G" + two_j_str);
	case 33: return ("H" + two_j_str);
	case 34: return ("I" + two_j_str);
	case 35: return ("J" + two_j_str);
	case 36: return ("K" + two_j_str);
	case 37: return ("L" + two_j_str);
	case 38: return ("M" + two_j_str);
	case 39: return ("N" + two_j_str);
	case 40: return ("O" + two_j_str);
	case 41: return ("P" + two_j_str);
	case 42: return ("Q" + two_j_str);
	case 43: return ("R" + two_j_str);
	case 44: return ("S" + two_j_str);
	case 45: return ("T" + two_j_str);
	case 46: return ("U" + two_j_str);
	case 47: return ("V" + two_j_str);
	case 48: return ("W" + two_j_str);
	case 49: return ("X" + two_j_str);
	case 50: return ("Y" + two_j_str);
	case 51: return ("Z" + two_j_str);
	default: return ("[l=" + l_str + "]" + two_j_str);
	}
    }
}





string string_routines::angular_state_two_body_cluster (const int S , const int L , const double J)
{
  return (make_string<int> (2*S + 1) + angular_state_cluster_CM_intrinsic_spin (L , J));
}




string string_routines::angular_state_cluster_CM (const int L)
{
  switch (L)
    {
    case  0: return ("S");
    case  1: return ("P");
    case  2: return ("D");
    case  3: return ("F");
    case  4: return ("G");
    case  5: return ("H");
    case  6: return ("I");
    case  7: return ("J");
    case  8: return ("K");
    case  9: return ("L");
    case 10: return ("M");
    case 11: return ("N");
    case 12: return ("O");
    case 13: return ("Q");
    case 14: return ("R");
    case 15: return ("T");
    case 16: return ("U");
    case 17: return ("V");
    case 18: return ("W");
    case 19: return ("X");
    case 20: return ("Y");
    case 21: return ("Z");
    case 22: return ("A");
    case 23: return ("B");
    case 24: return ("D");
    case 25: return ("E");
    case 26: return ("a");
    case 27: return ("b");
    case 28: return ("c");
    case 29: return ("d");
    case 30: return ("e");
    case 31: return ("f");
    case 32: return ("g");
    case 33: return ("h");
    case 34: return ("i");
    case 35: return ("j");
    case 36: return ("k");
    case 37: return ("l");
    case 38: return ("m");
    case 39: return ("n");
    case 40: return ("o");
    case 41: return ("p");
    case 42: return ("q");
    case 43: return ("r");
    case 44: return ("s");
    case 45: return ("t");
    case 46: return ("u");
    case 47: return ("v");
    case 48: return ("w");
    case 49: return ("x");
    case 50: return ("y");
    case 51: return ("z");
    default: return ("L=" + make_string<int> (L));
    } 	
}



string string_routines::angular_state_cluster_CM_intrinsic_spin (const int L , const double J)
{
  const int two_J = make_int (2.0*J);

  const bool is_J_integer = (two_J%2 == 0);

  const string L_str = make_string<int> (L);

  if (is_J_integer)
    {
      const int J_integer = make_int (J);

      const string J_str = make_string<int> (J_integer);

      switch (L)
	{
	case  0: return ("S" + J_str); 
	case  1: return ("P" + J_str); 
	case  2: return ("D" + J_str);
	case  3: return ("F" + J_str);
	case  4: return ("G" + J_str);
	case  5: return ("H" + J_str);
	case  6: return ("I" + J_str);
	case  7: return ("J" + J_str);
	case  8: return ("K" + J_str);
	case  9: return ("L" + J_str);
	case 10: return ("M" + J_str);
	case 11: return ("N" + J_str);
	case 12: return ("O" + J_str);
	case 13: return ("Q" + J_str);
	case 14: return ("R" + J_str);
	case 15: return ("T" + J_str);
	case 16: return ("U" + J_str);
	case 17: return ("V" + J_str);
	case 18: return ("W" + J_str);
	case 19: return ("X" + J_str);
	case 20: return ("Y" + J_str);
	case 21: return ("Z" + J_str);
	case 22: return ("A" + J_str);
	case 23: return ("B" + J_str);
	case 24: return ("D" + J_str);
	case 25: return ("E" + J_str);
	case 26: return ("a" + J_str);
	case 27: return ("b" + J_str);
	case 28: return ("c" + J_str);
	case 29: return ("d" + J_str);
	case 30: return ("e" + J_str);
	case 31: return ("f" + J_str);
	case 32: return ("g" + J_str);
	case 33: return ("h" + J_str);
	case 34: return ("i" + J_str);
	case 35: return ("j" + J_str);
	case 36: return ("k" + J_str);
	case 37: return ("l" + J_str);
	case 38: return ("m" + J_str);
	case 39: return ("n" + J_str);
	case 40: return ("o" + J_str);
	case 41: return ("p" + J_str);
	case 42: return ("q" + J_str);
	case 43: return ("r" + J_str);
	case 44: return ("s" + J_str);
	case 45: return ("t" + J_str);
	case 46: return ("u" + J_str);
	case 47: return ("v" + J_str);
	case 48: return ("w" + J_str);
	case 49: return ("x" + J_str);
	case 50: return ("y" + J_str);
	case 51: return ("z" + J_str);
	default: return ("L=" + L_str + " J=" + J_str);
	} 
    } 
  else
    {
      const string two_J_str = make_string<int> (two_J) + "/2";

      switch (L)
	{
	case  0: return ("S" + two_J_str);
	case  1: return ("P" + two_J_str);
	case  2: return ("D" + two_J_str);
	case  3: return ("F" + two_J_str);
	case  4: return ("G" + two_J_str);
	case  5: return ("H" + two_J_str);
	case  6: return ("I" + two_J_str);
	case  7: return ("J" + two_J_str);
	case  8: return ("K" + two_J_str);
	case  9: return ("L" + two_J_str);
	case 10: return ("M" + two_J_str);
	case 11: return ("N" + two_J_str);
	case 12: return ("O" + two_J_str);
	case 13: return ("Q" + two_J_str);
	case 14: return ("R" + two_J_str);
	case 15: return ("T" + two_J_str);
	case 16: return ("U" + two_J_str);
	case 17: return ("V" + two_J_str);
	case 18: return ("W" + two_J_str);
	case 19: return ("X" + two_J_str);
	case 20: return ("Y" + two_J_str);
	case 21: return ("Z" + two_J_str);
	case 22: return ("A" + two_J_str);
	case 23: return ("B" + two_J_str);
	case 24: return ("D" + two_J_str);
	case 25: return ("E" + two_J_str);
	case 26: return ("a" + two_J_str);
	case 27: return ("b" + two_J_str);
	case 28: return ("c" + two_J_str);
	case 29: return ("d" + two_J_str);
	case 30: return ("e" + two_J_str);
	case 31: return ("f" + two_J_str);
	case 32: return ("g" + two_J_str);
	case 33: return ("h" + two_J_str);
	case 34: return ("i" + two_J_str);
	case 35: return ("j" + two_J_str);
	case 36: return ("k" + two_J_str);
	case 37: return ("l" + two_J_str);
	case 38: return ("m" + two_J_str);
	case 39: return ("n" + two_J_str);
	case 40: return ("o" + two_J_str);
	case 41: return ("p" + two_J_str);
	case 42: return ("q" + two_J_str);
	case 43: return ("r" + two_J_str);
	case 44: return ("s" + two_J_str);
	case 45: return ("t" + two_J_str);
	case 46: return ("u" + two_J_str);
	case 47: return ("v" + two_J_str);
	case 48: return ("w" + two_J_str);
	case 49: return ("x" + two_J_str);
	case 50: return ("y" + two_J_str);
	case 51: return ("z" + two_J_str);
	default: return ("[L=" + L_str + "]" + two_J_str);
	}
    }
}



string string_routines::angular_state_cluster (const enum particle_type cluster , const int LCM , const double J)
{
  const int A = A_projectile_determine (cluster);

  const double J_intrinsic = J_intrinsic_projectile_determine (cluster);

  if (A == 1)
    return (angular_state (LCM , J));
  else if (A == 2)
    return (angular_state_two_body_cluster (J_intrinsic , LCM , J));
  else if (J_intrinsic == 0)
    return (angular_state_cluster_CM (LCM));
  else 
    return (angular_state_cluster_CM_intrinsic_spin (LCM , J));
}


string string_routines::angular_state_relative_cluster (const enum particle_type ST_cluster , const int l_relative , const double j_relative)
{
  if (!is_it_two_nucleon_ST_projectile_determine (ST_cluster)) error_message_print_abort ("Two-nucleon ST clusters only in angular_state_relative_cluster: " + make_string<enum particle_type> (ST_cluster));

  const string l_relative_str = make_string<int> (l_relative);

  const string j_relative_str = make_string<int> (j_relative);

  switch (l_relative)
    {
    case  0: return ("s" + j_relative_str); 
    case  1: return ("p" + j_relative_str); 
    case  2: return ("d" + j_relative_str);
    case  3: return ("f" + j_relative_str);
    case  4: return ("g" + j_relative_str);
    case  5: return ("h" + j_relative_str);
    case  6: return ("i" + j_relative_str);
    case  7: return ("j" + j_relative_str);
    case  8: return ("k" + j_relative_str);
    case  9: return ("l" + j_relative_str);
    case 10: return ("m" + j_relative_str);
    case 11: return ("n" + j_relative_str);
    case 12: return ("o" + j_relative_str);
    case 13: return ("q" + j_relative_str);
    case 14: return ("r" + j_relative_str);
    case 15: return ("t" + j_relative_str);
    case 16: return ("u" + j_relative_str);
    case 17: return ("v" + j_relative_str);
    case 18: return ("w" + j_relative_str);
    case 19: return ("x" + j_relative_str);
    case 20: return ("y" + j_relative_str);
    case 21: return ("z" + j_relative_str);
    case 22: return ("a" + j_relative_str);
    case 23: return ("b" + j_relative_str);
    case 24: return ("c" + j_relative_str);
    case 25: return ("e" + j_relative_str);
    case 26: return ("A" + j_relative_str);
    case 27: return ("B" + j_relative_str);
    case 28: return ("C" + j_relative_str);
    case 29: return ("D" + j_relative_str);
    case 30: return ("E" + j_relative_str);
    case 31: return ("F" + j_relative_str);
    case 32: return ("G" + j_relative_str);
    case 33: return ("H" + j_relative_str);
    case 34: return ("I" + j_relative_str);
    case 35: return ("J" + j_relative_str);
    case 36: return ("K" + j_relative_str);
    case 37: return ("L" + j_relative_str);
    case 38: return ("M" + j_relative_str);
    case 39: return ("N" + j_relative_str);
    case 40: return ("O" + j_relative_str);
    case 41: return ("P" + j_relative_str);
    case 42: return ("Q" + j_relative_str);
    case 43: return ("R" + j_relative_str);
    case 44: return ("S" + j_relative_str);
    case 45: return ("T" + j_relative_str);
    case 46: return ("U" + j_relative_str);
    case 47: return ("V" + j_relative_str);
    case 48: return ("W" + j_relative_str);
    case 49: return ("X" + j_relative_str);
    case 50: return ("Y" + j_relative_str);
    case 51: return ("Z" + j_relative_str);
    default: return ("l=" + l_relative_str + " j=" + j_relative_str);
    }   
}


string string_routines::angular_state_for_file_name (const int l , const double j)
{
  const int two_j = make_int (2.0*j);

  const bool is_j_integer = (two_j%2== 0);

  const string l_str = make_string<int> (l);

  if (is_j_integer)
    {
      const int j_integer = make_int (j);

      const string j_str = make_string<int> (j_integer);

      switch (l)
	{
	case  0: return ("s" + j_str); 
	case  1: return ("p" + j_str); 
	case  2: return ("d" + j_str);
	case  3: return ("f" + j_str);
	case  4: return ("g" + j_str);
	case  5: return ("h" + j_str);
	case  6: return ("i" + j_str);
	case  7: return ("j" + j_str);
	case  8: return ("k" + j_str);
	case  9: return ("l" + j_str);
	case 10: return ("m" + j_str);
	case 11: return ("n" + j_str);
	case 12: return ("o" + j_str);
	case 13: return ("q" + j_str);
	case 14: return ("r" + j_str);
	case 15: return ("t" + j_str);
	case 16: return ("u" + j_str);
	case 17: return ("v" + j_str);
	case 18: return ("w" + j_str);
	case 19: return ("x" + j_str);
	case 20: return ("y" + j_str);
	case 21: return ("z" + j_str);
	case 22: return ("a" + j_str);
	case 23: return ("b" + j_str);
	case 24: return ("c" + j_str);
	case 25: return ("e" + j_str);
	case 26: return ("A" + j_str);
	case 27: return ("B" + j_str);
	case 28: return ("C" + j_str);
	case 29: return ("D" + j_str);
	case 30: return ("E" + j_str);
	case 31: return ("F" + j_str);
	case 32: return ("G" + j_str);
	case 33: return ("H" + j_str);
	case 34: return ("I" + j_str);
	case 35: return ("J" + j_str);
	case 36: return ("K" + j_str);
	case 37: return ("L" + j_str);
	case 38: return ("M" + j_str);
	case 39: return ("N" + j_str);
	case 40: return ("O" + j_str);
	case 41: return ("P" + j_str);
	case 42: return ("Q" + j_str);
	case 43: return ("R" + j_str);
	case 44: return ("S" + j_str);
	case 45: return ("T" + j_str);
	case 46: return ("U" + j_str);
	case 47: return ("V" + j_str);
	case 48: return ("W" + j_str);
	case 49: return ("X" + j_str);
	case 50: return ("Y" + j_str);
	case 51: return ("Z" + j_str);
	default: return ("[l=" + l_str + "][j=" + j_str + "]");
	} 
    } 
  else
    {
      const string two_j_str = make_string<int> (two_j) + "I2";

      switch (l)
	{
	case  0: return ("s" + two_j_str);
	case  1: return ("p" + two_j_str);
	case  2: return ("d" + two_j_str);
	case  3: return ("f" + two_j_str);
	case  4: return ("g" + two_j_str);
	case  5: return ("h" + two_j_str);
	case  6: return ("i" + two_j_str);
	case  7: return ("j" + two_j_str);
	case  8: return ("k" + two_j_str);
	case  9: return ("l" + two_j_str);
	case 10: return ("m" + two_j_str);
	case 11: return ("n" + two_j_str);
	case 12: return ("o" + two_j_str);
	case 13: return ("q" + two_j_str);
	case 14: return ("r" + two_j_str);
	case 15: return ("t" + two_j_str);
	case 16: return ("u" + two_j_str);
	case 17: return ("v" + two_j_str);
	case 18: return ("w" + two_j_str);
	case 19: return ("x" + two_j_str);
	case 20: return ("y" + two_j_str);
	case 21: return ("z" + two_j_str);
	case 22: return ("a" + two_j_str);
	case 23: return ("b" + two_j_str);
	case 24: return ("c" + two_j_str);
	case 25: return ("e" + two_j_str);
	case 26: return ("A" + two_j_str);
	case 27: return ("B" + two_j_str);
	case 28: return ("C" + two_j_str);
	case 29: return ("D" + two_j_str);
	case 30: return ("E" + two_j_str);
	case 31: return ("F" + two_j_str);
	case 32: return ("G" + two_j_str);
	case 33: return ("H" + two_j_str);
	case 34: return ("I" + two_j_str);
	case 35: return ("J" + two_j_str);
	case 36: return ("K" + two_j_str);
	case 37: return ("L" + two_j_str);
	case 38: return ("M" + two_j_str);
	case 39: return ("N" + two_j_str);
	case 40: return ("O" + two_j_str);
	case 41: return ("P" + two_j_str);
	case 42: return ("Q" + two_j_str);
	case 43: return ("R" + two_j_str);
	case 44: return ("S" + two_j_str);
	case 45: return ("T" + two_j_str);
	case 46: return ("U" + two_j_str);
	case 47: return ("V" + two_j_str);
	case 48: return ("W" + two_j_str);
	case 49: return ("X" + two_j_str);
	case 50: return ("Y" + two_j_str);
	case 51: return ("Z" + two_j_str);
	default: return ("[l=" + l_str + "][j=" + two_j_str + "]");
	}
    }
}



string string_routines::angular_state_two_body_cluster_for_file_name (const int S , const int L , const double J)
{  
  return angular_state_two_body_cluster(S , L , J);
}




string string_routines::angular_state_cluster_CM_intrinsic_spin_for_file_name (const int L , const double J)
{
  const int two_J = make_int (2.0*J);

  const bool is_J_integer = (two_J%2 == 0);

  const string L_str = make_string<int> (L);

  if (is_J_integer)
    {
      const int J_integer = make_int (J);

      const string J_integer_str = make_string<int> (J_integer);

      switch (L)
	{
	case  0: return ("S" + J_integer_str); 
	case  1: return ("P" + J_integer_str); 
	case  2: return ("D" + J_integer_str);
	case  3: return ("F" + J_integer_str);
	case  4: return ("G" + J_integer_str);
	case  5: return ("H" + J_integer_str);
	case  6: return ("I" + J_integer_str);
	case  7: return ("J" + J_integer_str);
	case  8: return ("K" + J_integer_str);
	case  9: return ("L" + J_integer_str);
	case 10: return ("M" + J_integer_str);
	case 11: return ("N" + J_integer_str);
	case 12: return ("O" + J_integer_str);
	case 13: return ("Q" + J_integer_str);
	case 14: return ("R" + J_integer_str);
	case 15: return ("T" + J_integer_str);
	case 16: return ("U" + J_integer_str);
	case 17: return ("V" + J_integer_str);
	case 18: return ("W" + J_integer_str);
	case 19: return ("X" + J_integer_str);
	case 20: return ("Y" + J_integer_str);
	case 21: return ("Z" + J_integer_str);
	case 22: return ("A" + J_integer_str);
	case 23: return ("B" + J_integer_str);
	case 24: return ("D" + J_integer_str);
	case 25: return ("E" + J_integer_str);
	case 26: return ("a" + J_integer_str);
	case 27: return ("b" + J_integer_str);
	case 28: return ("c" + J_integer_str);
	case 29: return ("d" + J_integer_str);
	case 30: return ("e" + J_integer_str);
	case 31: return ("f" + J_integer_str);
	case 32: return ("g" + J_integer_str);
	case 33: return ("h" + J_integer_str);
	case 34: return ("i" + J_integer_str);
	case 35: return ("j" + J_integer_str);
	case 36: return ("k" + J_integer_str);
	case 37: return ("l" + J_integer_str);
	case 38: return ("m" + J_integer_str);
	case 39: return ("n" + J_integer_str);
	case 40: return ("o" + J_integer_str);
	case 41: return ("p" + J_integer_str);
	case 42: return ("q" + J_integer_str);
	case 43: return ("r" + J_integer_str);
	case 44: return ("s" + J_integer_str);
	case 45: return ("t" + J_integer_str);
	case 46: return ("u" + J_integer_str);
	case 47: return ("v" + J_integer_str);
	case 48: return ("w" + J_integer_str);
	case 49: return ("x" + J_integer_str);
	case 50: return ("y" + J_integer_str);
	case 51: return ("z" + J_integer_str);
	default: return ("[L=" + L_str + "][J=" + J_integer_str + "]");
	} 
    } 
  else
    {
      const string two_J_str = make_string<int> (two_J) + "I2";

      switch (L)
	{
	case  0: return ("S" + two_J_str);
	case  1: return ("P" + two_J_str);
	case  2: return ("D" + two_J_str);
	case  3: return ("F" + two_J_str);
	case  4: return ("G" + two_J_str);
	case  5: return ("H" + two_J_str);
	case  6: return ("I" + two_J_str);
	case  7: return ("J" + two_J_str);
	case  8: return ("K" + two_J_str);
	case  9: return ("L" + two_J_str);
	case 10: return ("M" + two_J_str);
	case 11: return ("N" + two_J_str);
	case 12: return ("O" + two_J_str);
	case 13: return ("Q" + two_J_str);
	case 14: return ("R" + two_J_str);
	case 15: return ("T" + two_J_str);
	case 16: return ("U" + two_J_str);
	case 17: return ("V" + two_J_str);
	case 18: return ("W" + two_J_str);
	case 19: return ("X" + two_J_str);
	case 20: return ("Y" + two_J_str);
	case 21: return ("Z" + two_J_str);
	case 22: return ("A" + two_J_str);
	case 23: return ("B" + two_J_str);
	case 24: return ("D" + two_J_str);
	case 25: return ("E" + two_J_str);
	case 26: return ("a" + two_J_str);
	case 27: return ("b" + two_J_str);
	case 28: return ("c" + two_J_str);
	case 29: return ("d" + two_J_str);
	case 30: return ("e" + two_J_str);
	case 31: return ("f" + two_J_str);
	case 32: return ("g" + two_J_str);
	case 33: return ("h" + two_J_str);
	case 34: return ("i" + two_J_str);
	case 35: return ("j" + two_J_str);
	case 36: return ("k" + two_J_str);
	case 37: return ("l" + two_J_str);
	case 38: return ("m" + two_J_str);
	case 39: return ("n" + two_J_str);
	case 40: return ("o" + two_J_str);
	case 41: return ("p" + two_J_str);
	case 42: return ("q" + two_J_str);
	case 43: return ("r" + two_J_str);
	case 44: return ("s" + two_J_str);
	case 45: return ("t" + two_J_str);
	case 46: return ("u" + two_J_str);
	case 47: return ("v" + two_J_str);
	case 48: return ("w" + two_J_str);
	case 49: return ("x" + two_J_str);
	case 50: return ("y" + two_J_str);
	case 51: return ("z" + two_J_str);
	default: return ("[L=" + L_str + "][J=" + two_J_str + "]");
	}
    }
}



string string_routines::angular_state_cluster_CM_for_file_name (const int L)
{
  return angular_state_cluster_CM (L);
}


string string_routines::angular_state_cluster_for_file_name (const enum particle_type cluster , const int LCM , const double J)
{
  const int A = A_projectile_determine (cluster);

  const double J_intrinsic = J_intrinsic_projectile_determine (cluster);

  if (A == 1)
    return (angular_state_for_file_name (LCM , J));
  else if (A == 2)
    return (angular_state_two_body_cluster_for_file_name (J_intrinsic , LCM , J));
  else if (J_intrinsic == 0)
    return (angular_state_cluster_CM_for_file_name (LCM));
  else 
    return (angular_state_cluster_CM_intrinsic_spin_for_file_name (LCM , J));
}


string string_routines::angular_state_relative_cluster_for_file_name (const enum particle_type ST_cluster , const int l_relative , const double j_relative)
{
  if (!is_it_two_nucleon_ST_projectile_determine (ST_cluster)) error_message_print_abort ("Two-nucleon ST clusters only in angular_state_relative_cluster_for_file_name: " + make_string<enum particle_type> (ST_cluster));

  const string l_relative_str = make_string<int> (l_relative);

  const string j_relative_str = make_string<int> (j_relative);

  switch (l_relative)
    {
    case  0: return ("relative_s" + j_relative_str); 
    case  1: return ("relative_p" + j_relative_str); 
    case  2: return ("relative_d" + j_relative_str);
    case  3: return ("relative_f" + j_relative_str);
    case  4: return ("relative_g" + j_relative_str);
    case  5: return ("relative_h" + j_relative_str);
    case  6: return ("relative_i" + j_relative_str);
    case  7: return ("relative_j" + j_relative_str);
    case  8: return ("relative_k" + j_relative_str);
    case  9: return ("relative_l" + j_relative_str);
    case 10: return ("relative_m" + j_relative_str);
    case 11: return ("relative_n" + j_relative_str);
    case 12: return ("relative_o" + j_relative_str);
    case 13: return ("relative_q" + j_relative_str);
    case 14: return ("relative_r" + j_relative_str);
    case 15: return ("relative_t" + j_relative_str);
    case 16: return ("relative_u" + j_relative_str);
    case 17: return ("relative_v" + j_relative_str);
    case 18: return ("relative_w" + j_relative_str);
    case 19: return ("relative_x" + j_relative_str);
    case 20: return ("relative_y" + j_relative_str);
    case 21: return ("relative_z" + j_relative_str);
    case 22: return ("relative_a" + j_relative_str);
    case 23: return ("relative_b" + j_relative_str);
    case 24: return ("relative_c" + j_relative_str);
    case 25: return ("relative_e" + j_relative_str);
    case 26: return ("relative_A" + j_relative_str);
    case 27: return ("relative_B" + j_relative_str);
    case 28: return ("relative_C" + j_relative_str);
    case 29: return ("relative_D" + j_relative_str);
    case 30: return ("relative_E" + j_relative_str);
    case 31: return ("relative_F" + j_relative_str);
    case 32: return ("relative_G" + j_relative_str);
    case 33: return ("relative_H" + j_relative_str);
    case 34: return ("relative_I" + j_relative_str);
    case 35: return ("relative_J" + j_relative_str);
    case 36: return ("relative_K" + j_relative_str);
    case 37: return ("relative_L" + j_relative_str);
    case 38: return ("relative_M" + j_relative_str);
    case 39: return ("relative_N" + j_relative_str);
    case 40: return ("relative_O" + j_relative_str);
    case 41: return ("relative_P" + j_relative_str);
    case 42: return ("relative_Q" + j_relative_str);
    case 43: return ("relative_R" + j_relative_str);
    case 44: return ("relative_S" + j_relative_str);
    case 45: return ("relative_T" + j_relative_str);
    case 46: return ("relative_U" + j_relative_str);
    case 47: return ("relative_V" + j_relative_str);
    case 48: return ("relative_W" + j_relative_str);
    case 49: return ("relative_X" + j_relative_str);
    case 50: return ("relative_Y" + j_relative_str);
    case 51: return ("relative_Z" + j_relative_str);
    default: return ("relative_[l=" + l_relative_str + "][j=" + j_relative_str + "]");
    }   
}







int string_routines::determine_n (const string &shell)
{
  if (shell.length () == 0) error_message_print_abort ("determine_n: empty shell");

  string n_string;

  for (unsigned int i = 0 ; ((i < shell.length ()) && isdigit (shell[i])) ; i++)
    {
      n_string += shell[i];
    }
  
  if (n_string.length () == 0) error_message_print_abort ("determine_n: no n read");

  const int n = atoi (n_string.c_str ());
  
  if (n > 1000000) error_message_print_abort ("determine_n: bad or too large (n > 1000000) : " + n_string);
  
  return n;
}



int string_routines::determine_l (const string &shell)
{
  const string shell_ended = shell + '\n';

  unsigned int i = 0;

  while (true)
    {
      switch (shell_ended[i])
	{
	case 's': return 0;
	case 'p': return 1;
	case 'd': return 2;
	case 'f': return 3;
	case 'g': return 4;
	case 'h': return 5;
	case 'i': return 6;
	case 'j': return 7;
	case 'k': return 8;
	case 'l': return 9;
	case 'm': return 10;
	case 'n': return 11;
	case 'o': return 12;
	case 'q': return 13;
	case 'r': return 14;
	case 't': return 15;
	case 'u': return 16;
	case 'v': return 17;
	case 'w': return 18;
	case 'x': return 19;
	case 'y': return 20;
	case 'z': return 21;
	case 'a': return 22;
	case 'b': return 23;
	case 'c': return 24;
	case 'e': return 25;
	case 'A': return 26;
	case 'B': return 27;
	case 'C': return 28;
	case 'D': return 29;
	case 'E': return 30;
	case 'F': return 31;
	case 'G': return 32;
	case 'H': return 33;
	case 'I': return 34;
	case 'J': return 35;
	case 'K': return 36;
	case 'L': return 37;
	case 'M': return 38;
	case 'N': return 39;
	case 'O': return 40;
	case 'P': return 41;
	case 'Q': return 42;
	case 'R': return 43;
	case 'S': return 44;
	case 'T': return 45;
	case 'U': return 46;
	case 'V': return 47;
	case 'W': return 48;
	case 'X': return 49;
	case 'Y': return 50;
	case 'Z': return 51;
	case '\n': {error_message_print_abort ("No orbital quantum number in string_routines::determine_l:" + shell_ended); break;}
	default: i++;
	}
    }
}

int string_routines::determine_L_cluster (const enum particle_type cluster , const string &shell)
{
  const int A = A_projectile_determine (cluster);

  const string shell_ended = shell + '\n';

  unsigned int i = 0;

  if (A == 1)
    {
      while (true)
	{
	  switch (shell_ended[i])
	    {
	    case 's': return 0;
	    case 'p': return 1;
	    case 'd': return 2;
	    case 'f': return 3;
	    case 'g': return 4;
	    case 'h': return 5;
	    case 'i': return 6;
	    case 'j': return 7;
	    case 'k': return 8;
	    case 'l': return 9;
	    case 'm': return 10;
	    case 'n': return 11;
	    case 'o': return 12;
	    case 'q': return 13;
	    case 'r': return 14;
	    case 't': return 15;
	    case 'u': return 16;
	    case 'v': return 17;
	    case 'w': return 18;
	    case 'x': return 19;
	    case 'y': return 20;
	    case 'z': return 21;
	    case 'a': return 22;
	    case 'b': return 23;
	    case 'c': return 24;
	    case 'e': return 25;
	    case 'A': return 26;
	    case 'B': return 27;
	    case 'C': return 28;
	    case 'D': return 29;
	    case 'E': return 30;
	    case 'F': return 31;
	    case 'G': return 32;
	    case 'H': return 33;
	    case 'I': return 34;
	    case 'J': return 35;
	    case 'K': return 36;
	    case 'L': return 37;
	    case 'M': return 38;
	    case 'N': return 39;
	    case 'O': return 40;
	    case 'P': return 41;
	    case 'Q': return 42;
	    case 'R': return 43;
	    case 'S': return 44;
	    case 'T': return 45;
	    case 'U': return 46;
	    case 'V': return 47;
	    case 'W': return 48;
	    case 'X': return 49;
	    case 'Y': return 50;
	    case 'Z': return 51;
	    case '\n': {error_message_print_abort ("No orbital quantum number in string_routines::determine_L_cluster:" + shell_ended + " (nucleon case)"); break;}
	    default: i++;
	    }
	}
    }
  else
    {
      while (true)
	{
	  switch (shell_ended[i])
	    {
	    case 'S': return 0;
	    case 'P': return 1;
	    case 'D': return 2;
	    case 'F': return 3;
	    case 'G': return 4;
	    case 'H': return 5;
	    case 'I': return 6;
	    case 'J': return 7;
	    case 'K': return 8;
	    case 'L': return 9;
	    case 'M': return 10;
	    case 'N': return 11;
	    case 'O': return 12;
	    case 'Q': return 13;
	    case 'R': return 14;
	    case 'T': return 15;
	    case 'U': return 16;
	    case 'V': return 17;
	    case 'W': return 18;
	    case 'X': return 19;
	    case 'Y': return 20;
	    case 'Z': return 21;
	    case 'A': return 22;
	    case 'B': return 23;
	    case 'C': return 24;
	    case 'E': return 25;
	    case 'a': return 26;
	    case 'b': return 27;
	    case 'c': return 28;
	    case 'd': return 29;
	    case 'e': return 30;
	    case 'f': return 31;
	    case 'g': return 32;
	    case 'h': return 33;
	    case 'i': return 34;
	    case 'j': return 35;
	    case 'k': return 36;
	    case 'l': return 37;
	    case 'm': return 38;
	    case 'n': return 39;
	    case 'o': return 40;
	    case 'p': return 41;
	    case 'q': return 42;
	    case 'r': return 43;
	    case 's': return 44;
	    case 't': return 45;
	    case 'u': return 46;
	    case 'v': return 47;
	    case 'w': return 48;
	    case 'x': return 49;
	    case 'y': return 50;
	    case 'z': return 51;
	    case '\n': {error_message_print_abort ("No orbital quantum number in string_routines::determine_L_cluster:" + shell_ended + " (cluster case)"); break;}
	    default: i++;
	    }
	}
    }

  return NADA;
}







// from a format: "0s0" or "2p1" or "0d4"
int string_routines::determine_jr (const string &shell)
{
  string shell_local = shell;

  shell_local.erase (std::remove (shell_local.begin () , shell_local.end () , '\n') , shell_local.end ());

  unsigned int i = 0;
  
  while (isdigit (shell_local[i])) i++;

  // cut the letter "s , p , d , ..."
  string jr_str = shell_local.substr (i+1 , shell_local.length () - 1);

  if (jr_str == "0") return 0;
  if (jr_str == "1") return 1;
  if (jr_str == "2") return 2;
  if (jr_str == "3") return 3;
  if (jr_str == "4") return 4;
  if (jr_str == "5") return 5;
  if (jr_str == "6") return 6;
  if (jr_str == "7") return 7;
  if (jr_str == "8") return 8;
  if (jr_str == "9") return 9;
  if (jr_str == "10") return 10;
  if (jr_str == "11") return 11;
  if (jr_str == "12") return 12;
  if (jr_str == "13") return 13;
  if (jr_str == "14") return 14;
  if (jr_str == "15") return 15;
  if (jr_str == "16") return 16;
  if (jr_str == "17") return 17;
  if (jr_str == "18") return 18;
  if (jr_str == "19") return 19;
  if (jr_str == "20") return 20;
  if (jr_str == "21") return 21;
  if (jr_str == "22") return 22;
  if (jr_str == "23") return 23;
  if (jr_str == "24") return 24;
  if (jr_str == "25") return 25;
  if (jr_str == "26") return 26;
  if (jr_str == "27") return 27;
  if (jr_str == "28") return 28;
  if (jr_str == "29") return 29;
  if (jr_str == "30") return 30;
  if (jr_str == "31") return 31;
  if (jr_str == "32") return 32;
  if (jr_str == "33") return 33;
  if (jr_str == "34") return 34;
  if (jr_str == "35") return 35;
  if (jr_str == "36") return 36;
  if (jr_str == "37") return 37;
  if (jr_str == "38") return 38;
  if (jr_str == "39") return 39;
  if (jr_str == "40") return 40;
  if (jr_str == "41") return 41;
  if (jr_str == "42") return 42;
  if (jr_str == "43") return 43;
  if (jr_str == "44") return 44;
  if (jr_str == "45") return 45;
  if (jr_str == "46") return 46;
  if (jr_str == "47") return 47;
  if (jr_str == "48") return 48;
  if (jr_str == "49") return 49;
  if (jr_str == "50") return 50;
  if (jr_str == "51") return 51;

  error_message_print_abort ("determine_jr: bad or too large (jr > 26) rotor angular momentum.");

  return 0;
}


double string_routines::determine_j (const string &shell)
{
  const string shell_ended = shell + '\n';

  int i = 0;

  while (isdigit (shell_ended[i]))
    {
      if (shell_ended[i] == '\n') error_message_print_abort ("Problem in string_routines::determine_j : " + shell);
      
      i++;
    }

  i++;

  string j_str;

  while (shell_ended[i] != '/')
    {
      j_str += shell_ended[i];
      
      i++;

      if (shell_ended[i] == '\n')
	{	  
	  if (j_str.length () == 0) error_message_print_abort ("determine_j: no j read (integer j)");
	  
	  const double j = atof (j_str.c_str ());
	    
	  if (j > 1000000) error_message_print_abort ("determine_j: bad or too large (integer j > 1000000) : " + j_str);
	  
	  return j;
	}
    }
  
  if (j_str.length () == 0) error_message_print_abort ("determine_j: no j read (half-integer j)");
	  
  const double two_j = atof (j_str.c_str ());

  const double j = 0.5*two_j;
	  
  if (j > 1000000) error_message_print_abort ("determine_j: bad or too large (half-integer j > 1000000) : " + j_str + "/2");
	  
  return j;
}



double string_routines::determine_J_cluster (const string &shell)
{
  const string shell_ended = shell + '\n';

  int i = 0;

  while (isdigit (shell_ended[i]))
    {
      if (shell_ended[i] == '\n') error_message_print_abort ("Problem in string_routines::determine_J_cluster : " + shell);
      
      i++;
    }

  i++;

  string J_str;

  while (shell_ended[i] != '/')
    {
      J_str += shell_ended[i];
      i++;

      if (shell_ended[i] == '\n')
	{
	  if (J_str.length () == 0) error_message_print_abort ("determine_J_cluster: no J read (integer J)");
  
	  const double J = atof (J_str.c_str ());
	  
	  if (J > 1000000) error_message_print_abort ("determine_J_cluster: bad or too large (integer J > 1000000) : " + J_str);
	  
	  return J;
	}
    }

  if (J_str.length () == 0) error_message_print_abort ("determine_J_cluster: no J read (half-integer J)");
	  
  const double two_J = atof (J_str.c_str ());

  const double J = 0.5*two_J;
	  
  if (J > 1000000) error_message_print_abort ("determine_J: bad or too large (half-integer J > 1000000) : " + J_str + "/2");
	  
  return J;
}



double string_routines::determine_M_cluster (const string &shell)
{
  const string shell_ended = shell + '\n';

  int i = 0;

  while (isdigit (shell_ended[i]))
    {
      if (shell_ended[i] == '\n') error_message_print_abort ("Problem in string_routines::determine_M_cluster : " + shell);
      
      i++;
    }

  i++;

  string M_str;

  while (shell_ended[i] != '/')
    {
      M_str += shell_ended[i];
      i++;

      if (shell_ended[i] == '\n')
	{
	  if (M_str.length () == 0) error_message_print_abort ("determine_M_cluster: no M read (integer M)");
	  
	  const double M = atof (M_str.c_str ());
	  
	  if (M > 1000000) error_message_print_abort ("determine_M_cluster: bad or too large (integer M > 1000000) : " + M_str);
	  
	  return M;
	}
    }

  if (M_str.length () == 0) error_message_print_abort ("determine_M_cluster: no M read (half-integer M)");
  
  const double two_M = atof (M_str.c_str ());

  const double M = 0.5*two_M;
	  
  if (M > 1000000) error_message_print_abort ("determine_M: bad or too large (half-integer M > 1000000) : " + M_str + "/2");
	  
  return M;
}






double string_routines::determine_half_integer_J (const string &s)
{
  const string s_ended = s + '\n';
  
  string J_str;

  for (unsigned int i = 0; s[i] != '/'; i++)
    {
      if (s_ended[i] == '\n') error_message_print_abort ("No half-integer found in string_routines::determine_half_integer_J : " + s);
      
      J_str += s[i];
    }
  
  if (J_str.length () == 0) error_message_print_abort ("determine_half_integer_J: no J read");
  
  const double two_J = atof (J_str.c_str ());

  const double J = 0.5*two_J;
	  
  if (J > 1000000) error_message_print_abort ("determine_half_integer_J: bad or too large (J > 1000000) : " + J_str + "/2");
	  
  return J;
}





double string_routines::determine_half_integer_M (const string &s)
{
  const string s_ended = s + '\n';
  
  string M_str;

  for (unsigned int i = 0; s[i] != '/'; i++)
    {
      if (s_ended[i] == '\n') error_message_print_abort ("No half-integer found in string_routines::determine_half_integer_M : " + s);
      
      M_str += s[i];
    }
  
  if (M_str.length () == 0) error_message_print_abort ("determine_half_integer_M: no M read");
  
  const double two_M = atof (M_str.c_str ());

  const double M = 0.5*two_M;
	  
  if (M > 1000000) error_message_print_abort ("determine_half_integer_M: bad or too large (M > 1000000) : " + M_str + "/2");
	  
  return M;
}






double string_routines::determine_half_integer_T (const string &s)
{
  const string s_ended = s + '\n';
  
  unsigned int i = 0;

  while (s_ended[i] != 'T')
    {
      if (s_ended[i] == '\n') error_message_print_abort ("No T found in string_routines::determine_half_integer_T : " + s);
      
      i++;
    }

  i += 2;

  string T_str;
  
  while (s_ended[i] != '/')
    {
      if (s_ended[i] == '\n') error_message_print_abort ("No half-integer found in string_routines::determine_half_integer_T:" + s);
      
      T_str += s_ended[i];

      i++;
    }

  if (T_str.length () == 0) error_message_print_abort ("determine_half_integer_T: no T read");
  
  const double two_T = atof (T_str.c_str ()) , T = 0.5*two_T;
	  
  if (T > 1000000) error_message_print_abort ("determine_half_integer_T: bad or too large (T > 1000000) : " + T_str + "/2");
	  
  return T;
}








double string_routines::determine_integer_J (const string &s)
{
  const string s_ended = s + '\n';
  
  string J_str;

  for (unsigned int i = 0; ((s_ended[i] != '+') && (s_ended[i] != '-') && (s_ended[i] != '\n')); i++)
    {
      J_str += s_ended[i];
    }
  
  if (J_str.length () == 0) error_message_print_abort ("determine_integer_J: no J read");
  
  const double J = atof (J_str.c_str ());
  
  if (J > 1000000) error_message_print_abort ("determine_integer_J: bad or too large (J > 1000000) : " + J_str);
  
  return J;
}



double string_routines::determine_integer_M (const string &s)
{
  const string s_ended = s + '\n';
  
  string M_str;

  for (unsigned int i = 0; ((s_ended[i] != '+') && (s_ended[i] != '-') && (s_ended[i] != '\n')); i++)
    {
      M_str += s_ended[i];
    }
  
  if (M_str.length () == 0) error_message_print_abort ("determine_integer_M: no M read");
  
  const double M = atof (M_str.c_str ());
  
  if (M > 1000000) error_message_print_abort ("determine_integer_M: bad or too large (M > 1000000) : " + M_str);
  
  return M;
}


double string_routines::determine_integer_T (const string &s)
{
  const string s_ended = s + '\n';
  
  unsigned int i = 0;
  
  while (s_ended[i] != 'T')
    {
      if (s_ended[i] == '\n') error_message_print_abort ("No T found in string_routines::determine_integer_T:" + s);

      i++;
    }

  i += 2;

  string T_str;

  while (s_ended[i] != '\n')
    {      
      T_str += s_ended[i];
      
      i++;
    }

  if (T_str.length () == 0) error_message_print_abort ("determine_integer_T: no T read");
  
  const double T = atof (T_str.c_str ());
	  
  if (T > 1000000) error_message_print_abort ("determine_integer_T: bad or too large (T > 1000000) : " + T_str);
  
  return T;
}







double string_routines::determine_J (const string &s)
{
  const string s_ended = s + '\n';

  //--// > 1000 <=> not found
  if (s_ended.find ("/2") > 1000)
    return determine_integer_J (s_ended); 
  else
    return determine_half_integer_J (s_ended);
}

double string_routines::determine_M (const string &s)
{
  const string s_ended = s + '\n';

  //--// > 1000 <=> not found
  if (s_ended.find ("/2") > 1000)
    return determine_integer_M (s_ended); 
  else
    return determine_half_integer_M (s_ended);
}




unsigned int string_routines::determine_Binary_Parity (const string &s)
{
  const string s_ended = s + '\n';

  unsigned int i = 0;

  while (true)
    {
      switch (s_ended[i])
	{
	case '+' : return 0;
	case '-' : return 1;
	  
	case '\n': {error_message_print_abort (" No parity found in string_routines::determine_Binary_Parity:" + s); return NADA;}

	default: i++;
	}
    }
}



bool string_routines::bool_determination_no_print (ifstream &file , const string &words)
{
  string bool_word;
  
  file >> bool_word;

  if (bool_word == words + "(yes)") return true;

  if (bool_word == words + "(no)") return false;

  error_message_print_abort ("Problem : " + words + "(yes or no) [reference word] <--> " + bool_word + " [read word].");

  return false;
}


bool string_routines::bool_determination_no_print (const string &words)
{
  string bool_word;
  
  cin >> bool_word;

  if (bool_word == words + "(yes)") return true;

  if (bool_word == words + "(no)") return false;

  error_message_print_abort ("Problem : " + words + "(yes or no) [reference word] <--> " + bool_word + " [read word].");

  return false;
}

bool string_routines::bool_determination (ifstream &file , const string &words)
{
  string bool_word;
  
  file >> bool_word;

  if (bool_word == words + "(yes)") 
    {
      cout << bool_word << endl;

      return true;
    }

  if (bool_word == words + "(no)")
    {
      cout << bool_word << endl;

      return false;
    }

  error_message_print_abort ("Problem : " + words + "(yes or no) [reference word] <--> " + bool_word + " [read word].");

  return false;
}


bool string_routines::bool_determination (const string &words)
{
  string bool_word;
  cin >> bool_word;
	
  if (bool_word == words + "(yes)") 
    {
      cout << bool_word << endl;

      return true;
    }

  if (bool_word == words + "(no)")
    {
      cout << bool_word << endl;

      return false;
    }

  error_message_print_abort ("Problem : " + words + "(yes or no) [reference word] <--> " + bool_word + " [read word].");

  return false;
}



void string_routines::word_check (const string &expected_string)
{
  string input_string;
  
  cin >> input_string;

  if (input_string != expected_string) error_message_print_abort ("Problem : " + expected_string + " (expected) ---- " + input_string + " (input)");
}



void string_routines::word_check (ifstream &file , const string &expected_string)
{
  string input_string;
  
  file >> input_string;

  if (input_string != expected_string) error_message_print_abort ("Problem : " + expected_string + " (expected) ---- " + input_string + " (input)");
}



void string_routines::check_partial_wave_nucleon (
						  const int l ,
						  const double j)
{
  const double j_minus_half = j - 0.5;
    
  const double jmin = abs (l - 0.5);

  const double jmax = l + 0.5;

  const bool is_partial_wave_angular_coupling_possible = ((abs (j_minus_half - rint (j_minus_half)) < precision) && ((rint (j - jmin) >= 0.0) && (rint (j - jmax) <= 0.0)));

  if (!is_partial_wave_angular_coupling_possible) error_message_print_abort ("Wrong partial wave coupling for nucleon :   l:" + make_string<int> (l)  + "   j:" + J_string (j));
}

void string_routines::check_partial_wave (
					  const enum particle_type particle,
					  const int LCM ,
					  const double J)
{
  const bool is_partial_wave_angular_coupling_possible = is_partial_wave_angular_coupling_possible_determine (particle , LCM , J);

  if (!is_partial_wave_angular_coupling_possible)
    {
      const double J_intrinsic = J_intrinsic_projectile_determine (particle);
  
      error_message_print_abort ("Wrong partial wave coupling.   particle:" + make_string<enum particle_type> (particle) + "   spin:" + J_string (J_intrinsic)  + "   l:" + make_string<int> (LCM)  + "   j:" + J_string (J));
    }
}



void string_routines::check_relative_partial_wave (
						   const int l_relative ,
						   const int j_relative)
{
  const int jmin_relative_all_spins = min (l_relative , abs (l_relative - 1));

  const int jmax_relative_all_spins = l_relative + 1;

  const bool is_partial_wave_angular_coupling_possible = ((j_relative >= jmin_relative_all_spins) && (j_relative <= jmax_relative_all_spins));
  
  if (!is_partial_wave_angular_coupling_possible)
    error_message_print_abort ("Wrong relative partial wave coupling.   S:0,1   l:" + make_string<int> (l_relative)  + "   j:" + J_string (j_relative));
}



void string_routines::quantum_numbers_read (
					    unsigned int &BP , 
					    int &J , 
					    unsigned int &vector_index)
{
  string PSI_string;
  cin >> PSI_string;

  BP = determine_Binary_Parity (PSI_string);
  J = make_int (determine_J (PSI_string));

  cin >> vector_index;
}


void string_routines::quantum_numbers_read (
					    unsigned int &BP , 
					    double &J , 
					    unsigned int &vector_index)
{
  string PSI_string;
  cin >> PSI_string;

  BP = determine_Binary_Parity (PSI_string);
  J = determine_J (PSI_string);

  cin >> vector_index;
}


void string_routines::quantum_numbers_read (
					    ifstream &file , 
					    unsigned int &BP , 
					    int &J , 
					    unsigned int &vector_index)
{
  string PSI_string;
  file >> PSI_string;

  BP = determine_Binary_Parity (PSI_string);
  J = make_int (determine_J (PSI_string));

  file >> vector_index;
}


void string_routines::quantum_numbers_read (
					    ifstream &file , 
					    unsigned int &BP , 
					    double &J , 
					    unsigned int &vector_index)
{
  string PSI_string;
  file >> PSI_string;

  BP = determine_Binary_Parity (PSI_string);
  J = determine_J (PSI_string);

  file >> vector_index;
}




string string_routines::Pi_string (const unsigned int BP)
{
  switch (BP)
    {
    case 0: return "+";

    case 1: return "-";

    default: abort_all ();
    }

  return "";
}




string string_routines::J_string (const double J)
{
  const int two_J = make_int (2.0*J);

  const string J_str = (two_J%2 == 0) ? (make_string<int> (two_J/2)) : (make_string<int> (two_J) + "/2");

  return J_str;
}

string string_routines::M_string (const double M)
{
  const int two_M = make_int (2.0*M);

  const string M_str = (two_M%2 == 0) ? (make_string<int> (two_M/2)) : (make_string<int> (two_M) + "/2");

  return M_str;
}

string string_routines::T_string (const double T)
{
  const int two_T = make_int (2.0*T);

  const string T_str = (two_T%2 == 0) ? (make_string<int> (two_T/2)) : (make_string<int> (two_T) + "/2");

  return T_str;
}

string string_routines::J_Pi_string (
				     const unsigned int BP , 
				     const double J)
{	
  const string J_Pi_str = J_string (J) + Pi_string (BP);

  return J_Pi_str;
}

string string_routines::M_Pi_string (
				     const unsigned int BP , 
				     const double M)
{	
  const string M_Pi_str = M_string (M) + Pi_string (BP);

  return M_Pi_str;
}

string string_routines::JM_string (
				   const double J , 
				   const double M)
{	
  const string JM_str = J_string (J) + "(M=" + M_string (M) + ")";

  return JM_str;
}

string string_routines::JM_Pi_string (
				      const unsigned int BP ,  
				      const double J , 
				      const double M)
{	
  const string JM_Pi_str = J_Pi_string (BP , J) + "(M=" + M_string (M) + ")";

  return JM_Pi_str;
}

string string_routines::J_Pi_vector_index_string (
						  const unsigned int BP , 
						  const double J , 
						  const unsigned int vector_index)
{
  return (J_Pi_string (BP , J) + "(" + make_string<unsigned int> (vector_index) + ")");
}

string string_routines::M_Pi_vector_index_string (
						  const unsigned int BP , 
						  const double M , 
						  const unsigned int vector_index)
{
  return (M_Pi_string (BP , M) + "(" + make_string<unsigned int> (vector_index) + ")");
}

string string_routines::JM_Pi_vector_index_string (
						   const unsigned int BP , 
						   const double J , 
						   const unsigned int vector_index , 
						   const double M) 
{
  return (J_Pi_vector_index_string (BP , J , vector_index) + " (M=" + M_string (M) + ")"); 
}


string string_routines::Pi_string_for_file_name (const unsigned int BP)
{
  return Pi_string (BP);
}


string string_routines::J_string_for_file_name (const double J)
{
  const int two_J = make_int (2.0*J);

  const string J_str = (two_J%2 == 0) ? (make_string<int> (two_J/2)) : (make_string<int> (two_J) + "I2");

  return J_str;
}

string string_routines::M_string_for_file_name (const double M)
{
  const int two_M = make_int (2.0*M);

  const string M_str = (two_M%2 == 0) ? (make_string<int> (two_M/2)) : (make_string<int> (two_M) + "I2");

  return M_str;
}

string string_routines::T_string_for_file_name (const double T)
{
  const int two_T = make_int (2.0*T);

  const string T_str = (two_T%2 == 0) ? (make_string<int> (two_T/2)) : (make_string<int> (two_T) + "I2");

  return T_str;
}

string string_routines::J_Pi_string_for_file_name (
						   const unsigned int BP , 
						   const double J)
{	
  const string J_Pi_str = J_string_for_file_name (J) + Pi_string (BP);

  return J_Pi_str;
}

string string_routines::M_Pi_string_for_file_name (
						   const unsigned int BP , 
						   const double M)
{	
  const string M_Pi_str = M_string_for_file_name (M) + Pi_string (BP);

  return M_Pi_str;
}

string string_routines::JM_string_for_file_name (
						 const double J , 
						 const double M)
{	
  const string JM_str = J_string_for_file_name (J) + "_" + M_string_for_file_name (M);

  return JM_str;
}

string string_routines::JM_Pi_string_for_file_name (
						    const unsigned int BP ,  
						    const double J , 
						    const double M)
{	
  const string JM_Pi_str = J_Pi_string_for_file_name (BP , J) + "_" + M_string_for_file_name (M);

  return JM_Pi_str;
}

string string_routines::J_Pi_vector_index_string_for_file_name (
								const unsigned int BP , 
								const double J , 
								const unsigned int vector_index)
{
  return (J_Pi_string_for_file_name (BP , J) + "_" + make_string<unsigned int> (vector_index));
}

string string_routines::M_Pi_vector_index_string_for_file_name (
								const unsigned int BP , 
								const double M , 
								const unsigned int vector_index)
{
  return (M_Pi_string_for_file_name (BP , M) + "_" + make_string<unsigned int> (vector_index));
}

string string_routines::JM_Pi_vector_index_string_for_file_name (
								 const unsigned int BP , 
								 const double J , 
								 const unsigned int vector_index , 
								 const double M) 
{
  return (J_Pi_vector_index_string_for_file_name (BP , J , vector_index) + "_" + M_string_for_file_name (M)); 
}






//--// get the range (min , max , step) of double type values like word_check_print
void string_routines::val_range_check_print (
					     ifstream &file_ , 
					     const string &correct_string_min_ , 
					     double &val_min_ , 
					     const string &correct_string_max_ , 
					     double &val_max_ , 
					     const string &correct_string_n_step_ , 
					     unsigned int &n_step_)
{
  file_ >> val_min_;
  word_check_print<double> (file_ , correct_string_min_.c_str () , val_min_);

  file_ >> val_max_;
  word_check_print<double> (file_ , correct_string_max_.c_str () , val_max_);

  if (val_min_ > val_max_) error_message_print_abort ( "------ val_range_check_print: val_min_ > val_max_ ------");

  file_ >> n_step_;
  word_check_print<double> (file_ , correct_string_n_step_.c_str () , n_step_);
}



string string_routines::CM_cluster_string (
					   const int NCM , 
					   const int LCM)
{
  return (make_string<int> (NCM) + angular_state_cluster_CM (LCM));
}

string string_routines::CM_cluster_string (
					   const int NCM , 
					   const int LCM , 
					   const int M_LCM)
{
  return (make_string<int> (NCM) + angular_state_cluster_CM (LCM) + " " + make_string<int> (M_LCM));
}



string string_routines::cluster_string_for_file_name (const enum particle_type cluster)
{
  switch (cluster)
    {
    case PROTON:    return "proton";
    case NEUTRON:   return "neutron";
    case ELECTRON:  return "electron";
    case DIPROTON:  return "diproton";
    case DINEUTRON: return "dineutron";
    case DEUTERON:  return "deuteron";
    case TRITON:    return "triton";
    case HE3:       return "He3";
    case ALPHA:     return "alpha";

    case DIPROTON_S0_T1: return "diproton_S0_T1";
    case DIPROTON_S1_T1: return "diproton_S1_T1";

    case DINEUTRON_S0_T1: return "dineutron_S0_T1";
    case DINEUTRON_S1_T1: return "dineutron_S1_T1";

    case DEUTERON_S0_T0: return "deuteron_S0_T0";
    case DEUTERON_S1_T0: return "deuteron_S1_T0";
    case DEUTERON_S0_T1: return "deuteron_S0_T1";
    case DEUTERON_S1_T1: return "deuteron_S1_T1";

    case DIPROTON_0_PLUS_S0_T1:    return "diproton_S0_T1_0+";
    case DIPROTON_0_PLUS_S0_T1_0:  return "diproton_S0_T1_0+_0";
    case DIPROTON_0_PLUS_S0_T1_1:  return "diproton_S0_T1_0+_1";
    case DIPROTON_0_PLUS_S0_T1_2:  return "diproton_S0_T1_0+_2";
    case DIPROTON_0_PLUS_S0_T1_3:  return "diproton_S0_T1_0+_3";
    case DIPROTON_0_PLUS_S0_T1_4:  return "diproton_S0_T1_0+_4";
    case DIPROTON_0_PLUS_S0_T1_5:  return "diproton_S0_T1_0+_5";
    case DIPROTON_0_PLUS_S0_T1_6:  return "diproton_S0_T1_0+_6";
    case DIPROTON_0_PLUS_S0_T1_7:  return "diproton_S0_T1_0+_7";
    case DIPROTON_0_PLUS_S0_T1_8:  return "diproton_S0_T1_0+_8";
    case DIPROTON_0_PLUS_S0_T1_9:  return "diproton_S0_T1_0+_9";
    case DIPROTON_0_PLUS_S0_T1_10: return "diproton_S0_T1_0+_10";
    case DIPROTON_0_PLUS_S0_T1_11: return "diproton_S0_T1_0+_11";
    case DIPROTON_0_PLUS_S0_T1_12: return "diproton_S0_T1_0+_12";
    case DIPROTON_0_PLUS_S0_T1_13: return "diproton_S0_T1_0+_13";
    case DIPROTON_0_PLUS_S0_T1_14: return "diproton_S0_T1_0+_14";
    case DIPROTON_0_PLUS_S0_T1_15: return "diproton_S0_T1_0+_15";
    case DIPROTON_0_PLUS_S0_T1_16: return "diproton_S0_T1_0+_16";
    case DIPROTON_0_PLUS_S0_T1_17: return "diproton_S0_T1_0+_17";
    case DIPROTON_0_PLUS_S0_T1_18: return "diproton_S0_T1_0+_18";
    case DIPROTON_0_PLUS_S0_T1_19: return "diproton_S0_T1_0+_19";
    case DIPROTON_0_PLUS_S0_T1_20: return "diproton_S0_T1_0+_20";
    case DIPROTON_0_PLUS_S0_T1_21: return "diproton_S0_T1_0+_21";
    case DIPROTON_0_PLUS_S0_T1_22: return "diproton_S0_T1_0+_22";
    case DIPROTON_0_PLUS_S0_T1_23: return "diproton_S0_T1_0+_23";
    case DIPROTON_0_PLUS_S0_T1_24: return "diproton_S0_T1_0+_24";
    case DIPROTON_0_PLUS_S0_T1_25: return "diproton_S0_T1_0+_25";
    case DIPROTON_0_PLUS_S0_T1_26: return "diproton_S0_T1_0+_26";
    case DIPROTON_0_PLUS_S0_T1_27: return "diproton_S0_T1_0+_27";
    case DIPROTON_0_PLUS_S0_T1_28: return "diproton_S0_T1_0+_28";
    case DIPROTON_0_PLUS_S0_T1_29: return "diproton_S0_T1_0+_29";
    case DIPROTON_0_PLUS_S0_T1_30: return "diproton_S0_T1_0+_30";
    case DIPROTON_0_PLUS_S0_T1_31: return "diproton_S0_T1_0+_31";
    case DIPROTON_0_PLUS_S0_T1_32: return "diproton_S0_T1_0+_32";
    case DIPROTON_0_PLUS_S0_T1_33: return "diproton_S0_T1_0+_33";
    case DIPROTON_0_PLUS_S0_T1_34: return "diproton_S0_T1_0+_34";
    case DIPROTON_0_PLUS_S0_T1_35: return "diproton_S0_T1_0+_35";
    case DIPROTON_0_PLUS_S0_T1_36: return "diproton_S0_T1_0+_36";
    case DIPROTON_0_PLUS_S0_T1_37: return "diproton_S0_T1_0+_37";
    case DIPROTON_0_PLUS_S0_T1_38: return "diproton_S0_T1_0+_38";
    case DIPROTON_0_PLUS_S0_T1_39: return "diproton_S0_T1_0+_39";
    case DIPROTON_0_PLUS_S0_T1_40: return "diproton_S0_T1_0+_40";
    case DIPROTON_0_PLUS_S0_T1_41: return "diproton_S0_T1_0+_41";
    case DIPROTON_0_PLUS_S0_T1_42: return "diproton_S0_T1_0+_42";
    case DIPROTON_0_PLUS_S0_T1_43: return "diproton_S0_T1_0+_43";
    case DIPROTON_0_PLUS_S0_T1_44: return "diproton_S0_T1_0+_44";
    case DIPROTON_0_PLUS_S0_T1_45: return "diproton_S0_T1_0+_45";
    case DIPROTON_0_PLUS_S0_T1_46: return "diproton_S0_T1_0+_46";
    case DIPROTON_0_PLUS_S0_T1_47: return "diproton_S0_T1_0+_47";
    case DIPROTON_0_PLUS_S0_T1_48: return "diproton_S0_T1_0+_48";
    case DIPROTON_0_PLUS_S0_T1_49: return "diproton_S0_T1_0+_49";
    case DIPROTON_0_PLUS_S0_T1_50: return "diproton_S0_T1_0+_50";
    case DIPROTON_0_PLUS_S0_T1_51: return "diproton_S0_T1_0+_51";
    case DIPROTON_0_PLUS_S0_T1_52: return "diproton_S0_T1_0+_52";
    case DIPROTON_0_PLUS_S0_T1_53: return "diproton_S0_T1_0+_53";
    case DIPROTON_0_PLUS_S0_T1_54: return "diproton_S0_T1_0+_54";
    case DIPROTON_0_PLUS_S0_T1_55: return "diproton_S0_T1_0+_55";
    case DIPROTON_0_PLUS_S0_T1_56: return "diproton_S0_T1_0+_56";
    case DIPROTON_0_PLUS_S0_T1_57: return "diproton_S0_T1_0+_57";
    case DIPROTON_0_PLUS_S0_T1_58: return "diproton_S0_T1_0+_58";
    case DIPROTON_0_PLUS_S0_T1_59: return "diproton_S0_T1_0+_59";
    case DIPROTON_0_PLUS_S0_T1_60: return "diproton_S0_T1_0+_60";
    case DIPROTON_0_PLUS_S0_T1_61: return "diproton_S0_T1_0+_61";
    case DIPROTON_0_PLUS_S0_T1_62: return "diproton_S0_T1_0+_62";
    case DIPROTON_0_PLUS_S0_T1_63: return "diproton_S0_T1_0+_63";
    case DIPROTON_0_PLUS_S0_T1_64: return "diproton_S0_T1_0+_64";
    case DIPROTON_0_PLUS_S0_T1_65: return "diproton_S0_T1_0+_65";
    case DIPROTON_0_PLUS_S0_T1_66: return "diproton_S0_T1_0+_66";
    case DIPROTON_0_PLUS_S0_T1_67: return "diproton_S0_T1_0+_67";
    case DIPROTON_0_PLUS_S0_T1_68: return "diproton_S0_T1_0+_68";
    case DIPROTON_0_PLUS_S0_T1_69: return "diproton_S0_T1_0+_69";
    case DIPROTON_0_PLUS_S0_T1_70: return "diproton_S0_T1_0+_70";
    case DIPROTON_0_PLUS_S0_T1_71: return "diproton_S0_T1_0+_71";
    case DIPROTON_0_PLUS_S0_T1_72: return "diproton_S0_T1_0+_72";
    case DIPROTON_0_PLUS_S0_T1_73: return "diproton_S0_T1_0+_73";
    case DIPROTON_0_PLUS_S0_T1_74: return "diproton_S0_T1_0+_74";
    case DIPROTON_0_PLUS_S0_T1_75: return "diproton_S0_T1_0+_75";
    case DIPROTON_0_PLUS_S0_T1_76: return "diproton_S0_T1_0+_76";
    case DIPROTON_0_PLUS_S0_T1_77: return "diproton_S0_T1_0+_77";
    case DIPROTON_0_PLUS_S0_T1_78: return "diproton_S0_T1_0+_78";
    case DIPROTON_0_PLUS_S0_T1_79: return "diproton_S0_T1_0+_79";
    case DIPROTON_0_PLUS_S0_T1_80: return "diproton_S0_T1_0+_80";
    case DIPROTON_0_PLUS_S0_T1_81: return "diproton_S0_T1_0+_81";
    case DIPROTON_0_PLUS_S0_T1_82: return "diproton_S0_T1_0+_82";
    case DIPROTON_0_PLUS_S0_T1_83: return "diproton_S0_T1_0+_83";
    case DIPROTON_0_PLUS_S0_T1_84: return "diproton_S0_T1_0+_84";
    case DIPROTON_0_PLUS_S0_T1_85: return "diproton_S0_T1_0+_85";
    case DIPROTON_0_PLUS_S0_T1_86: return "diproton_S0_T1_0+_86";
    case DIPROTON_0_PLUS_S0_T1_87: return "diproton_S0_T1_0+_87";
    case DIPROTON_0_PLUS_S0_T1_88: return "diproton_S0_T1_0+_88";
    case DIPROTON_0_PLUS_S0_T1_89: return "diproton_S0_T1_0+_89";
    case DIPROTON_0_PLUS_S0_T1_90: return "diproton_S0_T1_0+_90";
    case DIPROTON_0_PLUS_S0_T1_91: return "diproton_S0_T1_0+_91";
    case DIPROTON_0_PLUS_S0_T1_92: return "diproton_S0_T1_0+_92";
    case DIPROTON_0_PLUS_S0_T1_93: return "diproton_S0_T1_0+_93";
    case DIPROTON_0_PLUS_S0_T1_94: return "diproton_S0_T1_0+_94";
    case DIPROTON_0_PLUS_S0_T1_95: return "diproton_S0_T1_0+_95";
    case DIPROTON_0_PLUS_S0_T1_96: return "diproton_S0_T1_0+_96";
    case DIPROTON_0_PLUS_S0_T1_97: return "diproton_S0_T1_0+_97";
    case DIPROTON_0_PLUS_S0_T1_98: return "diproton_S0_T1_0+_98";
    case DIPROTON_0_PLUS_S0_T1_99: return "diproton_S0_T1_0+_99";

    case DIPROTON_2_PLUS_S0_T1:    return "diproton_S0_T1_2+";
    case DIPROTON_2_PLUS_S0_T1_0:  return "diproton_S0_T1_2+_0";
    case DIPROTON_2_PLUS_S0_T1_1:  return "diproton_S0_T1_2+_1";
    case DIPROTON_2_PLUS_S0_T1_2:  return "diproton_S0_T1_2+_2";
    case DIPROTON_2_PLUS_S0_T1_3:  return "diproton_S0_T1_2+_3";
    case DIPROTON_2_PLUS_S0_T1_4:  return "diproton_S0_T1_2+_4";
    case DIPROTON_2_PLUS_S0_T1_5:  return "diproton_S0_T1_2+_5";
    case DIPROTON_2_PLUS_S0_T1_6:  return "diproton_S0_T1_2+_6";
    case DIPROTON_2_PLUS_S0_T1_7:  return "diproton_S0_T1_2+_7";
    case DIPROTON_2_PLUS_S0_T1_8:  return "diproton_S0_T1_2+_8";
    case DIPROTON_2_PLUS_S0_T1_9:  return "diproton_S0_T1_2+_9";
    case DIPROTON_2_PLUS_S0_T1_10: return "diproton_S0_T1_2+_10";
    case DIPROTON_2_PLUS_S0_T1_11: return "diproton_S0_T1_2+_11";
    case DIPROTON_2_PLUS_S0_T1_12: return "diproton_S0_T1_2+_12";
    case DIPROTON_2_PLUS_S0_T1_13: return "diproton_S0_T1_2+_13";
    case DIPROTON_2_PLUS_S0_T1_14: return "diproton_S0_T1_2+_14";
    case DIPROTON_2_PLUS_S0_T1_15: return "diproton_S0_T1_2+_15";
    case DIPROTON_2_PLUS_S0_T1_16: return "diproton_S0_T1_2+_16";
    case DIPROTON_2_PLUS_S0_T1_17: return "diproton_S0_T1_2+_17";
    case DIPROTON_2_PLUS_S0_T1_18: return "diproton_S0_T1_2+_18";
    case DIPROTON_2_PLUS_S0_T1_19: return "diproton_S0_T1_2+_19";
    case DIPROTON_2_PLUS_S0_T1_20: return "diproton_S0_T1_2+_20";
    case DIPROTON_2_PLUS_S0_T1_21: return "diproton_S0_T1_2+_21";
    case DIPROTON_2_PLUS_S0_T1_22: return "diproton_S0_T1_2+_22";
    case DIPROTON_2_PLUS_S0_T1_23: return "diproton_S0_T1_2+_23";
    case DIPROTON_2_PLUS_S0_T1_24: return "diproton_S0_T1_2+_24";
    case DIPROTON_2_PLUS_S0_T1_25: return "diproton_S0_T1_2+_25";
    case DIPROTON_2_PLUS_S0_T1_26: return "diproton_S0_T1_2+_26";
    case DIPROTON_2_PLUS_S0_T1_27: return "diproton_S0_T1_2+_27";
    case DIPROTON_2_PLUS_S0_T1_28: return "diproton_S0_T1_2+_28";
    case DIPROTON_2_PLUS_S0_T1_29: return "diproton_S0_T1_2+_29";
    case DIPROTON_2_PLUS_S0_T1_30: return "diproton_S0_T1_2+_30";
    case DIPROTON_2_PLUS_S0_T1_31: return "diproton_S0_T1_2+_31";
    case DIPROTON_2_PLUS_S0_T1_32: return "diproton_S0_T1_2+_32";
    case DIPROTON_2_PLUS_S0_T1_33: return "diproton_S0_T1_2+_33";
    case DIPROTON_2_PLUS_S0_T1_34: return "diproton_S0_T1_2+_34";
    case DIPROTON_2_PLUS_S0_T1_35: return "diproton_S0_T1_2+_35";
    case DIPROTON_2_PLUS_S0_T1_36: return "diproton_S0_T1_2+_36";
    case DIPROTON_2_PLUS_S0_T1_37: return "diproton_S0_T1_2+_37";
    case DIPROTON_2_PLUS_S0_T1_38: return "diproton_S0_T1_2+_38";
    case DIPROTON_2_PLUS_S0_T1_39: return "diproton_S0_T1_2+_39";
    case DIPROTON_2_PLUS_S0_T1_40: return "diproton_S0_T1_2+_40";
    case DIPROTON_2_PLUS_S0_T1_41: return "diproton_S0_T1_2+_41";
    case DIPROTON_2_PLUS_S0_T1_42: return "diproton_S0_T1_2+_42";
    case DIPROTON_2_PLUS_S0_T1_43: return "diproton_S0_T1_2+_43";
    case DIPROTON_2_PLUS_S0_T1_44: return "diproton_S0_T1_2+_44";
    case DIPROTON_2_PLUS_S0_T1_45: return "diproton_S0_T1_2+_45";
    case DIPROTON_2_PLUS_S0_T1_46: return "diproton_S0_T1_2+_46";
    case DIPROTON_2_PLUS_S0_T1_47: return "diproton_S0_T1_2+_47";
    case DIPROTON_2_PLUS_S0_T1_48: return "diproton_S0_T1_2+_48";
    case DIPROTON_2_PLUS_S0_T1_49: return "diproton_S0_T1_2+_49";
    case DIPROTON_2_PLUS_S0_T1_50: return "diproton_S0_T1_2+_50";
    case DIPROTON_2_PLUS_S0_T1_51: return "diproton_S0_T1_2+_51";
    case DIPROTON_2_PLUS_S0_T1_52: return "diproton_S0_T1_2+_52";
    case DIPROTON_2_PLUS_S0_T1_53: return "diproton_S0_T1_2+_53";
    case DIPROTON_2_PLUS_S0_T1_54: return "diproton_S0_T1_2+_54";
    case DIPROTON_2_PLUS_S0_T1_55: return "diproton_S0_T1_2+_55";
    case DIPROTON_2_PLUS_S0_T1_56: return "diproton_S0_T1_2+_56";
    case DIPROTON_2_PLUS_S0_T1_57: return "diproton_S0_T1_2+_57";
    case DIPROTON_2_PLUS_S0_T1_58: return "diproton_S0_T1_2+_58";
    case DIPROTON_2_PLUS_S0_T1_59: return "diproton_S0_T1_2+_59";
    case DIPROTON_2_PLUS_S0_T1_60: return "diproton_S0_T1_2+_60";
    case DIPROTON_2_PLUS_S0_T1_61: return "diproton_S0_T1_2+_61";
    case DIPROTON_2_PLUS_S0_T1_62: return "diproton_S0_T1_2+_62";
    case DIPROTON_2_PLUS_S0_T1_63: return "diproton_S0_T1_2+_63";
    case DIPROTON_2_PLUS_S0_T1_64: return "diproton_S0_T1_2+_64";
    case DIPROTON_2_PLUS_S0_T1_65: return "diproton_S0_T1_2+_65";
    case DIPROTON_2_PLUS_S0_T1_66: return "diproton_S0_T1_2+_66";
    case DIPROTON_2_PLUS_S0_T1_67: return "diproton_S0_T1_2+_67";
    case DIPROTON_2_PLUS_S0_T1_68: return "diproton_S0_T1_2+_68";
    case DIPROTON_2_PLUS_S0_T1_69: return "diproton_S0_T1_2+_69";
    case DIPROTON_2_PLUS_S0_T1_70: return "diproton_S0_T1_2+_70";
    case DIPROTON_2_PLUS_S0_T1_71: return "diproton_S0_T1_2+_71";
    case DIPROTON_2_PLUS_S0_T1_72: return "diproton_S0_T1_2+_72";
    case DIPROTON_2_PLUS_S0_T1_73: return "diproton_S0_T1_2+_73";
    case DIPROTON_2_PLUS_S0_T1_74: return "diproton_S0_T1_2+_74";
    case DIPROTON_2_PLUS_S0_T1_75: return "diproton_S0_T1_2+_75";
    case DIPROTON_2_PLUS_S0_T1_76: return "diproton_S0_T1_2+_76";
    case DIPROTON_2_PLUS_S0_T1_77: return "diproton_S0_T1_2+_77";
    case DIPROTON_2_PLUS_S0_T1_78: return "diproton_S0_T1_2+_78";
    case DIPROTON_2_PLUS_S0_T1_79: return "diproton_S0_T1_2+_79";
    case DIPROTON_2_PLUS_S0_T1_80: return "diproton_S0_T1_2+_80";
    case DIPROTON_2_PLUS_S0_T1_81: return "diproton_S0_T1_2+_81";
    case DIPROTON_2_PLUS_S0_T1_82: return "diproton_S0_T1_2+_82";
    case DIPROTON_2_PLUS_S0_T1_83: return "diproton_S0_T1_2+_83";
    case DIPROTON_2_PLUS_S0_T1_84: return "diproton_S0_T1_2+_84";
    case DIPROTON_2_PLUS_S0_T1_85: return "diproton_S0_T1_2+_85";
    case DIPROTON_2_PLUS_S0_T1_86: return "diproton_S0_T1_2+_86";
    case DIPROTON_2_PLUS_S0_T1_87: return "diproton_S0_T1_2+_87";
    case DIPROTON_2_PLUS_S0_T1_88: return "diproton_S0_T1_2+_88";
    case DIPROTON_2_PLUS_S0_T1_89: return "diproton_S0_T1_2+_89";
    case DIPROTON_2_PLUS_S0_T1_90: return "diproton_S0_T1_2+_90";
    case DIPROTON_2_PLUS_S0_T1_91: return "diproton_S0_T1_2+_91";
    case DIPROTON_2_PLUS_S0_T1_92: return "diproton_S0_T1_2+_92";
    case DIPROTON_2_PLUS_S0_T1_93: return "diproton_S0_T1_2+_93";
    case DIPROTON_2_PLUS_S0_T1_94: return "diproton_S0_T1_2+_94";
    case DIPROTON_2_PLUS_S0_T1_95: return "diproton_S0_T1_2+_95";
    case DIPROTON_2_PLUS_S0_T1_96: return "diproton_S0_T1_2+_96";
    case DIPROTON_2_PLUS_S0_T1_97: return "diproton_S0_T1_2+_97";
    case DIPROTON_2_PLUS_S0_T1_98: return "diproton_S0_T1_2+_98";
    case DIPROTON_2_PLUS_S0_T1_99: return "diproton_S0_T1_2+_99";

    case DIPROTON_4_PLUS_S0_T1:    return "diproton_S0_T1_4+";
    case DIPROTON_4_PLUS_S0_T1_0:  return "diproton_S0_T1_4+_0";
    case DIPROTON_4_PLUS_S0_T1_1:  return "diproton_S0_T1_4+_1";
    case DIPROTON_4_PLUS_S0_T1_2:  return "diproton_S0_T1_4+_2";
    case DIPROTON_4_PLUS_S0_T1_3:  return "diproton_S0_T1_4+_3";
    case DIPROTON_4_PLUS_S0_T1_4:  return "diproton_S0_T1_4+_4";
    case DIPROTON_4_PLUS_S0_T1_5:  return "diproton_S0_T1_4+_5";
    case DIPROTON_4_PLUS_S0_T1_6:  return "diproton_S0_T1_4+_6";
    case DIPROTON_4_PLUS_S0_T1_7:  return "diproton_S0_T1_4+_7";
    case DIPROTON_4_PLUS_S0_T1_8:  return "diproton_S0_T1_4+_8";
    case DIPROTON_4_PLUS_S0_T1_9:  return "diproton_S0_T1_4+_9";
    case DIPROTON_4_PLUS_S0_T1_10: return "diproton_S0_T1_4+_10";
    case DIPROTON_4_PLUS_S0_T1_11: return "diproton_S0_T1_4+_11";
    case DIPROTON_4_PLUS_S0_T1_12: return "diproton_S0_T1_4+_12";
    case DIPROTON_4_PLUS_S0_T1_13: return "diproton_S0_T1_4+_13";
    case DIPROTON_4_PLUS_S0_T1_14: return "diproton_S0_T1_4+_14";
    case DIPROTON_4_PLUS_S0_T1_15: return "diproton_S0_T1_4+_15";
    case DIPROTON_4_PLUS_S0_T1_16: return "diproton_S0_T1_4+_16";
    case DIPROTON_4_PLUS_S0_T1_17: return "diproton_S0_T1_4+_17";
    case DIPROTON_4_PLUS_S0_T1_18: return "diproton_S0_T1_4+_18";
    case DIPROTON_4_PLUS_S0_T1_19: return "diproton_S0_T1_4+_19";
    case DIPROTON_4_PLUS_S0_T1_20: return "diproton_S0_T1_4+_20";
    case DIPROTON_4_PLUS_S0_T1_21: return "diproton_S0_T1_4+_21";
    case DIPROTON_4_PLUS_S0_T1_22: return "diproton_S0_T1_4+_22";
    case DIPROTON_4_PLUS_S0_T1_23: return "diproton_S0_T1_4+_23";
    case DIPROTON_4_PLUS_S0_T1_24: return "diproton_S0_T1_4+_24";
    case DIPROTON_4_PLUS_S0_T1_25: return "diproton_S0_T1_4+_25";
    case DIPROTON_4_PLUS_S0_T1_26: return "diproton_S0_T1_4+_26";
    case DIPROTON_4_PLUS_S0_T1_27: return "diproton_S0_T1_4+_27";
    case DIPROTON_4_PLUS_S0_T1_28: return "diproton_S0_T1_4+_28";
    case DIPROTON_4_PLUS_S0_T1_29: return "diproton_S0_T1_4+_29";
    case DIPROTON_4_PLUS_S0_T1_30: return "diproton_S0_T1_4+_30";
    case DIPROTON_4_PLUS_S0_T1_31: return "diproton_S0_T1_4+_31";
    case DIPROTON_4_PLUS_S0_T1_32: return "diproton_S0_T1_4+_32";
    case DIPROTON_4_PLUS_S0_T1_33: return "diproton_S0_T1_4+_33";
    case DIPROTON_4_PLUS_S0_T1_34: return "diproton_S0_T1_4+_34";
    case DIPROTON_4_PLUS_S0_T1_35: return "diproton_S0_T1_4+_35";
    case DIPROTON_4_PLUS_S0_T1_36: return "diproton_S0_T1_4+_36";
    case DIPROTON_4_PLUS_S0_T1_37: return "diproton_S0_T1_4+_37";
    case DIPROTON_4_PLUS_S0_T1_38: return "diproton_S0_T1_4+_38";
    case DIPROTON_4_PLUS_S0_T1_39: return "diproton_S0_T1_4+_39";
    case DIPROTON_4_PLUS_S0_T1_40: return "diproton_S0_T1_4+_40";
    case DIPROTON_4_PLUS_S0_T1_41: return "diproton_S0_T1_4+_41";
    case DIPROTON_4_PLUS_S0_T1_42: return "diproton_S0_T1_4+_42";
    case DIPROTON_4_PLUS_S0_T1_43: return "diproton_S0_T1_4+_43";
    case DIPROTON_4_PLUS_S0_T1_44: return "diproton_S0_T1_4+_44";
    case DIPROTON_4_PLUS_S0_T1_45: return "diproton_S0_T1_4+_45";
    case DIPROTON_4_PLUS_S0_T1_46: return "diproton_S0_T1_4+_46";
    case DIPROTON_4_PLUS_S0_T1_47: return "diproton_S0_T1_4+_47";
    case DIPROTON_4_PLUS_S0_T1_48: return "diproton_S0_T1_4+_48";
    case DIPROTON_4_PLUS_S0_T1_49: return "diproton_S0_T1_4+_49";
    case DIPROTON_4_PLUS_S0_T1_50: return "diproton_S0_T1_4+_50";
    case DIPROTON_4_PLUS_S0_T1_51: return "diproton_S0_T1_4+_51";
    case DIPROTON_4_PLUS_S0_T1_52: return "diproton_S0_T1_4+_52";
    case DIPROTON_4_PLUS_S0_T1_53: return "diproton_S0_T1_4+_53";
    case DIPROTON_4_PLUS_S0_T1_54: return "diproton_S0_T1_4+_54";
    case DIPROTON_4_PLUS_S0_T1_55: return "diproton_S0_T1_4+_55";
    case DIPROTON_4_PLUS_S0_T1_56: return "diproton_S0_T1_4+_56";
    case DIPROTON_4_PLUS_S0_T1_57: return "diproton_S0_T1_4+_57";
    case DIPROTON_4_PLUS_S0_T1_58: return "diproton_S0_T1_4+_58";
    case DIPROTON_4_PLUS_S0_T1_59: return "diproton_S0_T1_4+_59";
    case DIPROTON_4_PLUS_S0_T1_60: return "diproton_S0_T1_4+_60";
    case DIPROTON_4_PLUS_S0_T1_61: return "diproton_S0_T1_4+_61";
    case DIPROTON_4_PLUS_S0_T1_62: return "diproton_S0_T1_4+_62";
    case DIPROTON_4_PLUS_S0_T1_63: return "diproton_S0_T1_4+_63";
    case DIPROTON_4_PLUS_S0_T1_64: return "diproton_S0_T1_4+_64";
    case DIPROTON_4_PLUS_S0_T1_65: return "diproton_S0_T1_4+_65";
    case DIPROTON_4_PLUS_S0_T1_66: return "diproton_S0_T1_4+_66";
    case DIPROTON_4_PLUS_S0_T1_67: return "diproton_S0_T1_4+_67";
    case DIPROTON_4_PLUS_S0_T1_68: return "diproton_S0_T1_4+_68";
    case DIPROTON_4_PLUS_S0_T1_69: return "diproton_S0_T1_4+_69";
    case DIPROTON_4_PLUS_S0_T1_70: return "diproton_S0_T1_4+_70";
    case DIPROTON_4_PLUS_S0_T1_71: return "diproton_S0_T1_4+_71";
    case DIPROTON_4_PLUS_S0_T1_72: return "diproton_S0_T1_4+_72";
    case DIPROTON_4_PLUS_S0_T1_73: return "diproton_S0_T1_4+_73";
    case DIPROTON_4_PLUS_S0_T1_74: return "diproton_S0_T1_4+_74";
    case DIPROTON_4_PLUS_S0_T1_75: return "diproton_S0_T1_4+_75";
    case DIPROTON_4_PLUS_S0_T1_76: return "diproton_S0_T1_4+_76";
    case DIPROTON_4_PLUS_S0_T1_77: return "diproton_S0_T1_4+_77";
    case DIPROTON_4_PLUS_S0_T1_78: return "diproton_S0_T1_4+_78";
    case DIPROTON_4_PLUS_S0_T1_79: return "diproton_S0_T1_4+_79";
    case DIPROTON_4_PLUS_S0_T1_80: return "diproton_S0_T1_4+_80";
    case DIPROTON_4_PLUS_S0_T1_81: return "diproton_S0_T1_4+_81";
    case DIPROTON_4_PLUS_S0_T1_82: return "diproton_S0_T1_4+_82";
    case DIPROTON_4_PLUS_S0_T1_83: return "diproton_S0_T1_4+_83";
    case DIPROTON_4_PLUS_S0_T1_84: return "diproton_S0_T1_4+_84";
    case DIPROTON_4_PLUS_S0_T1_85: return "diproton_S0_T1_4+_85";
    case DIPROTON_4_PLUS_S0_T1_86: return "diproton_S0_T1_4+_86";
    case DIPROTON_4_PLUS_S0_T1_87: return "diproton_S0_T1_4+_87";
    case DIPROTON_4_PLUS_S0_T1_88: return "diproton_S0_T1_4+_88";
    case DIPROTON_4_PLUS_S0_T1_89: return "diproton_S0_T1_4+_89";
    case DIPROTON_4_PLUS_S0_T1_90: return "diproton_S0_T1_4+_90";
    case DIPROTON_4_PLUS_S0_T1_91: return "diproton_S0_T1_4+_91";
    case DIPROTON_4_PLUS_S0_T1_92: return "diproton_S0_T1_4+_92";
    case DIPROTON_4_PLUS_S0_T1_93: return "diproton_S0_T1_4+_93";
    case DIPROTON_4_PLUS_S0_T1_94: return "diproton_S0_T1_4+_94";
    case DIPROTON_4_PLUS_S0_T1_95: return "diproton_S0_T1_4+_95";
    case DIPROTON_4_PLUS_S0_T1_96: return "diproton_S0_T1_4+_96";
    case DIPROTON_4_PLUS_S0_T1_97: return "diproton_S0_T1_4+_97";
    case DIPROTON_4_PLUS_S0_T1_98: return "diproton_S0_T1_4+_98";
    case DIPROTON_4_PLUS_S0_T1_99: return "diproton_S0_T1_4+_99";

    case DIPROTON_0_MINUS_S1_T1:    return "diproton_S1_T1_0-";
		case DIPROTON_0_MINUS_S1_T1_0:  return "diproton_S1_T1_0-_0";
    case DIPROTON_0_MINUS_S1_T1_1:  return "diproton_S1_T1_0-_1";
    case DIPROTON_0_MINUS_S1_T1_2:  return "diproton_S1_T1_0-_2";
    case DIPROTON_0_MINUS_S1_T1_3:  return "diproton_S1_T1_0-_3";
    case DIPROTON_0_MINUS_S1_T1_4:  return "diproton_S1_T1_0-_4";
    case DIPROTON_0_MINUS_S1_T1_5:  return "diproton_S1_T1_0-_5";
    case DIPROTON_0_MINUS_S1_T1_6:  return "diproton_S1_T1_0-_6";
    case DIPROTON_0_MINUS_S1_T1_7:  return "diproton_S1_T1_0-_7";
    case DIPROTON_0_MINUS_S1_T1_8:  return "diproton_S1_T1_0-_8";
    case DIPROTON_0_MINUS_S1_T1_9:  return "diproton_S1_T1_0-_9";
    case DIPROTON_0_MINUS_S1_T1_10: return "diproton_S1_T1_0-_10";
    case DIPROTON_0_MINUS_S1_T1_11: return "diproton_S1_T1_0-_11";
    case DIPROTON_0_MINUS_S1_T1_12: return "diproton_S1_T1_0-_12";
    case DIPROTON_0_MINUS_S1_T1_13: return "diproton_S1_T1_0-_13";
    case DIPROTON_0_MINUS_S1_T1_14: return "diproton_S1_T1_0-_14";
    case DIPROTON_0_MINUS_S1_T1_15: return "diproton_S1_T1_0-_15";
    case DIPROTON_0_MINUS_S1_T1_16: return "diproton_S1_T1_0-_16";
    case DIPROTON_0_MINUS_S1_T1_17: return "diproton_S1_T1_0-_17";
    case DIPROTON_0_MINUS_S1_T1_18: return "diproton_S1_T1_0-_18";
    case DIPROTON_0_MINUS_S1_T1_19: return "diproton_S1_T1_0-_19";
    case DIPROTON_0_MINUS_S1_T1_20: return "diproton_S1_T1_0-_20";
    case DIPROTON_0_MINUS_S1_T1_21: return "diproton_S1_T1_0-_21";
    case DIPROTON_0_MINUS_S1_T1_22: return "diproton_S1_T1_0-_22";
    case DIPROTON_0_MINUS_S1_T1_23: return "diproton_S1_T1_0-_23";
    case DIPROTON_0_MINUS_S1_T1_24: return "diproton_S1_T1_0-_24";
    case DIPROTON_0_MINUS_S1_T1_25: return "diproton_S1_T1_0-_25";
    case DIPROTON_0_MINUS_S1_T1_26: return "diproton_S1_T1_0-_26";
    case DIPROTON_0_MINUS_S1_T1_27: return "diproton_S1_T1_0-_27";
    case DIPROTON_0_MINUS_S1_T1_28: return "diproton_S1_T1_0-_28";
    case DIPROTON_0_MINUS_S1_T1_29: return "diproton_S1_T1_0-_29";
    case DIPROTON_0_MINUS_S1_T1_30: return "diproton_S1_T1_0-_30";
    case DIPROTON_0_MINUS_S1_T1_31: return "diproton_S1_T1_0-_31";
    case DIPROTON_0_MINUS_S1_T1_32: return "diproton_S1_T1_0-_32";
    case DIPROTON_0_MINUS_S1_T1_33: return "diproton_S1_T1_0-_33";
    case DIPROTON_0_MINUS_S1_T1_34: return "diproton_S1_T1_0-_34";
    case DIPROTON_0_MINUS_S1_T1_35: return "diproton_S1_T1_0-_35";
    case DIPROTON_0_MINUS_S1_T1_36: return "diproton_S1_T1_0-_36";
    case DIPROTON_0_MINUS_S1_T1_37: return "diproton_S1_T1_0-_37";
    case DIPROTON_0_MINUS_S1_T1_38: return "diproton_S1_T1_0-_38";
    case DIPROTON_0_MINUS_S1_T1_39: return "diproton_S1_T1_0-_39";
    case DIPROTON_0_MINUS_S1_T1_40: return "diproton_S1_T1_0-_40";
    case DIPROTON_0_MINUS_S1_T1_41: return "diproton_S1_T1_0-_41";
    case DIPROTON_0_MINUS_S1_T1_42: return "diproton_S1_T1_0-_42";
    case DIPROTON_0_MINUS_S1_T1_43: return "diproton_S1_T1_0-_43";
    case DIPROTON_0_MINUS_S1_T1_44: return "diproton_S1_T1_0-_44";
    case DIPROTON_0_MINUS_S1_T1_45: return "diproton_S1_T1_0-_45";
    case DIPROTON_0_MINUS_S1_T1_46: return "diproton_S1_T1_0-_46";
    case DIPROTON_0_MINUS_S1_T1_47: return "diproton_S1_T1_0-_47";
    case DIPROTON_0_MINUS_S1_T1_48: return "diproton_S1_T1_0-_48";
    case DIPROTON_0_MINUS_S1_T1_49: return "diproton_S1_T1_0-_49";
    case DIPROTON_0_MINUS_S1_T1_50: return "diproton_S1_T1_0-_50";
    case DIPROTON_0_MINUS_S1_T1_51: return "diproton_S1_T1_0-_51";
    case DIPROTON_0_MINUS_S1_T1_52: return "diproton_S1_T1_0-_52";
    case DIPROTON_0_MINUS_S1_T1_53: return "diproton_S1_T1_0-_53";
    case DIPROTON_0_MINUS_S1_T1_54: return "diproton_S1_T1_0-_54";
    case DIPROTON_0_MINUS_S1_T1_55: return "diproton_S1_T1_0-_55";
    case DIPROTON_0_MINUS_S1_T1_56: return "diproton_S1_T1_0-_56";
    case DIPROTON_0_MINUS_S1_T1_57: return "diproton_S1_T1_0-_57";
    case DIPROTON_0_MINUS_S1_T1_58: return "diproton_S1_T1_0-_58";
    case DIPROTON_0_MINUS_S1_T1_59: return "diproton_S1_T1_0-_59";
    case DIPROTON_0_MINUS_S1_T1_60: return "diproton_S1_T1_0-_60";
    case DIPROTON_0_MINUS_S1_T1_61: return "diproton_S1_T1_0-_61";
    case DIPROTON_0_MINUS_S1_T1_62: return "diproton_S1_T1_0-_62";
    case DIPROTON_0_MINUS_S1_T1_63: return "diproton_S1_T1_0-_63";
    case DIPROTON_0_MINUS_S1_T1_64: return "diproton_S1_T1_0-_64";
    case DIPROTON_0_MINUS_S1_T1_65: return "diproton_S1_T1_0-_65";
    case DIPROTON_0_MINUS_S1_T1_66: return "diproton_S1_T1_0-_66";
    case DIPROTON_0_MINUS_S1_T1_67: return "diproton_S1_T1_0-_67";
    case DIPROTON_0_MINUS_S1_T1_68: return "diproton_S1_T1_0-_68";
    case DIPROTON_0_MINUS_S1_T1_69: return "diproton_S1_T1_0-_69";
    case DIPROTON_0_MINUS_S1_T1_70: return "diproton_S1_T1_0-_70";
    case DIPROTON_0_MINUS_S1_T1_71: return "diproton_S1_T1_0-_71";
    case DIPROTON_0_MINUS_S1_T1_72: return "diproton_S1_T1_0-_72";
    case DIPROTON_0_MINUS_S1_T1_73: return "diproton_S1_T1_0-_73";
    case DIPROTON_0_MINUS_S1_T1_74: return "diproton_S1_T1_0-_74";
    case DIPROTON_0_MINUS_S1_T1_75: return "diproton_S1_T1_0-_75";
    case DIPROTON_0_MINUS_S1_T1_76: return "diproton_S1_T1_0-_76";
    case DIPROTON_0_MINUS_S1_T1_77: return "diproton_S1_T1_0-_77";
    case DIPROTON_0_MINUS_S1_T1_78: return "diproton_S1_T1_0-_78";
    case DIPROTON_0_MINUS_S1_T1_79: return "diproton_S1_T1_0-_79";
    case DIPROTON_0_MINUS_S1_T1_80: return "diproton_S1_T1_0-_80";
    case DIPROTON_0_MINUS_S1_T1_81: return "diproton_S1_T1_0-_81";
    case DIPROTON_0_MINUS_S1_T1_82: return "diproton_S1_T1_0-_82";
    case DIPROTON_0_MINUS_S1_T1_83: return "diproton_S1_T1_0-_83";
    case DIPROTON_0_MINUS_S1_T1_84: return "diproton_S1_T1_0-_84";
    case DIPROTON_0_MINUS_S1_T1_85: return "diproton_S1_T1_0-_85";
    case DIPROTON_0_MINUS_S1_T1_86: return "diproton_S1_T1_0-_86";
    case DIPROTON_0_MINUS_S1_T1_87: return "diproton_S1_T1_0-_87";
    case DIPROTON_0_MINUS_S1_T1_88: return "diproton_S1_T1_0-_88";
    case DIPROTON_0_MINUS_S1_T1_89: return "diproton_S1_T1_0-_89";
    case DIPROTON_0_MINUS_S1_T1_90: return "diproton_S1_T1_0-_90";
    case DIPROTON_0_MINUS_S1_T1_91: return "diproton_S1_T1_0-_91";
    case DIPROTON_0_MINUS_S1_T1_92: return "diproton_S1_T1_0-_92";
    case DIPROTON_0_MINUS_S1_T1_93: return "diproton_S1_T1_0-_93";
    case DIPROTON_0_MINUS_S1_T1_94: return "diproton_S1_T1_0-_94";
    case DIPROTON_0_MINUS_S1_T1_95: return "diproton_S1_T1_0-_95";
    case DIPROTON_0_MINUS_S1_T1_96: return "diproton_S1_T1_0-_96";
    case DIPROTON_0_MINUS_S1_T1_97: return "diproton_S1_T1_0-_97";
    case DIPROTON_0_MINUS_S1_T1_98: return "diproton_S1_T1_0-_98";
    case DIPROTON_0_MINUS_S1_T1_99: return "diproton_S1_T1_0-_99";

    case DIPROTON_1_MINUS_S1_T1:    return "diproton_S1_T1_1-";
    case DIPROTON_1_MINUS_S1_T1_0:  return "diproton_S1_T1_1-_0";
    case DIPROTON_1_MINUS_S1_T1_1:  return "diproton_S1_T1_1-_1";
    case DIPROTON_1_MINUS_S1_T1_2:  return "diproton_S1_T1_1-_2";
    case DIPROTON_1_MINUS_S1_T1_3:  return "diproton_S1_T1_1-_3";
    case DIPROTON_1_MINUS_S1_T1_4:  return "diproton_S1_T1_1-_4";
    case DIPROTON_1_MINUS_S1_T1_5:  return "diproton_S1_T1_1-_5";
    case DIPROTON_1_MINUS_S1_T1_6:  return "diproton_S1_T1_1-_6";
    case DIPROTON_1_MINUS_S1_T1_7:  return "diproton_S1_T1_1-_7";
    case DIPROTON_1_MINUS_S1_T1_8:  return "diproton_S1_T1_1-_8";
    case DIPROTON_1_MINUS_S1_T1_9:  return "diproton_S1_T1_1-_9";
    case DIPROTON_1_MINUS_S1_T1_10: return "diproton_S1_T1_1-_10";
    case DIPROTON_1_MINUS_S1_T1_11: return "diproton_S1_T1_1-_11";
    case DIPROTON_1_MINUS_S1_T1_12: return "diproton_S1_T1_1-_12";
    case DIPROTON_1_MINUS_S1_T1_13: return "diproton_S1_T1_1-_13";
    case DIPROTON_1_MINUS_S1_T1_14: return "diproton_S1_T1_1-_14";
    case DIPROTON_1_MINUS_S1_T1_15: return "diproton_S1_T1_1-_15";
    case DIPROTON_1_MINUS_S1_T1_16: return "diproton_S1_T1_1-_16";
    case DIPROTON_1_MINUS_S1_T1_17: return "diproton_S1_T1_1-_17";
    case DIPROTON_1_MINUS_S1_T1_18: return "diproton_S1_T1_1-_18";
    case DIPROTON_1_MINUS_S1_T1_19: return "diproton_S1_T1_1-_19";
    case DIPROTON_1_MINUS_S1_T1_20: return "diproton_S1_T1_1-_20";
    case DIPROTON_1_MINUS_S1_T1_21: return "diproton_S1_T1_1-_21";
    case DIPROTON_1_MINUS_S1_T1_22: return "diproton_S1_T1_1-_22";
    case DIPROTON_1_MINUS_S1_T1_23: return "diproton_S1_T1_1-_23";
    case DIPROTON_1_MINUS_S1_T1_24: return "diproton_S1_T1_1-_24";
    case DIPROTON_1_MINUS_S1_T1_25: return "diproton_S1_T1_1-_25";
    case DIPROTON_1_MINUS_S1_T1_26: return "diproton_S1_T1_1-_26";
    case DIPROTON_1_MINUS_S1_T1_27: return "diproton_S1_T1_1-_27";
    case DIPROTON_1_MINUS_S1_T1_28: return "diproton_S1_T1_1-_28";
    case DIPROTON_1_MINUS_S1_T1_29: return "diproton_S1_T1_1-_29";
    case DIPROTON_1_MINUS_S1_T1_30: return "diproton_S1_T1_1-_30";
    case DIPROTON_1_MINUS_S1_T1_31: return "diproton_S1_T1_1-_31";
    case DIPROTON_1_MINUS_S1_T1_32: return "diproton_S1_T1_1-_32";
    case DIPROTON_1_MINUS_S1_T1_33: return "diproton_S1_T1_1-_33";
    case DIPROTON_1_MINUS_S1_T1_34: return "diproton_S1_T1_1-_34";
    case DIPROTON_1_MINUS_S1_T1_35: return "diproton_S1_T1_1-_35";
    case DIPROTON_1_MINUS_S1_T1_36: return "diproton_S1_T1_1-_36";
    case DIPROTON_1_MINUS_S1_T1_37: return "diproton_S1_T1_1-_37";
    case DIPROTON_1_MINUS_S1_T1_38: return "diproton_S1_T1_1-_38";
    case DIPROTON_1_MINUS_S1_T1_39: return "diproton_S1_T1_1-_39";
    case DIPROTON_1_MINUS_S1_T1_40: return "diproton_S1_T1_1-_40";
    case DIPROTON_1_MINUS_S1_T1_41: return "diproton_S1_T1_1-_41";
    case DIPROTON_1_MINUS_S1_T1_42: return "diproton_S1_T1_1-_42";
    case DIPROTON_1_MINUS_S1_T1_43: return "diproton_S1_T1_1-_43";
    case DIPROTON_1_MINUS_S1_T1_44: return "diproton_S1_T1_1-_44";
    case DIPROTON_1_MINUS_S1_T1_45: return "diproton_S1_T1_1-_45";
    case DIPROTON_1_MINUS_S1_T1_46: return "diproton_S1_T1_1-_46";
    case DIPROTON_1_MINUS_S1_T1_47: return "diproton_S1_T1_1-_47";
    case DIPROTON_1_MINUS_S1_T1_48: return "diproton_S1_T1_1-_48";
    case DIPROTON_1_MINUS_S1_T1_49: return "diproton_S1_T1_1-_49";
    case DIPROTON_1_MINUS_S1_T1_50: return "diproton_S1_T1_1-_50";
    case DIPROTON_1_MINUS_S1_T1_51: return "diproton_S1_T1_1-_51";
    case DIPROTON_1_MINUS_S1_T1_52: return "diproton_S1_T1_1-_52";
    case DIPROTON_1_MINUS_S1_T1_53: return "diproton_S1_T1_1-_53";
    case DIPROTON_1_MINUS_S1_T1_54: return "diproton_S1_T1_1-_54";
    case DIPROTON_1_MINUS_S1_T1_55: return "diproton_S1_T1_1-_55";
    case DIPROTON_1_MINUS_S1_T1_56: return "diproton_S1_T1_1-_56";
    case DIPROTON_1_MINUS_S1_T1_57: return "diproton_S1_T1_1-_57";
    case DIPROTON_1_MINUS_S1_T1_58: return "diproton_S1_T1_1-_58";
    case DIPROTON_1_MINUS_S1_T1_59: return "diproton_S1_T1_1-_59";
    case DIPROTON_1_MINUS_S1_T1_60: return "diproton_S1_T1_1-_60";
    case DIPROTON_1_MINUS_S1_T1_61: return "diproton_S1_T1_1-_61";
    case DIPROTON_1_MINUS_S1_T1_62: return "diproton_S1_T1_1-_62";
    case DIPROTON_1_MINUS_S1_T1_63: return "diproton_S1_T1_1-_63";
    case DIPROTON_1_MINUS_S1_T1_64: return "diproton_S1_T1_1-_64";
    case DIPROTON_1_MINUS_S1_T1_65: return "diproton_S1_T1_1-_65";
    case DIPROTON_1_MINUS_S1_T1_66: return "diproton_S1_T1_1-_66";
    case DIPROTON_1_MINUS_S1_T1_67: return "diproton_S1_T1_1-_67";
    case DIPROTON_1_MINUS_S1_T1_68: return "diproton_S1_T1_1-_68";
    case DIPROTON_1_MINUS_S1_T1_69: return "diproton_S1_T1_1-_69";
    case DIPROTON_1_MINUS_S1_T1_70: return "diproton_S1_T1_1-_70";
    case DIPROTON_1_MINUS_S1_T1_71: return "diproton_S1_T1_1-_71";
    case DIPROTON_1_MINUS_S1_T1_72: return "diproton_S1_T1_1-_72";
    case DIPROTON_1_MINUS_S1_T1_73: return "diproton_S1_T1_1-_73";
    case DIPROTON_1_MINUS_S1_T1_74: return "diproton_S1_T1_1-_74";
    case DIPROTON_1_MINUS_S1_T1_75: return "diproton_S1_T1_1-_75";
    case DIPROTON_1_MINUS_S1_T1_76: return "diproton_S1_T1_1-_76";
    case DIPROTON_1_MINUS_S1_T1_77: return "diproton_S1_T1_1-_77";
    case DIPROTON_1_MINUS_S1_T1_78: return "diproton_S1_T1_1-_78";
    case DIPROTON_1_MINUS_S1_T1_79: return "diproton_S1_T1_1-_79";
    case DIPROTON_1_MINUS_S1_T1_80: return "diproton_S1_T1_1-_80";
    case DIPROTON_1_MINUS_S1_T1_81: return "diproton_S1_T1_1-_81";
    case DIPROTON_1_MINUS_S1_T1_82: return "diproton_S1_T1_1-_82";
    case DIPROTON_1_MINUS_S1_T1_83: return "diproton_S1_T1_1-_83";
    case DIPROTON_1_MINUS_S1_T1_84: return "diproton_S1_T1_1-_84";
    case DIPROTON_1_MINUS_S1_T1_85: return "diproton_S1_T1_1-_85";
    case DIPROTON_1_MINUS_S1_T1_86: return "diproton_S1_T1_1-_86";
    case DIPROTON_1_MINUS_S1_T1_87: return "diproton_S1_T1_1-_87";
    case DIPROTON_1_MINUS_S1_T1_88: return "diproton_S1_T1_1-_88";
    case DIPROTON_1_MINUS_S1_T1_89: return "diproton_S1_T1_1-_89";
    case DIPROTON_1_MINUS_S1_T1_90: return "diproton_S1_T1_1-_90";
    case DIPROTON_1_MINUS_S1_T1_91: return "diproton_S1_T1_1-_91";
    case DIPROTON_1_MINUS_S1_T1_92: return "diproton_S1_T1_1-_92";
    case DIPROTON_1_MINUS_S1_T1_93: return "diproton_S1_T1_1-_93";
    case DIPROTON_1_MINUS_S1_T1_94: return "diproton_S1_T1_1-_94";
    case DIPROTON_1_MINUS_S1_T1_95: return "diproton_S1_T1_1-_95";
    case DIPROTON_1_MINUS_S1_T1_96: return "diproton_S1_T1_1-_96";
    case DIPROTON_1_MINUS_S1_T1_97: return "diproton_S1_T1_1-_97";
    case DIPROTON_1_MINUS_S1_T1_98: return "diproton_S1_T1_1-_98";
    case DIPROTON_1_MINUS_S1_T1_99: return "diproton_S1_T1_1-_99";

    case DIPROTON_2_MINUS_S1_T1:    return "diproton_S1_T1_2-";
    case DIPROTON_2_MINUS_S1_T1_0:  return "diproton_S1_T1_2-_0";
    case DIPROTON_2_MINUS_S1_T1_1:  return "diproton_S1_T1_2-_1";
    case DIPROTON_2_MINUS_S1_T1_2:  return "diproton_S1_T1_2-_2";
    case DIPROTON_2_MINUS_S1_T1_3:  return "diproton_S1_T1_2-_3";
    case DIPROTON_2_MINUS_S1_T1_4:  return "diproton_S1_T1_2-_4";
    case DIPROTON_2_MINUS_S1_T1_5:  return "diproton_S1_T1_2-_5";
    case DIPROTON_2_MINUS_S1_T1_6:  return "diproton_S1_T1_2-_6";
    case DIPROTON_2_MINUS_S1_T1_7:  return "diproton_S1_T1_2-_7";
    case DIPROTON_2_MINUS_S1_T1_8:  return "diproton_S1_T1_2-_8";
    case DIPROTON_2_MINUS_S1_T1_9:  return "diproton_S1_T1_2-_9";
    case DIPROTON_2_MINUS_S1_T1_10: return "diproton_S1_T1_2-_10";
    case DIPROTON_2_MINUS_S1_T1_11: return "diproton_S1_T1_2-_11";
    case DIPROTON_2_MINUS_S1_T1_12: return "diproton_S1_T1_2-_12";
    case DIPROTON_2_MINUS_S1_T1_13: return "diproton_S1_T1_2-_13";
    case DIPROTON_2_MINUS_S1_T1_14: return "diproton_S1_T1_2-_14";
    case DIPROTON_2_MINUS_S1_T1_15: return "diproton_S1_T1_2-_15";
    case DIPROTON_2_MINUS_S1_T1_16: return "diproton_S1_T1_2-_16";
    case DIPROTON_2_MINUS_S1_T1_17: return "diproton_S1_T1_2-_17";
    case DIPROTON_2_MINUS_S1_T1_18: return "diproton_S1_T1_2-_18";
    case DIPROTON_2_MINUS_S1_T1_19: return "diproton_S1_T1_2-_19";
    case DIPROTON_2_MINUS_S1_T1_20: return "diproton_S1_T1_2-_20";
    case DIPROTON_2_MINUS_S1_T1_21: return "diproton_S1_T1_2-_21";
    case DIPROTON_2_MINUS_S1_T1_22: return "diproton_S1_T1_2-_22";
    case DIPROTON_2_MINUS_S1_T1_23: return "diproton_S1_T1_2-_23";
    case DIPROTON_2_MINUS_S1_T1_24: return "diproton_S1_T1_2-_24";
    case DIPROTON_2_MINUS_S1_T1_25: return "diproton_S1_T1_2-_25";
    case DIPROTON_2_MINUS_S1_T1_26: return "diproton_S1_T1_2-_26";
    case DIPROTON_2_MINUS_S1_T1_27: return "diproton_S1_T1_2-_27";
    case DIPROTON_2_MINUS_S1_T1_28: return "diproton_S1_T1_2-_28";
    case DIPROTON_2_MINUS_S1_T1_29: return "diproton_S1_T1_2-_29";
    case DIPROTON_2_MINUS_S1_T1_30: return "diproton_S1_T1_2-_30";
    case DIPROTON_2_MINUS_S1_T1_31: return "diproton_S1_T1_2-_31";
    case DIPROTON_2_MINUS_S1_T1_32: return "diproton_S1_T1_2-_32";
    case DIPROTON_2_MINUS_S1_T1_33: return "diproton_S1_T1_2-_33";
    case DIPROTON_2_MINUS_S1_T1_34: return "diproton_S1_T1_2-_34";
    case DIPROTON_2_MINUS_S1_T1_35: return "diproton_S1_T1_2-_35";
    case DIPROTON_2_MINUS_S1_T1_36: return "diproton_S1_T1_2-_36";
    case DIPROTON_2_MINUS_S1_T1_37: return "diproton_S1_T1_2-_37";
    case DIPROTON_2_MINUS_S1_T1_38: return "diproton_S1_T1_2-_38";
    case DIPROTON_2_MINUS_S1_T1_39: return "diproton_S1_T1_2-_39";
    case DIPROTON_2_MINUS_S1_T1_40: return "diproton_S1_T1_2-_40";
    case DIPROTON_2_MINUS_S1_T1_41: return "diproton_S1_T1_2-_41";
    case DIPROTON_2_MINUS_S1_T1_42: return "diproton_S1_T1_2-_42";
    case DIPROTON_2_MINUS_S1_T1_43: return "diproton_S1_T1_2-_43";
    case DIPROTON_2_MINUS_S1_T1_44: return "diproton_S1_T1_2-_44";
    case DIPROTON_2_MINUS_S1_T1_45: return "diproton_S1_T1_2-_45";
    case DIPROTON_2_MINUS_S1_T1_46: return "diproton_S1_T1_2-_46";
    case DIPROTON_2_MINUS_S1_T1_47: return "diproton_S1_T1_2-_47";
    case DIPROTON_2_MINUS_S1_T1_48: return "diproton_S1_T1_2-_48";
    case DIPROTON_2_MINUS_S1_T1_49: return "diproton_S1_T1_2-_49";
    case DIPROTON_2_MINUS_S1_T1_50: return "diproton_S1_T1_2-_50";
    case DIPROTON_2_MINUS_S1_T1_51: return "diproton_S1_T1_2-_51";
    case DIPROTON_2_MINUS_S1_T1_52: return "diproton_S1_T1_2-_52";
    case DIPROTON_2_MINUS_S1_T1_53: return "diproton_S1_T1_2-_53";
    case DIPROTON_2_MINUS_S1_T1_54: return "diproton_S1_T1_2-_54";
    case DIPROTON_2_MINUS_S1_T1_55: return "diproton_S1_T1_2-_55";
    case DIPROTON_2_MINUS_S1_T1_56: return "diproton_S1_T1_2-_56";
    case DIPROTON_2_MINUS_S1_T1_57: return "diproton_S1_T1_2-_57";
    case DIPROTON_2_MINUS_S1_T1_58: return "diproton_S1_T1_2-_58";
    case DIPROTON_2_MINUS_S1_T1_59: return "diproton_S1_T1_2-_59";
    case DIPROTON_2_MINUS_S1_T1_60: return "diproton_S1_T1_2-_60";
    case DIPROTON_2_MINUS_S1_T1_61: return "diproton_S1_T1_2-_61";
    case DIPROTON_2_MINUS_S1_T1_62: return "diproton_S1_T1_2-_62";
    case DIPROTON_2_MINUS_S1_T1_63: return "diproton_S1_T1_2-_63";
    case DIPROTON_2_MINUS_S1_T1_64: return "diproton_S1_T1_2-_64";
    case DIPROTON_2_MINUS_S1_T1_65: return "diproton_S1_T1_2-_65";
    case DIPROTON_2_MINUS_S1_T1_66: return "diproton_S1_T1_2-_66";
    case DIPROTON_2_MINUS_S1_T1_67: return "diproton_S1_T1_2-_67";
    case DIPROTON_2_MINUS_S1_T1_68: return "diproton_S1_T1_2-_68";
    case DIPROTON_2_MINUS_S1_T1_69: return "diproton_S1_T1_2-_69";
    case DIPROTON_2_MINUS_S1_T1_70: return "diproton_S1_T1_2-_70";
    case DIPROTON_2_MINUS_S1_T1_71: return "diproton_S1_T1_2-_71";
    case DIPROTON_2_MINUS_S1_T1_72: return "diproton_S1_T1_2-_72";
    case DIPROTON_2_MINUS_S1_T1_73: return "diproton_S1_T1_2-_73";
    case DIPROTON_2_MINUS_S1_T1_74: return "diproton_S1_T1_2-_74";
    case DIPROTON_2_MINUS_S1_T1_75: return "diproton_S1_T1_2-_75";
    case DIPROTON_2_MINUS_S1_T1_76: return "diproton_S1_T1_2-_76";
    case DIPROTON_2_MINUS_S1_T1_77: return "diproton_S1_T1_2-_77";
    case DIPROTON_2_MINUS_S1_T1_78: return "diproton_S1_T1_2-_78";
    case DIPROTON_2_MINUS_S1_T1_79: return "diproton_S1_T1_2-_79";
    case DIPROTON_2_MINUS_S1_T1_80: return "diproton_S1_T1_2-_80";
    case DIPROTON_2_MINUS_S1_T1_81: return "diproton_S1_T1_2-_81";
    case DIPROTON_2_MINUS_S1_T1_82: return "diproton_S1_T1_2-_82";
    case DIPROTON_2_MINUS_S1_T1_83: return "diproton_S1_T1_2-_83";
    case DIPROTON_2_MINUS_S1_T1_84: return "diproton_S1_T1_2-_84";
    case DIPROTON_2_MINUS_S1_T1_85: return "diproton_S1_T1_2-_85";
    case DIPROTON_2_MINUS_S1_T1_86: return "diproton_S1_T1_2-_86";
    case DIPROTON_2_MINUS_S1_T1_87: return "diproton_S1_T1_2-_87";
    case DIPROTON_2_MINUS_S1_T1_88: return "diproton_S1_T1_2-_88";
    case DIPROTON_2_MINUS_S1_T1_89: return "diproton_S1_T1_2-_89";
    case DIPROTON_2_MINUS_S1_T1_90: return "diproton_S1_T1_2-_90";
    case DIPROTON_2_MINUS_S1_T1_91: return "diproton_S1_T1_2-_91";
    case DIPROTON_2_MINUS_S1_T1_92: return "diproton_S1_T1_2-_92";
    case DIPROTON_2_MINUS_S1_T1_93: return "diproton_S1_T1_2-_93";
    case DIPROTON_2_MINUS_S1_T1_94: return "diproton_S1_T1_2-_94";
    case DIPROTON_2_MINUS_S1_T1_95: return "diproton_S1_T1_2-_95";
    case DIPROTON_2_MINUS_S1_T1_96: return "diproton_S1_T1_2-_96";
    case DIPROTON_2_MINUS_S1_T1_97: return "diproton_S1_T1_2-_97";
    case DIPROTON_2_MINUS_S1_T1_98: return "diproton_S1_T1_2-_98";
    case DIPROTON_2_MINUS_S1_T1_99: return "diproton_S1_T1_2-_99";

    case DIPROTON_3_MINUS_S1_T1:    return "diproton_S1_T1_3-";
    case DIPROTON_3_MINUS_S1_T1_0:  return "diproton_S1_T1_3-_0";
    case DIPROTON_3_MINUS_S1_T1_1:  return "diproton_S1_T1_3-_1";
    case DIPROTON_3_MINUS_S1_T1_2:  return "diproton_S1_T1_3-_2";
    case DIPROTON_3_MINUS_S1_T1_3:  return "diproton_S1_T1_3-_3";
    case DIPROTON_3_MINUS_S1_T1_4:  return "diproton_S1_T1_3-_4";
    case DIPROTON_3_MINUS_S1_T1_5:  return "diproton_S1_T1_3-_5";
    case DIPROTON_3_MINUS_S1_T1_6:  return "diproton_S1_T1_3-_6";
    case DIPROTON_3_MINUS_S1_T1_7:  return "diproton_S1_T1_3-_7";
    case DIPROTON_3_MINUS_S1_T1_8:  return "diproton_S1_T1_3-_8";
    case DIPROTON_3_MINUS_S1_T1_9:  return "diproton_S1_T1_3-_9";
    case DIPROTON_3_MINUS_S1_T1_10: return "diproton_S1_T1_3-_10";
    case DIPROTON_3_MINUS_S1_T1_11: return "diproton_S1_T1_3-_11";
    case DIPROTON_3_MINUS_S1_T1_12: return "diproton_S1_T1_3-_12";
    case DIPROTON_3_MINUS_S1_T1_13: return "diproton_S1_T1_3-_13";
    case DIPROTON_3_MINUS_S1_T1_14: return "diproton_S1_T1_3-_14";
    case DIPROTON_3_MINUS_S1_T1_15: return "diproton_S1_T1_3-_15";
    case DIPROTON_3_MINUS_S1_T1_16: return "diproton_S1_T1_3-_16";
    case DIPROTON_3_MINUS_S1_T1_17: return "diproton_S1_T1_3-_17";
    case DIPROTON_3_MINUS_S1_T1_18: return "diproton_S1_T1_3-_18";
    case DIPROTON_3_MINUS_S1_T1_19: return "diproton_S1_T1_3-_19";
    case DIPROTON_3_MINUS_S1_T1_20: return "diproton_S1_T1_3-_20";
    case DIPROTON_3_MINUS_S1_T1_21: return "diproton_S1_T1_3-_21";
    case DIPROTON_3_MINUS_S1_T1_22: return "diproton_S1_T1_3-_22";
    case DIPROTON_3_MINUS_S1_T1_23: return "diproton_S1_T1_3-_23";
    case DIPROTON_3_MINUS_S1_T1_24: return "diproton_S1_T1_3-_24";
    case DIPROTON_3_MINUS_S1_T1_25: return "diproton_S1_T1_3-_25";
    case DIPROTON_3_MINUS_S1_T1_26: return "diproton_S1_T1_3-_26";
    case DIPROTON_3_MINUS_S1_T1_27: return "diproton_S1_T1_3-_27";
    case DIPROTON_3_MINUS_S1_T1_28: return "diproton_S1_T1_3-_28";
    case DIPROTON_3_MINUS_S1_T1_29: return "diproton_S1_T1_3-_29";
    case DIPROTON_3_MINUS_S1_T1_30: return "diproton_S1_T1_3-_30";
    case DIPROTON_3_MINUS_S1_T1_31: return "diproton_S1_T1_3-_31";
    case DIPROTON_3_MINUS_S1_T1_32: return "diproton_S1_T1_3-_32";
    case DIPROTON_3_MINUS_S1_T1_33: return "diproton_S1_T1_3-_33";
    case DIPROTON_3_MINUS_S1_T1_34: return "diproton_S1_T1_3-_34";
    case DIPROTON_3_MINUS_S1_T1_35: return "diproton_S1_T1_3-_35";
    case DIPROTON_3_MINUS_S1_T1_36: return "diproton_S1_T1_3-_36";
    case DIPROTON_3_MINUS_S1_T1_37: return "diproton_S1_T1_3-_37";
    case DIPROTON_3_MINUS_S1_T1_38: return "diproton_S1_T1_3-_38";
    case DIPROTON_3_MINUS_S1_T1_39: return "diproton_S1_T1_3-_39";
    case DIPROTON_3_MINUS_S1_T1_40: return "diproton_S1_T1_3-_40";
    case DIPROTON_3_MINUS_S1_T1_41: return "diproton_S1_T1_3-_41";
    case DIPROTON_3_MINUS_S1_T1_42: return "diproton_S1_T1_3-_42";
    case DIPROTON_3_MINUS_S1_T1_43: return "diproton_S1_T1_3-_43";
    case DIPROTON_3_MINUS_S1_T1_44: return "diproton_S1_T1_3-_44";
    case DIPROTON_3_MINUS_S1_T1_45: return "diproton_S1_T1_3-_45";
    case DIPROTON_3_MINUS_S1_T1_46: return "diproton_S1_T1_3-_46";
    case DIPROTON_3_MINUS_S1_T1_47: return "diproton_S1_T1_3-_47";
    case DIPROTON_3_MINUS_S1_T1_48: return "diproton_S1_T1_3-_48";
    case DIPROTON_3_MINUS_S1_T1_49: return "diproton_S1_T1_3-_49";
    case DIPROTON_3_MINUS_S1_T1_50: return "diproton_S1_T1_3-_50";
    case DIPROTON_3_MINUS_S1_T1_51: return "diproton_S1_T1_3-_51";
    case DIPROTON_3_MINUS_S1_T1_52: return "diproton_S1_T1_3-_52";
    case DIPROTON_3_MINUS_S1_T1_53: return "diproton_S1_T1_3-_53";
    case DIPROTON_3_MINUS_S1_T1_54: return "diproton_S1_T1_3-_54";
    case DIPROTON_3_MINUS_S1_T1_55: return "diproton_S1_T1_3-_55";
    case DIPROTON_3_MINUS_S1_T1_56: return "diproton_S1_T1_3-_56";
    case DIPROTON_3_MINUS_S1_T1_57: return "diproton_S1_T1_3-_57";
    case DIPROTON_3_MINUS_S1_T1_58: return "diproton_S1_T1_3-_58";
    case DIPROTON_3_MINUS_S1_T1_59: return "diproton_S1_T1_3-_59";
    case DIPROTON_3_MINUS_S1_T1_60: return "diproton_S1_T1_3-_60";
    case DIPROTON_3_MINUS_S1_T1_61: return "diproton_S1_T1_3-_61";
    case DIPROTON_3_MINUS_S1_T1_62: return "diproton_S1_T1_3-_62";
    case DIPROTON_3_MINUS_S1_T1_63: return "diproton_S1_T1_3-_63";
    case DIPROTON_3_MINUS_S1_T1_64: return "diproton_S1_T1_3-_64";
    case DIPROTON_3_MINUS_S1_T1_65: return "diproton_S1_T1_3-_65";
    case DIPROTON_3_MINUS_S1_T1_66: return "diproton_S1_T1_3-_66";
    case DIPROTON_3_MINUS_S1_T1_67: return "diproton_S1_T1_3-_67";
    case DIPROTON_3_MINUS_S1_T1_68: return "diproton_S1_T1_3-_68";
    case DIPROTON_3_MINUS_S1_T1_69: return "diproton_S1_T1_3-_69";
    case DIPROTON_3_MINUS_S1_T1_70: return "diproton_S1_T1_3-_70";
    case DIPROTON_3_MINUS_S1_T1_71: return "diproton_S1_T1_3-_71";
    case DIPROTON_3_MINUS_S1_T1_72: return "diproton_S1_T1_3-_72";
    case DIPROTON_3_MINUS_S1_T1_73: return "diproton_S1_T1_3-_73";
    case DIPROTON_3_MINUS_S1_T1_74: return "diproton_S1_T1_3-_74";
    case DIPROTON_3_MINUS_S1_T1_75: return "diproton_S1_T1_3-_75";
    case DIPROTON_3_MINUS_S1_T1_76: return "diproton_S1_T1_3-_76";
    case DIPROTON_3_MINUS_S1_T1_77: return "diproton_S1_T1_3-_77";
    case DIPROTON_3_MINUS_S1_T1_78: return "diproton_S1_T1_3-_78";
    case DIPROTON_3_MINUS_S1_T1_79: return "diproton_S1_T1_3-_79";
    case DIPROTON_3_MINUS_S1_T1_80: return "diproton_S1_T1_3-_80";
    case DIPROTON_3_MINUS_S1_T1_81: return "diproton_S1_T1_3-_81";
    case DIPROTON_3_MINUS_S1_T1_82: return "diproton_S1_T1_3-_82";
    case DIPROTON_3_MINUS_S1_T1_83: return "diproton_S1_T1_3-_83";
    case DIPROTON_3_MINUS_S1_T1_84: return "diproton_S1_T1_3-_84";
    case DIPROTON_3_MINUS_S1_T1_85: return "diproton_S1_T1_3-_85";
    case DIPROTON_3_MINUS_S1_T1_86: return "diproton_S1_T1_3-_86";
    case DIPROTON_3_MINUS_S1_T1_87: return "diproton_S1_T1_3-_87";
    case DIPROTON_3_MINUS_S1_T1_88: return "diproton_S1_T1_3-_88";
    case DIPROTON_3_MINUS_S1_T1_89: return "diproton_S1_T1_3-_89";
    case DIPROTON_3_MINUS_S1_T1_90: return "diproton_S1_T1_3-_90";
    case DIPROTON_3_MINUS_S1_T1_91: return "diproton_S1_T1_3-_91";
    case DIPROTON_3_MINUS_S1_T1_92: return "diproton_S1_T1_3-_92";
    case DIPROTON_3_MINUS_S1_T1_93: return "diproton_S1_T1_3-_93";
    case DIPROTON_3_MINUS_S1_T1_94: return "diproton_S1_T1_3-_94";
    case DIPROTON_3_MINUS_S1_T1_95: return "diproton_S1_T1_3-_95";
    case DIPROTON_3_MINUS_S1_T1_96: return "diproton_S1_T1_3-_96";
    case DIPROTON_3_MINUS_S1_T1_97: return "diproton_S1_T1_3-_97";
    case DIPROTON_3_MINUS_S1_T1_98: return "diproton_S1_T1_3-_98";
    case DIPROTON_3_MINUS_S1_T1_99: return "diproton_S1_T1_3-_99";

    case DIPROTON_4_MINUS_S1_T1:    return "diproton_S1_T1_4-";
    case DIPROTON_4_MINUS_S1_T1_0:  return "diproton_S1_T1_4-_0";
    case DIPROTON_4_MINUS_S1_T1_1:  return "diproton_S1_T1_4-_1";
    case DIPROTON_4_MINUS_S1_T1_2:  return "diproton_S1_T1_4-_2";
    case DIPROTON_4_MINUS_S1_T1_3:  return "diproton_S1_T1_4-_3";
    case DIPROTON_4_MINUS_S1_T1_4:  return "diproton_S1_T1_4-_4";
    case DIPROTON_4_MINUS_S1_T1_5:  return "diproton_S1_T1_4-_5";
    case DIPROTON_4_MINUS_S1_T1_6:  return "diproton_S1_T1_4-_6";
    case DIPROTON_4_MINUS_S1_T1_7:  return "diproton_S1_T1_4-_7";
    case DIPROTON_4_MINUS_S1_T1_8:  return "diproton_S1_T1_4-_8";
    case DIPROTON_4_MINUS_S1_T1_9:  return "diproton_S1_T1_4-_9";
    case DIPROTON_4_MINUS_S1_T1_10: return "diproton_S1_T1_4-_10";
    case DIPROTON_4_MINUS_S1_T1_11: return "diproton_S1_T1_4-_11";
    case DIPROTON_4_MINUS_S1_T1_12: return "diproton_S1_T1_4-_12";
    case DIPROTON_4_MINUS_S1_T1_13: return "diproton_S1_T1_4-_13";
    case DIPROTON_4_MINUS_S1_T1_14: return "diproton_S1_T1_4-_14";
    case DIPROTON_4_MINUS_S1_T1_15: return "diproton_S1_T1_4-_15";
    case DIPROTON_4_MINUS_S1_T1_16: return "diproton_S1_T1_4-_16";
    case DIPROTON_4_MINUS_S1_T1_17: return "diproton_S1_T1_4-_17";
    case DIPROTON_4_MINUS_S1_T1_18: return "diproton_S1_T1_4-_18";
    case DIPROTON_4_MINUS_S1_T1_19: return "diproton_S1_T1_4-_19";
    case DIPROTON_4_MINUS_S1_T1_20: return "diproton_S1_T1_4-_20";
    case DIPROTON_4_MINUS_S1_T1_21: return "diproton_S1_T1_4-_21";
    case DIPROTON_4_MINUS_S1_T1_22: return "diproton_S1_T1_4-_22";
    case DIPROTON_4_MINUS_S1_T1_23: return "diproton_S1_T1_4-_23";
    case DIPROTON_4_MINUS_S1_T1_24: return "diproton_S1_T1_4-_24";
    case DIPROTON_4_MINUS_S1_T1_25: return "diproton_S1_T1_4-_25";
    case DIPROTON_4_MINUS_S1_T1_26: return "diproton_S1_T1_4-_26";
    case DIPROTON_4_MINUS_S1_T1_27: return "diproton_S1_T1_4-_27";
    case DIPROTON_4_MINUS_S1_T1_28: return "diproton_S1_T1_4-_28";
    case DIPROTON_4_MINUS_S1_T1_29: return "diproton_S1_T1_4-_29";
    case DIPROTON_4_MINUS_S1_T1_30: return "diproton_S1_T1_4-_30";
    case DIPROTON_4_MINUS_S1_T1_31: return "diproton_S1_T1_4-_31";
    case DIPROTON_4_MINUS_S1_T1_32: return "diproton_S1_T1_4-_32";
    case DIPROTON_4_MINUS_S1_T1_33: return "diproton_S1_T1_4-_33";
    case DIPROTON_4_MINUS_S1_T1_34: return "diproton_S1_T1_4-_34";
    case DIPROTON_4_MINUS_S1_T1_35: return "diproton_S1_T1_4-_35";
    case DIPROTON_4_MINUS_S1_T1_36: return "diproton_S1_T1_4-_36";
    case DIPROTON_4_MINUS_S1_T1_37: return "diproton_S1_T1_4-_37";
    case DIPROTON_4_MINUS_S1_T1_38: return "diproton_S1_T1_4-_38";
    case DIPROTON_4_MINUS_S1_T1_39: return "diproton_S1_T1_4-_39";
    case DIPROTON_4_MINUS_S1_T1_40: return "diproton_S1_T1_4-_40";
    case DIPROTON_4_MINUS_S1_T1_41: return "diproton_S1_T1_4-_41";
    case DIPROTON_4_MINUS_S1_T1_42: return "diproton_S1_T1_4-_42";
    case DIPROTON_4_MINUS_S1_T1_43: return "diproton_S1_T1_4-_43";
    case DIPROTON_4_MINUS_S1_T1_44: return "diproton_S1_T1_4-_44";
    case DIPROTON_4_MINUS_S1_T1_45: return "diproton_S1_T1_4-_45";
    case DIPROTON_4_MINUS_S1_T1_46: return "diproton_S1_T1_4-_46";
    case DIPROTON_4_MINUS_S1_T1_47: return "diproton_S1_T1_4-_47";
    case DIPROTON_4_MINUS_S1_T1_48: return "diproton_S1_T1_4-_48";
    case DIPROTON_4_MINUS_S1_T1_49: return "diproton_S1_T1_4-_49";
    case DIPROTON_4_MINUS_S1_T1_50: return "diproton_S1_T1_4-_50";
    case DIPROTON_4_MINUS_S1_T1_51: return "diproton_S1_T1_4-_51";
    case DIPROTON_4_MINUS_S1_T1_52: return "diproton_S1_T1_4-_52";
    case DIPROTON_4_MINUS_S1_T1_53: return "diproton_S1_T1_4-_53";
    case DIPROTON_4_MINUS_S1_T1_54: return "diproton_S1_T1_4-_54";
    case DIPROTON_4_MINUS_S1_T1_55: return "diproton_S1_T1_4-_55";
    case DIPROTON_4_MINUS_S1_T1_56: return "diproton_S1_T1_4-_56";
    case DIPROTON_4_MINUS_S1_T1_57: return "diproton_S1_T1_4-_57";
    case DIPROTON_4_MINUS_S1_T1_58: return "diproton_S1_T1_4-_58";
    case DIPROTON_4_MINUS_S1_T1_59: return "diproton_S1_T1_4-_59";
    case DIPROTON_4_MINUS_S1_T1_60: return "diproton_S1_T1_4-_60";
    case DIPROTON_4_MINUS_S1_T1_61: return "diproton_S1_T1_4-_61";
    case DIPROTON_4_MINUS_S1_T1_62: return "diproton_S1_T1_4-_62";
    case DIPROTON_4_MINUS_S1_T1_63: return "diproton_S1_T1_4-_63";
    case DIPROTON_4_MINUS_S1_T1_64: return "diproton_S1_T1_4-_64";
    case DIPROTON_4_MINUS_S1_T1_65: return "diproton_S1_T1_4-_65";
    case DIPROTON_4_MINUS_S1_T1_66: return "diproton_S1_T1_4-_66";
    case DIPROTON_4_MINUS_S1_T1_67: return "diproton_S1_T1_4-_67";
    case DIPROTON_4_MINUS_S1_T1_68: return "diproton_S1_T1_4-_68";
    case DIPROTON_4_MINUS_S1_T1_69: return "diproton_S1_T1_4-_69";
    case DIPROTON_4_MINUS_S1_T1_70: return "diproton_S1_T1_4-_70";
    case DIPROTON_4_MINUS_S1_T1_71: return "diproton_S1_T1_4-_71";
    case DIPROTON_4_MINUS_S1_T1_72: return "diproton_S1_T1_4-_72";
    case DIPROTON_4_MINUS_S1_T1_73: return "diproton_S1_T1_4-_73";
    case DIPROTON_4_MINUS_S1_T1_74: return "diproton_S1_T1_4-_74";
    case DIPROTON_4_MINUS_S1_T1_75: return "diproton_S1_T1_4-_75";
    case DIPROTON_4_MINUS_S1_T1_76: return "diproton_S1_T1_4-_76";
    case DIPROTON_4_MINUS_S1_T1_77: return "diproton_S1_T1_4-_77";
    case DIPROTON_4_MINUS_S1_T1_78: return "diproton_S1_T1_4-_78";
    case DIPROTON_4_MINUS_S1_T1_79: return "diproton_S1_T1_4-_79";
    case DIPROTON_4_MINUS_S1_T1_80: return "diproton_S1_T1_4-_80";
    case DIPROTON_4_MINUS_S1_T1_81: return "diproton_S1_T1_4-_81";
    case DIPROTON_4_MINUS_S1_T1_82: return "diproton_S1_T1_4-_82";
    case DIPROTON_4_MINUS_S1_T1_83: return "diproton_S1_T1_4-_83";
    case DIPROTON_4_MINUS_S1_T1_84: return "diproton_S1_T1_4-_84";
    case DIPROTON_4_MINUS_S1_T1_85: return "diproton_S1_T1_4-_85";
    case DIPROTON_4_MINUS_S1_T1_86: return "diproton_S1_T1_4-_86";
    case DIPROTON_4_MINUS_S1_T1_87: return "diproton_S1_T1_4-_87";
    case DIPROTON_4_MINUS_S1_T1_88: return "diproton_S1_T1_4-_88";
    case DIPROTON_4_MINUS_S1_T1_89: return "diproton_S1_T1_4-_89";
    case DIPROTON_4_MINUS_S1_T1_90: return "diproton_S1_T1_4-_90";
    case DIPROTON_4_MINUS_S1_T1_91: return "diproton_S1_T1_4-_91";
    case DIPROTON_4_MINUS_S1_T1_92: return "diproton_S1_T1_4-_92";
    case DIPROTON_4_MINUS_S1_T1_93: return "diproton_S1_T1_4-_93";
    case DIPROTON_4_MINUS_S1_T1_94: return "diproton_S1_T1_4-_94";
    case DIPROTON_4_MINUS_S1_T1_95: return "diproton_S1_T1_4-_95";
    case DIPROTON_4_MINUS_S1_T1_96: return "diproton_S1_T1_4-_96";
    case DIPROTON_4_MINUS_S1_T1_97: return "diproton_S1_T1_4-_97";
    case DIPROTON_4_MINUS_S1_T1_98: return "diproton_S1_T1_4-_98";
    case DIPROTON_4_MINUS_S1_T1_99: return "diproton_S1_T1_4-_99";

    case DIPROTON_5_MINUS_S1_T1:    return "diproton_S1_T1_5-";
    case DIPROTON_5_MINUS_S1_T1_0:  return "diproton_S1_T1_5-_0";
    case DIPROTON_5_MINUS_S1_T1_1:  return "diproton_S1_T1_5-_1";
    case DIPROTON_5_MINUS_S1_T1_2:  return "diproton_S1_T1_5-_2";
    case DIPROTON_5_MINUS_S1_T1_3:  return "diproton_S1_T1_5-_3";
    case DIPROTON_5_MINUS_S1_T1_4:  return "diproton_S1_T1_5-_4";
    case DIPROTON_5_MINUS_S1_T1_5:  return "diproton_S1_T1_5-_5";
    case DIPROTON_5_MINUS_S1_T1_6:  return "diproton_S1_T1_5-_6";
    case DIPROTON_5_MINUS_S1_T1_7:  return "diproton_S1_T1_5-_7";
    case DIPROTON_5_MINUS_S1_T1_8:  return "diproton_S1_T1_5-_8";
    case DIPROTON_5_MINUS_S1_T1_9:  return "diproton_S1_T1_5-_9";
    case DIPROTON_5_MINUS_S1_T1_10: return "diproton_S1_T1_5-_10";
    case DIPROTON_5_MINUS_S1_T1_11: return "diproton_S1_T1_5-_11";
    case DIPROTON_5_MINUS_S1_T1_12: return "diproton_S1_T1_5-_12";
    case DIPROTON_5_MINUS_S1_T1_13: return "diproton_S1_T1_5-_13";
    case DIPROTON_5_MINUS_S1_T1_14: return "diproton_S1_T1_5-_14";
    case DIPROTON_5_MINUS_S1_T1_15: return "diproton_S1_T1_5-_15";
    case DIPROTON_5_MINUS_S1_T1_16: return "diproton_S1_T1_5-_16";
    case DIPROTON_5_MINUS_S1_T1_17: return "diproton_S1_T1_5-_17";
    case DIPROTON_5_MINUS_S1_T1_18: return "diproton_S1_T1_5-_18";
    case DIPROTON_5_MINUS_S1_T1_19: return "diproton_S1_T1_5-_19";
    case DIPROTON_5_MINUS_S1_T1_20: return "diproton_S1_T1_5-_20";
    case DIPROTON_5_MINUS_S1_T1_21: return "diproton_S1_T1_5-_21";
    case DIPROTON_5_MINUS_S1_T1_22: return "diproton_S1_T1_5-_22";
    case DIPROTON_5_MINUS_S1_T1_23: return "diproton_S1_T1_5-_23";
    case DIPROTON_5_MINUS_S1_T1_24: return "diproton_S1_T1_5-_24";
    case DIPROTON_5_MINUS_S1_T1_25: return "diproton_S1_T1_5-_25";
    case DIPROTON_5_MINUS_S1_T1_26: return "diproton_S1_T1_5-_26";
    case DIPROTON_5_MINUS_S1_T1_27: return "diproton_S1_T1_5-_27";
    case DIPROTON_5_MINUS_S1_T1_28: return "diproton_S1_T1_5-_28";
    case DIPROTON_5_MINUS_S1_T1_29: return "diproton_S1_T1_5-_29";
    case DIPROTON_5_MINUS_S1_T1_30: return "diproton_S1_T1_5-_30";
    case DIPROTON_5_MINUS_S1_T1_31: return "diproton_S1_T1_5-_31";
    case DIPROTON_5_MINUS_S1_T1_32: return "diproton_S1_T1_5-_32";
    case DIPROTON_5_MINUS_S1_T1_33: return "diproton_S1_T1_5-_33";
    case DIPROTON_5_MINUS_S1_T1_34: return "diproton_S1_T1_5-_34";
    case DIPROTON_5_MINUS_S1_T1_35: return "diproton_S1_T1_5-_35";
    case DIPROTON_5_MINUS_S1_T1_36: return "diproton_S1_T1_5-_36";
    case DIPROTON_5_MINUS_S1_T1_37: return "diproton_S1_T1_5-_37";
    case DIPROTON_5_MINUS_S1_T1_38: return "diproton_S1_T1_5-_38";
    case DIPROTON_5_MINUS_S1_T1_39: return "diproton_S1_T1_5-_39";
    case DIPROTON_5_MINUS_S1_T1_40: return "diproton_S1_T1_5-_40";
    case DIPROTON_5_MINUS_S1_T1_41: return "diproton_S1_T1_5-_41";
    case DIPROTON_5_MINUS_S1_T1_42: return "diproton_S1_T1_5-_42";
    case DIPROTON_5_MINUS_S1_T1_43: return "diproton_S1_T1_5-_43";
    case DIPROTON_5_MINUS_S1_T1_44: return "diproton_S1_T1_5-_44";
    case DIPROTON_5_MINUS_S1_T1_45: return "diproton_S1_T1_5-_45";
    case DIPROTON_5_MINUS_S1_T1_46: return "diproton_S1_T1_5-_46";
    case DIPROTON_5_MINUS_S1_T1_47: return "diproton_S1_T1_5-_47";
    case DIPROTON_5_MINUS_S1_T1_48: return "diproton_S1_T1_5-_48";
    case DIPROTON_5_MINUS_S1_T1_49: return "diproton_S1_T1_5-_49";
    case DIPROTON_5_MINUS_S1_T1_50: return "diproton_S1_T1_5-_50";
    case DIPROTON_5_MINUS_S1_T1_51: return "diproton_S1_T1_5-_51";
    case DIPROTON_5_MINUS_S1_T1_52: return "diproton_S1_T1_5-_52";
    case DIPROTON_5_MINUS_S1_T1_53: return "diproton_S1_T1_5-_53";
    case DIPROTON_5_MINUS_S1_T1_54: return "diproton_S1_T1_5-_54";
    case DIPROTON_5_MINUS_S1_T1_55: return "diproton_S1_T1_5-_55";
    case DIPROTON_5_MINUS_S1_T1_56: return "diproton_S1_T1_5-_56";
    case DIPROTON_5_MINUS_S1_T1_57: return "diproton_S1_T1_5-_57";
    case DIPROTON_5_MINUS_S1_T1_58: return "diproton_S1_T1_5-_58";
    case DIPROTON_5_MINUS_S1_T1_59: return "diproton_S1_T1_5-_59";
    case DIPROTON_5_MINUS_S1_T1_60: return "diproton_S1_T1_5-_60";
    case DIPROTON_5_MINUS_S1_T1_61: return "diproton_S1_T1_5-_61";
    case DIPROTON_5_MINUS_S1_T1_62: return "diproton_S1_T1_5-_62";
    case DIPROTON_5_MINUS_S1_T1_63: return "diproton_S1_T1_5-_63";
    case DIPROTON_5_MINUS_S1_T1_64: return "diproton_S1_T1_5-_64";
    case DIPROTON_5_MINUS_S1_T1_65: return "diproton_S1_T1_5-_65";
    case DIPROTON_5_MINUS_S1_T1_66: return "diproton_S1_T1_5-_66";
    case DIPROTON_5_MINUS_S1_T1_67: return "diproton_S1_T1_5-_67";
    case DIPROTON_5_MINUS_S1_T1_68: return "diproton_S1_T1_5-_68";
    case DIPROTON_5_MINUS_S1_T1_69: return "diproton_S1_T1_5-_69";
    case DIPROTON_5_MINUS_S1_T1_70: return "diproton_S1_T1_5-_70";
    case DIPROTON_5_MINUS_S1_T1_71: return "diproton_S1_T1_5-_71";
    case DIPROTON_5_MINUS_S1_T1_72: return "diproton_S1_T1_5-_72";
    case DIPROTON_5_MINUS_S1_T1_73: return "diproton_S1_T1_5-_73";
    case DIPROTON_5_MINUS_S1_T1_74: return "diproton_S1_T1_5-_74";
    case DIPROTON_5_MINUS_S1_T1_75: return "diproton_S1_T1_5-_75";
    case DIPROTON_5_MINUS_S1_T1_76: return "diproton_S1_T1_5-_76";
    case DIPROTON_5_MINUS_S1_T1_77: return "diproton_S1_T1_5-_77";
    case DIPROTON_5_MINUS_S1_T1_78: return "diproton_S1_T1_5-_78";
    case DIPROTON_5_MINUS_S1_T1_79: return "diproton_S1_T1_5-_79";
    case DIPROTON_5_MINUS_S1_T1_80: return "diproton_S1_T1_5-_80";
    case DIPROTON_5_MINUS_S1_T1_81: return "diproton_S1_T1_5-_81";
    case DIPROTON_5_MINUS_S1_T1_82: return "diproton_S1_T1_5-_82";
    case DIPROTON_5_MINUS_S1_T1_83: return "diproton_S1_T1_5-_83";
    case DIPROTON_5_MINUS_S1_T1_84: return "diproton_S1_T1_5-_84";
    case DIPROTON_5_MINUS_S1_T1_85: return "diproton_S1_T1_5-_85";
    case DIPROTON_5_MINUS_S1_T1_86: return "diproton_S1_T1_5-_86";
    case DIPROTON_5_MINUS_S1_T1_87: return "diproton_S1_T1_5-_87";
    case DIPROTON_5_MINUS_S1_T1_88: return "diproton_S1_T1_5-_88";
    case DIPROTON_5_MINUS_S1_T1_89: return "diproton_S1_T1_5-_89";
    case DIPROTON_5_MINUS_S1_T1_90: return "diproton_S1_T1_5-_90";
    case DIPROTON_5_MINUS_S1_T1_91: return "diproton_S1_T1_5-_91";
    case DIPROTON_5_MINUS_S1_T1_92: return "diproton_S1_T1_5-_92";
    case DIPROTON_5_MINUS_S1_T1_93: return "diproton_S1_T1_5-_93";
    case DIPROTON_5_MINUS_S1_T1_94: return "diproton_S1_T1_5-_94";
    case DIPROTON_5_MINUS_S1_T1_95: return "diproton_S1_T1_5-_95";
    case DIPROTON_5_MINUS_S1_T1_96: return "diproton_S1_T1_5-_96";
    case DIPROTON_5_MINUS_S1_T1_97: return "diproton_S1_T1_5-_97";
    case DIPROTON_5_MINUS_S1_T1_98: return "diproton_S1_T1_5-_98";
    case DIPROTON_5_MINUS_S1_T1_99: return "diproton_S1_T1_5-_99";

    case DINEUTRON_0_PLUS_S0_T1:    return "dineutron_S0_T1_0+";
    case DINEUTRON_0_PLUS_S0_T1_0:  return "dineutron_S0_T1_0+_0";
    case DINEUTRON_0_PLUS_S0_T1_1:  return "dineutron_S0_T1_0+_1";
    case DINEUTRON_0_PLUS_S0_T1_2:  return "dineutron_S0_T1_0+_2";
    case DINEUTRON_0_PLUS_S0_T1_3:  return "dineutron_S0_T1_0+_3";
    case DINEUTRON_0_PLUS_S0_T1_4:  return "dineutron_S0_T1_0+_4";
    case DINEUTRON_0_PLUS_S0_T1_5:  return "dineutron_S0_T1_0+_5";
    case DINEUTRON_0_PLUS_S0_T1_6:  return "dineutron_S0_T1_0+_6";
    case DINEUTRON_0_PLUS_S0_T1_7:  return "dineutron_S0_T1_0+_7";
    case DINEUTRON_0_PLUS_S0_T1_8:  return "dineutron_S0_T1_0+_8";
    case DINEUTRON_0_PLUS_S0_T1_9:  return "dineutron_S0_T1_0+_9";
    case DINEUTRON_0_PLUS_S0_T1_10: return "dineutron_S0_T1_0+_10";
    case DINEUTRON_0_PLUS_S0_T1_11: return "dineutron_S0_T1_0+_11";
    case DINEUTRON_0_PLUS_S0_T1_12: return "dineutron_S0_T1_0+_12";
    case DINEUTRON_0_PLUS_S0_T1_13: return "dineutron_S0_T1_0+_13";
    case DINEUTRON_0_PLUS_S0_T1_14: return "dineutron_S0_T1_0+_14";
    case DINEUTRON_0_PLUS_S0_T1_15: return "dineutron_S0_T1_0+_15";
    case DINEUTRON_0_PLUS_S0_T1_16: return "dineutron_S0_T1_0+_16";
    case DINEUTRON_0_PLUS_S0_T1_17: return "dineutron_S0_T1_0+_17";
    case DINEUTRON_0_PLUS_S0_T1_18: return "dineutron_S0_T1_0+_18";
    case DINEUTRON_0_PLUS_S0_T1_19: return "dineutron_S0_T1_0+_19";
    case DINEUTRON_0_PLUS_S0_T1_20: return "dineutron_S0_T1_0+_20";
    case DINEUTRON_0_PLUS_S0_T1_21: return "dineutron_S0_T1_0+_21";
    case DINEUTRON_0_PLUS_S0_T1_22: return "dineutron_S0_T1_0+_22";
    case DINEUTRON_0_PLUS_S0_T1_23: return "dineutron_S0_T1_0+_23";
    case DINEUTRON_0_PLUS_S0_T1_24: return "dineutron_S0_T1_0+_24";
    case DINEUTRON_0_PLUS_S0_T1_25: return "dineutron_S0_T1_0+_25";
    case DINEUTRON_0_PLUS_S0_T1_26: return "dineutron_S0_T1_0+_26";
    case DINEUTRON_0_PLUS_S0_T1_27: return "dineutron_S0_T1_0+_27";
    case DINEUTRON_0_PLUS_S0_T1_28: return "dineutron_S0_T1_0+_28";
    case DINEUTRON_0_PLUS_S0_T1_29: return "dineutron_S0_T1_0+_29";
    case DINEUTRON_0_PLUS_S0_T1_30: return "dineutron_S0_T1_0+_30";
    case DINEUTRON_0_PLUS_S0_T1_31: return "dineutron_S0_T1_0+_31";
    case DINEUTRON_0_PLUS_S0_T1_32: return "dineutron_S0_T1_0+_32";
    case DINEUTRON_0_PLUS_S0_T1_33: return "dineutron_S0_T1_0+_33";
    case DINEUTRON_0_PLUS_S0_T1_34: return "dineutron_S0_T1_0+_34";
    case DINEUTRON_0_PLUS_S0_T1_35: return "dineutron_S0_T1_0+_35";
    case DINEUTRON_0_PLUS_S0_T1_36: return "dineutron_S0_T1_0+_36";
    case DINEUTRON_0_PLUS_S0_T1_37: return "dineutron_S0_T1_0+_37";
    case DINEUTRON_0_PLUS_S0_T1_38: return "dineutron_S0_T1_0+_38";
    case DINEUTRON_0_PLUS_S0_T1_39: return "dineutron_S0_T1_0+_39";
    case DINEUTRON_0_PLUS_S0_T1_40: return "dineutron_S0_T1_0+_40";
    case DINEUTRON_0_PLUS_S0_T1_41: return "dineutron_S0_T1_0+_41";
    case DINEUTRON_0_PLUS_S0_T1_42: return "dineutron_S0_T1_0+_42";
    case DINEUTRON_0_PLUS_S0_T1_43: return "dineutron_S0_T1_0+_43";
    case DINEUTRON_0_PLUS_S0_T1_44: return "dineutron_S0_T1_0+_44";
    case DINEUTRON_0_PLUS_S0_T1_45: return "dineutron_S0_T1_0+_45";
    case DINEUTRON_0_PLUS_S0_T1_46: return "dineutron_S0_T1_0+_46";
    case DINEUTRON_0_PLUS_S0_T1_47: return "dineutron_S0_T1_0+_47";
    case DINEUTRON_0_PLUS_S0_T1_48: return "dineutron_S0_T1_0+_48";
    case DINEUTRON_0_PLUS_S0_T1_49: return "dineutron_S0_T1_0+_49";
    case DINEUTRON_0_PLUS_S0_T1_50: return "dineutron_S0_T1_0+_50";
    case DINEUTRON_0_PLUS_S0_T1_51: return "dineutron_S0_T1_0+_51";
    case DINEUTRON_0_PLUS_S0_T1_52: return "dineutron_S0_T1_0+_52";
    case DINEUTRON_0_PLUS_S0_T1_53: return "dineutron_S0_T1_0+_53";
    case DINEUTRON_0_PLUS_S0_T1_54: return "dineutron_S0_T1_0+_54";
    case DINEUTRON_0_PLUS_S0_T1_55: return "dineutron_S0_T1_0+_55";
    case DINEUTRON_0_PLUS_S0_T1_56: return "dineutron_S0_T1_0+_56";
    case DINEUTRON_0_PLUS_S0_T1_57: return "dineutron_S0_T1_0+_57";
    case DINEUTRON_0_PLUS_S0_T1_58: return "dineutron_S0_T1_0+_58";
    case DINEUTRON_0_PLUS_S0_T1_59: return "dineutron_S0_T1_0+_59";
    case DINEUTRON_0_PLUS_S0_T1_60: return "dineutron_S0_T1_0+_60";
    case DINEUTRON_0_PLUS_S0_T1_61: return "dineutron_S0_T1_0+_61";
    case DINEUTRON_0_PLUS_S0_T1_62: return "dineutron_S0_T1_0+_62";
    case DINEUTRON_0_PLUS_S0_T1_63: return "dineutron_S0_T1_0+_63";
    case DINEUTRON_0_PLUS_S0_T1_64: return "dineutron_S0_T1_0+_64";
    case DINEUTRON_0_PLUS_S0_T1_65: return "dineutron_S0_T1_0+_65";
    case DINEUTRON_0_PLUS_S0_T1_66: return "dineutron_S0_T1_0+_66";
    case DINEUTRON_0_PLUS_S0_T1_67: return "dineutron_S0_T1_0+_67";
    case DINEUTRON_0_PLUS_S0_T1_68: return "dineutron_S0_T1_0+_68";
    case DINEUTRON_0_PLUS_S0_T1_69: return "dineutron_S0_T1_0+_69";
    case DINEUTRON_0_PLUS_S0_T1_70: return "dineutron_S0_T1_0+_70";
    case DINEUTRON_0_PLUS_S0_T1_71: return "dineutron_S0_T1_0+_71";
    case DINEUTRON_0_PLUS_S0_T1_72: return "dineutron_S0_T1_0+_72";
    case DINEUTRON_0_PLUS_S0_T1_73: return "dineutron_S0_T1_0+_73";
    case DINEUTRON_0_PLUS_S0_T1_74: return "dineutron_S0_T1_0+_74";
    case DINEUTRON_0_PLUS_S0_T1_75: return "dineutron_S0_T1_0+_75";
    case DINEUTRON_0_PLUS_S0_T1_76: return "dineutron_S0_T1_0+_76";
    case DINEUTRON_0_PLUS_S0_T1_77: return "dineutron_S0_T1_0+_77";
    case DINEUTRON_0_PLUS_S0_T1_78: return "dineutron_S0_T1_0+_78";
    case DINEUTRON_0_PLUS_S0_T1_79: return "dineutron_S0_T1_0+_79";
    case DINEUTRON_0_PLUS_S0_T1_80: return "dineutron_S0_T1_0+_80";
    case DINEUTRON_0_PLUS_S0_T1_81: return "dineutron_S0_T1_0+_81";
    case DINEUTRON_0_PLUS_S0_T1_82: return "dineutron_S0_T1_0+_82";
    case DINEUTRON_0_PLUS_S0_T1_83: return "dineutron_S0_T1_0+_83";
    case DINEUTRON_0_PLUS_S0_T1_84: return "dineutron_S0_T1_0+_84";
    case DINEUTRON_0_PLUS_S0_T1_85: return "dineutron_S0_T1_0+_85";
    case DINEUTRON_0_PLUS_S0_T1_86: return "dineutron_S0_T1_0+_86";
    case DINEUTRON_0_PLUS_S0_T1_87: return "dineutron_S0_T1_0+_87";
    case DINEUTRON_0_PLUS_S0_T1_88: return "dineutron_S0_T1_0+_88";
    case DINEUTRON_0_PLUS_S0_T1_89: return "dineutron_S0_T1_0+_89";
    case DINEUTRON_0_PLUS_S0_T1_90: return "dineutron_S0_T1_0+_90";
    case DINEUTRON_0_PLUS_S0_T1_91: return "dineutron_S0_T1_0+_91";
    case DINEUTRON_0_PLUS_S0_T1_92: return "dineutron_S0_T1_0+_92";
    case DINEUTRON_0_PLUS_S0_T1_93: return "dineutron_S0_T1_0+_93";
    case DINEUTRON_0_PLUS_S0_T1_94: return "dineutron_S0_T1_0+_94";
    case DINEUTRON_0_PLUS_S0_T1_95: return "dineutron_S0_T1_0+_95";
    case DINEUTRON_0_PLUS_S0_T1_96: return "dineutron_S0_T1_0+_96";
    case DINEUTRON_0_PLUS_S0_T1_97: return "dineutron_S0_T1_0+_97";
    case DINEUTRON_0_PLUS_S0_T1_98: return "dineutron_S0_T1_0+_98";
    case DINEUTRON_0_PLUS_S0_T1_99: return "dineutron_S0_T1_0+_99";

    case DINEUTRON_2_PLUS_S0_T1:    return "dineutron_S0_T1_2+";
    case DINEUTRON_2_PLUS_S0_T1_0:  return "dineutron_S0_T1_2+_0";
    case DINEUTRON_2_PLUS_S0_T1_1:  return "dineutron_S0_T1_2+_1";
    case DINEUTRON_2_PLUS_S0_T1_2:  return "dineutron_S0_T1_2+_2";
    case DINEUTRON_2_PLUS_S0_T1_3:  return "dineutron_S0_T1_2+_3";
    case DINEUTRON_2_PLUS_S0_T1_4:  return "dineutron_S0_T1_2+_4";
    case DINEUTRON_2_PLUS_S0_T1_5:  return "dineutron_S0_T1_2+_5";
    case DINEUTRON_2_PLUS_S0_T1_6:  return "dineutron_S0_T1_2+_6";
    case DINEUTRON_2_PLUS_S0_T1_7:  return "dineutron_S0_T1_2+_7";
    case DINEUTRON_2_PLUS_S0_T1_8:  return "dineutron_S0_T1_2+_8";
    case DINEUTRON_2_PLUS_S0_T1_9:  return "dineutron_S0_T1_2+_9";
    case DINEUTRON_2_PLUS_S0_T1_10: return "dineutron_S0_T1_2+_10";
    case DINEUTRON_2_PLUS_S0_T1_11: return "dineutron_S0_T1_2+_11";
    case DINEUTRON_2_PLUS_S0_T1_12: return "dineutron_S0_T1_2+_12";
    case DINEUTRON_2_PLUS_S0_T1_13: return "dineutron_S0_T1_2+_13";
    case DINEUTRON_2_PLUS_S0_T1_14: return "dineutron_S0_T1_2+_14";
    case DINEUTRON_2_PLUS_S0_T1_15: return "dineutron_S0_T1_2+_15";
    case DINEUTRON_2_PLUS_S0_T1_16: return "dineutron_S0_T1_2+_16";
    case DINEUTRON_2_PLUS_S0_T1_17: return "dineutron_S0_T1_2+_17";
    case DINEUTRON_2_PLUS_S0_T1_18: return "dineutron_S0_T1_2+_18";
    case DINEUTRON_2_PLUS_S0_T1_19: return "dineutron_S0_T1_2+_19";
    case DINEUTRON_2_PLUS_S0_T1_20: return "dineutron_S0_T1_2+_20";
    case DINEUTRON_2_PLUS_S0_T1_21: return "dineutron_S0_T1_2+_21";
    case DINEUTRON_2_PLUS_S0_T1_22: return "dineutron_S0_T1_2+_22";
    case DINEUTRON_2_PLUS_S0_T1_23: return "dineutron_S0_T1_2+_23";
    case DINEUTRON_2_PLUS_S0_T1_24: return "dineutron_S0_T1_2+_24";
    case DINEUTRON_2_PLUS_S0_T1_25: return "dineutron_S0_T1_2+_25";
    case DINEUTRON_2_PLUS_S0_T1_26: return "dineutron_S0_T1_2+_26";
    case DINEUTRON_2_PLUS_S0_T1_27: return "dineutron_S0_T1_2+_27";
    case DINEUTRON_2_PLUS_S0_T1_28: return "dineutron_S0_T1_2+_28";
    case DINEUTRON_2_PLUS_S0_T1_29: return "dineutron_S0_T1_2+_29";
    case DINEUTRON_2_PLUS_S0_T1_30: return "dineutron_S0_T1_2+_30";
    case DINEUTRON_2_PLUS_S0_T1_31: return "dineutron_S0_T1_2+_31";
    case DINEUTRON_2_PLUS_S0_T1_32: return "dineutron_S0_T1_2+_32";
    case DINEUTRON_2_PLUS_S0_T1_33: return "dineutron_S0_T1_2+_33";
    case DINEUTRON_2_PLUS_S0_T1_34: return "dineutron_S0_T1_2+_34";
    case DINEUTRON_2_PLUS_S0_T1_35: return "dineutron_S0_T1_2+_35";
    case DINEUTRON_2_PLUS_S0_T1_36: return "dineutron_S0_T1_2+_36";
    case DINEUTRON_2_PLUS_S0_T1_37: return "dineutron_S0_T1_2+_37";
    case DINEUTRON_2_PLUS_S0_T1_38: return "dineutron_S0_T1_2+_38";
    case DINEUTRON_2_PLUS_S0_T1_39: return "dineutron_S0_T1_2+_39";
    case DINEUTRON_2_PLUS_S0_T1_40: return "dineutron_S0_T1_2+_40";
    case DINEUTRON_2_PLUS_S0_T1_41: return "dineutron_S0_T1_2+_41";
    case DINEUTRON_2_PLUS_S0_T1_42: return "dineutron_S0_T1_2+_42";
    case DINEUTRON_2_PLUS_S0_T1_43: return "dineutron_S0_T1_2+_43";
    case DINEUTRON_2_PLUS_S0_T1_44: return "dineutron_S0_T1_2+_44";
    case DINEUTRON_2_PLUS_S0_T1_45: return "dineutron_S0_T1_2+_45";
    case DINEUTRON_2_PLUS_S0_T1_46: return "dineutron_S0_T1_2+_46";
    case DINEUTRON_2_PLUS_S0_T1_47: return "dineutron_S0_T1_2+_47";
    case DINEUTRON_2_PLUS_S0_T1_48: return "dineutron_S0_T1_2+_48";
    case DINEUTRON_2_PLUS_S0_T1_49: return "dineutron_S0_T1_2+_49";
    case DINEUTRON_2_PLUS_S0_T1_50: return "dineutron_S0_T1_2+_50";
    case DINEUTRON_2_PLUS_S0_T1_51: return "dineutron_S0_T1_2+_51";
    case DINEUTRON_2_PLUS_S0_T1_52: return "dineutron_S0_T1_2+_52";
    case DINEUTRON_2_PLUS_S0_T1_53: return "dineutron_S0_T1_2+_53";
    case DINEUTRON_2_PLUS_S0_T1_54: return "dineutron_S0_T1_2+_54";
    case DINEUTRON_2_PLUS_S0_T1_55: return "dineutron_S0_T1_2+_55";
    case DINEUTRON_2_PLUS_S0_T1_56: return "dineutron_S0_T1_2+_56";
    case DINEUTRON_2_PLUS_S0_T1_57: return "dineutron_S0_T1_2+_57";
    case DINEUTRON_2_PLUS_S0_T1_58: return "dineutron_S0_T1_2+_58";
    case DINEUTRON_2_PLUS_S0_T1_59: return "dineutron_S0_T1_2+_59";
    case DINEUTRON_2_PLUS_S0_T1_60: return "dineutron_S0_T1_2+_60";
    case DINEUTRON_2_PLUS_S0_T1_61: return "dineutron_S0_T1_2+_61";
    case DINEUTRON_2_PLUS_S0_T1_62: return "dineutron_S0_T1_2+_62";
    case DINEUTRON_2_PLUS_S0_T1_63: return "dineutron_S0_T1_2+_63";
    case DINEUTRON_2_PLUS_S0_T1_64: return "dineutron_S0_T1_2+_64";
    case DINEUTRON_2_PLUS_S0_T1_65: return "dineutron_S0_T1_2+_65";
    case DINEUTRON_2_PLUS_S0_T1_66: return "dineutron_S0_T1_2+_66";
    case DINEUTRON_2_PLUS_S0_T1_67: return "dineutron_S0_T1_2+_67";
    case DINEUTRON_2_PLUS_S0_T1_68: return "dineutron_S0_T1_2+_68";
    case DINEUTRON_2_PLUS_S0_T1_69: return "dineutron_S0_T1_2+_69";
    case DINEUTRON_2_PLUS_S0_T1_70: return "dineutron_S0_T1_2+_70";
    case DINEUTRON_2_PLUS_S0_T1_71: return "dineutron_S0_T1_2+_71";
    case DINEUTRON_2_PLUS_S0_T1_72: return "dineutron_S0_T1_2+_72";
    case DINEUTRON_2_PLUS_S0_T1_73: return "dineutron_S0_T1_2+_73";
    case DINEUTRON_2_PLUS_S0_T1_74: return "dineutron_S0_T1_2+_74";
    case DINEUTRON_2_PLUS_S0_T1_75: return "dineutron_S0_T1_2+_75";
    case DINEUTRON_2_PLUS_S0_T1_76: return "dineutron_S0_T1_2+_76";
    case DINEUTRON_2_PLUS_S0_T1_77: return "dineutron_S0_T1_2+_77";
    case DINEUTRON_2_PLUS_S0_T1_78: return "dineutron_S0_T1_2+_78";
    case DINEUTRON_2_PLUS_S0_T1_79: return "dineutron_S0_T1_2+_79";
    case DINEUTRON_2_PLUS_S0_T1_80: return "dineutron_S0_T1_2+_80";
    case DINEUTRON_2_PLUS_S0_T1_81: return "dineutron_S0_T1_2+_81";
    case DINEUTRON_2_PLUS_S0_T1_82: return "dineutron_S0_T1_2+_82";
    case DINEUTRON_2_PLUS_S0_T1_83: return "dineutron_S0_T1_2+_83";
    case DINEUTRON_2_PLUS_S0_T1_84: return "dineutron_S0_T1_2+_84";
    case DINEUTRON_2_PLUS_S0_T1_85: return "dineutron_S0_T1_2+_85";
    case DINEUTRON_2_PLUS_S0_T1_86: return "dineutron_S0_T1_2+_86";
    case DINEUTRON_2_PLUS_S0_T1_87: return "dineutron_S0_T1_2+_87";
    case DINEUTRON_2_PLUS_S0_T1_88: return "dineutron_S0_T1_2+_88";
    case DINEUTRON_2_PLUS_S0_T1_89: return "dineutron_S0_T1_2+_89";
    case DINEUTRON_2_PLUS_S0_T1_90: return "dineutron_S0_T1_2+_90";
    case DINEUTRON_2_PLUS_S0_T1_91: return "dineutron_S0_T1_2+_91";
    case DINEUTRON_2_PLUS_S0_T1_92: return "dineutron_S0_T1_2+_92";
    case DINEUTRON_2_PLUS_S0_T1_93: return "dineutron_S0_T1_2+_93";
    case DINEUTRON_2_PLUS_S0_T1_94: return "dineutron_S0_T1_2+_94";
    case DINEUTRON_2_PLUS_S0_T1_95: return "dineutron_S0_T1_2+_95";
    case DINEUTRON_2_PLUS_S0_T1_96: return "dineutron_S0_T1_2+_96";
    case DINEUTRON_2_PLUS_S0_T1_97: return "dineutron_S0_T1_2+_97";
    case DINEUTRON_2_PLUS_S0_T1_98: return "dineutron_S0_T1_2+_98";
    case DINEUTRON_2_PLUS_S0_T1_99: return "dineutron_S0_T1_2+_99";

    case DINEUTRON_4_PLUS_S0_T1:    return "dineutron_S0_T1_4+";
    case DINEUTRON_4_PLUS_S0_T1_0:  return "dineutron_S0_T1_4+_0";
    case DINEUTRON_4_PLUS_S0_T1_1:  return "dineutron_S0_T1_4+_1";
    case DINEUTRON_4_PLUS_S0_T1_2:  return "dineutron_S0_T1_4+_2";
    case DINEUTRON_4_PLUS_S0_T1_3:  return "dineutron_S0_T1_4+_3";
    case DINEUTRON_4_PLUS_S0_T1_4:  return "dineutron_S0_T1_4+_4";
    case DINEUTRON_4_PLUS_S0_T1_5:  return "dineutron_S0_T1_4+_5";
    case DINEUTRON_4_PLUS_S0_T1_6:  return "dineutron_S0_T1_4+_6";
    case DINEUTRON_4_PLUS_S0_T1_7:  return "dineutron_S0_T1_4+_7";
    case DINEUTRON_4_PLUS_S0_T1_8:  return "dineutron_S0_T1_4+_8";
    case DINEUTRON_4_PLUS_S0_T1_9:  return "dineutron_S0_T1_4+_9";
    case DINEUTRON_4_PLUS_S0_T1_10: return "dineutron_S0_T1_4+_10";
    case DINEUTRON_4_PLUS_S0_T1_11: return "dineutron_S0_T1_4+_11";
    case DINEUTRON_4_PLUS_S0_T1_12: return "dineutron_S0_T1_4+_12";
    case DINEUTRON_4_PLUS_S0_T1_13: return "dineutron_S0_T1_4+_13";
    case DINEUTRON_4_PLUS_S0_T1_14: return "dineutron_S0_T1_4+_14";
    case DINEUTRON_4_PLUS_S0_T1_15: return "dineutron_S0_T1_4+_15";
    case DINEUTRON_4_PLUS_S0_T1_16: return "dineutron_S0_T1_4+_16";
    case DINEUTRON_4_PLUS_S0_T1_17: return "dineutron_S0_T1_4+_17";
    case DINEUTRON_4_PLUS_S0_T1_18: return "dineutron_S0_T1_4+_18";
    case DINEUTRON_4_PLUS_S0_T1_19: return "dineutron_S0_T1_4+_19";
    case DINEUTRON_4_PLUS_S0_T1_20: return "dineutron_S0_T1_4+_20";
    case DINEUTRON_4_PLUS_S0_T1_21: return "dineutron_S0_T1_4+_21";
    case DINEUTRON_4_PLUS_S0_T1_22: return "dineutron_S0_T1_4+_22";
    case DINEUTRON_4_PLUS_S0_T1_23: return "dineutron_S0_T1_4+_23";
    case DINEUTRON_4_PLUS_S0_T1_24: return "dineutron_S0_T1_4+_24";
    case DINEUTRON_4_PLUS_S0_T1_25: return "dineutron_S0_T1_4+_25";
    case DINEUTRON_4_PLUS_S0_T1_26: return "dineutron_S0_T1_4+_26";
    case DINEUTRON_4_PLUS_S0_T1_27: return "dineutron_S0_T1_4+_27";
    case DINEUTRON_4_PLUS_S0_T1_28: return "dineutron_S0_T1_4+_28";
    case DINEUTRON_4_PLUS_S0_T1_29: return "dineutron_S0_T1_4+_29";
    case DINEUTRON_4_PLUS_S0_T1_30: return "dineutron_S0_T1_4+_30";
    case DINEUTRON_4_PLUS_S0_T1_31: return "dineutron_S0_T1_4+_31";
    case DINEUTRON_4_PLUS_S0_T1_32: return "dineutron_S0_T1_4+_32";
    case DINEUTRON_4_PLUS_S0_T1_33: return "dineutron_S0_T1_4+_33";
    case DINEUTRON_4_PLUS_S0_T1_34: return "dineutron_S0_T1_4+_34";
    case DINEUTRON_4_PLUS_S0_T1_35: return "dineutron_S0_T1_4+_35";
    case DINEUTRON_4_PLUS_S0_T1_36: return "dineutron_S0_T1_4+_36";
    case DINEUTRON_4_PLUS_S0_T1_37: return "dineutron_S0_T1_4+_37";
    case DINEUTRON_4_PLUS_S0_T1_38: return "dineutron_S0_T1_4+_38";
    case DINEUTRON_4_PLUS_S0_T1_39: return "dineutron_S0_T1_4+_39";
    case DINEUTRON_4_PLUS_S0_T1_40: return "dineutron_S0_T1_4+_40";
    case DINEUTRON_4_PLUS_S0_T1_41: return "dineutron_S0_T1_4+_41";
    case DINEUTRON_4_PLUS_S0_T1_42: return "dineutron_S0_T1_4+_42";
    case DINEUTRON_4_PLUS_S0_T1_43: return "dineutron_S0_T1_4+_43";
    case DINEUTRON_4_PLUS_S0_T1_44: return "dineutron_S0_T1_4+_44";
    case DINEUTRON_4_PLUS_S0_T1_45: return "dineutron_S0_T1_4+_45";
    case DINEUTRON_4_PLUS_S0_T1_46: return "dineutron_S0_T1_4+_46";
    case DINEUTRON_4_PLUS_S0_T1_47: return "dineutron_S0_T1_4+_47";
    case DINEUTRON_4_PLUS_S0_T1_48: return "dineutron_S0_T1_4+_48";
    case DINEUTRON_4_PLUS_S0_T1_49: return "dineutron_S0_T1_4+_49";
    case DINEUTRON_4_PLUS_S0_T1_50: return "dineutron_S0_T1_4+_50";
    case DINEUTRON_4_PLUS_S0_T1_51: return "dineutron_S0_T1_4+_51";
    case DINEUTRON_4_PLUS_S0_T1_52: return "dineutron_S0_T1_4+_52";
    case DINEUTRON_4_PLUS_S0_T1_53: return "dineutron_S0_T1_4+_53";
    case DINEUTRON_4_PLUS_S0_T1_54: return "dineutron_S0_T1_4+_54";
    case DINEUTRON_4_PLUS_S0_T1_55: return "dineutron_S0_T1_4+_55";
    case DINEUTRON_4_PLUS_S0_T1_56: return "dineutron_S0_T1_4+_56";
    case DINEUTRON_4_PLUS_S0_T1_57: return "dineutron_S0_T1_4+_57";
    case DINEUTRON_4_PLUS_S0_T1_58: return "dineutron_S0_T1_4+_58";
    case DINEUTRON_4_PLUS_S0_T1_59: return "dineutron_S0_T1_4+_59";
    case DINEUTRON_4_PLUS_S0_T1_60: return "dineutron_S0_T1_4+_60";
    case DINEUTRON_4_PLUS_S0_T1_61: return "dineutron_S0_T1_4+_61";
    case DINEUTRON_4_PLUS_S0_T1_62: return "dineutron_S0_T1_4+_62";
    case DINEUTRON_4_PLUS_S0_T1_63: return "dineutron_S0_T1_4+_63";
    case DINEUTRON_4_PLUS_S0_T1_64: return "dineutron_S0_T1_4+_64";
    case DINEUTRON_4_PLUS_S0_T1_65: return "dineutron_S0_T1_4+_65";
    case DINEUTRON_4_PLUS_S0_T1_66: return "dineutron_S0_T1_4+_66";
    case DINEUTRON_4_PLUS_S0_T1_67: return "dineutron_S0_T1_4+_67";
    case DINEUTRON_4_PLUS_S0_T1_68: return "dineutron_S0_T1_4+_68";
    case DINEUTRON_4_PLUS_S0_T1_69: return "dineutron_S0_T1_4+_69";
    case DINEUTRON_4_PLUS_S0_T1_70: return "dineutron_S0_T1_4+_70";
    case DINEUTRON_4_PLUS_S0_T1_71: return "dineutron_S0_T1_4+_71";
    case DINEUTRON_4_PLUS_S0_T1_72: return "dineutron_S0_T1_4+_72";
    case DINEUTRON_4_PLUS_S0_T1_73: return "dineutron_S0_T1_4+_73";
    case DINEUTRON_4_PLUS_S0_T1_74: return "dineutron_S0_T1_4+_74";
    case DINEUTRON_4_PLUS_S0_T1_75: return "dineutron_S0_T1_4+_75";
    case DINEUTRON_4_PLUS_S0_T1_76: return "dineutron_S0_T1_4+_76";
    case DINEUTRON_4_PLUS_S0_T1_77: return "dineutron_S0_T1_4+_77";
    case DINEUTRON_4_PLUS_S0_T1_78: return "dineutron_S0_T1_4+_78";
    case DINEUTRON_4_PLUS_S0_T1_79: return "dineutron_S0_T1_4+_79";
    case DINEUTRON_4_PLUS_S0_T1_80: return "dineutron_S0_T1_4+_80";
    case DINEUTRON_4_PLUS_S0_T1_81: return "dineutron_S0_T1_4+_81";
    case DINEUTRON_4_PLUS_S0_T1_82: return "dineutron_S0_T1_4+_82";
    case DINEUTRON_4_PLUS_S0_T1_83: return "dineutron_S0_T1_4+_83";
    case DINEUTRON_4_PLUS_S0_T1_84: return "dineutron_S0_T1_4+_84";
    case DINEUTRON_4_PLUS_S0_T1_85: return "dineutron_S0_T1_4+_85";
    case DINEUTRON_4_PLUS_S0_T1_86: return "dineutron_S0_T1_4+_86";
    case DINEUTRON_4_PLUS_S0_T1_87: return "dineutron_S0_T1_4+_87";
    case DINEUTRON_4_PLUS_S0_T1_88: return "dineutron_S0_T1_4+_88";
    case DINEUTRON_4_PLUS_S0_T1_89: return "dineutron_S0_T1_4+_89";
    case DINEUTRON_4_PLUS_S0_T1_90: return "dineutron_S0_T1_4+_90";
    case DINEUTRON_4_PLUS_S0_T1_91: return "dineutron_S0_T1_4+_91";
    case DINEUTRON_4_PLUS_S0_T1_92: return "dineutron_S0_T1_4+_92";
    case DINEUTRON_4_PLUS_S0_T1_93: return "dineutron_S0_T1_4+_93";
    case DINEUTRON_4_PLUS_S0_T1_94: return "dineutron_S0_T1_4+_94";
    case DINEUTRON_4_PLUS_S0_T1_95: return "dineutron_S0_T1_4+_95";
    case DINEUTRON_4_PLUS_S0_T1_96: return "dineutron_S0_T1_4+_96";
    case DINEUTRON_4_PLUS_S0_T1_97: return "dineutron_S0_T1_4+_97";
    case DINEUTRON_4_PLUS_S0_T1_98: return "dineutron_S0_T1_4+_98";
    case DINEUTRON_4_PLUS_S0_T1_99: return "dineutron_S0_T1_4+_99";

    case DINEUTRON_0_MINUS_S1_T1:    return "dineutron_S1_T1_0-";
    case DINEUTRON_0_MINUS_S1_T1_0:  return "dineutron_S1_T1_0-_0";
    case DINEUTRON_0_MINUS_S1_T1_1:  return "dineutron_S1_T1_0-_1";
    case DINEUTRON_0_MINUS_S1_T1_2:  return "dineutron_S1_T1_0-_2";
    case DINEUTRON_0_MINUS_S1_T1_3:  return "dineutron_S1_T1_0-_3";
    case DINEUTRON_0_MINUS_S1_T1_4:  return "dineutron_S1_T1_0-_4";
    case DINEUTRON_0_MINUS_S1_T1_5:  return "dineutron_S1_T1_0-_5";
    case DINEUTRON_0_MINUS_S1_T1_6:  return "dineutron_S1_T1_0-_6";
    case DINEUTRON_0_MINUS_S1_T1_7:  return "dineutron_S1_T1_0-_7";
    case DINEUTRON_0_MINUS_S1_T1_8:  return "dineutron_S1_T1_0-_8";
    case DINEUTRON_0_MINUS_S1_T1_9:  return "dineutron_S1_T1_0-_9";
    case DINEUTRON_0_MINUS_S1_T1_10: return "dineutron_S1_T1_0-_10";
    case DINEUTRON_0_MINUS_S1_T1_11: return "dineutron_S1_T1_0-_11";
    case DINEUTRON_0_MINUS_S1_T1_12: return "dineutron_S1_T1_0-_12";
    case DINEUTRON_0_MINUS_S1_T1_13: return "dineutron_S1_T1_0-_13";
    case DINEUTRON_0_MINUS_S1_T1_14: return "dineutron_S1_T1_0-_14";
    case DINEUTRON_0_MINUS_S1_T1_15: return "dineutron_S1_T1_0-_15";
    case DINEUTRON_0_MINUS_S1_T1_16: return "dineutron_S1_T1_0-_16";
    case DINEUTRON_0_MINUS_S1_T1_17: return "dineutron_S1_T1_0-_17";
    case DINEUTRON_0_MINUS_S1_T1_18: return "dineutron_S1_T1_0-_18";
    case DINEUTRON_0_MINUS_S1_T1_19: return "dineutron_S1_T1_0-_19";
    case DINEUTRON_0_MINUS_S1_T1_20: return "dineutron_S1_T1_0-_20";
    case DINEUTRON_0_MINUS_S1_T1_21: return "dineutron_S1_T1_0-_21";
    case DINEUTRON_0_MINUS_S1_T1_22: return "dineutron_S1_T1_0-_22";
    case DINEUTRON_0_MINUS_S1_T1_23: return "dineutron_S1_T1_0-_23";
    case DINEUTRON_0_MINUS_S1_T1_24: return "dineutron_S1_T1_0-_24";
    case DINEUTRON_0_MINUS_S1_T1_25: return "dineutron_S1_T1_0-_25";
    case DINEUTRON_0_MINUS_S1_T1_26: return "dineutron_S1_T1_0-_26";
    case DINEUTRON_0_MINUS_S1_T1_27: return "dineutron_S1_T1_0-_27";
    case DINEUTRON_0_MINUS_S1_T1_28: return "dineutron_S1_T1_0-_28";
    case DINEUTRON_0_MINUS_S1_T1_29: return "dineutron_S1_T1_0-_29";
    case DINEUTRON_0_MINUS_S1_T1_30: return "dineutron_S1_T1_0-_30";
    case DINEUTRON_0_MINUS_S1_T1_31: return "dineutron_S1_T1_0-_31";
    case DINEUTRON_0_MINUS_S1_T1_32: return "dineutron_S1_T1_0-_32";
    case DINEUTRON_0_MINUS_S1_T1_33: return "dineutron_S1_T1_0-_33";
    case DINEUTRON_0_MINUS_S1_T1_34: return "dineutron_S1_T1_0-_34";
    case DINEUTRON_0_MINUS_S1_T1_35: return "dineutron_S1_T1_0-_35";
    case DINEUTRON_0_MINUS_S1_T1_36: return "dineutron_S1_T1_0-_36";
    case DINEUTRON_0_MINUS_S1_T1_37: return "dineutron_S1_T1_0-_37";
    case DINEUTRON_0_MINUS_S1_T1_38: return "dineutron_S1_T1_0-_38";
    case DINEUTRON_0_MINUS_S1_T1_39: return "dineutron_S1_T1_0-_39";
    case DINEUTRON_0_MINUS_S1_T1_40: return "dineutron_S1_T1_0-_40";
    case DINEUTRON_0_MINUS_S1_T1_41: return "dineutron_S1_T1_0-_41";
    case DINEUTRON_0_MINUS_S1_T1_42: return "dineutron_S1_T1_0-_42";
    case DINEUTRON_0_MINUS_S1_T1_43: return "dineutron_S1_T1_0-_43";
    case DINEUTRON_0_MINUS_S1_T1_44: return "dineutron_S1_T1_0-_44";
    case DINEUTRON_0_MINUS_S1_T1_45: return "dineutron_S1_T1_0-_45";
    case DINEUTRON_0_MINUS_S1_T1_46: return "dineutron_S1_T1_0-_46";
    case DINEUTRON_0_MINUS_S1_T1_47: return "dineutron_S1_T1_0-_47";
    case DINEUTRON_0_MINUS_S1_T1_48: return "dineutron_S1_T1_0-_48";
    case DINEUTRON_0_MINUS_S1_T1_49: return "dineutron_S1_T1_0-_49";
    case DINEUTRON_0_MINUS_S1_T1_50: return "dineutron_S1_T1_0-_50";
    case DINEUTRON_0_MINUS_S1_T1_51: return "dineutron_S1_T1_0-_51";
    case DINEUTRON_0_MINUS_S1_T1_52: return "dineutron_S1_T1_0-_52";
    case DINEUTRON_0_MINUS_S1_T1_53: return "dineutron_S1_T1_0-_53";
    case DINEUTRON_0_MINUS_S1_T1_54: return "dineutron_S1_T1_0-_54";
    case DINEUTRON_0_MINUS_S1_T1_55: return "dineutron_S1_T1_0-_55";
    case DINEUTRON_0_MINUS_S1_T1_56: return "dineutron_S1_T1_0-_56";
    case DINEUTRON_0_MINUS_S1_T1_57: return "dineutron_S1_T1_0-_57";
    case DINEUTRON_0_MINUS_S1_T1_58: return "dineutron_S1_T1_0-_58";
    case DINEUTRON_0_MINUS_S1_T1_59: return "dineutron_S1_T1_0-_59";
    case DINEUTRON_0_MINUS_S1_T1_60: return "dineutron_S1_T1_0-_60";
    case DINEUTRON_0_MINUS_S1_T1_61: return "dineutron_S1_T1_0-_61";
    case DINEUTRON_0_MINUS_S1_T1_62: return "dineutron_S1_T1_0-_62";
    case DINEUTRON_0_MINUS_S1_T1_63: return "dineutron_S1_T1_0-_63";
    case DINEUTRON_0_MINUS_S1_T1_64: return "dineutron_S1_T1_0-_64";
    case DINEUTRON_0_MINUS_S1_T1_65: return "dineutron_S1_T1_0-_65";
    case DINEUTRON_0_MINUS_S1_T1_66: return "dineutron_S1_T1_0-_66";
    case DINEUTRON_0_MINUS_S1_T1_67: return "dineutron_S1_T1_0-_67";
    case DINEUTRON_0_MINUS_S1_T1_68: return "dineutron_S1_T1_0-_68";
    case DINEUTRON_0_MINUS_S1_T1_69: return "dineutron_S1_T1_0-_69";
    case DINEUTRON_0_MINUS_S1_T1_70: return "dineutron_S1_T1_0-_70";
    case DINEUTRON_0_MINUS_S1_T1_71: return "dineutron_S1_T1_0-_71";
    case DINEUTRON_0_MINUS_S1_T1_72: return "dineutron_S1_T1_0-_72";
    case DINEUTRON_0_MINUS_S1_T1_73: return "dineutron_S1_T1_0-_73";
    case DINEUTRON_0_MINUS_S1_T1_74: return "dineutron_S1_T1_0-_74";
    case DINEUTRON_0_MINUS_S1_T1_75: return "dineutron_S1_T1_0-_75";
    case DINEUTRON_0_MINUS_S1_T1_76: return "dineutron_S1_T1_0-_76";
    case DINEUTRON_0_MINUS_S1_T1_77: return "dineutron_S1_T1_0-_77";
    case DINEUTRON_0_MINUS_S1_T1_78: return "dineutron_S1_T1_0-_78";
    case DINEUTRON_0_MINUS_S1_T1_79: return "dineutron_S1_T1_0-_79";
    case DINEUTRON_0_MINUS_S1_T1_80: return "dineutron_S1_T1_0-_80";
    case DINEUTRON_0_MINUS_S1_T1_81: return "dineutron_S1_T1_0-_81";
    case DINEUTRON_0_MINUS_S1_T1_82: return "dineutron_S1_T1_0-_82";
    case DINEUTRON_0_MINUS_S1_T1_83: return "dineutron_S1_T1_0-_83";
    case DINEUTRON_0_MINUS_S1_T1_84: return "dineutron_S1_T1_0-_84";
    case DINEUTRON_0_MINUS_S1_T1_85: return "dineutron_S1_T1_0-_85";
    case DINEUTRON_0_MINUS_S1_T1_86: return "dineutron_S1_T1_0-_86";
    case DINEUTRON_0_MINUS_S1_T1_87: return "dineutron_S1_T1_0-_87";
    case DINEUTRON_0_MINUS_S1_T1_88: return "dineutron_S1_T1_0-_88";
    case DINEUTRON_0_MINUS_S1_T1_89: return "dineutron_S1_T1_0-_89";
    case DINEUTRON_0_MINUS_S1_T1_90: return "dineutron_S1_T1_0-_90";
    case DINEUTRON_0_MINUS_S1_T1_91: return "dineutron_S1_T1_0-_91";
    case DINEUTRON_0_MINUS_S1_T1_92: return "dineutron_S1_T1_0-_92";
    case DINEUTRON_0_MINUS_S1_T1_93: return "dineutron_S1_T1_0-_93";
    case DINEUTRON_0_MINUS_S1_T1_94: return "dineutron_S1_T1_0-_94";
    case DINEUTRON_0_MINUS_S1_T1_95: return "dineutron_S1_T1_0-_95";
    case DINEUTRON_0_MINUS_S1_T1_96: return "dineutron_S1_T1_0-_96";
    case DINEUTRON_0_MINUS_S1_T1_97: return "dineutron_S1_T1_0-_97";
    case DINEUTRON_0_MINUS_S1_T1_98: return "dineutron_S1_T1_0-_98";
    case DINEUTRON_0_MINUS_S1_T1_99: return "dineutron_S1_T1_0-_99";

    case DINEUTRON_1_MINUS_S1_T1:    return "dineutron_S1_T1_1-";
    case DINEUTRON_1_MINUS_S1_T1_0:  return "dineutron_S1_T1_1-_0";
    case DINEUTRON_1_MINUS_S1_T1_1:  return "dineutron_S1_T1_1-_1";
    case DINEUTRON_1_MINUS_S1_T1_2:  return "dineutron_S1_T1_1-_2";
    case DINEUTRON_1_MINUS_S1_T1_3:  return "dineutron_S1_T1_1-_3";
    case DINEUTRON_1_MINUS_S1_T1_4:  return "dineutron_S1_T1_1-_4";
    case DINEUTRON_1_MINUS_S1_T1_5:  return "dineutron_S1_T1_1-_5";
    case DINEUTRON_1_MINUS_S1_T1_6:  return "dineutron_S1_T1_1-_6";
    case DINEUTRON_1_MINUS_S1_T1_7:  return "dineutron_S1_T1_1-_7";
    case DINEUTRON_1_MINUS_S1_T1_8:  return "dineutron_S1_T1_1-_8";
    case DINEUTRON_1_MINUS_S1_T1_9:  return "dineutron_S1_T1_1-_9";
    case DINEUTRON_1_MINUS_S1_T1_10: return "dineutron_S1_T1_1-_10";
    case DINEUTRON_1_MINUS_S1_T1_11: return "dineutron_S1_T1_1-_11";
    case DINEUTRON_1_MINUS_S1_T1_12: return "dineutron_S1_T1_1-_12";
    case DINEUTRON_1_MINUS_S1_T1_13: return "dineutron_S1_T1_1-_13";
    case DINEUTRON_1_MINUS_S1_T1_14: return "dineutron_S1_T1_1-_14";
    case DINEUTRON_1_MINUS_S1_T1_15: return "dineutron_S1_T1_1-_15";
    case DINEUTRON_1_MINUS_S1_T1_16: return "dineutron_S1_T1_1-_16";
    case DINEUTRON_1_MINUS_S1_T1_17: return "dineutron_S1_T1_1-_17";
    case DINEUTRON_1_MINUS_S1_T1_18: return "dineutron_S1_T1_1-_18";
    case DINEUTRON_1_MINUS_S1_T1_19: return "dineutron_S1_T1_1-_19";
    case DINEUTRON_1_MINUS_S1_T1_20: return "dineutron_S1_T1_1-_20";
    case DINEUTRON_1_MINUS_S1_T1_21: return "dineutron_S1_T1_1-_21";
    case DINEUTRON_1_MINUS_S1_T1_22: return "dineutron_S1_T1_1-_22";
    case DINEUTRON_1_MINUS_S1_T1_23: return "dineutron_S1_T1_1-_23";
    case DINEUTRON_1_MINUS_S1_T1_24: return "dineutron_S1_T1_1-_24";
    case DINEUTRON_1_MINUS_S1_T1_25: return "dineutron_S1_T1_1-_25";
    case DINEUTRON_1_MINUS_S1_T1_26: return "dineutron_S1_T1_1-_26";
    case DINEUTRON_1_MINUS_S1_T1_27: return "dineutron_S1_T1_1-_27";
    case DINEUTRON_1_MINUS_S1_T1_28: return "dineutron_S1_T1_1-_28";
    case DINEUTRON_1_MINUS_S1_T1_29: return "dineutron_S1_T1_1-_29";
    case DINEUTRON_1_MINUS_S1_T1_30: return "dineutron_S1_T1_1-_30";
    case DINEUTRON_1_MINUS_S1_T1_31: return "dineutron_S1_T1_1-_31";
    case DINEUTRON_1_MINUS_S1_T1_32: return "dineutron_S1_T1_1-_32";
    case DINEUTRON_1_MINUS_S1_T1_33: return "dineutron_S1_T1_1-_33";
    case DINEUTRON_1_MINUS_S1_T1_34: return "dineutron_S1_T1_1-_34";
    case DINEUTRON_1_MINUS_S1_T1_35: return "dineutron_S1_T1_1-_35";
    case DINEUTRON_1_MINUS_S1_T1_36: return "dineutron_S1_T1_1-_36";
    case DINEUTRON_1_MINUS_S1_T1_37: return "dineutron_S1_T1_1-_37";
    case DINEUTRON_1_MINUS_S1_T1_38: return "dineutron_S1_T1_1-_38";
    case DINEUTRON_1_MINUS_S1_T1_39: return "dineutron_S1_T1_1-_39";
    case DINEUTRON_1_MINUS_S1_T1_40: return "dineutron_S1_T1_1-_40";
    case DINEUTRON_1_MINUS_S1_T1_41: return "dineutron_S1_T1_1-_41";
    case DINEUTRON_1_MINUS_S1_T1_42: return "dineutron_S1_T1_1-_42";
    case DINEUTRON_1_MINUS_S1_T1_43: return "dineutron_S1_T1_1-_43";
    case DINEUTRON_1_MINUS_S1_T1_44: return "dineutron_S1_T1_1-_44";
    case DINEUTRON_1_MINUS_S1_T1_45: return "dineutron_S1_T1_1-_45";
    case DINEUTRON_1_MINUS_S1_T1_46: return "dineutron_S1_T1_1-_46";
    case DINEUTRON_1_MINUS_S1_T1_47: return "dineutron_S1_T1_1-_47";
    case DINEUTRON_1_MINUS_S1_T1_48: return "dineutron_S1_T1_1-_48";
    case DINEUTRON_1_MINUS_S1_T1_49: return "dineutron_S1_T1_1-_49";
    case DINEUTRON_1_MINUS_S1_T1_50: return "dineutron_S1_T1_1-_50";
    case DINEUTRON_1_MINUS_S1_T1_51: return "dineutron_S1_T1_1-_51";
    case DINEUTRON_1_MINUS_S1_T1_52: return "dineutron_S1_T1_1-_52";
    case DINEUTRON_1_MINUS_S1_T1_53: return "dineutron_S1_T1_1-_53";
    case DINEUTRON_1_MINUS_S1_T1_54: return "dineutron_S1_T1_1-_54";
    case DINEUTRON_1_MINUS_S1_T1_55: return "dineutron_S1_T1_1-_55";
    case DINEUTRON_1_MINUS_S1_T1_56: return "dineutron_S1_T1_1-_56";
    case DINEUTRON_1_MINUS_S1_T1_57: return "dineutron_S1_T1_1-_57";
    case DINEUTRON_1_MINUS_S1_T1_58: return "dineutron_S1_T1_1-_58";
    case DINEUTRON_1_MINUS_S1_T1_59: return "dineutron_S1_T1_1-_59";
    case DINEUTRON_1_MINUS_S1_T1_60: return "dineutron_S1_T1_1-_60";
    case DINEUTRON_1_MINUS_S1_T1_61: return "dineutron_S1_T1_1-_61";
    case DINEUTRON_1_MINUS_S1_T1_62: return "dineutron_S1_T1_1-_62";
    case DINEUTRON_1_MINUS_S1_T1_63: return "dineutron_S1_T1_1-_63";
    case DINEUTRON_1_MINUS_S1_T1_64: return "dineutron_S1_T1_1-_64";
    case DINEUTRON_1_MINUS_S1_T1_65: return "dineutron_S1_T1_1-_65";
    case DINEUTRON_1_MINUS_S1_T1_66: return "dineutron_S1_T1_1-_66";
    case DINEUTRON_1_MINUS_S1_T1_67: return "dineutron_S1_T1_1-_67";
    case DINEUTRON_1_MINUS_S1_T1_68: return "dineutron_S1_T1_1-_68";
    case DINEUTRON_1_MINUS_S1_T1_69: return "dineutron_S1_T1_1-_69";
    case DINEUTRON_1_MINUS_S1_T1_70: return "dineutron_S1_T1_1-_70";
    case DINEUTRON_1_MINUS_S1_T1_71: return "dineutron_S1_T1_1-_71";
    case DINEUTRON_1_MINUS_S1_T1_72: return "dineutron_S1_T1_1-_72";
    case DINEUTRON_1_MINUS_S1_T1_73: return "dineutron_S1_T1_1-_73";
    case DINEUTRON_1_MINUS_S1_T1_74: return "dineutron_S1_T1_1-_74";
    case DINEUTRON_1_MINUS_S1_T1_75: return "dineutron_S1_T1_1-_75";
    case DINEUTRON_1_MINUS_S1_T1_76: return "dineutron_S1_T1_1-_76";
    case DINEUTRON_1_MINUS_S1_T1_77: return "dineutron_S1_T1_1-_77";
    case DINEUTRON_1_MINUS_S1_T1_78: return "dineutron_S1_T1_1-_78";
    case DINEUTRON_1_MINUS_S1_T1_79: return "dineutron_S1_T1_1-_79";
    case DINEUTRON_1_MINUS_S1_T1_80: return "dineutron_S1_T1_1-_80";
    case DINEUTRON_1_MINUS_S1_T1_81: return "dineutron_S1_T1_1-_81";
    case DINEUTRON_1_MINUS_S1_T1_82: return "dineutron_S1_T1_1-_82";
    case DINEUTRON_1_MINUS_S1_T1_83: return "dineutron_S1_T1_1-_83";
    case DINEUTRON_1_MINUS_S1_T1_84: return "dineutron_S1_T1_1-_84";
    case DINEUTRON_1_MINUS_S1_T1_85: return "dineutron_S1_T1_1-_85";
    case DINEUTRON_1_MINUS_S1_T1_86: return "dineutron_S1_T1_1-_86";
    case DINEUTRON_1_MINUS_S1_T1_87: return "dineutron_S1_T1_1-_87";
    case DINEUTRON_1_MINUS_S1_T1_88: return "dineutron_S1_T1_1-_88";
    case DINEUTRON_1_MINUS_S1_T1_89: return "dineutron_S1_T1_1-_89";
    case DINEUTRON_1_MINUS_S1_T1_90: return "dineutron_S1_T1_1-_90";
    case DINEUTRON_1_MINUS_S1_T1_91: return "dineutron_S1_T1_1-_91";
    case DINEUTRON_1_MINUS_S1_T1_92: return "dineutron_S1_T1_1-_92";
    case DINEUTRON_1_MINUS_S1_T1_93: return "dineutron_S1_T1_1-_93";
    case DINEUTRON_1_MINUS_S1_T1_94: return "dineutron_S1_T1_1-_94";
    case DINEUTRON_1_MINUS_S1_T1_95: return "dineutron_S1_T1_1-_95";
    case DINEUTRON_1_MINUS_S1_T1_96: return "dineutron_S1_T1_1-_96";
    case DINEUTRON_1_MINUS_S1_T1_97: return "dineutron_S1_T1_1-_97";
    case DINEUTRON_1_MINUS_S1_T1_98: return "dineutron_S1_T1_1-_98";
    case DINEUTRON_1_MINUS_S1_T1_99: return "dineutron_S1_T1_1-_99";

    case DINEUTRON_2_MINUS_S1_T1:    return "dineutron_S1_T1_2-";
    case DINEUTRON_2_MINUS_S1_T1_0:  return "dineutron_S1_T1_2-_0";
    case DINEUTRON_2_MINUS_S1_T1_1:  return "dineutron_S1_T1_2-_1";
    case DINEUTRON_2_MINUS_S1_T1_2:  return "dineutron_S1_T1_2-_2";
    case DINEUTRON_2_MINUS_S1_T1_3:  return "dineutron_S1_T1_2-_3";
    case DINEUTRON_2_MINUS_S1_T1_4:  return "dineutron_S1_T1_2-_4";
    case DINEUTRON_2_MINUS_S1_T1_5:  return "dineutron_S1_T1_2-_5";
    case DINEUTRON_2_MINUS_S1_T1_6:  return "dineutron_S1_T1_2-_6";
    case DINEUTRON_2_MINUS_S1_T1_7:  return "dineutron_S1_T1_2-_7";
    case DINEUTRON_2_MINUS_S1_T1_8:  return "dineutron_S1_T1_2-_8";
    case DINEUTRON_2_MINUS_S1_T1_9:  return "dineutron_S1_T1_2-_9";
    case DINEUTRON_2_MINUS_S1_T1_10: return "dineutron_S1_T1_2-_10";
    case DINEUTRON_2_MINUS_S1_T1_11: return "dineutron_S1_T1_2-_11";
    case DINEUTRON_2_MINUS_S1_T1_12: return "dineutron_S1_T1_2-_12";
    case DINEUTRON_2_MINUS_S1_T1_13: return "dineutron_S1_T1_2-_13";
    case DINEUTRON_2_MINUS_S1_T1_14: return "dineutron_S1_T1_2-_14";
    case DINEUTRON_2_MINUS_S1_T1_15: return "dineutron_S1_T1_2-_15";
    case DINEUTRON_2_MINUS_S1_T1_16: return "dineutron_S1_T1_2-_16";
    case DINEUTRON_2_MINUS_S1_T1_17: return "dineutron_S1_T1_2-_17";
    case DINEUTRON_2_MINUS_S1_T1_18: return "dineutron_S1_T1_2-_18";
    case DINEUTRON_2_MINUS_S1_T1_19: return "dineutron_S1_T1_2-_19";
    case DINEUTRON_2_MINUS_S1_T1_20: return "dineutron_S1_T1_2-_20";
    case DINEUTRON_2_MINUS_S1_T1_21: return "dineutron_S1_T1_2-_21";
    case DINEUTRON_2_MINUS_S1_T1_22: return "dineutron_S1_T1_2-_22";
    case DINEUTRON_2_MINUS_S1_T1_23: return "dineutron_S1_T1_2-_23";
    case DINEUTRON_2_MINUS_S1_T1_24: return "dineutron_S1_T1_2-_24";
    case DINEUTRON_2_MINUS_S1_T1_25: return "dineutron_S1_T1_2-_25";
    case DINEUTRON_2_MINUS_S1_T1_26: return "dineutron_S1_T1_2-_26";
    case DINEUTRON_2_MINUS_S1_T1_27: return "dineutron_S1_T1_2-_27";
    case DINEUTRON_2_MINUS_S1_T1_28: return "dineutron_S1_T1_2-_28";
    case DINEUTRON_2_MINUS_S1_T1_29: return "dineutron_S1_T1_2-_29";
    case DINEUTRON_2_MINUS_S1_T1_30: return "dineutron_S1_T1_2-_30";
    case DINEUTRON_2_MINUS_S1_T1_31: return "dineutron_S1_T1_2-_31";
    case DINEUTRON_2_MINUS_S1_T1_32: return "dineutron_S1_T1_2-_32";
    case DINEUTRON_2_MINUS_S1_T1_33: return "dineutron_S1_T1_2-_33";
    case DINEUTRON_2_MINUS_S1_T1_34: return "dineutron_S1_T1_2-_34";
    case DINEUTRON_2_MINUS_S1_T1_35: return "dineutron_S1_T1_2-_35";
    case DINEUTRON_2_MINUS_S1_T1_36: return "dineutron_S1_T1_2-_36";
    case DINEUTRON_2_MINUS_S1_T1_37: return "dineutron_S1_T1_2-_37";
    case DINEUTRON_2_MINUS_S1_T1_38: return "dineutron_S1_T1_2-_38";
    case DINEUTRON_2_MINUS_S1_T1_39: return "dineutron_S1_T1_2-_39";
    case DINEUTRON_2_MINUS_S1_T1_40: return "dineutron_S1_T1_2-_40";
    case DINEUTRON_2_MINUS_S1_T1_41: return "dineutron_S1_T1_2-_41";
    case DINEUTRON_2_MINUS_S1_T1_42: return "dineutron_S1_T1_2-_42";
    case DINEUTRON_2_MINUS_S1_T1_43: return "dineutron_S1_T1_2-_43";
    case DINEUTRON_2_MINUS_S1_T1_44: return "dineutron_S1_T1_2-_44";
    case DINEUTRON_2_MINUS_S1_T1_45: return "dineutron_S1_T1_2-_45";
    case DINEUTRON_2_MINUS_S1_T1_46: return "dineutron_S1_T1_2-_46";
    case DINEUTRON_2_MINUS_S1_T1_47: return "dineutron_S1_T1_2-_47";
    case DINEUTRON_2_MINUS_S1_T1_48: return "dineutron_S1_T1_2-_48";
    case DINEUTRON_2_MINUS_S1_T1_49: return "dineutron_S1_T1_2-_49";
    case DINEUTRON_2_MINUS_S1_T1_50: return "dineutron_S1_T1_2-_50";
    case DINEUTRON_2_MINUS_S1_T1_51: return "dineutron_S1_T1_2-_51";
    case DINEUTRON_2_MINUS_S1_T1_52: return "dineutron_S1_T1_2-_52";
    case DINEUTRON_2_MINUS_S1_T1_53: return "dineutron_S1_T1_2-_53";
    case DINEUTRON_2_MINUS_S1_T1_54: return "dineutron_S1_T1_2-_54";
    case DINEUTRON_2_MINUS_S1_T1_55: return "dineutron_S1_T1_2-_55";
    case DINEUTRON_2_MINUS_S1_T1_56: return "dineutron_S1_T1_2-_56";
    case DINEUTRON_2_MINUS_S1_T1_57: return "dineutron_S1_T1_2-_57";
    case DINEUTRON_2_MINUS_S1_T1_58: return "dineutron_S1_T1_2-_58";
    case DINEUTRON_2_MINUS_S1_T1_59: return "dineutron_S1_T1_2-_59";
    case DINEUTRON_2_MINUS_S1_T1_60: return "dineutron_S1_T1_2-_60";
    case DINEUTRON_2_MINUS_S1_T1_61: return "dineutron_S1_T1_2-_61";
    case DINEUTRON_2_MINUS_S1_T1_62: return "dineutron_S1_T1_2-_62";
    case DINEUTRON_2_MINUS_S1_T1_63: return "dineutron_S1_T1_2-_63";
    case DINEUTRON_2_MINUS_S1_T1_64: return "dineutron_S1_T1_2-_64";
    case DINEUTRON_2_MINUS_S1_T1_65: return "dineutron_S1_T1_2-_65";
    case DINEUTRON_2_MINUS_S1_T1_66: return "dineutron_S1_T1_2-_66";
    case DINEUTRON_2_MINUS_S1_T1_67: return "dineutron_S1_T1_2-_67";
    case DINEUTRON_2_MINUS_S1_T1_68: return "dineutron_S1_T1_2-_68";
    case DINEUTRON_2_MINUS_S1_T1_69: return "dineutron_S1_T1_2-_69";
    case DINEUTRON_2_MINUS_S1_T1_70: return "dineutron_S1_T1_2-_70";
    case DINEUTRON_2_MINUS_S1_T1_71: return "dineutron_S1_T1_2-_71";
    case DINEUTRON_2_MINUS_S1_T1_72: return "dineutron_S1_T1_2-_72";
    case DINEUTRON_2_MINUS_S1_T1_73: return "dineutron_S1_T1_2-_73";
    case DINEUTRON_2_MINUS_S1_T1_74: return "dineutron_S1_T1_2-_74";
    case DINEUTRON_2_MINUS_S1_T1_75: return "dineutron_S1_T1_2-_75";
    case DINEUTRON_2_MINUS_S1_T1_76: return "dineutron_S1_T1_2-_76";
    case DINEUTRON_2_MINUS_S1_T1_77: return "dineutron_S1_T1_2-_77";
    case DINEUTRON_2_MINUS_S1_T1_78: return "dineutron_S1_T1_2-_78";
    case DINEUTRON_2_MINUS_S1_T1_79: return "dineutron_S1_T1_2-_79";
    case DINEUTRON_2_MINUS_S1_T1_80: return "dineutron_S1_T1_2-_80";
    case DINEUTRON_2_MINUS_S1_T1_81: return "dineutron_S1_T1_2-_81";
    case DINEUTRON_2_MINUS_S1_T1_82: return "dineutron_S1_T1_2-_82";
    case DINEUTRON_2_MINUS_S1_T1_83: return "dineutron_S1_T1_2-_83";
    case DINEUTRON_2_MINUS_S1_T1_84: return "dineutron_S1_T1_2-_84";
    case DINEUTRON_2_MINUS_S1_T1_85: return "dineutron_S1_T1_2-_85";
    case DINEUTRON_2_MINUS_S1_T1_86: return "dineutron_S1_T1_2-_86";
    case DINEUTRON_2_MINUS_S1_T1_87: return "dineutron_S1_T1_2-_87";
    case DINEUTRON_2_MINUS_S1_T1_88: return "dineutron_S1_T1_2-_88";
    case DINEUTRON_2_MINUS_S1_T1_89: return "dineutron_S1_T1_2-_89";
    case DINEUTRON_2_MINUS_S1_T1_90: return "dineutron_S1_T1_2-_90";
    case DINEUTRON_2_MINUS_S1_T1_91: return "dineutron_S1_T1_2-_91";
    case DINEUTRON_2_MINUS_S1_T1_92: return "dineutron_S1_T1_2-_92";
    case DINEUTRON_2_MINUS_S1_T1_93: return "dineutron_S1_T1_2-_93";
    case DINEUTRON_2_MINUS_S1_T1_94: return "dineutron_S1_T1_2-_94";
    case DINEUTRON_2_MINUS_S1_T1_95: return "dineutron_S1_T1_2-_95";
    case DINEUTRON_2_MINUS_S1_T1_96: return "dineutron_S1_T1_2-_96";
    case DINEUTRON_2_MINUS_S1_T1_97: return "dineutron_S1_T1_2-_97";
    case DINEUTRON_2_MINUS_S1_T1_98: return "dineutron_S1_T1_2-_98";
    case DINEUTRON_2_MINUS_S1_T1_99: return "dineutron_S1_T1_2-_99";

    case DINEUTRON_3_MINUS_S1_T1:    return "dineutron_S1_T1_3-";
    case DINEUTRON_3_MINUS_S1_T1_0:  return "dineutron_S1_T1_3-_0";
    case DINEUTRON_3_MINUS_S1_T1_1:  return "dineutron_S1_T1_3-_1";
    case DINEUTRON_3_MINUS_S1_T1_2:  return "dineutron_S1_T1_3-_2";
    case DINEUTRON_3_MINUS_S1_T1_3:  return "dineutron_S1_T1_3-_3";
    case DINEUTRON_3_MINUS_S1_T1_4:  return "dineutron_S1_T1_3-_4";
    case DINEUTRON_3_MINUS_S1_T1_5:  return "dineutron_S1_T1_3-_5";
    case DINEUTRON_3_MINUS_S1_T1_6:  return "dineutron_S1_T1_3-_6";
    case DINEUTRON_3_MINUS_S1_T1_7:  return "dineutron_S1_T1_3-_7";
    case DINEUTRON_3_MINUS_S1_T1_8:  return "dineutron_S1_T1_3-_8";
    case DINEUTRON_3_MINUS_S1_T1_9:  return "dineutron_S1_T1_3-_9";
    case DINEUTRON_3_MINUS_S1_T1_10: return "dineutron_S1_T1_3-_10";
    case DINEUTRON_3_MINUS_S1_T1_11: return "dineutron_S1_T1_3-_11";
    case DINEUTRON_3_MINUS_S1_T1_12: return "dineutron_S1_T1_3-_12";
    case DINEUTRON_3_MINUS_S1_T1_13: return "dineutron_S1_T1_3-_13";
    case DINEUTRON_3_MINUS_S1_T1_14: return "dineutron_S1_T1_3-_14";
    case DINEUTRON_3_MINUS_S1_T1_15: return "dineutron_S1_T1_3-_15";
    case DINEUTRON_3_MINUS_S1_T1_16: return "dineutron_S1_T1_3-_16";
    case DINEUTRON_3_MINUS_S1_T1_17: return "dineutron_S1_T1_3-_17";
    case DINEUTRON_3_MINUS_S1_T1_18: return "dineutron_S1_T1_3-_18";
    case DINEUTRON_3_MINUS_S1_T1_19: return "dineutron_S1_T1_3-_19";
    case DINEUTRON_3_MINUS_S1_T1_20: return "dineutron_S1_T1_3-_20";
    case DINEUTRON_3_MINUS_S1_T1_21: return "dineutron_S1_T1_3-_21";
    case DINEUTRON_3_MINUS_S1_T1_22: return "dineutron_S1_T1_3-_22";
    case DINEUTRON_3_MINUS_S1_T1_23: return "dineutron_S1_T1_3-_23";
    case DINEUTRON_3_MINUS_S1_T1_24: return "dineutron_S1_T1_3-_24";
    case DINEUTRON_3_MINUS_S1_T1_25: return "dineutron_S1_T1_3-_25";
    case DINEUTRON_3_MINUS_S1_T1_26: return "dineutron_S1_T1_3-_26";
    case DINEUTRON_3_MINUS_S1_T1_27: return "dineutron_S1_T1_3-_27";
    case DINEUTRON_3_MINUS_S1_T1_28: return "dineutron_S1_T1_3-_28";
    case DINEUTRON_3_MINUS_S1_T1_29: return "dineutron_S1_T1_3-_29";
    case DINEUTRON_3_MINUS_S1_T1_30: return "dineutron_S1_T1_3-_30";
    case DINEUTRON_3_MINUS_S1_T1_31: return "dineutron_S1_T1_3-_31";
    case DINEUTRON_3_MINUS_S1_T1_32: return "dineutron_S1_T1_3-_32";
    case DINEUTRON_3_MINUS_S1_T1_33: return "dineutron_S1_T1_3-_33";
    case DINEUTRON_3_MINUS_S1_T1_34: return "dineutron_S1_T1_3-_34";
    case DINEUTRON_3_MINUS_S1_T1_35: return "dineutron_S1_T1_3-_35";
    case DINEUTRON_3_MINUS_S1_T1_36: return "dineutron_S1_T1_3-_36";
    case DINEUTRON_3_MINUS_S1_T1_37: return "dineutron_S1_T1_3-_37";
    case DINEUTRON_3_MINUS_S1_T1_38: return "dineutron_S1_T1_3-_38";
    case DINEUTRON_3_MINUS_S1_T1_39: return "dineutron_S1_T1_3-_39";
    case DINEUTRON_3_MINUS_S1_T1_40: return "dineutron_S1_T1_3-_40";
    case DINEUTRON_3_MINUS_S1_T1_41: return "dineutron_S1_T1_3-_41";
    case DINEUTRON_3_MINUS_S1_T1_42: return "dineutron_S1_T1_3-_42";
    case DINEUTRON_3_MINUS_S1_T1_43: return "dineutron_S1_T1_3-_43";
    case DINEUTRON_3_MINUS_S1_T1_44: return "dineutron_S1_T1_3-_44";
    case DINEUTRON_3_MINUS_S1_T1_45: return "dineutron_S1_T1_3-_45";
    case DINEUTRON_3_MINUS_S1_T1_46: return "dineutron_S1_T1_3-_46";
    case DINEUTRON_3_MINUS_S1_T1_47: return "dineutron_S1_T1_3-_47";
    case DINEUTRON_3_MINUS_S1_T1_48: return "dineutron_S1_T1_3-_48";
    case DINEUTRON_3_MINUS_S1_T1_49: return "dineutron_S1_T1_3-_49";
    case DINEUTRON_3_MINUS_S1_T1_50: return "dineutron_S1_T1_3-_50";
    case DINEUTRON_3_MINUS_S1_T1_51: return "dineutron_S1_T1_3-_51";
    case DINEUTRON_3_MINUS_S1_T1_52: return "dineutron_S1_T1_3-_52";
    case DINEUTRON_3_MINUS_S1_T1_53: return "dineutron_S1_T1_3-_53";
    case DINEUTRON_3_MINUS_S1_T1_54: return "dineutron_S1_T1_3-_54";
    case DINEUTRON_3_MINUS_S1_T1_55: return "dineutron_S1_T1_3-_55";
    case DINEUTRON_3_MINUS_S1_T1_56: return "dineutron_S1_T1_3-_56";
    case DINEUTRON_3_MINUS_S1_T1_57: return "dineutron_S1_T1_3-_57";
    case DINEUTRON_3_MINUS_S1_T1_58: return "dineutron_S1_T1_3-_58";
    case DINEUTRON_3_MINUS_S1_T1_59: return "dineutron_S1_T1_3-_59";
    case DINEUTRON_3_MINUS_S1_T1_60: return "dineutron_S1_T1_3-_60";
    case DINEUTRON_3_MINUS_S1_T1_61: return "dineutron_S1_T1_3-_61";
    case DINEUTRON_3_MINUS_S1_T1_62: return "dineutron_S1_T1_3-_62";
    case DINEUTRON_3_MINUS_S1_T1_63: return "dineutron_S1_T1_3-_63";
    case DINEUTRON_3_MINUS_S1_T1_64: return "dineutron_S1_T1_3-_64";
    case DINEUTRON_3_MINUS_S1_T1_65: return "dineutron_S1_T1_3-_65";
    case DINEUTRON_3_MINUS_S1_T1_66: return "dineutron_S1_T1_3-_66";
    case DINEUTRON_3_MINUS_S1_T1_67: return "dineutron_S1_T1_3-_67";
    case DINEUTRON_3_MINUS_S1_T1_68: return "dineutron_S1_T1_3-_68";
    case DINEUTRON_3_MINUS_S1_T1_69: return "dineutron_S1_T1_3-_69";
    case DINEUTRON_3_MINUS_S1_T1_70: return "dineutron_S1_T1_3-_70";
    case DINEUTRON_3_MINUS_S1_T1_71: return "dineutron_S1_T1_3-_71";
    case DINEUTRON_3_MINUS_S1_T1_72: return "dineutron_S1_T1_3-_72";
    case DINEUTRON_3_MINUS_S1_T1_73: return "dineutron_S1_T1_3-_73";
    case DINEUTRON_3_MINUS_S1_T1_74: return "dineutron_S1_T1_3-_74";
    case DINEUTRON_3_MINUS_S1_T1_75: return "dineutron_S1_T1_3-_75";
    case DINEUTRON_3_MINUS_S1_T1_76: return "dineutron_S1_T1_3-_76";
    case DINEUTRON_3_MINUS_S1_T1_77: return "dineutron_S1_T1_3-_77";
    case DINEUTRON_3_MINUS_S1_T1_78: return "dineutron_S1_T1_3-_78";
    case DINEUTRON_3_MINUS_S1_T1_79: return "dineutron_S1_T1_3-_79";
    case DINEUTRON_3_MINUS_S1_T1_80: return "dineutron_S1_T1_3-_80";
    case DINEUTRON_3_MINUS_S1_T1_81: return "dineutron_S1_T1_3-_81";
    case DINEUTRON_3_MINUS_S1_T1_82: return "dineutron_S1_T1_3-_82";
    case DINEUTRON_3_MINUS_S1_T1_83: return "dineutron_S1_T1_3-_83";
    case DINEUTRON_3_MINUS_S1_T1_84: return "dineutron_S1_T1_3-_84";
    case DINEUTRON_3_MINUS_S1_T1_85: return "dineutron_S1_T1_3-_85";
    case DINEUTRON_3_MINUS_S1_T1_86: return "dineutron_S1_T1_3-_86";
    case DINEUTRON_3_MINUS_S1_T1_87: return "dineutron_S1_T1_3-_87";
    case DINEUTRON_3_MINUS_S1_T1_88: return "dineutron_S1_T1_3-_88";
    case DINEUTRON_3_MINUS_S1_T1_89: return "dineutron_S1_T1_3-_89";
    case DINEUTRON_3_MINUS_S1_T1_90: return "dineutron_S1_T1_3-_90";
    case DINEUTRON_3_MINUS_S1_T1_91: return "dineutron_S1_T1_3-_91";
    case DINEUTRON_3_MINUS_S1_T1_92: return "dineutron_S1_T1_3-_92";
    case DINEUTRON_3_MINUS_S1_T1_93: return "dineutron_S1_T1_3-_93";
    case DINEUTRON_3_MINUS_S1_T1_94: return "dineutron_S1_T1_3-_94";
    case DINEUTRON_3_MINUS_S1_T1_95: return "dineutron_S1_T1_3-_95";
    case DINEUTRON_3_MINUS_S1_T1_96: return "dineutron_S1_T1_3-_96";
    case DINEUTRON_3_MINUS_S1_T1_97: return "dineutron_S1_T1_3-_97";
    case DINEUTRON_3_MINUS_S1_T1_98: return "dineutron_S1_T1_3-_98";
    case DINEUTRON_3_MINUS_S1_T1_99: return "dineutron_S1_T1_3-_99";

    case DINEUTRON_4_MINUS_S1_T1:    return "dineutron_S1_T1_4-";
    case DINEUTRON_4_MINUS_S1_T1_0:  return "dineutron_S1_T1_4-_0";
    case DINEUTRON_4_MINUS_S1_T1_1:  return "dineutron_S1_T1_4-_1";
    case DINEUTRON_4_MINUS_S1_T1_2:  return "dineutron_S1_T1_4-_2";
    case DINEUTRON_4_MINUS_S1_T1_3:  return "dineutron_S1_T1_4-_3";
    case DINEUTRON_4_MINUS_S1_T1_4:  return "dineutron_S1_T1_4-_4";
    case DINEUTRON_4_MINUS_S1_T1_5:  return "dineutron_S1_T1_4-_5";
    case DINEUTRON_4_MINUS_S1_T1_6:  return "dineutron_S1_T1_4-_6";
    case DINEUTRON_4_MINUS_S1_T1_7:  return "dineutron_S1_T1_4-_7";
    case DINEUTRON_4_MINUS_S1_T1_8:  return "dineutron_S1_T1_4-_8";
    case DINEUTRON_4_MINUS_S1_T1_9:  return "dineutron_S1_T1_4-_9";
    case DINEUTRON_4_MINUS_S1_T1_10: return "dineutron_S1_T1_4-_10";
    case DINEUTRON_4_MINUS_S1_T1_11: return "dineutron_S1_T1_4-_11";
    case DINEUTRON_4_MINUS_S1_T1_12: return "dineutron_S1_T1_4-_12";
    case DINEUTRON_4_MINUS_S1_T1_13: return "dineutron_S1_T1_4-_13";
    case DINEUTRON_4_MINUS_S1_T1_14: return "dineutron_S1_T1_4-_14";
    case DINEUTRON_4_MINUS_S1_T1_15: return "dineutron_S1_T1_4-_15";
    case DINEUTRON_4_MINUS_S1_T1_16: return "dineutron_S1_T1_4-_16";
    case DINEUTRON_4_MINUS_S1_T1_17: return "dineutron_S1_T1_4-_17";
    case DINEUTRON_4_MINUS_S1_T1_18: return "dineutron_S1_T1_4-_18";
    case DINEUTRON_4_MINUS_S1_T1_19: return "dineutron_S1_T1_4-_19";
    case DINEUTRON_4_MINUS_S1_T1_20: return "dineutron_S1_T1_4-_20";
    case DINEUTRON_4_MINUS_S1_T1_21: return "dineutron_S1_T1_4-_21";
    case DINEUTRON_4_MINUS_S1_T1_22: return "dineutron_S1_T1_4-_22";
    case DINEUTRON_4_MINUS_S1_T1_23: return "dineutron_S1_T1_4-_23";
    case DINEUTRON_4_MINUS_S1_T1_24: return "dineutron_S1_T1_4-_24";
    case DINEUTRON_4_MINUS_S1_T1_25: return "dineutron_S1_T1_4-_25";
    case DINEUTRON_4_MINUS_S1_T1_26: return "dineutron_S1_T1_4-_26";
    case DINEUTRON_4_MINUS_S1_T1_27: return "dineutron_S1_T1_4-_27";
    case DINEUTRON_4_MINUS_S1_T1_28: return "dineutron_S1_T1_4-_28";
    case DINEUTRON_4_MINUS_S1_T1_29: return "dineutron_S1_T1_4-_29";
    case DINEUTRON_4_MINUS_S1_T1_30: return "dineutron_S1_T1_4-_30";
    case DINEUTRON_4_MINUS_S1_T1_31: return "dineutron_S1_T1_4-_31";
    case DINEUTRON_4_MINUS_S1_T1_32: return "dineutron_S1_T1_4-_32";
    case DINEUTRON_4_MINUS_S1_T1_33: return "dineutron_S1_T1_4-_33";
    case DINEUTRON_4_MINUS_S1_T1_34: return "dineutron_S1_T1_4-_34";
    case DINEUTRON_4_MINUS_S1_T1_35: return "dineutron_S1_T1_4-_35";
    case DINEUTRON_4_MINUS_S1_T1_36: return "dineutron_S1_T1_4-_36";
    case DINEUTRON_4_MINUS_S1_T1_37: return "dineutron_S1_T1_4-_37";
    case DINEUTRON_4_MINUS_S1_T1_38: return "dineutron_S1_T1_4-_38";
    case DINEUTRON_4_MINUS_S1_T1_39: return "dineutron_S1_T1_4-_39";
    case DINEUTRON_4_MINUS_S1_T1_40: return "dineutron_S1_T1_4-_40";
    case DINEUTRON_4_MINUS_S1_T1_41: return "dineutron_S1_T1_4-_41";
    case DINEUTRON_4_MINUS_S1_T1_42: return "dineutron_S1_T1_4-_42";
    case DINEUTRON_4_MINUS_S1_T1_43: return "dineutron_S1_T1_4-_43";
    case DINEUTRON_4_MINUS_S1_T1_44: return "dineutron_S1_T1_4-_44";
    case DINEUTRON_4_MINUS_S1_T1_45: return "dineutron_S1_T1_4-_45";
    case DINEUTRON_4_MINUS_S1_T1_46: return "dineutron_S1_T1_4-_46";
    case DINEUTRON_4_MINUS_S1_T1_47: return "dineutron_S1_T1_4-_47";
    case DINEUTRON_4_MINUS_S1_T1_48: return "dineutron_S1_T1_4-_48";
    case DINEUTRON_4_MINUS_S1_T1_49: return "dineutron_S1_T1_4-_49";
    case DINEUTRON_4_MINUS_S1_T1_50: return "dineutron_S1_T1_4-_50";
    case DINEUTRON_4_MINUS_S1_T1_51: return "dineutron_S1_T1_4-_51";
    case DINEUTRON_4_MINUS_S1_T1_52: return "dineutron_S1_T1_4-_52";
    case DINEUTRON_4_MINUS_S1_T1_53: return "dineutron_S1_T1_4-_53";
    case DINEUTRON_4_MINUS_S1_T1_54: return "dineutron_S1_T1_4-_54";
    case DINEUTRON_4_MINUS_S1_T1_55: return "dineutron_S1_T1_4-_55";
    case DINEUTRON_4_MINUS_S1_T1_56: return "dineutron_S1_T1_4-_56";
    case DINEUTRON_4_MINUS_S1_T1_57: return "dineutron_S1_T1_4-_57";
    case DINEUTRON_4_MINUS_S1_T1_58: return "dineutron_S1_T1_4-_58";
    case DINEUTRON_4_MINUS_S1_T1_59: return "dineutron_S1_T1_4-_59";
    case DINEUTRON_4_MINUS_S1_T1_60: return "dineutron_S1_T1_4-_60";
    case DINEUTRON_4_MINUS_S1_T1_61: return "dineutron_S1_T1_4-_61";
    case DINEUTRON_4_MINUS_S1_T1_62: return "dineutron_S1_T1_4-_62";
    case DINEUTRON_4_MINUS_S1_T1_63: return "dineutron_S1_T1_4-_63";
    case DINEUTRON_4_MINUS_S1_T1_64: return "dineutron_S1_T1_4-_64";
    case DINEUTRON_4_MINUS_S1_T1_65: return "dineutron_S1_T1_4-_65";
    case DINEUTRON_4_MINUS_S1_T1_66: return "dineutron_S1_T1_4-_66";
    case DINEUTRON_4_MINUS_S1_T1_67: return "dineutron_S1_T1_4-_67";
    case DINEUTRON_4_MINUS_S1_T1_68: return "dineutron_S1_T1_4-_68";
    case DINEUTRON_4_MINUS_S1_T1_69: return "dineutron_S1_T1_4-_69";
    case DINEUTRON_4_MINUS_S1_T1_70: return "dineutron_S1_T1_4-_70";
    case DINEUTRON_4_MINUS_S1_T1_71: return "dineutron_S1_T1_4-_71";
    case DINEUTRON_4_MINUS_S1_T1_72: return "dineutron_S1_T1_4-_72";
    case DINEUTRON_4_MINUS_S1_T1_73: return "dineutron_S1_T1_4-_73";
    case DINEUTRON_4_MINUS_S1_T1_74: return "dineutron_S1_T1_4-_74";
    case DINEUTRON_4_MINUS_S1_T1_75: return "dineutron_S1_T1_4-_75";
    case DINEUTRON_4_MINUS_S1_T1_76: return "dineutron_S1_T1_4-_76";
    case DINEUTRON_4_MINUS_S1_T1_77: return "dineutron_S1_T1_4-_77";
    case DINEUTRON_4_MINUS_S1_T1_78: return "dineutron_S1_T1_4-_78";
    case DINEUTRON_4_MINUS_S1_T1_79: return "dineutron_S1_T1_4-_79";
    case DINEUTRON_4_MINUS_S1_T1_80: return "dineutron_S1_T1_4-_80";
    case DINEUTRON_4_MINUS_S1_T1_81: return "dineutron_S1_T1_4-_81";
    case DINEUTRON_4_MINUS_S1_T1_82: return "dineutron_S1_T1_4-_82";
    case DINEUTRON_4_MINUS_S1_T1_83: return "dineutron_S1_T1_4-_83";
    case DINEUTRON_4_MINUS_S1_T1_84: return "dineutron_S1_T1_4-_84";
    case DINEUTRON_4_MINUS_S1_T1_85: return "dineutron_S1_T1_4-_85";
    case DINEUTRON_4_MINUS_S1_T1_86: return "dineutron_S1_T1_4-_86";
    case DINEUTRON_4_MINUS_S1_T1_87: return "dineutron_S1_T1_4-_87";
    case DINEUTRON_4_MINUS_S1_T1_88: return "dineutron_S1_T1_4-_88";
    case DINEUTRON_4_MINUS_S1_T1_89: return "dineutron_S1_T1_4-_89";
    case DINEUTRON_4_MINUS_S1_T1_90: return "dineutron_S1_T1_4-_90";
    case DINEUTRON_4_MINUS_S1_T1_91: return "dineutron_S1_T1_4-_91";
    case DINEUTRON_4_MINUS_S1_T1_92: return "dineutron_S1_T1_4-_92";
    case DINEUTRON_4_MINUS_S1_T1_93: return "dineutron_S1_T1_4-_93";
    case DINEUTRON_4_MINUS_S1_T1_94: return "dineutron_S1_T1_4-_94";
    case DINEUTRON_4_MINUS_S1_T1_95: return "dineutron_S1_T1_4-_95";
    case DINEUTRON_4_MINUS_S1_T1_96: return "dineutron_S1_T1_4-_96";
    case DINEUTRON_4_MINUS_S1_T1_97: return "dineutron_S1_T1_4-_97";
    case DINEUTRON_4_MINUS_S1_T1_98: return "dineutron_S1_T1_4-_98";
    case DINEUTRON_4_MINUS_S1_T1_99: return "dineutron_S1_T1_4-_99";

    case DINEUTRON_5_MINUS_S1_T1:    return "dineutron_S1_T1_5-";
    case DINEUTRON_5_MINUS_S1_T1_0:  return "dineutron_S1_T1_5-_0";
    case DINEUTRON_5_MINUS_S1_T1_1:  return "dineutron_S1_T1_5-_1";
    case DINEUTRON_5_MINUS_S1_T1_2:  return "dineutron_S1_T1_5-_2";
    case DINEUTRON_5_MINUS_S1_T1_3:  return "dineutron_S1_T1_5-_3";
    case DINEUTRON_5_MINUS_S1_T1_4:  return "dineutron_S1_T1_5-_4";
    case DINEUTRON_5_MINUS_S1_T1_5:  return "dineutron_S1_T1_5-_5";
    case DINEUTRON_5_MINUS_S1_T1_6:  return "dineutron_S1_T1_5-_6";
    case DINEUTRON_5_MINUS_S1_T1_7:  return "dineutron_S1_T1_5-_7";
    case DINEUTRON_5_MINUS_S1_T1_8:  return "dineutron_S1_T1_5-_8";
    case DINEUTRON_5_MINUS_S1_T1_9:  return "dineutron_S1_T1_5-_9";
    case DINEUTRON_5_MINUS_S1_T1_10: return "dineutron_S1_T1_5-_10";
    case DINEUTRON_5_MINUS_S1_T1_11: return "dineutron_S1_T1_5-_11";
    case DINEUTRON_5_MINUS_S1_T1_12: return "dineutron_S1_T1_5-_12";
    case DINEUTRON_5_MINUS_S1_T1_13: return "dineutron_S1_T1_5-_13";
    case DINEUTRON_5_MINUS_S1_T1_14: return "dineutron_S1_T1_5-_14";
    case DINEUTRON_5_MINUS_S1_T1_15: return "dineutron_S1_T1_5-_15";
    case DINEUTRON_5_MINUS_S1_T1_16: return "dineutron_S1_T1_5-_16";
    case DINEUTRON_5_MINUS_S1_T1_17: return "dineutron_S1_T1_5-_17";
    case DINEUTRON_5_MINUS_S1_T1_18: return "dineutron_S1_T1_5-_18";
    case DINEUTRON_5_MINUS_S1_T1_19: return "dineutron_S1_T1_5-_19";
    case DINEUTRON_5_MINUS_S1_T1_20: return "dineutron_S1_T1_5-_20";
    case DINEUTRON_5_MINUS_S1_T1_21: return "dineutron_S1_T1_5-_21";
    case DINEUTRON_5_MINUS_S1_T1_22: return "dineutron_S1_T1_5-_22";
    case DINEUTRON_5_MINUS_S1_T1_23: return "dineutron_S1_T1_5-_23";
    case DINEUTRON_5_MINUS_S1_T1_24: return "dineutron_S1_T1_5-_24";
    case DINEUTRON_5_MINUS_S1_T1_25: return "dineutron_S1_T1_5-_25";
    case DINEUTRON_5_MINUS_S1_T1_26: return "dineutron_S1_T1_5-_26";
    case DINEUTRON_5_MINUS_S1_T1_27: return "dineutron_S1_T1_5-_27";
    case DINEUTRON_5_MINUS_S1_T1_28: return "dineutron_S1_T1_5-_28";
    case DINEUTRON_5_MINUS_S1_T1_29: return "dineutron_S1_T1_5-_29";
    case DINEUTRON_5_MINUS_S1_T1_30: return "dineutron_S1_T1_5-_30";
    case DINEUTRON_5_MINUS_S1_T1_31: return "dineutron_S1_T1_5-_31";
    case DINEUTRON_5_MINUS_S1_T1_32: return "dineutron_S1_T1_5-_32";
    case DINEUTRON_5_MINUS_S1_T1_33: return "dineutron_S1_T1_5-_33";
    case DINEUTRON_5_MINUS_S1_T1_34: return "dineutron_S1_T1_5-_34";
    case DINEUTRON_5_MINUS_S1_T1_35: return "dineutron_S1_T1_5-_35";
    case DINEUTRON_5_MINUS_S1_T1_36: return "dineutron_S1_T1_5-_36";
    case DINEUTRON_5_MINUS_S1_T1_37: return "dineutron_S1_T1_5-_37";
    case DINEUTRON_5_MINUS_S1_T1_38: return "dineutron_S1_T1_5-_38";
    case DINEUTRON_5_MINUS_S1_T1_39: return "dineutron_S1_T1_5-_39";
    case DINEUTRON_5_MINUS_S1_T1_40: return "dineutron_S1_T1_5-_40";
    case DINEUTRON_5_MINUS_S1_T1_41: return "dineutron_S1_T1_5-_41";
    case DINEUTRON_5_MINUS_S1_T1_42: return "dineutron_S1_T1_5-_42";
    case DINEUTRON_5_MINUS_S1_T1_43: return "dineutron_S1_T1_5-_43";
    case DINEUTRON_5_MINUS_S1_T1_44: return "dineutron_S1_T1_5-_44";
    case DINEUTRON_5_MINUS_S1_T1_45: return "dineutron_S1_T1_5-_45";
    case DINEUTRON_5_MINUS_S1_T1_46: return "dineutron_S1_T1_5-_46";
    case DINEUTRON_5_MINUS_S1_T1_47: return "dineutron_S1_T1_5-_47";
    case DINEUTRON_5_MINUS_S1_T1_48: return "dineutron_S1_T1_5-_48";
    case DINEUTRON_5_MINUS_S1_T1_49: return "dineutron_S1_T1_5-_49";
    case DINEUTRON_5_MINUS_S1_T1_50: return "dineutron_S1_T1_5-_50";
    case DINEUTRON_5_MINUS_S1_T1_51: return "dineutron_S1_T1_5-_51";
    case DINEUTRON_5_MINUS_S1_T1_52: return "dineutron_S1_T1_5-_52";
    case DINEUTRON_5_MINUS_S1_T1_53: return "dineutron_S1_T1_5-_53";
    case DINEUTRON_5_MINUS_S1_T1_54: return "dineutron_S1_T1_5-_54";
    case DINEUTRON_5_MINUS_S1_T1_55: return "dineutron_S1_T1_5-_55";
    case DINEUTRON_5_MINUS_S1_T1_56: return "dineutron_S1_T1_5-_56";
    case DINEUTRON_5_MINUS_S1_T1_57: return "dineutron_S1_T1_5-_57";
    case DINEUTRON_5_MINUS_S1_T1_58: return "dineutron_S1_T1_5-_58";
    case DINEUTRON_5_MINUS_S1_T1_59: return "dineutron_S1_T1_5-_59";
    case DINEUTRON_5_MINUS_S1_T1_60: return "dineutron_S1_T1_5-_60";
    case DINEUTRON_5_MINUS_S1_T1_61: return "dineutron_S1_T1_5-_61";
    case DINEUTRON_5_MINUS_S1_T1_62: return "dineutron_S1_T1_5-_62";
    case DINEUTRON_5_MINUS_S1_T1_63: return "dineutron_S1_T1_5-_63";
    case DINEUTRON_5_MINUS_S1_T1_64: return "dineutron_S1_T1_5-_64";
    case DINEUTRON_5_MINUS_S1_T1_65: return "dineutron_S1_T1_5-_65";
    case DINEUTRON_5_MINUS_S1_T1_66: return "dineutron_S1_T1_5-_66";
    case DINEUTRON_5_MINUS_S1_T1_67: return "dineutron_S1_T1_5-_67";
    case DINEUTRON_5_MINUS_S1_T1_68: return "dineutron_S1_T1_5-_68";
    case DINEUTRON_5_MINUS_S1_T1_69: return "dineutron_S1_T1_5-_69";
    case DINEUTRON_5_MINUS_S1_T1_70: return "dineutron_S1_T1_5-_70";
    case DINEUTRON_5_MINUS_S1_T1_71: return "dineutron_S1_T1_5-_71";
    case DINEUTRON_5_MINUS_S1_T1_72: return "dineutron_S1_T1_5-_72";
    case DINEUTRON_5_MINUS_S1_T1_73: return "dineutron_S1_T1_5-_73";
    case DINEUTRON_5_MINUS_S1_T1_74: return "dineutron_S1_T1_5-_74";
    case DINEUTRON_5_MINUS_S1_T1_75: return "dineutron_S1_T1_5-_75";
    case DINEUTRON_5_MINUS_S1_T1_76: return "dineutron_S1_T1_5-_76";
    case DINEUTRON_5_MINUS_S1_T1_77: return "dineutron_S1_T1_5-_77";
    case DINEUTRON_5_MINUS_S1_T1_78: return "dineutron_S1_T1_5-_78";
    case DINEUTRON_5_MINUS_S1_T1_79: return "dineutron_S1_T1_5-_79";
    case DINEUTRON_5_MINUS_S1_T1_80: return "dineutron_S1_T1_5-_80";
    case DINEUTRON_5_MINUS_S1_T1_81: return "dineutron_S1_T1_5-_81";
    case DINEUTRON_5_MINUS_S1_T1_82: return "dineutron_S1_T1_5-_82";
    case DINEUTRON_5_MINUS_S1_T1_83: return "dineutron_S1_T1_5-_83";
    case DINEUTRON_5_MINUS_S1_T1_84: return "dineutron_S1_T1_5-_84";
    case DINEUTRON_5_MINUS_S1_T1_85: return "dineutron_S1_T1_5-_85";
    case DINEUTRON_5_MINUS_S1_T1_86: return "dineutron_S1_T1_5-_86";
    case DINEUTRON_5_MINUS_S1_T1_87: return "dineutron_S1_T1_5-_87";
    case DINEUTRON_5_MINUS_S1_T1_88: return "dineutron_S1_T1_5-_88";
    case DINEUTRON_5_MINUS_S1_T1_89: return "dineutron_S1_T1_5-_89";
    case DINEUTRON_5_MINUS_S1_T1_90: return "dineutron_S1_T1_5-_90";
    case DINEUTRON_5_MINUS_S1_T1_91: return "dineutron_S1_T1_5-_91";
    case DINEUTRON_5_MINUS_S1_T1_92: return "dineutron_S1_T1_5-_92";
    case DINEUTRON_5_MINUS_S1_T1_93: return "dineutron_S1_T1_5-_93";
    case DINEUTRON_5_MINUS_S1_T1_94: return "dineutron_S1_T1_5-_94";
    case DINEUTRON_5_MINUS_S1_T1_95: return "dineutron_S1_T1_5-_95";
    case DINEUTRON_5_MINUS_S1_T1_96: return "dineutron_S1_T1_5-_96";
    case DINEUTRON_5_MINUS_S1_T1_97: return "dineutron_S1_T1_5-_97";
    case DINEUTRON_5_MINUS_S1_T1_98: return "dineutron_S1_T1_5-_98";
    case DINEUTRON_5_MINUS_S1_T1_99: return "dineutron_S1_T1_5-_99";

    case DEUTERON_1_PLUS_S1_T0:    return "deuteron_S1_T0_1+";
    case DEUTERON_1_PLUS_S1_T0_0:  return "deuteron_S1_T0_1+_0";
    case DEUTERON_1_PLUS_S1_T0_1:  return "deuteron_S1_T0_1+_1";
    case DEUTERON_1_PLUS_S1_T0_2:  return "deuteron_S1_T0_1+_2";
    case DEUTERON_1_PLUS_S1_T0_3:  return "deuteron_S1_T0_1+_3";
    case DEUTERON_1_PLUS_S1_T0_4:  return "deuteron_S1_T0_1+_4";
    case DEUTERON_1_PLUS_S1_T0_5:  return "deuteron_S1_T0_1+_5";
    case DEUTERON_1_PLUS_S1_T0_6:  return "deuteron_S1_T0_1+_6";
    case DEUTERON_1_PLUS_S1_T0_7:  return "deuteron_S1_T0_1+_7";
    case DEUTERON_1_PLUS_S1_T0_8:  return "deuteron_S1_T0_1+_8";
    case DEUTERON_1_PLUS_S1_T0_9:  return "deuteron_S1_T0_1+_9";
    case DEUTERON_1_PLUS_S1_T0_10: return "deuteron_S1_T0_1+_10";
    case DEUTERON_1_PLUS_S1_T0_11: return "deuteron_S1_T0_1+_11";
    case DEUTERON_1_PLUS_S1_T0_12: return "deuteron_S1_T0_1+_12";
    case DEUTERON_1_PLUS_S1_T0_13: return "deuteron_S1_T0_1+_13";
    case DEUTERON_1_PLUS_S1_T0_14: return "deuteron_S1_T0_1+_14";
    case DEUTERON_1_PLUS_S1_T0_15: return "deuteron_S1_T0_1+_15";
    case DEUTERON_1_PLUS_S1_T0_16: return "deuteron_S1_T0_1+_16";
    case DEUTERON_1_PLUS_S1_T0_17: return "deuteron_S1_T0_1+_17";
    case DEUTERON_1_PLUS_S1_T0_18: return "deuteron_S1_T0_1+_18";
    case DEUTERON_1_PLUS_S1_T0_19: return "deuteron_S1_T0_1+_19";
    case DEUTERON_1_PLUS_S1_T0_20: return "deuteron_S1_T0_1+_20";
    case DEUTERON_1_PLUS_S1_T0_21: return "deuteron_S1_T0_1+_21";
    case DEUTERON_1_PLUS_S1_T0_22: return "deuteron_S1_T0_1+_22";
    case DEUTERON_1_PLUS_S1_T0_23: return "deuteron_S1_T0_1+_23";
    case DEUTERON_1_PLUS_S1_T0_24: return "deuteron_S1_T0_1+_24";
    case DEUTERON_1_PLUS_S1_T0_25: return "deuteron_S1_T0_1+_25";
    case DEUTERON_1_PLUS_S1_T0_26: return "deuteron_S1_T0_1+_26";
    case DEUTERON_1_PLUS_S1_T0_27: return "deuteron_S1_T0_1+_27";
    case DEUTERON_1_PLUS_S1_T0_28: return "deuteron_S1_T0_1+_28";
    case DEUTERON_1_PLUS_S1_T0_29: return "deuteron_S1_T0_1+_29";
    case DEUTERON_1_PLUS_S1_T0_30: return "deuteron_S1_T0_1+_30";
    case DEUTERON_1_PLUS_S1_T0_31: return "deuteron_S1_T0_1+_31";
    case DEUTERON_1_PLUS_S1_T0_32: return "deuteron_S1_T0_1+_32";
    case DEUTERON_1_PLUS_S1_T0_33: return "deuteron_S1_T0_1+_33";
    case DEUTERON_1_PLUS_S1_T0_34: return "deuteron_S1_T0_1+_34";
    case DEUTERON_1_PLUS_S1_T0_35: return "deuteron_S1_T0_1+_35";
    case DEUTERON_1_PLUS_S1_T0_36: return "deuteron_S1_T0_1+_36";
    case DEUTERON_1_PLUS_S1_T0_37: return "deuteron_S1_T0_1+_37";
    case DEUTERON_1_PLUS_S1_T0_38: return "deuteron_S1_T0_1+_38";
    case DEUTERON_1_PLUS_S1_T0_39: return "deuteron_S1_T0_1+_39";
    case DEUTERON_1_PLUS_S1_T0_40: return "deuteron_S1_T0_1+_40";
    case DEUTERON_1_PLUS_S1_T0_41: return "deuteron_S1_T0_1+_41";
    case DEUTERON_1_PLUS_S1_T0_42: return "deuteron_S1_T0_1+_42";
    case DEUTERON_1_PLUS_S1_T0_43: return "deuteron_S1_T0_1+_43";
    case DEUTERON_1_PLUS_S1_T0_44: return "deuteron_S1_T0_1+_44";
    case DEUTERON_1_PLUS_S1_T0_45: return "deuteron_S1_T0_1+_45";
    case DEUTERON_1_PLUS_S1_T0_46: return "deuteron_S1_T0_1+_46";
    case DEUTERON_1_PLUS_S1_T0_47: return "deuteron_S1_T0_1+_47";
    case DEUTERON_1_PLUS_S1_T0_48: return "deuteron_S1_T0_1+_48";
    case DEUTERON_1_PLUS_S1_T0_49: return "deuteron_S1_T0_1+_49";
    case DEUTERON_1_PLUS_S1_T0_50: return "deuteron_S1_T0_1+_50";
    case DEUTERON_1_PLUS_S1_T0_51: return "deuteron_S1_T0_1+_51";
    case DEUTERON_1_PLUS_S1_T0_52: return "deuteron_S1_T0_1+_52";
    case DEUTERON_1_PLUS_S1_T0_53: return "deuteron_S1_T0_1+_53";
    case DEUTERON_1_PLUS_S1_T0_54: return "deuteron_S1_T0_1+_54";
    case DEUTERON_1_PLUS_S1_T0_55: return "deuteron_S1_T0_1+_55";
    case DEUTERON_1_PLUS_S1_T0_56: return "deuteron_S1_T0_1+_56";
    case DEUTERON_1_PLUS_S1_T0_57: return "deuteron_S1_T0_1+_57";
    case DEUTERON_1_PLUS_S1_T0_58: return "deuteron_S1_T0_1+_58";
    case DEUTERON_1_PLUS_S1_T0_59: return "deuteron_S1_T0_1+_59";
    case DEUTERON_1_PLUS_S1_T0_60: return "deuteron_S1_T0_1+_60";
    case DEUTERON_1_PLUS_S1_T0_61: return "deuteron_S1_T0_1+_61";
    case DEUTERON_1_PLUS_S1_T0_62: return "deuteron_S1_T0_1+_62";
    case DEUTERON_1_PLUS_S1_T0_63: return "deuteron_S1_T0_1+_63";
    case DEUTERON_1_PLUS_S1_T0_64: return "deuteron_S1_T0_1+_64";
    case DEUTERON_1_PLUS_S1_T0_65: return "deuteron_S1_T0_1+_65";
    case DEUTERON_1_PLUS_S1_T0_66: return "deuteron_S1_T0_1+_66";
    case DEUTERON_1_PLUS_S1_T0_67: return "deuteron_S1_T0_1+_67";
    case DEUTERON_1_PLUS_S1_T0_68: return "deuteron_S1_T0_1+_68";
    case DEUTERON_1_PLUS_S1_T0_69: return "deuteron_S1_T0_1+_69";
    case DEUTERON_1_PLUS_S1_T0_70: return "deuteron_S1_T0_1+_70";
    case DEUTERON_1_PLUS_S1_T0_71: return "deuteron_S1_T0_1+_71";
    case DEUTERON_1_PLUS_S1_T0_72: return "deuteron_S1_T0_1+_72";
    case DEUTERON_1_PLUS_S1_T0_73: return "deuteron_S1_T0_1+_73";
    case DEUTERON_1_PLUS_S1_T0_74: return "deuteron_S1_T0_1+_74";
    case DEUTERON_1_PLUS_S1_T0_75: return "deuteron_S1_T0_1+_75";
    case DEUTERON_1_PLUS_S1_T0_76: return "deuteron_S1_T0_1+_76";
    case DEUTERON_1_PLUS_S1_T0_77: return "deuteron_S1_T0_1+_77";
    case DEUTERON_1_PLUS_S1_T0_78: return "deuteron_S1_T0_1+_78";
    case DEUTERON_1_PLUS_S1_T0_79: return "deuteron_S1_T0_1+_79";
    case DEUTERON_1_PLUS_S1_T0_80: return "deuteron_S1_T0_1+_80";
    case DEUTERON_1_PLUS_S1_T0_81: return "deuteron_S1_T0_1+_81";
    case DEUTERON_1_PLUS_S1_T0_82: return "deuteron_S1_T0_1+_82";
    case DEUTERON_1_PLUS_S1_T0_83: return "deuteron_S1_T0_1+_83";
    case DEUTERON_1_PLUS_S1_T0_84: return "deuteron_S1_T0_1+_84";
    case DEUTERON_1_PLUS_S1_T0_85: return "deuteron_S1_T0_1+_85";
    case DEUTERON_1_PLUS_S1_T0_86: return "deuteron_S1_T0_1+_86";
    case DEUTERON_1_PLUS_S1_T0_87: return "deuteron_S1_T0_1+_87";
    case DEUTERON_1_PLUS_S1_T0_88: return "deuteron_S1_T0_1+_88";
    case DEUTERON_1_PLUS_S1_T0_89: return "deuteron_S1_T0_1+_89";
    case DEUTERON_1_PLUS_S1_T0_90: return "deuteron_S1_T0_1+_90";
    case DEUTERON_1_PLUS_S1_T0_91: return "deuteron_S1_T0_1+_91";
    case DEUTERON_1_PLUS_S1_T0_92: return "deuteron_S1_T0_1+_92";
    case DEUTERON_1_PLUS_S1_T0_93: return "deuteron_S1_T0_1+_93";
    case DEUTERON_1_PLUS_S1_T0_94: return "deuteron_S1_T0_1+_94";
    case DEUTERON_1_PLUS_S1_T0_95: return "deuteron_S1_T0_1+_95";
    case DEUTERON_1_PLUS_S1_T0_96: return "deuteron_S1_T0_1+_96";
    case DEUTERON_1_PLUS_S1_T0_97: return "deuteron_S1_T0_1+_97";
    case DEUTERON_1_PLUS_S1_T0_98: return "deuteron_S1_T0_1+_98";
    case DEUTERON_1_PLUS_S1_T0_99: return "deuteron_S1_T0_1+_99";

    case DEUTERON_2_PLUS_S1_T0:    return "deuteron_S1_T0_2+";
    case DEUTERON_2_PLUS_S1_T0_0:  return "deuteron_S1_T0_2+_0";
    case DEUTERON_2_PLUS_S1_T0_1:  return "deuteron_S1_T0_2+_1";
    case DEUTERON_2_PLUS_S1_T0_2:  return "deuteron_S1_T0_2+_2";
    case DEUTERON_2_PLUS_S1_T0_3:  return "deuteron_S1_T0_2+_3";
    case DEUTERON_2_PLUS_S1_T0_4:  return "deuteron_S1_T0_2+_4";
    case DEUTERON_2_PLUS_S1_T0_5:  return "deuteron_S1_T0_2+_5";
    case DEUTERON_2_PLUS_S1_T0_6:  return "deuteron_S1_T0_2+_6";
    case DEUTERON_2_PLUS_S1_T0_7:  return "deuteron_S1_T0_2+_7";
    case DEUTERON_2_PLUS_S1_T0_8:  return "deuteron_S1_T0_2+_8";
    case DEUTERON_2_PLUS_S1_T0_9:  return "deuteron_S1_T0_2+_9";
    case DEUTERON_2_PLUS_S1_T0_10: return "deuteron_S1_T0_2+_10";
    case DEUTERON_2_PLUS_S1_T0_11: return "deuteron_S1_T0_2+_11";
    case DEUTERON_2_PLUS_S1_T0_12: return "deuteron_S1_T0_2+_12";
    case DEUTERON_2_PLUS_S1_T0_13: return "deuteron_S1_T0_2+_13";
    case DEUTERON_2_PLUS_S1_T0_14: return "deuteron_S1_T0_2+_14";
    case DEUTERON_2_PLUS_S1_T0_15: return "deuteron_S1_T0_2+_15";
    case DEUTERON_2_PLUS_S1_T0_16: return "deuteron_S1_T0_2+_16";
    case DEUTERON_2_PLUS_S1_T0_17: return "deuteron_S1_T0_2+_17";
    case DEUTERON_2_PLUS_S1_T0_18: return "deuteron_S1_T0_2+_18";
    case DEUTERON_2_PLUS_S1_T0_19: return "deuteron_S1_T0_2+_19";
    case DEUTERON_2_PLUS_S1_T0_20: return "deuteron_S1_T0_2+_20";
    case DEUTERON_2_PLUS_S1_T0_21: return "deuteron_S1_T0_2+_21";
    case DEUTERON_2_PLUS_S1_T0_22: return "deuteron_S1_T0_2+_22";
    case DEUTERON_2_PLUS_S1_T0_23: return "deuteron_S1_T0_2+_23";
    case DEUTERON_2_PLUS_S1_T0_24: return "deuteron_S1_T0_2+_24";
    case DEUTERON_2_PLUS_S1_T0_25: return "deuteron_S1_T0_2+_25";
    case DEUTERON_2_PLUS_S1_T0_26: return "deuteron_S1_T0_2+_26";
    case DEUTERON_2_PLUS_S1_T0_27: return "deuteron_S1_T0_2+_27";
    case DEUTERON_2_PLUS_S1_T0_28: return "deuteron_S1_T0_2+_28";
    case DEUTERON_2_PLUS_S1_T0_29: return "deuteron_S1_T0_2+_29";
    case DEUTERON_2_PLUS_S1_T0_30: return "deuteron_S1_T0_2+_30";
    case DEUTERON_2_PLUS_S1_T0_31: return "deuteron_S1_T0_2+_31";
    case DEUTERON_2_PLUS_S1_T0_32: return "deuteron_S1_T0_2+_32";
    case DEUTERON_2_PLUS_S1_T0_33: return "deuteron_S1_T0_2+_33";
    case DEUTERON_2_PLUS_S1_T0_34: return "deuteron_S1_T0_2+_34";
    case DEUTERON_2_PLUS_S1_T0_35: return "deuteron_S1_T0_2+_35";
    case DEUTERON_2_PLUS_S1_T0_36: return "deuteron_S1_T0_2+_36";
    case DEUTERON_2_PLUS_S1_T0_37: return "deuteron_S1_T0_2+_37";
    case DEUTERON_2_PLUS_S1_T0_38: return "deuteron_S1_T0_2+_38";
    case DEUTERON_2_PLUS_S1_T0_39: return "deuteron_S1_T0_2+_39";
    case DEUTERON_2_PLUS_S1_T0_40: return "deuteron_S1_T0_2+_40";
    case DEUTERON_2_PLUS_S1_T0_41: return "deuteron_S1_T0_2+_41";
    case DEUTERON_2_PLUS_S1_T0_42: return "deuteron_S1_T0_2+_42";
    case DEUTERON_2_PLUS_S1_T0_43: return "deuteron_S1_T0_2+_43";
    case DEUTERON_2_PLUS_S1_T0_44: return "deuteron_S1_T0_2+_44";
    case DEUTERON_2_PLUS_S1_T0_45: return "deuteron_S1_T0_2+_45";
    case DEUTERON_2_PLUS_S1_T0_46: return "deuteron_S1_T0_2+_46";
    case DEUTERON_2_PLUS_S1_T0_47: return "deuteron_S1_T0_2+_47";
    case DEUTERON_2_PLUS_S1_T0_48: return "deuteron_S1_T0_2+_48";
    case DEUTERON_2_PLUS_S1_T0_49: return "deuteron_S1_T0_2+_49";
    case DEUTERON_2_PLUS_S1_T0_50: return "deuteron_S1_T0_2+_50";
    case DEUTERON_2_PLUS_S1_T0_51: return "deuteron_S1_T0_2+_51";
    case DEUTERON_2_PLUS_S1_T0_52: return "deuteron_S1_T0_2+_52";
    case DEUTERON_2_PLUS_S1_T0_53: return "deuteron_S1_T0_2+_53";
    case DEUTERON_2_PLUS_S1_T0_54: return "deuteron_S1_T0_2+_54";
    case DEUTERON_2_PLUS_S1_T0_55: return "deuteron_S1_T0_2+_55";
    case DEUTERON_2_PLUS_S1_T0_56: return "deuteron_S1_T0_2+_56";
    case DEUTERON_2_PLUS_S1_T0_57: return "deuteron_S1_T0_2+_57";
    case DEUTERON_2_PLUS_S1_T0_58: return "deuteron_S1_T0_2+_58";
    case DEUTERON_2_PLUS_S1_T0_59: return "deuteron_S1_T0_2+_59";
    case DEUTERON_2_PLUS_S1_T0_60: return "deuteron_S1_T0_2+_60";
    case DEUTERON_2_PLUS_S1_T0_61: return "deuteron_S1_T0_2+_61";
    case DEUTERON_2_PLUS_S1_T0_62: return "deuteron_S1_T0_2+_62";
    case DEUTERON_2_PLUS_S1_T0_63: return "deuteron_S1_T0_2+_63";
    case DEUTERON_2_PLUS_S1_T0_64: return "deuteron_S1_T0_2+_64";
    case DEUTERON_2_PLUS_S1_T0_65: return "deuteron_S1_T0_2+_65";
    case DEUTERON_2_PLUS_S1_T0_66: return "deuteron_S1_T0_2+_66";
    case DEUTERON_2_PLUS_S1_T0_67: return "deuteron_S1_T0_2+_67";
    case DEUTERON_2_PLUS_S1_T0_68: return "deuteron_S1_T0_2+_68";
    case DEUTERON_2_PLUS_S1_T0_69: return "deuteron_S1_T0_2+_69";
    case DEUTERON_2_PLUS_S1_T0_70: return "deuteron_S1_T0_2+_70";
    case DEUTERON_2_PLUS_S1_T0_71: return "deuteron_S1_T0_2+_71";
    case DEUTERON_2_PLUS_S1_T0_72: return "deuteron_S1_T0_2+_72";
    case DEUTERON_2_PLUS_S1_T0_73: return "deuteron_S1_T0_2+_73";
    case DEUTERON_2_PLUS_S1_T0_74: return "deuteron_S1_T0_2+_74";
    case DEUTERON_2_PLUS_S1_T0_75: return "deuteron_S1_T0_2+_75";
    case DEUTERON_2_PLUS_S1_T0_76: return "deuteron_S1_T0_2+_76";
    case DEUTERON_2_PLUS_S1_T0_77: return "deuteron_S1_T0_2+_77";
    case DEUTERON_2_PLUS_S1_T0_78: return "deuteron_S1_T0_2+_78";
    case DEUTERON_2_PLUS_S1_T0_79: return "deuteron_S1_T0_2+_79";
    case DEUTERON_2_PLUS_S1_T0_80: return "deuteron_S1_T0_2+_80";
    case DEUTERON_2_PLUS_S1_T0_81: return "deuteron_S1_T0_2+_81";
    case DEUTERON_2_PLUS_S1_T0_82: return "deuteron_S1_T0_2+_82";
    case DEUTERON_2_PLUS_S1_T0_83: return "deuteron_S1_T0_2+_83";
    case DEUTERON_2_PLUS_S1_T0_84: return "deuteron_S1_T0_2+_84";
    case DEUTERON_2_PLUS_S1_T0_85: return "deuteron_S1_T0_2+_85";
    case DEUTERON_2_PLUS_S1_T0_86: return "deuteron_S1_T0_2+_86";
    case DEUTERON_2_PLUS_S1_T0_87: return "deuteron_S1_T0_2+_87";
    case DEUTERON_2_PLUS_S1_T0_88: return "deuteron_S1_T0_2+_88";
    case DEUTERON_2_PLUS_S1_T0_89: return "deuteron_S1_T0_2+_89";
    case DEUTERON_2_PLUS_S1_T0_90: return "deuteron_S1_T0_2+_90";
    case DEUTERON_2_PLUS_S1_T0_91: return "deuteron_S1_T0_2+_91";
    case DEUTERON_2_PLUS_S1_T0_92: return "deuteron_S1_T0_2+_92";
    case DEUTERON_2_PLUS_S1_T0_93: return "deuteron_S1_T0_2+_93";
    case DEUTERON_2_PLUS_S1_T0_94: return "deuteron_S1_T0_2+_94";
    case DEUTERON_2_PLUS_S1_T0_95: return "deuteron_S1_T0_2+_95";
    case DEUTERON_2_PLUS_S1_T0_96: return "deuteron_S1_T0_2+_96";
    case DEUTERON_2_PLUS_S1_T0_97: return "deuteron_S1_T0_2+_97";
    case DEUTERON_2_PLUS_S1_T0_98: return "deuteron_S1_T0_2+_98";
    case DEUTERON_2_PLUS_S1_T0_99: return "deuteron_S1_T0_2+_99";

    case DEUTERON_3_PLUS_S1_T0:    return "deuteron_S1_T0_3+";
    case DEUTERON_3_PLUS_S1_T0_0:  return "deuteron_S1_T0_3+_0";
    case DEUTERON_3_PLUS_S1_T0_1:  return "deuteron_S1_T0_3+_1";
    case DEUTERON_3_PLUS_S1_T0_2:  return "deuteron_S1_T0_3+_2";
    case DEUTERON_3_PLUS_S1_T0_3:  return "deuteron_S1_T0_3+_3";
    case DEUTERON_3_PLUS_S1_T0_4:  return "deuteron_S1_T0_3+_4";
    case DEUTERON_3_PLUS_S1_T0_5:  return "deuteron_S1_T0_3+_5";
    case DEUTERON_3_PLUS_S1_T0_6:  return "deuteron_S1_T0_3+_6";
    case DEUTERON_3_PLUS_S1_T0_7:  return "deuteron_S1_T0_3+_7";
    case DEUTERON_3_PLUS_S1_T0_8:  return "deuteron_S1_T0_3+_8";
    case DEUTERON_3_PLUS_S1_T0_9:  return "deuteron_S1_T0_3+_9";
    case DEUTERON_3_PLUS_S1_T0_10: return "deuteron_S1_T0_3+_10";
    case DEUTERON_3_PLUS_S1_T0_11: return "deuteron_S1_T0_3+_11";
    case DEUTERON_3_PLUS_S1_T0_12: return "deuteron_S1_T0_3+_12";
    case DEUTERON_3_PLUS_S1_T0_13: return "deuteron_S1_T0_3+_13";
    case DEUTERON_3_PLUS_S1_T0_14: return "deuteron_S1_T0_3+_14";
    case DEUTERON_3_PLUS_S1_T0_15: return "deuteron_S1_T0_3+_15";
    case DEUTERON_3_PLUS_S1_T0_16: return "deuteron_S1_T0_3+_16";
    case DEUTERON_3_PLUS_S1_T0_17: return "deuteron_S1_T0_3+_17";
    case DEUTERON_3_PLUS_S1_T0_18: return "deuteron_S1_T0_3+_18";
    case DEUTERON_3_PLUS_S1_T0_19: return "deuteron_S1_T0_3+_19";
    case DEUTERON_3_PLUS_S1_T0_20: return "deuteron_S1_T0_3+_20";
    case DEUTERON_3_PLUS_S1_T0_21: return "deuteron_S1_T0_3+_21";
    case DEUTERON_3_PLUS_S1_T0_22: return "deuteron_S1_T0_3+_22";
    case DEUTERON_3_PLUS_S1_T0_23: return "deuteron_S1_T0_3+_23";
    case DEUTERON_3_PLUS_S1_T0_24: return "deuteron_S1_T0_3+_24";
    case DEUTERON_3_PLUS_S1_T0_25: return "deuteron_S1_T0_3+_25";
    case DEUTERON_3_PLUS_S1_T0_26: return "deuteron_S1_T0_3+_26";
    case DEUTERON_3_PLUS_S1_T0_27: return "deuteron_S1_T0_3+_27";
    case DEUTERON_3_PLUS_S1_T0_28: return "deuteron_S1_T0_3+_28";
    case DEUTERON_3_PLUS_S1_T0_29: return "deuteron_S1_T0_3+_29";
    case DEUTERON_3_PLUS_S1_T0_30: return "deuteron_S1_T0_3+_30";
    case DEUTERON_3_PLUS_S1_T0_31: return "deuteron_S1_T0_3+_31";
    case DEUTERON_3_PLUS_S1_T0_32: return "deuteron_S1_T0_3+_32";
    case DEUTERON_3_PLUS_S1_T0_33: return "deuteron_S1_T0_3+_33";
    case DEUTERON_3_PLUS_S1_T0_34: return "deuteron_S1_T0_3+_34";
    case DEUTERON_3_PLUS_S1_T0_35: return "deuteron_S1_T0_3+_35";
    case DEUTERON_3_PLUS_S1_T0_36: return "deuteron_S1_T0_3+_36";
    case DEUTERON_3_PLUS_S1_T0_37: return "deuteron_S1_T0_3+_37";
    case DEUTERON_3_PLUS_S1_T0_38: return "deuteron_S1_T0_3+_38";
    case DEUTERON_3_PLUS_S1_T0_39: return "deuteron_S1_T0_3+_39";
    case DEUTERON_3_PLUS_S1_T0_40: return "deuteron_S1_T0_3+_40";
    case DEUTERON_3_PLUS_S1_T0_41: return "deuteron_S1_T0_3+_41";
    case DEUTERON_3_PLUS_S1_T0_42: return "deuteron_S1_T0_3+_42";
    case DEUTERON_3_PLUS_S1_T0_43: return "deuteron_S1_T0_3+_43";
    case DEUTERON_3_PLUS_S1_T0_44: return "deuteron_S1_T0_3+_44";
    case DEUTERON_3_PLUS_S1_T0_45: return "deuteron_S1_T0_3+_45";
    case DEUTERON_3_PLUS_S1_T0_46: return "deuteron_S1_T0_3+_46";
    case DEUTERON_3_PLUS_S1_T0_47: return "deuteron_S1_T0_3+_47";
    case DEUTERON_3_PLUS_S1_T0_48: return "deuteron_S1_T0_3+_48";
    case DEUTERON_3_PLUS_S1_T0_49: return "deuteron_S1_T0_3+_49";
    case DEUTERON_3_PLUS_S1_T0_50: return "deuteron_S1_T0_3+_50";
    case DEUTERON_3_PLUS_S1_T0_51: return "deuteron_S1_T0_3+_51";
    case DEUTERON_3_PLUS_S1_T0_52: return "deuteron_S1_T0_3+_52";
    case DEUTERON_3_PLUS_S1_T0_53: return "deuteron_S1_T0_3+_53";
    case DEUTERON_3_PLUS_S1_T0_54: return "deuteron_S1_T0_3+_54";
    case DEUTERON_3_PLUS_S1_T0_55: return "deuteron_S1_T0_3+_55";
    case DEUTERON_3_PLUS_S1_T0_56: return "deuteron_S1_T0_3+_56";
    case DEUTERON_3_PLUS_S1_T0_57: return "deuteron_S1_T0_3+_57";
    case DEUTERON_3_PLUS_S1_T0_58: return "deuteron_S1_T0_3+_58";
    case DEUTERON_3_PLUS_S1_T0_59: return "deuteron_S1_T0_3+_59";
    case DEUTERON_3_PLUS_S1_T0_60: return "deuteron_S1_T0_3+_60";
    case DEUTERON_3_PLUS_S1_T0_61: return "deuteron_S1_T0_3+_61";
    case DEUTERON_3_PLUS_S1_T0_62: return "deuteron_S1_T0_3+_62";
    case DEUTERON_3_PLUS_S1_T0_63: return "deuteron_S1_T0_3+_63";
    case DEUTERON_3_PLUS_S1_T0_64: return "deuteron_S1_T0_3+_64";
    case DEUTERON_3_PLUS_S1_T0_65: return "deuteron_S1_T0_3+_65";
    case DEUTERON_3_PLUS_S1_T0_66: return "deuteron_S1_T0_3+_66";
    case DEUTERON_3_PLUS_S1_T0_67: return "deuteron_S1_T0_3+_67";
    case DEUTERON_3_PLUS_S1_T0_68: return "deuteron_S1_T0_3+_68";
    case DEUTERON_3_PLUS_S1_T0_69: return "deuteron_S1_T0_3+_69";
    case DEUTERON_3_PLUS_S1_T0_70: return "deuteron_S1_T0_3+_70";
    case DEUTERON_3_PLUS_S1_T0_71: return "deuteron_S1_T0_3+_71";
    case DEUTERON_3_PLUS_S1_T0_72: return "deuteron_S1_T0_3+_72";
    case DEUTERON_3_PLUS_S1_T0_73: return "deuteron_S1_T0_3+_73";
    case DEUTERON_3_PLUS_S1_T0_74: return "deuteron_S1_T0_3+_74";
    case DEUTERON_3_PLUS_S1_T0_75: return "deuteron_S1_T0_3+_75";
    case DEUTERON_3_PLUS_S1_T0_76: return "deuteron_S1_T0_3+_76";
    case DEUTERON_3_PLUS_S1_T0_77: return "deuteron_S1_T0_3+_77";
    case DEUTERON_3_PLUS_S1_T0_78: return "deuteron_S1_T0_3+_78";
    case DEUTERON_3_PLUS_S1_T0_79: return "deuteron_S1_T0_3+_79";
    case DEUTERON_3_PLUS_S1_T0_80: return "deuteron_S1_T0_3+_80";
    case DEUTERON_3_PLUS_S1_T0_81: return "deuteron_S1_T0_3+_81";
    case DEUTERON_3_PLUS_S1_T0_82: return "deuteron_S1_T0_3+_82";
    case DEUTERON_3_PLUS_S1_T0_83: return "deuteron_S1_T0_3+_83";
    case DEUTERON_3_PLUS_S1_T0_84: return "deuteron_S1_T0_3+_84";
    case DEUTERON_3_PLUS_S1_T0_85: return "deuteron_S1_T0_3+_85";
    case DEUTERON_3_PLUS_S1_T0_86: return "deuteron_S1_T0_3+_86";
    case DEUTERON_3_PLUS_S1_T0_87: return "deuteron_S1_T0_3+_87";
    case DEUTERON_3_PLUS_S1_T0_88: return "deuteron_S1_T0_3+_88";
    case DEUTERON_3_PLUS_S1_T0_89: return "deuteron_S1_T0_3+_89";
    case DEUTERON_3_PLUS_S1_T0_90: return "deuteron_S1_T0_3+_90";
    case DEUTERON_3_PLUS_S1_T0_91: return "deuteron_S1_T0_3+_91";
    case DEUTERON_3_PLUS_S1_T0_92: return "deuteron_S1_T0_3+_92";
    case DEUTERON_3_PLUS_S1_T0_93: return "deuteron_S1_T0_3+_93";
    case DEUTERON_3_PLUS_S1_T0_94: return "deuteron_S1_T0_3+_94";
    case DEUTERON_3_PLUS_S1_T0_95: return "deuteron_S1_T0_3+_95";
    case DEUTERON_3_PLUS_S1_T0_96: return "deuteron_S1_T0_3+_96";
    case DEUTERON_3_PLUS_S1_T0_97: return "deuteron_S1_T0_3+_97";
    case DEUTERON_3_PLUS_S1_T0_98: return "deuteron_S1_T0_3+_98";
    case DEUTERON_3_PLUS_S1_T0_99: return "deuteron_S1_T0_3+_99";

    case DEUTERON_4_PLUS_S1_T0:    return "deuteron_S1_T0_4+";
    case DEUTERON_4_PLUS_S1_T0_0:  return "deuteron_S1_T0_4+_0";
    case DEUTERON_4_PLUS_S1_T0_1:  return "deuteron_S1_T0_4+_1";
    case DEUTERON_4_PLUS_S1_T0_2:  return "deuteron_S1_T0_4+_2";
    case DEUTERON_4_PLUS_S1_T0_3:  return "deuteron_S1_T0_4+_3";
    case DEUTERON_4_PLUS_S1_T0_4:  return "deuteron_S1_T0_4+_4";
    case DEUTERON_4_PLUS_S1_T0_5:  return "deuteron_S1_T0_4+_5";
    case DEUTERON_4_PLUS_S1_T0_6:  return "deuteron_S1_T0_4+_6";
    case DEUTERON_4_PLUS_S1_T0_7:  return "deuteron_S1_T0_4+_7";
    case DEUTERON_4_PLUS_S1_T0_8:  return "deuteron_S1_T0_4+_8";
    case DEUTERON_4_PLUS_S1_T0_9:  return "deuteron_S1_T0_4+_9";
    case DEUTERON_4_PLUS_S1_T0_10: return "deuteron_S1_T0_4+_10";
    case DEUTERON_4_PLUS_S1_T0_11: return "deuteron_S1_T0_4+_11";
    case DEUTERON_4_PLUS_S1_T0_12: return "deuteron_S1_T0_4+_12";
    case DEUTERON_4_PLUS_S1_T0_13: return "deuteron_S1_T0_4+_13";
    case DEUTERON_4_PLUS_S1_T0_14: return "deuteron_S1_T0_4+_14";
    case DEUTERON_4_PLUS_S1_T0_15: return "deuteron_S1_T0_4+_15";
    case DEUTERON_4_PLUS_S1_T0_16: return "deuteron_S1_T0_4+_16";
    case DEUTERON_4_PLUS_S1_T0_17: return "deuteron_S1_T0_4+_17";
    case DEUTERON_4_PLUS_S1_T0_18: return "deuteron_S1_T0_4+_18";
    case DEUTERON_4_PLUS_S1_T0_19: return "deuteron_S1_T0_4+_19";
    case DEUTERON_4_PLUS_S1_T0_20: return "deuteron_S1_T0_4+_20";
    case DEUTERON_4_PLUS_S1_T0_21: return "deuteron_S1_T0_4+_21";
    case DEUTERON_4_PLUS_S1_T0_22: return "deuteron_S1_T0_4+_22";
    case DEUTERON_4_PLUS_S1_T0_23: return "deuteron_S1_T0_4+_23";
    case DEUTERON_4_PLUS_S1_T0_24: return "deuteron_S1_T0_4+_24";
    case DEUTERON_4_PLUS_S1_T0_25: return "deuteron_S1_T0_4+_25";
    case DEUTERON_4_PLUS_S1_T0_26: return "deuteron_S1_T0_4+_26";
    case DEUTERON_4_PLUS_S1_T0_27: return "deuteron_S1_T0_4+_27";
    case DEUTERON_4_PLUS_S1_T0_28: return "deuteron_S1_T0_4+_28";
    case DEUTERON_4_PLUS_S1_T0_29: return "deuteron_S1_T0_4+_29";
    case DEUTERON_4_PLUS_S1_T0_30: return "deuteron_S1_T0_4+_30";
    case DEUTERON_4_PLUS_S1_T0_31: return "deuteron_S1_T0_4+_31";
    case DEUTERON_4_PLUS_S1_T0_32: return "deuteron_S1_T0_4+_32";
    case DEUTERON_4_PLUS_S1_T0_33: return "deuteron_S1_T0_4+_33";
    case DEUTERON_4_PLUS_S1_T0_34: return "deuteron_S1_T0_4+_34";
    case DEUTERON_4_PLUS_S1_T0_35: return "deuteron_S1_T0_4+_35";
    case DEUTERON_4_PLUS_S1_T0_36: return "deuteron_S1_T0_4+_36";
    case DEUTERON_4_PLUS_S1_T0_37: return "deuteron_S1_T0_4+_37";
    case DEUTERON_4_PLUS_S1_T0_38: return "deuteron_S1_T0_4+_38";
    case DEUTERON_4_PLUS_S1_T0_39: return "deuteron_S1_T0_4+_39";
    case DEUTERON_4_PLUS_S1_T0_40: return "deuteron_S1_T0_4+_40";
    case DEUTERON_4_PLUS_S1_T0_41: return "deuteron_S1_T0_4+_41";
    case DEUTERON_4_PLUS_S1_T0_42: return "deuteron_S1_T0_4+_42";
    case DEUTERON_4_PLUS_S1_T0_43: return "deuteron_S1_T0_4+_43";
    case DEUTERON_4_PLUS_S1_T0_44: return "deuteron_S1_T0_4+_44";
    case DEUTERON_4_PLUS_S1_T0_45: return "deuteron_S1_T0_4+_45";
    case DEUTERON_4_PLUS_S1_T0_46: return "deuteron_S1_T0_4+_46";
    case DEUTERON_4_PLUS_S1_T0_47: return "deuteron_S1_T0_4+_47";
    case DEUTERON_4_PLUS_S1_T0_48: return "deuteron_S1_T0_4+_48";
    case DEUTERON_4_PLUS_S1_T0_49: return "deuteron_S1_T0_4+_49";
    case DEUTERON_4_PLUS_S1_T0_50: return "deuteron_S1_T0_4+_50";
    case DEUTERON_4_PLUS_S1_T0_51: return "deuteron_S1_T0_4+_51";
    case DEUTERON_4_PLUS_S1_T0_52: return "deuteron_S1_T0_4+_52";
    case DEUTERON_4_PLUS_S1_T0_53: return "deuteron_S1_T0_4+_53";
    case DEUTERON_4_PLUS_S1_T0_54: return "deuteron_S1_T0_4+_54";
    case DEUTERON_4_PLUS_S1_T0_55: return "deuteron_S1_T0_4+_55";
    case DEUTERON_4_PLUS_S1_T0_56: return "deuteron_S1_T0_4+_56";
    case DEUTERON_4_PLUS_S1_T0_57: return "deuteron_S1_T0_4+_57";
    case DEUTERON_4_PLUS_S1_T0_58: return "deuteron_S1_T0_4+_58";
    case DEUTERON_4_PLUS_S1_T0_59: return "deuteron_S1_T0_4+_59";
    case DEUTERON_4_PLUS_S1_T0_60: return "deuteron_S1_T0_4+_60";
    case DEUTERON_4_PLUS_S1_T0_61: return "deuteron_S1_T0_4+_61";
    case DEUTERON_4_PLUS_S1_T0_62: return "deuteron_S1_T0_4+_62";
    case DEUTERON_4_PLUS_S1_T0_63: return "deuteron_S1_T0_4+_63";
    case DEUTERON_4_PLUS_S1_T0_64: return "deuteron_S1_T0_4+_64";
    case DEUTERON_4_PLUS_S1_T0_65: return "deuteron_S1_T0_4+_65";
    case DEUTERON_4_PLUS_S1_T0_66: return "deuteron_S1_T0_4+_66";
    case DEUTERON_4_PLUS_S1_T0_67: return "deuteron_S1_T0_4+_67";
    case DEUTERON_4_PLUS_S1_T0_68: return "deuteron_S1_T0_4+_68";
    case DEUTERON_4_PLUS_S1_T0_69: return "deuteron_S1_T0_4+_69";
    case DEUTERON_4_PLUS_S1_T0_70: return "deuteron_S1_T0_4+_70";
    case DEUTERON_4_PLUS_S1_T0_71: return "deuteron_S1_T0_4+_71";
    case DEUTERON_4_PLUS_S1_T0_72: return "deuteron_S1_T0_4+_72";
    case DEUTERON_4_PLUS_S1_T0_73: return "deuteron_S1_T0_4+_73";
    case DEUTERON_4_PLUS_S1_T0_74: return "deuteron_S1_T0_4+_74";
    case DEUTERON_4_PLUS_S1_T0_75: return "deuteron_S1_T0_4+_75";
    case DEUTERON_4_PLUS_S1_T0_76: return "deuteron_S1_T0_4+_76";
    case DEUTERON_4_PLUS_S1_T0_77: return "deuteron_S1_T0_4+_77";
    case DEUTERON_4_PLUS_S1_T0_78: return "deuteron_S1_T0_4+_78";
    case DEUTERON_4_PLUS_S1_T0_79: return "deuteron_S1_T0_4+_79";
    case DEUTERON_4_PLUS_S1_T0_80: return "deuteron_S1_T0_4+_80";
    case DEUTERON_4_PLUS_S1_T0_81: return "deuteron_S1_T0_4+_81";
    case DEUTERON_4_PLUS_S1_T0_82: return "deuteron_S1_T0_4+_82";
    case DEUTERON_4_PLUS_S1_T0_83: return "deuteron_S1_T0_4+_83";
    case DEUTERON_4_PLUS_S1_T0_84: return "deuteron_S1_T0_4+_84";
    case DEUTERON_4_PLUS_S1_T0_85: return "deuteron_S1_T0_4+_85";
    case DEUTERON_4_PLUS_S1_T0_86: return "deuteron_S1_T0_4+_86";
    case DEUTERON_4_PLUS_S1_T0_87: return "deuteron_S1_T0_4+_87";
    case DEUTERON_4_PLUS_S1_T0_88: return "deuteron_S1_T0_4+_88";
    case DEUTERON_4_PLUS_S1_T0_89: return "deuteron_S1_T0_4+_89";
    case DEUTERON_4_PLUS_S1_T0_90: return "deuteron_S1_T0_4+_90";
    case DEUTERON_4_PLUS_S1_T0_91: return "deuteron_S1_T0_4+_91";
    case DEUTERON_4_PLUS_S1_T0_92: return "deuteron_S1_T0_4+_92";
    case DEUTERON_4_PLUS_S1_T0_93: return "deuteron_S1_T0_4+_93";
    case DEUTERON_4_PLUS_S1_T0_94: return "deuteron_S1_T0_4+_94";
    case DEUTERON_4_PLUS_S1_T0_95: return "deuteron_S1_T0_4+_95";
    case DEUTERON_4_PLUS_S1_T0_96: return "deuteron_S1_T0_4+_96";
    case DEUTERON_4_PLUS_S1_T0_97: return "deuteron_S1_T0_4+_97";
    case DEUTERON_4_PLUS_S1_T0_98: return "deuteron_S1_T0_4+_98";
    case DEUTERON_4_PLUS_S1_T0_99: return "deuteron_S1_T0_4+_99";

    case DEUTERON_5_PLUS_S1_T0:    return "deuteron_S1_T0_5+";
    case DEUTERON_5_PLUS_S1_T0_0:  return "deuteron_S1_T0_5+_0";
    case DEUTERON_5_PLUS_S1_T0_1:  return "deuteron_S1_T0_5+_1";
    case DEUTERON_5_PLUS_S1_T0_2:  return "deuteron_S1_T0_5+_2";
    case DEUTERON_5_PLUS_S1_T0_3:  return "deuteron_S1_T0_5+_3";
    case DEUTERON_5_PLUS_S1_T0_4:  return "deuteron_S1_T0_5+_4";
    case DEUTERON_5_PLUS_S1_T0_5:  return "deuteron_S1_T0_5+_5";
    case DEUTERON_5_PLUS_S1_T0_6:  return "deuteron_S1_T0_5+_6";
    case DEUTERON_5_PLUS_S1_T0_7:  return "deuteron_S1_T0_5+_7";
    case DEUTERON_5_PLUS_S1_T0_8:  return "deuteron_S1_T0_5+_8";
    case DEUTERON_5_PLUS_S1_T0_9:  return "deuteron_S1_T0_5+_9";
    case DEUTERON_5_PLUS_S1_T0_10: return "deuteron_S1_T0_5+_10";
    case DEUTERON_5_PLUS_S1_T0_11: return "deuteron_S1_T0_5+_11";
    case DEUTERON_5_PLUS_S1_T0_12: return "deuteron_S1_T0_5+_12";
    case DEUTERON_5_PLUS_S1_T0_13: return "deuteron_S1_T0_5+_13";
    case DEUTERON_5_PLUS_S1_T0_14: return "deuteron_S1_T0_5+_14";
    case DEUTERON_5_PLUS_S1_T0_15: return "deuteron_S1_T0_5+_15";
    case DEUTERON_5_PLUS_S1_T0_16: return "deuteron_S1_T0_5+_16";
    case DEUTERON_5_PLUS_S1_T0_17: return "deuteron_S1_T0_5+_17";
    case DEUTERON_5_PLUS_S1_T0_18: return "deuteron_S1_T0_5+_18";
    case DEUTERON_5_PLUS_S1_T0_19: return "deuteron_S1_T0_5+_19";
    case DEUTERON_5_PLUS_S1_T0_20: return "deuteron_S1_T0_5+_20";
    case DEUTERON_5_PLUS_S1_T0_21: return "deuteron_S1_T0_5+_21";
    case DEUTERON_5_PLUS_S1_T0_22: return "deuteron_S1_T0_5+_22";
    case DEUTERON_5_PLUS_S1_T0_23: return "deuteron_S1_T0_5+_23";
    case DEUTERON_5_PLUS_S1_T0_24: return "deuteron_S1_T0_5+_24";
    case DEUTERON_5_PLUS_S1_T0_25: return "deuteron_S1_T0_5+_25";
    case DEUTERON_5_PLUS_S1_T0_26: return "deuteron_S1_T0_5+_26";
    case DEUTERON_5_PLUS_S1_T0_27: return "deuteron_S1_T0_5+_27";
    case DEUTERON_5_PLUS_S1_T0_28: return "deuteron_S1_T0_5+_28";
    case DEUTERON_5_PLUS_S1_T0_29: return "deuteron_S1_T0_5+_29";
    case DEUTERON_5_PLUS_S1_T0_30: return "deuteron_S1_T0_5+_30";
    case DEUTERON_5_PLUS_S1_T0_31: return "deuteron_S1_T0_5+_31";
    case DEUTERON_5_PLUS_S1_T0_32: return "deuteron_S1_T0_5+_32";
    case DEUTERON_5_PLUS_S1_T0_33: return "deuteron_S1_T0_5+_33";
    case DEUTERON_5_PLUS_S1_T0_34: return "deuteron_S1_T0_5+_34";
    case DEUTERON_5_PLUS_S1_T0_35: return "deuteron_S1_T0_5+_35";
    case DEUTERON_5_PLUS_S1_T0_36: return "deuteron_S1_T0_5+_36";
    case DEUTERON_5_PLUS_S1_T0_37: return "deuteron_S1_T0_5+_37";
    case DEUTERON_5_PLUS_S1_T0_38: return "deuteron_S1_T0_5+_38";
    case DEUTERON_5_PLUS_S1_T0_39: return "deuteron_S1_T0_5+_39";
    case DEUTERON_5_PLUS_S1_T0_40: return "deuteron_S1_T0_5+_40";
    case DEUTERON_5_PLUS_S1_T0_41: return "deuteron_S1_T0_5+_41";
    case DEUTERON_5_PLUS_S1_T0_42: return "deuteron_S1_T0_5+_42";
    case DEUTERON_5_PLUS_S1_T0_43: return "deuteron_S1_T0_5+_43";
    case DEUTERON_5_PLUS_S1_T0_44: return "deuteron_S1_T0_5+_44";
    case DEUTERON_5_PLUS_S1_T0_45: return "deuteron_S1_T0_5+_45";
    case DEUTERON_5_PLUS_S1_T0_46: return "deuteron_S1_T0_5+_46";
    case DEUTERON_5_PLUS_S1_T0_47: return "deuteron_S1_T0_5+_47";
    case DEUTERON_5_PLUS_S1_T0_48: return "deuteron_S1_T0_5+_48";
    case DEUTERON_5_PLUS_S1_T0_49: return "deuteron_S1_T0_5+_49";
    case DEUTERON_5_PLUS_S1_T0_50: return "deuteron_S1_T0_5+_50";
    case DEUTERON_5_PLUS_S1_T0_51: return "deuteron_S1_T0_5+_51";
    case DEUTERON_5_PLUS_S1_T0_52: return "deuteron_S1_T0_5+_52";
    case DEUTERON_5_PLUS_S1_T0_53: return "deuteron_S1_T0_5+_53";
    case DEUTERON_5_PLUS_S1_T0_54: return "deuteron_S1_T0_5+_54";
    case DEUTERON_5_PLUS_S1_T0_55: return "deuteron_S1_T0_5+_55";
    case DEUTERON_5_PLUS_S1_T0_56: return "deuteron_S1_T0_5+_56";
    case DEUTERON_5_PLUS_S1_T0_57: return "deuteron_S1_T0_5+_57";
    case DEUTERON_5_PLUS_S1_T0_58: return "deuteron_S1_T0_5+_58";
    case DEUTERON_5_PLUS_S1_T0_59: return "deuteron_S1_T0_5+_59";
    case DEUTERON_5_PLUS_S1_T0_60: return "deuteron_S1_T0_5+_60";
    case DEUTERON_5_PLUS_S1_T0_61: return "deuteron_S1_T0_5+_61";
    case DEUTERON_5_PLUS_S1_T0_62: return "deuteron_S1_T0_5+_62";
    case DEUTERON_5_PLUS_S1_T0_63: return "deuteron_S1_T0_5+_63";
    case DEUTERON_5_PLUS_S1_T0_64: return "deuteron_S1_T0_5+_64";
    case DEUTERON_5_PLUS_S1_T0_65: return "deuteron_S1_T0_5+_65";
    case DEUTERON_5_PLUS_S1_T0_66: return "deuteron_S1_T0_5+_66";
    case DEUTERON_5_PLUS_S1_T0_67: return "deuteron_S1_T0_5+_67";
    case DEUTERON_5_PLUS_S1_T0_68: return "deuteron_S1_T0_5+_68";
    case DEUTERON_5_PLUS_S1_T0_69: return "deuteron_S1_T0_5+_69";
    case DEUTERON_5_PLUS_S1_T0_70: return "deuteron_S1_T0_5+_70";
    case DEUTERON_5_PLUS_S1_T0_71: return "deuteron_S1_T0_5+_71";
    case DEUTERON_5_PLUS_S1_T0_72: return "deuteron_S1_T0_5+_72";
    case DEUTERON_5_PLUS_S1_T0_73: return "deuteron_S1_T0_5+_73";
    case DEUTERON_5_PLUS_S1_T0_74: return "deuteron_S1_T0_5+_74";
    case DEUTERON_5_PLUS_S1_T0_75: return "deuteron_S1_T0_5+_75";
    case DEUTERON_5_PLUS_S1_T0_76: return "deuteron_S1_T0_5+_76";
    case DEUTERON_5_PLUS_S1_T0_77: return "deuteron_S1_T0_5+_77";
    case DEUTERON_5_PLUS_S1_T0_78: return "deuteron_S1_T0_5+_78";
    case DEUTERON_5_PLUS_S1_T0_79: return "deuteron_S1_T0_5+_79";
    case DEUTERON_5_PLUS_S1_T0_80: return "deuteron_S1_T0_5+_80";
    case DEUTERON_5_PLUS_S1_T0_81: return "deuteron_S1_T0_5+_81";
    case DEUTERON_5_PLUS_S1_T0_82: return "deuteron_S1_T0_5+_82";
    case DEUTERON_5_PLUS_S1_T0_83: return "deuteron_S1_T0_5+_83";
    case DEUTERON_5_PLUS_S1_T0_84: return "deuteron_S1_T0_5+_84";
    case DEUTERON_5_PLUS_S1_T0_85: return "deuteron_S1_T0_5+_85";
    case DEUTERON_5_PLUS_S1_T0_86: return "deuteron_S1_T0_5+_86";
    case DEUTERON_5_PLUS_S1_T0_87: return "deuteron_S1_T0_5+_87";
    case DEUTERON_5_PLUS_S1_T0_88: return "deuteron_S1_T0_5+_88";
    case DEUTERON_5_PLUS_S1_T0_89: return "deuteron_S1_T0_5+_89";
    case DEUTERON_5_PLUS_S1_T0_90: return "deuteron_S1_T0_5+_90";
    case DEUTERON_5_PLUS_S1_T0_91: return "deuteron_S1_T0_5+_91";
    case DEUTERON_5_PLUS_S1_T0_92: return "deuteron_S1_T0_5+_92";
    case DEUTERON_5_PLUS_S1_T0_93: return "deuteron_S1_T0_5+_93";
    case DEUTERON_5_PLUS_S1_T0_94: return "deuteron_S1_T0_5+_94";
    case DEUTERON_5_PLUS_S1_T0_95: return "deuteron_S1_T0_5+_95";
    case DEUTERON_5_PLUS_S1_T0_96: return "deuteron_S1_T0_5+_96";
    case DEUTERON_5_PLUS_S1_T0_97: return "deuteron_S1_T0_5+_97";
    case DEUTERON_5_PLUS_S1_T0_98: return "deuteron_S1_T0_5+_98";
    case DEUTERON_5_PLUS_S1_T0_99: return "deuteron_S1_T0_5+_99";

    case DEUTERON_1_MINUS_S0_T0:    return "deuteron_S0_T0_1-";
    case DEUTERON_1_MINUS_S0_T0_0:  return "deuteron_S0_T0_1-_0";
    case DEUTERON_1_MINUS_S0_T0_1:  return "deuteron_S0_T0_1-_1";
    case DEUTERON_1_MINUS_S0_T0_2:  return "deuteron_S0_T0_1-_2";
    case DEUTERON_1_MINUS_S0_T0_3:  return "deuteron_S0_T0_1-_3";
    case DEUTERON_1_MINUS_S0_T0_4:  return "deuteron_S0_T0_1-_4";
    case DEUTERON_1_MINUS_S0_T0_5:  return "deuteron_S0_T0_1-_5";
    case DEUTERON_1_MINUS_S0_T0_6:  return "deuteron_S0_T0_1-_6";
    case DEUTERON_1_MINUS_S0_T0_7:  return "deuteron_S0_T0_1-_7";
    case DEUTERON_1_MINUS_S0_T0_8:  return "deuteron_S0_T0_1-_8";
    case DEUTERON_1_MINUS_S0_T0_9:  return "deuteron_S0_T0_1-_9";
    case DEUTERON_1_MINUS_S0_T0_10: return "deuteron_S0_T0_1-_10";
    case DEUTERON_1_MINUS_S0_T0_11: return "deuteron_S0_T0_1-_11";
    case DEUTERON_1_MINUS_S0_T0_12: return "deuteron_S0_T0_1-_12";
    case DEUTERON_1_MINUS_S0_T0_13: return "deuteron_S0_T0_1-_13";
    case DEUTERON_1_MINUS_S0_T0_14: return "deuteron_S0_T0_1-_14";
    case DEUTERON_1_MINUS_S0_T0_15: return "deuteron_S0_T0_1-_15";
    case DEUTERON_1_MINUS_S0_T0_16: return "deuteron_S0_T0_1-_16";
    case DEUTERON_1_MINUS_S0_T0_17: return "deuteron_S0_T0_1-_17";
    case DEUTERON_1_MINUS_S0_T0_18: return "deuteron_S0_T0_1-_18";
    case DEUTERON_1_MINUS_S0_T0_19: return "deuteron_S0_T0_1-_19";
    case DEUTERON_1_MINUS_S0_T0_20: return "deuteron_S0_T0_1-_20";
    case DEUTERON_1_MINUS_S0_T0_21: return "deuteron_S0_T0_1-_21";
    case DEUTERON_1_MINUS_S0_T0_22: return "deuteron_S0_T0_1-_22";
    case DEUTERON_1_MINUS_S0_T0_23: return "deuteron_S0_T0_1-_23";
    case DEUTERON_1_MINUS_S0_T0_24: return "deuteron_S0_T0_1-_24";
    case DEUTERON_1_MINUS_S0_T0_25: return "deuteron_S0_T0_1-_25";
    case DEUTERON_1_MINUS_S0_T0_26: return "deuteron_S0_T0_1-_26";
    case DEUTERON_1_MINUS_S0_T0_27: return "deuteron_S0_T0_1-_27";
    case DEUTERON_1_MINUS_S0_T0_28: return "deuteron_S0_T0_1-_28";
    case DEUTERON_1_MINUS_S0_T0_29: return "deuteron_S0_T0_1-_29";
    case DEUTERON_1_MINUS_S0_T0_30: return "deuteron_S0_T0_1-_30";
    case DEUTERON_1_MINUS_S0_T0_31: return "deuteron_S0_T0_1-_31";
    case DEUTERON_1_MINUS_S0_T0_32: return "deuteron_S0_T0_1-_32";
    case DEUTERON_1_MINUS_S0_T0_33: return "deuteron_S0_T0_1-_33";
    case DEUTERON_1_MINUS_S0_T0_34: return "deuteron_S0_T0_1-_34";
    case DEUTERON_1_MINUS_S0_T0_35: return "deuteron_S0_T0_1-_35";
    case DEUTERON_1_MINUS_S0_T0_36: return "deuteron_S0_T0_1-_36";
    case DEUTERON_1_MINUS_S0_T0_37: return "deuteron_S0_T0_1-_37";
    case DEUTERON_1_MINUS_S0_T0_38: return "deuteron_S0_T0_1-_38";
    case DEUTERON_1_MINUS_S0_T0_39: return "deuteron_S0_T0_1-_39";
    case DEUTERON_1_MINUS_S0_T0_40: return "deuteron_S0_T0_1-_40";
    case DEUTERON_1_MINUS_S0_T0_41: return "deuteron_S0_T0_1-_41";
    case DEUTERON_1_MINUS_S0_T0_42: return "deuteron_S0_T0_1-_42";
    case DEUTERON_1_MINUS_S0_T0_43: return "deuteron_S0_T0_1-_43";
    case DEUTERON_1_MINUS_S0_T0_44: return "deuteron_S0_T0_1-_44";
    case DEUTERON_1_MINUS_S0_T0_45: return "deuteron_S0_T0_1-_45";
    case DEUTERON_1_MINUS_S0_T0_46: return "deuteron_S0_T0_1-_46";
    case DEUTERON_1_MINUS_S0_T0_47: return "deuteron_S0_T0_1-_47";
    case DEUTERON_1_MINUS_S0_T0_48: return "deuteron_S0_T0_1-_48";
    case DEUTERON_1_MINUS_S0_T0_49: return "deuteron_S0_T0_1-_49";
    case DEUTERON_1_MINUS_S0_T0_50: return "deuteron_S0_T0_1-_50";
    case DEUTERON_1_MINUS_S0_T0_51: return "deuteron_S0_T0_1-_51";
    case DEUTERON_1_MINUS_S0_T0_52: return "deuteron_S0_T0_1-_52";
    case DEUTERON_1_MINUS_S0_T0_53: return "deuteron_S0_T0_1-_53";
    case DEUTERON_1_MINUS_S0_T0_54: return "deuteron_S0_T0_1-_54";
    case DEUTERON_1_MINUS_S0_T0_55: return "deuteron_S0_T0_1-_55";
    case DEUTERON_1_MINUS_S0_T0_56: return "deuteron_S0_T0_1-_56";
    case DEUTERON_1_MINUS_S0_T0_57: return "deuteron_S0_T0_1-_57";
    case DEUTERON_1_MINUS_S0_T0_58: return "deuteron_S0_T0_1-_58";
    case DEUTERON_1_MINUS_S0_T0_59: return "deuteron_S0_T0_1-_59";
    case DEUTERON_1_MINUS_S0_T0_60: return "deuteron_S0_T0_1-_60";
    case DEUTERON_1_MINUS_S0_T0_61: return "deuteron_S0_T0_1-_61";
    case DEUTERON_1_MINUS_S0_T0_62: return "deuteron_S0_T0_1-_62";
    case DEUTERON_1_MINUS_S0_T0_63: return "deuteron_S0_T0_1-_63";
    case DEUTERON_1_MINUS_S0_T0_64: return "deuteron_S0_T0_1-_64";
    case DEUTERON_1_MINUS_S0_T0_65: return "deuteron_S0_T0_1-_65";
    case DEUTERON_1_MINUS_S0_T0_66: return "deuteron_S0_T0_1-_66";
    case DEUTERON_1_MINUS_S0_T0_67: return "deuteron_S0_T0_1-_67";
    case DEUTERON_1_MINUS_S0_T0_68: return "deuteron_S0_T0_1-_68";
    case DEUTERON_1_MINUS_S0_T0_69: return "deuteron_S0_T0_1-_69";
    case DEUTERON_1_MINUS_S0_T0_70: return "deuteron_S0_T0_1-_70";
    case DEUTERON_1_MINUS_S0_T0_71: return "deuteron_S0_T0_1-_71";
    case DEUTERON_1_MINUS_S0_T0_72: return "deuteron_S0_T0_1-_72";
    case DEUTERON_1_MINUS_S0_T0_73: return "deuteron_S0_T0_1-_73";
    case DEUTERON_1_MINUS_S0_T0_74: return "deuteron_S0_T0_1-_74";
    case DEUTERON_1_MINUS_S0_T0_75: return "deuteron_S0_T0_1-_75";
    case DEUTERON_1_MINUS_S0_T0_76: return "deuteron_S0_T0_1-_76";
    case DEUTERON_1_MINUS_S0_T0_77: return "deuteron_S0_T0_1-_77";
    case DEUTERON_1_MINUS_S0_T0_78: return "deuteron_S0_T0_1-_78";
    case DEUTERON_1_MINUS_S0_T0_79: return "deuteron_S0_T0_1-_79";
    case DEUTERON_1_MINUS_S0_T0_80: return "deuteron_S0_T0_1-_80";
    case DEUTERON_1_MINUS_S0_T0_81: return "deuteron_S0_T0_1-_81";
    case DEUTERON_1_MINUS_S0_T0_82: return "deuteron_S0_T0_1-_82";
    case DEUTERON_1_MINUS_S0_T0_83: return "deuteron_S0_T0_1-_83";
    case DEUTERON_1_MINUS_S0_T0_84: return "deuteron_S0_T0_1-_84";
    case DEUTERON_1_MINUS_S0_T0_85: return "deuteron_S0_T0_1-_85";
    case DEUTERON_1_MINUS_S0_T0_86: return "deuteron_S0_T0_1-_86";
    case DEUTERON_1_MINUS_S0_T0_87: return "deuteron_S0_T0_1-_87";
    case DEUTERON_1_MINUS_S0_T0_88: return "deuteron_S0_T0_1-_88";
    case DEUTERON_1_MINUS_S0_T0_89: return "deuteron_S0_T0_1-_89";
    case DEUTERON_1_MINUS_S0_T0_90: return "deuteron_S0_T0_1-_90";
    case DEUTERON_1_MINUS_S0_T0_91: return "deuteron_S0_T0_1-_91";
    case DEUTERON_1_MINUS_S0_T0_92: return "deuteron_S0_T0_1-_92";
    case DEUTERON_1_MINUS_S0_T0_93: return "deuteron_S0_T0_1-_93";
    case DEUTERON_1_MINUS_S0_T0_94: return "deuteron_S0_T0_1-_94";
    case DEUTERON_1_MINUS_S0_T0_95: return "deuteron_S0_T0_1-_95";
    case DEUTERON_1_MINUS_S0_T0_96: return "deuteron_S0_T0_1-_96";
    case DEUTERON_1_MINUS_S0_T0_97: return "deuteron_S0_T0_1-_97";
    case DEUTERON_1_MINUS_S0_T0_98: return "deuteron_S0_T0_1-_98";
    case DEUTERON_1_MINUS_S0_T0_99: return "deuteron_S0_T0_1-_99";

    case DEUTERON_3_MINUS_S0_T0:    return "deuteron_S0_T0_3-";
    case DEUTERON_3_MINUS_S0_T0_0:  return "deuteron_S0_T0_3-_0";
    case DEUTERON_3_MINUS_S0_T0_1:  return "deuteron_S0_T0_3-_1";
    case DEUTERON_3_MINUS_S0_T0_2:  return "deuteron_S0_T0_3-_2";
    case DEUTERON_3_MINUS_S0_T0_3:  return "deuteron_S0_T0_3-_3";
    case DEUTERON_3_MINUS_S0_T0_4:  return "deuteron_S0_T0_3-_4";
    case DEUTERON_3_MINUS_S0_T0_5:  return "deuteron_S0_T0_3-_5";
    case DEUTERON_3_MINUS_S0_T0_6:  return "deuteron_S0_T0_3-_6";
    case DEUTERON_3_MINUS_S0_T0_7:  return "deuteron_S0_T0_3-_7";
    case DEUTERON_3_MINUS_S0_T0_8:  return "deuteron_S0_T0_3-_8";
    case DEUTERON_3_MINUS_S0_T0_9:  return "deuteron_S0_T0_3-_9";
    case DEUTERON_3_MINUS_S0_T0_10: return "deuteron_S0_T0_3-_10";
    case DEUTERON_3_MINUS_S0_T0_11: return "deuteron_S0_T0_3-_11";
    case DEUTERON_3_MINUS_S0_T0_12: return "deuteron_S0_T0_3-_12";
    case DEUTERON_3_MINUS_S0_T0_13: return "deuteron_S0_T0_3-_13";
    case DEUTERON_3_MINUS_S0_T0_14: return "deuteron_S0_T0_3-_14";
    case DEUTERON_3_MINUS_S0_T0_15: return "deuteron_S0_T0_3-_15";
    case DEUTERON_3_MINUS_S0_T0_16: return "deuteron_S0_T0_3-_16";
    case DEUTERON_3_MINUS_S0_T0_17: return "deuteron_S0_T0_3-_17";
    case DEUTERON_3_MINUS_S0_T0_18: return "deuteron_S0_T0_3-_18";
    case DEUTERON_3_MINUS_S0_T0_19: return "deuteron_S0_T0_3-_19";
    case DEUTERON_3_MINUS_S0_T0_20: return "deuteron_S0_T0_3-_20";
    case DEUTERON_3_MINUS_S0_T0_21: return "deuteron_S0_T0_3-_21";
    case DEUTERON_3_MINUS_S0_T0_22: return "deuteron_S0_T0_3-_22";
    case DEUTERON_3_MINUS_S0_T0_23: return "deuteron_S0_T0_3-_23";
    case DEUTERON_3_MINUS_S0_T0_24: return "deuteron_S0_T0_3-_24";
    case DEUTERON_3_MINUS_S0_T0_25: return "deuteron_S0_T0_3-_25";
    case DEUTERON_3_MINUS_S0_T0_26: return "deuteron_S0_T0_3-_26";
    case DEUTERON_3_MINUS_S0_T0_27: return "deuteron_S0_T0_3-_27";
    case DEUTERON_3_MINUS_S0_T0_28: return "deuteron_S0_T0_3-_28";
    case DEUTERON_3_MINUS_S0_T0_29: return "deuteron_S0_T0_3-_29";
    case DEUTERON_3_MINUS_S0_T0_30: return "deuteron_S0_T0_3-_30";
    case DEUTERON_3_MINUS_S0_T0_31: return "deuteron_S0_T0_3-_31";
    case DEUTERON_3_MINUS_S0_T0_32: return "deuteron_S0_T0_3-_32";
    case DEUTERON_3_MINUS_S0_T0_33: return "deuteron_S0_T0_3-_33";
    case DEUTERON_3_MINUS_S0_T0_34: return "deuteron_S0_T0_3-_34";
    case DEUTERON_3_MINUS_S0_T0_35: return "deuteron_S0_T0_3-_35";
    case DEUTERON_3_MINUS_S0_T0_36: return "deuteron_S0_T0_3-_36";
    case DEUTERON_3_MINUS_S0_T0_37: return "deuteron_S0_T0_3-_37";
    case DEUTERON_3_MINUS_S0_T0_38: return "deuteron_S0_T0_3-_38";
    case DEUTERON_3_MINUS_S0_T0_39: return "deuteron_S0_T0_3-_39";
    case DEUTERON_3_MINUS_S0_T0_40: return "deuteron_S0_T0_3-_40";
    case DEUTERON_3_MINUS_S0_T0_41: return "deuteron_S0_T0_3-_41";
    case DEUTERON_3_MINUS_S0_T0_42: return "deuteron_S0_T0_3-_42";
    case DEUTERON_3_MINUS_S0_T0_43: return "deuteron_S0_T0_3-_43";
    case DEUTERON_3_MINUS_S0_T0_44: return "deuteron_S0_T0_3-_44";
    case DEUTERON_3_MINUS_S0_T0_45: return "deuteron_S0_T0_3-_45";
    case DEUTERON_3_MINUS_S0_T0_46: return "deuteron_S0_T0_3-_46";
    case DEUTERON_3_MINUS_S0_T0_47: return "deuteron_S0_T0_3-_47";
    case DEUTERON_3_MINUS_S0_T0_48: return "deuteron_S0_T0_3-_48";
    case DEUTERON_3_MINUS_S0_T0_49: return "deuteron_S0_T0_3-_49";
    case DEUTERON_3_MINUS_S0_T0_50: return "deuteron_S0_T0_3-_50";
    case DEUTERON_3_MINUS_S0_T0_51: return "deuteron_S0_T0_3-_51";
    case DEUTERON_3_MINUS_S0_T0_52: return "deuteron_S0_T0_3-_52";
    case DEUTERON_3_MINUS_S0_T0_53: return "deuteron_S0_T0_3-_53";
    case DEUTERON_3_MINUS_S0_T0_54: return "deuteron_S0_T0_3-_54";
    case DEUTERON_3_MINUS_S0_T0_55: return "deuteron_S0_T0_3-_55";
    case DEUTERON_3_MINUS_S0_T0_56: return "deuteron_S0_T0_3-_56";
    case DEUTERON_3_MINUS_S0_T0_57: return "deuteron_S0_T0_3-_57";
    case DEUTERON_3_MINUS_S0_T0_58: return "deuteron_S0_T0_3-_58";
    case DEUTERON_3_MINUS_S0_T0_59: return "deuteron_S0_T0_3-_59";
    case DEUTERON_3_MINUS_S0_T0_60: return "deuteron_S0_T0_3-_60";
    case DEUTERON_3_MINUS_S0_T0_61: return "deuteron_S0_T0_3-_61";
    case DEUTERON_3_MINUS_S0_T0_62: return "deuteron_S0_T0_3-_62";
    case DEUTERON_3_MINUS_S0_T0_63: return "deuteron_S0_T0_3-_63";
    case DEUTERON_3_MINUS_S0_T0_64: return "deuteron_S0_T0_3-_64";
    case DEUTERON_3_MINUS_S0_T0_65: return "deuteron_S0_T0_3-_65";
    case DEUTERON_3_MINUS_S0_T0_66: return "deuteron_S0_T0_3-_66";
    case DEUTERON_3_MINUS_S0_T0_67: return "deuteron_S0_T0_3-_67";
    case DEUTERON_3_MINUS_S0_T0_68: return "deuteron_S0_T0_3-_68";
    case DEUTERON_3_MINUS_S0_T0_69: return "deuteron_S0_T0_3-_69";
    case DEUTERON_3_MINUS_S0_T0_70: return "deuteron_S0_T0_3-_70";
    case DEUTERON_3_MINUS_S0_T0_71: return "deuteron_S0_T0_3-_71";
    case DEUTERON_3_MINUS_S0_T0_72: return "deuteron_S0_T0_3-_72";
    case DEUTERON_3_MINUS_S0_T0_73: return "deuteron_S0_T0_3-_73";
    case DEUTERON_3_MINUS_S0_T0_74: return "deuteron_S0_T0_3-_74";
    case DEUTERON_3_MINUS_S0_T0_75: return "deuteron_S0_T0_3-_75";
    case DEUTERON_3_MINUS_S0_T0_76: return "deuteron_S0_T0_3-_76";
    case DEUTERON_3_MINUS_S0_T0_77: return "deuteron_S0_T0_3-_77";
    case DEUTERON_3_MINUS_S0_T0_78: return "deuteron_S0_T0_3-_78";
    case DEUTERON_3_MINUS_S0_T0_79: return "deuteron_S0_T0_3-_79";
    case DEUTERON_3_MINUS_S0_T0_80: return "deuteron_S0_T0_3-_80";
    case DEUTERON_3_MINUS_S0_T0_81: return "deuteron_S0_T0_3-_81";
    case DEUTERON_3_MINUS_S0_T0_82: return "deuteron_S0_T0_3-_82";
    case DEUTERON_3_MINUS_S0_T0_83: return "deuteron_S0_T0_3-_83";
    case DEUTERON_3_MINUS_S0_T0_84: return "deuteron_S0_T0_3-_84";
    case DEUTERON_3_MINUS_S0_T0_85: return "deuteron_S0_T0_3-_85";
    case DEUTERON_3_MINUS_S0_T0_86: return "deuteron_S0_T0_3-_86";
    case DEUTERON_3_MINUS_S0_T0_87: return "deuteron_S0_T0_3-_87";
    case DEUTERON_3_MINUS_S0_T0_88: return "deuteron_S0_T0_3-_88";
    case DEUTERON_3_MINUS_S0_T0_89: return "deuteron_S0_T0_3-_89";
    case DEUTERON_3_MINUS_S0_T0_90: return "deuteron_S0_T0_3-_90";
    case DEUTERON_3_MINUS_S0_T0_91: return "deuteron_S0_T0_3-_91";
    case DEUTERON_3_MINUS_S0_T0_92: return "deuteron_S0_T0_3-_92";
    case DEUTERON_3_MINUS_S0_T0_93: return "deuteron_S0_T0_3-_93";
    case DEUTERON_3_MINUS_S0_T0_94: return "deuteron_S0_T0_3-_94";
    case DEUTERON_3_MINUS_S0_T0_95: return "deuteron_S0_T0_3-_95";
    case DEUTERON_3_MINUS_S0_T0_96: return "deuteron_S0_T0_3-_96";
    case DEUTERON_3_MINUS_S0_T0_97: return "deuteron_S0_T0_3-_97";
    case DEUTERON_3_MINUS_S0_T0_98: return "deuteron_S0_T0_3-_98";
    case DEUTERON_3_MINUS_S0_T0_99: return "deuteron_S0_T0_3-_99";

    case DEUTERON_5_MINUS_S0_T0:    return "deuteron_S0_T0_5-";
    case DEUTERON_5_MINUS_S0_T0_0:  return "deuteron_S0_T0_5-_0";
    case DEUTERON_5_MINUS_S0_T0_1:  return "deuteron_S0_T0_5-_1";
    case DEUTERON_5_MINUS_S0_T0_2:  return "deuteron_S0_T0_5-_2";
    case DEUTERON_5_MINUS_S0_T0_3:  return "deuteron_S0_T0_5-_3";
    case DEUTERON_5_MINUS_S0_T0_4:  return "deuteron_S0_T0_5-_4";
    case DEUTERON_5_MINUS_S0_T0_5:  return "deuteron_S0_T0_5-_5";
    case DEUTERON_5_MINUS_S0_T0_6:  return "deuteron_S0_T0_5-_6";
    case DEUTERON_5_MINUS_S0_T0_7:  return "deuteron_S0_T0_5-_7";
    case DEUTERON_5_MINUS_S0_T0_8:  return "deuteron_S0_T0_5-_8";
    case DEUTERON_5_MINUS_S0_T0_9:  return "deuteron_S0_T0_5-_9";
    case DEUTERON_5_MINUS_S0_T0_10: return "deuteron_S0_T0_5-_10";
    case DEUTERON_5_MINUS_S0_T0_11: return "deuteron_S0_T0_5-_11";
    case DEUTERON_5_MINUS_S0_T0_12: return "deuteron_S0_T0_5-_12";
    case DEUTERON_5_MINUS_S0_T0_13: return "deuteron_S0_T0_5-_13";
    case DEUTERON_5_MINUS_S0_T0_14: return "deuteron_S0_T0_5-_14";
    case DEUTERON_5_MINUS_S0_T0_15: return "deuteron_S0_T0_5-_15";
    case DEUTERON_5_MINUS_S0_T0_16: return "deuteron_S0_T0_5-_16";
    case DEUTERON_5_MINUS_S0_T0_17: return "deuteron_S0_T0_5-_17";
    case DEUTERON_5_MINUS_S0_T0_18: return "deuteron_S0_T0_5-_18";
    case DEUTERON_5_MINUS_S0_T0_19: return "deuteron_S0_T0_5-_19";
    case DEUTERON_5_MINUS_S0_T0_20: return "deuteron_S0_T0_5-_20";
    case DEUTERON_5_MINUS_S0_T0_21: return "deuteron_S0_T0_5-_21";
    case DEUTERON_5_MINUS_S0_T0_22: return "deuteron_S0_T0_5-_22";
    case DEUTERON_5_MINUS_S0_T0_23: return "deuteron_S0_T0_5-_23";
    case DEUTERON_5_MINUS_S0_T0_24: return "deuteron_S0_T0_5-_24";
    case DEUTERON_5_MINUS_S0_T0_25: return "deuteron_S0_T0_5-_25";
    case DEUTERON_5_MINUS_S0_T0_26: return "deuteron_S0_T0_5-_26";
    case DEUTERON_5_MINUS_S0_T0_27: return "deuteron_S0_T0_5-_27";
    case DEUTERON_5_MINUS_S0_T0_28: return "deuteron_S0_T0_5-_28";
    case DEUTERON_5_MINUS_S0_T0_29: return "deuteron_S0_T0_5-_29";
    case DEUTERON_5_MINUS_S0_T0_30: return "deuteron_S0_T0_5-_30";
    case DEUTERON_5_MINUS_S0_T0_31: return "deuteron_S0_T0_5-_31";
    case DEUTERON_5_MINUS_S0_T0_32: return "deuteron_S0_T0_5-_32";
    case DEUTERON_5_MINUS_S0_T0_33: return "deuteron_S0_T0_5-_33";
    case DEUTERON_5_MINUS_S0_T0_34: return "deuteron_S0_T0_5-_34";
    case DEUTERON_5_MINUS_S0_T0_35: return "deuteron_S0_T0_5-_35";
    case DEUTERON_5_MINUS_S0_T0_36: return "deuteron_S0_T0_5-_36";
    case DEUTERON_5_MINUS_S0_T0_37: return "deuteron_S0_T0_5-_37";
    case DEUTERON_5_MINUS_S0_T0_38: return "deuteron_S0_T0_5-_38";
    case DEUTERON_5_MINUS_S0_T0_39: return "deuteron_S0_T0_5-_39";
    case DEUTERON_5_MINUS_S0_T0_40: return "deuteron_S0_T0_5-_40";
    case DEUTERON_5_MINUS_S0_T0_41: return "deuteron_S0_T0_5-_41";
    case DEUTERON_5_MINUS_S0_T0_42: return "deuteron_S0_T0_5-_42";
    case DEUTERON_5_MINUS_S0_T0_43: return "deuteron_S0_T0_5-_43";
    case DEUTERON_5_MINUS_S0_T0_44: return "deuteron_S0_T0_5-_44";
    case DEUTERON_5_MINUS_S0_T0_45: return "deuteron_S0_T0_5-_45";
    case DEUTERON_5_MINUS_S0_T0_46: return "deuteron_S0_T0_5-_46";
    case DEUTERON_5_MINUS_S0_T0_47: return "deuteron_S0_T0_5-_47";
    case DEUTERON_5_MINUS_S0_T0_48: return "deuteron_S0_T0_5-_48";
    case DEUTERON_5_MINUS_S0_T0_49: return "deuteron_S0_T0_5-_49";
    case DEUTERON_5_MINUS_S0_T0_50: return "deuteron_S0_T0_5-_50";
    case DEUTERON_5_MINUS_S0_T0_51: return "deuteron_S0_T0_5-_51";
    case DEUTERON_5_MINUS_S0_T0_52: return "deuteron_S0_T0_5-_52";
    case DEUTERON_5_MINUS_S0_T0_53: return "deuteron_S0_T0_5-_53";
    case DEUTERON_5_MINUS_S0_T0_54: return "deuteron_S0_T0_5-_54";
    case DEUTERON_5_MINUS_S0_T0_55: return "deuteron_S0_T0_5-_55";
    case DEUTERON_5_MINUS_S0_T0_56: return "deuteron_S0_T0_5-_56";
    case DEUTERON_5_MINUS_S0_T0_57: return "deuteron_S0_T0_5-_57";
    case DEUTERON_5_MINUS_S0_T0_58: return "deuteron_S0_T0_5-_58";
    case DEUTERON_5_MINUS_S0_T0_59: return "deuteron_S0_T0_5-_59";
    case DEUTERON_5_MINUS_S0_T0_60: return "deuteron_S0_T0_5-_60";
    case DEUTERON_5_MINUS_S0_T0_61: return "deuteron_S0_T0_5-_61";
    case DEUTERON_5_MINUS_S0_T0_62: return "deuteron_S0_T0_5-_62";
    case DEUTERON_5_MINUS_S0_T0_63: return "deuteron_S0_T0_5-_63";
    case DEUTERON_5_MINUS_S0_T0_64: return "deuteron_S0_T0_5-_64";
    case DEUTERON_5_MINUS_S0_T0_65: return "deuteron_S0_T0_5-_65";
    case DEUTERON_5_MINUS_S0_T0_66: return "deuteron_S0_T0_5-_66";
    case DEUTERON_5_MINUS_S0_T0_67: return "deuteron_S0_T0_5-_67";
    case DEUTERON_5_MINUS_S0_T0_68: return "deuteron_S0_T0_5-_68";
    case DEUTERON_5_MINUS_S0_T0_69: return "deuteron_S0_T0_5-_69";
    case DEUTERON_5_MINUS_S0_T0_70: return "deuteron_S0_T0_5-_70";
    case DEUTERON_5_MINUS_S0_T0_71: return "deuteron_S0_T0_5-_71";
    case DEUTERON_5_MINUS_S0_T0_72: return "deuteron_S0_T0_5-_72";
    case DEUTERON_5_MINUS_S0_T0_73: return "deuteron_S0_T0_5-_73";
    case DEUTERON_5_MINUS_S0_T0_74: return "deuteron_S0_T0_5-_74";
    case DEUTERON_5_MINUS_S0_T0_75: return "deuteron_S0_T0_5-_75";
    case DEUTERON_5_MINUS_S0_T0_76: return "deuteron_S0_T0_5-_76";
    case DEUTERON_5_MINUS_S0_T0_77: return "deuteron_S0_T0_5-_77";
    case DEUTERON_5_MINUS_S0_T0_78: return "deuteron_S0_T0_5-_78";
    case DEUTERON_5_MINUS_S0_T0_79: return "deuteron_S0_T0_5-_79";
    case DEUTERON_5_MINUS_S0_T0_80: return "deuteron_S0_T0_5-_80";
    case DEUTERON_5_MINUS_S0_T0_81: return "deuteron_S0_T0_5-_81";
    case DEUTERON_5_MINUS_S0_T0_82: return "deuteron_S0_T0_5-_82";
    case DEUTERON_5_MINUS_S0_T0_83: return "deuteron_S0_T0_5-_83";
    case DEUTERON_5_MINUS_S0_T0_84: return "deuteron_S0_T0_5-_84";
    case DEUTERON_5_MINUS_S0_T0_85: return "deuteron_S0_T0_5-_85";
    case DEUTERON_5_MINUS_S0_T0_86: return "deuteron_S0_T0_5-_86";
    case DEUTERON_5_MINUS_S0_T0_87: return "deuteron_S0_T0_5-_87";
    case DEUTERON_5_MINUS_S0_T0_88: return "deuteron_S0_T0_5-_88";
    case DEUTERON_5_MINUS_S0_T0_89: return "deuteron_S0_T0_5-_89";
    case DEUTERON_5_MINUS_S0_T0_90: return "deuteron_S0_T0_5-_90";
    case DEUTERON_5_MINUS_S0_T0_91: return "deuteron_S0_T0_5-_91";
    case DEUTERON_5_MINUS_S0_T0_92: return "deuteron_S0_T0_5-_92";
    case DEUTERON_5_MINUS_S0_T0_93: return "deuteron_S0_T0_5-_93";
    case DEUTERON_5_MINUS_S0_T0_94: return "deuteron_S0_T0_5-_94";
    case DEUTERON_5_MINUS_S0_T0_95: return "deuteron_S0_T0_5-_95";
    case DEUTERON_5_MINUS_S0_T0_96: return "deuteron_S0_T0_5-_96";
    case DEUTERON_5_MINUS_S0_T0_97: return "deuteron_S0_T0_5-_97";
    case DEUTERON_5_MINUS_S0_T0_98: return "deuteron_S0_T0_5-_98";
    case DEUTERON_5_MINUS_S0_T0_99: return "deuteron_S0_T0_5-_99";

    case DEUTERON_0_PLUS_S0_T1:    return "deuteron_S0_T1_0+";
    case DEUTERON_0_PLUS_S0_T1_0:  return "deuteron_S0_T1_0+_0";
    case DEUTERON_0_PLUS_S0_T1_1:  return "deuteron_S0_T1_0+_1";
    case DEUTERON_0_PLUS_S0_T1_2:  return "deuteron_S0_T1_0+_2";
    case DEUTERON_0_PLUS_S0_T1_3:  return "deuteron_S0_T1_0+_3";
    case DEUTERON_0_PLUS_S0_T1_4:  return "deuteron_S0_T1_0+_4";
    case DEUTERON_0_PLUS_S0_T1_5:  return "deuteron_S0_T1_0+_5";
    case DEUTERON_0_PLUS_S0_T1_6:  return "deuteron_S0_T1_0+_6";
    case DEUTERON_0_PLUS_S0_T1_7:  return "deuteron_S0_T1_0+_7";
    case DEUTERON_0_PLUS_S0_T1_8:  return "deuteron_S0_T1_0+_8";
    case DEUTERON_0_PLUS_S0_T1_9:  return "deuteron_S0_T1_0+_9";
    case DEUTERON_0_PLUS_S0_T1_10: return "deuteron_S0_T1_0+_10";
    case DEUTERON_0_PLUS_S0_T1_11: return "deuteron_S0_T1_0+_11";
    case DEUTERON_0_PLUS_S0_T1_12: return "deuteron_S0_T1_0+_12";
    case DEUTERON_0_PLUS_S0_T1_13: return "deuteron_S0_T1_0+_13";
    case DEUTERON_0_PLUS_S0_T1_14: return "deuteron_S0_T1_0+_14";
    case DEUTERON_0_PLUS_S0_T1_15: return "deuteron_S0_T1_0+_15";
    case DEUTERON_0_PLUS_S0_T1_16: return "deuteron_S0_T1_0+_16";
    case DEUTERON_0_PLUS_S0_T1_17: return "deuteron_S0_T1_0+_17";
    case DEUTERON_0_PLUS_S0_T1_18: return "deuteron_S0_T1_0+_18";
    case DEUTERON_0_PLUS_S0_T1_19: return "deuteron_S0_T1_0+_19";
    case DEUTERON_0_PLUS_S0_T1_20: return "deuteron_S0_T1_0+_20";
    case DEUTERON_0_PLUS_S0_T1_21: return "deuteron_S0_T1_0+_21";
    case DEUTERON_0_PLUS_S0_T1_22: return "deuteron_S0_T1_0+_22";
    case DEUTERON_0_PLUS_S0_T1_23: return "deuteron_S0_T1_0+_23";
    case DEUTERON_0_PLUS_S0_T1_24: return "deuteron_S0_T1_0+_24";
    case DEUTERON_0_PLUS_S0_T1_25: return "deuteron_S0_T1_0+_25";
    case DEUTERON_0_PLUS_S0_T1_26: return "deuteron_S0_T1_0+_26";
    case DEUTERON_0_PLUS_S0_T1_27: return "deuteron_S0_T1_0+_27";
    case DEUTERON_0_PLUS_S0_T1_28: return "deuteron_S0_T1_0+_28";
    case DEUTERON_0_PLUS_S0_T1_29: return "deuteron_S0_T1_0+_29";
    case DEUTERON_0_PLUS_S0_T1_30: return "deuteron_S0_T1_0+_30";
    case DEUTERON_0_PLUS_S0_T1_31: return "deuteron_S0_T1_0+_31";
    case DEUTERON_0_PLUS_S0_T1_32: return "deuteron_S0_T1_0+_32";
    case DEUTERON_0_PLUS_S0_T1_33: return "deuteron_S0_T1_0+_33";
    case DEUTERON_0_PLUS_S0_T1_34: return "deuteron_S0_T1_0+_34";
    case DEUTERON_0_PLUS_S0_T1_35: return "deuteron_S0_T1_0+_35";
    case DEUTERON_0_PLUS_S0_T1_36: return "deuteron_S0_T1_0+_36";
    case DEUTERON_0_PLUS_S0_T1_37: return "deuteron_S0_T1_0+_37";
    case DEUTERON_0_PLUS_S0_T1_38: return "deuteron_S0_T1_0+_38";
    case DEUTERON_0_PLUS_S0_T1_39: return "deuteron_S0_T1_0+_39";
    case DEUTERON_0_PLUS_S0_T1_40: return "deuteron_S0_T1_0+_40";
    case DEUTERON_0_PLUS_S0_T1_41: return "deuteron_S0_T1_0+_41";
    case DEUTERON_0_PLUS_S0_T1_42: return "deuteron_S0_T1_0+_42";
    case DEUTERON_0_PLUS_S0_T1_43: return "deuteron_S0_T1_0+_43";
    case DEUTERON_0_PLUS_S0_T1_44: return "deuteron_S0_T1_0+_44";
    case DEUTERON_0_PLUS_S0_T1_45: return "deuteron_S0_T1_0+_45";
    case DEUTERON_0_PLUS_S0_T1_46: return "deuteron_S0_T1_0+_46";
    case DEUTERON_0_PLUS_S0_T1_47: return "deuteron_S0_T1_0+_47";
    case DEUTERON_0_PLUS_S0_T1_48: return "deuteron_S0_T1_0+_48";
    case DEUTERON_0_PLUS_S0_T1_49: return "deuteron_S0_T1_0+_49";
    case DEUTERON_0_PLUS_S0_T1_50: return "deuteron_S0_T1_0+_50";
    case DEUTERON_0_PLUS_S0_T1_51: return "deuteron_S0_T1_0+_51";
    case DEUTERON_0_PLUS_S0_T1_52: return "deuteron_S0_T1_0+_52";
    case DEUTERON_0_PLUS_S0_T1_53: return "deuteron_S0_T1_0+_53";
    case DEUTERON_0_PLUS_S0_T1_54: return "deuteron_S0_T1_0+_54";
    case DEUTERON_0_PLUS_S0_T1_55: return "deuteron_S0_T1_0+_55";
    case DEUTERON_0_PLUS_S0_T1_56: return "deuteron_S0_T1_0+_56";
    case DEUTERON_0_PLUS_S0_T1_57: return "deuteron_S0_T1_0+_57";
    case DEUTERON_0_PLUS_S0_T1_58: return "deuteron_S0_T1_0+_58";
    case DEUTERON_0_PLUS_S0_T1_59: return "deuteron_S0_T1_0+_59";
    case DEUTERON_0_PLUS_S0_T1_60: return "deuteron_S0_T1_0+_60";
    case DEUTERON_0_PLUS_S0_T1_61: return "deuteron_S0_T1_0+_61";
    case DEUTERON_0_PLUS_S0_T1_62: return "deuteron_S0_T1_0+_62";
    case DEUTERON_0_PLUS_S0_T1_63: return "deuteron_S0_T1_0+_63";
    case DEUTERON_0_PLUS_S0_T1_64: return "deuteron_S0_T1_0+_64";
    case DEUTERON_0_PLUS_S0_T1_65: return "deuteron_S0_T1_0+_65";
    case DEUTERON_0_PLUS_S0_T1_66: return "deuteron_S0_T1_0+_66";
    case DEUTERON_0_PLUS_S0_T1_67: return "deuteron_S0_T1_0+_67";
    case DEUTERON_0_PLUS_S0_T1_68: return "deuteron_S0_T1_0+_68";
    case DEUTERON_0_PLUS_S0_T1_69: return "deuteron_S0_T1_0+_69";
    case DEUTERON_0_PLUS_S0_T1_70: return "deuteron_S0_T1_0+_70";
    case DEUTERON_0_PLUS_S0_T1_71: return "deuteron_S0_T1_0+_71";
    case DEUTERON_0_PLUS_S0_T1_72: return "deuteron_S0_T1_0+_72";
    case DEUTERON_0_PLUS_S0_T1_73: return "deuteron_S0_T1_0+_73";
    case DEUTERON_0_PLUS_S0_T1_74: return "deuteron_S0_T1_0+_74";
    case DEUTERON_0_PLUS_S0_T1_75: return "deuteron_S0_T1_0+_75";
    case DEUTERON_0_PLUS_S0_T1_76: return "deuteron_S0_T1_0+_76";
    case DEUTERON_0_PLUS_S0_T1_77: return "deuteron_S0_T1_0+_77";
    case DEUTERON_0_PLUS_S0_T1_78: return "deuteron_S0_T1_0+_78";
    case DEUTERON_0_PLUS_S0_T1_79: return "deuteron_S0_T1_0+_79";
    case DEUTERON_0_PLUS_S0_T1_80: return "deuteron_S0_T1_0+_80";
    case DEUTERON_0_PLUS_S0_T1_81: return "deuteron_S0_T1_0+_81";
    case DEUTERON_0_PLUS_S0_T1_82: return "deuteron_S0_T1_0+_82";
    case DEUTERON_0_PLUS_S0_T1_83: return "deuteron_S0_T1_0+_83";
    case DEUTERON_0_PLUS_S0_T1_84: return "deuteron_S0_T1_0+_84";
    case DEUTERON_0_PLUS_S0_T1_85: return "deuteron_S0_T1_0+_85";
    case DEUTERON_0_PLUS_S0_T1_86: return "deuteron_S0_T1_0+_86";
    case DEUTERON_0_PLUS_S0_T1_87: return "deuteron_S0_T1_0+_87";
    case DEUTERON_0_PLUS_S0_T1_88: return "deuteron_S0_T1_0+_88";
    case DEUTERON_0_PLUS_S0_T1_89: return "deuteron_S0_T1_0+_89";
    case DEUTERON_0_PLUS_S0_T1_90: return "deuteron_S0_T1_0+_90";
    case DEUTERON_0_PLUS_S0_T1_91: return "deuteron_S0_T1_0+_91";
    case DEUTERON_0_PLUS_S0_T1_92: return "deuteron_S0_T1_0+_92";
    case DEUTERON_0_PLUS_S0_T1_93: return "deuteron_S0_T1_0+_93";
    case DEUTERON_0_PLUS_S0_T1_94: return "deuteron_S0_T1_0+_94";
    case DEUTERON_0_PLUS_S0_T1_95: return "deuteron_S0_T1_0+_95";
    case DEUTERON_0_PLUS_S0_T1_96: return "deuteron_S0_T1_0+_96";
    case DEUTERON_0_PLUS_S0_T1_97: return "deuteron_S0_T1_0+_97";
    case DEUTERON_0_PLUS_S0_T1_98: return "deuteron_S0_T1_0+_98";
    case DEUTERON_0_PLUS_S0_T1_99: return "deuteron_S0_T1_0+_99";

    case DEUTERON_2_PLUS_S0_T1:    return "deuteron_S0_T1_2+";
    case DEUTERON_2_PLUS_S0_T1_0:  return "deuteron_S0_T1_2+_0";
    case DEUTERON_2_PLUS_S0_T1_1:  return "deuteron_S0_T1_2+_1";
    case DEUTERON_2_PLUS_S0_T1_2:  return "deuteron_S0_T1_2+_2";
    case DEUTERON_2_PLUS_S0_T1_3:  return "deuteron_S0_T1_2+_3";
    case DEUTERON_2_PLUS_S0_T1_4:  return "deuteron_S0_T1_2+_4";
    case DEUTERON_2_PLUS_S0_T1_5:  return "deuteron_S0_T1_2+_5";
    case DEUTERON_2_PLUS_S0_T1_6:  return "deuteron_S0_T1_2+_6";
    case DEUTERON_2_PLUS_S0_T1_7:  return "deuteron_S0_T1_2+_7";
    case DEUTERON_2_PLUS_S0_T1_8:  return "deuteron_S0_T1_2+_8";
    case DEUTERON_2_PLUS_S0_T1_9:  return "deuteron_S0_T1_2+_9";
    case DEUTERON_2_PLUS_S0_T1_10: return "deuteron_S0_T1_2+_10";
    case DEUTERON_2_PLUS_S0_T1_11: return "deuteron_S0_T1_2+_11";
    case DEUTERON_2_PLUS_S0_T1_12: return "deuteron_S0_T1_2+_12";
    case DEUTERON_2_PLUS_S0_T1_13: return "deuteron_S0_T1_2+_13";
    case DEUTERON_2_PLUS_S0_T1_14: return "deuteron_S0_T1_2+_14";
    case DEUTERON_2_PLUS_S0_T1_15: return "deuteron_S0_T1_2+_15";
    case DEUTERON_2_PLUS_S0_T1_16: return "deuteron_S0_T1_2+_16";
    case DEUTERON_2_PLUS_S0_T1_17: return "deuteron_S0_T1_2+_17";
    case DEUTERON_2_PLUS_S0_T1_18: return "deuteron_S0_T1_2+_18";
    case DEUTERON_2_PLUS_S0_T1_19: return "deuteron_S0_T1_2+_19";
    case DEUTERON_2_PLUS_S0_T1_20: return "deuteron_S0_T1_2+_20";
    case DEUTERON_2_PLUS_S0_T1_21: return "deuteron_S0_T1_2+_21";
    case DEUTERON_2_PLUS_S0_T1_22: return "deuteron_S0_T1_2+_22";
    case DEUTERON_2_PLUS_S0_T1_23: return "deuteron_S0_T1_2+_23";
    case DEUTERON_2_PLUS_S0_T1_24: return "deuteron_S0_T1_2+_24";
    case DEUTERON_2_PLUS_S0_T1_25: return "deuteron_S0_T1_2+_25";
    case DEUTERON_2_PLUS_S0_T1_26: return "deuteron_S0_T1_2+_26";
    case DEUTERON_2_PLUS_S0_T1_27: return "deuteron_S0_T1_2+_27";
    case DEUTERON_2_PLUS_S0_T1_28: return "deuteron_S0_T1_2+_28";
    case DEUTERON_2_PLUS_S0_T1_29: return "deuteron_S0_T1_2+_29";
    case DEUTERON_2_PLUS_S0_T1_30: return "deuteron_S0_T1_2+_30";
    case DEUTERON_2_PLUS_S0_T1_31: return "deuteron_S0_T1_2+_31";
    case DEUTERON_2_PLUS_S0_T1_32: return "deuteron_S0_T1_2+_32";
    case DEUTERON_2_PLUS_S0_T1_33: return "deuteron_S0_T1_2+_33";
    case DEUTERON_2_PLUS_S0_T1_34: return "deuteron_S0_T1_2+_34";
    case DEUTERON_2_PLUS_S0_T1_35: return "deuteron_S0_T1_2+_35";
    case DEUTERON_2_PLUS_S0_T1_36: return "deuteron_S0_T1_2+_36";
    case DEUTERON_2_PLUS_S0_T1_37: return "deuteron_S0_T1_2+_37";
    case DEUTERON_2_PLUS_S0_T1_38: return "deuteron_S0_T1_2+_38";
    case DEUTERON_2_PLUS_S0_T1_39: return "deuteron_S0_T1_2+_39";
    case DEUTERON_2_PLUS_S0_T1_40: return "deuteron_S0_T1_2+_40";
    case DEUTERON_2_PLUS_S0_T1_41: return "deuteron_S0_T1_2+_41";
    case DEUTERON_2_PLUS_S0_T1_42: return "deuteron_S0_T1_2+_42";
    case DEUTERON_2_PLUS_S0_T1_43: return "deuteron_S0_T1_2+_43";
    case DEUTERON_2_PLUS_S0_T1_44: return "deuteron_S0_T1_2+_44";
    case DEUTERON_2_PLUS_S0_T1_45: return "deuteron_S0_T1_2+_45";
    case DEUTERON_2_PLUS_S0_T1_46: return "deuteron_S0_T1_2+_46";
    case DEUTERON_2_PLUS_S0_T1_47: return "deuteron_S0_T1_2+_47";
    case DEUTERON_2_PLUS_S0_T1_48: return "deuteron_S0_T1_2+_48";
    case DEUTERON_2_PLUS_S0_T1_49: return "deuteron_S0_T1_2+_49";
    case DEUTERON_2_PLUS_S0_T1_50: return "deuteron_S0_T1_2+_50";
    case DEUTERON_2_PLUS_S0_T1_51: return "deuteron_S0_T1_2+_51";
    case DEUTERON_2_PLUS_S0_T1_52: return "deuteron_S0_T1_2+_52";
    case DEUTERON_2_PLUS_S0_T1_53: return "deuteron_S0_T1_2+_53";
    case DEUTERON_2_PLUS_S0_T1_54: return "deuteron_S0_T1_2+_54";
    case DEUTERON_2_PLUS_S0_T1_55: return "deuteron_S0_T1_2+_55";
    case DEUTERON_2_PLUS_S0_T1_56: return "deuteron_S0_T1_2+_56";
    case DEUTERON_2_PLUS_S0_T1_57: return "deuteron_S0_T1_2+_57";
    case DEUTERON_2_PLUS_S0_T1_58: return "deuteron_S0_T1_2+_58";
    case DEUTERON_2_PLUS_S0_T1_59: return "deuteron_S0_T1_2+_59";
    case DEUTERON_2_PLUS_S0_T1_60: return "deuteron_S0_T1_2+_60";
    case DEUTERON_2_PLUS_S0_T1_61: return "deuteron_S0_T1_2+_61";
    case DEUTERON_2_PLUS_S0_T1_62: return "deuteron_S0_T1_2+_62";
    case DEUTERON_2_PLUS_S0_T1_63: return "deuteron_S0_T1_2+_63";
    case DEUTERON_2_PLUS_S0_T1_64: return "deuteron_S0_T1_2+_64";
    case DEUTERON_2_PLUS_S0_T1_65: return "deuteron_S0_T1_2+_65";
    case DEUTERON_2_PLUS_S0_T1_66: return "deuteron_S0_T1_2+_66";
    case DEUTERON_2_PLUS_S0_T1_67: return "deuteron_S0_T1_2+_67";
    case DEUTERON_2_PLUS_S0_T1_68: return "deuteron_S0_T1_2+_68";
    case DEUTERON_2_PLUS_S0_T1_69: return "deuteron_S0_T1_2+_69";
    case DEUTERON_2_PLUS_S0_T1_70: return "deuteron_S0_T1_2+_70";
    case DEUTERON_2_PLUS_S0_T1_71: return "deuteron_S0_T1_2+_71";
    case DEUTERON_2_PLUS_S0_T1_72: return "deuteron_S0_T1_2+_72";
    case DEUTERON_2_PLUS_S0_T1_73: return "deuteron_S0_T1_2+_73";
    case DEUTERON_2_PLUS_S0_T1_74: return "deuteron_S0_T1_2+_74";
    case DEUTERON_2_PLUS_S0_T1_75: return "deuteron_S0_T1_2+_75";
    case DEUTERON_2_PLUS_S0_T1_76: return "deuteron_S0_T1_2+_76";
    case DEUTERON_2_PLUS_S0_T1_77: return "deuteron_S0_T1_2+_77";
    case DEUTERON_2_PLUS_S0_T1_78: return "deuteron_S0_T1_2+_78";
    case DEUTERON_2_PLUS_S0_T1_79: return "deuteron_S0_T1_2+_79";
    case DEUTERON_2_PLUS_S0_T1_80: return "deuteron_S0_T1_2+_80";
    case DEUTERON_2_PLUS_S0_T1_81: return "deuteron_S0_T1_2+_81";
    case DEUTERON_2_PLUS_S0_T1_82: return "deuteron_S0_T1_2+_82";
    case DEUTERON_2_PLUS_S0_T1_83: return "deuteron_S0_T1_2+_83";
    case DEUTERON_2_PLUS_S0_T1_84: return "deuteron_S0_T1_2+_84";
    case DEUTERON_2_PLUS_S0_T1_85: return "deuteron_S0_T1_2+_85";
    case DEUTERON_2_PLUS_S0_T1_86: return "deuteron_S0_T1_2+_86";
    case DEUTERON_2_PLUS_S0_T1_87: return "deuteron_S0_T1_2+_87";
    case DEUTERON_2_PLUS_S0_T1_88: return "deuteron_S0_T1_2+_88";
    case DEUTERON_2_PLUS_S0_T1_89: return "deuteron_S0_T1_2+_89";
    case DEUTERON_2_PLUS_S0_T1_90: return "deuteron_S0_T1_2+_90";
    case DEUTERON_2_PLUS_S0_T1_91: return "deuteron_S0_T1_2+_91";
    case DEUTERON_2_PLUS_S0_T1_92: return "deuteron_S0_T1_2+_92";
    case DEUTERON_2_PLUS_S0_T1_93: return "deuteron_S0_T1_2+_93";
    case DEUTERON_2_PLUS_S0_T1_94: return "deuteron_S0_T1_2+_94";
    case DEUTERON_2_PLUS_S0_T1_95: return "deuteron_S0_T1_2+_95";
    case DEUTERON_2_PLUS_S0_T1_96: return "deuteron_S0_T1_2+_96";
    case DEUTERON_2_PLUS_S0_T1_97: return "deuteron_S0_T1_2+_97";
    case DEUTERON_2_PLUS_S0_T1_98: return "deuteron_S0_T1_2+_98";
    case DEUTERON_2_PLUS_S0_T1_99: return "deuteron_S0_T1_2+_99";

    case DEUTERON_4_PLUS_S0_T1:    return "deuteron_S0_T1_4+";
    case DEUTERON_4_PLUS_S0_T1_0:  return "deuteron_S0_T1_4+_0";
    case DEUTERON_4_PLUS_S0_T1_1:  return "deuteron_S0_T1_4+_1";
    case DEUTERON_4_PLUS_S0_T1_2:  return "deuteron_S0_T1_4+_2";
    case DEUTERON_4_PLUS_S0_T1_3:  return "deuteron_S0_T1_4+_3";
    case DEUTERON_4_PLUS_S0_T1_4:  return "deuteron_S0_T1_4+_4";
    case DEUTERON_4_PLUS_S0_T1_5:  return "deuteron_S0_T1_4+_5";
    case DEUTERON_4_PLUS_S0_T1_6:  return "deuteron_S0_T1_4+_6";
    case DEUTERON_4_PLUS_S0_T1_7:  return "deuteron_S0_T1_4+_7";
    case DEUTERON_4_PLUS_S0_T1_8:  return "deuteron_S0_T1_4+_8";
    case DEUTERON_4_PLUS_S0_T1_9:  return "deuteron_S0_T1_4+_9";
    case DEUTERON_4_PLUS_S0_T1_10: return "deuteron_S0_T1_4+_10";
    case DEUTERON_4_PLUS_S0_T1_11: return "deuteron_S0_T1_4+_11";
    case DEUTERON_4_PLUS_S0_T1_12: return "deuteron_S0_T1_4+_12";
    case DEUTERON_4_PLUS_S0_T1_13: return "deuteron_S0_T1_4+_13";
    case DEUTERON_4_PLUS_S0_T1_14: return "deuteron_S0_T1_4+_14";
    case DEUTERON_4_PLUS_S0_T1_15: return "deuteron_S0_T1_4+_15";
    case DEUTERON_4_PLUS_S0_T1_16: return "deuteron_S0_T1_4+_16";
    case DEUTERON_4_PLUS_S0_T1_17: return "deuteron_S0_T1_4+_17";
    case DEUTERON_4_PLUS_S0_T1_18: return "deuteron_S0_T1_4+_18";
    case DEUTERON_4_PLUS_S0_T1_19: return "deuteron_S0_T1_4+_19";
    case DEUTERON_4_PLUS_S0_T1_20: return "deuteron_S0_T1_4+_20";
    case DEUTERON_4_PLUS_S0_T1_21: return "deuteron_S0_T1_4+_21";
    case DEUTERON_4_PLUS_S0_T1_22: return "deuteron_S0_T1_4+_22";
    case DEUTERON_4_PLUS_S0_T1_23: return "deuteron_S0_T1_4+_23";
    case DEUTERON_4_PLUS_S0_T1_24: return "deuteron_S0_T1_4+_24";
    case DEUTERON_4_PLUS_S0_T1_25: return "deuteron_S0_T1_4+_25";
    case DEUTERON_4_PLUS_S0_T1_26: return "deuteron_S0_T1_4+_26";
    case DEUTERON_4_PLUS_S0_T1_27: return "deuteron_S0_T1_4+_27";
    case DEUTERON_4_PLUS_S0_T1_28: return "deuteron_S0_T1_4+_28";
    case DEUTERON_4_PLUS_S0_T1_29: return "deuteron_S0_T1_4+_29";
    case DEUTERON_4_PLUS_S0_T1_30: return "deuteron_S0_T1_4+_30";
    case DEUTERON_4_PLUS_S0_T1_31: return "deuteron_S0_T1_4+_31";
    case DEUTERON_4_PLUS_S0_T1_32: return "deuteron_S0_T1_4+_32";
    case DEUTERON_4_PLUS_S0_T1_33: return "deuteron_S0_T1_4+_33";
    case DEUTERON_4_PLUS_S0_T1_34: return "deuteron_S0_T1_4+_34";
    case DEUTERON_4_PLUS_S0_T1_35: return "deuteron_S0_T1_4+_35";
    case DEUTERON_4_PLUS_S0_T1_36: return "deuteron_S0_T1_4+_36";
    case DEUTERON_4_PLUS_S0_T1_37: return "deuteron_S0_T1_4+_37";
    case DEUTERON_4_PLUS_S0_T1_38: return "deuteron_S0_T1_4+_38";
    case DEUTERON_4_PLUS_S0_T1_39: return "deuteron_S0_T1_4+_39";
    case DEUTERON_4_PLUS_S0_T1_40: return "deuteron_S0_T1_4+_40";
    case DEUTERON_4_PLUS_S0_T1_41: return "deuteron_S0_T1_4+_41";
    case DEUTERON_4_PLUS_S0_T1_42: return "deuteron_S0_T1_4+_42";
    case DEUTERON_4_PLUS_S0_T1_43: return "deuteron_S0_T1_4+_43";
    case DEUTERON_4_PLUS_S0_T1_44: return "deuteron_S0_T1_4+_44";
    case DEUTERON_4_PLUS_S0_T1_45: return "deuteron_S0_T1_4+_45";
    case DEUTERON_4_PLUS_S0_T1_46: return "deuteron_S0_T1_4+_46";
    case DEUTERON_4_PLUS_S0_T1_47: return "deuteron_S0_T1_4+_47";
    case DEUTERON_4_PLUS_S0_T1_48: return "deuteron_S0_T1_4+_48";
    case DEUTERON_4_PLUS_S0_T1_49: return "deuteron_S0_T1_4+_49";
    case DEUTERON_4_PLUS_S0_T1_50: return "deuteron_S0_T1_4+_50";
    case DEUTERON_4_PLUS_S0_T1_51: return "deuteron_S0_T1_4+_51";
    case DEUTERON_4_PLUS_S0_T1_52: return "deuteron_S0_T1_4+_52";
    case DEUTERON_4_PLUS_S0_T1_53: return "deuteron_S0_T1_4+_53";
    case DEUTERON_4_PLUS_S0_T1_54: return "deuteron_S0_T1_4+_54";
    case DEUTERON_4_PLUS_S0_T1_55: return "deuteron_S0_T1_4+_55";
    case DEUTERON_4_PLUS_S0_T1_56: return "deuteron_S0_T1_4+_56";
    case DEUTERON_4_PLUS_S0_T1_57: return "deuteron_S0_T1_4+_57";
    case DEUTERON_4_PLUS_S0_T1_58: return "deuteron_S0_T1_4+_58";
    case DEUTERON_4_PLUS_S0_T1_59: return "deuteron_S0_T1_4+_59";
    case DEUTERON_4_PLUS_S0_T1_60: return "deuteron_S0_T1_4+_60";
    case DEUTERON_4_PLUS_S0_T1_61: return "deuteron_S0_T1_4+_61";
    case DEUTERON_4_PLUS_S0_T1_62: return "deuteron_S0_T1_4+_62";
    case DEUTERON_4_PLUS_S0_T1_63: return "deuteron_S0_T1_4+_63";
    case DEUTERON_4_PLUS_S0_T1_64: return "deuteron_S0_T1_4+_64";
    case DEUTERON_4_PLUS_S0_T1_65: return "deuteron_S0_T1_4+_65";
    case DEUTERON_4_PLUS_S0_T1_66: return "deuteron_S0_T1_4+_66";
    case DEUTERON_4_PLUS_S0_T1_67: return "deuteron_S0_T1_4+_67";
    case DEUTERON_4_PLUS_S0_T1_68: return "deuteron_S0_T1_4+_68";
    case DEUTERON_4_PLUS_S0_T1_69: return "deuteron_S0_T1_4+_69";
    case DEUTERON_4_PLUS_S0_T1_70: return "deuteron_S0_T1_4+_70";
    case DEUTERON_4_PLUS_S0_T1_71: return "deuteron_S0_T1_4+_71";
    case DEUTERON_4_PLUS_S0_T1_72: return "deuteron_S0_T1_4+_72";
    case DEUTERON_4_PLUS_S0_T1_73: return "deuteron_S0_T1_4+_73";
    case DEUTERON_4_PLUS_S0_T1_74: return "deuteron_S0_T1_4+_74";
    case DEUTERON_4_PLUS_S0_T1_75: return "deuteron_S0_T1_4+_75";
    case DEUTERON_4_PLUS_S0_T1_76: return "deuteron_S0_T1_4+_76";
    case DEUTERON_4_PLUS_S0_T1_77: return "deuteron_S0_T1_4+_77";
    case DEUTERON_4_PLUS_S0_T1_78: return "deuteron_S0_T1_4+_78";
    case DEUTERON_4_PLUS_S0_T1_79: return "deuteron_S0_T1_4+_79";
    case DEUTERON_4_PLUS_S0_T1_80: return "deuteron_S0_T1_4+_80";
    case DEUTERON_4_PLUS_S0_T1_81: return "deuteron_S0_T1_4+_81";
    case DEUTERON_4_PLUS_S0_T1_82: return "deuteron_S0_T1_4+_82";
    case DEUTERON_4_PLUS_S0_T1_83: return "deuteron_S0_T1_4+_83";
    case DEUTERON_4_PLUS_S0_T1_84: return "deuteron_S0_T1_4+_84";
    case DEUTERON_4_PLUS_S0_T1_85: return "deuteron_S0_T1_4+_85";
    case DEUTERON_4_PLUS_S0_T1_86: return "deuteron_S0_T1_4+_86";
    case DEUTERON_4_PLUS_S0_T1_87: return "deuteron_S0_T1_4+_87";
    case DEUTERON_4_PLUS_S0_T1_88: return "deuteron_S0_T1_4+_88";
    case DEUTERON_4_PLUS_S0_T1_89: return "deuteron_S0_T1_4+_89";
    case DEUTERON_4_PLUS_S0_T1_90: return "deuteron_S0_T1_4+_90";
    case DEUTERON_4_PLUS_S0_T1_91: return "deuteron_S0_T1_4+_91";
    case DEUTERON_4_PLUS_S0_T1_92: return "deuteron_S0_T1_4+_92";
    case DEUTERON_4_PLUS_S0_T1_93: return "deuteron_S0_T1_4+_93";
    case DEUTERON_4_PLUS_S0_T1_94: return "deuteron_S0_T1_4+_94";
    case DEUTERON_4_PLUS_S0_T1_95: return "deuteron_S0_T1_4+_95";
    case DEUTERON_4_PLUS_S0_T1_96: return "deuteron_S0_T1_4+_96";
    case DEUTERON_4_PLUS_S0_T1_97: return "deuteron_S0_T1_4+_97";
    case DEUTERON_4_PLUS_S0_T1_98: return "deuteron_S0_T1_4+_98";
    case DEUTERON_4_PLUS_S0_T1_99: return "deuteron_S0_T1_4+_99";

    case DEUTERON_0_MINUS_S1_T1:    return "deuteron_S1_T1_0-";
    case DEUTERON_0_MINUS_S1_T1_0:  return "deuteron_S1_T1_0-_0";
    case DEUTERON_0_MINUS_S1_T1_1:  return "deuteron_S1_T1_0-_1";
    case DEUTERON_0_MINUS_S1_T1_2:  return "deuteron_S1_T1_0-_2";
    case DEUTERON_0_MINUS_S1_T1_3:  return "deuteron_S1_T1_0-_3";
    case DEUTERON_0_MINUS_S1_T1_4:  return "deuteron_S1_T1_0-_4";
    case DEUTERON_0_MINUS_S1_T1_5:  return "deuteron_S1_T1_0-_5";
    case DEUTERON_0_MINUS_S1_T1_6:  return "deuteron_S1_T1_0-_6";
    case DEUTERON_0_MINUS_S1_T1_7:  return "deuteron_S1_T1_0-_7";
    case DEUTERON_0_MINUS_S1_T1_8:  return "deuteron_S1_T1_0-_8";
    case DEUTERON_0_MINUS_S1_T1_9:  return "deuteron_S1_T1_0-_9";
    case DEUTERON_0_MINUS_S1_T1_10: return "deuteron_S1_T1_0-_10";
    case DEUTERON_0_MINUS_S1_T1_11: return "deuteron_S1_T1_0-_11";
    case DEUTERON_0_MINUS_S1_T1_12: return "deuteron_S1_T1_0-_12";
    case DEUTERON_0_MINUS_S1_T1_13: return "deuteron_S1_T1_0-_13";
    case DEUTERON_0_MINUS_S1_T1_14: return "deuteron_S1_T1_0-_14";
    case DEUTERON_0_MINUS_S1_T1_15: return "deuteron_S1_T1_0-_15";
    case DEUTERON_0_MINUS_S1_T1_16: return "deuteron_S1_T1_0-_16";
    case DEUTERON_0_MINUS_S1_T1_17: return "deuteron_S1_T1_0-_17";
    case DEUTERON_0_MINUS_S1_T1_18: return "deuteron_S1_T1_0-_18";
    case DEUTERON_0_MINUS_S1_T1_19: return "deuteron_S1_T1_0-_19";
    case DEUTERON_0_MINUS_S1_T1_20: return "deuteron_S1_T1_0-_20";
    case DEUTERON_0_MINUS_S1_T1_21: return "deuteron_S1_T1_0-_21";
    case DEUTERON_0_MINUS_S1_T1_22: return "deuteron_S1_T1_0-_22";
    case DEUTERON_0_MINUS_S1_T1_23: return "deuteron_S1_T1_0-_23";
    case DEUTERON_0_MINUS_S1_T1_24: return "deuteron_S1_T1_0-_24";
    case DEUTERON_0_MINUS_S1_T1_25: return "deuteron_S1_T1_0-_25";
    case DEUTERON_0_MINUS_S1_T1_26: return "deuteron_S1_T1_0-_26";
    case DEUTERON_0_MINUS_S1_T1_27: return "deuteron_S1_T1_0-_27";
    case DEUTERON_0_MINUS_S1_T1_28: return "deuteron_S1_T1_0-_28";
    case DEUTERON_0_MINUS_S1_T1_29: return "deuteron_S1_T1_0-_29";
    case DEUTERON_0_MINUS_S1_T1_30: return "deuteron_S1_T1_0-_30";
    case DEUTERON_0_MINUS_S1_T1_31: return "deuteron_S1_T1_0-_31";
    case DEUTERON_0_MINUS_S1_T1_32: return "deuteron_S1_T1_0-_32";
    case DEUTERON_0_MINUS_S1_T1_33: return "deuteron_S1_T1_0-_33";
    case DEUTERON_0_MINUS_S1_T1_34: return "deuteron_S1_T1_0-_34";
    case DEUTERON_0_MINUS_S1_T1_35: return "deuteron_S1_T1_0-_35";
    case DEUTERON_0_MINUS_S1_T1_36: return "deuteron_S1_T1_0-_36";
    case DEUTERON_0_MINUS_S1_T1_37: return "deuteron_S1_T1_0-_37";
    case DEUTERON_0_MINUS_S1_T1_38: return "deuteron_S1_T1_0-_38";
    case DEUTERON_0_MINUS_S1_T1_39: return "deuteron_S1_T1_0-_39";
    case DEUTERON_0_MINUS_S1_T1_40: return "deuteron_S1_T1_0-_40";
    case DEUTERON_0_MINUS_S1_T1_41: return "deuteron_S1_T1_0-_41";
    case DEUTERON_0_MINUS_S1_T1_42: return "deuteron_S1_T1_0-_42";
    case DEUTERON_0_MINUS_S1_T1_43: return "deuteron_S1_T1_0-_43";
    case DEUTERON_0_MINUS_S1_T1_44: return "deuteron_S1_T1_0-_44";
    case DEUTERON_0_MINUS_S1_T1_45: return "deuteron_S1_T1_0-_45";
    case DEUTERON_0_MINUS_S1_T1_46: return "deuteron_S1_T1_0-_46";
    case DEUTERON_0_MINUS_S1_T1_47: return "deuteron_S1_T1_0-_47";
    case DEUTERON_0_MINUS_S1_T1_48: return "deuteron_S1_T1_0-_48";
    case DEUTERON_0_MINUS_S1_T1_49: return "deuteron_S1_T1_0-_49";
    case DEUTERON_0_MINUS_S1_T1_50: return "deuteron_S1_T1_0-_50";
    case DEUTERON_0_MINUS_S1_T1_51: return "deuteron_S1_T1_0-_51";
    case DEUTERON_0_MINUS_S1_T1_52: return "deuteron_S1_T1_0-_52";
    case DEUTERON_0_MINUS_S1_T1_53: return "deuteron_S1_T1_0-_53";
    case DEUTERON_0_MINUS_S1_T1_54: return "deuteron_S1_T1_0-_54";
    case DEUTERON_0_MINUS_S1_T1_55: return "deuteron_S1_T1_0-_55";
    case DEUTERON_0_MINUS_S1_T1_56: return "deuteron_S1_T1_0-_56";
    case DEUTERON_0_MINUS_S1_T1_57: return "deuteron_S1_T1_0-_57";
    case DEUTERON_0_MINUS_S1_T1_58: return "deuteron_S1_T1_0-_58";
    case DEUTERON_0_MINUS_S1_T1_59: return "deuteron_S1_T1_0-_59";
    case DEUTERON_0_MINUS_S1_T1_60: return "deuteron_S1_T1_0-_60";
    case DEUTERON_0_MINUS_S1_T1_61: return "deuteron_S1_T1_0-_61";
    case DEUTERON_0_MINUS_S1_T1_62: return "deuteron_S1_T1_0-_62";
    case DEUTERON_0_MINUS_S1_T1_63: return "deuteron_S1_T1_0-_63";
    case DEUTERON_0_MINUS_S1_T1_64: return "deuteron_S1_T1_0-_64";
    case DEUTERON_0_MINUS_S1_T1_65: return "deuteron_S1_T1_0-_65";
    case DEUTERON_0_MINUS_S1_T1_66: return "deuteron_S1_T1_0-_66";
    case DEUTERON_0_MINUS_S1_T1_67: return "deuteron_S1_T1_0-_67";
    case DEUTERON_0_MINUS_S1_T1_68: return "deuteron_S1_T1_0-_68";
    case DEUTERON_0_MINUS_S1_T1_69: return "deuteron_S1_T1_0-_69";
    case DEUTERON_0_MINUS_S1_T1_70: return "deuteron_S1_T1_0-_70";
    case DEUTERON_0_MINUS_S1_T1_71: return "deuteron_S1_T1_0-_71";
    case DEUTERON_0_MINUS_S1_T1_72: return "deuteron_S1_T1_0-_72";
    case DEUTERON_0_MINUS_S1_T1_73: return "deuteron_S1_T1_0-_73";
    case DEUTERON_0_MINUS_S1_T1_74: return "deuteron_S1_T1_0-_74";
    case DEUTERON_0_MINUS_S1_T1_75: return "deuteron_S1_T1_0-_75";
    case DEUTERON_0_MINUS_S1_T1_76: return "deuteron_S1_T1_0-_76";
    case DEUTERON_0_MINUS_S1_T1_77: return "deuteron_S1_T1_0-_77";
    case DEUTERON_0_MINUS_S1_T1_78: return "deuteron_S1_T1_0-_78";
    case DEUTERON_0_MINUS_S1_T1_79: return "deuteron_S1_T1_0-_79";
    case DEUTERON_0_MINUS_S1_T1_80: return "deuteron_S1_T1_0-_80";
    case DEUTERON_0_MINUS_S1_T1_81: return "deuteron_S1_T1_0-_81";
    case DEUTERON_0_MINUS_S1_T1_82: return "deuteron_S1_T1_0-_82";
    case DEUTERON_0_MINUS_S1_T1_83: return "deuteron_S1_T1_0-_83";
    case DEUTERON_0_MINUS_S1_T1_84: return "deuteron_S1_T1_0-_84";
    case DEUTERON_0_MINUS_S1_T1_85: return "deuteron_S1_T1_0-_85";
    case DEUTERON_0_MINUS_S1_T1_86: return "deuteron_S1_T1_0-_86";
    case DEUTERON_0_MINUS_S1_T1_87: return "deuteron_S1_T1_0-_87";
    case DEUTERON_0_MINUS_S1_T1_88: return "deuteron_S1_T1_0-_88";
    case DEUTERON_0_MINUS_S1_T1_89: return "deuteron_S1_T1_0-_89";
    case DEUTERON_0_MINUS_S1_T1_90: return "deuteron_S1_T1_0-_90";
    case DEUTERON_0_MINUS_S1_T1_91: return "deuteron_S1_T1_0-_91";
    case DEUTERON_0_MINUS_S1_T1_92: return "deuteron_S1_T1_0-_92";
    case DEUTERON_0_MINUS_S1_T1_93: return "deuteron_S1_T1_0-_93";
    case DEUTERON_0_MINUS_S1_T1_94: return "deuteron_S1_T1_0-_94";
    case DEUTERON_0_MINUS_S1_T1_95: return "deuteron_S1_T1_0-_95";
    case DEUTERON_0_MINUS_S1_T1_96: return "deuteron_S1_T1_0-_96";
    case DEUTERON_0_MINUS_S1_T1_97: return "deuteron_S1_T1_0-_97";
    case DEUTERON_0_MINUS_S1_T1_98: return "deuteron_S1_T1_0-_98";
    case DEUTERON_0_MINUS_S1_T1_99: return "deuteron_S1_T1_0-_99";

    case DEUTERON_1_MINUS_S1_T1:    return "deuteron_S1_T1_1-";
    case DEUTERON_1_MINUS_S1_T1_0:  return "deuteron_S1_T1_1-_0";
    case DEUTERON_1_MINUS_S1_T1_1:  return "deuteron_S1_T1_1-_1";
    case DEUTERON_1_MINUS_S1_T1_2:  return "deuteron_S1_T1_1-_2";
    case DEUTERON_1_MINUS_S1_T1_3:  return "deuteron_S1_T1_1-_3";
    case DEUTERON_1_MINUS_S1_T1_4:  return "deuteron_S1_T1_1-_4";
    case DEUTERON_1_MINUS_S1_T1_5:  return "deuteron_S1_T1_1-_5";
    case DEUTERON_1_MINUS_S1_T1_6:  return "deuteron_S1_T1_1-_6";
    case DEUTERON_1_MINUS_S1_T1_7:  return "deuteron_S1_T1_1-_7";
    case DEUTERON_1_MINUS_S1_T1_8:  return "deuteron_S1_T1_1-_8";
    case DEUTERON_1_MINUS_S1_T1_9:  return "deuteron_S1_T1_1-_9";
    case DEUTERON_1_MINUS_S1_T1_10: return "deuteron_S1_T1_1-_10";
    case DEUTERON_1_MINUS_S1_T1_11: return "deuteron_S1_T1_1-_11";
    case DEUTERON_1_MINUS_S1_T1_12: return "deuteron_S1_T1_1-_12";
    case DEUTERON_1_MINUS_S1_T1_13: return "deuteron_S1_T1_1-_13";
    case DEUTERON_1_MINUS_S1_T1_14: return "deuteron_S1_T1_1-_14";
    case DEUTERON_1_MINUS_S1_T1_15: return "deuteron_S1_T1_1-_15";
    case DEUTERON_1_MINUS_S1_T1_16: return "deuteron_S1_T1_1-_16";
    case DEUTERON_1_MINUS_S1_T1_17: return "deuteron_S1_T1_1-_17";
    case DEUTERON_1_MINUS_S1_T1_18: return "deuteron_S1_T1_1-_18";
    case DEUTERON_1_MINUS_S1_T1_19: return "deuteron_S1_T1_1-_19";
    case DEUTERON_1_MINUS_S1_T1_20: return "deuteron_S1_T1_1-_20";
    case DEUTERON_1_MINUS_S1_T1_21: return "deuteron_S1_T1_1-_21";
    case DEUTERON_1_MINUS_S1_T1_22: return "deuteron_S1_T1_1-_22";
    case DEUTERON_1_MINUS_S1_T1_23: return "deuteron_S1_T1_1-_23";
    case DEUTERON_1_MINUS_S1_T1_24: return "deuteron_S1_T1_1-_24";
    case DEUTERON_1_MINUS_S1_T1_25: return "deuteron_S1_T1_1-_25";
    case DEUTERON_1_MINUS_S1_T1_26: return "deuteron_S1_T1_1-_26";
    case DEUTERON_1_MINUS_S1_T1_27: return "deuteron_S1_T1_1-_27";
    case DEUTERON_1_MINUS_S1_T1_28: return "deuteron_S1_T1_1-_28";
    case DEUTERON_1_MINUS_S1_T1_29: return "deuteron_S1_T1_1-_29";
    case DEUTERON_1_MINUS_S1_T1_30: return "deuteron_S1_T1_1-_30";
    case DEUTERON_1_MINUS_S1_T1_31: return "deuteron_S1_T1_1-_31";
    case DEUTERON_1_MINUS_S1_T1_32: return "deuteron_S1_T1_1-_32";
    case DEUTERON_1_MINUS_S1_T1_33: return "deuteron_S1_T1_1-_33";
    case DEUTERON_1_MINUS_S1_T1_34: return "deuteron_S1_T1_1-_34";
    case DEUTERON_1_MINUS_S1_T1_35: return "deuteron_S1_T1_1-_35";
    case DEUTERON_1_MINUS_S1_T1_36: return "deuteron_S1_T1_1-_36";
    case DEUTERON_1_MINUS_S1_T1_37: return "deuteron_S1_T1_1-_37";
    case DEUTERON_1_MINUS_S1_T1_38: return "deuteron_S1_T1_1-_38";
    case DEUTERON_1_MINUS_S1_T1_39: return "deuteron_S1_T1_1-_39";
    case DEUTERON_1_MINUS_S1_T1_40: return "deuteron_S1_T1_1-_40";
    case DEUTERON_1_MINUS_S1_T1_41: return "deuteron_S1_T1_1-_41";
    case DEUTERON_1_MINUS_S1_T1_42: return "deuteron_S1_T1_1-_42";
    case DEUTERON_1_MINUS_S1_T1_43: return "deuteron_S1_T1_1-_43";
    case DEUTERON_1_MINUS_S1_T1_44: return "deuteron_S1_T1_1-_44";
    case DEUTERON_1_MINUS_S1_T1_45: return "deuteron_S1_T1_1-_45";
    case DEUTERON_1_MINUS_S1_T1_46: return "deuteron_S1_T1_1-_46";
    case DEUTERON_1_MINUS_S1_T1_47: return "deuteron_S1_T1_1-_47";
    case DEUTERON_1_MINUS_S1_T1_48: return "deuteron_S1_T1_1-_48";
    case DEUTERON_1_MINUS_S1_T1_49: return "deuteron_S1_T1_1-_49";
    case DEUTERON_1_MINUS_S1_T1_50: return "deuteron_S1_T1_1-_50";
    case DEUTERON_1_MINUS_S1_T1_51: return "deuteron_S1_T1_1-_51";
    case DEUTERON_1_MINUS_S1_T1_52: return "deuteron_S1_T1_1-_52";
    case DEUTERON_1_MINUS_S1_T1_53: return "deuteron_S1_T1_1-_53";
    case DEUTERON_1_MINUS_S1_T1_54: return "deuteron_S1_T1_1-_54";
    case DEUTERON_1_MINUS_S1_T1_55: return "deuteron_S1_T1_1-_55";
    case DEUTERON_1_MINUS_S1_T1_56: return "deuteron_S1_T1_1-_56";
    case DEUTERON_1_MINUS_S1_T1_57: return "deuteron_S1_T1_1-_57";
    case DEUTERON_1_MINUS_S1_T1_58: return "deuteron_S1_T1_1-_58";
    case DEUTERON_1_MINUS_S1_T1_59: return "deuteron_S1_T1_1-_59";
    case DEUTERON_1_MINUS_S1_T1_60: return "deuteron_S1_T1_1-_60";
    case DEUTERON_1_MINUS_S1_T1_61: return "deuteron_S1_T1_1-_61";
    case DEUTERON_1_MINUS_S1_T1_62: return "deuteron_S1_T1_1-_62";
    case DEUTERON_1_MINUS_S1_T1_63: return "deuteron_S1_T1_1-_63";
    case DEUTERON_1_MINUS_S1_T1_64: return "deuteron_S1_T1_1-_64";
    case DEUTERON_1_MINUS_S1_T1_65: return "deuteron_S1_T1_1-_65";
    case DEUTERON_1_MINUS_S1_T1_66: return "deuteron_S1_T1_1-_66";
    case DEUTERON_1_MINUS_S1_T1_67: return "deuteron_S1_T1_1-_67";
    case DEUTERON_1_MINUS_S1_T1_68: return "deuteron_S1_T1_1-_68";
    case DEUTERON_1_MINUS_S1_T1_69: return "deuteron_S1_T1_1-_69";
    case DEUTERON_1_MINUS_S1_T1_70: return "deuteron_S1_T1_1-_70";
    case DEUTERON_1_MINUS_S1_T1_71: return "deuteron_S1_T1_1-_71";
    case DEUTERON_1_MINUS_S1_T1_72: return "deuteron_S1_T1_1-_72";
    case DEUTERON_1_MINUS_S1_T1_73: return "deuteron_S1_T1_1-_73";
    case DEUTERON_1_MINUS_S1_T1_74: return "deuteron_S1_T1_1-_74";
    case DEUTERON_1_MINUS_S1_T1_75: return "deuteron_S1_T1_1-_75";
    case DEUTERON_1_MINUS_S1_T1_76: return "deuteron_S1_T1_1-_76";
    case DEUTERON_1_MINUS_S1_T1_77: return "deuteron_S1_T1_1-_77";
    case DEUTERON_1_MINUS_S1_T1_78: return "deuteron_S1_T1_1-_78";
    case DEUTERON_1_MINUS_S1_T1_79: return "deuteron_S1_T1_1-_79";
    case DEUTERON_1_MINUS_S1_T1_80: return "deuteron_S1_T1_1-_80";
    case DEUTERON_1_MINUS_S1_T1_81: return "deuteron_S1_T1_1-_81";
    case DEUTERON_1_MINUS_S1_T1_82: return "deuteron_S1_T1_1-_82";
    case DEUTERON_1_MINUS_S1_T1_83: return "deuteron_S1_T1_1-_83";
    case DEUTERON_1_MINUS_S1_T1_84: return "deuteron_S1_T1_1-_84";
    case DEUTERON_1_MINUS_S1_T1_85: return "deuteron_S1_T1_1-_85";
    case DEUTERON_1_MINUS_S1_T1_86: return "deuteron_S1_T1_1-_86";
    case DEUTERON_1_MINUS_S1_T1_87: return "deuteron_S1_T1_1-_87";
    case DEUTERON_1_MINUS_S1_T1_88: return "deuteron_S1_T1_1-_88";
    case DEUTERON_1_MINUS_S1_T1_89: return "deuteron_S1_T1_1-_89";
    case DEUTERON_1_MINUS_S1_T1_90: return "deuteron_S1_T1_1-_90";
    case DEUTERON_1_MINUS_S1_T1_91: return "deuteron_S1_T1_1-_91";
    case DEUTERON_1_MINUS_S1_T1_92: return "deuteron_S1_T1_1-_92";
    case DEUTERON_1_MINUS_S1_T1_93: return "deuteron_S1_T1_1-_93";
    case DEUTERON_1_MINUS_S1_T1_94: return "deuteron_S1_T1_1-_94";
    case DEUTERON_1_MINUS_S1_T1_95: return "deuteron_S1_T1_1-_95";
    case DEUTERON_1_MINUS_S1_T1_96: return "deuteron_S1_T1_1-_96";
    case DEUTERON_1_MINUS_S1_T1_97: return "deuteron_S1_T1_1-_97";
    case DEUTERON_1_MINUS_S1_T1_98: return "deuteron_S1_T1_1-_98";
    case DEUTERON_1_MINUS_S1_T1_99: return "deuteron_S1_T1_1-_99";

    case DEUTERON_2_MINUS_S1_T1:    return "deuteron_S1_T1_2-";
    case DEUTERON_2_MINUS_S1_T1_0:  return "deuteron_S1_T1_2-_0";
    case DEUTERON_2_MINUS_S1_T1_1:  return "deuteron_S1_T1_2-_1";
    case DEUTERON_2_MINUS_S1_T1_2:  return "deuteron_S1_T1_2-_2";
    case DEUTERON_2_MINUS_S1_T1_3:  return "deuteron_S1_T1_2-_3";
    case DEUTERON_2_MINUS_S1_T1_4:  return "deuteron_S1_T1_2-_4";
    case DEUTERON_2_MINUS_S1_T1_5:  return "deuteron_S1_T1_2-_5";
    case DEUTERON_2_MINUS_S1_T1_6:  return "deuteron_S1_T1_2-_6";
    case DEUTERON_2_MINUS_S1_T1_7:  return "deuteron_S1_T1_2-_7";
    case DEUTERON_2_MINUS_S1_T1_8:  return "deuteron_S1_T1_2-_8";
    case DEUTERON_2_MINUS_S1_T1_9:  return "deuteron_S1_T1_2-_9";
    case DEUTERON_2_MINUS_S1_T1_10: return "deuteron_S1_T1_2-_10";
    case DEUTERON_2_MINUS_S1_T1_11: return "deuteron_S1_T1_2-_11";
    case DEUTERON_2_MINUS_S1_T1_12: return "deuteron_S1_T1_2-_12";
    case DEUTERON_2_MINUS_S1_T1_13: return "deuteron_S1_T1_2-_13";
    case DEUTERON_2_MINUS_S1_T1_14: return "deuteron_S1_T1_2-_14";
    case DEUTERON_2_MINUS_S1_T1_15: return "deuteron_S1_T1_2-_15";
    case DEUTERON_2_MINUS_S1_T1_16: return "deuteron_S1_T1_2-_16";
    case DEUTERON_2_MINUS_S1_T1_17: return "deuteron_S1_T1_2-_17";
    case DEUTERON_2_MINUS_S1_T1_18: return "deuteron_S1_T1_2-_18";
    case DEUTERON_2_MINUS_S1_T1_19: return "deuteron_S1_T1_2-_19";
    case DEUTERON_2_MINUS_S1_T1_20: return "deuteron_S1_T1_2-_20";
    case DEUTERON_2_MINUS_S1_T1_21: return "deuteron_S1_T1_2-_21";
    case DEUTERON_2_MINUS_S1_T1_22: return "deuteron_S1_T1_2-_22";
    case DEUTERON_2_MINUS_S1_T1_23: return "deuteron_S1_T1_2-_23";
    case DEUTERON_2_MINUS_S1_T1_24: return "deuteron_S1_T1_2-_24";
    case DEUTERON_2_MINUS_S1_T1_25: return "deuteron_S1_T1_2-_25";
    case DEUTERON_2_MINUS_S1_T1_26: return "deuteron_S1_T1_2-_26";
    case DEUTERON_2_MINUS_S1_T1_27: return "deuteron_S1_T1_2-_27";
    case DEUTERON_2_MINUS_S1_T1_28: return "deuteron_S1_T1_2-_28";
    case DEUTERON_2_MINUS_S1_T1_29: return "deuteron_S1_T1_2-_29";
    case DEUTERON_2_MINUS_S1_T1_30: return "deuteron_S1_T1_2-_30";
    case DEUTERON_2_MINUS_S1_T1_31: return "deuteron_S1_T1_2-_31";
    case DEUTERON_2_MINUS_S1_T1_32: return "deuteron_S1_T1_2-_32";
    case DEUTERON_2_MINUS_S1_T1_33: return "deuteron_S1_T1_2-_33";
    case DEUTERON_2_MINUS_S1_T1_34: return "deuteron_S1_T1_2-_34";
    case DEUTERON_2_MINUS_S1_T1_35: return "deuteron_S1_T1_2-_35";
    case DEUTERON_2_MINUS_S1_T1_36: return "deuteron_S1_T1_2-_36";
    case DEUTERON_2_MINUS_S1_T1_37: return "deuteron_S1_T1_2-_37";
    case DEUTERON_2_MINUS_S1_T1_38: return "deuteron_S1_T1_2-_38";
    case DEUTERON_2_MINUS_S1_T1_39: return "deuteron_S1_T1_2-_39";
    case DEUTERON_2_MINUS_S1_T1_40: return "deuteron_S1_T1_2-_40";
    case DEUTERON_2_MINUS_S1_T1_41: return "deuteron_S1_T1_2-_41";
    case DEUTERON_2_MINUS_S1_T1_42: return "deuteron_S1_T1_2-_42";
    case DEUTERON_2_MINUS_S1_T1_43: return "deuteron_S1_T1_2-_43";
    case DEUTERON_2_MINUS_S1_T1_44: return "deuteron_S1_T1_2-_44";
    case DEUTERON_2_MINUS_S1_T1_45: return "deuteron_S1_T1_2-_45";
    case DEUTERON_2_MINUS_S1_T1_46: return "deuteron_S1_T1_2-_46";
    case DEUTERON_2_MINUS_S1_T1_47: return "deuteron_S1_T1_2-_47";
    case DEUTERON_2_MINUS_S1_T1_48: return "deuteron_S1_T1_2-_48";
    case DEUTERON_2_MINUS_S1_T1_49: return "deuteron_S1_T1_2-_49";
    case DEUTERON_2_MINUS_S1_T1_50: return "deuteron_S1_T1_2-_50";
    case DEUTERON_2_MINUS_S1_T1_51: return "deuteron_S1_T1_2-_51";
    case DEUTERON_2_MINUS_S1_T1_52: return "deuteron_S1_T1_2-_52";
    case DEUTERON_2_MINUS_S1_T1_53: return "deuteron_S1_T1_2-_53";
    case DEUTERON_2_MINUS_S1_T1_54: return "deuteron_S1_T1_2-_54";
    case DEUTERON_2_MINUS_S1_T1_55: return "deuteron_S1_T1_2-_55";
    case DEUTERON_2_MINUS_S1_T1_56: return "deuteron_S1_T1_2-_56";
    case DEUTERON_2_MINUS_S1_T1_57: return "deuteron_S1_T1_2-_57";
    case DEUTERON_2_MINUS_S1_T1_58: return "deuteron_S1_T1_2-_58";
    case DEUTERON_2_MINUS_S1_T1_59: return "deuteron_S1_T1_2-_59";
    case DEUTERON_2_MINUS_S1_T1_60: return "deuteron_S1_T1_2-_60";
    case DEUTERON_2_MINUS_S1_T1_61: return "deuteron_S1_T1_2-_61";
    case DEUTERON_2_MINUS_S1_T1_62: return "deuteron_S1_T1_2-_62";
    case DEUTERON_2_MINUS_S1_T1_63: return "deuteron_S1_T1_2-_63";
    case DEUTERON_2_MINUS_S1_T1_64: return "deuteron_S1_T1_2-_64";
    case DEUTERON_2_MINUS_S1_T1_65: return "deuteron_S1_T1_2-_65";
    case DEUTERON_2_MINUS_S1_T1_66: return "deuteron_S1_T1_2-_66";
    case DEUTERON_2_MINUS_S1_T1_67: return "deuteron_S1_T1_2-_67";
    case DEUTERON_2_MINUS_S1_T1_68: return "deuteron_S1_T1_2-_68";
    case DEUTERON_2_MINUS_S1_T1_69: return "deuteron_S1_T1_2-_69";
    case DEUTERON_2_MINUS_S1_T1_70: return "deuteron_S1_T1_2-_70";
    case DEUTERON_2_MINUS_S1_T1_71: return "deuteron_S1_T1_2-_71";
    case DEUTERON_2_MINUS_S1_T1_72: return "deuteron_S1_T1_2-_72";
    case DEUTERON_2_MINUS_S1_T1_73: return "deuteron_S1_T1_2-_73";
    case DEUTERON_2_MINUS_S1_T1_74: return "deuteron_S1_T1_2-_74";
    case DEUTERON_2_MINUS_S1_T1_75: return "deuteron_S1_T1_2-_75";
    case DEUTERON_2_MINUS_S1_T1_76: return "deuteron_S1_T1_2-_76";
    case DEUTERON_2_MINUS_S1_T1_77: return "deuteron_S1_T1_2-_77";
    case DEUTERON_2_MINUS_S1_T1_78: return "deuteron_S1_T1_2-_78";
    case DEUTERON_2_MINUS_S1_T1_79: return "deuteron_S1_T1_2-_79";
    case DEUTERON_2_MINUS_S1_T1_80: return "deuteron_S1_T1_2-_80";
    case DEUTERON_2_MINUS_S1_T1_81: return "deuteron_S1_T1_2-_81";
    case DEUTERON_2_MINUS_S1_T1_82: return "deuteron_S1_T1_2-_82";
    case DEUTERON_2_MINUS_S1_T1_83: return "deuteron_S1_T1_2-_83";
    case DEUTERON_2_MINUS_S1_T1_84: return "deuteron_S1_T1_2-_84";
    case DEUTERON_2_MINUS_S1_T1_85: return "deuteron_S1_T1_2-_85";
    case DEUTERON_2_MINUS_S1_T1_86: return "deuteron_S1_T1_2-_86";
    case DEUTERON_2_MINUS_S1_T1_87: return "deuteron_S1_T1_2-_87";
    case DEUTERON_2_MINUS_S1_T1_88: return "deuteron_S1_T1_2-_88";
    case DEUTERON_2_MINUS_S1_T1_89: return "deuteron_S1_T1_2-_89";
    case DEUTERON_2_MINUS_S1_T1_90: return "deuteron_S1_T1_2-_90";
    case DEUTERON_2_MINUS_S1_T1_91: return "deuteron_S1_T1_2-_91";
    case DEUTERON_2_MINUS_S1_T1_92: return "deuteron_S1_T1_2-_92";
    case DEUTERON_2_MINUS_S1_T1_93: return "deuteron_S1_T1_2-_93";
    case DEUTERON_2_MINUS_S1_T1_94: return "deuteron_S1_T1_2-_94";
    case DEUTERON_2_MINUS_S1_T1_95: return "deuteron_S1_T1_2-_95";
    case DEUTERON_2_MINUS_S1_T1_96: return "deuteron_S1_T1_2-_96";
    case DEUTERON_2_MINUS_S1_T1_97: return "deuteron_S1_T1_2-_97";
    case DEUTERON_2_MINUS_S1_T1_98: return "deuteron_S1_T1_2-_98";
    case DEUTERON_2_MINUS_S1_T1_99: return "deuteron_S1_T1_2-_99";

    case DEUTERON_3_MINUS_S1_T1:    return "deuteron_S1_T1_3-";
    case DEUTERON_3_MINUS_S1_T1_0:  return "deuteron_S1_T1_3-_0";
    case DEUTERON_3_MINUS_S1_T1_1:  return "deuteron_S1_T1_3-_1";
    case DEUTERON_3_MINUS_S1_T1_2:  return "deuteron_S1_T1_3-_2";
    case DEUTERON_3_MINUS_S1_T1_3:  return "deuteron_S1_T1_3-_3";
    case DEUTERON_3_MINUS_S1_T1_4:  return "deuteron_S1_T1_3-_4";
    case DEUTERON_3_MINUS_S1_T1_5:  return "deuteron_S1_T1_3-_5";
    case DEUTERON_3_MINUS_S1_T1_6:  return "deuteron_S1_T1_3-_6";
    case DEUTERON_3_MINUS_S1_T1_7:  return "deuteron_S1_T1_3-_7";
    case DEUTERON_3_MINUS_S1_T1_8:  return "deuteron_S1_T1_3-_8";
    case DEUTERON_3_MINUS_S1_T1_9:  return "deuteron_S1_T1_3-_9";
    case DEUTERON_3_MINUS_S1_T1_10: return "deuteron_S1_T1_3-_10";
    case DEUTERON_3_MINUS_S1_T1_11: return "deuteron_S1_T1_3-_11";
    case DEUTERON_3_MINUS_S1_T1_12: return "deuteron_S1_T1_3-_12";
    case DEUTERON_3_MINUS_S1_T1_13: return "deuteron_S1_T1_3-_13";
    case DEUTERON_3_MINUS_S1_T1_14: return "deuteron_S1_T1_3-_14";
    case DEUTERON_3_MINUS_S1_T1_15: return "deuteron_S1_T1_3-_15";
    case DEUTERON_3_MINUS_S1_T1_16: return "deuteron_S1_T1_3-_16";
    case DEUTERON_3_MINUS_S1_T1_17: return "deuteron_S1_T1_3-_17";
    case DEUTERON_3_MINUS_S1_T1_18: return "deuteron_S1_T1_3-_18";
    case DEUTERON_3_MINUS_S1_T1_19: return "deuteron_S1_T1_3-_19";
    case DEUTERON_3_MINUS_S1_T1_20: return "deuteron_S1_T1_3-_20";
    case DEUTERON_3_MINUS_S1_T1_21: return "deuteron_S1_T1_3-_21";
    case DEUTERON_3_MINUS_S1_T1_22: return "deuteron_S1_T1_3-_22";
    case DEUTERON_3_MINUS_S1_T1_23: return "deuteron_S1_T1_3-_23";
    case DEUTERON_3_MINUS_S1_T1_24: return "deuteron_S1_T1_3-_24";
    case DEUTERON_3_MINUS_S1_T1_25: return "deuteron_S1_T1_3-_25";
    case DEUTERON_3_MINUS_S1_T1_26: return "deuteron_S1_T1_3-_26";
    case DEUTERON_3_MINUS_S1_T1_27: return "deuteron_S1_T1_3-_27";
    case DEUTERON_3_MINUS_S1_T1_28: return "deuteron_S1_T1_3-_28";
    case DEUTERON_3_MINUS_S1_T1_29: return "deuteron_S1_T1_3-_29";
    case DEUTERON_3_MINUS_S1_T1_30: return "deuteron_S1_T1_3-_30";
    case DEUTERON_3_MINUS_S1_T1_31: return "deuteron_S1_T1_3-_31";
    case DEUTERON_3_MINUS_S1_T1_32: return "deuteron_S1_T1_3-_32";
    case DEUTERON_3_MINUS_S1_T1_33: return "deuteron_S1_T1_3-_33";
    case DEUTERON_3_MINUS_S1_T1_34: return "deuteron_S1_T1_3-_34";
    case DEUTERON_3_MINUS_S1_T1_35: return "deuteron_S1_T1_3-_35";
    case DEUTERON_3_MINUS_S1_T1_36: return "deuteron_S1_T1_3-_36";
    case DEUTERON_3_MINUS_S1_T1_37: return "deuteron_S1_T1_3-_37";
    case DEUTERON_3_MINUS_S1_T1_38: return "deuteron_S1_T1_3-_38";
    case DEUTERON_3_MINUS_S1_T1_39: return "deuteron_S1_T1_3-_39";
    case DEUTERON_3_MINUS_S1_T1_40: return "deuteron_S1_T1_3-_40";
    case DEUTERON_3_MINUS_S1_T1_41: return "deuteron_S1_T1_3-_41";
    case DEUTERON_3_MINUS_S1_T1_42: return "deuteron_S1_T1_3-_42";
    case DEUTERON_3_MINUS_S1_T1_43: return "deuteron_S1_T1_3-_43";
    case DEUTERON_3_MINUS_S1_T1_44: return "deuteron_S1_T1_3-_44";
    case DEUTERON_3_MINUS_S1_T1_45: return "deuteron_S1_T1_3-_45";
    case DEUTERON_3_MINUS_S1_T1_46: return "deuteron_S1_T1_3-_46";
    case DEUTERON_3_MINUS_S1_T1_47: return "deuteron_S1_T1_3-_47";
    case DEUTERON_3_MINUS_S1_T1_48: return "deuteron_S1_T1_3-_48";
    case DEUTERON_3_MINUS_S1_T1_49: return "deuteron_S1_T1_3-_49";
    case DEUTERON_3_MINUS_S1_T1_50: return "deuteron_S1_T1_3-_50";
    case DEUTERON_3_MINUS_S1_T1_51: return "deuteron_S1_T1_3-_51";
    case DEUTERON_3_MINUS_S1_T1_52: return "deuteron_S1_T1_3-_52";
    case DEUTERON_3_MINUS_S1_T1_53: return "deuteron_S1_T1_3-_53";
    case DEUTERON_3_MINUS_S1_T1_54: return "deuteron_S1_T1_3-_54";
    case DEUTERON_3_MINUS_S1_T1_55: return "deuteron_S1_T1_3-_55";
    case DEUTERON_3_MINUS_S1_T1_56: return "deuteron_S1_T1_3-_56";
    case DEUTERON_3_MINUS_S1_T1_57: return "deuteron_S1_T1_3-_57";
    case DEUTERON_3_MINUS_S1_T1_58: return "deuteron_S1_T1_3-_58";
    case DEUTERON_3_MINUS_S1_T1_59: return "deuteron_S1_T1_3-_59";
    case DEUTERON_3_MINUS_S1_T1_60: return "deuteron_S1_T1_3-_60";
    case DEUTERON_3_MINUS_S1_T1_61: return "deuteron_S1_T1_3-_61";
    case DEUTERON_3_MINUS_S1_T1_62: return "deuteron_S1_T1_3-_62";
    case DEUTERON_3_MINUS_S1_T1_63: return "deuteron_S1_T1_3-_63";
    case DEUTERON_3_MINUS_S1_T1_64: return "deuteron_S1_T1_3-_64";
    case DEUTERON_3_MINUS_S1_T1_65: return "deuteron_S1_T1_3-_65";
    case DEUTERON_3_MINUS_S1_T1_66: return "deuteron_S1_T1_3-_66";
    case DEUTERON_3_MINUS_S1_T1_67: return "deuteron_S1_T1_3-_67";
    case DEUTERON_3_MINUS_S1_T1_68: return "deuteron_S1_T1_3-_68";
    case DEUTERON_3_MINUS_S1_T1_69: return "deuteron_S1_T1_3-_69";
    case DEUTERON_3_MINUS_S1_T1_70: return "deuteron_S1_T1_3-_70";
    case DEUTERON_3_MINUS_S1_T1_71: return "deuteron_S1_T1_3-_71";
    case DEUTERON_3_MINUS_S1_T1_72: return "deuteron_S1_T1_3-_72";
    case DEUTERON_3_MINUS_S1_T1_73: return "deuteron_S1_T1_3-_73";
    case DEUTERON_3_MINUS_S1_T1_74: return "deuteron_S1_T1_3-_74";
    case DEUTERON_3_MINUS_S1_T1_75: return "deuteron_S1_T1_3-_75";
    case DEUTERON_3_MINUS_S1_T1_76: return "deuteron_S1_T1_3-_76";
    case DEUTERON_3_MINUS_S1_T1_77: return "deuteron_S1_T1_3-_77";
    case DEUTERON_3_MINUS_S1_T1_78: return "deuteron_S1_T1_3-_78";
    case DEUTERON_3_MINUS_S1_T1_79: return "deuteron_S1_T1_3-_79";
    case DEUTERON_3_MINUS_S1_T1_80: return "deuteron_S1_T1_3-_80";
    case DEUTERON_3_MINUS_S1_T1_81: return "deuteron_S1_T1_3-_81";
    case DEUTERON_3_MINUS_S1_T1_82: return "deuteron_S1_T1_3-_82";
    case DEUTERON_3_MINUS_S1_T1_83: return "deuteron_S1_T1_3-_83";
    case DEUTERON_3_MINUS_S1_T1_84: return "deuteron_S1_T1_3-_84";
    case DEUTERON_3_MINUS_S1_T1_85: return "deuteron_S1_T1_3-_85";
    case DEUTERON_3_MINUS_S1_T1_86: return "deuteron_S1_T1_3-_86";
    case DEUTERON_3_MINUS_S1_T1_87: return "deuteron_S1_T1_3-_87";
    case DEUTERON_3_MINUS_S1_T1_88: return "deuteron_S1_T1_3-_88";
    case DEUTERON_3_MINUS_S1_T1_89: return "deuteron_S1_T1_3-_89";
    case DEUTERON_3_MINUS_S1_T1_90: return "deuteron_S1_T1_3-_90";
    case DEUTERON_3_MINUS_S1_T1_91: return "deuteron_S1_T1_3-_91";
    case DEUTERON_3_MINUS_S1_T1_92: return "deuteron_S1_T1_3-_92";
    case DEUTERON_3_MINUS_S1_T1_93: return "deuteron_S1_T1_3-_93";
    case DEUTERON_3_MINUS_S1_T1_94: return "deuteron_S1_T1_3-_94";
    case DEUTERON_3_MINUS_S1_T1_95: return "deuteron_S1_T1_3-_95";
    case DEUTERON_3_MINUS_S1_T1_96: return "deuteron_S1_T1_3-_96";
    case DEUTERON_3_MINUS_S1_T1_97: return "deuteron_S1_T1_3-_97";
    case DEUTERON_3_MINUS_S1_T1_98: return "deuteron_S1_T1_3-_98";
    case DEUTERON_3_MINUS_S1_T1_99: return "deuteron_S1_T1_3-_99";

    case DEUTERON_4_MINUS_S1_T1:    return "deuteron_S1_T1_4-";
    case DEUTERON_4_MINUS_S1_T1_0:  return "deuteron_S1_T1_4-_0";
    case DEUTERON_4_MINUS_S1_T1_1:  return "deuteron_S1_T1_4-_1";
    case DEUTERON_4_MINUS_S1_T1_2:  return "deuteron_S1_T1_4-_2";
    case DEUTERON_4_MINUS_S1_T1_3:  return "deuteron_S1_T1_4-_3";
    case DEUTERON_4_MINUS_S1_T1_4:  return "deuteron_S1_T1_4-_4";
    case DEUTERON_4_MINUS_S1_T1_5:  return "deuteron_S1_T1_4-_5";
    case DEUTERON_4_MINUS_S1_T1_6:  return "deuteron_S1_T1_4-_6";
    case DEUTERON_4_MINUS_S1_T1_7:  return "deuteron_S1_T1_4-_7";
    case DEUTERON_4_MINUS_S1_T1_8:  return "deuteron_S1_T1_4-_8";
    case DEUTERON_4_MINUS_S1_T1_9:  return "deuteron_S1_T1_4-_9";
    case DEUTERON_4_MINUS_S1_T1_10: return "deuteron_S1_T1_4-_10";
    case DEUTERON_4_MINUS_S1_T1_11: return "deuteron_S1_T1_4-_11";
    case DEUTERON_4_MINUS_S1_T1_12: return "deuteron_S1_T1_4-_12";
    case DEUTERON_4_MINUS_S1_T1_13: return "deuteron_S1_T1_4-_13";
    case DEUTERON_4_MINUS_S1_T1_14: return "deuteron_S1_T1_4-_14";
    case DEUTERON_4_MINUS_S1_T1_15: return "deuteron_S1_T1_4-_15";
    case DEUTERON_4_MINUS_S1_T1_16: return "deuteron_S1_T1_4-_16";
    case DEUTERON_4_MINUS_S1_T1_17: return "deuteron_S1_T1_4-_17";
    case DEUTERON_4_MINUS_S1_T1_18: return "deuteron_S1_T1_4-_18";
    case DEUTERON_4_MINUS_S1_T1_19: return "deuteron_S1_T1_4-_19";
    case DEUTERON_4_MINUS_S1_T1_20: return "deuteron_S1_T1_4-_20";
    case DEUTERON_4_MINUS_S1_T1_21: return "deuteron_S1_T1_4-_21";
    case DEUTERON_4_MINUS_S1_T1_22: return "deuteron_S1_T1_4-_22";
    case DEUTERON_4_MINUS_S1_T1_23: return "deuteron_S1_T1_4-_23";
    case DEUTERON_4_MINUS_S1_T1_24: return "deuteron_S1_T1_4-_24";
    case DEUTERON_4_MINUS_S1_T1_25: return "deuteron_S1_T1_4-_25";
    case DEUTERON_4_MINUS_S1_T1_26: return "deuteron_S1_T1_4-_26";
    case DEUTERON_4_MINUS_S1_T1_27: return "deuteron_S1_T1_4-_27";
    case DEUTERON_4_MINUS_S1_T1_28: return "deuteron_S1_T1_4-_28";
    case DEUTERON_4_MINUS_S1_T1_29: return "deuteron_S1_T1_4-_29";
    case DEUTERON_4_MINUS_S1_T1_30: return "deuteron_S1_T1_4-_30";
    case DEUTERON_4_MINUS_S1_T1_31: return "deuteron_S1_T1_4-_31";
    case DEUTERON_4_MINUS_S1_T1_32: return "deuteron_S1_T1_4-_32";
    case DEUTERON_4_MINUS_S1_T1_33: return "deuteron_S1_T1_4-_33";
    case DEUTERON_4_MINUS_S1_T1_34: return "deuteron_S1_T1_4-_34";
    case DEUTERON_4_MINUS_S1_T1_35: return "deuteron_S1_T1_4-_35";
    case DEUTERON_4_MINUS_S1_T1_36: return "deuteron_S1_T1_4-_36";
    case DEUTERON_4_MINUS_S1_T1_37: return "deuteron_S1_T1_4-_37";
    case DEUTERON_4_MINUS_S1_T1_38: return "deuteron_S1_T1_4-_38";
    case DEUTERON_4_MINUS_S1_T1_39: return "deuteron_S1_T1_4-_39";
    case DEUTERON_4_MINUS_S1_T1_40: return "deuteron_S1_T1_4-_40";
    case DEUTERON_4_MINUS_S1_T1_41: return "deuteron_S1_T1_4-_41";
    case DEUTERON_4_MINUS_S1_T1_42: return "deuteron_S1_T1_4-_42";
    case DEUTERON_4_MINUS_S1_T1_43: return "deuteron_S1_T1_4-_43";
    case DEUTERON_4_MINUS_S1_T1_44: return "deuteron_S1_T1_4-_44";
    case DEUTERON_4_MINUS_S1_T1_45: return "deuteron_S1_T1_4-_45";
    case DEUTERON_4_MINUS_S1_T1_46: return "deuteron_S1_T1_4-_46";
    case DEUTERON_4_MINUS_S1_T1_47: return "deuteron_S1_T1_4-_47";
    case DEUTERON_4_MINUS_S1_T1_48: return "deuteron_S1_T1_4-_48";
    case DEUTERON_4_MINUS_S1_T1_49: return "deuteron_S1_T1_4-_49";
    case DEUTERON_4_MINUS_S1_T1_50: return "deuteron_S1_T1_4-_50";
    case DEUTERON_4_MINUS_S1_T1_51: return "deuteron_S1_T1_4-_51";
    case DEUTERON_4_MINUS_S1_T1_52: return "deuteron_S1_T1_4-_52";
    case DEUTERON_4_MINUS_S1_T1_53: return "deuteron_S1_T1_4-_53";
    case DEUTERON_4_MINUS_S1_T1_54: return "deuteron_S1_T1_4-_54";
    case DEUTERON_4_MINUS_S1_T1_55: return "deuteron_S1_T1_4-_55";
    case DEUTERON_4_MINUS_S1_T1_56: return "deuteron_S1_T1_4-_56";
    case DEUTERON_4_MINUS_S1_T1_57: return "deuteron_S1_T1_4-_57";
    case DEUTERON_4_MINUS_S1_T1_58: return "deuteron_S1_T1_4-_58";
    case DEUTERON_4_MINUS_S1_T1_59: return "deuteron_S1_T1_4-_59";
    case DEUTERON_4_MINUS_S1_T1_60: return "deuteron_S1_T1_4-_60";
    case DEUTERON_4_MINUS_S1_T1_61: return "deuteron_S1_T1_4-_61";
    case DEUTERON_4_MINUS_S1_T1_62: return "deuteron_S1_T1_4-_62";
    case DEUTERON_4_MINUS_S1_T1_63: return "deuteron_S1_T1_4-_63";
    case DEUTERON_4_MINUS_S1_T1_64: return "deuteron_S1_T1_4-_64";
    case DEUTERON_4_MINUS_S1_T1_65: return "deuteron_S1_T1_4-_65";
    case DEUTERON_4_MINUS_S1_T1_66: return "deuteron_S1_T1_4-_66";
    case DEUTERON_4_MINUS_S1_T1_67: return "deuteron_S1_T1_4-_67";
    case DEUTERON_4_MINUS_S1_T1_68: return "deuteron_S1_T1_4-_68";
    case DEUTERON_4_MINUS_S1_T1_69: return "deuteron_S1_T1_4-_69";
    case DEUTERON_4_MINUS_S1_T1_70: return "deuteron_S1_T1_4-_70";
    case DEUTERON_4_MINUS_S1_T1_71: return "deuteron_S1_T1_4-_71";
    case DEUTERON_4_MINUS_S1_T1_72: return "deuteron_S1_T1_4-_72";
    case DEUTERON_4_MINUS_S1_T1_73: return "deuteron_S1_T1_4-_73";
    case DEUTERON_4_MINUS_S1_T1_74: return "deuteron_S1_T1_4-_74";
    case DEUTERON_4_MINUS_S1_T1_75: return "deuteron_S1_T1_4-_75";
    case DEUTERON_4_MINUS_S1_T1_76: return "deuteron_S1_T1_4-_76";
    case DEUTERON_4_MINUS_S1_T1_77: return "deuteron_S1_T1_4-_77";
    case DEUTERON_4_MINUS_S1_T1_78: return "deuteron_S1_T1_4-_78";
    case DEUTERON_4_MINUS_S1_T1_79: return "deuteron_S1_T1_4-_79";
    case DEUTERON_4_MINUS_S1_T1_80: return "deuteron_S1_T1_4-_80";
    case DEUTERON_4_MINUS_S1_T1_81: return "deuteron_S1_T1_4-_81";
    case DEUTERON_4_MINUS_S1_T1_82: return "deuteron_S1_T1_4-_82";
    case DEUTERON_4_MINUS_S1_T1_83: return "deuteron_S1_T1_4-_83";
    case DEUTERON_4_MINUS_S1_T1_84: return "deuteron_S1_T1_4-_84";
    case DEUTERON_4_MINUS_S1_T1_85: return "deuteron_S1_T1_4-_85";
    case DEUTERON_4_MINUS_S1_T1_86: return "deuteron_S1_T1_4-_86";
    case DEUTERON_4_MINUS_S1_T1_87: return "deuteron_S1_T1_4-_87";
    case DEUTERON_4_MINUS_S1_T1_88: return "deuteron_S1_T1_4-_88";
    case DEUTERON_4_MINUS_S1_T1_89: return "deuteron_S1_T1_4-_89";
    case DEUTERON_4_MINUS_S1_T1_90: return "deuteron_S1_T1_4-_90";
    case DEUTERON_4_MINUS_S1_T1_91: return "deuteron_S1_T1_4-_91";
    case DEUTERON_4_MINUS_S1_T1_92: return "deuteron_S1_T1_4-_92";
    case DEUTERON_4_MINUS_S1_T1_93: return "deuteron_S1_T1_4-_93";
    case DEUTERON_4_MINUS_S1_T1_94: return "deuteron_S1_T1_4-_94";
    case DEUTERON_4_MINUS_S1_T1_95: return "deuteron_S1_T1_4-_95";
    case DEUTERON_4_MINUS_S1_T1_96: return "deuteron_S1_T1_4-_96";
    case DEUTERON_4_MINUS_S1_T1_97: return "deuteron_S1_T1_4-_97";
    case DEUTERON_4_MINUS_S1_T1_98: return "deuteron_S1_T1_4-_98";
    case DEUTERON_4_MINUS_S1_T1_99: return "deuteron_S1_T1_4-_99";

    case DEUTERON_5_MINUS_S1_T1:    return "deuteron_S1_T1_5-";
    case DEUTERON_5_MINUS_S1_T1_0:  return "deuteron_S1_T1_5-_0";
    case DEUTERON_5_MINUS_S1_T1_1:  return "deuteron_S1_T1_5-_1";
    case DEUTERON_5_MINUS_S1_T1_2:  return "deuteron_S1_T1_5-_2";
    case DEUTERON_5_MINUS_S1_T1_3:  return "deuteron_S1_T1_5-_3";
    case DEUTERON_5_MINUS_S1_T1_4:  return "deuteron_S1_T1_5-_4";
    case DEUTERON_5_MINUS_S1_T1_5:  return "deuteron_S1_T1_5-_5";
    case DEUTERON_5_MINUS_S1_T1_6:  return "deuteron_S1_T1_5-_6";
    case DEUTERON_5_MINUS_S1_T1_7:  return "deuteron_S1_T1_5-_7";
    case DEUTERON_5_MINUS_S1_T1_8:  return "deuteron_S1_T1_5-_8";
    case DEUTERON_5_MINUS_S1_T1_9:  return "deuteron_S1_T1_5-_9";
    case DEUTERON_5_MINUS_S1_T1_10: return "deuteron_S1_T1_5-_10";
    case DEUTERON_5_MINUS_S1_T1_11: return "deuteron_S1_T1_5-_11";
    case DEUTERON_5_MINUS_S1_T1_12: return "deuteron_S1_T1_5-_12";
    case DEUTERON_5_MINUS_S1_T1_13: return "deuteron_S1_T1_5-_13";
    case DEUTERON_5_MINUS_S1_T1_14: return "deuteron_S1_T1_5-_14";
    case DEUTERON_5_MINUS_S1_T1_15: return "deuteron_S1_T1_5-_15";
    case DEUTERON_5_MINUS_S1_T1_16: return "deuteron_S1_T1_5-_16";
    case DEUTERON_5_MINUS_S1_T1_17: return "deuteron_S1_T1_5-_17";
    case DEUTERON_5_MINUS_S1_T1_18: return "deuteron_S1_T1_5-_18";
    case DEUTERON_5_MINUS_S1_T1_19: return "deuteron_S1_T1_5-_19";
    case DEUTERON_5_MINUS_S1_T1_20: return "deuteron_S1_T1_5-_20";
    case DEUTERON_5_MINUS_S1_T1_21: return "deuteron_S1_T1_5-_21";
    case DEUTERON_5_MINUS_S1_T1_22: return "deuteron_S1_T1_5-_22";
    case DEUTERON_5_MINUS_S1_T1_23: return "deuteron_S1_T1_5-_23";
    case DEUTERON_5_MINUS_S1_T1_24: return "deuteron_S1_T1_5-_24";
    case DEUTERON_5_MINUS_S1_T1_25: return "deuteron_S1_T1_5-_25";
    case DEUTERON_5_MINUS_S1_T1_26: return "deuteron_S1_T1_5-_26";
    case DEUTERON_5_MINUS_S1_T1_27: return "deuteron_S1_T1_5-_27";
    case DEUTERON_5_MINUS_S1_T1_28: return "deuteron_S1_T1_5-_28";
    case DEUTERON_5_MINUS_S1_T1_29: return "deuteron_S1_T1_5-_29";
    case DEUTERON_5_MINUS_S1_T1_30: return "deuteron_S1_T1_5-_30";
    case DEUTERON_5_MINUS_S1_T1_31: return "deuteron_S1_T1_5-_31";
    case DEUTERON_5_MINUS_S1_T1_32: return "deuteron_S1_T1_5-_32";
    case DEUTERON_5_MINUS_S1_T1_33: return "deuteron_S1_T1_5-_33";
    case DEUTERON_5_MINUS_S1_T1_34: return "deuteron_S1_T1_5-_34";
    case DEUTERON_5_MINUS_S1_T1_35: return "deuteron_S1_T1_5-_35";
    case DEUTERON_5_MINUS_S1_T1_36: return "deuteron_S1_T1_5-_36";
    case DEUTERON_5_MINUS_S1_T1_37: return "deuteron_S1_T1_5-_37";
    case DEUTERON_5_MINUS_S1_T1_38: return "deuteron_S1_T1_5-_38";
    case DEUTERON_5_MINUS_S1_T1_39: return "deuteron_S1_T1_5-_39";
    case DEUTERON_5_MINUS_S1_T1_40: return "deuteron_S1_T1_5-_40";
    case DEUTERON_5_MINUS_S1_T1_41: return "deuteron_S1_T1_5-_41";
    case DEUTERON_5_MINUS_S1_T1_42: return "deuteron_S1_T1_5-_42";
    case DEUTERON_5_MINUS_S1_T1_43: return "deuteron_S1_T1_5-_43";
    case DEUTERON_5_MINUS_S1_T1_44: return "deuteron_S1_T1_5-_44";
    case DEUTERON_5_MINUS_S1_T1_45: return "deuteron_S1_T1_5-_45";
    case DEUTERON_5_MINUS_S1_T1_46: return "deuteron_S1_T1_5-_46";
    case DEUTERON_5_MINUS_S1_T1_47: return "deuteron_S1_T1_5-_47";
    case DEUTERON_5_MINUS_S1_T1_48: return "deuteron_S1_T1_5-_48";
    case DEUTERON_5_MINUS_S1_T1_49: return "deuteron_S1_T1_5-_49";
    case DEUTERON_5_MINUS_S1_T1_50: return "deuteron_S1_T1_5-_50";
    case DEUTERON_5_MINUS_S1_T1_51: return "deuteron_S1_T1_5-_51";
    case DEUTERON_5_MINUS_S1_T1_52: return "deuteron_S1_T1_5-_52";
    case DEUTERON_5_MINUS_S1_T1_53: return "deuteron_S1_T1_5-_53";
    case DEUTERON_5_MINUS_S1_T1_54: return "deuteron_S1_T1_5-_54";
    case DEUTERON_5_MINUS_S1_T1_55: return "deuteron_S1_T1_5-_55";
    case DEUTERON_5_MINUS_S1_T1_56: return "deuteron_S1_T1_5-_56";
    case DEUTERON_5_MINUS_S1_T1_57: return "deuteron_S1_T1_5-_57";
    case DEUTERON_5_MINUS_S1_T1_58: return "deuteron_S1_T1_5-_58";
    case DEUTERON_5_MINUS_S1_T1_59: return "deuteron_S1_T1_5-_59";
    case DEUTERON_5_MINUS_S1_T1_60: return "deuteron_S1_T1_5-_60";
    case DEUTERON_5_MINUS_S1_T1_61: return "deuteron_S1_T1_5-_61";
    case DEUTERON_5_MINUS_S1_T1_62: return "deuteron_S1_T1_5-_62";
    case DEUTERON_5_MINUS_S1_T1_63: return "deuteron_S1_T1_5-_63";
    case DEUTERON_5_MINUS_S1_T1_64: return "deuteron_S1_T1_5-_64";
    case DEUTERON_5_MINUS_S1_T1_65: return "deuteron_S1_T1_5-_65";
    case DEUTERON_5_MINUS_S1_T1_66: return "deuteron_S1_T1_5-_66";
    case DEUTERON_5_MINUS_S1_T1_67: return "deuteron_S1_T1_5-_67";
    case DEUTERON_5_MINUS_S1_T1_68: return "deuteron_S1_T1_5-_68";
    case DEUTERON_5_MINUS_S1_T1_69: return "deuteron_S1_T1_5-_69";
    case DEUTERON_5_MINUS_S1_T1_70: return "deuteron_S1_T1_5-_70";
    case DEUTERON_5_MINUS_S1_T1_71: return "deuteron_S1_T1_5-_71";
    case DEUTERON_5_MINUS_S1_T1_72: return "deuteron_S1_T1_5-_72";
    case DEUTERON_5_MINUS_S1_T1_73: return "deuteron_S1_T1_5-_73";
    case DEUTERON_5_MINUS_S1_T1_74: return "deuteron_S1_T1_5-_74";
    case DEUTERON_5_MINUS_S1_T1_75: return "deuteron_S1_T1_5-_75";
    case DEUTERON_5_MINUS_S1_T1_76: return "deuteron_S1_T1_5-_76";
    case DEUTERON_5_MINUS_S1_T1_77: return "deuteron_S1_T1_5-_77";
    case DEUTERON_5_MINUS_S1_T1_78: return "deuteron_S1_T1_5-_78";
    case DEUTERON_5_MINUS_S1_T1_79: return "deuteron_S1_T1_5-_79";
    case DEUTERON_5_MINUS_S1_T1_80: return "deuteron_S1_T1_5-_80";
    case DEUTERON_5_MINUS_S1_T1_81: return "deuteron_S1_T1_5-_81";
    case DEUTERON_5_MINUS_S1_T1_82: return "deuteron_S1_T1_5-_82";
    case DEUTERON_5_MINUS_S1_T1_83: return "deuteron_S1_T1_5-_83";
    case DEUTERON_5_MINUS_S1_T1_84: return "deuteron_S1_T1_5-_84";
    case DEUTERON_5_MINUS_S1_T1_85: return "deuteron_S1_T1_5-_85";
    case DEUTERON_5_MINUS_S1_T1_86: return "deuteron_S1_T1_5-_86";
    case DEUTERON_5_MINUS_S1_T1_87: return "deuteron_S1_T1_5-_87";
    case DEUTERON_5_MINUS_S1_T1_88: return "deuteron_S1_T1_5-_88";
    case DEUTERON_5_MINUS_S1_T1_89: return "deuteron_S1_T1_5-_89";
    case DEUTERON_5_MINUS_S1_T1_90: return "deuteron_S1_T1_5-_90";
    case DEUTERON_5_MINUS_S1_T1_91: return "deuteron_S1_T1_5-_91";
    case DEUTERON_5_MINUS_S1_T1_92: return "deuteron_S1_T1_5-_92";
    case DEUTERON_5_MINUS_S1_T1_93: return "deuteron_S1_T1_5-_93";
    case DEUTERON_5_MINUS_S1_T1_94: return "deuteron_S1_T1_5-_94";
    case DEUTERON_5_MINUS_S1_T1_95: return "deuteron_S1_T1_5-_95";
    case DEUTERON_5_MINUS_S1_T1_96: return "deuteron_S1_T1_5-_96";
    case DEUTERON_5_MINUS_S1_T1_97: return "deuteron_S1_T1_5-_97";
    case DEUTERON_5_MINUS_S1_T1_98: return "deuteron_S1_T1_5-_98";
    case DEUTERON_5_MINUS_S1_T1_99: return "deuteron_S1_T1_5-_99";

    default: error_message_print_abort ("No cluster recognized in string_routines::cluster_string_for_file_name");
    }

  return "";
}


string string_routines::intrinsic_CM_cluster_string (
						     const enum particle_type cluster , 
						     const double M_intrinsic , 
						     const int NCM , 
						     const int LCM , 
						     const int M_LCM)
{	
  const string cluster_str = make_string<enum particle_type> (cluster);

  const string M_intrinsic_string = " intrinsic:" + M_string (M_intrinsic);

  const string PSI_CM_string = " CM:" + CM_cluster_string (NCM , LCM , M_LCM);

  const string PSI_string = cluster_str + M_intrinsic_string + PSI_CM_string;

  return PSI_string;
}

string string_routines::intrinsic_CM_cluster_string (
						     const enum particle_type cluster , 
						     const int NCM , 
						     const int LCM , 
						     const double J)
{
  const int A_cluster = A_projectile_determine (cluster);

  const string space_for_two_body_cluster = (A_cluster == 2) ? (" ") : ("");

  const string cluster_str = make_string<enum particle_type> (cluster);

  const string angular_state_cluster_string = " " + make_string<int> (NCM) + space_for_two_body_cluster + angular_state_cluster (cluster , LCM , J);

  const string PSI_string = cluster_str + angular_state_cluster_string;

  return PSI_string;
}


string string_routines::intrinsic_CM_cluster_string (
						     const enum particle_type cluster , 
						     const int NCM , 
						     const int LCM , 
						     const double J , 
						     const double M)
{
  const int A_cluster = A_projectile_determine (cluster);

  const string space_for_two_body_cluster = (A_cluster == 2) ? (" ") : ("");

  const string cluster_str = make_string<enum particle_type> (cluster);

  const string angular_state_cluster_string = " " + make_string<int> (NCM) + space_for_two_body_cluster + angular_state_cluster (cluster , LCM , J);

  const string M_projectile_string = " " + M_string (M);

  const string PSI_string = cluster_str + angular_state_cluster_string + M_projectile_string;

  return PSI_string;
}






string string_routines::CM_cluster_string_for_file_name (
							 const int NCM , 
							 const int LCM)
{
  return (make_string<int> (NCM) + angular_state_cluster_CM (LCM));
}

string string_routines::CM_cluster_string_for_file_name (
							 const int NCM , 
							 const int LCM , 
							 const int M_LCM)
{
  return (make_string<int> (NCM) + angular_state_cluster_CM (LCM) + "_" + make_string<int> (M_LCM));
}

string string_routines::file_name_intrinsic_CM_cluster_string (
							       const string &PSI_str , 
							       const enum particle_type cluster , 
							       const double M_intrinsic , 
							       const int NCM , 
							       const int LCM , 
							       const int M_LCM)
{	
  const string cluster_str = "_" + cluster_string_for_file_name (cluster);

  const string M_intrinsic_string = "_intrinsic_" + M_string_for_file_name (M_intrinsic);

  const string PSI_CM_string = "_CM_" + CM_cluster_string_for_file_name (NCM , LCM , M_LCM);

  const string PSI_string = STORAGE_DIR + PSI_str + cluster_str + M_intrinsic_string + PSI_CM_string;

  return PSI_string;
}

string string_routines::intrinsic_CM_cluster_string_for_file_name (
								   const enum particle_type cluster , 
								   const int NCM , 
								   const int LCM , 
								   const double J)
{
  const int A_cluster = A_projectile_determine (cluster);

  const string underscore_for_two_body_cluster = (A_cluster == 2) ? ("_") : ("");
	
  const string cluster_str = cluster_string_for_file_name (cluster);

  const string angular_state_cluster_string = "_" + make_string<int> (NCM) + underscore_for_two_body_cluster + angular_state_cluster_for_file_name (cluster , LCM , J);

  const string cluster_NLJ_CM_string = cluster_str + angular_state_cluster_string;

  return cluster_NLJ_CM_string;
}



string string_routines::intrinsic_CM_cluster_string_for_file_name (
								   const enum particle_type cluster , 
								   const int NCM , 
								   const int LCM , 
								   const double J , 
								   const double M)
{
  const string cluster_NLJ_CM_string = intrinsic_CM_cluster_string_for_file_name (cluster , NCM , LCM , J);

  const string M_projectile_string = "_" + M_string_for_file_name (M);

  const string cluster_NLJM_CM_string = cluster_NLJ_CM_string + M_projectile_string;

  return cluster_NLJM_CM_string;
}




string string_routines::file_name_intrinsic_CM_cluster_string (
							       const string &PSI_str , 
							       const enum particle_type cluster , 
							       const int NCM , 
							       const int LCM , 
							       const double J)
{
  const string cluster_NLJ_CM_string = intrinsic_CM_cluster_string_for_file_name (cluster , NCM , LCM , J);

  const string PSI_cluster_string = STORAGE_DIR + PSI_str + "_" + cluster_NLJ_CM_string;

  return PSI_cluster_string;
}

string string_routines::file_name_intrinsic_CM_cluster_string (
							       const string &PSI_str , 
							       const enum particle_type cluster , 
							       const int NCM , 
							       const int LCM , 
							       const double J , 
							       const double M)
{	
  const string cluster_NLJM_CM_string = intrinsic_CM_cluster_string_for_file_name (cluster , NCM , LCM , J , M);

  const string PSI_cluster_string = STORAGE_DIR + PSI_str + "_" + cluster_NLJM_CM_string;

  return PSI_cluster_string;
}



string string_routines::file_name_J_Pi_string (
					       const string &file_name_debut , 
					       const unsigned int BP , 
					       const double J)
{
  const string file_name = STORAGE_DIR + file_name_debut + "_" + J_Pi_string_for_file_name (BP , J);

  return file_name;
}

string string_routines::file_name_M_Pi_string (
					       const string &file_name_debut , 
					       const unsigned int BP , 
					       const double M)
{
  const string file_name = STORAGE_DIR + file_name_debut + "_" + M_Pi_string_for_file_name (BP , M);

  return file_name;
}


string string_routines::make_string_length (const string str_ , const unsigned int tot_length_)
{
  const unsigned int str_length = str_.length ();
  
  if (str_length > tot_length_)
    {
      cerr << "make_string_length: tot_length_ is larger than str_ (" << str_ << ") length" << endl;

      abort_all ();
    }

  const unsigned int diff_length = tot_length_ - str_length;

  unsigned int i = 0;
  string new_str = str_;
  
  while (i < diff_length)
    {
      new_str += " ";
      i++;
    }

  return new_str;
}

string string_routines::file_name_J_string (const double J)
{
  const int two_J = make_int (2.0*J);

  ostringstream os;

  if (two_J%2 == 0)
    {
      os << make_int (J);
    }

  if (two_J%2 != 0)
    {
      os << two_J << "I2";
    }

  return os.str ();
}

// Determination of the string used to define the directory in which data related to a node are stored for 2D partitioning
string string_routines::node_string_determine (const bool full_common_vectors_used_in_file , const unsigned int process)
{

#ifdef UseMPI

  const string node_string = (full_common_vectors_used_in_file) ? ("") : ("node_" + make_string<unsigned int> (process) + "/");

#else

  if (process != MASTER_PROCESS) error_message_print_abort ("Master process only in node_string_determine for a sequential calculation");

  const string node_string = (full_common_vectors_used_in_file) ? ("") : (""); // to avoid a warning telling that full_common_vectors_used_in_file is not used

#endif

  return node_string;
}

// Determination of the string related to J+ and J- phases calculations
string string_routines::Jpm_str_determine (
					   const bool is_it_both_Jplus_Jminus ,
					   const int pm)
{
  if (is_it_both_Jplus_Jminus)
    {
      const string Jpm_str = "J+ and J-";
  
      return Jpm_str;
    }
  
  const string Jpm_str = (pm == 1) ? ("J+") : ("J-");
	  
  return Jpm_str;
}




