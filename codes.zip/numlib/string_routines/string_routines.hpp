#ifndef STRING_ROUTINES_HPP
#define STRING_ROUTINES_HPP

namespace string_routines
{
  // Make a string from a given type so it can be inserted in another string
  // -----------------------------------------------------------------------
  template<typename T>
  string make_string (const T &x)
  {
    ostringstream os;
    os.precision (15);

    os << x;

    return os.str ();
  }

  string angular_state (const int l , const double j);
  string angular_state_two_body_cluster (const int S , const int L , const double J);
  string angular_state_cluster_CM (const int L);
  string angular_state_cluster_CM_intrinsic_spin (const int L , const double J);
  string angular_state_cluster (const enum particle_type cluster , const int LCM , const double J);
  string angular_state_relative_cluster (const enum particle_type ST_cluster , const int l_relative , const double j_relative);

  string angular_state_for_file_name (const int l , const double j);
  string angular_state_two_body_cluster_for_file_name (const int S , const int L , const double J);
  string angular_state_cluster_CM_intrinsic_spin_for_file_name (const int L , const double J);
  string angular_state_cluster_CM_for_file_name (const int L);
  string angular_state_cluster_for_file_name (const enum particle_type cluster , const int LCM , const double J);
  string angular_state_relative_cluster_for_file_name (const enum particle_type ST_cluster , const int l_relative , const double j_relative);

  int determine_n (const string &shell);
  int determine_l (const string &shell);
  int determine_L_cluster (const enum particle_type cluster , const string &shell);

  int determine_jr (const string &shell);
  
  double determine_j (const string &shell);
  
  double determine_J_cluster (const string &shell);
  double determine_M_cluster (const string &shell);

  double determine_half_integer_J (const string &s);
  double determine_half_integer_M (const string &s);  
  double determine_half_integer_T (const string &s);

  double determine_integer_J (const string &s);
  double determine_integer_M (const string &s);
  double determine_integer_T (const string &s);

  double determine_J (const string &s);  
  double determine_M (const string &s);

  unsigned int determine_Binary_Parity (const string &s);

  bool bool_determination_no_print (const string &words);
  bool bool_determination_no_print (ifstream &file , const string &words);

  bool bool_determination (const string &words);
  bool bool_determination (ifstream &file , const string &words);

  void word_check (const string &expected_string);
  void word_check (ifstream &file , const string &expected_string);

  void check_partial_wave_nucleon (
				   const int l ,
				   const double j);
  
  void check_partial_wave (const enum particle_type particle , const int LCM , const double J);
  
  void check_relative_partial_wave (const int l_relative , const int j_relative);

  void quantum_numbers_read (unsigned int &BP , int &J , unsigned int &vector_index);
  void quantum_numbers_read (ifstream &file , unsigned int &BP , int &J , unsigned int &vector_index);
  void quantum_numbers_read (unsigned int &BP , double &J , unsigned int &vector_index);
  void quantum_numbers_read (ifstream &file , unsigned int &BP , double &J , unsigned int &vector_index);

  string Pi_string (const unsigned int BP);
  string J_string (const double J);
  string M_string (const double J);
  string T_string (const double T);

  string J_Pi_string (const unsigned int BP , const double J);
  string M_Pi_string (const unsigned int BP , const double M);
  string JM_string (const double J , const double M);
  string JM_Pi_string (const unsigned int BP , const double J , const double M);

  string J_Pi_vector_index_string (const unsigned int BP , const double J , const unsigned int vector_index);
  string M_Pi_vector_index_string (const unsigned int BP , const double J , const unsigned int vector_index);
  string JM_Pi_vector_index_string (const unsigned int BP , const double J , const unsigned int vector_index , const double M);

  string Pi_string_for_file_name (const unsigned int BP);
  string J_string_for_file_name (const double J);
  string M_string_for_file_name (const double M);
  string T_string_for_file_name (const double T);

  string J_Pi_string_for_file_name (const unsigned int BP , const double J);
  string M_Pi_string_for_file_name (const unsigned int BP , const double M);
  string JM_string_for_file_name (const double J , const double M);
  string JM_Pi_string_for_file_name (const unsigned int BP , const double J , const double M);

  string J_Pi_vector_index_string_for_file_name (const unsigned int BP , const double J , const unsigned int vector_index);
  string M_Pi_vector_index_string_for_file_name (const unsigned int BP , const double J , const unsigned int vector_index);
  string JM_Pi_vector_index_string_for_file_name (const unsigned int BP , const double J , const unsigned int vector_index , const double M);

  string CM_cluster_string (const int NCM , const int LCM);
  string CM_cluster_string (const int NCM , const int LCM , const int M_LCM);

  string cluster_string_for_file_name (const enum particle_type cluster);

  string intrinsic_CM_cluster_string (const enum particle_type cluster , const double M_intrinsic , const int NCM , const int LCM , const int M_LCM);

  string intrinsic_CM_cluster_string (const enum particle_type cluster , const int NCM , const int LCM , const double J);
  string intrinsic_CM_cluster_string (const enum particle_type cluster , const int NCM , const int LCM , const double J , const double M);

  string CM_cluster_string_for_file_name (const int NCM , const int LCM);
  string CM_cluster_string_for_file_name (const int NCM , const int LCM , const int M_LCM);

  string intrinsic_CM_cluster_string_for_file_name (const enum particle_type cluster , const int NCM , const int LCM , const double J);
  string intrinsic_CM_cluster_string_for_file_name (const enum particle_type cluster , const int NCM , const int LCM , const double J , const double M);

  string file_name_intrinsic_CM_cluster_string (const string &PSI_str , const enum particle_type cluster , const double M_intrinsic , const int NCM , const int LCM , const int M_LCM);

  string file_name_intrinsic_CM_cluster_string (const string &PSI_str , const enum particle_type cluster , const int NCM , const int LCM , const double J);
  string file_name_intrinsic_CM_cluster_string (const string &PSI_str , const enum particle_type cluster , const int NCM , const int LCM , const double J , const double M);

  string file_name_J_Pi_string (const string &file_name_debut , const unsigned int BP , const double J);
  string file_name_M_Pi_string (const string &file_name_debut , const unsigned int BP , const double J);

  // Determination of the string used to define the directory in which data related to a node are stored for 2D partitioning
  string node_string_determine (const bool full_common_vectors_used_in_file , const unsigned int process);

  template<class C>
  void word_check_print (const string &expected_string , const C &object)
  {
    string input_string;
    cin >> input_string;

    if (input_string == expected_string)
      {
	cout << object << " " << expected_string << endl;
      }
    else
      error_message_print_abort ("Problem : " + make_string<C> (object) + " " + expected_string + " (expected) ---- " + input_string + " (input)");
  }

  template<class C>
  void word_check_print (
			 ifstream &file , 
			 const string &expected_string , 
			 const C &object)
  {
    string input_string;
    file >> input_string;

    if (input_string == expected_string)
      {
	cout << object << " " << expected_string << endl;
      }
    else
      error_message_print_abort ("Problem : " + make_string<C> (object) + " " + expected_string + " (expected) ---- " + input_string + " (input)");
  }

  //--// get the range (min , max , step) of double type values like word_check_print
  void val_range_check_print (
			      ifstream &file_ , 
			      const string &correct_string_min_ , 
			      double &val_min_ , 
			      const string &correct_string_max_ , 
			      double &val_max_ , 
			      const string &correct_string_n_step_ , 
			      unsigned int &n_step_);


  string make_string_length (const string str_ , const unsigned int tot_length_);

  string file_name_J_string (const double J);
  
  string Jpm_str_determine (
			    const bool is_it_both_Jplus_Jminus ,
			    const int pm);
}

#endif
