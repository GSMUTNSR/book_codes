#ifndef QUICK_SORT_H
#define QUICK_SORT_H


//:::// low key , to be change in medium key a[(first + middle + last)/3]





//--// swap two values of a vector and the corresponding two values of the associated vector
template<typename type>
void swap (vector<type> &a , vector<type> &b , const unsigned int index_0 , const unsigned int index_1)
{
  swap<type> (a[index_0] , a[index_1]);
  swap<type> (b[index_0] , b[index_1]);
}



//--// swap two values of a vector and the corresponding two values of the associated vector
template<typename type , typename type_>
void swap (vector<type> &a , vector<type_> &b , const unsigned int index_0 , const unsigned int index_1)
{
  swap<type> (a[index_0] , a[index_1]);
  swap<type_> (b[index_0] , b[index_1]);
}


//--// swap two lines of a buffer
template<typename type>
void swap (vector<type> &a , unsigned int num_col_ , const unsigned int index_0 , const unsigned int index_1)
{
  //--// indexes at each begin of line where index_0/1 appear
  unsigned int i = index_0 - (index_0 % num_col_);
  unsigned int j = index_1 - (index_1 % num_col_);


  //--// for each element of the lines
  unsigned int k = 0;
  while (k < num_col_)
    {
      type tempo;

      tempo = a[i];
      a[i] = a[j];
      a[j] = tempo;

      i++;
      j++;
      k++;
    }
}




//--// quicksort algorithmn for an arbitrary array of a given type, with existing or overloaded comparison operators


//================================== std table ==================================//

template<typename type>
void quick_sort (type a[] , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;
  
  const type pivot = a[pivot_index];
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while (a[i_sort] < pivot) i_sort++;
      while (a[j_sort] > pivot) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort (a , low , j_sort);

  if (i_sort < high) quick_sort (a , i_sort , high);
}





//================================== std vector ==================================//


//--// quicksort algorithmn for vector of a given type, with existing or overloaded comparison operators
template<typename type>
void quick_sort (vector<type>  &a , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const type pivot = a[pivot_index];
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while (a[i_sort] < pivot)	i_sort++;
      while (a[j_sort] > pivot)	j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort (a , low , j_sort);

  if (i_sort < high) quick_sort (a , i_sort , high);
}



//--// quicksort algorithmn for a vector of arbitrary type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified excatly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type>
void quick_sort (vector<type> &a , vector<type> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }

  const int pivot_index = low + (high - low)/2;

  const type pivot = a[pivot_index];
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while (a[i_sort] < pivot)	i_sort++;
      while (a[j_sort] > pivot)	j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , b , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort (a , b , low , j_sort);

  if (i_sort < high) quick_sort (a , b , i_sort , high);
}




//--// quicksort algorithmn for a vector of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified exactly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type , typename type_>
void quick_sort (vector<type>  &a , vector<type_> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }

  const int pivot_index = low + (high - low)/2;

  const type pivot = a[pivot_index];
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while (a[i_sort] < pivot)	i_sort++;
      while (a[j_sort] > pivot)	j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  swap<type> (b[i_sort] , b[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort (a , b , low , j_sort);

  if (i_sort < high) quick_sort (a , b , i_sort , high);
}




//================================== buffer (vector) ==================================//



//--// quicksort algorithmn for buffer of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger

template<typename type>
void quick_sort (vector<type> &a , unsigned int num_col_ , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const type pivot = a[pivot_index];
    
  int i_sort = low;
  int j_sort = high;

  do
    {
      while (a[i_sort] < pivot)	i_sort++;
      while (a[j_sort] > pivot)	j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , num_col_ , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort (a , num_col_ , low , j_sort);

  if (i_sort < high) quick_sort (a , num_col_ , i_sort , high);	
}





//--// quicksort algorithmn for an arbitrary array of a scalar type, using real part to sort

//================================== std table ==================================//

template<typename type>
void quick_sort_by_real_part (type a[] , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot = real_dc (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((real_dc (a[i_sort]) < pivot) && (abs (real_dc (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (a[j_sort]) > pivot) && (abs (real_dc (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_real_part (a , low , j_sort);

  if (i_sort < high) quick_sort_by_real_part (a , i_sort , high);
}





//================================== std vector ==================================//


//--// quicksort algorithmn for vector of a given type, with existing or overloaded comparison operators
template<typename type>
void quick_sort_by_real_part (vector<type>  &a , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;
  
  const double pivot = real_dc (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((real_dc (a[i_sort]) < pivot) && (abs (real_dc (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (a[j_sort]) > pivot) && (abs (real_dc (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_real_part (a , low , j_sort);

  if (i_sort < high) quick_sort_by_real_part (a , i_sort , high);
}



//--// quicksort algorithmn for a vector of arbitrary type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified excatly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type>
void quick_sort_by_real_part (vector<type> &a , vector<type> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort_by_real_part: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }
  
  const int pivot_index = low + (high - low)/2;
  
  const double pivot = real_dc (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((real_dc (a[i_sort]) < pivot) && (abs (real_dc (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (a[j_sort]) > pivot) && (abs (real_dc (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , b , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_real_part (a , b , low , j_sort);

  if (i_sort < high) quick_sort_by_real_part (a , b , i_sort , high);
}




//--// quicksort algorithmn for a vector of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified exactly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type , typename type_>
void quick_sort_by_real_part (vector<type>  &a , vector<type_> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort_by_real_part: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }

  const int pivot_index = low + (high - low)/2;
  
  const double pivot = real_dc (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((real_dc (a[i_sort]) < pivot) && (abs (real_dc (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (a[j_sort]) > pivot) && (abs (real_dc (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  swap<type> (b[i_sort] , b[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_real_part (a , b , low , j_sort);

  if (i_sort < high) quick_sort_by_real_part (a , b , i_sort , high);
}




//================================== buffer (vector) ==================================//



//--// quicksort algorithmn for buffer of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger

template<typename type>
void quick_sort_by_real_part (vector<type> &a , unsigned int num_col_ , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;
  
  const double pivot = real_dc (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((real_dc (a[i_sort]) < pivot) && (abs (real_dc (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (a[j_sort]) > pivot) && (abs (real_dc (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , num_col_ , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_real_part (a , num_col_ , low , j_sort);

  if (i_sort < high) quick_sort_by_real_part (a , num_col_ , i_sort , high);	
}





//--// quicksort algorithmn for an arbitrary array of a scalar type, using abs to sort

//================================== std table ==================================//

template<typename type>
void quick_sort_by_abs (type a[] , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (a[i_sort]) < pivot) && (abs (abs (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((abs (a[j_sort]) > pivot) && (abs (abs (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_abs (a , low , j_sort);

  if (i_sort < high) quick_sort_by_abs (a , i_sort , high);
}





//================================== std vector ==================================//


//--// quicksort algorithmn for vector of a given type, with existing or overloaded comparison operators
template<typename type>
void quick_sort_by_abs (vector<type>  &a , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (a[i_sort]) < pivot) && (abs (abs (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((abs (a[j_sort]) > pivot) && (abs (abs (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_abs (a , low , j_sort);

  if (i_sort < high) quick_sort_by_abs (a , i_sort , high);
}



//--// quicksort algorithmn for a vector of arbitrary type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified excatly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type>
void quick_sort_by_abs (vector<type> &a , vector<type> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort_by_abs: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }
  
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (a[i_sort]) < pivot) && (abs (abs (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((abs (a[j_sort]) > pivot) && (abs (abs (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , b , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_abs (a , b , low , j_sort);

  if (i_sort < high) quick_sort_by_abs (a , b , i_sort , high);
}




//--// quicksort algorithmn for a vector of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger
//--// the second vector (annex) is modified exactly like the first (preserve the association vec[i] <--> vec_annex[i])


template<typename type , typename type_>
void quick_sort_by_abs (vector<type>  &a , vector<type_> &b , const int low , const int high)
{
  if (a.size () != b.size ())
    {
      cerr << "------ quick_sort_by_abs: associated vectors do not have the same size ------" << endl;

      abort_all ();
    }
  
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (a[i_sort]) < pivot) && (abs (abs (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((abs (a[j_sort]) > pivot) && (abs (abs (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a[i_sort] , a[j_sort]);
	  swap<type> (b[i_sort] , b[j_sort]);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_abs (a , b , low , j_sort);

  if (i_sort < high) quick_sort_by_abs (a , b , i_sort , high);
}




//================================== buffer (vector) ==================================//



//--// quicksort algorithmn for buffer of a given type, with existing or overloaded comparison operators
//--// sort from the smaller to the bigger

template<typename type>
void quick_sort_by_abs (vector<type> &a , unsigned int num_col_ , const int low , const int high)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (a[pivot_index]);
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (a[i_sort]) < pivot) && (abs (abs (a[i_sort]) - pivot) > 1E-14)) i_sort++;
      while ((abs (a[j_sort]) > pivot) && (abs (abs (a[j_sort]) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<type> (a , num_col_ , i_sort , j_sort);
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) quick_sort_by_abs (a , num_col_ , low , j_sort);

  if (i_sort < high) quick_sort_by_abs (a , num_col_ , i_sort , high);	
}






#endif
