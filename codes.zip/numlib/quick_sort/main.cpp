#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    //--// reset of the seed to time (0)
    seed ();

    clog << "------ test of quick_sort for int ------" << endl;
    
    class array<int> tab_i (5);

    tab_i (0) =  6;
    tab_i (1) =  5;
    tab_i (2) =  4;
    tab_i (3) =  3;
    tab_i (4) = -5;


    for (unsigned int i = 0 ; i < tab_i.dimension (0) ; i++)
      {
	clog << tab_i (i) << endl;
      }

    clog << "------ test ------" << endl;
    
    tab_i.quick_sort (0 , tab_i.dimension (0) - 1);

    for (unsigned int i = 0 ; i < tab_i.dimension (0) ; i++) clog << tab_i (i) << endl;
    
    clog << "------ test of quick_sort for double ------" << endl;

    class array<double> tab (10);

    for (unsigned int i = 0 ; i < tab.dimension (0) ; i++)
      {
	tab (i) = random_number<double> ();

	clog << tab (i) << endl;
      }

    clog << "------ test ------" << endl;

    tab.quick_sort (0 , tab.dimension (0) - 1);

    for (unsigned int i = 0 ; i < tab.dimension (0) ; i++) clog << tab (i) << endl;
    
    clog << "------ test of quick_sort_by_real_part for complex<double> ------" << endl;

    class array<complex<double> > tab_cx (10);

    for (unsigned int i = 0 ; i < tab_cx.dimension (0) ; i++)
      {
	tab_cx (i) = random_number<complex<double> > ();

	clog << tab_cx (i) << endl;
      }


    clog << "------ test ------" << endl;
    
    //quick_sort_by_real_part (tab_cx , 0 , tab_cx.dimension (0) - 1);

    tab_cx.quick_sort_by_real_part (0 , tab_cx.dimension (0) - 1);

    for (unsigned int i = 0 ; i < tab_cx.dimension (0) ; i++) clog << tab_cx (i) << endl;
    
    clog << "------ test of quick_sort for vector<double> ------" << endl;

    vector<double> vec (10);

    double t[10];

    for (unsigned int i = 0 ; i < vec.size () ; i++)
      {
	vec[i] = random_number<double> ();

	t[i] = vec[i];

	clog << vec[i] << " " << t[i] << endl;
      }


    clog << "------ test ------" << endl;
    
    quick_sort<double> (vec , 0 , vec.size () - 1);

    quick_sort<double> (t , 0 , 9);

    for (unsigned int i = 0 ; i < vec.size () ; i++) clog << vec[i] << " " << t[i] << endl;
    
    cerr << "--------------------------- test vec asso --------------------------" << endl;

    vector<complex<double> > vec_cx_asso (10);
    
    vector<complex<double> > vec_cx_asso_annex (10);

    for (unsigned int i = 0 ; i < vec_cx_asso.size () ; i++)
      {
	const complex<double> cx_i (sin (i) , i/2.0);

	vec_cx_asso[i] = cx_i;

	vec_cx_asso_annex[i] = i;
      }

    cerr << "--------------------------- before --------------------------" << endl;

    for (unsigned int i = 0 ; i < vec_cx_asso.size () ; i++) cerr << vec_cx_asso[i] << " " << vec_cx_asso_annex[i] << endl;
    
    cerr << "--------------------------- after --------------------------" << endl;
    
    quick_sort_by_real_part (vec_cx_asso , vec_cx_asso_annex , 0 , vec_cx_asso.size () - 1);
    
    for (unsigned int i = 0 ; i < vec_cx_asso.size () ; i++) cerr << vec_cx_asso[i] << " " << vec_cx_asso_annex[i] << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }









