#ifndef SMALL_CLASSES_H
#define SMALL_CLASSES_H

class nlj_struct
{
public:
  nlj_struct ();

  nlj_struct (
	      const int n_c , 
	      const int l_c , 
	      const double j_c , 
	      const bool S_matrix_pole_c , 
	      const complex<double> &k_c , 
	      const complex<double> &w_c);

  void initialize (
		   const int n_c , 
		   const int l_c , 
		   const double j_c , 
		   const bool S_matrix_pole_c , 
		   const complex<double> &k_c , 
		   const complex<double> &w_c);
  
  void initialize (const class nlj_struct &X);

  void operator = (const class nlj_struct &X);

  int get_n () const
  {
    return n;
  }
  
  int get_l () const
  {
    return l;
  }
  
  double get_j () const
  {
    return j;
  }
  
  int get_ij () const
  {
    return ij;
  }
  
  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }
  
  complex<double> get_k () const
  {
    return k;
  }
  
  complex<double> get_w () const
  {
    return w;
  }

private:
  
  int n;
  int l;
  double j;
  int ij;
  bool S_matrix_pole;
  complex<double> k;
  complex<double> w;
};

bool operator == (const class nlj_struct &a , const class nlj_struct &b);

bool operator != (const class nlj_struct &a , const class nlj_struct &b);

bool operator > (const class nlj_struct &a , const class nlj_struct &b);

bool operator >= (const class nlj_struct &a , const class nlj_struct &b);

bool operator < (const class nlj_struct &a , const class nlj_struct &b);

bool operator <= (const class nlj_struct &a , const class nlj_struct &b);

ostream & operator << (ostream &os , const class nlj_struct &s);

istream & operator >> (istream &is , class nlj_struct &s);

double used_memory_calc (const class nlj_struct &T);







template<class C>
class lj_table
{
public:

  lj_table () {}
    
  explicit lj_table (const int lmax)
  {
    allocate (lmax);
  }

  explicit lj_table (const int lmax , const unsigned int N)
  {
    allocate (lmax , N);
  }

  explicit lj_table (const int lmax , const unsigned int N0 , const unsigned int N1)
  {
    allocate (lmax , N0 , N1);
  }

  lj_table (const class lj_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (const int lmax)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;
    
    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (dimension_lj);
  }

  void allocate (const int lmax , const unsigned int N)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (dimension_lj , N);
  }

  void allocate (const int lmax , const unsigned int N0 , const unsigned int N1)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (dimension_lj , N0 , N1);
  }

  void allocate_fill (const class lj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);
    
    table.allocate_fill (X.table);
  }
  
  void allocate_fill_object_elements (const class lj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);
    
    table.allocate_fill_object_elements (X.table);
  }

  void deallocate ()
  {
    lj_indices.deallocate ();
    
    table.deallocate ();
  }
  
  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class lj_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class lj_table<C> operator + () const 
  {
    return *this;
  }
  
  class lj_table<C> operator - () const 
  {
    class lj_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class lj_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class lj_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (lj_index);
  }

  unsigned int index_determine (const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (lj_index , i);
  }

  unsigned int index_determine (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (lj_index , i , ip);
  }

  C & operator () (const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table(lj_index);
  }

  C & operator () (const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table(lj_index , i);
  }

  C & operator () (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table(lj_index , i , ip);
  }

  int get_lmax () const
  {
    return (lj_indices.dimension (0) - 1);
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (1);
      case 1:  return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }

  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif
  
  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }
  
  template <class D>
  friend ostream & operator << (ostream &os , const class lj_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class lj_table<D> &T);

private:

  class array<unsigned short int> lj_indices;
  
  class array<C> table;
};

//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class lj_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class lj_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lj_indices) + used_memory_calc (T.table) - (sizeof (T.lj_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class lj_table<C> operator + (const class lj_table<C> &A , const class lj_table<C> &B) 
{
  class lj_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class lj_table<C> operator - (const class lj_table<C> &A , const class lj_table<C> &B) 
{
  class lj_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class lj_table<C> operator * (const class lj_table<C> &A , const C &x)
{
  class lj_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class lj_table<C> operator * (const C &x , const class lj_table<C> &A) 
{
  class lj_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class lj_table<C> operator / (const class lj_table<C> &A , const C &x) 
{
  class lj_table<C> M = A;

  M /= x;

  return M;
}




#ifdef UseMPI

template <class C>
void lj_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void lj_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process);
}

template <class C>
void lj_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void lj_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void lj_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif





template<class C>
class nlj_table
{
public:

  nlj_table () {}
    
  explicit nlj_table (
		      const int nmax ,
		      const int lmax)
  {
    allocate (nmax , lmax);
  }

  explicit nlj_table (
		      const int nmax ,
		      const int lmax ,
		      const unsigned int N)
  {
    allocate (nmax , lmax , N);
  }

  explicit nlj_table (
		      const int nmax ,
		      const int lmax ,
		      const unsigned int N0 ,
		      const unsigned int N1)
  {
    allocate (nmax , lmax , N0 , N1);
  }

  nlj_table (const class nlj_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (
		 const int nmax ,
		 const int lmax)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (nmax+1 , dimension_lj);
  }

  void allocate (
		 const int nmax ,
		 const int lmax ,
		 const unsigned int N)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (nmax+1 , dimension_lj , N);
  }

  void allocate (
		 const int nmax ,
		 const int lmax ,
		 const unsigned int N0 ,
		 const unsigned int N1)
  {
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const unsigned int j_index = (l < j) ? (0) : (1);
	  
	  lj_indices(l , j_index) = dimension_lj++;
	  
	  if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	}
  
    table.allocate (nmax+1 , dimension_lj , N0 , N1);
  }

  void allocate_fill (const class nlj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);

    table.allocate_fill (X.table);
  }


  void allocate_fill_object_elements (const class nlj_table<C> &X)
  {
    lj_indices.allocate_fill (X.lj_indices);

    table.allocate_fill_object_elements (X.table);
  }
  
  void deallocate ()
  {
    lj_indices.deallocate ();

    table.deallocate ();
  }
  
  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class nlj_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class nlj_table<C> operator + () const 
  {
    return *this;
  }
  
  class nlj_table<C> operator - () const 
  {
    class nlj_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class nlj_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class nlj_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int n , const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (n , lj_index);
  }

  unsigned int index_determine (const int n , const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (n , lj_index , i);
  }

  unsigned int index_determine (const int n , const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table.index_determine (n , lj_index , i , ip);
  }

  C & operator () (const int n , const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table(n , lj_index);
  }

  C & operator () (const int n , const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table(n , lj_index , i);
  }

  C & operator () (const int n , const int l , const double j , const unsigned int i , const unsigned int ip) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);

    return table(n , lj_index , i , ip);
  }

  int get_nmax () const
  {
    return (table.dimension (0) - 1);
  }
  
  int get_lmax () const
  {
    return (lj_indices.dimension (0) - 1);
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (2);
      case 1:  return table.dimension (3);
      default: return 0;
      }

    return NADA;
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }
  
  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }
  
#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif


  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class nlj_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class nlj_table<D> &T);
  
private:

  class array<unsigned short int> lj_indices;
  
  class array<C> table;
};


//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class nlj_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class nlj_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lj_indices) + used_memory_calc (T.table) - (sizeof (T.lj_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class nlj_table<C> operator + (const class nlj_table<C> &A , const class nlj_table<C> &B) 
{
  class nlj_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class nlj_table<C> operator - (const class nlj_table<C> &A , const class nlj_table<C> &B) 
{
  class nlj_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class nlj_table<C> operator * (const class nlj_table<C> &A , const C &x)
{
  class nlj_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class nlj_table<C> operator * (const C &x , const class nlj_table<C> &A) 
{
  class nlj_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class nlj_table<C> operator / (const class nlj_table<C> &A , const C &x) 
{
  class nlj_table<C> M = A;

  M /= x;

  return M;
}




#ifdef UseMPI

template <class C>
void nlj_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void nlj_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process);
}

template <class C>
void nlj_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void nlj_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif















template<class C>
class ljm_table
{
public:

  ljm_table () {}
  
  explicit ljm_table (const int lmax , const double m_max)
  {
    allocate (lmax , m_max);
  }

  explicit ljm_table (const int lmax , const double m_max , const unsigned int N)
  {
    allocate (lmax , m_max , N);
  }

  explicit ljm_table (const int lmax , const double m_max , const unsigned int N0 , const unsigned int N1)
  {
    allocate (lmax , m_max , N0 , N1);
  }

  ljm_table (const class ljm_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (const int lmax , const double m_max)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);
    
    ljm_indices.allocate (lmax+1 , 2 , m_max_plus_half);
    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const double m_max_j = ::min (m_max , j);

	  for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
	    {
	      const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
	      
	      ljm_indices(l , j_index , m_index) = dimension_ljm++;
	      
	      if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	    }
	}

    table.allocate (dimension_ljm);
  }

  void allocate (const int lmax , const double m_max , const unsigned int N)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);
    
    ljm_indices.allocate (lmax+1 , 2 , m_max_plus_half); 
    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const double m_max_j = ::min (m_max , j);

	  for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
	    {
	      const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
	      
	      ljm_indices(l , j_index , m_index) = dimension_ljm++;
	      
	      if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	    }
	}

    table.allocate (dimension_ljm , N);
  }

  void allocate (const int lmax , const double m_max , const unsigned int N0 , const unsigned int N1)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);
    
    ljm_indices.allocate (lmax+1 , 2 , m_max_plus_half); 
    ljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	{
	  const double m_max_j = ::min (m_max , j);

	  for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
	    {
	      const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
	      
	      ljm_indices(l , j_index , m_index) = dimension_ljm++;
	      
	      if (dimension_ljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	    }
	}

    table.allocate (dimension_ljm , N0 , N1);
  }

  void allocate_fill (const class ljm_table<C> &X)
  {
    ljm_indices.allocate_fill (X.ljm_indices);

    table.allocate_fill (X.table);
  }

  void allocate_fill_object_elements (const class ljm_table<C> &X)
  {
    ljm_indices.allocate_fill (X.ljm_indices);

    table.allocate_fill_object_elements (X.table);
  }
  
  void deallocate ()
  {
    ljm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class ljm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class ljm_table<C> operator + () const
  {
    return *this;
  }

  class ljm_table<C> operator - () const
  {
    class ljm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class ljm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class ljm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j , const double m) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table.index_determine (ljm_index);
  }

  unsigned int index_determine (const int l , const double j , const double m , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table.index_determine (ljm_index , i);
  } 

  unsigned int index_determine (const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table.index_determine (ljm_index , i , ip);
  }

  C & operator () (const int l , const double j , const double m) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table(ljm_index);
  }

  C & operator () (const int l , const double j , const double m , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table(ljm_index , i);
  } 

  C & operator () (const int l , const double j , const double m , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljm_index = ljm_indices(l , j_index , m_index);

    return table(ljm_index , i , ip);
  }
   
  int get_lmax () const
  {
    return (ljm_indices.dimension (0) - 1);
  }
  
  double get_m_max () const
  {
    return (ljm_indices.dimension (2) - 0.5);
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (1);
      case 1:  return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }

  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }

  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }
  
  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif


  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class ljm_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class ljm_table<D> &T);
  
private:
  
  class array<unsigned short int> ljm_indices;
  
  class array<C> table;
};

//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class ljm_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class ljm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.ljm_indices) + used_memory_calc (T.table) - (sizeof (T.ljm_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class ljm_table<C> operator + (const class ljm_table<C> &A , const class ljm_table<C> &B) 
{
  class ljm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class ljm_table<C> operator - (const class ljm_table<C> &A , const class ljm_table<C> &B) 
{
  class ljm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class ljm_table<C> operator * (const class ljm_table<C> &A , const C &x)
{
  class ljm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class ljm_table<C> operator * (const C &x , const class ljm_table<C> &A) 
{
  class ljm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class ljm_table<C> operator / (const class ljm_table<C> &A , const C &x) 
{
  class ljm_table<C> M = A;

  M /= x;

  return M;
}




#ifdef UseMPI

template <class C>
void ljm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void ljm_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void ljm_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif












template<class C>
class ljljm_table
{
public:

  ljljm_table () {}
  
  explicit ljljm_table (const int lmax , const double m_max)
  {
    allocate (lmax , m_max);
  }

  explicit ljljm_table (const int lmax , const double m_max , const unsigned int N)
  {
    allocate (lmax , m_max , N);
  }

  explicit ljljm_table (const int lmax , const double m_max , const unsigned int N0 , const unsigned int N1)
  {
    allocate (lmax , m_max , N0 , N1);
  }

  ljljm_table (const class ljljm_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (const int lmax , const double m_max)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);

    ljljm_indices.allocate (lmax+1 , 2 , lmax+1 , 2 , m_max_plus_half);
    ljljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  if ((l + lp)%2 == 0)
	    {
	      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
		for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
		  {
		    const double m_max_j = ::min (m_max , ::min (j , jp));

		    for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
		      {
			const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
			ljljm_indices(l , j_index , lp , jp_index , m_index) = ljljm_indices(lp , jp_index , l , j_index , m_index) = dimension_ljljm++;
			if (dimension_ljljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
		      }
		  }
	    }
	}
    
    table.allocate (dimension_ljljm);
  }


  void allocate (const int lmax , const double m_max , const unsigned int N)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);

    ljljm_indices.allocate (lmax+1 , 2 , lmax+1 , 2 , m_max_plus_half); 
    ljljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  if ((l + lp)%2 == 0)
	    {
	      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
		for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
		  {
		    const double m_max_j = ::min (m_max , ::min (j , jp));

		    for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
		      {
			const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
			ljljm_indices(l , j_index , lp , jp_index , m_index) = ljljm_indices(lp , jp_index , l , j_index , m_index) = dimension_ljljm++;
			if (dimension_ljljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
		      }
		  }
	    }
	}

    table.allocate (dimension_ljljm , N);
  }

  void allocate (const int lmax , const double m_max , const unsigned int N0 , const unsigned int N1)
  {
    const int m_max_plus_half = make_int (m_max + 0.5);

    ljljm_indices.allocate (lmax+1 , 2 , lmax+1 , 2 , m_max_plus_half); 
    ljljm_indices = OUT_OF_RANGE;

    unsigned short int dimension_ljljm = 0;

    for (int l = 0 ; l <= lmax ; l++)
      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  if ((l + lp)%2 == 0)
	    {
	      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
		for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
		  {
		    const double m_max_j = ::min (m_max , ::min (j , jp));

		    for (double m = 0.5 ; rint (m - m_max_j) <= 0.0 ; m++)
		      {
			const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
		    
			ljljm_indices(l , j_index , lp , jp_index , m_index) = ljljm_indices(lp , jp_index , l , j_index , m_index) = dimension_ljljm++;
		    
			if (dimension_ljljm == OUT_OF_RANGE) error_message_print_abort ("Table too large");
		      }
		  }
	    }
	}

    table.allocate (dimension_ljljm , N0 , N1);
  }

  void allocate_fill (const class ljljm_table<C> &X)
  {
    ljljm_indices.allocate_fill (X.ljljm_indices);

    table.allocate_fill (X.table);
  }
  
  void allocate_fill_object_elements (const class ljljm_table<C> &X)
  {
    ljljm_indices.allocate_fill (X.ljljm_indices);

    table.allocate_fill_object_elements (X.table);
  }
  
  void deallocate ()
  {
    ljljm_indices.deallocate ();

    table.deallocate ();
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class ljljm_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class ljljm_table<C> operator + () const
  {
    return *this;
  }
  
  class ljljm_table<C> operator - () const
  {
    class ljljm_table<C> M = *this;

    M.table = -M.table;

    return M;
  }

  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class ljljm_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class ljljm_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j , const int lp , const double jp , const double m) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table.index_determine (ljljm_index);
  }

  unsigned int index_determine (const int l , const double j , const int lp , const double jp , const double m , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table.index_determine (ljljm_index , i);
  } 

  unsigned int index_determine (
				const int l , const double j , 
				const int lp , const double jp , 
				const double m , 
				const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table.index_determine (ljljm_index , i , ip);
  }

  C & operator () (const int l , const double j , const int lp , const double jp , const double m) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table(ljljm_index);
  }

  C & operator () (const int l , const double j , const int lp , const double jp , const double m , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table(ljljm_index , i);
  } 

  C & operator () (
		   const int l , const double j , 
		   const int lp , const double jp , 
		   const double m , 
		   const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1) , jp_index = (lp < jp) ? (0) : (1) , m_index = make_uns_int (m - 0.5);
    const unsigned int ljljm_index = ljljm_indices(l , j_index , lp , jp_index , m_index);

    return table(ljljm_index , i , ip);
  }

  int get_lmax () const
  {
    return (ljljm_indices.dimension (0) - 1);
  }
  
  double get_m_max () const
  {
    return (ljljm_indices.dimension (4) - 0.5);
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (1);
      case 1:  return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }
    
  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }
  
  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }
  
  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif


  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  
  template <class D>
  friend ostream & operator << (ostream &os , const class ljljm_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class ljljm_table<D> &T);
  
private:
    
  class array<unsigned short int> ljljm_indices;
  
  class array<C> table;
};

//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class ljljm_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class ljljm_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.ljljm_indices) + used_memory_calc (T.table) - (sizeof (T.ljljm_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class ljljm_table<C> operator + (const class ljljm_table<C> &A , const class ljljm_table<C> &B) 
{
  class ljljm_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class ljljm_table<C> operator - (const class ljljm_table<C> &A , const class ljljm_table<C> &B) 
{
  class ljljm_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class ljljm_table<C> operator * (const class ljljm_table<C> &A , const C &x)
{
  class ljljm_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class ljljm_table<C> operator * (const C &x , const class ljljm_table<C> &A) 
{
  class ljljm_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class ljljm_table<C> operator / (const class ljljm_table<C> &A , const C &x) 
{
  class ljljm_table<C> M = A;

  M /= x;

  return M;
}





#ifdef UseMPI

template <class C>
void ljljm_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void ljljm_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void ljljm_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process , MPI_C);
}

template <class C>
void ljljm_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void ljljm_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void ljljm_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void ljljm_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif











template<class C>
class parity_lj_table
{
public:

  parity_lj_table () : lmin (0) , lmax (0) {}
  
  explicit parity_lj_table (const int lmin_c , const int lmax_c)
  {
    allocate (lmin_c , lmax_c);
  }

  explicit  parity_lj_table (const int lmin_c , const int lmax_c , const unsigned int N)
  {
    allocate (lmin_c , lmax_c , N);
  }

  explicit parity_lj_table (const int lmin_c , const int lmax_c , const unsigned int N0 , const unsigned int N1)
  {
    allocate (lmin_c , lmax_c , N0 , N1);
  }

  parity_lj_table (const class parity_lj_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (const int lmin_c , const int lmax_c)
  {
    lmin = lmin_c;
    lmax = lmax_c;
    
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		const unsigned int j_index = (l < j) ? (0) : (1);
		
		lj_indices(l , j_index) = dimension_lj++;
		
		if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_lj);
  }

  void allocate (const int lmin_c , const int lmax_c , const unsigned int N)
  {
    lmin = lmin_c;
    lmax = lmax_c;
    
    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		const unsigned int j_index = (l < j) ? (0) : (1);
		
		lj_indices(l , j_index) = dimension_lj++;
		
		if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_lj , N);
  }

  void allocate (const int lmin_c , const int lmax_c , const unsigned int N0 , const unsigned int N1)
  {
    lmin = lmin_c;
    lmax = lmax_c;

    lj_indices.allocate (lmax+1 , 2);
    lj_indices = OUT_OF_RANGE;

    unsigned short int dimension_lj = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      {
		const unsigned int j_index = (l < j) ? (0) : (1);
		
		lj_indices(l , j_index) = dimension_lj++;
		
		if (dimension_lj == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_lj , N0 , N1);
  }

  void allocate_fill (const class parity_lj_table<C> &X)
  {
    lmin = X.lmin;
    lmax = X.lmax;

    lj_indices.allocate_fill (X.lj_indices);
    
    table.allocate_fill (X.table);
  }
  
  void allocate_fill_object_elements (const class parity_lj_table<C> &X)
  {
    lmin = X.lmin;
    lmax = X.lmax;

    lj_indices.allocate_fill (X.lj_indices);

    table.allocate_fill_object_elements (X.table);
  }
  
  void deallocate ()
  {
    lj_indices.deallocate ();
    
    table.deallocate ();

    lmin = lmax = 0;
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class parity_lj_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class parity_lj_table<C> operator + () const
  {
    return *this;
  }
  
  class parity_lj_table<C> operator - () const
  {
    class parity_lj_table<C> M = *this;

    M.table = -M.table;

    return M;
  }
  
  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class parity_lj_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class parity_lj_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table.index_determine (lj_index);
  }

  unsigned int index_determine (const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table.index_determine (lj_index , i);
  } 

  unsigned int index_determine (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table.index_determine (lj_index , i , ip);
  }

  C & operator () (const int l , const double j) const
  {
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table(lj_index);
  }

  C & operator () (const int l , const double j , const unsigned int i) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table(lj_index , i);
  } 

  C & operator () (const int l , const double j , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int j_index = (l < j) ? (0) : (1);
    const unsigned int lj_index = lj_indices(l , j_index);
    
    return table(lj_index , i , ip);
  }

  int get_lmin () const
  {
    return lmin;
  }
  
  int get_lmax () const
  {
    return lmax;
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (1);
      case 1:  return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }
      
  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }
  
  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }
  
  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif


  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }

  template <class D>
  friend ostream & operator << (ostream &os , const class parity_lj_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class parity_lj_table<D> &T);
  
private:

  int lmin , lmax;
  
  class array<unsigned short int> lj_indices;
  
  class array<C> table;
};



//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class parity_lj_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class parity_lj_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lmin) + used_memory_calc (T.lmax) + used_memory_calc (T.lj_indices) + used_memory_calc (T.table) - (sizeof (T.lmin) + sizeof (T.lmax) + sizeof (T.lj_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class parity_lj_table<C> operator + (const class parity_lj_table<C> &A , const class parity_lj_table<C> &B) 
{
  class parity_lj_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class parity_lj_table<C> operator - (const class parity_lj_table<C> &A , const class parity_lj_table<C> &B) 
{
  class parity_lj_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class parity_lj_table<C> operator * (const class parity_lj_table<C> &A , const C &x)
{
  class parity_lj_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class parity_lj_table<C> operator * (const C &x , const class parity_lj_table<C> &A) 
{
  class parity_lj_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class parity_lj_table<C> operator / (const class parity_lj_table<C> &A , const C &x) 
{
  class parity_lj_table<C> M = A;

  M /= x;

  return M;
}




#ifdef UseMPI

template <class C>
void parity_lj_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void parity_lj_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void parity_lj_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process , MPI_C);
}

template <class C>
void parity_lj_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void parity_lj_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void parity_lj_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void parity_lj_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif










template<class C>
class parity_ls_table
{
public:

  parity_ls_table () : lmin (0) , lmax (0) {}
  
  explicit parity_ls_table (const int lmin_c , const int lmax_c)
  {
    allocate (lmin_c , lmax_c);
  }

  explicit  parity_ls_table (const int lmin_c , const int lmax_c , const unsigned int N)
  {
    allocate (lmin_c , lmax_c , N);
  }

  explicit parity_ls_table (const int lmin_c , const int lmax_c , const unsigned int N0 , const unsigned int N1)
  {
    allocate (lmin_c , lmax_c , N0 , N1);
  }

  parity_ls_table (const class parity_ls_table<C> &X)
  {
    allocate_fill (X);
  }
  
  void allocate (const int lmin_c , const int lmax_c)
  {
    lmin = lmin_c;
    lmax = lmax_c;
    
    ls_indices.allocate (lmax+1 , 2);
    ls_indices = OUT_OF_RANGE;

    unsigned short int dimension_ls = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (unsigned int s_index = 0 ; s_index <= 1 ; s_index++)
	      {
		ls_indices(l , s_index) = dimension_ls++;
		
		if (dimension_ls == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_ls);
  }

  void allocate (const int lmin_c , const int lmax_c , const unsigned int N)
  {
    lmin = lmin_c;
    lmax = lmax_c;
    
    ls_indices.allocate (lmax+1 , 2);

    unsigned short int dimension_ls = 0;
    ls_indices = OUT_OF_RANGE;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (unsigned int s_index = 0 ; s_index <= 1 ; s_index++)
	      {
		ls_indices(l , s_index) = dimension_ls++;
		
		if (dimension_ls == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_ls , N);
  }

  void allocate (const int lmin_c , const int lmax_c , const unsigned int N0 , const unsigned int N1)
  {
    lmin = lmin_c;
    lmax = lmax_c;

    ls_indices.allocate (lmax+1 , 2);
    ls_indices = OUT_OF_RANGE;

    unsigned short int dimension_ls = 0;

    for (int l = 0 ; l <= lmax ; l++)
      {
	if ((l + lmin)%2 == 0)
	  {
	    for (unsigned int s_index = 0 ; s_index <= 1 ; s_index++)
	      {
		ls_indices(l , s_index) = dimension_ls++;
		
		if (dimension_ls == OUT_OF_RANGE) error_message_print_abort ("Table too large");
	      }
	  }
      }
  
    table.allocate (dimension_ls , N0 , N1);
  }

  void allocate_fill (const class parity_ls_table<C> &X)
  {
    lmin = X.lmin;
    lmax = X.lmax;

    ls_indices.allocate_fill (X.ls_indices);
    
    table.allocate_fill (X.table);
  }
  
  void allocate_fill_object_elements (const class parity_ls_table<C> &X)
  {
    lmin = X.lmin;
    lmax = X.lmax;

    ls_indices.allocate_fill (X.ls_indices);

    table.allocate_fill_object_elements (X.table);
  }
  
  void deallocate ()
  {
    ls_indices.deallocate ();
    
    table.deallocate ();

    lmin = lmax = 0;
  }

  void deallocate_object_elements ()
  {
    table.deallocate_object_elements ();
  }
  
  void operator = (const class parity_ls_table<C> &X)
  {
    table = X.table;
  }

  void operator = (const C &x)
  {
    table = x;
  }

  class parity_ls_table<C> operator + () const
  {
    return *this;
  }
  
  class parity_ls_table<C> operator - () const
  {
    class parity_ls_table<C> M = *this;

    M.table = -M.table;

    return M;
  }
  
  void operator += (const C &x)
  {
    table += x;
  }

  void operator -= (const C &x)
  {
    table -= x;
  }

  void operator *= (const C &x)
  {
    table *= x;
  }

  void operator /= (const C &x)
  {
    table /= x;
  }

  void operator += (const class parity_ls_table<C> &A)
  {
    table += A.table;
  }

  void operator -= (const class parity_ls_table<C> &A)
  {
    table -= A.table;
  }

  C & operator [] (const unsigned int i) const
  {
    return table[i];
  }

  unsigned int index_determine (const int l , const double s) const
  {
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table.index_determine (ls_index);
  }

  unsigned int index_determine (const int l , const double s , const unsigned int i) const
  {    
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table.index_determine (ls_index , i);
  } 

  unsigned int index_determine (const int l , const double s , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table.index_determine (ls_index , i , ip);
  }

  C & operator () (const int l , const double s) const
  {
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table(ls_index);
  }

  C & operator () (const int l , const double s , const unsigned int i) const
  {    
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table(ls_index , i);
  } 

  C & operator () (const int l , const double s , const unsigned int i , const unsigned int ip) const
  {    
    const unsigned int s_index = (s > 0) ? (0) : (1);
    const unsigned int ls_index = ls_indices(l , s_index);
    
    return table(ls_index , i , ip);
  }

  int get_lmin () const
  {
    return lmin;
  }
  
  int get_lmax () const
  {
    return lmax;
  }
  
  unsigned int dimension (const unsigned int index) const
  {
    switch (index)
      {
      case 0:  return table.dimension (1);
      case 1:  return table.dimension (2);
      default: return 0;
      }

    return NADA;
  }
      
  void read_disk (const string &file_name)
  {
    table.read_disk (file_name);
  }

  void copy_disk (const string &file_name) const
  {
    table.copy_disk (file_name);
  }
  
  C sum () const
  {
    return table.sum ();
  }

  C product () const
  {
    return table.product ();
  }
  
  C max () const
  {
    return table.max ();
  }

  C min () const
  {
    return table.min ();
  }

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.first_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
  {
    return table.last_index_determine_for_MPI (group_processes_number , process);
  }

  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
  {
    return table.active_process_determine_for_MPI (group_processes_number , index);
  }

#ifdef UseMPI
  void MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allgatherv (const MPI_Comm MPI_C);
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
  void MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C);
  void MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C);
#endif


  bool is_it_filled () const
  {
    return table.is_it_filled ();
  }


  template <class D>
  friend ostream & operator << (ostream &os , const class parity_ls_table<D> &T);
  
  template <class D>
  friend double used_memory_calc (const class parity_ls_table<D> &T);
  
private:

  int lmin , lmax;
  
  class array<unsigned short int> ls_indices;
  
  class array<C> table;
};


//  print overload.
// ----------------
template <class C>
ostream & operator << (ostream &os , const class parity_ls_table<C> &T)
{
  return os << T.table;
}

// Memory used by the class
// ------------------------
template <class C>
double used_memory_calc (const class parity_ls_table<C> &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.lmin) + used_memory_calc (T.lmax) + used_memory_calc (T.ls_indices) + used_memory_calc (T.table) - (sizeof (T.lmin) + sizeof (T.lmax) + sizeof (T.ls_indices) + sizeof (T.table))/1000000.0);
}

// "+" overloading.
// ----------------
template <typename C>  
class parity_ls_table<C> operator + (const class parity_ls_table<C> &A , const class parity_ls_table<C> &B) 
{
  class parity_ls_table<C> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename C>
class parity_ls_table<C> operator - (const class parity_ls_table<C> &A , const class parity_ls_table<C> &B) 
{
  class parity_ls_table<C> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times x
//----------------------------
template <typename C>  
class parity_ls_table<C> operator * (const class parity_ls_table<C> &A , const C &x)
{
  class parity_ls_table<C> M = A;

  M *= x;

  return M;
}



// "*" overloading : x times A
// ---------------------------
template <typename C>
class parity_ls_table<C> operator * (const C &x , const class parity_ls_table<C> &A) 
{
  class parity_ls_table<C> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over x
// --------------------------
template <typename C>  
class parity_ls_table<C> operator / (const class parity_ls_table<C> &A , const C &x) 
{
  class parity_ls_table<C> M = A;

  M /= x;

  return M;
}



#ifdef UseMPI

template <class C>
void parity_ls_table<C>::MPI_Send (const unsigned int receiving_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Send (receiving_process , tag , MPI_C);
}

template <class C>
void parity_ls_table<C>::MPI_Recv (const unsigned int sending_process , const int tag , const MPI_Comm MPI_C)
{
  table.MPI_Recv (sending_process , tag , MPI_C);
}
template <class C>
void parity_ls_table<C>::MPI_Gatherv (const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Gatherv (receiving_process , MPI_C);
}

template <class C>
void parity_ls_table<C>::MPI_Allgatherv (const MPI_Comm MPI_C)
{
  table.MPI_Allgatherv (MPI_C);
}

template <class C>
void parity_ls_table<C>::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  table.MPI_Bcast (sending_process , MPI_C);
}

template <class C>
void parity_ls_table<C>::MPI_Reduce (const MPI_Op op , const unsigned int receiving_process , const MPI_Comm MPI_C)
{
  table.MPI_Reduce (op , receiving_process , MPI_C);
}

template <class C>
void parity_ls_table<C>::MPI_Allreduce (const MPI_Op op , const MPI_Comm MPI_C)
{
  table.MPI_Allreduce (op , MPI_C);
}

#endif


bool same_lj (const class nlj_struct &s1 , const class nlj_struct &s2);


bool same_nlj (const class nlj_struct &s1 , const class nlj_struct &s2);


#endif
