#include "../numlib_def/numlib_def.h"
#include "nljm_indices_tables.hpp"

using namespace string_routines;

nlj_struct::nlj_struct () {}

nlj_struct::nlj_struct (
			const int n_c , 
			const int l_c , 
			const double j_c , 
			const bool S_matrix_pole_c , 
			const complex<double> &k_c , 
			const complex<double> &w_c)
{
  initialize (n_c , l_c , j_c , S_matrix_pole_c , k_c , w_c);
}

void nlj_struct::initialize (
			     const int n_c , 
			     const int l_c , 
			     const double j_c , 
			     const bool S_matrix_pole_c , 
			     const complex<double> &k_c , 
			     const complex<double> &w_c)
{
  n = n_c;
  l = l_c;
  j = j_c;
  ij = make_int (j - 0.5);
  S_matrix_pole = S_matrix_pole_c;
  k = k_c;
  w = w_c;
}
 
void nlj_struct::initialize (const class nlj_struct &X)
{
  n = X.n;
  l = X.l;
  j = X.j;
  ij = X.ij;
  S_matrix_pole = X.S_matrix_pole;
  k = X.k;
  w = X.w;
}

void nlj_struct::operator = (const class nlj_struct &X)
{
  initialize (X);
}





bool operator == (const class nlj_struct &a , const class nlj_struct &b)
{
  if (a.get_S_matrix_pole () != b.get_S_matrix_pole ()) return false;
  
  if ((a.get_n () != b.get_n ()) || (a.get_l () != b.get_l ()) || (a.get_ij () != b.get_ij ())) return false;

  if (inf_norm (a.get_k () - b.get_k ()) > precision) return false;
  if (inf_norm (a.get_w () - b.get_w ()) > precision) return false;

  return true;
}



bool operator != (const class nlj_struct &a , const class nlj_struct &b)
{
  return !(a == b);
}



bool operator > (const class nlj_struct &a , const class nlj_struct &b)
{
  if (!a.get_S_matrix_pole () && b.get_S_matrix_pole ()) return true; 
  if ((a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_l () > b.get_l ())) return true; 
  if ((a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_l () == b.get_l ()) && (a.get_ij () > b.get_ij ())) return true;
  if ((a.get_S_matrix_pole () == b.get_S_matrix_pole ()) && (a.get_l () == b.get_l ()) && (a.get_ij () == b.get_ij ()) && (real (a.get_k ()) > real (b.get_k ()))) return true;

  return false;
}



bool operator >= (const class nlj_struct &a , const class nlj_struct &b)
{
  return ((a > b) || (a == b));
}



bool operator < (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b > a);
}

bool operator <= (const class nlj_struct &a , const class nlj_struct &b)
{
  return (b >= a);
}




ostream & operator << (ostream &os , const class nlj_struct &s)
{
  return os << s.get_n () << angular_state (s.get_l () , s.get_j ());
}






istream & operator >> (istream &is , class nlj_struct &s)
{
  string nlj_string;

  is >> nlj_string;

  const int n = determine_n (nlj_string);
  const int l = determine_l (nlj_string);
  const double j = determine_j (nlj_string);

  string A;

  is >> A;

  bool S_matrix_pole = false;
	
  if (A == "S.matrix.pole(yes)") 
    S_matrix_pole = true;
  else if (A == "S.matrix.pole(no)") 
    S_matrix_pole = false;
  else
    error_message_print_abort ("Error with " + nlj_string + " in string " + A);

  s.initialize (n , l , j , S_matrix_pole , NADA , NADA);
 
  return is;
}

bool same_lj (const class nlj_struct &s1 , const class nlj_struct &s2)
{
  return ((s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0));
}

bool same_nlj (const class nlj_struct &s1 , const class nlj_struct &s2)
{
  return ((s1.get_n () == s2.get_n ()) && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0));
}

double used_memory_calc (const class nlj_struct &T)
{
  return sizeof (T)/1000000.0;
}


