#include "../numlib_def/numlib_def.h"




//--// rescale the real and imaginary part of each elements of a vector<cx> to given values
void rescaling_real_and_imag (vector<complex<double> > &vec_ , const double re_norm_ , const double im_norm_)
{
  const unsigned int vec_size = vec_.size ();

  if (vec_size != 0)
    {
      for (unsigned int i = 0 ; i < vec_size ; i++)
	{
	  const complex<double> cx = vec_[i];
	  const complex<double> new_cx (real (cx) / re_norm_ , imag (cx) / im_norm_);

	  vec_[i] = new_cx;
	}
    }
  else
    {
      cerr << "------ rescaling_real_and_imag: the vector size is equal to zero ------" << endl;

      exit (1);
    }
}


