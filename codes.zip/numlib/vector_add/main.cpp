#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
    
    vector<complex<double> > vec (10);

    for (unsigned int i = 0 ; i < vec.size () ; i++)
      {
	const complex<double> cx (i , -1.0*i);

	vec[i] = cx;

	clog << cx << endl;
      }

    const double re_norm = real (vec[vec.size () - 1]);
    const double im_norm = imag (vec[vec.size () - 1]);

    rescaling_real_and_imag (vec , re_norm , im_norm);

    clog << "---------------------------------------" << endl;

    for (unsigned int i = 0 ; i < vec.size () ; i++)
      {
	clog << vec[i] << endl;
      }

    const complex<double> cx_shift (0.5 , -0.5);

    add_shift_vec<complex<double> > (vec , cx_shift);

    clog << "---------------------------------------" << endl;

    for (unsigned int i = 0 ; i < vec.size () ; i++)
      {
	clog << vec[i] << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


