#ifndef VECTOR_ADD_HPP
#define VECTOR_ADD_HPP



//--// rescale the real and imaginary part of each elements of a vector<cx> to given values
void rescaling_real_and_imag (vector<complex<double> > &vec_ , const double re_norm_ , const double im_norm_);




//--// add a shift to all values of a given vector
template<typename type>
void add_shift_vec (vector<type> &vec_ , type shift_)
{
  const unsigned int vec_size = vec_.size ();

  if (vec_size != 0)
    {
      for (unsigned int i = 0 ; i < vec_size ; i++)
	{
	  vec_[i] = vec_[i] + shift_;
	}
    }
  else
    {
      cerr << "------ add_shift_vec: the vector size is equal to zero ------" << endl;

      exit (1);
    }
}



#endif


