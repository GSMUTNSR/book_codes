#ifndef MPI2DPARTITIONING_H
#define MPI2DPARTITIONING_H

// There are no column routines for the non-symmetric case as there are MPI column transfers only for the symmetric case.
// Routines uses the symmetric case by default if the result for symmetric and non-symmetric cases are the same.

namespace MPI_2D_partitioning
{
  // Determination of the number of squares on a row or column in the 2D partitioning scheme. They can be occupied or not.
  // ---------------------------------------------------------------------------------------------------------------------
  unsigned int squares_number_per_row_column_calculate (const unsigned int processes_number);

  // Determination of the total number of active squares in the 2D partitioning scheme. The diagonal is always active even if squares are not occupied so that it is N(N+1)/2 in all cases
  // -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  unsigned int active_squares_number_calculate (const unsigned int processes_number);

  // Determination of the active character of a process in the 2D partitioning scheme
  // --------------------------------------------------------------------------------
  bool is_process_active_determine_2D (
				       const unsigned int process ,
				       const unsigned int processes_number);
  
  // Determination of the 2D partitioning number of squares of the first half columns (even case), number of squares of a column (odd case)
  // --------------------------------------------------------------------------------------------------------------------------------------
  unsigned int get_N_column_first_half (const unsigned int N);

  // Determination of the 2D partitioning number of squares of the last half columns (even case), number of squares of a column (odd case)
  // -------------------------------------------------------------------------------------------------------------------------------------
  unsigned int get_N_column_last_half (const unsigned int N);

  // Determination of the 2D partitioning number of squares of the j column
  // ----------------------------------------------------------------------
  unsigned int get_N_column (
			     const unsigned int N ,
			     const unsigned int j);
  
  // Determination of the 2D partitioning number of squares of the first half rows (even case), number of squares of a row (odd case)
  // --------------------------------------------------------------------------------------------------------------------------------
  unsigned int get_N_row_first_half (const unsigned int N);

  // Determination of the 2D partitioning number of squares of the last half rows (even case), number of squares of a row (odd case)
  // -------------------------------------------------------------------------------------------------------------------------------
  unsigned int get_N_row_last_half (const unsigned int N);

  // Determination of the 2D partitioning number of squares of the i row
  // -------------------------------------------------------------------
  unsigned int get_N_row (
			  const unsigned int N ,
			  const unsigned int i);

  // Determination of the index of the 2D partitioning diagonal square of the k row or column. One uses a formula valid for the column k, and one uses the fact that the result is the same for the row k.
  // ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  unsigned int get_diagonal_square_index (
					  const unsigned int N ,
					  const unsigned int k);
  
  // Calculation of the indices of the symmetric 2D partitioning for a fixed row
  // ---------------------------------------------------------------------------
  void fixed_row_square_indices_calc_fill_symmetric_case (
							  const unsigned int i ,
							  class array<bool> &fixed_row_are_squares_occupied ,
							  class array<unsigned int> &fixed_row_square_indices);
  
  // Calculation of the indices of the symmetric 2D partitioning for a fixed column
  // ------------------------------------------------------------------------------
  void fixed_column_square_indices_calc_fill_symmetric_case (
							     const unsigned int j ,
							     class array<bool> &fixed_column_are_squares_occupied ,
							     class array<unsigned int> &fixed_column_square_indices);
  
  // Calculation of the indices of the non-symmetric 2D partitioning for a fixed row
  // -------------------------------------------------------------------------------
  void fixed_row_square_indices_calc_fill_non_symmetric_case (
							      const unsigned int i ,
							      class array<bool> &fixed_row_are_squares_occupied ,
							      class array<unsigned int> &fixed_row_square_indices);
  
  // Calculation of the indices of the non-symmetric 2D partitioning for a fixed column
  // -------------------------------------------------------------------------------
  void fixed_column_square_indices_calc_fill_non_symmetric_case (
								 const unsigned int j ,
								 class array<bool> &fixed_column_are_squares_occupied ,
								 class array<unsigned int> &fixed_column_square_indices);

  // Determine the row on which a process is found for the symmetric case
  // --------------------------------------------------------------------
  unsigned int row_index_determine_symmetric_case (
						   const unsigned int process ,
						   const unsigned int processes_number);
  
  // Determine the column on which a process is found for the symmetric case
  // -----------------------------------------------------------------------
  unsigned int column_index_determine_symmetric_case (
						      const unsigned int process ,
						      const unsigned int processes_number);
 
  // Determine the row on which a process is found
  // ---------------------------------------------
  unsigned int row_index_determine (
				    const bool are_occupied_squares_considered ,
				    const unsigned int process ,
				    const unsigned int processes_number);

  // Determine the column on which a process is found
  // ------------------------------------------------
  unsigned int column_index_determine (
				       const bool are_occupied_squares_considered ,
				       const unsigned int process ,
				       const unsigned int processes_number);
 
  // Checks if one is in a diagonal square in 2D
  // -------------------------------------------
  bool is_it_diagonal_square_determine_2D (
					   const unsigned int process , 
					   const unsigned int processes_number);
 
  // Returns the square row index in which a vector index is if it is occupied in a process in hybrid 1D/2D
  // ------------------------------------------------------------------------------------------------------
  unsigned int square_row_index_determine_hybrid_1D_2D (
							const unsigned long int total_vector_index ,
							const class array<unsigned long int> &first_total_vector_indices ,
							const class array<unsigned long int> &last_total_vector_indices);
  
  // Checks if one is in a diagonal square in hybrid 1D/2D
  // -----------------------------------------------------
  bool is_it_diagonal_square_determine_hybrid_1D_2D (
						     const bool is_it_MPI_parallelized_local ,
						     const unsigned int square_row_index);
  
  // Prints the numbers of nodes close to that used which are all active with 2D partitioning
  // ----------------------------------------------------------------------------------------
  void print_active_processes_numbers ();
}
#endif
