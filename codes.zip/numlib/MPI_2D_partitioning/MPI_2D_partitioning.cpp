#include "../numlib_def/numlib_def.h"



// Calculation of row and column indices in the 2D partitioning method
// -------------------------------------------------------------------
//
// Symmetric case
// ------------------
// One considers a matrix which is divided in N^2 squares. N is the considered number of nodes in the MPI calculation. OpenMP is not considered here.
// A square is denoted as (i,j), with i the row index and j the column index.
//
// N odd: Each j column has (N+1)/2 indices, which starts from the diagonal with j.(N+1)/2 .
//        If one has not filled (N+1)/2 indices reaching the bottom of the matrix, one continues from the (0,j) square until all (N+1)/2 indices are filled (see below).
// 
// N even: If j <= N/2, each j column has N/2 indices, which start from the diagonal with j.N/2 .
//         If one has not filled N/2 indices reaching the bottom of the matrix, one continues from the (0,j) square until all N/2 indices are filled.
//         If j >= N/2 + 1, each column has N/2 + 1 indices, which start from the diagonal with j.(N/2 + 1) - N/2 .
//         If one has not filled N/2 + 1 indices reaching the bottom of the matrix, one continues from the (0,j) square until all N/2 + 1 indices are filled (see below).
//
// One can check that N(N+1)/2 squares are filled with this scheme, that all diagonal squares are present, and that only one (i,j) or (j,i) square is filled for fixed i and j, i different from j.
// As each column takes care of N/2, (N+1)/2 or N/2 + 1 squares, this scheme is well-balanced for N odd ((N+1)/2 squares per column) and quasi well-balanced for N even (N/2 or N/2 + 1 squares per column),
// assuming that each square possesses the same number of matrix elements. The load unbalance for N even clearly disappears for large N.
//
// For a fixed column, the counting procedure described above is used.
// For a fixed row, as the row index formula is more complicated than that of the column index formula, one considers the previous procedure for all columns and select indices from the fixed row.
// Fixed row/column indices always have N entries for simplicity, so that T(i) (fixed column) or T(j) (fixed row) provides with the square index.
//
// (i,j) squares not considered for symmetry reasons are assigned the index N^2 by convention.
//
// Cases for 1 <= N <= 7
// ---------------------
//
// N=1
// ---
// 0
//
// N=2
// ---
// 0 2
// x 1
//
// N=3
// ---
// 0 x 5
// 1 2 x
// x 3 4
// 
// N=4
// ---
// 0 x 6 8
// 1 2 x 9
// x 3 4 x
// x x 5 7 
//
// N=5
// ---
// 0 x x 11 13
// 1 3 x x  14
// 2 4 6 x  x
// x 5 7 9  x
// x x 8 10 12
// 
// N=6
// ---
// 0 x x 12 15 18
// 1 3 x x  16 19
// 2 4 6 x  x  20
// x 5 7 9  x  x
// x x 8 10 13 x
// x x x 11 14 17
//
// N=7
// ---
// 0 x x  x  19 22 25
// 1 4 x  x  x  23 26
// 2 5 8  x  x  x  27
// 3 6 9  12 x  x  x
// x 7 10 13 16 x  x
// x x 11 14 17 20 x
// x x x  15 18 21 24
//
//
//
// Non-symmetric case
// ------------------
// The symmetric case is firstly considered and one fills the unoccupied squares indices of the symmetric case with its occupied squares indices.
// For the odd N case: All squares except for the diagonal squares are used, with the unoccupied squares indices filled taken from the occupied squares indices starting from the left (see below).
// For the even N case: For the highest rows, one uses the occupied squares of the symmetric case besides the diagonal square and the last off-diagonal square is not used (see below).
//                      For the lowest rows, all the occupied squares of the symmetric case are used, taken from the occupied squares indices starting from the left (see below).
//
// Cases for 1 <= N <= 7
// ---------------------
//
// N=1
// ---
// 0
//
// N=2
// ---
// 0 2
// 1 1
//
// N=3
// ---
// 0 4 5
// 1 2 2
// 3 3 4
// 
// N=4
// ---
// 0 6 6 8
// 1 2 1 9
// 3 3 4 4
// 5 7 5 7 
//
// N=5
// ---
// 0 11 13 11 13
// 1 3  1  14 14
// 2 4  6  2  4
// 5 5  7  9  7
// 8 10 8 10 12
// 
// N=6
// ---
// 0  12 15 12 15 18
// 1  3  1  16 16 19
// 2  4  6  2  4  20
// 5  5  7  9  7  9
// 8  10 8  10 13 13
// 11 14 17 11 14 17
//
// N=7
// ---
// 0  19 22 25 19 22 25
// 1  4  1  23 26 23 26
// 2  5  8  2  5  27 27
// 3  6  9  12 3  6  9
// 7  7  10 13 16 10 13
// 11 14 11 14 17 20 17
// 15 18 21 15 18 21 24
// 
//
// Variables
// ---------
// N, N_square: N_square = N^2 is the number of squares of the matrix
// i: row index
// j: column index
// N_column_first_half: number of elements of the first half columns, with j <  N/2 : N/2     if N is even, (N+1)/2 if N is odd
// N_column_last_half:  number of elements of the last  half columns, with j >= N/2 : N/2 + 1 if N is even, (N+1)/2 if N is odd
// N_column: number of elements of the j column
// diagonal_square_index: square index of the diagonal square of the j column
// shift: integer added to the diagonal square index to obtain the square index of the (i,j) square
// i_try: row index trial value to test again a fixed i row index.


// Determination of the number of squares on a row or column in the 2D partitioning scheme. They can be occupied or not.
// ---------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::squares_number_per_row_column_calculate (const unsigned int processes_number)
{
  const unsigned int squares_number_per_row_column = make_uns_int (floor (-0.5 + 0.5*sqrt (1.0 + 8.0*processes_number)));

  return squares_number_per_row_column;
}


// Determination of the total number of active squares in the 2D partitioning scheme. The diagonal is always active even if squares are not occupied so that it is N(N+1)/2 in all cases
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::active_squares_number_calculate (const unsigned int processes_number)
{
  const unsigned int squares_number_per_row_column = squares_number_per_row_column_calculate (processes_number);

  const unsigned int active_squares_number = (squares_number_per_row_column*(squares_number_per_row_column + 1))/2;
  
  return active_squares_number;
}




// Determination of the active character of a process in the 2D partitioning scheme
// --------------------------------------------------------------------------------
bool MPI_2D_partitioning::is_process_active_determine_2D (
							  const unsigned int process ,
							  const unsigned int processes_number)
{
  const unsigned int active_squares_number = active_squares_number_calculate (processes_number);
  
  const bool is_process_active = (process < active_squares_number);
  
  return is_process_active;
}




// Determination of the symmetric 2D partitioning number of squares of the first half columns (even case), number of squares of a column (odd case)
// ------------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_column_first_half (const unsigned int N)
{
  const unsigned int N_column_first_half = (N%2 == 0) ? (N/2) : ((N + 1)/2);

  return N_column_first_half;
}

// Determination of the symmetric 2D partitioning number of squares of the last half columns (even case), number of squares of a column (odd case)
// -----------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_column_last_half (const unsigned int N)
{
  const unsigned int N_column_last_half = (N%2 == 0) ? (N/2 + 1) : ((N + 1)/2);

  return N_column_last_half;
}

// Determination of the symmetric 2D partitioning number of squares of the j column
// --------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_column (
						const unsigned int N ,
						const unsigned int j)
{
  if (N%2 == 0)
    {
      const unsigned int N_column_first_half = get_N_column_first_half (N);

      const unsigned int N_column = (j < N_column_first_half) ? (N_column_first_half) : (get_N_column_last_half (N));

      return N_column;
    }
  else
    {
      const unsigned int N_column = (N + 1)/2;

      return N_column;
    }
}

// Determination of the symmetric 2D partitioning number of squares of the first half rows (even case), number of squares of a row (odd case)
// ------------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_row_first_half (const unsigned int N)
{
  const unsigned int N_row_first_half = (N%2 == 0) ? (N/2 + 1) : ((N + 1)/2);

  return N_row_first_half;
}

// Determination of the symmetric 2D partitioning number of squares of the last half rows (even case), number of squares of a row (odd case)
// -----------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_row_last_half (const unsigned int N)
{
  const unsigned int N_row_last_half = (N%2 == 0) ? (N/2) : ((N + 1)/2);

  return N_row_last_half;
}

// Determination of the symmetric 2D partitioning number of squares of the i row
// --------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_N_row (
					     const unsigned int N ,
					     const unsigned int i)
{
  if (N%2 == 0)
    {
      const unsigned int N_row_first_half = get_N_row_first_half (N);
      
      const unsigned int N_row_first_half_minus_one = N_row_first_half - 1;

      const unsigned int N_row = (i < N_row_first_half_minus_one) ? (N_row_first_half) : (get_N_row_last_half (N));

      return N_row;
    }
  else
    {
      const unsigned int N_row = (N + 1)/2;

      return N_row;
    }
}


// Determination of the index of the 2D partitioning diagonal square of the k row or column. One uses a formula valid for the column k, and one uses the fact that the result is the same for the row k.
// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::get_diagonal_square_index (
							     const unsigned int N ,
							     const unsigned int k)
{
  if (N%2 == 0)
    {
      const unsigned int N_column_first_half = get_N_column_first_half (N);

      const unsigned int diagonal_square_index = (k <= N_column_first_half) ? (k*N_column_first_half) : (k*get_N_column_last_half (N) - N_column_first_half);

      return diagonal_square_index;
    }
  else
    {
      const unsigned int N_column = (N + 1)/2;

      const unsigned int diagonal_square_index = k*N_column;

      return diagonal_square_index;
    }
}



// Calculation of the indices of symmetric 2D partitioning for a fixed row
// -----------------------------------------------------------------------
void MPI_2D_partitioning::fixed_row_square_indices_calc_fill_symmetric_case (
									     const unsigned int i ,
									     class array<bool> &fixed_row_are_squares_occupied ,
									     class array<unsigned int> &fixed_row_square_indices)
{
  const unsigned int N = fixed_row_are_squares_occupied.dimension (0);

  const unsigned int N_square = N*N;

  fixed_row_square_indices = N_square;

  fixed_row_are_squares_occupied = false;

  for (unsigned int j = 0 ; j < N ; j++)
    {
      const unsigned int N_column = get_N_column (N , j);

      const unsigned int diagonal_square_index = get_diagonal_square_index (N , j);

      unsigned int shift = 0;

      bool has_square_index_been_found = false;

      while ((shift < N_column) && !has_square_index_been_found)
	{
	  const unsigned int i_try = (j + shift)%N;

	  if (i_try == i)
	    {
	      const unsigned int square_index = diagonal_square_index + shift;

	      fixed_row_square_indices(j) = square_index;

	      fixed_row_are_squares_occupied(j) = has_square_index_been_found = true;
	    }

	  shift++;
	}
    }
}





// Calculation of the indices of symmetric 2D partitioning for a fixed column
// --------------------------------------------------------------------------
void MPI_2D_partitioning::fixed_column_square_indices_calc_fill_symmetric_case (
										const unsigned int j ,
										class array<bool> &fixed_column_are_squares_occupied ,
										class array<unsigned int> &fixed_column_square_indices)
{
  const unsigned int N = fixed_column_are_squares_occupied.dimension (0);

  const unsigned int N_square = N*N;

  fixed_column_square_indices = N_square;

  fixed_column_are_squares_occupied = false;

  const unsigned int N_column = get_N_column (N , j);

  const unsigned int diagonal_square_index = get_diagonal_square_index (N , j);

  for (unsigned int shift = 0 ; shift < N_column ; shift++)
    {
      const unsigned int i = (j + shift)%N;

      const unsigned int square_index = diagonal_square_index + shift;

      fixed_column_square_indices(i) = square_index;

      fixed_column_are_squares_occupied(i) = true;
    }
}




// Calculation of the indices of non-symmetric 2D partitioning for a fixed row
// ---------------------------------------------------------------------------
void MPI_2D_partitioning::fixed_row_square_indices_calc_fill_non_symmetric_case (
										 const unsigned int i ,
										 class array<bool> &fixed_row_are_squares_occupied ,
										 class array<unsigned int> &fixed_row_square_indices)
{
  const unsigned int N = fixed_row_square_indices.dimension (0);
  
  class array<bool> are_squares_occupied(N , N);

  class array<unsigned int> square_indices(N , N);

  are_squares_occupied = false;

  square_indices = N;
  
  for (unsigned int ii = 0 ; ii < N ; ii++)
    {
      fixed_row_square_indices_calc_fill_symmetric_case (ii , fixed_row_are_squares_occupied , fixed_row_square_indices);

      for (unsigned int jj = 0 ; jj < N ; jj++)
	{
	  const bool is_square_occupied = fixed_row_are_squares_occupied(jj);
	  
	  if (is_square_occupied)
	    {
	      square_indices(ii , jj) = square_indices(jj , ii) = fixed_row_square_indices(jj);
	  
	      are_squares_occupied(ii , jj) = true;
	    }
	}
    }
  
  for (unsigned int j = 0 ; j < N ; j++)
    {
      fixed_row_are_squares_occupied(j) = are_squares_occupied(i , j);
      
      fixed_row_square_indices(j) = square_indices(i , j);
    }
}




// Calculation of the indices of non-symmetric 2D partitioning for a fixed column
// ---------------------------------------------------------------------------
void MPI_2D_partitioning::fixed_column_square_indices_calc_fill_non_symmetric_case (
										    const unsigned int j ,
										    class array<bool> &fixed_column_are_squares_occupied ,
										    class array<unsigned int> &fixed_column_square_indices)
{
  const unsigned int N = fixed_column_square_indices.dimension (0);
  
  class array<bool> are_squares_occupied(N , N);

  class array<unsigned int> square_indices(N , N);

  are_squares_occupied = false;

  square_indices = N;
  
  for (unsigned int jj = 0 ; jj < N ; jj++)
    {
      fixed_column_square_indices_calc_fill_symmetric_case (jj , fixed_column_are_squares_occupied , fixed_column_square_indices);

      for (unsigned int ii = 0 ; ii < N ; ii++)
	{
	  const bool is_square_occupied = fixed_column_are_squares_occupied(ii);
	  
	  if (is_square_occupied)
	    {
	      square_indices(ii , jj) = square_indices(jj , ii) = fixed_column_square_indices(ii);
	  
	      are_squares_occupied(ii , jj) = true;
	    }
	}
    }

  for (unsigned int i = 0 ; i < N ; i++)
    {
      fixed_column_are_squares_occupied(i) = are_squares_occupied(i , j);
      
      fixed_column_square_indices(i) = square_indices(i , j);
    }
}








// Determine the row on which a process is found for the symmetric case
// --------------------------------------------------------------------
unsigned int MPI_2D_partitioning::row_index_determine_symmetric_case (
								      const unsigned int process ,
								      const unsigned int processes_number)
{
  const unsigned int N = squares_number_per_row_column_calculate (processes_number);
  
  if (!is_process_active_determine_2D (process , processes_number)) return N;
  
  class array<bool> fixed_column_are_squares_occupied(N);

  class array<unsigned int> fixed_column_square_indices(N);

  for (unsigned int j = 0 ; j < N ; j++)
    {	    
      fixed_column_square_indices_calc_fill_symmetric_case (j , fixed_column_are_squares_occupied , fixed_column_square_indices);

      for (unsigned int i = 0 ; i < N ; i++)
	{
	  if (fixed_column_square_indices(i) == process) return i;
	}
    }
  
  return N;
}









// Determine the column on which a process is found for the symmetric case
// -----------------------------------------------------------------------
unsigned int MPI_2D_partitioning::column_index_determine_symmetric_case (
									 const unsigned int process ,
									 const unsigned int processes_number)
{
  const unsigned int N = squares_number_per_row_column_calculate (processes_number);
  
  if (!is_process_active_determine_2D (process , processes_number)) return N;
  
  class array<bool> fixed_column_are_squares_occupied(N);

  class array<unsigned int> fixed_column_square_indices(N);
  
  for (unsigned int j = 0 ; j < N ; j++)
    {	    
      fixed_column_square_indices_calc_fill_symmetric_case (j , fixed_column_are_squares_occupied , fixed_column_square_indices);

      for (unsigned int i = 0 ; i < N ; i++)
	{
	  if (fixed_column_square_indices(i) == process) return j;
	}
    }
  
  return N;
}






// Determine the row on which a process is found
// ---------------------------------------------
unsigned int MPI_2D_partitioning::row_index_determine (
						       const bool are_occupied_squares_considered ,
						       const unsigned int process ,
						       const unsigned int processes_number)
{
  const unsigned int i = (are_occupied_squares_considered) ? (row_index_determine_symmetric_case (process , processes_number)) : (column_index_determine_symmetric_case (process , processes_number));
  
  return i;
}






// Determine the column on which a process is found
// ------------------------------------------------
unsigned int MPI_2D_partitioning::column_index_determine (
							  const bool are_occupied_squares_considered ,
							  const unsigned int process ,
							  const unsigned int processes_number)
{
  const unsigned int j = (are_occupied_squares_considered) ? (column_index_determine_symmetric_case (process , processes_number)) : (row_index_determine_symmetric_case (process , processes_number));
  
  return j;
}




 
// Checks if one is in a diagonal square in 2D
// -------------------------------------------
bool MPI_2D_partitioning::is_it_diagonal_square_determine_2D (
							      const unsigned int process , 
							      const unsigned int processes_number)
{
  const unsigned int i_symmetric_case = row_index_determine_symmetric_case (process , processes_number);

  const unsigned int N = squares_number_per_row_column_calculate (processes_number);
  
  const unsigned int diagonal_square_index = get_diagonal_square_index (N , i_symmetric_case);

  const bool is_it_diagonal_square = (diagonal_square_index == process);
  
  return is_it_diagonal_square;
}








// Returns the square row index in which a vector index is if it is occupied in a process in hybrid 1D/2D
// ------------------------------------------------------------------------------------------------------
unsigned int MPI_2D_partitioning::square_row_index_determine_hybrid_1D_2D (
									   const unsigned long int total_vector_index ,
									   const class array<unsigned long int> &first_total_vector_indices ,
									   const class array<unsigned long int> &last_total_vector_indices)
{ 
  const unsigned int N = first_total_vector_indices.dimension (0);

  const unsigned int Nm1 = N - 1;
   
  unsigned int square_row_index_debut = 0;
  
  unsigned int square_row_index_end = Nm1;
   
  while ((square_row_index_end - square_row_index_debut) > 1)
    { 
      const unsigned int square_row_index_middle = square_row_index_debut + (square_row_index_end - square_row_index_debut)/2;
       
      if (total_vector_index <= first_total_vector_indices(square_row_index_middle))
	square_row_index_end = square_row_index_middle;
      else
	square_row_index_debut = square_row_index_middle;
    }
   
  const unsigned long int first_total_vector_index_debut = first_total_vector_indices(square_row_index_debut);

  const unsigned long int last_total_vector_index_debut = last_total_vector_indices(square_row_index_debut);
   
  if ((total_vector_index >= first_total_vector_index_debut) && (total_vector_index <= last_total_vector_index_debut)) return square_row_index_debut;
   
  const unsigned long int first_total_vector_index_end = first_total_vector_indices(square_row_index_end);

  const unsigned long int last_total_vector_index_end = last_total_vector_indices(square_row_index_end);
   
  if ((total_vector_index >= first_total_vector_index_end) && (total_vector_index <= last_total_vector_index_end)) return square_row_index_end;
   
  error_message_print_abort ("Square row index not found in MPI_symmetric_2D_partitioning::square_row_index_determine");
   
  return N;
}




 
// Checks if one is in a diagonal square in hybrid 1D/2D
// -----------------------------------------------------
bool MPI_2D_partitioning::is_it_diagonal_square_determine_hybrid_1D_2D (
									const bool is_it_MPI_parallelized_local ,
									const unsigned int square_row_index)
{
  return (!is_it_MPI_parallelized_local || (square_row_index == THIS_PROCESS));
}



// Prints the numbers of nodes close to that used which are all active with 2D partitioning
// ----------------------------------------------------------------------------------------
void MPI_2D_partitioning::print_active_processes_numbers ()
{
  const unsigned int squares_number_per_row_column_2D = squares_number_per_row_column_calculate (NUMBER_OF_PROCESSES);
      
  const unsigned int active_squares_number_2D_present  = (squares_number_per_row_column_2D*(squares_number_per_row_column_2D + 1))/2;
  const unsigned int active_squares_number_2D_previous = (squares_number_per_row_column_2D*(squares_number_per_row_column_2D - 1))/2;
  const unsigned int active_squares_number_2D_next     = ((squares_number_per_row_column_2D + 1)*(squares_number_per_row_column_2D + 2))/2;

  cout << endl << "Present  number of active processes for 2D partitioning : " << active_squares_number_2D_present << endl;
  cout <<         "Previous number of active processes for 2D partitioning : " << active_squares_number_2D_previous << endl;
  cout <<         "Next     number of active processes for 2D partitioning : " << active_squares_number_2D_next << endl << endl;
}
