#include "../numlib_def/numlib_def.h"

using namespace MPI_2D_partitioning;
using namespace string_routines;

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
 
#else
  int main ()
  {
    non_MPI_initialization ();
    
#endif

    OpenMP_initialization ();
    
    if (THIS_PROCESS == MASTER_PROCESS)
      {
	const unsigned int nd_max = 200;
	
	cout << endl;
	cout << "nd, N = nd(nd+1)/2" << endl;
	cout << "--------------------" << endl << endl;
	
	for (unsigned int nd = 1 ; nd <= nd_max ; nd += 10)
	  {
	    const unsigned int N0 = (nd%2 == 0) ? ((nd + 1)*(nd/2)) : (nd*((nd + 1)/2));
	    
	    const unsigned int N1 = ((nd + 1)%2 == 0) ? ((nd + 2)*((nd + 1)/2)) : ((nd + 1)*((nd + 2)/2));
	    const unsigned int N2 = ((nd + 2)%2 == 0) ? ((nd + 3)*((nd + 2)/2)) : ((nd + 2)*((nd + 3)/2));
	    const unsigned int N3 = ((nd + 3)%2 == 0) ? ((nd + 4)*((nd + 3)/2)) : ((nd + 3)*((nd + 4)/2));
	    const unsigned int N4 = ((nd + 4)%2 == 0) ? ((nd + 5)*((nd + 4)/2)) : ((nd + 4)*((nd + 5)/2));
	    const unsigned int N5 = ((nd + 5)%2 == 0) ? ((nd + 6)*((nd + 5)/2)) : ((nd + 5)*((nd + 6)/2));
	    const unsigned int N6 = ((nd + 6)%2 == 0) ? ((nd + 7)*((nd + 6)/2)) : ((nd + 6)*((nd + 7)/2));
	    const unsigned int N7 = ((nd + 7)%2 == 0) ? ((nd + 8)*((nd + 7)/2)) : ((nd + 7)*((nd + 8)/2));
	    const unsigned int N8 = ((nd + 8)%2 == 0) ? ((nd + 9)*((nd + 8)/2)) : ((nd + 8)*((nd + 9)/2));
	    
	    cout << "nd:" << nd     << " N:" << N0 << "  ";
	    cout << "nd:" << nd + 1 << " N:" << N1 << "  ";
	    cout << "nd:" << nd + 2 << " N:" << N2 << "  ";
	    cout << "nd:" << nd + 3 << " N:" << N3 << "  ";
	    cout << "nd:" << nd + 4 << " N:" << N4 << "  ";
	    cout << "nd:" << nd + 5 << " N:" << N5 << "  ";
	    cout << "nd:" << nd + 6 << " N:" << N6 << "  ";
	    cout << "nd:" << nd + 7 << " N:" << N7 << "  ";
	    cout << "nd:" << nd + 8 << " N:" << N8 << endl;
	  }
	
	cout << endl;
      }
    
#ifdef UseMPI
    
    const unsigned int N = squares_number_per_row_column_calculate (NUMBER_OF_PROCESSES);
	
    class array<bool> fixed_row_are_squares_occupied(N);
    class array<bool> fixed_column_are_squares_occupied(N);
    
    class array<unsigned int> fixed_row_square_indices(N);
    class array<unsigned int> fixed_column_square_indices(N);
    
    class array<bool> fixed_row_are_squares_occupied_hybrid_1D_2D(NUMBER_OF_PROCESSES);
    class array<bool> fixed_column_are_squares_occupied_hybrid_1D_2D(NUMBER_OF_PROCESSES);

    class array<unsigned int> fixed_row_square_indices_hybrid_1D_2D(NUMBER_OF_PROCESSES);
    class array<unsigned int> fixed_column_square_indices_hybrid_1D_2D(NUMBER_OF_PROCESSES);

#else
    
    const unsigned int N = 10;
    
#endif

    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl;
	cout << "Symmetric case" << endl;
	cout << "--------------" << endl << endl;
	
	for (unsigned int n = 1 ; n <= N ; n++)
	  {	    
	    class array<bool> are_squares_occupied_from_rows(n , n);
	    class array<bool> are_squares_occupied_from_columns(n , n);
	    
	    class array<unsigned int> square_indices_from_rows(n , n);
	    class array<unsigned int> square_indices_from_columns(n , n);

	    class array<bool> fixed_row_are_squares_occupied(n);
	    class array<bool> fixed_column_are_squares_occupied(n);
	    
	    class array<unsigned int> fixed_row_square_indices(n);
	    class array<unsigned int> fixed_column_square_indices(n);

	    cout << "n = " << n << endl;
	    cout << "------" << endl << endl;
				
	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		fixed_row_square_indices_calc_fill_symmetric_case  (i , fixed_row_are_squares_occupied , fixed_row_square_indices);
				
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    are_squares_occupied_from_rows(i , j) = fixed_row_are_squares_occupied(j);
		    
		    square_indices_from_rows(i , j) = fixed_row_square_indices(j);
		  }
	      }

	    for (unsigned int j = 0 ; j < n ; j++)
	      {
		fixed_column_square_indices_calc_fill_symmetric_case (j , fixed_column_are_squares_occupied , fixed_column_square_indices);

		for (unsigned int i = 0 ; i < n ; i++)
		  {
		    are_squares_occupied_from_columns(i , j) = fixed_column_are_squares_occupied(i);
		    
		    square_indices_from_columns(i , j) = fixed_column_square_indices(i);
		  }
	      }

	    cout << "Matrix from rows" << endl << endl;
		
	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		unsigned int n_row = 0;
		
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    if (are_squares_occupied_from_rows(i , j) && (square_indices_from_rows(i , j) >= 10))
		      {
			cout << square_indices_from_rows(i , j) << " ";
			
			n_row++;
		      }
		    else if (are_squares_occupied_from_rows(i , j) && (square_indices_from_rows(i , j) <= 9))
		      {
			cout << square_indices_from_rows(i , j) << "  ";
			
			n_row++;
		      }
		    else
		      cout << "x  ";
		  }
	    
		if (n_row != get_N_row (n , i)) error_message_print_abort ("Problem with get_N_row for n = " + make_string<unsigned int> (n));					
		
		cout << endl;
	      }
	    
	    cout << endl;

	    cout << "Matrix from columns" << endl << endl;
	    
 	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    if (are_squares_occupied_from_columns(i , j) && (square_indices_from_columns(i , j) >= 10))
		      {
			cout << square_indices_from_columns(i , j) << " ";
		      }
		    else if (are_squares_occupied_from_columns(i , j) && (square_indices_from_columns(i , j) <= 9))
		      {
			cout << square_indices_from_columns(i , j) << "  ";
		      }
		    else
		      {
			cout << "x  ";
		      }
		  }		
		
		cout << endl;
	      }
	    
	    cout << endl;
	  }
      
	cout << endl;
      }
    
#ifdef UseMPI

    MPI_helper::Barrier ();
    
    for (unsigned int i = 0 ; i < N ; i++)
      {
	fixed_row_square_indices_calc_fill_symmetric_case (i , fixed_row_are_squares_occupied_hybrid_1D_2D , fixed_row_square_indices_hybrid_1D_2D);

	const bool is_square_occupied = fixed_row_are_squares_occupied_hybrid_1D_2D(THIS_PROCESS);
	    
	const unsigned int color = (is_square_occupied) ? (i) : (i + N);

	const MPI_Comm MPI_row_communicator = MPI_helper::Comm_split (color , THIS_PROCESS , MPI_COMM_WORLD);
	
	const unsigned int MPI_row_communicator_process_number = MPI_helper::Comm_size (MPI_row_communicator);

	const unsigned int MPI_row_communicator_process = MPI_helper::Comm_rank (MPI_row_communicator);
	    
	MPI_helper::Barrier ();
	
	if (is_square_occupied)
	  cout << "World process:" << THIS_PROCESS
	       << "  row:" << i
	       << "  row communicator process number:" << MPI_row_communicator_process_number
	       << "  row communicator process:" << MPI_row_communicator_process << endl;
	
	MPI_helper::Barrier ();
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
      }
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
	    
    MPI_helper::Barrier ();
    
    for (unsigned int j = 0 ; j < N ; j++)
      {
	fixed_column_square_indices_calc_fill_symmetric_case (j , fixed_column_are_squares_occupied_hybrid_1D_2D , fixed_column_square_indices_hybrid_1D_2D);

	const bool is_square_occupied = fixed_column_are_squares_occupied_hybrid_1D_2D(THIS_PROCESS);
    	
	const unsigned int color = (is_square_occupied) ? (j) : (j + N);

	const MPI_Comm MPI_column_communicator = MPI_helper::Comm_split (color , THIS_PROCESS , MPI_COMM_WORLD);
	
	const unsigned int MPI_column_communicator_process_number = MPI_helper::Comm_size (MPI_column_communicator);

	const unsigned int MPI_column_communicator_process = MPI_helper::Comm_rank (MPI_column_communicator);
	
	MPI_helper::Barrier ();
	
	if (is_square_occupied)
	  cout << "World process:" << THIS_PROCESS
	       << "  column:" << j
	       << "  column communicator process number:" << MPI_column_communicator_process_number
	       << "  column communicator process:" << MPI_column_communicator_process << endl;
	
	MPI_helper::Barrier ();
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
      }
    
#endif

    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << endl << endl;
	cout << "Non-symmetric case" << endl;
	cout << "------------------" << endl << endl;

	for (unsigned int n = 1 ; n <= N ; n++)
	  {
	    class array<bool> are_squares_occupied_from_rows(n , n);
	    class array<bool> are_squares_occupied_from_columns(n , n);
	    
	    class array<unsigned int> square_indices_from_rows(n , n);
	    class array<unsigned int> square_indices_from_columns(n , n);

	    class array<bool> fixed_row_are_squares_occupied(n);
	    class array<bool> fixed_column_are_squares_occupied(n);
	    
	    class array<unsigned int> fixed_row_square_indices(n);
	    class array<unsigned int> fixed_column_square_indices(n);

	    cout << "n = " << n << endl;
	    cout << "------" << endl << endl;
				
	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		fixed_row_square_indices_calc_fill_non_symmetric_case  (i , fixed_row_are_squares_occupied , fixed_row_square_indices);
				
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    are_squares_occupied_from_rows(i , j) = fixed_row_are_squares_occupied(j);
		    
		    square_indices_from_rows(i , j) = fixed_row_square_indices(j);
		  }
	      }

	    for (unsigned int j = 0 ; j < n ; j++)
	      {
		fixed_column_square_indices_calc_fill_non_symmetric_case (j , fixed_column_are_squares_occupied , fixed_column_square_indices);

		for (unsigned int i = 0 ; i < n ; i++)
		  {
		    are_squares_occupied_from_columns(i , j) = fixed_column_are_squares_occupied(i);
		    
		    square_indices_from_columns(i , j) = fixed_column_square_indices(i);
		  }
	      }

	    cout << "Matrix from rows" << endl << endl;
	    
	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    if (square_indices_from_rows(i , j) >= 10)
		      {
			cout << square_indices_from_rows(i , j) << " ";
		      }
		    else if (square_indices_from_rows(i , j) <= 9)
		      {
			cout << square_indices_from_rows(i , j) << "  ";
		      }	
		  }
	    
		cout << endl;
	      }
	    
	    cout << endl;
	    
	    cout << "Matrix from columns" << endl << endl;
	    
	    for (unsigned int i = 0 ; i < n ; i++)
	      {
		for (unsigned int j = 0 ; j < n ; j++)
		  {
		    if (square_indices_from_columns(i , j) >= 10)
		      {
			cout << square_indices_from_columns(i , j) << " ";
		      }
		    else if (square_indices_from_columns(i , j) <= 9)
		      {
			cout << square_indices_from_columns(i , j) << "  ";
		      }		
		  }
	    
		cout << endl;
	      }
      
	    cout << endl;
	  }	  
      }
	  
#ifdef UseMPI
    
    MPI_helper::Barrier ();
	    
    for (unsigned int i = 0 ; i < N ; i++)
      {
	fixed_row_square_indices_calc_fill_non_symmetric_case (i , fixed_row_are_squares_occupied_hybrid_1D_2D , fixed_row_square_indices_hybrid_1D_2D);

	const bool is_square_occupied = fixed_row_are_squares_occupied_hybrid_1D_2D(THIS_PROCESS);
    
	const unsigned int color = (is_square_occupied) ? (i) : (i + N);
	
	const MPI_Comm MPI_row_communicator = MPI_helper::Comm_split (color , THIS_PROCESS , MPI_COMM_WORLD);
	
	const unsigned int MPI_row_communicator_process_number = MPI_helper::Comm_size (MPI_row_communicator);
	
	const unsigned int MPI_row_communicator_process = MPI_helper::Comm_rank (MPI_row_communicator);
	
	MPI_helper::Barrier ();
	
	if (is_square_occupied)
	  cout << "World process:" << THIS_PROCESS
	       << "  row:" << i
	       << "  row communicator process number:" << MPI_row_communicator_process_number
	       << "  row communicator process:" << MPI_row_communicator_process << endl;
	
	MPI_helper::Barrier ();
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
      }
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl;
    
#endif
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

