#include "../numlib_def/numlib_def.h"

//--// reset the random number generator with the system clock
void seed ()
{
  srand   ((unsigned) time (NULL));
  srand48 ((unsigned) time (NULL));
}

//--// reset the random number generator with a given seed
void seed (const unsigned int s_)
{
  srand   (s_);
  srand48 (s_);
}

//--// return an integer random number between 0 and N-1
unsigned int rand_int (const unsigned int N)
{
  if (N == 0) error_message_print_abort ("One must have N > 0 in rand_int");
  
  return rand () % N;
}

//random numbers for all basic types

template<> bool random_number<bool> ()
{
  return (rand () % 2 == 0) ? (true) : (false);
}

template<> signed char random_number<signed char> ()
{
  return rand () % 256;
} 

template<> wchar_t random_number<wchar_t> ()
{
  return static_cast<wchar_t> (rand ());
} 

template<> unsigned char random_number<unsigned char> ()
{
  return rand () % 256;
} 

template<> unsigned short int random_number<unsigned short int> ()
{
  return rand () % 65536;
} 

template<> unsigned int random_number<unsigned int> ()
{
  return rand ();
}

template<> unsigned long int random_number<unsigned long int> ()
{
  return rand ();
}

template<> char random_number<char> ()
{
  return rand () % 256;
} 

template<> short int random_number<short int> ()
{
  return rand () % 65536;
} 

template<> int random_number<int> ()
{
  return rand ();
}

template<> long int random_number<long int> ()
{
  return rand ();
}

template<> float random_number<float> ()
{
  return static_cast<float> (drand48 ());
} 

template<> double random_number<double> ()
{
  return drand48 ();
}

template<> long double random_number<long double> ()
{
  return drand48 ();
}

template<> complex<float> random_number<complex<float> > ()
{
  return complex<float> (random_number<float> () , random_number<float> ());
} 

template<> complex<double> random_number<complex<double> > ()
{
  return complex<double> (random_number<double> () , random_number<double> ());
}

template<> complex<long double> random_number<complex<long double> > ()
{
  return complex<long double> (random_number<double> () , random_number<double> ());
}


