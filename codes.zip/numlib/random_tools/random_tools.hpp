#ifndef RANDOM_TOOLS_H
#define RANDOM_TOOLS_H


//--// Reset the random number generator with the system clock
void seed ();

//--// Reset the random number generator with an integer
void seed (const unsigned int s_);

//--// return a integer random number between 0 and N-1
unsigned int rand_int (const unsigned int N);

template <class C>
C random_number ();

template<> bool                 random_number<bool> ();
template<> signed char          random_number<signed char> (); 
template<> wchar_t              random_number<wchar_t> (); 
template<> unsigned char        random_number<unsigned char> (); 
template<> unsigned short int   random_number<unsigned short int> (); 
template<> unsigned int         random_number<unsigned int> ();
template<> unsigned long int    random_number<unsigned long int> ();
template<> char                 random_number<char> (); 
template<> short int            random_number<short int> (); 
template<> int                  random_number<int> ();
template<> long int             random_number<long int> ();
template<> float                random_number<float> (); 
template<> double               random_number<double> ();
template<> long double          random_number<long double> ();
template<> complex<float>       random_number<complex<float> > (); 
template<> complex<double>      random_number<complex<double> > ();
template<> complex<long double> random_number<complex<long double> > ();

#endif
