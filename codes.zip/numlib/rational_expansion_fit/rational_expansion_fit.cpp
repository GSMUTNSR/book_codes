#include "../numlib_def/numlib_def.h"

// Same as rational_expansion_fit , but the abscissas can be complex here as well.

rational_expansion_fit_complex::rational_expansion_fit_complex () : fit (NO_FIT) , Nx (0) , dimension (0) , degree (0) , degree_derivative (0) {}

rational_expansion_fit_complex::rational_expansion_fit_complex (
								const enum fit_type fit_c , 
								const class array<complex<double> > &x_tab , 
								const class array<complex<double> > &f_tab)

{
  allocate_calc (fit_c , x_tab , f_tab);
}


rational_expansion_fit_complex::rational_expansion_fit_complex (const class rational_expansion_fit_complex &X)

{
  allocate_fill (X);
}




void rational_expansion_fit_complex::allocate_calc (
						    const enum fit_type fit_c , 
						    const class array<complex<double> > &x_tab , 
						    const class array<complex<double> > &f_tab)
{
  fit = fit_c;
  Nx = (x_tab.dimension (0)%2 == 0) ? (x_tab.dimension (0) - 1) : (x_tab.dimension (0));
  degree = (x_tab.dimension (0) - 1)/2;
  dimension = degree + 1;
  degree_derivative = degree - 1;
  
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.allocate (3);
      expansion_coeff_derivative_tab.allocate (2);

      expansion_coeff_tab = 0.0;
      expansion_coeff_derivative_tab = 0.0;
    }

  coeff_numerator_tab.allocate (dimension);
  coeff_denominator_tab.allocate (dimension);

  coeff_numerator_derivative_tab.allocate (dimension - 1);
  coeff_denominator_derivative_tab.allocate (dimension - 1);

  coeff_numerator_tab = 0.0 , coeff_denominator_tab = 0.0 , coeff_numerator_derivative_tab = 0.0 , coeff_denominator_derivative_tab = 0.0;
  coeff_denominator_tab(0) = 1.0;

  bool is_it_all_zeros = true;
  for (unsigned int i = 0 ; (i < Nx) && is_it_all_zeros ; i++) is_it_all_zeros = is_it_all_zeros && (f_tab(i) == 0.0);

  if (!is_it_all_zeros)
    {
      switch (fit)
	{
	case RATIONAL: 
	  {
	    class vector_class<complex<double> > f_smooth_tab(Nx);
	    for (unsigned int i = 0 ; i < Nx ; i++) f_smooth_tab(i) = f_tab(i);
	    rational_interpolation_coeff (x_tab , f_smooth_tab); 
	  } break;

	case RATIONAL_EXPANSION_DECAY: all_coefficients_expansion_decay (x_tab , f_tab); break;

	case RATIONAL_GAUSSIAN: all_coefficients_gaussian (x_tab , f_tab); break;

	default: abort_all ();
	}
    }
}



void rational_expansion_fit_complex::allocate_fill (const class rational_expansion_fit_complex &X)
{
  fit = X.fit;
  Nx = X.Nx;
  dimension = X.dimension;
  degree = X.degree;
  degree_derivative = X.degree_derivative;
  
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.allocate_fill (X.expansion_coeff_tab);
      expansion_coeff_derivative_tab.allocate_fill (X.expansion_coeff_derivative_tab);
    }

  coeff_numerator_tab.allocate_fill (X.coeff_numerator_tab);
  coeff_denominator_tab.allocate_fill (X.coeff_denominator_tab);

  coeff_numerator_derivative_tab.allocate_fill (X.coeff_numerator_derivative_tab);
  coeff_denominator_derivative_tab.allocate_fill (X.coeff_denominator_derivative_tab);
}





void rational_expansion_fit_complex::deallocate ()
{
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.deallocate ();
      expansion_coeff_derivative_tab.deallocate ();
    }

  coeff_numerator_tab.deallocate ();
  coeff_denominator_tab.deallocate ();

  coeff_numerator_derivative_tab.deallocate ();
  coeff_denominator_derivative_tab.deallocate ();
  
  fit = NO_FIT;
  Nx = 0;
  dimension = 0;
  degree = 0;
  degree_derivative = 0;
}


enum fit_type rational_expansion_fit_complex::fit_value () const
{
  return fit;
}

unsigned int rational_expansion_fit_complex::Nx_value () const
{
  return Nx;
}

unsigned int rational_expansion_fit_complex::dimension_value () const
{
  return dimension;
}

unsigned int rational_expansion_fit_complex::degree_value () const
{
  return degree;
}

unsigned int rational_expansion_fit_complex::degree_derivative_value () const
{
  return degree_derivative;
}


complex<double> rational_expansion_fit_complex::expansion_decay_constant_value () const
{
  return expansion_coeff_tab(1);
}




// Determination of the function F(x).exp(expansion_coeff(2)*x*x + expansion_coeff(1)*x + expansion_coeff(0))
// approximating the discrete function f_tab.
// F(x) is a rational function.
// If f_tab is made of real numbers and fit_type is not RATIONAL , f_tab must be strictly positive.


void rational_expansion_fit_complex::rational_interpolation_coeff (
								   const class array<complex<double> > &x_tab , 
								   const class vector_class<complex<double> > &f_smooth_tab)
{
  class matrix<complex<double> > interpolation_mat(Nx);
  
  class vector_class<complex<double> > coeff_numerator_den(Nx);

  for (unsigned int ix = 0 ; ix < Nx ; ix++)  
    { 
      const complex<double> &x = x_tab(ix);

      complex<double> x_pow_i = 1.0;

      complex<double> x_pow_i_plus_one_times_fx = f_smooth_tab(ix)*x;

      for (unsigned int i = 0 ; i <= degree ; i++)
	{
	  interpolation_mat(ix , i) = x_pow_i;

	  if (i > 0) interpolation_mat(ix , i+degree) = -x_pow_i_plus_one_times_fx;

	  x_pow_i *= x;
	  
	  if (i > 0) x_pow_i_plus_one_times_fx *= x;
	}
    }

  linear_system_solution_calc (interpolation_mat , f_smooth_tab , coeff_numerator_den);

  for (unsigned int i = 0 ; i <= degree ; i++) 
    {
      coeff_numerator_tab(i) = coeff_numerator_den(i);
      
      coeff_denominator_tab(i) = (i == 0) ? (1.0) : (coeff_numerator_den(i+degree));
    }

  for (unsigned int i = 0 ; i <= degree_derivative ; i++) 
    {
      coeff_numerator_derivative_tab(i) = (i+1)*coeff_numerator_tab[i+1];
      
      coeff_denominator_derivative_tab(i) = (i+1)*coeff_denominator_tab[i+1]; 
    }
}




void rational_expansion_fit_complex::all_coefficients_gaussian (
								const class array<complex<double> > &x_tab , 
								const class array<complex<double> > &f_tab)
{
  class matrix<complex<double> > A(3);
  
  class vector_class<complex<double> > B(3);
  class vector_class<complex<double> > X(3);

  A = 0.0 , B = 0.0;

  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const complex<double> &x = x_tab(ix) , x2 = x*x , x3 = x2*x , x4 = x3*x;
      const complex<double> log_fx = log (f_tab(ix)) , x_log_fx = x*log_fx , x2_log_fx = x*x_log_fx;

      A(0 , 0) += 1 , A(1 , 0) += x , A(2 , 0) += x2; 
      A(0 , 1) += x , A(1 , 1) += x2 , A(2 , 1) += x3; 
      A(0 , 2) += x2 , A(1 , 2) += x3 , A(2 , 2) += x4;

      B(0) += log_fx , B(1) += x_log_fx , B(2) += x2_log_fx;
    }

  linear_system_solution_calc (A , B , X);

  for (unsigned int i = 0 ; i < 3 ; i++) expansion_coeff_tab(i) = X(i);
  for (unsigned int i = 0 ; i < 2 ; i++) expansion_coeff_derivative_tab(i) = (i+1)*X(i+1);  

  class vector_class<complex<double> > f_smooth_tab(Nx);
  
  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const complex<double> &x = x_tab(ix);
      const complex<double> Px = polynomial_evaluation<complex<double> > (2 , expansion_coeff_tab , x);
      
      f_smooth_tab(ix) = f_tab(ix)/exp (Px);
    }

  rational_interpolation_coeff (x_tab , f_smooth_tab);
}




void rational_expansion_fit_complex::all_coefficients_expansion_decay (
								       const class array<complex<double> > &x_tab , 
								       const class array<complex<double> > &f_tab)
{
  class matrix<complex<double> > A(2);
  
  class vector_class<complex<double> > B(2);
  class vector_class<complex<double> > X(2);

  A = 0.0 , B = 0.0;

  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const complex<double> &x = x_tab(ix) , x2 = x*x;
      const complex<double> log_fx = log (f_tab(ix)) , x_log_fx = x*log_fx;

      A(0 , 0) += 1 , A(1 , 0) += x ; 
      A(0 , 1) += x , A(1 , 1) += x2; 

      B(0) += log_fx , B(1) += x_log_fx;
    }

  linear_system_solution_calc (A , B , X);
  
  const complex<double> k = X(1);

  expansion_coeff_tab(0) = 0.0;
  expansion_coeff_tab(1) = k;
  expansion_coeff_tab(2) = 0.0;
  
  expansion_coeff_derivative_tab(0) = k;
  expansion_coeff_derivative_tab(1) = 0.0;

  class vector_class<complex<double> > f_smooth_tab(Nx);
  
  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const complex<double> &x = x_tab(ix);
      
      f_smooth_tab(ix) = f_tab(ix)/exp (k*x);
    }

  rational_interpolation_coeff (x_tab , f_smooth_tab);
}



complex<double> rational_expansion_fit_complex::operator () (const complex<double> &x) const
{	
  const complex<double> poly_numerator = polynomial_evaluation<complex<double> > (degree , coeff_numerator_tab , x);
  const complex<double> poly_denominator = polynomial_evaluation<complex<double> > (degree , coeff_denominator_tab , x);
  const complex<double> ratio = poly_numerator/poly_denominator;

  switch (fit)
    {
    case RATIONAL: 
      {
	return ratio;
      }

    case RATIONAL_EXPANSION_DECAY: 
      {
	const complex<double> k = expansion_decay_constant_value () , Fx = ratio*exp (k*x);

	return Fx;
      }

    case RATIONAL_GAUSSIAN: 
      {
	const complex<double> Px = polynomial_evaluation<complex<double> > (2 , expansion_coeff_tab , x) , Fx = ratio*exp (Px);

	return Fx;
      }

    default: abort_all ();
    }

  return NADA;
}




complex<double> rational_expansion_fit_complex::derivative (const complex<double> &x) const
{
  const complex<double> poly_numerator = polynomial_evaluation<complex<double> > (degree , coeff_numerator_tab , x);
  const complex<double> poly_denominator = polynomial_evaluation<complex<double> > (degree , coeff_denominator_tab , x);

  const complex<double> poly_numerator_derivative = polynomial_evaluation<complex<double> > (degree_derivative , coeff_numerator_derivative_tab , x);
  const complex<double> poly_denominator_derivative = polynomial_evaluation<complex<double> > (degree_derivative , coeff_denominator_derivative_tab , x);

  switch (fit)
    {
    case RATIONAL: 
      {
	const complex<double> dFx = (poly_numerator_derivative - poly_numerator*poly_denominator_derivative/poly_denominator)/poly_denominator;

	return dFx;
      }

    case RATIONAL_EXPANSION_DECAY:  
      {
	const complex<double> k = expansion_decay_constant_value ();
	const complex<double> dFx = (poly_numerator_derivative + poly_numerator*(k - poly_denominator_derivative/poly_denominator))*exp (k*x)/poly_denominator;

	return dFx;
      }

    case RATIONAL_GAUSSIAN: 
      {	
	const complex<double> Px = polynomial_evaluation<complex<double> > (2 , expansion_coeff_tab , x); 
	const complex<double> dPx = polynomial_evaluation<complex<double> > (1 , expansion_coeff_derivative_tab , x);
	const complex<double> dFx = (poly_numerator_derivative + poly_numerator*(dPx - poly_denominator_derivative/poly_denominator))*exp (Px)/poly_denominator;

	return dFx;
      }

    default: abort_all ();
    }

  return NADA;
}

