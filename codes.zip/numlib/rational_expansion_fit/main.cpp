#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void double_test (const unsigned int N , const unsigned int N_big , const double xmin , const double xmax , const double k , const double a , const double sample)
{
  const double step = (xmax - xmin)/static_cast<double> (N);

  const double step_big = (xmax - xmin)/static_cast<double> (N_big);

  class array<double> x_tab(N);
  class array<double> f_tab(N);

  class array<double> f_exp_tab(N);

  class array<double> f_Gaussian_tab(N);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = xmin + i*step + 1E-15 , fx = sin (x)*sin(x) , fx_exp = fx*exp (-k*x) , fx_Gaussian = fx_exp*exp (-a*x*x);
		
      x_tab(i) = x , f_tab(i) = fx , f_exp_tab(i) = fx_exp , f_Gaussian_tab(i) = fx_Gaussian;
    }

  const class rational_expansion_fit<double> F(RATIONAL , x_tab , f_tab);
  const class rational_expansion_fit<double> F_exp(RATIONAL_EXPANSION_DECAY , x_tab , f_exp_tab);
  const class rational_expansion_fit<double> F_Gaussian(RATIONAL_GAUSSIAN , x_tab , f_Gaussian_tab);

  for (unsigned int i = 0 ; i < N_big ; i++)
    {
      if (random_number<double> () < sample)
	{
	  const double x = xmin + i*step_big + 1E-15;

	  const double fx = sin (x)*sin(x);

	  const double fx_exp = fx*exp (-k*x);

	  const double fx_Gaussian = fx_exp*exp (-a*x*x);

	  const double dfx = 2.0*cos (x)*sin(x);

	  const double dfx_exp = dfx*exp (-k*x) - k*fx_exp;

	  const double dfx_Gaussian = dfx_exp*exp (-a*x*x) -2.0*a*x*fx_Gaussian;

	  const double f_precision = inf_norm (F(x) - fx);

	  const double df_precision = inf_norm (F.derivative(x) - dfx);

	  const double f_exp_precision = inf_norm (F_exp(x) - fx_exp);

	  const double df_exp_precision = inf_norm (F_exp.derivative(x) - dfx_exp);

	  const double f_Gaussian_precision = inf_norm (F_Gaussian(x) - fx_Gaussian);

	  const double df_Gaussian_precision = inf_norm (F_Gaussian.derivative(x) - dfx_Gaussian);

	  const double total_precision = (f_precision + df_precision + f_exp_precision + df_exp_precision + f_Gaussian_precision + df_Gaussian_precision)/6.0;

	  cout << "x : " << x << " fit precision (double) : " << total_precision << endl;
	}
    }
}


void complex_test (const unsigned int N , const unsigned int N_big , const double xmin , const double xmax , const double kr , const double ar , const double theta , const double sample)
{
  const double step = (xmax - xmin)/static_cast<double> (N);

  const double step_big = (xmax - xmin)/static_cast<double> (N_big);

  const double cos_theta = cos (theta);
  const double sin_theta = sin (theta);

  const complex<double> exp_Itheta(cos_theta , sin_theta);

  const complex<double> k = kr*exp_Itheta;
  const complex<double> a = ar*exp_Itheta;

  class array<complex<double> > x_tab(N);
  class array<complex<double> > f_tab(N);

  class array<complex<double> > f_exp_tab(N);

  class array<complex<double> > f_Gaussian_tab(N);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const complex<double> x = (xmin + i*step)*exp_Itheta + 1E-15;

      const complex<double> fx = sin (x);

      const complex<double> fx_exp = fx*exp (-k*x);

      const complex<double> fx_Gaussian = fx_exp*exp (-a*x*x);
		
      x_tab(i) = x , f_tab(i) = fx , f_exp_tab(i) = fx_exp , f_Gaussian_tab(i) = fx_Gaussian;
    }

  const class rational_expansion_fit_complex F(RATIONAL , x_tab , f_tab);
  
  const class rational_expansion_fit_complex F_exp(RATIONAL_EXPANSION_DECAY , x_tab , f_exp_tab);

  const class rational_expansion_fit_complex F_Gaussian(RATIONAL_GAUSSIAN , x_tab , f_Gaussian_tab);

  for (unsigned int i = 0 ; i < N_big ; i++)
    {
      if (random_number<double> () < sample)
	{
	  const complex<double> x = (xmin + i*step_big)*exp_Itheta + 1E-15;

	  const complex<double> fx = sin (x);

	  const complex<double> fx_exp = fx*exp (-k*x);

	  const complex<double> fx_Gaussian = fx_exp*exp (-a*x*x);

	  const complex<double> dfx = cos (x);

	  const complex<double> dfx_exp = dfx*exp (-k*x) - k*fx_exp;

	  const complex<double> dfx_Gaussian = dfx_exp*exp (-a*x*x) -2.0*a*x*fx_Gaussian;

	  const double f_precision = inf_norm (F(x) - fx);

	  const double df_precision = inf_norm (F.derivative (x) - dfx);

	  const double f_exp_precision = inf_norm (F_exp(x) - fx_exp);

	  const double df_exp_precision = inf_norm (F_exp.derivative (x) - dfx_exp);

	  const double f_Gaussian_precision = inf_norm (F_Gaussian(x) - fx_Gaussian);

	  const double df_Gaussian_precision = inf_norm (F_Gaussian.derivative (x) - dfx_Gaussian);

	  const double total_precision = (f_precision + df_precision + f_exp_precision + df_exp_precision + f_Gaussian_precision + df_Gaussian_precision)/6.0;

	  cout << "x : " << x << " fit precision (complex) : " << total_precision << endl;
	}
    }
}


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);

    const unsigned int N = 300;

    const unsigned int N_big = 1000;
    
    const double xmin = 0.0;
    const double xmax = 5.0;

    const double k = 0.1;
    const double a = 0.01;

    const double theta = 0.125;
    const double sample = 0.04;

    double_test (N , N_big , xmin , xmax , k , a , sample);

    complex_test (N , N_big , xmin , xmax , k , a , theta , sample);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif

  }




