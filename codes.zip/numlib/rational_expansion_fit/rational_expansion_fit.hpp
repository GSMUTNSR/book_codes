#ifndef RATIONAL_EXPANSION_FIT_HPP
#define RATIONAL_EXPANSION_FIT_HPP

enum fit_type {NO_FIT , RATIONAL , RATIONAL_EXPANSION_DECAY , RATIONAL_GAUSSIAN};

// Class interpolationolating functions with an rational , exponential or Gaussian asymptotic behavior
// -------------------------------------------------------------------------------------------
// One wants a very precise interpolationolation of a function.
// A standard rational fit (RATIONAL) , as in Padé approximation , is very precise for smooth functions.
// However , it is not the case for functions behaving as f_smooth(x).exp (a.x) or f_smooth(x).exp (a.x + b*x^2).
// In this case , the function is first approximated by exp (a.x) (RATIONAL_EXPANSION_DECAY) or exp (a.x + b*x^2) (RATIONAL_GAUSSIAN) , 
// issued from a linear problem from log (f) , and then f_smooth(x) = f(x)/exp (a.x) or f(x)/exp (a.x + b*x^2).
// f_smooth is then treated with a standard rational fit.
// As log (f) is used for exponential and Gaussian decay , f(x) must be strictly positive if it is double.
// If f(x) is zero for a given x , it is sufficient to replace it by a small non-zero number.

template<typename SCALAR_TYPE>
class rational_expansion_fit
{
public:

  rational_expansion_fit () : fit (NO_FIT) , Nx (0) , dimension (0) , degree (0) , degree_derivative (0) {}
    
  rational_expansion_fit (
			  const enum fit_type fit_c , 
			  const class array<double> &x_tab , 
			  const class array<SCALAR_TYPE> &f_tab)
  {
    allocate_calc (fit_c , x_tab , f_tab);
  }

  rational_expansion_fit (const class rational_expansion_fit &X)
  {
    allocate_fill (X);
  }

  void allocate_calc (
		      const enum fit_type fit_c , 
		      const class array<double> &x_tab , 
		      const class array<SCALAR_TYPE> &f_tab);

  void allocate_fill (const class rational_expansion_fit<SCALAR_TYPE> &X);

  void deallocate ();

  enum fit_type fit_value () const
  {
    return fit;
  }

  unsigned int Nx_value () const
  {
    return Nx;
  }

  unsigned int dimension_value () const
  {
    return dimension;
  }

  unsigned int degree_value () const
  {
    return degree;
  }

  unsigned int degree_derivative_value () const
  {
    return degree_derivative;
  }

  SCALAR_TYPE expansion_decay_constant_value () const
  {	
    return expansion_coeff_tab(1);
  }
  
  SCALAR_TYPE operator() (const double x) const;

  SCALAR_TYPE derivative (const double x) const;

private:
 
  enum fit_type fit;
  unsigned int Nx , dimension , degree , degree_derivative;

  class array<SCALAR_TYPE> expansion_coeff_tab , coeff_numerator_tab , coeff_denominator_tab;
  class array<SCALAR_TYPE> expansion_coeff_derivative_tab , coeff_numerator_derivative_tab , coeff_denominator_derivative_tab;

  void all_coefficients_gaussian (const class array<double> &x_tab , const class array<SCALAR_TYPE> &f_tab);
  void all_coefficients_expansion_decay (const class array<double> &x_tab , const class array<SCALAR_TYPE> &f_tab);
  void rational_interpolation_coeff (const class array<double> &x_tab , const class vector_class<SCALAR_TYPE> &f_smooth_tab);
};



template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::allocate_calc (
							 const enum fit_type fit_c , 
							 const class array<double> &x_tab , 
							 const class array<SCALAR_TYPE> &f_tab)
{
  fit = fit_c;
  Nx = (x_tab.dimension (0)%2 == 0) ? (x_tab.dimension (0) - 1) : (x_tab.dimension (0));
  degree = (x_tab.dimension (0) - 1)/2;
  dimension = degree + 1;
  degree_derivative = degree - 1;
  
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.allocate (3);
      expansion_coeff_derivative_tab.allocate (2);

      expansion_coeff_tab = 0.0 , expansion_coeff_derivative_tab = 0.0;
    }

  coeff_numerator_tab.allocate (dimension);
  coeff_denominator_tab.allocate (dimension);

  coeff_numerator_derivative_tab.allocate (dimension - 1);
  coeff_denominator_derivative_tab.allocate (dimension - 1);

  coeff_numerator_tab = 0.0 , coeff_denominator_tab = 0.0 , coeff_numerator_derivative_tab = 0.0 , coeff_denominator_derivative_tab = 0.0;
  coeff_denominator_tab(0) = 1.0;

  bool is_it_all_zeros = true;
  for (unsigned int i = 0 ; (i < Nx) && is_it_all_zeros ; i++) is_it_all_zeros = is_it_all_zeros && (f_tab(i) == 0.0);

  if (!is_it_all_zeros)
    {
      switch (fit)
	{
	case RATIONAL: 
	  {
	    class vector_class<SCALAR_TYPE> f_smooth_tab(Nx);
	    for (unsigned int i = 0 ; i < Nx ; i++) f_smooth_tab(i) = f_tab(i);
	    rational_interpolation_coeff (x_tab , f_smooth_tab); 
	  } break;
	  
	case RATIONAL_EXPANSION_DECAY: all_coefficients_expansion_decay (x_tab , f_tab); break;
	  
	case RATIONAL_GAUSSIAN: all_coefficients_gaussian (x_tab , f_tab); break;

	default: abort_all ();
	}
    }
}

template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::allocate_fill (const class rational_expansion_fit<SCALAR_TYPE> &X)
{
  fit = X.fit;
  Nx = X.Nx;
  dimension = X.dimension;
  degree = X.degree;
  degree_derivative = X.degree_derivative;
  
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.allocate_fill (X.expansion_coeff_tab);
      expansion_coeff_derivative_tab.allocate_fill (X.expansion_coeff_derivative_tab);
    }

  coeff_numerator_tab.allocate_fill (X.coeff_numerator_tab);
  coeff_denominator_tab.allocate_fill (X.coeff_denominator_tab);

  coeff_numerator_derivative_tab.allocate_fill (X.coeff_numerator_derivative_tab);
  coeff_denominator_derivative_tab.allocate_fill (X.coeff_denominator_derivative_tab);
}




template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::deallocate ()
{
  if (fit != RATIONAL) 
    {
      expansion_coeff_tab.deallocate ();
      expansion_coeff_derivative_tab.deallocate ();
    }

  coeff_numerator_tab.deallocate ();
  coeff_denominator_tab.deallocate ();

  coeff_numerator_derivative_tab.deallocate ();
  coeff_denominator_derivative_tab.deallocate ();

  fit = NO_FIT;
  Nx = 0;
  dimension = 0;
  degree = 0;
  degree_derivative = 0;
}

// Determination of the function F(x).exp(expansion_coeff(2)*x*x + expansion_coeff(1)*x + expansion_coeff(0))
// approximating the discrete function f_tab.
// F(x) is a rational function.
// If f_tab is made of real numbers and fit_type is not RATIONAL , f_tab must be strictly positive.


template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::rational_interpolation_coeff (
									const class array<double> &x_tab , 
									const class vector_class<SCALAR_TYPE> &f_smooth_tab)
{
  class matrix<SCALAR_TYPE> interpolation_mat(Nx);

  class vector_class<SCALAR_TYPE> coeff_numerator_den(Nx);
    
  for (unsigned int ix = 0 ; ix < Nx ; ix++)  
    { 
      const double x = x_tab(ix);
      
      double x_pow_i = 1.0;

      SCALAR_TYPE x_pow_i_plus_one_times_fx = f_smooth_tab(ix)*x;

      for (unsigned int i = 0 ; i <= degree ; i++)
	{
	  interpolation_mat(ix , i) = x_pow_i;

	  if (i > 0) interpolation_mat(ix , i+degree) = -x_pow_i_plus_one_times_fx;

	  x_pow_i *= x;

	  if (i > 0) x_pow_i_plus_one_times_fx *= x;
	}
    }

  linear_system_solution_calc (interpolation_mat , f_smooth_tab , coeff_numerator_den);

  for (unsigned int i = 0 ; i <= degree ; i++) 
    {
      coeff_numerator_tab(i) = coeff_numerator_den(i);
      
      coeff_denominator_tab(i) = (i == 0) ? (1.0) : (coeff_numerator_den(i+degree));
    }

  for (unsigned int i = 0 ; i <= degree_derivative ; i++) 
    {
      coeff_numerator_derivative_tab(i) = (i+1)*coeff_numerator_tab[i+1];

      coeff_denominator_derivative_tab(i) = (i+1)*coeff_denominator_tab[i+1]; 
    }
}




template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::all_coefficients_gaussian (
								     const class array<double> &x_tab , 
								     const class array<SCALAR_TYPE> &f_tab)
{
  class matrix<SCALAR_TYPE> A(3);
  
  class vector_class<SCALAR_TYPE> B(3);
  class vector_class<SCALAR_TYPE> X(3);

  A = 0.0;
  B = 0.0;

  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const double x = x_tab(ix);

      const double x2 = x*x;

      const double x3 = x2*x;
      const double x4 = x3*x;
      
      const SCALAR_TYPE log_fx = log (f_tab(ix));

      const SCALAR_TYPE x_log_fx = x*log_fx;
      
      const SCALAR_TYPE x2_log_fx = x*x_log_fx;

      A(0 , 0) += 1  , A(1 , 0) += x  , A(2 , 0) += x2; 
      A(0 , 1) += x  , A(1 , 1) += x2 , A(2 , 1) += x3; 
      A(0 , 2) += x2 , A(1 , 2) += x3 , A(2 , 2) += x4;

      B(0) += log_fx , B(1) += x_log_fx , B(2) += x2_log_fx;
    }

  linear_system_solution_calc (A , B , X);

  for (unsigned int i = 0 ; i < 3 ; i++) expansion_coeff_tab(i) = X(i);

  for (unsigned int i = 0 ; i < 2 ; i++) expansion_coeff_derivative_tab(i) = (i+1)*X(i+1);  

  class vector_class<SCALAR_TYPE> f_smooth_tab(Nx);
  
  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const double x = x_tab(ix);
      
      const SCALAR_TYPE Px = polynomial_evaluation<SCALAR_TYPE> (2 , expansion_coeff_tab , x);

      f_smooth_tab(ix) = f_tab(ix)/exp (Px);
    }

  rational_interpolation_coeff (x_tab , f_smooth_tab);
}




template<typename SCALAR_TYPE>
void rational_expansion_fit<SCALAR_TYPE>::all_coefficients_expansion_decay (
									    const class array<double> &x_tab , 
									    const class array<SCALAR_TYPE> &f_tab)
{
  class matrix<SCALAR_TYPE> A(2); 

  class vector_class<SCALAR_TYPE> B(2);
  class vector_class<SCALAR_TYPE> X(2);

  A = 0.0;
  B = 0.0;

  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const double x = x_tab(ix);

      const double x2 = x*x;
      
      const SCALAR_TYPE log_fx = log (f_tab(ix));

      const SCALAR_TYPE x_log_fx = x*log_fx;

      A(0 , 0) += 1 , A(1 , 0) += x ; 
      A(0 , 1) += x , A(1 , 1) += x2; 

      B(0) += log_fx , B(1) += x_log_fx;
    }

  linear_system_solution_calc (A , B , X);
  
  const SCALAR_TYPE k = X(1);

  expansion_coeff_tab(0) = 0.0;
  expansion_coeff_tab(1) = k;
  expansion_coeff_tab(2) = 0.0;

  expansion_coeff_derivative_tab(0) = k;
  expansion_coeff_derivative_tab(1) = 0.0;

  class vector_class<SCALAR_TYPE> f_smooth_tab(Nx);

  for (unsigned int ix = 0 ; ix < Nx ; ix++)
    {
      const double x = x_tab(ix);

      f_smooth_tab(ix) = f_tab(ix)/exp (k*x);
    }

  rational_interpolation_coeff (x_tab , f_smooth_tab);
}



template<typename SCALAR_TYPE>
SCALAR_TYPE rational_expansion_fit<SCALAR_TYPE>::operator () (const double x) const
{
  const SCALAR_TYPE poly_num = polynomial_evaluation<SCALAR_TYPE> (degree , coeff_numerator_tab , x);
  const SCALAR_TYPE poly_den = polynomial_evaluation<SCALAR_TYPE> (degree , coeff_denominator_tab , x);
  const SCALAR_TYPE ratio = poly_num/poly_den;

  switch (fit)
    {
    case RATIONAL: 
      {
	return ratio;
      }

    case RATIONAL_EXPANSION_DECAY:  
      {
	const SCALAR_TYPE k = expansion_coeff_tab(1) , Fx = ratio*exp (k*x);

	return Fx;
      }

    case RATIONAL_GAUSSIAN: 
      {
	const SCALAR_TYPE Px = polynomial_evaluation<SCALAR_TYPE> (2 , expansion_coeff_tab , x) , Fx = ratio*exp (Px);

	return Fx;
      }

    default: abort_all ();
    }

  return NADA;
}




template<typename SCALAR_TYPE>
SCALAR_TYPE rational_expansion_fit<SCALAR_TYPE>::derivative (const double x) const
{
  const SCALAR_TYPE poly_num = polynomial_evaluation<SCALAR_TYPE> (degree , coeff_numerator_tab , x);
  const SCALAR_TYPE poly_den = polynomial_evaluation<SCALAR_TYPE> (degree , coeff_denominator_tab , x);

  const SCALAR_TYPE poly_num_der = polynomial_evaluation<SCALAR_TYPE> (degree_derivative , coeff_numerator_derivative_tab , x);
  const SCALAR_TYPE poly_den_der = polynomial_evaluation<SCALAR_TYPE> (degree_derivative , coeff_denominator_derivative_tab , x);


  switch (fit)
    {
    case RATIONAL: 
      {
	const SCALAR_TYPE dFx = (poly_num_der - poly_num*poly_den_der/poly_den)/poly_den;

	return dFx;
      }

    case RATIONAL_EXPANSION_DECAY: 
      {
	const SCALAR_TYPE k = expansion_coeff_tab(1) , dFx = (poly_num_der + poly_num*(k - poly_den_der/poly_den))*exp (k*x)/poly_den;

	return dFx;
      }

    case RATIONAL_GAUSSIAN: 
      {	
	const SCALAR_TYPE Px = polynomial_evaluation<SCALAR_TYPE> (2 , expansion_coeff_tab , x) , dPx = polynomial_evaluation<SCALAR_TYPE> (1 , expansion_coeff_derivative_tab , x);
	const SCALAR_TYPE dFx = (poly_num_der + poly_num*(dPx - poly_den_der/poly_den))*exp (Px)/poly_den;

	return dFx;
      }

    default: abort_all ();
    }

  return NADA;
}




class rational_expansion_fit_complex
{
public:
  
  rational_expansion_fit_complex ();
  
  rational_expansion_fit_complex (
				  const enum fit_type fit_c , 
				  const class array<complex<double> > &x_tab , 
				  const class array<complex<double> > &f_tab);

  rational_expansion_fit_complex (const class rational_expansion_fit_complex &X);

  void allocate_calc (
		      const enum fit_type fit_c , 
		      const class array<complex<double> > &x_tab , 
		      const class array<complex<double> > &f_tab);

  void allocate_fill (const class rational_expansion_fit_complex &X);

  void deallocate ();

  enum fit_type fit_value () const;
  unsigned int Nx_value () const;
  unsigned int dimension_value () const;
  unsigned int degree_value () const;
  unsigned int degree_derivative_value () const;
  
  complex<double> operator() (const complex<double> &x) const;

  complex<double> derivative (const complex<double> &x) const;

  complex<double> expansion_decay_constant_value () const;
  
private:

  enum fit_type fit;
  unsigned int Nx , dimension , degree , degree_derivative;

  class array<complex<double> > expansion_coeff_tab , coeff_numerator_tab , coeff_denominator_tab;
  class array<complex<double> > expansion_coeff_derivative_tab , coeff_numerator_derivative_tab , coeff_denominator_derivative_tab;

  void all_coefficients_gaussian (const class array<complex<double> > &x_tab , const class array<complex<double> > &f_tab);
  void all_coefficients_expansion_decay (const class array<complex<double> > &x_tab , const class array<complex<double> > &f_tab);
  void rational_interpolation_coeff (const class array<complex<double> > &x_tab , const class vector_class<complex<double> > &f_smooth_tab);
};

#endif

