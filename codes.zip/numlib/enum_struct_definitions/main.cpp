#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    cout << "beta (allowed) : "         << beta_type_determine ("allowed")         << endl;
    cout << "beta (first.forbidden) : " << beta_type_determine ("first.forbidden") << endl;

    cout << endl;
    cout << "beta (beta+) : " << beta_pm_type_determine ("beta+") << endl;
    cout << "beta (beta-) : " << beta_pm_type_determine ("beta-") << endl;

    cout << endl;
    cout << "EM (E) : " << EM_determine ("E2") << endl;
    cout << "EM (M) : " << EM_determine ("M1") << endl;

    cout << endl;
    cout << "EM (index = 0) : " << EM_determine_from_index (0) << endl;
    cout << "EM (index = 1) : " << EM_determine_from_index (1) << endl;

    if (EM_determine_from_index (0) != ELECTRIC) error_message_print_abort ("Problem with EM_determine_from_index");
    if (EM_determine_from_index (1) != MAGNETIC) error_message_print_abort ("Problem with EM_determine_from_index");

    cout << endl;
    cout << "ELECTRIC index : " << EM_index_determine (ELECTRIC) << endl;
    cout << "MAGNETIC index : " << EM_index_determine (MAGNETIC) << endl;

    if (EM_index_determine (ELECTRIC) != 0) error_message_print_abort ("Problem with EM_index_determine");
    if (EM_index_determine (MAGNETIC) != 1) error_message_print_abort ("Problem with EM_index_determine");

    cout << endl;
    cout << "spectroscopic_factor (stripping): " << spectroscopic_factor_type_determine ("stripping") << endl;
    cout << "spectroscopic_factor (pick.up): " << spectroscopic_factor_type_determine ("pick.up") << endl;


    cout << endl;
    cout << "EM letter (ELECTRIC) : " << EM_letter_determine (ELECTRIC) << endl;
    cout << "EM letter (MAGNETIC) : " << EM_letter_determine (MAGNETIC) << endl;

    cout << endl << GSM_CODE << " " << OPTIMIZATION_CODE << " " << CC_CODE << endl;
    cout << ELECTRIC << " " << MAGNETIC << endl << endl;

    ofstream outfile("test_file");
    outfile << ZERO_KPEAK << " " << KPEAK_KMIDDLE << " " << KMIDDLE_KMAX << " " << endl;
    outfile << COULOMB_POTENTIAL << " " << HO_POTENTIAL << " " << WS << " " << WS_ANALYTIC << " " << COMPLEX_WS << " " << WS_ANALYTIC_PARTIAL_DERIVATIVE << " " << PTG_POTENTIAL << " " << HF << " " << MSDHF << " " << EFFECTIVE_MASS_POTENTIAL << " " << INTERPOLATED_POTENTIAL << " " << COMPLEX_INTERPOLATED_POTENTIAL << " " << KKNN  << " " << SOURCE << " " << DIPOLAR << " " << QUADRUPOLAR << " " << DEFORMED_WS << " " << NO_SOURCE << " " << NO_POTENTIAL << endl;
    outfile << ELECTRON << " " << NEUTRON << " " << PROTON << " " << DIPROTON << " " << DINEUTRON << " " << DEUTERON << " " << TRITON << " " << " " << HE3 << " " << ALPHA << endl;
    outfile << SDI << " " << SGI << " " << SGI_COSM << " " << MSGI << " " << MSGI_COSM << " " << REALISTIC_INTERACTION << " " << FIT << " " << SKYRME << " " << MINNESOTA << " " << MINNESOTA_COSM << " " << FHT << " " << FHT_COSM << " " << EFT << " " << EFT_COSM << " " << CM_KINETIC_INTERACTION << " " << HCM_INTERACTION << " " << ONE_BODY_KINETIC << " " << ONE_BODY_NUCLEAR << " " << ONE_BODY_COULOMB << endl;
    outfile << IDENTITY << " " << HAMILTONIAN << " " << J_PLUS_MINUS << " " << J_SQUARE << " " << T_SQUARE << " " << CENTER_OF_MASS << " " << L_SQUARE_CENTER_OF_MASS << " " << TIME_REVERSAL_SYMMETRY << " " << A_DAGGER_COUPLED_TO_J << " " << A_DAGGER_CLUSTER_COUPLED_TO_J << " " << CLUSTER_HO_TO_BERGGREN << " " << ELECTROMAGNETIC << " " << BETA << " " << SPECTROSCOPIC_FACTOR << " " << OVERLAP_FUNCTION << " " << DENSITY << " " << CORRELATION_DENSITY << " " << HCM << " " << CM_KINETIC << " " << LPLUS << " " << LMINUS << " " << LZ << " " << A_DAGGER_CM_HO_PLUS_ONE << " " << A_DAGGER_CM_HO_MINUS_ONE << " " << A_DAGGER_CM_HO_ZERO << " " << RMS_RADIUS_PROTON << " " << RMS_RADIUS_NEUTRON << " " << H_POTENTIAL_HO_CC << endl;
    outfile << LAB_HO_TBMES_READ << " " << RELATIVE_BESSEL_TBMES_READ << " " << RELATIVE_HO_TBMES_READ << " " << endl;
    outfile << PROTONS_ONLY << " " << NEUTRONS_ONLY << " " << PROTONS_NEUTRONS << endl;
    outfile << SCATTERING << " " << RADIATIVE_CAPTURE << endl;
    outfile << FULL_STORAGE << " " << ON_THE_FLY << endl;
    outfile << DIRECT_INTEGRATION << " " << HO_EXPANSION << " " << THO_EXPANSION << " " << HF_EXPANSION << " " << PTG_EXPANSION << endl;
    outfile << SPHERICAL << " " << PROLATE << " " << OBLATE << endl;
		
    ifstream infile("test_file");
    file_existence_check ("test_file" , infile);

    enum segment_type segment;
    for (unsigned int i = 0 ; i < 3 ; i++) infile >> segment;

    enum potential_type potential;
    for (unsigned int i = 0 ; i < 19 ; i++) infile >> potential; 

    enum particle_type particle;
    for (unsigned int i = 0 ; i < 9 ; i++) infile >> particle;

    enum interaction_type inter;
    for (unsigned int i = 0 ; i < 19 ; i++) infile >> inter;

    enum operator_type Op;
    for (unsigned int i = 0 ; i < 28 ; i++) infile >> Op;

    enum interaction_read_type inter_read;
    for (unsigned int i = 0 ; i < 3 ; i++) infile >> inter_read;

    enum space_type space;
    for (unsigned int i = 0 ; i < 3 ; i++) infile >> space;

    enum CC_reaction_type CC_reaction;
    for (unsigned int i = 0 ; i < 2 ; i++) infile >> CC_reaction;

    enum storage_type storage;
    for (unsigned int i = 0 ; i < 2 ; i++) infile >> storage;

    enum integration_type integration;
    for (unsigned int i = 0 ; i < 5 ; i++) infile >> integration;

    enum deformation_type deformation;
    for (unsigned int i = 0 ; i < 3 ; i++) infile >> deformation;

    if (!is_it_CM_operator_determine (CM_KINETIC)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (HCM)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (RMS_RADIUS_PROTON)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (RMS_RADIUS_NEUTRON)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (LPLUS)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (LMINUS)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (LZ)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (A_DAGGER_CM_HO_PLUS_ONE)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (A_DAGGER_CM_HO_MINUS_ONE)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 
    if (!is_it_CM_operator_determine (A_DAGGER_CM_HO_ZERO)) error_message_print_abort ("Problem with is_it_CM_operator_determine"); 

    ostringstream os;
    os << ZERO_KPEAK << " " << KPEAK_KMIDDLE << " " << KMIDDLE_KMAX << " " << endl;
    os << COULOMB_POTENTIAL << " " << HO_POTENTIAL << " " << WS << " " << WS_ANALYTIC << " " << COMPLEX_WS << " " << WS_ANALYTIC_PARTIAL_DERIVATIVE << " " << PTG_POTENTIAL << " " << HF << " " << MSDHF << " " << EFFECTIVE_MASS_POTENTIAL << " " << INTERPOLATED_POTENTIAL << " " << COMPLEX_INTERPOLATED_POTENTIAL << " " << KKNN  << " " << SOURCE << " " << DIPOLAR << " " << QUADRUPOLAR << " " << DEFORMED_WS << " " << NO_SOURCE << " " << NO_POTENTIAL << endl;
    os << ELECTRON << " " << NEUTRON << " " << PROTON << " " << TRITON << " " << HE3 << " " << ALPHA << endl;
    os << SDI << " " << SGI << " " << SGI_COSM << " " << MSGI << " " << MSGI_COSM << " " << REALISTIC_INTERACTION << " " << FIT << " " << SKYRME << " " << MINNESOTA << " " << MINNESOTA_COSM << " " << FHT << " " << FHT_COSM << " " << EFT << " " << EFT_COSM << " " << CM_KINETIC_INTERACTION << " " << HCM_INTERACTION << " " << ONE_BODY_KINETIC << " " << ONE_BODY_NUCLEAR << " " << ONE_BODY_COULOMB << endl;
    os << IDENTITY << " " << HAMILTONIAN << " " << J_PLUS_MINUS << " " << J_SQUARE << " " << T_SQUARE << " " << CENTER_OF_MASS << " " << L_SQUARE_CENTER_OF_MASS << " " << TIME_REVERSAL_SYMMETRY << " " << A_DAGGER_COUPLED_TO_J << " " << A_DAGGER_CLUSTER_COUPLED_TO_J << " " << CLUSTER_HO_TO_BERGGREN << " " << ELECTROMAGNETIC << " " << BETA << " " << SPECTROSCOPIC_FACTOR << " " << OVERLAP_FUNCTION << " " << DENSITY << " " << CORRELATION_DENSITY << " " << HCM << " " << CM_KINETIC << " " << LPLUS << " " << LMINUS << " " << LZ << " " << A_DAGGER_CM_HO_PLUS_ONE << " " << A_DAGGER_CM_HO_MINUS_ONE << " " << A_DAGGER_CM_HO_ZERO << " " << RMS_RADIUS_PROTON << " " << RMS_RADIUS_NEUTRON << " " << H_POTENTIAL_HO_CC << endl;
    os << LAB_HO_TBMES_READ << " " << RELATIVE_BESSEL_TBMES_READ << " " << RELATIVE_HO_TBMES_READ << endl;
    os << PROTONS_ONLY << " " << NEUTRONS_ONLY << " " << PROTONS_NEUTRONS << endl;
    os << SCATTERING << " " << RADIATIVE_CAPTURE << endl;
    os << FULL_STORAGE << " " << ON_THE_FLY << endl;
    os << DIRECT_INTEGRATION << " " << HO_EXPANSION << " " << THO_EXPANSION << " " << HF_EXPANSION << " " << PTG_EXPANSION << endl;
    os << SPHERICAL << " " << PROLATE << " " << OBLATE << endl;

    cout << endl << os.str () << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

