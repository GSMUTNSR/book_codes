#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const double mass_modif = 0.1;

    const double particle_mass_for_calc = 1.0;

    const double hbar_omega = 15;

    const double r_HO = 2.0;

    const class HO_class HO_pot(false , mass_modif , particle_mass_for_calc , hbar_omega);

    cout << "HO potential(r_HO = 2) :" << HO_pot(r_HO) << endl << endl << endl;

    const double d = 0.65;

    const double R0 = 5.0;

    const double Vo = 60.0;

    const double Vso = 10.0;

    const double R_ch = 5.5;

    const int Z_charge = 50;

    const int l = 2;
    
    const double j = l+0.5;

    cout << "WS potential and partial derivatives test" << endl;

    const class WS_analytic_class WS_pot(false , d , R0 , Vo , Vso , PROTON , Z_charge , R_ch , l , j);

    const class WS_analytic_class WS_d_plus (false , d + sqrt_precision , R0 , Vo , Vso , PROTON , Z_charge , R_ch , l , j);
    const class WS_analytic_class WS_d_minus(false , d - sqrt_precision , R0 , Vo , Vso , PROTON , Z_charge , R_ch , l , j);

    const class WS_analytic_class WS_R0_plus (false , d , R0 + sqrt_precision , Vo , Vso , PROTON , Z_charge , R_ch , l , j);
    const class WS_analytic_class WS_R0_minus(false , d , R0 - sqrt_precision , Vo , Vso , PROTON , Z_charge , R_ch , l , j);

    const class WS_analytic_class WS_Vo_plus (false , d , R0 , Vo + sqrt_precision , Vso , PROTON , Z_charge , R_ch , l , j);
    const class WS_analytic_class WS_Vo_minus(false , d , R0 , Vo - sqrt_precision , Vso , PROTON , Z_charge , R_ch , l , j);

    const class WS_analytic_class WS_Vso_plus (false , d , R0 , Vo , Vso + sqrt_precision , PROTON , Z_charge , R_ch , l , j);
    const class WS_analytic_class WS_Vso_minus(false , d , R0 , Vo , Vso - sqrt_precision , PROTON , Z_charge , R_ch , l , j);
	
    const class WS_analytic_class WS_R_ch_plus (false , d , R0 , Vo , Vso , PROTON , Z_charge , R_ch + sqrt_precision , l , j);
    const class WS_analytic_class WS_R_ch_minus(false , d , R0 , Vo , Vso , PROTON , Z_charge , R_ch - sqrt_precision , l , j);

    const unsigned int N = 10;
    
    const double rmin = max (R0 - 2*d , 0.0);

    const double rmax = R0 + 2*d;

    const double step_R0_zone = (rmax - rmin)/static_cast<double> (N - 1);

    const double two_sqrt_precision = 2.0*sqrt_precision;
    
    for (unsigned int i = 0 ; i < N ; i++)
      {
	const double r = rmin + i*step_R0_zone;

	const double WSr_d_plus    = WS_d_plus(r)    , WSr_d_minus    = WS_d_minus(r)    , WSr_d_der_app    = (WSr_d_plus    - WSr_d_minus   )/two_sqrt_precision , dWS_over_dd    = WS_pot.d_derivative_calc (r);
	const double WSr_R0_plus   = WS_R0_plus(r)   , WSr_R0_minus   = WS_R0_minus(r)   , WSr_R0_der_app   = (WSr_R0_plus   - WSr_R0_minus  )/two_sqrt_precision , dWS_over_dR0   = WS_pot.R0_derivative_calc (r);
	const double WSr_Vo_plus   = WS_Vo_plus(r)   , WSr_Vo_minus   = WS_Vo_minus(r)   , WSr_Vo_der_app   = (WSr_Vo_plus   - WSr_Vo_minus  )/two_sqrt_precision , dWS_over_dVo   = WS_pot.Vo_derivative_calc (r);
	const double WSr_Vso_plus  = WS_Vso_plus(r)  , WSr_Vso_minus  = WS_Vso_minus(r)  , WSr_Vso_der_app  = (WSr_Vso_plus  - WSr_Vso_minus )/two_sqrt_precision , dWS_over_dVso  = WS_pot.Vso_derivative_calc (r);
	const double WSr_R_ch_plus = WS_R_ch_plus(r) , WSr_R_ch_minus = WS_R_ch_minus(r) , WSr_R_ch_der_app = (WSr_R_ch_plus - WSr_R_ch_minus)/two_sqrt_precision , dWS_over_dR_ch = WS_pot.R_charge_derivative_calc (r);

	cout << "r : " << r << endl;
	
	cout << "dWS/dd app:    " <<  WSr_d_der_app    << " dWS/dd:    " << dWS_over_dd    << " precision : " << inf_norm (WSr_d_der_app    - dWS_over_dd) << endl; 
	cout << "dWS/dR0 app:   " <<  WSr_R0_der_app   << " dWS/dR0:   " << dWS_over_dR0   << " precision : " << inf_norm (WSr_R0_der_app   - dWS_over_dR0) << endl; 
	cout << "dWS/dVo app:   " <<  WSr_Vo_der_app   << " dWS/dVo:   " << dWS_over_dVo   << " precision : " << inf_norm (WSr_Vo_der_app   - dWS_over_dVo) << endl; 
	cout << "dWS/dVso app:  " <<  WSr_Vso_der_app  << " dWS/dVso:  " << dWS_over_dVso  << " precision : " << inf_norm (WSr_Vso_der_app  - dWS_over_dVso) << endl; 
	cout << "dWS/dR_ch app: " <<  WSr_R_ch_der_app << " dWS/dR_ch: " << dWS_over_dR_ch << " precision : " << inf_norm (WSr_R_ch_der_app - dWS_over_dR_ch) << endl; 

	cout << endl;
      }
    
    /*		
		const unsigned int Nt = 40 , Nr = 50 , R = 15;
		const int lmax = 20 , J = 0 , lambda_max = 2*lmax;
		const double r_step = R/static_cast<double> (Nr - 1) , beta_2 = 0.5;

		const class deformed_WS_class WS_def(Nt , Nr , R , PROTON , Z_charge , R_ch , d , R0 , beta_2 , Vo , 0.0 , J , lmax);

		class array<double> t_tab_GL(Nt) , wt_tab_GL(Nt) , r_tab(Nr) , def_WS_tab(Nt , Nr);

		for (unsigned int ir = 0 ; ir < Nr ; ir++) r_tab(ir) = ir*r_step;
		
		Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , t_tab_GL , wt_tab_GL);

		for (unsigned int it = 0 ; it < Nt ; it++)
		{
		const double t = t_tab_GL(it) , sqrt_1mt2 = sqrt (1.0 - t*t) , Y20_term = spherical_harmonics::PYlm (2 , 0 , sqrt_1mt2) , R0_theta = R0*(1.0 + beta_2*Y20_term);
		const class WS_class WSt_nucl(false , d , R0_theta , Vo , 0.0 , PROTON , Z_charge , R_ch , NADA , NADA);

		for (unsigned int ir = 0 ; ir < Nr ; ir++)
		{
		const double r = r_tab(ir);
		def_WS_tab(it , ir) = WSt_nucl(r);
		}
		}

		for (unsigned int ir = 0 ; ir < Nr ; ir++)
		{
		const double r = r_tab(ir);

		if ((r >= rmin) && (r <= rmax))
		{
		for (unsigned int it = 0 ; it < Nt ; it++)
		if (it%6 == 0)
		{
		const double t = t_tab_GL(it);

		double WS_rt_test = 0.0;

		for (int lambda = 0 ; lambda <= lambda_max ; lambda++)
		{
		if (lambda%2 == 0)
		WS_rt_test += WS_def.multipole (lambda , r)*spherical_harmonics::Plm (lambda , 0 , t_tab_GL(it));
		}
						
		cout << "r : " << r << " t : " << t << "   deformed WS (multipole) : " << WS_rt_test << "   (exact) : " << def_WS_tab(it , ir) << "   precision : " << inf_norm (WS_rt_test - def_WS_tab(it , ir)) << endl;
		}
				
		cout << endl;
		}
		}

		const double V0_tab[] = {-96.3 , 77 , 34 , -85 , 51}; 

		const double rho_tab[] = {0.36 , 0.9 , 0.2 , 0.53 , 2.5};

		//const double V0_ls_tab[] = {-8.4 , -10 , 10};
		//const double rho_ls_tab[] = {0.52 , 0.396 , 2.2};

		const double V0_ls_tab[] = {0.0 , 0.0 , 0.0};

		const double rho_ls_tab[] =  {0.0 , 0.0 , 0.0};
    
		const class KKNN_class KKNN_0(false , V0_tab , rho_tab , V0_ls_tab , rho_ls_tab , NEUTRON , 0 , 0 , 0 , 0.5);
		const class KKNN_class KKNN_1(false , V0_tab , rho_tab , V0_ls_tab , rho_ls_tab , NEUTRON , 0 , 0 , 1 , 0.5);

		const unsigned int NN = 200;

		const double R = 10.0;

		const double step = R/NN;
    
		for (unsigned int i = 0 ; i <= NN ; i++)
		{
		const double r = i*step;

		cout << r << " " << KKNN_0(r) << " " << KKNN_1(r) << endl;
		}
    */
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

