#include "../numlib_def/numlib_def.h"

using namespace string_routines;

// The centrifugal barrier is considered as kinetic , and so is not included here.

// Harmonic oscillator potential
// -----------------------------
//  Variables :
// -----------
// r : radius (fm).
// r_over_b : r/b

HO_class::HO_class ()
{
  initialize (false , 0.0 , 0.0 , 0.0);
}

HO_class::HO_class (
		    const bool is_it_electron ,
		    const double mass_modif ,
		    const double particle_mass_for_calc ,
		    const double b_c)
{
  initialize (is_it_electron , mass_modif , particle_mass_for_calc , b_c);
}

HO_class::HO_class (const class HO_class &X)
{
  initialize (X);
}

void HO_class::initialize (
			   const bool is_it_electron ,
			   const double mass_modif ,
			   const double particle_mass_for_calc ,
			   const double b_c)
{
  b = b_c;
  
  kinetic_factor = kinetic_factor_calc (is_it_electron , mass_modif , particle_mass_for_calc);

  hbar_omega = 2.0/(kinetic_factor*b*b);
}

void HO_class::initialize (const class HO_class &X)
{
  hbar_omega = X.hbar_omega;
  b = X.b;
  kinetic_factor = X.kinetic_factor;
}

void HO_class::operator = (const class HO_class &X)
{
  initialize (X);
}


double HO_class::operator () (const double r) const
{
  const double r_over_b = r/b;

  const double HO_r = 0.5*hbar_omega*r_over_b*r_over_b;

  return HO_r;
}


double used_memory_calc (const class HO_class &T)
{
  return sizeof (T)/1000000.0;
}







// Coulomb potential
// -----------------
// Standard notations

Coulomb_potential_class::Coulomb_potential_class ()
{
  initialize (false , NO_PARTICLE , 0 , 0.0);
}

Coulomb_potential_class::Coulomb_potential_class (
						  const bool is_it_relative , 
						  const enum particle_type particle_c ,
						  const int Z_target_c ,
						  const double R_charge_c)
{
  initialize (is_it_relative , particle_c , Z_target_c , R_charge_c);
}

Coulomb_potential_class::Coulomb_potential_class (const class Coulomb_potential_class &X)
{
  initialize (X);
}
  

void Coulomb_potential_class::initialize (
					  const bool is_it_relative , 
					  const enum particle_type particle_c ,
					  const int Z_target_c ,
					  const double R_charge_c)
{
  particle = particle_c;

  Z_target = Z_target_c;

  R_charge = R_charge_c;

  R_charge_four_over_three_sqrt_Pi = 0.752252778063675 * R_charge;

  if (is_it_relative)
    {
      const int A_projectile = A_projectile_determine (particle);

      if (A_projectile != 2) error_message_print_abort ("A relative particle has to have two nucleons in Coulomb_potential_class::initialize ");

      const int Z_projectile = Z_projectile_determine (particle);

      if (Z_projectile <= 1) 
	Cc_Z_target_particle_charge = 0;
      else
	{
	  if (Z_target != 1) error_message_print_abort ("Z_target has to be equal to one with diproton in Coulomb_potential_class::initialize ");
	  
	  Cc_Z_target_particle_charge = Coulomb_constant;
	}
    }
  else
    Cc_Z_target_particle_charge = Coulomb_constant * Z_target * particle_charge_determine (particle);
}

void Coulomb_potential_class::initialize (const class Coulomb_potential_class &X)
{
  particle = X.particle;

  Z_target = X.Z_target;

  R_charge = X.R_charge;

  R_charge_four_over_three_sqrt_Pi = X.R_charge_four_over_three_sqrt_Pi;

  Cc_Z_target_particle_charge = X.Cc_Z_target_particle_charge;
}

void Coulomb_potential_class::operator = (const class Coulomb_potential_class &X)
{
  initialize (X);
}




// Real Coulomb potential of a point charge for a particle
// ------------------------------------------------------ - 
double Coulomb_potential_class::point_potential_calc (const double r) const
{
  if (Z_target == 0) return 0.0;

  const double potential = Cc_Z_target_particle_charge/r;

  return potential;
}

// Real Coulomb potential derivative of a point charge for a particle
// ------------------------------------------------------------------
double Coulomb_potential_class::point_potential_derivative_calc (const double r) const
{
  if (Z_target == 0) return 0.0;

  const double potential_der = -Cc_Z_target_particle_charge/(r*r);

  return potential_der;
}




// Complex Coulomb potential of a point charge for a particle
// ----------------------------------------------------------
complex<double> Coulomb_potential_class::point_potential_calc (const complex<double> &r) const
{
  if (Z_target == 0) return 0.0;

  const complex<double> potential = Cc_Z_target_particle_charge/r;

  return potential;
}

// Complex Coulomb potential derivative of a point charge for a particle
// ---------------------------------------------------------------------
complex<double> Coulomb_potential_class::point_potential_derivative_calc (const complex<double> &r) const
{
  if (Z_target == 0) return 0.0;

  const complex<double> potential_der = -Cc_Z_target_particle_charge/(r*r);

  return potential_der;
}




// Real Coulomb potential of a uniformly-charged sphere for a particle
// ----------------------------------------------------------------- - 
// The density is constant up to R_charge , after which it is zero.
//
double Coulomb_potential_class::uniform_potential_calc (const double r) const
{ 
  if (Z_target == 0) return 0.0;

  const double potential = ((r < R_charge) ? (Cc_Z_target_particle_charge/R_charge * (1.5 - 0.5 * r * r/R_charge/R_charge)) : (Cc_Z_target_particle_charge/r));

  return potential;
}





// Real analytic Coulomb potential of a diffused charge for a particle
// ------------------------------------------------------------------ - 
// The density is proportional to a Gaussian function , so that the Coulomb potential is proportional to erf(r/R_charge_four_over_three_sqrt_Pi)/r.
// R_charge_four_over_three_sqrt_Pi = 4 R_charge/(3 sqrt(Pi)) , so that this potential and the uniformly-charged sphere potential are equal at r=0 .

double Coulomb_potential_class::analytic_potential_calc (const double r) const
{ 
  if (Z_target == 0) return 0.0;

  const double potential = ((r != 0.0) ? (Cc_Z_target_particle_charge * erf (r/R_charge_four_over_three_sqrt_Pi)/r) : (Cc_Z_target_particle_charge * M_2_SQRTPI/R_charge_four_over_three_sqrt_Pi));

  return potential;
}


// Real analytic Coulomb potential derivative of a diffused charge for a particle
// ------------------------------------------------------------------------------ - 
// The density is proportional to a Gaussian function , so that the Coulomb potential is proportional to erf(r/R_charge_four_over_three_sqrt_Pi)/r.
// R_charge_four_over_three_sqrt_Pi = 4 R_charge/(3 sqrt(Pi)) , so that this potential and the uniformly-charged sphere potential are equal at r=0 .
// To calculate the derivative of the Coulomb potential Vc(r) for r real, one calculates Vc (r + 1E-10),
// Hence, as Vc (r + 1E-10) = Vc(r) + i.1E-10.Vc'(r) + O(1E-20), one has Vc'(r) = Im(Vc (r + 1E-10))/(1E-10) up to machine precision.

double Coulomb_potential_class::analytic_potential_derivative_calc (const double r) const
{
  if (Z_target == 0) return 0.0;
  
  const complex<double> rp(r , precision);

  const complex<double> potential_rp = Cc_Z_target_particle_charge * erf (rp/R_charge_four_over_three_sqrt_Pi)/rp;
 
  const double potential_der = imag (potential_rp)/precision;
  
  return potential_der;
}


double used_memory_calc (const class Coulomb_potential_class &T)
{
  return sizeof (T)/1000000.0;
}





// Woods-Saxon potential : 
// -----------------------
// Its unit is MeV.
// The Coulomb potential is here derived from a uniformly charged sphere distribution.
//
// Variables :
// -----------
// r : radius (fm).
// f and df : function f:r-->-1/(1+exp ((r-R0)/d)) and its derivative.
// V_nuclear : central potential WS : Vo.f(r).
// V_spin_orbit : spin-orbit potential <=> 1/r.df/dr.2.two_l_scalar_s.Vso. 
// V_Coulomb : Coulomb potential of uniformly-charged density.

WS_class::WS_class ()
{
  initialize (false , 0.0 , 0.0 , 0.0 , 0.0 , NO_PARTICLE , 0 , 0.0 , 0 , 0.0);
}

WS_class::WS_class (
		    const bool is_it_relative , 
		    const double d_c , 
		    const double R0_c , 
		    const double Vo_c , 
		    const double Vso_c , 
		    const enum particle_type particle_c , 
		    const int Z_charge_c , 
		    const double R_charge_c , 
		    const int l_c , 
		    const double j_c)
{
  initialize (is_it_relative , d_c , R0_c , Vo_c , Vso_c , particle_c , Z_charge_c , R_charge_c , l_c , j_c);
}

WS_class::WS_class (const class WS_class &X) 
{
  initialize (X);
}


void WS_class::initialize (
			   const bool is_it_relative , 
			   const double d_c , 
			   const double R0_c , 
			   const double Vo_c , 
			   const double Vso_c , 
			   const enum particle_type particle_c , 
			   const int Z_charge_c , 
			   const double R_charge_c , 
			   const int l_c , 
			   const double j_c)
{
  d = d_c;
  R0 = R0_c;
  Vo = Vo_c;
  Vso = Vso_c;
  particle = particle_c;
  Z_charge = Z_charge_c;
  R_charge = R_charge_c;
  l = l_c;
  j = j_c;

  const double j_intrinsic = J_intrinsic_projectile_determine (particle);

  two_l_scalar_s = j*(j + 1) - l*(l + 1) - j_intrinsic*(j_intrinsic + 1);

  is_there_spin_orbit = ((Vso != 0.0) && (two_l_scalar_s != 0.0));

  if (particle == ELECTRON) error_message_print_abort ("No WS potential for electron in WS_class::initialize (1)");

  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
}

void WS_class::initialize (const class WS_class &X)
{
  Vo = X.Vo; 
  Vso = X.Vso;
  l = X.l; 
  j = X.j;
  two_l_scalar_s = X.two_l_scalar_s;  
  is_there_spin_orbit = X.is_there_spin_orbit;
  d = X.d; 
  R0 = X.R0; 
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  particle = X.particle;

  if (particle == ELECTRON) error_message_print_abort ("No WS potential for electron in WS_class::initialize (2)");
  
  Coulomb_potential.initialize (X.Coulomb_potential);
}

void WS_class::operator = (const class WS_class &X)
{
  initialize (X);
}



double WS_class::operator () (const double r) const
{                 
  const double exp_r_minus_R0_over_d = exp ((r - R0)/d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double V_nuclear = Vo*f;
  
  const double V_spin_orbit = (two_l_scalar_s != 0.0) ? (-2.0*two_l_scalar_s*Vso*df/r) : (0.0);

  const double V_Coulomb = Coulomb_potential.uniform_potential_calc (r);

  const double V = V_nuclear + V_spin_orbit + V_Coulomb;
  
  return V;
}

double used_memory_calc (const class WS_class &T)
{
  return sizeof (T)/1000000.0;
}





// Analytic Woods-Saxon potential : 
// --------------------------------
// Its unit is MeV.
// The Coulomb potential is here analytical and derived from a Gaussian charge distribution.
//
// Variables :
// -----------
// r : radius (fm).
// f and df : function f:r-->-1/(1+exp ((r-R0)/d)) and its derivative.
// V_nuclear : central potential WS : Vo.f(r).
// V_spin_orbit : spin-orbit potential <=> 1/r.df/dr.2.two_l_scalar_s.Vso. 
// V_Coulomb : analytical Coulomb potential.
// four_l_scalar_s : 2.(j(j+1) - l(l+1) - 0.75)
// two_f_plus_one = 2f + 1
// Cc_Z : Coulomb_constant.Z_charge
// four_over_three_sqrt_Pi : 4/(3 sqrt (Pi))
// r_over_R_charge_normed : r/(4 R_charge/ (3 sqrt (Pi))

WS_analytic_class::WS_analytic_class ()
{
  initialize (false , 0.0 , 0.0 , 0.0 , 0.0 , NO_PARTICLE , 0 , 0.0 , 0 , 0.0);
}

WS_analytic_class::WS_analytic_class (
				      const bool is_it_relative , 
				      const double d_c , 
				      const double R0_c , 
				      const double Vo_c , 
				      const double Vso_c , 
				      const enum particle_type particle_c , 
				      const int Z_charge_c , 
				      const double R_charge_c , 
				      const int l_c , 
				      const double j_c)
{
  initialize (is_it_relative , d_c , R0_c , Vo_c , Vso_c , particle_c , Z_charge_c , R_charge_c , l_c , j_c);
}

WS_analytic_class::WS_analytic_class (const class WS_analytic_class &X) 
{
  initialize (X);
}

void WS_analytic_class::initialize (
				    const bool is_it_relative , 
				    const double d_c , 
				    const double R0_c , 
				    const double Vo_c , 
				    const double Vso_c , 
				    const enum particle_type particle_c , 
				    const int Z_charge_c , 
				    const double R_charge_c , 
				    const int l_c , 
				    const double j_c)
{
  d = d_c;
  R0 = R0_c;
  Vo = Vo_c;
  Vso = Vso_c;
  particle = particle_c;
  Z_charge = Z_charge_c;
  R_charge = R_charge_c;
  l = l_c;
  j = j_c;

  const double j_intrinsic = J_intrinsic_projectile_determine (particle);
  
  two_l_scalar_s = j*(j + 1) - l*(l + 1) - j_intrinsic*(j_intrinsic + 1);

  is_there_spin_orbit = ((Vso != 0.0) && (two_l_scalar_s != 0.0));

  if (particle == ELECTRON) error_message_print_abort ("No WS analytic potential for electron in WS_analytic_class::initialize (1)");

  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
}

void WS_analytic_class::initialize (const class WS_analytic_class &X)
{
  Vo = X.Vo; 
  Vso = X.Vso;
  l = X.l; 
  j = X.j;
  two_l_scalar_s = X.two_l_scalar_s;  
  is_there_spin_orbit = X.is_there_spin_orbit;
  d = X.d; 
  R0 = X.R0; 
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  particle = X.particle;

  if (particle == ELECTRON) error_message_print_abort ("No WS analytic potential for electron in WS_analytic_class::initialize (2)");

  Coulomb_potential.initialize (X.Coulomb_potential);
}

void WS_analytic_class::operator = (const class WS_analytic_class &X)
{
  initialize (X);
}



double WS_analytic_class::operator () (const double r) const
{
  const double exp_r_minus_R0_over_d = exp ((r - R0)/d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double V_nuclear = Vo*f;

  const double V_Coulomb = Coulomb_potential.analytic_potential_calc (r);

  const double V_spin_orbit = (is_there_spin_orbit) ? (-2.0*two_l_scalar_s*Vso*df/r) : (0.0);

  const double V = V_nuclear + V_spin_orbit + V_Coulomb;

  return V;
}





double WS_analytic_class::d_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double two_f_plus_one = 2.0*f + 1.0;

  const double four_l_scalar_s =  2.0*two_l_scalar_s;

  const double Vso_four_l_scalar_s_over_rd = (is_there_spin_orbit) ? (Vso*four_l_scalar_s/(r*d)) : (0.0);

  const double dWS_over_dd = df*(-Vo*r_minus_R0_over_d + Vso_four_l_scalar_s_over_rd*(1.0 - r_minus_R0_over_d*two_f_plus_one));

  return dWS_over_dd;
}




double WS_analytic_class::R0_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double two_f_plus_one = 2.0*f + 1.0;

  const double four_l_scalar_s =  2.0*two_l_scalar_s;

  const double Vso_four_l_scalar_s_over_rd = (is_there_spin_orbit) ? (Vso*four_l_scalar_s/(r*d)) : (0.0);

  const double dWS_over_dR0 = -df*(Vo + Vso_four_l_scalar_s_over_rd*two_f_plus_one);

  return dWS_over_dR0;
}




double WS_analytic_class::Vo_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  return f;
}




double WS_analytic_class::Vso_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double four_l_scalar_s = 2.0*two_l_scalar_s;

  const double dWS_over_dVso = -four_l_scalar_s*df/r;

  return dWS_over_dVso;
}



double WS_analytic_class::R_charge_derivative_calc (const double r) const
{
  const int particle_charge = particle_charge_determine (particle);

  const double Cc_Z_target_particle_charge = Coulomb_constant * Z_charge * particle_charge;

  const double Cc_Z_two_over_sqrt_Pi = M_2_SQRTPI*Cc_Z_target_particle_charge;

  const double four_over_three_sqrt_Pi = 0.752252778063675;

  const double r_over_R_charge_normed = r/(four_over_three_sqrt_Pi*R_charge);

  const double dWS_over_dR_charge = -Cc_Z_two_over_sqrt_Pi*exp (-r_over_R_charge_normed*r_over_R_charge_normed)/(four_over_three_sqrt_Pi*R_charge*R_charge);

  return dWS_over_dR_charge;
}



double WS_analytic_class::derivative_calc (const enum FHT_EFT_parameter_type WS_parameter , const double r) const
{
  switch (WS_parameter)
    {
    case CORE_D_PROTON:        return d_derivative_calc   (r);
    case CORE_R0_PROTON:       return R0_derivative_calc  (r);
    case CORE_VO_PROTON:       return Vo_derivative_calc  (r);
    case CORE_VSO_PROTON:      return Vso_derivative_calc (r);

    case CORE_R_CHARGE_PROTON: return R_charge_derivative_calc (r);

    case CORE_D_NEUTRON:       return d_derivative_calc   (r);
    case CORE_R0_NEUTRON:      return R0_derivative_calc  (r);
    case CORE_VO_NEUTRON:      return Vo_derivative_calc  (r);
    case CORE_VSO_NEUTRON:     return Vso_derivative_calc (r);

    default: error_message_print_abort ("Only WS parameters in WS_analytic_class::derivative_calc.");
    }	

  return NADA;
}



double WS_analytic_class::derivative_calc (const enum WS_parameter_type WS_parameter , const double r) const
{
  switch (WS_parameter)
    {
    case D_PROTON:        return d_derivative_calc   (r);
    case R0_PROTON:       return R0_derivative_calc  (r);
    case VO_PROTON:       return Vo_derivative_calc  (r);
    case VSO_PROTON:      return Vso_derivative_calc (r);

    case R_CHARGE_PROTON: return R_charge_derivative_calc (r);

    case D_NEUTRON:       return d_derivative_calc   (r);
    case R0_NEUTRON:      return R0_derivative_calc  (r);
    case VO_NEUTRON:      return Vo_derivative_calc  (r);
    case VSO_NEUTRON:     return Vso_derivative_calc (r);

    default: error_message_print_abort ("Only WS parameters in WS_analytic_class::derivative_calc.");
    }	

  return NADA;
}

double used_memory_calc (const class WS_analytic_class &T)
{
  return sizeof (T)/1000000.0;
}




// Complex Woods-Saxon potential : 
// -----------------------------
//  Its unit is MeV.
//
// Variables :
// -----------
// r : radius (fm).
// f and df : function f:r-->-1/(1+exp ((r-R0)/d) and its derivative.
// V_nuclear : central potential WS : Vo.f(r).
// V_spin_orbit : spin-orbit potential <=> 1/r.df/dr.2.two_l_scalar_s.Vso. 
// V_Coulomb : Coulomb potential of uniformly charged sphere.

WS_complex_class::WS_complex_class ()
{
  initialize (false , 0.0 , 0.0 , 0.0 , 0.0 , NO_PARTICLE , 0 , 0.0 , 0 , 0.0);
}

WS_complex_class::WS_complex_class (
				    const bool is_it_relative , 
				    const double d_c , 
				    const double R0_c , 
				    const complex<double> &Vo_c , 
				    const complex<double> &Vso_c , 
				    const enum particle_type particle_c , 
				    const int Z_charge_c , 
				    const double R_charge_c , 
				    const int l_c , 
				    const double j_c)
{
  initialize (is_it_relative , d_c , R0_c , Vo_c , Vso_c , particle_c , Z_charge_c , R_charge_c , l_c , j_c);
}

WS_complex_class::WS_complex_class (const class WS_complex_class &X) 
{
  initialize (X);
}

void WS_complex_class::initialize (
				   const bool is_it_relative , 
				   const double d_c , 
				   const double R0_c , 
				   const complex<double> &Vo_c , 
				   const complex<double> &Vso_c , 
				   const enum particle_type particle_c , 
				   const int Z_charge_c , 
				   const double R_charge_c , 
				   const int l_c , 
				   const double j_c)
{
  d = d_c;
  R0 = R0_c;
  Vo = Vo_c;
  Vso = ((particle_c == PROTON) || (particle_c == NEUTRON)) ? (Vso_c) : (0.0);
  particle = particle_c;
  Z_charge = Z_charge_c;
  R_charge = R_charge_c;
  l = l_c;
  j = j_c;
 
  const double j_intrinsic = J_intrinsic_projectile_determine (particle);
  
  two_l_scalar_s = j*(j + 1) - l*(l + 1) - j_intrinsic*(j_intrinsic + 1);

  is_there_spin_orbit = ((Vso != 0.0) && (two_l_scalar_s != 0.0));

  if (particle == ELECTRON) error_message_print_abort ("No complex WS potential for electron in WS_complex_class::initialize (1)");
  
  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
}

void WS_complex_class::initialize (const class WS_complex_class &X)
{
  Vo = X.Vo; 
  Vso = X.Vso;
  l = X.l; 
  j = X.j;
  two_l_scalar_s = X.two_l_scalar_s;  
  is_there_spin_orbit = X.is_there_spin_orbit;
  d = X.d; 
  R0 = X.R0; 
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  particle = X.particle;

  if (particle == ELECTRON) error_message_print_abort ("No complex WS potential for electron in WS_complex_class::initialize (2)");

  Coulomb_potential.initialize (X.Coulomb_potential);
}

void WS_complex_class::operator = (const class WS_complex_class &X)
{
  initialize (X);
}


complex<double> WS_complex_class::operator () (const double r) const
{                 
  const double exp_r_minus_R0_over_d = exp ((r - R0)/d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const complex<double> V_nuclear = Vo*f;

  const complex<double> V_spin_orbit = (two_l_scalar_s != 0.0) ? (-2.0*two_l_scalar_s*Vso*df/r) : (0.0);

  const complex<double> V_Coulomb = Coulomb_potential.uniform_potential_calc (r);

  const complex<double> V = V_nuclear + V_spin_orbit + V_Coulomb;

  return V;
}


double used_memory_calc (const class WS_complex_class &T)
{
  return sizeof (T)/1000000.0;
}





// Complex Woods-Saxon analytic potential : 
// ----------------------------------------
//  Its unit is MeV.
//
// Variables :
// -----------
// r : radius (fm).
// f and df : function f:r-->-1/(1+exp ((r-R0)/d) and its derivative.
// V_nuclear : central potential WS : Vo.f(r).
// V_spin_orbit : spin-orbit potential <=> 1/r.df/dr.2.two_l_scalar_s.Vso. 
// V_Coulomb : Coulomb analytic potential 

WS_analytic_complex_class::WS_analytic_complex_class ()
{
  initialize (false , 0.0 , 0.0 , 0.0 , 0.0 , NO_PARTICLE , 0 , 0.0 , 0 , 0.0);
}

WS_analytic_complex_class::WS_analytic_complex_class (
						      const bool is_it_relative , 
						      const double d_c , 
						      const double R0_c , 
						      const complex<double> &Vo_c , 
						      const complex<double> &Vso_c , 
						      const enum particle_type particle_c , 
						      const int Z_charge_c , 
						      const double R_charge_c , 
						      const int l_c , 
						      const double j_c)
{
  initialize (is_it_relative , d_c , R0_c , Vo_c , Vso_c , particle_c , Z_charge_c , R_charge_c , l_c , j_c);
}


WS_analytic_complex_class::WS_analytic_complex_class (const class WS_analytic_complex_class &X)
{
  initialize (X);
}

void WS_analytic_complex_class::initialize (
					    const bool is_it_relative , 
					    const double d_c , 
					    const double R0_c , 
					    const complex<double> &Vo_c , 
					    const complex<double> &Vso_c , 
					    const enum particle_type particle_c , 
					    const int Z_charge_c , 
					    const double R_charge_c , 
					    const int l_c , 
					    const double j_c)
{
  d = d_c;
  R0 = R0_c;
  Vo = Vo_c;
  Vso = ((particle_c == PROTON) || (particle_c == NEUTRON)) ? (Vso_c) : (0.0);
  particle = particle_c;
  Z_charge = Z_charge_c;
  R_charge = R_charge_c;
  l = l_c;
  j = j_c;

  const double j_intrinsic = J_intrinsic_projectile_determine (particle);

  two_l_scalar_s = j*(j + 1) - l*(l + 1) - j_intrinsic*(j_intrinsic + 1);

  is_there_spin_orbit = ((Vso != 0.0) && (two_l_scalar_s != 0.0));

  if (particle == ELECTRON) error_message_print_abort ("No complex analytic WS potential for electron in WS_analytic_complex_class::initialize (1)");
  
  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
}

void WS_analytic_complex_class::initialize (const class WS_analytic_complex_class &X)
{
  Vo = X.Vo; 
  Vso = X.Vso;
  l = X.l; 
  j = X.j;
  two_l_scalar_s = X.two_l_scalar_s;  
  is_there_spin_orbit = X.is_there_spin_orbit;
  d = X.d; 
  R0 = X.R0; 
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  particle = X.particle;

  if (particle == ELECTRON) error_message_print_abort ("No complex analytic WS potential for electron in WS_analytic_complex_class::initialize (2)");
  
  Coulomb_potential.initialize (X.Coulomb_potential);
}

void WS_analytic_complex_class::operator = (const class WS_analytic_complex_class &X)
{
  initialize (X);
}



complex<double> WS_analytic_complex_class::operator () (const double r) const
{
  const double exp_r_minus_R0_over_d = exp ((r - R0)/d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const complex<double> V_nuclear = Vo*f;

  const complex<double> V_Coulomb = Coulomb_potential.analytic_potential_calc (r);

  const complex<double> V_spin_orbit = (two_l_scalar_s != 0.0) ? (-2.0*two_l_scalar_s*Vso*df/r) : (0.0);

  const complex<double> V = V_nuclear + V_spin_orbit + V_Coulomb;

  return V;
}





complex<double> WS_analytic_complex_class::d_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double two_f_plus_one = 2.0*f + 1.0;

  const double four_l_scalar_s =  2.0*two_l_scalar_s;

  const complex<double> Vso_four_l_scalar_s_over_rd = (is_there_spin_orbit) ? (Vso*four_l_scalar_s/(r*d)) : (0.0);

  const complex<double> dWS_over_dd = df*(-Vo*r_minus_R0_over_d + Vso_four_l_scalar_s_over_rd*(1.0 - r_minus_R0_over_d*two_f_plus_one));

  return dWS_over_dd;
}




complex<double> WS_analytic_complex_class::R0_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double two_f_plus_one = 2.0*f + 1.0;

  const double four_l_scalar_s =  2.0*two_l_scalar_s;

  const complex<double> Vso_four_l_scalar_s_over_rd = (is_there_spin_orbit) ? (Vso*four_l_scalar_s/(r*d)) : (0.0);

  const complex<double> dWS_over_dR0 = -df*(Vo + Vso_four_l_scalar_s_over_rd*two_f_plus_one);

  return dWS_over_dR0;
}




double WS_analytic_complex_class::Vo_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  return f;
}




double WS_analytic_complex_class::Vso_derivative_calc (const double r) const
{
  const double r_minus_R0_over_d = (r - R0)/d;

  const double exp_r_minus_R0_over_d = exp (r_minus_R0_over_d);

  const double f = -1.0/(1.0 + exp_r_minus_R0_over_d);

  const double df = exp_r_minus_R0_over_d*f*f/d;

  const double four_l_scalar_s = 2.0*two_l_scalar_s;

  const double dWS_over_dVso = -four_l_scalar_s*df/r;

  return dWS_over_dVso;
}



double WS_analytic_complex_class::R_charge_derivative_calc (const double r) const
{
  const int particle_charge = particle_charge_determine (particle);

  const double Cc_Z_target_particle_charge = Coulomb_constant * Z_charge * particle_charge;

  const double Cc_Z_two_over_sqrt_Pi = M_2_SQRTPI*Cc_Z_target_particle_charge;

  const double four_over_three_sqrt_Pi = 0.752252778063675;

  const double r_over_R_charge_normed = r/(four_over_three_sqrt_Pi*R_charge);

  const double dWS_over_dR_charge = -Cc_Z_two_over_sqrt_Pi*exp (-r_over_R_charge_normed*r_over_R_charge_normed)/(four_over_three_sqrt_Pi*R_charge*R_charge);

  return dWS_over_dR_charge;
}



complex<double> WS_analytic_complex_class::derivative_calc (const enum FHT_EFT_parameter_type WS_parameter , const double r) const
{
  switch (WS_parameter)
    {
    case CORE_D_PROTON:        return d_derivative_calc   (r);
    case CORE_R0_PROTON:       return R0_derivative_calc  (r);
    case CORE_VO_PROTON:       return Vo_derivative_calc  (r);
    case CORE_VSO_PROTON:      return Vso_derivative_calc (r);

    case CORE_R_CHARGE_PROTON: return R_charge_derivative_calc (r);

    case CORE_D_NEUTRON:       return d_derivative_calc   (r);
    case CORE_R0_NEUTRON:      return R0_derivative_calc  (r);
    case CORE_VO_NEUTRON:      return Vo_derivative_calc  (r);
    case CORE_VSO_NEUTRON:     return Vso_derivative_calc (r);

    default: error_message_print_abort ("Only WS parameters in WS_analytic_complex_class::derivative_calc.");
    }	

  return NADA;
}




complex<double> WS_analytic_complex_class::derivative_calc (const enum WS_parameter_type WS_parameter , const double r) const
{
  switch (WS_parameter)
    {
    case D_PROTON:        return d_derivative_calc   (r);
    case R0_PROTON:       return R0_derivative_calc  (r);
    case VO_PROTON:       return Vo_derivative_calc  (r);
    case VSO_PROTON:      return Vso_derivative_calc (r);

    case R_CHARGE_PROTON: return R_charge_derivative_calc (r);

    case D_NEUTRON:       return d_derivative_calc   (r);
    case R0_NEUTRON:      return R0_derivative_calc  (r);
    case VO_NEUTRON:      return Vo_derivative_calc  (r);
    case VSO_NEUTRON:     return Vso_derivative_calc (r);

    default: error_message_print_abort ("Only WS parameters in WS_analytic_complex_class::derivative_calc.");
    }	

  return NADA;
}

double used_memory_calc (const class WS_analytic_complex_class &T)
{
  return sizeof (T)/1000000.0;
}






// KKNN potential
// --------------
//  Its unit is MeV.
//
// Variables :
// -----------
// Zc: charge of alpha core
// r : radius (fm).
// r2 : r^2
// Vcentral_12 : l-independent central part
// Vcentral_345 : l-dependent central part
// Vcentral : central part
// Vls_0 : l-independent spin-orbit part
// Vls_13 : l-dependent spin-orbit part
// Vls : spin-orbit part
// Vn : nuclear potential
// Vc: Coulomb potential

KKNN_class::KKNN_class ()
{
  V0_0 = -96.3;
  V0_1 = 77;
  V0_2 = 34;
  V0_3 = -85;
  V0_4 = 51;

  rho_0 = 0.36;
  rho_1 = 0.9;
  rho_2 = 0.2;
  rho_3 = 0.53;
  rho_4 = 2.5;

  V0_ls_0 = -8.4;
  V0_ls_1 = -10;
  V0_ls_2 = 10;
  
  rho_ls_0 = 0.52;
  rho_ls_1 = 0.396;
  rho_ls_2 = 2.2;
}

KKNN_class::KKNN_class (
			const bool is_it_relative , 
			const double V0_tab[] , 
			const double rho_tab[] , 
			const double V0_ls_tab[] , 
			const double rho_ls_tab[] , 
			const enum particle_type particle_c , 
			const int Z_charge_c , 
			const double R_charge_c , 
			const int l_c , 
			const double j_c)
{
  initialize (is_it_relative , V0_tab , rho_tab , V0_ls_tab , rho_ls_tab , particle_c , Z_charge_c , R_charge_c , l_c , j_c);
}

KKNN_class::KKNN_class (const class KKNN_class &X)
{
  initialize (X);
}

void KKNN_class::initialize (
			     const bool is_it_relative , 
			     const double V0_tab[] , 
			     const double rho_tab[] , 
			     const double V0_ls_tab[] , 
			     const double rho_ls_tab[] , 
			     const enum particle_type particle_c , 
			     const int Z_charge_c , 
			     const double R_charge_c , 
			     const int l_c , 
			     const double j_c)
{
  l = l_c;
  j = j_c;
  
  V0_0 = V0_tab[0]; 
  V0_1 = V0_tab[1]; 
  V0_2 = V0_tab[2]; 
  V0_3 = V0_tab[3]; 
  V0_4 = V0_tab[4];
  
  rho_0 = rho_tab[0]; 
  rho_1 = rho_tab[1]; 
  rho_2 = rho_tab[2]; 
  rho_3 = rho_tab[3]; 
  rho_4 = rho_tab[4];
  
  V0_ls_0 = V0_ls_tab[0]; 
  V0_ls_1 = V0_ls_tab[1]; 
  V0_ls_2 = V0_ls_tab[2];
  
  rho_ls_0 = rho_ls_tab[0]; 
  rho_ls_1 = rho_ls_tab[1]; 
  rho_ls_2 = rho_ls_tab[2];
  
  particle = particle_c; 
  Z_charge = Z_charge_c; 
  R_charge = R_charge_c;
  
  minus_one_pow_l = minus_one_pow (l); 

  l_dependent_factor = 1.0 - 0.3*minus_one_pow (l); 

  const double j_intrinsic = J_intrinsic_projectile_determine (particle);
  
  two_l_scalar_s = j*(j + 1) - l*(l + 1) - j_intrinsic*(j_intrinsic + 1);

  is_there_spin_orbit = (((V0_ls_0 != 0.0) || (V0_ls_1 != 0.0) || (V0_ls_2 != 0.0)) && (two_l_scalar_s != 0.0));

  if (particle == ELECTRON) error_message_print_abort ("No KKNN potential for electron in KKNN_class::initialize (1)");
  
  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
}



void KKNN_class::initialize (const class KKNN_class &X)
{
  l = X.l; 
  j = X.j; 

  V0_2 = X.V0_2;
  V0_0 = X.V0_0; 
  V0_1 = X.V0_1; 
  V0_2 = X.V0_2; 
  V0_3 = X.V0_3; 
  V0_4 = X.V0_4; 

  rho_0 = X.rho_0; 
  rho_1 = X.rho_1; 
  rho_2 = X.rho_2; 
  rho_3 = X.rho_3; 
  rho_4 = X.rho_4; 

  V0_ls_0 = X.V0_ls_0; 
  V0_ls_1 = X.V0_ls_1; 
  V0_ls_2 = X.V0_ls_2;       

  rho_ls_0 = X.rho_ls_0; 
  rho_ls_1 = X.rho_ls_1; 
  rho_ls_2 = X.rho_ls_2;    

  particle = X.particle; 

  Z_charge = X.Z_charge; 

  R_charge = X.R_charge;                      

  minus_one_pow_l = X.minus_one_pow_l; 

  l_dependent_factor = X.l_dependent_factor; 

  two_l_scalar_s = X.two_l_scalar_s;

  is_there_spin_orbit = X.is_there_spin_orbit;

  if (particle == ELECTRON) error_message_print_abort ("No KKNN potential for electron in KKNN_class::initialize (2)");
  
  Coulomb_potential.initialize (X.Coulomb_potential);
}

void KKNN_class::operator = (const class KKNN_class &X)
{
  initialize (X);
}

double KKNN_class::get_V0 (const unsigned int index) const
{
  switch (index)
    {
    case 0: return V0_0;
    case 1: return V0_1;
    case 2: return V0_2;
    case 3: return V0_3;
    case 4: return V0_4;
    default: abort_all ();
    }
  
  return NADA;
}

double KKNN_class::get_rho (const unsigned int index) const
{
  switch (index)
    {
    case 0: return rho_0;
    case 1: return rho_1;
    case 2: return rho_2;
    case 3: return rho_3;
    case 4: return rho_4;
    default: abort_all ();
    }
  
  return NADA;
}
  
double KKNN_class::get_V0_ls (const unsigned int index) const
{
  switch (index)
    {
    case 0: return V0_ls_0;
    case 1: return V0_ls_1;
    case 2: return V0_ls_2;
    default: abort_all ();
    }
  
  return NADA;
}

double KKNN_class::get_rho_ls (const unsigned int index) const
{
  switch (index)
    {
    case 0: return rho_ls_0;
    case 1: return rho_ls_1;
    case 2: return rho_ls_2;
    default: abort_all ();
    }
  
  return NADA;
}
  
double KKNN_class::operator () (const double r) const
{
  const double r2 = r*r;

  const double Vcentral_01_term = V0_0*exp (-rho_0*r2) + V0_1*exp (-rho_1*r2);
  const double Vcentral_234_term = V0_2*exp (-rho_2*r2) + V0_3*exp (-rho_3*r2) + V0_4*exp (-rho_4*r2);

  const double V0_ls_0_term = V0_ls_0*exp (-rho_ls_0*r2);
  const double V0_ls_12_term = V0_ls_1*exp (-rho_ls_1*r2) + V0_ls_2*exp (-rho_ls_2*r2);

  const double Vcentral = Vcentral_01_term + minus_one_pow_l*Vcentral_234_term ;
  
  const double V0_ls = two_l_scalar_s*(V0_ls_0_term + l_dependent_factor*V0_ls_12_term);
  
  const double V_nuclear = Vcentral + V0_ls;
  
  const double V_Coulomb = Coulomb_potential.analytic_potential_calc (r);

  const double V = V_nuclear + V_Coulomb;

  return V;
}

double used_memory_calc (const class KKNN_class &T)
{
  return sizeof (T)/1000000.0;
}





// PTG class constructor and destructor
// ------------------------------------

PTG_class::PTG_class ()
{
  initialize (0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0);
}

PTG_class::PTG_class (
		      const double kinetic_factor_c , 
		      const double l_c , 
		      const double Lambda_c , 
		      const double s_c , 
		      const double nu_c , 
		      const double a_c) 
{
  initialize (kinetic_factor_c , l_c , Lambda_c , s_c , nu_c , a_c);
}

PTG_class::PTG_class (const class PTG_class &X)
{
  initialize (X);
}


void PTG_class::initialize (
			    const double kinetic_factor_c , 
			    const double l_c , 
			    const double Lambda_c , 
			    const double s_c , 
			    const double nu_c , 
			    const double a_c)
{
  kinetic_factor = kinetic_factor_c; 

  Lambda = Lambda_c; 

  s = s_c; 

  nu = nu_c; 

  l = l_c; 

  a = a_c;
  
  s_square_over_kinetic_factor = s*s/kinetic_factor; 

  Lambda2 = Lambda*Lambda; 

  Lambda2_minus_one = Lambda*Lambda - 1.0; 

  sqrt_abs_Lambda2_minus_one = sqrt (abs (Lambda*Lambda - 1.0));
  
  Lambda2_s = Lambda*Lambda*s; 
 
  nu_nu_plus_one = nu*(nu + 1.0);
  
  two_a = 2.0*a; 

  one_minus_a = 1.0 - a; 

  five_one_minus_a = 5.0*(1.0 - a); 

  three_two_minus_Lambda2 = 3.0*(2.0 - Lambda*Lambda); 

  a_four_minus_three_Lambda2 = a*(4.0 - 3.0*Lambda*Lambda);
  
  seven_minus_Lambda2 = 7.0 - Lambda*Lambda; 

  five_Lambda2_minus_one = 5.0*(Lambda*Lambda - 1.0); 

  Lambda2_minus_one_over_four = (Lambda*Lambda - 1.0)*0.25; 

  llp1 = l*(l+1.0);
  
  V_cl_zero = llp1*(Lambda*Lambda - 2.0)/3.0; 

  two_a_s_kinetic_factor = 2.0*a*s*kinetic_factor;

  s_over_one_minus_a = s/one_minus_a;
  
  Lambda2_one_minus_a = Lambda2*one_minus_a;
}


void PTG_class::initialize (const class PTG_class &X)
{
  kinetic_factor = X.kinetic_factor; 

  Lambda = X.Lambda; 

  s = X.s; 

  nu = X.nu; 

  l = X.l; 

  a = X.a; 

  s_square_over_kinetic_factor = X.s_square_over_kinetic_factor; 

  Lambda2 = X.Lambda2; 

  Lambda2_minus_one = X.Lambda2_minus_one; 

  sqrt_abs_Lambda2_minus_one = X.sqrt_abs_Lambda2_minus_one; 

  Lambda2_s = X.Lambda2_s; 

  nu_nu_plus_one = X.nu_nu_plus_one; 

  two_a = X.two_a; 

  one_minus_a = X.one_minus_a; 

  five_one_minus_a = X.five_one_minus_a; 

  three_two_minus_Lambda2 = X.three_two_minus_Lambda2; 

  a_four_minus_three_Lambda2 = X.a_four_minus_three_Lambda2; 

  seven_minus_Lambda2 = X.seven_minus_Lambda2; 

  five_Lambda2_minus_one = X.five_Lambda2_minus_one; 

  Lambda2_minus_one_over_four = X.Lambda2_minus_one_over_four; 

  V_cl_zero = X.V_cl_zero; 

  llp1 = X.llp1;

  two_a_s_kinetic_factor = X.two_a_s_kinetic_factor;
  
  s_over_one_minus_a = X.s_over_one_minus_a;
  
  Lambda2_one_minus_a = X.Lambda2_one_minus_a;
}


void PTG_class::operator = (const class PTG_class &X)
{
  initialize (X);
}


// Calculation of Lambda^2.s.r(y) in the Ginocchio formula
// -------------------------------------------------------
// If Lambda^2 >= 1 , Lambda^2.s.r(y) = atanh(y) + sqrt[Lambda^2-1].atan(sqrt[Lambda^2-1].y).
// If Lambda^2 <= 1 , Lambda^2.s.r(y) = atanh(y) - sqrt[1-Lambda^2].atanh(sqrt[1-Lambda^2].y)
//
// Variables
// ---------
// y : Ginocchio variable.

double PTG_class::Lambda2_sr_function (const double y) const
{
  if (Lambda2 >= 1.0) 
    return atanh (y) + sqrt_abs_Lambda2_minus_one*atan (sqrt_abs_Lambda2_minus_one*y);
  else 
    return atanh (y) - sqrt_abs_Lambda2_minus_one*atanh (sqrt_abs_Lambda2_minus_one*y);
}














// Calculation of de y(r) real with r real for PTG :
// -------------------------------------------------
// 
// If r=0 , y=0 is returned.
//
// If Lambda^2 >= 1 , Lambda^2.s.r(y) = atanh(y) + sqrt[Lambda^2-1].atan(sqrt[Lambda^2-1].y).
// If Lambda^2 <= 1 , Lambda^2.s.r(y) = atanh(y) - sqrt[1-Lambda^2].atanh(sqrt[1-Lambda^2].y)
//
//
// One has y in [y_debut:y_end] , with y_debut = max (tanh (Lambda2_sr - sqrt[Lambda^2-1].atan (sqrt[Lambda^2-1])) , 0) , y_end = tanh (Lambda2_sr) for Lambda^2 > 1
//                                    y_debut = tanh (Lambda2_sr) , y_end = tanh (Lambda2_sr + sqrt[1-Lambda^2].atanh (sqrt[1-Lambda^2])) , Lambda^2 <= 1
//
// If y_debut > 0.99 , y~1 , so 1 is returned as the iterative method for y~1 will be used afterwards.
// 
// If y_debut > 0.5 , y_debut (Lambda^2 > 1) or y_end (Lambda^2 <= 1) is taken as starting point of the Newton method.
// If not , one takes sr as starting point (0.99 if sr > 0.99). 
// Indeed , y ~ y_debut (Lambda^2 > 1) or y ~ y_end (Lambda^2 <= 1) for y ~ 1 up to (1-y)^2 , 
// and y ~ sr for y ~ 0 up to y^3.
//
// This way , the starting point is almost exact if y is close to 0 or 1 , thus giving quick convergence.
// Otherwise , convergence is quick also as y'(r) varies quickly for y ~ 0.5 and large |Lambda - 1|.
// For small |Lambda - 1| , the starting point is very good as y_debut = y_end = y(r) for Lambda = 1 (Poschl-Teller potential).
//
// If y is not in ]0:1[ during the Newton method , one uses bisection instead in [y_debut:y_end].
//
// Variables :
// -----------
// y_debut , y_end : y is in [y_debut:y_end] (see above). During bisection , y_debut-y_end -> 0.
// y_start_try: y_debut if Lambda > 1 or y_end if Lambda <= 1.
// y_start: y_start_try if y_start_try > 0.5 , sr (0.99 if sr > 0.99) if not
// y_bef , y: value of y of previous Newton iteration and of current Newton/bisection iteration.
// y2 , Lambda2_sr_function_der_y: y2 , Lambda^2 s r'(y)
// f_debut , f : Lambda^2.s.r(y) with y=y_debut and at y=(y_debut+y_end)/2.
// test : test of the Newton method. If it failed , test of the bisection method.

double PTG_class::y_search (const double Lambda2_sr) const
{
  if (Lambda2_sr == 0.0) return 0.0;

  double y_debut = (Lambda <= 1) ? (tanh (Lambda2_sr)) : (max (tanh (Lambda2_sr - sqrt_abs_Lambda2_minus_one*atan  (sqrt_abs_Lambda2_minus_one)) , 0.0));
  double y_end   = (Lambda >= 1) ? (tanh (Lambda2_sr)) :      (tanh (Lambda2_sr + sqrt_abs_Lambda2_minus_one*atanh (sqrt_abs_Lambda2_minus_one)));

  if (y_debut > 0.99) return 1.0;

  unsigned int count = 0;

  const double y_start_try = (Lambda >= 1) ? (y_debut) : (y_end);

  double y_bef = -1.0;

  double y = (y_start_try > 0.5) ? (y_start_try) : (min (Lambda2_sr/Lambda2 , 0.99));

  while ((abs (y/y_bef - 1.0) > 1E-15) && (count++ < 100))
    {
      const double y2 = y*y;

      const double Lambda2_sr_function_der_y = 1.0/(1.0 - y2) + Lambda2_minus_one/(1.0 + Lambda2_minus_one*y2);

      y_bef = y;
      
      y -= (Lambda2_sr_function (y) - Lambda2_sr)/Lambda2_sr_function_der_y;

      if ((y <= 0.0) || (y >= 1.0))
	{
	  double f_debut = Lambda2_sr_function (y_debut) - Lambda2_sr;

	  while (abs (y_debut/y_end - 1.0) > 1E-15)
	    {
	      y = 0.5*(y_debut + y_end);    

	      const double f = Lambda2_sr_function (y) - Lambda2_sr;

	      if (SIGN (f_debut) != SIGN (f))
		y_end = y;
	      else 
		y_debut = y , f_debut = f;
	    }

	  return y;
	}
    }

  return y;
}






// Iterative research of exp(-2.atanh(y)) of the PTG potential for y~1:
// --------------------------------------------------------------------
// One has here y~1 , i.e. |1-y| < 1E-5 , y first determined by bisection.
// Then 1-y has numerical imprecision , and then it is refined here with an iterative method.
// One calculates x by iteration , x defined so y = tanh(x):
// 
// y[0] = 1
// x[n] = Lambda2_sr - sqrt[Lambda^2-1].atan [y[n-1].sqrt[Lambda^2-1]] if Lambda >  1 , n>= 1
// x[n] = Lambda2_sr + sqrt[1-Lambda^2].atanh[y[n-1].sqrt[1-Lambda^2]] if Lambda <= 1 , n>= 1
// y[n] = 1 - 2.exp(-2x[n])/(1 + exp(-2x[n])).
//
// Variables :
// -----------
// y : parameter of the PTG equation
// Lambda2_sr : Lambda^2.s.r , used to find y(r)
// x , exp_minus_2x : values of x of exp(-2x) , with x defined so y = tanh(x).
// exp_minus_2x_bef : value of exp(-2x) for the previous x in the iteration.



double PTG_class::exp_minus_2x_iterative (const double Lambda2_sr) const
{
  double exp_minus_2x = 1E-300;

  double exp_minus_2x_bef = 1.0;

  int count = 0;

  while ((abs (exp_minus_2x/exp_minus_2x_bef - 1.0) > 1E-15) && (count++ < 20))
    {
      const double y = 1.0 - 2.0*exp_minus_2x/(1.0 + exp_minus_2x);      

      const double x = (Lambda >= 1.0) 
	? (Lambda2_sr - sqrt_abs_Lambda2_minus_one*atan  (y*sqrt_abs_Lambda2_minus_one)) 
	: (Lambda2_sr + sqrt_abs_Lambda2_minus_one*atanh (y*sqrt_abs_Lambda2_minus_one));

      exp_minus_2x_bef = exp_minus_2x;
      
      exp_minus_2x = exp (-2.0*x);
    }

  return exp_minus_2x;
}




// Calculation of the angular momentum dependent potential V_cl(r)
// ---------------------------------------------------------------
// The angular potential V_cl(r) is equal to l(l+1) [(1-y^2)(1 + (Lambda^2 - 1) y^2)/(y^2) - 1/((sr)^2)] for r > 0 , 
// and has a limit V_cl(0) = l(l+1).(Lambda^2 - 2)/3 for r -> 0.
// V_cl(r) is finite for all r >= 0 , but is the difference of two diverging terms for r -> 0.
// Then , its implementation cannot use the previous formula directly for small due to numerical cancellations.
// In order to have a stable formula for small non zero r , one uses r(y) explcit formula with power series expansions of atan and atanh , so that:
// V_cl(r) = l(l+1) [(1 + y/(s r)) (y/(s r)) S(r)/(Lambda^2) + (Lambda^2 - 1) - (1 + (Lambda^2 - 1) y^2)]
// with S(r) = \sum_{n = 1}^{+oo} (1 - (1-Lambda^2)^{n+1})/(2n + 1) y^{2n-2}
// The used test for convergence to truncate the series is |(1 - (1-Lambda^2)^{n+1})/(2n + 1) y^{2n-2}| < 1E-15 |1-(1-Lambda^2)^2|/3.
// It is used when parameters of atan and atanh in r(y) expression are smaller than 0.01 , so that the series converges quickly , 
// while its defining expression is stable for other values. If r = 0 , l(l+1).(Lambda^2 - 2)/3 is directly returned.
//
// Variables
// ---------
// y , y2 , one_minus_y2 , sr: Ginocchio implicit parameter y(r) , y^2 , 1 - y^2 , s.r
// y_centrifugal_part: one_minus_y2*(1.0 + Lambda2_minus_one*y2)/y2
// V_cl: returned value of V_cl(r)
// n: index of the power series S(r) , starting at n = 1.
// one_minus_Lambda2 , factor_y2 , factor_Lambda2: 1-Lambda^2 , y^{2n-2} , (1-Lambda^2)^{n+1}
// Lambda2_sr_minus_y_over_y3 , term: S(r) truncated sum , term of the series at given n equal to (1 - (1-Lambda^2)^{n+1})/(2n + 1) y^{2n-2}
// test , prec: test of convergence |(1 - (1-Lambda^2)^{n+1})/(2n + 1) y^{2n-2}| , demanded precision 1E-15 |1-(1-Lambda^2)^2|/3.
// y_over_sr: y/(s r)

double PTG_class::V_cl_calc (const double y , const double y2 , const double one_minus_y2 , const double sr) const
{
  const double y_centrifugal_part = one_minus_y2*(1.0 + Lambda2_minus_one*y2)/y2;

  if (sr == 0.0)
    return V_cl_zero;
  else if (y_centrifugal_part < 1E4)
    {
      const double V_cl = llp1*(y_centrifugal_part - 1.0/(sr*sr));

      return V_cl;
    } 
  else
    {
      const double one_minus_Lambda2 = -Lambda2_minus_one;

      double factor_y2 = 1.0;

      double factor_Lambda = one_minus_Lambda2*one_minus_Lambda2;

      double Lambda2_sr_minus_y_over_y3 = (1.0 - factor_Lambda)/3.0;

      double test = 1.0;

      const double prec = 1E-15*abs (Lambda2_sr_minus_y_over_y3);

      int n = 2;

      while (test > prec)
	{
	  factor_y2 *= y2;

	  factor_Lambda *= one_minus_Lambda2;

	  const double term = (1.0 - factor_Lambda)*factor_y2/(2*n + 1);

	  Lambda2_sr_minus_y_over_y3 += term;

	  test = abs (term);

	  n++;
	}

      const double y_over_sr = (sr != 0.0) ? (y/sr) : (1.0);

      const double V_cl = llp1*((1.0 + y_over_sr)*y_over_sr*Lambda2_sr_minus_y_over_y3/Lambda2 + Lambda2_minus_one - (1.0 + Lambda2_minus_one*y2));

      return V_cl;
    }
}





// PTG potential and effective mass: 
// ---------------------------------
// Unit : MeV.
// One has : V_PTG(r) = v(s.r).s^2/kinetic_factor , with v the potential in reduced units of Ginnochio's papers 
// (Annals of Physics 152 , 203-219 (1984) , 159 467-480(1985)).
// The energy E in MeV is e.s^2/kinetic_factor , with e the energy in reduced units of Ginnochio's papers.
// kinetic_factor is 2 mu/hbar^2. 
//
// One calculates the PTG potential value by first determining y as an implicit function of r , 
// as the PTG potential is a direct function of y(r).
// Indeed , Lambda^2.s.r = atanh[y] + sqrt[Lambda^2 - 1].atan([Lambda^2 - 1].y).
// First , y is looked for with a bisection method.
// If |1-y| > 1E-5 , the value is correct.
// If not , 1-y can have numerical imprecision , and it is refined with an iterative method on exp(-2.atanh(y)) (see above).
// All y , y^2 , 1-y^2 can be calculated precisely from exp(-2.atanh(y)).
// The PTG potential is a polynomial in y and is calculated directly.
//
// The returned effective mass is [1 - a + a*y^2].kinetic_factor
// The derivative of the effective mass is : 2.a.s.kinetic_factor.y.(1 - y^2).(1 - y^2 + Lambda^2.y^2)
// It is calculated using dy/dr = s.(1 - y^2).(1 - y^2 + Lambda^2.y^2)
//
//
// Variables :
// -----------
// ys : y first determined by bisection or Newton method.
// y , y2 , y4 , one_minus_y2 : parameter of the PTG equation , y2=y^2 y4=(y^2)^2 , one_minus_y2=1-y^2.
//                        one_minus_y2 is calculated so as to avoid numerical imprecision for y~1.
// Lambda2_sr : Lambda^2.s.r , used to find y(r)
// sr: s.r
// V_cl : approximate centrifugal potential of the PTG potential minus l(l+1)/r^2/kinetic_factor. 
//        It is finite for r<<1 but behaves like - l(l+1)/r^2/kinetic_factor for r -> +oo.
//        If |y| < 0.01 or |sqrt[|Lambda^2-1|]| < 0.01 , it is calculated expanding Lambda2.sr(y)-y in power series of y to avoid numerical cancellations.
// V_central : PTG potential without l dependence.
// mu_r , mu_factor : dimensionless effective mass , factor depending on mu of the PTG potential effective mass part.
// V_mu_1 , V_mu_2 , V_mu : effective mass parts of the PTG potential , total effective mass part of the PTG potential.
// x , e_m2x , e_m2x_fraction: atanh (y) , exp (-2.x) , 1/(1 + exp (-2.x))
// Vr : total PTG potential

double PTG_class::operator () (const double r) const
{
  const double Lambda2_sr = Lambda2_s*r;

  const double ys = y_search (Lambda2_sr);

  const double sr = s*r;

  if (abs (1.0 - ys) > sqrt_precision)
    {
      const double y = ys;

      const double y2 = y*y;

      const double y4 = y2*y2;

      const double one_minus_y2 = 1.0 - y2;

      const double mu_r = 1.0 - a*one_minus_y2;

      const double V_mu_1 = one_minus_a + (a_four_minus_three_Lambda2 - three_two_minus_Lambda2)*y2;
      
      const double V_mu_2 = Lambda2_minus_one*y4*(five_one_minus_a + two_a*y2);

      const double mu_factor = one_minus_y2*(one_minus_y2 + Lambda2*y2)*a/(mu_r*mu_r);

      const double V_mu = mu_factor*(V_mu_1 - V_mu_2);

      const double V_central = one_minus_y2*(-Lambda2*nu_nu_plus_one - Lambda2_minus_one_over_four*(2.0 - y2*seven_minus_Lambda2  - five_Lambda2_minus_one*y4));

      const double V_cl = (l != 0) ? (V_cl_calc (y , y2 , one_minus_y2 , sr)) : (0.0);

      const double Vr = s_square_over_kinetic_factor*(V_central + V_cl + V_mu)/mu_r;

      return Vr;
    }
  else 
    {
      const double e_m2x = exp_minus_2x_iterative (Lambda2_sr);
      
      const double e_m2x_fraction = 1.0/(1.0 + e_m2x);

      const double y = 1.0 - 2.0*e_m2x*e_m2x_fraction;

      const double y2 = y*y;

      const double y4 = y2*y2;

      const double one_minus_y2 = 4.0*e_m2x*e_m2x_fraction*e_m2x_fraction;

      const double mu_r = 1.0 - a*one_minus_y2;

      const double V_mu_1 = one_minus_a + (a_four_minus_three_Lambda2 - three_two_minus_Lambda2)*y2;

      const double V_mu_2 = Lambda2_minus_one*y4*(five_one_minus_a + two_a*y2);

      const double mu_factor = one_minus_y2*(one_minus_y2 + Lambda2*y2)*a/(mu_r*mu_r);

      const double V_mu = mu_factor*(V_mu_1 - V_mu_2);

      const double V_central = one_minus_y2*(-Lambda2*nu_nu_plus_one - Lambda2_minus_one_over_four*(2.0 - y2*seven_minus_Lambda2  - five_Lambda2_minus_one*y4));

      const double V_cl = (l != 0) ? (V_cl_calc (y , y2 , one_minus_y2 , sr)) : (0.0);

      const double Vr = s_square_over_kinetic_factor*(V_central + V_cl + V_mu)/mu_r;

      return Vr;
    }
}



double PTG_class::effective_mass (const double r) const
{
  const double Lambda2_sr = Lambda2_s*r;

  const double ys = y_search (Lambda2_sr);

  if (abs (1.0 - ys) > sqrt_precision)
    {
      const double y = ys;

      const double one_minus_y2 = 1.0 - y*y;

      const double kinetic_factor_mu_r = (1.0 - a*one_minus_y2)*kinetic_factor;

      return kinetic_factor_mu_r;
    }
  else 
    {
      const double e_m2x = exp_minus_2x_iterative (Lambda2_sr);

      const double e_m2x_fraction = 1.0/(1.0 + e_m2x);

      const double one_minus_y2 = 4.0*e_m2x*e_m2x_fraction*e_m2x_fraction;

      const double kinetic_factor_mu_r = (1.0 - a*one_minus_y2)*kinetic_factor;

      return kinetic_factor_mu_r;
    }
}

double PTG_class::effective_mass_der (const double r) const
{
  const double Lambda2_sr = Lambda2_s*r;

  const double ys = y_search (Lambda2_sr);

  if (abs (1.0 - ys) > sqrt_precision)
    {
      const double y = ys;

      const double y2 = y*y;

      const double one_minus_y2 = 1.0 - y2;

      const double kinetic_factor_mu_der_r = two_a_s_kinetic_factor*y*one_minus_y2*(one_minus_y2 + Lambda2*y2);

      return kinetic_factor_mu_der_r;
    }
  else 
    {
      const double e_m2x = exp_minus_2x_iterative (Lambda2_sr);

      const double e_m2x_fraction = 1.0/(1.0 + e_m2x);

      const double one_minus_y2 = 4.0*e_m2x*e_m2x_fraction*e_m2x_fraction;

      const double y = 1.0 - 2.0*e_m2x*e_m2x_fraction;

      const double y2 = y*y;

      const double kinetic_factor_mu_der_r = two_a_s_kinetic_factor*y*one_minus_y2*(one_minus_y2 + Lambda2*y2);

      return kinetic_factor_mu_der_r;
    }
}






// Calculation of k of the PTG potential
// -------------------------------------
// One uses the Ginocchio formula for k and one considers the different cases of bound, antibound and resonant states.
// The first case is for bound states and antibound states, and the second for resonant states.
// k_PTG = i s [-(N_PTG + 1/2) +/- sqrt[Delta]]/(1-a),
// where N_PTG = 2n + l + 1, Delta = Lambda^2 (nu + 1/2)^2 (1-a) - (Lambda^2 (1-a) - 1) (N_PTG + 1/2)^2,
// and +/- is "+" for bound/antibound states and "-" for resonant states.
//
// Variables:
// ----------
// n , l: principal quantum number of the state, angular momentum, 2 m0/hbar^2
// Lambda,s,nu,a : parameters of the PTG potential
// N_PTG , Lambda2_one_minus_a : 2n + l + 1, Lambda^2.(1-a).
// Delta: Lambda^2 (nu + 1/2)^2 (1-a) - (Lambda^2 (1-a) - 1) (N_PTG + 1/2)^2
// is_Delta_positive: true if Delta >= 0.0, false if not.
// Is_over_one_minus_a : i.s/(1-a)
// k_PTG: returned value

complex<double> PTG_class::k_pole_calc (const int n) const
{
  const int N_PTG = 2*n + l + 1;
    
  const complex<double> Is_over_one_minus_a(0 , s_over_one_minus_a);
  
  const complex<double> Delta = Lambda2_one_minus_a*(nu + 0.5)*(nu + 0.5) - (Lambda2_one_minus_a - 1.0)*(N_PTG + 0.5)*(N_PTG + 0.5);
  
  const complex<double> k_PTG = (real (Delta) >= 0.0) ? (Is_over_one_minus_a*(-N_PTG - 0.5 + sqrt_mod (Delta))) : (Is_over_one_minus_a*(-N_PTG - 0.5 - sqrt_mod (Delta)));
  
  return k_PTG;
}


double used_memory_calc (const class PTG_class &T)
{
  return sizeof (T)/1000000.0;
}




// Modified PTG potential
// ----------------------
// It is a PTG potential plus E[barrier] for r <= r[asymptote] and the Coulomb potential for r >= r[asymptote].
// It is the potential with analytical wave functions which is the closest to a WS potential.
// The PTG potential is fitted from a WS potential.


modified_PTG_class::modified_PTG_class ()
{
  initialize (false , false , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , NO_PARTICLE , 0 , 0.0 , 0.0 , 0 , 0.0 , 0.0 , 0 , 0);
}

modified_PTG_class::modified_PTG_class (
					const bool is_modified_PTG_fitted_from_WS_analytic ,
					const bool is_it_relative , 
					const double d_c , 
					const double R0_c , 
					const double Vo_c ,
					const double Vso_c , 
					const double scaled_effective_mass_inv_minus_one_zero_radius ,
					const enum particle_type particle_c , 
					const int Z_charge_c , 
					const double R_charge_c , 
					const double kinetic_factor , 
					const int l_c , 
					const double j_c ,
					const double R ,
					const unsigned int N_big ,
					const unsigned int N_GL)
{
  initialize (is_modified_PTG_fitted_from_WS_analytic , is_it_relative ,
	      d_c , R0_c , Vo_c , Vso_c , scaled_effective_mass_inv_minus_one_zero_radius ,
	      particle_c , Z_charge_c , R_charge_c , kinetic_factor , l_c , j_c , R , N_big , N_GL);
}

modified_PTG_class::modified_PTG_class (const class modified_PTG_class &X)
{
  initialize (X);
}

void modified_PTG_class::initialize (
				     const bool is_modified_PTG_fitted_from_WS_analytic ,
				     const bool is_it_relative , 
				     const double d_c , 
				     const double R0_c , 
				     const double Vo_c ,
				     const double Vso_c , 
				     const double scaled_effective_mass_inv_minus_one_zero_radius ,
				     const enum particle_type particle_c , 
				     const int Z_charge_c , 
				     const double R_charge_c , 
				     const double kinetic_factor , 
				     const int l_c , 
				     const double j_c ,
				     const double R ,
				     const unsigned int N_big ,
				     const unsigned int N_GL)
{
  d = d_c; 
  R0 = R0_c; 
  Vo = Vo_c; 
  Vso = Vso_c;
  particle = particle_c;
  Z_charge = Z_charge_c; 
  R_charge = R_charge_c; 
  l = l_c; 
  j = j_c;

  if (particle == ELECTRON) error_message_print_abort ("The modified PTG potential can only be used with nucleons");
  
  if ((N_big == 0) || (N_GL == 0) || (R == 0.0)) return;

  Coulomb_potential.initialize (is_it_relative , particle , Z_charge , R_charge);
  
  const double Coulomb_factor = Coulomb_potential.point_potential_calc (1);
    
  const enum potential_type potential_to_fit = (is_modified_PTG_fitted_from_WS_analytic) ? (WS_ANALYTIC) : (WS);
  
  const double step_bef_R_big = R/static_cast<double> (N_big - 1);
  
  class array<double> r_bef_R_tab_big(N_big);

  for (unsigned int i = 0 ; i < N_big ; i++) r_bef_R_tab_big(i) = i*step_bef_R_big;
    
  const double a = scaled_effective_mass_inv_minus_one_zero_radius/(1.0 + scaled_effective_mass_inv_minus_one_zero_radius);
      
  double Lambda = 0.0;

  double s = 0.0;
  
  double nu = 0.0;

  double test_PTG = INFINITE;
  
  const double r_min = 1.0;

  class potentials_effective_mass T;
  
  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
	    
  if (potential_to_fit == WS) WS_potential.initialize (is_it_relative , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
	  	
  if (potential_to_fit == WS_ANALYTIC) WS_analytic_potential.initialize (is_it_relative , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  T.initialize_constants (potential_to_fit , kinetic_factor , NADA , l , Z_charge , j , NADA , NADA , NADA);
  
  class array<double> r_tab_GL(N_GL);
  class array<double> w_tab_GL(N_GL);
  class array<double> V_tab_GL(N_GL);

  potential_barrier::barrier_values_calc (r_bef_R_tab_big , particle , T , r_asy , E_barrier);
 
  Gauss_Legendre::abscissas_weights_tables_calc (r_min , r_asy , r_tab_GL , w_tab_GL);
  
  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double r = r_tab_GL(i);

      V_tab_GL(i) = real (T.potential_calc (r));
    }
  
  for (int N_bound = 0 ; N_bound <= 3 ; N_bound++)
    {
      double Lambda_try = 0.0;

      double s_try = 0.0;

      double nu_try = 0.0;
    
      PTG_potential_fit::parameters_determine (r_bef_R_tab_big , particle , T , N_bound , Lambda_try , s_try , nu_try);
      
      const double test_PTG_try = PTG_potential_fit::chi_square_calc (r_tab_GL , w_tab_GL , V_tab_GL , kinetic_factor , l , E_barrier , Lambda_try  , s_try , nu_try , 0.0);
      
      if (test_PTG_try < test_PTG)
	{
	  Lambda = Lambda_try;
	  
	  s = s_try;
	  
	  nu = nu_try;
	  
	  test_PTG = test_PTG_try;
	}
    }
  
  PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);

  if (E_barrier == 0.0) return;

  // The potential must be continuous in r_asy, so that V-PTG(r_asy) = Coulomb.point.particle(r_asy).
  // One has here E[barrier] > 0, so that the radius r_asy exists.
  // r_asy is determined with the Newton method.
  // The positive solution of E[barrier].r_asy^2 - Coulomb_factor.r_asy - l(l+1)/kinetic_factor = 0, which is analytical, is taken as starting point. 
  // This value is accurate as PTG_potential(r) + l(l+1)/(kinetic_factor.r^2) ~ 0 for medium and large r.
  
  r_asy = (Coulomb_factor + sqrt (Coulomb_factor*Coulomb_factor + (4*l*(l + 1))*E_barrier/kinetic_factor))/(2.0*E_barrier);

  double test_r_asy = INFINITE;

  while (test_r_asy > precision)
    {
      const double r_asy_minus = r_asy*(1.0 - sqrt_precision);
      const double r_asy_plus  = r_asy*(1.0 + sqrt_precision);

      const double F_r_asy = PTG_potential(r_asy) + E_barrier - Coulomb_potential.point_potential_calc (r_asy);

      const double F_r_asy_minus = PTG_potential(r_asy_minus) + E_barrier - Coulomb_potential.point_potential_calc (r_asy_minus);
      const double F_r_asy_plus  = PTG_potential(r_asy_plus)  + E_barrier - Coulomb_potential.point_potential_calc (r_asy_plus);

      const double dF_r_asy = (F_r_asy_plus - F_r_asy_minus)/(r_asy_plus - r_asy_minus);

      const double dr_asy = F_r_asy/dF_r_asy;
      
      r_asy -= dr_asy;

      test_r_asy = abs (dr_asy);
    }
}


void modified_PTG_class::initialize (const class modified_PTG_class &X)
{
  d = X.d; 
  R0 = X.R0; 
  Vo = X.Vo; 
  Vso = X.Vso;
  particle = X.particle;
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  l = X.l; 
  j = X.j;
  r_asy = X.r_asy;
  E_barrier = X.E_barrier;
  
  PTG_potential.initialize (X.PTG_potential);
  
  Coulomb_potential.initialize (X.Coulomb_potential);
}


double modified_PTG_class::operator () (const double r) const
{  
  const double Vr = (r < r_asy) ? (PTG_potential(r) + E_barrier) : (Coulomb_potential.point_potential_calc (r));

  return Vr;
}



    
double used_memory_calc (const class modified_PTG_class &T)
{
  return sizeof (T)/1000000.0;
}




// dipolar potential.
// --------------------

// constructors - destructors

dipolar_potential_class::dipolar_potential_class () :
  mu (0.0) , 
  s (0.0) ,
  alpha_0 (0.0) , 
  alpha_2 (0.0) , 
  r_0 (0.0) , 
  Q_zz (0.0) , 
  V_0 (0.0) , 
  r_c (0.0) , 
  J (-1) , 
  lmax (-1)
  //R (R_c)
{}

dipolar_potential_class::dipolar_potential_class (
						  const double mu_c , 
						  const double s_c , 
						  const double alpha_0_c , 
						  const double alpha_2_c , 
						  const double r_0_c , 
						  const double Q_zz_c , 
						  const double V_0_c , 
						  const double r_c_c , 
						  const int J_c , 
						  const int lmax_c)// , 
//const double R_c)
{
  allocate_calc (mu_c , s_c , alpha_0_c , alpha_2_c , r_0_c , Q_zz_c , V_0_c , r_c_c , J_c , lmax_c);// , R_c);
}

dipolar_potential_class::dipolar_potential_class (const class dipolar_potential_class &X)
{
  allocate_fill (X);
}

// methods
    
void dipolar_potential_class::allocate_calc (
					     const double mu_c , 
					     const double s_c , 
					     const double alpha_0_c , 
					     const double alpha_2_c , 
					     const double r_0_c , 
					     const double Q_zz_c , 
					     const double V_0_c , 
					     const double r_c_c , 
					     const int J_c , 
					     const int lmax_c)// , 
//const double R_c)
{
  mu = mu_c;
  s = s_c;
  alpha_0 = alpha_0_c;
  alpha_2 = alpha_2_c;
  r_0 = r_0_c;
  Q_zz = Q_zz_c;
  V_0 = V_0_c;
  r_c = r_c_c;
  J = J_c;
  lmax = lmax_c;
  //R = R_c;
  
  const int jr_max = J + lmax;
  
  const int lambda_max_jr = 2*jr_max;

  const int lambda_max_l = 2*lmax;
  
  const int lambda_max_tot = min (lambda_max_jr , lambda_max_l);
  
  P_lambda_molecular_tab.allocate (lambda_max_tot+1 , jr_max+1 , lmax+1 , jr_max+1 , lmax+1);

  angular_matrix_elements::P_lambda_rotor_tensor_spinless_part_tab_calc (J , P_lambda_molecular_tab);
}

void dipolar_potential_class::allocate_fill (const class dipolar_potential_class &X)
{
  mu = X.mu;
  s = X.s;
  alpha_0 = X.alpha_0;
  alpha_2 = X.alpha_2;
  r_0 = X.r_0;
  Q_zz = X.Q_zz;
  V_0 = X.V_0;
  r_c = X.r_c;
  J = X.J;
  lmax = X.lmax;
  //R = X.R;
    
  P_lambda_molecular_tab.allocate_fill (X.P_lambda_molecular_tab);
}

    

void dipolar_potential_class::deallocate ()
{
  P_lambda_molecular_tab.deallocate ();

  mu = 0.0;
  s = 0.0;
  alpha_0 = 0.0;
  alpha_2 = 0.0;
  r_0 = 0.0;
  Q_zz = 0.0;
  V_0 = 0.0;
  r_c = 0.0;
  J = -1;
  lmax = -1;
  //R = 0.0;
}



// calcule V_lambda(r) pour r == r/a_0 complexe; |r| doit etre assez grand pour que le potentiel soit une fonction rationnelle en r.
void dipolar_potential_class::V_lambda_asymptotic_tab_calc (
							    const int jr , 
							    const int l , 
							    const int jrp , 
							    const int lp , 
							    const complex<double> &z , 
							    class array<complex<double> > &V_lambda_asymptotic_tab) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  V_lambda_asymptotic_tab = 0.0;

  if ((jr + jrp)%2 != (l + lp)%2)
    return;

  if ((lambda_min <= 2) && ((jr + jrp)%2 == 0))
    {
      //const complex<double> z_over_z_0 = z/r_0;
      //const complex<double> z_over_r_c = z/r_c;
      const complex<double> z2 = z*z , z3 = z*z2 , z4 = z*z3;

      if (lambda_min == 0) V_lambda_asymptotic_tab(0) = -0.5*alpha_0/z4;

      if (lambda_max >= 2) V_lambda_asymptotic_tab(2) = -(0.5*alpha_2/z4 + Q_zz/z3);
    }

  bool is_there_Coulomb_dipole = false;
  
  for (int lambda = lambda_min ; (!is_there_Coulomb_dipole) && (lambda <= lambda_max) ; lambda++) 
    is_there_Coulomb_dipole = ((lambda%2 == 1) && ((jrp + jr + lambda)%2 == 0));

  if (is_there_Coulomb_dipole)
    {
      const complex<double> z_ratio = s/z;

      complex<double> Coulomb_dipole_term = - mu * pow (z_ratio , lambda_min) / (s*z); 

      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++) 
	{
	  if ((lambda%2 == 1) && ((jrp + jr + lambda)%2 == 0)) V_lambda_asymptotic_tab(lambda) += Coulomb_dipole_term;

	  Coulomb_dipole_term *= z_ratio;
	}
    }
}



// calcule V_lambda(r) pour r == r/a_0
void dipolar_potential_class::V_lambda_tab_calc (
						 const int jr , 
						 const int l , 
						 const int jrp , 
						 const int lp , 
						 const double r , 
						 class array<double> &V_lambda_tab) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp ;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  V_lambda_tab = 0.0;

  if ((jr + jrp)%2 != (l + lp)%2)
    return;

  if ((lambda_min <= 2) && ((jr + jrp)%2 == 0))
    {
      const double r_over_r_0 = r/r_0;
      const double r_over_r_c = r/r_c;
      
      const double f_r = -expm1 (-pow(r_over_r_0 , 6));
      
      const double exp_minus_r_over_r_c_pow_six = exp (-pow(r_over_r_c , 6));

      const double r2 = r*r , r3 = r*r2 , r4 = r*r3;

      if (lambda_min == 0) V_lambda_tab(0) = (r > 0) ? (- 0.5*alpha_0 * f_r/r4  + const_V0_dimensionless * V_0 * exp_minus_r_over_r_c_pow_six) : (const_V0_dimensionless * V_0);

      if (lambda_max >= 2) V_lambda_tab(2) = (r > 0) ? (- ( 0.5*alpha_2/r4 + Q_zz/r3 ) * f_r) : (0.0) ;
    }

  bool is_there_Coulomb_dipole = false;

  for (int lambda = lambda_min ; (!is_there_Coulomb_dipole) && (lambda <= lambda_max) ; lambda++) is_there_Coulomb_dipole = ((lambda%2 == 1) && ((jrp + jr + lambda)%2 == 0)); 

  if (is_there_Coulomb_dipole && (r != 0.0))
    {
      // original in the Garrett's article , remove the discontinuity in r = s
      const double r_inf = min(s , r) , r_sup = max(s , r) , r_ratio = r_inf/r_sup;

      //const double r_sup = s * Fermi_like_function (s , d_molecular_pot , r) + r * (1.0 - Fermi_like_function (s , d_molecular_pot , r));
      //const double r_ratio = ((r/s) * Fermi_like_function (s , d_molecular_pot , r) + (s/r) * (1.0 - Fermi_like_function (s , d_molecular_pot , r))) * erf (a_molecular_pot * r);
      double Coulomb_dipole_term = - mu * pow (r_ratio , lambda_min) / (s*r_sup); 

      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++) 
	{
	  if ((lambda%2 == 1) && ((jrp + jr + lambda)%2 == 0)) V_lambda_tab(lambda) += Coulomb_dipole_term;

	  Coulomb_dipole_term *= r_ratio;
	}
    }
}




// calcule Vccp_r2(jr' l' jr l) de sorte que V(l' , jr' , l , jr , r) ~ Vccp_r2(jr' l' jr l)/r^2 en eV avec r == r/a_0 pour r -> +oo
double dipolar_potential_class::Vccp_quadratic_inverse_calc (const int jr , const int l , const int jrp , const int lp) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  const int lambda = 1;
  
  if ((lambda < lambda_min) || (lambda > lambda_max)) return 0.0;

  const double V_lambda = -mu;
  
  const double P_lambda_molecular = P_lambda_molecular_tab (lambda , jr , l , jrp , lp);
  
  const double Vccp_quad_inv = const_dimensionless_equation*V_lambda*P_lambda_molecular; 

  return Vccp_quad_inv;
}





// calcule V_total(jr' l' jr l) = sum_lambda [ V_lambda(r) * <P_lambda_mol>(jr' l' jr l) ] en eV avec r == r/a_0
double dipolar_potential_class::operator () (const int jr , const int l , const int jrp , const int lp , const double r) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  class array<double> V_lambda_tab(lambda_max+1);

  V_lambda_tab_calc (jr , l , jrp , lp , r , V_lambda_tab);

  double V_total = 0.0;

  // la condition sur lambda vient des coeff Wigner_3j particuliers
  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      const double V_lambda = V_lambda_tab(lambda);
      
      const double P_lambda_molecular = P_lambda_molecular_tab (lambda , jr , l , jrp , lp);    
      
      V_total += const_dimensionless_equation*V_lambda*P_lambda_molecular; 
    }

  return V_total;
}




// calcule V_total(jr' l' jr l) = sum_lambda [ V_lambda(r) * <P_lambda_mol>(jr' l' jr l) ] en eV avec r == r/a_0 , |r| >> 1.
complex<double> dipolar_potential_class::V_asymptotic_calc (
							    const int jr , 
							    const int l , 
							    const int jrp , 
							    const int lp , 
							    const complex<double> &z) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  class array<complex<double> > V_lambda_asymptotic_tab(lambda_max+1);
  V_lambda_asymptotic_tab_calc (jr , l , jrp , lp , z , V_lambda_asymptotic_tab);

  complex<double> V_total = 0.0;

  // la condition sur lambda vient des coeff Wigner_3j particuliers
  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      const double P_lambda_molecular = P_lambda_molecular_tab (lambda , jr , l , jrp , lp);    

      const complex<double> V_lambda = V_lambda_asymptotic_tab(lambda);

      V_total += const_dimensionless_equation*V_lambda*P_lambda_molecular; 
    }

  return V_total;
}


double used_memory_calc (const class dipolar_potential_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.P_lambda_molecular_tab) - sizeof (T.P_lambda_molecular_tab)/1000000.0);
}





// quadrupolar potential.
// --------------------

// constructors - destructors

quadrupolar_potential_class::quadrupolar_potential_class () :
  s (0.0) ,
  Q_pm (0.0) , 
  V_0 (0.0) , 
  r_c (0.0) , 
  J (-1) , 
  lmax (-1)
  //R (0.0)
{}

quadrupolar_potential_class::quadrupolar_potential_class (
							  const double s_c ,
							  const double Q_pm_c ,
							  const double V_0_c ,
							  const double r_c_c ,
							  const int J_c ,
							  const int lmax_c)
{
  allocate_calc (s_c , Q_pm_c , V_0_c , r_c_c , J_c , lmax_c);
}

quadrupolar_potential_class::quadrupolar_potential_class (const class quadrupolar_potential_class &X)
{
  allocate_fill (X);
}

// methods

void quadrupolar_potential_class::allocate_calc (
						 const double s_c ,
						 const double Q_pm_c ,
						 const double V_0_c ,
						 const double r_c_c ,
						 const int J_c ,
						 const int lmax_c)
{
  s = s_c;
  Q_pm = Q_pm_c;
  V_0 = V_0_c;
  r_c = r_c_c;
  J = J_c;
  lmax = lmax_c;
  
  const int jr_max = J + lmax;
  const int lambda_max_jr = 2*jr_max;
  const int lambda_max_l = 2*lmax;
  const int lambda_max_tot = min (lambda_max_jr , lambda_max_l);
  
  P_lambda_molecular_tab.allocate (lambda_max_tot+1 , jr_max+1 , lmax+1 , jr_max+1 , lmax+1);

  angular_matrix_elements::P_lambda_rotor_tensor_spinless_part_tab_calc (J , P_lambda_molecular_tab);
}

void quadrupolar_potential_class::allocate_fill (const class quadrupolar_potential_class &X)
{
  s = X.s;
  Q_pm = X.Q_pm;
  V_0 = X.V_0;
  r_c = X.r_c;
  J = X.J;
  lmax = X.lmax;
  
  P_lambda_molecular_tab.allocate_fill (X.P_lambda_molecular_tab);
}

void quadrupolar_potential_class::deallocate ()
{
  P_lambda_molecular_tab.deallocate ();

  s = 0.0;
  Q_pm = 0.0; 
  V_0 = 0.0; 
  r_c = 0.0; 
  J = -1; 
  lmax = -1;
  //R = 0.0;
}


// calculate V_lambda(r) for r == r/a_0 complex; |r| must be large enough so that the potential is a rational function in r
void quadrupolar_potential_class::V_lambda_asymptotic_tab_calc (
								const int jr , 
								const int l , 
								const int jrp , 
								const int lp , 
								const complex<double> &z , 
								class array<complex<double> > &V_lambda_asymptotic_tab) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  V_lambda_asymptotic_tab = 0.0; 

  if ((jr + jrp)%2 != (l + lp)%2) return;

  const double Q_s2 = -Q_pm/(s*s);

  const complex<double> s_z = s/z;

  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      if ((lambda >= 2) && (lambda%2 == 0)) V_lambda_asymptotic_tab(lambda) = Q_s2*pow (s_z , lambda)*(1.0/z);
    }
}



// calculate V_lambda(r) for r == r/a_0
void quadrupolar_potential_class::V_lambda_tab_calc (
						     const int jr , 
						     const int l , 
						     const int jrp , 
						     const int lp , 
						     const double r , 
						     class array<double> &V_lambda_tab) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  V_lambda_tab = 0.0; 

  if ((jr + jrp)%2 != (l + lp)%2) return;
  //if (r <= 0.0) return;

  const double r_sup = max (s , r);
  const double r_inf = min (s , r);
  
  const double r_ratio = r_inf/r_sup;
  
  const double Q_s2 = -Q_pm/(s*s);
  
  const double sign_Q_pm = (Q_pm < 0.0) ? (-1.0) : (1.0);

  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      if (lambda == 0) V_lambda_tab(lambda) = (r > 0) ? (-Q_s2*(1.0/r - 1.0/r_sup)) : (sign_Q_pm * V_0);

      //V_lambda_tab(lambda) = (r > 0) ? (-Q_s2*(1.0/r - 1.0/r_sup) + (sign_Q_pm * V_0) * exp (-pow(r/r_c , 6))) : (sign_Q_pm * V_0);//xyz to smooth

      if ((lambda >= 2) && (lambda%2 == 0)) V_lambda_tab(lambda) = Q_s2*pow (r_ratio , lambda)*(1.0/r_sup);
    }
}





// calculate V_total(jr' l' jr l) = sum_lambda [ V_lambda(r) * <P_lambda_mol>(jr' l' jr l) ] in eV with r == r/a_0
double quadrupolar_potential_class::operator () (
						 const int jr , 
						 const int l , 
						 const int jrp , 
						 const int lp , 
						 const double r) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  const int lambda_max_plus_one = lambda_max + 1;

  class array<double> V_lambda_tab (lambda_max_plus_one);

  V_lambda_tab_calc (jr , l , jrp , lp , r , V_lambda_tab);

  double V_total = 0.0;

  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      const double V_lambda = V_lambda_tab (lambda);

      const double P_lambda_molecular = P_lambda_molecular_tab (lambda , jr , l , jrp , lp);    
      
      V_total += const_dimensionless_equation*V_lambda*P_lambda_molecular; 
    }

  return V_total;
}





// calculate V_total(jr' l' jr l) = sum_lambda [ V_lambda(r) * <P_lambda_mol>(jr' l' jr l) ] in eV with r == r/a_0 , |r| >> 1.
complex<double> quadrupolar_potential_class::V_asymptotic_calc (
								const int jr , 
								const int l , 
								const int jrp , 
								const int lp , 
								const complex<double> &z) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  const int lambda_max_plus_one = lambda_max + 1;

  class array<complex<double> > V_lambda_asymptotic_tab (lambda_max_plus_one);

  V_lambda_asymptotic_tab_calc (jr , l , jrp , lp , z , V_lambda_asymptotic_tab);

  complex<double> V_total = 0.0;

  // la condition sur lambda vient des coeff Wigner_3j particuliers
  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      const double P_lambda_molecular = P_lambda_molecular_tab (lambda , jr , l , jrp , lp);

      const complex<double> V_lambda = V_lambda_asymptotic_tab (lambda);

      V_total += const_dimensionless_equation*V_lambda*P_lambda_molecular; 
    }

  return V_total;
}



double used_memory_calc (const class quadrupolar_potential_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.P_lambda_molecular_tab) - sizeof (T.P_lambda_molecular_tab)/1000000.0);
}



















// Class for P_lambda , depending on lambda , jr , l , j
// -----------------------------------------------------

P_lambda_rotor_tensor_part_class::P_lambda_rotor_tensor_part_class () {}

P_lambda_rotor_tensor_part_class::P_lambda_rotor_tensor_part_class (const double J , const int lmax)
{
  allocate_calc (J , lmax);
}

P_lambda_rotor_tensor_part_class::P_lambda_rotor_tensor_part_class (const class P_lambda_rotor_tensor_part_class &X)
{
  allocate_fill (X);
}

// methods

void P_lambda_rotor_tensor_part_class::indices_dimension_table_calc (const double J , const int lmax , unsigned int &dimension_table)
{
  indices = OUT_OF_RANGE;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      // |l-s| <= j <= l+s
      const double jmin_l = abs (0.5 - l);
      const double jmax_l = 0.5 + l;
      
      const unsigned int N_j = make_int (jmax_l - jmin_l + 1);

      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  // |l'-s| <= j' <= l'+s
	  const double jp_min_lp = abs (0.5 - lp);
	  const double jp_max_lp = 0.5 + lp;
	  
	  const unsigned int N_jp = make_int (jp_max_lp - jp_min_lp + 1);

	  for (unsigned int i_j = 0 ; i_j < N_j ; i_j ++)
	    {
	      // |J-j| <= jr <= J+j
	      const double j = jmin_l + i_j;

	      const int jr_min_j = make_int (abs (J - j));
	      const int jr_max_j = make_int (J + j);

	      const unsigned int j_index = (l < j) ? (0) : (1);

	      for (unsigned int i_jp = 0 ; i_jp < N_jp ; i_jp ++)
		{
		  // |J-j'| <= jr' <= J+j'
		  const double jp = jp_min_lp + i_jp;

		  const int jr_min_jp = make_int (abs (J - jp));
		  const int jr_max_jp = make_int (J + jp);

		  const unsigned int jp_index = (lp < jp) ? (0) : (1);

		  for (int jr = jr_min_j ; jr <= jr_max_j ; jr++)
		    {
		      for (int jrp = jr_min_jp ; jrp <= jr_max_jp ; jrp++)
			{
			  // |jr'-jr| <= lambda <= jr'+jr && |j'-j| <= lambda <= j'+j

			  const int lambda_min_jr = abs (jrp - jr);
			  const int lambda_max_jr = jr + jrp;

			  const int lambda_min_j = make_int (abs (jp - j));
			  const int lambda_max_j = make_int (j + jp);

			  const int lambda_min = max (lambda_min_jr , lambda_min_j);
			  const int lambda_max = min (lambda_max_jr , lambda_max_j);

			  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
			    {
			      if ((lp + l + lambda)%2 == 0) indices(lambda , jr , l , j_index , jrp , lp , jp_index) = dimension_table++;
			    }
			}
		    }
		}
	    }
	}
    }
}


void P_lambda_rotor_tensor_part_class::table_calc (const double J , const int lmax)
{
  table = 0.0;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      // |l-s| <= j <= l+s

      const double jmin_l = abs (0.5 - l);
      const double jmax_l = 0.5 + l;
      
      const unsigned int N_j = make_int (jmax_l - jmin_l + 1);

      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  // |l'-s| <= j' <= l'+s
	  
	  const double jp_min_lp = abs (0.5 - lp);
	  const double jp_max_lp = 0.5 + lp;
	  
	  const unsigned int N_jp = make_int (jp_max_lp - jp_min_lp + 1);

	  for (unsigned int i_j = 0 ; i_j < N_j ; i_j ++)
	    {
	      // |J-j| <= jr <= J+j

	      const double j = jmin_l + i_j;
	      
	      const int jr_min_j = make_int (abs (J - j));
	      const int jr_max_j = make_int (J + j);
	      
	      const unsigned int j_index = (l < j) ? (0) : (1);

	      for (unsigned int i_jp = 0 ; i_jp < N_jp ; i_jp ++)
		{
		  // |J-j'| <= jr' <= J+j'

		  const double jp = jp_min_lp + i_jp;
		  
		  const int jr_min_jp = make_int (abs (J - jp));
		  const int jr_max_jp = make_int (J + jp);
		  
		  const unsigned int jp_index = (lp < jp) ? (0) : (1);

		  for (int jr = jr_min_j ; jr <= jr_max_j ; jr++)
		    {
		      for (int jrp = jr_min_jp ; jrp <= jr_max_jp ; jrp++)
			{
			  // |jr'-jr| <= lambda <= jr'+jr && |j'-j| <= lambda <= j'+j
			  
			  const int lambda_min_jr = abs (jrp - jr);
			  const int lambda_max_jr = jr + jrp;
			  
			  const int lambda_min_j = make_int (abs (jp - j));
			  const int lambda_max_j = make_int (j + jp);
			  
			  const int lambda_min = max (lambda_min_jr , lambda_min_j);
			  const int lambda_max = min (lambda_max_jr , lambda_max_j);

			  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
			    {			      
			      if ((lp + l + lambda)%2 == 0) table(indices(lambda , jr , l , j_index , jrp , lp , jp_index)) = angular_matrix_elements::P_lambda_rotor_tensor_part_calc (lambda , jr , l , j , jrp , lp , jp , J);
			    }
			}
		    }
		}
	    }
	}
    }
}



void P_lambda_rotor_tensor_part_class::allocate_calc (const double J , const int lmax)
{
  const double jmax = 0.5 + lmax;
  
  const int jr_max = make_int (J + jmax);
  
  const int lambda_max_jr = make_int (2 * jr_max);

  const int lambda_max_j = make_int (2 * jmax);
  
  const int lambda_max = min (lambda_max_jr , lambda_max_j);
  
  const int lmax_plus_one = lmax + 1;

  const int lambda_max_plus_one = lambda_max + 1;

  const int jr_max_plus_one = jr_max + 1;

  unsigned int dimension_table = 0;

  indices.allocate (lambda_max_plus_one , jr_max_plus_one , lmax_plus_one , 2 , jr_max_plus_one , lmax_plus_one , 2);

  indices_dimension_table_calc (J , lmax , dimension_table);
  
  table.allocate (dimension_table);

  table_calc (J , lmax);
}

void P_lambda_rotor_tensor_part_class::allocate_fill (const class P_lambda_rotor_tensor_part_class &X)
{
  indices.allocate_fill (X.indices);

  table.allocate_fill (X.table);
}

void P_lambda_rotor_tensor_part_class::deallocate ()
{
  indices.deallocate ();

  table.deallocate ();
}

double & P_lambda_rotor_tensor_part_class::operator [] (const unsigned int i) const
{
  return table[i];
}

unsigned int P_lambda_rotor_tensor_part_class::index_determine (
								const int lambda , 
								const int jr , 
								const int l , 
								const double j , 
								const int jrp , 
								const int lp , 
								const double jp) const
{    
  const unsigned int j_index = (l < j) ? (0) : (1);
  
  const unsigned int jp_index = (lp < jp) ? (0) : (1);

  const unsigned int index = indices(lambda , jr , l , j_index , jrp , lp , jp_index);

  return index;
}

double & P_lambda_rotor_tensor_part_class::operator () (
							const int lambda , 
							const int jr , 
							const int l , 
							const double j , 
							const int jrp , 
							const int lp , 
							const double jp) const
{    
  const unsigned int index = index_determine(lambda , jr , l , j , jrp , lp , jp);

  return table(index);
}



double used_memory_calc (const class P_lambda_rotor_tensor_part_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.indices) + used_memory_calc (T.table) - (sizeof (T.indices) + sizeof (T.table))/1000000.0);
}









// Deformed WS potential.
// ---------------------
// Spin-orbit and Coulomb potentials are sphericals.

// constructors - destructors

deformed_WS_class::deformed_WS_class () :
  Nt (0) ,
  Nr (0) ,
  R (0.0) ,
  particle (NO_PARTICLE) ,
  Z_charge (0) ,
  R_charge (0.0) ,
  d (0.0) ,
  R0 (0.0) ,
  beta_2 (0.0) ,
  Vo (0.0) ,
  Vso (0.0) ,
  J (0.0) ,
  lmax (0)
{}

deformed_WS_class::deformed_WS_class (
				      const unsigned int Nt_c , 
				      const unsigned int Nr_c , 
				      const double R_c , 
				      const enum particle_type particle_c , 
				      const int Z_charge_c , 
				      const double R_charge_c , 
				      const double d_c , 
				      const double R0_c , 
				      const double beta_2_c , 
				      const double Vo_c , 
				      const double Vso_c , 
				      const double J_c , 
				      const int lmax_c)
{
  allocate_calc (Nt_c , Nr_c , R_c , particle_c , Z_charge_c , R_charge_c , d_c , R0_c , beta_2_c , Vo_c , Vso_c , J_c , lmax_c);
}







deformed_WS_class::deformed_WS_class (const class deformed_WS_class &X)
{
  allocate_fill (X);
}








// methods


void deformed_WS_class::allocate_calc (
				       const unsigned int Nt_c , 
				       const unsigned int Nr_c , 
				       const double R_c , 
				       const enum particle_type particle_c , 
				       const int Z_charge_c , 
				       const double R_charge_c , 
				       const double d_c , 
				       const double R0_c , 
				       const double beta_2_c , 
				       const double Vo_c , 
				       const double Vso_c , 
				       const double J_c , 
				       const int lmax_c)
{ 
  Nt = Nt_c; 
  Nr = Nr_c; 
  R = R_c; 
  particle = particle_c; 
  Z_charge = Z_charge_c; 
  R_charge = R_charge_c; 
  d = d_c; 
  R0 = R0_c; 
  beta_2 = beta_2_c; 
  Vo = Vo_c; 
  Vso = Vso_c; 
  J = J_c; 
  lmax = lmax_c;
  
  if (particle == ELECTRON) error_message_print_abort ("No deformed WS potential for electron (1)");

  // calculation of P_lambda MEs
  // ================================== ================================== //

  P_lambda_nuclear_tab.allocate_calc (J , lmax);

  // calculation of multipole expansion tables
  // ==================================================================== //

  multipole_expansion_tables_alloc_calc ();  
}







void deformed_WS_class::allocate_fill (const class deformed_WS_class &X)
{
  Nt = X.Nt; 
  Nr = X.Nr; 
  R = X.R; 
  particle = X.particle; 
  Z_charge = X.Z_charge; 
  I = X.I; 
  is_I_tab_used = X.is_I_tab_used; 
  R_charge = X.R_charge; 
  d = X.d; 
  R0 = X.R0; 
  beta_2 = X.beta_2; 
  Vo = X.Vo; 
  Vso = X.Vso; 
  J = X.J; 
  lmax = X.lmax;

  if (particle == ELECTRON) error_message_print_abort ("No deformed WS potential for electron (2)");

  P_lambda_nuclear_tab.allocate_fill (X.P_lambda_nuclear_tab);

  const unsigned int NL_central = X.V_lambda_central_splines_tab.dimension (0);
  const unsigned int NL_so = X.V_lambda_so_times_r_splines_tab.dimension (0);

  V_lambda_central_splines_tab.allocate (NL_central);
  V_lambda_so_times_r_splines_tab.allocate (NL_so);

  for (unsigned int iL = 0 ; iL < NL_central ; iL++) V_lambda_central_splines_tab(iL).allocate_fill (X.V_lambda_central_splines_tab(iL));

  for (unsigned int iL = 0 ; iL < NL_so ; iL++) V_lambda_so_times_r_splines_tab(iL).allocate_fill (X.V_lambda_so_times_r_splines_tab(iL));

  rotor_angular_momenta.deallocate ();

  moments_of_inertia.deallocate ();

  rotor_angular_momenta.allocate_fill (X.rotor_angular_momenta);

  moments_of_inertia.allocate_fill (X.moments_of_inertia);
}






void deformed_WS_class::deallocate ()
{
  P_lambda_nuclear_tab.deallocate ();
  
  const unsigned int NL_central = V_lambda_central_splines_tab.dimension (0);

  const unsigned int NL_so = V_lambda_so_times_r_splines_tab.dimension (0);
  
  for (unsigned int iL = 0 ; iL < NL_central ; iL++) V_lambda_central_splines_tab(iL).deallocate ();

  for (unsigned int iL = 0 ; iL < NL_so ; iL++) V_lambda_so_times_r_splines_tab(iL).deallocate ();

  V_lambda_central_splines_tab.deallocate ();

  V_lambda_so_times_r_splines_tab.deallocate ();

  rotor_angular_momenta.deallocate ();

  moments_of_inertia.deallocate ();

  Nt = 0;
  Nr = 0;
  R = 0.0;
  particle = NO_PARTICLE;
  Z_charge = 0;
  R_charge = 0.0;
  d = 0.0;
  R0 = 0.0;
  beta_2 = 0.0;
  Vo = 0.0;
  Vso = 0.0;
  J = 0.0;
  lmax = 0;
}



void deformed_WS_class::multipole_expansion_tables_alloc_calc ()
{ 
  const double jmax = 0.5 + lmax;

  const int jr_max = make_int (J + jmax);

  const int lambda_max_jr = make_int (2 * jr_max);

  const int lambda_max_j = make_int (2 * jmax);
  
  const int lambda_max = min (lambda_max_jr , lambda_max_j);

  class array<double> V_lambda_central_tab(Nr);

  class array<double> V_lambda_so_times_r_tab(Nr);
  
  class array<double>  t_tab_GL(Nt);
  class array<double> wt_tab_GL(Nt);

  class array<double> YL0_tab_GL(lambda_max+1 , Nt);

  class array<double> sqrt_four_Pi_wt_tab_GL(Nt);

  class array<double> factor_YL0_weights_GL(Nt);

  class array<double> r_tab(Nr);

  class array<double> def_WS_central_tab(Nt , Nr);

  class array<double> def_WS_so_times_r_tab(Nt , Nr);

  // ================================== ================================== //

  const unsigned int NL = lambda_max/2 + 1;

  const double r_step = R/static_cast<double> (Nr - 1);
  
  const double sqrt_four_Pi = 3.5449077018110320546;

  for (unsigned int ir = 0 ; ir < Nr ; ir++) r_tab(ir) = ir*r_step;

  // cos(theta) , w(cos(theta))
  // cos(theta) in [0:1] -> theta in [pi/2:0] -> factor /2 which is removed in the integration of the V_lambda
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , t_tab_GL , wt_tab_GL);

  // PY_lm (cos theta) = Y_lm (theta)
  spherical_harmonics::PYlm_tables_calc (0 , t_tab_GL , YL0_tab_GL);

  V_lambda_central_splines_tab.allocate (NL);
  V_lambda_so_times_r_splines_tab.allocate (NL);

  // constant volume condition: the deformation should not change the nuclear matter volume
  // formula only valid for quadrupole deformation (beta_2) , checked numerically
  // ================================== ================================== //
  // factor sqrt (5/(4pi)) from Y20(t) = factor * P2(cos(theta))
  const double b2_scaled = beta_2 * sqrt (5.0/(4.0*M_PI));
  const double b2_scaled2 = b2_scaled*b2_scaled;
  const double b2_scaled3 = b2_scaled2*b2_scaled;

  // int_0^1 d(cos(theta)) (1 + beta_2 * Y20 (t))^3 (= 1 if beta_2 = 0)
  const double integral = 2.0/35.0 * b2_scaled3 + 3.0/5.0 * b2_scaled2 + 1.0;

  // ((4pi) / (int_0^2pi d(phi) * 2*integral))^1/3
  const double const_vol_cond = cbrt (1.0/integral);

  const double R0_scaled = R0 * const_vol_cond;
  // ================================== ================================== //
	  
  // for each cos (theta_i)
  for (unsigned int it = 0 ; it < Nt ; it++)
    {
      // PY_20 (cos theta_i) = Y_20 (theta_i) , R0 (theta_i)
      // maximal deformation in the z direction , minimal in the (x , y) directions
      const double t = t_tab_GL (it);

      const double Y20_term = spherical_harmonics::PYlm (2 , 0 , t);

      const double R0_theta = R0_scaled * (1.0 + beta_2 * Y20_term);
	  
      // central part == WS (Vso=0 , R0 (t)) = WS (r , t)
      const class WS_analytic_class WSt_nuclear_central (false , d , R0_theta , Vo , 0.0 , particle , Z_charge , R_charge , NADA , NADA);
  
      for (unsigned int ir = 0 ; ir < Nr ; ir++)
	{
	  const double r = r_tab(ir);
 
	  // spin-orbit part (without l.s operators and without 1/r)

	  const double exp_r_minus_R0_theta_over_d = exp ((r - R0) / d);

	  const double f = -1.0 / (1.0 + exp_r_minus_R0_theta_over_d);

	  const double df = exp_r_minus_R0_theta_over_d * f * f / d;

	  const double V_spin_orbit_theta_times_r = -2.0 * Vso * df;

	  def_WS_central_tab (it , ir) = WSt_nuclear_central (r);
	  def_WS_so_times_r_tab (it , ir) = V_spin_orbit_theta_times_r;

	  // print r_cyl , z , V (r , t) for tests
	  // same convention in CC_state.cpp , which is the usual convention in physics (r_cyl = r * sin(theta) , z = r * cos(theta))
	  // rotor along the z axis in the intrinsic frame
	  //cout << "xyz " << r*sqrt (1.0 - cos(theta)*cos(theta)) << " " << r*cos(theta) << " " << def_WS_central_tab (it , ir) << endl;//xyz
	}
  
      //cout << endl;
    }
  
  // ================================== integration over theta and splines ================================== //
 
  for (unsigned int iL = 0 ; iL < NL ; iL++)
    {
      const int lambda = 2*iL;

      // no factor /2 because the integration is for theta in [pi/2:0]
      // Yl0 (t) = sqrt((2l+1)/(4pi)) P_l(cos(theta)) = PYl0(cos(theta))

      for (unsigned int it = 0 ; it < Nt ; it++) factor_YL0_weights_GL(it) = YL0_tab_GL(lambda , it) * wt_tab_GL(it) * sqrt_four_Pi * hat (lambda);

      for (unsigned int ir = 0 ; ir < Nr ; ir++)
	{
	  double UL_central_r = 0.0;
	  double UL_so_times_r_r = 0.0;

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      // sqrt(4pi*(2l+1)) int_0^1 d(cos(theta)) Yl0 (t) WS (r , t) = (2l+1) int_0^1 d(cos(theta)) P_l(cos(theta)) WS (r , t)

	      UL_central_r += def_WS_central_tab (it , ir) * factor_YL0_weights_GL(it);

	      UL_so_times_r_r += def_WS_so_times_r_tab (it , ir) * factor_YL0_weights_GL(it);
	    }

	  V_lambda_central_tab(ir) = UL_central_r;

	  V_lambda_so_times_r_tab(ir) = UL_so_times_r_r;
	}

      V_lambda_central_splines_tab(iL).allocate_calc (r_tab , V_lambda_central_tab);

      V_lambda_so_times_r_splines_tab(iL).allocate_calc (r_tab , V_lambda_so_times_r_tab);
    }
}






// calcule V_total(j' l' j l) = sum_lambda [ V_lambda(r) * <P_lambda_nuclear_tab>(j' l' j l) ] en MeV
double deformed_WS_class::operator () (
				       const int jr , 
				       const int l , 
				       const double j , 
				       const int jrp , 
				       const int lp , 
				       const double jp , 
				       const double r) const
{
  // ( |jr-jr'| <= lambda <= jr+jr' ) and ( |j-j'| <= lambda <= j+j' )
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_j = make_int (abs (jp - j));
  const int lambda_max_j = make_int (j + jp);
  
  const int lambda_min = max (lambda_min_jr , lambda_min_j);
  const int lambda_max = min (lambda_max_jr , lambda_max_j);

  double V_total = 0.0;

  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      if ((lp + l + lambda)%2 == 0)
	{	
	  const int iL = lambda/2;

	  const class splines_class<double> &V_lambda_central_splines = V_lambda_central_splines_tab(iL);

	  const class splines_class<double> &V_lambda_so_times_r_splines = V_lambda_so_times_r_splines_tab(iL);

	  // splines of Vso*r -> divide by r to get Vso

	  const double V_lambda_central = V_lambda_central_splines(r);

	  const double V_lambda_so = (r == 0) ? (0.0) : (V_lambda_so_times_r_splines(r)/r); // The value is r=0 is correct, as only s-wave components exist in r=0, where one has no spin-orbit coupling.

	  // j is half integer
	  // always equal to 1 if jr=jrp=0
	  const double P_lambda_nuclear = P_lambda_nuclear_tab (lambda , jr , l , j , jrp , lp , jp);

	  // 2.l.s := 0.5 * (2.l.s + 2.l'.s') = 0.5 * (j*(j+1) - l*(l+1) - 0.75 + jp*(jp+1) - lp*(lp+1) - 0.75) (symboliquement)
	  V_total += (V_lambda_central + 0.5 * V_lambda_so * (j*(j + 1) - l*(l + 1) - 0.75 + jp*(jp + 1) - lp*(lp + 1) - 0.75)) * P_lambda_nuclear;
	}
    }
  
  return V_total;

  //class WS_class WS_potential_lj (d , R0 , Vo , Vso , NEUTRON , Z_charge , R_charge , l , j);//xyz test
  //return WS_potential_lj (r);
}







void deformed_WS_class::set_moment_of_inertia (
					       const double I_c , 
					       const bool is_I_tab_used_c , 
					       const class array<unsigned int> &new_rotor_angular_momenta , 
					       const class array<double> &new_moments_of_inertia , 
					       const double mass_modif , 
					       const double nucleon_mass_for_calc)
{
  if (I_c == 0.0) error_message_print_abort ("------ deformed_WS_class::set_moment_of_inertia: -I- cannot be zero ------");

  I = I_c;

  is_I_tab_used = is_I_tab_used_c;

  if (is_I_tab_used)
    {
      const unsigned int jr_number = new_rotor_angular_momenta.dimension (0);
      const unsigned int I_number = new_moments_of_inertia.dimension (0);

      if ((jr_number == I_number) && (I_number != 0))
	{
	  rotor_angular_momenta.deallocate ();
	  rotor_angular_momenta.allocate (jr_number);

	  moments_of_inertia.deallocate ();
	  moments_of_inertia.allocate (I_number);

	  for (unsigned int i = 0 ; i < I_number ; i++)
	    {
	      rotor_angular_momenta[i] = new_rotor_angular_momenta[i];

	      // corrective factor due to the mass of the core + particle system

	      const double factor = two_amu_over_hbar_square / kinetic_factor_calc (false , mass_modif , nucleon_mass_for_calc);

	      moments_of_inertia[i] = new_moments_of_inertia[i] * factor;
	    }
	}
      else 
	error_message_print_abort ("------ deformed_WS_class::set_moment_of_inertia: problem with table sizes ------");
    }
}






double deformed_WS_class::get_moment_of_inertia (const unsigned int jr) const
{
  if (jr == 0) return I;

  if (is_I_tab_used)
    {
      double rotor_I = I;

      const unsigned int I_number = moments_of_inertia.dimension (0);

      unsigned int i = 0;

      bool is_found = false;

      while (!is_found && (i < I_number))
	{
	  const unsigned int rotor_jr = rotor_angular_momenta[i];

	  if (jr == rotor_jr)
	    {
	      rotor_I = moments_of_inertia[i];

	      is_found = true;
	    }

	  i++;
	}

      if (!is_found) cout << "------ deformed_WS_class::get_moment_of_inertia: warning: default moment of inertia returned for jr: " << jr << " ------" << endl;

      return rotor_I;
    }
  else
    return I;
}


double used_memory_calc (const class deformed_WS_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.rotor_angular_momenta) + used_memory_calc (T.moments_of_inertia) + used_memory_calc (T.P_lambda_nuclear_tab) + used_memory_calc (T.V_lambda_central_splines_tab) + used_memory_calc (T.V_lambda_so_times_r_splines_tab) - (sizeof (T.rotor_angular_momenta) + sizeof (T.moments_of_inertia) + sizeof (T.P_lambda_nuclear_tab) + sizeof (T.V_lambda_central_splines_tab) + sizeof (T.V_lambda_so_times_r_splines_tab))/1000000.0);
}






//Gaussian function potential: V0.exp (-(r-r0)^2/(2 mu^2)).PL0(polarity,t)
//------------------------------------------------------------------------

//constructors - destructors

Gaussian_potential_class::Gaussian_potential_class () :
  Nt (0), 
  Nr (0),  
  R (0) ,
  V0 (0),
  r0 (0),
  mu (0),
  one_over_two_mu_square (0) ,
  polarity (0),
  J (0),
  lmax (0)
{}


Gaussian_potential_class::Gaussian_potential_class (
						    const unsigned int Nt_c , 
						    const unsigned int Nr_c ,
						    const double R_c , 
						    const double V0_c ,
						    const double r0_c ,
						    const double mu_c ,
						    const int J_c,
						    const int lmax_c,
						    const int polarity_c)
{
  allocate_calc (Nt_c , Nr_c ,  R_c , V0_c , r0_c , mu_c , J_c , lmax_c , polarity_c);
}

Gaussian_potential_class::Gaussian_potential_class (const class Gaussian_potential_class &X)
{
  allocate_fill (X);
}

void Gaussian_potential_class::allocate_calc (
					      const unsigned int Nt_c , 
					      const unsigned int Nr_c ,
					      const double R_c , 
					      const double V0_c ,
					      const double r0_c ,
					      const double mu_c ,
					      const int J_c,
					      const int lmax_c,
					      const int polarity_c)
{
  Nt = Nt_c;
  Nr = Nr_c;
  
  R = R_c;
  
  V0 = V0_c;
  r0 = r0_c;
  mu = mu_c;

  one_over_two_mu_square = 0.5/(mu*mu);

  J = J_c;

  lmax = lmax_c;

  polarity = polarity_c;

  const int lmax_plus_one = lmax + 1;
  
  const int jr_max = J + lmax;
  
  const int lambda_max_jr = 2*jr_max;
  
  const int lambda_max_l = 2*lmax;
  
  const int lambda_max_total = min (lambda_max_jr , lambda_max_l);   
  
  const int jr_max_plus_one = jr_max + 1;
    
  const int lambda_max_total_plus_one = lambda_max_total + 1;
  
  P_lambda_molecular_tab.allocate (lambda_max_total_plus_one , jr_max_plus_one , lmax_plus_one , jr_max_plus_one , lmax_plus_one);

  angular_matrix_elements::P_lambda_rotor_tensor_spinless_part_tab_calc (J , P_lambda_molecular_tab);

  V_lambda_tab_calc ();
}

void Gaussian_potential_class::allocate_fill (const class Gaussian_potential_class &X)
{
  Nt = X.Nt;
  Nr = X.Nr;
  
  R = X.R;
  
  V0 = X.V0;
  r0 = X.r0;
  mu = X.mu;

  one_over_two_mu_square = X.one_over_two_mu_square;
    
  J = X.J;

  lmax = X.lmax;

  polarity = X.polarity;

  P_lambda_molecular_tab.allocate_fill (X.P_lambda_molecular_tab);

  const unsigned int NL = X.V_lambda_splines_tab.dimension (0);

  V_lambda_splines_tab.allocate (NL);

  for (unsigned int iL = 0 ; iL < NL ; iL++) V_lambda_splines_tab(iL).allocate_fill (X.V_lambda_splines_tab(iL));
}

void Gaussian_potential_class::deallocate ()
{
  Nt = 0;
  Nr = 0;
  
  R = 0;
  
  V0 = 0;
  r0 = 0;
  mu = 0;

  one_over_two_mu_square = 0;
  
  J = 0;

  lmax = 0;

  polarity = 0;
  
  V_lambda_splines_tab.deallocate ();

  P_lambda_molecular_tab.deallocate ();
}







//methods

void Gaussian_potential_class::V_lambda_tab_calc ()
{
  const int jr_max = make_int (J + lmax);
  
  const int lambda_max_jr = make_int (2 * jr_max);
  
  const int lambda_max_l = make_int (2 * lmax);
  
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  // ================================== ================================== //

  class array<double> V_lambda_tab(Nr);
  
  class array<double> t_tab_GL(Nt);
  class array<double> wt_tab_GL(Nt);
  
  class array<double> YL0_tab_GL(lambda_max+1,Nt);
  class array<double> sqrt_four_Pi_wt_tab_GL(Nt);
  
  class array<double> factor_YL0_weights_GL(Nt);
  
  class array<double> r_tab(Nr);
  
  class array<double> Gaussian_potential_tab(Nt,Nr);

  // ================================== ================================== //

  const unsigned int NL = lambda_max + 1;

  const double r_step = R/static_cast<double> (Nr - 1);

  const double sqrt_four_Pi = 3.5449077018110320546;

  for (unsigned int ir = 0 ; ir < Nr ; ir++) r_tab(ir) = ir*r_step;

  // cos(theta) , w(cos(theta))
  // cos(theta) in [0:1] -> theta in [pi/2:0] -> factor /2 which is removed in the integration of the V_lambda//xyz
  //Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , t_tab_GL , wt_tab_GL);//xyz
  // cos(theta) in [-1:1] -> t in [pi:0]
  Gauss_Legendre::abscissas_weights_tables_calc (-1.0 , 1.0 , t_tab_GL , wt_tab_GL);

  // PY_lm (cos theta) = Y_lm (theta)
  spherical_harmonics::PYlm_tables_calc (0,t_tab_GL,YL0_tab_GL);

  // for each cos (theta_i)
  for (unsigned int it = 0 ; it < Nt ; it++)
    for (unsigned int ir = 0 ; ir < Nr ; ir++)
      {
	const double r = r_tab(ir);
	  
	const double r_minus_r0 = r - r0;
  
	Gaussian_potential_tab (it , ir) = V0*exp (-r_minus_r0*r_minus_r0*one_over_two_mu_square) * YL0_tab_GL(polarity , it) * sqrt_four_Pi / hat (polarity);	  
      }

  // ================================== integration over theta and splines ================================== //
  V_lambda_splines_tab.allocate (NL);

  for (unsigned int iL = 0 ; iL < NL ; iL++)
    {
      const unsigned int lambda = iL;

      // no factor /2 because the integration is for theta in [pi/2:0]
      // Yl0 (t) = sqrt((2l+1)/(4pi)) P_l(cos(theta)) = PYl0(cos(theta))

      for (unsigned int it = 0 ; it < Nt ; it++) factor_YL0_weights_GL(it) = YL0_tab_GL(lambda,it) * wt_tab_GL(it) * sqrt_four_Pi * hat (lambda) / 2.0;

      for (unsigned int ir = 0 ; ir < Nr ; ir++)
	{
	  double UL_central_r = 0.0;

	  for (unsigned int it = 0 ; it < Nt ; it++) UL_central_r += Gaussian_potential_tab (it , ir) * factor_YL0_weights_GL(it);

	  V_lambda_tab(ir) = UL_central_r;
	}

      V_lambda_splines_tab(iL).allocate_calc (r_tab , V_lambda_tab);
    }
}




double Gaussian_potential_class::operator () (
					      const int jr,
					      const int l,
					      const int jrp,
					      const int lp,
					      const double r) const
{
  const int lambda_min_jr = abs (jrp - jr);
  const int lambda_max_jr = jr + jrp;
  
  const int lambda_min_l = abs (lp - l);
  const int lambda_max_l = l + lp;
  
  const int lambda_min = max (lambda_min_jr , lambda_min_l);
  const int lambda_max = min (lambda_max_jr , lambda_max_l);

  if ((polarity < lambda_min) || (polarity > lambda_max)) return 0.0;
  
  const double P_lambda_molecular = P_lambda_molecular_tab (polarity , jr , l , jrp , lp);

  const double r_minus_r0 = r - r0;
      
  const double V_total = V0*exp (-r_minus_r0*r_minus_r0*one_over_two_mu_square)*P_lambda_molecular;
  
  return V_total;
}

double used_memory_calc (const class Gaussian_potential_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.V_lambda_splines_tab) + used_memory_calc (T.P_lambda_molecular_tab) - (sizeof (T.V_lambda_splines_tab) + sizeof (T.P_lambda_molecular_tab))/1000000.0);
}









// Class for P_lambda in the static case , depending on lambda , l , j
// -------------------------------------------------------------------

P_lambda_static_class::P_lambda_static_class () {}

P_lambda_static_class::P_lambda_static_class (const double K , const int lmax)
{
  allocate_calc (K , lmax);
}

P_lambda_static_class::P_lambda_static_class (const class P_lambda_static_class &X)
{
  allocate_fill (X);
}

// methods

void P_lambda_static_class::indices_dimension_table_calc (const double K , const int lmax , unsigned int &dimension_table)
{
  indices = OUT_OF_RANGE;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      // |l-s| <= j <= l+s and K <= j

      const double jmin_l = abs (0.5 - l);
      const double jmax_l = 0.5 + l;

      const unsigned int N_j = make_int (jmax_l - jmin_l + 1);

      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  // |l'-s| <= j' <= l'+s and K <= j'

	  const double jp_min_lp = abs (0.5 - lp);
	  const double jp_max_lp = 0.5 + lp;

	  const unsigned int N_jp = make_int (jp_max_lp - jp_min_lp + 1);

	  for (unsigned int i_j = 0 ; i_j < N_j ; i_j ++)
	    {
	      const double j = jmin_l + i_j;

	      if (rint (K - j) > 0.0) continue;
	      
	      const unsigned int j_index = (l < j) ? (0) : (1);

	      for (unsigned int i_jp = 0 ; i_jp < N_jp ; i_jp ++)
		{
		  const double jp = jp_min_lp + i_jp;
		  
		  if (rint (K - jp) > 0.0) continue;
	      
		  const unsigned int jp_index = (lp < jp) ? (0) : (1);

		  const int lambda_min = make_int (abs (jp - j));
		  const int lambda_max = make_int (j + jp);

		  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		    {
		      if ((lp + l + lambda)%2 == 0) indices(lambda , l , j_index , lp , jp_index) = dimension_table++;
		    }
		}
	    }
	}
    }
}


void P_lambda_static_class::table_calc (const double K , const int lmax)
{
  table = 0.0;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      // |l-s| <= j <= l+s and K <= j

      const double jmin_l = abs (0.5 - l);
      const double jmax_l = 0.5 + l;
      
      const unsigned int N_j = make_int (jmax_l - jmin_l + 1);

      for (int lp = 0 ; lp <= lmax ; lp++)
	{
	  // |l'-s| <= j' <= l'+s and K <= j'
	  
	  const double jp_min_lp = abs (0.5 - lp);
	  const double jp_max_lp = 0.5 + lp;
	  
	  const unsigned int N_jp = make_int (jp_max_lp - jp_min_lp + 1);

	  for (unsigned int i_j = 0 ; i_j < N_j ; i_j ++)
	    {
	      const double j = jmin_l + i_j;
	      
	      if (rint (K - j) > 0.0) continue;
	      
	      const unsigned int j_index = (l < j) ? (0) : (1);

	      for (unsigned int i_jp = 0 ; i_jp < N_jp ; i_jp ++)
		{
		  const double jp = jp_min_lp + i_jp;
		  
		  if (rint (K - jp) > 0.0) continue;
	      
		  const unsigned int jp_index = (lp < jp) ? (0) : (1);

		  const int lambda_min = make_int (abs (jp - j));
		  const int lambda_max = make_int (j + jp);
		
		  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		    {			      
		      if ((lp + l + lambda)%2 == 0) table(indices(lambda , l , j_index , lp , jp_index)) = angular_matrix_elements::P_lambda_static_calc (lambda , l , j , lp , jp , K);
		    }
		}
	    }
	}
    }
}




void P_lambda_static_class::allocate_calc (const double K , const int lmax)
{
  const double jmax = 0.5 + lmax;

  const int lambda_max = make_int (2 * jmax);
    
  const int lmax_plus_one = lmax + 1;

  const int lambda_max_plus_one = lambda_max + 1;

  unsigned int dimension_table = 0;

  indices.allocate (lambda_max_plus_one , lmax_plus_one , 2 , lmax_plus_one , 2);

  indices_dimension_table_calc (K , lmax , dimension_table);
  
  table.allocate (dimension_table);

  table_calc (K , lmax);
}

void P_lambda_static_class::allocate_fill (const class P_lambda_static_class &X)
{
  indices.allocate_fill (X.indices);

  table.allocate_fill (X.table);
}

void P_lambda_static_class::deallocate ()
{
  indices.deallocate ();

  table.deallocate ();
}

double & P_lambda_static_class::operator [] (const unsigned int i) const
{
  return table[i];
}

unsigned int P_lambda_static_class::index_determine (
						     const int lambda , 
						     const int l , 
						     const double j , 
						     const int lp , 
						     const double jp) const
{    
  const unsigned int j_index = (l < j) ? (0) : (1);
  
  const unsigned int jp_index = (lp < jp) ? (0) : (1);

  const unsigned int index = indices(lambda , l , j_index , lp , jp_index);

  return index;
}

double & P_lambda_static_class::operator () (
					     const int lambda , 
					     const int l , 
					     const double j , 
					     const int lp , 
					     const double jp) const
{  
  const unsigned int index = index_determine(lambda , l , j , lp , jp);

  return table(index);
}



double used_memory_calc (const class P_lambda_static_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.indices) + used_memory_calc (T.table) - (sizeof (T.indices) + sizeof (T.table))/1000000.0);
}



// Static deformed WS potential.
// -----------------------------
// One uses a static nucleus, i.e. there is no rotor and K is a good quantum number
// Spin-orbit and Coulomb potentials are sphericals.

// constructors - destructors

deformed_WS_static_class::deformed_WS_static_class () :
  Nt (0) ,
  Nr (0) ,
  R (0.0) ,
  particle (NO_PARTICLE) ,
  Z_charge (0) ,
  R_charge (0.0) ,
  d (0.0) ,
  R0 (0.0) ,
  beta_2 (0.0) ,
  Vo (0.0) ,
  Vso (0.0) ,
  K (0.0) ,
  lmax (0)
{}

deformed_WS_static_class::deformed_WS_static_class (
						    const unsigned int Nt_c , 
						    const unsigned int Nr_c , 
						    const double R_c , 
						    const enum particle_type particle_c , 
						    const int Z_charge_c , 
						    const double R_charge_c , 
						    const double d_c , 
						    const double R0_c , 
						    const double beta_2_c , 
						    const double Vo_c , 
						    const double Vso_c , 
						    const double K_c , 
						    const int lmax_c)
{
  allocate_calc (Nt_c , Nr_c , R_c , particle_c , Z_charge_c , R_charge_c , d_c , R0_c , beta_2_c , Vo_c , Vso_c , K_c , lmax_c);
}







deformed_WS_static_class::deformed_WS_static_class (const class deformed_WS_static_class &X)
{
  allocate_fill (X);
}








// methods


void deformed_WS_static_class::allocate_calc (
					      const unsigned int Nt_c , 
					      const unsigned int Nr_c , 
					      const double R_c , 
					      const enum particle_type particle_c , 
					      const int Z_charge_c , 
					      const double R_charge_c , 
					      const double d_c , 
					      const double R0_c , 
					      const double beta_2_c , 
					      const double Vo_c , 
					      const double Vso_c , 
					      const double K_c , 
					      const int lmax_c)
{ 
  Nt = Nt_c; 
  Nr = Nr_c; 
  R = R_c; 
  particle = particle_c; 
  Z_charge = Z_charge_c; 
  R_charge = R_charge_c; 
  d = d_c; 
  R0 = R0_c; 
  beta_2 = beta_2_c; 
  Vo = Vo_c; 
  Vso = Vso_c; 
  K = K_c; 
  lmax = lmax_c;
  
  if (particle == ELECTRON) error_message_print_abort ("No static deformed WS potential for electron (1)");

  // calculation of P_lambda MEs
  // ================================== ================================== //

  P_lambda_nuclear_tab.allocate_calc (K , lmax);

  // calculation of multipole expansion tables
  // ==================================================================== //

  multipole_expansion_tables_alloc_calc ();  
}







void deformed_WS_static_class::allocate_fill (const class deformed_WS_static_class &X)
{
  Nt = X.Nt; 
  Nr = X.Nr; 
  R = X.R; 
  particle = X.particle; 
  Z_charge = X.Z_charge; 
  R_charge = X.R_charge; 
  d = X.d; 
  R0 = X.R0; 
  beta_2 = X.beta_2; 
  Vo = X.Vo; 
  Vso = X.Vso; 
  K = X.K; 
  lmax = X.lmax;

  if (particle == ELECTRON) error_message_print_abort ("No deformed WS potential for electron (2)");

  P_lambda_nuclear_tab.allocate_fill (X.P_lambda_nuclear_tab);

  const unsigned int NL_central = X.V_lambda_central_splines_tab.dimension (0);
  const unsigned int NL_so = X.V_lambda_so_times_r_splines_tab.dimension (0);

  V_lambda_central_splines_tab.allocate (NL_central);
  V_lambda_so_times_r_splines_tab.allocate (NL_so);

  for (unsigned int iL = 0 ; iL < NL_central ; iL++) V_lambda_central_splines_tab(iL).allocate_fill (X.V_lambda_central_splines_tab(iL));

  for (unsigned int iL = 0 ; iL < NL_so ; iL++) V_lambda_so_times_r_splines_tab(iL).allocate_fill (X.V_lambda_so_times_r_splines_tab(iL));
}






void deformed_WS_static_class::deallocate ()
{
  P_lambda_nuclear_tab.deallocate ();
  
  const unsigned int NL_central = V_lambda_central_splines_tab.dimension (0);

  const unsigned int NL_so = V_lambda_so_times_r_splines_tab.dimension (0);
  
  for (unsigned int iL = 0 ; iL < NL_central ; iL++) V_lambda_central_splines_tab(iL).deallocate ();

  for (unsigned int iL = 0 ; iL < NL_so ; iL++) V_lambda_so_times_r_splines_tab(iL).deallocate ();

  V_lambda_central_splines_tab.deallocate ();

  V_lambda_so_times_r_splines_tab.deallocate ();

  Nt = 0;
  Nr = 0;
  R = 0.0;
  particle = NO_PARTICLE;
  Z_charge = 0;
  R_charge = 0.0;
  d = 0.0;
  R0 = 0.0;
  beta_2 = 0.0;
  Vo = 0.0;
  Vso = 0.0;
  K = 0.0;
  lmax = 0;
}



void deformed_WS_static_class::multipole_expansion_tables_alloc_calc ()
{ 
  const double jmax = 0.5 + lmax;

  const int lambda_max = make_int (2 * jmax);
  
  class array<double> V_lambda_central_tab(Nr);

  class array<double> V_lambda_so_times_r_tab(Nr);
  
  class array<double>  t_tab_GL(Nt);
  class array<double> wt_tab_GL(Nt);

  class array<double> YL0_tab_GL(lambda_max+1 , Nt);

  class array<double> sqrt_four_Pi_wt_tab_GL(Nt);

  class array<double> factor_YL0_weights_GL(Nt);

  class array<double> r_tab(Nr);

  class array<double> def_WS_central_tab(Nt , Nr);

  class array<double> def_WS_so_times_r_tab(Nt , Nr);

  // ================================== ================================== //

  const unsigned int NL = lambda_max/2 + 1;

  const double r_step = R/static_cast<double> (Nr - 1);
  
  const double sqrt_four_Pi = 3.5449077018110320546;

  for (unsigned int ir = 0 ; ir < Nr ; ir++) r_tab(ir) = ir*r_step;

  // cos(theta) , w(cos(theta))
  // cos(theta) in [0:1] -> theta in [pi/2:0] -> factor /2 which is removed in the integration of the V_lambda
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , 1.0 , t_tab_GL , wt_tab_GL);

  // PY_lm (cos theta) = Y_lm (theta)
  spherical_harmonics::PYlm_tables_calc (0 , t_tab_GL , YL0_tab_GL);

  V_lambda_central_splines_tab.allocate (NL);
  V_lambda_so_times_r_splines_tab.allocate (NL);

  // constant volume condition: the deformation should not change the nuclear matter volume
  // formula only valid for quadrupole deformation (beta_2) , checked numerically
  // ================================== ================================== //
  // factor sqrt (5/(4pi)) from Y20(t) = factor * P2(cos(theta))
  const double b2_scaled = beta_2 * sqrt (5.0/(4.0*M_PI));
  const double b2_scaled2 = b2_scaled*b2_scaled;
  const double b2_scaled3 = b2_scaled2*b2_scaled;

  // int_0^1 d(cos(theta)) (1 + beta_2 * Y20 (t))^3 (= 1 if beta_2 = 0)
  const double integral = 2.0/35.0 * b2_scaled3 + 3.0/5.0 * b2_scaled2 + 1.0;

  // ((4pi) / (int_0^2pi d(phi) * 2*integral))^1/3
  const double const_vol_cond = cbrt (1.0/integral);

  const double R0_scaled = R0 * const_vol_cond;
  // ================================== ================================== //
	  
  // for each cos (theta_i)
  for (unsigned int it = 0 ; it < Nt ; it++)
    {
      // PY_20 (cos theta_i) = Y_20 (theta_i) , R0 (theta_i)
      // maximal deformation in the z direction , minimal in the (x , y) directions
      const double t = t_tab_GL (it);

      const double Y20_term = spherical_harmonics::PYlm (2 , 0 , t);

      const double R0_theta = R0_scaled * (1.0 + beta_2 * Y20_term);
	  
      // central part == WS (Vso=0 , R0 (t)) = WS (r , t)
      const class WS_analytic_class WSt_nuclear_central (false , d , R0_theta , Vo , 0.0 , particle , Z_charge , R_charge , NADA , NADA);
  
      for (unsigned int ir = 0 ; ir < Nr ; ir++)
	{
	  const double r = r_tab(ir);
 
	  // spin-orbit part (without l.s operators and without 1/r)

	  const double exp_r_minus_R0_theta_over_d = exp ((r - R0) / d);

	  const double f = -1.0 / (1.0 + exp_r_minus_R0_theta_over_d);

	  const double df = exp_r_minus_R0_theta_over_d * f * f / d;

	  const double V_spin_orbit_theta_times_r = -2.0 * Vso * df;

	  def_WS_central_tab (it , ir) = WSt_nuclear_central (r);
	  def_WS_so_times_r_tab (it , ir) = V_spin_orbit_theta_times_r;

	  // print r_cyl , z , V (r , t) for tests
	  // same convention in CC_state.cpp , which is the usual convention in physics (r_cyl = r * sin(theta) , z = r * cos(theta))
	  // rotor along the z axis in the intrinsic frame
	  //cout << "xyz " << r*sqrt (1.0 - cos(theta)*cos(theta)) << " " << r*cos(theta) << " " << def_WS_central_tab (it , ir) << endl;//xyz
	}
  
      //cout << endl;
    }
  
  // ================================== integration over theta and splines ================================== //
 
  for (unsigned int iL = 0 ; iL < NL ; iL++)
    {
      const int lambda = 2*iL;

      // no factor /2 because the integration is for theta in [pi/2:0]
      // Yl0 (t) = sqrt((2l+1)/(4pi)) P_l(cos(theta)) = PYl0(cos(theta))

      for (unsigned int it = 0 ; it < Nt ; it++) factor_YL0_weights_GL(it) = YL0_tab_GL(lambda , it) * wt_tab_GL(it) * sqrt_four_Pi * hat (lambda);

      for (unsigned int ir = 0 ; ir < Nr ; ir++)
	{
	  double UL_central_r = 0.0;
	  double UL_so_times_r_r = 0.0;

	  for (unsigned int it = 0 ; it < Nt ; it++)
	    {
	      // sqrt(4pi*(2l+1)) int_0^1 d(cos(theta)) Yl0 (t) WS (r , t) = (2l+1) int_0^1 d(cos(theta)) P_l(cos(theta)) WS (r , t)

	      UL_central_r += def_WS_central_tab (it , ir) * factor_YL0_weights_GL(it);

	      UL_so_times_r_r += def_WS_so_times_r_tab (it , ir) * factor_YL0_weights_GL(it);
	    }

	  V_lambda_central_tab(ir) = UL_central_r;

	  V_lambda_so_times_r_tab(ir) = UL_so_times_r_r;
	}

      V_lambda_central_splines_tab(iL).allocate_calc (r_tab , V_lambda_central_tab);

      V_lambda_so_times_r_splines_tab(iL).allocate_calc (r_tab , V_lambda_so_times_r_tab);
    }
}






// calcule V_total(j' l' j l) = sum_lambda [ V_lambda(r) * <P_lambda_nuclear_tab>(j' l' j l) ] en MeV
double deformed_WS_static_class::operator () (
					      const int l , 
					      const double j , 
					      const int lp , 
					      const double jp , 
					      const double r) const
{
  // ( |j-j'| <= lambda <= j+j' )

  const int lambda_min = make_int (abs (jp - j));
  const int lambda_max = make_int (j + jp);

  double V_total = 0.0;

  for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
    {
      if ((lp + l + lambda)%2 == 0)
	{	
	  const int iL = lambda/2;

	  const class splines_class<double> &V_lambda_central_splines = V_lambda_central_splines_tab(iL);

	  const class splines_class<double> &V_lambda_so_times_r_splines = V_lambda_so_times_r_splines_tab(iL);

	  // splines of Vso*r -> divide by r to get Vso

	  const double V_lambda_central = V_lambda_central_splines(r);

	  const double V_lambda_so = (r == 0) ? (0.0) : (V_lambda_so_times_r_splines(r)/r); // The value is r=0 is correct, as only s-wave components exist in r=0, where one has no spin-orbit coupling.

	  // j is half integer
	  const double P_lambda_nuclear = P_lambda_nuclear_tab (lambda , l , j , lp , jp);

	  // 2.l.s := 0.5 * (2.l.s + 2.l'.s') = 0.5 * (j*(j+1) - l*(l+1) - 0.75 + jp*(jp+1) - lp*(lp+1) - 0.75) (symboliquement)
	  V_total += (V_lambda_central + 0.5 * V_lambda_so * (j*(j + 1) - l*(l + 1) - 0.75 + jp*(jp + 1) - lp*(lp + 1) - 0.75)) * P_lambda_nuclear;
	}
    }
  
  return V_total;

  //class WS_class WS_potential_lj (d , R0 , Vo , Vso , NEUTRON , Z_charge , R_charge , l , j);//xyz test
  //return WS_potential_lj (r);
}



double used_memory_calc (const class deformed_WS_static_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.P_lambda_nuclear_tab) + used_memory_calc (T.V_lambda_central_splines_tab) + used_memory_calc (T.V_lambda_so_times_r_splines_tab) - (sizeof (T.P_lambda_nuclear_tab) + sizeof (T.V_lambda_central_splines_tab) + sizeof (T.V_lambda_so_times_r_splines_tab))/1000000.0);
}














potentials_effective_mass::potentials_effective_mass ()
{
  initialize_constants (NO_POTENTIAL , 0.0 , 0.0 , 0.0 , 0 , 0.0 , 0.0 , 0.0 , 0.0);
}

potentials_effective_mass::potentials_effective_mass (const class potentials_effective_mass &X)
{
  allocate_fill (X);
}


void potentials_effective_mass::initialize_constants (
						      const enum potential_type potential_c , 
						      const double kinetic_factor_c , 
						      const int jr_c , 
						      const complex<double> &l_c , 
						      const int Z_charge_c , 
						      const double j_c , 
						      const complex<double> &k_c , 
						      const complex<double> &eta_c,
						      const complex<double> &lambda_c)
{
  potential = potential_c;

  kinetic_factor = kinetic_factor_c;
    
  jr = jr_c;

  l = l_c;

  ll_plus_one = l*(l + 1.0);

  l_integer = make_int (real (l));

  Z_charge = Z_charge_c;

  j = j_c;

  k = k_c;

  E = k*k/kinetic_factor;

  eta = eta_c;
  
  two_eta = 2.0*eta;

  lambda = lambda_c;
}



void potentials_effective_mass::allocate_fill (const class potentials_effective_mass &X)
{
  potential = X.potential;

  jr = X.jr;

  l_integer = X.l_integer;

  Z_charge = X.Z_charge;

  j = X.j;

  kinetic_factor = X.kinetic_factor; 
  
  lambda = X.lambda;

  l = X.l;
  k = X.k;
  E = X.E;

  eta = X.eta; 

  two_eta = X.two_eta;
  
  KKNN_potential.initialize (X.KKNN_potential); 

  WS_potential.initialize (X.WS_potential); 

  WS_analytic_potential.initialize (X.WS_analytic_potential); 

  WS_complex_potential.initialize (X.WS_complex_potential); 

  WS_complex_analytic_potential.initialize (X.WS_complex_analytic_potential); 

  PTG_potential.initialize (X.PTG_potential);
  
  modified_PTG_potential.initialize (X.modified_PTG_potential);
  
  trivially_equivalent_potential.allocate_fill (X.trivially_equivalent_potential); 

  source.allocate_fill (X.source); 

  V_interpolated.allocate_fill (X.V_interpolated);
  
  V_interpolated_complex.allocate_fill (X.V_interpolated_complex); 

  V_effective_mass_scaled.allocate_fill (X.V_effective_mass_scaled); 

  V_effective_mass_unscaled.allocate_fill (X.V_effective_mass_unscaled); 

  W_full_effective_mass.allocate_fill (X.W_full_effective_mass); 

  full_effective_mass.allocate_fill (X.full_effective_mass);
  
  const unsigned int N_channels = X.CC_trivially_equivalent_potential_tab.dimension (0);
									 
  if (N_channels > 0)
    {
      CC_trivially_equivalent_potential_tab.allocate (N_channels , N_channels);

      CC_source_tab.allocate (N_channels , N_channels);

      for (unsigned int i = 0 ; i < N_channels ; i++)
	for (unsigned int j = 0 ; j < N_channels ; j++)
	  {
	    CC_trivially_equivalent_potential_tab(i,j).allocate_fill (X.CC_trivially_equivalent_potential_tab(i,j));

	    CC_source_tab(i,j).allocate_fill (X.CC_source_tab(i,j));
	  }
    }
    
  V_dipolar.allocate_fill (X.V_dipolar);
  
  V_quadrupolar.allocate_fill (X.V_quadrupolar);
  
  V_deformed_WS.allocate_fill (X.V_deformed_WS);
  
  V_deformed_WS_static.allocate_fill (X.V_deformed_WS_static);  

  V_Gaussian.allocate_fill (X.V_Gaussian);
}


// Potential
// ---------
// Calculation of the integrated potential at r.
//
// Variables:
// ----------
// WS : WS class giving the Woods-Saxon potential in r with a uniform charged sphere Coulomb potential.
// COMPLEX_WS : WS class giving the complex Woods-Saxon potential in r with a uniform charged sphere Coulomb potential.
// WS_ANALYTIC : WS class giving the Woods-Saxon potential in r with an analytic Coulomb potential.
// PTG_POTENTIAL : PTG class giving the Poschl-Teller-Ginocchio potential in r.
// MODIFIED_PTG_POTENTIAL : modified_PTG class giving the modified Poschl-Teller-Ginocchio potential in r (see above for definition).
// HF : HF potential without effective mass.
// MSDHF : MSDHF potential without effective mass.
// EFFECTIVE_MASS_POTENTIAL : potential with effective mass. It is unscaled here as the potential is used for HO diagonalization in particular.
// EFFECTIVE_MASS_POTENTIAL : potential with effective mass behaving like a PTG potential. It is unscaled here as the potential is used for HO diagonalization in particular.
// KKNN : KKNN potential.
// INTERPOLATED_POTENTIAL : potential given by a set of points.
// DIPOLAR: dipolar potential for molecules in the rotor model
// QUADRUPOLAR: quadrupolar potential for molecules in the rotor model
// DEFORMED_WS: deformed potential for nuclei in the rotor model 
// DEFORMED_WS_STATIC: deformed potential for nuclei in a static framework (no core rotation)

complex<double> potentials_effective_mass::potential_calc (const double r) const
{  
  switch (potential)
    {
    case KKNN:                              return KKNN_potential(r);  
    case WS:                                return WS_potential(r);
    case WS_ANALYTIC:                       return WS_analytic_potential(r);
    case WS_ANALYTIC_PARTIAL_DERIVATIVE:    return WS_analytic_potential(r);
    case COMPLEX_WS:                        return WS_complex_potential(r);
    case COMPLEX_WS_ANALYTIC:               return WS_complex_analytic_potential(r);
    case PTG_POTENTIAL:                     return PTG_potential(r);
    case MODIFIED_PTG_POTENTIAL:            return modified_PTG_potential(r);
    case HF:                                return trivially_equivalent_potential(r);
    case MSDHF:                             return trivially_equivalent_potential(r);
    case EFFECTIVE_MASS_POTENTIAL:          return V_effective_mass_unscaled(r);
    case EFFECTIVE_MASS_POTENTIAL_PTG_LIKE: return V_effective_mass_unscaled(r);
    case INTERPOLATED_POTENTIAL:            return V_interpolated(r);
    case COMPLEX_INTERPOLATED_POTENTIAL:    return V_interpolated_complex(r);
    case DIPOLAR:                           return V_dipolar(jr , l_integer , jr , l_integer , r);
    case QUADRUPOLAR:                       return V_quadrupolar(jr , l_integer , jr , l_integer , r);
    case DEFORMED_WS:                       return V_deformed_WS(jr , l_integer , j , jr , l_integer , j , r);
    case DEFORMED_WS_STATIC:                return V_deformed_WS_static(l_integer , j , l_integer , j , r);
    case GAUSSIAN:                          return V_Gaussian(jr , l_integer , jr , l_integer , r);

    default: error_message_print_abort ("Potential " + make_string<enum potential_type> (potential) + " not available in potentials_effective_mass::potential_calc");
    }

  return NADA;
}



// Calculation of F(z , u(z)) in u''(z) = F(z , u(z)) : 
// --------------------------------------------------
// function :
// ----------
// COULOMB_POTENTIAL : F(z , u(z))=(l(l+1)/(z^2) + 2.eta/z - 1).u(z)
//
// In all the following cases , one must have z = real (z) , written r.
// 
// EFFECTIVE_MASS_POTENTIAL : F(r , u(r)) = (l(l+1)/(r^2) + full_effective_mass(r).(V_scaled(r) - E).u(r)
//                            The potential has to be scaled here for the direct integration.
//
// EFFECTIVE_MASS_POTENTIAL_PTG_LIKE : F(r , u(r)) = (l(l+1)/(r^2) + full_effective_mass(r).(V_scaled(r) - E).u(r)
//                                     where F(r , u(r)) = -E.u(r) for r -> +oo, hence behaves as a PTG potential with effective mass.
//                                     The potential has to be scaled here for the direct integration.
//
// HF or MSDHF : F(r , u(r))=(l(l+1)/(r^2) + V(r) - E).u(r) + S(r) , 
//      V(r) is the quasi-equivalent potential of the finite range non local HF potential.
//      S(r) is the source coming from the removal of singularities 
//           of the triviallyially equivalent potential of the finite range non local HF potential.
//
// SOURCE : the formula is the same as HF , but here the source S(r) also contains a source
//          contained in the non-local equation , making the equation inhomogenous.
//
// WS_ANALYTIC_PARTIAL_DERIVATIVE: F(r , u(r))=(l(l+1)/(r^2) + V(r) - E).du(r)/dx + S(r) , 
//                                 V(r) is a Woods-Saxon potential and an analytic Coulomb potential.
//
// GAUSSIAN_POTENTIAL: F(r , u(r))=(l(l+1)/(r^2) + V(r) - E).du(r)/dx , 
//                     V(r) is a Gaussian potential of the form V(r)=(2pi)^(-3/2) c^(-3)*exp(-(r-b)^2/2 c^2)
// 
// Other cases: F(r , u(r))=(l(l+1)/(r^2) + V(r) - E).u(r) , 
//              where V(r) is a nuclear potential:
//              _ without Coulomb part (PTG_POTENTIAL)
//              _ with a Coulomb potential of uniformly charged sphere (WS, COMPLEX_WS or MODIFIED_PTG_POTENTIAL)
//              _ with an analytic Coulomb potential (other nuclear potentials)
//              or is a dipolar or quadrupolar potential for molecules (DIPOLAR or QUADRUPOLAR)
//
// Variables:
// ----------
// z : parameter of the wave function.
// u : discretized wave function in z.
// r : real(z). If potential is not COULOMB , z=r.
// real_centrifugal : If potential is COULOMB , it is not needed and put to 0.0 for simplicity.
//                    If potential is not COULOMB , it is 0 if l=0 , and l(l+1)/(r^2) if l > 0.
// one_over_z : 1.0/z
// WS , PTG , Veq , effective_mass : type of potential and effective mass one integrates.

complex<double> potentials_effective_mass::F_z_u (const complex<double> &z , const complex<double> &u) const
{
  if (potential == COULOMB_POTENTIAL)
    {
      if (l == 0)
	{
	  const complex<double> F_z_u_value = (two_eta/z - 1.0)*u;

	  return F_z_u_value;
	}

      const complex<double> one_over_z = 1.0/z;

      const complex<double> F_z_u_value = ((ll_plus_one*one_over_z + two_eta)*one_over_z - 1.0)*u;

      return F_z_u_value;
    }

  const double r = real (z);

  const double real_centrifugal = (l != 0) ? (real (ll_plus_one)/(r*r)) : (0.0);

  if (is_there_effective_mass_determine (potential))
    {
      const complex<double> F_z_u_value = (real_centrifugal + full_effective_mass(r)*(V_effective_mass_scaled(r) - E))*u;

      return F_z_u_value;
    }

  const complex<double> Vr = potential_calc (r);

  if ((potential == HF) || (potential == MSDHF) || (potential == SOURCE) || (potential == WS_ANALYTIC_PARTIAL_DERIVATIVE))
    {
      const complex<double> F_z_u_value = (real_centrifugal + kinetic_factor*(Vr - E))*u + kinetic_factor*source(r);

      return F_z_u_value;
    }

  const complex<double> F_z_u_value = (real_centrifugal + kinetic_factor*(Vr - E))*u;

  return F_z_u_value;
}




complex<double> potentials_effective_mass_F_z_u (const void * ptr , const complex<double> &r , const complex<double> &u)
{
  const class potentials_effective_mass &T = *(static_cast<const class potentials_effective_mass *> (ptr));

  return T.F_z_u (r , u);
}



double used_memory_calc (const class potentials_effective_mass &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.KKNN_potential) + used_memory_calc (T.WS_potential) + used_memory_calc (T.WS_analytic_potential) + used_memory_calc (T.WS_complex_potential) + used_memory_calc (T.WS_complex_analytic_potential) + used_memory_calc (T.PTG_potential) + used_memory_calc (T.trivially_equivalent_potential) + used_memory_calc (T.source) + used_memory_calc (T.V_interpolated) + used_memory_calc (T.V_interpolated_complex) + used_memory_calc (T.V_effective_mass_scaled) + used_memory_calc (T.V_effective_mass_unscaled) + used_memory_calc (T.full_effective_mass) + used_memory_calc (T.W_full_effective_mass) + used_memory_calc (T.CC_trivially_equivalent_potential_tab) + used_memory_calc (T.CC_source_tab) + used_memory_calc (T.V_dipolar) + used_memory_calc (T.V_quadrupolar) + used_memory_calc (T.V_deformed_WS) + used_memory_calc (T.V_deformed_WS_static) + used_memory_calc (T.V_Gaussian) - (sizeof (T.KKNN_potential) + sizeof (T.WS_potential) + sizeof (T.WS_analytic_potential) + sizeof (T.WS_complex_potential) + sizeof (T.WS_complex_analytic_potential) + sizeof (T.PTG_potential) + sizeof (T.trivially_equivalent_potential) + sizeof (T.source) + sizeof (T.V_interpolated) + sizeof (T.V_interpolated_complex) + sizeof (T.V_effective_mass_scaled) + sizeof (T.V_effective_mass_unscaled) + sizeof (T.full_effective_mass) + sizeof (T.W_full_effective_mass) + sizeof (T.CC_trivially_equivalent_potential_tab) + sizeof (T.CC_source_tab) + sizeof (T.V_dipolar) + sizeof (T.V_quadrupolar) + sizeof (T.V_deformed_WS) + sizeof (T.V_deformed_WS_static) + sizeof (T.V_Gaussian))/1000000.0);
}



// Potential barrier and radius
//-----------------------------
// Calculation of the potential barrier and radius.
// For barrier , one starts at R , and one decreases r until the real part of the potential reaches a maximum.
// If l=0 or if there is no charge or if no barrier is found , V_barrier = 0 MeV and r_barrier = R are returned.
//
// Variables:
// ----------
// ll_plus_one_over_kinetic_factor : l(l + 1)/kinetic_factor
// Rmax_for_fit: maximal radius considered in case no barrier is found. It is fixed at 10 fm.
// r_barrier : value of the barrier radius. This value is returned in r_barrier_calc.
// V_barrier:  value of the potential at the height of the barrier in MeV. This value is returned in V_barrier_calc.
// is_there_a_barrier : false if there is no barrier , true if there is.
// barrier_to_consider: false if l=0 or if there is no charge , true if not.
// r , Vr , r_bef , Vr_bef , r_aft , Vr_aft : radius and potential at r , same in r - step_bef_R_big , same in r + step_bef_R_big.
// V_total_r , V_total_r_bef , V_total_r_aft : radius and potential with the centrifugal part at r, r_bef, r_aft



void potential_barrier::barrier_values_calc (
					     const class array<double> &r_bef_R_tab_big ,
					     const enum particle_type particle ,
					     const class potentials_effective_mass &T , 			    
					     double &r_barrier ,		    
					     double &V_barrier)
{
  const unsigned int N_bef_R_big = r_bef_R_tab_big.dimension (0);
  
  if (N_bef_R_big <= 1) error_message_print_abort ("One must have N_bef_R_big >= 2 in potential_barrier::barrier_values_calc");

  const enum potential_type potential = T.get_potential ();
  
  const int Z_charge = T.get_Z_charge ();
  
  const int l = make_int (real (T.get_l ()));
  
  const bool barrier_to_consider = (!is_it_PTG_like_determine (potential) && ((l > 0) || ((particle == PROTON) && (Z_charge != 0))));
  
  const unsigned int N_bef_R_big_minus_one = N_bef_R_big - 1;
  
  r_barrier = r_bef_R_tab_big(N_bef_R_big_minus_one);
  
  V_barrier = 0.0;

  if (!barrier_to_consider) return;    
  
  const unsigned int N_bef_R_big_minus_two = N_bef_R_big - 2;
  
  const double step_bef_R_big = r_bef_R_tab_big(1);
    
  const double kinetic_factor = T.get_kinetic_factor ();
  
  const double ll_plus_one_over_kinetic_factor = l*(l + 1)/kinetic_factor;

  bool is_there_a_barrier = false;
  
  for (unsigned int i = N_bef_R_big_minus_two ; i >= 2 ; i--)
    { 
      const double r = r_bef_R_tab_big(i);

      const double Vr = real (T.potential_calc (r));

      const double r_bef = r - step_bef_R_big , Vr_bef = real (T.potential_calc (r_bef));
      const double r_aft = r + step_bef_R_big , Vr_aft = real (T.potential_calc (r_aft));

      const double V_total_r = Vr + ll_plus_one_over_kinetic_factor/(r*r);

      const double V_total_r_bef = Vr_bef + ll_plus_one_over_kinetic_factor/(r_bef*r_bef);
      const double V_total_r_aft = Vr_aft + ll_plus_one_over_kinetic_factor/(r_aft*r_aft);
      
      if (!is_there_a_barrier && (V_total_r > V_total_r_bef) && (V_total_r > V_total_r_aft))
	{
	  is_there_a_barrier = true;

	  r_barrier = r;
	  
	  V_barrier = V_total_r;
	}
    }
  
  if (is_there_a_barrier)
    {
      const double two_sqrt_precision = 2.0*sqrt_precision;
      
      const double two_ll_plus_one_over_kinetic_factor = 2.0*ll_plus_one_over_kinetic_factor;      
      const double six_ll_plus_one_over_kinetic_factor = 6.0*ll_plus_one_over_kinetic_factor;
      
      double test = INFINITE;
	  
      while (test > precision)
	{
	  const double r_barrier_square = r_barrier*r_barrier;
	  
	  const double Vr = real (T.potential_calc (r_barrier));
	  
	  const double r_barrier_plus  = r_barrier + sqrt_precision;
	  const double r_barrier_minus = r_barrier - sqrt_precision;
	  
	  const double r_barrier_plus_plus   = r_barrier_plus  + sqrt_precision;
	  const double r_barrier_minus_minus = r_barrier_minus - sqrt_precision;
	  	  
	  const double Vr_plus  = real (T.potential_calc (r_barrier_plus));
	  const double Vr_minus = real (T.potential_calc (r_barrier_minus));
	  
	  const double Vr_plus_plus   = real (T.potential_calc (r_barrier_plus_plus));
	  const double Vr_minus_minus = real (T.potential_calc (r_barrier_minus_minus));

	  const double dVr_plus  = (Vr_plus_plus - Vr)/two_sqrt_precision;
	  
	  const double dVr_minus = (Vr - Vr_minus_minus)/two_sqrt_precision;

	  const double dVr  = (Vr_plus - Vr_minus)/two_sqrt_precision;
	  
	  const double d2Vr = (dVr_plus - dVr_minus)/two_sqrt_precision;
	  
	  const double dVr_barrier = dVr - two_ll_plus_one_over_kinetic_factor/(r_barrier_square*r_barrier);
	  
	  const double d2Vr_barrier = d2Vr + six_ll_plus_one_over_kinetic_factor/(r_barrier_square*r_barrier_square);

	  const double dr = dVr_barrier/d2Vr_barrier;
	  	  
	  r_barrier -= dr;
	  
	  test = abs (dr);
	}
	  
      V_barrier = real (T.potential_calc (r_barrier)) + ll_plus_one_over_kinetic_factor/(r_barrier*r_barrier);
    }
}




double potential_barrier::V_barrier_calc (
					  const class array<double> &r_bef_R_tab_big ,
					  const enum particle_type particle ,
					  const class potentials_effective_mass &T)
{
  double r_barrier = 0.0;
  
  double V_barrier = 0.0;
  
  barrier_values_calc (r_bef_R_tab_big , particle , T , r_barrier , V_barrier);

  return V_barrier;
}






double potential_barrier::r_barrier_calc (
					  const class array<double> &r_bef_R_tab_big ,
					  const enum particle_type particle ,
					  const class potentials_effective_mass &T)
{
  double r_barrier = 0.0;
  
  double V_barrier = 0.0;
  
  barrier_values_calc (r_bef_R_tab_big , particle , T , r_barrier , V_barrier);

  return r_barrier;
}









// Chi square of the PTG potential fit of the initial potential
// ------------------------------------------------------------
// chi^2 = \int_{r_min}^{R_barrier} (V_PTG(r) - V(r))^2 dr
//
// Variables
// ---------
// r_tab_GL, w_tab_GL, V_tab_GL : Gauss-Legendre radii, weights and potential values to fit
// N_GL: number of Gauss-Legendre radii
// V_PTG : PTG potential of parameters Lambda, s, nu, a
// r, w, Vr : Gauss-Legendre radius, weight and potential value to fit
// V_difference_r : V(r) - V_PTG_try(r)
// chi_square_PTG : \int_{r_min}^{R_barrier} (V_PTG(r) - V(r))^2 dr

double PTG_potential_fit::chi_square_calc (
					   const class array<double> &r_tab_GL ,
					   const class array<double> &w_tab_GL ,
					   const class array<double> &V_tab_GL ,
					   const double kinetic_factor ,
					   const int l ,
					   const double E_barrier ,
					   const double Lambda ,
					   const double s ,
					   const double nu ,
					   const double a)
{
  const unsigned int N_GL = r_tab_GL.dimension (0);
  	
  const class PTG_class V_PTG(kinetic_factor , l , Lambda , s , nu , a);
	  
  double chi_square_PTG = 0.0;
  
  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double r = r_tab_GL(i);
      const double w = w_tab_GL(i);
      
      const double V_PTG_E_barrier_r = V_PTG(r) + E_barrier;
      
      const double Vr = V_tab_GL(i);
      
      const double V_difference_r = V_PTG_E_barrier_r - Vr;
      
      chi_square_PTG += V_difference_r*V_difference_r*w;
    }

  return chi_square_PTG;
}












// Determination of a Lambda, s and nu with the Newton method for given boundaries Lambda_min, Lambda_max and nu_min, nu_max
// ------------------------------------------------------------------------------------------------------------------------------------------
// One uses a sequential search of the best Lambda, s and nu set minimizing ||V_PTG - V|| = \int_{r_min}^{R_barrier} (V_PTG(r) - V(r))^2 dr in (Lambda,nu) intervals.
// Intervals in which Lambda and nu vary are [Lambda_min:Lambda_max] and [nu_min:nu_max]. 
// s is determined using the property V_PTG[Lambda , s=1 , nu](0) = V_PTG[Lambda , s , nu](0)/s^2.
// Indeed , replacing V_PTG[Lambda , s , nu](0) by Re[V(r_min)] - E_barrier , one has s = sqrt [(Re[V(r_min)] - E_barrier)/V_PTG[Lambda , s=1 , nu](0)].
// The search of Lambda , s , nu is done with a two-dimensional sequential search on Lambda and nu.
//
// Variables:
// ----------
// r_min: minimal value for which one small value used instead of 0 fm , at which V(r=0) can be infinite due to spin-orbit potential.
//        It is fixed at 1 fm.
// E_barrier : energy shift to take into account approximately the barrier (see barrier_values_calc).
// r_barrier : barrier radius of the potential.
// r_tab_GL, w_tab_GL, V_tab_GL: Gauss-Legendre radii, weights and potential values to fit
// N_GL: number of Gauss-Legendre radii
// Lambda, s, nu : parameters of the PTG potential to fit to the potential to integrate.
// a: effective mass parameter of the PTG potential. One has, with everything dimensionless, a = 1 - effective_mass(0) for Skyrme and a = 0 if not.
// E_barrier: energy shift to take into account approximately the barrier.
// Vo_minus_E_barrier: Re[V(r_min)] - E_barrier. It is used to calculate s.
// N_PTG : number of points for Lambda and nu between their min and max values.
// Lambda_try, s_try, nu_try : trial values of Lambda, s, nu.
// chi_square_PTG, chi_square_PTG_try : ||V_PTG - V|| for respectively the best fit and tried Lambda, s, nu.
// Lambda_min , Lambda_max , Lambda_step: min (0) and max (10) values of Lambda for the first search , and the step (Lambda_max - Lambda_min)/N_PTG for the first iteration
//                                        values updated in Lambda +/ Lambda_step afterwards
// nu_min , nu_max , nu_step: min (2.N_bound + l - 1) and max (2.N_bound + l + 1) values of nu for the first search , and the step (nu_max - nu_min)/N_PTG for the first iteration
//                            values updated in nu +/ nu_step afterwards
// V_PTG_s_one : PTG potential with Lambda_try, s = 1 and nu_try as parameters, with which one calculates s (see above).

void PTG_potential_fit::parameters_determine_local (
						    const unsigned int N_PTG ,
						    const class array<double> &r_tab_GL ,
						    const class array<double> &w_tab_GL ,
						    const class array<double> &V_tab_GL ,
						    const int l ,
						    const double kinetic_factor ,
						    const double a ,
						    const double E_barrier ,
						    const double Vo_minus_E_barrier ,
						    const double Lambda_min ,
						    const double Lambda_max ,
						    const double nu_min ,
						    const double nu_max , 
						    double &Lambda ,
						    double &s ,
						    double &nu)
{    
  const double Lambda_step = (Lambda_max - Lambda_min)/N_PTG;
  
  const double nu_step = (nu_max - nu_min)/N_PTG;
  
  double chi_square_PTG = INFINITE;
  
  Lambda = 0.0;

  s = 0.0;

  nu = 0.0;

  for (unsigned int iL = 0 ; iL <= N_PTG ; iL++)
    for (unsigned int i_nu = 0 ; i_nu <= N_PTG ; i_nu++)
      {	
	const double Lambda_try = Lambda_min + iL*Lambda_step;
	
	const double nu_try = nu_min + i_nu*nu_step;

	const class PTG_class V_PTG_s_one(kinetic_factor , l , Lambda_try , 1.0 , nu_try , a);
  
	const double s_try = sqrt (abs (Vo_minus_E_barrier/V_PTG_s_one(0.0))); 
	
	const double chi_square_PTG_try = chi_square_calc (r_tab_GL , w_tab_GL , V_tab_GL , kinetic_factor , l , E_barrier , Lambda_try  , s_try , nu_try , a);
	
	if (chi_square_PTG_try < chi_square_PTG)
	  {
	    Lambda = Lambda_try;

	    s = s_try;

	    nu = nu_try;
	    
	    chi_square_PTG = chi_square_PTG_try;
	  }
      }
}










// Calculation of the k guess given by the best PTG potential fitting the potential to integrate.
// ----------------------------------------------------------------------------------------------
// One finds here a PTG potential very close to the potential to integrate.
// For the Skyrme interaction , the effective mass parameter a is taken from the effective mass value at r=0 , otherwise it is zero.
// One approximates the barrier by a constant E_barrier added to the PTG potential.
// E_barrier is the value of the barrier at r_barrier (see barrier_values_calc).
// nu varies between 2.N_bound + l - 1 and 2.N_bound + l + 1 , as it is only in this zone that one has N_bound bound and narrow resonant states.
// Lambda is varied from 0 to 10.
// s is fixed by using V_PTG(Lambda,s,nu)(r=0) = V_PTG(Lambda,1,nu)(r=0).s^2, and approximating  V_PTG(Lambda,s,nu)(r=0) by Re[V(r_min)] - E_barrier (see above).
// One does a sequential search in [Lambda_min:Lambda_max] and [nu_min:nu_max] 5 times, replacing the min/max values by the new Lambda/nu +/- Lambda/nu step.
// The integer nu case is suppressed by adding 0.001 to nu in case it happens, as it typically leads to instabilities.
//
// Variables:
// ----------
// r_min: minimal value for which one small value used instead of 0 fm , at which V(r=0) can be infinite due to spin-orbit potential.
//        It is fixed at 1 fm.
// E_barrier : energy shift to take into account approximately the barrier (see barrier_values_calc).
// r_barrier : barrier radius of the potential.
// r_bef_R_tab_big : array of radiin supposed to be dense. It allows to find the radius of the barrier
// N_PTG : number of points for Lambda and nu between their min and max values.
// particle : proton or neutron
// T : class which contains the potential to fit
// N_bound : number of bound states of the potential. It allows to fix the interval in which nu varies.
// Lambda , s , nu : parameters of the PTG potential to fit
// r_tab_GL, w_tab_GL, V_tab_GL : Gauss-Legendre radii, weights and potential values to fit
// N_GL: number of Gauss-Legendre radii
// N_bound : number of bound and narrow resonant states of the potential.
// Lambda , s , nu : parameters of the PTG potential to fit to the potential to integrate.
// a: effective mass parameter of the PTG potential. One has , with everything dimensionless , a = 1 - effective_mass(r) for Skyrme and a = 0 if not.
// Lambda_min , Lambda_max , Lambda_step: min (0) and max (10) values of Lambda for the first search , and the step (Lambda_max - Lambda_min)/N_PTG for the first iteration
//                                        values updated in Lambda +/ Lambda_step afterwards
// nu_min , nu_max , nu_step: min (2.N_bound + l - 1) and max (2.N_bound + l + 1) values of nu for the first search , and the step (nu_max - nu_min)/N_PTG for the first iteration
//                            values updated in nu +/ nu_step afterwards
// iter_max: number of two-dimensional sequential searches

void PTG_potential_fit::parameters_determine (
					      const class array<double> &r_bef_R_tab_big ,
					      const enum particle_type particle ,
					      const class potentials_effective_mass &T ,
					      const unsigned int N_bound ,
					      double &Lambda ,
					      double &s ,
					      double &nu)
{  
  const double r_min = 1.0;
  
  double r_barrier = 0.0;
  
  double E_barrier = 0.0;

  potential_barrier::barrier_values_calc (r_bef_R_tab_big , particle , T , r_barrier , E_barrier);
  
  const unsigned int N_PTG = 10;
  
  const unsigned int N_GL = 50;
    
  class array<double> r_tab_GL(N_GL);
  class array<double> w_tab_GL(N_GL);
  class array<double> V_tab_GL(N_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (r_min , r_barrier , r_tab_GL , w_tab_GL);
  
  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double r = r_tab_GL(i);

      V_tab_GL(i) = real (T.potential_calc (r));
    }
  
  const double kinetic_factor = T.get_kinetic_factor ();
  
  const enum potential_type potential = T.get_potential ();
  
  const int l = make_int (real (T.get_l ()));
  
  const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();
	
  const double a = (is_there_effective_mass_determine (potential)) ? (1.0 - full_effective_mass(0.0)/kinetic_factor) : (0.0);
  
  const double Vo_minus_E_barrier = real (T.potential_calc (r_min)) - E_barrier;
    
  const unsigned int iter_max = 5;
  
  double Lambda_min = 0.0;
  double Lambda_max = 10.0;

  double nu_min = 2.0*N_bound + l - 1;
  double nu_max = 2.0*N_bound + l + 1;
      
  Lambda = 0.0;

  s = 0.0;

  nu = 0.0;

  for (unsigned iter = 0 ; iter < iter_max ; iter++)
    {      
      parameters_determine_local (N_PTG , r_tab_GL , w_tab_GL , V_tab_GL , l , kinetic_factor , a , E_barrier , Vo_minus_E_barrier , Lambda_min , Lambda_max , nu_min , nu_max , Lambda , s , nu);

      const double Lambda_step = (Lambda_max - Lambda_min)/N_PTG;
  
      const double nu_step = (nu_max - nu_min)/N_PTG;
    
      Lambda_min = max (Lambda - Lambda_step , Lambda_min);
      Lambda_max = min (Lambda + Lambda_step , Lambda_max);

      nu_min = max (nu - nu_step , nu_min);
      nu_max = min (nu + nu_step , nu_max);
    }

  if (rint (nu) == nu) nu += 0.001;
}











void PTG_potential_fit::copy_potential_PTG_fit_to_file (
							const bool is_there_effective_mass ,
							const class array<double> &r_bef_R_tab_big ,
							const enum particle_type particle ,
							const class potentials_effective_mass &T ,
							const double Lambda ,
							const double s ,
							const double nu ,
							const double a)
{
  const unsigned int N_bef_R_big = r_bef_R_tab_big.dimension (0);
  
  const double kinetic_factor = T.get_kinetic_factor ();

  const int l = make_int (real (T.get_l ()));

  const int llp1 = l*(l + 1);

  const double E_barrier = potential_barrier::V_barrier_calc (r_bef_R_tab_big , particle , T);
    
  ofstream out_file("potential_PTG_fit.dat");

  const class PTG_class V_PTG(kinetic_factor , l , Lambda , s , nu , a);
  
  if (!is_there_effective_mass)
    {
      for (unsigned int i = 1 ; i < N_bef_R_big ; i++)
	{
	  const double r = r_bef_R_tab_big(i);
      
	  out_file << r << " " << real (T.potential_calc (r)) + llp1/(r*r*kinetic_factor) << " " << V_PTG(r) + E_barrier + llp1/(r*r*kinetic_factor) << endl;
	}
    }
  else
    {
      const class PTG_class V_PTG(kinetic_factor , l , Lambda , s , nu , a);

      const class splines_class<double> &full_effective_mass_splines = T.get_full_effective_mass ();

      for (unsigned int i = 1 ; i < N_bef_R_big ; i++)
	{
	  const double r = r_bef_R_tab_big(i);
      
	  out_file << r << " " << real (T.potential_calc (r)) + llp1/(r*r*kinetic_factor) << " " << V_PTG(r) + E_barrier + llp1/(r*r*kinetic_factor) << " "
		   << full_effective_mass_splines(r)/kinetic_factor << "   " << V_PTG.effective_mass (r)/kinetic_factor << endl;
	}
    }
}
