#ifndef POTENTIALS_H
#define POTENTIALS_H


// Harmonic oscillator.
// --------------------
// Standard notations , except for kinetic_factor = 2.mu/[hbar^2].

class HO_class
{
public:

  HO_class ();
  
  HO_class (const bool is_it_electron , const double mass_modif , const double particle_mass_for_calc , const double b_c);

  HO_class (const class HO_class &X);
  
  void initialize (const bool is_it_electron , const double mass_modif , const double particle_mass_for_calc , const double b_c);

  void initialize (const class HO_class &X);
  
  void operator = (const class HO_class &X);

  double get_hbar_omega () const
  {
    return hbar_omega;
  }

  double get_b () const
  {
    return b;
  }

  double get_kinetic_factor () const
  {
    return kinetic_factor;
  }
  
  double operator () (double r) const;

private:
  
  double hbar_omega , b , kinetic_factor;
};

double used_memory_calc (const class HO_class &T);
  








// Coulomb potential
// -----------------
// Standard notations

class Coulomb_potential_class
{
public:

  Coulomb_potential_class ();
  
  Coulomb_potential_class (const bool is_it_relative , const enum particle_type particle_c , const int Z_target_c , const double R_charge_c);

  Coulomb_potential_class (const class Coulomb_potential_class &X);
  
  void initialize (const bool is_it_relative , const enum particle_type particle_c , const int Z_target_c , const double R_charge_c);

  void initialize (const class Coulomb_potential_class &X);
  
  void operator = (const class Coulomb_potential_class &X);
  
  enum particle_type get_particle () const
  {
    return particle;
  }

  double get_Z_target () const
  {
    return Z_target;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  // Coulomb point potential and derivative
  double point_potential_calc            (const double r) const;
  double point_potential_derivative_calc (const double r) const;
  
  complex<double> point_potential_calc            (const complex<double> &z) const;
  complex<double> point_potential_derivative_calc (const complex<double> &z) const;
  
  // Coulomb potential for zero-range charge
  double uniform_potential_calc (const double r) const;
  
  // Coulomb potential and derivative for finite-range charge
  double analytic_potential_calc            (const double r) const;
  double analytic_potential_derivative_calc (const double r) const;
  
private:
  
  enum particle_type particle;
  
  int Z_target;
  
  double R_charge;

  double Cc_Z_target_particle_charge;

  double R_charge_four_over_three_sqrt_Pi;
};


double used_memory_calc (const class Coulomb_potential_class &T);








// WS potential with spin-orbit and Coulomb. 
// -----------------------------------------
// The Coulomb potential comes from a uniformed charged sphere.

class WS_class
{
public:
  
  WS_class ();
  
  WS_class (
	    const bool is_it_relative , 
	    const double d_c , 
	    const double R0_c , 
	    const double Vo_c ,
	    const double Vso_c , 
	    const enum particle_type particle_c , 
	    const int Z_charge_c , 
	    const double R_charge_c , 
	    const int l_c , 
	    const double j_c);

  WS_class (const class WS_class &X);

  void initialize (
		   const bool is_it_relative , 
		   const double d_c , 
		   const double R0_c , 
		   const double Vo_c ,
		   const double Vso_c , 
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const int l_c , 
		   const double j_c); 

  void initialize (const class WS_class &X);
  
  void operator = (const class WS_class &X);

  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  void set_Vo (const double Vo_c)
  {
    Vo = Vo_c;
  }

  double get_Vo () const
  {
    return Vo;
  }

  void set_Vso (const double Vso_c)
  {
    Vso = Vso_c;
  }

  double get_Vso () const
  {
    return Vso;
  }

  double operator () (const double r) const;
  
private:
  
  int l;                              // orbital angular momentum

  double j , two_l_scalar_s , d , R0; // total angular momentum , diffuseness (fm) , R0 = ro.A^(1/3).

  bool is_there_spin_orbit;           // true if the spin-orbit potential is non zero, false if not

  int Z_charge;                       // Z-1 of the nucleus.

  double R_charge;                    // Charge radius of Coulomb potential

  enum particle_type particle;        // PROTON , NEUTRON or DIPROTON.

  double Vo , Vso;                    // central and spin-orbit potentials strengths. Vso is zero for DIPROTON.

  class Coulomb_potential_class Coulomb_potential; // Coulomb potential
};
  
double used_memory_calc (const class WS_class &T);






// WS potential with spin-orbit and Coulomb. 
// -----------------------------------------
// The Coulomb potential is analytical.

class WS_analytic_class
{
public:

  WS_analytic_class ();
  
  WS_analytic_class (
		     const bool is_it_relative , 
		     const double d_c , 
		     const double R0_c , 
		     const double Vo_c ,
		     const double Vso_c , 
		     const enum particle_type particle_c , 
		     const int Z_charge_c , 
		     const double R_charge_c , 
		     const int l_c , 
		     const double j_c);

  WS_analytic_class (const class WS_analytic_class &X);

  void initialize (
		   const bool is_it_relative , 
		   const double d_c , 
		   const double R0_c , 
		   const double Vo_c ,
		   const double Vso_c , 
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const int l_c , 
		   const double j_c); 

  void initialize (const class WS_analytic_class &X);
  
  void operator = (const class WS_analytic_class &X);
  
  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }
 
  void set_Vo (const double Vo_c)
  {
    Vo = Vo_c;
  }

  double get_Vo () const
  {
    return Vo;
  }

  void set_Vso (const double Vso_c)
  {
    Vso = Vso_c;
  }

  double get_Vso () const
  {
    return Vso;
  }

  class Coulomb_potential_class & get_Coulomb_potential ()
  {
    return Coulomb_potential;
  }
  
  const class Coulomb_potential_class & get_Coulomb_potential () const
  {
    return Coulomb_potential;
  }
  
  double operator () (const double r) const;
  
  double d_derivative_calc (const double r) const;
  double R0_derivative_calc (const double r) const;
  double Vo_derivative_calc (const double r) const;
  double Vso_derivative_calc (const double r) const;
  double R_charge_derivative_calc (const double r) const;
  
  double derivative_calc (const enum FHT_EFT_parameter_type WS_parameter , const double r) const;
  double derivative_calc (const enum WS_parameter_type WS_parameter      , const double r) const;
  
private:
  
  int l;                              // orbital angular momentum

  double j , two_l_scalar_s , d , R0; // total angular momentum , diffuseness (fm) , R0 = ro.A^(1/3).

  bool is_there_spin_orbit;           // true if the spin-orbit potential is non zero, false if not

  int Z_charge;                       // Z-1 of the nucleus.

  double R_charge;                    // Charge radius of Coulomb potential

  enum particle_type particle;        // PROTON , NEUTRON or DIPROTON.

  double Vo , Vso;                    // central and spin-orbit potentials strengths. Vso is zero for DIPROTON.

  class Coulomb_potential_class Coulomb_potential; // Coulomb potential
};
    
double used_memory_calc (const class WS_analytic_class &T);







// Complex WS potential with spin-orbit and Coulomb. 
// -------------------------------------------------
// The Coulomb potential comes from a uniformed charged sphere.

class WS_complex_class

{
public:
  
  WS_complex_class ();
  
  WS_complex_class (
		    const bool is_it_relative , 
		    const double d_c , 
		    const double R0_c , 	    
		    const complex<double> &Vo_c ,
		    const complex<double> &Vso_c ,  
		    const enum particle_type particle_c , 
		    const int Z_charge_c , 
		    const double R_charge_c , 
		    const int l_c , 
		    const double j_c);

  WS_complex_class (const class WS_complex_class &X);

  void initialize (
		   const bool is_it_relative , 
		   const double d_c , 
		   const double R0_c , 
		   const complex<double> &Vo_c ,
		   const complex<double> &Vso_c , 
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const int l_c , 
		   const double j_c); 

  void initialize (const class WS_complex_class &X);
  
  void operator = (const class WS_complex_class &X);
  
  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }
 
  void set_Vo (const complex<double> &Vo_c)
  {
    Vo = Vo_c;
  }

  complex<double> get_Vo () const
  {
    return Vo;
  }

  void set_Vso (const complex<double> &Vso_c)
  {
    Vso = Vso_c;
  }

  complex<double> get_Vso () const
  {
    return Vso;
  }

  class Coulomb_potential_class & get_Coulomb_potential ()
  {
    return Coulomb_potential;
  }
  
  const class Coulomb_potential_class & get_Coulomb_potential () const
  {
    return Coulomb_potential;
  }
  
  complex<double> operator () (const double r) const;
  
private:
  
  int l;                              // orbital angular momentum
 
  double j , two_l_scalar_s , d , R0; // total angular momentum , diffuseness (fm) , R0 = ro.A^(1/3).

  bool is_there_spin_orbit;           // true if the spin-orbit potential is non zero, false if not

  int Z_charge;                       // Z-1 of the nucleus.

  double R_charge;                    // Charge radius of Coulomb potential

  enum particle_type particle;        // PROTON , NEUTRON or DIPROTON.

  complex<double> Vo , Vso;           // central and spin-orbit potentials strengths. Vso is zero for DIPROTON.

  class Coulomb_potential_class Coulomb_potential; // Coulomb potential
};
  
double used_memory_calc (const class WS_complex_class &T);



// Complex WS analytic potential with spin-orbit and Coulomb. 
// ----------------------------------------------------------
// The Coulomb potential is analytic.

class WS_analytic_complex_class
{
public:

  WS_analytic_complex_class ();
  
  WS_analytic_complex_class (
			     const bool is_it_relative , 
			     const double d_c , 
			     const double R0_c , 
			     const complex<double> &Vo_c , 
			     const complex<double> &Vso_c ,  
			     const enum particle_type particle_c , 
			     const int Z_charge_c , 
			     const double R_charge_c , 
			     const int l_c , 
			     const double j_c);

  WS_analytic_complex_class (const class WS_analytic_complex_class &X);

  void initialize (
		   const bool is_it_relative , 
		   const double d_c , 
		   const double R0_c , 
		   const complex<double> &Vo_c , 
		   const complex<double> &Vso_c , 
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const int l_c , 
		   const double j_c); 

  void initialize (const class WS_analytic_complex_class &X);
  
  void operator = (const class WS_analytic_complex_class &X);
  
  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }
 
  void set_Vo (const complex<double> &Vo_c)
  {
    Vo = Vo_c;
  }

  complex<double> get_Vo () const
  {
    return Vo;
  }

  void set_Vso (const complex<double> &Vso_c)
  {
    Vso = Vso_c;
  }

  complex<double> get_Vso () const
  {
    return Vso;
  }

  class Coulomb_potential_class & get_Coulomb_potential ()
  {
    return Coulomb_potential;
  }
  
  const class Coulomb_potential_class & get_Coulomb_potential () const
  {
    return Coulomb_potential;
  }
  
  complex<double> operator () (const double r) const;
  
  complex<double> d_derivative_calc (const double r) const;
  complex<double> R0_derivative_calc (const double r) const;
  
  double Vo_derivative_calc (const double r) const;
  double Vso_derivative_calc (const double r) const;
  double R_charge_derivative_calc (const double r) const;
  
  complex<double> derivative_calc (const enum FHT_EFT_parameter_type WS_parameter , const double r) const;
  complex<double> derivative_calc (const enum WS_parameter_type WS_parameter , const double r) const;
  
private:
  
  int l;                              // orbital angular momentum

  double j , two_l_scalar_s , d , R0; // total angular momentum , diffuseness (fm) , R0 = ro.A^(1/3).

  bool is_there_spin_orbit;           // true if the spin-orbit potential is non zero, false if not

  int Z_charge;                       // Z-1 of the nucleus.

  double R_charge;                    // Charge radius of Coulomb potential

  enum particle_type particle;        // PROTON , NEUTRON or DIPROTON.

  complex<double> Vo , Vso;           // central and spin-orbit potentials strengths. Vso is zero for DIPROTON.

  class Coulomb_potential_class Coulomb_potential; // Coulomb potential
};
  
double used_memory_calc (const class WS_analytic_complex_class &T);




// KKNN potential with spin-orbit 
// ------------------------------

class KKNN_class
{
public:

  KKNN_class ();
    
  KKNN_class (
	      const bool is_it_relative , 
	      const double V0_tab[] , 
	      const double rho_tab[] , 
	      const double V0_ls_tab[] , 
	      const double rho_ls_tab[] , 
	      const enum particle_type particle_c , 
	      const int Z_charge_c , 
	      const double R_charge_c , 
	      const int l_c , 
	      const double j_c);

  KKNN_class (const class KKNN_class &X);

  void initialize (
		   const bool is_it_relative , 
		   const double V0_tab[] , 
		   const double rho_tab[] , 
		   const double V0_ls_tab[] , 
		   const double rho_ls_tab[] , 
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const int l_c , 
		   const double j_c);

  void initialize (const class KKNN_class &X);
  
  void operator = (const class KKNN_class &X);
  
  double operator () (const double r) const;
  
  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }
 
  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }
  
  class Coulomb_potential_class & get_Coulomb_potential ()
  {
    return Coulomb_potential;
  }
  
  const class Coulomb_potential_class & get_Coulomb_potential () const
  {
    return Coulomb_potential;
  }
  
  double get_V0 (const unsigned int index) const;
  double get_rho (const unsigned int index) const;
  double get_V0_ls (const unsigned int index) const;
  double get_rho_ls (const unsigned int index) const;
  
private:
  
  int l;
  double j;
  double V0_0 , V0_1 , V0_2 , V0_3 , V0_4;      // depths of the central
  double rho_0 , rho_1 , rho_2 , rho_3 , rho_4; // ranges of the central part
  double V0_ls_0 , V0_ls_1 , V0_ls_2;           // depths of the spin-orbit part
  double rho_ls_0 , rho_ls_1 , rho_ls_2;        // ranges of the spin-orbit part
  enum particle_type particle;                  // proton or neutron 
  int Z_charge;                                 // (-1)^l , target charge
  double R_charge;                              // Coulomb length
  int minus_one_pow_l;                          // (-1)^l , target charge
  double l_dependent_factor;                    // 1 + 0.3 x (0.1)^l
  double two_l_scalar_s;                        // j(j+1) - l(l+1) - 3/4
  bool is_there_spin_orbit;                     // true if the spin-orbit potential is non zero, false if not

  class Coulomb_potential_class Coulomb_potential; // Coulomb potential
};
  
double used_memory_calc (const class KKNN_class &T);



// PTG potential
// -------------

class PTG_class
{
public:

  PTG_class ();
  
  PTG_class (
	     const double kinetic_factor_c , 
	     const double l_c , 
	     const double Lambda_c , 
	     const double s_c , 
	     const double nu_c , 
	     const double a_c);

  PTG_class (const class PTG_class &X);

  void initialize (
		   const double kinetic_factor_c , 
		   const double l_c , 
		   const double Lambda_c , 
		   const double s_c , 
		   const double nu_c , 
		   const double a_c);

  void initialize (const class PTG_class &X);
  
  void operator = (const class PTG_class &X);
  
  double get_kinetic_factor () const
  {
    return kinetic_factor;
  }

  double get_Lambda () const
  {
    return Lambda;
  }

  double get_s () const
  {
    return s;
  }

  double get_nu () const
  {
    return nu;
  }

  double get_l () const
  {
    return l;
  }

  double get_a () const
  {
    return a;
  }
  
  double operator () (const double r) const;
  
  complex<double> k_pole_calc (const int n) const;

  double effective_mass (const double r) const;
  double effective_mass_der (const double r) const;
  double y_search (const double Lambda2_sr) const;
  double exp_minus_2x_iterative (const double Lambda2_sr) const;
  
private:

  double s_square_over_kinetic_factor;

  double Lambda2 , Lambda2_minus_one , sqrt_abs_Lambda2_minus_one , Lambda2_s;

  double nu_nu_plus_one;
  
  double two_a , one_minus_a , five_one_minus_a;

  double three_two_minus_Lambda2 , a_four_minus_three_Lambda2 , seven_minus_Lambda2;

  double five_Lambda2_minus_one , Lambda2_minus_one_over_four;

  double V_cl_zero;

  double llp1;

  double two_a_s_kinetic_factor;

  double s_over_one_minus_a , Lambda2_one_minus_a;

  double Lambda2_sr_function (const double y) const;

  double V_cl_calc (
		    const double y ,
		    const double y2 ,
		    const double one_minus_y2 ,
		    const double sr) const;
  
  double kinetic_factor;

  double Lambda , s , nu;

  double l;

  double a;
};

double used_memory_calc (const class PTG_class &T);










// Modified PTG potential
// ----------------------
// It is a PTG potential plus E[barrier] for r <= r[barrier] and the Coulomb potential for r >= r[barrier].
// It is the potential with analytical wave functions which is the closest to a WS potential.
// The PTG potential is fitted from a WS potential.
// scaled_effective_mass_inv_minus_one_zero_radius is m/mu(r=0) - 1, with m the bare mass.

class modified_PTG_class
{
public:
  
  modified_PTG_class ();

  modified_PTG_class (
		      const bool is_modified_PTG_fitted_from_WS_analytic ,
		      const bool is_it_relative , 
		      const double d_c , 
		      const double R0_c , 
		      const double Vo_c ,
		      const double Vso_c , 
		      const double scaled_effective_mass_inv_minus_one_zero_radius ,
		      const enum particle_type particle_c , 
		      const int Z_charge_c , 
		      const double R_charge_c , 
		      const double kinetic_factor , 
		      const int l_c , 
		      const double j_c ,
		      const double R ,
		      const unsigned int N_big ,
		      const unsigned int N_GL);
  
  modified_PTG_class (const class modified_PTG_class &X);
		      
  void initialize (
		   const bool is_modified_PTG_fitted_from_WS_analytic ,
		   const bool is_it_relative , 
		   const double d_c , 
		   const double R0_c , 
		   const double Vo_c ,
		   const double Vso_c , 
		   const double scaled_effective_mass_inv_minus_one_zero_radius ,
		   const enum particle_type particle_c , 
		   const int Z_charge_c , 
		   const double R_charge_c , 
		   const double kinetic_factor , 
		   const int l_c , 
		   const double j_c ,
		   const double R ,
		   const unsigned int N_big ,
		   const unsigned int N_GL);
  
  void initialize (const class modified_PTG_class &X);

  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_Vo () const
  {
    return Vo;
  }

  double get_Vso () const
  {
    return Vso;
  }
  
  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }
  
  double get_kinetic_factor () const
  {
    return PTG_potential.get_kinetic_factor ();
  }

  double get_Lambda () const
  {
    return PTG_potential.get_Lambda ();
  }

  double get_s () const
  {
    return PTG_potential.get_s ();
  }

  double get_nu () const
  {
    return PTG_potential.get_nu ();
  }

  double get_a () const
  {
    return PTG_potential.get_a ();
  }
      
  double get_r_asy () const
  {
    return r_asy;
  }

  double get_E_barrier () const
  {
    return E_barrier;
  }
    
  double operator () (const double r) const;
  
private:
  
  int l;                       // orbital angular momentum

  double j , d , R0;           // total angular momentum , diffuseness (fm) , R0 = ro.A^(1/3).

  int Z_charge;                // Z-1 of the nucleus.

  double R_charge;             // Charge radius of Coulomb potential

  enum particle_type particle; // PROTON , NEUTRON or DIPROTON.

  double Vo , Vso;             // central and spin-orbit potentials strengths. Vso is zero for DIPROTON
  
  double r_asy , E_barrier;    // Radius defining the asymptotic zone and barrier energy so that the potential is PTG_potential(r) + E_barrier for r <= r_asy and the point-particle Coulomb potential for r >= r_asy.
    
  class PTG_class PTG_potential;
  
  class Coulomb_potential_class Coulomb_potential;
};

double used_memory_calc (const class modified_PTG_class &T);



  


// dipolar potential.
// --------------------

class dipolar_potential_class
{
public:

  // constructors - destructors

  dipolar_potential_class ();
  
  dipolar_potential_class (
			   const double mu_c , 
			   const double s_c , 
			   const double alpha_0_c , 
			   const double alpha_2_c , 
			   const double r_0_c , 
			   const double Q_zz_c , 
			   const double V_0_c , 
			   const double r_c_c , 
			   const int J_c , 
			   const int lmax_c);// , 
  //const double R);

  dipolar_potential_class (const class dipolar_potential_class &X);

  void allocate_calc (
		      const double mu_c , 
		      const double s_c , 
		      const double alpha_0_c , 
		      const double alpha_2_c , 
		      const double r_0_c , 
		      const double Q_zz_c , 
		      const double V_0_c , 
		      const double r_c_c , 
		      const int J_c , 
		      const int lmax_c);// , 
  //const double R_c);

  void allocate_fill (const class dipolar_potential_class &X);

  void deallocate ();

  double get_mu () const
  {
    return mu;
  }

  double get_s () const
  {
    return s;
  }

  double get_alpha_0 () const
  {
    return alpha_0;
  }

  double get_alpha_2 () const
  {
    return alpha_2;
  }

  double get_r_0 () const
  {
    return r_0;
  }

  double get_Q_zz () const
  {
    return Q_zz;
  }

  double get_V_0 () const
  {
    return V_0;
  }

  double get_r_c () const
  {
    return r_c;
  }

  int get_J () const
  {
    return J;
  }

  int get_lmax () const
  {
    return lmax;
  }
  
  // V_asy(jr' l' jr l) is defined so that V(jr' , l' , l , jr , r) ~ V_asy(jr' l' jr l)/r^2 in atomic units for r -> +oo
  double Vccp_quadratic_inverse_calc (const int jr , const int l , const int jrp , const int lp) const;

  // Value of the potential for jr , l , jr' , l' and r
  double operator () (const int jr , const int l , const int jrp , const int lp , const double r) const;

  // Asymptotical value of the potential for jr , l , jr' , l' and z complex: one puts all exponentials to 1 and r_inf = s , r_sup = z. 
  complex<double> V_asymptotic_calc (const int jr , const int l , const int jrp , const int lp , const complex<double> &z) const;

  friend double used_memory_calc (const class dipolar_potential_class &T);
  
private:

  double mu , s , alpha_0 , alpha_2 , r_0 , Q_zz , V_0 , r_c;
  int J , lmax;
  //const double R;
  
  // methods

  void V_lambda_tab_calc (const int jr , const int l , const int jrp , const int lp , const double r , class array<double> &V_lambda_tab) const;
  void V_lambda_asymptotic_tab_calc (const int jr , const int l , const int jrp , const int lp , const complex<double> &z , class array<complex<double> > &V_lambda_asymptotic_tab) const;

  class array<double> P_lambda_molecular_tab;
};







// quadrupolar potential.
// --------------------

class quadrupolar_potential_class
{
public:

  // constructors - destructors
  quadrupolar_potential_class ();
  
  quadrupolar_potential_class (
			       const double s_c ,
			       const double Q_pm_c ,
			       const double V_0_c ,
			       const double r_c_c ,
			       const int J_c ,
			       const int lmax_c);

  quadrupolar_potential_class (const class quadrupolar_potential_class &X);

  void allocate_calc (
		      const double s_c ,
		      const double Q_pm_c ,
		      const double V_0_c ,
		      const double r_c_c ,
		      const int J_c ,
		      const int lmax_c);

  void allocate_fill (const class quadrupolar_potential_class &X);

  void deallocate ();
   
  double get_s () const
  {
    return s;
  }

  double get_Q_pm () const
  {
    return Q_pm;
  }

  double get_V_0 () const
  {
    return V_0;
  }

  double get_r_c () const
  {
    return r_c;
  }

  int get_J () const
  {
    return J;
  }

  int get_lmax () const
  {
    return lmax;
  }
  
  // V_asy(jr' l' jr l) is defined so that V(jr' , l' , l , jr , r) ~ V_asy(jr' l' jr l)/r^2 in atomic units for r -> +oo
  //double Vccp_quadratic_inverse_calc (const int j , const int l , const int jp , const int lp) const;

  // Value of the potential for jr , l , jr' , l' and r
  double operator () (const int jr , const int l , const int jrp , const int lp , const double r) const;

  // Asymptotical value of the potential for jr , l , jr' , l' and z complex: one puts all exponentials to 1 and r_inf = s , r_sup = z. 
  complex<double> V_asymptotic_calc (const int jr , const int l , const int jrp , const int lp , const complex<double> &z) const;

  friend double used_memory_calc (const class quadrupolar_potential_class &T);
  
private:
  
  double s , Q_pm , V_0 , r_c;
  int J , lmax;
  
  // methods
  
  void V_lambda_tab_calc (const int jr , const int l , const int jrp , const int lp , const double r , class array<double> &V_lambda_tab) const;
  void V_lambda_asymptotic_tab_calc (const int jr , const int l , const int jrp , const int lp , const complex<double> &z , class array<complex<double> > &V_lambda_asymptotic_tab) const;

  class array<double> P_lambda_molecular_tab;
};




// Class for P_lambda , depending on lambda , jr , l , j
// -----------------------------------------------------

class P_lambda_rotor_tensor_part_class
{
public:

  P_lambda_rotor_tensor_part_class ();
 
  P_lambda_rotor_tensor_part_class (const double K , const int lmax);

  P_lambda_rotor_tensor_part_class (const class P_lambda_rotor_tensor_part_class &X);

  void indices_dimension_table_calc (const double K , const int lmax , unsigned int &dimension_table);

  void table_calc (const double K , const int lmax);

  void allocate_calc (const double K , const int lmax);

  void allocate_fill (const class P_lambda_rotor_tensor_part_class &X);

  void deallocate ();
  
  double & operator [] (const unsigned int i) const;

  unsigned int index_determine (
				const int lambda , 
				const int jr , 
				const int l , 
				const double j , 
				const int jrp , 
				const int lp , 
				const double jp) const;

  double & operator () (
			const int lambda , 
			const int jr , 
			const int l , 
			const double j , 
			const int jrp , 
			const int lp , 
			const double jp) const;

  friend double used_memory_calc (const class P_lambda_rotor_tensor_part_class &T);
  
private:

  class array<unsigned int> indices;

  class array<double> table;
};








// Deformed WS potential.
// ---------------------

class deformed_WS_class
{
public:
  
  deformed_WS_class ();
  
  deformed_WS_class (
		     const unsigned int Nt_c , 
		     const unsigned int Nr_c , 
		     const double R_c , 
		     const enum particle_type particle_c , 
		     const int Z_charge_c , 
		     const double R_charge_c , 
		     const double d_c , 
		     const double R0_c , 
		     const double beta_2_c , 
		     const double Vo_c , 
		     const double Vso_c , 
		     const double J_c , 
		     const int lmax_c);

  deformed_WS_class (const class deformed_WS_class &X);

  void allocate_calc (
		      const unsigned int Nt_c , 
		      const unsigned int Nr_c , 
		      const double R_c , 
		      const enum particle_type particle_c , 
		      const int Z_charge_c , 
		      const double R_charge_c , 
		      const double d_c , 
		      const double R0_c , 
		      const double beta_2_c , 
		      const double Vo_c , 
		      const double Vso_c , 
		      const double J_c , 
		      const int lmax_c);

  void allocate_fill (const class deformed_WS_class &X);

  void deallocate ();

  void multipole_expansion_tables_alloc_calc ();
  
  double get_I () const
  {
    return I;
  }

  bool get_is_I_tab_used () const
  {
    return is_I_tab_used;
  }

  unsigned get_Nt () const
  {
    return Nt;
  }

  unsigned get_Nr () const
  {
    return Nr;
  }

  double get_R () const
  {
    return R;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_beta_2 () const
  {
    return beta_2;
  }

  double get_Vo () const
  {
    return Vo;
  }

  double get_Vso () const
  {
    return Vso;
  }

  int get_J () const
  {
    return J;
  }

  int get_lmax () const
  {
    return lmax;
  }

  double operator () (
		      const int jr , 
		      const int l , 
		      const double j , 
		      const int jrp , 
		      const int lp , 
		      const double jp , 
		      const double r) const;

  void set_moment_of_inertia (
			      const double I_c , 
			      const bool is_I_tab_used_c , 
			      const class array<unsigned int> &new_rotor_angular_momenta , 
			      const class array<double> &new_moments_of_inertia , 
			      const double mass_modif , 
			      const double nucleon_mass_for_calc);
  
  double get_moment_of_inertia (const unsigned int jr) const;

  friend double used_memory_calc (const class deformed_WS_class &T);
  
private:
  
  double I;
  bool is_I_tab_used;

  unsigned int Nt , Nr;
  double R;
  enum particle_type particle;
  int Z_charge;
 
  double R_charge , d , R0 , beta_2 , Vo , Vso;
  double J;
  int lmax;
  
  class array<unsigned int> rotor_angular_momenta;
  class array<double> moments_of_inertia;

  class P_lambda_rotor_tensor_part_class P_lambda_nuclear_tab;
  
  class array<class splines_class<double> > V_lambda_central_splines_tab;
  class array<class splines_class<double> > V_lambda_so_times_r_splines_tab;
};




















// Gaussian potential.
// f(x)=a*exp(-(x-b)^2/2c^2)
// ---------------------------

class Gaussian_potential_class
{
public:

  unsigned get_Nt () const
  {
    return Nt;
  }

  unsigned get_Nr () const
  {
    return Nr;
  }

  double get_R () const
  {
    return R;
  }
  
  double get_V0 () const
  {
    return V0;
  }

  double get_r0 () const
  {
    return r0;
  }

  double get_mu () const
  {
    return mu;
  }

  int get_polarity () const
  {
    return polarity;
  }

  int get_J () const
  {
    return J;
  }

  int get_lmax () const
  {
    return lmax;
  }

  //constructors - destructors
  Gaussian_potential_class ();

  Gaussian_potential_class (
			    const unsigned int Nt_c , 
			    const unsigned int Nr_c ,
			    const double R_c , 
			    const double V0_c ,
			    const double r0_c ,
			    const double mu_c ,
			    const int J_c,
			    const int lmax_c,
			    const int polarity_c);

  Gaussian_potential_class (const class Gaussian_potential_class &X);

  void allocate_calc (
		      const unsigned int Nt_c , 
		      const unsigned int Nr_c ,
		      const double R_c , 
		      const double V0_c ,
		      const double r0_c ,
		      const double mu_c ,
		      const int J_c,
		      const int lmax_c,
		      const int polarity_c);

  void allocate_fill (const class Gaussian_potential_class &X);
 
  void deallocate ();

  double operator () (const int jr , const int l , const int jrp , const int lp , const double r) const;

  friend double used_memory_calc (const class Gaussian_potential_class &T);
  
private:

  unsigned int Nt;
  unsigned int Nr;

  double R;

  double V0;
  double r0;
  double mu;
  
  double one_over_two_mu_square;

  int polarity;

  int J;

  int lmax;

  //methods

  void V_lambda_tab_calc ();

  class array<class splines_class<double> > V_lambda_splines_tab;

  class array<double> P_lambda_molecular_tab;
};
























// Class for P_lambda in the static case , depending on lambda , l , j
// -------------------------------------------------------------------

class P_lambda_static_class
{
public:

  P_lambda_static_class ();
 
  P_lambda_static_class (const double K , const int lmax);

  P_lambda_static_class (const class P_lambda_static_class &X);

  void indices_dimension_table_calc (const double K , const int lmax , unsigned int &dimension_table);

  void table_calc (const double K , const int lmax);

  void allocate_calc (const double K , const int lmax);

  void allocate_fill (const class P_lambda_static_class &X);

  void deallocate ();
  
  double & operator [] (const unsigned int i) const;

  unsigned int index_determine (
				const int lambda , 
				const int l , 
				const double j , 
				const int lp , 
				const double jp) const;

  double & operator () (
			const int lambda , 
			const int l , 
			const double j , 
			const int lp , 
			const double jp) const;

  friend double used_memory_calc (const class P_lambda_static_class &T);
  
private:

  class array<unsigned int> indices;

  class array<double> table;
};





// Deformed WS potential.
// ---------------------

class deformed_WS_static_class
{
public:
  
  deformed_WS_static_class ();
  
  deformed_WS_static_class (
			    const unsigned int Nt_c , 
			    const unsigned int Nr_c , 
			    const double R_c , 
			    const enum particle_type particle_c , 
			    const int Z_charge_c , 
			    const double R_charge_c , 
			    const double d_c , 
			    const double R0_c , 
			    const double beta_2_c , 
			    const double Vo_c , 
			    const double Vso_c , 
			    const double K_c , 
			    const int lmax_c);

  deformed_WS_static_class (const class deformed_WS_static_class &X);

  void allocate_calc (
		      const unsigned int Nt_c , 
		      const unsigned int Nr_c , 
		      const double R_c , 
		      const enum particle_type particle_c , 
		      const int Z_charge_c , 
		      const double R_charge_c , 
		      const double d_c , 
		      const double R0_c , 
		      const double beta_2_c , 
		      const double Vo_c , 
		      const double Vso_c , 
		      const double K_c , 
		      const int lmax_c);

  void allocate_fill (const class deformed_WS_static_class &X);

  void deallocate ();

  void multipole_expansion_tables_alloc_calc ();
  
  unsigned get_Nt () const
  {
    return Nt;
  }

  unsigned get_Nr () const
  {
    return Nr;
  }

  double get_R () const
  {
    return R;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R_charge () const
  {
    return R_charge;
  }

  double get_d () const
  {
    return d;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_beta_2 () const
  {
    return beta_2;
  }

  double get_Vo () const
  {
    return Vo;
  }

  double get_Vso () const
  {
    return Vso;
  }

  int get_K () const
  {
    return K;
  }

  int get_lmax () const
  {
    return lmax;
  }

  double operator () (
		      const int l , 
		      const double j , 
		      const int lp , 
		      const double jp , 
		      const double r) const;

  friend double used_memory_calc (const class deformed_WS_static_class &T);
  
private:
  
  unsigned int Nt , Nr;
  double R;
  enum particle_type particle;
  int Z_charge;
 
  double R_charge , d , R0 , beta_2 , Vo , Vso;
  double K;
  int lmax;

  class P_lambda_static_class P_lambda_nuclear_tab;
  
  class array<class splines_class<double> > V_lambda_central_splines_tab;
  class array<class splines_class<double> > V_lambda_so_times_r_splines_tab;
};






class potentials_effective_mass
{
public:
  
  potentials_effective_mass ();

  potentials_effective_mass (const class potentials_effective_mass &X);
  
  void initialize_constants (
			     const enum potential_type potential_c , 
			     const double kinetic_factor_c , 
			     const int jr_c , 
			     const complex<double> &l_c ,  
			     const int Z_charge_c , 
			     const double j_c , 
			     const complex<double> &k_c , 
			     const complex<double> &eta_c ,
			     const complex<double> &lambda_c);  

  void allocate_fill (const class potentials_effective_mass &X);
  
  enum potential_type get_potential () const
  {
    return potential;
  }

  int get_jr () const
  {
    return jr;
  }

  int get_l_integer () const
  {
    return l_integer;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_j () const
  {
    return j;
  }

  double get_kinetic_factor () const
  {
    return kinetic_factor;
  }

  complex<double> get_lambda () const
  {
    return lambda;
  }

  complex<double> get_l () const
  {
    return l;
  }

  complex<double> get_k () const
  {
    return k;
  }

  complex<double> get_E () const
  {
    return E;
  }

  complex<double> get_eta () const
  {
    return eta;
  }

  complex<double> get_two_eta () const
  {
    return two_eta;
  }

  class KKNN_class & get_KKNN_potential ()
  {
    return KKNN_potential;
  }
  
  const class KKNN_class & get_KKNN_potential () const
  {
    return KKNN_potential;
  }
  
  class WS_class &get_WS_potential ()
  {
    return WS_potential;
  }
  
  const class WS_class & get_WS_potential () const
  {
    return WS_potential;
  }
  
  class WS_analytic_class & get_WS_analytic_potential ()
  {
    return WS_analytic_potential;
  }

  const class WS_analytic_class & get_WS_analytic_potential () const
  {
    return WS_analytic_potential;
  }

  class WS_complex_class & get_WS_complex_potential ()
  {
    return WS_complex_potential;
  }

  const class WS_complex_class & get_WS_complex_potential () const
  {
    return WS_complex_potential;
  }

  class WS_analytic_complex_class & get_WS_complex_analytic_potential ()
  {
    return WS_complex_analytic_potential;
  }
  
  const class WS_analytic_complex_class & get_WS_complex_analytic_potential () const
  {
    return WS_complex_analytic_potential;
  }

  class PTG_class & get_PTG_potential ()
  {
    return PTG_potential;
  }

  const class PTG_class & get_PTG_potential () const
  {
    return PTG_potential;
  }

  class modified_PTG_class & get_modified_PTG_potential ()
  {
    return modified_PTG_potential;
  }

  const class modified_PTG_class & get_modified_PTG_potential () const
  {
    return modified_PTG_potential;
  }

  class splines_class<complex<double> > & get_trivially_equivalent_potential ()
  {
    return trivially_equivalent_potential;
  }

  const class splines_class<complex<double> > & get_trivially_equivalent_potential () const
  {
    return trivially_equivalent_potential;
  }

  class splines_class<complex<double> > & get_source ()
  {
    return source;
  }

  const class splines_class<complex<double> > & get_source () const
  {
    return source;
  }

  class splines_class<double> & get_V_interpolated ()
  {
    return V_interpolated;
  }

  const class splines_class<double> & get_V_interpolated () const
  {
    return V_interpolated;
  }

  class splines_class<complex<double> > & get_V_interpolated_complex ()
  {
    return V_interpolated_complex;
  }

  const class splines_class<complex<double> > & get_V_interpolated_complex () const
  {
    return V_interpolated_complex;
  }

  class splines_class<double> & get_V_effective_mass_scaled ()
  {
    return V_effective_mass_scaled;
  }

  const class splines_class<double> & get_V_effective_mass_scaled () const
  {
    return V_effective_mass_scaled;
  }

  class splines_class<double> & get_V_effective_mass_unscaled ()
  {
    return V_effective_mass_unscaled;
  }

  const class splines_class<double> & get_V_effective_mass_unscaled () const
  {
    return V_effective_mass_unscaled;
  }

  class splines_class<double> & get_full_effective_mass ()
  {
    return full_effective_mass;
  }

  const class splines_class<double> & get_full_effective_mass () const
  {
    return full_effective_mass;
  }

  class splines_class<double> & get_W_full_effective_mass ()
  {
    return W_full_effective_mass;
  }

  const class splines_class<double> & get_W_full_effective_mass () const
  {
    return W_full_effective_mass;
  }

  class array<class splines_class<complex<double> > > & get_CC_trivially_equivalent_potential_tab ()
  {
    return CC_trivially_equivalent_potential_tab;
  }

  const class array<class splines_class<complex<double> > > & get_CC_trivially_equivalent_potential_tab () const
  {
    return CC_trivially_equivalent_potential_tab;
  }

  class array<class splines_class<complex<double> > > & get_CC_source_tab ()
  {
    return CC_source_tab;
  }
  
  const class array<class splines_class<complex<double> > > & get_CC_source_tab () const
  {
    return CC_source_tab;
  }
  
  class dipolar_potential_class & get_V_dipolar ()
  {
    return V_dipolar;
  }

  const class dipolar_potential_class & get_V_dipolar () const
  {
    return V_dipolar;
  }

  class quadrupolar_potential_class & get_V_quadrupolar ()
  {
    return V_quadrupolar;
  }

  const class quadrupolar_potential_class & get_V_quadrupolar () const
  {
    return V_quadrupolar;
  }

  class deformed_WS_class & get_V_deformed_WS ()
  {
    return V_deformed_WS;
  }

  const class deformed_WS_class & get_V_deformed_WS () const
  {
    return V_deformed_WS;
  }

  class deformed_WS_static_class & get_V_deformed_WS_static ()
  {
    return V_deformed_WS_static;
  }

  const class deformed_WS_static_class & get_V_deformed_WS_static () const
  {
    return V_deformed_WS_static;
  }

  class Gaussian_potential_class & get_V_Gaussian ()
  {
    return V_Gaussian;
  }

  const class Gaussian_potential_class & get_V_Gaussian () const
  {
    return V_Gaussian;
  }

  complex<double> potential_calc (const double r) const;

  complex<double> F_z_u (const complex<double> &z , const complex<double> &u) const;
 
  friend double used_memory_calc (const class potentials_effective_mass &T);
  
private:

  enum potential_type potential;                          // type of potential one integrates : WS , PTG , HF , ..

  int jr , l_integer , Z_charge;                          // rotor angular momentum , l rounded to an integer , charge of the nucleus seen by the cluster

  double j , kinetic_factor;                              // particle total momentum , 2.mu/hbar^2 , with mu the reduced mass

  complex<double> lambda , l , ll_plus_one;               // chemical potential , particle angular momentum , l(l+1)

  complex<double> k , E , eta , two_eta;                  // linear momentum of the state , energy of the state , Sommerfeld parameter , 2.eta (useful for the Coulomb equation only).
  
  class KKNN_class KKNN_potential;
  class WS_class WS_potential;
  class WS_analytic_class WS_analytic_potential;
  class WS_complex_class WS_complex_potential;
  class WS_analytic_complex_class WS_complex_analytic_potential;
  class PTG_class PTG_potential;
  class modified_PTG_class modified_PTG_potential;
  
  class splines_class<complex<double> > trivially_equivalent_potential;
  class splines_class<complex<double> > source;
  class splines_class<complex<double> > V_interpolated_complex;

  class splines_class<double> V_interpolated;
  
  class splines_class<double> V_effective_mass_scaled;
  class splines_class<double> V_effective_mass_unscaled;
  
  class splines_class<double> full_effective_mass;
  
  class splines_class<double> W_full_effective_mass;
  
  class array<class splines_class<complex<double> > > CC_trivially_equivalent_potential_tab;

  class array<class splines_class<complex<double> > > CC_source_tab;
  
  class dipolar_potential_class V_dipolar;

  class quadrupolar_potential_class V_quadrupolar;

  class deformed_WS_class V_deformed_WS;
  
  class deformed_WS_static_class V_deformed_WS_static;

  class Gaussian_potential_class V_Gaussian;
};

complex<double> potentials_effective_mass_F_z_u (const void * ptr , const complex<double> &z , const complex<double> &u);






namespace potential_barrier
{
  void barrier_values_calc (
			    const class array<double> &r_bef_R_tab_big ,
			    const enum particle_type particle ,
			    const class potentials_effective_mass &T , 			    
			    double &r_barrier ,		    
			    double &V_barrier);
  double V_barrier_calc (
			 const class array<double> &r_bef_R_tab_big ,
			 const enum particle_type particle ,
			 const class potentials_effective_mass &T);

  double r_barrier_calc (
			 const class array<double> &r_bef_R_tab_big ,
			 const enum particle_type particle ,
			 const class potentials_effective_mass &T);
}





namespace PTG_potential_fit
{
  double chi_square_calc (
			  const class array<double> &r_tab_GL ,
			  const class array<double> &w_tab_GL ,
			  const class array<double> &V_tab_GL ,
			  const double kinetic_factor ,
			  const int l ,
			  const double E_barrier ,
			  const double Lambda ,
			  const double s ,
			  const double nu ,
			  const double a);
 
  void parameters_determine_local (
				   const unsigned int N_PTG ,
				   const class array<double> &r_tab_GL ,
				   const class array<double> &w_tab_GL ,
				   const class array<double> &V_tab_GL ,
				   const int l ,
				   const double kinetic_factor ,
				   const double a ,
				   const double E_barrier ,
				   const double Vo_minus_E_barrier ,
				   const double Lambda_min ,
				   const double Lambda_max ,
				   const double nu_min ,
				   const double nu_max , 
				   double &Lambda ,
				   double &s ,
				   double &nu);
  
  void parameters_determine (
			     const class array<double> &r_bef_R_tab_big ,
			     const enum particle_type particle ,
			     const class potentials_effective_mass &T ,
			     const unsigned int N_bound ,
			     double &Lambda ,
			     double &s ,
			     double &nu);

  void copy_potential_PTG_fit_to_file (
				       const bool is_there_effective_mass ,
				       const class array<double> &r_bef_R_tab_big ,
				       const enum particle_type particle ,
				       const class potentials_effective_mass &T ,
				       const double Lambda ,
				       const double s ,
				       const double nu ,
				       const double a);
}

#endif
