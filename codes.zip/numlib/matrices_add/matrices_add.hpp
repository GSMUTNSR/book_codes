#ifndef MATRIX_ADD_HPP
#define MATRIX_ADD_HPP

// template functions which cannot be put in matrix.hpp because they need total_diagonalization.hpp (it needs matrix.hpp)
// SCALAR_TYPE must be double or complex.
// One cannot mix double and complex in general. Convert double to complex when necessary.
// All eigenvalues of infinite norm smaller than SVD_precision are considered as equal to zero. 

// Matrix power using Moore Penrose inverse
// (for small matrices)
// ======================
// The matrix has to be symmetric.
// 1) diagonalization of the input matrix A = P^(-1) D P
// 2) calculation of a pseudo inverse power of the input matrix:
// {Ap}^{\alpha} = P^(-1) {Dp}^{\alpha} P
// with D the diagonal matrix and {Dp}^{\alpha} its alpha power using Moore Penrose regularization
// ---- the pseudo inverse is used in case of non invertible matrix if real (alpha) <= 0 ----
// {Dp}^{\alpha}.P is stored in A.
// {Ap}^{\alpha} is stored in A.
// Routines are optimized so as to limit memory use of matrices: three matrices must be present in memory.
// If x^alpha is not defined , it is assumed that one calculates for example (-epsilon)^alpha instead of (0.0)^alpha for the double case. 
// Hence , 0.0 is taken instead therein by default , as A assumed to be positive definite for the double case if alpha is non-integer.
//
// One uses Householder-QL diagonalization with real symmetric matrices and complex/bicomplex hermitian matrices, as it is the most stable in this case.
// One uses the Newton method for diagonalization (see total_diagonalization.hpp) for complex symmetric matrices.
// Indeed, the matrices used with Moore-Penrose pseudoinverse typically have eigenvalues close to zero so that the latter diagonalization is the most precise therein.


// ALPHA_TYPE is necessary as integer alpha is not accepted otherwise.
template <typename SCALAR_TYPE, typename ALPHA_TYPE> 
void Moore_Penrose_pow_symmetric (class matrix<SCALAR_TYPE> &A , const ALPHA_TYPE &alpha , const double SVD_precision)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("Moore_Penrose_pow_symmetric is used with square matrices only (real part)");

  if (!A.isfinite ()) error_message_print_abort ("The matrix is not finite in Moore_Penrose_pow_symmetric");

  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in Moore_Penrose_pow_symmetric");
  
  const unsigned int dimension = A.get_dimension ();

  if (A.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  SCALAR_TYPE &A_ii = A(i , i);

	  A_ii = (inf_norm (A_ii) > SVD_precision) ? (pow (A_ii , alpha)) : (0.0);
	}

      return;
    }

  class array<SCALAR_TYPE> eigenvalues (dimension);

  // P and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in P.
  
  class matrix<SCALAR_TYPE> P_transpose = A;
  
  if (A.is_it_real ())
    total_diagonalization::symmetric::all_eigenpairs_Householder (P_transpose , eigenvalues);
  else
    total_diagonalization::symmetric::all_eigenpairs_Newton (P_transpose , eigenvalues);

  // {Dp}^{\alpha} P is stored in A as fD_P_transpose is a reference to A
  
  class matrix<SCALAR_TYPE> &Dp_pow_alpha_P_transpose = A;

  Dp_pow_alpha_P_transpose = 0.0;
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      if (inf_norm (eigenvalue_i) > SVD_precision)
	{	
	  const SCALAR_TYPE eigenvalue_i_pow_alpha_maybe_inf = pow (eigenvalue_i , alpha);

	  const SCALAR_TYPE eigenvalue_i_pow_alpha = (finite (eigenvalue_i_pow_alpha_maybe_inf)) ? (eigenvalue_i_pow_alpha_maybe_inf) : (0.0);
 
	  const class vector_class<SCALAR_TYPE> &Pi_transpose = P_transpose.row_vector (i);

	  class vector_class<SCALAR_TYPE> &Dp_pow_alpha_Pi_transpose = Dp_pow_alpha_P_transpose.row_vector (i);

	  Dp_pow_alpha_Pi_transpose = Pi_transpose;
      
	  Dp_pow_alpha_Pi_transpose *= eigenvalue_i_pow_alpha;
	}
    }
  
  // P^(-1) is given by P.transpose () and stored in P

  class matrix<SCALAR_TYPE> &P = P_transpose;
  
  P.transpose ();
  
  // {Ap}^{\alpha} = P.{Dp}^{\alpha}.P_transpose is stored in A
  // The temporary matrix created in operator * is unavoidable as A and Dp_pow_alpha_P_transpose are the same object.
  A = P*Dp_pow_alpha_P_transpose;

  A.symmetrize ();
}






// ALPHA_TYPE is necessary as integer alpha is not accepted otherwise.
template <typename SCALAR_TYPE, typename ALPHA_TYPE>  
void Moore_Penrose_pow_hermitian (class matrix<SCALAR_TYPE> &Ar , class matrix<SCALAR_TYPE> &Ai , const ALPHA_TYPE &alpha , const double SVD_precision)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("Moore_Penrose_pow_hermitian is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("Moore_Penrose_pow_hermitian is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ())        error_message_print_abort ("The matrix is not finite in Moore_Penrose_pow_hermitian (real part)");
  if (!Ai.isfinite ())        error_message_print_abort ("The matrix is not finite in Moore_Penrose_pow_hermitian (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in Moore_Penrose_pow_hermitian");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in Moore_Penrose_pow_hermitian");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in Moore_Penrose_pow_hermitian");
  
  const unsigned int dimension = Ar.get_dimension ();	

  if (Ar.is_it_diagonal () && Ai.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{	
	  SCALAR_TYPE &Ar_ii = Ar(i , i);

	  Ar_ii = (inf_norm (Ar_ii) > SVD_precision) ? (pow (Ar_ii , alpha)) : (0.0);
	}

      return;
    }
      
  class array<SCALAR_TYPE> eigenvalues (dimension);

  // Pr, Pi and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in Pr and Pi.
  
  class matrix<SCALAR_TYPE> Pr_transpose = Ar;
  class matrix<SCALAR_TYPE> Pi_transpose = Ai;

  if (Ar.is_it_real () && Ai.is_it_real ())
    total_diagonalization::hermitian::all_eigenpairs_Householder (Pr_transpose , Pi_transpose , eigenvalues);
  else
    total_diagonalization::hermitian::all_eigenpairs_Newton (Pr_transpose , Pi_transpose , eigenvalues);
  
  // I do not use references for next matrices therein as one needs both next matrices for Ar and Ai, calculated one after the other.
  
  class matrix<SCALAR_TYPE> Dp_pow_alpha_Pr_transpose = Ar;
  class matrix<SCALAR_TYPE> Dp_pow_alpha_Pi_transpose = Ai;

  Dp_pow_alpha_Pr_transpose = 0.0;
  Dp_pow_alpha_Pi_transpose = 0.0;
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      if (inf_norm (eigenvalue_i) > SVD_precision)
	{	
	  const SCALAR_TYPE eigenvalue_i_pow_alpha_maybe_inf = pow (eigenvalue_i , alpha);

	  const SCALAR_TYPE eigenvalue_i_pow_alpha = (finite (eigenvalue_i_pow_alpha_maybe_inf)) ? (eigenvalue_i_pow_alpha_maybe_inf) : (0.0);
 
	  const class vector_class<SCALAR_TYPE> &Pr_transpose_i = Pr_transpose.row_vector (i);
	  const class vector_class<SCALAR_TYPE> &Pi_transpose_i = Pi_transpose.row_vector (i);

	  class vector_class<SCALAR_TYPE> &Dp_pow_alpha_Pr_transpose_i = Dp_pow_alpha_Pr_transpose.row_vector (i);
	  class vector_class<SCALAR_TYPE> &Dp_pow_alpha_Pi_transpose_i = Dp_pow_alpha_Pi_transpose.row_vector (i);

	  Dp_pow_alpha_Pr_transpose_i = Pr_transpose_i;
	  Dp_pow_alpha_Pi_transpose_i = Pi_transpose_i;
      
	  Dp_pow_alpha_Pr_transpose_i *= eigenvalue_i_pow_alpha;
	  Dp_pow_alpha_Pi_transpose_i *= eigenvalue_i_pow_alpha;
	}
    }
  
  // {Pr + i.Pi}^(-1)  = {Pr + i.Pi}^{+} = Pr.transpose () - i.Pi.transpose ()
  
  class matrix<SCALAR_TYPE> &Pr = Pr_transpose;
  class matrix<SCALAR_TYPE> &Pi = Pi_transpose;
  
  Pr.transpose ();
  Pi.transpose ();
      
  // {Ap}^{\alpha} = P.{Dp}^{\alpha}.P_dagger is stored in A
  // One uses a work matrix here to avoid the matrix temporaries induced by operator *

  class matrix<SCALAR_TYPE> M(dimension);

  matrix_multiplication (Pr , Dp_pow_alpha_Pr_transpose , M) , Ar  = M;  
  matrix_multiplication (Pi , Dp_pow_alpha_Pi_transpose , M) , Ar += M;
 
  matrix_multiplication (Pi , Dp_pow_alpha_Pr_transpose , M) , Ai  = M;
  matrix_multiplication (Pr , Dp_pow_alpha_Pi_transpose , M) , Ai -= M; 

  Ar.symmetrize ();
  Ai.antisymmetrize ();
}


// Special cases of Moore Penrose powers

void Moore_Penrose_pow (class matrix<double> &A , const int alpha , const double SVD_precision);
void Moore_Penrose_pow (class matrix<double> &A , const double alpha , const double SVD_precision);

void Moore_Penrose_pow (class matrix<complex<double> > &A , const int alpha , const double SVD_precision);
void Moore_Penrose_pow (class matrix<complex<double> > &A , const double alpha , const double SVD_precision);
void Moore_Penrose_pow (class matrix<complex<double> > &A , const complex<double> &alpha , const double SVD_precision);
  
void pseudo_inverse         (class matrix<double> &A , const double SVD_precision);
void Moore_Penrose_sqrt     (class matrix<double> &A , const double SVD_precision);
void Moore_Penrose_sqrt_inv (class matrix<double> &A , const double SVD_precision);
void Moore_Penrose_cbrt     (class matrix<double> &A , const double SVD_precision);
void Moore_Penrose_cbrt_inv (class matrix<double> &A , const double SVD_precision);

void pseudo_inverse         (class matrix<complex<double> > &A , const double SVD_precision);
void Moore_Penrose_sqrt     (class matrix<complex<double> > &A , const double SVD_precision);
void Moore_Penrose_sqrt_inv (class matrix<complex<double> > &A , const double SVD_precision);
void Moore_Penrose_cbrt     (class matrix<complex<double> > &A , const double SVD_precision);
void Moore_Penrose_cbrt_inv (class matrix<complex<double> > &A , const double SVD_precision);


template <typename SCALAR_TYPE> 
void Moore_Penrose_pow (class block_matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &alpha , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      Moore_Penrose_pow (A_block , alpha , SVD_precision);
    }  
}


template <typename SCALAR_TYPE>
void pseudo_inverse (class block_matrix<SCALAR_TYPE> &A , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      pseudo_inverse (A_block , SVD_precision);
    }  
}


template <typename SCALAR_TYPE>
void Moore_Penrose_sqrt (class block_matrix<SCALAR_TYPE> &A , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      Moore_Penrose_sqrt (A_block , SVD_precision);
    }  
}


template <typename SCALAR_TYPE>
void Moore_Penrose_sqrt_inv (class block_matrix<SCALAR_TYPE> &A , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      Moore_Penrose_sqrt_inv (A_block , SVD_precision);
    }  
}



template <typename SCALAR_TYPE>
void Moore_Penrose_cbrt (class block_matrix<SCALAR_TYPE> &A , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      Moore_Penrose_cbrt (A_block , SVD_precision);
    }  
}


template <typename SCALAR_TYPE>
void Moore_Penrose_cbrt_inv (class block_matrix<SCALAR_TYPE> &A , const double SVD_precision)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      Moore_Penrose_cbrt_inv (A_block , SVD_precision);
    }  
}







// Matrix function using diagonalization
// (for small matrices)
// ======================
// The matrix has to be symmetric (double, complex) or hermitian (complex, bicomplex).
// 1) diagonalization of the input matrix A = P^(-1) D P
// 2) calculation of a pseudo inverse function of the input matrix:
// f(A) = P^(-1) f(D) P
// with D the diagonal matrix and f(D) its function image
// f is a scalar function of one scalar argument.
// f(D).P  is stored in A.
// f(A) is stored in A.
// Routines are optimized so as to limit memory use of matrices: three matrices must be present in memory.
// Double and complex have to be separated , as the double argument in f is given by value and the complex argument by reference.
// If f(x) is not defined , it is assumed that one calculates for example sqrt (-epsilon) instead of sqrt (0.0) for the double case. 
// Hence , f(0.0) is taken instead therein by default , as A is assumed to be positive definite if f = sqrt for the double case.
// Analogous routines are done for hermitian matrices.


void matrix_function_symmetric (class matrix<double> &A , double (&f) (const double) );

void matrix_function_hermitian (class matrix<double> &A , double (&f) (const double) );

void matrix_function_hermitian (class matrix<double> &Ar , class matrix<double> &Ai , double (&f) (const double) );

void matrix_function_symmetric (class matrix<complex<double> > &A , complex<double> (&f) (const complex<double> &) );

void matrix_function_hermitian (class matrix<complex<double> > &Ar , class matrix<complex<double> > &Ai , complex<double> (&f) (const complex<double> &) );

void matrix_function_hermitian (class matrix<complex<double> > &A , double (&f) (double) );

void block_matrix_function_symmetric (class block_matrix<double> &A , double (&f) (const double) );

void block_matrix_function_hermitian (class block_matrix<complex<double> > &A, double (&f) (const double) );

void block_matrix_function_symmetric (class block_matrix<complex<double> > &A , complex<double> (&f) (const complex<double> &) );




//
// Calculation of a polynomial matrix with the Horner scheme.
// ----------------------------------------------------------
// The matrix has to be symmetric (double, complex) or hermitian (complex, bicomplex).
// 1) diagonalization of the input matrix A = P^(-1) D P
// 2) calculation of a pseudo inverse function of the input matrix:
// poly(A) = P^(-1) poly(D) P
// with D the diagonal matrix and poly(D) its polynomial
// poly(D).P  is stored in A.
// poly(A) is stored in A.
// Routines are optimized so as to limit memory use of matrices: three matrices must be present in memory.

template <typename SCALAR_TYPE>
void poly_matrix_function_symmetric (
				     const unsigned int degree , 
				     const class array<SCALAR_TYPE> &coefficients , 
				     class matrix<SCALAR_TYPE> &A) 
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("poly_matrix_function_symmetric is used with square matrices only");

  if (!A.isfinite ())        error_message_print_abort ("The matrix is not finite in poly_matrix_function_symmetric");
  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in poly_matrix_function_symmetric");

  const unsigned int dimension = A.get_dimension ();	

  if (A.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{	
	  SCALAR_TYPE &Aii = A(i , i);
	  
	  Aii = polynomial_evaluation (degree , coefficients , Aii);
	}

      return;
    }

  class array<SCALAR_TYPE> eigenvalues (dimension);

  // P and eigenvalues are filled
  class matrix<SCALAR_TYPE> P_transpose = A;

  if (A.is_it_real ())
    total_diagonalization::symmetric::all_eigenpairs_Householder (P_transpose , eigenvalues);
  else
    total_diagonalization::symmetric::all_eigenpairs_Newton (P_transpose , eigenvalues);

  // poly(D).P_transpose is stored in A as poly_D_P_transpose is a reference to A
  class matrix<SCALAR_TYPE> &poly_D_P_transpose = A;

  poly_D_P_transpose = 0.0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      const SCALAR_TYPE poly_eigenvalue_i = polynomial_evaluation (degree , coefficients , eigenvalue_i);

      const class vector_class<SCALAR_TYPE> &Pi_transpose = P_transpose.row_vector (i);
      
      class vector_class<SCALAR_TYPE> &poly_D_Pi_transpose = poly_D_P_transpose.row_vector (i);

      poly_D_Pi_transpose = Pi_transpose;
      
      poly_D_Pi_transpose *= poly_eigenvalue_i;
    }

  // P^(-1) is given by P.transpose () and stored in P

  class matrix<SCALAR_TYPE> &P = P_transpose;
  
  P.transpose ();

  // poly(A) = P_transpose.f(D).P is stored in A
  // The temporary matrix created in operator * is unavoidable as A and Dp_pow_alpha_P_transpose are the same object.
  A = P*poly_D_P_transpose;

  A.symmetrize ();
}







template <typename SCALAR_TYPE>
void poly_matrix_function_hermitian (
				     const unsigned int degree , 
				     const class array<SCALAR_TYPE> &coefficients , 
				     class matrix<SCALAR_TYPE> &Ar ,
				     class matrix<SCALAR_TYPE> &Ai)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("poly_matrix_function_hermitian is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("poly_matrix_function_hermitian is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ())        error_message_print_abort ("The matrix is not finite in poly_matrix_function_hermitian (real part)");
  if (!Ai.isfinite ())        error_message_print_abort ("The matrix is not finite in poly_matrix_function_hermitian (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in poly_matrix_function_hermitian");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in poly_matrix_function_hermitian");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in poly_matrix_function_hermitian");
  
  const unsigned int dimension = Ar.get_dimension ();

  if (Ar.is_it_diagonal () && Ai.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  SCALAR_TYPE &Ar_ii = Ar(i , i);

	  Ar_ii = polynomial_evaluation (degree , coefficients , Ar_ii);
	}

      return;
    }

  class array<SCALAR_TYPE> eigenvalues (dimension);

  // P and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in Pr and Pi.
  
  class matrix<SCALAR_TYPE> Pr_transpose = Ar;
  class matrix<SCALAR_TYPE> Pi_transpose = Ai;

  if (Ar.is_it_real () && Ai.is_it_real ())
    total_diagonalization::hermitian::all_eigenpairs_Householder (Pr_transpose , Pi_transpose , eigenvalues);
  else
    total_diagonalization::hermitian::all_eigenpairs_Newton (Pr_transpose , Pi_transpose , eigenvalues);
    
  // I do not use references for all next matrices therein as one needs both next matrices for Ar and Ai, calculated one after the other.

  class matrix<SCALAR_TYPE> poly_D_Pr_transpose = Ar;
  class matrix<SCALAR_TYPE> poly_D_Pi_transpose = Ai;

  poly_D_Pr_transpose = 0.0;
  poly_D_Pi_transpose = 0.0;
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      const SCALAR_TYPE poly_eigenvalue_i = polynomial_evaluation (degree , coefficients , eigenvalue_i);
 
      const class vector_class<SCALAR_TYPE> &Pr_transpose_i = Pr_transpose.row_vector (i);
      const class vector_class<SCALAR_TYPE> &Pi_transpose_i = Pi_transpose.row_vector (i);

      class vector_class<SCALAR_TYPE> &poly_D_Pr_transpose_i = poly_D_Pr_transpose.row_vector (i);
      class vector_class<SCALAR_TYPE> &poly_D_Pi_transpose_i = poly_D_Pi_transpose.row_vector (i);

      poly_D_Pr_transpose_i = Pr_transpose_i;
      poly_D_Pi_transpose_i = Pi_transpose_i;
      
      poly_D_Pr_transpose_i *= poly_eigenvalue_i;
      poly_D_Pi_transpose_i *= poly_eigenvalue_i;
    }
  
  // {Pr + i.Pi}^(-1)  = {Pr + i.Pi}^{+} = Pr.transpose () - i.Pi.transpose ()
  
  class matrix<SCALAR_TYPE> &Pr = Pr_transpose;
  class matrix<SCALAR_TYPE> &Pi = Pi_transpose;
  
  Pr.transpose ();
  Pi.transpose ();

  // {Ap}^{\alpha} = P_dagger.poly(D).P is stored in A
  // One uses a work matrix here to avoid the matrix temporaries induced by operator *
  
  class matrix<SCALAR_TYPE> M(dimension);

  matrix_multiplication (Pr , poly_D_Pr_transpose , M) , Ar  = M;  
  matrix_multiplication (Pi , poly_D_Pi_transpose , M) , Ar += M;

  matrix_multiplication (Pi , poly_D_Pr_transpose , M) , Ai  = M;
  matrix_multiplication (Pr , poly_D_Pi_transpose , M) , Ai -= M;  
  
  Ar.symmetrize ();
  Ai.antisymmetrize ();
}





// Specializations

class matrix<double> polynomial_evaluation (
					    const unsigned int degree , 
					    const class array<double> &coefficients , 
					    const class matrix<double> &A);


class matrix<complex<double> > polynomial_evaluation (
						      const unsigned int degree , 
						      const class array<complex<double> > &coefficients , 
						      const class matrix<complex<double> > &A);



template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> polynomial_evaluation (
						       const unsigned int degree , 
						       const class array<SCALAR_TYPE> &coefficients , 
						       const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> poly_A = A;
    
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);
      
      class matrix<SCALAR_TYPE> &poly_A_block = poly_A(i);

      poly_A_block = polynomial_evaluation (degree , coefficients , A_block);
    }

  return poly_A;
}








// Direct calculation is effected for alpha integer with  -1 <= alpha <= 2, as then calculations are trivial or come from other routines.

// ALPHA_TYPE is necessary as integer alpha is not accepted otherwise.
template <typename SCALAR_TYPE, typename ALPHA_TYPE>  
class matrix<SCALAR_TYPE> pow (const class matrix<SCALAR_TYPE> &A , const ALPHA_TYPE &alpha)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("pow (complex) is used with square matrices only");

  if (!A.isfinite ()) error_message_print_abort ("The matrix is not finite in pow (complex)");

  const bool is_A_symmetric = A.is_it_symmetric ();
  const bool is_A_hermitian = A.is_it_hermitian ();
  
  if (!is_A_symmetric && !is_A_hermitian) error_message_print_abort ("The matrix must be symmetric or hermitian in pow (complex)");
	
  if (!is_A_symmetric && is_A_hermitian && (imag_dc (alpha) != 0.0)) error_message_print_abort ("alpha has to be real in pow (complex) in the hermitian case for A^alpha to be hermitian");
  
  const unsigned int N = A.get_dimension ();

  if (A.is_it_diagonal ())
    {
      class matrix<SCALAR_TYPE> A_pow(N);
  
      A_pow = 0.0;

      for (unsigned int i = 0 ; i < N ; i++) A_pow(i , i) = pow (A(i , i) , alpha);

      return A_pow;
    }

  if (alpha == 0)
    {
      class matrix<SCALAR_TYPE> A_pow(N);
      
      A_pow.identity ();
 
      return A_pow;
    }

  if (alpha == 2)
    {
      class matrix<SCALAR_TYPE> A_pow = A*A;

      if (is_A_symmetric)
	A_pow.symmetrize ();
      else if (is_A_hermitian)
	A_pow.hermitize ();
 
      return A_pow;
    }
  
  if (alpha == 1) return A;
  
  if (alpha == -1)
    {
      class matrix<SCALAR_TYPE> A_pow = A;
      
      A_pow.inverse ();

      if (is_A_symmetric)
	A_pow.symmetrize ();
      else if (is_A_hermitian)
	A_pow.hermitize ();
  
      return A_pow;
    }
        
  class matrix<SCALAR_TYPE> A_pow = A;
      
  Moore_Penrose_pow (A_pow , alpha , 0.0);
 
  return A_pow;
}







// ALPHA_TYPE is necessary as integer alpha is not accepted otherwise.
template <typename SCALAR_TYPE, typename ALPHA_TYPE>  
class block_matrix<SCALAR_TYPE> pow (const class block_matrix<SCALAR_TYPE> &A , const ALPHA_TYPE &alpha)
{
  class block_matrix<SCALAR_TYPE> A_pow = A;
      
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);
      
      class matrix<SCALAR_TYPE> &A_pow_block = A_pow(i);

      A_pow_block = pow (A_block , alpha); 
    }

  return A_pow;
}






// Solution of the diagonal linear system AX = B
// ---------------------------------------------
// It is a simple wrapper of the diagonal system, trivial to solve.

template <typename SCALAR_TYPE>
void diagonal_linear_system_solution_calc (
					   const class array<SCALAR_TYPE> &diagonal_table ,
					   const class vector_class<SCALAR_TYPE> &B ,
					   class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int N = B.get_dimension ();

  X = B;

  for (unsigned int i = 0 ; i < N ; i++) X(i) /= diagonal_table(i);
}

template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> diagonal_linear_system_solution (
								 const class array<SCALAR_TYPE> &diagonal_table ,
								 const class vector_class<SCALAR_TYPE> &B)
{
  const unsigned int N = B.get_dimension ();
  
  class vector_class<SCALAR_TYPE> X = B;

  for (unsigned int i = 0 ; i < N ; i++) X(i) /= diagonal_table(i);

  return X;
}




// Solution of the tridiagonal linear system AX = B
// ------------------------------------------------
// The linear system is exactly solved for dimensions 1 and 2. 
// Otherwise, the Thomas algorithm is used.
// It is the LU decomposition for tridiagonal matrices and is O(N).
// No pivoting is done, as LU decomposition for tridiagonal matrices is typically very stable (see Numerical Recipes and after as well).
// We do not consider Cholesky decomposition here and the decomposition is done everytime the function is called as the Thomas algorithm is fast.
//
// A is stored as three arrays, sub_diagonal, diagonal and super_diagonal.
// Two work arrays are used in the routine.
// The Thomas algorithm can be unstable if diagonal matrix elements are too small relatively to off-diagonal matrix elements.
// Hence, the calculation solution is tested if |diagonal_table(i)|oo < (|sub_diagonal_table(i)|oo + |superdiagonal_table(i)|oo)/10 for an index i (A factor of 1/10 has been checked to be large enough) .
// The code stops if it is not precise up to 10^(-10) in relative precision.
// However, this situation has never been found in practice, where precision ~ 10^(-15), even though matrices are mildly ill-conditioned (condition number ~ 10^(-3)) in the Lanczos full diagonalization method.
// If one encounters a pathological case, one should use LU decomposition instead with a full matrix.
// As one needs the initial matrix to test the precision of X, the matrix is not destroyed, contrary to the general case, but then one needs two additional work arrays therein.
//
// As the overload generated by the allocation/deallocation of a few arrays is typically negligible, a wrapper is provided where no work arrays are demanded as inputs and where X is returned instead of being a variable array.
// This wrapper makes codes much more concise without generating speed or memory lags in most situations.
//
// Determinant and its scaled logarithm and phase are available as determinant is the product of the diagonal terms of the LU matrices.
// It has been checked to be precise even if diagonal matrix elements are small.
// See matrix <SCALAR_TYPE>::determinant and matrix <SCALAR_TYPE>::log_scaled_determinant_and_phase for method.
// The matrix is destroyed, as in the general case.





template <typename SCALAR_TYPE>
void Thomas_decompose (
		       class array<SCALAR_TYPE> &diagonal_work_table ,
		       class array<SCALAR_TYPE> &sub_diagonal_work_table ,
		       const class array<SCALAR_TYPE> &super_diagonal_table)
{
  const unsigned int N = diagonal_work_table.dimension (0);
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (diagonal_work_table(i) == 0) diagonal_work_table(i) = 1E-15;
    }
 
  for (unsigned int i = 1 ; i < N ; i++)
    {
      const unsigned int im1 = i - 1;
      
      SCALAR_TYPE &sub_diagonal_work_table_im1 = sub_diagonal_work_table(im1);
      
      sub_diagonal_work_table_im1 /= diagonal_work_table(im1);
      
      diagonal_work_table(i) -= sub_diagonal_work_table_im1*super_diagonal_table(im1);     
    }
}











template <typename SCALAR_TYPE>
void tridiagonal_linear_system_solution_calc (
					      const class array<SCALAR_TYPE> &sub_diagonal_table ,
					      const class array<SCALAR_TYPE> &diagonal_table ,
					      const class array<SCALAR_TYPE> &super_diagonal_table ,
					      class array<SCALAR_TYPE> &sub_diagonal_work_table ,
					      class array<SCALAR_TYPE> &diagonal_work_table ,  
					      const class vector_class<SCALAR_TYPE> &B ,
					      class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int N = B.get_dimension ();

  if (N == 0) return;
  
  const unsigned int Nm1 = N - 1;
  
  bool is_it_diagonal = true;
   
  for (unsigned int i = 0 ; is_it_diagonal && (i < Nm1) ; i++)
    {
      if ((sub_diagonal_table(i) != 0.0) || (super_diagonal_table(i) != 0.0)) is_it_diagonal = false;
    }

  if (is_it_diagonal)
    {
      diagonal_linear_system_solution_calc (diagonal_table , B , X);
      
      return;
    }

  if (N == 2)
    {
      const SCALAR_TYPE &A00 = diagonal_table(0);
      const SCALAR_TYPE &A11 = diagonal_table(1);
      
      const SCALAR_TYPE &A01 = super_diagonal_table(0);
      const SCALAR_TYPE &A10 = sub_diagonal_table(0);

      const SCALAR_TYPE &B0 = B(0);
      const SCALAR_TYPE &B1 = B(1);

      const SCALAR_TYPE A_determinant = A00*A11 - A01*A10;

      X(0) =  (A11*B0 - A01*B1)/A_determinant;
      X(1) = -(A10*B0 - A00*B1)/A_determinant;
      
      return;
    }
    
  
  const unsigned int Nm2 = N - 2;
  
  diagonal_work_table = diagonal_table;
  
  sub_diagonal_work_table = sub_diagonal_table;

  Thomas_decompose (diagonal_work_table , sub_diagonal_work_table , super_diagonal_table);
  
  X = B;
  
  for (unsigned int i = 1 ; i < N ; i++)
    {
      const unsigned int im1 = i - 1;
      
      X(i) -= sub_diagonal_work_table(im1)*X(im1);
    }
    
  X(Nm1) /= diagonal_work_table(Nm1);

  for (unsigned int i = Nm2 ; i <= Nm2 ; i--)
    {
      SCALAR_TYPE &Xi = X(i);

      Xi -= super_diagonal_table(i)*X(i + 1);
	
      Xi /= diagonal_work_table(i);
    }
  
  bool is_diagonal_large_enough = true;
      
  for (unsigned int i = 0 ; is_diagonal_large_enough && (i < N) ; i++) is_diagonal_large_enough = (inf_norm (diagonal_table(i)) > 0.1*(inf_norm (sub_diagonal_table(i)) + inf_norm (super_diagonal_table(i))));

  if (!is_diagonal_large_enough)
    {
      const double X_infinite_norm = X.infinite_norm ();
  
      double X_test = inf_norm (diagonal_table(0)*X(0) + super_diagonal_table(0)*X(1) - B(0));
  
      for (unsigned int i = 1 ; i < Nm1 ; i++)
	{
	  const unsigned int im1 = i - 1;
	  
	  X_test = max (X_test , inf_norm (sub_diagonal_table(im1)*X(im1) + diagonal_table(i)*X(i) + super_diagonal_table(i)*X(i + 1) - B(i)));
	}
      
      X_test = max (X_test , inf_norm (sub_diagonal_table(Nm2)*X(Nm2) + diagonal_table(Nm1)*X(Nm1) - B(Nm1)));
  
      if (X_infinite_norm != 0.0) X_test /= X_infinite_norm;

      if (!finite (X_test)) error_message_print_abort ("Infinite numbers encountered in the solution of a tridiagonal linear system");
      
      if (X_test > precision) error_message_print_abort ("Solution of a tridiagonal linear system imprecise");
    }
}




template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> tridiagonal_linear_system_solution (
								    const class array<SCALAR_TYPE> &sub_diagonal_table ,
								    const class array<SCALAR_TYPE> &diagonal_table ,
								    const class array<SCALAR_TYPE> &super_diagonal_table ,
								    const class vector_class<SCALAR_TYPE> &B)
{
  const unsigned int N = B.get_dimension ();
  
  class array<SCALAR_TYPE> diagonal_work_table(N);
  
  class array<SCALAR_TYPE> sub_diagonal_work_table(N);
    
  class vector_class<SCALAR_TYPE> X(N);
  
  tridiagonal_linear_system_solution_calc (sub_diagonal_table , diagonal_table , super_diagonal_table , sub_diagonal_work_table , diagonal_work_table , B , X);

  return X;
}















template <typename SCALAR_TYPE>
SCALAR_TYPE tridiagonal_determinant (
				     class array<SCALAR_TYPE> &sub_diagonal_table ,
				     class array<SCALAR_TYPE> &diagonal_table ,
				     const class array<SCALAR_TYPE> &super_diagonal_table)
{
  const unsigned int N = diagonal_table.dimension (0);
  
  if (N == 0) return 1.0;
  
  if (N == 1) return diagonal_table(0);

  if (N == 2) return (diagonal_table(0)*diagonal_table(1) - sub_diagonal_table(0)*super_diagonal_table(0));
  
  Thomas_decompose (diagonal_table , sub_diagonal_table , super_diagonal_table);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (diagonal_table(i) == 0.0) return 0.0;
    }
      
  const SCALAR_TYPE diagonal_elements_product = diagonal_table.product ();

  if (!finite (diagonal_elements_product) || (diagonal_elements_product == 0.0))
    {
      int phase = 1;
	  
      SCALAR_TYPE log_Det_no_phase = 0.0;
	   
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  if (real_dc (diagonal_table(i)) >= 0.0)
	    log_Det_no_phase += log (diagonal_table(i));
	  else
	    {		 
	      log_Det_no_phase += log (-diagonal_table(i));
		  
	      phase = -phase;
	    }
	}
      
      const SCALAR_TYPE Det = phase*exp (log_Det_no_phase);

      return Det;
    }
  else
    return diagonal_elements_product;
}









template <typename SCALAR_TYPE>
void tridiagonal_log_scaled_determinant_and_phase (
						   class array<SCALAR_TYPE> &sub_diagonal_table ,
						   class array<SCALAR_TYPE> &diagonal_table ,
						   const class array<SCALAR_TYPE> &super_diagonal_table ,
						   SCALAR_TYPE &log_Det_no_phase ,
						   int &phase)
{
  const unsigned int N = diagonal_table.dimension (0);
  
  log_Det_no_phase = 0.0;
  
  phase = 1;
  
  if (N == 0) return;

  if (N == 1)
    {
      const SCALAR_TYPE &d0 = diagonal_table(0);

      if (real_dc (d0) >= 0.0)
	log_Det_no_phase = log (d0);
      else
	{
	  log_Det_no_phase = log (-d0);

	  phase = -1;
	}

      return;     
    }

  if (N == 2)
    {
      const SCALAR_TYPE Det = diagonal_table(0)*diagonal_table(1) - sub_diagonal_table(0)*super_diagonal_table(0);

      if (real_dc (Det) >= 0.0)
	log_Det_no_phase = log (Det);
      else
	{
	  log_Det_no_phase = log (-Det);

	  phase = -1;
	}
      
      return;  
    }

  Thomas_decompose (diagonal_table , sub_diagonal_table , super_diagonal_table);
	   
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (real_dc (diagonal_table(i)) >= 0.0)
	log_Det_no_phase += log (diagonal_table(i));
      else
	{		 
	  log_Det_no_phase += log (-diagonal_table(i));
		  
	  phase = -phase;
	}
    }
}








// Solution of the linear system AX = B
// ------------------------------------
// A direct calculation is done if A is diagonal or if dimension is equal to two.
// Cholesky decomposition is firstly tested. 
// LU decomposition is used otherwise if Cholesky decomposition failed.
// Backsubstitution is done after the matrix is LU or Cholesky decomposed.
// The calculation cost is about N^3/3 for LU decomposition, N^3/6 for Cholesky decomposition, and is about N^2 for backsustitution.

template <typename SCALAR_TYPE>
void linear_system_solution_calc (
				  class matrix<SCALAR_TYPE> &A ,
				  const class vector_class<SCALAR_TYPE> &B ,
				  class vector_class<SCALAR_TYPE> &X)
{	
  if (A.is_it_Cholesky_decomposed ())
    {
      A.Cholesky_backsubstitute (B , X);

      return;
    }
  
  if (A.is_it_LU_decomposed ())
    {
      A.LU_backsubstitute (B , X);
    
      return;
    }
  
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("linear_system_solution_calc is used with square matrices only");

  if (A.get_dimension () != B.get_dimension ()) error_message_print_abort ("Matrix and vector must have the same dimension in linear_system_solution_calc");

  const unsigned int N = A.get_dimension ();

  if (A.is_it_diagonal ())
    {
      X = B;

      for (unsigned int i = 0 ; i < N ; i++) X(i) /= A(i , i);

      return;
    }
  else if (N == 2)
    {
      const SCALAR_TYPE &A00 = A(0 , 0);
      const SCALAR_TYPE &A01 = A(0 , 1);
      const SCALAR_TYPE &A10 = A(1 , 0);
      const SCALAR_TYPE &A11 = A(1 , 1);

      const SCALAR_TYPE &B0 = B(0);
      const SCALAR_TYPE &B1 = B(1);

      const SCALAR_TYPE A_determinant = A00*A11 - A01*A10;

      X(0) =  (A11*B0 - A01*B1)/A_determinant;
      X(1) = -(A10*B0 - A00*B1)/A_determinant;

      return;
    }
  else
    {      
      if (A.is_it_symmetric () || A.is_it_hermitian ()) A.Cholesky_decompose ();
      
      if (A.is_it_Cholesky_decomposed ())
	A.Cholesky_backsubstitute (B , X);
      else
	{
	  A.LU_decompose ();
	  
	  A.LU_backsubstitute (B , X);
	}
    }
}


template <typename SCALAR_TYPE>
void linear_system_solution_calc (
				  class block_matrix<SCALAR_TYPE> &A ,
				  const class vector_class<SCALAR_TYPE> &B ,
				  class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int blocks_number = A.get_blocks_number ();
    
  X = B;
      
  unsigned int B_index = 0;
  unsigned int X_index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      const unsigned int A_block_dimension = A_block.get_dimension ();
      
      class vector_class<SCALAR_TYPE> B_block(A_block_dimension);
      class vector_class<SCALAR_TYPE> X_block(A_block_dimension);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) B_block(ii) = B(B_index++);
      
      linear_system_solution_calc (A_block , B_block , X_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) X(X_index++) = X_block(ii);
    }
}



// SVD solution of a linear system 
// -------------------------------
// The SVD solution of the linear system AX = B via Moore_Penrose pseudo-inverse is calculated.
// Symmetric or hermitian matrices only are supposed to be handled here.
// relative_SVD_precision is the relative precision below which an eigenvalue is treated as zero.
// If relative_SVD_precision is equal to zero , a standard LU decomposition is used. 
// It is slightly faster than using pseudo_inverse with Moore_Penrose_pow for symmetric matrices, as no matrix product is used.
// One does not need any additional matrix either. Only matrix-vector operations take place: X = P^(-1) . Dp^(-1) . P . B
// A is either LU/Cholesky decomposed (relative_SVD_precision = 0 for symmetric matrices) , or is P (relative_SVD_precision != 0 for symmetric matrices)

template <typename SCALAR_TYPE>
void linear_system_SVD_solution_symmetric_calc (
						class matrix<SCALAR_TYPE> &A ,
						const class vector_class<SCALAR_TYPE> &B ,
						const double relative_SVD_precision ,
						class vector_class<SCALAR_TYPE> &X)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("linear_system_SVD_solution_calc is used with square matrices only");
  if (!A.isfinite ())                                      error_message_print_abort ("The matrix is not finite in linear_system_SVD_solution_calc");
  if (!A.is_it_symmetric ())                               error_message_print_abort ("The matrix is not symmetric in linear_system_SVD_solution_calc");
  if (A.get_dimension () != B.get_dimension ())            error_message_print_abort ("Matrix and vector must have the same dimension in linear_system_SVD_solution_calc");

  const unsigned int dimension = A.get_dimension ();

  if (A.is_it_diagonal ())
    {
      const double A_infinite_norm = A.infinite_norm ();

      const double SVD_precision = A_infinite_norm*relative_SVD_precision;

      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  SCALAR_TYPE &Aii = A(i , i);

	  X(i) = (inf_norm (Aii) > SVD_precision) ? (B(i)/Aii) : (0.0);

	  Aii = 1.0;
	}

      return;
    }

  if (relative_SVD_precision == 0.0)
    {
      linear_system_solution_calc (A , B , X);

      return;
    }
  
  class array<SCALAR_TYPE> eigenvalues(dimension);

  // A and eigenvalues are filled

  if (A.is_it_real ())
    total_diagonalization::symmetric::all_eigenpairs_Householder (A , eigenvalues);
  else
    total_diagonalization::symmetric::all_eigenpairs_Newton (A , eigenvalues);
    
  const double inf_norm_max_eigenvalue = inf_norm (eigenvalues(dimension - 1));

  const double SVD_precision = inf_norm_max_eigenvalue*relative_SVD_precision;

  class matrix<SCALAR_TYPE> &P_transpose = A;
  
  // P^(-1) B is calculated
  X = P_transpose*B;

  // Dp^(-1) P^(-1) B is calculated

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      if (inf_norm (eigenvalue_i) > SVD_precision) 
	X(i) /= eigenvalue_i;
      else
	X(i) = 0.0;
    }

  // P Dp^(-1) P^(-1) B is calculated

  class matrix<SCALAR_TYPE> &P = P_transpose;
  
  P.transpose ();

  X = P*X;
}


template <typename SCALAR_TYPE>
void linear_system_SVD_solution_hermitian_calc (
						class matrix<SCALAR_TYPE> &Ar ,
						class matrix<SCALAR_TYPE> &Ai ,
						const class vector_class<SCALAR_TYPE> &Br ,
						const class vector_class<SCALAR_TYPE> &Bi ,								      
						const double relative_SVD_precision ,
						class vector_class<SCALAR_TYPE> &Xr ,
						class vector_class<SCALAR_TYPE> &Xi)
{ 
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("linear_system_SVD_solution_hermitian_calc is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("linear_system_SVD_solution_hermitian_calc is used with square matrices only (imaginary part)");
  
  if (!Ar.isfinite ())        error_message_print_abort ("The matrix is not finite in linear_system_SVD_solution_hermitian_calc (real part)");
  if (!Ai.isfinite ())        error_message_print_abort ("The matrix is not finite in linear_system_SVD_solution_hermitian_calc (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in linear_system_SVD_solution_hermitian_calc");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in linear_system_SVD_solution_hermitian_calc");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in linear_system_SVD_solution_hermitian_calc");
  
  if (Ar.get_dimension_row () != Br.get_dimension ()) error_message_print_abort ("Matrix and input vector must have the same dimension in linear_system_SVD_solution_hermitian_calc (real part)");
  if (Ai.get_dimension_row () != Bi.get_dimension ()) error_message_print_abort ("Matrix and input vector must have the same dimension in linear_system_SVD_solution_hermitian_calc (imaginary part)");
  
  if (Ar.get_dimension_row () != Xr.get_dimension ()) error_message_print_abort ("Matrix and vector solution must have the same dimension in linear_system_SVD_solution_hermitian_calc (real part)");
  if (Ai.get_dimension_row () != Xi.get_dimension ()) error_message_print_abort ("Matrix and vector solution must have the same dimension in linear_system_SVD_solution_hermitian_calc (imaginary part)");
  
  const unsigned int dimension = Ar.get_dimension ();
  
  if (Ar.is_it_diagonal () && Ai.is_it_diagonal ())
    {
      const double A_infinite_norm = Ar.infinite_norm ();

      const double SVD_precision = A_infinite_norm*relative_SVD_precision;

      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  SCALAR_TYPE &Ar_ii = Ar(i , i);

	  if (inf_norm (Ar_ii) > SVD_precision)
	    {
	      const SCALAR_TYPE one_over_Ar_ii = 1.0/Ar_ii;
	  
	      Xr(i) = one_over_Ar_ii*Br(i);
	      Xi(i) = one_over_Ar_ii*Bi(i);
	    }
	  else
	    Xr(i) = Xi(i) = 0.0;
	  
	  Ar_ii = 1.0;
	}

      return;
    }

  class array<SCALAR_TYPE> eigenvalues (dimension);

  // Ar, Ai and eigenvalues are filled
  
  if (Ar.is_it_real () && Ai.is_it_real ())
    total_diagonalization::hermitian::all_eigenpairs_Householder (Ar , Ai , eigenvalues);
  else
    total_diagonalization::hermitian::all_eigenpairs_Newton (Ar , Ai , eigenvalues);

  const double inf_norm_max_eigenvalue = inf_norm (eigenvalues(dimension - 1));

  const double SVD_precision = inf_norm_max_eigenvalue*relative_SVD_precision;
  
  class matrix<SCALAR_TYPE> &Pr_transpose = Ar;
  class matrix<SCALAR_TYPE> &Pi_transpose = Ai;
  
  // P^(-1) B is calculated
  
  Xr = Pr_transpose*Br + Pi_transpose*Bi;
  Xi = Pr_transpose*Bi - Pi_transpose*Br;

  // Dp^(-1) P^(-1) B is calculated

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const SCALAR_TYPE eigenvalue_i = eigenvalues(i);

      if (inf_norm (eigenvalue_i) > SVD_precision)
	{
	  const SCALAR_TYPE one_over_eigenvalue_i = 1.0/eigenvalue_i;
	  
	  Xr(i) *= one_over_eigenvalue_i;
	  Xi(i) *= one_over_eigenvalue_i;
	}
      else
	Xr(i) = Xi(i) = 0.0;	  
    }

  // P Dp^(-1) P^(-1) B is calculated

  class matrix<SCALAR_TYPE> &Pr = Pr_transpose;
  class matrix<SCALAR_TYPE> &Pi = Pi_transpose;
  
  Pr.transpose ();
  Pi.transpose ();

  const class vector_class<SCALAR_TYPE> Xr_new = Pr*Xr - Pi*Xi;
  const class vector_class<SCALAR_TYPE> Xi_new = Pr*Xi + Pi*Xr;
    
  Xr = Xr_new;
  Xi = Xi_new;
}





void linear_system_SVD_solution_calc (
				      class matrix<double> &A ,
				      const class vector_class<double> &B ,
				      const double relative_SVD_precision , 
				      class vector_class<double> &X);


void linear_system_SVD_solution_calc (
				      class matrix<complex<double>> &A ,
				      const class vector_class<complex<double> > &B ,
				      const double relative_SVD_precision , 
				      class vector_class<complex<double> > &X);



template <typename SCALAR_TYPE>
void linear_system_SVD_solution_calc (
				      class block_matrix<SCALAR_TYPE> &A ,
				      const class vector_class<SCALAR_TYPE> &B ,
				      const double relative_SVD_precision , 
				      class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int blocks_number = A.get_blocks_number ();
    
  X = B;
      
  unsigned int B_index = 0;
  unsigned int X_index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      const unsigned int A_block_dimension = A_block.get_dimension ();
      
      class vector_class<SCALAR_TYPE> B_block(A_block_dimension);
      class vector_class<SCALAR_TYPE> X_block(A_block_dimension);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) B_block(ii) = B(B_index++);
      
      linear_system_SVD_solution_calc (A_block , B_block , relative_SVD_precision , X_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) X(X_index++) = X_block(ii);
    }
}







// Biconjugate stabilized method to solve a linear system 
// ------------------------------------------------------
// The biconjugate stabilized method is used to solve the linear system AX = B.
// A_app = A on its diagonal, except for its zeroes.
// One uses the A_inv_app preconditioner matrix, which is the inverse of A_app on its diagonal.
// Then, one has A_new = A_inv_app A and B_new = A_inv_app B.
// The new linear system A_new X = B_new is then solved directly with the biconjugate stabilized method.
// A and B are replaced by other values in the routine.
// Full and sparse matrix versions can be used.
//
// The number of iterations is fonction of the condition number c: ||X(k) - X|| ~ 2 ((c^(1/2) - 1)/(c^(1/2) + 1))^k, with X the exact solution.
// Hence, the number of number of iterations needed for convergence scales as c^(1/2) for c >> 1.

template <typename SCALAR_TYPE>
void linear_system_solution_biconjugate_gradient_stabilized_calc (
								  const bool printed_information ,
								  const double vector_solution_precision , 
								  class matrix<SCALAR_TYPE> &A ,
								  class vector_class<SCALAR_TYPE> &B ,
								  class vector_class<SCALAR_TYPE> &X)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("linear_system_solution_biconjugate_gradient_stabilized_calc is used with square matrices only (full)");
  if (A.get_dimension ()     != B.get_dimension ())        error_message_print_abort ("Matrix and vector must have the same dimension in linear_system_solution_biconjugate_gradient_stabilized_calc (full)");

  const unsigned int dimension = A.get_dimension ();
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {
      const SCALAR_TYPE diagonal_matrix_element = A(i , i);
      
      if (diagonal_matrix_element != 0.0)
	{		
	  A.row_vector(i) /= diagonal_matrix_element;
	  
	  B(i) /= diagonal_matrix_element;
	}
    }

  X = B;
  
  class vector_class<SCALAR_TYPE> AX = A*X , R = B - AX;
  
  if (R.infinite_norm () < vector_solution_precision) return;

  B = R;

  class vector_class<SCALAR_TYPE> P(dimension) , S(dimension) , U(dimension) , V(dimension);
  
  V = 0.0;
  P = 0.0;

  SCALAR_TYPE alpha = 1.0 , omega = 1.0 , rho_bef = 1.0;
  
  for (unsigned int i = 0 ; i < dimension ; i++) 	
    {      
      const SCALAR_TYPE rho = (B*R);

      const SCALAR_TYPE beta = (rho/rho_bef)*(alpha/omega);

      S = V;
      S *= omega;
      
      U = P;
      U -= S;
      
      S = U;
      S *= beta;

      P = R;
      P += S;
            
      V = A*P;

      alpha = rho/(B*V);

      S = P;
      S *= alpha;

      X += S;

      U = V;      
      U *= alpha;

      AX += U;

      S = AX;
      S -= B;

      const double Res_inf_norm_1 = S.infinite_norm ();
      
      if (Res_inf_norm_1 < vector_solution_precision)
	{
	  if (printed_information) cout << "(1) BiCG iteration : " << i << " test : " << Res_inf_norm_1 << endl;
      
	  return;
	}
      
      S = R;
      S -= U;

      R = A*S;

      omega = (R*S)/(R*R);

      U = S;
      U *= omega;

      X += U;

      U = R;
      U *= omega;

      AX += U;

      const double Res_inf_norm_2 = U.infinite_norm ();
            
      if (printed_information) cout << "(2) BiCG iteration : " << i << " test : " << Res_inf_norm_2 << endl;
      
      if (Res_inf_norm_2 < vector_solution_precision) return;
      
      R = S;
      R -= U;
      
      rho_bef = rho;                  
    }
}








template <typename SCALAR_TYPE>
void linear_system_solution_biconjugate_gradient_stabilized_calc (
								  const bool printed_information ,
								  const double vector_solution_precision , 
								  class sparse_matrix<SCALAR_TYPE> &A ,
								  class vector_class<SCALAR_TYPE> &B ,
								  class vector_class<SCALAR_TYPE> &X)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("linear_system_solution_biconjugate_gradient_stabilized_calc is used with square matrices only (sparse)");
  if (A.get_dimension ()     != B.get_dimension ())        error_message_print_abort ("Matrix and vector must have the same dimension in linear_system_solution_biconjugate_gradient_stabilized_calc (sparse)");

  const unsigned int dimension = A.get_dimension ();
  
  const unsigned int non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
    
  class array<SCALAR_TYPE> diagonal_matrix_elements(dimension);

  A.diagonal_part (diagonal_matrix_elements);
 
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = A.get_row_index (index);
      
      const SCALAR_TYPE diagonal_matrix_element = diagonal_matrix_elements(i);
            
      if (diagonal_matrix_element != 0.0) A.get_matrix_element (index) /= diagonal_matrix_element;
    }
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    {            
      const SCALAR_TYPE diagonal_matrix_element = diagonal_matrix_elements(i);
      
      if (diagonal_matrix_element != 0.0) B(i) /= diagonal_matrix_element;
    }

  X = B;
  
  class vector_class<SCALAR_TYPE> AX = A*X , R = B - AX;
    
  if (R.infinite_norm () < vector_solution_precision) return;

  B = R;
  
  class vector_class<SCALAR_TYPE> P(dimension) , S(dimension) , T(dimension) , U(dimension) , V(dimension);
  
  V = 0.0;
  P = 0.0;

  SCALAR_TYPE alpha = 1.0 , omega = 1.0 , rho_bef = 1.0;
  
  for (unsigned int i = 0 ; i < dimension ; i++) 	
    {      
      const SCALAR_TYPE rho = (B*R);

      const SCALAR_TYPE beta = (rho/rho_bef)*(alpha/omega);

      S = V;
      S *= omega;

      U = P;
      U -= S;
      
      S = U;
      S *= beta;

      P = R;
      P += S;
            
      V = A*P;

      alpha = rho/(B*V);

      S = P;
      S *= alpha;

      X += S;

      U = V;      
      U *= alpha;

      AX += U;

      S = AX;
      S -= B;

      const double Res_inf_norm_1 = S.infinite_norm ();
      
      if (Res_inf_norm_1 < vector_solution_precision)
	{
	  if (printed_information) cout << "(1) BiCG sparse iteration : " << i << " test : " << Res_inf_norm_1 << endl;
      
	  return;
	}
      
      S = R;
      S -= U;

      R = A*S;

      omega = (R*S)/(R*R);

      U = S;
      U *= omega;

      X += U;

      U = R;
      U *= omega;

      AX += U;

      const double Res_inf_norm_2 = U.infinite_norm ();
            
      if (printed_information) cout << "(2) BiCG sparse iteration : " << i << " test : " << Res_inf_norm_2 << endl;
      
      if (Res_inf_norm_2 < vector_solution_precision) return;
      
      R = S;
      R -= U;
      
      rho_bef = rho;                  
    }

  return;
}


template <typename SCALAR_TYPE>
void linear_system_solution_biconjugate_gradient_stabilized_calc (
								  const bool printed_information ,
								  const double vector_solution_precision , 
								  class block_matrix<SCALAR_TYPE> &A ,
								  class vector_class<SCALAR_TYPE> &B ,
								  class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int blocks_number = A.get_blocks_number ();
    
  X = B;
      
  unsigned int B_index = 0;
  unsigned int X_index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);

      const unsigned int A_block_dimension = A_block.get_dimension ();
      
      class vector_class<SCALAR_TYPE> B_block(A_block_dimension);
      class vector_class<SCALAR_TYPE> X_block(A_block_dimension);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) B_block(ii) = B(B_index++);
      
      linear_system_solution_biconjugate_gradient_stabilized_calc (printed_information , vector_solution_precision , A_block , B_block , X_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) X(X_index++) = X_block(ii);
    }
}





template <typename SCALAR_TYPE>
void linear_system_solution_biconjugate_gradient_stabilized_calc (
								  const bool printed_information ,
								  const double vector_solution_precision , 
								  class block_sparse_matrix<SCALAR_TYPE> &A ,
								  class vector_class<SCALAR_TYPE> &B,
								  class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int blocks_number = A.get_blocks_number ();
    
  X = B;
      
  unsigned int B_index = 0;
  unsigned int X_index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class sparse_matrix<SCALAR_TYPE> &A_block = A(i);

      const unsigned int A_block_dimension = A_block.get_dimension ();
      
      class vector_class<SCALAR_TYPE> B_block(A_block_dimension);
      class vector_class<SCALAR_TYPE> X_block(A_block_dimension);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) B_block(ii) = B(B_index++);
      
      linear_system_solution_biconjugate_gradient_stabilized_calc (printed_information , vector_solution_precision , A_block , B_block , X_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) X(X_index++) = X_block(ii);
    }
}










// Standard matrix functions wrapping matrix_function_symmetric
// The matrix has to be symmetric (double, complex) or hermitian (complex).


class matrix<double> exp   (const class matrix<double> &A);
class matrix<double> log   (const class matrix<double> &A);
class matrix<double> sqrt  (const class matrix<double> &A);
class matrix<double> cbrt  (const class matrix<double> &A);
class matrix<double> cos   (const class matrix<double> &A);
class matrix<double> sin   (const class matrix<double> &A);
class matrix<double> tan   (const class matrix<double> &A);
class matrix<double> acos  (const class matrix<double> &A);
class matrix<double> asin  (const class matrix<double> &A);
class matrix<double> atan  (const class matrix<double> &A);
class matrix<double> cosh  (const class matrix<double> &A);
class matrix<double> sinh  (const class matrix<double> &A);
class matrix<double> tanh  (const class matrix<double> &A);
class matrix<double> acosh (const class matrix<double> &A);
class matrix<double> asinh (const class matrix<double> &A);
class matrix<double> atanh (const class matrix<double> &A);
class matrix<double> expm1 (const class matrix<double> &A);
class matrix<double> log1p (const class matrix<double> &A);



class matrix<complex<double> > exp   (const class matrix<complex<double> > &A);
class matrix<complex<double> > log   (const class matrix<complex<double> > &A);
class matrix<complex<double> > sqrt  (const class matrix<complex<double> > &A);
class matrix<complex<double> > cbrt  (const class matrix<complex<double> > &A);
class matrix<complex<double> > cos   (const class matrix<complex<double> > &A);
class matrix<complex<double> > sin   (const class matrix<complex<double> > &A);
class matrix<complex<double> > tan   (const class matrix<complex<double> > &A);
class matrix<complex<double> > acos  (const class matrix<complex<double> > &A);
class matrix<complex<double> > asin  (const class matrix<complex<double> > &A);
class matrix<complex<double> > atan  (const class matrix<complex<double> > &A);
class matrix<complex<double> > cosh  (const class matrix<complex<double> > &A);
class matrix<complex<double> > sinh  (const class matrix<complex<double> > &A);
class matrix<complex<double> > tanh  (const class matrix<complex<double> > &A);
class matrix<complex<double> > acosh (const class matrix<complex<double> > &A);
class matrix<complex<double> > asinh (const class matrix<complex<double> > &A);
class matrix<complex<double> > atanh (const class matrix<complex<double> > &A);
class matrix<complex<double> > expm1 (const class matrix<complex<double> > &A);
class matrix<complex<double> > log1p (const class matrix<complex<double> > &A);





template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> exp (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> exp_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &exp_A_block = exp_A(i);

      exp_A_block = exp (A_block);
    }

  return exp_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> log (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> log_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &log_A_block = log_A(i);

      log_A_block = log (A_block);
    }

  return log_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> sqrt (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> sqrt_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &sqrt_A_block = sqrt_A(i);

      sqrt_A_block = sqrt (A_block);
    }

  return sqrt_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> cbrt (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> cbrt_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &cbrt_A_block = cbrt_A(i);

      cbrt_A_block = cbrt (A_block);
    }

  return cbrt_A;
}


template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> cos (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> cos_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &cos_A_block = cos_A(i);

      cos_A_block = cos (A_block);
    }

  return cos_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> sin (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> sin_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &sin_A_block = sin_A(i);

      sin_A_block = sin (A_block);
    }

  return sin_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> tan (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> tan_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &tan_A_block = tan_A(i);

      tan_A_block = tan (A_block);
    }

  return tan_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> acos (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> acos_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &acos_A_block = acos_A(i);

      acos_A_block = acos (A_block);
    }

  return acos_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> asin (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> asin_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &asin_A_block = asin_A(i);

      asin_A_block = asin (A_block);
    }

  return asin_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> atan (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> atan_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &atan_A_block = atan_A(i);

      atan_A_block = atan (A_block);
    }

  return atan_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> cosh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> cosh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &cosh_A_block = cosh_A(i);

      cosh_A_block = cosh (A_block);
    }

  return cosh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> sinh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> sinh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &sinh_A_block = sinh_A(i);

      sinh_A_block = sinh (A_block);
    }

  return sinh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> tanh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> tanh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &tanh_A_block = tanh_A(i);

      tanh_A_block = tanh (A_block);
    }

  return tanh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> acosh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> acosh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &acosh_A_block = acosh_A(i);

      acosh_A_block = acosh (A_block);
    }

  return acosh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> asinh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> asinh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &asinh_A_block = asinh_A(i);

      asinh_A_block = asinh (A_block);
    }

  return asinh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> atanh (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> atanh_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &atanh_A_block = atanh_A(i);

      atanh_A_block = atanh (A_block);
    }

  return atanh_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> expm1 (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> expm1_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &expm1_A_block = expm1_A(i);

      expm1_A_block = expm1 (A_block);
    }

  return expm1_A;
}

template <typename SCALAR_TYPE>
class block_matrix<SCALAR_TYPE> log1p (const class block_matrix<SCALAR_TYPE> &A)
{
  class block_matrix<SCALAR_TYPE> log1p_A = A;
  
  const unsigned int blocks_number = A.get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      const class matrix<SCALAR_TYPE> &A_block = A(i);

      class matrix<SCALAR_TYPE> &log1p_A_block = log1p_A(i);

      log1p_A_block = log1p (A_block);
    }

  return log1p_A;
}


#endif



