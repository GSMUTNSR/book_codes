#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

void double_test (const unsigned int N , const double alpha)
{
  const unsigned int Nm1_mod = (N >= 1) ? (N-1) : (0);
  
  const class matrix<double> Id = identity<double> (N);

  class matrix<double> A(N) , B(N) , C(N) , A_copy(N);
    
  class vector_class<double> V0(N) , V1(N) , V2(N) , V3(N);
  
  class array<double> sub_diagonal_table(Nm1_mod);

  class array<double> diagonal_table(N);

  class array<double> super_diagonal_table(Nm1_mod);

  class array<double> sub_diagonal_work_table(Nm1_mod);
  
  class array<double> diagonal_work_table(N);

  diagonal_table.random_array ();

  sub_diagonal_table.random_array ();

  super_diagonal_table.random_array ();
  
  V0.random_vector ();

  for (unsigned int i = 0 ; i < N ; i++) V1(i) = diagonal_table(i)*V0(i);

  diagonal_linear_system_solution_calc (diagonal_table , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with diagonal_linear_system_solution_calc"); 

  V2 = diagonal_linear_system_solution (diagonal_table , V1);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with diagonal_linear_system_solution"); 

  A = 0.0;

  A.put_array_diagonal_part (diagonal_table);

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (diagonal case)");
    
  A = 0.0;

  A.put_array_diagonal_part (diagonal_table);

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A , V1 , precision , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_SVD_solution_calc (diagonal case)");
    
  A.tridiagonal (sub_diagonal_table , diagonal_table , super_diagonal_table);
  
  V0.random_vector ();

  V1 = A*V0;
  
  tridiagonal_linear_system_solution_calc (sub_diagonal_table , diagonal_table , super_diagonal_table , sub_diagonal_work_table , diagonal_work_table , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with tridiagonal_linear_system_solution_calc");
  
  V2 = tridiagonal_linear_system_solution (sub_diagonal_table , diagonal_table , super_diagonal_table , V1);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with tridiagonal_linear_system_solution"); 
  
  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  if (inf_norm (A.determinant () - tridiagonal_determinant (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table)) > 1E-6)
    error_message_print_abort ("Problem in double_test with tridiagonal_determinant");

  double log_Det_no_phase = 0.0;
  
  int phase = 1;

  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  tridiagonal_log_scaled_determinant_and_phase (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table , log_Det_no_phase , phase);
   
  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  if (inf_norm (tridiagonal_determinant (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table) - phase*exp (log_Det_no_phase)) > 1E-6)
    error_message_print_abort ("Problem in double_test with tridiagonal_log_scaled_determinant_and_phase");
  
  OpenMP_parallelization_linear_algebra_enabled ();

  MPI_parallelization_linear_algebra_enabled ();

  A.random_matrix ();

  A *= 0.1;

  for (unsigned int i = 0 ; i < N ; i++) A(i , i) = i + 0.1;
  
#ifdef UseMPI
  A.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
  
  A_copy = A;
  
  V0.random_vector ();
      
#ifdef UseMPI
  V0.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
  V1 = A*V0;
  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , A_copy , V1 , V2);
  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test in linear_system_solution_calc_biconjugate_gradient_stabilized_calc (double, full)");

  const unsigned int non_trivial_zeros_number = (N*(N+1))/2;
  
  class sparse_matrix<double> As(N , non_trivial_zeros_number);

  unsigned int index = 0;
    
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (index < non_trivial_zeros_number)
	{
	  As.get_row_index (index) = i;

	  As.get_column_index (index) = i;
	  
	  As.get_matrix_element (index) = 1.0 + 0.01*random_number<double> ();
				
	  index++;
	}
    }
  
  for (unsigned int i = 0 ; i < N ; i++)
    for (unsigned int j = 0 ; j < N ; j++)
      {
	if (i != j)
	  {
	    if (index < non_trivial_zeros_number)
	      {
		As.get_row_index (index) = i;

		As.get_column_index (index) = j;
		
		As.get_matrix_element (index) = 0.01*random_number<double> ();		

		index++;
	      }
	  }
      }    

  class sparse_matrix<double> As_copy = As;
  
  V1 = As*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , As_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test in linear_system_solution_calc_biconjugate_gradient_stabilized_calc (double, sparse)");
  
  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
  
  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();

  B = A;
  
  A.random_matrix ();

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with inverse");

  A.random_matrix ();

  A = sqrt (A*transpose (A));  

  A.symmetrize ();

  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with pseudo_inverse");
  
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc"); 

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , precision , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_SVD_solution_calc");
  
  A.scalar (alpha);

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (diagonal)");

  class matrix<double> A2(2) , A2_copy(2);
  class vector_class<double> V02(2) , V12(2) , V22(2) , V32(2);

  A2.random_matrix ();

  A2_copy = A2;

  V02.random_vector ();

  V12 = A2*V02;

  linear_system_solution_calc (A2_copy , V12 , V22);

  V32 = V22 - V02;

  if (V32.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (dimension = 2)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();

  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv");

  const unsigned int degree = 5;

  class array<double> coeff(degree+1);

  for (unsigned int i = 0 ; i <= degree ; i++) coeff(i) = 0.1*i;

  class matrix<double> C_poly = scalar<double> (N , coeff(degree));

  C.symmetric_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (1.01);

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<double> (N , coeff(i-1)) + C*C_poly;

  class matrix<double> D = polynomial_evaluation (degree , coeff , C);

  class matrix<double> E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with poly_matrix_function or polynomial_evaluation");

  A.random_matrix ();

  A *= 1E-5;

  A.add_scalar_diagonal_part (1.0);

  A.symmetrize ();

  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;
            
      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with pow (n = " + make_string<int> (n) + ")");
    }
  
  A.symmetric_random_matrix ();

  A *= 0.01;

  A.add_scalar_diagonal_part (1.0);

  E = pow (A , alpha)*pow (A , -alpha) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with pow");	

  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with exp or log");	

  E = sqrt (A)*sqrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with sqrt");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with cbrt");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with cos or acos");	

  E = sin (asin (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with sin or asin");	

  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with tan or atan");	

  A += Id;

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with cosh or acosh");	

  A -= Id;

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with sinh or asinh");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with tanh or atanh");	

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with expm1");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with log1p");

  A_copy = A;
  
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if ((N >= 3) && !A_copy.is_it_Cholesky_decomposed ()) error_message_print_abort ("A should be Cholesky decomposed in double_test");
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (Cholesky)");
  
  A.random_matrix ();

  A_copy = A;
    
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (random)");
  
  if (N >= 3)
    {
      A.symmetric_random_matrix ();

      A *= 0.01;

      A.remove_scalar_diagonal_part (1.0);

      A_copy = A;
  
      A_copy.Cholesky_decompose ();
  
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
  
      if (A_copy.is_it_Cholesky_decomposed ()) error_message_print_abort ("A should not be Cholesky decomposed in double_test");
  
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_test with linear_system_solution_calc (Cholesky fails then LU)");
    }
}






void double_block_test (const double alpha)
{
  const unsigned int blocks_number = 5;
    
  class array<unsigned int> block_dimensions(blocks_number);
  
  for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + 1;
    
  const unsigned int N = block_dimensions.sum ();
    
  const class block_matrix<double> Id = identity<double> (block_dimensions);

  class block_matrix<double> A(block_dimensions) , B(block_dimensions) , C(block_dimensions) , A_copy(block_dimensions);
    
  class vector_class<double> V0(N) , V1(N) , V2(N) , V3(N);
    
  OpenMP_parallelization_linear_algebra_enabled ();

  MPI_parallelization_linear_algebra_enabled ();

  A.random_matrix ();

  A *= 0.1;

  for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
    for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
      A(matrix_index)(i , i) = i + 0.1;
  
#ifdef UseMPI
  A.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
  
  A_copy = A;
  
  V0.random_vector ();
      
#ifdef UseMPI
  V0.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
  V1 = A*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test in linear_system_solution_biconjugate_gradient_stabilized_calc (double, full)");

  const class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
  
  for(unsigned int i = 0 ; i < blocks_number ; i++) non_trivial_zeros_numbers(i) = (block_dimensions(i)*(block_dimensions(i) + 1))/2;
    
  class block_sparse_matrix<double> As(block_dimensions , non_trivial_zeros_numbers);
  
  for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
    {
      unsigned int index = 0;

      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	{
	  if (index < non_trivial_zeros_numbers(matrix_index))
	    {
	      As(matrix_index).get_row_index (index) = i;

	      As(matrix_index).get_column_index (index) = i;

	      As(matrix_index).get_matrix_element (index) = 1.0 + 0.01*random_number<double> ();
		    
	      index++;
	    }
	}
      
      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	for (unsigned int j = 0 ; j < block_dimensions(matrix_index) ; j++)
	  {
	    if (i != j)
	      {
		if (index < non_trivial_zeros_numbers(matrix_index))
		  {
		    As(matrix_index).get_row_index (index) = i;

		    As(matrix_index).get_column_index (index) = j;
		    
		    As(matrix_index).get_matrix_element (index) = 0.01*random_number<double> ();
		    
		    index++;
		  }
	      }
	  }
    }
      
  class block_sparse_matrix<double> As_copy = As;
  
  V1 = As*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , As_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test in linear_system_solution_biconjugate_gradient_stabilized_calc (double, sparse)");
  
  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
  
  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();

  B = A;

  A.random_matrix ();

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with inverse");

  A.random_matrix ();

  A = sqrt (A*transpose (A));  

  A.symmetrize ();

  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;	

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with pseudo_inverse");
  
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_solution_calc"); 

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , precision , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_SVD_solution_calc");
  
  A.scalar (alpha);

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_solution_calc (diagonal)");

  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv");

  const unsigned int degree = 5;

  class array<double> coeff(degree+1);

  for (unsigned int i = 0 ; i <= degree ; i++) coeff(i) = 0.1*i;

  class block_matrix<double> C_poly = scalar<double> (block_dimensions , coeff(degree));

  C.symmetric_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (1.01);

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<double> (block_dimensions , coeff(i-1)) + C*C_poly;

  class block_matrix<double> D = polynomial_evaluation (degree , coeff , C);

  class block_matrix<double> E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with poly_matrix_function or polynomial_evaluation");

  A.random_matrix ();

  A *= 1E-5;

  A.add_scalar_diagonal_part (1.0);

  A.symmetrize ();

  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;
            
      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with pow (n = " + make_string<int> (n) + ")");
    }
  
  A.symmetric_random_matrix ();

  A *= 0.01;

  A.add_scalar_diagonal_part (1.0);

  E = pow (A , alpha)*pow (A , -alpha) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with pow");	

  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with exp or log");	

  E = sqrt (A)*sqrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with sqrt");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with cbrt");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with cos or acos");	

  E = sin (asin (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with sin or asin");	

  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with tan or atan");	

  A += Id;

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with cosh or acosh");	

  A -= Id;

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with sinh or asinh");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with tanh or atanh");	

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with expm1");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with log1p");
   
  A.random_matrix ();

  A_copy = A;
    
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_solution_calc (random)");
  
  A_copy = A;
  
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
    
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_solution_calc (positive definite)");

  if (N >= 3)
    {
      A.symmetric_random_matrix ();

      A *= 0.01;

      A.remove_scalar_diagonal_part (1.0);

      A_copy = A;
  
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
    
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in double_block_test with linear_system_solution_calc (non positive definite)");
    }
}







void complex_test (const unsigned int N , const complex<double> &alpha)
{
  const unsigned int Nm1_mod = (N >= 1) ? (N-1) : (0);
  
  const class matrix<complex<double> > Id = identity<complex<double> > (N);
  
  const complex<double> x(10.1788 , -3.675);

  class matrix<complex<double> > A(N) , B(N) , C(N) , A_copy(N);
  
  class vector_class<complex<double> > V0(N) , V1(N) , V2(N) , V3(N);

  class array<complex<double> > sub_diagonal_table(Nm1_mod);

  class array<complex<double> > diagonal_table(N);

  class array<complex<double> > super_diagonal_table(Nm1_mod);

  class array<complex<double> > sub_diagonal_work_table(Nm1_mod);
  
  class array<complex<double> > diagonal_work_table(N);
  
  diagonal_table.random_array ();

  sub_diagonal_table.random_array ();

  super_diagonal_table.random_array ();
  
  V0.random_vector ();

  for (unsigned int i = 0 ; i < N ; i++) V1(i) = diagonal_table(i)*V0(i);

  diagonal_linear_system_solution_calc (diagonal_table , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with diagonal_linear_system_solution_calc");
  
  V2 = diagonal_linear_system_solution (diagonal_table , V1);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with diagonal_linear_system_solution");
  
  A = 0.0;

  A.put_array_diagonal_part (diagonal_table);

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (diagonal case)");
  
  A = 0.0;

  A.put_array_diagonal_part (diagonal_table);

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A , V1 , precision , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_SVD_solution_calc (diagonal case)");
    
  A.tridiagonal (sub_diagonal_table , diagonal_table , super_diagonal_table);

  V0.random_vector ();

  V1 = A*V0;

  tridiagonal_linear_system_solution_calc (sub_diagonal_table , diagonal_table , super_diagonal_table , sub_diagonal_work_table , diagonal_work_table , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tridiagonal_linear_system_solution_calc");
  
  V2 = tridiagonal_linear_system_solution (sub_diagonal_table , diagonal_table , super_diagonal_table , V1);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tridiagonal_linear_system_solution");
  
  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  if (inf_norm (A.determinant () - tridiagonal_determinant (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table)) > 1E-6)
    error_message_print_abort ("Problem in complex_test with tridiagonal_determinant");

  complex<double> log_Det_no_phase = 0.0;
  
  int phase = 1;

  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  tridiagonal_log_scaled_determinant_and_phase (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table , log_Det_no_phase , phase);
   
  sub_diagonal_work_table = sub_diagonal_table;
  
  diagonal_work_table = diagonal_table;
  
  if (inf_norm (tridiagonal_determinant (sub_diagonal_work_table , diagonal_work_table , super_diagonal_table) - phase*exp (log_Det_no_phase)) > 1E-6)
    error_message_print_abort ("Problem in complex_test with tridiagonal_log_scaled_determinant_and_phase");
  
  OpenMP_parallelization_linear_algebra_enabled ();

  MPI_parallelization_linear_algebra_enabled ();

  A.random_matrix ();

  A *= 0.1;

  for (unsigned int i = 0 ; i < N ; i++) A(i , i) = i + complex<double> (0.1 , 0.1);
  
#ifdef UseMPI
  A.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
  A_copy = A;

  V0.random_vector ();
      
#ifdef UseMPI
  V0.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

  V1 = A*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test in linear_system_solution_calc_biconjugate_gradient_stabilized (complex, full)");
  
  const unsigned int non_trivial_zeros_number = (N*(N+1))/2;
  
  class sparse_matrix<complex<double> > As(N , non_trivial_zeros_number);
  
  unsigned int index = 0;
    
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (index < non_trivial_zeros_number)
	{
	  As.get_row_index (index) = i;

	  As.get_column_index (index) = i;
	  
	  As.get_matrix_element (index) = 1.0 + 0.01*random_number<complex<double> > ();
				
	  index++;
	}
    }
  
  for (unsigned int i = 0 ; i < N ; i++)
    for (unsigned int j = 0 ; j < N ; j++)
      {
	if (i != j)
	  {
	    if (index < non_trivial_zeros_number)
	      {
		As.get_row_index (index) = i;

		As.get_column_index (index) = j;
		
		As.get_matrix_element (index) = 0.01*random_number<complex<double> > ();
		
		index++;
	      }
	  }
      }    
    
  class sparse_matrix<complex<double> > As_copy = As;
  
  V1 = As*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , As_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test in linear_system_solution_calc_biconjugate_gradient_stabilized (complex, sparse)");
  
  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
  
  A.scalar (alpha);

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (diagonal)");

  class matrix<complex<double> > A2(2) , A2_copy(2);

  class vector_class<complex<double> > V02(2) , V12(2) , V22(2) , V32(2);

  A2.random_matrix ();

  A2_copy = A2;

  V02.random_vector ();

  V12 = A2*V02;

  linear_system_solution_calc (A2_copy , V12 , V22);

  V32 = V22 - V02;

  if (V32.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (dimension = 2)");

  
  A.symmetric_random_matrix ();

  A += x;

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;	

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with inverse (symmetric)");

  A.symmetric_random_matrix ();

  A += x;

  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pseudo_inverse (symmetric)");
   
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (symmetric)");

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , 0.0 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_SVD_solution_ca;c (symmetric)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv (symmetric)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv (symmetric)");

  const unsigned int degree = 5;

  class array<complex<double> > coeff(degree+1);

  for (unsigned int i = 0 ; i <= degree ; i++) coeff(i) = 0.1*i;

  class matrix<complex<double> > C_poly = scalar<complex<double> > (N , coeff(degree));

  C.symmetric_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (complex<double> (1.01 , 0.1));

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<complex<double> > (N , coeff(i-1)) + C*C_poly;

  class matrix<complex<double> > D = polynomial_evaluation (degree , coeff , C);

  class matrix<complex<double> > E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with poly_matrix_function or polynomial_evaluation (symmetric)");
  
  A.symmetric_random_matrix ();

  A *= 0.01;
  A.add_scalar_diagonal_part (1.0);
  
  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;

      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pow (n = " + make_string<int> (n) + ") (symmetric)");
    }
  
  E = pow (A , alpha)*pow (A , -alpha) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pow (symmetric)");	

  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with exp or log (symmetric)");	

  E = sqrt (A)*sqrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sqrt (symmetric)");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cbrt (symmetric)");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cos or acos (symmetric)");	

  E = sin (asin (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sin or asin (symmetric)");	

  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tan or atan (symmetric)");	

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cosh or acosh (symmetric)");	

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sinh or asinh (symmetric)");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tanh or atanh (symmetric)");	

  A *= 0.01;

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with expm1 (symmetric)");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with log1p (symmetric)");

  A.random_matrix ();

  A = A*dagger (A);

  A.hermitize ();
  
  A.symmetric_random_matrix ();

  A += x;

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;	

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with inverse (symmetric)");

  A.hermitian_random_matrix ();

  A += real (x);
  
  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pseudo_inverse (hermitian)");
  
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (hermitian)");

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , 0.0 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_SVD_solution_calc (hermitian)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv (hermitian)");
  
  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv (hermitian)");
  
  C_poly = scalar<complex<double> > (N , coeff(degree));

  C.hermitian_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (1.01);

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<complex<double> > (N , coeff(i-1)) + C*C_poly;

  D = polynomial_evaluation (degree , coeff , C);

  E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with poly_matrix_function or polynomial_evaluation (hermitian)");

  A.hermitian_random_matrix ();

  A *= 0.01;

  A.add_scalar_diagonal_part (1.0);
    
  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;

      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pow (n = " + make_string<int> (n) + ") (hermitian)");
    }
      
  E = pow (A , real (alpha))*pow (A , -real (alpha)) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with pow (hermitian)");	
  
  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with exp or log (hermitian)");	

  E = sqrt (A)*sqrt (A) - A;
  
  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sqrt (hermitian)");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cbrt (hermitian)");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cos or acos (hermitian)");	

  E = sin (asin (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sin or asin (hermitian)");	

  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tan or atan (hermitian)");	

  A += Id;

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with cosh or acosh (hermitian)");	

  A -= Id;

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with sinh or asinh (hermitian)");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with tanh or atanh (hermitian)");	

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with expm1 (hermitian)");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with log1p (hermitian)");
  
  A_copy = A;
  
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if ((N >= 3) && !A_copy.is_it_Cholesky_decomposed ()) error_message_print_abort ("A should be Cholesky decomposed in complex_test");
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (hermitian Cholesky)");

  A.random_matrix ();

  A_copy = A;
    
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (random)");
  
  if (N >= 3)
    {
      A.symmetric_random_matrix ();

      A_copy = A;
  
      A_copy.Cholesky_decompose ();
  
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
  
      if (!A_copy.is_it_Cholesky_decomposed ()) error_message_print_abort ("A should be Cholesky decomposed in complex_test (hermitian)");
  
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (symmetric Cholesky)");
  
      A.hermitian_random_matrix ();  

      A *= 0.01;

      A.remove_scalar_diagonal_part (1.0);

      A_copy = A;
  
      A_copy.Cholesky_decompose ();
  
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
  
      if (A_copy.is_it_Cholesky_decomposed ()) error_message_print_abort ("A should not be Cholesky decomposed in complex_test (hermitian)");
  
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_test with linear_system_solution_calc (hermitian Cholesky fails then LU)");
    }
}













void complex_block_test (const complex<double> &alpha)
{
  const unsigned int blocks_number = 5;
    
  class array<unsigned int> block_dimensions(blocks_number);
  
  for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + 1;
      
  const unsigned int N = block_dimensions.sum ();
  
  const class block_matrix<complex<double> > Id = identity<complex<double> > (block_dimensions);
  
  const complex<double> x(10.1788 , -3.675);

  class block_matrix<complex<double> > A(block_dimensions);
  class block_matrix<complex<double> > B(block_dimensions);
  class block_matrix<complex<double> > C(block_dimensions);
  
  class block_matrix<complex<double> > A_copy(block_dimensions);
  
  class vector_class<complex<double> > V0(N) , V1(N) , V2(N) , V3(N);
  
  OpenMP_parallelization_linear_algebra_enabled ();

  MPI_parallelization_linear_algebra_enabled ();

  A.random_matrix ();
  A *= 0.1;
  
  for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
    for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
      A(matrix_index)(i , i) = i + complex<double> (0.1 , 0.1);
  
#ifdef UseMPI
  A.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
      
  A_copy = A;

  V0.random_vector ();
      
#ifdef UseMPI
  V0.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif

  V1 = A*V0;
  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , A_copy , V1 , V2);
  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test in linear_system_solution_biconjugate_gradient_stabilized (complex, full)");
  
  const class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
  
  for(unsigned int i = 0 ; i < blocks_number ; i++) non_trivial_zeros_numbers(i) = (block_dimensions(i)*(block_dimensions(i) + 1))/2;
  
  class block_sparse_matrix<complex<double> > As(block_dimensions , non_trivial_zeros_numbers);

  for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
    {
      unsigned int index = 0;

      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	{
	  if (index < non_trivial_zeros_numbers(matrix_index))
	    {
	      As(matrix_index).get_row_index (index) = i;

	      As(matrix_index).get_column_index (index) = i;

	      As(matrix_index).get_matrix_element (index) = 1.0 + 0.01*random_number<complex<double> > ();
		    
	      index++;
	    }
	}
      
      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	for (unsigned int j = 0 ; j < block_dimensions(matrix_index) ; j++)
	  {
	    if (i != j)
	      {
		if (index < non_trivial_zeros_numbers(matrix_index))
		  {
		    As(matrix_index).get_row_index (index) = i;
		    
		    As(matrix_index).get_column_index (index) = j;
		    
		    As(matrix_index).get_matrix_element (index) = 0.01*random_number<complex<double> > ();
		    
		    index++;
		  }
	      }
	  }
    }
      
  class block_sparse_matrix<complex<double> > As_copy = As;
  
  V1 = As*V0;

  linear_system_solution_biconjugate_gradient_stabilized_calc (false , precision , As_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test in linear_system_solution_biconjugate_gradient_stabilized (complex, sparse)");
  
  OpenMP_parallelization_linear_algebra_disabled ();

  MPI_parallelization_linear_algebra_disabled ();
  
  A.scalar (alpha);

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (diagonal)");
  
  A.symmetric_random_matrix ();

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;	

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with inverse (symmetric)");

  A.symmetric_random_matrix ();

  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pseudo_inverse (symmetric)");
   
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (symmetric)");

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , 0.0 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_SVD_solution_calc (symmetric)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv (symmetric)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv (symmetric)");

  const unsigned int degree = 5;

  class array<complex<double> > coeff(degree+1);

  for (unsigned int i = 0 ; i <= degree ; i++) coeff(i) = 0.1*i;

  class block_matrix<complex<double> > C_poly = scalar<complex<double> > (block_dimensions , coeff(degree));

  C.symmetric_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (complex<double> (1.01 , 0.1));

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<complex<double> > (block_dimensions , coeff(i-1)) + C*C_poly;

  class block_matrix<complex<double> > D = polynomial_evaluation (degree , coeff , C);

  class block_matrix<complex<double> > E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with poly_matrix_function or polynomial_evaluation (symmetric)");
  
  A.symmetric_random_matrix ();

  A *= 0.01;

  A.add_scalar_diagonal_part (1.0);
  
  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;

      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pow (n = " + make_string<int> (n) + ") (symmetric)");
    }

  E = pow (A , alpha)*pow (A , -alpha) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pow (symmetric)");	

  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with exp or log (symmetric)");	

  E = sqrt (A)*sqrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sqrt (symmetric)");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cbrt (symmetric)");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cos or acos (symmetric)");	

  E = sin (asin (A)) - A;
  
  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sin or asin (symmetric)");	
  
  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with tan or atan (symmetric)");	

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cosh or acosh (symmetric)");	

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sinh or asinh (symmetric)");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with tanh or atanh (symmetric)");	

  A *= 0.01;

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with expm1 (symmetric)");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with log1p (symmetric)");

  A.random_matrix ();

  A = A*dagger (A);

  A.hermitize ();
  
  A.symmetric_random_matrix ();

  B = A;

  A_copy = A;

  B.inverse ();

  C = A*B - Id;	

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with inverse (symmetric)");

  A.hermitian_random_matrix ();
  
  B = A;

  A_copy = A;

  pseudo_inverse (A , 0.0);

  B.inverse ();

  C = B - A;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pseudo_inverse (hermitian)");
   
  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (hermitian)");

  A_copy = A;

  V0.random_vector ();

  V1 = A*V0;

  linear_system_SVD_solution_calc (A_copy , V1 , 0.0 , V2);

  V3 = V2 - V0;

  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_SVD_solution_calc (hermitian)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_sqrt (A , 0.0);

  Moore_Penrose_sqrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with Moore_Penrose_sqrt or Moore_Penrose_sqrt_inv (hermitian)");

  A.random_matrix ();

  A = sqrt (A*transpose (A));

  A.symmetrize ();
  
  B = A;

  Moore_Penrose_cbrt (A , 0.0);

  Moore_Penrose_cbrt_inv (B , 0.0);

  C = B*A - Id;

  if (C.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with Moore_Penrose_cbrt or Moore_Penrose_cbrt_inv (hermitian)");
  
  C_poly = scalar<complex<double> > (block_dimensions , coeff(degree));

  C.hermitian_random_matrix ();

  C *= 0.01;

  C.put_scalar_diagonal_part (1.01);

  for (unsigned int i = degree ; i > 0 ; i--) C_poly = scalar<complex<double> > (block_dimensions , coeff(i-1)) + C*C_poly;

  D = polynomial_evaluation (degree , coeff , C);

  E = D - C_poly;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with poly_matrix_function or polynomial_evaluation (hermitian)");

  A.hermitian_random_matrix ();

  A *= 0.01;

  A.add_scalar_diagonal_part (1.0);
    
  for (int n = 0 ; n <= 3 ; n++)
    {
      E = pow (A , n)*pow (A , -n) - Id;

      if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pow (n = " + make_string<int> (n) + ") (hermitian)");
    }
      
  E = pow (A , real (alpha))*pow (A , -real (alpha)) - Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with pow (hermitian)");	
  
  E = exp (log (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with exp or log (hermitian)");	

  E = sqrt (A)*sqrt (A) - A;
  
  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sqrt (hermitian)");	

  E = cbrt (A)*cbrt (A)*cbrt (A) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cbrt (hermitian)");	

  A *= 0.01;
  
  E = cos (acos (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cos or acos (hermitian)");	

  E = sin (asin (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sin or asin (hermitian)");	

  E = tan (atan (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with tan or atan (hermitian)");	

  A += Id;

  E = cosh (acosh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with cosh or acosh (hermitian)");	

  A -= Id;

  E = sinh (asinh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with sinh or asinh (hermitian)");	

  E = tanh (atanh (A)) - A;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with tanh or atanh (hermitian)");	

  E = expm1 (A) - exp (A) + Id;

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with expm1 (hermitian)");

  E = log1p (A) - log (Id + A);

  if (E.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with log1p (hermitian)");
  
  A.random_matrix ();

  A_copy = A;
    
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (random)");
  
  A_copy = A;
  
  V0.random_vector ();

  V1 = A*V0;

  linear_system_solution_calc (A_copy , V1 , V2);

  V3 = V2 - V0;
  
  if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (positive definite)");

  if (N >= 3)
    {
      A.symmetric_random_matrix ();

      A_copy = A;
    
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
    
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (symmetric)");

      A.hermitian_random_matrix ();  

      A *= 0.01;

      A.remove_scalar_diagonal_part (1.0);

      A_copy = A;
    
      V0.random_vector ();

      V1 = A*V0;

      linear_system_solution_calc (A_copy , V1 , V2);

      V3 = V2 - V0;
    
      if (V3.infinite_norm () > 1E-6) error_message_print_abort ("Problem in complex_block_test with linear_system_solution_calc (hermitian non positive definite)");
    }
}















#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  MPI_parallelization_linear_algebra_enabled ();

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    OpenMP_parallelization_linear_algebra_enabled ();

#ifdef UseOpenMP
    OpenMP_set_threads_number (4);
#endif
    
    seed ();

    /*
    
      {
      OpenMP_parallelization_linear_algebra_enabled ();
    
      const unsigned int N = 500;

      class array<double> eigenvalues(N);
      
      class matrix<double> M(N);

      M.symmetric_random_matrix ();
      
      class matrix<double> P = M;
      
      total_diagonalization::all_eigenpairs (P , eigenvalues);

      for (unsigned int i = 0 ; i < N ; i++) eigenvalues(i) = i;

      eigenvalues /= N-1;
      
      const double eps = 1E-4;
      
      eigenvalues += eps;

      M = 0.0;

      M.put_array_diagonal_part (eigenvalues);

      M = P*M*transpose (P);
      
      const class matrix<double> M_copy = M;
      
      class vector_class<double> B(N);
      class vector_class<double> X(N);

      B.random_vector ();
           
      const class vector_class<double> B_copy = B;
      
      linear_system_solution_biconjugate_gradient_stabilized_calc (true , 1E-4 , M , B , X);
       
      const class vector_class<double> Res = M_copy*X - B_copy;

      cout << Res.infinite_norm ()/X.infinite_norm () << endl;

      exit (1);
      }

    */
    
    const unsigned int N = 20;

    const double alpha = 0.45;
    
    const complex<double> alpha_c(0.25 , 0.41);
    
    for (unsigned int n = 0 ; n <= N ; n++)
      {
	double_test (n , alpha);
	
	complex_test (n , alpha_c);
      }
    	
    double_block_test (alpha);
	
    complex_block_test (alpha_c);
	
    if (THIS_PROCESS == MASTER_PROCESS) cout << "All matrices_add tests are correct." << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
