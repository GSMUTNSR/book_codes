#include "../numlib_def/numlib_def.h"

void Moore_Penrose_pow (class matrix<double> &A , const int alpha , const double SVD_precision)
{
  Moore_Penrose_pow_symmetric (A , alpha , SVD_precision);
}

void Moore_Penrose_pow (class matrix<double> &A , const double alpha , const double SVD_precision)
{
  Moore_Penrose_pow_symmetric (A , alpha , SVD_precision);
}

void Moore_Penrose_pow (class matrix<complex<double> > &A , const int alpha , const double SVD_precision)
{
  if (A.is_it_symmetric ())
    Moore_Penrose_pow_symmetric (A , alpha , SVD_precision);
  else if (A.is_it_hermitian ())
    {      
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();
       
      Moore_Penrose_pow_hermitian (Ar , Ai , alpha , SVD_precision);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();
  
      A.allocate_fill (A_new);
    }
  else
    error_message_print_abort ("A must be symmetric or hermitian in Moore_Penrose_pow (complex with int alpha)");
}

void Moore_Penrose_pow (class matrix<complex<double> > &A , const double alpha , const double SVD_precision)
{
  if (A.is_it_symmetric ())
    Moore_Penrose_pow_symmetric (A , alpha , SVD_precision);
  else if (A.is_it_hermitian ())
    {      
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();
       
      Moore_Penrose_pow_hermitian (Ar , Ai , alpha , SVD_precision);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();
  
      A.allocate_fill (A_new);
    }
  else
    error_message_print_abort ("A must be symmetric or hermitian in Moore_Penrose_pow (complex with double alpha)");
}

void Moore_Penrose_pow (class matrix<complex<double> > &A , const complex<double> &alpha , const double SVD_precision)
{
  if (A.is_it_symmetric ())
    Moore_Penrose_pow_symmetric (A , alpha , SVD_precision);
  else if (A.is_it_hermitian ())
    {      
      if (imag (alpha) != 0.0)
	error_message_print_abort ("alpha must be real in Moore_Penrose_pow (complex with complex alpha) in the hermitian case for A^alpha to be hermitian");

      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();
       
      Moore_Penrose_pow_hermitian (Ar , Ai , real (alpha) , SVD_precision);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();
  
      A.allocate_fill (A_new);
    }
  else
    error_message_print_abort ("A must be symmetric or hermitian in Moore_Penrose_pow (complex with complex alpha)");
}

void pseudo_inverse (class matrix<double> &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -1.0 , SVD_precision);
}

 
void Moore_Penrose_sqrt (class matrix<double> &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , 0.5 , SVD_precision);
}

 
void Moore_Penrose_sqrt_inv (class matrix<double> &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -0.5 , SVD_precision);
}

 
void Moore_Penrose_cbrt (class matrix<double> &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , 0.3333333333333333 , SVD_precision);
}

 
void Moore_Penrose_cbrt_inv (class matrix<double> &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -0.3333333333333333 , SVD_precision);
}


void pseudo_inverse (class matrix<complex<double> > &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -1.0 , SVD_precision);
}

 
void Moore_Penrose_sqrt (class matrix<complex<double> > &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , 0.5 , SVD_precision);
}

 
void Moore_Penrose_sqrt_inv (class matrix<complex<double> > &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -0.5 , SVD_precision);
}

 
void Moore_Penrose_cbrt (class matrix<complex<double> > &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , 0.3333333333333333 , SVD_precision);
}

 
void Moore_Penrose_cbrt_inv (class matrix<complex<double> > &A , const double SVD_precision)
{
  Moore_Penrose_pow (A , -0.3333333333333333 , SVD_precision);
}






class matrix<double> polynomial_evaluation (
					    const unsigned int degree , 
					    const class array<double> &coefficients , 
					    const class matrix<double> &A) 
{
  class matrix<double> poly_A = A; 

  poly_matrix_function_symmetric (degree , coefficients , poly_A);

  return poly_A;
}



class matrix<complex<double> > polynomial_evaluation (
						      const unsigned int degree , 
						      const class array<complex<double> > &coefficients , 
						      const class matrix<complex<double> > &A) 
{
  if (A.is_it_symmetric ()) 
    {
      class matrix<complex<double> > poly_A = A;
      
      poly_matrix_function_symmetric (degree , coefficients , poly_A);
      
      return poly_A;
    }
  else if (A.is_it_hermitian ())
    {
      const unsigned int N = coefficients.dimension (0);
      
      class array<double> coefficients_r(N);

      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const complex<double> coefficient = coefficients(i);
	
	  if (imag (coefficient) != 0.0)
	    error_message_print_abort ("The polynomial coefficients must be real in polynomial_evaluation (complex with complex coefficients) in the hermitian case for the resulting matrix to be hermitian");

	  coefficients_r(i) = real (coefficient);
	}
      
      class matrix<double> poly_Ar = real<double , complex<double> > (A);
      class matrix<double> poly_Ai = imag<double , complex<double> > (A);
         
      poly_matrix_function_hermitian (degree , coefficients_r , poly_Ar , poly_Ai);
      
      const class matrix<complex<double> > poly_A = complex_matrix<double , complex<double> > (poly_Ar , poly_Ai);
    
      return poly_A;
    }
  else
    error_message_print_abort ("A must be symmetric or hermitian in polynomial_evaluation (complex with complex coefficients)");
  
  const class matrix<complex<double> > dummy;

  return dummy;
}





// Matrix function using diagonalization
// (for small matrices)
// ======================
// The matrix has to be symmetric (double, complex) or hermitian (complex, bicomplex).
// 1) diagonalization of the input matrix A = {P}^(-1) D P
// 2) calculation of a pseudo inverse function of the input matrix:
// f(A) = {P}^(-1) f(D) P
// with D the diagonal matrix and f(D) its function image
// f is a scalar function of one scalar argument.
// f(D).P  is stored in A.
// f(A) is stored in A.
// Routines are optimized so as to limit memory use of matrices: three matrices must be present in memory.
// Double and complex have to be separated , as the double argument in f is given by value and the complex argument by reference.
// If f(x) is not defined , it is assumed that one calculates for example sqrt (-epsilon) instead of sqrt (0.0) for the double case. 
// Hence , f(0.0) is taken instead therein by default , as A is assumed to be positive definite if f is a non-integer power for the double case.

void matrix_function_symmetric (class matrix<double> &A , double (&f) (const double) )
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("matrix_function_symmetric (double) is used with square matrices only");

  if (!A.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_symmetric (double)");
  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in matrix_function_symmetric (double)");

  const unsigned int dimension = A.get_dimension ();	

  if (A.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  double &Aii = A(i , i);

	  Aii = f (Aii);
	}

      return;
    }

  class array<double> eigenvalues (dimension);

  // P and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in P.
  
  class matrix<double> P_transpose = A;

  total_diagonalization::all_eigenpairs_Householder (P_transpose , eigenvalues);

  // f(D).P is stored in A as fD_P is a reference to A
  class matrix<double> &fD_P_transpose = A;

  fD_P_transpose = 0.0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const double eigenvalue_i = eigenvalues(i);

      const double f_eigenvalue_i_maybe_inf = f (eigenvalue_i);

      const double f_eigenvalue_i = (finite (f_eigenvalue_i_maybe_inf)) ? (f_eigenvalue_i_maybe_inf) : (f (0.0));

      const class vector_class<double> &Pi_transpose = P_transpose.row_vector (i);

      class vector_class<double> &fD_Pi_transpose = fD_P_transpose.row_vector (i);

      fD_Pi_transpose  = Pi_transpose;
      fD_Pi_transpose *= f_eigenvalue_i;
    }

  // {P}^(-1) is given by P.transpose () and stored in P

  class matrix<double> &P = P_transpose;
  
  P.transpose ();

  // f(A) = P.f(D).P_transpose is stored in A
  // The temporary matrix created in operator * is unavoidable as A and fD_P_transpose are the same object.
  A = P*fD_P_transpose;

  A.symmetrize ();
}


void matrix_function_hermitian (class matrix<double> &A , double (&f) (const double) )
{
  matrix_function_symmetric (A , f);
}

void matrix_function_hermitian (class matrix<double> &Ar , class matrix<double> &Ai , double (&f) (const double) )
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("matrix_function_hermitian (double) is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("matrix_function_hermitian (double) is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_hermitian (double) (real part)");
  if (!Ai.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_hermitian (double) (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in matrix_function_hermitian (double)");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in matrix_function_hermitian (double)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in matrix_function_hermitian (double)");
  
  const unsigned int dimension = Ar.get_dimension ();	

  if (Ar.is_it_diagonal () && Ai.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{	
	  double &Ar_ii = Ar(i , i);

	  Ar_ii = f (Ar_ii);
	}

      return;
    }

  class array<double> eigenvalues (dimension);

  // Pr, Pi and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in Pr and Pi.
  
  class matrix<double> Pr_transpose = Ar;
  class matrix<double> Pi_transpose = Ai;

  total_diagonalization::hermitian::all_eigenpairs_Householder (Pr_transpose , Pi_transpose , eigenvalues);
    
  // I do not use references for all next matrices therein as one needs both next matrices for Ar and Ai, calculated one after the other.

  class matrix<double> fD_Pr_transpose = Ar;
  class matrix<double> fD_Pi_transpose = Ai;

  fD_Pr_transpose = 0.0;
  fD_Pi_transpose = 0.0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const double eigenvalue_i = eigenvalues(i);

      const double f_eigenvalue_i_maybe_inf = f (eigenvalue_i);
      
      const double f_eigenvalue_i = (finite (f_eigenvalue_i_maybe_inf)) ? (f_eigenvalue_i_maybe_inf) : (f (0.0));

      const class vector_class<double> &Pr_transpose_i = Pr_transpose.row_vector (i);
      const class vector_class<double> &Pi_transpose_i = Pi_transpose.row_vector (i);

      class vector_class<double> &fD_Pr_transpose_i = fD_Pr_transpose.row_vector (i);
      class vector_class<double> &fD_Pi_transpose_i = fD_Pi_transpose.row_vector (i);

      fD_Pr_transpose_i  = Pr_transpose_i;
      fD_Pi_transpose_i  = Pi_transpose_i;
      
      fD_Pr_transpose_i *= f_eigenvalue_i;
      fD_Pi_transpose_i *= f_eigenvalue_i;
    }
  
  // {Pr + i.Pi}^(-1)  = {Pr + i.Pi}^{+} = Pr.transpose () - i.Pi.transpose ()
    
  class matrix<double> &Pr = Pr_transpose;
  class matrix<double> &Pi = Pi_transpose;
  
  Pr.transpose ();
  Pi.transpose ();

  // f(A) = P.f(D).P_dagger is stored in A
  // One uses a work matrix here to avoid the matrix temporaries induced by operator *

  class matrix<double> M(dimension);

  matrix_multiplication (Pr , fD_Pr_transpose , M) , Ar  = M;  
  matrix_multiplication (Pi , fD_Pi_transpose , M) , Ar += M;
 
  matrix_multiplication (Pi , fD_Pr_transpose , M) , Ai  = M;
  matrix_multiplication (Pr , fD_Pi_transpose , M) , Ai -= M;
  
  Ar.symmetrize ();
  Ai.antisymmetrize ();
}




// One can directly call matrix_function_hermitian with a complex matrix.
// They are separated in real and imaginary parts.
// A is copied to Ar and Ai (A = Ar + i.Ai) and deallocated when Ar and Ai only are used.
// It is reallocated afterwards, so that Ar + i.Ai -> A for the new Ar, Ai.
// This creates no memory time/issue as one needs two to seven real matrices in the routines from the namespace total_diagonalization::hermitian called afterwards, so that one can tolerate an additional matrix here.

void matrix_function_hermitian (class matrix<complex<double> > &A , double (&f) (const double) )
{
  class matrix<double> Ar = real<double , complex<double> > (A);
  class matrix<double> Ai = imag<double , complex<double> > (A);
  
  A.deallocate ();
  
  matrix_function_hermitian (Ar , Ai , f);
    
  const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
  Ar.deallocate ();
  Ai.deallocate ();
  
  A.allocate_fill (A_new);
}





void matrix_function_symmetric (class matrix<complex<double> > &A , complex<double> (&f) (const complex<double> &) )
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("matrix_function_symmetric (complex) is used with square matrices only");
  if (!A.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_symmetric (complex)");
  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in matrix_function_symmetric (complex");

  const unsigned int dimension = A.get_dimension ();

  if (A.is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{	
	  complex<double> &Aii = A(i , i);

	  Aii = f (Aii);
	}

      return;
    }

  class array<complex<double> > eigenvalues (dimension);

  // A becomes P_transpose and eigenvalues is filled

  class matrix<complex<double> > P_transpose = A;

  if (A.is_it_real ())
    total_diagonalization::all_eigenpairs_Householder (P_transpose , eigenvalues);
  else
    total_diagonalization::all_eigenpairs_Newton (P_transpose , eigenvalues);

  // A becomes f(D).P_transpose
  class matrix<complex<double> > &fD_P_transpose = A;

  fD_P_transpose = 0.0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const complex<double> eigenvalue_i = eigenvalues(i);

      const complex<double> f_eigenvalue_i = f (eigenvalue_i);

      const class vector_class<complex<double> > &Pi_transpose = P_transpose.row_vector (i);

      class vector_class<complex<double> > &fD_Pi_transpose = fD_P_transpose.row_vector (i);

      fD_Pi_transpose  = Pi_transpose;
      fD_Pi_transpose *= f_eigenvalue_i;
    }

  // {P}^(-1) is given by P.transpose () and stored in P

  class matrix<complex<double> > &P = P_transpose;
  
  P.transpose ();
  
  // A becomes f(A)
  // The temporary matrix created in operator * is unavoidable as A and fD_P_transpose are the same object.
  A = P*fD_P_transpose;

  A.symmetrize ();
}



void matrix_function_hermitian (class matrix<complex<double> > &Ar , class matrix<complex<double> > &Ai , complex<double> (&f) (const complex<double> &) )
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("matrix_function_hermitian (complex, bicomplex) is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("matrix_function_hermitian (complex, bicomplex) is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_hermitian (complex, bicomplex) (real part)");
  if (!Ai.isfinite ())        error_message_print_abort ("The matrix is not finite in matrix_function_hermitian (complex, bicomplex) (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in matrix_function_hermitian (complex, bicomplex)");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in matrix_function_hermitian (complex, bicomplex)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in matrix_function_hermitian (complex, bicomplex)");
  
  const unsigned int dimension = Ar.get_dimension ();	

  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0))
    {
      for (unsigned int i = 0 ; i < dimension ; i++)
	{	
	  complex<double> &Ar_ii = Ar(i , i);

	  Ar_ii = f (Ar_ii);
	}

      return;
    }

  class array<complex<double> > eigenvalues (dimension);

  // Pr, Pi and eigenvalues are filled
  // As I store vectors as row vectors, transpose is used to have column eigenvectors in Pr and Pi.
  class matrix<complex<double> > Pr_transpose = Ar;
  class matrix<complex<double> > Pi_transpose = Ai;

  if (Ar.is_it_real () && Ai.is_it_real ())
    total_diagonalization::hermitian::all_eigenpairs_Householder (Pr_transpose , Pi_transpose , eigenvalues);
  else
    total_diagonalization::hermitian::all_eigenpairs_Newton (Pr_transpose , Pi_transpose , eigenvalues);

  // I do not use references for all next matrices therein as one needs both next matrices for Ar and Ai, calculated one after the other.
  
  class matrix<complex<double> > fD_Pr_transpose = Ar;
  class matrix<complex<double> > fD_Pi_transpose = Ai;

  fD_Pr_transpose = 0.0;
  fD_Pi_transpose = 0.0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {	
      const complex<double> eigenvalue_i = eigenvalues(i);

      const complex<double> f_eigenvalue_i_maybe_inf = f (eigenvalue_i);

      const complex<double> f_eigenvalue_i = (finite (f_eigenvalue_i_maybe_inf)) ? (f_eigenvalue_i_maybe_inf) : (f (0.0));

      const class vector_class<complex<double> > &Pr_i_transpose = Pr_transpose.row_vector (i);
      const class vector_class<complex<double> > &Pi_i_transpose = Pi_transpose.row_vector (i);

      class vector_class<complex<double> > &fD_Pr_i_transpose = fD_Pr_transpose.row_vector (i);
      class vector_class<complex<double> > &fD_Pi_i_transpose = fD_Pi_transpose.row_vector (i);

      fD_Pr_i_transpose  = Pr_i_transpose;
      fD_Pi_i_transpose  = Pi_i_transpose;
      
      fD_Pr_i_transpose *= f_eigenvalue_i;
      fD_Pi_i_transpose *= f_eigenvalue_i;
    }

  // {Pr + i.Pi}^(-1)  = {Pr + i.Pi}^{+} = Pr.transpose () - i.Pi.transpose ()
  
  class matrix<complex<double> > &Pr = Pr_transpose;
  class matrix<complex<double> > &Pi = Pi_transpose;
  
  Pr.transpose ();
  Pi.transpose ();

  // f(A) = P_dagger.f(D).P is stored in A
  // One uses a work matrix here to avoid the matrix temporaries induced by operator *
  
  class matrix<complex<double> > M(dimension);

  matrix_multiplication (Pr , fD_Pr_transpose , M) , Ar  = M;
  matrix_multiplication (Pi , fD_Pi_transpose , M) , Ar += M;
  
  matrix_multiplication (Pi , fD_Pr_transpose , M) , Ai  = M;
  matrix_multiplication (Pr , fD_Pi_transpose , M) , Ai -= M;

  Ar.symmetrize ();
  Ai.antisymmetrize ();
}





void block_matrix_function_symmetric (class block_matrix<double> &A , double (&f) (const double) )
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<double> &A_block = A(i);

      matrix_function_symmetric (A_block , f);
    }  
}

void block_matrix_function_hermitian (class block_matrix<complex<double> > &A, double (&f) (const double) )
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<complex<double> > &A_block = A(i);

      matrix_function_hermitian (A_block , f);
    }  
}


void block_matrix_function_symmetric (class block_matrix<complex<double> > &A , complex<double> (&f) (const complex<double> &) )
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<complex<double> > &A_block = A(i);

      matrix_function_symmetric (A_block , f);
    }  
}












// One can directly call linear_system_SVD_solution_calc to get a complex vector from complex matrix and vector in the hermitian case.
// They are separated in real and imaginary parts.
// A is copied to Ar and Ai (A = Ar + i.Ai) and deallocated when Ar and Ai only are used.
// It is reallocated afterwards, so that Ar + i.Ai -> A for the new Ar, Ai (LU/Cholesky deomcposed for example).
// This creates no memory time/issue as one needs two to seven real matrices in the routines from the namespace total_diagonalization::hermitian called afterwards, so that one can tolerate an additional matrix here.



void linear_system_SVD_solution_calc (
				      class matrix<double> &A ,
				      const class vector_class<double> &B ,
				      const double relative_SVD_precision ,
				      class vector_class<double> &X)
{
  linear_system_SVD_solution_symmetric_calc (A , B , relative_SVD_precision , X);
}


void linear_system_SVD_solution_calc (
				      class matrix<complex<double> > &A ,
				      const class vector_class<complex<double> > &B ,
				      const double relative_SVD_precision ,
				      class vector_class<complex<double> > &X)
{
  if (A.is_it_symmetric ())
    linear_system_SVD_solution_symmetric_calc (A , B , relative_SVD_precision , X);
  else if (A.is_it_hermitian ())
    {
      if (relative_SVD_precision == 0.0)
	{
	  linear_system_solution_calc (A , B , X);

	  return;
	}
      
      const unsigned int dimension = A.get_dimension ();
  
      const class vector_class<double> Br = real<double , complex<double> > (B);
      const class vector_class<double> Bi = imag<double , complex<double> > (B);
     
      class vector_class<double> Xr(dimension);
      class vector_class<double> Xi(dimension);
  
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
         
      linear_system_SVD_solution_hermitian_calc (Ar , Ai , Br , Bi , relative_SVD_precision , Xr , Xi);
      
      for (unsigned int i = 0 ; i < dimension ; i++)
	{
	  const class vector_class<double> &Ar_i = Ar.row_vector (i);
	  const class vector_class<double> &Ai_i = Ai.row_vector (i);

	  class vector_class<complex<double> > &Ai = A.row_vector (i);
      
	  for (unsigned int j = 0 ; j < dimension ; j++) Ai(j) = complex<double> (Ar_i(j) , Ai_i(j));

	  X(i) = complex<double> (Xr(i) , Xi(i));
	}
    }
  else
    error_message_print_abort ("A must be symmetric or hermitian in linear_system_SVD_solution_calc (complex)");
}









// Standard matrix functions wrapping matrix_function_symmetric
// The matrix has to be symmetric (double, complex) or hermitian (complex).


class matrix<double> exp (const class matrix<double> &A)
{
  class matrix<double> exp_A = A;
  
  matrix_function_symmetric (exp_A , exp);
    
  return exp_A;
}



class matrix<double> log (const class matrix<double> &A)
{
  class matrix<double> log_A = A;
  
  matrix_function_symmetric (log_A , log);
    
  return log_A;
}





class matrix<double> sqrt (const class matrix<double> &A)
{
  class matrix<double> sqrt_A = A;
  
  matrix_function_symmetric (sqrt_A , sqrt);
    
  return sqrt_A;
}



class matrix<double> cbrt (const class matrix<double> &A)
{
  class matrix<double> cbrt_A = A;
  
  matrix_function_symmetric (cbrt_A , cbrt);
    
  return cbrt_A;
}





class matrix<double> cos (const class matrix<double> &A)
{
  class matrix<double> cos_A = A;
  
  matrix_function_symmetric (cos_A , cos);
    
  return cos_A;
}





class matrix<double> sin (const class matrix<double> &A)
{
  class matrix<double> sin_A = A;
  
  matrix_function_symmetric (sin_A , sin);
    
  return sin_A;
}





class matrix<double> tan (const class matrix<double> &A)
{
  class matrix<double> tan_A = A;
  
  matrix_function_symmetric (tan_A , tan);
    
  return tan_A;
}





class matrix<double> acos (const class matrix<double> &A)
{
  class matrix<double> acos_A = A;
  
  matrix_function_symmetric (acos_A , acos);
    
  return acos_A;
}






class matrix<double> asin (const class matrix<double> &A)
{
  class matrix<double> asin_A = A;
  
  matrix_function_symmetric (asin_A , asin);
    
  return asin_A;
}




class matrix<double> atan (const class matrix<double> &A)
{
  class matrix<double> atan_A = A;
  
  matrix_function_symmetric (atan_A , atan);
    
  return atan_A;
}




class matrix<double> cosh (const class matrix<double> &A)
{
  class matrix<double> cosh_A = A;
  
  matrix_function_symmetric (cosh_A , cosh);
    
  return cosh_A;
}




class matrix<double> sinh (const class matrix<double> &A)
{
  class matrix<double> sinh_A = A;
  
  matrix_function_symmetric (sinh_A , sinh);
    
  return sinh_A;
}



class matrix<double> tanh (const class matrix<double> &A)
{
  class matrix<double> tanh_A = A;
  
  matrix_function_symmetric (tanh_A , tanh);
    
  return tanh_A;
}





class matrix<double> acosh (const class matrix<double> &A)
{
  class matrix<double> acosh_A = A;
  
  matrix_function_symmetric (acosh_A , acosh);
    
  return acosh_A;
}





class matrix<double> asinh (const class matrix<double> &A)
{
  class matrix<double> asinh_A = A;
  
  matrix_function_symmetric (asinh_A , asinh);
    
  return asinh_A;
}






class matrix<double> atanh (const class matrix<double> &A)
{
  class matrix<double> atanh_A = A;
  
  matrix_function_symmetric (atanh_A , atanh);
    
  return atanh_A;
}





class matrix<double> expm1 (const class matrix<double> &A)
{
  class matrix<double> expm1_A = A;
  
  matrix_function_symmetric (expm1_A , expm1);

  return expm1_A;
}





class matrix<double> log1p (const class matrix<double> &A)
{
  class matrix<double> log1p_A = A;
  
  matrix_function_symmetric (log1p_A , log1p);
    
  return log1p_A;
}














class matrix<complex<double> > exp (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > exp_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (exp_A , std::exp);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (exp_A , exp);
  else
    error_message_print_abort ("A must be symmetric or hermitian in exp (complex)");
  
  return exp_A;
}



class matrix<complex<double> > log (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > log_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (log_A , std::log);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (log_A , log);
  else
    error_message_print_abort ("A must be symmetric or hermitian in log (complex)");
  
  return log_A;
}





class matrix<complex<double> > sqrt (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > sqrt_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (sqrt_A , std::sqrt);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (sqrt_A , sqrt);
  else 
    error_message_print_abort ("A must be symmetric or hermitian in sqrt (complex)");
  
  return sqrt_A;
}



class matrix<complex<double> > cbrt (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > cbrt_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (cbrt_A , cbrt);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (cbrt_A , cbrt);
  else
    error_message_print_abort ("A must be symmetric or hermitian in cbrt (complex)");
  
  return cbrt_A;
}





class matrix<complex<double> > cos (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > cos_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (cos_A , std::cos);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (cos_A , cos);
  else
    error_message_print_abort ("A must be symmetric or hermitian in cos (complex)");
  
  return cos_A;
}





class matrix<complex<double> > sin (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > sin_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (sin_A , std::sin);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (sin_A , sin);
  else
    error_message_print_abort ("A must be symmetric or hermitian in sin (complex)");
  
  return sin_A;
}





class matrix<complex<double> > tan (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > tan_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (tan_A , std::tan);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (tan_A , tan);
  else
    error_message_print_abort ("A must be symmetric or hermitian in tan (complex)");
  
  return tan_A;
}





class matrix<complex<double> > acos (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > acos_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (acos_A , acos);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (acos_A , acos);
  else
    error_message_print_abort ("A must be symmetric or hermitian in acos (complex)");
  
  return acos_A;
}






class matrix<complex<double> > asin (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > asin_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (asin_A , asin);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (asin_A , asin);
  else
    error_message_print_abort ("A must be symmetric or hermitian in asin (complex)");
  
  return asin_A;
}




class matrix<complex<double> > atan (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > atan_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (atan_A , atan);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (atan_A , atan);
  else
    error_message_print_abort ("A must be symmetric or hermitian in atan (complex)");
  
  return atan_A;
}




class matrix<complex<double> > cosh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > cosh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (cosh_A , std::cosh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (cosh_A , cosh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in cosh (complex)");
  
  return cosh_A;
}




class matrix<complex<double> > sinh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > sinh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (sinh_A , std::sinh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (sinh_A , sinh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in sinh (complex)");
  
  return sinh_A;
}



class matrix<complex<double> > tanh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > tanh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (tanh_A , std::tanh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (tanh_A , tanh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in tanh (complex)");
  
  return tanh_A;
}





class matrix<complex<double> > acosh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > acosh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (acosh_A , acosh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (acosh_A , acosh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in acosh (complex)");
  
  return acosh_A;
}





class matrix<complex<double> > asinh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > asinh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (asinh_A , asinh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (asinh_A , asinh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in asinh (complex)");
  
  return asinh_A;
}






class matrix<complex<double> > atanh (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > atanh_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (atanh_A , atanh);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (atanh_A , atanh);
  else
    error_message_print_abort ("A must be symmetric or hermitian in atanh (complex)");
  
  return atanh_A;
}





class matrix<complex<double> > expm1 (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > expm1_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (expm1_A , expm1);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (expm1_A , expm1);
  else
    error_message_print_abort ("A must be symmetric or hermitian in expm1 (complex)");
  
  return expm1_A;
}





class matrix<complex<double> > log1p (const class matrix<complex<double> > &A)
{
  class matrix<complex<double> > log1p_A = A;
  
  if (A.is_it_symmetric ())
    matrix_function_symmetric (log1p_A , log1p);
  else if (A.is_it_hermitian ())
    matrix_function_hermitian (log1p_A , log1p);
  else
    error_message_print_abort ("A must be symmetric or hermitian in log1p (complex)");
  
  return log1p_A;
}



