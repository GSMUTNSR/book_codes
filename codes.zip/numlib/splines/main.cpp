#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const unsigned int N = 100;

    const unsigned int N_big = 5677;

    const double rmin = 1;
    const double rmax = 10;

    const double sample = 0.005;

    const double step = (rmax - rmin)/static_cast<double> (N - 1);

    const double step_big = (rmax - rmin)/static_cast<double> (N_big - 1);

    const int alpha = 3;

    const complex<double> beta(1.1 , 0.01);
    
    const complex<double> beta_p1 = beta + 1.0;
    const complex<double> beta_m1 = beta - 1.0;

    class array<double> r_tab(N);

    class array<complex<double> > f_tab(N);
    class array<complex<double> > g_tab(N);

    for (unsigned int i = 0 ; i < N ; i++)
      {
	const double r = rmin + i*step*(1 + 0.1*random_number<double> ());
	
	r_tab(i) = r;
	
	f_tab(i) = pow (r , beta);
	g_tab(i) = pow (r , beta_p1);
      }

    const complex<double> r_deb = r_tab(0);
    const complex<double> r_end = r_tab(N-1);

    const class splines_class<complex<double> > f1_splines(r_tab , f_tab);
    const class splines_class<complex<double> > f2_splines(r_tab , f_tab , beta   *pow (r_deb , beta_m1) , beta   *pow (r_end , beta_m1));
    const class splines_class<complex<double> > g2_splines(r_tab , g_tab , beta_p1*pow (r_deb , beta)    , beta_p1*pow (r_end , beta));

    const class splines_moment_class<complex<double> > moments(alpha , f2_splines);

    const class splines_scaled_integration_class<complex<double> > f_scaled(alpha , f2_splines);
    const class splines_scaled_integration_class<complex<double> > g_scaled(alpha , g2_splines);

    for (unsigned int i = 0 ; i < N_big ; i++)
      {
	if (random_number<double> () < sample)
	  {
	    const double r = rmin + i*step_big;

	    const complex<double> f1_r      = f1_splines(r);
	    const complex<double> f1_r_der  = f1_splines.derivative (r);
	    const complex<double> f1_r_prim = f1_splines.primitive (r);

	    const complex<double> f2_r      = f2_splines(r);
	    const complex<double> f2_r_der  = f2_splines.derivative (r);
	    const complex<double> f2_r_prim = f2_splines.primitive (r);
	    const complex<double> f2_moment = moments(r);

	    const complex<double> f_r = pow (r , beta);

	    const complex<double> f_r_der = beta*pow (r , beta_m1);

	    const complex<double> f_r_prim = pow (r , beta + 1)/(beta + 1) - pow (r_deb , beta + 1)/(beta + 1);
	  
	    const complex<double> f_moment = pow (r , alpha + beta + 1)/(alpha + beta + 1) - pow (r_deb , alpha + beta + 1)/(alpha + beta + 1);

	    const complex<double> f_scaled_r = f_scaled(r);
	    const complex<double> g_scaled_r = g_scaled(r);

	    //f_scaled_r_test is obtained from f_scaled_r via an integration by parts: t^beta is integrated and exp (alpha*(t - r)) differentiated.
	  
	    const complex<double> f_scaled_r_test = pow (r , beta + 1)/(beta + 1) - pow (r_deb , beta + 1)/(beta + 1)*exp (alpha*(r_deb - r)) - alpha/beta_p1*g_scaled_r;

	    cout << " r : " << r << " f1 precision : " << (inf_norm (f1_r - f_r)) << endl;
	  
	    cout << " r : " << r << " f1' precision : " << (inf_norm (f1_r_der - f_r_der)) << endl;

	    cout << " r : " << r << " f1 primitive precision : " << (inf_norm (f1_r_prim - f_r_prim)) << endl;

	    cout << " r : " << r << " f2 precision : " << (inf_norm (f2_r - f_r))  << endl;

	    cout << " r : " << r << " f2' precision : " << (inf_norm (f2_r_der - f_r_der)) << endl;

	    cout << " r : " << r << " f2 primitive precision : " << (inf_norm (f2_r_prim - f_r_prim)) << endl;

	    cout << " r : " << r << " f moment precision : " << (inf_norm (f2_moment - f_moment)) << endl;

	    cout << " r : " << r << " f scaled integral precision : " << (inf_norm (f_scaled_r - f_scaled_r_test)) << endl << endl;
	  }
      }
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

