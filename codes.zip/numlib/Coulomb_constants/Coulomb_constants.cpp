#include "../numlib_def/numlib_def.h"

// Whittaker constant
// ------------------
// It is exp ((-eta + i.l).Pi/2 - i.sigma) , so that Wm(z) = H+(z).Whittaker_const.
// Wm is the modified Whittaker function , as it is real for z and eta pure imaginary (bound states).

complex<double> Whittaker_const_calc (const complex<double> &l , const complex<double> &eta)
{
  const complex<double> sigma = sigma_l_calc (l , eta);
  const complex<double> I_l(-imag (l) , real (l));
  const complex<double> I_sigma(-imag (sigma) , real (sigma));
  const complex<double> Whittaker_const = exp ((-eta + I_l) * M_PI_2 - I_sigma); 
  
  return Whittaker_const;
}



// Coulomb phase shift.
// --------------------
// It is given by the formula [Gamma[1 + l + I.eta] - Gamma[1 + l - I.eta]]/[2i].
// 0 is returned if 1 + l +/- I.eta is a negative integer.
//
// Variables:
// ----------
// l : orbital angular momentum l.
// eta : Sommerfeld parameter.
// Ieta , one_over_two_I : i.eta , 1/[2.i] .
// arg_plus , arg_minus : 1 + l + i.eta , 1 + l - i.eta.
// log_Gamma_plus , log_Gamma_minus : logs of Gamma[1 + l + I.eta] , Gamma[1 + l - I.eta].
// sigma_l : returned result.

complex<double> sigma_l_calc (const complex<double> &l , const complex<double> &eta)
{
  const complex<double> Ieta(-imag (eta) , real (eta));
  const complex<double> one_over_two_I(0 , -0.5);

  const complex<double> arg_plus = 1.0 + l + Ieta;
  const complex<double> arg_minus = 1.0 + l - Ieta;

  if ((rint (real (arg_plus)) == arg_plus) && (rint (real (arg_plus)) <= 0.0))
    {
      return 0.0;
    }

  if ((rint (real (arg_minus)) == arg_minus) && (rint (real (arg_minus)) <= 0.0))
    {
      return 0.0;
    }

  const complex<double> log_Gamma_plus = log_Gamma (arg_plus);
  const complex<double> log_Gamma_minus = log_Gamma (arg_minus); 

  const complex<double> sigma_l = (log_Gamma_plus - log_Gamma_minus) * one_over_two_I;

  return sigma_l;
}






// log of C(l , eta)
// ---------------- 
// It is given by the formula l * log[2] - eta.Pi/2 + (log[Gamma[1 + l + I.eta]] + log[Gamma[1 + l - I.eta]])/2 - log[Gamma[2l + 2]].
// 0 is returned if 1 + l +/- I.eta is a negative integer.
// 2l + 2 should not be a negative integer : one has to use- l - 1 instead of l in this case.
//
// Variables:
// ----------
// l : orbital angular momentum l.
// eta : Sommerfeld parameter.
// Ieta : i.eta .
// arg_plus , arg_minus : 1 + l + i.eta , 1 + l - i.eta.
// log_Gamma_plus , log_Gamma_minus , log_Gamma_2l_plus_2 : logs of Gamma[1 + l + I.eta] , Gamma[1 + l - I.eta] , Gamma[2l + 2].
// log_Cl_eta : returned result.

complex<double> log_Cl_eta_calc (const complex<double> &l , const complex<double> &eta)
{
  const complex<double> Ieta(-imag (eta) , real (eta));

  const complex<double> arg_plus = 1.0 + l + Ieta;
  const complex<double> arg_minus = 1.0 + l - Ieta; 

  if ((rint (real (arg_plus)) == arg_plus) && (rint (real (arg_plus)) <= 0.0))
    {
      return 0.0;
    }

  if ((rint (real (arg_minus)) == arg_minus) && (rint (real (arg_minus)) <= 0.0))
    {
      return 0.0;
    }

  const complex<double> log_Gamma_plus = log_Gamma (arg_plus);
  const complex<double> log_Gamma_minus = log_Gamma (arg_minus);
  const complex<double> log_Gamma_2l_plus_2 = log_Gamma (2.0 * l + 2.0);

  const complex<double> log_Cl_eta = l * M_LN2 - M_PI_2*eta + 0.5*(log_Gamma_plus + log_Gamma_minus) - log_Gamma_2l_plus_2;

  return log_Cl_eta;
}



// Cut constant log for the asymptotic series.
// ------------------------------------------ - 
// The asymptotic series and H[omega] behave differently near the negative real axis.
// Then , if one is in the bad quadrant of H[omega] , one has to take into account the cut directly.
// One is in the bad quadrant of H[omega] if Re[z] < 0.0 and sign(Im[z]) = - omega.
// 
// H[omega] = [H[omega] from asymptotic function formula] + (1 - exp(2.i.Pi.(i.eta - l.omega))).[H[ - omega] from asymptotic function formula]
//
//
// The cut constant log is then log [1 - exp(2.i.Pi.(i.eta - l.omega))].
// Its returned imaginary part is not necessarily in ] - Pi:Pi]
//
//
// Variables:
// ----------
// omega : 1 or - 1.
// l : orbital angular momentum l.
// eta : Sommerfeld parameter.
// Ieta : i.eta
// l_int , Ieta_int : closest integers to Re[l] , Re[i.eta]
// eps : (Ieta - Ieta_int) - (l.omega - l_int.omega)
// two_I_Pi , two_I_Pi_eps : 2.i.Pi , 2.i.Pi.eps .
// log_cut_constant : returned result.

complex<double> log_cut_constant_AS_calc (const int omega , const complex<double> &l , const complex<double> &eta)
{
  const complex<double> Ieta(-imag (eta) , real (eta));

  const double l_int = rint (real (l));
  const double Ieta_int = rint (real (Ieta));

  const complex<double> eps = (Ieta - Ieta_int) - omega * (l - l_int);

  const complex<double> two_I_Pi(0 , 2.0 * M_PI);
  const complex<double> two_I_Pi_eps = two_I_Pi * eps;

  if (real (two_I_Pi_eps) > -0.1)
    {
      const complex<double> log_cut_constant = log (expm1 (-two_I_Pi_eps)) + two_I_Pi_eps;

      return log_cut_constant;
    }
  else
    {
      const complex<double> log_cut_constant = log1p (-exp (two_I_Pi_eps));

      return log_cut_constant;
    }
}





// Cut constant log for continued fractions : H[omega] from H[omega , not corrected] case.
// --------------------------------------------------------------------------------------
// The continued fraction has no cut on the negative real axis , whereas H[omega] has one.
// Then , if one is in the bad quadrant of H[omega] , one has to take into account the cut directly.
// One is in the bad quadrant of H[omega] if Re[z] < 0.0 and sign(Im[z]) = - omega.
// 
// H[omega] = H[omega , not corrected] - cut_constant.F .
//
// The cut constant is 2i.omega.norm.(exp (2.i.Pi.[l.omega - i.eta]) - 1) , and one takes its log.
// The imaginary part of the log is not necessarily in ] - Pi:Pi].
// Norm is 1.0 for normalized wave functions , C(l , eta)^2 for unnormalized wave functions.
//
//
// Variables:
// ---------- 
// is_it_normalized : true if one wants normalized functions , i.e. the standard normalization , 
// false if one wants F -> F/C(l , eta) and H+/H-/G -> H+/H-/G.C(l , eta) , to avoid overflows for |eta| >> 1 and |z| small.
// omega : 1 or -1.
// l : orbital angular momentum l.
// eta : Sommerfeld parameter.
// Ieta : i.eta .
// l_int , Ieta_int : closest integers to Re[l] , Re[i.eta]
// eps : (l.omega - l_int.omega) - (Ieta - Ieta_int)
// log_norm : log[C(l , eta)^2] if is_it_normalized is false , 0.0 if it is true.
// two_I_Pi , two_I_Pi_eps : 2.i.Pi , 2.i.Pi.eps .
// log_two_I_omega : log[2.i.omega] = log[2] + i.omega.Pi/2 .
// log_cut_constant : returned result.

complex<double> log_cut_constant_CFa_calc (
					   const bool is_it_normalized , 
					   const int omega , 
					   const complex<double> &l , 
					   const complex<double> &eta)
{
  const complex<double> Ieta(-imag (eta) , real (eta));

  const double l_int = rint (real (l));
  const double Ieta_int = rint (real (Ieta));

  const complex<double> eps = omega * (l - l_int) - (Ieta - Ieta_int);
  const complex<double> log_norm = (!is_it_normalized) ? (2.0 * log_Cl_eta_calc (l , eta)) : (0.0);

  const complex<double> two_I_Pi(0 , 2.0 * M_PI);
  const complex<double> two_I_Pi_eps = two_I_Pi * eps;
  const complex<double> log_two_I_omega(M_LN2 , omega * M_PI_2);

  if (real (two_I_Pi_eps) < 0.1)
    {
      const complex<double> log_cut_constant = log_two_I_omega + log (expm1 (two_I_Pi_eps)) + log_norm;

      return log_cut_constant;
    }
  else
    {
      const complex<double> log_cut_constant = log_two_I_omega + log1p (-exp (-two_I_Pi_eps)) + two_I_Pi_eps + log_norm;

      return log_cut_constant; 
    }
}




// Cut constant log for continued fractions : H[omega] from H[ - omega , not corrected] case.
// -------------------------------------------------------------------------------------- - 
// The continued fraction has no cut on the negative real axis , whereas H[-omega] has one.
// Then , if one is in the bad quadrant of H[-omega] , one has to take into account the cut directly.
// One is in the bad quadrant of H[ - omega] if Re[z] < 0.0 and sign(Im[z]) = omega.
// 
// H[omega] = H[-omega , not corrected] - cut_constant.F .
//
// The cut constant is 2i.omega.norm.exp (-2.i.Pi.[l.omega + i.eta]) , and one takes its log.
// The returned imaginary part of the log is not necessarily in ]-Pi:Pi].
// Norm is 1.0 for normalized wave functions , C(l , eta)^2 for unnormalized wave functions.
//
//
// Variables:
// ----------
// is_it_normalized : true if one wants normalized functions , i.e. the standard normalization , 
// false if one wants F -> F/C(l , eta) and H+/H-/G -> H+/H-/G.C(l , eta) , to avoid overflows for |eta| >> 1 and |z| small.
// omega : 1 or -1.
// l : orbital angular momentum l.
// eta : Sommerfeld parameter = Coulomb_constant.Z.(2.mu/hbar^2)/(2k).
// Ieta : i.eta .
// l_int , Ieta_int : closest integers to Re[l] , Re[i.eta]
// eps : (l.omega - l_int.omega) + (Ieta - Ieta_int)
// two_I_Pi : 2.i.Pi .
// log_norm : log[C(l , eta)^2] if is_it_normalized is false , 0.0 if it is true.
// log_two_I_omega : log[2.i.omega] = log[2] + i.omega.Pi/2 .
// log_cut_constant : returned result.

complex<double> log_cut_constant_CFb_calc (
					   const bool is_it_normalized , 
					   const int omega , 
					   const complex<double> &l , 
					   const complex<double> &eta)
{
  const complex<double> Ieta(-imag (eta) , real (eta));

  const double l_int = rint (real (l));
  const double Ieta_int = rint (real (Ieta));

  const complex<double> eps = omega * (l - l_int) + (Ieta - Ieta_int);
  const complex<double> log_norm = (!is_it_normalized) ? (2.0 * log_Cl_eta_calc (l , eta)) : (0.0);

  const complex<double> two_I_Pi(0 , 2.0 * M_PI);
  const complex<double> log_two_I_omega(M_LN2 , omega * M_PI_2);
  const complex<double> log_cut_constant = log_two_I_omega - two_I_Pi * eps + log_norm;

  return log_cut_constant;
}



// Sin (chi) calculation
// --------------------- 
// If 2l is integer , 0 is returned as chi is zero.
// If not, one calculates sin (chi) with chi = sigma(l , eta) - sigma(-l-1 , eta) - (l + 1/2).Pi .
// One uses the stable formula sin (chi) = -(2l + 1).C(l , eta).C(-l-1 , eta).
//
// Variables
// --------- 
// l : orbital angular momentum l.
// two_l: 2.l
// eta : Sommerfeld parameter.
// sin_chi : sin (chi)

complex<double> sin_chi_calc (const complex<double> &l , const complex<double> &eta)
{
  const complex<double> two_l = 2.0*l;
  
  if (rint (real (two_l)) == two_l)
    {
      return 0.0;
    }

  const complex<double> sin_chi = -(2*l + 1) * exp (log_Cl_eta_calc (l , eta) + log_Cl_eta_calc (-l-1 , eta));

  return sin_chi;
}







// exp (i.omega.chi) calculation.
// ------------------------------
// One calculates exp (i.omega.chi), with chi = sigma(l , eta) - sigma(l , -eta) - (l + 1/2).Pi .
// If 2l is integer, 1 is returned as chi is zero.
// If not, one first calculates sin (chi) with the previous routine.
// If |sin (chi)| > 0.5, chi obtained with the formula sigma(l , eta) - sigma(l , -eta) - (l + 1/2).Pi is stable so that exp[i.omega.chi] follows directly.
// If not, one uses exp[i.omega.chi] = cos (chi) + i.omega.sin (chi), with cos (chi) = sqrt [1 - sin (chi) * sin (chi)].sign[Re[cos (chi)]], 
// with chi given by sigma(l , eta) - sigma(l , - eta) - (l + 1/2).Pi and sin (chi) given by sin_chi_calc (see above). 
// One assumes that sign[Re[cos (chi)]] is correct even if cos (chi) calculated directly is not precise.
//
// Variables
// -------- - 
// omega : 1 or -1
// l : orbital angular momentum l.
// eta : Sommerfeld parameter = Coulomb_constant.Z.(2.mu/hbar^2)/(2k).
// two_l: 2.l
// I_omega : i.omega
// sin_chi : sin (chi)
// chi : sigma(l , eta) - sigma(l , - eta) - (l + 1/2).Pi . 
// cos_chi : sign[Re[cos (chi)]].sqrt[1 - [sin(chi)]^2]
// exp_I_omega_chi : exp[i.omega.chi] , returned result.

complex<double> exp_I_omega_chi_calc (const int omega , const complex<double> &l , const complex<double> &eta)
{
  const complex<double> two_l = 2.0*l;
  
  if (rint (real (two_l)) == two_l)
    {
      return 1.0;
    }

  const complex<double> I_omega(0 , omega);
  
  const complex<double> sin_chi = sin_chi_calc (l , eta);

  const complex<double> chi = sigma_l_calc (l , eta) - sigma_l_calc (-l-1 , eta) - (l + 0.5) * M_PI;

  if (abs (sin_chi) > 0.5)
    {
      const complex<double> exp_I_omega_chi = exp (I_omega * chi);

      return exp_I_omega_chi;
    }
  else
    {
      const complex<double> cos_chi = SIGN (real (cos (chi))) * sqrt (1.0 - sin_chi * sin_chi);
      
      const complex<double> exp_I_omega_chi = cos_chi + I_omega * sin_chi;

      return exp_I_omega_chi;
    }
}




