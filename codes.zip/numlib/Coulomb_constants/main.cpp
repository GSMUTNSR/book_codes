#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();

    const complex<double> I(0 , 1);
    
    const complex<double> l(1.0 , 0.1);
    
    const complex<double> eta (2.0 , 0.1);
    
    cout << "Small imaginary parts of l and eta are handled in Coulomb_wave_functions.cpp" << endl << endl;
    
    cout << "l : " << l << endl;
    
    cout << "eta : " << eta << endl << endl;

    const complex<double> W = Whittaker_const_calc (l , eta);

    const complex<double> sigma_l   = sigma_l_calc (l   , eta);
    const complex<double> sigma_lp1 = sigma_l_calc (l+1 , eta);

    cout << "Whittaker_const (l , eta) : " << W << endl;
    
    cout << "recalculation test : " << inf_norm (W - exp (( - eta + I*l) * M_PI_2 - I*sigma_l)) << endl << endl;

    const double test_sigma = inf_norm (sigma_lp1 - sigma_l - atan (eta/(l+1.0)));
    
    cout << "sigma_l_calc (l , eta) : " << sigma_l << endl;
    
    cout << "|sigma(l+1 , eta) - sigma(l , eta) - atan (eta/(l+1))|oo : " << test_sigma << endl << endl;

    const complex<double> Cl_eta   = exp (log_Cl_eta_calc (l   , eta));
    const complex<double> Clm1_eta = exp (log_Cl_eta_calc (l-1 , eta));

    const double test_Cl_eta = inf_norm (Cl_eta - sqrt (l*l + eta*eta)/l/(2*l+1)*Clm1_eta); 

    cout << "Cl_eta : " << Cl_eta << endl;
    
    cout << "|Cl_eta - sqrt (l^2 + eta^2)/[l.(2l+1)]C(l-1 , eta)|oo : " << test_Cl_eta << endl << endl;

    const complex<double> log_cut_constant_AS = log_cut_constant_AS_calc (1 , l , eta);
    
    cout << "log_cut_constant_AS_calc (1 , l , eta) : " << log_cut_constant_AS << endl;
    
    cout << "recalculation test : " << inf_norm (log_cut_constant_AS - log (1 - exp (2*I*M_PI*(I*eta - l)))) << endl << endl;

    const complex<double> log_cut_constant_CFa = log_cut_constant_CFa_calc (true , 1 , l , eta);

    cout << "log_cut_constant_CFa_calc (true , 1 , l , eta) : " << log_cut_constant_CFa << endl;
    
    cout << "recalculation test : " << inf_norm (log_cut_constant_CFa - log (2*I*(exp (2*I*M_PI*(l - I*eta)) - 1))) << endl << endl;

    const complex<double> log_cut_constant_CFb = log_cut_constant_CFb_calc (true , 1 , l , eta);

    cout << "log_cut_constant_CFb_calc (true , 1 , l , eta) : " << log_cut_constant_CFb << endl;
    
    cout << "recalculation test : " << inf_norm (log_cut_constant_CFb - log (2*I*exp (-2*I*M_PI*(l + I*eta)))) << endl << endl;

    // sin_chi is not calculated in Coulomb_constants.cpp by sin (chi) but by - (2l + 1).C(l , eta).C( - l - 1 , eta) , which is more stable numerically.

    const complex<double> sin_chi = sin_chi_calc (l , eta);

    const complex<double> chi = sigma_l_calc (l , eta) - sigma_l_calc ( - l - 1 , eta) - (l + 0.5) * M_PI;

    const double test_sin_chi = inf_norm (sin_chi - sin (chi));
    
    cout << "sin_chi_calc (l , eta) : " << sin_chi << endl;
    
    cout << "|sin (chi) [from code formula] - sin (chi) [direct calculation]|oo : " << test_sin_chi << endl << endl;

    const complex<double> exp_I_chi = exp_I_omega_chi_calc (1 , l , eta);

    const double test_exp_I_chi = inf_norm (exp_I_chi - exp (I*chi));
    
    cout << "exp_I_omega_chi_calc (1 , l , eta) : " << exp_I_chi << endl;
    
    cout << "|exp (i.chi) [from code formula] - exp (i.chi) [direct calculation]|oo : " << test_exp_I_chi << endl << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


