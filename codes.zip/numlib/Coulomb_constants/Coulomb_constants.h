#ifndef COULOMB_CONSTANTS_H
#define COULOMB_CONSTANTS_H

complex<double> Whittaker_const_calc (const complex<double> &l , const complex<double> &eta);

complex<double> sigma_l_calc (const complex<double> &l , const complex<double> &eta);

complex<double> log_Cl_eta_calc (const complex<double> &l , const complex<double> &eta);

complex<double> log_cut_constant_AS_calc (const int omega , const complex<double> &l , const complex<double> &eta);

complex<double> log_cut_constant_CFa_calc (
					   const bool is_it_normalized , 
					   const int omega , 
					   const complex<double> &l , 
					   const complex<double> &eta);

complex<double> log_cut_constant_CFb_calc (
					   const bool is_it_normalized , 
					   const int omega , 
					   const complex<double> &l , 
					   const complex<double> &eta);

complex<double> sin_chi_calc (const complex<double> &l , const complex<double> &eta);

complex<double> exp_I_omega_chi_calc (const int omega , const complex<double> &l , const complex<double> &eta);

#endif

