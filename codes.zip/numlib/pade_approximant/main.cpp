#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    seed ();
    
    const unsigned int N = 7;
    
    const unsigned int two_N_plus_one = 2*N + 1;
    
    const unsigned int Np1 = N + 1;

    cout << "Test of (1 + i)/(1 - x) expanded in power series with " << two_N_plus_one << " terms and Pade approximant from the power series" << endl << endl;
    
    const unsigned int Np = 30;

    const complex<double> alpha(1 , 1);
    
    const double r_max = 10;
        
    class array<complex<double> > cn(two_N_plus_one);

    class array<complex<double> > an(Np1);
    class array<complex<double> > bn(Np1);

    cn.random_array ();
    
    cn *= 1E-15;
    cn += 1.0;
    cn *= alpha;
    
    pade_approximant::an_bn_calc (cn , an , bn);
    
    for (unsigned i = 0 ; i < Np ; i++)
      {
	const complex<double> x = r_max*random_number<complex<double> > ();
	
	const complex<double> fx_pade = pade_approximant::function_calc (an , bn , x);

	const complex<double> fx_exact = alpha/(1.0 - x);

	const double test = inf_norm (1.0 - fx_pade/fx_exact);
	
	cout << "x:" << x << "   Pade:" << fx_pade << "   exact:" << fx_exact << "   test:" << test << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


