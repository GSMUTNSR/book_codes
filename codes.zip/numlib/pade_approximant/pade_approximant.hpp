#ifndef PADE_APPROXIMANT_HPP
#define PADE_APPROXIMANT_HPP

namespace pade_approximant
{
  template<typename SCALAR_TYPE>
  void an_bn_calc (
		   const class array<SCALAR_TYPE> &cn,
		   class array<SCALAR_TYPE> &an,
		   class array<SCALAR_TYPE> &bn);
  
  template<typename SCALAR_TYPE>
  SCALAR_TYPE function_calc (
			     const class array<SCALAR_TYPE> &an,
			     const class array<SCALAR_TYPE> &bn ,
			     const SCALAR_TYPE &x); 
}




// Calculation of the pade approximant arrays a(n) and b(n)
// --------------------------------------------------------
// One has f(x) ~ \sum_{n = 0}^{2N + 1} c(n) x^n => fr(x) ~ \sum_{n = 0}^{N} a(n) x^n / \sum_{n = 0}^{N} b(n) x^n with a(0) = c(0) and b(0) = 1.
// c(n) must have 2N + 1 terms and a(n), b(n), N+1 terms.
// |x| can typically be larger in the pade approximant compared to the power series, as the power series typically has a finite radius of convergence. 
// See Numerical Recipes for the method.
//
// One has to solve a linear system to obtain a(n), b(n).
// If the matrix of the linear system is non-invertible, this can mean that a(n) and b(n) are not unique.
// Then, one can try to add very small numbers (~10^{-15} in relative value) to c(n) numbers to fix the solution.
//
// Arrays a(n) and b(n) are calculated in an_bn_calc.
// fr(x) ~ \sum_{n = 0}^{N} a(n) x^n / \sum_{n = 0}^{N} b(n) x^n is calculated in function_calc.
//
// Variables
// ---------
// an, bn, cn: see above
// x: variable of f(x) (see above)
//
// A, X , Y: one must solve the linear system AX = Y to obtain an, bn.
//           A(i , j) = cn(i + N - j) and  Y(i) = cn(i + N + 1) for (i,j) in [0:N-1].
//           This linear system is obtained from the equality fr^(k) (0) = f^(k) (0) for k in [1:2N].
//           Then, a(0) = c(0), b(0) = 1, and a(i + 1) = Y(i), b(i + 1) = -X(i) for i in [0:N-1].

template<typename SCALAR_TYPE>
void pade_approximant::an_bn_calc (
				   const class array<SCALAR_TYPE> &cn,
				   class array<SCALAR_TYPE> &an,
				   class array<SCALAR_TYPE> &bn)
{
  const unsigned int Np1 = an.dimension (0);
    
  const unsigned int N = Np1 - 1;

  if ((bn.dimension (0) != an.dimension (0)) || (cn.dimension (0) != 2*N + 1))
    error_message_print_abort ("cn must have 2N+1 terms, and an, bn must have N+1 terms in pade_approximant::an_bn_calc");
    
  class matrix<SCALAR_TYPE> A(N);

  class vector_class<SCALAR_TYPE> Y(N);
  class vector_class<SCALAR_TYPE> X(N);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      Y(i) = cn(i + Np1);

      for (unsigned int j = 0 ; j < N ; j++)
	{
	  const unsigned int Nmj = N - j;
	  
	  A(i , j) = cn(i + Nmj);
	}
    }
  
  linear_system_solution_calc (A , Y , X);
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      SCALAR_TYPE Yi = cn(i + 1);
    
      for (unsigned int j = 0 ; j <= i ; j++) Yi -= X(j)*cn(i - j);

      Y(i) = Yi;
    }

  an(0) = cn(0);
  
  bn(0) = 1.0;
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const unsigned int ip1 = i + 1;
    
      an(ip1) =  Y(i);
      bn(ip1) = -X(i);
    }
}
  
template<typename SCALAR_TYPE>
SCALAR_TYPE pade_approximant::function_calc (
					     const class array<SCALAR_TYPE> &an,
					     const class array<SCALAR_TYPE> &bn ,
					     const SCALAR_TYPE &x)
{
  const unsigned int N = an.dimension (0) - 1;
    
  const SCALAR_TYPE fx = polynomial_evaluation (N , an , x) / polynomial_evaluation (N , bn , x);

  return fx;
}

#endif
