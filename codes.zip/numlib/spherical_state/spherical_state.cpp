#include "../numlib_def/numlib_def.h"

// Except for COMPLEX_WS and COMPLEX_INTERPOLATED_POTENTIAL , one considers that all potentials are real (normal case or equivalent potential of a real wave function).

using namespace string_routines;
using namespace Jost_WS_potential_fit;

spherical_state::spherical_state () :
  is_k_OK (false) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  E (0.0) ,
  C0 (0.0) ,
  Cplus (0.0) ,
  Cminus (0.0) ,
  CF (0.0) ,
  CG (0.0) ,
  wf_R0 (0.0) ,
  dwf_R0 (0.0) ,
  is_k_search_start_used (false) ,
  k_search_start (0.0) ,
  is_it_relative (false) ,
  are_there_scaled_wfs (false) ,
  n (0) ,
  jr (0) ,
  l (0) ,
  j (0) ,
  particle (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  potential (NO_POTENTIAL) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  matching_point (0.0) ,
  s_radial (0.0) ,
  R0 (0.0) ,
  R_real_max (0.0) ,
  kmax_momentum (0.0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) , 
  N_matching_point (0) ,
  N_bef_s_GL (0) ,
  N_bef_R_GL (0) ,
  N_aft_R_GL (0) ,
  N_bef_R_uniform (0) ,
  N_aft_R_uniform (0) ,
  Nk_momentum_uniform (0) ,  
  Nk_momentum_GL (0) ,
  is_it_cwf_standard_normalization (false) {}

spherical_state::spherical_state (
				  const bool is_it_relative_c , 
				  const bool are_there_scaled_wfs_c , 
				  const enum potential_type potential_c , 
				  const int A_c , 
				  const int Z_charge_c , 
				  const double mass_modif , 
				  const unsigned int N_bef_s_GL_c , 
				  const unsigned int N_bef_R_GL_c , 
				  const unsigned int N_aft_R_GL_c , 
				  const unsigned int N_bef_R_uniform_c , 
				  const unsigned int N_aft_R_uniform_c , 
				  const unsigned int Nk_momentum_GL_c , 
				  const unsigned int Nk_momentum_uniform_c , 
				  const double R_c , 
				  const double s_radial_c , 
				  const double R0_c , 
				  const double R_real_max_c , 
				  const double kmax_momentum_c , 
				  const double R_Fermi_momentum_c , 
				  const bool S_matrix_pole_c , 
				  const enum particle_type particle_c , 
				  const int n_c , 
				  const double jr_c , 
				  const int l_c , 
				  const double j_c , 
				  const bool automatic_starting_point , 
				  const complex<double> &k_c , 
				  const double effective_mass_for_calc , 
				  const complex<double> &C0_c , 
				  const complex<double> &Cplus_c) : 
  is_k_OK (false) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  E (0.0) ,
  C0 (0.0) ,
  Cplus (0.0) ,
  Cminus (0.0) ,
  CF (0.0) ,
  CG (0.0) ,
  wf_R0 (0.0) ,
  dwf_R0 (0.0) ,
  is_k_search_start_used (false) ,
  k_search_start (0.0) ,
  is_it_relative (false) ,
  are_there_scaled_wfs (false) ,
  n (0) ,
  jr (0) ,
  l (0) ,
  j (0) ,
  particle (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  potential (NO_POTENTIAL) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  matching_point (0.0) ,
  s_radial (0.0) ,
  R0 (0.0) ,
  R_real_max (0.0) ,
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) , 
  N_matching_point (0) ,
  N_bef_s_GL (0) ,
  N_bef_R_GL (0) ,
  N_aft_R_GL (0) ,
  N_bef_R_uniform (0) ,
  N_aft_R_uniform (0) ,
  Nk_momentum_uniform (0) ,  
  Nk_momentum_GL (0) ,
  is_it_cwf_standard_normalization (false)
{
  allocate (is_it_relative_c , are_there_scaled_wfs_c , potential_c , A_c , Z_charge_c , mass_modif ,
	    N_bef_s_GL_c , N_bef_R_GL_c , N_aft_R_GL_c , N_bef_R_uniform_c , N_aft_R_uniform_c , Nk_momentum_GL_c , Nk_momentum_uniform_c , 
	    R_c , s_radial_c , R0_c , R_real_max_c , kmax_momentum_c , R_Fermi_momentum_c , S_matrix_pole_c , particle_c ,
	    n_c , jr_c , l_c , j_c , automatic_starting_point , k_c , effective_mass_for_calc , C0_c , Cplus_c);
}






// Standard copy constructor  
// ------------------------

spherical_state::spherical_state (const class spherical_state &X) :
  is_k_OK (false) ,
  kinetic_factor (0.0) ,
  k (0.0) ,
  eta (0.0) ,
  E (0.0) ,
  C0 (0.0) ,
  Cplus (0.0) ,
  Cminus (0.0) ,
  CF (0.0) ,
  CG (0.0) ,
  wf_R0 (0.0) ,
  dwf_R0 (0.0) ,
  is_k_search_start_used (false) ,
  k_search_start (0.0) ,
  is_it_relative (false) ,
  are_there_scaled_wfs (false) ,
  n (0) ,
  jr (0) ,
  l (0) ,
  j (0) ,
  particle (NO_PARTICLE) ,
  S_matrix_pole (false) ,
  potential (NO_POTENTIAL) ,
  A (0) ,
  Z_charge (0) ,
  R (0.0) ,
  matching_point (0.0) ,
  s_radial (0.0) ,
  R0 (0.0) ,
  R_real_max (0.0) ,
  kmax_momentum (0.0) ,
  R_Fermi_momentum (0.0) ,
  step_bef_R_uniform (0.0) ,
  step_aft_R_uniform (0.0) ,
  step_momentum_uniform (0.0) , 
  N_matching_point (0) ,
  N_bef_s_GL (0) ,
  N_bef_R_GL (0) ,
  N_aft_R_GL (0) ,
  N_bef_R_uniform (0) ,
  N_aft_R_uniform (0) ,
  Nk_momentum_uniform (0) ,  
  Nk_momentum_GL (0)
{
  allocate_fill (X);
}



// Destructor for compiler  
// ------------------------

spherical_state::~spherical_state () {}

// Constants definition and tables allocation/allocation copy/deallocation
// -----------------------------------------------------------------------

void spherical_state::allocate (
				const bool is_it_relative_c ,
				const bool are_there_scaled_wfs_c , 
				const enum potential_type potential_c , 
				const int A_c , 
				const int Z_charge_c , 
				const double mass_modif , 
				const unsigned int N_bef_s_GL_c , 
				const unsigned int N_bef_R_GL_c , 
				const unsigned int N_aft_R_GL_c , 
				const unsigned int N_bef_R_uniform_c , 
				const unsigned int N_aft_R_uniform_c ,  
				const unsigned int Nk_momentum_GL_c , 
				const unsigned int Nk_momentum_uniform_c ,
				const double R_c , 
				const double s_radial_c , 
				const double R0_c , 
				const double R_real_max_c , 
				const double kmax_momentum_c , 
				const double R_Fermi_momentum_c , 
				const bool S_matrix_pole_c , 
				const enum particle_type particle_c , 
				const int n_c , 
				const double jr_c , 
				const int l_c , 
				const double j_c , 
				const bool automatic_starting_point , 
				const complex<double> &k_c , 
				const double effective_mass_for_calc , 
				const complex<double> &C0_c , 
				const complex<double> &Cplus_c)  

{  
  if (is_it_filled ()) error_message_print_abort ("spherical_state cannot be allocated twice in spherical_state::allocate");
  
  is_it_relative = is_it_relative_c;

  are_there_scaled_wfs = are_there_scaled_wfs_c; 

  n = n_c; 

  jr = jr_c; 

  l = l_c; 
  j = j_c; 

  particle = particle_c; 

  S_matrix_pole = S_matrix_pole_c; 

  potential = potential_c; 

  A = A_c; 

  Z_charge = Z_charge_c; 

  R = R_c; 

  s_radial = s_radial_c; 

  R0 = R0_c; 

  R_real_max = R_real_max_c; 

  kmax_momentum = kmax_momentum_c;
  
  R_Fermi_momentum = R_Fermi_momentum_c;
  
  N_bef_s_GL = N_bef_s_GL_c; 
  N_bef_R_GL = N_bef_R_GL_c; 
  N_aft_R_GL = N_aft_R_GL_c; 

  N_bef_R_uniform = N_bef_R_uniform_c; 
  N_aft_R_uniform = N_aft_R_uniform_c; 

  Nk_momentum_GL  = Nk_momentum_GL_c;
  Nk_momentum_uniform = Nk_momentum_uniform_c;
  
  k = k_c;
  
  C0 = C0_c; 

  Cplus = Cplus_c;
  
  if (N_bef_R_uniform <= 1) error_message_print_abort ("One must have N_bef_R_uniform >= 2 in spherical_state");
  
  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;
  
  matching_point = (S_matrix_pole && (potential != MODIFIED_PTG_POTENTIAL)) ? (R0) : (R);

  step_bef_R_uniform = R/static_cast<double> (N_bef_R_uniform_minus_one);
  
  step_aft_R_uniform = pow (R , -0.25)/static_cast<double> (N_aft_R_uniform - 1); 

  step_momentum_uniform = kmax_momentum/static_cast<double> (Nk_momentum_uniform - 1);
  
  N_matching_point = (S_matrix_pole) ? (make_uns_int (floor ((N_bef_R_uniform_minus_one)*R0/R))) : (N_bef_R_uniform_minus_one);

  is_k_OK = (S_matrix_pole) ? (!automatic_starting_point) : (true);

  const bool is_it_electron = (particle == ELECTRON);

  kinetic_factor = kinetic_factor_calc (is_it_electron  , mass_modif , effective_mass_for_calc); 
  
  eta = (k != 0.0) ? (eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k)) : (eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , precision));

  E = k*k/kinetic_factor;

  Cminus = (!S_matrix_pole) ? (Cplus) : (0.0); 

  CF = 0.0; 
  CG = 0.0; 

  wf_R0  = 0.0; 
  dwf_R0 = 0.0; 

  is_k_search_start_used = (S_matrix_pole) ? (!automatic_starting_point) : (false);

  k_search_start = (is_k_search_start_used) ? (k) : (NADA);

  is_it_cwf_standard_normalization = true;
  
  if (is_it_electron && (potential != DIPOLAR) && (potential != QUADRUPOLAR) && (potential != GAUSSIAN)) error_message_print_abort ("Dipolar, quadrupolar or Gaussian potential only for electron");

  isItRotor = ((potential == DIPOLAR) || (potential == QUADRUPOLAR) || (potential == DEFORMED_WS) || (potential == GAUSSIAN)) ? (true) : (false);

  if (C0 == 0.0)    C0 = 1.0;
  if (Cplus == 0.0) Cplus = 1.0;

  wf_bef_R_tab_uniform.allocate   (N_bef_R_uniform);
  dwf_bef_R_tab_uniform.allocate  (N_bef_R_uniform);
  d2wf_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  wf_bef_R_tab_uniform   = INFINITE;
  dwf_bef_R_tab_uniform  = INFINITE;
  d2wf_bef_R_tab_uniform = INFINITE;
  
  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform.allocate  (2 , 4 , N_aft_R_uniform);
      scaled_dwf_aft_R_tab_uniform.allocate (2 , 4 , N_aft_R_uniform);

      scaled_wf_aft_R_tab_uniform  = INFINITE;
      scaled_dwf_aft_R_tab_uniform = INFINITE;	
    }

  if (kmax_momentum > 0.0)
    {
      wf_momentum_tab_uniform.allocate  (Nk_momentum_uniform);
      dwf_momentum_tab_uniform.allocate (Nk_momentum_uniform);

      wf_momentum_tab_GL.allocate  (Nk_momentum_GL);
      dwf_momentum_tab_GL.allocate (Nk_momentum_GL);
    }
  
  wf_bef_R_tab_GL.allocate   (N_bef_R_GL);
  dwf_bef_R_tab_GL.allocate  (N_bef_R_GL);
  d2wf_bef_R_tab_GL.allocate (N_bef_R_GL);

  wf_bef_R_tab_GL   = INFINITE;
  dwf_bef_R_tab_GL  = INFINITE;
  d2wf_bef_R_tab_GL = INFINITE;

  if (is_it_electron)
    {
      wf_bef_s_tab_GL.allocate   (N_bef_s_GL);
      dwf_bef_s_tab_GL.allocate  (N_bef_s_GL);
      d2wf_bef_s_tab_GL.allocate (N_bef_s_GL);

      wf_bef_s_tab_GL   = INFINITE;
      dwf_bef_s_tab_GL  = INFINITE;
      d2wf_bef_s_tab_GL = INFINITE;
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      wf_bef_R_tab_GL_SGI_MSGI.allocate  (N_bef_R_GL); // This set goes from 0 to 2.R0.
      dwf_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL); // This set goes from 0 to 2.R0.

      wf_bef_R_tab_GL_SGI_MSGI  = INFINITE;
      dwf_bef_R_tab_GL_SGI_MSGI = INFINITE;

      r_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL); // This set goes from 0 to 2.R0.
      w_bef_R_tab_GL_SGI_MSGI.allocate (N_bef_R_GL); // This set goes from 0 to 2.R0.

      const double R_SGI_MSGI = 2.0 * R0;

      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_SGI_MSGI , r_bef_R_tab_GL_SGI_MSGI , w_bef_R_tab_GL_SGI_MSGI);
    }

  if (R_real_max > 0.0) 
    {
      wf_aft_R_tab_GL_real.allocate   (N_aft_R_GL); // This set goes from R to R_real_max.
      dwf_aft_R_tab_GL_real.allocate  (N_aft_R_GL); // This set goes from R to R_real_max.
      d2wf_aft_R_tab_GL_real.allocate (N_aft_R_GL); // This set goes from R to R_real_max.

      wf_aft_R_tab_GL_complex.allocate   (N_aft_R_GL); // This set goes from R to R + (R_real_max - R).exp(i theta).
      dwf_aft_R_tab_GL_complex.allocate  (N_aft_R_GL); // This set goes from R to R + (R_real_max - R).exp(i theta).
      d2wf_aft_R_tab_GL_complex.allocate (N_aft_R_GL); // This set goes from R to R + (R_real_max - R).exp(i theta).

      wf_aft_R_tab_GL_real   = INFINITE;
      dwf_aft_R_tab_GL_real  = INFINITE;
      d2wf_aft_R_tab_GL_real = INFINITE;

      wf_aft_R_tab_GL_complex   = INFINITE;
      dwf_aft_R_tab_GL_complex  = INFINITE;
      d2wf_aft_R_tab_GL_complex = INFINITE;
    }

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_GL.allocate  (2 , 4 , N_aft_R_GL);
      scaled_dwf_aft_R_tab_GL.allocate (2 , 4 , N_aft_R_GL);

      scaled_wf_aft_R_tab_GL  = INFINITE;
      scaled_dwf_aft_R_tab_GL = INFINITE;	
    }

  if (kmax_momentum > 0.0)
    {
      wf_momentum_tab_uniform  = INFINITE;
      dwf_momentum_tab_uniform = INFINITE;

      wf_momentum_tab_GL  = INFINITE;
      dwf_momentum_tab_GL = INFINITE;
    }
  
  r_bef_R_tab_uniform.allocate (N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) r_bef_R_tab_uniform(i) = i*step_bef_R_uniform;

  k_tab_uniform.allocate (Nk_momentum_uniform);

  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) k_tab_uniform(i) = i*step_momentum_uniform;
  
  r_bef_R_tab_GL.allocate (N_bef_R_GL);
  w_bef_R_tab_GL.allocate (N_bef_R_GL);

  if (kmax_momentum > 0.0)
    {
      k_tab_GL.allocate  (Nk_momentum_GL);
      wk_tab_GL.allocate (Nk_momentum_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , kmax_momentum , k_tab_GL , wk_tab_GL);
    }
  
  if (is_it_electron)
    {
      r_bef_s_tab_GL.allocate (N_bef_s_GL);
      w_bef_s_tab_GL.allocate (N_bef_s_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , s_radial , r_bef_s_tab_GL , w_bef_s_tab_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (s_radial , R , r_bef_R_tab_GL , w_bef_R_tab_GL);
    }
  else		
    Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_tab_GL , w_bef_R_tab_GL);

  if (R_real_max > 0.0) 
    {
      const complex<double> exp_Itheta(cos_theta_tab[0] , sin_theta_tab[0]);

      r_aft_R_tab_GL_real.allocate (N_aft_R_GL);
      w_aft_R_tab_GL_real.allocate (N_aft_R_GL);

      Gauss_Legendre::abscissas_weights_tables_calc (R , R_real_max , r_aft_R_tab_GL_real , w_aft_R_tab_GL_real);

      r_aft_R_tab_GL_complex.allocate (N_aft_R_GL);
      w_aft_R_tab_GL_complex.allocate (N_aft_R_GL);

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  r_aft_R_tab_GL_complex(i) = R + (r_aft_R_tab_GL_real(i) - R)*exp_Itheta;

	  w_aft_R_tab_GL_complex(i) = w_aft_R_tab_GL_real(i)*exp_Itheta;
	}
    }

  const double R_pow_minus_0p25 = pow (R , -0.25);

  class array<double> u_aft_R(N_aft_R_GL);

  class array<double> weights_aft_R(N_aft_R_GL);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_pow_minus_0p25 , u_aft_R , weights_aft_R);

  um4_aft_R_tab_GL.allocate (N_aft_R_GL);

  w_aft_R_tab_GL.allocate (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double u = u_aft_R(i);

      const double um4 = pow (u , -4);

      um4_aft_R_tab_GL(i) = um4;

      w_aft_R_tab_GL(i) = weights_aft_R(i)*um4/u;
    }
}









void spherical_state::allocate_fill (const class spherical_state &X)
{
  if (is_it_filled ()) error_message_print_abort ("spherical_state cannot be allocated twice in spherical_state::allocate_fill");

  is_it_relative = X.is_it_relative;

  are_there_scaled_wfs = X.are_there_scaled_wfs; 

  n = X.n; 

  jr = X.jr;  

  l = X.l; 

  j = X.j; 

  particle = X.particle; 

  S_matrix_pole = X.S_matrix_pole; 

  potential = X.potential; 

  A = X.A; 

  Z_charge = X.Z_charge; 

  R = X.R; 

  matching_point = X.matching_point; 

  s_radial = X.s_radial; 

  R0 = X.R0; 

  R_real_max = X.R_real_max; 

  kmax_momentum = X.kmax_momentum;
  
  step_bef_R_uniform = X.step_bef_R_uniform; 
  step_aft_R_uniform = X.step_aft_R_uniform; 

  step_momentum_uniform = X.step_momentum_uniform;
  
  N_matching_point = X.N_matching_point; 

  N_bef_s_GL = X.N_bef_s_GL; 
  N_bef_R_GL = X.N_bef_R_GL; 

  N_aft_R_GL = X.N_aft_R_GL; 

  N_bef_R_uniform = X.N_bef_R_uniform; 
  N_aft_R_uniform = X.N_aft_R_uniform; 

  Nk_momentum_GL  = X.Nk_momentum_GL;
  Nk_momentum_uniform = X.Nk_momentum_uniform;
  
  is_k_OK = X.is_k_OK; 

  kinetic_factor = X.kinetic_factor; 

  k = X.k; 

  eta = X.eta;

  E = X.E;

  C0 = X.C0; 

  Cplus = X.Cplus; 
  Cminus = X.Cminus; 

  CF = X.CF; 
  CG = X.CG; 

  wf_R0 = X.wf_R0; 
  dwf_R0 = X.dwf_R0; 

  is_k_search_start_used = X.is_k_search_start_used; 

  k_search_start = X.k_search_start; 

  // additional element
  isItRotor = X.isItRotor;
  is_it_cwf_standard_normalization = X.is_it_cwf_standard_normalization;
  
  wf_bef_R_tab_uniform.allocate_fill   (X.wf_bef_R_tab_uniform);
  dwf_bef_R_tab_uniform.allocate_fill  (X.dwf_bef_R_tab_uniform);
  d2wf_bef_R_tab_uniform.allocate_fill (X.d2wf_bef_R_tab_uniform);

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform.allocate_fill  (X.scaled_wf_aft_R_tab_uniform);
      scaled_dwf_aft_R_tab_uniform.allocate_fill (X.scaled_dwf_aft_R_tab_uniform);
    }

  if (kmax_momentum > 0.0)
    {
      wf_momentum_tab_uniform.allocate_fill (X.wf_momentum_tab_uniform);
      dwf_momentum_tab_uniform.allocate_fill (X.dwf_momentum_tab_uniform);

      wf_momentum_tab_GL.allocate_fill (X.wf_momentum_tab_GL);
      dwf_momentum_tab_GL.allocate_fill (X.dwf_momentum_tab_GL);
    }
  
  wf_bef_R_tab_GL.allocate_fill   (X.wf_bef_R_tab_GL);
  dwf_bef_R_tab_GL.allocate_fill  (X.dwf_bef_R_tab_GL);
  d2wf_bef_R_tab_GL.allocate_fill (X.d2wf_bef_R_tab_GL);

  if (particle == ELECTRON)
    {
      wf_bef_s_tab_GL.allocate_fill   (X.wf_bef_s_tab_GL);
      dwf_bef_s_tab_GL.allocate_fill  (X.dwf_bef_s_tab_GL);
      d2wf_bef_s_tab_GL.allocate_fill (X.d2wf_bef_s_tab_GL);
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      wf_bef_R_tab_GL_SGI_MSGI.allocate_fill  (X.wf_bef_R_tab_GL_SGI_MSGI);  // This set goes from 0 to 2.R0.
      dwf_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.dwf_bef_R_tab_GL_SGI_MSGI); // This set goes from 0 to 2.R0.

      r_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.r_bef_R_tab_GL_SGI_MSGI); // This set goes from 0 to 2.R0.
      w_bef_R_tab_GL_SGI_MSGI.allocate_fill (X.w_bef_R_tab_GL_SGI_MSGI); // This set goes from 0 to 2.R0.
    }

  if (R_real_max > 0.0) 
    {	
      wf_aft_R_tab_GL_real.allocate_fill   (X.wf_aft_R_tab_GL_real);   // This set goes from R to R_real_max.
      dwf_aft_R_tab_GL_real.allocate_fill  (X.dwf_aft_R_tab_GL_real);  // This set goes from R to R_real_max.
      d2wf_aft_R_tab_GL_real.allocate_fill (X.d2wf_aft_R_tab_GL_real); // This set goes from R to R_real_max.

      wf_aft_R_tab_GL_complex.allocate_fill   (X.wf_aft_R_tab_GL_complex);   // This set goes from R to R + (R_real_max - R).exp(i theta).
      dwf_aft_R_tab_GL_complex.allocate_fill  (X.dwf_aft_R_tab_GL_complex);  // This set goes from R to R + (R_real_max - R).exp(i theta).
      d2wf_aft_R_tab_GL_complex.allocate_fill (X.d2wf_aft_R_tab_GL_complex); // This set goes from R to R + (R_real_max - R).exp(i theta).
    }

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_GL.allocate_fill  (X.scaled_wf_aft_R_tab_GL);
      scaled_dwf_aft_R_tab_GL.allocate_fill (X.scaled_dwf_aft_R_tab_GL);
    }

  r_bef_R_tab_uniform.allocate_fill (X.r_bef_R_tab_uniform);

  k_tab_uniform.allocate_fill (X.k_tab_uniform);
  
  r_bef_R_tab_GL.allocate_fill (X.r_bef_R_tab_GL);
  w_bef_R_tab_GL.allocate_fill (X.w_bef_R_tab_GL);

  if (kmax_momentum > 0.0)
    {
      k_tab_GL.allocate_fill (X.k_tab_GL);
      wk_tab_GL.allocate_fill (X.wk_tab_GL);
    }

  if (particle == ELECTRON)
    {
      r_bef_s_tab_GL.allocate_fill (X.r_bef_s_tab_GL);
      w_bef_s_tab_GL.allocate_fill (X.w_bef_s_tab_GL);
    }

  if (R_real_max > 0.0) 
    {
      r_aft_R_tab_GL_real.allocate_fill (X.r_aft_R_tab_GL_real);
      w_aft_R_tab_GL_real.allocate_fill (X.w_aft_R_tab_GL_real);

      r_aft_R_tab_GL_complex.allocate_fill (X.r_aft_R_tab_GL_complex);
      w_aft_R_tab_GL_complex.allocate_fill (X.w_aft_R_tab_GL_complex);
    }

  um4_aft_R_tab_GL.allocate_fill (X.um4_aft_R_tab_GL);
  
  w_aft_R_tab_GL.allocate_fill (X.w_aft_R_tab_GL);
}









void spherical_state::deallocate ()
{
  wf_bef_R_tab_uniform.deallocate ();
  dwf_bef_R_tab_uniform.deallocate ();
  d2wf_bef_R_tab_uniform.deallocate ();

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform.deallocate ();
      scaled_dwf_aft_R_tab_uniform.deallocate ();
    }

  wf_bef_R_tab_GL.deallocate ();
  dwf_bef_R_tab_GL.deallocate ();
  d2wf_bef_R_tab_GL.deallocate ();

  if (particle == ELECTRON)
    {
      wf_bef_s_tab_GL.deallocate ();
      dwf_bef_s_tab_GL.deallocate ();
      d2wf_bef_s_tab_GL.deallocate ();
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      wf_bef_R_tab_GL_SGI_MSGI.deallocate ();
      dwf_bef_R_tab_GL_SGI_MSGI.deallocate ();

      r_bef_R_tab_GL_SGI_MSGI.deallocate ();
      w_bef_R_tab_GL_SGI_MSGI.deallocate ();
    }

  if (R_real_max > 0.0) 
    {	
      wf_aft_R_tab_GL_real.deallocate ();
      dwf_aft_R_tab_GL_real.deallocate ();
      d2wf_aft_R_tab_GL_real.deallocate ();

      wf_aft_R_tab_GL_complex.deallocate ();
      dwf_aft_R_tab_GL_complex.deallocate ();
      d2wf_aft_R_tab_GL_complex.deallocate ();
    }

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_GL.deallocate ();
      scaled_dwf_aft_R_tab_GL.deallocate ();
    }

  if (kmax_momentum > 0.0)
    {
      wf_momentum_tab_uniform.deallocate ();
      dwf_momentum_tab_uniform.deallocate ();

      wf_momentum_tab_GL.deallocate ();
      dwf_momentum_tab_GL.deallocate ();
    }
  
  r_bef_R_tab_uniform.deallocate ();

  k_tab_uniform.deallocate ();
  
  r_bef_R_tab_GL.deallocate ();
  w_bef_R_tab_GL.deallocate ();

  k_tab_GL.deallocate ();
  wk_tab_GL.deallocate ();
  
  if (particle == ELECTRON)
    {
      r_bef_s_tab_GL.deallocate ();
      w_bef_s_tab_GL.deallocate ();
    }

  if (R_real_max > 0.0) 
    {
      r_aft_R_tab_GL_real.deallocate ();
      w_aft_R_tab_GL_real.deallocate ();

      r_aft_R_tab_GL_complex.deallocate ();
      w_aft_R_tab_GL_complex.deallocate ();
    }

  um4_aft_R_tab_GL.deallocate ();

  w_aft_R_tab_GL.deallocate ();

  is_k_OK = false;

  kinetic_factor = 0.0;

  k = 0.0;

  eta = 0.0;

  E = 0.0;

  C0 = 0.0;

  Cplus = 0.0;
  Cminus = 0.0;

  CF = 0.0;
  CG = 0.0;

  wf_R0 = 0.0;
  dwf_R0 = 0.0;

  is_k_search_start_used = false;

  k_search_start = 0.0;

  is_it_relative = false;

  are_there_scaled_wfs = false;

  n = 0;
  jr = 0;

  l = 0;
  j = 0;

  particle = NO_PARTICLE;

  S_matrix_pole = false;

  potential = NO_POTENTIAL;

  A = 0;

  Z_charge = 0;

  R = 0.0;

  matching_point = 0.0;

  s_radial = 0.0;

  R0 = 0.0;

  R_real_max = 0.0;

  kmax_momentum = 0.0;
  
  R_Fermi_momentum = 0.0;
  
  step_bef_R_uniform = 0.0;
  step_aft_R_uniform = 0.0;

  step_momentum_uniform = 0.0;
  
  N_matching_point = 0;

  N_bef_s_GL = 0;
  N_bef_R_GL = 0;

  N_aft_R_GL = 0;

  N_bef_R_uniform = 0;
  N_aft_R_uniform = 0;

  is_it_cwf_standard_normalization = false;
}




// Wave function identically equal to zero
// ---------------------------------------

void spherical_state::zero ()
{
  wf_R0  = 0.0;
  dwf_R0 = 0.0;

  C0 = 0.0;

  Cplus  = 0.0;
  Cminus = 0.0;

  CF = 0.0;
  CG = 0.0;

  wf_bef_R_tab_uniform   = 0.0;
  dwf_bef_R_tab_uniform  = 0.0;
  d2wf_bef_R_tab_uniform = 0.0;

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform  = 0.0;
      scaled_dwf_aft_R_tab_uniform = 0.0;

      scaled_wf_aft_R_tab_GL  = 0.0;
      scaled_dwf_aft_R_tab_GL = 0.0;		
    }

  wf_bef_R_tab_GL   = 0.0;
  dwf_bef_R_tab_GL  = 0.0;
  d2wf_bef_R_tab_GL = 0.0;

  if (particle == ELECTRON)
    {
      wf_bef_s_tab_GL   = 0.0;
      dwf_bef_s_tab_GL  = 0.0;
      d2wf_bef_s_tab_GL = 0.0;
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      wf_bef_R_tab_GL_SGI_MSGI  = 0.0;
      dwf_bef_R_tab_GL_SGI_MSGI = 0.0;
    }

  if (R_real_max > 0.0) 
    {
      wf_aft_R_tab_GL_real   = 0.0;
      dwf_aft_R_tab_GL_real  = 0.0;
      d2wf_aft_R_tab_GL_real = 0.0;
      
      wf_aft_R_tab_GL_complex   = 0.0;
      dwf_aft_R_tab_GL_complex  = 0.0;
      d2wf_aft_R_tab_GL_complex = 0.0;
    }
  
  if (kmax_momentum > 0.0)
    {  
      wf_momentum_tab_uniform  = 0.0;
      dwf_momentum_tab_uniform = 0.0;
      
      wf_momentum_tab_GL  = 0.0;
      dwf_momentum_tab_GL = 0.0;
    }
}











// Search of the S matrix poles
// ----------------------------
// First , one looks for a good starting point for k (see k_guess function).
// If , after that , is_k_OK is false , k is too large to be found and then it is meaningless to look for it.
// n is taken into account in k_guess.
// From this starting point , the complex Newton-Raphson method is used to find the zero of the Jost function.
// If |Re[k]|oo < precision , one looks for a bound state , so Re[k] is put to 0.
// If |J(k)|oo > 1E-3 at the end of the search , it means one found nothing and k is put to zero.
// If k has been found , one calculates eta and one prints results of the search.
// Antibound states are considered only close to E=0 with bisection.
//
// Variables
// ---------
// count : number of current Newton iterations. If count >= 50 , the process stops.
// test : test to know if the Newton method has converged : it is min (inf_norm (k_bef/k - 1.0) , J(k)) and initialized at INFINITY.
// k_bef : k of the last iteration. Initialized at k_guess.(1+sqrt_precision).
// Jost_k_bef : Jost (k_bef).
// Jost_k : Jost (k)
// Jost_k_der : approximate derivative of the Jost function. 
//           It is (Jost_k_bef - Jost_k)/(k_bef - k) if k_bef and k are not too close (when test > 1E-5).
//           It is kept constant when k_bef and k become too close (when test <= 1E-5).

void spherical_state::k_search (
				class potentials_effective_mass &T ,
				const bool all_states ,
				const bool print_statement)
{
  
  if (potential == QBOX_POTENTIAL) error_message_print_abort ("No Qbox potential in spherical_state::k_search");

  if (S_matrix_pole && (matching_point > R)) error_message_print_abort ("One must have R0 <= R in spherical_state for poles in spherical_state::k_search");

  const bool no_barrier = (is_it_PTG_like_determine (potential) || ((l == 0) && ((particle_charge_determine (particle) == 0) || (Z_charge == 0))));

  if (no_barrier && !is_k_search_start_used && (potential == MODIFIED_PTG_POTENTIAL))
    {
      k = k_PTG_guess (T , NADA);

      eta = 0.0;

      E = k*k/kinetic_factor;

      is_k_OK = true;

      return;
    }
   
  if (is_k_search_start_used)
    {
      k = k_search_start;      

      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

      E = k_search_start*k_search_start/kinetic_factor;
      
      is_k_OK = true;

      if (k == 0.0)
	{
	  is_k_OK = false;
	  
	  return;
	}
    }
  // HO guess in general. It can be a guess from a two-dimensional bisection on k for broad resonance states.
  else
    {
      if (!is_k_OK || (real (k) > 0.0)) k_guess (T , all_states);
        
      if (!is_k_OK) return;
      
      if (k == 0.0)
	{
	  if ((THIS_PROCESS == MASTER_PROCESS) && print_statement)
	    {
	      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , 0.0 , INFINITE , NADA);
	  
	      const complex<double> Jost_k_is_zero = Jost (T , particle , R , matching_point , C0 , Cplus);
	      
#ifdef UseOpenMP
#pragma omp critical
#endif
	      cout << particle << " k:0 fm^(-1) |Jost(k)|oo:" << inf_norm (Jost_k_is_zero) << endl;
	    }
	  
	  return;
	}
    }
  
  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k , eta , NADA);
  
  complex<double> Jost_k = Jost (T , particle , R , matching_point , C0 , Cplus);  
  
  if (!finite (Jost_k))
    {
      is_k_OK = false;

      return;
    }

  is_k_OK = true;

  if (inf_norm (Jost_k) > precision)
    {
      complex<double> k_bef = k*(1.0 + sqrt_precision);

      complex<double> eta_bef = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_bef);

      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_bef , eta_bef , NADA);
  
      complex<double> Jost_k_bef = Jost (T , particle , R , matching_point , C0 , Cplus);

      complex<double> Jost_k_der = (Jost_k_bef - Jost_k)/(k_bef - k);
  
      int count = 0;

      double test = INFINITE;

      while (count++ < 50)
	{	  
	  if (inf_norm (k) > 10.0) // arbitrary
	    {
	      //cout << "spherical_state::k_search: |k| too uniform" << endl;
	      is_k_OK = false;
	      return;
	    }

	  // insures that diverging states are not calculated in vain
	  if (inf_norm (Jost_k) > 1000) // arbitrary
	    {
	      is_k_OK = false;
	      return;
	    }

	  //#ifdef UseOpenMP
	  //#pragma omp critical
	  //#endif
	  //if (THIS_PROCESS == MASTER_PROCESS) cout << *this << " " << particle << " k:" << k << " Jost(k):" << Jost_k << endl;  
	  //if (THIS_PROCESS == MASTER_PROCESS) cout << *this << " " << particle << " E:" << k*k/kinetic_factor << " Jost(k):" << Jost_k << endl;
     
	  k_bef = k;

	  eta_bef = eta;

	  k -= Jost_k/Jost_k_der;

	  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

	  E = k*k/kinetic_factor;

	  if (abs (real (k)) < sqrt_precision)
	    {
	      k = complex<double> (0 , imag (k));
	  
	      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
	  
	      E = k*k/kinetic_factor;
	    }
       
	  test = min (inf_norm (k_bef/k - 1.0) , inf_norm (Jost_k));
      
	  if (test < precision) break;

	  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k , eta , NADA);

	  Jost_k = Jost (T , particle , R , matching_point , C0 , Cplus);

	  if (inf_norm (Jost_k) > sqrt_precision) Jost_k_der = (Jost_k_bef - Jost_k)/(k_bef - k);

	  Jost_k_bef = Jost_k;
	}
    }
  
  // ensure that only well converged states are kept: value of 1E-3 arbitrary
  // The value of k is nevertheless kept if potential is HF or MSDHF, as an imprecision here typically wanes out during the self-consistent process
  if ((potential != HF) && (potential != MSDHF) && (inf_norm (Jost_k) > 1.0e-3)) is_k_OK = false;

  if ((THIS_PROCESS == MASTER_PROCESS) && print_statement)
    {
      cout.precision (15);

      const double real_E = real (E);
      
      const double Gamma = -2000.0*imag (E);

#ifdef UseOpenMP
#pragma omp critical
#endif
      {
	// GSM calculations
	if ((particle != ELECTRON) && (!isItRotor))
	  cout << particle <<  " " << *this << "   k:" << k << " fm^(-1)   E:" << real_E << " MeV   G:" << Gamma << " keV   |Jost(k)|oo:" << inf_norm (Jost_k) << endl;
	// code_rotor_CC calculations
	else if (isItRotor)
	  {
	    // dipolar and quadrupolar and Gaussian anions
	    if (particle == ELECTRON)
	      cout << "k_search:   n:" << n << " l:" << l << " jr:" << jr
		   <<" k:" << k << " a0^(-1)   E:" << real_E << " Ry   G:" << -2.0*imag (E) << " Ry   |Jost(k)|oo:"<< inf_norm (Jost_k) << endl;
	    // nuclei
	    else
	      cout << "k_search:   n: " << n << " (jr:" << jr << ")" << angular_state (l , j)
		   << " k:" << k << " fm^(-1)   E:" << real_E << " MeV   G:" << -2.0*imag (E) << " MeV   |Jost(k)|oo:"<< inf_norm (Jost_k) << endl;
	  }
	else 
	  error_message_print_abort ("spherical_states::k_search: display not defined for this situation.");
      }
    }

  //if (inf_norm (Jost_k) > sqrt_precision) {is_k_OK = false; return;}
}


void spherical_state::set_is_k_search_start_used (const bool is_k_search_start_used_)
{
  is_k_search_start_used = is_k_search_start_used_;
}


void spherical_state::set_k_search_start (const complex<double> &k_search_start_)
{
  k_search_start = k_search_start_;
}









// Calculation of the norm of a Gamow state or scattering state : 
// --------------------------------------------------------------
//
// Pole state:
// -----------
// One calculates the squared norm Reg[\int_0^{+oo} wf(r)^2 dr] with the complex scaling.
// One returns : Sqrt[Reg[\int_0^{+oo} wf(r)^2 dr]].sign[Re[sqrt[norm^2]]] if Re[k] = 0 and Im[k] >= 0 (bound states) , 
//               Sqrt[Reg[\int_0^{+oo} wf(r)^2 dr]].sign[Re[sqrt[norm^2]]].sign[Re[k]] if Re[k] != 0 (resonant and antiresonant states) , 
//               -Sqrt[Reg[\int_0^{+oo} wf(r)^2 dr]].sign[Im[sqrt[norm^2]]] if Re[k] = 0 and Im[k] < 0 (antibound states).
//
// Scattering state :
//-------------------
// With u(r > R) = C+.h+[k.r]+C-.h-[k.r] , not normed , the squared norm is 2.Pi.C+.C-.
// The normed state must verify C+.C- = 1/(2.Pi).
// It is equivalent to the dirac delta normalization.
// One returns : Sqrt[2.Pi.C+.C-].sign[Re[sqrt[norm^2]]].sign[Re[k]] if Re[k] != 0
//               -Sqrt[Reg[\int_0^{+oo} wf(r)^2 dr]].sign[Im[norm]] if Re[k] = 0
// All scattering states must have Im[k] <= 0.
//
// Variables
// ---------
// wf_norm_no_phase : sqrt [\int u^2(r) dr].
// square_wf_norm_bef_R : \int u^2(r) dr on [0:R]
// exp_Itheta , angle_index : exp(I.theta) , with theta the best angle of rotation given by optimal_angle_index. 
// F_aft : wf(r)^2 on [R:+oo[ with the complex scaling 
// square_wf_norm_aft_R : \int u^2(r) dr on [R:+oo[ with the complex scaling
// sc_wf : scaled wave function on [R:+oo[ with the complex scaling
// unscale , unscale_corr : exp[2i(k.z - eta.log[2.k.z])] , the same value or 0 if it is not finite. 
// two_I , kz : 2.i , k.z
// is_it_real_bound_state_cwf_standard_normalization_case : true if one has a bound state in a real potential and Coulomb wave functions with their standard normalization , false if not
// kinetic_factor: 2mu/hbar^2.
// two_sqrt_Vc, two_I_sqrt_Vc : 2 sqrt[Vc.Z] with Vc = kinetic_factor.Z_charge.Coulomb_constant, i times two_sqrt_Vc.
// norm_k_is_zero : exp[i l_term Pi/2]
// cwf_zero_k, l_term : class Coulomb_wave_functions with l_term = 2.l + 1/2 and eta = 0.

complex<double> spherical_state::Gamow_norm () const			
{
  if (!S_matrix_pole)
    {      
      const complex<double> wf_norm_no_phase = sqrt (2.0*M_PI*Cplus*Cminus);

      if (!finite (wf_norm_no_phase)) return 1.0;

      return (real (k) != 0) ? (wf_norm_no_phase*SIGN (real (wf_norm_no_phase))*SIGN (real (k))) : (-wf_norm_no_phase*SIGN (imag (wf_norm_no_phase)));
    }
  else
    {
      const bool is_it_real_bound_state_cwf_standard_normalization_case = (is_it_cwf_standard_normalization && is_it_real ());

      complex<double> wf_norm2_bef_R = 0.0;
      complex<double> wf_norm2_mid = 0.0;
      complex<double> wf_norm2_aft_R_rot = 0.0;

      complex<double> wf_r = 0.0;

      complex<double> dummy = 0.0;

      if (particle == ELECTRON)
	{
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    wf_norm2_bef_R += wf_bef_s_tab_GL(i)*wf_bef_s_tab_GL(i)*w_bef_s_tab_GL(i); 
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_norm2_bef_R += wf_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*w_bef_R_tab_GL(i);

      const unsigned int angle_index = optimal_angle_index (2.0*k);

      const unsigned int N_mid_tab_GL = N_bef_R_GL;

      const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

      const double two_Rt = (!is_it_PTG_like_determine (potential) && (abs (real (k)) > precision)) ? (2.0*(abs (eta/k) + sqrt (abs (l*(l + 1)/k) + abs (eta*eta/k)))) : (R);

      const double R_rot = (two_Rt > R + 10) ? (two_Rt) : (R);

      const complex<double> eta_k_non_zero = (k != 0.0) ? (eta) : (NADA);
      
      class Coulomb_wave_functions cwf(is_it_cwf_standard_normalization , l , eta_k_non_zero);

      if (R_rot > R)
	{
	  const double R_rot_pow_minus_0p25 = pow (R_rot , -0.25);
	  
	  class array<double> r_mid_tab_GL(N_mid_tab_GL);
	  class array<double> weights_mid_tab_GL(N_mid_tab_GL);

	  class array<double> u_aft_R_rot(N_aft_R_GL);
	  class array<double> weights_aft_R_rot(N_aft_R_GL);
	  
	  Gauss_Legendre::abscissas_weights_tables_calc (R , R_rot , r_mid_tab_GL , weights_mid_tab_GL);
	  
	  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_rot_pow_minus_0p25 , u_aft_R_rot , weights_aft_R_rot);

	  for (unsigned int i = 0 ; i < N_mid_tab_GL ; i++) 
	    {
	      if (is_it_real_bound_state_cwf_standard_normalization_case)
		cwf.Wm_kz_dWm_kz (k , r_mid_tab_GL(i) , wf_r , dummy);
	      else
		cwf.H_kz_dH_kz (1 , k , r_mid_tab_GL(i) , wf_r , dummy);
	      
	      wf_r *= Cplus;

	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_norm2_mid += wf_r*wf_r*weights_mid_tab_GL(i);
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double um4 = pow (u_aft_R_rot(i) , -4);

	      const complex<double> z = R_rot + (um4 - R_rot)*exp_Itheta;
	      
	      if (is_it_real_bound_state_cwf_standard_normalization_case)
		cwf.Wm_kz_dWm_kz (k , z , wf_r , dummy);
	      else
		cwf.H_kz_dH_kz (1 , k , z , wf_r , dummy);
	      
	      wf_r *= Cplus;

	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_norm2_aft_R_rot += wf_r*wf_r*weights_aft_R_rot(i)*um4/u_aft_R_rot(i);
	    }

	  wf_norm2_aft_R_rot *= 4.0*exp_Itheta;
	}
      else
	{
	  const int particle_charge = particle_charge_determine (particle);
      
	  const int Z_charge_times_particle_charge = Z_charge*particle_charge;
      
	  const double l_term = 2.0*l + 0.5;

	  const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);

	  const complex<double> Il_term(0 , l_term);

	  const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

	  const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

	  const complex<double> Ik(-imag (k) , real (k));

	  class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const complex<double> z = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;

	      if (k == 0.0)
		wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k , z , wf_r , dummy);
	      else if (is_it_PTG_like_determine (potential))
		wf_r = exp (Ik*z);
	      else
		{
		  if (is_it_real_bound_state_cwf_standard_normalization_case)
		    cwf.Wm_kz_dWm_kz (k , z , wf_r , dummy);
		  else
		    cwf.H_kz_dH_kz (1 , k , z , wf_r , dummy);
		}
	      
	      wf_r *= Cplus;
	      
	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_norm2_aft_R_rot += wf_r*wf_r*w_aft_R_tab_GL(i);
	    }

	  wf_norm2_aft_R_rot *= 4.0*exp_Itheta;
	}

      const complex<double> wf_norm_no_phase = sqrt (wf_norm2_bef_R + wf_norm2_mid + wf_norm2_aft_R_rot);

      if ((real (k) == 0.0) && (imag (k) >= 0.0))
	return real (wf_norm_no_phase)*SIGN (real (wf_norm_no_phase));
      else if ((real (k) > 0.0) && (imag (k) == 0.0))
	return real (wf_norm_no_phase)*SIGN (real (wf_norm_no_phase));
      else if (real (k) != 0.0)
	return wf_norm_no_phase*SIGN (real (wf_norm_no_phase))*SIGN (real (k));
      else
	return wf_norm_no_phase*SIGN (imag (wf_norm_no_phase));
    }
}



// Rms radius of a resonant state
// ------------------------------
// It is sqrt (\int u(r)^2 r^2) calculated with complex scaling.

complex<double> spherical_state::rms_radius_calc () const			
{
  if (S_matrix_pole)
    {      
      const bool is_it_real_bound_state_cwf_standard_normalization_case = (is_it_cwf_standard_normalization && is_it_real ());

      complex<double> wf_squared_rms_radius_bef_R = 0.0;
      complex<double> wf_squared_rms_radius_mid = 0.0;
      complex<double> wf_squared_rms_radius_aft_R_rot = 0.0;

      complex<double> wf_r = 0.0;

      complex<double> dummy = 0.0;

      if (particle == ELECTRON)
	{
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    wf_squared_rms_radius_bef_R += r_bef_s_tab_GL(i)*r_bef_s_tab_GL(i)*wf_bef_s_tab_GL(i)*wf_bef_s_tab_GL(i)*w_bef_s_tab_GL(i); 
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_squared_rms_radius_bef_R += r_bef_R_tab_GL(i)*r_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*wf_bef_R_tab_GL(i)*w_bef_R_tab_GL(i);

      const unsigned int angle_index = optimal_angle_index (2.0*k);

      const unsigned int N_mid_tab_GL = N_bef_R_GL;

      const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

      const double two_Rt = (!is_it_PTG_like_determine (potential) && (abs (real (k)) > precision)) ? (2.0*(abs (eta/k) + sqrt (abs (l*(l + 1)/k) + abs (eta*eta/k)))) : (R);

      const double R_rot = (two_Rt > R + 10) ? (two_Rt) : (R);

      const complex<double> eta_k_non_zero = (k != 0.0) ? (eta) : (NADA);
      
      class Coulomb_wave_functions cwf(is_it_cwf_standard_normalization , l , eta_k_non_zero);

      if (R_rot > R)
	{
	  const double R_rot_pow_minus_0p25 = pow (R_rot , -0.25);
	  
	  class array<double> r_mid_tab_GL(N_mid_tab_GL);
	  class array<double> weights_mid_tab_GL(N_mid_tab_GL);

	  class array<double> u_aft_R_rot(N_aft_R_GL);
	  class array<double> weights_aft_R_rot(N_aft_R_GL);
	  
	  Gauss_Legendre::abscissas_weights_tables_calc (R , R_rot , r_mid_tab_GL , weights_mid_tab_GL);
	  
	  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_rot_pow_minus_0p25 , u_aft_R_rot , weights_aft_R_rot);

	  for (unsigned int i = 0 ; i < N_mid_tab_GL ; i++) 
	    {
	      const double r = r_mid_tab_GL(i);
	      
	      if (is_it_real_bound_state_cwf_standard_normalization_case)
		cwf.Wm_kz_dWm_kz (k , r , wf_r , dummy);
	      else
		cwf.H_kz_dH_kz (1 , k , r , wf_r , dummy);
	      
	      wf_r *= Cplus;

	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_squared_rms_radius_mid += r*r*wf_r*wf_r*weights_mid_tab_GL(i);
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double um4 = pow (u_aft_R_rot(i) , -4);

	      const complex<double> z = R_rot + (um4 - R_rot)*exp_Itheta;
	      
	      if (is_it_real_bound_state_cwf_standard_normalization_case)
		cwf.Wm_kz_dWm_kz (k , z , wf_r , dummy);
	      else
		cwf.H_kz_dH_kz (1 , k , z , wf_r , dummy);
	      
	      wf_r *= Cplus;

	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_squared_rms_radius_aft_R_rot += z*z*wf_r*wf_r*weights_aft_R_rot(i)*um4/u_aft_R_rot(i);
	    }

	  wf_squared_rms_radius_aft_R_rot *= 4.0*exp_Itheta;
	}
      else
	{
	  const int particle_charge = particle_charge_determine (particle);
      
	  const int Z_charge_times_particle_charge = Z_charge*particle_charge;
      
	  const double l_term = 2.0*l + 0.5;

	  const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);

	  const complex<double> Il_term(0 , l_term);

	  const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

	  const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

	  const complex<double> Ik(-imag (k) , real (k));

	  class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const complex<double> z = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;

	      if (k == 0.0)
		wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k , z , wf_r , dummy);
	      else if (is_it_PTG_like_determine (potential))
		wf_r = exp (Ik*z);
	      else
		{
		  if (is_it_real_bound_state_cwf_standard_normalization_case)
		    cwf.Wm_kz_dWm_kz (k , z , wf_r , dummy);
		  else
		    cwf.H_kz_dH_kz (1 , k , z , wf_r , dummy);
		}
	      
	      wf_r *= Cplus;
	      
	      if (!finite (wf_r)) wf_r = 0.0;
	      
	      wf_squared_rms_radius_aft_R_rot += z*z*wf_r*wf_r*w_aft_R_tab_GL(i);
	    }

	  wf_squared_rms_radius_aft_R_rot *= 4.0*exp_Itheta;
	}

      const complex<double> rms_radius = sqrt (wf_squared_rms_radius_bef_R + wf_squared_rms_radius_mid + wf_squared_rms_radius_aft_R_rot);

      return rms_radius;
    }
  else
    {
      error_message_print_abort ("Rms radius is not defined for scattering states");

      return NADA;
    }
}




// Normalization of the wave function : factor = 1.0/Gamow norm or sqrt(Delta_k).
// ------------------------------------------------------------------------------

void spherical_state::normalization (const complex<double> &factor)
{
  wf_bef_R_tab_uniform   *= factor;
  dwf_bef_R_tab_uniform  *= factor;
  d2wf_bef_R_tab_uniform *= factor;

  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform  *= factor;
      scaled_dwf_aft_R_tab_uniform *= factor;

      scaled_wf_aft_R_tab_GL  *= factor;
      scaled_dwf_aft_R_tab_GL *= factor;	
    }

  wf_bef_R_tab_GL   *= factor;
  dwf_bef_R_tab_GL  *= factor;
  d2wf_bef_R_tab_GL *= factor;

  if (particle == ELECTRON)
    {
      wf_bef_s_tab_GL   *= factor;
      dwf_bef_s_tab_GL  *= factor;
      d2wf_bef_s_tab_GL *= factor;
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      wf_bef_R_tab_GL_SGI_MSGI  *= factor;
      dwf_bef_R_tab_GL_SGI_MSGI *= factor;
    }

  if (R_real_max > 0.0) 
    {
      wf_aft_R_tab_GL_real   *= factor;
      dwf_aft_R_tab_GL_real  *= factor;
      d2wf_aft_R_tab_GL_real *= factor;

      wf_aft_R_tab_GL_complex   *= factor;
      dwf_aft_R_tab_GL_complex  *= factor;
      d2wf_aft_R_tab_GL_complex *= factor;
    }

  if (kmax_momentum > 0.0)
    {
      wf_momentum_tab_uniform  *= factor;
      dwf_momentum_tab_uniform *= factor;

      wf_momentum_tab_GL  *= factor;
      dwf_momentum_tab_GL *= factor;
    }
  
  C0 *= factor;
  
  Cplus *= factor;
  Cminus *= factor;

  CF *= factor;
  CG *= factor;

  wf_R0  *= factor;
  dwf_R0 *= factor;
}





// Checks if the wave function is real
// -----------------------------------
// is_it_real_bound_state_case : true if one has a bound state with a real potential , false if not
// is_it_real_scat_case : true if one has a real scattering state (k real and potential real) , false if not	

bool spherical_state::is_it_real () const
{
  if ((potential == COMPLEX_WS) || (potential == COMPLEX_WS_ANALYTIC) || (potential == COMPLEX_INTERPOLATED_POTENTIAL)) return false;

  const bool is_it_real_bound_state_case = (S_matrix_pole && (real (k) == 0.0) && (imag (k) >= 0.0));

  const bool is_it_real_scat_case = (!S_matrix_pole && (imag (k) == 0.0));

  const bool is_it_real = (is_it_real_bound_state_case || is_it_real_scat_case);

  return is_it_real;
}



// Remove the imaginary parts in case the wave function is real for its components which are theoretically real.

void spherical_state::make_it_real ()
{
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      wf_bef_R_tab_uniform  (i) = real (wf_bef_R_tab_uniform(i));
      dwf_bef_R_tab_uniform (i) = real (dwf_bef_R_tab_uniform(i));
      d2wf_bef_R_tab_uniform(i) = real (d2wf_bef_R_tab_uniform(i));
    }
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      wf_bef_R_tab_GL  (i) = real (wf_bef_R_tab_GL(i));
      dwf_bef_R_tab_GL (i) = real (dwf_bef_R_tab_GL(i));
      d2wf_bef_R_tab_GL(i) = real (d2wf_bef_R_tab_GL(i));
    }

  if (particle == ELECTRON)
    {
      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  wf_bef_s_tab_GL  (i) = real (wf_bef_s_tab_GL(i));
	  dwf_bef_s_tab_GL (i) = real (dwf_bef_s_tab_GL(i));
	  d2wf_bef_s_tab_GL(i) = real (d2wf_bef_s_tab_GL(i));
	}
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL_SGI_MSGI (i) = real (wf_bef_R_tab_GL_SGI_MSGI(i));
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = real (dwf_bef_R_tab_GL_SGI_MSGI(i));
	}
    }

  if (R_real_max > 0.0) 
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  wf_aft_R_tab_GL_real  (i) = real (wf_aft_R_tab_GL_real(i));
	  dwf_aft_R_tab_GL_real (i) = real (dwf_aft_R_tab_GL_real(i));
	  d2wf_aft_R_tab_GL_real(i) = real (d2wf_aft_R_tab_GL_real(i));
	}
    }

  if (kmax_momentum > 0.0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  wf_momentum_tab_uniform (i) = real (wf_momentum_tab_uniform (i));
	  dwf_momentum_tab_uniform(i) = real (dwf_momentum_tab_uniform(i));
	}
  
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  wf_momentum_tab_GL (i) = real (wf_momentum_tab_GL (i));
	  dwf_momentum_tab_GL(i) = real (dwf_momentum_tab_GL(i));
	}
    }
  
  C0 = real (C0);
  CG = real (CG);

  if (S_matrix_pole)
    {
      Cplus = real (Cplus);
      
      CF = complex<double> (0.0 , imag (CF));
    }
  else
    CF = real (CF);
}



// Normalization of the wave function after the matching point before R so that it is continuous therein from 0 to R.

void spherical_state::normalization_before_R_after_matching_point (const complex<double> &Cplus_ratio)
{
  if (!S_matrix_pole || (potential == MODIFIED_PTG_POTENTIAL)) error_message_print_abort ("Normalization of the wave function after the matching point before R for poles only and no modified PTG potential");

  const unsigned int N_matching_point_plus_one = N_matching_point + 1;

  for (unsigned int i = N_matching_point_plus_one ; i < N_bef_R_uniform ; i++)
    {
      wf_bef_R_tab_uniform(i)  *= Cplus_ratio;
      dwf_bef_R_tab_uniform(i) *= Cplus_ratio;
    }
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      if (r_bef_R_tab_GL(i) > matching_point)
	{
	  wf_bef_R_tab_GL(i)  *= Cplus_ratio;
	  dwf_bef_R_tab_GL(i) *= Cplus_ratio;
	}
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  if (r_bef_R_tab_GL_SGI_MSGI(i) > matching_point)
	    {
	      wf_bef_R_tab_GL_SGI_MSGI(i)  *= Cplus_ratio;
	      dwf_bef_R_tab_GL_SGI_MSGI(i) *= Cplus_ratio;
	    }
	}
    }
}



// Calculation of the normalized wave function
// -------------------------------------------
// If one has a unbound proton state with arg(k) < -Pi/4, 
// it cannot be calculated for integration with the complex scaling because of the branch cut of the Coulomb wave function.
// is_k_OK is then put to false in this case and a HO wave function is returned instead.
// The coefficients A and B in u[r >= R] = A.h+[k.r] + B.h-[k.r] must also be determined. 
// There are 3 parts to calculate :
// _ u[r] for r <= R : integration without complex scaling.
//   The initial conditions are : wf(r) = C0.r^(l + 1) near 0 (see forward_integration_before_R).
//   Then ones does a forward integration until matching_point, or R for scattering states.
//   One integrates backwards from R to matching_point with the initial condition u[R] = C+[bef].H+[k.R] for pole states.
//   One then calculates the C+, C-, CF and CG constants in Cplus_Cminus_CF_CG_calc with these two tables.
//   One then matches the two parts of the wave function renormalizing thew second part of the wave function with C+ for pole states. 
//
// Then one unscales the wave function if there is an effective mass (see unscale_wave_function).
//
// Momentum wave functions are calculated in wave_calculation_momentum using an HO expansion of the radial wave function.
// Radial wave functions are then needed and b[HO] must be provided therein. 
//
// Momentum wave functions are always calculated in wave_calculation_HO_diag, HO_wave_function, wave_calculation_THO_diag, THO_wave_function, as b[HO] is defined therein.
// One multiplies by a Fermi function so that the Fourier-Bessel transform is defined on the real axis. 
// The Fermi function must have a radius as large as possible (around R typically) and a large diffuseness, wihch is fixed at 2 fm.
//
// Otherwise, momentum wave functions are not calculated and one must explicitly call wave_calculation_momentum to calculate them.
//
//
// Variables
// ---------
// E : energy of the wave state.
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// effective_mass_inv_minus_one : effective_mass(r)-1 on [0:R].
// effective_mass_inv_der : derivative of effective_mass(r) on [0:R].
// effective_mass_inv_2der : second derivative of effective_mass(r) on [0:R].
// Cplus_bef: for pole states, initial C+ with which u+(R) = C+[bef].H+[kR].
//            u+ is calculated from u+(R) with backward integration.
//            At this point, u-(matching_point) calculated from forward integration is not u+(matching_point).
// Cplus_bef, Cplus_ratio: C+/C+[bef] so that u(r) = u-(r) before matching_point and u(r) = C+/C+[bef].u+(r) after.
// Gamow_norm_value : square root of the integral \int u^2(r)~dr calculated with complex scaling. u(r) is normalized when divided by this value.
// width_from_current_formula: width of a resonant state calculated from the current formula in keV if the state is very narrow. Both values should be virtually equal.
// log10_width_from_current_formula: decimal logarithm of the width form the current formula
// log10_width_from_current_formula_integer_part: closest integer to log10_width_from_current_formula
// log10_width_from_current_formula_decimal_part: log10_width_from_current_formula - log10_width_from_current_formula_integer_part
// width_from_current_formula_decimal_part: 10^log10_width_from_current_formula_decimal_part

void spherical_state::wave_calculation (
					const bool is_there_cout ,
					class potentials_effective_mass &T ,
					const bool scaled_tables_calc)
{
  if (potential == QBOX_POTENTIAL) error_message_print_abort ("No Qbox potential in spherical_state::wave_calculation (no effective mass)");
  
  if (S_matrix_pole && (matching_point > R)) error_message_print_abort ("One must have R0 <= R in spherical_state for poles in spherical_state::wave_calculation (no effective mass)");

  if ((particle == PROTON) && (arg (k) < -M_PI_4))
    {
      ostringstream shell_os;
      
      shell_os << *this;

      error_message_print_abort ("Proton state " + shell_os.str () + " with arg[k] < -Pi/4. k=" + make_string<complex<double> > (k));
    }

  const class PTG_class &PTG_potential = T.get_PTG_potential ();

  if ((potential == PTG_POTENTIAL) && (PTG_potential.get_a () != 0.0)) error_message_print_abort ("PTG potential can be used in wave_calculation only if there is no effective mass (a=0)");

  if (!is_k_OK) return;

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  E = k*k/kinetic_factor;

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k , eta , NADA);
  
  const class ODE_integration ODE(&T , &potentials_effective_mass_F_z_u);

  if (S_matrix_pole)
    {
      const complex<double> Cplus_bef = Cplus;

      forward_integration_before_R (ODE);

      backward_integration_before_R (ODE);

      Cplus_Cminus_CF_CG_calc (ODE);
      
      const complex<double> Cplus_ratio = Cplus/Cplus_bef;

      normalization_before_R_after_matching_point (Cplus_ratio);

      d2wf_calc_before_R (T);

      if (are_there_scaled_wfs && scaled_tables_calc)
	{
	  scaled_wf_aft_R_tab_uniform = 0.0;
	  scaled_dwf_aft_R_tab_uniform = 0.0;

	  scaled_wf_aft_R_tab_GL = 0.0;
	  scaled_dwf_aft_R_tab_GL = 0.0;

	  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
	}
    }
  else
    {
      forward_integration_before_R (ODE); 

      Cplus_Cminus_CF_CG_calc (ODE);

      d2wf_calc_before_R (T);

      if (are_there_scaled_wfs && scaled_tables_calc)
	{
	  scaled_wf_aft_R_tab_uniform = 0.0;
	  scaled_dwf_aft_R_tab_uniform = 0.0;

	  scaled_wf_aft_R_tab_GL = 0.0;
	  scaled_dwf_aft_R_tab_GL = 0.0;

	  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
	}
    }

  if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();

  const complex<double> Gamow_norm_value = Gamow_norm ();
  
#ifdef UseOpenMP
#pragma omp critical
#endif
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole) cout << *this << " norm from complex scaling : " << Gamow_norm_value << endl;
    
  normalization (1.0/Gamow_norm_value);

  if (is_it_real ()) make_it_real ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole && (real (k) > 0) && (abs (imag (k)) < 1E-3))
    {
      const double log10_width_from_current_formula = log10_width_from_current_formula_calc ();

#ifdef UseOpenMP
#pragma omp critical
#endif
      {
	cout << endl;
	
	print_width_from_current_formula (log10_width_from_current_formula);
      }
    }
}






// Calculation of the second derivative of the wave function on [0:R].
// -------------------------------------------------------------------
// The second derivative of the wave function is calculated with the Schroedinger equation from the wave function , 
// and in 0 from the formula u(r) ~ C0.r0^{l + 1}.
//
// Variables:
// ----------
// llp1 : l(l + 1)
// E : energy of the state.
// r_bef_R_tab_uniform : tables of radii : r = i.step_bef_R_uniform on [0:R].
// full_effective_mass : interpolated table giving the effective mass on [0:R] in MeV^(-1) fm^{-2}.
// source : source in the HF equations with the quasi-equivalent potential.

void spherical_state::d2wf_calc_before_R (const class potentials_effective_mass &T)
{
  if (potential == QBOX_POTENTIAL) error_message_print_abort ("No Qbox potential in spherical_state::d2wf_calc_before_R");
  
  const double llp1 = l*(l + 1);

  d2wf_bef_R_tab_uniform(0) = (l == 1) ? (2.0*C0) : (0.0);

  switch (potential)
    {
    case EFFECTIVE_MASS_POTENTIAL:
      {
	const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();

	const class splines_class<double> &V_effective_mass_scaled = T.get_V_effective_mass_scaled ();

	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + full_effective_mass(r)*(V_effective_mass_scaled(r) - E))*wf_bef_R_tab_uniform(i);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + full_effective_mass(r)*(V_effective_mass_scaled(r) - E))*wf_bef_R_tab_GL(i);
	  }

      } break;

    case EFFECTIVE_MASS_POTENTIAL_PTG_LIKE:
      {
	const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();

	const class splines_class<double> &V_effective_mass_scaled = T.get_V_effective_mass_scaled ();

	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + full_effective_mass(r)*(V_effective_mass_scaled(r) - E))*wf_bef_R_tab_uniform(i);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + full_effective_mass(r)*(V_effective_mass_scaled(r) - E))*wf_bef_R_tab_GL(i);
	  }

      } break;

    case HF:
      {
	const class splines_class<complex<double> > &source = T.get_source ();

	const class splines_class<complex<double> > &Veq = T.get_trivially_equivalent_potential ();

	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_uniform(i) + kinetic_factor*source(r);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_GL(i) + kinetic_factor*source(r);
	  }

      } break;

    case MSDHF:
      {
	const class splines_class<complex<double> > &source = T.get_source ();

	const class splines_class<complex<double> > &Veq = T.get_trivially_equivalent_potential ();

	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_uniform(i) + kinetic_factor*source(r);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_GL(i) + kinetic_factor*source(r);
	  }

      } break;

    case SOURCE:
      {
	const class splines_class<complex<double> > &source = T.get_source ();

	const class splines_class<complex<double> > &Veq = T.get_trivially_equivalent_potential ();

	for (unsigned int i = 1 ; i <= N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_uniform(i) + kinetic_factor*source(r);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_GL(i) + kinetic_factor*source(r);
	  }

      } break;

    case NO_SOURCE:
      {
	const class splines_class<complex<double> > &Veq = T.get_trivially_equivalent_potential ();

	for (unsigned int i = 1 ; i <= N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_uniform(i);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(Veq(r) - E))*wf_bef_R_tab_GL(i);
	  }

      } break;

    case COULOMB_POTENTIAL:
      {
	d2wf_bef_R_tab_uniform(0) *= exp (log_Cl_eta_calc (l , eta));

	const class Coulomb_potential_class Coulomb_potential(is_it_relative , particle , Z_charge , NADA);
	
	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(Coulomb_potential.point_potential_calc (r) - E))*wf_bef_R_tab_uniform(i);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(Coulomb_potential.point_potential_calc (r) - E))*wf_bef_R_tab_GL(i);
	  }

      } break;

    default:
      {
	for (unsigned int i = 1 ; i < N_bef_R_uniform ; i++)
	  {
	    const double r = r_bef_R_tab_uniform(i);
	    
	    d2wf_bef_R_tab_uniform(i) = (llp1/(r*r) + kinetic_factor*(T.potential_calc (r) - E))*wf_bef_R_tab_uniform(i);
	  }

	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    
	    d2wf_bef_R_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(T.potential_calc (r) - E))*wf_bef_R_tab_GL(i);
	  }

	if (particle == ELECTRON)
	  {
	    for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	      {
		const double r = r_bef_s_tab_GL(i);
		
		d2wf_bef_s_tab_GL(i) = (llp1/(r*r) + kinetic_factor*(T.potential_calc (r) - E))*wf_bef_s_tab_GL(i);
	      }
	  }

      } break;
    }
}







// Calculation of the wave function if one has only a pure 1/r Coulomb potential
// ----------------------------------------------------------------------------
// The wave function is a here a Bessel or Coulomb wave function.
// It has to be a scattering state.

void spherical_state::Coulomb_eigenstate_calc (const bool only_bef_R)
{
  if (potential != COULOMB_POTENTIAL) error_message_print_abort ("potential must be COULOMB to use spherical_state::Coulomb_eigenstate_calc.");

  if (S_matrix_pole) error_message_print_abort ("There are no poles if potential is COULOMB.");

  class Coulomb_wave_functions cwf(true , l , eta);

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) cwf.F_kz_dF_kz (k , r_bef_R_tab_uniform(i) , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i));
  for (unsigned int i = 0 ; i < N_bef_R_GL  ; i++) cwf.F_kz_dF_kz (k , r_bef_R_tab_GL(i)  , wf_bef_R_tab_GL(i)  , dwf_bef_R_tab_GL(i));

  const complex<double> half_I(0 , 0.5);

  CF = 1.0;
  CG = 0.0;

  Cplus = -half_I;
  Cminus = half_I;

  class potentials_effective_mass dummy;
  
  d2wf_calc_before_R (dummy);

  if (!only_bef_R) 
    {	
      scaled_wf_aft_R_tab_uniform = 0.0;
      scaled_dwf_aft_R_tab_uniform = 0.0;

      scaled_wf_aft_R_tab_GL = 0.0;
      scaled_dwf_aft_R_tab_GL = 0.0;

      for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);

      if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();
    }

  normalization (sqrt (M_2_PI));
}





// Copy unscaled wave function tables to a file
// --------------------------------------------

void spherical_state::copy_to_file_for_figure_coordinate (
							  const string debut_file_name , 
							  const bool is_it_Gauss_Legendre ,
							  const bool is_it_bef_R_only ,
							  const bool is_it_real_axis) const
{
  string file_name = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + "_";

  if (is_it_Gauss_Legendre)
    file_name += "Gauss_Legendre.dat";
  else
    file_name += "uniform_grid.dat";

  ofstream out_file(file_name.c_str ());
  
  out_file.precision (15);

  if (is_it_Gauss_Legendre)
    {
      if (particle == ELECTRON)
	{	
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++) 
	    out_file << r_bef_s_tab_GL(i) << " "
		     << real (wf_bef_s_tab_GL(i))   << " " << imag (wf_bef_s_tab_GL(i))   << " "
		     << real (dwf_bef_s_tab_GL(i))  << " " << imag (dwf_bef_s_tab_GL(i))  << " "
		     << real (d2wf_bef_s_tab_GL(i)) << " " << imag (d2wf_bef_s_tab_GL(i)) << endl;
	}

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	out_file << r_bef_R_tab_GL(i) << " "
		 << real (wf_bef_R_tab_GL(i))   << " " << imag (wf_bef_R_tab_GL(i))   << " "
		 << real (dwf_bef_R_tab_GL(i))  << " " << imag (dwf_bef_R_tab_GL(i))  << " "
		 << real (d2wf_bef_R_tab_GL(i)) << " " << imag (d2wf_bef_R_tab_GL(i)) << endl;

    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
	out_file << r_bef_R_tab_uniform(i) << " "
		 << real (wf_bef_R_tab_uniform(i))   << " " << imag (wf_bef_R_tab_uniform(i))   << " "
		 << real (dwf_bef_R_tab_uniform(i))  << " " << imag (dwf_bef_R_tab_uniform(i))  << " "
		 << real (d2wf_bef_R_tab_uniform(i)) << " " << imag (d2wf_bef_R_tab_uniform(i)) << endl;
    }
  
  if (!is_it_bef_R_only && (R_real_max > 0.0))
    {
      if (is_it_real_axis)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    out_file << r_aft_R_tab_GL_real(i) << " "
		     << real (wf_aft_R_tab_GL_real(i))   << " " << imag (wf_aft_R_tab_GL_real(i))   << " "
		     << real (dwf_aft_R_tab_GL_real(i))  << " " << imag (dwf_aft_R_tab_GL_real(i))  << " "
		     << real (d2wf_aft_R_tab_GL_real(i)) << " " << imag (d2wf_aft_R_tab_GL_real(i)) << endl;
	}
      else
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    out_file << r_aft_R_tab_GL_complex(i) << " "
		     << real (wf_aft_R_tab_GL_complex(i))   << " " << imag (wf_aft_R_tab_GL_complex(i))   << " "
		     << real (dwf_aft_R_tab_GL_complex(i))  << " " << imag (dwf_aft_R_tab_GL_complex(i))  << " "
		     << real (d2wf_aft_R_tab_GL_complex(i)) << " " << imag (d2wf_aft_R_tab_GL_complex(i)) << endl;
	}
    }
}





void spherical_state::copy_to_file_for_figure_momentum (
							const string debut_file_name ,
							const bool is_it_Gauss_Legendre) const
{
  if (kmax_momentum == 0.0) error_message_print_abort ("kmax_momentum must be positive to use spherical_state::copy_to_file_for_figure_momentum ");
  
  string file_name = debut_file_name + "_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + "_momentum_";

  if (is_it_Gauss_Legendre)
    file_name += "Gauss_Legendre.dat";
  else
    file_name += "uniform_grid.dat";

  ofstream out_file(file_name.c_str ());
  
  out_file.precision (15);

  if (is_it_Gauss_Legendre)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++) 
	out_file << k_tab_GL(i) << " "
		 << real (wf_momentum_tab_GL(i))   << " " << imag (wf_momentum_tab_GL(i))   << " "
		 << real (dwf_momentum_tab_GL(i))  << " " << imag (dwf_momentum_tab_GL(i))  << endl;
    }
  else
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++) 
	out_file << k_tab_uniform(i) << " "
		 << real (wf_momentum_tab_uniform(i))   << " " << imag (wf_momentum_tab_uniform(i))   << " "
		 << real (dwf_momentum_tab_uniform(i))  << " " << imag (dwf_momentum_tab_uniform(i))  << endl;
    }
}






void spherical_state::copy_to_file (const string &debut_file_name) const
{
  const string file_name = debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";
  
  const unsigned int N = all_data_dimension_calc ();

  class array<complex<double> > T(N);
  
  unsigned int index = 0;
    
  T(index++) = k;

  T(index++) = eta;

  T(index++) = E;

  T(index++) = C0;

  T(index++) = Cplus;
  T(index++) = Cminus;

  T(index++) = CF;
  T(index++) = CG;

  T(index++) = wf_R0;
  T(index++) = dwf_R0;
    
  if (N_bef_R_uniform > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  T(index++) = wf_bef_R_tab_uniform(i);
	  T(index++) = dwf_bef_R_tab_uniform(i);
	  T(index++) = d2wf_bef_R_tab_uniform(i);
	}
    }

  if (N_bef_R_GL > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  T(index++) = wf_bef_R_tab_GL(i);
	  T(index++) = dwf_bef_R_tab_GL(i);
	  T(index++) = d2wf_bef_R_tab_GL(i);
	}
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  T(index++) = wf_bef_R_tab_GL_SGI_MSGI(i);
	  T(index++) = dwf_bef_R_tab_GL_SGI_MSGI(i);
	}
    }
    
  if ((particle == ELECTRON) && (N_bef_s_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  T(index++) = wf_bef_s_tab_GL(i);
	  T(index++) = dwf_bef_s_tab_GL(i);
	  T(index++) = d2wf_bef_s_tab_GL(i);
	}
    }

  if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  T(index++) = wf_aft_R_tab_GL_real(i);
	  T(index++) = dwf_aft_R_tab_GL_real(i);
	  T(index++) = d2wf_aft_R_tab_GL_real(i);

	  T(index++) = wf_aft_R_tab_GL_complex(i);
	  T(index++) = dwf_aft_R_tab_GL_complex(i);
	  T(index++) = d2wf_aft_R_tab_GL_complex(i);
	}
    }

  if (Nk_momentum_uniform > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  T(index++) = wf_momentum_tab_uniform(i);
	  T(index++) = dwf_momentum_tab_uniform(i);
	}
    }

  if (are_there_scaled_wfs && (N_aft_R_GL > 0))
    {
      for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      T(index++) = scaled_wf_aft_R_tab_GL (asy , angle_index , i);
	      T(index++) = scaled_dwf_aft_R_tab_GL(asy , angle_index , i);
	    }
    }

  if (Nk_momentum_GL > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  T(index++) = wf_momentum_tab_GL(i);
	  T(index++) = dwf_momentum_tab_GL(i);
	}
    }

  if (are_there_scaled_wfs && (N_aft_R_uniform > 0))
    {
      for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      T(index++) = scaled_wf_aft_R_tab_uniform (asy , angle_index , i);
	      T(index++) = scaled_dwf_aft_R_tab_uniform(asy , angle_index , i);
	    }
    }
  
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::copy_to_file.");

  T.copy_disk (file_name);
}








void spherical_state::get_from_file (const string &debut_file_name)
{
  const string file_name = debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";

  const unsigned int N = all_data_dimension_calc ();

  class array<complex<double> > T(N);

  T.read_disk (file_name);
  
  unsigned int index = 0;
  
  k = T(index++);

  eta = T(index++);

  E = T(index++);

  C0 = T(index++);

  Cplus  = T(index++);
  Cminus = T(index++);

  CF = T(index++);
  CG = T(index++);

  wf_R0  = T(index++);
  dwf_R0 = T(index++);
  
  if (N_bef_R_uniform > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform  (i) = T(index++);
	  dwf_bef_R_tab_uniform (i) = T(index++);
	  d2wf_bef_R_tab_uniform(i) = T(index++);
	}
    }

  if (N_bef_R_GL > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL  (i) = T(index++);
	  dwf_bef_R_tab_GL (i) = T(index++);
	  d2wf_bef_R_tab_GL(i) = T(index++);
	}      
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL_SGI_MSGI (i) = T(index++);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = T(index++);
	}
    }

  if ((particle == ELECTRON) && (N_bef_s_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  wf_bef_s_tab_GL  (i) = T(index++);
	  dwf_bef_s_tab_GL (i) = T(index++);
	  d2wf_bef_s_tab_GL(i) = T(index++);
	}
    }

  if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  wf_aft_R_tab_GL_real  (i) = T(index++);
	  dwf_aft_R_tab_GL_real (i) = T(index++);
	  d2wf_aft_R_tab_GL_real(i) = T(index++);

	  wf_aft_R_tab_GL_complex  (i) = T(index++);
	  dwf_aft_R_tab_GL_complex (i) = T(index++);
	  d2wf_aft_R_tab_GL_complex(i) = T(index++);
	}
    }

  if (are_there_scaled_wfs && (N_aft_R_uniform > 0))
    {
      for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      scaled_wf_aft_R_tab_uniform (asy , angle_index , i) = T(index++);
	      scaled_dwf_aft_R_tab_uniform(asy , angle_index , i) = T(index++);
	    }
    }

  if (are_there_scaled_wfs && (N_aft_R_GL > 0))
    {
      for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      scaled_wf_aft_R_tab_GL(asy , angle_index , i)  = T(index++);
	      scaled_dwf_aft_R_tab_GL(asy , angle_index , i) = T(index++);
	    }
    }

  if (Nk_momentum_uniform > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  wf_momentum_tab_uniform (i) = T(index++);
	  dwf_momentum_tab_uniform(i) = T(index++);
	}
    }

  if (Nk_momentum_GL > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  wf_momentum_tab_GL  (i) = T(index++);
	  dwf_momentum_tab_GL (i) = T(index++);
	}
    }
  
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::get_from_file.");
}







void spherical_state::copy_to_file_no_scaled_wfs (const string &debut_file_name) const
{
  const string file_name = debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";
  
  const unsigned int N = all_data_dimension_no_scaled_wfs_calc ();

  class array<complex<double> > T(N);
  
  unsigned int index = 0;
    
  T(index++) = k;

  T(index++) = eta;

  T(index++) = E;

  T(index++) = C0;

  T(index++) = Cplus;
  T(index++) = Cminus;

  T(index++) = CF;
  T(index++) = CG;

  T(index++) = wf_R0;
  T(index++) = dwf_R0;
    
  if (N_bef_R_uniform > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  T(index++) = wf_bef_R_tab_uniform(i);
	  T(index++) = dwf_bef_R_tab_uniform(i);
	  T(index++) = d2wf_bef_R_tab_uniform(i);
	}
    }

  if (N_bef_R_GL > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  T(index++) = wf_bef_R_tab_GL(i);
	  T(index++) = dwf_bef_R_tab_GL(i);
	  T(index++) = d2wf_bef_R_tab_GL(i);
	}
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  T(index++) = wf_bef_R_tab_GL_SGI_MSGI(i);
	  T(index++) = dwf_bef_R_tab_GL_SGI_MSGI(i);
	}
    }
    
  if ((particle == ELECTRON) && (N_bef_s_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  T(index++) = wf_bef_s_tab_GL(i);
	  T(index++) = dwf_bef_s_tab_GL(i);
	  T(index++) = d2wf_bef_s_tab_GL(i);
	}
    }

  if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  T(index++) = wf_aft_R_tab_GL_real(i);
	  T(index++) = dwf_aft_R_tab_GL_real(i);
	  T(index++) = d2wf_aft_R_tab_GL_real(i);

	  T(index++) = wf_aft_R_tab_GL_complex(i);
	  T(index++) = dwf_aft_R_tab_GL_complex(i);
	  T(index++) = d2wf_aft_R_tab_GL_complex(i);
	}
    }

  if (Nk_momentum_uniform > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  T(index++) = wf_momentum_tab_uniform(i);
	  T(index++) = dwf_momentum_tab_uniform(i);
	}
    }

  if (Nk_momentum_GL > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  T(index++) = wf_momentum_tab_GL(i);
	  T(index++) = dwf_momentum_tab_GL(i);
	}
    }

  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::copy_to_file_no_scaled_wfs.");

  T.copy_disk (file_name);
}








void spherical_state::get_from_file_no_scaled_wfs (const string &debut_file_name)
{
  const string file_name = debut_file_name + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";

  const unsigned int N = all_data_dimension_no_scaled_wfs_calc ();

  class array<complex<double> > T(N);

  T.read_disk (file_name);
  
  unsigned int index = 0;
  
  k = T(index++);

  eta = T(index++);

  E = T(index++);

  C0 = T(index++);

  Cplus  = T(index++);
  Cminus = T(index++);

  CF = T(index++);
  CG = T(index++);

  wf_R0  = T(index++);
  dwf_R0 = T(index++);
  
  if (N_bef_R_uniform > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform  (i) = T(index++);
	  dwf_bef_R_tab_uniform (i) = T(index++);
	  d2wf_bef_R_tab_uniform(i) = T(index++);
	}
    }

  if (N_bef_R_GL > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL  (i) = T(index++);
	  dwf_bef_R_tab_GL (i) = T(index++);
	  d2wf_bef_R_tab_GL(i) = T(index++);
	}      
    }

  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL_SGI_MSGI (i) = T(index++);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = T(index++);
	}
    }

  if ((particle == ELECTRON) && (N_bef_s_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	{
	  wf_bef_s_tab_GL  (i) = T(index++);
	  dwf_bef_s_tab_GL (i) = T(index++);
	  d2wf_bef_s_tab_GL(i) = T(index++);
	}
    }

  if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  wf_aft_R_tab_GL_real  (i) = T(index++);
	  dwf_aft_R_tab_GL_real (i) = T(index++);
	  d2wf_aft_R_tab_GL_real(i) = T(index++);

	  wf_aft_R_tab_GL_complex  (i) = T(index++);
	  dwf_aft_R_tab_GL_complex (i) = T(index++);
	  d2wf_aft_R_tab_GL_complex(i) = T(index++);
	}
    }

  if (Nk_momentum_uniform > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  wf_momentum_tab_uniform (i) = T(index++);
	  dwf_momentum_tab_uniform(i) = T(index++);
	}
    }

  if (Nk_momentum_GL > 0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  wf_momentum_tab_GL  (i) = T(index++);
	  dwf_momentum_tab_GL (i) = T(index++);
	}
    }
  
  if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::get_from_file.");
}












void spherical_state::Qbox_wf_calc_from_file (const string &debut_file_name)
{
  if (particle == ELECTRON) error_message_print_abort ("No electron in spherical_state::Qbox_wf_calc_from_file");

  if (potential != QBOX_POTENTIAL) error_message_print_abort ("Qbox potential only in spherical_state::Qbox_wf_calc_from_file");
    
  const string file_name = debut_file_name + "Qbox_wf_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";

  ifstream wf_file_input(file_name.c_str ());

  wf_file_input >> boolalpha;
	
  const unsigned int N_total = elements_number<string> (file_name);

  const unsigned int N_points_from_file = (N_total - 4)/3;

  double R_from_file;
  
  double kinetic_factor_from_file;
  
  bool S_matrix_pole_from_file;

  complex<double> k_from_file;

  is_k_OK = true;
  
  is_k_search_start_used = false;

  is_it_cwf_standard_normalization = true;
  
  wf_file_input >> R_from_file >> kinetic_factor_from_file >> S_matrix_pole_from_file >> k;
  
  if ((abs (R - R_from_file) > precision) && (R > R_from_file))
    error_message_print_abort ("One must have R <= R[Qbox file] in spherical_state::Qbox_wf_calc_from_file");
    
  if (abs (kinetic_factor - kinetic_factor_from_file) > precision)
    error_message_print_abort ("kinetic_factor and kinetic_factor[Qbox file] are different in file " + file_name + " in spherical_state::Qbox_wf_calc_from_file");
    
  if (S_matrix_pole_from_file != S_matrix_pole)
    error_message_print_abort ("S_matrix_pole and S_matrix_pole[Qbox file] are different in file " + file_name + " in spherical_state::Qbox_wf_calc_from_file");
  
  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  E = k*k/kinetic_factor;
  
  class array<double> r_tab_from_file(N_points_from_file);
  
  class array<complex<double> > wf_tab_from_file(N_points_from_file);
  
  class array<complex<double> > wf_der_tab_from_file(N_points_from_file);
  
  class array<complex<double> > wf_2der_tab_from_file(N_points_from_file);

  double r;
  
  double Re_wf_r;
  double Im_wf_r;
      
  for (unsigned int i = 0 ; i < N_points_from_file ; i++)
    {
      wf_file_input >> r >> Re_wf_r >> Im_wf_r;

      const complex<double> wf_r(Re_wf_r , Im_wf_r);
	  
      r_tab_from_file(i) = r;
      
      wf_tab_from_file(i) = wf_r;
    }

  const class splines_class<complex<double> > wf_splines(r_tab_from_file , wf_tab_from_file);
  
  for (unsigned int i = 0 ; i < N_points_from_file ; i++)
    {
      const double r = r_tab_from_file(i);
	  
      wf_der_tab_from_file(i) = wf_splines.derivative (r);
    }

  const class splines_class<complex<double> > wf_der_splines(r_tab_from_file , wf_der_tab_from_file);
  
  for (unsigned int i = 0 ; i < N_points_from_file ; i++)
    {
      const double r = r_tab_from_file(i);
	  
      wf_2der_tab_from_file(i) = wf_der_splines.derivative (r);
    }
  
  const class splines_class<complex<double> > wf_2der_splines(r_tab_from_file , wf_2der_tab_from_file);

  if (N_bef_R_uniform > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  const double r = r_bef_R_tab_uniform(i);
	  
	  wf_bef_R_tab_uniform(i) = wf_splines(r);
	  dwf_bef_R_tab_uniform(i) = wf_der_splines(r);
	  d2wf_bef_R_tab_uniform(i) = wf_2der_splines(r);
	}
    }

  if (N_bef_R_GL > 0)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r = r_bef_R_tab_GL(i);
	  
	  wf_bef_R_tab_GL(i) = wf_splines(r);
	  dwf_bef_R_tab_GL(i) = wf_der_splines(r);
	  d2wf_bef_R_tab_GL(i) = wf_2der_splines(r);
	}
    }

  wf_R0 = wf_splines(R0);

  dwf_R0 = wf_der_splines(R0);

  const double r0 = (l > 0) ? (r_tab_from_file(1)) : (0.0);

  C0 = (l > 0) ? (wf_tab_from_file(1)/pow (r0 , l + 1)) : (wf_der_tab_from_file(0));
  
  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;

  const complex<double>  u_R =  wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one);
  const complex<double> du_R = dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one);
      
  class Coulomb_wave_functions cwf(true , l , eta);
  
  if ((S_matrix_pole) || (imag (k) > 0.1))
    {
      complex<double> wf_asy_r  = 0.0;
      complex<double> dwf_asy_r = 0.0;
      
      if (is_it_real ())
	cwf.Wm_kz_dWm_kz (k , R , wf_asy_r , dwf_asy_r);
      else
	cwf.H_kz_dH_kz (1 , k , R , wf_asy_r , dwf_asy_r);
      
      Cplus = u_R/wf_asy_r;
      
      Cminus = 0.0;

      CG = Cplus;

      CF = complex<double> (-imag (Cplus) , real (Cplus));
      
      const double Re_E = real (E);

      const double Gamma = -2000.0*imag (E);
      
#ifdef UseOpenMP
#pragma omp critical
#endif
      cout << *this << " k:" << k << " fm^(-1) E:" << Re_E << " MeV" << " G:" << Gamma << " keV" << endl;
    } 
  else
    {
      complex<double> F = 0.0 , dF = 0.0;
      complex<double> G = 0.0 , dG = 0.0;

      cwf.F_kz_dF_kz (k , R , F , dF);
      cwf.G_kz_dG_kz (k , R , G , dG);
      
      const complex<double> Det = dF*G - F*dG;

      CF =  (du_R*G - u_R*dG)/Det;
      CG = -(du_R*F - u_R*dF)/Det;

      const complex<double> I_CF(-imag (CF) , real (CF));

      Cplus  = 0.5*(CG - I_CF);
      Cminus = 0.5*(CG + I_CF);
    }
  
  if (are_there_scaled_wfs)
    {
      scaled_wf_aft_R_tab_uniform = 0.0;
      scaled_dwf_aft_R_tab_uniform = 0.0;

      scaled_wf_aft_R_tab_GL = 0.0;      
      scaled_dwf_aft_R_tab_GL = 0.0;
	  
      for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);      
    }
  
  if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();
  
  if (S_matrix_pole) normalization (1.0/Gamow_norm ());
      
  if (is_it_real ()) make_it_real ();
}







unsigned int spherical_state::all_data_dimension_calc () const
{
  unsigned int N = 10;

  N += 3*N_bef_R_uniform;
  
  N += 3*N_bef_R_GL;

  if (kmax_momentum > 0.0)
    {
      N += 2*Nk_momentum_uniform;
  
      N += 2*Nk_momentum_GL;
    }
  
  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL)) N += 2*N_bef_R_GL;

  if (particle == ELECTRON) N += 3*N_bef_s_GL;

  if (are_there_scaled_wfs) N += 16*N_aft_R_uniform;

  if (R_real_max > 0.0) N += 6*N_aft_R_GL;

  if (are_there_scaled_wfs) N += 16*N_aft_R_GL;

  return N;
}




unsigned int spherical_state::all_data_dimension_no_scaled_wfs_calc () const
{
  unsigned int N = 10;

  N += 3*N_bef_R_uniform;
  
  N += 3*N_bef_R_GL;

  if (kmax_momentum > 0.0)
    {
      N += 2*Nk_momentum_uniform;
  
      N += 2*Nk_momentum_GL;
    }
  
  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL)) N += 2*N_bef_R_GL;

  if (particle == ELECTRON) N += 3*N_bef_s_GL;

  if (R_real_max > 0.0) N += 6*N_aft_R_GL;
  
  return N;
}





#ifdef UseMPI

void spherical_state::MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  MPI_helper::Bcast<bool> (is_k_OK , sending_process , MPI_C);

  const unsigned int N = all_data_dimension_calc ();

  class array<complex<double> > T(N);

  if (THIS_PROCESS == sending_process)
    {
      unsigned int index = 0;

      T(index++) = k;

      T(index++) = eta;

      T(index++) = E;

      T(index++) = C0;

      T(index++) = Cplus;
      T(index++) = Cminus;

      T(index++) = CF;
      T(index++) = CG;

      T(index++) = wf_R0;
      T(index++) = dwf_R0;

      if (N_bef_R_uniform > 0)
	{
	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {
	      T(index++) = wf_bef_R_tab_uniform(i);
	      T(index++) = dwf_bef_R_tab_uniform(i);
	      T(index++) = d2wf_bef_R_tab_uniform(i);
	    }
	}

      if (N_bef_R_GL > 0)
	{
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      T(index++) = wf_bef_R_tab_GL(i);
	      T(index++) = dwf_bef_R_tab_GL(i);
	      T(index++) = d2wf_bef_R_tab_GL(i);
	    }
	}

      if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      T(index++) = wf_bef_R_tab_GL_SGI_MSGI(i);
	      T(index++) = dwf_bef_R_tab_GL_SGI_MSGI(i);
	    }
	}

      if ((particle == ELECTRON) && (N_bef_s_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    {
	      T(index++) = wf_bef_s_tab_GL(i);
	      T(index++) = dwf_bef_s_tab_GL(i);
	      T(index++) = d2wf_bef_s_tab_GL(i);
	    }
	}

      if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      T(index++) = wf_aft_R_tab_GL_real(i);
	      T(index++) = dwf_aft_R_tab_GL_real(i);
	      T(index++) = d2wf_aft_R_tab_GL_real(i);

	      T(index++) = wf_aft_R_tab_GL_complex(i);
	      T(index++) = dwf_aft_R_tab_GL_complex(i);
	      T(index++) = d2wf_aft_R_tab_GL_complex(i);
	    }
	}

      if (are_there_scaled_wfs && (N_aft_R_uniform > 0))
	{
	  for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	    for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
		{
		  T(index++) = scaled_wf_aft_R_tab_uniform(asy , angle_index , i);
		  T(index++) = scaled_dwf_aft_R_tab_uniform(asy , angle_index , i);
		}
	}

      if (are_there_scaled_wfs && (N_aft_R_GL > 0))
	{
	  for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	    for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{
		  T(index++) = scaled_wf_aft_R_tab_GL(asy , angle_index , i);
		  T(index++) = scaled_dwf_aft_R_tab_GL(asy , angle_index , i);
		}
	}

      if (Nk_momentum_uniform > 0)
	{
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      T(index++) = wf_momentum_tab_uniform(i);
	      T(index++) = dwf_momentum_tab_uniform(i);
	    }
	}

      if (Nk_momentum_GL > 0)
	{
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      T(index++) = wf_momentum_tab_GL(i);
	      T(index++) = dwf_momentum_tab_GL(i);
	    }
	}

      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::MPI_Bcast(send).");
    }

  T.MPI_Bcast (sending_process , MPI_C);

  if (THIS_PROCESS != sending_process)
    { 
      unsigned int index = 0;

      k = T(index++);

      eta = T(index++);

      E = T(index++);

      C0 = T(index++);

      Cplus  = T(index++);
      Cminus = T(index++);

      CF = T(index++);
      CG = T(index++);

      wf_R0  = T(index++);
      dwf_R0 = T(index++);

      if (N_bef_R_uniform > 0)
	{
	  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	    {
	      wf_bef_R_tab_uniform  (i) = T(index++);
	      dwf_bef_R_tab_uniform (i) = T(index++);
	      d2wf_bef_R_tab_uniform(i) = T(index++);
	    }
	}

      if (N_bef_R_GL > 0)
	{
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      wf_bef_R_tab_GL  (i) = T(index++);
	      dwf_bef_R_tab_GL (i) = T(index++);
	      d2wf_bef_R_tab_GL(i) = T(index++);
	    }
	}

      if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL) && (N_bef_R_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      wf_bef_R_tab_GL_SGI_MSGI (i) = T(index++);
	      dwf_bef_R_tab_GL_SGI_MSGI(i) = T(index++);
	    }
	}

      if ((particle == ELECTRON) && (N_bef_s_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_bef_s_GL ; i++)
	    {
	      wf_bef_s_tab_GL  (i) = T(index++);
	      dwf_bef_s_tab_GL (i) = T(index++);
	      d2wf_bef_s_tab_GL(i) = T(index++);
	    }
	}

      if ((R_real_max > 0.0) && (N_aft_R_GL > 0))
	{
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      wf_aft_R_tab_GL_real  (i) = T(index++);
	      dwf_aft_R_tab_GL_real (i) = T(index++);
	      d2wf_aft_R_tab_GL_real(i) = T(index++);

	      wf_aft_R_tab_GL_complex  (i) = T(index++);
	      dwf_aft_R_tab_GL_complex (i) = T(index++);
	      d2wf_aft_R_tab_GL_complex(i) = T(index++);
	    }
	}
      
      if (are_there_scaled_wfs && (N_aft_R_uniform > 0))
	{
	  for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	    for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
		{
		  scaled_wf_aft_R_tab_uniform (asy , angle_index , i) = T(index++);
		  scaled_dwf_aft_R_tab_uniform(asy , angle_index , i) = T(index++);
		}
	}

      if (are_there_scaled_wfs && (N_aft_R_GL > 0))
	{
	  for (unsigned int asy = 0 ; asy <= 1 ; asy++)
	    for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++)
	      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
		{
		  scaled_wf_aft_R_tab_GL (asy , angle_index , i) = T(index++);
		  scaled_dwf_aft_R_tab_GL(asy , angle_index , i) = T(index++);
		}
	}
      
      if (Nk_momentum_uniform > 0)
	{
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      wf_momentum_tab_uniform (i) = T(index++);
	      dwf_momentum_tab_uniform(i) = T(index++);
	    }
	}

      if (Nk_momentum_GL > 0)
	{
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      wf_momentum_tab_GL (i) = T(index++);
	      dwf_momentum_tab_GL(i) = T(index++);
	    }
	}

      if (index != N) error_message_print_abort ("index=" + make_string<unsigned int> (index) + " is not equal to N=" + make_string<unsigned int> (N) + " in spherical_state::MPI_Bcast(receive).");
    }
}
#endif







//  <<  overloading to print a wave function under the form 0p3/2 , 0f7/2 , 1s1/2 , etc ...
// -------------------------------------------------------------------------------------

ostream & operator <<  (ostream &os , const class spherical_state &u)
{
  if (u.get_isItRotor ())
    {
      if (u.get_particle () == ELECTRON)
	return os << "n:" << u.get_n () << " jr:" << u.get_jr () << " l:" << u.get_l ();
      else
	return os << u.get_n () << "(jr:" << u.get_jr () << ")" << angular_state (u.get_l () , u.get_j ());
    }
  else
    {
      const int A_particle = A_projectile_determine (u.get_particle ());

      if (A_particle == 2)
	{
	  if (is_it_two_nucleon_ST_projectile_determine (u.get_particle ()))
	    return os << u.get_n () << angular_state_relative_cluster (u.get_particle () , u.get_l () , u.get_j ());
	  else
	    return os << u.get_n () << " " << angular_state_cluster (u.get_particle () , u.get_l () , u.get_j ());
	}
      else 
	{
	  return os << u.get_n () << angular_state_cluster (u.get_particle () , u.get_l () , u.get_j ());
	}
    }
}




//--// spherical_state_asymptotic


// Correction of the proton wave function due to the Coulomb wave function branch cut
// ----------------------------------------------------------------------------------
// For proton wave functions, one uses Coulomb wave functions in the complex plane.
// One has to have |arg (k)| <= Pi/4 for unbound states in order to avoid to cross the branch cut, 
// which is the negative real axis, as then wave functions become discontinuous.
// But for bound states with k != 0, it is unavoidable and happens for cos (theta) < 0.
// Nevertheless, in this case, |H+| -> +oo, so one can replace H+ by H+ minus the discontinuity function due to the branch cut.
// One then has : u(z) = H+(kz).exp[2.Pi.eta] + [exp[2.Pi.eta] - 1].[H+(kz) - H-(kz)] scaled.
// Nothing changes concerning complex scaling, as both wave functions have the same growth for |z| -> +oo.
//
// Variables
// ---------
// exp_two_Pi_eta : exp[2.Pi.eta]. It is used in the branch cut formula of the wave function.
// exp_two_Pi_eta_minus_one : exp[2.Pi.eta] - 1. It is used in the branch cut formula of the proton wave function and calculated with expm1.
// exp_Itheta : exp[i.theta], with theta the angle of complex rotation.
// cwf : class Coulomb_wave_function of parameters l and eta. 
//       The Coulomb wave functions are there not normalized.
// N : number of wave function values.
// index : index of the wave function value one calculates. It must be smaller than N-1.
// z, kz : variable of the wave function at index : z = R + (r - R).exp[i.theta], k.z .
// z_bef, kz_bef : variable of the wave function at index + 1 : z_bef = R + (r_bef - R).exp[i.theta], k.z_bef.
// is_it_crossed : true if the branch cut has been crossed, false if not.
// sc_wf_plus, sc_dwf_plus : tables with the scaled H+[kz] and dH+/dz[kz]
// sc_wf_plus[index] : originally H+[kz] scaled. 
//                     It becomes H+(kz).exp[2.Pi.eta] +/- [exp[2.Pi.eta] - 1].[H+(kz) - H-(kz)] scaled if the branch cut is crossed.
// sc_dwf_plus[index] : originally dH+/dz[kz] scaled. 
//                      It becomes dH+/dz(kz).exp[2.Pi.eta] +/- [exp[2.Pi.eta] - 1].[dH+(kz)/dz - dH-(kz)/dz] scaled if the branch cut is crossed.
// H_minus, dH_minus_dz : H-[kz], dH-[kz]/dz, used in the branch cut formula.
// exp_scale : exp (-i.[k.z - eta.log[2.k.z]]), used for the scaling of the wave function u(z).
// branch_cut_factor_plus, branch_cut_factor_minus : factors so u(z) = branch_cut_factor_plus.H+[kz] - branch_cut_factor_minus.H-[kz] scaled .
// z_tab : table with all the wave function variables z.

void spherical_state::branch_cut_correction (
					     const complex<double> &exp_two_Pi_eta , 
					     const complex<double> &exp_two_Pi_eta_minus_one , 
					     class Coulomb_wave_functions &cwf , 
					     const class array<complex<double> > &z_tab , 
					     const unsigned int angle_index , 
					     const unsigned int i , 
					     bool &is_it_crossed , 
					     class array<complex<double> > &scaled_wfs , 
					     class array<complex<double> > &scaled_dwfs)
{
  const unsigned int N = z_tab.dimension (0);

  if (S_matrix_pole && (Z_charge != 0) &&  (i < N - 1))
    {
      const complex<double> kz = k*z_tab(i);

      const complex<double> kz_bef = k*z_tab(i + 1);

      if ((real (kz_bef) < 0.0) && (real (kz) < 0.0) && (SIGN (imag (kz_bef)) != SIGN (imag (kz)))) is_it_crossed = true;

      if (is_it_crossed)
	{
	  complex<double> H_minus = 0.0;
	  complex<double> dH_minus_dz = 0.0;

	  cwf.H_kz_dH_kz (-1 , k , z_tab(i) , H_minus , dH_minus_dz);

	  const complex<double> I(0 , 1);

	  const complex<double> exp_scale = exp (-I*(kz - eta*(M_LN2 + log (kz))));

	  const complex<double> branch_cut_factor_minus = exp_two_Pi_eta_minus_one*exp_scale;

	  scaled_wfs (0 , angle_index , i) = exp_two_Pi_eta*scaled_wfs (0 , angle_index , i) - branch_cut_factor_minus*H_minus;
	  scaled_dwfs(0 , angle_index , i) = exp_two_Pi_eta*scaled_dwfs(0 , angle_index , i) - branch_cut_factor_minus*dH_minus_dz;
	}
    }
}






// Calculation of the wave functions ingoing and outgoing and derivatives after R with the complex scaling.
// --------------------------------------------------------------------------------------------------------
// The wave function is calculated with the Coulomb wave functions.
// The complex radius is z = R + (r - R)*exp_Itheta, with r in [R:+oo[.
// For r -> +oo, one takes the limit of the scaled Coulomb wave functions.
// One calculates u+, du+, u-, du- as they usually require the same values F(k.z) and F'(k.z), which are stored in the class Coulomb_wave_functions.
// It is multiplied by exp(-i.[k.z - eta.log[2kz]]) if outgoing at +oo or exp(i.[k.z - eta.log[2kz]]]) if incoming at +oo to avoid overflow or underflow.
// If k = 0.0 (pole states), one uses the asymptotic formulae for k = 0 (see above).
// If one has a pole proton state crossing the branch cut in the kz plane, 
// one takes into account this crossing by removing the branch cut discontinuity of the wave function.
// It has to be a bound state, as one demands |arg(k)| <= Pi/4 for unbound proton states, 
// which implies that no branch cut crossing can happen in this case with the considered contours.
// 
// Variables:
// ----------
// N_aft_R_uniform_minus_one : N_aft_R_uniform - 1
// angle_index : 0, 1, 2, 3 for Pi/4, 3Pi/4, -3Pi/4, -Pi/4.
// exp_Itheta : exp(I.theta), theta the rotation angle.
// two_Pi_eta : 2.Pi.eta
// exp_two_Pi_eta : exp[2.Pi.eta]. It is used in the branch cut formula of the proton wave function.
// exp_two_Pi_eta_minus_one : exp[2.Pi.eta] - 1. It is used in the branch cut formula of the proton wave function and calculated with expm1.
// cwf : class Coulomb_wave_functions to calculate the Coulomb wave functions.
// two_sqrt_Vc, two_I_sqrt_Vc : 2 sqrt[Vc.Z] with Vc = kinetic_factor.Z_charge.Coulomb_constant, i times two_sqrt_Vc.
// cwf_zero_k, l_term : class Coulomb_wave_functions with l_term = 2l + 1/2 and eta = 0.
// norm_k_is_zero : exp[i l0 Pi/2]. When multiplied by u+ and u+' if k = 0.0, u+ and u+' are real on the real axis.
// is_it_crossed_tab_uniform : true if the branch cut has been crossed on the tab_uniform grid, false if not.
// is_it_crossed_tab_GL : true if the branch cut has been crossed on the Gauss Legendre grid, false if not.
// u_aft_R_tab_uniform, z_aft_R_tab_uniform, z_aft_R_tab_GL : table with the u = 1/r for the tab_uniform grid, z = R + (r-R).exp_Itheta for the tab_uniform and Gauss Legendre grid.
// iGL : index of the Gaussian points.
// Il_term : (2l + 1/2).i .
// is_it_real_bound_state_cwf_standard_normalization_case : true if one has a bound state with a real potential and Coulomb wave functions use with their standard normalization, false if not
// Whittaker_const: It is exp ((-eta + i.l).Pi/2 - i.sigma), so that Wm(z) = H+(z).Whittaker_const.

void spherical_state::out_ingoing_waves_after_R (const unsigned int angle_index)
{
  if (N_aft_R_uniform <= 1) error_message_print_abort ("One must have N_aft_R_uniform >= 2 in spherical_state::out_ingoing_waves_after_R");
    
  const int particle_charge = particle_charge_determine (particle);
      
  const int Z_charge_times_particle_charge = Z_charge*particle_charge;
      
  const unsigned int N_aft_R_uniform_minus_one = N_aft_R_uniform - 1;

  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const double l_term = 2.0*l + 0.5;

  const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);

  const complex<double> Il_term(0 , l_term);

  const complex<double> two_Pi_eta = 2.0*M_PI*eta;

  const complex<double> exp_two_Pi_eta = exp (two_Pi_eta);

  const complex<double> exp_two_Pi_eta_minus_one = expm1 (two_Pi_eta);

  const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

  const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

  class array<double> u_aft_R_tab_uniform(N_aft_R_uniform);

  class array<double> u_aft_R_tab_GL(N_aft_R_GL);

  class array<complex<double> > z_aft_R_tab_uniform(N_aft_R_uniform);

  class array<complex<double> > z_aft_R_tab_GL(N_aft_R_GL);

  u_aft_R_tab_uniform(0) = 0.0;

  z_aft_R_tab_uniform(0) = INFINITE*exp_Itheta;

  for (unsigned int i = 1 ; i < N_aft_R_uniform ; i++)
    {
      u_aft_R_tab_uniform(i) = i*step_aft_R_uniform;
      
      z_aft_R_tab_uniform(i) = R + (pow (u_aft_R_tab_uniform(i) , -4) - R)*exp_Itheta;
    }
  
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      u_aft_R_tab_GL(i) = pow (um4_aft_R_tab_GL(i) , -0.25);

      z_aft_R_tab_GL(i) = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;
    }
  
  if (!is_it_PTG_like_determine (potential))
    {
      bool is_it_crossed_tab_uniform = false;

      bool is_it_crossed_tab_GL = false;

      unsigned int iGL = N_aft_R_GL - 1;

      if (S_matrix_pole && (k == 0.0))
	{
	  class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);

	  for (unsigned int i = N_aft_R_uniform_minus_one ; i > 0 ; i--)
	    { 
	      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k ,
				z_aft_R_tab_uniform(i) , scaled_wf_aft_R_tab_uniform(0 , angle_index , i) , scaled_dwf_aft_R_tab_uniform(0 , angle_index , i));

	      while ((iGL < N_aft_R_GL) && (u_aft_R_tab_GL(iGL) <= u_aft_R_tab_uniform(i)) && (u_aft_R_tab_GL(iGL) >= u_aft_R_tab_uniform(i - 1)))
		{
		  wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k ,
				    z_aft_R_tab_GL(iGL) , scaled_wf_aft_R_tab_GL(0 , angle_index , iGL) , scaled_dwf_aft_R_tab_GL(0 , angle_index , iGL));

		  iGL--;
		}	      
	    }

	  scaled_wf_aft_R_tab_uniform (0 , angle_index , 0) = 0.0;
	  scaled_dwf_aft_R_tab_uniform(0 , angle_index , 0) = 0.0;
	} 
      else
	{
	  class Coulomb_wave_functions cwf(is_it_cwf_standard_normalization , l , eta);

	  for (unsigned int i = N_aft_R_uniform_minus_one ; i > 0 ; i--)
	    {
	      cwf.H_kz_dH_kz_scaled (1 , k , z_aft_R_tab_uniform(i) , scaled_wf_aft_R_tab_uniform(0 , angle_index , i) , scaled_dwf_aft_R_tab_uniform(0 , angle_index , i));

	      branch_cut_correction (exp_two_Pi_eta , exp_two_Pi_eta_minus_one , cwf , z_aft_R_tab_uniform , angle_index , i ,
				     is_it_crossed_tab_uniform , scaled_wf_aft_R_tab_uniform , scaled_dwf_aft_R_tab_uniform);
	      
	      if (!S_matrix_pole) cwf.H_kz_dH_kz_scaled (-1 , k , z_aft_R_tab_uniform(i) , scaled_wf_aft_R_tab_uniform(1 , angle_index , i) , scaled_dwf_aft_R_tab_uniform(1 , angle_index , i));
	      
	      while ((iGL < N_aft_R_GL) && (u_aft_R_tab_GL(iGL) <= u_aft_R_tab_uniform(i)) && (u_aft_R_tab_GL(iGL) >= u_aft_R_tab_uniform(i - 1)))
		{
		  cwf.H_kz_dH_kz_scaled (1 , k , z_aft_R_tab_GL(iGL) , scaled_wf_aft_R_tab_GL(0 , angle_index , iGL) , scaled_dwf_aft_R_tab_GL(0 , angle_index , iGL));

		  branch_cut_correction (exp_two_Pi_eta , exp_two_Pi_eta_minus_one , cwf , z_aft_R_tab_GL , angle_index , iGL ,
					 is_it_crossed_tab_GL , scaled_wf_aft_R_tab_GL , scaled_dwf_aft_R_tab_GL);

		  if (!S_matrix_pole) cwf.H_kz_dH_kz_scaled (-1 , k , z_aft_R_tab_GL(iGL) , scaled_wf_aft_R_tab_GL(1 , angle_index , iGL) , scaled_dwf_aft_R_tab_GL(1 , angle_index , iGL));
		  
		  iGL--;
		}
	    }

	  cwf.H_kz_dH_kz_scaled_limit_infinite (1 , k , scaled_wf_aft_R_tab_uniform(0 , angle_index , 0) , scaled_dwf_aft_R_tab_uniform(0 , angle_index , 0));
	  
	  if (is_it_crossed_tab_uniform)
	    {
	      scaled_wf_aft_R_tab_uniform (0 , angle_index , 0) *= exp_two_Pi_eta;
	      scaled_dwf_aft_R_tab_uniform(0 , angle_index , 0) *= exp_two_Pi_eta;
	    }
	  
	  if (!S_matrix_pole) cwf.H_kz_dH_kz_scaled_limit_infinite (-1 , k , scaled_wf_aft_R_tab_uniform(1 , angle_index , 0) , scaled_dwf_aft_R_tab_uniform(1 , angle_index , 0));
	}
    }

  out_ingoing_waves_after_R_Cplus_Cminus_multiplication_infinities_remove (angle_index);
}

void spherical_state::out_ingoing_waves_after_R_Cplus_Cminus_multiplication_infinities_remove (const unsigned int angle_index)
{
  const bool is_it_real_bound_state_cwf_standard_normalization_case = (is_it_cwf_standard_normalization && S_matrix_pole && is_it_real ());

  if (!is_it_PTG_like_determine (potential))
    {
      if (is_it_real_bound_state_cwf_standard_normalization_case && (k != 0.0))
	{
	  const complex<double> Whittaker_const = Whittaker_const_calc (l , eta);

	  const complex<double> Cplus_Whittaker_const = Cplus*Whittaker_const;
	  
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      scaled_wf_aft_R_tab_uniform (0 , angle_index , i) *= Cplus_Whittaker_const;
	      scaled_dwf_aft_R_tab_uniform(0 , angle_index , i) *= Cplus_Whittaker_const;
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      scaled_wf_aft_R_tab_GL (0 , angle_index , i) *= Cplus_Whittaker_const;
	      scaled_dwf_aft_R_tab_GL(0 , angle_index , i) *= Cplus_Whittaker_const;
	    }
	}
      else
	{
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      scaled_wf_aft_R_tab_uniform (0 , angle_index , i) *= Cplus;
	      scaled_dwf_aft_R_tab_uniform(0 , angle_index , i) *= Cplus;
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      scaled_wf_aft_R_tab_GL (0 , angle_index , i) *= Cplus;
	      scaled_dwf_aft_R_tab_GL(0 , angle_index , i) *= Cplus;
	    }
	}

      if (!S_matrix_pole)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      scaled_wf_aft_R_tab_uniform (1 , angle_index , i) *= Cminus;
	      scaled_dwf_aft_R_tab_uniform(1 , angle_index , i) *= Cminus;
	    }

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      scaled_wf_aft_R_tab_GL (1 , angle_index , i) *= Cminus;
	      scaled_dwf_aft_R_tab_GL(1 , angle_index , i) *= Cminus;
	    }
	}
      
      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	{
	  if (!finite (scaled_wf_aft_R_tab_uniform(0 , angle_index , i)))
	    {
	      scaled_wf_aft_R_tab_uniform (0 , angle_index , i) = 0.0;
	      scaled_dwf_aft_R_tab_uniform(0 , angle_index , i) = 0.0;
	    }
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  if (!finite (scaled_wf_aft_R_tab_GL(0 , angle_index , i)))
	    {
	      scaled_wf_aft_R_tab_GL (0 , angle_index , i) = 0.0;
	      scaled_dwf_aft_R_tab_GL(0 , angle_index , i) = 0.0;
	    }
	}
	
      if (!S_matrix_pole)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      if (!finite (scaled_wf_aft_R_tab_uniform(1 , angle_index , i)))
		{
		  scaled_wf_aft_R_tab_uniform (1 , angle_index , i) = 0.0;
		  scaled_dwf_aft_R_tab_uniform(1 , angle_index , i) = 0.0;
		}
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      if (!finite (scaled_wf_aft_R_tab_GL(1 , angle_index , i)))
		{
		  scaled_wf_aft_R_tab_GL (1 , angle_index , i) = 0.0;
		  scaled_dwf_aft_R_tab_GL(1 , angle_index , i) = 0.0;
		}
	    }
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	{
	  scaled_wf_aft_R_tab_uniform(0 , angle_index , i)  = Cplus;
	  scaled_dwf_aft_R_tab_uniform(0 , angle_index , i) = Cplus;
	}
      
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  scaled_wf_aft_R_tab_GL(0 , angle_index , i)  = Cplus;
	  scaled_dwf_aft_R_tab_GL(0 , angle_index , i) = Cplus;
	}
      
      if (!S_matrix_pole)
	{
	  for (unsigned int i = 0 ; i < N_aft_R_uniform ; i++)
	    {
	      scaled_wf_aft_R_tab_uniform (1 , angle_index , i) = Cminus;
	      scaled_dwf_aft_R_tab_uniform(1 , angle_index , i) = Cminus;
	    }
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      scaled_wf_aft_R_tab_GL (1 , angle_index , i) = Cminus;
	      scaled_dwf_aft_R_tab_GL(1 , angle_index , i) = Cminus;
	    }
	}
    }
}





// Calculation of the wave functions after R on the real axis
// ----------------------------------------------------------
// The wave function is calculated with the Coulomb wave functions between R and R_real_max with tab_GL points.
// One uses F and G for scattering states and H+ for bound and resonant states.
//
// Variables:
// ----------
// llp1 : l(l + 1)
// cwf_r, cwf_z : class Coulomb_wave_functions to calculate the Coulomb wave functions. cwf_r is used for real r values and cwf_z for complex r values
// two_sqrt_Vc, two_I_sqrt_Vc : 2 sqrt[Vc.Z] with Vc = kinetic_factor.Z_charge_times_particle_charge.Coulomb_constant, i times two_sqrt_Vc.
// cwf_zero_k : class Coulomb_wave_functions with l0 = 2l + 1/2 and eta0 = 0.
// norm_k_is_zero : exp[i l0 Pi/2]. When multiplied by u+ and u+' if k = 0.0, u+ and u+' are real on the real axis.
// Il_term : (2l + 1/2).i .
// r_aft_R_tab_GL_real, w_aft_R_tab_GL_real : Gaussian abscissas and weights before R : r in ]R:R_real_max[.
// r_aft_R_tab_GL_complex, w_aft_R_tab_GL_complex : Gaussian abscissas and weights before R : r in ]R:R+ (R_real_max - R).exp (i.theta)[.

void spherical_state::wave_after_R_real_axis_tab_GL ()
{
  const double llp1 = l*(l + 1);
  
  const complex<double> k2 = k*k;

  const complex<double> Ik(-imag (k) , real (k));
  
  const class Coulomb_potential_class Coulomb_potential(is_it_relative , particle , Z_charge , NADA);
	
  if (S_matrix_pole)
    { 
      if (k == 0.0)
	{
	  const int particle_charge = particle_charge_determine (particle);
	  
	  const int Z_charge_times_particle_charge = Z_charge*particle_charge;      

	  const double l_term = 2.0*l + 0.5;

	  const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);

	  const complex<double> Il_term(0 , l_term);

	  const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

	  const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

	  class Coulomb_wave_functions cwf_zero_k_r(true , l_term , 0.0);

	  class Coulomb_wave_functions cwf_zero_k_z(true , l_term , 0.0);
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);

	      const complex<double> z = r_aft_R_tab_GL_complex(i);
		  
	      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k_r , r , wf_aft_R_tab_GL_real(i)    , dwf_aft_R_tab_GL_real(i));
	      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k_z , z , wf_aft_R_tab_GL_complex(i) , dwf_aft_R_tab_GL_complex(i));
	    }
	}
      else
	{
	  const bool is_it_real_bound_state_cwf_standard_normalization_case = (is_it_cwf_standard_normalization && is_it_real ());
      
	  class Coulomb_wave_functions cwf_r(is_it_cwf_standard_normalization , l , eta);
	  class Coulomb_wave_functions cwf_z(is_it_cwf_standard_normalization , l , eta);
	  
	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      const double r = r_aft_R_tab_GL_real(i);
	      
	      const complex<double> z = r_aft_R_tab_GL_complex(i);

	      if (is_it_PTG_like_determine (potential))
		{
		  wf_aft_R_tab_GL_real(i) = exp (Ik*r);

		  dwf_aft_R_tab_GL_real(i) = Ik*wf_aft_R_tab_GL_real(i);

		  wf_aft_R_tab_GL_complex(i) = exp (Ik*z);

		  dwf_aft_R_tab_GL_complex(i) = Ik*wf_aft_R_tab_GL_complex(i);
		}
	      else
		{
		  if (is_it_real_bound_state_cwf_standard_normalization_case)
		    {
		      cwf_r.Wm_kz_dWm_kz (k , r , wf_aft_R_tab_GL_real(i)    , dwf_aft_R_tab_GL_real(i));
		      cwf_z.Wm_kz_dWm_kz (k , z , wf_aft_R_tab_GL_complex(i) , dwf_aft_R_tab_GL_complex(i));
		    }
		  else
		    {
		      cwf_r.H_kz_dH_kz (1 , k , r , wf_aft_R_tab_GL_real(i)    , dwf_aft_R_tab_GL_real(i));
		      cwf_z.H_kz_dH_kz (1 , k , z , wf_aft_R_tab_GL_complex(i) , dwf_aft_R_tab_GL_complex(i));
		    }
		}
	    }
	}
      
      wf_aft_R_tab_GL_real  *= Cplus;
      dwf_aft_R_tab_GL_real *= Cplus;
      
      wf_aft_R_tab_GL_complex  *= Cplus;
      dwf_aft_R_tab_GL_complex *= Cplus;
    }
  else
    {
      class Coulomb_wave_functions cwf_r(true , l , eta);
      class Coulomb_wave_functions cwf_z(true , l , eta);
  
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL_real(i);
	  
	  const complex<double> z = r_aft_R_tab_GL_complex(i);
	  
	  complex<double> Fr  = 0.0;
	  complex<double> dFr = 0.0;

	  complex<double> Gr  = 0.0;
	  complex<double> dGr = 0.0;

	  complex<double> Fz  = 0.0;
	  complex<double> dFz = 0.0;

	  complex<double> Gz  = 0.0;
	  complex<double> dGz = 0.0;
	  
	  if (is_it_PTG_like_determine (potential))
	    {
	      Fr = sin (k*r) , dGr = -k*Fr;
	      Gr = cos (k*r) , dFr =  k*Gr;

	      Fz = sin (k*z) , dGz = -k*Fz;
	      Gz = cos (k*z) , dFz =  k*Gz;
	    }
	  else
	    {
	      cwf_r.F_kz_dF_kz (k , r , Fr , dFr);
	      cwf_r.G_kz_dG_kz (k , r , Gr , dGr);
	      
	      cwf_z.F_kz_dF_kz (k , z , Fz , dFz);
	      cwf_z.G_kz_dG_kz (k , z , Gz , dGz);
	    }
	  
	  wf_aft_R_tab_GL_real (i) = CF*Fr  + CG*Gr;
	  dwf_aft_R_tab_GL_real(i) = CF*dFr + CG*dGr;

	  wf_aft_R_tab_GL_complex (i) = CF*Fz  + CG*Gz;
	  dwf_aft_R_tab_GL_complex(i) = CF*dFz + CG*dGz;
	}
    }
  
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double r = r_aft_R_tab_GL_real(i);

      const double r2 = r*r;

      const complex<double> z = r_aft_R_tab_GL_complex(i);

      const complex<double> z2 = z*z;
      
      d2wf_aft_R_tab_GL_real(i)    = (!is_it_PTG_like_determine (potential)) ? ((llp1/r2 + kinetic_factor*(Coulomb_potential.point_potential_calc (r) - E))*wf_aft_R_tab_GL_real   (i)) : (-k2*wf_aft_R_tab_GL_real   (i));
      d2wf_aft_R_tab_GL_complex(i) = (!is_it_PTG_like_determine (potential)) ? ((llp1/z2 + kinetic_factor*(Coulomb_potential.point_potential_calc (z) - E))*wf_aft_R_tab_GL_complex(i)) : (-k2*wf_aft_R_tab_GL_complex(i));
    }
}






//--// spherical_state_direct_integration


// The Coulomb wave function is normalized properly for scattering states
// and is normalized so that there is no underflow or overflow for pole states.


// Calculation of the part of the wave function for E complex between 0 and matching_point.
//-----------------------------------------------------------------------------------------
// One integrates the Schrodinger equation from r0 to matching_point.
// One approximates V(r) by V(r0) for r <= r0 so u(r) =  C0.r^{l + 1} if r < r0.
// One has to integrate forward from r ~ 0 , because the modulus of the wave function is increasing in a forward direction for r ~ 0.
// The wave function and derivative at the Gaussian points are also calculated by direct integration. 
//
// Variables:
// ----------
// lp1 , llp1 : l + 1 , l(l + 1)
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// r0 : r0 = 0.005.sqrt (l*(l + 1.0))
// u0 , du0 : C0.r0^{l + 1} and C0.(l + 1).r0^{l}. 
// r_previous : the radius just before r in the grid , so one integrates from r_previous to r to gain speed and stability.
// r_GL : r of Gauss-Legendre table
// iGL : index of the Gaussian points.
// r_bef_mp : point just before the matching point on the tab_uniform grid.

void spherical_state::forward_integration_before_R (const class ODE_integration &ODE)
{
  const int lp1 = l + 1;
  
  const double llp1 = l*lp1;

  const double r0 = 0.005*sqrt (llp1);

  const double r_bef_mp = N_matching_point*step_bef_R_uniform;

  complex<double> u0 = C0*pow (r0 , lp1);

  complex<double> du0 = C0*lp1*pow (r0 , l);

  wf_bef_R_tab_uniform(0) = 0.0;

  dwf_bef_R_tab_uniform(0) = (l == 0) ? (C0) : (0.0);

  unsigned int iGL_e = 0;

  unsigned int iGL = 0;

  unsigned int iGL_SGI_MSGI = 0;

  if (particle == ELECTRON)
    {	
      while ((iGL_e < N_bef_s_GL) && (r_bef_s_tab_GL(iGL_e) <= r0))
	{
	  const double r_GL = r_bef_s_tab_GL(iGL_e);
	  {
	    wf_bef_s_tab_GL(iGL_e) = C0*pow (r_GL , lp1);

	    dwf_bef_s_tab_GL(iGL_e) = lp1*wf_bef_s_tab_GL(iGL_e)/r_GL;

	    iGL_e++;
	  }
	}
    }

  while ((iGL < N_bef_R_GL) && (r_bef_R_tab_GL(iGL) <= r0))
    {
      const double r_GL = r_bef_R_tab_GL(iGL);
      
      wf_bef_R_tab_GL(iGL) = C0*pow (r_GL , lp1);

      dwf_bef_R_tab_GL(iGL) = lp1*wf_bef_R_tab_GL(iGL)/r_GL;

      iGL++; 
    }

  if (!is_there_effective_mass_determine (potential))
    {
      while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r0))
	{
	  const double r_SGI_MSGI = r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI);
	  
	  wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) = C0*pow (r_SGI_MSGI , lp1);

	  dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) = lp1*wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI)/r_SGI_MSGI;

	  iGL_SGI_MSGI++;
	}
    }

  for (unsigned int i = 1 ; i <= N_matching_point ; i++)
    {
      const unsigned int im1 = i - 1;
      
      const double r_previous = r_bef_R_tab_uniform(im1);

      const double r = r_bef_R_tab_uniform(i);

      if (r <= r0)
	{
	  wf_bef_R_tab_uniform(i) = C0*pow (r , lp1);

	  dwf_bef_R_tab_uniform(i) = lp1*wf_bef_R_tab_uniform(i)/r;
	}
      else
	{
	  if (r_previous < r0)
	    {
	      if ((particle == ELECTRON) && (s_radial > r0) && (s_radial < r))
		{
		  complex<double> wf_s = 0.0;

		  complex<double> dwf_s = 0.0;

		  ODE (r0 , u0 , du0 , s_radial , wf_s , dwf_s);

		  ODE (s_radial , wf_s , dwf_s , r , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i));
		}
	      else
		ODE (r0 , u0 , du0 , r , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i));
	    }
	  else
	    {
	      if ((particle == ELECTRON) && (s_radial > r_previous) && (s_radial < r))
		{
		  complex<double> wf_s = 0.0;

		  complex<double> dwf_s = 0.0;
		  
		  ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , s_radial , wf_s , dwf_s);

		  ODE (s_radial , wf_s , dwf_s , r , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i));
		}
	      else
		ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , r , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i));
	    }

	  if (!is_there_effective_mass_determine (potential) && (r >= R0) && (r_previous < R0))
	    ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , R0 , wf_R0 , dwf_R0);

	  if (particle == ELECTRON)
	    {	
	      while ((iGL_e < N_bef_s_GL) && (r_bef_s_tab_GL(iGL_e) >= r_previous) && (r_bef_s_tab_GL(iGL_e) <= r))
		{
		  const double r_GL = r_bef_s_tab_GL(iGL_e);

		  (r_previous < r0)
		    ? (ODE (r0 , u0 , du0 , r_GL , wf_bef_s_tab_GL(iGL_e) , dwf_bef_s_tab_GL(iGL_e)))	
		    : (ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , r_GL , wf_bef_s_tab_GL(iGL_e) , dwf_bef_s_tab_GL(iGL_e)));
		  
		  iGL_e++;
		} 
	    }

	  while ((iGL < N_bef_R_GL) && (r_bef_R_tab_GL(iGL) >= r_previous) && (r_bef_R_tab_GL(iGL) <= r))
	    {
	      const double r_GL = r_bef_R_tab_GL(iGL);

	      (r_previous < r0)
		? (ODE (r0 , u0 , du0 , r_GL , wf_bef_R_tab_GL(iGL) , dwf_bef_R_tab_GL(iGL)))	
		: (ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , r_GL , wf_bef_R_tab_GL(iGL) , dwf_bef_R_tab_GL(iGL)));	

	      iGL++;
	    } 

	  if (!is_there_effective_mass_determine (potential))
	    {
	      while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) >= r_previous) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r))
		{
		  const double r_SGI_MSGI = r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI);

		  (r_previous < r0)
		    ? (ODE (r0 , u0 , du0 , r_SGI_MSGI , wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI)))	
		    : (ODE (r_previous , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1) , r_SGI_MSGI , wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI)));

		  iGL_SGI_MSGI++;
		}
	    }
	}
    }

  if (!is_there_effective_mass_determine (potential) && (matching_point <= R0))
    ODE (r_bef_mp , wf_bef_R_tab_uniform(N_matching_point) , dwf_bef_R_tab_uniform(N_matching_point) , R0 , wf_R0 , dwf_R0);

  if (particle == ELECTRON)
    {	
      while ((iGL_e < N_bef_s_GL) && (r_bef_s_tab_GL(iGL_e) <= matching_point))
	{
	  ODE (r_bef_mp , wf_bef_R_tab_uniform(N_matching_point) , dwf_bef_R_tab_uniform(N_matching_point) , r_bef_s_tab_GL(iGL_e) , wf_bef_s_tab_GL(iGL_e) , dwf_bef_s_tab_GL(iGL_e));

	  iGL_e++;
	}
    }
  
  while ((iGL < N_bef_R_GL) && (r_bef_R_tab_GL(iGL) <= matching_point))
    {
      ODE (r_bef_mp , wf_bef_R_tab_uniform(N_matching_point) , dwf_bef_R_tab_uniform(N_matching_point) , r_bef_R_tab_GL(iGL) , wf_bef_R_tab_GL(iGL) , dwf_bef_R_tab_GL(iGL));

      iGL++;
    }
  
  if (!is_there_effective_mass_determine (potential))
    {
      while ((iGL_SGI_MSGI < N_bef_R_GL) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= matching_point))
	{
	  ODE (r_bef_mp , wf_bef_R_tab_uniform(N_matching_point) , dwf_bef_R_tab_uniform(N_matching_point) ,
	       r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) ,
	       dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI));

	  iGL_SGI_MSGI++;
	}
    }
}




// Calculation of the part of the wave function for E complex between matching_point and R.
//-----------------------------------------------------------------------------------------
// One integrates the Schrodinger equation from R to matching_point for poles , as matching_point < R.
// Integrating this way , the integration is stable.
// Indeed , for bound or narrow resonant states , the wave function is exponentially increasing in this direction.
// For broad resonant states , it does not matter.
// The wave function and derivative at the Gaussian points are also calculated by direct integration.
//
// Variables:
// ---------- 
// N_bef_R_uniform_minus_one : N_bef_R_uniform-1
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// r_next : point next to r in the grid from 0 to R.
// iGL : index of the Gaussian points.
// r_mp : matching_point if is_it_irregular is false , 0 if it is true.
// r_aft_mp : point just after the matching point on the tab_uniform grid if is_it_irregular is false , just one point after 0 if not.
// Nmp_plus_one : index of r_aft_mp.
// wf_plus , dwf_plus : wave function ans its derivative in R equal to C+.H+(k.R) and C+.k.H+'(k.R)

void spherical_state::backward_integration_before_R (const class ODE_integration &ODE)
{
  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;

  if (k == 0.0)
    {
      const int particle_charge = particle_charge_determine (particle);
      
      const int Z_charge_times_particle_charge = Z_charge*particle_charge;
      
      const double l_term = 2.0*l + 0.5;

      const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);

      const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

      const complex<double> Il_term(0 , l_term);

      const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

      class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);
      
      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k , R , wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) , dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one));
    }
  else if (is_it_PTG_like_determine (potential))
    {
      const complex<double> Ik(-imag (k) , real (k));
      
      wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) = exp (Ik*R);
      
      dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) = Ik*wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one);
    }
  else
    {
      const bool is_it_real_bound_state_case = (S_matrix_pole && is_it_real ());

      class Coulomb_wave_functions cwf(true , l , eta);

      complex<double>  wf_plus = 0.0;
      complex<double> dwf_plus = 0.0;
  
      if (is_it_real_bound_state_case)
	cwf.Wm_kz_dWm_kz (k , R , wf_plus , dwf_plus);
      else
	cwf.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);
      
      if (!finite (wf_plus) || !finite (dwf_plus) || (wf_plus == 0.0) || (dwf_plus == 0.0))
	{
	  is_it_cwf_standard_normalization = false;
	  
	  class Coulomb_wave_functions cwf_renormalization(false , l , eta);

	  cwf_renormalization.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);	  
	}

      wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) = wf_plus;
      
      dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) = dwf_plus;
    }

  wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one)  *= Cplus;
  dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one) *= Cplus;

  const unsigned int Nmp_plus_one = N_matching_point + 1;

  const double r_aft_mp = Nmp_plus_one*step_bef_R_uniform;

  unsigned int iGL = N_bef_R_GL - 1;

  unsigned int iGL_SGI_MSGI = iGL;

  for (unsigned int i = N_bef_R_uniform_minus_one ; i > Nmp_plus_one ; i--)
    {
      const unsigned int im1 = i - 1;
      
      const double r_next = r_bef_R_tab_uniform(i);

      const double r = r_bef_R_tab_uniform(im1);

      ODE (r_next , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i) , r , wf_bef_R_tab_uniform(im1) , dwf_bef_R_tab_uniform(im1));

      while ((iGL > 0) && (r_bef_R_tab_GL(iGL) <= r_next) && (r_bef_R_tab_GL(iGL) >= r))
	{
	  ODE (r_next , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i) , r_bef_R_tab_GL(iGL) , wf_bef_R_tab_GL(iGL) , dwf_bef_R_tab_GL(iGL));

	  iGL--;
	}
      
      if (!is_there_effective_mass_determine (potential))
	{
	  while ((iGL_SGI_MSGI > 0) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) <= r_next) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) >= r))
	    {
	      ODE (r_next , wf_bef_R_tab_uniform(i) , dwf_bef_R_tab_uniform(i) ,
		   r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI));

	      iGL_SGI_MSGI--;
	    }
	}
    }

  while ((iGL > 0) && (r_bef_R_tab_GL(iGL) > matching_point))
    {
      ODE (r_aft_mp , wf_bef_R_tab_uniform(Nmp_plus_one) , dwf_bef_R_tab_uniform(Nmp_plus_one) , r_bef_R_tab_GL(iGL) , wf_bef_R_tab_GL(iGL) , dwf_bef_R_tab_GL(iGL));

      iGL--;
    }
  
  if (r_bef_R_tab_GL(0) > matching_point) ODE (r_aft_mp , wf_bef_R_tab_uniform(Nmp_plus_one) , dwf_bef_R_tab_uniform(Nmp_plus_one) , r_bef_R_tab_GL(0) , wf_bef_R_tab_GL(0) , dwf_bef_R_tab_GL(0));

  if (!is_there_effective_mass_determine (potential))
    {
      while ((iGL_SGI_MSGI > 0) && (r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) > matching_point))
	{
	  ODE (r_aft_mp , wf_bef_R_tab_uniform(Nmp_plus_one) , dwf_bef_R_tab_uniform(Nmp_plus_one) ,
	       r_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , wf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI) , dwf_bef_R_tab_GL_SGI_MSGI(iGL_SGI_MSGI));

	  iGL_SGI_MSGI--;
	}
      
      if (r_bef_R_tab_GL_SGI_MSGI(0) > matching_point)
	ODE (r_aft_mp , wf_bef_R_tab_uniform(Nmp_plus_one) , dwf_bef_R_tab_uniform(Nmp_plus_one) , r_bef_R_tab_GL_SGI_MSGI(0) , wf_bef_R_tab_GL_SGI_MSGI(0) , dwf_bef_R_tab_GL_SGI_MSGI(0));
    }
}


















// Calculation of C+, C-, CF, CG and u(R), u'(R). 
// -------------------------------------------
// u[z] = C+.H+[kz] + C-.H-[kz] = CF.F[kz] + CG.G[kz], with z = R + (r-R).exp_Itheta in [R:+oo[.
//
//
// Pole state:
//------------
// 
// Numerical integration
// ---------------------
// ODE has defined parameters, i.e. one integrated numerically the wave function.
// One integrates the wave function with the normalization u(R) = C+[bef].H+[k.R] from R to matching_point, where one obtains u+[matching_point].
// Then, to calculate C+, one uses u-[matching_point] integrated from wf_bef_R_tab_uniform[N_matching_point], 
// at the point just before the matching point on the tab_uniform grid, and u+[matching_point].
// As one knows that u[z] = C+.H+[kz] after R (except for k = 0 : see wf_dwf_k_is_zero), it is clear that C+ = C+[bef].u-[matching_point]/u+[matching_point] and C- = 0.
//
// Analytical wave function
// ------------------------
// ODE has undefined parameters, i.e. one calculated analytically the wave function from closed formulas from r=0 to r=R.
// For the moment, this is used only with the modified PTG potential.
// As one knows that u[z] = C+.H+[kz] after R (except for k = 0 : see wf_dwf_k_is_zero), it is clear that C+ = u[R]/H+[kR] and C- = 0.
//
// Then, CF = i.C+ and CG = C+. But, as C-, they are useless in this case.
//
//
//
//
// Scattering state :
//-------------------
// To calculate the constants, one uses : 
// _u[R] = wf_bef_R_tab_uniform[N];
// _u'[R] = dwf_bef_R_tab_uniform[N]. 
// As one knows that u[z] = CF.F[kz] + CG.G[kz], knowing u, F, G and their derivatives in R, 
// one has to solve a linear system to have CF and CG.
// Then, C+ = [CG - iCF]/2 and C- = [CG + i.CF]/2, using the fact that H+, H-, G are normalized properly (see H+_H-.c++).
//
// Variables:
// ----------
// N_bef_R_uniform_minus_one : N_bef_R_uniform-1
// ODE : class ODE_integration with which one integrates the wave function from one point to another.
// two_I_sqrt_Vc : 2i sqrt[vc.Z] with vc = kinetic_factor.Z_charge_times_particle_charge.Coulomb_constant.
// norm_k_is_zero : exp[i l0 Pi/2]. When multiplied by u+ and u+' if k = 0, u+ and u+' are real on the real axis.
// cwf : class Coulomb_wave_functions to calculate the Coulomb wave functions in R.
// cwf_zero_k : class Coulomb_wave_functions with l_term = 2l + 1/2 and eta = 0, which is used when k = 0 (see wf_dwf_k_is_zero).
// F, dF, G, dG : Coulomb wave functions (and derivative) regular and irregular in kR.
// Hp, dHp: outgoing Coulomb wave functions (and derivative) in kR.
// Det : determinant of the linear system to solve to know CF and CG.
// u_mp_minus, du_mp_minus, u_mp_plus, du_mp_plus : 
// wave functions and derivatives in matching_point after forward and backward intergration.
// r_bef_mp : point just before the matching point on the tab_uniform grid.
// u_R, du_R : wave function and derivative at r = R for scattering states.
// I_CF : I.CF

void spherical_state::Cplus_Cminus_CF_CG_calc (const class ODE_integration &ODE)
{
  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;

  if (S_matrix_pole)
    {
      if (ODE.is_it_filled ())
	{
	  const unsigned int N_mp = N_matching_point;

	  const unsigned int N_mp_plus_one = N_mp + 1;

	  const double r_bef_mp = N_mp*step_bef_R_uniform;

	  const double r_aft_mp = N_mp_plus_one*step_bef_R_uniform;
      
	  complex<double> u_mp_minus  = 0.0;
	  complex<double> du_mp_minus = 0.0;

	  complex<double> u_mp_plus  = 0.0;
	  complex<double> du_mp_plus = 0.0;
      
	  ODE (r_bef_mp , wf_bef_R_tab_uniform(N_mp) , dwf_bef_R_tab_uniform(N_mp) , matching_point , u_mp_minus , du_mp_minus);

	  ODE (r_aft_mp , wf_bef_R_tab_uniform(N_mp_plus_one) , dwf_bef_R_tab_uniform(N_mp_plus_one) , matching_point , u_mp_plus , du_mp_plus);
	  	  
	  Cplus *= u_mp_minus/u_mp_plus;
	}
      else
	{
	  const unsigned int N_bef_R_uniform_minus_one = N_bef_R_uniform - 1;

	  complex<double>  wf_plus = 0.0;
	  complex<double> dwf_plus = 0.0;
      
	  if (k == 0)
	    {
	      const int particle_charge = particle_charge_determine (particle);
	      
	      const int Z_charge_times_particle_charge = Z_charge*particle_charge;

	      const double l_term = 2.0*l + 0.5;
	      
	      const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge_times_particle_charge*Coulomb_constant);
	      
	      const complex<double> Il_term(0 , l_term);
	      
	      const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);
	      
	      const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);
	  
	      class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);
	  
	      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k , R , wf_plus , dwf_plus);	      
	    }
	  else
	    {
	      class Coulomb_wave_functions cwf(true , l , eta);
	      
	      if (is_it_real ())
		cwf.Wm_kz_dWm_kz (k , R , wf_plus , dwf_plus);
	      else
		cwf.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);
	      
	      if (!finite (wf_plus) || !finite (dwf_plus) || (wf_plus == 0.0) || (dwf_plus == 0.0))
		{
		  is_it_cwf_standard_normalization = false;
		  
		  class Coulomb_wave_functions cwf_renormalization(false , l , eta);
		  
		  cwf_renormalization.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);	  
		}
	    }

	  Cplus = wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one)/wf_plus;
      	}
      	      
      Cminus = 0.0;

      CG = Cplus;

      CF = complex<double> (-imag (Cplus) , real (Cplus));
    } 
  else
    {
      complex<double> F = 0.0 , dF = 0.0;
      complex<double> G = 0.0 , dG = 0.0;

      if (is_it_PTG_like_determine (potential))
	{
	  F = sin (k*R) , dG = -k*F;
	  G = cos (k*R) , dF =  k*G;
	}
      else
	{
	  class Coulomb_wave_functions cwf(true , l , eta);
	  
	  cwf.F_kz_dF_kz (k , R , F , dF);
	  cwf.G_kz_dG_kz (k , R , G , dG);
	}

      const complex<double>  u_R =  wf_bef_R_tab_uniform(N_bef_R_uniform_minus_one);
      const complex<double> du_R = dwf_bef_R_tab_uniform(N_bef_R_uniform_minus_one);
      
      const complex<double> Det = dF*G - F*dG;

      CF =  (du_R*G - u_R*dG)/Det;
      CG = -(du_R*F - u_R*dF)/Det;

      const complex<double> I_CF(-imag (CF) , real (CF));

      Cplus  = 0.5*(CG - I_CF);
      Cminus = 0.5*(CG + I_CF);
    }
}







//--// spherical_state_HO_THO


// Diagonalization in a HO basis. 
// -----------------------------
// It always gives a very good first guess for the Newton search if the sought state is well bound or well unbound with a very small width.
// The HO states are calculated and stored in HO_wfs and in HO_dfws.
// One uses Vnucl(r) ~ 0 for r > R, as the potential may be given by splines, unavailable for r > R.
// To find the starting energy, one looks for the eigenvector which has the largest overlap with |u[HO](n, l)>.
// If the probability to be in |u[HO](n, l)> is more than 50%, one surely has a bound state or a narrow unbound state.
// Then the starting energy is the one of the eigenvector which has the largest overlap with |u[HO](n, l)>.
// If not, then one has a broad resonant state, and then one sends eigenvalues(n), as the starting energy of a broad resonant state
// does not have to be very close to it, but must be far away from the other bound states if they exist.
// One also returns the approximate number of bound states of the potential, 
// given by the number of eigenvectors having an overlap of more than 50% with a harmonic oscillator state.
// It is used in the PTG fit if the HO guess is bad, to initialize the parameter nu, 
// as it is related to the number of bound and narrow resonant states of the PTG potential.
//
// Variables:
// ----------
// llp1 : l(l + 1)
// nmax_HO : HO maximal n.
// R_HO_end : point where one stops the integration of radial matrix elements.
//            One assumes int_{0}^{R_HO_end} uf(r).O(r).ui(r) dr ~ \int_{0}^{+oo} uf(r).O(r).ui(r) dr .
// r_bef_R_HO_tab_GL, w_bef_R_HO_tab_GL : Gauss-Legendre radii and weights between 0 and R_HO_end
// HO_matrix : matrix of the potential to integrate on the HO basis.
// HO_wfs, HO_dwfs, HO_wfs_n, HO_dwfs_n : class array<double> containing the HO wave functions and derivatives for all n and r and for one r and all n.
// V_function_tab : table containing the table function of different potentials to integrate from 0 to R.
// full_effective_mass : interpolated effective mass in MeV^(-1) fm^{-2}.
// V_effective_mass_unscaled : Skyrme potential without the r-dependent rotation.
// full_effective_mass_r, full_effective_mass_der_r : effective mass in MeV^(-1) fm^{-2} and derivative for a given r.
// full_effective_mass_inv_tab : table containing 1.0/full_effective_mass(r) from 0 to R.
// OBME : matrix element of HO_matrix.
// eigenvalues : table which will contain the eigenvalues of matrix of the the potential to integrate on the HO basis. eigenvalues(n) is returned.
// E_HO : HO guess of the energy of the state
// N_bound : number of bound and narrow resonant states of the potential.

void spherical_state::HO_matrix_calc (const class potentials_effective_mass &T , const double b_HO , class matrix<double> &HO_matrix) const
{
  const class Coulomb_potential_class Coulomb_potential(is_it_relative , particle , Z_charge , NADA);
  
  const int nmax_HO_plus_one = HO_matrix.get_dimension ();
  
  const int nmax_HO = nmax_HO_plus_one - 1;
  
  const double R_HO_end = 50;

  const double llp1 = l*(l + 1);

  class array<double> r_bef_R_HO_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_HO_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_HO_end , r_bef_R_HO_tab_GL , w_bef_R_HO_tab_GL);

  class array<double> HO_wfs (nmax_HO_plus_one , N_bef_R_GL);
  class array<double> HO_dwfs(nmax_HO_plus_one , N_bef_R_GL);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_HO , l , r_bef_R_HO_tab_GL , HO_wfs , HO_dwfs);

  class array<double> V_function_tab(N_bef_R_GL);

  class array<double> full_effective_mass_inv_tab(N_bef_R_GL);
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_HO_tab_GL(i);

      if (is_there_effective_mass_determine (potential))
	{
	  const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();
	  
	  const class splines_class<double> &V_effective_mass_unscaled = T.get_V_effective_mass_unscaled ();
	  
	  const double full_effective_mass_r = (r <= R) ? (full_effective_mass(r)) : (kinetic_factor);
	  
	  const double full_effective_mass_der_r = (r <= R) ? (full_effective_mass.derivative (r)) : (0.0);

	  full_effective_mass_inv_tab(i) = 1.0/full_effective_mass_r;

	  V_function_tab(i) = (r <= R) ? (V_effective_mass_unscaled(r)) : (Coulomb_potential.point_potential_calc (r));

	  V_function_tab(i) += full_effective_mass_inv_tab(i)*llp1/(r*r) - full_effective_mass_der_r/(r*full_effective_mass_r*full_effective_mass_r);
	}
      else
	V_function_tab(i) = (r <= R) ? (real (T.potential_calc (r)) + llp1/(r*r*kinetic_factor)) : (Coulomb_potential.point_potential_calc (r) + llp1/(r*r*kinetic_factor));
    } 
  
  for (int n_in = 0 ; n_in <= nmax_HO ; n_in++)
    for (int n_out = 0 ; n_out <= n_in ; n_out++)
      {
	double OBME = 0.0;

	if (is_there_effective_mass_determine (potential))
	  {
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      OBME += (HO_wfs(n_in , i)*HO_wfs(n_out , i)*V_function_tab(i) + HO_dwfs(n_in , i)*HO_dwfs(n_out , i)*full_effective_mass_inv_tab(i))*w_bef_R_HO_tab_GL(i);
	  }
	else
	  {
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      OBME += (HO_wfs(n_in , i)*HO_wfs(n_out , i)*V_function_tab(i) + HO_dwfs(n_in , i)*HO_dwfs(n_out , i)/kinetic_factor)*w_bef_R_HO_tab_GL(i);
	  }

	HO_matrix(n_in , n_out) = HO_matrix(n_out , n_in) = OBME;
      }
}




// Calculation of the wave function only through HO diagonalization
// ----------------------------------------------------------------

void spherical_state::wave_calculation_HO_diag (
						const class potentials_effective_mass &T ,
						const double b_HO)
{ 
  if (particle == ELECTRON) error_message_print_abort ("HO diagonalization not available for electron.");

  if (!S_matrix_pole) error_message_print_abort ("HO diagonalization for pole states only.");

  if (R_real_max < R) error_message_print_abort ("R_real_max must be larger than R.");

  const int nmax_HO = 20;
  
  const int nmax_HO_plus_one = nmax_HO + 1;

  const double bk_HO = 1.0/b_HO;
  
  const unsigned int N_tab_GL = N_bef_R_GL + N_aft_R_GL;

  class array<double> eigenvalues(nmax_HO_plus_one);

  class matrix<double> HO_matrix(nmax_HO_plus_one);

  HO_matrix_calc (T , b_HO , HO_matrix);
  
  total_diagonalization::all_eigenpairs (HO_matrix , eigenvalues);

  int nn_try = 0; 

  for (int nn = 0 ; nn <= nmax_HO ; nn++)
    {
      if (abs (HO_matrix.eigenvector(nn)(n)) > abs (HO_matrix.eigenvector(nn_try)(n))) nn_try = nn;
    }

  const int n_from_diagonalization = (HO_matrix.eigenvector(nn_try)(n)*HO_matrix.eigenvector(nn_try)(n) > 0.5) ? (nn_try) : (n);

  E = eigenvalues(n_from_diagonalization);
  
  k = sqrt (kinetic_factor*E);

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  is_k_OK = true; 

  zero ();

  class vector_class<double> &eigenvector = HO_matrix.eigenvector(n_from_diagonalization);

  for (int nn = 0 ; nn <= nmax_HO ; nn++)
    {
      const double C0_HO_nn = HO_wave_functions::HO_3D::C0_calc (b_HO , nn , l);

      C0 += eigenvector(nn)*C0_HO_nn;
    }

  if (real (C0) < 0.0)
    {
      eigenvector = -eigenvector;

      C0 = -C0;
    }
  
  class array<double> r_tab_GL(N_tab_GL);
  
  for (unsigned int i = 0 ; i < N_tab_GL ; i++)
    r_tab_GL(i) = (i >= N_bef_R_GL) ? (r_aft_R_tab_GL_real(i - N_bef_R_GL)) : (r_bef_R_tab_GL(i));
  
  class array<double> HO_wfs_tab_GL  (nmax_HO_plus_one , N_tab_GL);
  class array<double> HO_dwfs_tab_GL (nmax_HO_plus_one , N_tab_GL);
  class array<double> HO_d2wfs_tab_GL(nmax_HO_plus_one , N_tab_GL);
  
  class array<double> HO_wfs_bef_R_tab_uniform  (nmax_HO_plus_one , N_bef_R_uniform);
  class array<double> HO_dwfs_bef_R_tab_uniform (nmax_HO_plus_one , N_bef_R_uniform);
  class array<double> HO_d2wfs_bef_R_tab_uniform(nmax_HO_plus_one , N_bef_R_uniform);
  
  class array<double> HO_wfs_bef_R_tab_GL_SGI_MSGI (nmax_HO_plus_one , N_bef_R_GL);
  class array<double> HO_dwfs_bef_R_tab_GL_SGI_MSGI(nmax_HO_plus_one , N_bef_R_GL);
  
  class array<double> HO_wfs_momentum_tab_GL (nmax_HO_plus_one , Nk_momentum_GL);
  class array<double> HO_dwfs_momentum_tab_GL(nmax_HO_plus_one , Nk_momentum_GL);
  
  class array<double> HO_wfs_momentum_tab_uniform (nmax_HO_plus_one , Nk_momentum_uniform);
  class array<double> HO_dwfs_momentum_tab_uniform(nmax_HO_plus_one , Nk_momentum_uniform);

  HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b_HO , l , r_bef_R_tab_uniform , HO_wfs_bef_R_tab_uniform , HO_dwfs_bef_R_tab_uniform , HO_d2wfs_bef_R_tab_uniform);
  HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b_HO , l , r_tab_GL            , HO_wfs_tab_GL            , HO_dwfs_tab_GL            , HO_d2wfs_tab_GL);
  
  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , l , k_tab_uniform , HO_wfs_momentum_tab_uniform , HO_dwfs_momentum_tab_uniform);
  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , l , k_tab_GL      , HO_wfs_momentum_tab_GL      , HO_dwfs_momentum_tab_GL);

  if (!is_there_effective_mass_determine (potential))
    HO_wave_functions::HO_3D::u_du_r_tables_calc (b_HO , l , r_bef_R_tab_GL_SGI_MSGI , HO_wfs_bef_R_tab_GL_SGI_MSGI , HO_dwfs_bef_R_tab_GL_SGI_MSGI);

  for (int nn = 0 ; nn <= nmax_HO ; nn++)
    {
      const double Vnn = eigenvector(nn);

      wf_R0  += Vnn*HO_wave_functions::HO_3D::u  (b_HO , nn , l , R0);
      dwf_R0 += Vnn*HO_wave_functions::HO_3D::du (b_HO , nn , l , R0);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform(i)   += Vnn*HO_wfs_bef_R_tab_uniform  (nn , i);
	  dwf_bef_R_tab_uniform(i)  += Vnn*HO_dwfs_bef_R_tab_uniform (nn , i);
	  d2wf_bef_R_tab_uniform(i) += Vnn*HO_d2wfs_bef_R_tab_uniform(nn , i);
	}
      
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL(i)   += Vnn*HO_wfs_tab_GL  (nn , i);
	  dwf_bef_R_tab_GL(i)  += Vnn*HO_dwfs_tab_GL (nn , i);
	  d2wf_bef_R_tab_GL(i) += Vnn*HO_d2wfs_tab_GL(nn , i);
	}

      if (kmax_momentum > 0.0)
	{
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      wf_momentum_tab_uniform(i)   += Vnn*HO_wfs_momentum_tab_uniform (nn , i);
	      dwf_momentum_tab_uniform(i)  += Vnn*HO_dwfs_momentum_tab_uniform(nn , i);
	    }
	  
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      wf_momentum_tab_GL(i)   += Vnn*HO_wfs_momentum_tab_GL (nn , i);
	      dwf_momentum_tab_GL(i)  += Vnn*HO_dwfs_momentum_tab_GL(nn , i);
	    }
	}
    }

  if (!is_there_effective_mass_determine (potential))
    {
      for (int nn = 0 ; nn <= nmax_HO ; nn++)
	{	
	  const double Vnn = eigenvector(nn);

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      wf_bef_R_tab_GL_SGI_MSGI(i)  += Vnn*HO_wfs_bef_R_tab_GL_SGI_MSGI (nn , i);
	      dwf_bef_R_tab_GL_SGI_MSGI(i) += Vnn*HO_dwfs_bef_R_tab_GL_SGI_MSGI(nn , i);
	    }
	}
    }

  if (R_real_max > 0.0)
    {
      for (int nn = 0 ; nn <= nmax_HO ; nn++)
	{	
	  const double Vnn = eigenvector(nn);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      const unsigned int ii = i + N_bef_R_GL;

	      wf_aft_R_tab_GL_real(i)   += Vnn*HO_wfs_tab_GL  (nn , ii);
	      dwf_aft_R_tab_GL_real(i)  += Vnn*HO_dwfs_tab_GL (nn , ii);
	      d2wf_aft_R_tab_GL_real(i) += Vnn*HO_d2wfs_tab_GL(nn , ii);
	    }
	}
    }
}



// Calculation of the wave function as equal to a HO wave function
// ---------------------------------------------------------------

void spherical_state::HO_wave_function (const double b_HO)
{
  if (particle == ELECTRON) error_message_print_abort ("HO wf not available for electron.");

  const double bk_HO = 1.0/b_HO;
  
  const double b_HO_2 = b_HO*b_HO;

  const double k2 = (4*n + 2*l + 3)/b_HO_2;

  zero ();

  C0 = HO_wave_functions::HO_3D::C0_calc (b_HO , n , l);

  k = sqrt (k2);

  E = k2/kinetic_factor;

  eta = 0.0; //arbitrary value as eta is meaningless for HO wave functions

  wf_R0  = HO_wave_functions::HO_3D::u  (b_HO , n , l , R0);
  dwf_R0 = HO_wave_functions::HO_3D::du (b_HO , n , l , R0);

  is_k_OK = true;

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);

      wf_bef_R_tab_uniform  (i) = HO_wave_functions::HO_3D::u   (b_HO , n , l , r);
      dwf_bef_R_tab_uniform (i) = HO_wave_functions::HO_3D::du  (b_HO , n , l , r);
      d2wf_bef_R_tab_uniform(i) = HO_wave_functions::HO_3D::d2u (b_HO , n , l , r);
    }

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);

      wf_bef_R_tab_GL  (i) = HO_wave_functions::HO_3D::u   (b_HO , n , l , r);
      dwf_bef_R_tab_GL (i) = HO_wave_functions::HO_3D::du  (b_HO , n , l , r);
      d2wf_bef_R_tab_GL(i) = HO_wave_functions::HO_3D::d2u (b_HO , n , l , r);	
    }

  if (!is_there_effective_mass_determine (potential))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r_SGI_MSGI = r_bef_R_tab_GL_SGI_MSGI(i);
	  
	  wf_bef_R_tab_GL_SGI_MSGI (i) = HO_wave_functions::HO_3D::u  (b_HO , n , l , r_SGI_MSGI);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = HO_wave_functions::HO_3D::du (b_HO , n , l , r_SGI_MSGI);
	}
    }

  if (R_real_max > 0.0)
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL_real(i);

	  wf_aft_R_tab_GL_real  (i) = HO_wave_functions::HO_3D::u   (b_HO , n , l , r);
	  dwf_aft_R_tab_GL_real (i) = HO_wave_functions::HO_3D::du  (b_HO , n , l , r);
	  d2wf_aft_R_tab_GL_real(i) = HO_wave_functions::HO_3D::d2u (b_HO , n , l , r);
	}
    }
  
  if (kmax_momentum > 0.0)
    {
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  const double k = k_tab_uniform(i);
	  
	  wf_momentum_tab_uniform (i) = HO_wave_functions::HO_3D::u_momentum  (bk_HO , n , l , k);
	  dwf_momentum_tab_uniform(i) = HO_wave_functions::HO_3D::du_momentum (bk_HO , n , l , k);
	}
      
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  const double k = k_tab_GL(i);
	  
	  wf_momentum_tab_GL (i) = HO_wave_functions::HO_3D::u_momentum  (bk_HO , n , l , k);
	  dwf_momentum_tab_GL(i) = HO_wave_functions::HO_3D::du_momentum (bk_HO , n , l , k);
	}
    }
}



// Diagonalization in a THO basis. 
// -----------------------------
// It always gives a very good first guess for the Newton search if the sought state is well bound or well unbound with a very small width.
// The THO states are calculated and stored in THO_wfs and in THO_dfws.
// One uses Vnucl(r) ~ 0 for r > R , as the potential may be given by splines , unavailable for r > R.
// To find the starting energy , one looks for the eigenvector which has the largest overlap with |u[THO](n , l)>.
// If the probability to be in |u[THO](n , l)> is more than 50% , one surely has a bound state or a narrow unbound state.
// Then the starting energy is the one of the eigenvector which has the largest overlap with |u[THO](n , l)>.
// If not , then one has a broad resonant state , and then one sends eigenvalues(n) , as the starting energy of a broad resonant state
// does not have to be very close to it , but must be far away from the other bound states if they exist.
// One also returns the approximate number of bound states of the potential , 
// given by the number of eigenvectors having an overlap of more than 50% with a harmonic oscillator state.
// It is used int the PTG fit if the THO guess is bad , to initialize the parameter nu , 
// as it is related to the number of bound and narrow resonant states of the PTG potential.
//
// Variables:
// ----------
// llp1 : l(l + 1)
// nmax_THO : THO maximal n.
// R_THO_end : point where one stops the integration of radial matrix elements.
//            One assumes int_{0}^{R_THO_end} uf(r).O(r).ui(r) dr ~ \int_{0}^{+oo} uf(r).O(r).ui(r) dr .
// r_bef_R_THO_tab_GL , w_bef_R_HO_tab_GL : Gauss-Legendre radii and weights between 0 and R_THO_end.
// THO_matrix : matrix of the potential to integrate on the THO basis.
// THO_wfs , THO_dwfs , THO_wfs_n , THO_dwfs_n : class array<double> containing the THO wave functions and derivatives for all n and r and for one r and all n.
// V_function_tab : table containing the table function of different potentials to integrate from 0 to R.
// full_effective_mass : interpolated effective mass in MeV^(-1) fm^{-2}.
// V_effective_mass_unscaled : Skyrme potential without the r-dependent rotation.
// full_effective_mass_r , full_effective_mass_der_r : effective mass in MeV^(-1) fm^{-2} and derivative for a given r.
// full_effective_mass_inv_tab : table containing 1.0/full_effective_mass(r) from 0 to R.
// OBME : matrix element of THO_matrix.
// eigenvalues : table which will contain the eigenvalues of matrix of the the potential to integrate on the THO basis. eigenvalues(n) is returned.

void spherical_state::THO_matrix_calc (
				       const class potentials_effective_mass &T , 
				       const class THO_class &THO , 
				       class matrix<double> &THO_matrix) const
{
  const class Coulomb_potential_class Coulomb_potential(is_it_relative , particle , Z_charge , NADA);
  
  const int nmax_THO_plus_one = THO_matrix.get_dimension ();
  
  const int nmax_THO = nmax_THO_plus_one - 1;

  const double R_THO_end = 50;

  const double llp1 = l*(l + 1);

  class array<double> r_bef_R_THO_tab_GL(N_bef_R_GL);
  class array<double> w_bef_R_THO_tab_GL(N_bef_R_GL);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R_THO_end , r_bef_R_THO_tab_GL , w_bef_R_THO_tab_GL);

  class array<double> THO_wfs (nmax_THO_plus_one , N_bef_R_GL);
  class array<double> THO_dwfs(nmax_THO_plus_one , N_bef_R_GL);

  THO.u_du_r_tables_calc (l , r_bef_R_THO_tab_GL , THO_wfs , THO_dwfs);

  class array<double> V_function_tab(N_bef_R_GL);

  class array<double> full_effective_mass_inv_tab(N_bef_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_THO_tab_GL(i);

      if (is_there_effective_mass_determine (potential))
	{
	  const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();

	  const class splines_class<double> &V_effective_mass_unscaled = T.get_V_effective_mass_unscaled ();

	  const double full_effective_mass_r = (r <= R) ? (full_effective_mass(r)) : (kinetic_factor);

	  const double full_effective_mass_der_r = (r <= R) ? (full_effective_mass.derivative (r)) : (0.0);

	  full_effective_mass_inv_tab(i) = 1.0/full_effective_mass_r;

	  V_function_tab(i) = (r <= R) ? (V_effective_mass_unscaled(r)) : (Coulomb_potential.point_potential_calc (r));

	  V_function_tab(i) += full_effective_mass_inv_tab(i)*llp1/(r*r) - full_effective_mass_der_r/(r*full_effective_mass_r*full_effective_mass_r);
	}
      else
	V_function_tab(i) = (r <= R) ? (real (T.potential_calc (r)) + llp1/(r*r*kinetic_factor)) : (Coulomb_potential.point_potential_calc (r) + llp1/(r*r*kinetic_factor));
    } 

  for (int n_in = 0 ; n_in <= nmax_THO ; n_in++)
    for (int n_out = 0 ; n_out <= n_in ; n_out++)
      {
	double OBME = 0.0;

	if (is_there_effective_mass_determine (potential))
	  {
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      OBME += (THO_wfs(n_in , i)*THO_wfs(n_out , i)*V_function_tab(i) + THO_dwfs(n_in , i)*THO_dwfs(n_out , i)*full_effective_mass_inv_tab(i))*w_bef_R_THO_tab_GL(i);
	  }
	else
	  {
	    for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	      OBME += (THO_wfs(n_in , i)*THO_wfs(n_out , i)*V_function_tab(i) + THO_dwfs(n_in , i)*THO_dwfs(n_out , i)/kinetic_factor)*w_bef_R_THO_tab_GL(i);
	  }

	THO_matrix(n_in , n_out) = THO_matrix(n_out , n_in) = OBME;
      }
}










// Calculation of the wave function only through THO diagonalization
// ----------------------------------------------------------------

void spherical_state::wave_calculation_THO_diag (
						 const class potentials_effective_mass &T , 
						 const double b_HO , 
						 const class array<double> &r_tab , 
						 const class array<double> &rho , 
						 const class array<double> &r_HO_tab , 
						 const class array<double> &rho_HO)
{ 
  if (particle == ELECTRON) error_message_print_abort ("THO diagonalization not available for electron.");

  if (!S_matrix_pole) error_message_print_abort ("THO diagonalization for pole states only.");

  if (R_real_max < R) error_message_print_abort ("R_real_max must be larger than R.");

  const int nmax_THO = 20;

  const int nmax_THO_plus_one = nmax_THO + 1;
    
  const unsigned int N_tab_GL = N_bef_R_GL + N_aft_R_GL;

  const class THO_class THO(b_HO , r_tab , rho , r_HO_tab , rho_HO);
  
  class array<double> eigenvalues(nmax_THO_plus_one);

  class matrix<double> THO_matrix(nmax_THO_plus_one);

  THO_matrix_calc (T , THO , THO_matrix);

  total_diagonalization::all_eigenpairs (THO_matrix , eigenvalues);

  int nn_try = 0; 

  for (int nn = 0 ; nn <= nmax_THO ; nn++)
    {
      if (abs (THO_matrix.eigenvector(nn)(n)) > abs (THO_matrix.eigenvector(nn_try)(n)))
	nn_try = nn;
    }

  const int n_from_diagonalization = (THO_matrix.eigenvector(nn_try)(n)*THO_matrix.eigenvector(nn_try)(n) > 0.5) ? (nn_try) : (n);

  E = eigenvalues(n_from_diagonalization);

  k = sqrt (kinetic_factor*E);

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  is_k_OK = true;

  if (eigenvalues(n_from_diagonalization) > potential_barrier::V_barrier_calc (r_bef_R_tab_uniform , particle , T))
    {
      is_k_OK = false;

      return;
    }

  zero ();

  class vector_class<double> &eigenvector = THO_matrix.eigenvector(n_from_diagonalization);

  for (int nn = 0 ; nn <= nmax_THO ; nn++)
    {
      const double C0_HO_nn = HO_wave_functions::HO_3D::C0_calc (b_HO , nn , l);

      C0 += eigenvector(nn)*C0_HO_nn;
    }

  if (real (C0) < 0.0) eigenvector = -eigenvector , C0 = -C0;

  class array<double> THO_wfs_tab_GL  (nmax_THO_plus_one , N_tab_GL);
  class array<double> THO_dwfs_tab_GL (nmax_THO_plus_one , N_tab_GL);
  class array<double> THO_d2wfs_tab_GL(nmax_THO_plus_one , N_tab_GL);

  class array<double> r_tab_GL(N_tab_GL);

  class array<double> THO_wfs_bef_R_tab_uniform  (nmax_THO_plus_one , N_bef_R_uniform);
  class array<double> THO_dwfs_bef_R_tab_uniform (nmax_THO_plus_one , N_bef_R_uniform);
  class array<double> THO_d2wfs_bef_R_tab_uniform(nmax_THO_plus_one , N_bef_R_uniform);

  for (unsigned int i = 0 ; i < N_tab_GL ; i++) r_tab_GL(i) = (i >= N_bef_R_GL) ? (r_aft_R_tab_GL_real(i - N_bef_R_GL)) : (r_bef_R_tab_GL(i));

  THO.u_du_d2u_r_tables_calc (l , r_tab_GL            , THO_wfs_tab_GL            , THO_dwfs_tab_GL            , THO_d2wfs_tab_GL);
  THO.u_du_d2u_r_tables_calc (l , r_bef_R_tab_uniform , THO_wfs_bef_R_tab_uniform , THO_dwfs_bef_R_tab_uniform , THO_d2wfs_bef_R_tab_uniform);

  for (int nn = 0 ; nn <= nmax_THO ; nn++)
    {
      const double Vnn = eigenvector(nn);
      
      wf_R0  += Vnn*THO.u  (nn , l , R0);
      dwf_R0 += Vnn*THO.du (nn , l , R0);

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform(i)   += Vnn*THO_wfs_bef_R_tab_uniform  (nn , i);
	  dwf_bef_R_tab_uniform(i)  += Vnn*THO_dwfs_bef_R_tab_uniform (nn , i);
	  d2wf_bef_R_tab_uniform(i) += Vnn*THO_d2wfs_bef_R_tab_uniform(nn , i);
	}
      
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL(i)   += Vnn*THO_wfs_tab_GL  (nn , i);
	  dwf_bef_R_tab_GL(i)  += Vnn*THO_dwfs_tab_GL (nn , i);
	  d2wf_bef_R_tab_GL(i) += Vnn*THO_d2wfs_tab_GL(nn , i);
	}
    }	

  if (R_real_max > 0.0)
    {
      for (int nn = 0 ; nn <= nmax_THO ; nn++)
	{
	  const double Vnn = eigenvector(nn);

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	    {
	      const unsigned int ii = i + N_bef_R_GL;
	      
	      wf_aft_R_tab_GL_real(i)   += Vnn*THO_wfs_tab_GL  (nn , ii);
	      dwf_aft_R_tab_GL_real(i)  += Vnn*THO_dwfs_tab_GL (nn , ii);
	      d2wf_aft_R_tab_GL_real(i) += Vnn*THO_d2wfs_tab_GL(nn , ii);
	    }
	}
    }

  if (kmax_momentum > 0.0) wave_calculation_momentum (b_HO);
}



// Calculation of the wave function as equal to a THO wave function
// ----------------------------------------------------------------

void spherical_state::THO_wave_function (const class THO_class &THO)
{ 
  if (particle == ELECTRON) error_message_print_abort ("THO wf not available for electron.");

  const double b_HO = THO.get_b_HO ();

  const double b_HO_2 = b_HO*b_HO;

  const double k2 = (4*n + 2*l + 3)/b_HO_2;

  zero ();

  C0 = HO_wave_functions::HO_3D::C0_calc (b_HO , n , l);

  k = sqrt (k2);

  E = k2/kinetic_factor;

  eta = 0.0; //arbitrary value as eta is meaningless for THO wave functions

  wf_R0  = THO.u  (n , l , R0);
  dwf_R0 = THO.du (n , l , R0);

  is_k_OK = true;

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);
      
      wf_bef_R_tab_uniform  (i) = THO.u   (n , l , r);
      dwf_bef_R_tab_uniform (i) = THO.du  (n , l , r);
      d2wf_bef_R_tab_uniform(i) = THO.d2u (n , l , r);
    }

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);

      wf_bef_R_tab_GL  (i) = THO.u   (n , l , r);
      dwf_bef_R_tab_GL (i) = THO.du  (n , l , r);
      d2wf_bef_R_tab_GL(i) = THO.d2u (n , l , r);
    }

  if (!is_there_effective_mass_determine (potential))
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  const double r_SGI_MSGI = r_bef_R_tab_GL_SGI_MSGI(i);
	  
	  wf_bef_R_tab_GL_SGI_MSGI (i) = THO.u  (n , l , r_SGI_MSGI);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) = THO.du (n , l , r_SGI_MSGI);
	}
    }

  if (R_real_max > 0.0)
    {
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	{
	  const double r = r_aft_R_tab_GL_real(i);

	  wf_aft_R_tab_GL_real  (i) = THO.u   (n , l , r);
	  dwf_aft_R_tab_GL_real (i) = THO.du  (n , l , r);
	  d2wf_aft_R_tab_GL_real(i) = THO.d2u (n , l , r);
	}
    }
  
  if (kmax_momentum > 0.0) wave_calculation_momentum (b_HO);
}




//--// spherical_state_potential






// Calculation of the PTG state before R for r small
// -------------------------------------------------
// Formula stable for y not too close to 1, i.e. for r small.
// The analytical formula is used.
// Functions are not normalized here.

void spherical_state::PTG_wf_dwf_d2wf_small_r_calc (const class PTG_class &PTG_potential ,
						    const double y ,
						    complex<double> &wf,
						    complex<double> &dwf,
						    complex<double> &d2wf) const
{
  const double Lambda = PTG_potential.get_Lambda ();
  
  const double s = PTG_potential.get_s ();

  const double nu = PTG_potential.get_nu ();

  const double a = PTG_potential.get_a ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double two_Lambda2_s = 2.0*Lambda2_s;

  const double Lambda2_one_minus_a = Lambda2*(1.0 - a);
  
  const double lp1 = l + 1;

  const double lp = l + 1.5;

  const double l_exp = 0.5*lp1;

  const double Lambda2_one_minus_a_minus_one = Lambda2_one_minus_a - 1;

  const double Lambda2_minus_one = Lambda2 - 1;

  const double nu_p_half = nu + 0.5;

  const complex<double> I(0.0 , 1.0);
  const complex<double> Ik(-imag (k) , real (k));

  const complex<double> beta_bar = -Ik/Lambda2_s;

  const complex<double> beta_bar_over_two = 0.5*beta_bar;

  const complex<double> beta_bar_over_two_minus_one = beta_bar_over_two - 1;

  const complex<double> nu_bar = sqrt (nu_p_half*nu_p_half - beta_bar*beta_bar*Lambda2_one_minus_a_minus_one);

  const complex<double> nu_p = 0.5*(lp + beta_bar + nu_bar);
  const complex<double> nu_m = 0.5*(lp + beta_bar - nu_bar);

  const complex<double> nu_p_plus_one = nu_p + 1.0;
  const complex<double> nu_p_plus_two = nu_p + 2.0;

  const complex<double> nu_m_plus_one = nu_m + 1.0;
  const complex<double> nu_m_plus_two = nu_m + 2.0;

  const complex<double> lp_plus_one = lp + 1.0;
  const complex<double> lp_plus_two = lp + 2.0;

  const complex<double> df_factor = nu_m*nu_p/lp;

  const complex<double> d2f_factor = df_factor*nu_m_plus_one*nu_p_plus_one/lp_plus_one;

  const double y2 = y*y;

  const double Lambda2_y2 = Lambda2*y2;

  const double one_minus_y2 = 1.0 - y2;

  const double xm = Lambda2_y2/(one_minus_y2 + Lambda2_y2);

  const double xp = 1.0 - xm;

  const double chi_term_1 = Lambda2_one_minus_a_minus_one/(xm + Lambda2_one_minus_a*xp);

  const double chi_term_2 = Lambda2_minus_one/(xm + Lambda2*xp);

  const double chi_term_3 = lp1/xm;

  const double chi = sqrt ((xm + Lambda2_one_minus_a*xp)/sqrt (xm + Lambda2*xp))*pow (xm , l_exp);

  const double chi_log_der = 0.5*(-chi_term_1 + 0.5*chi_term_2 + chi_term_3);

  const double dchi = chi*chi_log_der;

  const double d2chi = dchi*chi_log_der + 0.5*chi*(-chi_term_1*chi_term_1 + 0.5*chi_term_2*chi_term_2 - chi_term_3/xm);

  const double dxm_dr = two_Lambda2_s*y*xp;

  const double d2xm_dr2 = two_Lambda2_s*(s*one_minus_y2*one_minus_y2 - y*dxm_dr);

  const complex<double> X = pow (xp , beta_bar_over_two);

  const complex<double> dX = -beta_bar_over_two*X/xp;

  const complex<double> d2X = -beta_bar_over_two_minus_one*dX/xp;

  const complex<double> f = hyp_2F1 (nu_m , nu_p , lp , xm);

  const complex<double> df = df_factor*hyp_2F1 (nu_m_plus_one , nu_p_plus_one , lp_plus_one , xm);

  const complex<double> d2f = d2f_factor*hyp_2F1 (nu_m_plus_two , nu_p_plus_two , lp_plus_two , xm);

  const complex<double> Phi = f*chi*X;

  const complex<double> dPhi = (df*X + f*dX)*chi + f*X*dchi;

  const complex<double> d2Phi = (d2f*X + 2.0*df*dX + f*d2X)*chi + 2.0*(df*X + dX*f)*dchi + f*X*d2chi;

  wf = Phi;

  dwf = dPhi*dxm_dr;

  d2wf = d2Phi*dxm_dr*dxm_dr + dPhi*d2xm_dr2;
}














// Calculation of the PTG state before R for r large
// -------------------------------------------------
// Formulas stable for y close to 1, i.e. for r large.
// Poles and scattering cases are two different cases.
// Poles just have an outgoing part.
// Scattering states have an incoming and outgoing parts.
// The analytical formula is used.
// Functions are not normalized here.


void spherical_state::PTG_wf_dwf_d2wf_pole_large_r_calc (const class PTG_class &PTG_potential ,
							 const double Lambda2_sr ,
							 complex<double> &wf ,
							 complex<double> &dwf ,
							 complex<double> &d2wf) const
{
  const double Lambda = PTG_potential.get_Lambda ();

  const double s = PTG_potential.get_s ();

  const double nu = PTG_potential.get_nu ();

  const double a = PTG_potential.get_a ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double two_Lambda2_s = 2.0*Lambda2_s;

  const double Lambda2_one_minus_a = Lambda2*(1.0 - a);
  
  const double lp1 = l + 1;

  const double lp = l + 1.5;

  const double l_exp = 0.5*lp1;

  const double Lambda2_one_minus_a_minus_one = Lambda2_one_minus_a - 1;

  const double Lambda2_minus_one = Lambda2 - 1;

  const double nu_p_half = nu + 0.5;

  const complex<double> I(0.0 , 1.0);

  const complex<double> Ik(-imag (k) , real (k));

  const complex<double> beta_bar = -Ik/Lambda2_s;

  const complex<double> beta_bar_over_two = 0.5*beta_bar;

  const complex<double> beta_bar_over_two_minus_one = beta_bar_over_two - 1;

  const complex<double> beta_bar_plus_one = beta_bar + 1;

  const complex<double> nu_bar = sqrt (nu_p_half*nu_p_half - beta_bar*beta_bar*Lambda2_one_minus_a_minus_one);

  const complex<double> nu_p = 0.5*(lp + beta_bar + nu_bar);
  const complex<double> nu_m = 0.5*(lp + beta_bar - nu_bar);

  const complex<double> mu_p = 0.5*(lp - beta_bar + nu_bar);
  const complex<double> mu_m = 0.5*(lp - beta_bar - nu_bar);

  const complex<double> nu_p_plus_one = nu_p + 1.0;
  const complex<double> nu_p_plus_two = nu_p + 2.0;

  const complex<double> nu_m_plus_one = nu_m + 1.0;
  const complex<double> nu_m_plus_two = nu_m + 2.0;

  const complex<double> beta_bar_plus_two   = beta_bar + 2.0;
  const complex<double> beta_bar_plus_three = beta_bar + 3.0;

  const complex<double> dg_factor = nu_m*nu_p/beta_bar_plus_one;

  const complex<double> d2g_factor = dg_factor*nu_m_plus_one*nu_p_plus_one/beta_bar_plus_two;

  const complex<double> Gamma_product = exp (log_Gamma (lp) + log_Gamma (-beta_bar) - log_Gamma (mu_p) - log_Gamma (mu_m));

  const double e_m2x = PTG_potential.exp_minus_2x_iterative (Lambda2_sr);

  const double e_m2x_fraction = 1.0/(1.0 + e_m2x);

  const double y = 1.0 - 2.0*e_m2x*e_m2x_fraction;

  const double y2 = y*y;

  const double one_minus_y2 = 4.0*e_m2x*e_m2x_fraction*e_m2x_fraction;

  const double xp = one_minus_y2/(one_minus_y2 + Lambda2*y2);

  const double xm = 1.0 - xp;

  const double chi_term_1 = Lambda2_one_minus_a_minus_one/(xm + Lambda2_one_minus_a*xp);

  const double chi_term_2 = Lambda2_minus_one/(xm + Lambda2*xp);

  const double chi_term_3 = lp1/xm;

  const double chi = sqrt ((xm + Lambda2_one_minus_a*xp)/sqrt (xm + Lambda2*xp))*pow (xm , l_exp);

  const double chi_log_der = 0.5*(chi_term_1 - 0.5*chi_term_2 - chi_term_3);

  const double dchi = chi*chi_log_der;

  const double d2chi = dchi*chi_log_der + 0.5*chi*(-chi_term_1*chi_term_1 + 0.5*chi_term_2*chi_term_2 - chi_term_3/xm);

  const double dxp_dr = -two_Lambda2_s*y*xp;

  const double d2xp_dr2 = -two_Lambda2_s*(s*one_minus_y2*one_minus_y2 + y*dxp_dr);

  const complex<double> X = pow (xp , beta_bar_over_two);

  const complex<double> dX = beta_bar_over_two*X/xp;

  const complex<double> d2X = beta_bar_over_two_minus_one*dX/xp;

  const complex<double> g = hyp_2F1 (nu_m , nu_p , beta_bar_plus_one , xp);

  const complex<double> dg = dg_factor*hyp_2F1 (nu_m_plus_one , nu_p_plus_one , beta_bar_plus_two , xp);

  const complex<double> d2g = d2g_factor*hyp_2F1 (nu_m_plus_two , nu_p_plus_two , beta_bar_plus_three , xp);

  const complex<double> Phi = g*chi*X;

  const complex<double> dPhi = (dg*X + g*dX)*chi + g*X*dchi;

  const complex<double> d2Phi = (d2g*X + 2.0*dg*dX + g*d2X)*chi + 2.0*(dg*X + dX*g)*dchi + g*X*d2chi;
  
  wf = Gamma_product*Phi;

  dwf = Gamma_product*dPhi*dxp_dr;

  d2wf = Gamma_product*(d2Phi*dxp_dr*dxp_dr + dPhi*d2xp_dr2);
}






void spherical_state::PTG_wf_dwf_d2wf_scat_large_r_calc (const class PTG_class &PTG_potential ,
							 const double Lambda2_sr ,
							 complex<double> &wf ,
							 complex<double> &dwf ,
							 complex<double> &d2wf) const
{
  const double Lambda = PTG_potential.get_Lambda ();

  const double s = PTG_potential.get_s ();

  const double nu = PTG_potential.get_nu ();

  const double a = PTG_potential.get_a ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double two_Lambda2_s = 2.0*Lambda2_s;

  const double Lambda2_one_minus_a = Lambda2*(1.0 - a);
  
  const double lp1 = l + 1.0;

  const double lp = l + 1.5;

  const double l_exp = 0.5*lp1;

  const double Lambda2_one_minus_a_minus_one = Lambda2_one_minus_a - 1;

  const double Lambda2_minus_one = Lambda2 - 1;

  const double nu_p_half = nu + 0.5;

  const complex<double> I(0.0 , 1.0);
  
  const complex<double> Ik(-imag (k) , real (k));

  const complex<double> beta_bar = -Ik/Lambda2_s;

  const complex<double> beta_bar_over_two = 0.5*beta_bar;

  const complex<double> beta_bar_over_two_minus_one = beta_bar_over_two - 1;

  const complex<double> beta_bar_plus_one = beta_bar + 1;

  const complex<double> minus_beta_bar_plus_one = -beta_bar + 1;

  const complex<double> nu_bar = sqrt (nu_p_half*nu_p_half - beta_bar*beta_bar*Lambda2_one_minus_a_minus_one);

  const complex<double> beta_bar_over_two_plus_one = beta_bar_over_two + 1;

  const complex<double> nu_p = 0.5*(lp + beta_bar + nu_bar);
  const complex<double> nu_m = 0.5*(lp + beta_bar - nu_bar);

  const complex<double> mu_p = 0.5*(lp - beta_bar + nu_bar);
  const complex<double> mu_m = 0.5*(lp - beta_bar - nu_bar);

  const complex<double> nu_p_plus_one = nu_p + 1.0;
  const complex<double> nu_p_plus_two = nu_p + 2.0;

  const complex<double> nu_m_plus_one = nu_m + 1.0;
  const complex<double> nu_m_plus_two = nu_m + 2.0;

  const complex<double> mu_p_plus_one = mu_p + 1.0;
  const complex<double> mu_p_plus_two = mu_p + 2.0;

  const complex<double> mu_m_plus_one = mu_m + 1.0;
  const complex<double> mu_m_plus_two = mu_m + 2.0;

  const complex<double> beta_bar_plus_two   = beta_bar + 2.0;
  const complex<double> beta_bar_plus_three = beta_bar + 3.0;

  const complex<double> minus_beta_bar_plus_two   = -beta_bar + 2.0;
  const complex<double> minus_beta_bar_plus_three = -beta_bar + 3.0;

  const complex<double> dg_in_factor = mu_m*mu_p/minus_beta_bar_plus_one;

  const complex<double> d2g_in_factor = dg_in_factor*mu_m_plus_one*mu_p_plus_one/minus_beta_bar_plus_two;

  const complex<double> dg_out_factor = nu_m*nu_p/beta_bar_plus_one;
  
  const complex<double> d2g_out_factor = dg_out_factor*nu_m_plus_one*nu_p_plus_one/beta_bar_plus_two;

  const complex<double> Gamma_product_in  = exp (log_Gamma (lp) + log_Gamma ( beta_bar) - log_Gamma (nu_p) - log_Gamma (nu_m));
  const complex<double> Gamma_product_out = exp (log_Gamma (lp) + log_Gamma (-beta_bar) - log_Gamma (mu_p) - log_Gamma (mu_m));

  const double e_m2x = PTG_potential.exp_minus_2x_iterative (Lambda2_sr);

  const double e_m2x_fraction = 1.0/(1.0 + e_m2x);

  const double y = 1.0 - 2.0*e_m2x*e_m2x_fraction;

  const double y2 = y*y;

  const double one_minus_y2 = 4.0*e_m2x*e_m2x_fraction*e_m2x_fraction;

  const double xp = one_minus_y2/(one_minus_y2 + Lambda2*y2);

  const double xm = 1.0 - xp;

  const double chi_term_1 = Lambda2_one_minus_a_minus_one/(xm + Lambda2_one_minus_a*xp);
  
  const double chi_term_2 = Lambda2_minus_one/(xm + Lambda2*xp);

  const double chi_term_3 = lp1/xm;

  const double chi = sqrt ((xm + Lambda2_one_minus_a*xp)/sqrt (xm + Lambda2*xp))*pow (xm , l_exp);

  const double chi_log_der = 0.5*(chi_term_1 - 0.5*chi_term_2 - chi_term_3);

  const double dchi = chi*chi_log_der;

  const double d2chi = dchi*chi_log_der + 0.5*chi*(-chi_term_1*chi_term_1 + 0.5*chi_term_2*chi_term_2 - chi_term_3/xm);

  const double dxp_dr = -two_Lambda2_s*y*xp;

  const double d2xp_dr2 = -two_Lambda2_s*(s*one_minus_y2*one_minus_y2 + y*dxp_dr);

  const complex<double> X_in = pow (xp , -beta_bar_over_two);

  const complex<double> dX_in = -beta_bar_over_two*X_in/xp;

  const complex<double> d2X_in = -beta_bar_over_two_plus_one*dX_in/xp;

  const complex<double> X_out = 1.0/X_in;

  const complex<double> dX_out = beta_bar_over_two*X_out/xp;

  const complex<double> d2X_out = beta_bar_over_two_minus_one*dX_out/xp;

  const complex<double> g_in = hyp_2F1 (mu_m , mu_p , minus_beta_bar_plus_one , xp);

  const complex<double> dg_in = dg_in_factor*hyp_2F1 (mu_m_plus_one , mu_p_plus_one , minus_beta_bar_plus_two , xp);
  
  const complex<double> d2g_in = d2g_in_factor*hyp_2F1 (mu_m_plus_two , mu_p_plus_two , minus_beta_bar_plus_three , xp);

  const complex<double> g_out = hyp_2F1 (nu_m , nu_p , beta_bar_plus_one , xp);

  const complex<double> dg_out = dg_out_factor*hyp_2F1 (nu_m_plus_one , nu_p_plus_one , beta_bar_plus_two , xp);

  const complex<double> d2g_out = d2g_out_factor*hyp_2F1 (nu_m_plus_two , nu_p_plus_two , beta_bar_plus_three , xp);

  const complex<double> Phi_in = g_in*chi*X_in;

  const complex<double> dPhi_in = (dg_in*X_in + g_in*dX_in)*chi + g_in*X_in*dchi;

  const complex<double> d2Phi_in = (d2g_in*X_in + 2.0*dg_in*dX_in + g_in*d2X_in)*chi + 2.0*(dg_in*X_in + dX_in*g_in)*dchi + g_in*X_in*d2chi;

  const complex<double> Phi_out = g_out*chi*X_out;

  const complex<double> dPhi_out = (dg_out*X_out + g_out*dX_out)*chi + g_out*X_out*dchi;

  const complex<double> d2Phi_out = (d2g_out*X_out + 2.0*dg_out*dX_out + g_out*d2X_out)*chi + 2.0*(dg_out*X_out + dX_out*g_out)*dchi + g_out*X_out*d2chi;

  wf = Gamma_product_in*Phi_in + Gamma_product_out*Phi_out;

  dwf = (Gamma_product_in*dPhi_in + Gamma_product_out*dPhi_out)*dxp_dr;

  d2wf = Gamma_product_in*(d2Phi_in*dxp_dr*dxp_dr + dPhi_in*d2xp_dr2) + Gamma_product_out*(d2Phi_out*dxp_dr*dxp_dr + dPhi_out*d2xp_dr2);
}











void spherical_state::PTG_wf_dwf_d2wf_calc (const class PTG_class &PTG_potential ,
					    const double r ,
					    complex<double> &wf ,
					    complex<double> &dwf ,
					    complex<double> &d2wf) const
{
  const double Lambda = PTG_potential.get_Lambda ();

  const double s = PTG_potential.get_s ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double Lambda2_sr = Lambda2_s*r;

  const double ys = PTG_potential.y_search (Lambda2_sr);

  if (abs (1.0 - ys) > sqrt_precision)
    PTG_wf_dwf_d2wf_small_r_calc (PTG_potential , ys , wf , dwf , d2wf);
  else
    {
      if (S_matrix_pole)
	PTG_wf_dwf_d2wf_pole_large_r_calc (PTG_potential , Lambda2_sr , wf , dwf , d2wf);
      else
	PTG_wf_dwf_d2wf_scat_large_r_calc (PTG_potential , Lambda2_sr , wf, dwf, d2wf);
    }
}




complex<double> spherical_state::PTG_state_norm_calc (const class PTG_class &PTG_potential) const
{
  const double Lambda = PTG_potential.get_Lambda ();

  const double s = PTG_potential.get_s ();

  const double nu = PTG_potential.get_nu ();

  const double a = PTG_potential.get_a ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double two_Lambda2_s = 2.0*Lambda2_s;

  const double Lambda2_one_minus_a = Lambda2*(1.0 - a);
  
  const double lp = l + 1.5;

  const double Lambda2_one_minus_a_minus_one = Lambda2_one_minus_a - 1;

  const double nu_p_half = nu + 0.5;

  const complex<double> I(0.0 , 1.0);

  const complex<double> Ik(-imag (k) , real (k));

  const complex<double> beta_bar = -Ik/Lambda2_s;

  if (S_matrix_pole)
    {
      const complex<double> norm_1 = (lp + beta_bar*Lambda2_one_minus_a + 2*n)/(two_Lambda2_s*beta_bar*(lp + beta_bar + 2*n));

      const complex<double> norm_2 = exp (log_Gamma (n + 1) + log_Gamma (beta_bar + n + 1) + 2*log_Gamma (lp) - log_Gamma (lp + beta_bar + n) - log_Gamma (lp + n));

      const complex<double> PTG_state_norm_no_phase = sqrt (norm_1*norm_2);

      const complex<double> PTG_state_norm = PTG_state_norm_no_phase*SIGN (real (PTG_state_norm_no_phase));

      return PTG_state_norm;
    }
  else
    {
      const complex<double> nu_bar = sqrt (nu_p_half*nu_p_half - beta_bar*beta_bar*Lambda2_one_minus_a_minus_one);

      const complex<double> nu_p = 0.5*(lp + beta_bar + nu_bar);
      const complex<double> nu_m = 0.5*(lp + beta_bar - nu_bar);

      const complex<double> mu_p = 0.5*(lp - beta_bar + nu_bar);
      const complex<double> mu_m = 0.5*(lp - beta_bar - nu_bar);

      const complex<double> log_norm_1 = log_Gamma (nu_p) + log_Gamma (nu_m) + log_Gamma (mu_p) + log_Gamma (mu_m);

      const complex<double> log_norm_2 = 2.0*log_Gamma (lp) + log_Gamma (beta_bar) + log_Gamma (-beta_bar);

      const complex<double> PTG_state_norm_no_phase = sqrt ((2.0*M_PI)*exp (log_norm_2 - log_norm_1));

      const complex<double> PTG_state_norm = PTG_state_norm_no_phase*SIGN (real (PTG_state_norm_no_phase));

      return PTG_state_norm;
    }
}






void spherical_state::PTG_bef_R_constants_wfs_calc (const class PTG_class &PTG_potential)
{	
  const double Lambda = PTG_potential.get_Lambda ();
  
  const double s = PTG_potential.get_s ();

  const double nu = PTG_potential.get_nu ();

  const double a = PTG_potential.get_a ();

  const double Lambda2 = Lambda*Lambda;

  const double Lambda2_s = Lambda2*s;

  const double Lambda2_one_minus_a = Lambda2*(1.0 - a);

  const double lp = l + 1.5;

  const double Lambda2_one_minus_a_minus_one = Lambda2_one_minus_a - 1;

  const double Lambda2_minus_one = Lambda2 - 1;

  const double log_half_Lambda = log (0.5*Lambda);

  const double sqrt_abs_Lambda2_minus_one = sqrt (abs (Lambda2_minus_one));

  const double r1 = (Lambda2 >= 1.0)
    ? (( sqrt_abs_Lambda2_minus_one*atan  (sqrt_abs_Lambda2_minus_one) - log_half_Lambda)/Lambda2_s)
    : ((-sqrt_abs_Lambda2_minus_one*atanh (sqrt_abs_Lambda2_minus_one) - log_half_Lambda)/Lambda2_s);

  const double nu_p_half = nu + 0.5;

  if (S_matrix_pole)
    {
      k = PTG_potential.k_pole_calc (n);

      E = k*k/kinetic_factor;
    }

  eta = 0.0; //The PTG potential is of finite range, whatever the value of l or Z_charge.
  
  const complex<double> I(0.0 , 1.0);

  const complex<double> Ik(-imag (k) , real (k));

  const complex<double> beta_bar = -Ik/Lambda2_s;

  const complex<double> nu_bar = sqrt (nu_p_half*nu_p_half - beta_bar*beta_bar*Lambda2_one_minus_a_minus_one);

  const complex<double> nu_p = 0.5*(lp + beta_bar + nu_bar);
  const complex<double> nu_m = 0.5*(lp + beta_bar - nu_bar);

  const complex<double> mu_p = 0.5*(lp - beta_bar + nu_bar);
  const complex<double> mu_m = 0.5*(lp - beta_bar - nu_bar);
  
  const complex<double> Gamma_product_in = (!S_matrix_pole) ? (exp (log_Gamma (lp) + log_Gamma (beta_bar) - log_Gamma (nu_p) - log_Gamma (nu_m))) : (0.0);
  const complex<double> Gamma_product_out = exp (log_Gamma (lp) + log_Gamma (-beta_bar) - log_Gamma (mu_p) - log_Gamma (mu_m));

  C0 = sqrt (Lambda*(1.0 - a))*pow (Lambda*s , l + 1);

  Cplus = Gamma_product_out*exp (-Ik*r1);

  Cminus = Gamma_product_in*exp (Ik*r1);
  
  CG = Cplus + Cminus;

  CF = I*(Cplus - Cminus);

  wf_bef_R_tab_uniform(0) = 0.0;
  
  dwf_bef_R_tab_uniform(0) = (l == 0) ? (C0) : (0.0);

  d2wf_bef_R_tab_uniform(0) = (l == 1) ? (2.0*C0) : (0.0);

  for (unsigned int loop = 0 ; loop <= 1 ; loop++)
    {
      const unsigned int N_points = (loop == 0) ? (N_bef_R_uniform) : (N_bef_R_GL);

      const unsigned int i_min = (loop == 0) ? (1) : (0);

      class array<complex<double> > &wf_tab   = (loop == 0) ? (wf_bef_R_tab_uniform)   : (wf_bef_R_tab_GL);
      class array<complex<double> > &dwf_tab  = (loop == 0) ? (dwf_bef_R_tab_uniform)  : (dwf_bef_R_tab_GL);
      class array<complex<double> > &d2wf_tab = (loop == 0) ? (d2wf_bef_R_tab_uniform) : (d2wf_bef_R_tab_GL);

      for (unsigned int i = i_min ; i < N_points ; i++)
	{
	  const double r = (loop == 0) ? (r_bef_R_tab_uniform(i)) : (r_bef_R_tab_GL(i));

	  PTG_wf_dwf_d2wf_calc (PTG_potential , r , wf_tab(i) , dwf_tab(i) , d2wf_tab(i));
	}
    }

  complex<double> dummy = 0.0;
  
  PTG_wf_dwf_d2wf_calc (PTG_potential , R0 , wf_R0 , dwf_R0 , dummy);
}












// Calculation of the spherical state eigenstate of a PTG potential
// ----------------------------------------------------------------

void spherical_state::PTG_eigenstate_calc (
					   const bool is_there_cout ,
					   const class PTG_class &PTG_potential)
{
  if (potential != PTG_POTENTIAL) error_message_print_abort ("spherical_state::PTG_eigenstate_calc is used with the PTG potential only");

  PTG_bef_R_constants_wfs_calc (PTG_potential);

  const complex<double> PTG_state_norm = PTG_state_norm_calc (PTG_potential);
  
  if ((THIS_PROCESS == MASTER_PROCESS) && S_matrix_pole && is_there_cout) 
    {
      const double real_E = real (E);
      
      const double Gamma = -2000.0*imag (E);
      
#ifdef UseOpenMP
#pragma omp critical
#endif
      cout << *this << " " << particle << " k:" << k << " fm^(-1) E:" << real_E << " MeV" << " G:" << Gamma << " keV    PTG state norm : " << PTG_state_norm << endl;
    } 

  if (are_there_scaled_wfs)
    {	
      scaled_wf_aft_R_tab_uniform  = 0.0;
      scaled_dwf_aft_R_tab_uniform = 0.0;

      scaled_wf_aft_R_tab_GL  = 0.0;
      scaled_dwf_aft_R_tab_GL = 0.0;

      for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
    }

  if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();
  
  normalization (1.0/PTG_state_norm);

  if (is_it_real ()) make_it_real ();

  is_k_OK = true;
}




// Calculation of the spherical state eigenstate of a modified PTG potential
// -------------------------------------------------------------------------
// The wave function is a wave function up to r_asy and is a linear combination of Coulomb wave function afterwards.
// Hence, one uses an intermediate PTG wave function to calculate the wave function up to r_asy.
// The usual routines are use when r >= r_asy to calculate the wave function in the asymptotic region.
// One must have R = r_asy

void spherical_state::modified_PTG_eigenstate_calc (
						    const bool is_there_cout ,
						    class potentials_effective_mass &T ,
						    const bool scaled_tables_calc)
{
  if (potential != MODIFIED_PTG_POTENTIAL) error_message_print_abort ("spherical_state::PTG_eigenstate_calc is used with the modified PTG potential only");

  if (!is_k_OK) return;
		
  const bool no_barrier = (is_it_PTG_like_determine (potential) || ((l == 0) && ((particle_charge_determine (particle) == 0) || (Z_charge == 0))));

  const class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();

  const double Lambda = modified_PTG_potential.get_Lambda ();

  const double s = modified_PTG_potential.get_s ();
	  
  const double nu = modified_PTG_potential.get_nu ();
	
  const double a = modified_PTG_potential.get_a ();
  
  const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
  
  if (no_barrier)
    {
      potential = PTG_POTENTIAL;

      PTG_eigenstate_calc (is_there_cout , PTG_potential);
      
      potential = MODIFIED_PTG_POTENTIAL;

      return;
    }
  	
  const double r_asy = modified_PTG_potential.get_r_asy ();
  
  const double E_barrier = modified_PTG_potential.get_E_barrier ();
  
  if (abs (R - r_asy) > precision) error_message_print_abort ("R and r.max[PTG] must be equal in spherical_state::modified_PTG_eigenstate_calc");
  
  const double nu_mass_equivalent = kinetic_factor/two_amu_over_hbar_square;
    
  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  E = k*k/kinetic_factor;

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k , eta , NADA);

  const complex<double> E_no_barrier = E - E_barrier;

  const complex<double> k_no_barrier = sqrt_mod (kinetic_factor*E_no_barrier);

  const int nmax_PTG = 10;
  
  bool S_matrix_pole_PTG = false;
  
  int n_PTG = NADA;
  
  for (int n = 0 ; (n <= nmax_PTG) && (!S_matrix_pole_PTG) ; n++)
    {	  
      const complex<double> kn_PTG = PTG_potential.k_pole_calc (n);
      
      if (inf_norm (kn_PTG - k_no_barrier) < precision) S_matrix_pole_PTG = true , n_PTG = n;
      if (inf_norm (kn_PTG + k_no_barrier) < precision) S_matrix_pole_PTG = true , n_PTG = n; 
    }
      
  class spherical_state u_PTG(false , false , PTG_POTENTIAL , A , 0 , 0 , 0 , N_bef_R_GL , 0 , N_bef_R_uniform , 0 , 0 , 0 , r_asy , NADA , r_asy , r_asy , 0 , 0 ,
			      S_matrix_pole_PTG , particle , n_PTG , NADA , l , j , false , k_no_barrier , nu_mass_equivalent , 1 , 1);
  
  u_PTG.PTG_eigenstate_calc (false , PTG_potential);
      
  C0 = u_PTG.C0;
  
  wf_bef_R_tab_uniform = u_PTG.wf_bef_R_tab_uniform;
  dwf_bef_R_tab_uniform = u_PTG.dwf_bef_R_tab_uniform;
  d2wf_bef_R_tab_uniform = u_PTG.d2wf_bef_R_tab_uniform;
  
  wf_bef_R_tab_GL = u_PTG.wf_bef_R_tab_GL;
  dwf_bef_R_tab_GL = u_PTG.dwf_bef_R_tab_GL;
  d2wf_bef_R_tab_GL = u_PTG.d2wf_bef_R_tab_GL;
  
  if (!is_there_effective_mass_determine (potential))
    {
      wf_bef_R_tab_GL_SGI_MSGI = u_PTG.wf_bef_R_tab_GL_SGI_MSGI;
      dwf_bef_R_tab_GL_SGI_MSGI = u_PTG.dwf_bef_R_tab_GL_SGI_MSGI;
      
      wf_R0 = u_PTG.wf_R0;
      dwf_R0 = u_PTG.dwf_R0;
    }
    
  u_PTG.deallocate ();

  const class ODE_integration no_ODE;

  Cplus_Cminus_CF_CG_calc (no_ODE);
  
  if (are_there_scaled_wfs && scaled_tables_calc)
    {
      scaled_wf_aft_R_tab_uniform  = 0.0;
      scaled_dwf_aft_R_tab_uniform = 0.0;

      scaled_wf_aft_R_tab_GL  = 0.0;
      scaled_dwf_aft_R_tab_GL = 0.0;

      for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
    }

  if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();
  
  const complex<double> Gamow_norm_value = Gamow_norm ();
 
#ifdef UseOpenMP
#pragma omp critical
#endif
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole) cout << *this << " norm from complex scaling : " << Gamow_norm_value << endl;
    
  normalization (1.0/Gamow_norm_value);

  if (is_it_real ()) make_it_real ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole && (real (k) > 0) && (abs (imag (k)) < 1E-3))
    {
      const double log10_width_from_current_formula = log10_width_from_current_formula_calc ();

#ifdef UseOpenMP
#pragma omp critical
#endif
      {
	cout << endl;
	
	print_width_from_current_formula (log10_width_from_current_formula);
      }
    }
}








//--// spherical_state_Skyrme


// Wave function unscaled for the Skyrme interaction.
// --------------------------------------------------
// The Skyrme wave function is calculated with a scaling factor , 1/sqrt(effective_mass) , so one no longer has a velocity dependence.
// This factor is removed here to have the good wave function.
// It has to be taken into account for C0 : C0 -> C0.sqrt[effective_mass (r0)] , with r0 = 0.005.sqrt[l(l + 1)]
// All effective masses are dimensionless here , except full_effective_mass which is in MeV^(-1) fm^{-2}.
//
// Variables:
// ----------
// effective_mass_inv_minus_one_tab_uniform: effective_mass(r)-1 on [0:R] with N_bef_R_uniform points.
// effective_mass_inv_der_tab_uniform : derivative of effective_mass(r) on [0:R] with N_bef_R_uniform points.
// effective_mass_inv_2der_tab_uniform : second derivative of effective_mass(r) on [0:R] with N_bef_R_uniform points.
// effective_mass_inv_minus_one_tab_GL: effective_mass(r)-1 on [0:R] with N_bef_R_GL Gaussian points.
// effective_mass_inv_der_tab_GL : derivative of effective_mass(r) on [0:R] with N_bef_R_GL Gaussian points.
// effective_mass_inv_2der_tab_GL : second derivative of effective_mass(r) on [0:R] with N_bef_R_GL Gaussian points.
// scaled_wf : wave function with the scaling factor , 1/sqrt(effective_mass).
// scaled_dwf : derivative of the wave function with the scaling factor , 1/sqrt(effective_mass).
// scaled_d2wf : second derivative of the wave function with the scaling factor , 1/sqrt(effective_mass).
// effective_mass_r , sqrt_effective_mass_r : effective mass in r , its square root.
// effective_mass_inv_log_der : derivative of the logarithm of the inverse of the effective mass.
// effective_mass_inv_log_2der : second derivative of the logarithm of the inverse of the effective mass.
// effective_mass : splines interpolation of the effective mass
// C0 : factor so u(r) ~ C0.r^{l + 1} for r->0
// r0 :  0.005.sqrt[l(l + 1)]


void spherical_state::unscale_wave_function (
					     const class potentials_effective_mass &T , 
					     const class array<double> &effective_mass_inv_minus_one_tab_uniform , 
					     const class array<double> &effective_mass_inv_der_tab_uniform , 
					     const class array<double> &effective_mass_inv_2der_tab_uniform , 
					     const class array<double> &effective_mass_inv_minus_one_tab_GL , 
					     const class array<double> &effective_mass_inv_der_tab_GL , 
					     const class array<double> &effective_mass_inv_2der_tab_GL)
{
  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
    {
      const complex<double> scaled_wf   = wf_bef_R_tab_uniform(i);
      const complex<double> scaled_dwf  = dwf_bef_R_tab_uniform(i);
      const complex<double> scaled_d2wf = d2wf_bef_R_tab_uniform(i);

      const double effective_mass_r = 1.0/(1.0 + effective_mass_inv_minus_one_tab_uniform(i));

      const double sqrt_effective_mass_r = sqrt (effective_mass_r);

      const double effective_mass_inv_log_der = effective_mass_inv_der_tab_uniform(i)*effective_mass_r;

      const double effective_mass_inv_log_2der = effective_mass_inv_2der_tab_uniform(i)*effective_mass_r - effective_mass_inv_log_der*effective_mass_inv_log_der;

      wf_bef_R_tab_uniform(i) = scaled_wf*sqrt_effective_mass_r;

      dwf_bef_R_tab_uniform(i) = scaled_dwf*sqrt_effective_mass_r - 0.5*wf_bef_R_tab_uniform(i)*effective_mass_inv_log_der;

      d2wf_bef_R_tab_uniform(i) = (scaled_d2wf - 0.5*scaled_dwf*effective_mass_inv_log_der)*sqrt_effective_mass_r; 

      d2wf_bef_R_tab_uniform(i) -= 0.5*(dwf_bef_R_tab_uniform(i)*effective_mass_inv_log_der + wf_bef_R_tab_uniform(i)*effective_mass_inv_log_2der);
    }

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const complex<double> scaled_wf   = wf_bef_R_tab_GL(i);
      const complex<double> scaled_dwf  = dwf_bef_R_tab_GL(i);
      const complex<double> scaled_d2wf = d2wf_bef_R_tab_GL(i);

      const double effective_mass_r = 1.0/(1.0 + effective_mass_inv_minus_one_tab_GL(i));

      const double sqrt_effective_mass_r = sqrt (effective_mass_r);

      const double effective_mass_inv_log_der = effective_mass_inv_der_tab_GL(i)*effective_mass_r;

      const double effective_mass_inv_log_2der = effective_mass_inv_2der_tab_GL(i)*effective_mass_r - effective_mass_inv_log_der*effective_mass_inv_log_der;

      wf_bef_R_tab_GL(i) = scaled_wf*sqrt_effective_mass_r;

      dwf_bef_R_tab_GL(i) = scaled_dwf*sqrt_effective_mass_r - 0.5*wf_bef_R_tab_GL(i)*effective_mass_inv_log_der;

      d2wf_bef_R_tab_GL(i) = (scaled_d2wf - 0.5*scaled_dwf*effective_mass_inv_log_der)*sqrt_effective_mass_r;

      d2wf_bef_R_tab_GL(i) -= 0.5*(dwf_bef_R_tab_GL(i)*effective_mass_inv_log_der + wf_bef_R_tab_GL(i)*effective_mass_inv_log_2der);
    }

  const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();

  const double r0 = 0.005*sqrt (l*(l + 1.0));

  C0 *= sqrt (full_effective_mass (r0)/kinetic_factor);
}




void spherical_state::wave_calculation (
					const bool is_there_cout ,
					class potentials_effective_mass &T , 
					const bool scaled_tables_calc , 
					const class array<double> &effective_mass_inv_minus_one_tab_uniform , 
					const class array<double> &effective_mass_inv_der_tab_uniform , 
					const class array<double> &effective_mass_inv_2der_tab_uniform , 
					const class array<double> &effective_mass_inv_minus_one_tab_GL , 
					const class array<double> &effective_mass_inv_der_tab_GL , 
					const class array<double> &effective_mass_inv_2der_tab_GL)
{
  if (potential == QBOX_POTENTIAL) error_message_print_abort ("No Qbox potential in spherical_state::wave_calculation (effective mass)");
  
  if (!is_there_effective_mass_determine (potential)) error_message_print_abort ("Do not put effective mass tables parameters in spherical_state::wave_calculation (effective mass)");

  if (S_matrix_pole && (matching_point > R)) error_message_print_abort ("One must have R0 <= R in spherical_state for poles in spherical_state::wave_calculation (effective mass)");

  if ((particle == PROTON) && (arg (k) < -M_PI_4))
    {
      ostringstream shell_os;

      shell_os << *this;

      error_message_print_abort ("Proton state " + shell_os.str () + " with arg[k] < -Pi/4. k=" + make_string<complex<double> > (k));
    }

  if (!is_k_OK) return;

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  E = k*k/kinetic_factor;

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k , eta , NADA);
  
  const class ODE_integration ODE(&T , &potentials_effective_mass_F_z_u);

  if (S_matrix_pole)
    {	
      const complex<double> Cplus_bef = Cplus;

      forward_integration_before_R (ODE);

      backward_integration_before_R (ODE);

      Cplus_Cminus_CF_CG_calc (ODE);

      const complex<double> Cplus_ratio = Cplus/Cplus_bef;

      normalization_before_R_after_matching_point (Cplus_ratio);

      d2wf_calc_before_R (T);

      if (are_there_scaled_wfs && scaled_tables_calc)
	{
	  scaled_wf_aft_R_tab_uniform = 0.0;
	  scaled_dwf_aft_R_tab_uniform = 0.0;

	  scaled_wf_aft_R_tab_GL = 0.0;
	  scaled_dwf_aft_R_tab_GL = 0.0;

	  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
	}
    }
  else
    {
      forward_integration_before_R (ODE); 

      Cplus_Cminus_CF_CG_calc (ODE);

      d2wf_calc_before_R (T);

      if (are_there_scaled_wfs && scaled_tables_calc)
	{
	  scaled_wf_aft_R_tab_uniform = 0.0;
	  scaled_dwf_aft_R_tab_uniform = 0.0;

	  scaled_wf_aft_R_tab_GL = 0.0;
	  scaled_dwf_aft_R_tab_GL = 0.0;

	  for (unsigned int angle_index = 0 ; angle_index < 4 ; angle_index++) out_ingoing_waves_after_R (angle_index);
	}
    }

  if (R_real_max > 0.0) wave_after_R_real_axis_tab_GL ();

  unscale_wave_function (T , effective_mass_inv_minus_one_tab_uniform , effective_mass_inv_der_tab_uniform , effective_mass_inv_2der_tab_uniform ,
			 effective_mass_inv_minus_one_tab_GL , effective_mass_inv_der_tab_GL , effective_mass_inv_2der_tab_GL);

  const complex<double> Gamow_norm_value = Gamow_norm ();
  
#ifdef UseOpenMP
#pragma omp critical
#endif
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole) cout << *this << " norm from complex scaling : " << Gamow_norm_value << endl;
  
  normalization (1.0/Gamow_norm_value);

  if (is_it_real ()) make_it_real ();
  
  if ((THIS_PROCESS == MASTER_PROCESS) && is_there_cout && S_matrix_pole && (real (k) > 0) && (abs (imag (k)) < 1E-3))
    {
      const double log10_width_from_current_formula = log10_width_from_current_formula_calc ();
	  
#ifdef UseOpenMP
#pragma omp critical
#endif
      {
	cout << endl;
	
	print_width_from_current_formula (log10_width_from_current_formula);
      }
    }
}



//--// spherical_state_starting_point



// Test of presence of k
// ---------------------
// One calculates the Jost function between E_debut and E_end with 2, ... , 2048 points, tried if nothing is found.
// One then takes into account Re[Jost(k)] if |Re[Jost(k)]| > |Im[Jost(k)]| and Im[Jost(k)] if not.
// If Re(Im)[Jost(k)] changes sign and |Re(Im)[Jost(k)]| < 10 (otherwise it is a singularity coming from Coulomb wave function cuts),
// it means that Re(Im)[Jost(k)] has a zero in [k_debut:k_end] , 
// and one returns true as "k is here" (or very close if k is complex) , as well as the corresponding boundaries.
// If not , one returns false and E_debut and E_end are unchanged.
// Antibound states are considered only for l = 0 neutrons or Z_charge = 0.
//
// Variables:
// ----------
// is_it_antibound : true if one looks for antibound state , false if not.
// E_debut : first energy of the energy interval where the bisection method can be done.
// E_end : end energy of the energy interval where the bisection method can be done.
// N : number of intervals in [E_debut:E_end]. It is fixed at 2, ... , 2048 points.
// dE : length of a small interval between E_debut and E_end. It is (E_end - E_debut)/N.
// E_bef , E_aft : beginning and end of a small interval of length dE. 
//               E_bef is initialized at E_debut , E_aft at E_debut + dE and are incremented by dE in a loop.
// Jost_bef , Jost_aft : Jost functions at E_bef and E_aft.
// real_Jost_bef : Re[Jost(k_bef)] if |Re[Jost(k_bef)]| > |Im[Jost(k_bef)]| and Im[Jost(k_bef)] if not.
// real_Jost_aft : Re[Jost(k_aft)] if |Re[Jost(k_bef)]| > |Im[Jost(k_bef)]| and Im[Jost(k_aft)] if not.
// is_it_real_part : true if |Re[Jost(k_bef)]| > |Im[Jost(k_bef)]| or if it is a proton , false if not.
// Re_J_bef , Im_J_bef: real and imaginary part of the Jost function in k_bef.
// Re_J_aft , Im_J_aft: real and imaginary part of the Jost function in k_aft.

bool spherical_state::is_it_here (
				  class potentials_effective_mass &T ,
				  const unsigned int N , 
				  const bool is_it_antibound ,
				  double &E_debut ,
				  double &E_end) const
{ 
  const double sign = (is_it_antibound) ? (-1.0) : (1.0);

  const double dE = (E_end - E_debut)/static_cast<double> (N);

  double E_bef = E_debut;

  const complex<double> k_debut = sign*sqrt (complex<double> (E_debut*kinetic_factor));

  const complex<double> eta_debut = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_debut);

  const bool is_charged_case = ((Z_projectile_determine (particle) > 0) && (Z_charge > 0));

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_debut , eta_debut , NADA);
      
  complex<double> Jost_bef = Jost (T , particle , R , matching_point , C0 , Cplus);
        
  for (unsigned int i = 1 ; i <= N ; i++)
    {
      const double E_aft = E_debut + i*dE;

      const complex<double> k_aft = sign*sqrt (complex<double> (E_aft*kinetic_factor));
      
      const complex<double> eta_aft = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_aft);
      
      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_aft , eta_aft , NADA);

      const complex<double> Jost_aft = Jost (T , particle , R , matching_point , C0 , Cplus);
      
      const double Re_J_bef = real (Jost_bef);
      const double Im_J_bef = imag (Jost_bef);

      const double Re_J_aft = real (Jost_aft);
      const double Im_J_aft = imag (Jost_aft);

      const bool is_it_real_part = (is_charged_case) || (abs (Re_J_bef) > abs (Im_J_bef));

      const double real_Jost_bef = (is_it_real_part) ? (Re_J_bef) : (Im_J_bef);
      const double real_Jost_aft = (is_it_real_part) ? (Re_J_aft) : (Im_J_aft);
      	  
      if ((abs (real_Jost_bef) < 10.0) && (SIGN (real_Jost_bef) != SIGN (real_Jost_aft)))
	{
	  E_debut = E_bef;
	  
	  E_end = E_aft;

	  return true;
	} 

      E_bef = E_aft;
      
      Jost_bef = Jost_aft;
    }

  if ((particle != PROTON) && (E_debut > 0.0))
    {
      E_bef = E_debut;

      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_debut , eta_debut , NADA);
      
      Jost_bef = Jost (T , particle , R , matching_point , C0 , Cplus);

      for (unsigned int i = 1 ; i <= N ; i++)
	{
	  const double E_aft = E_debut + i*dE;

	  const complex<double> k_aft = sign*sqrt (complex<double> (E_aft*kinetic_factor));

	  const complex<double> eta_aft = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_aft);

	  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_aft , eta_aft , NADA);

	  const complex<double> Jost_aft = Jost (T , particle , R , matching_point , C0 , Cplus);

	  const double Re_J_bef = real (Jost_bef);
	  const double Re_J_aft = real (Jost_aft);

	  if (SIGN (Re_J_bef) != SIGN (Re_J_aft)) 
	    {
	      E_debut = E_bef;

	      E_end = E_aft;

	      return true;
	    } 

	  E_bef = E_aft;

	  Jost_bef = Jost_aft;
	}
    }

  return false;
}





// Bisection method to find a good guess for k if k~0.
// ---------------------------------------------------
// If the harmonic oscillator energy guess is between -1 and 1 MeV,  this guess may be bad because of threshold effects.
// One then has to determine a better starting point with bisection.
// One calculates firstly the Jost function between E = 0 MeV and E = 2 MeV with 2 points (with barrier).
// If a change of sign is encountered, then there is a zero of the wave function : the wave function is a narrow resonant state.
// If not, one looks for a bound state between E = -2 Mev and E = 0 MeV (with barrier) or E = -1E-2 MeV (without barrier) with 8 points (128 with electron as it is less stable). 
// If nothing is found, and l=0 for an uncharged particle, one looks for an antibound state the same way.
// One augments the number of points until 2048 points in case zeroes are well hidden.
// As the width is very small, Re[Jost(k_app)] = 0 or Im[Jost(k_app)] = 0 for a real k_app very close to the exact k, which is complex.
// One then turns to the bisection method to find this very good guess of k for the Newton-Raphson method.
// If a change of sign is encountered for Re[Jost] or Im[Jost] (see above), then there is a zero of Re[Jost] or Im[Jost] in this interval.
// One then turns to the bisection method for a very good guess for the Newton-Raphson method.
// If nothing is found, is_k_OK is put to false and one exits the routine.
//
// Variables:
// ----------
// Nmin: minimal number of points for location: 8 for nucleon, 128 for electron
// bound_E_debut : debut of the real energy interval for bound and antibound states (l=0, neutron).
// bound_E_end : end of the real energy interval for bound and antibound states (l=0, neutron).
// res_E_debut : debut of the real energy interval for resonant states.
// res_E_end : end of the real energy interval for resonant states.
// bound_found : true if there is a bound state in [bound_E_debut:bound_E_end], false if not.
// res_found : true if there is a resonant state near [res_E_debut:res_E_end], false if not.
// antibound_found : true if there is a antibound state in [bound_E_debut:bound_E_end], false if not.
// E_debut : bound_E_debut if bound_found is true, res_E_debut if res_found is true.
// E_end : bound_E_end if bound_found is true, res_E_end if res_found is true.
// Jost_debut : Jost(k_debut)
// is_it_real_part : true if |Re[Jost(k_debut)]| > |Im[Jost(k_debut)]| or if it is a proton, false if not.
// real_Jost_debut : Re[Jost(k_debut)] if is_it_real_part is true, Im[Jost(k_debut)] if not.
// E_middle, k_middle : energy and k in the middle of the bisection interval at each iteration.
// k_debut : sqrt [E_debut.kinetic_factor].
// real_Jost_middle : Re[Jost(k_middle)] if is_it_real_part is true and Im[Jost(k_middle)] if not.
// test : test to know if the bisection has converged. It is inf_norm (E_debut/E_end - 1.0).
// Re_J_debut, Im_J_debut: real and imaginary part of the Jost function in k_debut
// Re_J_middle, Im_J_middle: real and imaginary part of Jost function in k_middle

void spherical_state::k_bisection (class potentials_effective_mass &T)
{  
  const bool no_barrier = (l == 0) && ((particle_charge_determine (particle) == 0) || (Z_charge == 0));
  
  const unsigned int Nmin = ((particle == ELECTRON) || (potential == MODIFIED_PTG_POTENTIAL)) ? (128) : (8);

  double bound_E_debut = (particle == ELECTRON) ? (-0.01) : (-2.0);
  double bound_E_end = (no_barrier) ? (-precision) : (0.0);

  double antibound_E_debut = (particle == ELECTRON) ? (-0.01) : (-2.0);
  double antibound_E_end = -precision;

  double resonance_E_debut = 0.0;
  double resonance_E_end = (particle == ELECTRON) ? (0.01) : (2.0);

  bool resonance_found = false;
  bool bound_found     = false;
  bool antibound_found = false;

  if (potential != MODIFIED_PTG_POTENTIAL)
    {
      for (unsigned int N = Nmin ; (N <= 2048) && (!bound_found && !antibound_found && !resonance_found) ; N *= 2)
	{
	  resonance_found = (!no_barrier) && is_it_here (T , N , false , resonance_E_debut , resonance_E_end);
	        
	  if (!resonance_found) bound_found = is_it_here (T , N , false , bound_E_debut , bound_E_end);

	  if (!bound_found && !resonance_found) antibound_found = is_it_here (T , N , true , antibound_E_debut , antibound_E_end);	  
	}
    }
  else
    {
      for (unsigned int N = Nmin ; (N <= 2048) && (!bound_found && !antibound_found && !resonance_found) ; N *= 2)
	{
	  bound_found = is_it_here (T , N , false , bound_E_debut , bound_E_end);

	  if (!bound_found) resonance_found = (!no_barrier) && is_it_here (T , N , false , resonance_E_debut , resonance_E_end);
	  
	  if (!bound_found && !resonance_found) antibound_found = is_it_here (T , N , true , antibound_E_debut , antibound_E_end);
	}      
    }
  
  if (!bound_found && !antibound_found && !resonance_found) 
    {
      is_k_OK = false; 

      return;
    }
 
  double E_debut = 0.0;
  double E_end = 0.0;
  
  if (bound_found)
    {
      E_debut = bound_E_debut;
      
      E_end = bound_E_end;
    }
  
  if (antibound_found)
    {
      E_debut = antibound_E_debut;

      E_end = antibound_E_end;
    }
  
  if (resonance_found)
    {
      E_debut = resonance_E_debut;

      E_end = resonance_E_end;
    }
  
  const double sign = (antibound_found) ? (-1.0) : (1.0);
  
  const complex<double> k_debut = sign*sqrt (complex<double> (E_debut)*kinetic_factor);
  
  const complex<double> eta_debut = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_debut);

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_debut , eta_debut , NADA);

  complex<double> Jost_debut = Jost (T , particle , R , matching_point , C0 , Cplus);

  const double Re_J_debut = real (Jost_debut);

  const double Im_J_debut = imag (Jost_debut);
  
  const bool is_it_real_part = (particle == PROTON) || (abs (Re_J_debut) > abs (Im_J_debut));
  
  double real_Jost_debut = (is_it_real_part) ? (Re_J_debut) : (Im_J_debut);

  double test = 1.0;

  do
    {
      const double E_middle = E_debut + 0.5*(E_end - E_debut);
      
      const complex<double> k_middle = sign*sqrt (complex<double> (E_middle)*kinetic_factor);

      const complex<double> eta_middle = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_middle);

      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_middle , eta_middle , NADA);

      const complex<double> Jost_middle = Jost (T , particle , R , matching_point , C0 , Cplus);
      
      const double Re_J_middle = real (Jost_middle);
      const double Im_J_middle = imag (Jost_middle);

      const double real_Jost_middle = (is_it_real_part) ? (Re_J_middle) : (Im_J_middle);
      	  
      if (SIGN (real_Jost_debut) != SIGN (real_Jost_middle))
	E_end = E_middle;
      else
	{
	  E_debut = E_middle;
	  
	  real_Jost_debut = real_Jost_middle;
	}

      test = inf_norm (E_debut/E_end - 1.0);
    }
  while (test > precision);

  is_k_OK = true;
  
  k = sign*sqrt (complex<double> (E_debut)*kinetic_factor);

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  E = E_debut;
}






// Calculation of a k guess for very broad resonant states
// -------------------------------------------------------
// If the k PTG guess is not bound, the state is either very broad or does not exist.
// Hence, the best one can do is to look for the best k on a grid for which Gamma > 0
// This is done for Re[k] in [Re_k_min:Re_k_max] and |Im[k]| in [abs_Im_k_min:abs_Im_k_max], so that E > 0 and Gamma > 1 MeV and Gamma < 20 MeV. 
// The latter condition allows to avoid narrow resonant states, otherwise obtained with the other techniques if it is under the barrier, as is virtually always the case, and too broad states, which are meaningless.
//
// Variables:
// ----------
// Re_k_min, Re_k_max : k is searched for Re[k] in [Re_k_min:Re_k_max]
// abs_Im_k_min, abs_Im_k_max : k is searched for |Im[k]| in [abs_Im_k_min:abs_Im_k_max]
// Nk: number of k points on [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max]
// Re_k_step, abs_Im_k_step: steps on intervals [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max]
// Gamma_min: minimal Gamma accepted. It is 1 MeV.
// i_Re, i_Im, k_try, Re_k_try, abs_Im_k_try: k guess, its real and imaginary parts equal to
//                                        Re_k_min + i_Re.Re_k_step and abs_Im_k_min + i_Im.abs_Im_k_step
// E_tilde_try, E_try, Gamma_try: complex energy, energy and width associated to k_try
// inf_norm_Jost_k, inf_norm_Jost_k_try: |Jost function at k_try|oo, |Jost function at k_try|oo , 

void spherical_state::broad_state_k_guess (
					   class potentials_effective_mass &T ,
					   const unsigned int Nk , 
					   const double Re_k_min ,
					   const double Re_k_max , 
					   const double abs_Im_k_min ,
					   const double abs_Im_k_max)
{
  const double Re_k_step = (Re_k_max - Re_k_min)/Nk;

  const double abs_Im_k_step = (abs_Im_k_max - abs_Im_k_min)/Nk;
  
  const double Gamma_min = (particle == ELECTRON) ? (0.005) : (1.0);
  const double Gamma_max = (particle == ELECTRON) ? (1.0) : (20.0);

  double inf_norm_Jost_k = INFINITE;

  for (unsigned int i_Re = 0 ; i_Re <= Nk ; i_Re++)
    for (unsigned int i_Im = 0 ; i_Im <= Nk ; i_Im++)
      {
	const double Re_k_try = Re_k_min + i_Re*Re_k_step;

	const double abs_Im_k_try = abs_Im_k_min + i_Im*abs_Im_k_step;
	
	const complex<double> k_try(Re_k_try , -abs_Im_k_try);

	const complex<double> E_tilde_try = k_try*k_try/kinetic_factor;
	
	const double E_try = real (E_tilde_try);

	const double Gamma_try = -2.0*imag (E_tilde_try);

	if ((E_try > 0) && (Gamma_try > Gamma_min) && (Gamma_try < Gamma_max))
	  {
	    const complex<double> eta_try = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_try);

	    T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_try , eta_try , NADA);

	    const double inf_norm_Jost_k_try = inf_norm (Jost (T , particle , R , matching_point , C0 , Cplus));
	    
	    if (inf_norm_Jost_k_try < inf_norm_Jost_k) k = k_try , inf_norm_Jost_k = inf_norm_Jost_k_try;
	  }
      }
}










// Calculation of the number of bound and narrow resonant states and energy guess from HO diagonalization
// ------------------------------------------------------------------------------------------------------
// To fit the PTG potential to the integrated potential, one needs to know the number of its bound states.
// They correspond to bound and narrow resonant states of the integrated potential.
// Their number is taken as the number of physical bound states obtained with HO diagonalization , 
// which are found with the overlap method (75% of occupation at least in a single HO basis state).


// Variables:
// ----------
// E_HO_guess : energy guess given by a diagonalization on a harmonic oscillator basis.
// N_bound : number of bound and narrow resonant states given by the HO diagonalization.
//           It is used to initialize nu of the PTG potential.
// b_HO : HO length of the used HO basis to diagonalize the considered potential
// sqrt_0p75: sqrt[0.75]. The overlap method is considered successful if the calculated state has an overlap of 75% with a basis state.
// HO matrix: matrix of the considered potential in the HO basis
// eigenvalues: eigenvalues of the HO matrix
// i_try: component index of the vector which has the largest overlap with a given basis state.

void spherical_state::N_bound_E_HO_guess (
					  class potentials_effective_mass &T ,
					  unsigned int &N_bound ,
					  double &E_HO_guess) const
{
  const int nmax_HO = 15;
  
  const int nmax_HO_plus_one = nmax_HO + 1;

  const double b_HO = b_HO_calc ();

  const double sqrt_0p75 = 0.866025403784439;

  class matrix<double> HO_matrix(nmax_HO_plus_one);

  HO_matrix_calc (T , b_HO , HO_matrix);

  class array<double> eigenvalues(nmax_HO_plus_one);

  total_diagonalization::all_eigenpairs (HO_matrix , eigenvalues);

  int i_try = 0;
  
  N_bound = 0;
  
  for (int i = 0 ; i <= nmax_HO ; i++) 
    {
      const class vector_class<double> &HO_eigenvector_try = HO_matrix.eigenvector(i_try);
      const class vector_class<double> &HO_eigenvector = HO_matrix.eigenvector(i);
      
      if (abs (HO_eigenvector(n)) > abs (HO_eigenvector_try(n))) i_try = i;
      
      for (int j = 0 ; j <= nmax_HO ; j++)
	{
	  if (abs (HO_eigenvector(j)) > sqrt_0p75) N_bound++;
	}
    }

  const class vector_class<double> &HO_eigenvector_try = HO_matrix.eigenvector(i_try);
  
  //E_HO_guess = eigenvalues(i_try);
  E_HO_guess = (abs (HO_eigenvector_try(n)) > sqrt_0p75) ? (eigenvalues(i_try)) : (eigenvalues(n));
}







double spherical_state::b_HO_calc () const
{
  if (particle == ELECTRON)
    return 1.0; // arbitrary
  else
    {
      const double A_composite = A;

      const double A_projectile = A_projectile_determine (particle);

      const double b_HO = pow (A_composite , 0.1666666666666667)/sqrt (A_projectile);
      
      return b_HO;
    }
}




// Calculation of the k guess given by the best PTG potential fitting the potential to integrate.
// ----------------------------------------------------------------------------------------------
// One finds here a PTG potential very close to the potential to integrate.
// For the Skyrme interaction , the effective mass parameter a is taken from the effective mass value at r=0 , otherwise it is zero.
// One approximates the barrier by a constant E_barrier added to the PTG potential.
// E_barrier is the value of the barrier at r_barrier = i_barrier.step_bef_R_uniform (see spherical_state_potential.cpp).
// One uses this method when the HO and bisection methods failed to give a very accurate result.
// nu varies between 2.N_bound + l and 2.N_bound + l + 2 , as it is only in this zone that one has N_bound bound and narrow resonant states.
// If the integrated potential is PTG, the guess is exact and is returned.
// The value of k_PTG without barrier is returned for the general case as its value in the complex plane is related to the bound, antibound or resonant character of the guess.
// Note that the guess is exact if one considers a modified PTG potential where E[barrier] = 0.
//
// Variables:
// ----------
// N_bound : number of bound and narrow resonant states of the potential.
// Lambda , s , nu : parameters of the PTG potential to fit to the potential to integrate.
// test_PTG: precision of the PTG potential fit
// a: effective mass parameter of the PTG potential. One has , with everything dimensionless , a = 1 - effective_mass(r) for Skyrme and a = 0 if not.
// k_PTG_no_barrier, E_PTG_no_barrier : k and energy guess without barrier for modified PTG potential (see above).
// k_PTG, E_PTG : k and energy guess (see above).

complex<double> spherical_state::k_PTG_guess (
					      const class potentials_effective_mass &T ,
					      const unsigned int N_bound) const
{
  if (potential != MODIFIED_PTG_POTENTIAL)
    {
      const class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();
  
      const double a = (is_there_effective_mass_determine (potential)) ? (1.0 - full_effective_mass(0.0)/kinetic_factor) : (0.0);
  
      double Lambda = 0.0;

      double s = 0.0;

      double nu = 0.0;
  
      PTG_potential_fit::parameters_determine (r_bef_R_tab_uniform , particle , T , N_bound , Lambda , s , nu);

      const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);

      const complex<double> k_PTG = PTG_potential.k_pole_calc (n);
  
      return k_PTG;
    }
  else
    {
      const class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();
        
      const double Lambda = modified_PTG_potential.get_Lambda ();

      const double s = modified_PTG_potential.get_s ();
	  
      const double nu = modified_PTG_potential.get_nu ();
	
      const double a = modified_PTG_potential.get_a ();
	
      const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
  
      const complex<double> k_PTG = PTG_potential.k_pole_calc (n);
      	
      return k_PTG;
    }
}

//ofstream out_file("out");
//const class PTG_class V_PTG(kinetic_factor , l , Lambda , s , nu , a);
//for (unsigned int iii = 1 ; iii < N_bef_R_uniform ; iii++)
//{
//  const double r = r_bef_R_tab_uniform_tab(iii)
//  out_file << r << " " << real (T.potential_calc (r)) + l*(l + 1)/(r*r)/kinetic_factor << " " << V_PTG(r) + E_barrier + l*(l + 1)/(r*r)/kinetic_factor << " " << endl;
//}
//out_file.close ();

// ofstream out_file("out");
// const class PTG_class V_PTG(kinetic_factor , l , Lambda , s , nu , a);
// const class splines_class<double> &full_effective_mass_splines = T.get_full_effective_mass ();
// for (unsigned int iii = 1 ; iii < N_bef_R_uniform ; iii++)
// {
//   const double r = r_bef_R_tab_uniform_tab(iii)
//   out_file << r << " " << real (T.potential_calc (r)) + l*(l + 1)/(r*r)/kinetic_factor << " " << V_PTG(r) + E_barrier + l*(l + 1)/(r*r)/kinetic_factor << " "
//				<< full_effective_mass_splines(r)/kinetic_factor << "   " << V_PTG.effective_mass (r)/kinetic_factor << endl;
// }





// Calculation of a k guess to start the Newton-Raphson method.
// ------------------------------------------------------------
// First, one calculates a energy guess with a diagonalization on a harmonic oscillator basis.
// If the energy guess is smaller than -1 MeV, it is good and accepted.
// If |Jost(k_HO)/Jost'(k_HO)/k_HO|oo < 1E-3, the guess is also good and accepted.
// If not, one sees if k = 0 is a good approximation, as the k~0 zone is numerically unstable.
// Then, if it is not, one looks if the state is very close to k=0 with k != 0 (|E_HO_guess| < 1 MeV), with a bisection method.
// If it is not there, one fits a PTG potential to the potential one integrates.
// If the guess is a bound state (i.e. Im(k_PTG) > 0), the sought state is very likely a resonant state under the barrier.
// The HO guess is still taken in this case as it is very good for resonant states with non-negligible width and almost exact if the width is negligible.
// If not, the state has a large negative imaginary part, and is refused if all_states is false.
// It one has no barrier and the PTG guess is antibound, it is likely to have a relatively small energy and it is returned.
// Otherwise, one makes a global guess in the complex plane.
// One considers only broad resonant states here, with E > 0 and Gamma > 1 MeV, as the only antibound states of practical interest are those of small energy.
// One searches over [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max], discretized with Nk points each, with a bisection method in the complex plane.
//
// Variables:
// ----------
// all_states : false if one looks only for narrow resonant states, true if not.
// E_no_threshold_effect : one considers that threshold effects are important in [-E_no_threshold_effect:E_no_threshold_effect].
// E_HO_guess : energy guess given by a diagonalization on a harmonic oscillator basis.
// N_bound : number of bound and narrow resonant states given by the HO diagonalization.
//           It is used to initialize nu of the PTG potential.
// k_HO, Jost_k_HO : k corresponding to the HO energy guess, its Jost function.
// k_HO_plus, Jost_k_HO_plus : k corresponding to the HO energy guess plus sqrt_precision, its Jost function.
// Jost_k_der_HO : approximate J'(k_HO), which is [Jost_k_HO_plus-Jost_k_HO]/sqrt_precision.
// Re_k_min, Re_k_max : k is searched for Re[k] in [Re_k_min:Re_k_max]
// abs_Im_k_min, abs_Im_k_max : k is searched for |Im[k]| in [abs_Im_k_min:abs_Im_k_max]
// Re_k, abs_Im_k: real and absolute values of the imaginary part of k obtained after each global optimization of k
// Nk: number of k points on [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max], refined after each iteration.
// iter_max: number of times the intervals [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max] are shrinked to get a better guess.
// Re_k_step, abs_Im_k_step: steps on [Re_k_min:Re_k_max] and [abs_Im_k_min:abs_Im_k_max] discretized with Nk points
// is_it_PTG_bound, is_it_PTG_antibound: true if the PTG guess is bound or antibound, false if nor

void spherical_state::k_guess (
			       class potentials_effective_mass &T ,
			       const bool all_states)
{
  const double E_no_threshold_effect = (particle == ELECTRON) ? (0.005) : (1.0);

  const bool no_barrier = (is_it_PTG_like_determine (potential) || ((l == 0) && ((particle_charge_determine (particle) == 0) || (Z_charge == 0))));
  
  unsigned int N_bound = 0;

  double E_HO_guess = 0.0;
  
  N_bound_E_HO_guess (T , N_bound , E_HO_guess);
  
  if (!all_states && !no_barrier && (E_HO_guess > 1.25*potential_barrier::V_barrier_calc (r_bef_R_tab_uniform , particle , T)))
    {
      is_k_OK = false;
      
      return;
    }
  
  if (no_barrier && (potential == MODIFIED_PTG_POTENTIAL))
    {
      k = k_PTG_guess (T , N_bound);
      
      E = k*k/kinetic_factor;
      
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

      is_k_OK = true;
      
      return;
    }
  
  const complex<double> k_HO = sqrt (complex<double> (E_HO_guess*kinetic_factor));

  const complex<double> eta_k_HO = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_HO);

  if (E_HO_guess < -E_no_threshold_effect) 
    {
      k = k_HO; 
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
      E = E_HO_guess;
      is_k_OK = true;
      
      return;
    }

  if ((E_HO_guess < E_no_threshold_effect) || no_barrier)
    {
      T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , 0.0 , INFINITE , NADA);

      if (!no_barrier)
	{
	  const complex<double> Jost_k_is_zero = Jost (T , particle , R , matching_point , C0 , Cplus);

	  if (inf_norm (Jost_k_is_zero) < precision)
	    {
	      k = E = 0.0;
	      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , precision);
	      is_k_OK = true;
	  
	      return;
	    }
	}
      
      k_bisection (T);

      if (is_k_OK) return;

      if (!no_barrier)
	{
	  k = k_HO;
	  E = E_HO_guess;
	  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
	  is_k_OK = true;
	 
	  return;
	}
    }
  
  // The HO guess has been found to provide convergence in practice with the modified PTG potential for very broad resonances in the presence of a barrier, so that it is directly returned in this case.
  
  if (potential == MODIFIED_PTG_POTENTIAL)
    {
      k = k_HO;
      
      E = E_HO_guess;
            
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
      
      is_k_OK = true;
      
      return;
    }

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_HO , eta_k_HO , NADA);

  const complex<double> Jost_k_HO = Jost (T , particle , R , matching_point , C0 , Cplus);
      
  const complex<double> k_HO_plus = k_HO*(1.0 + sqrt_precision);

  const complex<double> eta_k_HO_plus = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k_HO_plus);

  T.initialize_constants (potential , kinetic_factor , jr , l , Z_charge , j , k_HO_plus , eta_k_HO_plus , NADA);

  const complex<double> Jost_k_HO_plus = Jost (T , particle , R , matching_point , C0 , Cplus);

  const complex<double> Jost_k_der_HO = (Jost_k_HO_plus - Jost_k_HO)/(k_HO_plus - k_HO);

  const double Jost_ratio_k_HO = inf_norm (Jost_k_HO/Jost_k_der_HO/k_HO);

  if (Jost_ratio_k_HO < 1E-3)
    {
      k = k_HO;
      
      E = E_HO_guess;
      
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
      
      is_k_OK = true;
      
      return;
    }

  const complex<double> k_PTG = k_PTG_guess (T , N_bound);
  
  const bool is_it_PTG_bound = (imag (k_PTG) > 0.0);
  
  if (is_it_PTG_bound)
    {
      k = k_HO;
      
      E = E_HO_guess;
      
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);
      
      is_k_OK = true;
    }
  else if (all_states)
    {
      if (no_barrier)
	{
#ifdef UseOpenMP
#pragma omp critical
#endif
	  if (THIS_PROCESS == MASTER_PROCESS) cout << *this << " is either antibound with large |E| or a broad resonance with large |E|. No guess is available." << endl;

	  is_k_OK = false;

	  return;
	}
	 
      const unsigned int Nk = 10;

      const unsigned int iter_max = 5;

      double Re_k_min = 0.0;
      double Re_k_max = 0.5;

      double abs_Im_k_min = 0.0;
      double abs_Im_k_max = 0.5;

      for (unsigned iter = 0 ; iter < iter_max ; iter++)
	{
	  broad_state_k_guess (T , Nk , Re_k_min , Re_k_max , abs_Im_k_min , abs_Im_k_max);
	  
	  const double Re_k = real (k);

	  const double abs_Im_k = abs (imag (k));

	  const double Re_k_step = (Re_k_max - Re_k_min)/Nk;

	  const double abs_Im_k_step = (abs_Im_k_max - abs_Im_k_min)/Nk;

	  Re_k_min = max (Re_k - Re_k_step , Re_k_min);
	  Re_k_max = min (Re_k + Re_k_step , Re_k_max);

	  abs_Im_k_min = max (abs_Im_k - abs_Im_k_step , abs_Im_k_min);
	  abs_Im_k_max = min (abs_Im_k + abs_Im_k_step , abs_Im_k_max);
	}

      E = k*k/kinetic_factor;
      
      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

      is_k_OK = true;
    }
  else
    is_k_OK = false;
}










//--// return the phase shift associated to the spherical state
const complex<double> spherical_state::get_phase_shift () const
{
  const complex<double> minus_half_I (0.0 , -0.5);
  
  const complex<double> phase_shift = minus_half_I*log (-Cplus/Cminus);

  return phase_shift;
}




//--// return the S_matrix associated to the spherical state
const complex<double> spherical_state::get_S_matrix () const
{
  const complex<double> S_matrix = -Cplus/Cminus;

  return S_matrix;
}










//--// Calculation of the overlap between the state and a core state
complex<double> spherical_state::overlap_OCM_core_shell_calc (const class spherical_state &OCM_core_shell) const
{
  const array<complex<double> > &wf_OCM_core_bef_R_tab_GL = OCM_core_shell.wf_bef_R_tab_GL;

  const array<complex<double> > &wf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.wf_aft_R_tab_GL_real;

  complex<double> overlap_OCM_core_shell = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double w = w_bef_R_tab_GL(i);
      
      const complex<double> wf_r = wf_bef_R_tab_GL(i);

      const complex<double> wf_OCM_core_r = wf_OCM_core_bef_R_tab_GL(i);

      overlap_OCM_core_shell += w*wf_r*wf_OCM_core_r;
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL_real(i);
      
      const complex<double> wf_r = wf_aft_R_tab_GL_real(i);

      const complex<double> wf_OCM_core_r = wf_OCM_core_aft_R_tab_GL_real(i);

      overlap_OCM_core_shell += w*wf_r*wf_OCM_core_r;
    }

  return overlap_OCM_core_shell;
}








//--// Orthogonalization between the state and a core state
void spherical_state::OCM_core_shell_orthogonalize (const class spherical_state &OCM_core_shell)
{
  const class array<complex<double> > &wf_OCM_core_bef_R_tab_uniform   = OCM_core_shell.wf_bef_R_tab_uniform;
  const class array<complex<double> > &dwf_OCM_core_bef_R_tab_uniform  = OCM_core_shell.dwf_bef_R_tab_uniform;
  const class array<complex<double> > &d2wf_OCM_core_bef_R_tab_uniform = OCM_core_shell.d2wf_bef_R_tab_uniform;
  
  const class array<complex<double> > &wf_OCM_core_bef_R_tab_GL   = OCM_core_shell.wf_bef_R_tab_GL;
  const class array<complex<double> > &dwf_OCM_core_bef_R_tab_GL  = OCM_core_shell.dwf_bef_R_tab_GL;
  const class array<complex<double> > &d2wf_OCM_core_bef_R_tab_GL = OCM_core_shell.d2wf_bef_R_tab_GL;
  
  const class array<complex<double> > &wf_OCM_core_aft_R_tab_GL_real   = OCM_core_shell.wf_aft_R_tab_GL_real;
  const class array<complex<double> > &dwf_OCM_core_aft_R_tab_GL_real  = OCM_core_shell.dwf_aft_R_tab_GL_real;
  const class array<complex<double> > &d2wf_OCM_core_aft_R_tab_GL_real = OCM_core_shell.d2wf_aft_R_tab_GL_real;

  const complex<double> overlap_OCM_core_shell = overlap_OCM_core_shell_calc (OCM_core_shell);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      wf_bef_R_tab_GL(i)   -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_GL(i);
      dwf_bef_R_tab_GL(i)  -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_GL(i);
      d2wf_bef_R_tab_GL(i) -= overlap_OCM_core_shell*d2wf_OCM_core_bef_R_tab_GL(i);
    }

  for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++) 
    {   
      wf_bef_R_tab_uniform(i)   -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_uniform(i);
      dwf_bef_R_tab_uniform(i)  -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_uniform(i);
      d2wf_bef_R_tab_uniform(i) -= overlap_OCM_core_shell*d2wf_OCM_core_bef_R_tab_uniform(i);
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      wf_aft_R_tab_GL_real(i)   -= overlap_OCM_core_shell*wf_OCM_core_aft_R_tab_GL_real(i);
      dwf_aft_R_tab_GL_real(i)  -= overlap_OCM_core_shell*dwf_OCM_core_aft_R_tab_GL_real(i);
      d2wf_aft_R_tab_GL_real(i) -= overlap_OCM_core_shell*d2wf_OCM_core_aft_R_tab_GL_real(i);
    }   

  if (!is_there_effective_mass_determine (potential))
    {
      const class array<complex<double> > &wf_OCM_core_bef_R_tab_GL_SGI_MSGI  = OCM_core_shell.wf_bef_R_tab_GL_SGI_MSGI;
      const class array<complex<double> > &dwf_OCM_core_bef_R_tab_GL_SGI_MSGI = OCM_core_shell.dwf_bef_R_tab_GL_SGI_MSGI;

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	{
	  wf_bef_R_tab_GL_SGI_MSGI(i)  -= overlap_OCM_core_shell*wf_OCM_core_bef_R_tab_GL_SGI_MSGI(i);
	  dwf_bef_R_tab_GL_SGI_MSGI(i) -= overlap_OCM_core_shell*dwf_OCM_core_bef_R_tab_GL_SGI_MSGI(i);
	}
    }
}






// HO or THO wave function direct filling from tables
// --------------------------------------------------

void spherical_state::wave_fill_from_HO_THO_tables (
						    const double b_HO , 
						    const bool is_it_Gauss_Legendre ,
						    const class array<double> &wfs_R0_tab ,
						    const class array<double> &dwfs_R0_tab ,
						    const class array<double> &wfs_bef_R_tab ,
						    const class array<double> &dwfs_bef_R_tab ,
						    const class array<double> &d2wfs_bef_R_tab)
{ 
  zero ();

  E = (4*n + 2*l + 3)/(b_HO*b_HO*kinetic_factor); // As the energy of a THO state is undefined, one uses that of HO for both HO and THO cases.

  k = sqrt (E * kinetic_factor);

  eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

  is_k_OK = true;

  C0 = HO_wave_functions::HO_3D::C0_calc (b_HO , n , l);

  wf_R0 = wfs_R0_tab(n);
  
  dwf_R0 = dwfs_R0_tab(n);

  if (is_it_Gauss_Legendre)
    {
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL  (i) = wfs_bef_R_tab  (n , i);
	  dwf_bef_R_tab_GL (i) = dwfs_bef_R_tab (n , i);
	  d2wf_bef_R_tab_GL(i) = d2wfs_bef_R_tab(n , i);
	}
    }
  else
    {
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform  (i) = wfs_bef_R_tab  (n , i);
	  dwf_bef_R_tab_uniform (i) = dwfs_bef_R_tab (n , i);
	  d2wf_bef_R_tab_uniform(i) = d2wfs_bef_R_tab(n , i);
	}
    }
}


















void spherical_state::wave_calculation_add_from_vector (
							const bool is_energy_defined ,
							const double E_init , 
							const class vector_class<double> &V ,						    
							const class array<unsigned int> &basis_shells_indices , 
							const class array<class spherical_state> &basis_shells) 
{ 
  const int nmax_basis = basis_shells_indices.dimension (0) - 1;

  if (is_energy_defined)
    {
      E = E_init;

      k = sqrt (complex<double> (E * kinetic_factor));

      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

      is_k_OK = true;
    }
  else
    {
      E = k = eta = NADA;

      is_k_OK = false;
    }

  Cplus = Cminus = CF = CG = NADA;

  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const double Vnn = V(nn);

      const unsigned int shell_nn_index = basis_shells_indices(nn);
      
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);
      
      const complex<double> C0_shell_nn = shell_nn.C0;
      
      C0 += Vnn*C0_shell_nn;
    }
  
  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const double Vnn = V(nn);

      const unsigned int shell_nn_index = basis_shells_indices(nn);
      
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);
      
      const complex<double> wf_R0_shell_nn  = shell_nn.wf_R0;
      const complex<double> dwf_R0_shell_nn = shell_nn.dwf_R0;

      wf_R0  += Vnn*wf_R0_shell_nn;
      dwf_R0 += Vnn*dwf_R0_shell_nn;
    }
  
  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const double &Vnn = V(nn);

      const unsigned int shell_nn_index = basis_shells_indices(nn);
	  
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);

      const class array<complex<double> > &wf_nn_bef_R_tab_uniform   = shell_nn.wf_bef_R_tab_uniform;
      const class array<complex<double> > &dwf_nn_bef_R_tab_uniform  = shell_nn.dwf_bef_R_tab_uniform;
      const class array<complex<double> > &d2wf_nn_bef_R_tab_uniform = shell_nn.d2wf_bef_R_tab_uniform;

      const class array<complex<double> > &wf_nn_bef_R_tab_GL   = shell_nn.wf_bef_R_tab_GL;
      const class array<complex<double> > &dwf_nn_bef_R_tab_GL  = shell_nn.dwf_bef_R_tab_GL;
      const class array<complex<double> > &d2wf_nn_bef_R_tab_GL = shell_nn.d2wf_bef_R_tab_GL;
      

      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform(i)   += Vnn*wf_nn_bef_R_tab_uniform(i);
	  dwf_bef_R_tab_uniform(i)  += Vnn*dwf_nn_bef_R_tab_uniform(i);
	  d2wf_bef_R_tab_uniform(i) += Vnn*d2wf_nn_bef_R_tab_uniform(i);
	}
	  
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL(i)   += Vnn*wf_nn_bef_R_tab_GL(i);
	  dwf_bef_R_tab_GL(i)  += Vnn*dwf_nn_bef_R_tab_GL(i);
	  d2wf_bef_R_tab_GL(i) += Vnn*d2wf_nn_bef_R_tab_GL(i);
	}
      
      if (kmax_momentum > 0.0)
	{
	  const class array<complex<double> > &wf_nn_momentum_tab_uniform  = shell_nn.wf_momentum_tab_uniform;
	  const class array<complex<double> > &dwf_nn_momentum_tab_uniform = shell_nn.dwf_momentum_tab_uniform;

	  const class array<complex<double> > &wf_nn_momentum_tab_GL  = shell_nn.wf_momentum_tab_GL;
	  const class array<complex<double> > &dwf_nn_momentum_tab_GL = shell_nn.dwf_momentum_tab_GL;
      
	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      wf_momentum_tab_uniform(i)  += Vnn*wf_nn_momentum_tab_uniform(i);
	      dwf_momentum_tab_uniform(i) += Vnn*dwf_nn_momentum_tab_uniform(i);
	    }
	  
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      wf_momentum_tab_GL(i)  += Vnn*wf_nn_momentum_tab_GL(i);
	      dwf_momentum_tab_GL(i) += Vnn*dwf_nn_momentum_tab_GL(i);
	    }
	}
    }
  
  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {      
      for (int nn = 0 ; nn <= nmax_basis ; nn++)
	{
	  const double Vnn = V(nn);

	  const unsigned int shell_nn_index = basis_shells_indices(nn);
	      
	  const class spherical_state &shell_nn = basis_shells(shell_nn_index);

	  const class array<complex<double> > &wf_nn_bef_R_tab_GL_SGI_MSGI  = shell_nn.wf_bef_R_tab_GL_SGI_MSGI;
	  const class array<complex<double> > &dwf_nn_bef_R_tab_GL_SGI_MSGI = shell_nn.dwf_bef_R_tab_GL_SGI_MSGI;
	  
	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {
	      wf_bef_R_tab_GL_SGI_MSGI(i)  += Vnn*wf_nn_bef_R_tab_GL_SGI_MSGI(i);
	      dwf_bef_R_tab_GL_SGI_MSGI(i) += Vnn*dwf_nn_bef_R_tab_GL_SGI_MSGI(i);
	    }
	}
    }
  
  if (R_real_max > 0.0)
    {
      for (int nn = 0 ; nn <= nmax_basis ; nn++)
	{
	  const double Vnn = V(nn);

	  const unsigned int shell_nn_index = basis_shells_indices(nn);
	      
	  const class spherical_state &shell_nn = basis_shells(shell_nn_index);
	      
	  const class array<complex<double> > &wf_nn_aft_R_tab_GL_real   = shell_nn.wf_aft_R_tab_GL_real;
	  const class array<complex<double> > &dwf_nn_aft_R_tab_GL_real  = shell_nn.dwf_aft_R_tab_GL_real;
	  const class array<complex<double> > &d2wf_nn_aft_R_tab_GL_real = shell_nn.d2wf_aft_R_tab_GL_real;

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      wf_aft_R_tab_GL_real(i)   += Vnn*wf_nn_aft_R_tab_GL_real(i);
	      dwf_aft_R_tab_GL_real(i)  += Vnn*dwf_nn_aft_R_tab_GL_real(i);
	      d2wf_aft_R_tab_GL_real(i) += Vnn*d2wf_nn_aft_R_tab_GL_real(i);
	    }
	      
	  const class array<complex<double> > &wf_nn_aft_R_tab_GL_complex   = shell_nn.wf_aft_R_tab_GL_complex;
	  const class array<complex<double> > &dwf_nn_aft_R_tab_GL_complex  = shell_nn.dwf_aft_R_tab_GL_complex;	      
	  const class array<complex<double> > &d2wf_nn_aft_R_tab_GL_complex = shell_nn.d2wf_aft_R_tab_GL_complex;

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      wf_aft_R_tab_GL_complex(i)   += Vnn*wf_nn_aft_R_tab_GL_complex(i);
	      dwf_aft_R_tab_GL_complex(i)  += Vnn*dwf_nn_aft_R_tab_GL_complex(i);
	      d2wf_aft_R_tab_GL_complex(i) += Vnn*d2wf_nn_aft_R_tab_GL_complex(i);
	    }
	}
    }
}



void spherical_state::wave_calculation_from_vector (
						    const bool is_energy_defined ,
						    const double E_init , 
						    const class vector_class<double> &V ,						    
						    const class array<unsigned int> &basis_shells_indices , 
						    const class array<class spherical_state> &basis_shells) 
{
  zero ();

  wave_calculation_add_from_vector (is_energy_defined , E_init , V , basis_shells_indices , basis_shells);
}







void spherical_state::wave_calculation_add_from_vector (
							const bool is_energy_defined ,
							const complex<double> &E_init , 
							const class vector_class<complex<double> > &V ,			    
							const class array<unsigned int> &basis_shells_indices , 
							const class array<class spherical_state> &basis_shells) 
{ 
  const int nmax_basis = basis_shells_indices.dimension (0) - 1;

  if (is_energy_defined)
    {
      E = E_init;

      k = sqrt_mod (E * kinetic_factor);

      eta = eta_calc (is_it_relative , particle , Z_charge , kinetic_factor , k);

      is_k_OK = true;
    }
  else
    {
      E = k = eta = NADA;

      is_k_OK = false;
    }

  Cplus = Cminus = CF = CG = NADA;

  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const complex<double> &Vnn = V(nn);

      const unsigned int shell_nn_index = basis_shells_indices(nn);
      
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);
      
      const complex<double> &C0_shell_nn = shell_nn.C0;
	  
      C0 += Vnn*C0_shell_nn;
    }
  
  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const complex<double> &Vnn = V(nn);
      
      const unsigned int shell_nn_index = basis_shells_indices(nn);
      
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);
      
      const complex<double> &wf_R0_shell_nn  = shell_nn.wf_R0;
      const complex<double> &dwf_R0_shell_nn = shell_nn.dwf_R0;
      
      wf_R0  += Vnn*wf_R0_shell_nn;
      dwf_R0 += Vnn*dwf_R0_shell_nn;
    }
  
  for (int nn = 0 ; nn <= nmax_basis ; nn++)
    {
      const complex<double> &Vnn = V(nn);

      const unsigned int shell_nn_index = basis_shells_indices(nn);
	  
      const class spherical_state &shell_nn = basis_shells(shell_nn_index);

      const class array<complex<double> > &wf_nn_bef_R_tab_uniform   = shell_nn.wf_bef_R_tab_uniform;
      const class array<complex<double> > &dwf_nn_bef_R_tab_uniform  = shell_nn.dwf_bef_R_tab_uniform;
      const class array<complex<double> > &d2wf_nn_bef_R_tab_uniform = shell_nn.d2wf_bef_R_tab_uniform;

      const class array<complex<double> > &wf_nn_bef_R_tab_GL   = shell_nn.wf_bef_R_tab_GL;
      const class array<complex<double> > &dwf_nn_bef_R_tab_GL  = shell_nn.dwf_bef_R_tab_GL;
      const class array<complex<double> > &d2wf_nn_bef_R_tab_GL = shell_nn.d2wf_bef_R_tab_GL;
      
      for (unsigned int i = 0 ; i < N_bef_R_uniform ; i++)
	{
	  wf_bef_R_tab_uniform(i)   += Vnn*wf_nn_bef_R_tab_uniform(i);
	  dwf_bef_R_tab_uniform(i)  += Vnn*dwf_nn_bef_R_tab_uniform(i);
	  d2wf_bef_R_tab_uniform(i) += Vnn*d2wf_nn_bef_R_tab_uniform(i);
	}
	  
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	{
	  wf_bef_R_tab_GL(i)   += Vnn*wf_nn_bef_R_tab_GL(i);
	  dwf_bef_R_tab_GL(i)  += Vnn*dwf_nn_bef_R_tab_GL(i);
	  d2wf_bef_R_tab_GL(i) += Vnn*d2wf_nn_bef_R_tab_GL(i);
	}
      
      if (kmax_momentum > 0.0)
	{      
	  const class array<complex<double> > &wf_nn_momentum_tab_uniform  = shell_nn.wf_momentum_tab_uniform;
	  const class array<complex<double> > &dwf_nn_momentum_tab_uniform = shell_nn.dwf_momentum_tab_uniform;

	  const class array<complex<double> > &wf_nn_momentum_tab_GL  = shell_nn.wf_momentum_tab_GL;
	  const class array<complex<double> > &dwf_nn_momentum_tab_GL = shell_nn.dwf_momentum_tab_GL;

	  for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	    {
	      wf_momentum_tab_uniform(i)  += Vnn*wf_nn_momentum_tab_uniform(i);
	      dwf_momentum_tab_uniform(i) += Vnn*dwf_nn_momentum_tab_uniform(i);
	    }
	  
	  for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	    {
	      wf_momentum_tab_GL(i)  += Vnn*wf_nn_momentum_tab_GL(i);
	      dwf_momentum_tab_GL(i) += Vnn*dwf_nn_momentum_tab_GL(i);
	    }
	}
    }
  
  if (!is_there_effective_mass_determine (potential) && (potential != QBOX_POTENTIAL))
    {
      for (int nn = 0 ; nn <= nmax_basis ; nn++)
	{
	  const complex<double> &Vnn = V(nn);

	  const unsigned int shell_nn_index = basis_shells_indices(nn);

	  const class spherical_state &shell_nn = basis_shells(shell_nn_index);

	  const class array<complex<double> > &wf_nn_bef_R_tab_GL_SGI_MSGI  = shell_nn.wf_bef_R_tab_GL_SGI_MSGI;
	  const class array<complex<double> > &dwf_nn_bef_R_tab_GL_SGI_MSGI = shell_nn.dwf_bef_R_tab_GL_SGI_MSGI;

	  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	    {	      
	      wf_bef_R_tab_GL_SGI_MSGI(i)  += Vnn*wf_nn_bef_R_tab_GL_SGI_MSGI(i);
	      dwf_bef_R_tab_GL_SGI_MSGI(i) += Vnn*dwf_nn_bef_R_tab_GL_SGI_MSGI(i);
	    }
	}
    }
  
  if (R_real_max > 0.0)
    {
      for (int nn = 0 ; nn <= nmax_basis ; nn++)
	{
	  const complex<double> &Vnn = V(nn);

	  const unsigned int shell_nn_index = basis_shells_indices(nn);
	      
	  const class spherical_state &shell_nn = basis_shells(shell_nn_index);

	  const class array<complex<double> > &wf_nn_aft_R_tab_GL_real   = shell_nn.wf_aft_R_tab_GL_real;
	  const class array<complex<double> > &dwf_nn_aft_R_tab_GL_real  = shell_nn.dwf_aft_R_tab_GL_real;
	  const class array<complex<double> > &d2wf_nn_aft_R_tab_GL_real = shell_nn.d2wf_aft_R_tab_GL_real;

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      wf_aft_R_tab_GL_real(i)   += Vnn*wf_nn_aft_R_tab_GL_real(i);
	      dwf_aft_R_tab_GL_real(i)  += Vnn*dwf_nn_aft_R_tab_GL_real(i);
	      d2wf_aft_R_tab_GL_real(i) += Vnn*d2wf_nn_aft_R_tab_GL_real(i);
	    }
	      
	  const class array<complex<double> > &wf_nn_aft_R_tab_GL_complex   = shell_nn.wf_aft_R_tab_GL_complex;
	  const class array<complex<double> > &dwf_nn_aft_R_tab_GL_complex  = shell_nn.dwf_aft_R_tab_GL_complex;
	  const class array<complex<double> > &d2wf_nn_aft_R_tab_GL_complex = shell_nn.d2wf_aft_R_tab_GL_complex;

	  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	    {
	      wf_aft_R_tab_GL_complex(i)   += Vnn*wf_nn_aft_R_tab_GL_complex(i);
	      dwf_aft_R_tab_GL_complex(i)  += Vnn*dwf_nn_aft_R_tab_GL_complex(i);
	      d2wf_aft_R_tab_GL_complex(i) += Vnn*d2wf_nn_aft_R_tab_GL_complex(i);
	    }
	}
    }
}

void spherical_state::wave_calculation_from_vector (
						    const bool is_energy_defined ,
						    const complex<double> &E_init , 
						    const class vector_class<complex<double> > &V ,			    
						    const class array<unsigned int> &basis_shells_indices , 
						    const class array<class spherical_state> &basis_shells) 
{
  zero ();

  wave_calculation_add_from_vector (is_energy_defined , E_init , V , basis_shells_indices , basis_shells);
}




// Calculation of the wave function in momentum space
// --------------------------------------------------
// The wave function must have been calculated firstly in radial coordinate space.
// One multiplies it by a Fermi function otherwise its Fourier-Bessel transform is not defined in general.
// The diffuseness is fixed at 2 fm, at it has to be large and this value leads to precise calculations for all cases.
// It is then projected on a subset of HO states, using nmax = 40 as one has a precision of 10^(-6) typically therein.
// One then calculates the wave function and its derivative in momentum space of the projection wave function from the analytical HO states in momentum space.
//
// Variables
// ---------
// b_HO, bk_HO, nmax_HO: oscillator length is radial and momentum space and maximal quantum number of used HO states
// HO_wfs/dwfs_bef/aft_R_tab_GL: HO states and derivatives in radial space before and after R
// HO_overlap_Fermi_n_HO: HO overlaps between the calculated wave function multiplied by a Fermi function and the HO states of principal quantum number n_HO
// HO_wfs/dwfs_momentum_tab_uniform/GL: HO states and derivatives in momentum space
// d_Fermi_monentum: diffuseness of the Fermi function in fm
// wf_Fermi_w_bef/aft_R_tab_GL: products of radial wave function, Fermi function and Gauss-Legendre weights before/after R

void spherical_state::wave_calculation_momentum (const double b_HO)
{
  if (!is_k_OK) return;
    
  if (kmax_momentum == 0.0) error_message_print_abort ("kmax_momentum must be positive to use spherical_state::wave_calculation_momentum");
    
  if (R_Fermi_momentum == 0.0) error_message_print_abort ("R_Fermi_momentum must be positive to use spherical_state::wave_calculation_momentum");

  if (R_real_max == 0.0) error_message_print_abort ("R_real_max must be positive to use spherical_state::wave_calculation_momentum");
    
  if (inf_norm (wf_bef_R_tab_GL(0)) > SQRT_INFINITE)
    error_message_print_abort ("Wave function " + make_string<spherical_state> (*this) + " must have been calculated in radial space in order to calculate it in momentum space in spherical_state::wave_calculation_momentum");

  wf_momentum_tab_uniform  = 0.0;
  dwf_momentum_tab_uniform = 0.0;
  
  wf_momentum_tab_GL  = 0.0;
  dwf_momentum_tab_GL = 0.0;

  const double d_Fermi_momentum = 10.0;
  
  const int nmax_HO = 40;
  
  const int nmax_HO_plus_one = nmax_HO + 1;

  const double bk_HO = 1.0/b_HO;
  
  class array<double> HO_wfs_bef_R_tab_GL (nmax_HO_plus_one , N_bef_R_GL);  
  class array<double> HO_wfs_aft_R_tab_GL (nmax_HO_plus_one , N_aft_R_GL);

  HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , l , r_bef_R_tab_GL      , HO_wfs_bef_R_tab_GL);
  HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , l , r_aft_R_tab_GL_real , HO_wfs_aft_R_tab_GL);
      
  class array<complex<double> > wf_Fermi_w_bef_R_tab_GL (N_bef_R_GL);  
  class array<complex<double> > wf_Fermi_w_aft_R_tab_GL (N_aft_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_Fermi_w_bef_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_bef_R_tab_GL(i))     *wf_bef_R_tab_GL(i)     *w_bef_R_tab_GL(i);
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) wf_Fermi_w_aft_R_tab_GL(i) = Fermi_like_function (R_Fermi_momentum , d_Fermi_momentum , r_aft_R_tab_GL_real(i))*wf_aft_R_tab_GL_real(i)*w_aft_R_tab_GL_real(i);
  
  class array<double> HO_wfs_momentum_tab_uniform (nmax_HO_plus_one , Nk_momentum_uniform);
  class array<double> HO_dwfs_momentum_tab_uniform(nmax_HO_plus_one , Nk_momentum_uniform);
  
  class array<double> HO_wfs_momentum_tab_GL (nmax_HO_plus_one , Nk_momentum_GL);
  class array<double> HO_dwfs_momentum_tab_GL(nmax_HO_plus_one , Nk_momentum_GL);

  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , l , k_tab_uniform , HO_wfs_momentum_tab_uniform , HO_dwfs_momentum_tab_uniform);
  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk_HO , l , k_tab_GL      , HO_wfs_momentum_tab_GL      , HO_dwfs_momentum_tab_GL);
      
  for (int n_HO = 0 ; n_HO <= nmax_HO ; n_HO++)
    {
      complex<double> HO_overlap_Fermi_n_HO = 0.0;
	
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) HO_overlap_Fermi_n_HO += wf_Fermi_w_bef_R_tab_GL(i)*HO_wfs_bef_R_tab_GL(n_HO , i);
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) HO_overlap_Fermi_n_HO += wf_Fermi_w_aft_R_tab_GL(i)*HO_wfs_aft_R_tab_GL(n_HO , i);
      
      for (unsigned int i = 0 ; i < Nk_momentum_uniform ; i++)
	{
	  wf_momentum_tab_uniform (i) += HO_wfs_momentum_tab_uniform (n_HO , i)*HO_overlap_Fermi_n_HO;
	  dwf_momentum_tab_uniform(i) += HO_dwfs_momentum_tab_uniform(n_HO , i)*HO_overlap_Fermi_n_HO;
	}
	      
      for (unsigned int i = 0 ; i < Nk_momentum_GL ; i++)
	{
	  wf_momentum_tab_GL (i) += HO_wfs_momentum_tab_GL (n_HO , i)*HO_overlap_Fermi_n_HO;
	  dwf_momentum_tab_GL(i) += HO_dwfs_momentum_tab_GL(n_HO , i)*HO_overlap_Fermi_n_HO;
	}
    }
}




void spherical_state::accept ()
{
  is_k_OK = true;
}




void spherical_state::reject ()
{
  is_k_OK = false;

  k = SQRT_INFINITE;

  E = INFINITE;
}




bool spherical_state::is_it_filled () const
{
  return (particle != NO_PARTICLE);
}






// Decimal logarithm of the width of a one-body state calculated with the current approximation formula in keV
// -----------------------------------------------------------------------------------------------------------
// log10(Gamma) ~ log10(2) + log10 (hbar^2/m) + log10(|C+|^2) + log10 (Re(k)) + 3 from Gamma in keV.
//
// Variables
// ---------
// log10_Cplus: log10 (C+).
//              It is used as C+ has to be renormalized in case one does not use the standard normalization of Coulomb wave functions for the width with the current formula.
// log10_Cl_eta: decimal logarithm of the Gamow factor.
//               It is used as C+ has to be renormalized with Cl(eta) in case one does not use the standard normalization of Coulomb wave function for the width with the current formula.
// log10_width_from_current_formula: returned decimal logarithm of the width from the current formula

double spherical_state::log10_width_from_current_formula_calc () const
{
  const complex<double> log10_Cl_eta = (!is_it_cwf_standard_normalization) ? (log_Cl_eta_calc (l , eta)/M_LN10) : (NADA);
  
  const complex<double> log10_Cplus = log10 (Cplus);
  
  const complex<double> log10_Cplus_normalized = (is_it_cwf_standard_normalization) ? (log10_Cplus) : (log10_Cl_eta + log10_Cplus);
  
  const double log10_width_from_current_formula = ::log10_width_from_current_formula_calc (kinetic_factor , log10_Cplus_normalized , real (k));

  return log10_width_from_current_formula;
}







// Width of a one-body state calculated with the current approximation formula in keV
// ----------------------------------------------------------------------------------
// Gamma ~ 2000.hbar^2/m |C+|^2 Re(k) in keV.
//
// Variables
// ---------
// Cplus: log10 (C+).
//        It is used as C+ has to be renormalized in case one does not use the standard normalization of Coulomb wave functions for the width with the current formula.
// Cl_eta: Gamow factor.
//         It is used as C+ has to be renormalized with Cl(eta) in case one does not use the standard normalization of Coulomb wave function for the width with the current formula.
// width_from_current_formula: returned width from the current formula

double spherical_state::width_from_current_formula_calc () const
{
  const complex<double> Cl_eta = (!is_it_cwf_standard_normalization) ? (exp (log_Cl_eta_calc (l , eta))) : (NADA);
  
  const complex<double> Cplus_normalized = (is_it_cwf_standard_normalization) ? (Cplus) : (Cl_eta*Cplus);
  
  const double width_from_current_formula = ::width_from_current_formula_calc (kinetic_factor , Cplus_normalized , real (k));

  return width_from_current_formula;
}







// Memory used by the class
// ------------------------

double used_memory_calc (const class spherical_state &T)
{
  const double used_memory_constants = sizeof (T)/1000000.0;

  const double used_memory_allocated_arrays = used_memory_calc (T.r_bef_R_tab_uniform) + used_memory_calc (T.r_bef_R_tab_GL) + used_memory_calc (T.w_bef_R_tab_GL) + used_memory_calc (T.r_bef_s_tab_GL) + used_memory_calc (T.w_bef_s_tab_GL) + used_memory_calc (T.r_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.w_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.r_aft_R_tab_GL_real) + used_memory_calc (T.w_aft_R_tab_GL_real) + used_memory_calc (T.r_aft_R_tab_GL_complex) + used_memory_calc (T.w_aft_R_tab_GL_complex) + used_memory_calc (T.um4_aft_R_tab_GL) + used_memory_calc (T.w_aft_R_tab_GL) + used_memory_calc (T.k_tab_uniform) + used_memory_calc (T.k_tab_GL) + used_memory_calc (T.wk_tab_GL) + used_memory_calc (T.wf_bef_R_tab_uniform) + used_memory_calc (T.dwf_bef_R_tab_uniform) +used_memory_calc (T.d2wf_bef_R_tab_uniform) + used_memory_calc (T.scaled_wf_aft_R_tab_uniform) + used_memory_calc (T.scaled_dwf_aft_R_tab_uniform) + used_memory_calc (T.wf_bef_R_tab_GL) + used_memory_calc (T.dwf_bef_R_tab_GL) + used_memory_calc (T.d2wf_bef_R_tab_GL) + used_memory_calc (T.wf_bef_s_tab_GL) + used_memory_calc (T.dwf_bef_s_tab_GL) + used_memory_calc (T.d2wf_bef_s_tab_GL) + used_memory_calc (T.wf_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.dwf_bef_R_tab_GL_SGI_MSGI) + used_memory_calc (T.wf_aft_R_tab_GL_real) + used_memory_calc (T.dwf_aft_R_tab_GL_real) + used_memory_calc (T.d2wf_aft_R_tab_GL_real) + used_memory_calc (T.wf_aft_R_tab_GL_complex) + used_memory_calc (T.dwf_aft_R_tab_GL_complex) + used_memory_calc (T.d2wf_aft_R_tab_GL_complex) + used_memory_calc (T.wf_momentum_tab_uniform) + used_memory_calc (T.dwf_momentum_tab_uniform) + used_memory_calc (T.wf_momentum_tab_GL) + used_memory_calc (T.dwf_momentum_tab_GL) + used_memory_calc (T.scaled_wf_aft_R_tab_GL) + used_memory_calc (T.scaled_dwf_aft_R_tab_GL) - (sizeof (T.r_bef_R_tab_uniform) + sizeof (T.r_bef_R_tab_GL) + sizeof (T.w_bef_R_tab_GL) + sizeof (T.r_bef_s_tab_GL) + sizeof (T.w_bef_s_tab_GL) + sizeof (T.r_bef_R_tab_GL_SGI_MSGI) + sizeof (T.w_bef_R_tab_GL_SGI_MSGI) + sizeof (T.r_aft_R_tab_GL_real) + sizeof (T.w_aft_R_tab_GL_real) + sizeof (T.r_aft_R_tab_GL_complex) + sizeof (T.w_aft_R_tab_GL_complex) + sizeof (T.um4_aft_R_tab_GL) + sizeof (T.w_aft_R_tab_GL) + sizeof (T.k_tab_uniform) + sizeof (T.k_tab_GL) + sizeof (T.wk_tab_GL) + sizeof (T.wf_bef_R_tab_uniform) + sizeof (T.dwf_bef_R_tab_uniform) +sizeof (T.d2wf_bef_R_tab_uniform) + sizeof (T.scaled_wf_aft_R_tab_uniform) + sizeof (T.scaled_dwf_aft_R_tab_uniform) + sizeof (T.wf_bef_R_tab_GL) + sizeof (T.dwf_bef_R_tab_GL) + sizeof (T.d2wf_bef_R_tab_GL) + sizeof (T.wf_bef_s_tab_GL) + sizeof (T.dwf_bef_s_tab_GL) + sizeof (T.d2wf_bef_s_tab_GL) + sizeof (T.wf_bef_R_tab_GL_SGI_MSGI) + sizeof (T.dwf_bef_R_tab_GL_SGI_MSGI) + sizeof (T.wf_aft_R_tab_GL_real) + sizeof (T.dwf_aft_R_tab_GL_real) + sizeof (T.d2wf_aft_R_tab_GL_real) + sizeof (T.wf_aft_R_tab_GL_complex) + sizeof (T.dwf_aft_R_tab_GL_complex) + sizeof (T.d2wf_aft_R_tab_GL_complex) + sizeof (T.wf_momentum_tab_uniform) + sizeof (T.dwf_momentum_tab_uniform) + sizeof (T.wf_momentum_tab_GL) + sizeof (T.dwf_momentum_tab_GL) + sizeof (T.scaled_wf_aft_R_tab_GL) + sizeof (T.scaled_dwf_aft_R_tab_GL))/1000000.0;

  const double used_memory = used_memory_constants + used_memory_allocated_arrays;

  return used_memory;
}



// Tests if states have the same (l,j) or (n,l,j) quantum numbers
// --------------------------------------------------------------

bool same_nlj (
	       const class spherical_state &s1 , 
	       const class spherical_state &s2)
{
  return ((s1.get_n () == s2.get_n ()) && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0));
}


bool same_lj (
	      const class spherical_state &s1 , 
	      const class spherical_state &s2)
{
  return ((s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0));
}






// In the following comparison operators, one assumes that all states are generated by the same Hamiltonian.
// Thus, a state is fully defined by its (n,l,j), and possibly jr, quantum numbers.
// One uses a lexicographic order based on is_k_OK, S_matrix_pole, n, l, j, and possibly jr.
// By definition, an undefined state, i.e. with is_k_OK false, is larger than all defined states.
// For fixed is_k_OK, all pole states are smaller than scattering states.
// Then one uses the lexicographic order generated by the list of integers (jr, l , j, n) (rotor case) or (l, j, n) (non-rotor case).

bool operator == (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2)
{
  if (s1.get_isItRotor     () != s2.get_isItRotor ())     return false;     
  if (s1.get_is_k_OK       () != s2.get_is_k_OK ())       return false;
  if (s1.get_S_matrix_pole () != s2.get_S_matrix_pole ()) return false;

  if ((s1.get_n () != s2.get_n ()) || (s1.get_l () != s2.get_l ()) || (rint (s1.get_j () - s2.get_j ()) != 0.0)) return false;
      
  if (s1.get_isItRotor () && (s1.get_jr () != s2.get_jr ())) return false;
      
  return true;
}




bool operator != (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2)
{
  return !(s1 == s2);
}




bool operator > (
		 const class spherical_state &s1 , 
		 const class spherical_state &s2)
{
  if (s1.get_isItRotor () != s2.get_isItRotor ()) error_message_print_abort ("Rotor and non-rotor states cannot be larger or smaller than each other");

  if (!s1.get_is_k_OK () && s2.get_is_k_OK ()) return true; 
  if ((s1.get_is_k_OK () == s2.get_is_k_OK ()) && !s1.get_S_matrix_pole () && s2.get_S_matrix_pole ()) return true;

  const bool same_is_k_OK_S_matrix_pole = ((s1.get_is_k_OK () == s2.get_is_k_OK ()) && (s1.get_S_matrix_pole () == s2.get_S_matrix_pole ()));
      
  if (s1.get_isItRotor ())
    {
      if (same_is_k_OK_S_matrix_pole && (s1.get_jr () > s2.get_jr ())) return true; 
      if (same_is_k_OK_S_matrix_pole && (s1.get_jr () == s2.get_jr ()) && (s1.get_l () > s2.get_l ())) return true; 
      if (same_is_k_OK_S_matrix_pole && (s1.get_jr () == s2.get_jr ()) && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) > 0.0)) return true;
      if (same_is_k_OK_S_matrix_pole && (s1.get_jr () == s2.get_jr ()) && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0) && (s1.get_n () > s2.get_n ())) return true;
    }
  else
    {
      if (same_is_k_OK_S_matrix_pole && (s1.get_l () > s2.get_l ())) return true; 
      if (same_is_k_OK_S_matrix_pole && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) > 0.0)) return true;
      if (same_is_k_OK_S_matrix_pole && (s1.get_l () == s2.get_l ()) && (rint (s1.get_j () - s2.get_j ()) == 0.0) && (s1.get_n () > s2.get_n ())) return true;
    }
  
  return false;
}





bool operator >= (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2)
{
  return ((s1 > s2) || (s1 == s2));
}




bool operator < (
		 const class spherical_state &s1 , 
		 const class spherical_state &s2)
{
  return (s2 > s1);
}




bool operator <= (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2)
{
  return ((s1 < s2) || (s1 == s2));
}








