#ifndef SPHERICAL_STATE_H
#define SPHERICAL_STATE_H

class spherical_state 
{
public:

  // Default constructor
  // -------------------

  spherical_state ();
  
  // Normal constructor ,  where the tables have to be allocated and calculated.
  // ---------------------------------------------------------------------------

  spherical_state (
		   const bool is_it_relative_c , 
		   const bool are_there_scaled_wfs_c , 
		   const enum potential_type potential_c , 
		   const int A_c , 
		   const int Z_charge_c , 
		   const double mass_modif , 
		   const unsigned int N_bef_s_GL_c , 
		   const unsigned int N_bef_R_GL_c , 
		   const unsigned int N_aft_R_GL_c , 
		   const unsigned int N_bef_R_uniform_c , 
		   const unsigned int N_aft_R_uniform_c , 
		   const unsigned int Nk_momentum_uniform_c , 
		   const unsigned int Nk_momentum_GL_c , 
		   const double R_c , 
		   const double s_radial_c , 
		   const double R0_c , 
		   const double R_real_max_c , 
		   const double kmax_momentum_c , 
		   const double R_Fermi_momentum_c , 
		   const bool S_matrix_pole_c , 
		   const enum particle_type particle_c , 
		   const int n_c , 
		   const double jr_c , 
		   const int l_c , 
		   const double j_c , 
		   const bool automatic_starting_point , 
		   const complex<double> &k_c , 
		   const double effective_mass_for_calc , 
		   const complex<double> &C0_c , 
		   const complex<double> &Cplus_c);
  
  // Copy constructor
  // ----------------

  spherical_state (const class spherical_state &s);

  ~spherical_state ();
 
  void allocate (
		 const bool is_it_relative_c , 
		 const bool are_there_scaled_wfs_c , 
		 const enum potential_type potential_c , 
		 const int A_c , 
		 const int Z_charge_c , 
		 const double mass_modif , 
		 const unsigned int N_bef_s_GL_c , 
		 const unsigned int N_bef_R_GL_c , 
		 const unsigned int N_aft_R_GL_c , 
		 const unsigned int N_bef_R_uniform_c , 
		 const unsigned int N_aft_R_uniform_c , 
		 const unsigned int Nk_momentum_uniform_c , 
		 const unsigned int Nk_momentum_GL_c , 
		 const double R_c , 
		 const double s_radial_c , 
		 const double R0_c , 
		 const double R_real_max_c , 
		 const double kmax_momentum_c , 
		 const double R_Fermi_momentum_c , 
		 const bool S_matrix_pole_c , 
		 const enum particle_type particle_c , 
		 const int n_c , 
		 const double jr_c , 
		 const int l_c , 
		 const double j_c , 
		 const bool automatic_starting_point , 
		 const complex<double> &k_c , 
		 const double effective_mass_for_calc , 
		 const complex<double> &C0_c , 
		 const complex<double> &Cplus_c);

  void allocate_fill (const class spherical_state &s);
  
  void deallocate ();
  
  // Public constant functions returning private values
  // --------------------------------------------------

  bool get_is_k_OK () const
  {
    return is_k_OK;
  }

  double get_kinetic_factor () const
  {
    return kinetic_factor;
  }
  
  void set_k (const complex<double> &k_c)
  {
    k = k_c;
  }
  
  complex<double> get_k () const
  {
    return k;
  }

  void set_eta (const complex<double> &eta_c)
  {
    eta = eta_c;
  }
  
  complex<double> get_eta () const
  {
    return eta;
  }

  complex<double> get_E () const
  {
    return E;
  }

  void set_C0 (const complex<double> &C0_c)
  {
    C0 = C0_c;
  }

  complex<double> get_C0 () const
  {
    return C0;
  }

  void set_Cplus (const complex<double> &Cplus_c)
  {
    Cplus = Cplus_c;
  }

  complex<double> get_Cplus () const
  {
    return Cplus;
  }

  complex<double> get_Cminus () const
  {
    return Cminus;
  }

  complex<double> get_CF () const
  {
    return CF;
  }

  complex<double> get_CG () const
  {
    return CG;
  }

  complex<double> get_wf_R0 () const
  {
    return wf_R0;
  }

  complex<double> get_dwf_R0 () const
  {
    return dwf_R0;
  }

  bool get_is_k_search_start_used () const
  {
    return is_k_search_start_used;
  }

  complex<double> get_k_search_start () const
  {
    return k_search_start;
  }

  bool get_isItRotor () const
  {
    return isItRotor;
  }

  bool get_is_it_relative () const
  {
    return is_it_relative;
  }
  
  bool get_are_there_scaled_wfs () const
  {
    return are_there_scaled_wfs;
  }
  
  int get_n () const
  {
    return n;
  }

  double get_jr () const
  {
    return jr;
  }

  int get_l () const
  {
    return l;
  }

  double get_j () const
  {
    return j;
  }

  enum particle_type get_particle () const
  {
    return particle;
  }

  bool get_S_matrix_pole () const
  {
    return S_matrix_pole;
  }

  enum potential_type get_potential () const
  {
    return potential;
  }

  int get_A () const
  {
    return A;
  }

  int get_Z_charge () const
  {
    return Z_charge;
  }

  double get_R () const
  {
    return R;
  }

  double get_matching_point () const
  {
    return matching_point;
  }

  double get_s_radial () const
  {
    return s_radial;
  }

  double get_R0 () const
  {
    return R0;
  }

  double get_R_real_max () const
  {
    return R_real_max;
  }

  double get_kmax_momentum () const
  {
    return kmax_momentum;
  }
  
  double get_R_Fermi_momentum () const
  {
    return R_Fermi_momentum;
  }
  
  double get_step_bef_R_uniform () const
  {
    return step_bef_R_uniform;
  }

  double get_step_aft_R_uniform () const
  {
    return step_aft_R_uniform;
  }
	
  double get_step_momentum_uniform () const
  {
    return step_momentum_uniform;
  }

  unsigned int get_N_matching_point () const
  {
    return N_matching_point;
  }

  unsigned int get_N_bef_s_GL () const
  {
    return N_bef_s_GL;
  }

  unsigned int get_N_bef_R_GL () const
  {
    return N_bef_R_GL;
  }

  unsigned int get_N_aft_R_GL () const
  {
    return N_aft_R_GL;
  }

  unsigned int get_N_bef_R_uniform () const
  {
    return N_bef_R_uniform;
  }

  unsigned int get_N_aft_R_uniform () const
  {
    return N_aft_R_uniform;
  }

  unsigned int get_Nk_momentum_uniform ()  const
  {
    return Nk_momentum_uniform;
  }

  unsigned int get_Nk_momentum_GL () const
  {
    return Nk_momentum_GL;
  }
  
  const class array<double> & get_r_bef_R_tab_uniform () const
  {
    return r_bef_R_tab_uniform;
  }

  const class array<double> & get_k_tab_uniform () const
  {
    return k_tab_uniform;
  }

  const class array<double> & get_r_bef_R_tab_GL () const
  {
    return r_bef_R_tab_GL;
  }

  const class array<double> & get_w_bef_R_tab_GL () const
  {
    return w_bef_R_tab_GL;
  }
  
  const class array<double> & get_r_bef_s_tab_GL () const
  {
    return r_bef_s_tab_GL;
  }

  const class array<double> & get_w_bef_s_tab_GL () const
  {
    return w_bef_s_tab_GL;
  }
   
  const class array<double> & get_k_tab_GL () const
  {
    return k_tab_GL;
  }

  const class array<double> & get_wk_tab_GL () const
  {
    return wk_tab_GL;
  }
   
  const class array<double> & get_r_bef_R_tab_GL_SGI_MSGI () const
  {
    return r_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_w_bef_R_tab_GL_SGI_MSGI () const
  {
    return w_bef_R_tab_GL_SGI_MSGI;
  }

  const class array<double> & get_r_aft_R_tab_GL_real () const
  {
    return r_aft_R_tab_GL_real;
  }

  const class array<double> & get_w_aft_R_tab_GL_real () const
  {
    return w_aft_R_tab_GL_real;
  }
   
  const class array<complex<double> > & get_r_aft_R_tab_GL_complex () const
  {
    return r_aft_R_tab_GL_complex;
  }

  const class array<complex<double> > & get_w_aft_R_tab_GL_complex () const
  {
    return w_aft_R_tab_GL_complex;
  }
  
  const class array<double> & get_um4_aft_R_tab_GL () const
  {
    return um4_aft_R_tab_GL;
  }

  const class array<double> & get_w_aft_R_tab_GL () const
  {
    return w_aft_R_tab_GL;
  }

  void set_wf_bef_R_tab_uniform (const class array<complex<double> > &X)
  {
    wf_bef_R_tab_uniform = X;
  }
 
  class array<complex<double> > & get_wf_bef_R_tab_uniform ()
  {
    return wf_bef_R_tab_uniform;
  }
 
  const class array<complex<double> > & get_wf_bef_R_tab_uniform () const
  {
    return wf_bef_R_tab_uniform;
  }

  void set_dwf_bef_R_tab_uniform (const class array<complex<double> > &X)
  {
    dwf_bef_R_tab_uniform = X;
  }

  class array<complex<double> > & get_dwf_bef_R_tab_uniform ()
  {
    return dwf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_dwf_bef_R_tab_uniform () const
  {
    return dwf_bef_R_tab_uniform;
  }

  void set_d2wf_bef_R_tab_uniform (const class array<complex<double> > &X)
  {
    d2wf_bef_R_tab_uniform = X;
  }
 
  class array<complex<double> > & get_d2wf_bef_R_tab_uniform ()
  {
    return d2wf_bef_R_tab_uniform;
  }
 
  const class array<complex<double> > & get_d2wf_bef_R_tab_uniform () const
  {
    return d2wf_bef_R_tab_uniform;
  }

  const class array<complex<double> > & get_scaled_wf_aft_R_tab_uniform () const
  {
    return scaled_wf_aft_R_tab_uniform;
  }

  const class array<complex<double> > & get_scaled_dwf_aft_R_tab_uniform () const
  {
    return scaled_dwf_aft_R_tab_uniform;
  }
   
  void set_wf_bef_R_tab_GL (const class array<complex<double> > &X)
  {
    wf_bef_R_tab_GL = X;
  }
 
  class array<complex<double> > & get_wf_bef_R_tab_GL ()
  {
    return wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_wf_bef_R_tab_GL () const
  {
    return wf_bef_R_tab_GL;
  }

  void set_dwf_bef_R_tab_GL (const class array<complex<double> > &X)
  {
    dwf_bef_R_tab_GL = X;
  }
 
  class array<complex<double> > & get_dwf_bef_R_tab_GL ()
  {
    return dwf_bef_R_tab_GL;
  }
 
  const class array<complex<double> > & get_dwf_bef_R_tab_GL () const
  {
    return dwf_bef_R_tab_GL;
  }

  void set_d2wf_bef_R_tab_GL (const class array<complex<double> > &X)
  {
    d2wf_bef_R_tab_GL = X;
  }
 
  class array<complex<double> > & get_d2wf_bef_R_tab_GL ()
  {
    return d2wf_bef_R_tab_GL;
  }

  const class array<complex<double> > & get_d2wf_bef_R_tab_GL () const
  {
    return d2wf_bef_R_tab_GL;
  }

  void set_wf_bef_s_tab_GL (const class array<complex<double> > &X)
  {
    wf_bef_s_tab_GL = X;
  }
 
  class array<complex<double> > & get_wf_bef_s_tab_GL ()
  {
    return wf_bef_s_tab_GL;
  }
 
  const class array<complex<double> > & get_wf_bef_s_tab_GL () const
  {
    return wf_bef_s_tab_GL;
  }

  void set_dwf_bef_s_tab_GL (const class array<complex<double> > &X)
  {
    dwf_bef_s_tab_GL = X;
  }
 
  class array<complex<double> > & get_dwf_bef_s_tab_GL ()
  {
    return dwf_bef_s_tab_GL;
  }

  const class array<complex<double> > & get_dwf_bef_s_tab_GL () const
  {
    return dwf_bef_s_tab_GL;
  }

  void set_d2wf_bef_s_tab_GL (const class array<complex<double> > &X)
  {
    d2wf_bef_s_tab_GL = X;
  }
 
  class array<complex<double> > & get_d2wf_bef_s_tab_GL ()
  {
    return d2wf_bef_s_tab_GL;
  }
  
  const class array<complex<double> > & get_d2wf_bef_s_tab_GL () const
  {
    return d2wf_bef_s_tab_GL;
  }
 
  void set_wf_bef_R_tab_GL_SGI_MSGI (const class array<complex<double> > &X)
  {
    wf_bef_R_tab_GL_SGI_MSGI = X;
  }
 
  class array<complex<double> > & get_wf_bef_R_tab_GL_SGI_MSGI ()
  {
    return wf_bef_R_tab_GL_SGI_MSGI;
  }
 
  const class array<complex<double> > & get_wf_bef_R_tab_GL_SGI_MSGI () const
  {
    return wf_bef_R_tab_GL_SGI_MSGI;
  }

  void set_dwf_bef_R_tab_GL_SGI_MSGI (const class array<complex<double> > &X)
  {
    dwf_bef_R_tab_GL_SGI_MSGI = X;
  }
 
  class array<complex<double> > & get_dwf_bef_R_tab_GL_SGI_MSGI ()
  {
    return dwf_bef_R_tab_GL_SGI_MSGI;
  }
 
  const class array<complex<double> > & get_dwf_bef_R_tab_GL_SGI_MSGI () const
  {
    return dwf_bef_R_tab_GL_SGI_MSGI;
  }
        
  void set_wf_aft_R_tab_GL_real (const class array<complex<double> > &X)
  {
    wf_aft_R_tab_GL_real = X;
  }
 
  class array<complex<double> > & get_wf_aft_R_tab_GL_real ()
  {
    return wf_aft_R_tab_GL_real;
  }
 
  const class array<complex<double> > & get_wf_aft_R_tab_GL_real () const
  {
    return wf_aft_R_tab_GL_real;
  }

  void set_dwf_aft_R_tab_GL_real (const class array<complex<double> > &X)
  {
    dwf_aft_R_tab_GL_real = X;
  }
 
  class array<complex<double> > & get_dwf_aft_R_tab_GL_real ()
  {
    return dwf_aft_R_tab_GL_real;
  }
 
  const class array<complex<double> > & get_dwf_aft_R_tab_GL_real () const
  {
    return dwf_aft_R_tab_GL_real;
  }

  void set_d2wf_aft_R_tab_GL_real (const class array<complex<double> > &X)
  {
    d2wf_aft_R_tab_GL_real = X;
  }
 
  class array<complex<double> > & get_d2wf_aft_R_tab_GL_real ()
  {
    return d2wf_aft_R_tab_GL_real;
  }
 
  const class array<complex<double> > & get_d2wf_aft_R_tab_GL_real () const
  {
    return d2wf_aft_R_tab_GL_real;
  }

  void set_wf_aft_R_tab_GL_complex (const class array<complex<double> > &X)
  {
    wf_aft_R_tab_GL_complex = X;
  }
 
  class array<complex<double> > & get_wf_aft_R_tab_GL_complex ()
  {
    return wf_aft_R_tab_GL_complex;
  }
 
  const class array<complex<double> > & get_wf_aft_R_tab_GL_complex () const
  {
    return wf_aft_R_tab_GL_complex;
  }

  void set_dwf_aft_R_tab_GL_complex (const class array<complex<double> > &X)
  {
    dwf_aft_R_tab_GL_complex = X;
  }
 
  class array<complex<double> > & get_dwf_aft_R_tab_GL_complex ()
  {
    return dwf_aft_R_tab_GL_complex;
  }
 
  const class array<complex<double> > & get_dwf_aft_R_tab_GL_complex () const
  {
    return dwf_aft_R_tab_GL_complex;
  }

  void set_d2wf_aft_R_tab_GL_complex (const class array<complex<double> > &X)
  {
    d2wf_aft_R_tab_GL_complex = X;
  }
 
  class array<complex<double> > & get_d2wf_aft_R_tab_GL_complex ()
  {
    return d2wf_aft_R_tab_GL_complex;
  }
 
  const class array<complex<double> > & get_d2wf_aft_R_tab_GL_complex () const
  {
    return d2wf_aft_R_tab_GL_complex;
  }
  
  void set_wf_momentum_tab_uniform (const class array<complex<double> > &X)
  {
    wf_momentum_tab_uniform = X;
  }
 
  class array<complex<double> > & get_wf_momentum_tab_uniform ()
  {
    return wf_momentum_tab_uniform;
  }
 
  const class array<complex<double> > & get_wf_momentum_tab_uniform () const
  {
    return wf_momentum_tab_uniform;
  }

  void set_dwf_momentum_tab_uniform (const class array<complex<double> > &X)
  {
    dwf_momentum_tab_uniform = X;
  }

  class array<complex<double> > & get_dwf_momentum_tab_uniform ()
  {
    return dwf_momentum_tab_uniform;
  }

  const class array<complex<double> > & get_dwf_momentum_tab_uniform () const
  {
    return dwf_momentum_tab_uniform;
  }
  
  void set_wf_momentum_tab_GL (const class array<complex<double> > &X)
  {
    wf_momentum_tab_GL = X;
  }
 
  class array<complex<double> > & get_wf_momentum_tab_GL ()
  {
    return wf_momentum_tab_GL;
  }
 
  const class array<complex<double> > & get_wf_momentum_tab_GL () const
  {
    return wf_momentum_tab_GL;
  }

  void set_dwf_momentum_tab_GL (const class array<complex<double> > &X)
  {
    dwf_momentum_tab_GL = X;
  }

  class array<complex<double> > & get_dwf_momentum_tab_GL ()
  {
    return dwf_momentum_tab_GL;
  }

  const class array<complex<double> > & get_dwf_momentum_tab_GL () const
  {
    return dwf_momentum_tab_GL;
  }

  const class array<complex<double> > & get_scaled_wf_aft_R_tab_GL () const
  {
    return scaled_wf_aft_R_tab_GL;
  }

  const class array<complex<double> > & get_scaled_dwf_aft_R_tab_GL () const
  {
    return scaled_dwf_aft_R_tab_GL;
  }
  
  complex<double> Gamow_norm () const;
  
  complex<double> rms_radius_calc () const;

  void normalization (const complex<double> &factor);
  
  bool is_it_real () const;
  
  void make_it_real ();

  void normalization_before_R_after_matching_point (const complex<double> &Cplus_ratio);
  
  void HO_wave_function (const double b_HO);

  void wave_calculation_HO_diag (const class potentials_effective_mass &T , const double b_HO);

  void THO_wave_function (const class THO_class &THO);

  void wave_calculation_THO_diag (
				  const class potentials_effective_mass &T ,
				  const double b_HO ,
				  const class array<double> &r_tab , 
				  const class array<double> &rho ,
				  const class array<double> &r_HO_tab ,
				  const class array<double> &rho_HO);

  void zero (); 

  void k_search (
		 class potentials_effective_mass &T ,
		 const bool all_states ,
		 const bool print_statement);

  void wave_calculation (
			 const bool is_there_cout ,
			 class potentials_effective_mass &T ,
			 const bool scaled_tables_calc);  

  void wave_calculation (
			 const bool is_there_cout ,
			 class potentials_effective_mass &T ,
			 const bool scaled_tables_calc , 
			 const class array<double> &eff_mass_inv_minus_one_tab_uniform , 
			 const class array<double> &eff_mass_inv_der_tab_uniform , 
			 const class array<double> &eff_mass_inv_2der_tab_uniform , 
			 const class array<double> &eff_mass_inv_minus_one_tab_GL , 
			 const class array<double> &eff_mass_inv_der_tab_GL , 
			 const class array<double> &eff_mass_inv_2der_tab_GL);

  void wave_after_R_real_axis_tab_GL ();

  void PTG_eigenstate_calc (const bool is_there_cout , const class PTG_class &PTG_potential);
  
  void modified_PTG_eigenstate_calc (const bool is_there_cout , class potentials_effective_mass &T , const bool scaled_tables_calc);  

  void Coulomb_eigenstate_calc (const bool only_bef_R);

  void copy_to_file_for_figure_coordinate (const string debut_file_name , const bool is_it_Gauss_Legendre , const bool is_it_bef_R_only , const bool is_it_real_axis) const;
  
  void copy_to_file_for_figure_momentum (const string debut_file_name ,const bool is_it_Gauss_Legendre) const;
  
  void copy_to_file (const string &debut_file_name) const;
  
  void get_from_file (const string &debut_file_name);
  
  void copy_to_file_no_scaled_wfs (const string &debut_file_name) const;
  
  void get_from_file_no_scaled_wfs (const string &debut_file_name);
  
  void Qbox_wf_calc_from_file (const string &debut_file_name);
  
  //--// return the S_matrix associated to the spherical state
  const complex<double> get_S_matrix () const;

  //--// return the phase shift associated to the spherical state
  const complex<double> get_phase_shift () const;

  complex<double> overlap_OCM_core_shell_calc (const class spherical_state &OCM_core_shell) const;

  void OCM_core_shell_orthogonalize (const class spherical_state &OCM_core_shell);

#ifdef UseMPI
  void MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
#endif

  void set_is_k_search_start_used (const bool is_k_search_start_used_);
  void set_k_search_start (const complex<double> &k_search_start_);
  
  void wave_fill_from_HO_THO_tables (
				     const double b_HO ,
				     const bool is_it_Gauss_Legendre ,
				     const class array<double> &wfs_R0_tab ,
				     const class array<double> &dwfs_R0_tab ,
				     const class array<double> &wfs_bef_R_tab ,
				     const class array<double> &dwfs_bef_R_tab ,
				     const class array<double> &d2wfs_bef_R_tab);
  
  void wave_calculation_add_from_vector (
					 const bool is_energy_defined ,
					 const double E , 
					 const class vector_class<double> &V ,
					 const class array<unsigned int> &basis_shells_indices , 
					 const class array<class spherical_state> &basis_shells);

  void wave_calculation_from_vector (
				     const bool is_energy_defined ,
				     const double E , 
				     const class vector_class<double> &V ,
				     const class array<unsigned int> &basis_shells_indices , 
				     const class array<class spherical_state> &basis_shells);
  
  void wave_calculation_add_from_vector (
					 const bool is_energy_defined ,
					 const complex<double> &E , 
					 const class vector_class<complex<double> > &V ,
					 const class array<unsigned int> &basis_shells_indices , 
					 const class array<class spherical_state> &basis_shells);

  void wave_calculation_from_vector (
				     const bool is_energy_defined ,
				     const complex<double> &E , 
				     const class vector_class<complex<double> > &V ,
				     const class array<unsigned int> &basis_shells_indices , 
				     const class array<class spherical_state> &basis_shells);

  void wave_calculation_momentum (const double b_HO);
  
  bool is_it_filled () const;

  void accept ();
  void reject ();
  
  double log10_width_from_current_formula_calc () const;

  double width_from_current_formula_calc () const;
  
  friend double used_memory_calc (const class spherical_state &T);

private:
  
  bool is_k_OK; // true if the wave function is well defined (typically with an energy found with the Newton method for poles for example), false if not

  double kinetic_factor; // 2mu/hbar^2
  
  complex<double> k , eta , E; // linear momentum in fm^(-1) (nucleon) a0^(-1) (electron), Sommerfeld parameter (nucleon only), energy in MeV (nucleon) or Ry (electron)

  complex<double> C0 , Cplus , Cminus , CF , CG; // Integration constants: u(r) ~ C0 r^(l+1) for r ~ 0, u(r) = Cplus H+(l,eta,kr) + Cminus H-(l,eta,kr) = CF F(l,eta,kr) + CG G(l,eta,kr) for r > R

  complex<double> wf_R0 , dwf_R0;  // wave function at R0 ,  which may not be on the grid.

  bool is_k_search_start_used; // true if a starting energy is used for the Newton method for poles, false if not

  complex<double> k_search_start; // value of the starting linear momentum for the Newton method for poles 

  bool isItRotor; // true if one is the rotor case, false if not

  bool   is_it_relative; // true if the wave function is relative (diproton, dineutron, deuteron), false if not. COSM is not considered as relative.

  bool   are_there_scaled_wfs; // scaled wave functions are calculated_only if are_there_scaled_wfs is true

  int    n;  // principal quantum number
  double jr; // rotor angular momenutum (rotor only)
  int    l;  // orbital angular momenutum
  double j;  // total angular momenutum (nucleon only)

  enum particle_type   particle; // proton, neutron or electron

  bool S_matrix_pole; // true for bound and resonant states, false for scattering states

  enum potential_type  potential; // type of potential: WS, PTG, KKNN, dipolar, qudrupolar, Gaussian, ...

  int A , Z_charge; // number of nucleons and charge of the nucleus creating the potential (nucleon only)

  double R , matching_point , s_radial , R0 , R_real_max;  // s_radial: non-analytic point for electron. R_real_max =  maximal radius for integration with HO states.

  double kmax_momentum; // maximal momentum in momentum space

  double R_Fermi_momentum; // Radius of the Fermi function used to make the Fourier-Bessel transform of one-body states finite on the real axis 
  
  double step_bef_R_uniform , step_aft_R_uniform; // number of points on uniform grid on [0:R] (nucleon) or [s_radial:R] (electron), (before R) and [R:R_real_max], ]0:R^{-1/4}[ (after R)

  double step_momentum_uniform; // number of points on uniform grid on [0:kmax_momentum]

  unsigned int N_matching_point , N_bef_s_GL , N_bef_R_GL , N_aft_R_GL ,  N_bef_R_uniform , N_aft_R_uniform; // number of points on [0:s_radial] (electron), [0:R] (nucleon) or [s_radial:R] (electron), [R:R_real_max], ]0:R^{-1/4}[ (after R) 
  // using Gauss-Legendre (GL) or uniform (uniform) discretization

  unsigned int Nk_momentum_uniform , Nk_momentum_GL; // number of points on [0:kmax_momentum] using Gauss-Legendre (GL) or uniform (uniform) discretization
  
  bool is_it_cwf_standard_normalization; // true if one uses the standard normalization of Coulomb wave functions, 
                                         // false if one uses the other normalization, with which Cl(eta) is removed so that the wave function does not underflow or overflow.


 
  class array<double>           r_bef_R_tab_uniform;                                    // Uniformly distributed abscissas before R : r = i.step_bef_R_uniform ,  i in [0:N_bef_R_uniform-1]

  class array<double>           r_bef_R_tab_GL , w_bef_R_tab_GL;                    // Gaussian abscissas and weights before R : r in ]0:R[ (nucleon) or ]s_radial:R[ (electron).
  class array<double>           r_bef_s_tab_GL , w_bef_s_tab_GL;                    // Gaussian abscissas and weights before R : r in ]0:s_radial[ (electron).

  class array<double>           r_bef_R_tab_GL_SGI_MSGI , w_bef_R_tab_GL_SGI_MSGI;  // Gaussian abscissas and weights before R : r in ]0:2.R0[ for SGI and MSGI integrals.

  class array<double>           r_aft_R_tab_GL_real    , w_aft_R_tab_GL_real;       // Gaussian abscissas and weights after R : r in ]R:R_real_max[ if R_real_max > 0.
  class array<complex<double> > r_aft_R_tab_GL_complex , w_aft_R_tab_GL_complex;    // Gaussian abscissas and weights after R : r in ]R:R + (R-R_real_max)exp(i.theta)[ ,  if R_real_max > 0.

  class array<double>           um4_aft_R_tab_GL , w_aft_R_tab_GL;                  // Gaussian abscissas to the power -4 and weights times u^{-5} after R : u in ]0:R^{-1/4}[.

  // z = R + (um4-R).exp[i.theta] ,  x in ]R:+oo[
  // One has : Reg \int_{R}^{+oo} f(z) dz ~ \sum_{i=0}^{N_tab_GL-1} f(z(um4_aft_R_tab_GL(i))).w_aft_R_tab_GL(i) .

  class array<double> k_tab_uniform; // Uniformly distributed abscissas on [0:kmax_momentum]
  
  class array<double> k_tab_GL , wk_tab_GL; // Gaussian abscissas and weights on [0:kmax_momentum]


  class array<complex<double> > wf_bef_R_tab_uniform ;  // wave function on [0:R] with N_bef_R_uniform points.
  class array<complex<double> > dwf_bef_R_tab_uniform;  // wave function derivative on [0:R] with N_bef_R_uniform points.
  class array<complex<double> > d2wf_bef_R_tab_uniform; // wave function second derivative on [0:R] with N_bef_R_uniform points.

  // scaled_wf_aft_R(1 , angle_index , i) = C-.H-(k.z).exp[i[kz - eta.log[kz]]] with N_aft_R_uniform points , 
  // same with derivatives.
  // z = R + (r-R).exp(I.theta) ,  r = u_bef_R_tab_GL(i)^{-4}
  // scaled_wf/dwf_aft_R(asy , angle_index , i) : asy=0 , 1 => outgoing ,  ingoing.
  // scaled_wf/dwf_aft_R(asy , angle_index , i) : angle_index=0 , 1 , 2 , 3 => theta =  Pi/4 ,  3Pi/4 ,  -3Pi/4 ,  -Pi/4.

  class array<complex<double> > scaled_wf_aft_R_tab_uniform;
  class array<complex<double> > scaled_dwf_aft_R_tab_uniform;

  class array<complex<double> > wf_bef_R_tab_GL;   // wave function on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.
  class array<complex<double> > dwf_bef_R_tab_GL;  // wave derivative on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.
  class array<complex<double> > d2wf_bef_R_tab_GL; // wave second derivatives on [0:R] (nucleon) or [s_radial:R] (electron) with Gaussian points.

  class array<complex<double> > wf_bef_s_tab_GL;   // wave function and derivatives on [0:s_radial] with Gaussian points (electron).
  class array<complex<double> > dwf_bef_s_tab_GL;  // wave derivative on [0:s_radial] with Gaussian points (electron).
  class array<complex<double> > d2wf_bef_s_tab_GL; // wave second derivative on [0:s_radial] with Gaussian points (electron).

  class array<complex<double> > wf_bef_R_tab_GL_SGI_MSGI;   // wave function on [0:2.R0] with Gaussian points.
  class array<complex<double> > dwf_bef_R_tab_GL_SGI_MSGI;  // wave function derivative on [0:2.R0] with Gaussian points.

  class array<complex<double> > wf_aft_R_tab_GL_real;    // wave function on [R:R_real_max] with Gaussian points.
  class array<complex<double> > dwf_aft_R_tab_GL_real;   // wave function derivative on [R:R_real_max] with Gaussian points.
  class array<complex<double> > d2wf_aft_R_tab_GL_real;  // wave function second derivative on [R:R_real_max] with Gaussian points.

  class array<complex<double> > wf_aft_R_tab_GL_complex;   // wave function on [R:R + (R - R_real_max)exp(i.theta)].
  class array<complex<double> > dwf_aft_R_tab_GL_complex;  // wave function derivative on [R:R + (R - R_real_max)exp(i.theta)].
  class array<complex<double> > d2wf_aft_R_tab_GL_complex; // wave function second derivative on [R:R + (R - R_real_max)exp(i.theta)].

  // One uses an HO expansion of u(r) to calculate its Fourier-Bessel transform to avoid divergence problems.
  
  class array<complex<double> > wf_momentum_tab_uniform , dwf_momentum_tab_uniform; // wave function and derivative in momentum space on [0:kmax_momentum] using a unform grid
  class array<complex<double> > wf_momentum_tab_GL  , dwf_momentum_tab_GL;          // wave function and derivative in momentum space on [0:kmax_momentum] using with Gaussian points

    
  // scaled_wf_aft_R(1 , angle_index , i) = C-.H-(k.z).exp[i[kz - eta.log[kz]]] with Gaussian points , 
  // same with derivatives.
  // z = R + (r-R).exp(I.theta) ,  r = u_bef_R_tab_GL(i)^{-4}
  // scaled_wf/dwf_aft_R(asy , angle_index , i) : asy=0 , 1 => outgoing ,  ingoing.
  // scaled_wf/dwf_aft_R(asy , angle_index , i) : angle_index=0 , 1 , 2 , 3 => theta =  Pi/4 ,  3Pi/4 ,  -3Pi/4 ,  -Pi/4.

  class array<complex<double> > scaled_wf_aft_R_tab_GL; 
  class array<complex<double> > scaled_dwf_aft_R_tab_GL;

  void d2wf_calc_before_R (const class potentials_effective_mass &T);

  void unscale_wave_function (
			      const class potentials_effective_mass &T , 
			      const class array<double> &eff_mass_inv_minus_one_tab_uniform , 
			      const class array<double> &eff_mass_inv_der_tab_uniform , 
			      const class array<double> &eff_mass_inv_2der_tab_uniform , 
			      const class array<double> &eff_mass_inv_minus_one_tab_GL , 
			      const class array<double> &eff_mass_inv_der_tab_GL , 
			      const class array<double> &eff_mass_inv_2der_tab_GL);

  void branch_cut_correction (
			      const complex<double> &exp_two_Pi_eta , 
			      const complex<double> &exp_two_Pi_eta_minus_one , 
			      class Coulomb_wave_functions &cwf , 
			      const class array<complex<double> > &z_tab , 
			      const unsigned int angle_index , 
			      const unsigned int i , 
			      bool &is_it_crossed , 
			      class array<complex<double> > &scaled_wfs , 
			      class array<complex<double> > &scaled_dwfs);

  void out_ingoing_waves_after_R (const unsigned int angle_index);

  void out_ingoing_waves_after_R_Cplus_Cminus_multiplication_infinities_remove (const unsigned int angle_index);

  void HO_matrix_calc (const class potentials_effective_mass &T , const double b_HO , class matrix<double> &HO_matrix) const;

  void THO_matrix_calc (const class potentials_effective_mass &T , const class THO_class &THO , class matrix<double> &THO_matrix) const;

  bool is_it_here (class potentials_effective_mass &T , const unsigned int N , const bool is_it_antibound , double &E_debut , double &E_end) const;

  void k_bisection (class potentials_effective_mass &T);

  void N_bound_E_HO_guess (class potentials_effective_mass &T , unsigned int &N_bound , double &E_HO_guess) const; 

  double b_HO_calc () const;

  void broad_state_k_guess (
			    class potentials_effective_mass &T ,
			    const unsigned int Nk , 
			    const double Re_k_min ,
			    const double Re_k_max , 
			    const double abs_Im_k_min ,
			    const double abs_Im_k_max);

  void k_guess (class potentials_effective_mass &T , const bool all_states);

  complex<double> k_PTG_guess (const class potentials_effective_mass &T , const unsigned int N_bound) const;

  complex<double> k_PTG_calc (const class PTG_class &PTG_potential , const double Es) const;

  void PTG_wf_dwf_d2wf_small_r_calc (const class PTG_class &PTG_potential ,
				     const double y ,
				     complex<double> &wf ,
				     complex<double> &dwf ,
				     complex<double> &d2wf) const;

  void PTG_wf_dwf_d2wf_pole_large_r_calc (const class PTG_class &PTG_potential,
					  const double L2_sr ,
					  complex<double> &wf ,
					  complex<double> &dwf ,
					  complex<double> &d2wf) const;
  
  void PTG_wf_dwf_d2wf_scat_large_r_calc (const class PTG_class &PTG_potential ,
					  const double L2_sr ,
					  complex<double> &wf ,
					  complex<double> &dwf ,
					  complex<double> &d2wf) const;

  void PTG_wf_dwf_d2wf_calc (const class PTG_class &PTG_potential ,
			     const double y ,
			     complex<double> &wf ,
			     complex<double> &dwf ,
			     complex<double> &d2wf) const;
  
  complex<double> PTG_state_norm_calc (const class PTG_class &PTG_potential) const;
  
  void PTG_bef_R_constants_wfs_calc (const class PTG_class &PTG_potential);

  void forward_integration_before_R (const class ODE_integration &ODE);

  void backward_integration_before_R (const class ODE_integration &ODE);

  void Cplus_Cminus_CF_CG_calc (const class ODE_integration &ODE);
  
  unsigned int all_data_dimension_calc () const;
  
  unsigned int all_data_dimension_no_scaled_wfs_calc () const;
};


bool same_nlj (const class spherical_state &s1 , const class spherical_state &s2);
bool same_lj  (const class spherical_state &s1 , const class spherical_state &s2);

ostream & operator << (ostream &os , const class spherical_state &u);

bool operator == (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2);


bool operator != (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2);

bool operator < (
		 const class spherical_state &s1 , 
		 const class spherical_state &s2);

bool operator <= (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2);


bool operator > (
		 const class spherical_state &s1 , 
		 const class spherical_state &s2);


bool operator >= (
		  const class spherical_state &s1 , 
		  const class spherical_state &s2);


#endif
