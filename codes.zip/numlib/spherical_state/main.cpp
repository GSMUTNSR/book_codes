#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace Jost_WS_potential_fit;

void PTG_no_effective_mass_test_pole (
				      const int A , 
				      const int n , 
				      const int l , 	
				      const double j , 						
				      const double R , 
				      const double Rmax , 
				      const double kmax_momentum , 
				      const double Rmp , 								 
				      const double target_mass , 
				      const double nu_mass , 				 
				      const unsigned int N_GL , 
				      const unsigned int N_uniform , 
				      const double Lambda , 
				      const double s , 
				      const double nu)
{
  cout << endl << endl << "No effective mass (pole)" << endl << "---------------------------" << endl;

  class spherical_state u_test(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			       true , NEUTRON , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);

  cout << "PTG wave function from analytical formulas" << endl;

  const double kinetic_factor = u_test.get_kinetic_factor ();

  const double a = 0.0;

  class potentials_effective_mass T;

  class PTG_class &PTG_potential = T.get_PTG_potential ();
  
  PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);
  
  T.initialize_constants (PTG_POTENTIAL , kinetic_factor , NADA , l , 0 , j , NADA , NADA , NADA);
  
  u_test.PTG_eigenstate_calc (true , PTG_potential);

  cout << endl << "PTG wave function from numerical integration" << endl;

  class spherical_state u(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,
			  N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			  true , NEUTRON , n , NADA , l , j , false , u_test.get_k () , nu_mass , 1.0 , 1.0);
  
  u.k_search (T , true , true);

  u.wave_calculation (true , T , true);

  cout << endl;

  const class array<complex<double> > &wf_bef_R_tab_uniform_test   = u_test.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform_test  = u_test.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform_test = u_test.get_d2wf_bef_R_tab_uniform ();

  const class array<complex<double> > &wf_bef_R_tab_uniform   = u.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform  = u.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform = u.get_d2wf_bef_R_tab_uniform ();

  double test_wfs_uniform = 0.0;

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    test_wfs_uniform += inf_norm (wf_bef_R_tab_uniform(i) - wf_bef_R_tab_uniform_test(i)) + inf_norm (dwf_bef_R_tab_uniform(i) - dwf_bef_R_tab_uniform_test(i)) + inf_norm (d2wf_bef_R_tab_uniform(i) - d2wf_bef_R_tab_uniform_test(i));

  test_wfs_uniform /= 3.0*N_uniform;

  const class array<complex<double> > &wf_bef_R_tab_GL_test   = u_test.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL_test  = u_test.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL_test = u_test.get_d2wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_bef_R_tab_GL   = u.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL  = u.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL = u.get_d2wf_bef_R_tab_GL ();

  double test_wfs_GL = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    test_wfs_GL += inf_norm (wf_bef_R_tab_GL(i) - wf_bef_R_tab_GL_test(i)) + inf_norm (dwf_bef_R_tab_GL(i) - dwf_bef_R_tab_GL_test(i)) + inf_norm (d2wf_bef_R_tab_GL(i) - d2wf_bef_R_tab_GL_test(i));
  
  test_wfs_GL /= 3.0*N_GL;

  const double test_wfs = 0.5*(test_wfs_uniform + test_wfs_GL);

  cout << "Linear momentum precision : " << inf_norm (u.get_k () - u_test.get_k ()) << endl;
  
  cout << "Wave functions precision : " << test_wfs << endl;
}












void PTG_no_effective_mass_test_scat (
				      const int A , 
				      const complex<double> &k , 
				      const int l , 	
				      const double j , 						
				      const double R , 
				      const double Rmax , 
				      const double kmax_momentum , 
				      const double Rmp , 								 
				      const double target_mass , 
				      const double nu_mass , 				 
				      const unsigned int N_GL , 
				      const unsigned int N_uniform , 
				      const double Lambda , 
				      const double s , 
				      const double nu)
{
  cout << endl << endl << "No effective mass (scat)" << endl << "---------------------------" << endl;

  class spherical_state u_test(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			       false , NEUTRON , NADA , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

  const double kinetic_factor = u_test.get_kinetic_factor ();

  const double a = 0.0;

  class potentials_effective_mass T;

  class PTG_class &PTG_potential = T.get_PTG_potential ();
  
  PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);
  
  T.initialize_constants (PTG_POTENTIAL , kinetic_factor , NADA , l , 0 , j , NADA , NADA , NADA);
  
  u_test.PTG_eigenstate_calc (true , PTG_potential);

  class spherical_state u(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,
			  N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			  false , NEUTRON , NADA , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);
  
  u.wave_calculation (true , T , true);

  const class array<complex<double> > &wf_bef_R_tab_uniform_test   = u_test.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform_test  = u_test.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform_test = u_test.get_d2wf_bef_R_tab_uniform ();

  const class array<complex<double> > &wf_bef_R_tab_uniform   = u.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform  = u.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform = u.get_d2wf_bef_R_tab_uniform ();

  double test_wfs_uniform = 0.0;

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    test_wfs_uniform += inf_norm (wf_bef_R_tab_uniform(i) - wf_bef_R_tab_uniform_test(i)) + inf_norm (dwf_bef_R_tab_uniform(i) - dwf_bef_R_tab_uniform_test(i)) + inf_norm (d2wf_bef_R_tab_uniform(i) - d2wf_bef_R_tab_uniform_test(i));

  test_wfs_uniform /= 3.0*N_uniform;

  const class array<complex<double> > &wf_bef_R_tab_GL_test   = u_test.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL_test  = u_test.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL_test = u_test.get_d2wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_bef_R_tab_GL   = u.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL  = u.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL = u.get_d2wf_bef_R_tab_GL ();

  double test_wfs_GL = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    test_wfs_GL += inf_norm (wf_bef_R_tab_GL(i) - wf_bef_R_tab_GL_test(i)) + inf_norm (dwf_bef_R_tab_GL(i) - dwf_bef_R_tab_GL_test(i)) + inf_norm (d2wf_bef_R_tab_GL(i) - d2wf_bef_R_tab_GL_test(i));
  
  test_wfs_GL /= 3.0*N_GL;

  const double test_wfs = 0.5*(test_wfs_uniform + test_wfs_GL);
  
  cout << "k : " << k << " fm^(-1)" << endl;
  
  cout << "Wave functions precision : " << test_wfs << endl;
}




















void PTG_effective_mass_test_pole (
				   const int A , 
				   const int n , 
				   const int l , 			
				   const double j , 				
				   const double R , 
				   const double Rmax , 
				   const double kmax_momentum , 
				   const double Rmp , 								 
				   const double target_mass , 
				   const double nu_mass , 			 
				   const unsigned int N_GL , 
				   const unsigned int N_uniform , 
				   const double Lambda , 
				   const double s , 
				   const double nu , 
				   const double a)
{
  cout << endl << endl << "Effective mass (pole)" << endl << "------------------------" << endl;

  class spherical_state u_test(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,			       
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			       true , NEUTRON , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);

  cout << "PTG wave function from analytical formulas" << endl;

  const double kinetic_factor = u_test.get_kinetic_factor ();
  
  const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
  
  u_test.PTG_eigenstate_calc (true , PTG_potential);
  
  cout << endl << "PTG wave function from numerical integration" << endl;
  
  class spherical_state u(false , true , EFFECTIVE_MASS_POTENTIAL_PTG_LIKE , A , 0 , target_mass , NADA ,
			  N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R , 
			  true , NEUTRON , n , NADA , l , j , false , u_test.get_k () , nu_mass , 1.0 , 1.0);
  
  class array<double> effective_mass_inv_minus_one_tab_uniform(N_uniform);
  class array<double> effective_mass_inv_der_tab_uniform(N_uniform);
  class array<double> effective_mass_inv_2der_tab_uniform(N_uniform);

  class array<double> effective_mass_inv_minus_one_tab_GL(N_GL);
  class array<double> effective_mass_inv_der_tab_GL(N_GL);
  class array<double> effective_mass_inv_2der_tab_GL(N_GL);

  class array<double> full_effective_mass_tab(N_uniform);

  class array<double> potential_tab_unscaled(N_uniform);
  class array<double> potential_tab_scaled(N_uniform);

  const class array<double> &r_bef_R_tab_uniform = u.get_r_bef_R_tab_uniform ();

  const class array<double> &r_bef_R_tab_GL = u.get_r_bef_R_tab_GL ();

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);
      
      const double r_plus  = r + sqrt_precision;
      const double r_minus = r - sqrt_precision;

      const double effective_mass_r = PTG_potential.effective_mass (r)/kinetic_factor;
      
      const double effective_mass_der_r = PTG_potential.effective_mass_der (r)/kinetic_factor;

      const double effective_mass_der_r_plus  = PTG_potential.effective_mass_der (r_plus)/kinetic_factor;
      const double effective_mass_der_r_minus = PTG_potential.effective_mass_der (r_minus)/kinetic_factor;
      
      const double effective_mass_2der_r = (effective_mass_der_r_plus - effective_mass_der_r_minus)/(r_plus - r_minus);

      const double effective_mass_inv_der_r = -effective_mass_der_r/(effective_mass_r*effective_mass_r);
      
      const double effective_mass_inv_2der_r = (-effective_mass_2der_r + 2.0*effective_mass_der_r*effective_mass_der_r/effective_mass_r)/(effective_mass_r*effective_mass_r);

      effective_mass_inv_minus_one_tab_uniform(i) = 1.0/effective_mass_r - 1.0;

      effective_mass_inv_der_tab_uniform(i) = effective_mass_inv_der_r;

      effective_mass_inv_2der_tab_uniform(i) = effective_mass_inv_2der_r;

      potential_tab_unscaled(i) = PTG_potential(r);

      full_effective_mass_tab(i) = kinetic_factor*effective_mass_r;

      potential_tab_scaled(i) = potential_tab_unscaled(i) + (0.5*effective_mass_inv_2der_r - 0.25*effective_mass_inv_der_r*effective_mass_inv_der_r*effective_mass_r)/kinetic_factor;
    }
    
  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      
      const double r_plus  = r + sqrt_precision;
      const double r_minus = r - sqrt_precision;

      const double effective_mass_r = PTG_potential.effective_mass (r)/kinetic_factor;

      const double effective_mass_der_r = PTG_potential.effective_mass_der (r)/kinetic_factor;

      const double effective_mass_der_r_plus  = PTG_potential.effective_mass_der (r_plus)/kinetic_factor;
      const double effective_mass_der_r_minus = PTG_potential.effective_mass_der (r_minus)/kinetic_factor;
      
      const double effective_mass_2der_r = (effective_mass_der_r_plus - effective_mass_der_r_minus)/(r_plus - r_minus);

      const double effective_mass_inv_der_r = -effective_mass_der_r/(effective_mass_r*effective_mass_r);
      
      const double effective_mass_inv_2der_r = (-effective_mass_2der_r + 2.0*effective_mass_der_r*effective_mass_der_r/effective_mass_r)/(effective_mass_r*effective_mass_r);

      effective_mass_inv_minus_one_tab_GL(i) = 1.0/effective_mass_r - 1.0;

      effective_mass_inv_der_tab_GL(i) = effective_mass_inv_der_r;

      effective_mass_inv_2der_tab_GL(i) = effective_mass_inv_2der_r;
    }
  
  class potentials_effective_mass T;

  T.initialize_constants (EFFECTIVE_MASS_POTENTIAL_PTG_LIKE , kinetic_factor , NADA , l , 0 , j , NADA , NADA , NADA);

  class splines_class<double> &V_effective_mass_unscaled = T.get_V_effective_mass_unscaled ();

  class splines_class<double> &V_effective_mass_scaled = T.get_V_effective_mass_scaled ();

  class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();
  
  V_effective_mass_unscaled.allocate_calc (r_bef_R_tab_uniform , potential_tab_unscaled , 0.0 , 0.0);

  V_effective_mass_scaled.allocate_calc (r_bef_R_tab_uniform , potential_tab_scaled , 0.0 , 0.0);

  full_effective_mass.allocate_calc (r_bef_R_tab_uniform , full_effective_mass_tab , 0.0 , 0.0);
  
  u.k_search (T , true , true);

  u.wave_calculation (true , T , true , effective_mass_inv_minus_one_tab_uniform , effective_mass_inv_der_tab_uniform , effective_mass_inv_2der_tab_uniform ,
		      effective_mass_inv_minus_one_tab_GL , effective_mass_inv_der_tab_GL , effective_mass_inv_2der_tab_GL);

  cout << endl;

  const class array<complex<double> > &wf_bef_R_tab_uniform_test   = u_test.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform_test  = u_test.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform_test = u_test.get_d2wf_bef_R_tab_uniform ();
  
  const class array<complex<double> > &wf_bef_R_tab_uniform   = u.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform  = u.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform = u.get_d2wf_bef_R_tab_uniform ();

  double test_wfs_uniform = 0.0;

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    test_wfs_uniform += inf_norm (wf_bef_R_tab_uniform(i) - wf_bef_R_tab_uniform_test(i)) + inf_norm (dwf_bef_R_tab_uniform(i) - dwf_bef_R_tab_uniform_test(i)) + inf_norm (d2wf_bef_R_tab_uniform(i) - d2wf_bef_R_tab_uniform_test(i));

  test_wfs_uniform /= 3.0*N_uniform;

  const class array<complex<double> > &wf_bef_R_tab_GL_test   = u_test.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL_test  = u_test.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL_test = u_test.get_d2wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_bef_R_tab_GL   = u.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL  = u.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL = u.get_d2wf_bef_R_tab_GL ();

  double test_wfs_GL = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    test_wfs_GL += inf_norm (wf_bef_R_tab_GL(i) - wf_bef_R_tab_GL_test(i)) + inf_norm (dwf_bef_R_tab_GL(i) - dwf_bef_R_tab_GL_test(i)) + inf_norm (d2wf_bef_R_tab_GL(i) - d2wf_bef_R_tab_GL_test(i));

  test_wfs_GL /= 3.0*N_GL;

  const double test_wfs = 0.5*(test_wfs_uniform + test_wfs_GL);

  cout << "Linear momentum precision : " << inf_norm (u.get_k () - u_test.get_k ()) << endl;
  
  cout << "Wave functions precision : " << test_wfs << endl;
}


















void PTG_effective_mass_test_scat (
				   const int A , 
				   const complex<double> &k , 
				   const int l , 			
				   const double j , 				
				   const double R , 
				   const double Rmax , 
				   const double kmax_momentum , 
				   const double Rmp , 								 
				   const double target_mass , 
				   const double nu_mass , 			 
				   const unsigned int N_GL , 
				   const unsigned int N_uniform , 
				   const double Lambda , 
				   const double s , 
				   const double nu , 
				   const double a)
{
  cout << endl << endl << "Effective mass (scat)" << endl << "------------------------" << endl;

  class spherical_state u_test(false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA ,			       
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R ,
			       false , NEUTRON , NADA , NADA , l , j , true , k , nu_mass , 1.0 , 1.0);

  const double kinetic_factor = u_test.get_kinetic_factor ();
  
  const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
  
  u_test.PTG_eigenstate_calc (true , PTG_potential);
  
  class spherical_state u(false , true , EFFECTIVE_MASS_POTENTIAL_PTG_LIKE , A , 0 , target_mass , NADA ,
			  N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , Rmp , Rmax , kmax_momentum , R ,
			  false , NEUTRON , NADA , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);
  
  class array<double> effective_mass_inv_minus_one_tab_uniform(N_uniform);
  class array<double> effective_mass_inv_der_tab_uniform(N_uniform);
  class array<double> effective_mass_inv_2der_tab_uniform(N_uniform);

  class array<double> effective_mass_inv_minus_one_tab_GL(N_GL);
  class array<double> effective_mass_inv_der_tab_GL(N_GL);
  class array<double> effective_mass_inv_2der_tab_GL(N_GL);

  class array<double> full_effective_mass_tab(N_uniform);

  class array<double> potential_tab_unscaled(N_uniform);
  class array<double> potential_tab_scaled(N_uniform);

  const class array<double> &r_bef_R_tab_uniform = u.get_r_bef_R_tab_uniform ();

  const class array<double> &r_bef_R_tab_GL = u.get_r_bef_R_tab_GL ();

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    {
      const double r = r_bef_R_tab_uniform(i);
      
      const double r_plus  = r + sqrt_precision;
      const double r_minus = r - sqrt_precision;

      const double effective_mass_r = PTG_potential.effective_mass (r)/kinetic_factor;
      
      const double effective_mass_der_r = PTG_potential.effective_mass_der (r)/kinetic_factor;

      const double effective_mass_der_r_plus  = PTG_potential.effective_mass_der (r_plus)/kinetic_factor;
      const double effective_mass_der_r_minus = PTG_potential.effective_mass_der (r_minus)/kinetic_factor;
      
      const double effective_mass_2der_r = (effective_mass_der_r_plus - effective_mass_der_r_minus)/(r_plus - r_minus);

      const double effective_mass_inv_der_r = -effective_mass_der_r/(effective_mass_r*effective_mass_r);
      
      const double effective_mass_inv_2der_r = (-effective_mass_2der_r + 2.0*effective_mass_der_r*effective_mass_der_r/effective_mass_r)/(effective_mass_r*effective_mass_r);

      effective_mass_inv_minus_one_tab_uniform(i) = 1.0/effective_mass_r - 1.0;

      effective_mass_inv_der_tab_uniform(i) = effective_mass_inv_der_r;

      effective_mass_inv_2der_tab_uniform(i) = effective_mass_inv_2der_r;

      potential_tab_unscaled(i) = PTG_potential(r);

      full_effective_mass_tab(i) = kinetic_factor*effective_mass_r;

      potential_tab_scaled(i) = potential_tab_unscaled(i) + (0.5*effective_mass_inv_2der_r - 0.25*effective_mass_inv_der_r*effective_mass_inv_der_r*effective_mass_r)/kinetic_factor;
    }
    
  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      
      const double r_plus  = r + sqrt_precision;
      const double r_minus = r - sqrt_precision;

      const double effective_mass_r = PTG_potential.effective_mass (r)/kinetic_factor;

      const double effective_mass_der_r = PTG_potential.effective_mass_der (r)/kinetic_factor;

      const double effective_mass_der_r_plus  = PTG_potential.effective_mass_der (r_plus)/kinetic_factor;
      const double effective_mass_der_r_minus = PTG_potential.effective_mass_der (r_minus)/kinetic_factor;
      
      const double effective_mass_2der_r = (effective_mass_der_r_plus - effective_mass_der_r_minus)/(r_plus - r_minus);

      const double effective_mass_inv_der_r = -effective_mass_der_r/(effective_mass_r*effective_mass_r);
      
      const double effective_mass_inv_2der_r = (-effective_mass_2der_r + 2.0*effective_mass_der_r*effective_mass_der_r/effective_mass_r)/(effective_mass_r*effective_mass_r);

      effective_mass_inv_minus_one_tab_GL(i) = 1.0/effective_mass_r - 1.0;

      effective_mass_inv_der_tab_GL(i) = effective_mass_inv_der_r;

      effective_mass_inv_2der_tab_GL(i) = effective_mass_inv_2der_r;
    }
  
  class potentials_effective_mass T;

  T.initialize_constants (EFFECTIVE_MASS_POTENTIAL_PTG_LIKE , kinetic_factor , NADA , l , 0 , j , NADA , NADA , NADA);

  class splines_class<double> &V_effective_mass_unscaled = T.get_V_effective_mass_unscaled ();

  class splines_class<double> &V_effective_mass_scaled = T.get_V_effective_mass_scaled ();

  class splines_class<double> &full_effective_mass = T.get_full_effective_mass ();
  
  V_effective_mass_unscaled.allocate_calc (r_bef_R_tab_uniform , potential_tab_unscaled , 0.0 , 0.0);

  V_effective_mass_scaled.allocate_calc (r_bef_R_tab_uniform , potential_tab_scaled , 0.0 , 0.0);

  full_effective_mass.allocate_calc (r_bef_R_tab_uniform , full_effective_mass_tab , 0.0 , 0.0);
  
  u.wave_calculation (true , T , true , effective_mass_inv_minus_one_tab_uniform , effective_mass_inv_der_tab_uniform , effective_mass_inv_2der_tab_uniform ,
		      effective_mass_inv_minus_one_tab_GL , effective_mass_inv_der_tab_GL , effective_mass_inv_2der_tab_GL);

  const class array<complex<double> > &wf_bef_R_tab_uniform_test   = u_test.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform_test  = u_test.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform_test = u_test.get_d2wf_bef_R_tab_uniform ();
  
  const class array<complex<double> > &wf_bef_R_tab_uniform   = u.get_wf_bef_R_tab_uniform ();
  const class array<complex<double> > &dwf_bef_R_tab_uniform  = u.get_dwf_bef_R_tab_uniform ();
  const class array<complex<double> > &d2wf_bef_R_tab_uniform = u.get_d2wf_bef_R_tab_uniform ();

  double test_wfs_uniform = 0.0;

  for (unsigned int i = 0 ; i < N_uniform ; i++)
    test_wfs_uniform += inf_norm (wf_bef_R_tab_uniform(i) - wf_bef_R_tab_uniform_test(i)) + inf_norm (dwf_bef_R_tab_uniform(i) - dwf_bef_R_tab_uniform_test(i)) + inf_norm (d2wf_bef_R_tab_uniform(i) - d2wf_bef_R_tab_uniform_test(i));

  test_wfs_uniform /= 3.0*N_uniform;

  const class array<complex<double> > &wf_bef_R_tab_GL_test   = u_test.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL_test  = u_test.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL_test = u_test.get_d2wf_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_bef_R_tab_GL   = u.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &dwf_bef_R_tab_GL  = u.get_dwf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_bef_R_tab_GL = u.get_d2wf_bef_R_tab_GL ();

  double test_wfs_GL = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    test_wfs_GL += inf_norm (wf_bef_R_tab_GL(i) - wf_bef_R_tab_GL_test(i)) + inf_norm (dwf_bef_R_tab_GL(i) - dwf_bef_R_tab_GL_test(i)) + inf_norm (d2wf_bef_R_tab_GL(i) - d2wf_bef_R_tab_GL_test(i));

  test_wfs_GL /= 3.0*N_GL;

  const double test_wfs = 0.5*(test_wfs_uniform + test_wfs_GL);
  
  cout << "k : " << k << " fm^(-1)" << endl;
  
  cout << "Wave functions precision : " << test_wfs << endl;
}




#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#endif

    OpenMP_initialization ();

    cout.precision (15);

    const int A = 50;

    const int n = 1;
    
    const int l = 1;

    const double target_mass = 50;

    const double R = 20;

    const double Rmax = 100;

    const double kmax_momentum = 5.0;
      
    const double Rmp = 3.5; 

    const double nu_mass = 1;

    const double j = l + 0.5;

    const unsigned int N_GL = 100;

    const unsigned int N_uniform = 500;

    //-----------------------------------------------------------------------------------------------------------//
    
    const double Lambda = 5;

    const double s = 0.05;
    
    const double nu = 4.6;

    const double a = 0.4;

    //-----------------------------------------------------------------------------------------------------------//
    
    const complex<double> k(0.1 , -0.001);
    
    PTG_no_effective_mass_test_pole (A , n , l , j , R , Rmax , kmax_momentum , Rmp , target_mass , nu_mass , N_GL , N_uniform , Lambda , s , nu);
    PTG_no_effective_mass_test_scat (A , k , l , j , R , Rmax , kmax_momentum , Rmp , target_mass , nu_mass , N_GL , N_uniform , Lambda , s , nu);

    cout << endl;

    PTG_effective_mass_test_pole (A , n , l , j , R , Rmax , kmax_momentum , Rmp , target_mass , nu_mass , N_GL , N_uniform , Lambda , s , nu , a);
    PTG_effective_mass_test_scat (A , k , l , j , R , Rmax , kmax_momentum , Rmp , target_mass , nu_mass , N_GL , N_uniform , Lambda , s , nu , a);
          
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

