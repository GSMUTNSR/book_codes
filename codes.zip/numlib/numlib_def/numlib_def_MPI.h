#ifndef NUMLIB_DEF_H
#define NUMLIB_DEF_H

// ================================== ================================== //
/*
  #define UseMPI
  //#define UseOpenMP
  #define UsePetsc

  #ifdef UseMPI
  #include "mpi.h"
  #endif

  #ifdef UseOpenMP
  #include "omp.h"
  #endif

  // Petsc defines and includes
  #ifdef UsePetsc
  #define PETSC_HAVE_BROKEN_RECURSIVE_MACRO  // for.hpp files
  #include <petsctao.h>
  #endif
  // */
// ================================== ================================== //

//--// standard libraries
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <cstring>
#include <complex>

#include <math.h>
#include <time.h>
#include <limits>
#include <vector>
#include <iterator>
#include <map>
#include <algorithm>

using std::boolalpha;
using std::scientific;
using std::fixed;
using std::cin;
using std::cout;
using std::cerr;
using std::clog;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using std::istringstream;
using std::ostringstream;
using std::ios;
using std::ios_base;
using std::map;
using std::istream_iterator;
using std::complex;
using std::polar;
using std::vector;
using std::min;
using std::max;
using std::swap;
using std::pow;
using std::abs;
using std::norm;



#define OMPI_SKIP_MPICXX 1

#define UseMPI
//#define UseOpenMP




#ifdef UseMPI
#include "mpi.h"
#endif



#ifdef UseOpenMP
#include "omp.h"
#endif



//--// const library
#include "../const/const.h"


//--// numlib libraries

#include "../file_tools/file_tools.hpp"
#include "../complex_add/complex_add.h"
#include "../MPI_OpenMP_sequential_calls/MPI_OpenMP_sequential_calls.h"
#include "../enum_struct_definitions/enum_struct_definitions.h"
#include "../string_routines/string_routines.hpp"
#include "../basic_maths/basic_maths.h"
#include "../reference_frame_change_coefficients/reference_frame_change_coefficients.h"
#include "../MPI_helper/MPI_helper.hpp"
#include "../quick_sort/quick_sort.hpp"
#include "../random_tools/random_tools.hpp"
#include "../array_vector_class/array_vector_class.hpp"
#include "../sparse_matrices/sparse_matrices.hpp"
#include "../matrices/matrices.hpp"
#include "../block_sparse_matrices/block_sparse_matrices.hpp"
#include "../block_matrices/block_matrices.hpp"
#include "../MPI_2D_partitioning/MPI_2D_partitioning.h"
#include "../Wigner_signs/Wigner_signs.h"
#include "../angular_matrix_elements/angular_matrix_elements.h"
#include "../polynomial_evaluation/polynomial_evaluation.hpp"
#include "../splines/splines.hpp"
#include "../Gamma/Gamma.h"
#include "../Coulomb_constants/Coulomb_constants.h"
#include "../HO_wave_functions/HO_wave_functions.h"
#include "../potentials/potentials.h"
#include "../ODE/ODE.h"
#include "../Coulomb_wave_functions/Coulomb_wave_functions.h"
#include "../Coulomb_wave_functions_add/Coulomb_wave_functions_add.h"
#include "../observables_basic_functions/observables_basic_functions.h"
#include "../Gauss_Chebyshev/Gauss_Chebyshev.h"
#include "../Gauss_Legendre/Gauss_Legendre.hpp"
#include "../Gauss_Laguerre/Gauss_Laguerre.h"
#include "../Gauss_Hermite/Gauss_Hermite.h"
#include "../Gauss_Jacobi/Gauss_Jacobi.h"
#include "../permutations/permutations.h"
#include "../rational_expansion_fit/rational_expansion_fit.hpp"
#include "../THO_wave_functions/THO_wave_functions.h"
#include "../hyp_2F1/hyp_2F1.h"
#include "../Moshinsky/Moshinsky.h"
#include "../correlated_state_routines/correlated_state_routines.h"
#include "../total_diagonalization/total_diagonalization.hpp"
#include "../matrices_add/matrices_add.hpp"
#include "../spherical_state/spherical_state.h"
#include "../Jost_WS_potential_fit/Jost_WS_potential_fit.h"
#include "../spherical_harmonics/spherical_harmonics.h"
#include "../Airy/Airy.h"
#include "../complex_splines/complex_splines.h"
#include "../EM_beta_transitions_radial_operators/EM_beta_transitions_radial_operators.h"

#include "../Lanczos/Lanczos.hpp"
#include "../Davidson/Davidson.hpp"


#include "../spherical_state_partial_derivatives/spherical_state_partial_derivatives.h"

#include "../vector_add/vector_add.hpp"

#include "../Skyrme_class/Skyrme_class.h"

#include "../Takagi/Takagi.hpp"

#include "../Gauss_non_classical/Gauss_non_classical.hpp"

#include "../error/error.h"

#include "../multidimensional_optimization/multidimensional_optimization.h"

#include "../linear_programming/linear_programming.h"

#include "../optimization/Optimizer.h"

#include "../pade_approximant/pade_approximant.hpp"

#endif

