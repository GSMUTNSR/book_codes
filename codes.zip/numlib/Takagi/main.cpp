#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#endif

    OpenMP_initialization ();

    cout.precision (15);

    const unsigned N = 25;

    // One has: A.X = E.X* , with A = H - i.P and X = U + i.V 
    // Hence :
    // H.U + P.V = E.U
    // P.U - H.V = -E.V
    // A.X = E.X* is equivalent to HFB equations
    // The E's are the SVD's of A.

    class matrix<double> H(N);

    class matrix<double> P(N);

    class matrix<double> U(N);
    class matrix<double> V(N);
    
    class array<double> s(N);

    H.symmetric_random_matrix ();
    
    P.symmetric_random_matrix ();

    Takagi::factorization<double , complex<double> > (true , H , P , s , U , V);

    for (unsigned int i = 0 ; i < N ; i++)
      {
	const double si = s(i);

	const class vector_class<double> &Ui = U.row_vector (i);		
	const class vector_class<double> &Vi = V.row_vector (i);		

	const class vector_class<double> Re_Res = H*Ui - P*Vi - si*Ui;
	const class vector_class<double> Im_Res = P*Ui + H*Vi + si*Vi;

	const double prec_vi = max (Re_Res.infinite_norm () , Im_Res.infinite_norm ());

	cout << "Takagi vector i : " << i << "   s : " << si << "   precision : " << prec_vi << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

