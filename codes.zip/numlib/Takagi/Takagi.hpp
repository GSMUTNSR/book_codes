#ifndef TAKAGI_HPP
#define TAKAGI_HPP

namespace Takagi
{
  template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
  void bidiagonalization (
			  const bool singular_vectors_calculated , 
			  class matrix<SCALAR_TYPE> &H , 
			  class matrix<SCALAR_TYPE> &H_tilde , 
			  class array<SCALAR_TYPE> &Re_s , 
			  class array<SCALAR_TYPE> &Re_e , 
			  class matrix<SCALAR_TYPE> &U , 
			  class matrix<SCALAR_TYPE> &V);

  template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
  void factorization_bidiagonalized (
				     const bool singular_vectors_calculated , 
				     const class matrix<SCALAR_TYPE> &H , 
				     const class matrix<SCALAR_TYPE> &H_tilde , 
				     class array<SCALAR_TYPE> &s , 
				     class array<SCALAR_TYPE> &e , 
				     class matrix<SCALAR_TYPE> &U , 
				     class matrix<SCALAR_TYPE> &V);

  template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
  void factorization (
		      const bool singular_vectors_calculated , 
		      const class matrix<SCALAR_TYPE> &H , 
		      const class matrix<SCALAR_TYPE> &H_tilde , 
		      class array<SCALAR_TYPE> &s , 
		      class matrix<SCALAR_TYPE> &U , 
		      class matrix<SCALAR_TYPE> &V);
}


template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
void Takagi::bidiagonalization (
				const bool singular_vectors_calculated , 
				class matrix<SCALAR_TYPE> &H , 
				class matrix<SCALAR_TYPE> &H_tilde , 
				class array<SCALAR_TYPE> &Re_s , 
				class array<SCALAR_TYPE> &Re_e , 
				class matrix<SCALAR_TYPE> &U , 
				class matrix<SCALAR_TYPE> &V)
{
  const unsigned int n = H.get_dimension () , nm1 = n-1 , nm2 = n-2;
  class array<SCALAR_TYPE> Re_work(n) , Im_work(n) , Im_s(n) , Im_e(n);

  for (unsigned int l = 0; l < nm1; l++ )
    {
      const unsigned int lp1 = l + 1 , nml = n-l , nm1_m_l = nm1-l;

      SCALAR_TYPE sl_norm2 = 0.0;
      SCALAR_TYPE &Re_sl = Re_s(l) , &Im_sl = Im_s(l) , &Hll = H(l , l) , &H_tilde_ll = H_tilde(l , l);
      for (unsigned int ii = 0 ; ii < nml ; ii++)
	{
	  const SCALAR_TYPE Hll_ii = H(l , l+ii) ,  H_tilde_ll_ii = H_tilde(l , l+ii);
	  sl_norm2 += Hll_ii*Hll_ii + H_tilde_ll_ii*H_tilde_ll_ii;
	}

      Re_sl = sqrt (sl_norm2) ,  Im_sl = 0.0;

      if (Re_sl != 0.0)
	{
	  if ((Hll != 0.0) || (H_tilde_ll != 0.0)) 
	    {
	      const SCALAR_TYPE factor = sqrt (Re_sl*Re_sl + Im_sl*Im_sl)/sqrt (Hll*Hll + H_tilde_ll*H_tilde_ll);
	      Re_sl = factor*Hll ,  Im_sl = factor*H_tilde_ll;
	    }

	  const COMPLEX_TYPE sl(Re_sl , Im_sl) , t = 1.0/sl;
	  const SCALAR_TYPE Re_t = real (t) , Im_t = imag (t);
	  for (unsigned int ii = 0 ; ii < nml ; ii++) 
	    {
	      SCALAR_TYPE &Hll_ii = H(l , l+ii) , &H_tilde_ll_ii = H_tilde(l , l+ii);
	      const SCALAR_TYPE Hll_ii_new = Hll_ii*Re_t - H_tilde_ll_ii*Im_t; 
	      const SCALAR_TYPE H_tilde_ll_ii_new = H_tilde_ll_ii*Re_t + Hll_ii*Im_t; 
	      Hll_ii = Hll_ii_new ,  H_tilde_ll_ii = H_tilde_ll_ii_new;
	    }

	  Hll += 1.0;
	}
      Re_sl = -Re_sl ,  Im_sl = -Im_sl;

      for (unsigned int j = lp1; j < n; j++ )
	{
	  if ((Re_sl != 0.0) || (Im_sl != 0.0)) 
	    { 
	      SCALAR_TYPE Re_t = 0.0 , Im_t = 0.0;
	      for (unsigned int ii = 0 ; ii < nml ; ii++) 
		{
		  const SCALAR_TYPE Hll_ii = H(l , l+ii) , H_tilde_ll_ii = H_tilde(l , l+ii);
		  const SCALAR_TYPE Hjl_ii = H(j , l+ii) , H_tilde_jl_ii = H_tilde(j , l+ii);
		  Re_t -= Hll_ii*Hjl_ii + H_tilde_ll_ii*H_tilde_jl_ii ,  Im_t -= H_tilde_jl_ii*Hll_ii - Hjl_ii*H_tilde_ll_ii;
		}

	      const COMPLEX_TYPE xll(Hll , H_tilde_ll);
	      COMPLEX_TYPE t(Re_t , Im_t);
	      t /= xll , Re_t = real (t) , Im_t = imag (t);

	      for (unsigned int ii = 0 ; ii < nml ; ii++)
		{
		  const SCALAR_TYPE Hll_ii = H(l , l+ii) , H_tilde_ll_ii = H_tilde(l , l+ii);
		  H(j , l+ii) += Hll_ii*Re_t - H_tilde_ll_ii*Im_t ,  H_tilde(j , l+ii) += Im_t*Hll_ii + Re_t*H_tilde_ll_ii; 
		}
	    }

	  Re_e(j) = H(j , l) ,  Im_e(j) = -H_tilde(j , l);
	}

      SCALAR_TYPE el_norm2 = 0.0;
      SCALAR_TYPE &Re_el = Re_e(l) , &Im_el = Im_e(l) , &Re_e_lp1 = Re_e(lp1) , &Im_e_lp1 = Im_e(lp1);
      for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
	{
	  const SCALAR_TYPE Re_e_lp1_ii = Re_e(lp1+ii) ,  Im_e_lp1_ii = Im_e(lp1+ii);
	  el_norm2 += Re_e_lp1_ii*Re_e_lp1_ii + Im_e_lp1_ii*Im_e_lp1_ii;
	}

      Re_el = sqrt (el_norm2) ,  Im_el = 0.0;

      if (Re_el != 0.0)
	{
	  if ((Re_e_lp1 != 0.0) || (Im_e_lp1 != 0.0))
	    {
	      const SCALAR_TYPE factor = sqrt (Re_el*Re_el + Im_el*Im_el)/sqrt (Re_e_lp1*Re_e_lp1 + Im_e_lp1*Im_e_lp1);
	      Re_el = factor*Re_e_lp1 ,  Im_el = factor*Im_e_lp1;
	    }

	  const COMPLEX_TYPE el(Re_el , Im_el) , t = 1.0/el;
	  const SCALAR_TYPE Re_t = real (t) , Im_t = imag (t);
	  for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
	    {
	      SCALAR_TYPE &Re_e_lp1_ii = Re_e(lp1+ii) , &Im_e_lp1_ii = Im_e(lp1+ii);
	      const SCALAR_TYPE Re_e_lp1_ii_new = Re_e_lp1_ii*Re_t - Im_e_lp1_ii*Im_t; 
	      const SCALAR_TYPE Im_e_lp1_ii_new = Im_e_lp1_ii*Re_t + Re_e_lp1_ii*Im_t; 
	      Re_e_lp1_ii = Re_e_lp1_ii_new ,  Im_e_lp1_ii = Im_e_lp1_ii_new;
	    }

	  Re_e_lp1 += 1.0;
	}

      Re_el = -Re_el;

      if ((Re_el != 0.0) || (Im_el != 0.0))
	{
	  for (unsigned int j = lp1; j < n; j++) Re_work(j) = Im_work(j) = 0.0;

	  const COMPLEX_TYPE e_lp1(Re_e(lp1) , Im_e(lp1));

	  for (unsigned int j = lp1; j < n; j++) 
	    {
	      const SCALAR_TYPE Re_ej = Re_e(j) , Im_ej = Im_e(j);

	      for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
		{
		  const SCALAR_TYPE Hj_lp1_ii = H(j , lp1+ii) , H_tilde_j_lp1_ii = H_tilde(j , lp1+ii);
		  Re_work(lp1+ii) += Hj_lp1_ii*Re_ej - H_tilde_j_lp1_ii*Im_ej ,  Im_work(lp1+ii) += Im_ej*Hj_lp1_ii + Re_ej*H_tilde_j_lp1_ii; 
		}
	    }

	  for (unsigned int j = lp1; j < n; j++) 
	    {
	      const COMPLEX_TYPE ej(Re_e(j) , Im_e(j)) , ratio = ej/e_lp1;
	      const SCALAR_TYPE Re_t = -real (ratio) , Im_t = imag (ratio);

	      for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
		{
		  const SCALAR_TYPE Re_work_lp1_ii = Re_work(lp1+ii) , Im_work_lp1_ii = Im_work(lp1+ii);
		  H(j , lp1+ii) += Re_work_lp1_ii*Re_t - Im_work_lp1_ii*Im_t ,  H_tilde(j , lp1+ii) += Im_t*Re_work_lp1_ii + Re_t*Im_work_lp1_ii; 
		}
	    } 
	}

      if (singular_vectors_calculated)
	{
	  for (unsigned int i = lp1; i < n; i++) U(l , i) = Re_e(i) , V(l , i) = Im_e(i);
	}
    }

  Re_s(nm1) = H(nm1 , nm1) ,  Re_e(nm2) = H(nm1 , nm2) ,  Re_e(nm1) = 0.0;
  Im_s(nm1) = H_tilde(nm1 , nm1) ,  Im_e(nm2) = H_tilde(nm1 , nm2) ,  Im_e(nm1) = 0.0;

  if (singular_vectors_calculated)
    for (unsigned int ll = 0; ll < n; ll++ )
      {
	const unsigned int l = nm1 - ll ,  lp1 = l+1 ,  nm1_m_l = nm1 - l;

	if ((l < nm2) && ((Re_e(l) != 0.0) || (Im_e(l) != 0.0)))
	  for (unsigned int j = lp1; j < n; j++ )
	    {
	      SCALAR_TYPE Re_t = 0.0 , Im_t = 0.0;

	      for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
		{
		  const SCALAR_TYPE Ul_lp1_ii = U(l , lp1+ii) , Vl_lp1_ii = V(l , lp1+ii);
		  const SCALAR_TYPE Uj_lp1_ii = U(j , lp1+ii) , Vj_lp1_ii = V(j , lp1+ii);
		  Re_t -= Ul_lp1_ii*Uj_lp1_ii + Vl_lp1_ii*Vj_lp1_ii ,  Im_t -= Vj_lp1_ii*Ul_lp1_ii - Uj_lp1_ii*Vl_lp1_ii;
		}

	      const COMPLEX_TYPE vl_lp1(U(l , lp1) , V(l , lp1));
	      COMPLEX_TYPE t(Re_t , Im_t);
	      t /= vl_lp1 , Re_t = real (t) , Im_t = imag (t);

	      for (unsigned int ii = 0 ; ii < nm1_m_l ; ii++)
		{
		  const SCALAR_TYPE Ul_lp1_ii = U(l , lp1+ii) , Vl_lp1_ii = V(l , lp1+ii);
		  U(j , lp1+ii) += Ul_lp1_ii*Re_t - Vl_lp1_ii*Im_t ,  V(j , lp1+ii) += Im_t*Ul_lp1_ii + Re_t*Vl_lp1_ii;
		}
	    }

	for (unsigned int i = 0; i < n ; i++) U(l , i) = V(l , i) = 0.0;
	U(l , l) = 1.0;
      }

  for (unsigned int i = 0; i < n; i++ )
    {
      SCALAR_TYPE &Re_si = Re_s(i) , &Re_ei = Re_e(i);
      SCALAR_TYPE &Im_si = Im_s(i) , &Im_ei = Im_e(i);

      if ((Re_si != 0.0) || (Im_si != 0.0))
	{      
	  const SCALAR_TYPE t = sqrt (Re_si*Re_si + Im_si*Im_si) , Re_r = Re_si/t , Im_r = Im_si/t;
	  const COMPLEX_TYPE r(Re_r , Im_r);

	  Re_si = t ,  Im_si = 0.0;
	  if (i < nm1) 
	    {
	      COMPLEX_TYPE ei(Re_ei , Im_ei);
	      ei /= r ,  Re_ei = real (ei) ,  Im_ei = imag (ei);
	    }
	}

      if (i == nm1) break;

      if ((Re_ei != 0.0) || (Im_ei != 0.0))
	{
	  const SCALAR_TYPE t = sqrt (Re_ei*Re_ei + Im_ei*Im_ei);

	  const COMPLEX_TYPE ei(Re_ei , Im_ei) , r = t/ei;
	  const SCALAR_TYPE Re_r = real (r) ,  Im_r = imag (r);
	  Re_ei = t ,  Im_ei = 0.0;

	  const unsigned int ip1 = i+1;
	  SCALAR_TYPE &Re_s_ip1 = Re_s(ip1) , &Im_s_ip1 = Im_s(ip1);
	  const SCALAR_TYPE Re_s_ip1_new = Re_s_ip1*Re_r - Im_s_ip1*Im_r;
	  const SCALAR_TYPE Im_s_ip1_new = Re_s_ip1*Im_r + Im_s_ip1*Re_r;
	  Re_s_ip1 = Re_s_ip1_new ,  Im_s_ip1 = Im_s_ip1_new;

	  if (singular_vectors_calculated) 
	    {
	      for (unsigned int ii = 0 ; ii < n ; ii++) 
		{
		  SCALAR_TYPE &U_ip1_ii = U(i+1 , ii) , &V_ip1_ii = V(i+1 , ii);
		  const SCALAR_TYPE U_ip1_ii_new = U_ip1_ii*Re_r - V_ip1_ii*Im_r;
		  const SCALAR_TYPE V_ip1_ii_new = V_ip1_ii*Re_r + U_ip1_ii*Im_r;
		  U_ip1_ii = U_ip1_ii_new ,  V_ip1_ii = V_ip1_ii_new;
		}
	    }
	}
    }
}






template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
void Takagi::factorization_bidiagonalized (
					   const bool singular_vectors_calculated , 
					   const class matrix<SCALAR_TYPE> &H , 
					   const class matrix<SCALAR_TYPE> &H_tilde , 
					   class array<SCALAR_TYPE> &s , 
					   class array<SCALAR_TYPE> &e , 
					   class matrix<SCALAR_TYPE> &U , 
					   class matrix<SCALAR_TYPE> &V)
{
  const unsigned int n = U.get_dimension () , max_iter = 30;

  unsigned int m = n , mm = n , iter = 0 , l = 0;

  while (true)
    {
      if (m == 0) break;
      if (iter >= max_iter) error_message_print_abort ("No convergence in Takagi diagonalization.");

      const unsigned int mm1_deb = m-1;

      for (unsigned int ll = 0; ll <= mm1_deb ; ll++ )
	{
	  l = mm1_deb - ll;
	  if (l == 0) break;

	  const unsigned int lm1 = l-1;
	  const double test = inf_norm (s(lm1)) + inf_norm (s(l)) , ztest = test + inf_norm (e(lm1));

	  if (ztest == test) 
	    {
	      e(lm1) = 0.0; 
	      break;
	    }
	}

      unsigned int ls = 0 , the_case = 0;

      if (l == mm1_deb)
	the_case = 4;
      else 
	{
	  for (unsigned int lls = l; lls <= m; lls++ )
	    {
	      ls = m - lls + l;
	      if (ls == l) break;

	      const unsigned int ls_m1 = ls-1;      
	      double test = 0.0;
	      if (ls != m) test += inf_norm (e(ls_m1));
	      if (ls_m1 != l) test += inf_norm (e(ls-2));

	      const double ztest = test + inf_norm (s(ls_m1));
	      if (ztest == test) 
		{
		  s(ls_m1) = 0.0; 
		  break;
		}
	    }

	  if (ls == l)
	    the_case = 3;
	  else if (ls == m)
	    the_case = 1;
	  else
	    the_case = 2 ,  l = ls;
	} 

      l++;

      switch (the_case)
	{
	case 1:
	  {
	    const unsigned int mm1 = m-1 , mm2 = m-2;

	    SCALAR_TYPE &e_mm2 = e(mm2) , f = e_mm2;
	    e_mm2 = 0.0;

	    for (unsigned int kk = 1; kk < mm2; kk++ )
	      {
		const unsigned int k = mm2 - kk + l;

		SCALAR_TYPE &sk = s(k) , t1 = sk , cs = 1.0 , sn = 0.0;
		const SCALAR_TYPE big = (abs (f) < abs (t1)) ? (t1) : (f);

		if (big != 0.0)
		  {
		    const SCALAR_TYPE r = ((real_dc (big) > 0.0) || ((real_dc (big) == 0.0) && (imag_dc (big) > 0.0))) ? (hypot (t1 , f)) : (-hypot (t1 , f));          
		    cs = t1/r ,  sn = f/r ,  t1 = r;
		  } 

		sk = t1;

		if (k+1 != l) 
		  {
		    SCALAR_TYPE &e_km1 = e(k-1);
		    f = -sn*e_km1 ,  e_km1 *= cs;
		  }

		if (singular_vectors_calculated) 
		  {
		    for (unsigned int ii = 0 ; ii < n ; ii++)
		      {
			SCALAR_TYPE &Uk_ii = U(k , ii) , &Vk_ii = V(k , ii);
			SCALAR_TYPE &U_mm1_ii = U(mm1 , ii) , &V_mm1_ii = V(mm1 , ii);

			const SCALAR_TYPE Uk_ii_new = cs*Uk_ii + sn*U_mm1_ii , U_mm1_ii_new = cs*U_mm1_ii - sn*Uk_ii;
			const SCALAR_TYPE Vk_ii_new = cs*Vk_ii + sn*V_mm1_ii , V_mm1_ii_new = cs*V_mm1_ii - sn*Vk_ii;

			Uk_ii = Uk_ii_new ,  Vk_ii = Vk_ii_new ,  U_mm1_ii = U_mm1_ii_new ,  V_mm1_ii = V_mm1_ii_new;
		      }
		  }
	      }
	  } break;

	case 2:
	  {
	    SCALAR_TYPE &e_lm2 = e(l-2) , f = e_lm2;
	    e_lm2 = 0.0;

	    for (unsigned int k = l-1; k < m; k++)
	      {
		SCALAR_TYPE &sk = s(k) , &ek = e(k) , t1 = sk , cs = 1.0 , sn = 0.0;

		const SCALAR_TYPE big = (abs (f) < abs (t1)) ? (t1) : (f);

		if (big != 0.0)
		  {
		    const SCALAR_TYPE r = ((real_dc (big) > 0.0) || ((real_dc (big) == 0.0) && (imag_dc (big) > 0.0))) ? (hypot (t1 , f)) : (-hypot (t1 , f));
		    cs = t1/r ,  sn = f/r ,  t1 = r;
		  } 

		sk = t1 ,  f = -sn*ek ,  ek *= cs;
	      }
	  } break;

	case 3:
	  {
	    const unsigned int mm1 = m-1 , mm2 = m-2 , lm1 = l-1;
	    const SCALAR_TYPE s_mm1 = s(mm1) , s_mm2 = s(mm2) , e_mm2 = e(mm2) , s_lm1 = s(lm1) , e_lm1 = e(lm1);
	    const double s_mm1_inf = inf_norm (s_mm1) , s_mm2_inf = inf_norm (s_mm2) , e_mm2_inf = inf_norm (e_mm2) , s_lm1_inf = inf_norm (s_lm1);
	    const double e_lm1_inf = inf_norm (e_lm1) , sc = max (s_mm1_inf , max (s_mm2_inf , max (e_mm2_inf , max (s_lm1_inf , e_lm1_inf))));

	    const SCALAR_TYPE sm_sc = s_mm1/sc , smm1_sc = s_mm2/sc , emm1_sc = e_mm2/sc , sl_sc = s_lm1/sc , el_sc = e_lm1/sc;
	    const SCALAR_TYPE b = 0.5*((smm1_sc + sm_sc)*(smm1_sc - sm_sc) + emm1_sc*emm1_sc) , c = (sm_sc*emm1_sc)*(sm_sc*emm1_sc);

	    const SCALAR_TYPE sqrt_term = ((real_dc (b) > 0.0) || ((real_dc (b) == 0.0) && (imag_dc (b) > 0.0))) ? (sqrt (b*b + c)) : (-sqrt (b*b + c));
	    const SCALAR_TYPE shift = ((b != 0.0) || (c != 0.0)) ? (c/(b + sqrt_term)) : (0.0);

	    SCALAR_TYPE f = (sl_sc + sm_sc)*(sl_sc - sm_sc) + shift , g = sl_sc*el_sc;

	    for (unsigned int k = lm1; k < mm1; k++ )
	      {
		const unsigned int kp1 = k+1;
		SCALAR_TYPE cs = 1.0 , sn = 0.0;
		const SCALAR_TYPE big_one = (abs (g) < abs (f)) ? (f) : (g);

		if (big_one != 0.0)
		  {
		    const SCALAR_TYPE r = ((real_dc (big_one) > 0.0) || ((real_dc (big_one) == 0.0) && (imag_dc (big_one) > 0.0))) ? (hypot (f , g)) : (-hypot (f , g));
		    cs = f/r ,  sn = g/r ,  f = r;
		  } 

		if (kp1 != l) e(k-1) = f;

		SCALAR_TYPE &sk = s(k) , &s_kp1 = s(kp1) , &ek = e(k) , &e_kp1 = e(kp1);
		f = cs*sk + sn*ek ,  g = sn*s_kp1 ,  ek = cs*ek - sn*sk ,  s_kp1 *= cs;

		if (singular_vectors_calculated)
		  {
		    for (unsigned int ii = 0 ; ii < n ; ii++)
		      {
			SCALAR_TYPE &Uk_ii = U(k , ii) , &U_kp1_ii = U(kp1 , ii);
			SCALAR_TYPE &Vk_ii = V(k , ii) , &V_kp1_ii = V(kp1 , ii);

			const SCALAR_TYPE Uk_ii_new = cs*Uk_ii + sn*U_kp1_ii , U_kp1_ii_new = cs*U_kp1_ii - sn*Uk_ii;
			const SCALAR_TYPE Vk_ii_new = cs*Vk_ii + sn*V_kp1_ii , V_kp1_ii_new = cs*V_kp1_ii - sn*Vk_ii;

			Uk_ii = Uk_ii_new ,  Vk_ii = Vk_ii_new ,  U_kp1_ii = U_kp1_ii_new ,  V_kp1_ii = V_kp1_ii_new;
		      }
		  }
		const SCALAR_TYPE big_two = (abs (g) < abs (f)) ? (f) : (g);

		if (big_two != 0.0)
		  {
		    const SCALAR_TYPE r = ((real_dc (big_two) > 0.0) || ((real_dc (big_two) == 0.0) && (imag_dc (big_two) > 0.0))) ? (hypot (f , g)) : (-hypot (f , g));
		    cs = f/r ,  sn = g/r ,  f = r;
		  } 

		sk = f ,  f = cs*ek + sn*s_kp1 ,  s_kp1 = -sn*ek + cs*s_kp1 ,  g = sn*e_kp1 ,  e_kp1 *= cs;
	      }
	    e(m-2) = f ,  iter++;
	  } break;

	case 4:
	  {   
	    const unsigned int lm1_deb = l-1;
	    SCALAR_TYPE &s_lm1_deb = s(lm1_deb);

	    if (real_dc (s_lm1_deb) < 0.0)
	      {
		s_lm1_deb = -s_lm1_deb;

		if (singular_vectors_calculated)
		  {
		    for (unsigned int ii = 0 ; ii < n ; ii++) U(lm1_deb , ii) = -U(lm1_deb , ii) ,  V(lm1_deb , ii) = -V(lm1_deb , ii);
		  }
	      }

	    while (l != mm)
	      {
		const unsigned int lm1 = l-1;
		SCALAR_TYPE &s_lm1 = s(lm1) , &sl = s(l);

		if (real_dc (sl) <= real_dc (s_lm1)) break;

		const SCALAR_TYPE temp = s_lm1;
		s_lm1 = sl ,  sl = temp;

		if (singular_vectors_calculated && (l < n))
		  {
		    for (unsigned int ii = 0 ; ii < n ; ii++) 
		      {
			SCALAR_TYPE &U_lm1_ii = U(lm1 , ii) , &Ul_ii = U(l , ii);
			const SCALAR_TYPE Re_temp = U_lm1_ii;
			U_lm1_ii = Ul_ii ,  Ul_ii = Re_temp;

			SCALAR_TYPE &V_lm1_ii = V(lm1 , ii) , &Vl_ii = V(l , ii);
			const SCALAR_TYPE Im_temp = V_lm1_ii;
			V_lm1_ii = Vl_ii ,  Vl_ii = Im_temp;
		      }
		  }

		l++;
	      }

	    iter = 0 ,  m--;
	  } break;
	}
    }

  if (singular_vectors_calculated)
    { 
      /*for (unsigned int i = 0 ; i < n ; i++)
	{
	class vector_class<SCALAR_TYPE> &Ui = U.row_vector (i) , &Vi = V.row_vector (i);

	const SCALAR_TYPE E = s(i);
	const class vector_class<SCALAR_TYPE> H_Vi = H*Ui - H_tilde*Vi , H_tilde_Vi = H_tilde*Ui + H*Vi;

	const SCALAR_TYPE Re_overlap = H_Vi*Ui - H_tilde_Vi*Vi , Im_overlap = H_tilde_Vi*Ui + H_Vi*Vi;

	const COMPLEX_TYPE overlap(Re_overlap , Im_overlap) , phase = sqrt (E/overlap);

	const SCALAR_TYPE Re_phase = real (phase) ,  Im_phase = imag (phase);

	const class vector_class<SCALAR_TYPE> Ui_new = Ui*Re_phase - Vi*Im_phase ,  Vi_new = Vi*Re_phase + Ui*Im_phase;
	Ui = Ui_new ,  Vi = Vi_new;
	}
	return;*/

      for (unsigned int i = 0 ; i < n ; i++)
	{
	  class vector_class<SCALAR_TYPE> &Ui = U.row_vector (i) , &Vi = V.row_vector (i);

	  int ii_max = 0;
	  double test_comp = max (inf_norm (Ui(0)) , inf_norm (Vi(0)));
	  for (unsigned int ii = 1 ; ii < n ; ii++)
	    {
	      const double test_comp_try = max (inf_norm (Ui(ii)) , inf_norm (Vi(ii)));
	      if (test_comp_try > test_comp) test_comp = test_comp_try ,  ii_max = ii;
	    }

	  const class vector_class<SCALAR_TYPE> &Ux = H.row_vector (ii_max) , &Vx = H_tilde.row_vector (ii_max);

	  const SCALAR_TYPE E = s(i) , Re_E_conj_Vi_Vx = E*Ui(ii_max) , Im_E_conj_Vi_Vx = -E*Vi(ii_max);
	  const SCALAR_TYPE Re_Vx_Vi = Ux*Ui - Vx*Vi , Im_Vx_Vi = Vx*Ui + Ux*Vi;

	  const COMPLEX_TYPE E_conj_Vi_Vx(Re_E_conj_Vi_Vx , Im_E_conj_Vi_Vx) , Vx_Vi(Re_Vx_Vi , Im_Vx_Vi) , phase = sqrt (E_conj_Vi_Vx/Vx_Vi);
	  const SCALAR_TYPE Re_phase = real (phase) , Im_phase = imag (phase);

	  const class vector_class<SCALAR_TYPE> Ui_new = Ui*Re_phase - Vi*Im_phase ,  Vi_new = Vi*Re_phase + Ui*Im_phase;
	  Ui = Ui_new ,  Vi = Vi_new;
	}
    }
}


template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
void Takagi::factorization (
			    const bool singular_vectors_calculated , 
			    const class matrix<SCALAR_TYPE> &H , 
			    const class matrix<SCALAR_TYPE> &H_tilde , 
			    class array<SCALAR_TYPE> &s , 
			    class matrix<SCALAR_TYPE> &U , 
			    class matrix<SCALAR_TYPE> &V)
{
  const unsigned int N = H.get_dimension ();

  class array<SCALAR_TYPE> e(N);
  class matrix<SCALAR_TYPE> H_copy = H , H_tilde_copy = H_tilde;

  bidiagonalization<SCALAR_TYPE , COMPLEX_TYPE> (singular_vectors_calculated , H_copy , H_tilde_copy , s , e , U , V);

  factorization_bidiagonalized<SCALAR_TYPE , COMPLEX_TYPE> (singular_vectors_calculated , H , H_tilde , s , e , U , V);
}

#endif
