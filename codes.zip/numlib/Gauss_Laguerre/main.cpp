#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;








#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);

    const unsigned int N = 100;

    seed ();
    
    const double alpha = 10*random_number<double> ();
    
    const complex<double> beta = random_number<complex<double>  >();
    
    const complex<double> exact_integral = pow (1.0 + beta , -alpha - 1.0)/Gamma_inv (1.0 + alpha);
    
    cout << "exp (-beta.x) w(x), with w(x) = x^alpha exp(-x), is integrated numerically and exactly on [0:+oo[" << endl << endl;

    cout << "alpha = " << alpha << endl;
    
    cout << "beta = " << beta << endl << endl;
    
    cout << "Gauss-Laguerre number of points   Gauss-Laguerre integral   exact integral    test"  << endl << endl;

    for (unsigned int n = 0 ; n <= N ; n ++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);

	Gauss_Laguerre::abscissas_weights_tables_calc (alpha , x_tab , w_tab);
	
	complex<double> integral = 0.0;

	for (unsigned int i = 0 ; i < n ; i++) integral += exp (-beta*x_tab(i))*w_tab(i);
      
	cout << n << " " << integral << " " << exact_integral << " " << inf_norm (integral/exact_integral - 1.0) << endl;
      }
    
    cout << endl << "P(n,alpha,x) and P'(n,alpha,x) test from a standard relation" << endl << endl;

    cout.precision (8);
    
    seed ();
    
    for (int n = 1 ; n <= 10 ; n++)
      {
	const double alpha = random_number<double> ();
      
	const double x = random_number<double> ();

	const double P_nm1_x = Gauss_Laguerre::poly (n-1 , alpha , x);
      
	const double Pn_x = Gauss_Laguerre::poly (n , alpha , x);
	
	const double Pn_der_x = Gauss_Laguerre::poly_der (n , alpha , x);

	double P_nm1_x_test , Pn_x_test , Pn_der_x_test;

	Gauss_Laguerre::P_lower_P_dP (n , alpha , x , P_nm1_x_test , Pn_x_test , Pn_der_x_test);

	if (abs (P_nm1_x - P_nm1_x_test) + abs (Pn_x - Pn_x_test) + abs (Pn_der_x - Pn_der_x_test) > 1E-12) error_message_print_abort ("Problem with Gauss-Laguerre polynomials and/or derivatives");
	
	const double test = inf_norm ((n*Pn_x - (n + alpha)*P_nm1_x)/x/Pn_der_x - 1.0);
	
	cout << "n : " << n << "   alpha : " << alpha << "   x : " << x << "   P(n,x) : " << Pn_x << "   P'(n,x) : " << Pn_der_x << "   test : " << test << endl;
      }  
  
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

