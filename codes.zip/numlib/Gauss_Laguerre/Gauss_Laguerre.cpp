#include "../numlib_def/numlib_def.h"


// Calculation of the Laguerre polynomial L(n, alpha, x)
// ---------------------------------------------- - 
// The following recurrence relation is used : 
// (i+1).L(i+1, alpha, x) = (-x + alpha + 1 + 2i).L(i, alpha, x) - (i+a).L(i-1, alpha, x) for i > 0.
// L(0, alpha, x) = 1. This value is directly returned if the degree of the polynomial is 0.
// L(1, alpha, x) = alpha + 1 - x. This value is directly returned if the degree of the polynomial is 1.
//
// 
// Variables:
// ----------
// degree : degree of the Laguerre polynomial
// i, poly_im1, poly_i, poly_ip1 : Laguerre polynomials of degree i-1, i, and i+1, with n > 1.
// i goes from 1 to n - 1.
// alpha : parameter of the Laguerre polynomial
// minus_x_plus_alpha_plus_one : -x + alpha + 1
// x : variable of the Laguerre polynomial.

double Gauss_Laguerre::poly (
			     const int degree ,
			     const double alpha ,
			     const double x)
{  
  if (degree == 0) return 1.0;

  const double minus_x_plus_alpha_plus_one = -x + alpha + 1.0;

  double poly_im1 = 0.0;
  
  double poly_i = 1.0;

  double poly_ip1 = minus_x_plus_alpha_plus_one;

  for (int i = 1 ; i < degree ; i++)
    {
      poly_im1 = poly_i;

      poly_i = poly_ip1;
      
      poly_ip1 = ((minus_x_plus_alpha_plus_one + 2 * i) * poly_i - (i + alpha) * poly_im1)/(i + 1.0);
    }

  return poly_ip1;
}





// Calculation of the Laguerre polynomial derivative dL/dx(n, alpha, x)
// --------------------------------------------------------------
// The following recurrence relations are used : 
// (i+1).L'(i+1, alpha, x) = (-x + alpha + 1 + 2i).L'(i, alpha, x) - (i+a).L'(i-1, alpha, x) - L(i, alpha, x) for i > 0.
// (i+1).L(i+1, alpha, x) = (-x + alpha + 1 + 2i).L(i, alpha, x) - (i+a).L(i-1, alpha, x) for i > 0.
// L(0, alpha, x) = 1 
// L(1, alpha, x) = 1 + alpha - x
// L'(0, alpha, x) = 0. This value is directly returned if the degree of the polynomial is 0.
// L'(1, alpha, x) = - 1. This value is directly returned if the degree of the polynomial is 1.
// 
// I do not use the formula L'(i+1 , alpha , x) = ((i+1).L(i+1 , alpha , x) - (i + 1 + alpha).L(i , alpha , x))/x as it is unstable for x ~ 0.
//
// Variables:
// ----------
// degree : degree of the Laguerre polynomial, not of the derivative of the Laguerre polynomial.
// i, poly_im1, poly_i, poly_ip1, poly_der_im1, poly_der_i, poly_der_ip1 : Laguerre polynomials and derivatives of degree i-1, i, and i+1, with n > 1.
// i goes from 1 to n - 1.
// one_over_ip1 : 1/(i+1)
// minus_x_plus_alpha_plus_one : -x + alpha + 1
// minus_x_plus_alpha_plus_one_plus_2i : -x + alpha + 1 + 2i
// x : variable of the Laguerre polynomial derivative.
// alpha : parameter of the Laguerre polynomial

double Gauss_Laguerre::poly_der (
				 const int degree ,
				 const double alpha ,
				 const double x)
{
  if (degree == 0) return 0.0;

  const double minus_x_plus_alpha_plus_one = -x + alpha + 1.0;

  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = minus_x_plus_alpha_plus_one;
    
  double poly_der_im1 = 0.0;

  double poly_der_i = 0.0;

  double poly_der_ip1 = -1.0;

  for (int i = 1 ; i < degree ; i++)
    {
      const double one_over_ip1 = 1.0/(i + 1.0);

      const double i_plus_alpha = i + alpha;

      const double minus_x_plus_alpha_plus_one_plus_2i = minus_x_plus_alpha_plus_one + 2.0 * i;

      poly_im1 = poly_i;
	
      poly_der_im1 = poly_der_i;

      poly_i = poly_ip1;
	
      poly_der_i = poly_der_ip1;
      
      poly_ip1 = (minus_x_plus_alpha_plus_one_plus_2i * poly_i - i_plus_alpha * poly_im1) * one_over_ip1;
	
      poly_der_ip1 = (minus_x_plus_alpha_plus_one_plus_2i * poly_der_i - i_plus_alpha * poly_der_im1 - poly_i) * one_over_ip1;
    }

  return poly_der_ip1;
}







// Polynomial and derivative of the Laguerre polynomial of order degree and degree - 1
// -----------------------------------------------------------------------------------
//
// The following recurrence relations are used : 
// (i+1).L'(i+1, alpha, x) = (-x + alpha + 1 + 2i).L'(i, alpha, x) - (i+a).L'(i-1, alpha, x) - L(i, alpha, x) for i > 0.
// (i+1).L(i+1, alpha, x) = (-x + alpha + 1 + 2i).L(i, alpha, x) - (i+a).L(i-1, alpha, x) for i > 0.
// L(0, alpha, x) = 1, L'(0, alpha, x) = 0. These values are directly returned if the degree of the polynomial is 0.
// L(1, alpha, x) = 1 + alpha - x, L'(1, alpha, x) = - 1. These values are directly returned if the degree of the polynomial is 1.
// 
// I do not use the formula L'(i+1 , alpha , x) = ((i+1).L(i+1 , alpha , x) - (i + 1 + alpha).L(i , alpha , x))/x as it is unstable for x ~ 0.
//
// Variables:
// ----------
// degree : degree of the Laguerre polynomial, not of the derivative of the Laguerre.
// x : variable of the Laguerre polynomial derivative
// i, poly_im1, poly_i, poly_ip1 : Laguerre polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// i goes from 1 to n - 1.
// one_over_ip1 : 1/(i+1)
// minus_x_plus_alpha_plus_one : -x + alpha + 1
// minus_x_plus_alpha_plus_one_plus_2i : -x + alpha + 1 + 2i
// x : variable of the Laguerre polynomial derivative.
// alpha : parameter of the Laguerre polynomial
// P_lower: Laguerre polynomial of order degree - 1 to calculate
// P, dP: Laguerre polynomial and derivative of order degree to calculate

void Gauss_Laguerre::P_lower_P_dP (
				   const int degree ,
				   const double alpha ,
				   const double x ,
				   double &P_lower ,
				   double &P ,
				   double &dP)
{ 
  if (degree == 0) error_message_print_abort ("Gauss_Laguerre::P_lower_P_dP undefined for degree = 0");
  
  const double minus_x_plus_alpha_plus_one = -x + alpha + 1.0;
  
  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = minus_x_plus_alpha_plus_one;
    
  double poly_der_im1 = 0.0;

  double poly_der_i = 0.0;

  double poly_der_ip1 = -1.0;

  for (int i = 1 ; i < degree ; i++)
    {
      const double one_over_ip1 = 1.0/(i + 1.0);
	  
      const double i_plus_alpha = i + alpha;
	  
      const double minus_x_plus_alpha_plus_one_plus_2i = minus_x_plus_alpha_plus_one + 2.0 * i;

      poly_im1 = poly_i;
	
      poly_der_im1 = poly_der_i;

      poly_i = poly_ip1;
	
      poly_der_i = poly_der_ip1;
      
      poly_ip1 = (minus_x_plus_alpha_plus_one_plus_2i * poly_i - i_plus_alpha * poly_im1) * one_over_ip1;
	
      poly_der_ip1 = (minus_x_plus_alpha_plus_one_plus_2i * poly_der_i - i_plus_alpha * poly_der_im1 - poly_i) * one_over_ip1;
    }
      
  P_lower = poly_i;
      
  P = poly_ip1;

  dP = poly_der_ip1;
}





// Calculation of the abscissas and weights of the Gauss-Laguerre quadrature
// ----------------------------------------------------------------------------
// These are the abscissas and weights of the Gauss-Laguerre quadrature on [0:+oo[.
// I use the Golub-Welsch method as it is more stable than the Numerical Recipes method for large N, alpha.
// Moreover, the Golub-Welsch method is as good for small or moderate values of N, alpha and even comparable in speed.
// Also, only eigenvalues are needed, as there is a closed form formula for weights when the root is known.
// Refinement of roots with the Newton method is done to be sure to have maximal precision.
// Polynomials overflow typically where integrands are negligible. Weights are then put to zero therein.
// The routine has been tested successfully for N <= 1000 and alpha ~ 100.
//
// Variables
// -------- -
// alpha, alpha_plus_one: parameter of the Gauss-Laguerre quadrature weight function, alpha + 1
// N : number of points in the Gauss-Laguerre quadrature.
// x_table : table of Gauss-Laguerre abscissas.
// w_table : table of Gauss-Laguerre weights.
// count : The Newton method stops if count >= 20 as starting points are close to their exact value.
// P_lower: Laguerre polynomial of order N-1
// P, dP, ratio: Laguerre polynomial and derivative of order i, P/dP
// weight_factor: factor -Gamma (a+n)/Gamma (N) entering weights
// a_table, sqrt_b_table: arrays of a[i] and sqrt(b[i]) for the Golub-Welsch matrix
// xi, wi : i-th root of the Laguerre polynomial and its weight. xi is refined with the Newton method. A precision of 1e-16 is demanded.

void Gauss_Laguerre::abscissas_weights_tables_calc (
						    const double alpha ,
						    class array<double> &x_table , 
						    class array<double> &w_table)
{  
  const unsigned int N = x_table.dimension (0);

  if (N == 0) return;

  if (alpha <= -1.0) error_message_print_abort ("One has to have alpha > -1 in Gauss_Laguerre::abscissas_weights_tables_calc for integrals to converge");
  
  const double weight_factor = -exp (lgamma (alpha + N) - lgamma (N));
  
  const unsigned int Nm1 = N - 1;
  
  class array<double> a_table(N);

  const double alpha_plus_one = alpha + 1.0;

  for (unsigned int i = 0 ; i < N ; i++) a_table(i) = alpha_plus_one + 2*i;
  
  class array<double> sqrt_b_table(Nm1);

  for (unsigned int i = 0 ; i < Nm1 ; i++) sqrt_b_table(i) = sqrt ((i + 1)*(i + alpha_plus_one));

  total_diagonalization::symmetric::all_eigenvalues (sqrt_b_table , a_table , x_table);
      
  w_table = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      double &xi = x_table(i);
      
      unsigned int count = 0;
      
      double P_lower = 0.0;
      
      double P = 0.0;
 
      double dP = 0.0;

      double ratio = 1.0;
      
      while ((abs (ratio) > 1E-16) && (count++ < 20))
	{
	  P_lower_P_dP (N , alpha , xi , P_lower , P , dP);

	  ratio = P/dP;

	  if (finite (ratio))
	    xi -= ratio;
	  else
	    break;
	}

      const double wi = weight_factor/(dP*N*P_lower);
	    
      if (finite (wi)) w_table(i) = wi;
    }
}




