#ifndef GAUSS_LAGUERRE_H
#define GAUSS_LAGUERRE_H

namespace Gauss_Laguerre
{
  double poly (
	       const int degree ,
	       const double alpha ,
	       const double x);
  
  double poly_der (
		   const int degree ,
		   const double alpha ,
		   const double x);
  
  void P_lower_P_dP (
		     const int degree ,
		     const double alpha ,
		     const double x ,
		     double &P_lower ,
		     double &P ,
		     double &dP);
  
  void abscissas_weights_tables_calc (
				      const double alpha ,
				      class array<double> &x_table , 
				      class array<double> &w_table);
}

#endif

