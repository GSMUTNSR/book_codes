#include "../numlib_def/numlib_def.h"

using namespace Wigner_signs;






// Talmi - Moshinsky transformation bracket table
//-----------------------------------------------
// cf Nuclear Physics A 695 (2001) 191 - 202
//
// <(n , l)(N , L);lambda|(n1 , l1) , (n2 , l2);lambda> for all n , l , N , L.
// One has Moshinsky_table_values(l , i[L] = (L - L_min)/2 , i[n] = n + (l + L - lambda)/2) with :
// l : 0 -> (e1 + e2 + lambda)/2. One uses the fact that l[max] + L <= e1 + e2 and l[max] - L >= lambda.
// l[max] is larger than all possible l and L because they play symmetric roles.
// i[L] : 0 -> min [lambda , (e1 + e2 - lambda)/2]. Parity conservation , l + L <= e1 + e2 and l , L , lambda coupling is used. 
// L_min is |l - lambda| if l1 + l2 - l is even , |l - lambda| + 1 if it is odd.
// i[n] : 0 -> (e1 + e2 - lambda)/2. One uses n : 0 -> (e_max - l - L)/2 and L + l >= lambda.
//
// N is given by 2(n + N) + l + L = 2(n1 + n2) + l1 + l2. 
//
// If one wants <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda> for all n1 , l1 , l2 , l2
// one has to use the symmetry <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda> = <(n1 , l1) , (n2 , l2);lambda | (n , l) , (N , L);lambda>.
//
// d = m1/m2 : mass ratio of the particles
//
// All Wigner 9j for l1 , l2 , l , L are calculated and stored during the n loop calculation.
//
// For d = 1 (worst case) , the average precision is about 10^(-13), the worst precision is about 10^(-11) and dispersion about 10^(-12).

Moshinsky_table::Moshinsky_table ()
  : n1 (0) , 
    l1 (0) ,
    e1 (0) ,
    n2 (0) , 
    l2 (0) ,
    e2 (0),
    e_max (0) ,
    lambda (0) ,
    d (0.0) ,
    is_d_equal_to_one (false)
{}

Moshinsky_table::Moshinsky_table (
				  const int n1_c , 
				  const int l1_c , 
				  const int n2_c , 
				  const int l2_c , 
				  const int lambda_c ,
				  const double d_c) 
{
  allocate (n1_c , l1_c , n2_c , l2_c , lambda_c , d_c);
}




Moshinsky_table::Moshinsky_table (const class Moshinsky_table &X)
{ 
  Moshinsky_table_values.allocate_fill (X.Moshinsky_table_values);
}





void Moshinsky_table::allocate (
				const int n1_c ,
				const int l1_c ,
				const int n2_c ,
				const int l2_c ,
				const int lambda_c ,
				const double d_c)
{
  if (Moshinsky_table_values.is_it_filled ()) error_message_print_abort ("Moshinsky_table cannot be allocated twice in allocate");
  
  n1 = n1_c;
  l1 = l1_c;
  
  n2 = n2_c; 
  l2 = l2_c;
  
  lambda = lambda_c;
  
  d = d_c;
  
  if (n1 < 0) error_message_print_abort ("One must have n1 >= 0 in Moshinsky_table::allocate");
  if (l1 < 0) error_message_print_abort ("One must have l1 >= 0 in Moshinsky_table::allocate");

  if (n2 < 0) error_message_print_abort ("One must have n2 >= 0 in Moshinsky_table::allocate");
  if (l2 < 0) error_message_print_abort ("One must have l2 >= 0 in Moshinsky_table::allocate");
  
  if (lambda < 0) error_message_print_abort ("One must have lambda >= 0 in Moshinsky_table::allocate");
  
  if (d <= 0.0) error_message_print_abort ("One must have d >= 0 in Moshinsky_table::allocate");
  
  if (!is_it_triangle_integer (l1 , l2 , lambda)) error_message_print_abort ("l1 and l2 cannot couple to lambda in Moshinsky_table::allocate");

  e1 = 2*n1 + l1;
  e2 = 2*n2 + l2;
  
  e_max = e1 + e2;
  
  is_d_equal_to_one = (abs (d - 1.0) < 1E-13);
  
  const unsigned int l_number = (e_max + lambda)/2 + 1;

  const unsigned int L_number = min (lambda , (e_max - lambda)/2) + 1;

  const unsigned int n_number = (e_max - lambda)/2 + 1;

  Moshinsky_table_values.allocate (l_number , L_number , n_number);
}




void Moshinsky_table::allocate_fill (const class Moshinsky_table &X)
{
  if (Moshinsky_table_values.is_it_filled ()) error_message_print_abort ("Moshinsky_table cannot be allocated twice in Moshinsky_table::allocate_fill");
  
  n1 = X.n1; 
  l1 = X.l1;
  e1 = X.e1;
  
  n2 = X.n2; 
  l2 = X.l2;
  e2 = X.e2;

  e_max = X.e_max;
  
  lambda = X.lambda;

  d = X.d;

  is_d_equal_to_one = X.is_d_equal_to_one;
  
  Moshinsky_table_values.allocate_fill (X.Moshinsky_table_values);
}



void Moshinsky_table::deallocate ()
{
  Moshinsky_table_values.deallocate ();

  n1 = l1 = e1 = 0;
  n2 = l2 = e2 = 0;

  e_max = 0;

  lambda = 0;

  d = 0.0;

  is_d_equal_to_one = false;
}



bool Moshinsky_table::is_it_filled () const
{
  return Moshinsky_table_values.is_it_filled ();
}




// Calculation of  <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda> from the analytic formulas
//---------------------------------------------------------------------------------------------------

void Moshinsky_table::calc ()
{
  const int e2_plus_one = e2 + 1;

  const double minus_d = -d;

  const double sqrt_pow_one_plus_d_minus_e1_minus_e2 = sqrt (pow (1.0 + d , - e1 - e2));
  
  const int e_max_plus_one = e_max + 1;

  const int two_e_max = 2*e_max;

  const int two_e_max_plus_two = two_e_max + 2;

  const int e_max_over_two = e_max/2;

  const int e_max_over_two_plus_one = e_max_over_two + 1;
  
  const int e2_over_two = e2/2;

  const int e2_over_two_plus_one = e2_over_two + 1;

  const int L_index_max = min (lambda , (e_max - lambda)/2);
  
  const bool is_e_max_plus_lambda_even = ((e_max + lambda)%2 == 0);

  class array<double> binom(two_e_max_plus_two , two_e_max_plus_two);
  
  class array<double> trinom(two_e_max_plus_two , two_e_max_plus_two , two_e_max_plus_two);

  binom_trinom_tables_calc (binom , trinom);

  class array<double> Wigner_9j_table(e2_plus_one , e_max_over_two_plus_one , e2_over_two_plus_one , e_max_over_two_plus_one);
  
  class array<bool> is_Wigner_9j_calculated_table(e2_plus_one , e_max_over_two_plus_one , e2_over_two_plus_one , e_max_over_two_plus_one);

  class array<double> pow_e_term_tab(e_max_plus_one);
  
  class array<double> p_ed_tab(e2_plus_one);

  class array<double> G_function_tab_ab(e_max_over_two_plus_one , e_max_over_two_plus_one);
  class array<double> G_function_tab_ac(e_max_over_two_plus_one , e_max_over_two_plus_one);
  class array<double> G_function_tab_bd(e_max_over_two_plus_one , e_max_over_two_plus_one);
  class array<double> G_function_tab_cd(e_max_over_two_plus_one , e_max_over_two_plus_one);

  pow_e_term_tab(0) = pow (d , e1);  
  for (int e = 1 ; e <= e_max ; e++) pow_e_term_tab(e) = pow_e_term_tab(e - 1)/d;
  for (int e = 0 ; e <= e_max ; e++) pow_e_term_tab(e) = sqrt (pow_e_term_tab(e));
  pow_e_term_tab *= sqrt_pow_one_plus_d_minus_e1_minus_e2;
    
  p_ed_tab(0) = 1.0;
  for (int ed = 1 ; ed <= e2 ; ed++) p_ed_tab(ed) = minus_d*p_ed_tab(ed - 1);

  for (int l = 0 ; l <= e_max ; l++)
    {
      const int L_min = (is_e_max_plus_lambda_even) ? (abs (l - lambda)) : (abs (l - lambda) + 1);

      for (int L_index = 0 ; L_index <= L_index_max ; L_index++)
	{
	  const int L = L_min + 2*L_index;

	  const int shift_n = (l + L - lambda)/2;

	  if ((is_it_triangle_integer (l , L , lambda)) && (L <= e_max - l))
	    {
	      Wigner_9j_table_lL_fixed_calc (l , L , Wigner_9j_table , is_Wigner_9j_calculated_table);

	      const int n_max_lL = (e_max - l - L)/2;

	      const int bin_phase = (n_max_lL + n1 + n2)%2; // phase is (-1)^(n + N + n1 + n2) = (-1)^(n_max_lL + n1 + n2)

	      const int phase = parity_from_binary_parity (bin_phase);
	      
	      for (int n = 0 ; n <= n_max_lL ; n++)
		{
		  const int N = n_max_lL - n;

		  if (!is_d_equal_to_one || ((n < N) || ((n == N) && (l <= L))))
		    {
		      const int e = 2*n + l;

		      const int ed_max = min (e , e2);

		      const int n_plus_shift_n = n + shift_n;

		      double sum = 0.0;

		      for (int ed = 0 ; ed <= ed_max ; ed++)
			{      
			  const int ea = e1 - e + ed;
			  const int eb = e  - ed;
			  const int ec = e2 - ed;

			  G_function_tabs_calc (n , l , N , L , ea , eb , ec , ed , binom , trinom , G_function_tab_ab , G_function_tab_ac , G_function_tab_bd , G_function_tab_cd);

			  double sub_sum = 0.0;

			  for (int ld = ed ; ld >= 0 ; ld -= 2)
			    { 
			      const int ld_over_two = ld/2;

			      for (int lb = eb ; lb >= 0 ; lb -= 2)
				{
				  if (is_it_triangle_integer (lb , ld , l)) 
				    {
				      const int lb_over_two = lb/2;

				      for (int lc = ec ; lc >= 0 ; lc -= 2)
					{
					  if (is_it_triangle_integer (lc , ld , l2))
					    {
					      const int lc_over_two = lc/2;

					      for (int la = ea ; la >= 0 ; la -= 2)
						{
						  if (is_it_triangle_integer (la , lb , l1) && is_it_triangle_integer (la , lc , L))
						    {
						      const int la_over_two = la/2;

						      const double Wigner_9j_value = Wigner_9j_table(ld , lb_over_two , lc_over_two , la_over_two);
						      
						      const double G_function_ab = G_function_tab_ab(la_over_two , lb_over_two);
						      const double G_function_ac = G_function_tab_ac(la_over_two , lc_over_two);
						      const double G_function_bd = G_function_tab_bd(lb_over_two , ld_over_two);
						      const double G_function_cd = G_function_tab_cd(lc_over_two , ld_over_two);

						      sub_sum += Wigner_9j_value*G_function_ab*G_function_ac*G_function_bd*G_function_cd;
						    }}}}}}}
			  
			  sub_sum *= p_ed_tab(ed);

			  sum += sub_sum;
			}

		      sum *= pow_e_term_tab(e);

		      Moshinsky_table_values(l , L_index , n_plus_shift_n) = (phase == 1) ? (sum) : (-sum);
		    }
		}
	    }
	}
    } 

  if (is_d_equal_to_one) table_rest_from_symmetry ();
}






// Calculation of  <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda> from the table <(n , l) , (N , L);lambda|(n2 , l2) , (n1 , l1);lambda>
//----------------------------------------------------------------------------------------------------------------------------------------------- 
// They are equal up to (-1)^(L - lambda) 

void Moshinsky_table::symmetric_table (const class Moshinsky_table &symmetric_table)
{
  if ((n1 != symmetric_table.n2) || (l1 != symmetric_table.l2) || (n2 != symmetric_table.n1) || (l2 != symmetric_table.l1) || !is_d_equal_to_one || !symmetric_table.is_d_equal_to_one)
    error_message_print_abort ("One must have symmetric_table constituted of <(n , l) , (N , L);lambda|(n2 , l2) , (n1 , l1);lambda> brackets with d = 1 in Moshinsky_table.symmetric_table_calc.");

  const int L_index_max = min (lambda , (e_max - lambda)/2);
  
  const bool is_e_max_plus_lambda_even = ((e_max + lambda)%2 == 0);

  for (int l = 0 ; l <= e_max ; l++)
    {
      const int L_min = (is_e_max_plus_lambda_even) ? (abs (l - lambda)) : (abs (l - lambda) + 1);

      for (int L_index = 0 ; L_index <= L_index_max ; L_index++)
	{
	  const int L = L_min + 2*L_index;
	      
	  if ((is_it_triangle_integer (l , L , lambda)) && (L <= e_max - l))
	    {
	      const int shift_n = (l + L - lambda)/2;

	      const int bin_phase = (L - lambda)%2;
	      
	      const int n_max_lL = (e_max - l - L)/2;

	      const int phase = parity_from_binary_parity (bin_phase);
	  
	      for (int n = 0 ; n <= n_max_lL ; n++)
		{
		  const int N = n_max_lL - n;

		  Moshinsky_table_values(l , L_index , n + shift_n) = (phase == 1) ? (symmetric_table(n , l , N , L)) : (-symmetric_table(n , l , N , L));
		}
	    }
	}
    }
}







// Moshinsky coefficient
//----------------------

double Moshinsky_table::operator () (const int n , const int l , const int N , const int L) const
{  
  if (((2*(n + N) + l + L) != e_max) || (!is_it_triangle_integer (l , L , lambda)))
    return 0.0;
  else
    {
      const int L_index = (L - abs (l - lambda))/2;
      
      const int n_index = n + (l + L - lambda)/2;

      return Moshinsky_table_values(l , L_index , n_index);
    }
}







// Calculation of binomial and trinomial tables
//---------------------------------------------

void Moshinsky_table::binom_trinom_tables_calc (class array<double> &binom , class array<double> &trinom) const
{
  const int two_e_max = 2*e_max , two_e_max_plus_one = two_e_max + 1;

  for (int n = 0 ; n <= two_e_max_plus_one ; n++)
    {
      binom(n , 0) = binom(n , n) = 1.0;

      const int n_over_two = n/2;

      for (int p = 1 ; p <= n_over_two ; p++) 
	{
	  binom(n , p) = rint ((binom(n , p - 1)/static_cast<double> (p))*(n - p + 1));
	  
	  binom(n , n - p) = binom(n , p);
	}
    }

  trinom(0 , 0 , 0) = trinom(1 , 1 , 1) = 1.0;

  for (int nn1 = 2 ; nn1 <= two_e_max_plus_one ; nn1++)
    {
      const int M = nn1 - (nn1/2)*2 , N = M + 2;

      trinom(nn1 , nn1 , M) = trinom(nn1 , M , nn1) = 1.0;

      for (int nn2 = nn1 ; nn2 >= N ; nn2 -= 2)
	{
	  for (int nn3 = N ; nn3 <= nn2; nn3 += 2) 
	    {
	      trinom(nn1 , nn2 , nn3) = trinom(nn1 , nn2 , nn3 - 2)/nn3;
	      trinom(nn1 , nn3 , nn2) = trinom(nn1 , nn2 , nn3);
	    }

	  trinom(nn1 , nn2 - 2 , M) = trinom(nn1 , nn2 , M)*nn2;
	  trinom(nn1 , M , nn2 - 2) = trinom(nn1 , nn2 - 2 , M);
	}
    }
}






// The G-function (cf. article mentioned above)
//---------------------------------------------
//
double Moshinsky_table::G_func (
				const int ee , 
				const int ll , 
				const int ea , 
				const int la , 
				const int eb , 
				const int lb , 
				const class array<double> &binom , 
				const class array<double> &trinom) const
{ 
  const int la_mlb_ll = la - lb + ll;

  const int la_lb_mll = la + lb - ll;

  const int la_lb_ll = la + lb + ll;

  const int two_ll = 2*ll;

  const int la_lb_factor = (2*la + 1)*(2*lb + 1);

  const double binom_product = binom(ll , la_mlb_ll/2)*binom(la_lb_ll/2 , ll);
  
  const double ratio_1 = trinom(ee - ll , ea - la , eb - lb)/binom(two_ll , la_mlb_ll);
  
  const double ratio_2 = trinom(ee + ll + 1 , ea + la + 1 , eb + lb + 1)/binom(la_lb_ll + 1 , two_ll + 1);

  const double G = (la_lb_mll%4 == 0) ? (binom_product*sqrt (la_lb_factor*ratio_1*ratio_2)) : (-binom_product*sqrt (la_lb_factor*ratio_1*ratio_2));

  return G;
}








// Calculation of the Wigner 9j signs occurring at fixed l and L
//-------------------------------------------------------------- 

void Moshinsky_table::Wigner_9j_table_lL_fixed_calc (
						     const int l , 
						     const int L , 
						     class array<double> &Wigner_9j_table , 
						     class array<bool> &is_Wigner_9j_calculated_table) const
{
  const int n_max_lL = (e_max - l - L)/2;

  for (int ld = 0 ; ld <= e2 ; ld++)
    {
      for (int lb = (l + ld)%2 ; lb <= e_max ; lb += 2)
	{
	  if (is_it_triangle_integer (lb , ld , l))
	    {
	      for (int lc = (l2 + ld)%2 ; lc <= e2 ; lc += 2)
		{
		  if (is_it_triangle_integer (lc , ld , l2))
		    {
		      for (int la = (l1 + lb)%2 ; la <= e_max ; la += 2)
			{
			  if (is_it_triangle_integer (la , lb , l1) && is_it_triangle_integer (la , lc , L)) 
			    {
			      const int la_over_two = la/2;
			      const int lb_over_two = lb/2;
			      const int lc_over_two = lc/2;

			      is_Wigner_9j_calculated_table(ld , lb_over_two , lc_over_two , la_over_two) = false;
			    }}}}}}
    }
  
  for (int n = 0 ; n <= n_max_lL ; n++)
    {
      const int N = n_max_lL - n;

      if (!is_d_equal_to_one || ((n < N) || ((n == N) && (l <= L))))
	{
	  const int e = 2*n + l , ed_max = min (e , e2);

	  for (int ed = 0 ; ed <= ed_max ; ed++)
	    {
	      const int ea = e1 - e + ed , eb = e - ed , ec = e2 - ed;	 

	      for (int ld = ed ; ld >= 0 ; ld -= 2)
		{
		  for (int lb = eb ; lb >= 0 ; lb -= 2)
		    {
		      if (is_it_triangle_integer (lb , ld , l))
			{
			  for (int lc = ec ; lc >= 0 ; lc -= 2)
			    {
			      if (is_it_triangle_integer (lc , ld , l2))
				{
				  for (int la = ea ; la >= 0 ; la -= 2)
				    {
				      if (is_it_triangle_integer (la , lb , l1) && is_it_triangle_integer (la , lc , L))
					{
					  const int la_over_two = la/2;
					  const int lb_over_two = lb/2;
					  const int lc_over_two = lc/2;
					  
					  const unsigned int index = is_Wigner_9j_calculated_table.index_determine (ld , lb_over_two , lc_over_two , la_over_two);

					  bool &is_Wigner_9j_calculated = is_Wigner_9j_calculated_table[index];

					  if (!is_Wigner_9j_calculated)
					    {
					      Wigner_9j_table[index] = Wigner_9j(la , lb , l1 , lc , ld , l2 , L , l , lambda);

					      is_Wigner_9j_calculated = true;
					    }}}}}}}}}}}
}








// Calculation of G functions tables
//----------------------------------

void Moshinsky_table::G_function_tabs_calc (
					    const int n , 
					    const int l , 
					    const int N , 
					    const int L , 
					    const int ea , 
					    const int eb , 
					    const int ec , 
					    const int ed , 
					    const class array<double> &binom , 
					    const class array<double> &trinom , 
					    class array<double> &G_function_tab_ab , 
					    class array<double> &G_function_tab_ac , 
					    class array<double> &G_function_tab_bd , 
					    class array<double> &G_function_tab_cd) const
{
  const int e = 2*n + l , E = 2*N + L;

  for (int la = ea ; la >= 0 ; la -= 2) 
    for (int lb = eb ; lb >= 0 ; lb -= 2) 
      if (is_it_triangle_integer (la , lb , l1)) 
	G_function_tab_ab(la/2 , lb/2) = G_func(e1 , l1 , ea , la , eb , lb , binom , trinom);

  for (int la = ea ; la >= 0 ; la -= 2) 
    for (int lc = ec ; lc >= 0 ; lc -= 2) 
      if (is_it_triangle_integer (la , lc , L))  
	G_function_tab_ac(la/2 , lc/2) = G_func(E , L , ea , la , ec , lc , binom , trinom);

  for (int lb = eb ; lb >= 0 ; lb -= 2) 
    for (int ld = ed ; ld >= 0 ; ld -= 2) 
      if (is_it_triangle_integer (lb , ld , l))  
	G_function_tab_bd(lb/2 , ld/2) = G_func(e , l , eb , lb , ed , ld , binom , trinom);

  for (int lc = ec ; lc >= 0 ; lc -= 2) 
    for (int ld = ed ; ld >= 0 ; ld -= 2) 
      if (is_it_triangle_integer (lc , ld , l2)) 
	G_function_tab_cd(lc/2 , ld/2) = G_func(e2 , l2 , ec , lc , ed , ld , binom , trinom);
}









// Calculation of the rest of Moshinsky coefficient using symmetry relations
//-------------------------------------------------------------------------- 
// One uses <(N , L) , (n , l);lambda|(n1 , l1) , (n2 , l2);lambda> = (-1)^(l1 - lambda) <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda>

void Moshinsky_table::table_rest_from_symmetry ()
{
  if (!is_d_equal_to_one) error_message_print_abort ("Moshinsky symmetry can only be used if d = 1 in Moshinsky_table::table_rest_from_symmetry");

  const int L_index_max = min (lambda , (e_max - lambda)/2);
  
  const bool is_e_max_plus_lambda_even = ((e_max + lambda)%2 == 0);

  const unsigned int bin_phase = (l1 - lambda)%2;

  const int phase = parity_from_binary_parity (bin_phase);
	      
  for (int l = 0 ; l <= e_max ; l++)
    {
      const int L_min = (is_e_max_plus_lambda_even) ? (abs (l - lambda)) : (abs (l - lambda) + 1);

      for (int L_index = 0 ; L_index <= L_index_max ; L_index++)
	{
	  const int L = L_min + 2*L_index;

	  const int shift_n = (l + L - lambda)/2;

	  const int l_index_sym = (l - abs (L - lambda))/2;

	  if (is_it_triangle_integer (l , L , lambda) && (L <= e_max - l))
	    {
	      const int n_max_lL = (e_max - l - L)/2;

	      for (int n = 0 ; n <= n_max_lL ; n++)
		{
		  const int N = n_max_lL - n;

		  if ((n > N) || ((n == N) && (l > L)))
		    Moshinsky_table_values(l , L_index , n + shift_n) = (phase == 1) ? (Moshinsky_table_values(L , l_index_sym , N + shift_n)) : (-Moshinsky_table_values(L , l_index_sym , N + shift_n));
		}
	    }
	}
    }
}





// Tables shuffle for optimal Open MP distribution of calculations
// ---------------------------------------------------------------
// Moshinsky coefficients <n l np lp | n_rel l_rel NCM LCM>_lambda are more and more expensive numerically when l and lp increase.
// Hence, a direct Open MP distribution of a (l,lp) array of Moshinsky coefficients is very unbalanced.
// To counter it, arrays of (l,lp) values are shuffled so that small and large values of (l,lp) are found for all indices.
// 50 random shuffles are done so that (l,lp) values are well scattered.
// The Open MP distribution of the shuffled (l,lp) array of Moshinsky coefficients is then well balanced.


void l_lp_tabs_shuffle_for_optimal_OpenMP_distribution (
							class array<int> &l_tab , 
							class array<int> &lp_tab)
{
  const unsigned int lmax_total_plus_one_square = l_tab.dimension (0);
  
  const unsigned int shift = lmax_total_plus_one_square/NUMBER_OF_THREADS;

  const unsigned int N_random_tries = 50;

  int smallest_l_plus_lp_sums_per_thread = 0;
  
  class array<int> l_tab_try(lmax_total_plus_one_square);

  class array<int> lp_tab_try(lmax_total_plus_one_square);

  for (unsigned int random_try = 0 ; random_try < N_random_tries ; random_try++)
    {  
      for (unsigned int index = 0 ; index < lmax_total_plus_one_square ; index++)
	{
	  l_tab_try(index) = l_tab(index);
	  
	  lp_tab_try(index) = lp_tab(index);
	}
      
      for (unsigned int index = 0 ; index < lmax_total_plus_one_square ; index++)
	{
	  const unsigned random_index = rand_int (lmax_total_plus_one_square);
	  
	  swap<int> (l_tab_try(index) , l_tab_try(random_index));
	  
	  swap<int> (lp_tab_try(index) , lp_tab_try(random_index));
	}

      int smallest_l_plus_lp_sums_per_thread_try = lmax_total_plus_one_square;

      for (unsigned int thread = 0 ; thread < NUMBER_OF_THREADS ; thread++)
	{
	  int l_plus_lp_sums = 0;

	  for (unsigned int i = 0 ; i < shift ; i++)
	    {
	      const unsigned int index = i + shift*thread;
	      
	      l_plus_lp_sums += l_tab_try(index) + lp_tab_try(index);
	    }

	  smallest_l_plus_lp_sums_per_thread_try = min (smallest_l_plus_lp_sums_per_thread_try , l_plus_lp_sums);
	}

      if (smallest_l_plus_lp_sums_per_thread_try > smallest_l_plus_lp_sums_per_thread)
	{
	  smallest_l_plus_lp_sums_per_thread = smallest_l_plus_lp_sums_per_thread_try;
	  
	  for (unsigned int index = 0 ; index < lmax_total_plus_one_square ; index++)
	    {
	      l_tab(index) = l_tab_try(index);
	      
	      lp_tab(index) = lp_tab_try(index);
	    }
	}
    }
}






// Calculation of arrays of Moshinsky coefficients along with recoupling coefficients
// ----------------------------------------------------------------------------------
// The full Brody-Moshinsky transformation of a laboratory two-body state taking into account spin reads:
//
// |n,l,j np,lp,jp>_J = \sum <n l np lp | n_rel l_rel N L >_lambda  6j(S,lambda,l_rel,L,J_rel,J) \hat{J_rel}.\hat{lambda} .(-1)^(L + l_rel  + S + J) . 9j(l,1/2,j,lp,1/2,jp,lambda,S,J) \hat{j}.hat{jp}.\hat{S}.\hat{lambda}
//
// where n_rel,l_rel are relative quantum numbers and N,L are center of mass quantum numbers. 
// l,lp and l,L are coupled to lambda.
// j,jp , lambda and S , are coupled to J. 
// l_rel and S are coupled to J_rel.
// One sums over n_rel,l_rel,lambda,N,L,S,J_rel.
// \hat{j} is sqrt(2j+1).
//
// The arrays of Moshinsky coefficients are allocated and calculated first using the shuffle method explained above (OpenMP only).
//
// The additional Wigner signs and phases appearing above are calculated afterwards:
// 6j(S,lambda,l,L,J_rel,J) \hat{J_rel}.\hat{lambda} .(-1)^(L + l + S + J) is stored in three_js_recoupling_table(l , L , lambda , S , J_rel , J)
// 9j(l,1/2,j,lp,1/2,jp,lambda,S,J) \hat{j}.hat{jp}.\hat{S}.\hat{lambda} is stored in four_js_recoupling_table(l , ij , lp , ijp , lambda , S , J), with ij = 0,1 for j=l-1/2,l+1/2 (same for lp,jp,ijp)
//


void Moshinsky_recoupling_relative_lab_tables_alloc_calc (
							  const bool is_there_cout ,
							  const double mass_ratio , 
							  const int Jmin_global , 
							  const int Jmax_global , 
							  const class array<int> &nmax_HO_lab_tab ,
							  class array<class Moshinsky_table> &Moshinsky_tables , 
							  class array<double> &three_js_recoupling_table , 
							  class array<double> &four_js_recoupling_table)
{  
  const double reference_time = (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) ? (absolute_time_determine ()) : (NADA);

  const int lmax_total = Moshinsky_tables.dimension (1) - 1;
  
  const int lambda_max_total = Moshinsky_tables.dimension (4) - 1;

  const int lmax_total_plus_one = lmax_total + 1;
  
  const int l_relative_max_total = three_js_recoupling_table.dimension (0) - 1;

  const int Lmax_total = three_js_recoupling_table.dimension (1) - 1;

  const int J_relative_max_total = three_js_recoupling_table.dimension (4) - 1;
  
  const unsigned int lmax_total_plus_one_square = lmax_total_plus_one*lmax_total_plus_one;

  const bool is_mass_ratio_equal_to_one = (abs (mass_ratio - 1.0) < 1E-13);
  
  class array<int> l_tab(lmax_total_plus_one_square);

  class array<int> lp_tab(lmax_total_plus_one_square);

  unsigned int index_init = 0;
  
  for (int l = 0 ; l <= lmax_total ; l++)
    for (int lp = 0 ; lp <= lmax_total ; lp++)
      {
	const int n_max_l   = nmax_HO_lab_tab(l);
	const int np_max_lp = nmax_HO_lab_tab(lp);

	const int lambda_min = abs (l - lp);
	const int lambda_max = min (l + lp , lambda_max_total);

	for (int n = 0 ; n <= n_max_l ; n++)
	  for (int np = 0 ; np <= np_max_lp ; np++)
	    for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	      Moshinsky_tables(n , l , np , lp , lambda).allocate (n , l , np , lp , lambda , mass_ratio);

	l_tab(index_init) = l;

	lp_tab(index_init) = lp;

	index_init++;
      }


#ifdef UseOpenMP
  l_lp_tabs_shuffle_for_optimal_OpenMP_distribution (l_tab , lp_tab);
#endif

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (unsigned int index = 0 ; index < lmax_total_plus_one_square ; index++)
    {
      const int l = l_tab(index);
      
      const int lp = lp_tab(index);

      const int n_max_l   = nmax_HO_lab_tab(l);
      const int np_max_lp = nmax_HO_lab_tab(lp);

      const int lambda_min = abs (l - lp);
      
      const int lambda_max = min (l + lp , lambda_max_total);

      for (int n = 0 ; n <= n_max_l ; n++)
	for (int np = 0 ; np <= np_max_lp ; np++)
	  {
	    if (!is_mass_ratio_equal_to_one || ((np < n) || ((np == n) && (lp <= l))))
	      {
		for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		  Moshinsky_tables(n , l , np , lp , lambda).calc ();
	      }
	  }
    }

  if (is_mass_ratio_equal_to_one)
    {
      for (int l = 0 ; l <= lmax_total ; l++)
	for (int lp = 0 ; lp <= lmax_total ; lp++)
	  {
	    const int n_max_l   = nmax_HO_lab_tab(l);
	    const int np_max_lp = nmax_HO_lab_tab(lp);

	    const int lambda_min = abs (l - lp);

	    const int lambda_max = min (l + lp , lambda_max_total);

	    for (int n = 0 ; n <= n_max_l ; n++)
	      for (int np = 0 ; np <= np_max_lp ; np++)
		{
		  if ((np > n) || ((np == n) && (lp > l)))
		    {
		      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
			{
			  const class Moshinsky_table &Moshinsky_np_lp_n_l_table = Moshinsky_tables(np , lp , n , l , lambda);
		  
			  Moshinsky_tables(n , l , np , lp , lambda).symmetric_table (Moshinsky_np_lp_n_l_table);
			}
		    }
		}
	  }
    }
  
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int L = 0 ; L <= Lmax_total ; L++)
    for (int l_relative = 0 ; l_relative <= l_relative_max_total ; l_relative++)
      {
	const int lambda_min = abs (L - l_relative);
	const int lambda_max = min (L + l_relative , lambda_max_total);

	for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	  for (int S = 0 ; S <= 1 ; S++)
	    {
	      const int J_relative_min = abs (l_relative - S);
	      const int J_relative_max = min (l_relative + S , J_relative_max_total);

	      const int Jmin_lambda_S = abs (lambda - S);

	      const int Jmax_lambda_S = lambda + S;

	      for (int J_relative = J_relative_min ; J_relative <= J_relative_max ; J_relative++)
		{
		  const int Jmin_L_J_relative = abs (J_relative - L);
		  
		  const int Jmax_L_J_relative = J_relative + L;

		  const int Jmin_local = max (Jmin_L_J_relative , Jmin_lambda_S);
		  const int Jmax_local = min (Jmax_L_J_relative , Jmax_lambda_S);

		  class array<double> Wig_partial_table(Jmax_local - Jmin_local + 1);
		  
		  Wigner_6j_tab_calc (S , lambda , l_relative , L , J_relative , Wig_partial_table);

		  const int Jmin = max (Jmin_local , Jmin_global);
		  const int Jmax = min (Jmax_local , Jmax_global);

		  for (int J = Jmin ; J <= Jmax ; J++)
		    {
		      const double hat_J_relative_lambda_phase = hat (J_relative)*hat (lambda)*minus_one_pow (L + l_relative + S + J);

		      //old phase mistake
		      //const double hat_J_relative_lambda_phase = hat (J_relative)*hat (lambda)*minus_one_pow (lambda + J_relative + L + S);
		      
		      three_js_recoupling_table(l_relative , L , lambda , S , J_relative , J) = Wig_partial_table(J-Jmin_local)*hat_J_relative_lambda_phase;
		    }
		}
	    }
      }

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized) schedule (dynamic)
#endif
  for (int l = 0 ; l <= lmax_total ; l++)
    for (int lp = 0 ; lp <= lmax_total ; lp++)
      {
	const int lambda_min = abs (l - lp);

	const int lambda_max = min (l + lp , lambda_max_total);

	for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
	  for (int S = 0 ; S <= 1 ; S++)
	    {
	      const int Jmin_lambda_S = abs (lambda - S);
	      const int Jmax_lambda_S = lambda + S;

	      const double hats_lambda_S = hat (S)*hat (lambda);

	      for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
		for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
		  {
		    const int Jmin_j_jp = abs (make_int (j - jp));
		    const int Jmax_j_jp = make_int (j + jp);

		    const int Jmin_local = max (Jmin_j_jp , Jmin_lambda_S);
		    const int Jmax_local = min (Jmax_j_jp , Jmax_lambda_S);

		    const int Jmin = max (Jmin_local , Jmin_global);
		    const int Jmax = min (Jmax_local , Jmax_global);

		    const double hats = hat (j)*hat (jp)*hats_lambda_S;
		    
		    const unsigned int ij  = (j  > l)  ? (1) : (0);
		    const unsigned int ijp = (jp > lp) ? (1) : (0);

		    for (int J = Jmin ; J <= Jmax ; J++) four_js_recoupling_table(l , ij , lp , ijp , lambda , S , J) = Wigner_9j (l , 0.5 , j , lp , 0.5 , jp , lambda , S , J)*hats;
		  }
	    }
      }

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS))
    {
      const double now = absolute_time_determine () , relative_time = now - reference_time; 

      cout << endl << "Moshinsky coefficients and recoupling terms calculated. time:" << relative_time << " s" << endl << endl; 
    }
}



double used_memory_calc (const class Moshinsky_table &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.Moshinsky_table_values) - sizeof (T.Moshinsky_table_values)/1000000.0);
}




