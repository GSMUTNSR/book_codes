#ifndef MOSHINSKY_H
#define MOSHINSKY_H



// Talmi-Moshinsky transformation bracket table
// --------------------------------------------
//
// <(N , L) , (n , l);lambda|(n1 , l1) , (n2 , l2);lambda> for all n , l , N , L.
// One has Moshinsky_table_values(l , i[L] = (L-L_min)/2 , i[n] = n+(l+L-lambda)/2) with :
// l : 0 -> (e1 + e2 + lambda)/2. One uses the fact that l[max]+L <= e1+e2 and l[max]-L >= lambda.
// l[max] is larger than all possible l and L because they play symmetric roles.
// i[L] : 0 -> min [lambda , (e1+e2-lambda)/2]. Parity conservation ,  l+L <= e1+e2 and l , L , lambda coupling is used. 
// L_min is |l-lambda| if l1+l2-l is even ,  |l-lambda| + 1 if it is odd.
// i[n] : 0 -> (e1+e2-lambda)/2. One uses n : 0 -> (e_max-l-L)/2 and L+l >= lambda.
//
// N is given by 2(n+N) + l + L = 2(n1+n2) + l1 + l2. 
//
// If one wants <(n , l) , (N , L);lambda|(n1 , l1) , (n2 , l2);lambda> for all n1 , l1 , l2 , l2
// one has to use the symmetry  <(N , L) , (n , l);lambda|(n1 , l1) , (n2 , l2);lambda> = <(n1 , l1) , (n2 , l2);lambda | (N , L) , (n , l);lambda>.
//
// d = m1/m2 : mass ratio of the particles
//
// All Wigner 9j for l1 , l2 , l , L are calculated and stored during the n loop calculation.



class Moshinsky_table
{
public:
  
  Moshinsky_table ();
  
  Moshinsky_table (const int n1_c , const int l1_c , const int n2_c , const int l2_c , const int lambda_c , const double d_c);

  Moshinsky_table (const class Moshinsky_table &X);

  void allocate (const int n1_c , const int l1_c , const int n2_c , const int l2_c , const int lambda_c , const double d_c);
  
  void allocate_fill (const class Moshinsky_table &X);

  void deallocate ();

  bool is_it_filled () const;
  
  void calc ();

  void symmetric_table (const class Moshinsky_table &symmetric_table);

  double operator () (const int n , const int l , const int N , const int L) const;

  unsigned int index_determine (const int n , const int l , const int N , const int L) const;

  friend double used_memory_calc (const class Moshinsky_table &T);
  
private:

  int n1 , l1 , e1 , n2 , l2 , e2 , e_max , lambda;

  double d;

  bool is_d_equal_to_one;
  
  class array<double> Moshinsky_table_values;

  void binom_trinom_tables_calc (class array<double> &binom , class array<double> &trinom) const;

  double G_func (
		 const int ee , 
		 const int ll , 
		 const int ea , 
		 const int la , 
		 const int eb , 
		 const int lb , 
		 const class array<double> &binom , 
		 const class array<double> &trinom) const;

  void Wigner_9j_table_lL_fixed_calc (
				      const int l , 
				      const int L , 
				      class array<double> &Wigner_9j_table ,  
				      class array<bool> &is_Wigner_9j_calculated_table) const;

  void G_function_tabs_calc (
			     const int n , 
			     const int l , 
			     const int N , 
			     const int L , 
			     const int ea , 
			     const int eb , 
			     const int ec , 
			     const int ed , 
			     const class array<double> &binom , 
			     const class array<double> &trinom , 
			     class array<double> &G_function_tab_ab , 
			     class array<double> &G_function_tab_ac , 
			     class array<double> &G_function_tab_bd , 
			     class array<double> &G_function_tab_cd) const;

  void table_rest_from_symmetry ();
};

// Tables shuffle for optimal Open MP distribution of calculations
// ---------------------------------------------------------------

void l_lp_tabs_shuffle_for_optimal_OpenMP_distribution (
							class array<int> &l_tab , 
							class array<int> &lp_tab);

void Moshinsky_recoupling_relative_lab_tables_alloc_calc (
							  const bool is_there_cout ,
							  const double mass_ratio , 
							  const int Jmin_global , 
							  const int Jmax_global , 
							  const class array<int> &nmax_HO_lab_tab ,
							  class array<class Moshinsky_table> &Moshinsky_tables , 
							  class array<double> &three_js_recoupling_table , 
							  class array<double> &four_js_recoupling_table);
#endif
