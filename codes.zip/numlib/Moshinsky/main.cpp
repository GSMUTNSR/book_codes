#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);

    const double sample = 0.005;
	
    const int nmax = 10;
    const int lmax = 5;
	
    const int lambda_max_total = 2*lmax;
	
    const int nmax_plus_one = nmax + 1;
    const int lmax_plus_one = lmax + 1;

    const int lambda_max_total_plus_one = lambda_max_total + 1;

    const int d_max = 10;
    
    class array<double> max_test_Moshinsky(d_max + 1);
    class array<double> sum_test_Moshinsky(d_max + 1);

    class array<double> sum_test_Moshinsky_squares(d_max + 1);

    class array<unsigned int> N_tests(d_max + 1);
	
    max_test_Moshinsky = 0.0;
    sum_test_Moshinsky = 0.0;

    sum_test_Moshinsky_squares = 0.0;

    N_tests = 0.0;
    
    for (int d = 1 ; d <= d_max ; d++)
      {    
	class array<class Moshinsky_table> T_tab(nmax_plus_one , lmax_plus_one , nmax_plus_one , lmax_plus_one , lambda_max_total_plus_one);
    
	for (int la = 0 ; la <= lmax ; la++)
	  for (int lb = 0 ; lb <= lmax ; lb++)
	    {
	      const int lambda_min = abs (la - lb);
	      const int lambda_max = la + lb;

	      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		for (int na = 0 ; na <= nmax ; na++)
		  for (int nb = 0 ; nb <= nmax ; nb++)
		    {
		      if (random_number<double> () > sample) continue;

		      class Moshinsky_table &T = T_tab(na , la , nb , lb , lambda);

		      T.allocate (na , la , nb , lb , lambda , d);

		      T.calc ();
		    }
	    }

	for (int la = 0 ; la <= lmax ; la++)
	  for (int lb = 0 ; lb <= lmax ; lb++)
	    {
	      const int lambda_min = abs (la - lb);
	      const int lambda_max = la + lb;

	      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		for (int na = 0 ; na <= nmax ; na++)
		  for (int nb = 0 ; nb <= nmax ; nb++)
		    {
		      const int E = 2*(na + nb) + la + lb;

		      if (!T_tab(na , la , nb , lb , lambda).is_it_filled ()) continue;

		      const class Moshinsky_table &A = T_tab(na , la , nb , lb , lambda);

		      for (int lc = 0 ; lc <= lmax ; lc++)
			for (int ld = 0 ; ld <= lmax ; ld++)
			  {
			    if ((la + lb)%2 == (lc + ld)%2)
			      {
				for (int nc = 0 ; nc <= nmax ; nc++)
				  for (int nd = 0 ; nd <= nmax ; nd++)
				    {
				      const int lambda_p_min = abs (lc - ld);
				      const int lambda_p_max = lc + ld;
				      
				      const int Ep = 2*(nc + nd) + lc + ld;

				      if ((lambda >= lambda_p_min) && (lambda <= lambda_p_max) && (Ep == E))
					{
					  if (!T_tab(nc , lc , nd , ld , lambda).is_it_filled ()) continue;

					  const class Moshinsky_table &Ap = T_tab(nc , lc , nd , ld , lambda);

					  double test_Moshinsky = 0.0;

					  for (int n = 0 ; n <= E ; n++)
					    for (int l = 0 ; l <= E ; l++)
					      {
						const int Lmin = abs (l - lambda);
						const int Lmax = l + lambda;

						for (int L = Lmin ; L <= Lmax ; L++)
						  if ((l + L)%2 == (la + lb)%2)
						    {
						      const int N = (E - 2*n - l - L)/2;

						      if (N < 0) continue;

						      test_Moshinsky += A(n , l , N , L)*Ap(n , l , N , L);
						    }
					      }

					  if ((na == nc) && (la == lc) && (nb == nd) && (lb == ld)) test_Moshinsky -= 1.0;

					  test_Moshinsky = abs (test_Moshinsky);
					  
					  max_test_Moshinsky(d) = max (test_Moshinsky , max_test_Moshinsky(d));
					  sum_test_Moshinsky(d) += test_Moshinsky;
					  sum_test_Moshinsky_squares(d) += test_Moshinsky*test_Moshinsky;

					  N_tests(d)++;
					  
					  cout <<    "na:" << na << " la:" << la << "   nb:" << nb << " lb:" << lb 
					       << "   nc:" << nc << " lc:" << lc << "   nd:" << nd << " ld:" << ld 
					       << "   lambda:" << lambda 
					       << "   d:" << d 
					       << "   test:" << test_Moshinsky << endl;
					}
				    }
			      }
			  }
		    }
	    }	
      }

    cout << endl << "Tests statistics" << endl;
    cout         << "----------------" << endl << endl;
    
    for (int d = 1 ; d <= d_max ; d++) 
      cout <<"d=" << d
	   << "   Maximum : " << max_test_Moshinsky(d)
	   << "   Average : " << sum_test_Moshinsky(d)/N_tests(d)
	   << "   Dispersion : " << statistical_sigma_calc (N_tests(d) ,  sum_test_Moshinsky(d) , sum_test_Moshinsky_squares(d)) << endl;


#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

