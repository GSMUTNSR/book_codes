#include "../numlib_def/numlib_def.h"

void abort_all ()
{
#ifdef UseMPI
  MPI_helper::Abort ();
#else
  abort ();
#endif
}



void error_message_print_abort (const string &error_message)
{
#ifdef UseMPI

  usleep (1000*THIS_PROCESS);

  cout << "MPI process:" << THIS_PROCESS << " " << error_message << endl;

#else

  cout << error_message << endl;

#endif

  abort_all ();
}





void non_MPI_initialization ()
{
  THIS_PROCESS = MASTER_PROCESS;

  NUMBER_OF_PROCESSES = 1;

  is_it_MPI_parallelized_init = is_it_MPI_parallelized = is_it_MPI_parallelized_linear_algebra = false;

  cout.precision (15); 

  cout << boolalpha;
}


void MPI_parallelization_enabled ()
{
  is_it_MPI_parallelized = is_it_MPI_parallelized_init;
}

void MPI_parallelization_disabled ()
{
  is_it_MPI_parallelized = false;
}

void MPI_parallelization_linear_algebra_enabled ()
{
  is_it_MPI_parallelized_linear_algebra = true;
}

void MPI_parallelization_linear_algebra_disabled ()
{
  is_it_MPI_parallelized_linear_algebra = false;
}




// The number of OpenMP threads is by default the maximal number of threads possible

void OpenMP_initialization ()
{
  is_it_OpenMP_parallelized_linear_algebra = false;

#ifdef UseOpenMP

  is_it_OpenMP_parallelized_init = is_it_OpenMP_parallelized = true;

#pragma omp parallel
  {
    NUMBER_OF_THREADS = omp_get_num_threads ();	

#pragma omp master
    MASTER_THREAD = omp_get_thread_num ();
  }
  
#else

  is_it_OpenMP_parallelized_init = is_it_OpenMP_parallelized = false;

  NUMBER_OF_THREADS = 1;

  MASTER_THREAD = 0;
 
#endif
}



#ifdef UseOpenMP

void OpenMP_set_threads_number (const unsigned int number_of_OpenMP_threads)
{
  //--// set the number of threads

  NUMBER_OF_THREADS = number_of_OpenMP_threads;

  omp_set_num_threads (number_of_OpenMP_threads);
}

#endif


void OpenMP_parallelization_enabled ()
{
  is_it_OpenMP_parallelized = is_it_OpenMP_parallelized_init;
}

void OpenMP_parallelization_disabled ()
{
  is_it_OpenMP_parallelized = false;
}

void OpenMP_parallelization_linear_algebra_enabled ()
{
  is_it_OpenMP_parallelized_linear_algebra = true;
}

void OpenMP_parallelization_linear_algebra_disabled ()
{
  is_it_OpenMP_parallelized_linear_algebra = false;
}

//  OpenMP thread number with or without OpenMP included
unsigned int OpenMP_thread_number_determine ()
{
#ifdef UseOpenMP
  return omp_get_thread_num ();
#else
  return 0;
#endif
}

// Reference time initialized according to sequential/OpenMP/MPI/OpenMP+MPI usage
// ------------------------------------------------------------------------------
double absolute_time_determine ()
{
#ifdef UseMPI  
  return MPI_helper::Wtime ();
#endif 
  
#ifdef UseOpenMP
  return omp_get_wtime ();
#else
  return static_cast<double> (clock ())/CLOCKS_PER_SEC;
#endif 
}
