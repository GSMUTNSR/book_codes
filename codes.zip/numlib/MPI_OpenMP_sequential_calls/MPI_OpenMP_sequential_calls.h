#ifndef DEFINITIONS_H
#define DEFINITIONS_H

// Abort function which can be changed according to sequential or parallel computation
void abort_all ();

// Error message written and all processes stop
void error_message_print_abort (const string &error_message);

// Initialization of global variables without MPI
void non_MPI_initialization ();

// MPI parallelization enabled or disabled
void MPI_parallelization_enabled ();
void MPI_parallelization_disabled ();
void MPI_parallelization_linear_algebra_enabled ();
void MPI_parallelization_linear_algebra_disabled ();

// Initialization of global variables with OpenMP
void OpenMP_initialization ();

// OpenMP parallelization enabled or disabled
void OpenMP_parallelization_enabled ();
void OpenMP_parallelization_disabled ();
void OpenMP_parallelization_linear_algebra_enabled ();
void OpenMP_parallelization_linear_algebra_disabled ();

//  OpenMP thread number with or without OpenMP included
unsigned int OpenMP_thread_number_determine ();

// Setting global variables with OpenMP
void OpenMP_set_threads_number (const unsigned int number_of_OpenMP_threads);

void sequential_initialization ();

void OpenMP_initialization ();

// Reference time according to sequential/OpenMP/MPI/OpenMP+MPI usage
// ------------------------------------------------------------------
double absolute_time_determine ();

#endif
