#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    {
      OpenMP_parallelization_linear_algebra_enabled ();
      
      MPI_parallelization_linear_algebra_enabled ();

#ifdef UseOpenMP
      OpenMP_set_threads_number (2);
#endif
      
      const unsigned int blocks_number = 7;
      
      const unsigned int N0 = 100;
      
      const double zero_probability = 0.1;      
      
      class array<unsigned int> block_dimensions(blocks_number);
      
      for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + N0;
      
      class block_matrix<complex<double> > M_full(block_dimensions);
      
      M_full.random_matrix ();
      
      M_full.put_zeros_with_probability (zero_probability);
      
      const unsigned int N = block_dimensions.sum ();
    
      class block_sparse_matrix<complex<double> > M = M_full;

      if (!M.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class block_sparse_matrix (1)");
      	
      class vector_class<complex<double> > X(N);

      for (unsigned int i = 0 ; i < N ; i++) X(i) = complex<double> (cos (i) , sin(i));

      X.normalization ();

      const class vector_class<complex<double> > B = M*X;

      const class vector_class<complex<double> > B_from_full = M_full*X;

      const class vector_class<complex<double> > Res = B - B_from_full;
      
      if (Res.infinite_norm () > precision) error_message_print_abort ("Problem with operator matrix times vector in class block_sparse_matrix");

      OpenMP_parallelization_linear_algebra_disabled ();

      MPI_parallelization_linear_algebra_disabled ();
    }
		
    const unsigned int blocks_number = 3;
    
    const unsigned int N0 = 20;
    
    const double zero_probability = 0.1;
      
    class array<unsigned int> block_dimensions(blocks_number);
      
    for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + N0;
      
    class block_matrix<complex<double> > M_full(block_dimensions);
      
    M_full.random_matrix ();

    M_full.put_zeros_with_probability (zero_probability);
      
    const unsigned int N = block_dimensions.sum ();
    
    class block_sparse_matrix<complex<double> > M = M_full;
    
    if (!M.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class block_sparse_matrix (2)");
      
    if (M.is_it_real ()) error_message_print_abort ("Problem in class block_sparse_matrix with is_it_real");
    
    M.random_matrix ();

    M *= complex<double> (4 , 6);

    const complex<double> a(4.7 ,  3.8);
    const complex<double> b(7.8 , -3.9);
    const complex<double> c(2.4 , -1.2);

    class block_sparse_matrix<complex<double> > A = b*M;

    class block_sparse_matrix<complex<double> > B = A;
    
    A += a*M;
    A -= a*M;

    A *= b;
    A /= b;

    A -= b*M;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with = , += , -= , *= or /=");

    A = b*M;

    A = A + a*M;
    A = A - a*M;

    A = A*b;
    A = A/b;

    A = A - b*M;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with = , + , - , * or /");

    A = M + B;

    A *= b;
    A /= b;

    A = A - M - B;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with = , += , -= , *= or /=");

    B = -A;

    M = B + A;

    if (M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with unary -");

    M *= a;

    A = M;

    A.transpose ();

    B = transpose (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in transpose");

    M.random_matrix ();

    M *= a;

    A = M;

    A.conjugate ();

    B = conj (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with conjugate"); 

    M.random_matrix ();

    M *= a;

    A = M;

    A.dagger ();

    B = dagger (A) - M;
    
    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with dagger"); 

    const class block_sparse_matrix<double> Re_M = real<double , complex<double> > (M);
    const class block_sparse_matrix<double> Im_M = imag<double , complex<double> > (M);

    const class block_sparse_matrix<complex<double> > M_test = complex_matrix<double , complex<double> > (Re_M , Im_M);

    A = M - M_test;	

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with real , imag or complex_sparse_matrix");

    if (!Re_M.is_it_real ()) error_message_print_abort ("Problem in class block_sparse_matrix with is_it_real");
    
    class block_sparse_matrix<unsigned int> C(block_dimensions , block_dimensions);

    for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	{
	  C(matrix_index).get_row_index (i) = i;
	  C(matrix_index).get_column_index (i) = i;
	  C(matrix_index).get_matrix_element (i) = 1;
	}
    
    if (!C.is_it_consistent ()) error_message_print_abort ("Inconsistent matrix in class block_sparse_matrix (3)");
    
    class array<unsigned int> diag_tab(N);
    
    C.diagonal_part (diag_tab);
    
    for (unsigned int i = 0 ; i < N ; i++)
      {
	if (diag_tab(i) != 1) error_message_print_abort ("Problem in class sparse_matrix with diagonal_part");
      }
    
    const unsigned int T = C.trace ();
    if (T != N) error_message_print_abort ("Problem in class sparse_matrix with trace");
    
    class block_sparse_matrix<double> C_double = convert<unsigned int , double> (C);

    for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
      for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++)
	C_double(matrix_index).get_matrix_element (i) -= 1;
    
    if (C_double.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_sparse_matrix with convert"); 

    class array<complex<double> > A_diagonal_init(N);
    
    A.diagonal_part (A_diagonal_init);
        
    A.multiply_scalar_diagonal_part (a);

    A.divide_scalar_diagonal_part (a);
    
    for (unsigned int i = 0 ; i < N ; i++)
      if (inf_norm (A.matrix_element_determine (i , i) - A_diagonal_init(i)) > 1E-13)
	error_message_print_abort ("Problem in class block_sparse_matrix with multiply/divide_scalar_diagonal_part");
    
    A.zero_diagonal_part ();
    
    for (unsigned int i = 0 ; i < N ; i++)
      if (A.matrix_element_determine (i , i) != 0.0)
	error_message_print_abort ("Problem in class block_sparse_matrix with zero_diagonal_part");
    
    const complex<double> M_sum = M.sum ();
  
    complex<double> M_sum_try = 0.0;
  
    for (unsigned int i = 0 ; i < N ; i++)
      for (unsigned int j = 0 ; j < N ; j++)
	M_sum_try += M.matrix_element_determine (i , j);

    if (inf_norm (M_sum - M_sum_try ) > precision) error_message_print_abort ("Problem in class block_sparse_matrix with sum");
    
    class block_sparse_matrix<double> Y = real<double , complex<double> > (M);
  
    Y.random_matrix ();

    const double Y_min = Y.min ();
    const double Y_max = Y.max ();

    for (unsigned int i = 0 ; i < N ; i++)
      for (unsigned int j = 0 ; j < N ; j++)
	{
	  if (Y.matrix_element_determine (i,j) < Y_min) error_message_print_abort ("Problem in class block_sparse_matrix with min (member class)");
	  if (Y.matrix_element_determine (i,j) > Y_max) error_message_print_abort ("Problem in class block_sparse_matrix with max (member class)");
	}

    if (THIS_PROCESS == MASTER_PROCESS) cout << "All block_sparse matrix class tests are correct." << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
