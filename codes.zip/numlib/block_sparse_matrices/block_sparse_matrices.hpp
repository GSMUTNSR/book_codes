#ifndef BLOCKSPARSEMATRIX_HPP
#define BLOCKSPARSEMATRIX_HPP

// Class describing a block sparse square matrix type.
// ---------------------------------------------------
// SCALAR_TYPE must be double or complex.
// One cannot mix double and complex in general. Convert double to complex when necessary.
// The number of non zero matrix elements is fixed , but the places of the non zero matrix elements can change.
// The table of matrix elements can contain zeros , in which case the associated row and column indices can have arbitrary values between 0 and dimension-1.

// Many temporaries are created in the binary operators +,-,*,/ ...
// Unless dimensions are small (100-200 or less typically), routines are not often called (10,000 times or more typically) and the number of non-zeroes is small,
// one should not use routines creating temporaries unless one is sure that it creates no time/memory lag, as in "const class block_sparse_matrix<double> A = B+C;" for example.
// Nevertheless, binary operators are very practical in small applications or to test codes, for example.
// In any case, it is always possible to avoid temporaries using operator =, +=, -=, *=, /= ...

template <typename SCALAR_TYPE>
class block_matrix;

template <typename SCALAR_TYPE>
class block_sparse_matrix
{
public:

  block_sparse_matrix () {}

  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions , 
				const class array<unsigned int> &non_trivial_zeros_numbers)
  {
    allocate (block_dimensions , non_trivial_zeros_numbers);
  }

  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions_row ,
				const class array<unsigned int> &block_dimensions_column ,
				const class array<unsigned int> &non_trivial_zeros_numbers)
  {
    allocate (block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
  }


  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions , 
				const class array<class array<unsigned int> > &row_indices , 
				const class array<class array<unsigned int> > &column_indices) 
  {
    allocate_fill (block_dimensions , row_indices , column_indices);
  }


  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions_row ,
				const class array<unsigned int> &block_dimensions_column ,
				const class array<class array<unsigned int> > &row_indices , 
				const class array<class array<unsigned int> > &column_indices)
  {
    allocate_fill (block_dimensions_row , block_dimensions_column , row_indices , column_indices);
  }

  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions ,
				const class array<class array<unsigned int> > &row_indices , 
				const class array<class array<unsigned int> > &column_indices ,
				const class array<class array<SCALAR_TYPE> > &matrix_elements)
  {
    allocate_fill (block_dimensions , row_indices , column_indices , matrix_elements);
  }

  explicit block_sparse_matrix (
				const class array<unsigned int> &block_dimensions_row ,
				const class array<unsigned int> &block_dimensions_column ,
				const class array<class array<unsigned int> > &row_indices , 
				const class array<class array<unsigned int> > &column_indices ,
				const class array<class array<SCALAR_TYPE> > &matrix_elements)
  {
    allocate_fill (block_dimensions_row , block_dimensions_column , row_indices , column_indices , matrix_elements);
  }


  block_sparse_matrix (const class block_sparse_matrix &X)
  {
    allocate_fill (X);
  }
  
  block_sparse_matrix (const class block_matrix<SCALAR_TYPE> &X)
  {
    allocate_fill (X);
  }

  ~block_sparse_matrix () {}

  void allocate (
		 const class array<unsigned int> &block_dimensions , 
		 const class array<unsigned int> &non_trivial_zeros_numbers)

  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate (1)");
						  
    const unsigned int blocks_number = block_dimensions.dimension (0);

    if (non_trivial_zeros_numbers.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for matrix elements and other arrays for a block sparse matrix (1)");
        
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate (block_dimensions(i) , non_trivial_zeros_numbers(i));
  }

  void allocate (
		 const class array<unsigned int> &block_dimensions_row ,
		 const class array<unsigned int> &block_dimensions_column ,
		 const class array<unsigned int> &non_trivial_zeros_numbers)
  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate (2)");
						  
    const unsigned int blocks_number = block_dimensions_row.dimension (0);
    
    if (block_dimensions_column.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row dimensions and other arrays for a block sparse matrix (2)");
    
    if (non_trivial_zeros_numbers.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for non trivial zeros numbers and other arrays for a block sparse matrix (2)");
            
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate (block_dimensions_row(i) , block_dimensions_column(i) , non_trivial_zeros_numbers(i));    
  }

  void allocate_fill (
		      const class array<unsigned int> &block_dimensions , 
		      const class array<class array<unsigned int> > &row_indices , 
		      const class array<class array<unsigned int> > &column_indices)

  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (1)");
						  
    const unsigned int blocks_number = block_dimensions.dimension (0);

    if (row_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row indices and other arrays for a block sparse matrix (3)");
    
    if (column_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for column indices and other arrays for a block sparse matrix (3)");
    
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate_fill (block_dimensions(i) , row_indices(i) , column_indices(i));    
  }

  void allocate_fill (
		      const class array<unsigned int> &block_dimensions_row ,
		      const class array<unsigned int> &block_dimensions_column ,
		      const class array<class array<unsigned int> > &row_indices , 
		      const class array<class array<unsigned int> > &column_indices)

  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (2)");
						      
    const unsigned int blocks_number = block_dimensions_row.dimension (0);
            
    if (block_dimensions_column.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row dimensions and other arrays for a block sparse matrix (4)");
    
    if (row_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row indices and other arrays for a block sparse matrix (4)");
    
    if (column_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for column indices and other arrays for a block sparse matrix (4)");

    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate (block_dimensions_row(i) , block_dimensions_column(i) , row_indices(i) , column_indices(i));
  }

  void allocate_fill (
		      const class array<unsigned int> &block_dimensions , 
		      const class array<class array<unsigned int> > &row_indices , 
		      const class array<class array<unsigned int> > &column_indices ,
		      const class array<class array<SCALAR_TYPE> > &matrix_elements) 

  {   
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (3)");
						      
    const unsigned int blocks_number = block_dimensions.dimension (0);

    if (row_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row indices and other arrays for a block sparse matrix (5)");
    
    if (column_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for column indices and other arrays for a block sparse matrix (5)");
    
    if (matrix_elements.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for matrix elements and other arrays for a block sparse matrix (5)");
    
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate_fill (block_dimensions(i) , row_indices(i) , column_indices(i) , matrix_elements(i));
  }

  void allocate_fill (
		      const class array<unsigned int> &block_dimensions_row ,
		      const class array<unsigned int> &block_dimensions_column ,
		      const class array<class array<unsigned int> > &row_indices , 
		      const class array<class array<unsigned int> > &column_indices ,
		      const class array<class array<SCALAR_TYPE> > &matrix_elements)

  { 
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (4)");
						      
    const unsigned int blocks_number = block_dimensions_row.dimension (0);

    if (block_dimensions_column.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row dimensions and other arrays for a block sparse matrix (6)");
    
    if (row_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for row indices and other arrays for a block sparse matrix (6)");
    
    if (column_indices.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for column indices and other arrays for a block sparse matrix (6)");
    
    if (matrix_elements.dimension (0) != blocks_number) error_message_print_abort ("The number of blocks must be the same for matrix elements and other arrays for a block sparse matrix (6)");
    
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate (block_dimensions_row(i) , block_dimensions_column(i) , row_indices(i) , column_indices(i) , matrix_elements(i));
  }

  void allocate_fill (const class block_sparse_matrix &X)
  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (5)");
		    
    sparse_matrices.allocate_fill_object_elements (X.sparse_matrices);    
  }

  void allocate_fill (const class block_matrix<SCALAR_TYPE> &X)
  {
    if (sparse_matrices.is_it_filled ()) error_message_print_abort ("A block sparse matrix cannot be allocated twice in block_sparse_matrix::allocate_fill (6)");
						      
    const unsigned int blocks_number = X.get_blocks_number ();
        
    sparse_matrices.allocate (blocks_number);
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).allocate_fill (X(i));
  }


  void deallocate ()
  {
    sparse_matrices.deallocate ();
  }

  // put all matrix elements to zero
  void zero ();
  
  // get a sparse matrix in a given block
  class sparse_matrix<SCALAR_TYPE> & operator () (const unsigned int matrix_index) const
  {
    return sparse_matrices(matrix_index);
  }
  
  class sparse_matrix<SCALAR_TYPE> & operator [] (const unsigned int matrix_index) const
  {
    return sparse_matrices(matrix_index);
  }
  
  // Number of blocks of the block sparse matrix
  unsigned int get_blocks_number () const
  {
    return sparse_matrices.dimension_total ();
  }
  
  // dimension of the block matrix.
  unsigned int get_dimension () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int dimension_row = 0;

    unsigned int dimension_column = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++)
      {
	const class matrix<SCALAR_TYPE> &Mi = sparse_matrices(i);
	
	dimension_row += Mi.get_dimension_row ();
	
	dimension_column += Mi.get_dimension_column ();
      }
    
    if (dimension_row != dimension_column) error_message_print_abort ("get_dimension () is used with block sparse square matrices only.");
    
    return dimension_row;
  }
  

  // row dimension of the block matrix.
  unsigned int get_dimension_row () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int dimension_row = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) dimension_row += sparse_matrices(i).get_dimension_row ();
    
    return dimension_row;
  }
  
  // column dimension of the block matrix.
  unsigned int get_dimension_column () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int dimension_column = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) dimension_column += sparse_matrices(i).get_dimension_column ();
    
    return dimension_column;
  }
  
  // non zero matrix elements number of the block sparse matrix.
  unsigned int get_non_trivial_zeros_number () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int non_trivial_zeros_number = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) non_trivial_zeros_number += sparse_matrices(i).get_non_trivial_zeros_number ();
    
    return non_trivial_zeros_number;
  }
  
  // dimension of a sparse matrix in a block or maximum of row and column dimensions.
  unsigned int get_matrix_dimension (const unsigned int i) const
  {
    return sparse_matrices(i).get_dimension ();
  }

  // row dimension of a sparse matrix in a block
  unsigned int get_matrix_dimension_row (const unsigned int i) const
  {
    return sparse_matrices(i).get_dimension_row ();
  }

  // column dimension of a sparse matrix in a block
  unsigned int get_matrix_dimension_column (const unsigned int i) const
  {
    return sparse_matrices(i).get_dimension_column ();
  }
  
  // maximal row dimension of matrices in all blocks
  unsigned int get_maximal_matrix_dimension_row () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int maximal_matrix_dimension_row = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) maximal_matrix_dimension_row = max (maximal_matrix_dimension_row , sparse_matrices(i).get_dimension_row ());
    
    return maximal_matrix_dimension_row;
  }

  // maximal column dimension of matrices in all blocks
  unsigned int get_maximal_matrix_dimension_column () const
  {
    const unsigned int blocks_number = get_blocks_number ();
    
    unsigned int maximal_matrix_dimension_column = 0;
    
    for (unsigned int i = 0 ; i < blocks_number ; i++) maximal_matrix_dimension_column = max (maximal_matrix_dimension_column , sparse_matrices(i).get_dimension_column ());
    
    return maximal_matrix_dimension_column;
  }
  
  // maximal dimension of the block matrix.
  unsigned int get_maximal_matrix_dimension () const
  {
    return max (get_maximal_matrix_dimension_row () , get_maximal_matrix_dimension_column ());
  }
  
  bool is_it_filled () const
  {
    return (sparse_matrices.is_it_filled ());
  }

  // Check if the indices of non trivial zeros are sorted or not.
  bool are_indices_matrix_sorted () const;
  
  // Sort the matrix so that i + dimension_column.j increases. This allows to deal with same occurrences of (i,j) quickly
  void indices_matrix_sort ();
  
  // The matrix is reallocated so that it has no zero matrix elements.
  // Of course, nothing is done if there are no zero matrix elements.
  void remove_zeros ();
  
  // An (i,j) occurence should occur only once in sparse matrix.
  // One returns true if it is the case and false if not.
  bool is_it_consistent () const;

  // One makes the matrix consistent by remving (i,j) repetitions and summing matrix elements of same (i,j) in its first occurrence.
  // The matrix is reallocated afterwards so that ir is consistent (unless nothing changes).
  // One can also remove zeros at the same time.
  void make_it_consistent ();  
  void make_it_consistent_no_zeros ();
  
  class block_sparse_matrix& operator += (const class block_sparse_matrix &);
  class block_sparse_matrix& operator -= (const class block_sparse_matrix &);

  class block_sparse_matrix& operator *= (const SCALAR_TYPE &);
  class block_sparse_matrix& operator /= (const SCALAR_TYPE &);

  const class block_sparse_matrix& operator = (const class block_sparse_matrix &);

  SCALAR_TYPE matrix_element_determine (const unsigned int i , const unsigned int j) const;
  
  SCALAR_TYPE min () const;
  SCALAR_TYPE max () const;

  SCALAR_TYPE sum () const;
  
  void transpose ();
  void conjugate ();
  void dagger ();

  SCALAR_TYPE trace () const;

  unsigned int non_trivial_zeros_number_calc () const;
  
  double infinite_norm () const;

  SCALAR_TYPE Frobenius_squared_norm () const;
  
  SCALAR_TYPE Frobenius_norm () const;
  
  double Frobenius_squared_norm_hermitian () const;
  
  double Frobenius_norm_hermitian () const;
  
  bool is_it_real () const;
  bool is_it_diagonal () const;
  bool is_it_symmetric () const;
  bool is_it_antisymmetric () const;
  bool is_it_hermitian () const;

  void random_matrix ();
  void pseudo_random_matrix ();
  void symmetric_random_matrix ();
  void symmetric_pseudo_random_matrix ();
  void antisymmetric_random_matrix ();
  void antisymmetric_pseudo_random_matrix ();
  void hermitian_random_matrix ();
  void hermitian_pseudo_random_matrix ();
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);

  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);

  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);

  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);

  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif 


  void diagonal_part (class array<SCALAR_TYPE> &) const;

  // The following routines do not change the number of non-trivially zero matrix elements.
  // Adding a non-zero scalar to the diagonal is impossible in general for example.
  
  void zero_diagonal_part ();
  
  void multiply_scalar_diagonal_part (const SCALAR_TYPE &x);
  void divide_scalar_diagonal_part (const SCALAR_TYPE &x);
  
  void multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void divide_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  
  unsigned int matrix_index_of_vector_index (const unsigned int V_index) const;

  unsigned int row_index_in_block (const unsigned int matrix_index , const unsigned int row_index) const;
  
  unsigned int column_index_in_block (const unsigned int matrix_index , const unsigned int column_index) const;
  
  unsigned int vector_index_in_block (const unsigned int matrix_index , const unsigned int V_index) const;
  
  template <typename C>
  friend double used_memory_calc (const class block_sparse_matrix<C> &T);
  
private:
  
  // matrices in the different blocks
  class array<class sparse_matrix<SCALAR_TYPE> > sparse_matrices;
};


// put all matrix elements to zero
template <typename SCALAR_TYPE> 
void block_sparse_matrix<SCALAR_TYPE>::zero ()
{
  const unsigned int blocks_number = get_blocks_number ();

  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).zero ();
}


// Check if the indices of non trivial zeros are sorted or not.
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::are_indices_matrix_sorted () const
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).are_indices_matrix_sorted ()) return false;
    }

  return true;
}

// Sort the matrix so that i + dimension_column.j increases. This allows to deal with same occurrences of (i,j) quickly
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::indices_matrix_sort ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).indices_matrix_sort ();
}

// The matrix is reallocated so that it has no zero matrix elements.
// Of course, nothing is done if there are no zero matrix elements.
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::remove_zeros ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).remove_zeros ();
}


// An (i,j) occurence should occur only once in a sparse matrix.
// One returns true if it is the case and false if not.
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_consistent () const
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_consistent ()) return false;
    }

  return true;
}


// One makes the matrix consistent by remving (i,j) repetitions and summing matrix elements of same (i,j) in its first occurrence.
// The matrix is reallocated afterwards so that ir is consistent (unless nothing changes).
// One can also remove zeros at the same time.
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::make_it_consistent ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).make_it_consistent ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::make_it_consistent_no_zeros ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).make_it_consistent_no_zeros ();
}

// The matrices and vectors must have the same dimensions and same sparsity scheme. No test is made.


// Value of a matrix element from its row and column indices
// ---------------------------------------------------------
// A(i , j) is returned.
// It takes time , as one has to search over indices to find i and j.
// If i and j are not found , zero is returned.

template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::matrix_element_determine (const unsigned int i , const unsigned int j) const
{	
  const unsigned int blocks_number = get_blocks_number ();
    
  const unsigned int dimension_row = get_dimension_row ();
  
  const unsigned int dimension_column = get_dimension_column ();
  
  if (i >= dimension_row) error_message_print_abort ("Row index too large in matrix_element_determine (block sparse matrices)");
  
  if (j >= dimension_column) error_message_print_abort ("Column index too large in matrix_element_determine (block sparse matrices)");
  
  unsigned int sum_dimensions_row = 0.0;
  
  unsigned int sum_dimensions_column = 0.0;
  
  for (unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
    {
      const class sparse_matrix<SCALAR_TYPE> &M_block = sparse_matrices(matrix_index);
      
      const unsigned int M_block_dimension_row = M_block.get_dimension_row ();
      
      const unsigned int M_block_dimension_column = M_block.get_dimension_column ();
      
      const unsigned int i_in_block = (i >= sum_dimensions_row) ? (i - sum_dimensions_row) : (dimension_row);
  
      const unsigned int j_in_block = (j >= sum_dimensions_column) ? (j - sum_dimensions_column) : (dimension_column);
  
      if ((i_in_block < M_block_dimension_row) && (j_in_block < M_block_dimension_column)) return M_block.matrix_element_determine (i_in_block , j_in_block);
      
      sum_dimensions_row += M_block_dimension_row;
      
      sum_dimensions_column += M_block_dimension_column;
    }

  return 0.0;
}






// Minimal and maximal values of matrix
// ------------------------------------

template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::min () const
{
  const unsigned int blocks_number = get_blocks_number ();
  
  if (blocks_number == 0) error_message_print_abort ("min function not defined for block matrix without elements");
  
  const class matrix<SCALAR_TYPE> &A0 = sparse_matrices(0);
  
  SCALAR_TYPE A_min = A0.min ();

  for (unsigned long int i = 1 ; i < blocks_number ; i++)
    {
      const class matrix<SCALAR_TYPE> &Ai = sparse_matrices(i);

      const SCALAR_TYPE Ai_min = Ai.min ();
  
      A_min = ::min (A_min , Ai_min);
    }

  return A_min;
}


template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::max () const
{
  const unsigned int blocks_number = get_blocks_number ();
  
  if (blocks_number == 0) error_message_print_abort ("max function not defined for block matrix without elements");
  
  const class matrix<SCALAR_TYPE> &A0 = sparse_matrices(0);
  
  SCALAR_TYPE A_max = A0.max ();

  for (unsigned long int i = 1 ; i < blocks_number ; i++)
    {
      const class matrix<SCALAR_TYPE> &Ai = sparse_matrices(i);

      const SCALAR_TYPE Ai_max = Ai.max ();
  
      A_max = ::max (A_max , Ai_max);
    }

  return A_max;
}


// Sum of matrix elements
// ----------------------
// Product of matrix elements is not coded as it is not zero only if the matrix is full.

template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::sum () const
{
  const unsigned int blocks_number = get_blocks_number ();
    
  SCALAR_TYPE A_sum = 0.0;

  for (unsigned int i = 0 ; i < blocks_number ; i++) A_sum += sparse_matrices(i).sum ();

  return A_sum;
}




// "=" overloading.
// ----------------
template <typename SCALAR_TYPE>
const class block_sparse_matrix<SCALAR_TYPE> & block_sparse_matrix<SCALAR_TYPE>::operator = (const class block_sparse_matrix<SCALAR_TYPE> &A)
{ 
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i) = A.sparse_matrices(i);
    
  return *this;
}





// "+=" overloading.
// ----------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> & block_sparse_matrix<SCALAR_TYPE>::operator += (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i) += A.sparse_matrices(i);

  return *this;
}



// "-=" overloading.
// ----------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> & block_sparse_matrix<SCALAR_TYPE>::operator -= (const class block_sparse_matrix<SCALAR_TYPE>& A)
{ 
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i) -= A.sparse_matrices(i);

  return *this;
}



// "*=" overloading : M times SCALAR_TYPE.
// ---------------------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> & block_sparse_matrix<SCALAR_TYPE>::operator *= (const SCALAR_TYPE &x)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i) *= x;

  return *this;  
}





// "/=" overloading: M over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> & block_sparse_matrix<SCALAR_TYPE>::operator /= (const SCALAR_TYPE &x)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i) /= x;

  return *this;  
}



// Standard MPI routines (see MPI_helper)
// --------------------------------------

#ifdef UseMPI

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Send (Recv_process , tag , MPI_C);
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Recv (Send_process , tag , MPI_C);
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Bcast (Send_process , MPI_C);
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Reduce (op , Recv_process , process , MPI_C);
}


template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Allreduce (op , MPI_C);
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).MPI_Allgatherv (group_processes_number , MPI_C);
}

#endif



// Index of matrix whose block is associated to the component of the input vector
// ------------------------------------------------------------------------------
template <typename SCALAR_TYPE>  
unsigned int block_sparse_matrix<SCALAR_TYPE>::matrix_index_of_vector_index (const unsigned int V_index) const
{
  const unsigned int dimension_column = get_dimension_column ();
  
  if (V_index >= dimension_column) error_message_print_abort ("Vector index too large in matrix_index_of_vector_index (block matrices)");
  
  unsigned int matrix_index = 0;
  
  unsigned int sum_dimensions = 0;
  
  while (V_index >= sum_dimensions) sum_dimensions += sparse_matrices(matrix_index++).get_dimension_column ();

  return matrix_index;
}


// Index of the vector or of the row/column indices of the matrix component associated to the matrix of the considered block_sparse, not to the full block_sparse matrix
// -------------------------------------------------------------------------------------------------------------------------------------------------------
// dimension is returned if one is outside the block_sparse.

template <typename SCALAR_TYPE>  
unsigned int block_sparse_matrix<SCALAR_TYPE>::row_index_in_block (const unsigned int matrix_index , const unsigned int row_index) const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  if (row_index >= dimension_row) error_message_print_abort ("Row index too large in row_index_in_block (block sparse matrices)");

  unsigned int sum_dimensions_row = 0;
  
  for (unsigned int i = 0 ; i < matrix_index ; i++) sum_dimensions_row += sparse_matrices(i).get_dimension_row ();

  const unsigned int row_index_in_block_value = (row_index >= sum_dimensions_row) ? (row_index - sum_dimensions_row) : (dimension_row);

  return row_index_in_block_value;
}

template <typename SCALAR_TYPE>  
unsigned int block_sparse_matrix<SCALAR_TYPE>::column_index_in_block (const unsigned int matrix_index , const unsigned int column_index) const
{
  const unsigned int dimension_column = get_dimension_column ();
  
  if (column_index >= dimension_column) error_message_print_abort ("Column index too large in column_index_in_block (block sparse matrices)");
  
  unsigned int sum_dimensions_column = 0;
  
  for (unsigned int i = 0 ; i < matrix_index ; i++) sum_dimensions_column += sparse_matrices(i).get_dimension_column ();

  const unsigned int column_index_in_block_value = (column_index >= sum_dimensions_column) ? (column_index - sum_dimensions_column) : (dimension_column);

  return column_index_in_block_value;
}

template <typename SCALAR_TYPE>  
unsigned int block_sparse_matrix<SCALAR_TYPE>::vector_index_in_block (const unsigned int matrix_index , const unsigned int V_index) const
{
  return column_index_in_block (matrix_index , V_index);
}




// "+" overloading.
// ----------------
template <typename SCALAR_TYPE>  
class block_sparse_matrix<SCALAR_TYPE> operator + (const class block_sparse_matrix<SCALAR_TYPE> &A , const class block_sparse_matrix<SCALAR_TYPE> &B) 
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M += B;

  return M;
}




// "-" overloading.
// ----------------  
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> operator - (const class block_sparse_matrix<SCALAR_TYPE> &A , const class block_sparse_matrix<SCALAR_TYPE> &B) 
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M -= B;

  return M;
}


// "*" overloading : A times SCALAR_TYPE.
// --------------------------------------
template <typename SCALAR_TYPE>  
class  block_sparse_matrix<SCALAR_TYPE> operator * (const class block_sparse_matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x)
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M *= x;

  return M;
}



// "*" overloading : SCALAR_TYPE times A.
// --------------------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> operator * (const SCALAR_TYPE &x , const class block_sparse_matrix<SCALAR_TYPE> &A) 
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M *= x;

  return M;
}





// "/" overloading : A over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE>  
class block_sparse_matrix<SCALAR_TYPE> operator / (const class block_sparse_matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x) 
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M /= x;

  return M;
}



// Returns the number of non trivially zero matrix elements in all blocks
// ----------------------------------------------------------------------

template <typename SCALAR_TYPE>
unsigned int block_sparse_matrix<SCALAR_TYPE>::non_trivial_zeros_number_calc () const
{
  const unsigned int blocks_number = get_blocks_number ();

  unsigned int non_trivial_zeros_number = 0;
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) non_trivial_zeros_number += sparse_matrices(i).get_non_trivial_zeros_number ();
  
  return non_trivial_zeros_number;
}






// Infinite norm.
// --------------
// It is the largest component |M(i , j)|oo

template <typename SCALAR_TYPE>
double block_sparse_matrix<SCALAR_TYPE>::infinite_norm () const 
{
  double norm = 0.0;

  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class matrix<SCALAR_TYPE> &Mi = sparse_matrices(i);

      const double inf_norm_Mi = Mi.infinite_norm ();

      if (!finite (inf_norm_Mi)) return inf_norm_Mi;

      if (norm < inf_norm_Mi) norm = inf_norm_Mi;
    }
  
  return norm;
}





// Frobenius norm: Tr(A A^T) or Tr (A A^\dagger) (hermitian)

template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::Frobenius_squared_norm () const 
{  
  SCALAR_TYPE squared_norm = 0.0;

  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) squared_norm += sparse_matrices(i).Frobenius_squared_norm ();

  return squared_norm;
}


template <typename SCALAR_TYPE> 
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::Frobenius_norm () const
{
  const SCALAR_TYPE Frobenius_squared_norm_value = Frobenius_squared_norm ();
    
  const SCALAR_TYPE Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}


template <typename SCALAR_TYPE>
double block_sparse_matrix<SCALAR_TYPE>::Frobenius_squared_norm_hermitian () const 
{  
  double squared_norm = 0.0;

  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) squared_norm += sparse_matrices(i).Frobenius_squared_norm_hermitian ();

  return squared_norm;
}



template <typename SCALAR_TYPE> 
double block_sparse_matrix<SCALAR_TYPE>::Frobenius_norm_hermitian () const
{
  const double Frobenius_squared_norm_value = Frobenius_squared_norm_hermitian ();
    
  const double Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}



// Check if A is a real matrix
// ---------------------------
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_real () const 
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_real ()) return false;
    }

  return true;
}


// Conversion of one scalar type to another
// ----------------------------------------
template <typename IN_SCALAR_TYPE , typename OUT_SCALAR_TYPE>
class block_sparse_matrix<OUT_SCALAR_TYPE> convert (const class block_sparse_matrix<IN_SCALAR_TYPE> &M_in)
{  
  const unsigned int blocks_number = M_in.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  class array<unsigned int> block_dimensions_column(blocks_number);
  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<IN_SCALAR_TYPE> &M_in_block = M_in(i);
  
      block_dimensions_row(i) = M_in_block.get_dimension_row ();      
      block_dimensions_column(i) = M_in_block.get_dimension_column ();
      non_trivial_zeros_numbers(i) = M_in_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<OUT_SCALAR_TYPE> M_out(block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++) M_out(i) = convert<IN_SCALAR_TYPE , OUT_SCALAR_TYPE> (M_in(i));

  return M_out;
}


// Check if A is diagonal
// ----------------------
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_diagonal () const 
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_diagonal ()) return false;
    }

  return true;
}






// Check if A is symmetric
// -----------------------
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_symmetric () const 
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_symmetric ()) return false;
    }

  return true;
}


// Check if A is antisymmetric
// ---------------------------
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_antisymmetric () const 
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_antisymmetric ()) return false;
    }

  return true;
}




// Check if A is hermitian
// -----------------------
template <typename SCALAR_TYPE>
bool block_sparse_matrix<SCALAR_TYPE>::is_it_hermitian () const 
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (!sparse_matrices(i).is_it_hermitian ()) return false;
    }

  return true;
}



// Unary +
// -------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> operator + (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  return A;
}




// Unary -
// -------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> operator - (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M *= -1.0;
  
  return M;
}





// Matrix transpose
// ----------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::transpose ()
{	
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).transpose ();
}




// Matrix conjugate.
// -----------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::conjugate ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).conjugate ();
}




// Matrix hermitian conjugate
// --------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::dagger ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).dagger ();
}




// Matrix transpose returned.
// --------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> transpose (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  
  class array<unsigned int> block_dimensions_column(blocks_number);

  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<SCALAR_TYPE> &A_block = A(i);
  
      block_dimensions_row(i) = A_block.get_dimension_row ();

      block_dimensions_column(i) = A_block.get_dimension_column ();

      non_trivial_zeros_numbers(i) = A_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<SCALAR_TYPE> M(block_dimensions_column , block_dimensions_row , non_trivial_zeros_numbers);

  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int non_trivial_zeros_number = A_block.get_non_trivial_zeros_number ();
      
      class sparse_matrix<SCALAR_TYPE> &M_block = M(i);            
   
      for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
	{
	  M_block.get_row_index (index) = A_block.get_column_index (index);

	  M_block.get_column_index (index) = A_block.get_row_index (index);
      
	  M_block.get_matrix_element (index) = A_block.get_matrix_element (index) ;
	}
    }
  
  return M;
}






// Matrix conjugate returned.
// --------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> conj (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  class block_sparse_matrix<SCALAR_TYPE> M = A;

  M.conjugate ();

  return M;
}




// Matrix hermitian conjugate returned.
// ------------------------------------
template <typename SCALAR_TYPE>
class block_sparse_matrix<SCALAR_TYPE> dagger (const class block_sparse_matrix<SCALAR_TYPE> &A)
{
  class block_sparse_matrix<SCALAR_TYPE> M = transpose (A);
  
  M.conjugate ();
  
  return M;
}





// Matrix real part returned
// -------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class block_sparse_matrix<SCALAR_TYPE> real (const class block_sparse_matrix<COMPLEX_TYPE> &M)
{
  const unsigned int blocks_number = M.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  class array<unsigned int> block_dimensions_column(blocks_number);
  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<COMPLEX_TYPE> &M_block = M(i);
  
      block_dimensions_row(i) = M_block.get_dimension_row ();
      block_dimensions_column(i) = M_block.get_dimension_column ();
      non_trivial_zeros_numbers(i) = M_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<SCALAR_TYPE> Re_M(block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) Re_M(i) = real<SCALAR_TYPE , COMPLEX_TYPE> (M(i));

  return Re_M;
}


// Matrix imaginary part returned
// ------------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class block_sparse_matrix<SCALAR_TYPE> imag (const class block_sparse_matrix<COMPLEX_TYPE> &M)
{
  const unsigned int blocks_number = M.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  class array<unsigned int> block_dimensions_column(blocks_number);
  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<COMPLEX_TYPE> &M_block = M(i);
  
      block_dimensions_row(i) = M_block.get_dimension_row ();
      block_dimensions_column(i) = M_block.get_dimension_column ();
      non_trivial_zeros_numbers(i) = M_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<SCALAR_TYPE> Im_M(block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) Im_M(i) = imag<SCALAR_TYPE , COMPLEX_TYPE> (M(i));

  return Im_M;
}







// Complex matrix returned from real and/or imaginary parts
// --------------------------------------------------------

template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class block_sparse_matrix<COMPLEX_TYPE> complex_matrix (const class block_sparse_matrix<SCALAR_TYPE> &Re_M)
{	
  const unsigned int blocks_number = Re_M.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  class array<unsigned int> block_dimensions_column(blocks_number);
  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<SCALAR_TYPE> &Re_M_block = Re_M(i);
  
      block_dimensions_row(i) = Re_M_block.get_dimension_row ();
      block_dimensions_column(i) = Re_M_block.get_dimension_column ();
      non_trivial_zeros_numbers(i) = Re_M_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<COMPLEX_TYPE> M(block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) M(i) = complex_matrix<SCALAR_TYPE , COMPLEX_TYPE> (Re_M(i));

  return M;
}






template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class block_sparse_matrix<COMPLEX_TYPE> complex_matrix (const class block_sparse_matrix<SCALAR_TYPE> &Re_M , const class block_sparse_matrix<SCALAR_TYPE> &Im_M)
{	
  const unsigned int blocks_number = Re_M.get_blocks_number ();
  
  class array<unsigned int> block_dimensions_row(blocks_number);
  class array<unsigned int> block_dimensions_column(blocks_number);
  class array<unsigned int> non_trivial_zeros_numbers(blocks_number);
      
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<SCALAR_TYPE> &Re_M_block = Re_M(i);
  
      block_dimensions_row(i) = Re_M_block.get_dimension_row ();
      block_dimensions_column(i) = Re_M_block.get_dimension_column ();
      non_trivial_zeros_numbers(i) = Re_M_block.get_non_trivial_zeros_number ();
    }
      
  class block_sparse_matrix<COMPLEX_TYPE> M(block_dimensions_row , block_dimensions_column , non_trivial_zeros_numbers);
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) M(i) = complex_matrix<SCALAR_TYPE , COMPLEX_TYPE> (Re_M(i) , Im_M(i));

  return M;
}







// Trace of the matrix
// -------------------
template <typename SCALAR_TYPE>
SCALAR_TYPE block_sparse_matrix<SCALAR_TYPE>::trace () const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("trace member function is used with sparse square matrices only.");

  SCALAR_TYPE trace_value = 0.0;
  
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) trace_value += sparse_matrices(i).trace ();
  
  return trace_value;
}




// Diagonal part of the matrix
// ---------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::diagonal_part (class array<SCALAR_TYPE> &diagonal_array) const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("diagonal_part member function is used with square matrices only for block sparse matrices");
  
  unsigned int index = 0;
  
  const unsigned int blocks_number = get_blocks_number ();

  diagonal_array = 0.0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      const class sparse_matrix<SCALAR_TYPE> &M_block = sparse_matrices(i);
  
      const unsigned int M_block_dimension = M_block.get_dimension ();
            
      const unsigned int M_non_trivial_zeros_number = M_block.get_non_trivial_zeros_number ();
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  bool is_ii_found = false;
	  
	  for (unsigned int index_non_trivial_zeros = 0 ; !is_ii_found && (index_non_trivial_zeros < M_non_trivial_zeros_number) ; index_non_trivial_zeros++)
	    {
	      const unsigned int i = M_block.get_row_index (index_non_trivial_zeros);

	      const unsigned int j = M_block.get_column_index (index_non_trivial_zeros);

	      if ((i == ii) && (j == ii)) diagonal_array(index) = M_block.get_matrix_element (index_non_trivial_zeros) , is_ii_found = true;
	    }

	  index++;
	  
	}
    }
}

// put a scalar to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::zero_diagonal_part ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).zero_diagonal_part ();
}

// multiply a scalar to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::multiply_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).multiply_scalar_diagonal_part (x);
}


// divide the diagonal by a scalar
// -------------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::divide_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).divide_scalar_diagonal_part (x);
}




// multiply an array to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  unsigned int index = 0;

  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      class sparse_matrix<SCALAR_TYPE> &M_block = sparse_matrices(i);
  
      const class array<SCALAR_TYPE> M_block_dimension = M_block.get_dimension ();
            
      class array<SCALAR_TYPE> T_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++) T_block(ii) = T(index++);

      M_block.multiply_array_diagonal_part (T_block);
    }
}


// divide the diagonal by an array
// -------------------------------
template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::divide_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int blocks_number = get_blocks_number ();
    
  unsigned int index = 0;

  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      class matrix<SCALAR_TYPE> &M_block = sparse_matrices(i);
  
      const class array<SCALAR_TYPE> M_block_dimension = M_block.get_dimension ();
            
      class array<SCALAR_TYPE> T_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++) T_block(ii) = T(index++);

      M_block.divide_array_diagonal_part (T_block);
    }
}


// V=AX.
// -----
template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> operator * (const class block_sparse_matrix<SCALAR_TYPE> &A , const class vector_class<SCALAR_TYPE> &X)
{	
  if (A.get_dimension_column () != X.get_dimension ()) error_message_print_abort ("Column dimension of A and dimension of X must be equal for matrix-vector multiplication for block sparse matrices");

  const unsigned int blocks_number = A.get_blocks_number ();
  
  unsigned int X_index = 0;
  unsigned int V_index = 0;
  
  class vector_class<SCALAR_TYPE> V = X;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class sparse_matrix<SCALAR_TYPE> &A_block = A(i);
  
      const unsigned int A_block_dimension = A_block.get_dimension ();
            
      class vector_class<SCALAR_TYPE> X_block(A_block_dimension);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) X_block(ii) = X(X_index++);

      const class vector_class<SCALAR_TYPE> V_block = A_block*X_block;

      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) V(V_index++) = V_block(ii);
    }

  return V;
}







//  M << print overload.
// ---------------------
template <typename SCALAR_TYPE>
ostream & operator << (ostream &os , const class block_sparse_matrix<SCALAR_TYPE> &M)
{
  const unsigned int blocks_number = M.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) os << M(i) << endl;

  return os;
}




//  M >> get overload.
// -------------------
template <typename SCALAR_TYPE>
istream & operator >> (istream &is , class block_sparse_matrix<SCALAR_TYPE> &M)
{
  const unsigned int blocks_number = M.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) is >> M(i);

  return is;
}




//  Matrix randomly initialized.
// -----------------------------

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).random_matrix ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::pseudo_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).pseudo_random_matrix ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::symmetric_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).symmetric_random_matrix ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::symmetric_pseudo_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).symmetric_pseudo_random_matrix ();
}


template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::antisymmetric_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).antisymmetric_random_matrix ();
}


template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::antisymmetric_pseudo_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).antisymmetric_pseudo_random_matrix ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::hermitian_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).hermitian_random_matrix ();
}

template <typename SCALAR_TYPE>
void block_sparse_matrix<SCALAR_TYPE>::hermitian_pseudo_random_matrix ()
{
  const unsigned int blocks_number = get_blocks_number ();
    
  for (unsigned int i = 0 ; i < blocks_number ; i++) sparse_matrices(i).hermitian_pseudo_random_matrix ();
}






template <typename SCALAR_TYPE>
bool operator == (const class block_sparse_matrix<SCALAR_TYPE> &A , const class block_sparse_matrix<SCALAR_TYPE> &B)
{
  const unsigned int blocks_number = A.get_blocks_number ();
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {
      if (A(i) != B(i)) return false;
    }

  return true;
}

template <typename SCALAR_TYPE>
bool operator != (const class block_sparse_matrix<SCALAR_TYPE> &A , const class block_sparse_matrix<SCALAR_TYPE> &B)
{
  return (!(A == B));
}

template <typename SCALAR_TYPE>
double used_memory_calc (const class block_sparse_matrix<SCALAR_TYPE> &T)
{
  const double used_memory = sizeof (T)/1000000.0 + used_memory_calc (T.sparse_matrices);
    
  return used_memory;
}




template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product (
				      const class block_sparse_matrix<SCALAR_TYPE> &A ,
				      const class block_sparse_matrix<SCALAR_TYPE> &B)
{  
  if (A.get_blocks_number () != B.get_blocks_number ()) error_message_print_abort ("The number of blocks must be the same for A, B and M in Frobenius_scalar_product (A sparse , B sparse)");
  
  const unsigned int blocks_number = A.get_blocks_number ();

  SCALAR_TYPE Frobenius_scalar_product_value = 0.0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) Frobenius_scalar_product_value += Frobenius_scalar_product (A(i) , B(i));

  return Frobenius_scalar_product_value;
}


template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product_hermitian (
						const class block_sparse_matrix<SCALAR_TYPE> &A ,
						const class block_sparse_matrix<SCALAR_TYPE> &B)
{  
  if (A.get_blocks_number () != B.get_blocks_number ()) error_message_print_abort ("The number of blocks must be the same for A, B and M in Frobenius_scalar_product_hermitian (A sparse , B sparse)");
  
  const unsigned int blocks_number = A.get_blocks_number ();

  SCALAR_TYPE Frobenius_scalar_product_hermitian_value = 0.0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++) Frobenius_scalar_product_hermitian_value += Frobenius_scalar_product_hermitian (A(i) , B(i));

  return Frobenius_scalar_product_hermitian_value;
}




#endif
