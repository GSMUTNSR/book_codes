#include "../numlib_def/numlib_def.h"

// Generate all permutations of an array of N unsigned integers
// ------------------------------------------------------------
// Recursive Heap's algorithm is used. (Heap ,  B. R. (1963). "Permutations by Interchanges". The Computer Journal 6 (3): 293–4. ,  see http://en.wikipedia.org/wiki/Heap's_algorithm)
// The integer "signature" and array "permutation" of dimension N are working tables of the recursive method , 
// containing the signature and permutation of the current permutation.
// The integer "adjacent_index" is adjacent to the index of an integer changing place in the considered permutation in Heap's method ,  which decreases by one unit at each recursive call.
// They must be initialized for "permutation" at the initial table to permute ,  for "signature" at its signature and for "adjacent_index" at N.
// The index of permutation must be initialized at permutation_index = 0.
// Final results are stored in arrays signatures and permutations, of respective dimension N and (N! , N) .
//
// Cost in time is O(N.N!) and recursive calls increase as N!, so that N ~ 10 at most typically.
// All integers are unsigned int, except signatures, which are int. 
// They must all be different, otherwise the result is meaningless. No test is made.
// 
// Variables
// ---------
// N : number of integers in the permutation.
// adjacent_index : index adjacent to that of an integer changing place in the permutation. It is N at the beginning and decreases by one unit at each recursive call.
// right_changing_integer_index : adjacent_index - 1
// left_changing_integer_index : 0 if adjacent_index is odd, i if not, with 0 <= i < adjacent_index of the Heap's method loop.
// signature : work integer containing the signature of the permutation
// permutation : work array of N integers containing the permutation
// permutation_index : current index of the considered permutation
// permutations : two-dimensional array of N! times N integers containing at the end all permutations. 
//                The first index is that of the permutation and the second index that of the permuted integer.
// signatures : array of N! integers containing the signatures of permutations

void generate_all_permutations (
				const unsigned int adjacent_index , 
				class array<unsigned int> &permutation , 
				int &signature , 
				unsigned int &permutation_index , 
				class array<unsigned int> &permutations , 
				class array<int> &signatures)
{
  if (adjacent_index == 1) 
    {
      const unsigned int N = permutation.dimension (0);

      for (unsigned int i = 0 ; i < N ; i++) permutations(permutation_index , i) = permutation(i);

      signatures(permutation_index) = signature;

      permutation_index++;
    }
  else
    {
      const unsigned int right_changing_integer_index = adjacent_index-1;

      for (unsigned int i = 0 ; i < adjacent_index ; i++) 
	{
	  generate_all_permutations (right_changing_integer_index , permutation , signature , permutation_index , permutations , signatures);

	  const unsigned int left_changing_integer_index = (adjacent_index%2 == 1) ? (0) : (i);

	  if (left_changing_integer_index != right_changing_integer_index) 
	    {
	      swap (permutation(left_changing_integer_index) , permutation(right_changing_integer_index));
				
	      signature = -signature;
	    }
	}
    }
}


