#ifndef PERMUTATIONS_H
#define PERMUTATIONS_H

// Generate all permutations of a table of integers
void generate_all_permutations (
				const unsigned int adjacent_index , 
				class array<unsigned int> &permutation , 
				int &signature , 
				unsigned int &permutation_index , 
				class array<unsigned int> &permutations , 
				class array<int> &signatures);

#endif
