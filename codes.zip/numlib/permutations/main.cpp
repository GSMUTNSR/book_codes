#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


using namespace Wigner_signs;


void reordering (
		 class array<unsigned int> &table , 
		 int &signature)
{
  const unsigned int N = table.dimension (0);

  signature = 1;

  unsigned int inc = Shell_method_increment_determine (N);

  while (inc > 1)
    {
      inc /= 3;
      
      const unsigned int inc_m1 = inc - 1;

      for (unsigned int i = inc ; i < N ; i++)
	{
	  const unsigned int a = table[i];

	  unsigned int ii = i , aa;

	  while ((ii > inc_m1) && ((aa = table[ii - inc]) > a))
	    {
	      table[ii] = aa;

	      ii -= inc;

	      signature = -signature;
	    }

	  table[ii] = a;
	}
    }	
}






#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const unsigned int N = 5;

    const unsigned int factorial_N = make_uns_int (factorial (N));	

    int signature = 1;

    unsigned int permutation_index = 0; 

    class array<unsigned int> permutations(factorial_N , N);

    class array<unsigned int> permutation(N);

    class array<int> signatures(factorial_N);

    for (unsigned int i = 0 ; i < N ; i++) permutation(i) = i;

    generate_all_permutations (N , permutation , signature , permutation_index , permutations , signatures);

    for (unsigned int i = 0 ; i < factorial_N ; i++)
      {
	for (unsigned int ip = 0 ; ip < factorial_N ; ip++)
	  {
	    if (ip != i)
	      {
		bool is_there_redundancy = true;

		for (unsigned int j = 0 ; (j < N) && is_there_redundancy ; j++)
		  is_there_redundancy = is_there_redundancy && (permutations(i , j) == permutations(ip , j));

		if (is_there_redundancy) error_message_print_abort ("Problem in generate_all_permutations for permutation");
	      }
	  }

	for (unsigned int j = 0 ; j < N ; j++) permutation(j) = permutations(i , j);

	reordering (permutation , signature);

	if (signature != signatures(i)) error_message_print_abort ("Problem in generate_all_permutations for signature");

	cout << "Permutation " << i << " : ";

	for (unsigned int j = 0 ; j < N ; j++) cout << permutations(i , j) << " ";

	cout << " signature : " << signatures(i) << endl;
      }

    cout << endl << "Permutations test is correct." << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
