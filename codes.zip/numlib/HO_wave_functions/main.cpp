#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

void fixed_functions_test_1D (
			      const unsigned int N , 
			      const int n , 
			      const int m , 
			      const double b , 
			      const double mass , 
			      const double X)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> x_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (-X , X , x_tab , w_tab);

  double I0 = 0.0;
  double I1 = 0.0;
  double I2 = 0.0;

  double OBME_x2_test = 0.0;
  double OBME_p2_test = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double x = x_tab(i);
      const double w = w_tab(i);
      
      const double x2 = x*x;
      
      const double yn   = HO_wave_functions::HO_1D::y   (b , n , x);
      const double dyn  = HO_wave_functions::HO_1D::dy  (b , n , x);
      const double d2yn = HO_wave_functions::HO_1D::d2y (b , n , x);

      const double ym = HO_wave_functions::HO_1D::y (b , m , x);
      
      I0 += yn*ym*w;
      I1 += yn*dyn*w;
      I2 += (yn*d2yn + dyn*dyn)*w;
      
      OBME_x2_test += yn*ym*x2*w;
      OBME_p2_test -= ym*d2yn/(two_amu_over_hbar_square*mass)*w;
    }

  if (n == m) I0 -= 1.0;

  OBME_x2_test -= HO_wave_functions::HO_1D::OBME_x2_HO_calc (n , m , b);
  OBME_p2_test -= HO_wave_functions::HO_1D::OBME_kinetic_HO_calc (n , m , hbar_omega);
	      
  I0 = abs (I0);
  I1 = abs (I1);
  I2 = abs (I2);

  OBME_x2_test = abs (OBME_x2_test);
  OBME_p2_test = abs (OBME_p2_test);
  
  if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_x2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
    error_message_print_abort ("Problem in fixed_functions_test_1D");
		
  cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   x2-test:" << OBME_x2_test << "   p2-test:" << OBME_p2_test << endl;
}








void tables_functions_y_test_1D (
				 const unsigned int N , 
				 const int nmax ,
				 const double b , 
				 const double mass , 
				 const double X)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> x_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (-X , X , x_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);
    
  HO_wave_functions::HO_1D::y_x_tables_calc (b , x_tab , HO_wfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      {
	HO_dwfs (n , i) = HO_wave_functions::HO_1D::dy  (b , n , x_tab(i));
	HO_d2wfs(n , i) = HO_wave_functions::HO_1D::d2y (b , n , x_tab(i));
      }
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_x2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double x = x_tab(i);
		const double w = w_tab(i);
      
		const double x2 = x*x;

		const double yn   = HO_wfs  (n , i);
		const double dyn  = HO_dwfs (n , i);
		const double d2yn = HO_d2wfs(n , i);

		const double ym = HO_wfs(m , i);

		I0 += yn*ym*w;
		I1 += yn*dyn*w;
		I2 += (yn*d2yn + dyn*dyn)*w;

		OBME_x2_test += yn*ym*x2*w;
		OBME_p2_test -= ym*d2yn/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_x2_test -= HO_wave_functions::HO_1D::OBME_x2_HO_calc (n , m , b);
	    
	    OBME_p2_test -= HO_wave_functions::HO_1D::OBME_kinetic_HO_calc (n , m , hbar_omega);
	      
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_x2_test = abs (OBME_x2_test);
	    OBME_p2_test = abs (OBME_p2_test);
  
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_x2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_y_test_1D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   x2-test:" << OBME_x2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_y_dy_test_1D (
				    const unsigned int N , 
				    const int nmax , 
				    const double b , 
				    const double mass , 
				    const double X)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> x_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (-X , X , x_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);
  
  HO_wave_functions::HO_1D::y_dy_x_tables_calc (b , x_tab , HO_wfs , HO_dwfs);
  
  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      HO_d2wfs(n , i) = HO_wave_functions::HO_1D::d2y (b , n , x_tab(i));

  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_x2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double x = x_tab(i);
		const double w = w_tab(i);
      
		const double x2 = x*x;

		const double yn   = HO_wfs  (n , i);
		const double dyn  = HO_dwfs (n , i);
		const double d2yn = HO_d2wfs(n , i);

		const double ym = HO_wfs(m , i);

		I0 += yn*ym*w;
		I1 += yn*dyn*w;
		I2 += (yn*d2yn + dyn*dyn)*w;

		OBME_x2_test += yn*ym*x2*w;
		OBME_p2_test -= ym*d2yn/(two_amu_over_hbar_square*mass)*w;		
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_x2_test -= HO_wave_functions::HO_1D::OBME_x2_HO_calc (n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_1D::OBME_kinetic_HO_calc (n , m , hbar_omega);
	      
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_x2_test = abs (OBME_x2_test);
	    OBME_p2_test = abs (OBME_p2_test);
  
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_x2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_y_dy_test_1D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   x2-test:" << OBME_x2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_y_dy_d2y_OBMEs_test_1D (
					      const unsigned int N , 
					      const int nmax , 
					      const double b , 
					      const double mass , 
					      const double X)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);

  class array<double> x_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (-X , X , x_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_1D::y_dy_d2y_x_tables_calc (b , x_tab , HO_wfs , HO_dwfs , HO_d2wfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_x2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double x = x_tab(i);
		const double w = w_tab(i);
      
		const double x2 = x*x;

		const double yn   = HO_wfs  (n , i);
		const double dyn  = HO_dwfs (n , i);
		const double d2yn = HO_d2wfs(n , i);

		const double ym = HO_wfs(m , i);

		I0 += yn*ym*w;
		I1 += yn*dyn*w;
		I2 += (yn*d2yn + dyn*dyn)*w;

		OBME_x2_test += yn*ym*x2*w;
		OBME_p2_test -= ym*d2yn/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_x2_test -= HO_wave_functions::HO_1D::OBME_x2_HO_calc (n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_1D::OBME_kinetic_HO_calc (n , m , hbar_omega);
	      
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_x2_test = abs (OBME_x2_test);
	    OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_x2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_y_dy_d2y_test_1D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   x2-test:" << OBME_x2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}















void fixed_functions_test_3D (
			      const unsigned int N , 
			      const int n , 
			      const int m , 
			      const int l , 
			      const double b , 
			      const double mass , 
			      const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  double I0 = 0.0;
  double I1 = 0.0;
  double I2 = 0.0;
  
  double OBME_r2_test = 0.0;
  double OBME_p2_test = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double r = r_tab(i);
      const double w = w_tab(i);

      const double r2 = r*r;

      const double un   = HO_wave_functions::HO_3D::u   (b , n , l , r);
      const double dun  = HO_wave_functions::HO_3D::du  (b , n , l , r);
      const double d2un = HO_wave_functions::HO_3D::d2u (b , n , l , r);

      const double um = HO_wave_functions::HO_3D::u (b , m , l , r);

      I0 += un*um*w;
      I1 += un*dun*w;
      I2 += (un*d2un + dun*dun)*w;
      
      OBME_r2_test += un*um*r2*w;
      OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
    }

  if (n == m) I0 -= 1.0;

  OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
  OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
  I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	    
  if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
    error_message_print_abort ("Problem in fixed_functions_test_3D");
		
  cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
}








void tables_functions_u_fixed_l_test_3D (
					 const unsigned int N , 
					 const int nmax , 
					 const int l , 
					 const double b , 
					 const double mass , 
					 const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> r_tab(N);
  class array<double> w_tab(N);

  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b , l , r_tab , HO_wfs , HO_dwfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      {
	HO_dwfs (n , i) = HO_wave_functions::HO_3D::du  (b , n , l , r_tab(i));
	HO_d2wfs(n , i) = HO_wave_functions::HO_3D::d2u (b , n , l , r_tab(i));
      }
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double r = r_tab(i);
		const double w = w_tab(i);

		const double r2 = r*r;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);

		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;
		
		OBME_r2_test += un*um*r2*w;
		OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_fixed_l_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_u_du_fixed_l_test_3D (
					    const unsigned int N , 
					    const int nmax , 
					    const int l , 
					    const double b , 
					    const double mass , 
					    const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b , l , r_tab , HO_wfs , HO_dwfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      HO_d2wfs(n , i) = HO_wave_functions::HO_3D::d2u (b , n , l , r_tab(i));
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double r = r_tab(i);
		const double w = w_tab(i);

		const double r2 = r*r;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);

		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;

		OBME_r2_test += un*um*r2*w;
		OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_du_fixed_l_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_u_du_d2u_OBMEs_fixed_l_test_3D (
						      const unsigned int N , 
						      const int nmax , 
						      const int l , 
						      const double b , 
						      const double mass , 
						      const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);

  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b , l , r_tab , HO_wfs , HO_dwfs , HO_d2wfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double r = r_tab(i);
		const double w = w_tab(i);

		const double r2 = r*r;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);

		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;

		OBME_r2_test += un*um*r2*w;
		OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
  
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_du_d2u_OBMEs_fixed_l_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_u_test_3D (
				 const unsigned int N , 	
				 const int nmax , 
				 const int lmax , 
				 const double b , 
				 const double mass , 
				 const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_r_tables_calc (b , r_tab , HO_wfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (unsigned int i = 0 ; i < N ; i++) 
	{
	  HO_dwfs (n , l , i) = HO_wave_functions::HO_3D::du  (b , n , l , r_tab(i));
	  HO_d2wfs(n , l , i) = HO_wave_functions::HO_3D::d2u (b , n , l , r_tab(i));
	}
  
  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double r = r_tab(i);
		  const double w = w_tab(i);

		  const double r2 = r*r;

		  const double un = HO_wfs(n , l , i);
		  const double dun = HO_dwfs(n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);
		
		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += un*um*r2*w;
		  OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	    
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}







void tables_functions_u_du_test_3D (
				    const unsigned int N , 	
				    const int nmax , 
				    const int lmax , 
				    const double b , 
				    const double mass , 
				    const double R)
{  
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b , r_tab , HO_wfs , HO_dwfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (unsigned int i = 0 ; i < N ; i++) 
	HO_d2wfs(n , l , i) = HO_wave_functions::HO_3D::d2u (b , n , l , r_tab(i));
  
  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double r = r_tab(i);
		  const double w = w_tab(i);

		  const double r2 = r*r;

		  const double un = HO_wfs(n , l , i);
		  const double dun = HO_dwfs(n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);

		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += un*um*r2*w;
		  OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	    
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_du_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}










void tables_functions_u_du_d2u_OBMEs_test_3D (
					      const unsigned int N , 	
					      const int nmax , 
					      const int lmax , 
					      const double b , 
					      const double mass , 
					      const double R)
{
  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);

  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b , r_tab , HO_wfs , HO_dwfs , HO_d2wfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double r = r_tab(i);
		  const double w = w_tab(i);

		  const double r2 = r*r;

		  const double un = HO_wfs(n , l , i);
		  const double dun = HO_dwfs(n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);

		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += un*um*r2*w;
		  OBME_p2_test += um*(-d2un + l*(l+1)/r2*un)/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0) , I1 = abs (I1) , I2 = abs (I2) , OBME_r2_test = abs (OBME_r2_test) , OBME_p2_test = abs (OBME_p2_test);
	      
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_du_d2u_OBMEs_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}









void fixed_functions_momentum_test_3D (
				       const unsigned int N , 
				       const int n , 
				       const int m , 
				       const int l , 
				       const double bk , 
				       const double mass , 
				       const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
    
  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  double I0 = 0.0;
  double I1 = 0.0;
  double I2 = 0.0;
  
  double OBME_r2_test = 0.0;
  double OBME_p2_test = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double k = k_tab(i);
      const double w = w_tab(i);
      
      const double k2 = k*k;

      const double un   = HO_wave_functions::HO_3D::u_momentum   (bk , n , l , k);
      const double dun  = HO_wave_functions::HO_3D::du_momentum  (bk , n , l , k);
      const double d2un = HO_wave_functions::HO_3D::d2u_momentum (bk , n , l , k);

      const double um = HO_wave_functions::HO_3D::u_momentum (bk , m , l , k);

      I0 += un*um*w;
      I1 += un*dun*w;
      I2 += (un*d2un + dun*dun)*w;
      
      OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
      OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
    }

  if (n == m) I0 -= 1.0;

  OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
  OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
  I0 = abs (I0);
  I1 = abs (I1);
  I2 = abs (I2);

  OBME_r2_test = abs (OBME_r2_test);
  OBME_p2_test = abs (OBME_p2_test);
	    
  if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
    error_message_print_abort ("Problem in fixed_functions_momentum_test_3D");
		
  cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
}









void tables_functions_u_fixed_l_momentum_test_3D (
						  const unsigned int N , 
						  const int nmax , 
						  const int l , 
						  const double bk , 
						  const double mass , 
						  const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_k_tables_calc (bk , l , k_tab , HO_wfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      {
	HO_dwfs (n , i) = HO_wave_functions::HO_3D::du_momentum  (bk , n , l , k_tab(i));
	HO_d2wfs(n , i) = HO_wave_functions::HO_3D::d2u_momentum (bk , n , l , k_tab(i));
      }
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double k = k_tab(i);
		const double w = w_tab(i);
      
		const double k2 = k*k;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);
		
		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;
		
		OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_r2_test = abs (OBME_r2_test);
	    OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_fixed_l_momentum_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}








void tables_functions_u_du_fixed_l_momentum_test_3D (
						     const unsigned int N , 	
						     const int nmax , 
						     const int l , 
						     const double bk , 
						     const double mass , 
						     const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
    
  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk , l , k_tab , HO_wfs , HO_dwfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (unsigned int i = 0 ; i < N ; i++)
      HO_d2wfs(n , i) = HO_wave_functions::HO_3D::d2u_momentum (bk , n , l , k_tab(i));
  
  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double k = k_tab(i);
		const double w = w_tab(i);
      
		const double k2 = k*k;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);

		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;
		
		OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_r2_test = abs (OBME_r2_test);
	    OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_du_fixed_l_momentum_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}










void tables_functions_u_du_d2u_OBMEs_fixed_l_momentum_test_3D (
							       const unsigned int N , 
							       const int nmax , 
							       const int l , 
							       const double bk , 
							       const double mass , 
							       const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);

  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , N);

  HO_wave_functions::HO_3D::u_du_d2u_k_tables_calc (bk , l , k_tab , HO_wfs , HO_dwfs , HO_d2wfs);

  for (int n = 0 ; n <= nmax ; n++)
    for (int m = 0 ; m <= n ; m++)
      {
	if (random_number<double> () < 0.5)
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;
	    
	    double OBME_r2_test = 0.0;
	    double OBME_p2_test = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double k = k_tab(i);
		const double w = w_tab(i);
      
		const double k2 = k*k;

		const double un   = HO_wfs  (n , i);
		const double dun  = HO_dwfs (n , i);
		const double d2un = HO_d2wfs(n , i);

		const double um = HO_wfs(m , i);

		I0 += un*um*w;
		I1 += un*dun*w;
		I2 += (un*d2un + dun*dun)*w;

		OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
	      }

	    if (n == m) I0 -= 1.0;

	    OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	    OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);

	    OBME_r2_test = abs (OBME_r2_test);
	    OBME_p2_test = abs (OBME_p2_test);
	    
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
	      error_message_print_abort ("Problem in tables_functions_u_du_d2u_OBMEs_fixed_l_momentum_test_3D");
		
	    cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	  }
      }
}









void tables_functions_u_momentum_test_3D (
					  const unsigned int N , 
					  const int nmax , 
					  const int lmax , 
					  const double bk , 
					  const double mass , 
					  const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_k_tables_calc (bk , k_tab , HO_wfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  HO_dwfs (n , l , i) = HO_wave_functions::HO_3D::du_momentum  (bk , n , l , k_tab(i));
	  HO_d2wfs(n , l , i) = HO_wave_functions::HO_3D::d2u_momentum (bk , n , l , k_tab(i));
	}
  
  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double k = k_tab(i);
		  const double w = w_tab(i);
      
		  const double k2 = k*k;

		  const double un   = HO_wfs  (n , l , i);
		  const double dun  = HO_dwfs (n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);

		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		  OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0);
	      I1 = abs (I1);
	      I2 = abs (I2);

	      OBME_r2_test = abs (OBME_r2_test);
	      OBME_p2_test = abs (OBME_p2_test);
	    
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_momentum_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}








void tables_functions_u_du_momentum_test_3D (
					     const unsigned int N , 
					     const int nmax , 
					     const int lmax , 
					     const double bk , 
					     const double mass , 
					     const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);
  
  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_du_k_tables_calc (bk , k_tab , HO_wfs , HO_dwfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (unsigned int i = 0 ; i < N ; i++) 
	HO_d2wfs(n , l , i) = HO_wave_functions::HO_3D::d2u_momentum (bk , n , l , k_tab(i));
  
  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double k = k_tab(i);
		  const double w = w_tab(i);
      
		  const double k2 = k*k;

		  const double un   = HO_wfs  (n , l , i);
		  const double dun  = HO_dwfs (n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);

		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		  OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0);
	      I1 = abs (I1);
	      I2 = abs (I2);

	      OBME_r2_test = abs (OBME_r2_test);
	      OBME_p2_test = abs (OBME_p2_test);
	    
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_du_momentum_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}









void tables_functions_u_du_d2u_OBMEs_momentum_test_3D (
						       const unsigned int N , 
						       const int nmax , 
						       const int lmax , 
						       const double bk , 
						       const double mass , 
						       const double K)
{
  const double b = 1.0/bk;

  const double hbar_omega = HO_wave_functions::hbar_omega_calc (false , 0.0 , mass , b);

  class array<double> k_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , K , k_tab , w_tab);

  class array<double> HO_wfs  (nmax+1 , lmax+1 , N);
  class array<double> HO_dwfs (nmax+1 , lmax+1 , N);
  class array<double> HO_d2wfs(nmax+1 , lmax+1 , N);

  HO_wave_functions::HO_3D::u_du_d2u_k_tables_calc (bk , k_tab , HO_wfs , HO_dwfs , HO_d2wfs);

  for (int l = 0 ; l <= lmax ; l++)
    for (int n = 0 ; n <= nmax ; n++)
      for (int m = 0 ; m <= n ; m++)
	{
	  if (random_number<double> () < 0.05)
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;
	      
	      double OBME_r2_test = 0.0;
	      double OBME_p2_test = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double k = k_tab(i);
		  const double w = w_tab(i);
      
		  const double k2 = k*k;

		  const double un   = HO_wfs  (n , l , i);
		  const double dun  = HO_dwfs (n , l , i);
		  const double d2un = HO_d2wfs(n , l , i);

		  const double um = HO_wfs(m , l , i);

		  I0 += un*um*w;
		  I1 += un*dun*w;
		  I2 += (un*d2un + dun*dun)*w;

		  OBME_r2_test += um*(-d2un + l*(l+1)/k2*un)*w;
		  OBME_p2_test += un*um*k2/(two_amu_over_hbar_square*mass)*w;
		}

	      if (n == m) I0 -= 1.0;

	      OBME_r2_test -= HO_wave_functions::HO_3D::OBME_r2_HO_calc (l , n , m , b);
	      OBME_p2_test -= HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (l , n , m , hbar_omega);
	    
	      I0 = abs (I0);
	      I1 = abs (I1);
	      I2 = abs (I2);

	      OBME_r2_test = abs (OBME_r2_test);
	      OBME_p2_test = abs (OBME_p2_test);
	    
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision) || (OBME_r2_test > sqrt_precision) || (OBME_p2_test > sqrt_precision))
		error_message_print_abort ("Problem in tables_functions_u_du_d2u_OBMEs_momentum_test_3D");
		
	      cout << "n:" << n << " m:" << m << "   I0:" << I0 << "   I1:" << I1 << "   I2:" << I2 << "   r2-test:" << OBME_r2_test << "   p2-test:" << OBME_p2_test << endl;
	    }
	}
}









void tables_functions_j0_OBMEs_test_3D (
					const unsigned int N ,
					const double b ,
					const double R,
					const complex<double> &q)
{
  class array<double> r_tab(N);
  class array<double> w_tab(N);
  
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_tab , w_tab);

  complex<double> j0_ME_GL = 0.0;

  complex<double> hat_j0_der_ME_GL = 0.0;

  complex<double> r_hat_j0_ME_GL = 0.0;

  complex<double> hat_j0_ME_GL = 0.0;

  complex<double> hat_j0_over_r_ME_GL = 0.0;

  complex<double> r_j0_ME_GL = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double r = r_tab(i);
      const double w = w_tab(i);
      
      const double u = HO_wave_functions::HO_3D::u (b , 0 , 0 , r);
      
      const double u2 = u*u;

      const complex<double> qr = q*r;

      const complex<double> hat_j0_qr = sin (qr);

      const complex<double> j0_qr = hat_j0_qr/qr;

      const complex<double> hat_j0_der_qr = cos (qr);

      const complex<double> r_hat_j0_qr = r*hat_j0_qr;

      const complex<double> hat_j0_qr_over_r = hat_j0_qr/r;

      const complex<double> r_j0_ME = r*j0_qr;

      j0_ME_GL += w*u2*j0_qr;

      hat_j0_der_ME_GL += w*u2*hat_j0_der_qr;

      r_hat_j0_ME_GL += w*u2*r_hat_j0_qr;

      hat_j0_ME_GL += w*u2*hat_j0_qr;

      hat_j0_over_r_ME_GL += w*u2*hat_j0_qr_over_r;

      r_j0_ME_GL += w*u2*r_j0_ME;
    }

  const complex<double> j0_ME_exact            = HO_wave_functions::HO_3D::j0_ME_calc (b , q);
  const complex<double> hat_j0_der_ME_exact    = HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (b , q);
  const complex<double> r_hat_j0_ME_exact      = HO_wave_functions::HO_3D::r_hat_j0_ME_calc (b , q);
  const complex<double> hat_j0_ME_exact        = HO_wave_functions::HO_3D::hat_j0_ME_calc (b , q);
  const complex<double> hat_j0_over_r_ME_exact = HO_wave_functions::HO_3D::hat_j0_over_r_ME_calc (b , q);
  const complex<double> r_j0_ME_exact          = HO_wave_functions::HO_3D::r_j0_ME_calc (b , q);

  cout << "j0(qr)        OBME   GL : " << j0_ME_GL            << "   exact : " << j0_ME_exact            << "   test : " << abs (j0_ME_GL - j0_ME_exact) << endl;
  cout << "hat(j0)'(qr)  OBME   GL : " << hat_j0_der_ME_GL    << "   exact : " << hat_j0_der_ME_exact    << "   test : " << abs (hat_j0_der_ME_GL - hat_j0_der_ME_exact) << endl;
  cout << "r hat(j0)(qr) OBME   GL : " << r_hat_j0_ME_GL      << "   exact : " << r_hat_j0_ME_exact      << "   test : " << abs (r_hat_j0_ME_GL - r_hat_j0_ME_exact) << endl;
  cout << "hat(j0)(qr)   OBME   GL : " << hat_j0_ME_GL        << "   exact : " << hat_j0_ME_exact        << "   test : " << abs (hat_j0_ME_GL - hat_j0_ME_exact) << endl;
  cout << "hat(j0)(qr)/r OBME   GL : " << hat_j0_over_r_ME_GL << "   exact : " << hat_j0_over_r_ME_exact << "   test : " << abs (hat_j0_over_r_ME_GL - hat_j0_over_r_ME_exact) << endl;
  cout << "r j0(qr)      OBME   GL : " << r_j0_ME_GL          << "   exact : " << r_j0_ME_exact          << "   test : " << abs (r_j0_ME_GL - r_j0_ME_exact) << endl;  
}






void quadrupole_operator_test (const unsigned int NGL , const double R)
{      
  const int n_in = 5;
  const int l_in = 4;
  
  const int n_out = 4;
  const int l_out = 6;

  const double j_in  = l_in  + 0.5;
  const double j_out = l_out + 0.5;
         
  const int E_in  = 2*n_in  + l_in;
  const int E_out = 2*n_out + l_out;
            
  double OBME_r2_GL = 0.0;

  if (E_in == E_out)
    {
      class array<double> rGL_table(NGL); 
      class array<double> wGL_table(NGL); 
      
      Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , rGL_table , wGL_table);
  
      for (unsigned int i = 0 ; i < NGL ; i++)
	{
	  const double r = rGL_table(i);
	  const double w = wGL_table(i);

	  const double u_in_r  = HO_wave_functions::HO_3D::u (1.0 , n_in  , l_in  , r);
	  const double u_out_r = HO_wave_functions::HO_3D::u (1.0 , n_out , l_out , r);

	  OBME_r2_GL += r*r*u_in_r*u_out_r*w;
	}
    }
  
  cout << n_in << angular_state (l_in , j_in) << " " << n_out << angular_state (l_out , j_out) << endl;
  
  cout << "l-coupled GL(integral):" << sqrt (3.2*M_PI)*OBME_r2_GL*angular_matrix_elements::OBME_YL_reduced_in_l (2 , l_in , l_out) << endl;

  cout << "l-coupled HO(routines):" << HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_l_calc (n_in , l_in , n_out , l_out) << endl << endl;
  
  cout << n_in << angular_state (l_in , j_in) << " " << n_out << angular_state (l_out , j_out) << endl;  

  cout << "j-coupled GL(integral):" << sqrt (3.2*M_PI)*OBME_r2_GL*angular_matrix_elements::OBME_YL_reduced_in_j (2 , l_in , j_in , l_out , j_out) << endl;

  cout << "j-coupled HO(routines):" << HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_j_calc (n_in , l_in , j_in , n_out , l_out , j_out) << endl << endl;
  
  double OBME_q2_test = 0.0;

  const int lmin = (l_in%2 == 0) ? (0) : (1);
  
  for (int lp = lmin ; lp <= E_in ; lp += 2)
    {
      const int np = (E_in - lp)/2;
      
      const double OBME_q_minus = (lp > 0) ? (HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_j_calc (n_in , l_in , j_in , np , lp , lp - 0.5)) : (0.0);
      const double OBME_q_plus  =             HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_j_calc (n_in , l_in , j_in , np , lp , lp + 0.5);
      
      OBME_q2_test += OBME_q_minus*OBME_q_minus + OBME_q_plus*OBME_q_plus;
    }

  OBME_q2_test /= 2*j_in + 1.0;
 
  cout << n_in << angular_state (l_in , j_in) << endl;
  
  cout << "OBME q^2  (l-routine):" << HO_wave_functions::HO_3D::OBME_q2_HO_calc (n_in , l_in) << endl;  

  cout << "OBME q^2  (j-formula):" << OBME_q2_test << endl << endl;

  const int na = n_in;
  const int la = l_in;
  
  const int nb = n_in + 1;
  const int lb = l_in + 2;  
  
  const double ja = la + 0.5;
  const double jb = lb + 0.5;
  
  const int nc = n_out;
  const int lc = l_out;
  
  const int nd = n_out + 1;
  const int ld = l_out + 2;  
  
  const double jc = lc + 0.5;
  const double jd = ld + 0.5;
  
  const int Jmin = max (abs (make_int (ja - jb)) , abs (make_int (jc - jd)));
  
  const int Jmax = min (make_int (ja + jb) , make_int (jc + jd));

  const int J = (Jmin + Jmax)/2;

  double TBME_LS_test = 0.0;
  
  for (int S = 0 ; S <= 1 ; S++)
    for (int L = abs (J - S) ; L <= J+S ; L++)
      {
	const double TBME_L = HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_calc (na , la , nb , lb , nc , lc , nd , ld , L);

	TBME_LS_test += TBME_L*Wigner_signs::Wigner_9j (la , 0.5 , ja , lb , 0.5 , jb , L , S , J)*Wigner_signs::Wigner_9j (lc , 0.5 , jc , ld , 0.5 , jd , L , S , J)*hat (ja)*hat (jb)*hat (jc)*hat(jd)*(2*S + 1)*(2*L + 1);
      }
  
  cout << na << angular_state (la , ja) << " " << nb << angular_state (lb , jb) << " " << nc << angular_state (lc , jc) << " " << nd << angular_state (ld , jd) << " J:" << J << endl;

  cout << "TBME q1.q2 (LS-coupling-sum):" << TBME_LS_test << endl;  

  cout << "TBME q1.q2     (jj-coupling):" << HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_calc (na , la , ja , nb , lb , jb , nc , lc , jc , nd , ld , jd , J) << endl;
}     







#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#endif

    OpenMP_initialization ();

    seed ();
    
    cout.precision (5);
    
    cout << "Tests for harmonic oscillator wave functions are made with orthogonality and integration by parts for 1D and 3D." << endl;
    
    cout << "I0 = int u_n(r) u_m(r) dr - delta(n , m) = 0" << endl;

    cout << "I1 = int u_n(r) u_n'(r) dr = 0" << endl;

    cout << "I2 = int u_n(r) u_n''(r) dr + int u_n'(r) u_n'(r) dr = 0" << endl << endl;

    const unsigned int N_3D = 150;
    
    const unsigned int N_1D = N_3D*2;
    
    const int n = 4;
    const int m = 6;
    const int l = 2;

    const int nmax = 10;
    const int lmax = 6;
    
    const double b = 2.345;

    const double bk = 1.0/b;

    const double R = 50;
    
    const double X = R;
    const double K = 5;

    const double mass = 1.046;

    const complex<double> q(1.734 , -0.01465);

    cout << "N[1D]:" << N_1D << " N[3D]:" << N_3D << " n:" << n << " m:" << m << " l:" << l << " nmax:" << nmax << " lmax:" << lmax << endl;
    
    cout << "b:" << b << " R:" << R << " K:" << K << " mass:" << mass << " q:" << q << endl;


    cout << endl << endl << "Fixed functions test 1D" << endl;

    fixed_functions_test_1D (N_1D , n , m , b , mass , X);

    cout << endl << "Tables functions test_1D (y)" << endl;

    tables_functions_y_test_1D (N_1D , nmax , b , mass , X);

    cout << endl << "Tables functions test_1D (y dy)" << endl;

    tables_functions_y_dy_test_1D (N_1D , nmax , b , mass , X);

    cout << endl << "Tables functions test_1D (y dy d2y)" << endl;

    tables_functions_y_dy_d2y_OBMEs_test_1D (N_1D , nmax , b , mass , X);

    
    cout << endl << endl << "Fixed functions test 3D" << endl;

    fixed_functions_test_3D (N_3D , n , m , l , b , mass , R);

    cout << endl << "Tables functions fixed l test_3D (u)" << endl;

    tables_functions_u_fixed_l_test_3D (N_3D , nmax , l , b , mass , R);

    cout << endl << "Tables functions fixed l test_3D (u du)" << endl;

    tables_functions_u_du_fixed_l_test_3D (N_3D , nmax , l , b , mass , R);

    cout << endl << "Tables functions fixed l test_3D (u du d2u)" << endl;

    tables_functions_u_du_d2u_OBMEs_fixed_l_test_3D (N_3D , nmax , l , b , mass , R);

    cout << endl << "Tables functions test_3D (u)" << endl;

    tables_functions_u_test_3D (N_3D , nmax , lmax , b , mass , R);

    cout << endl << "Tables functions test_3D (u du)" << endl;

    tables_functions_u_du_test_3D (N_3D , nmax , lmax , b , mass , R);

    cout << endl << "Tables functions test_3D (u du d2u)" << endl;

    tables_functions_u_du_d2u_OBMEs_test_3D (N_3D , nmax , lmax , b , mass , R);	



    cout << endl << "Fixed functions momentum test 3D" << endl;
    fixed_functions_momentum_test_3D (N_3D , n , m , l , bk , mass , K);

    cout << endl << "Tables functions fixed l momentum test_3D (u)" << endl;

    tables_functions_u_fixed_l_momentum_test_3D (N_3D , nmax , l , bk , mass , K);

    cout << endl << "Tables functions fixed l momentum test_3D (u du)" << endl;

    tables_functions_u_du_fixed_l_momentum_test_3D (N_3D , nmax , l , bk , mass , K);

    cout << endl << "Tables functions fixed l momentum test_3D (u du d2u)" << endl;

    tables_functions_u_du_d2u_OBMEs_fixed_l_momentum_test_3D (N_3D , nmax , l , bk , mass , K);

    cout << endl << "Tables functions momentum test_3D (u)" << endl;

    tables_functions_u_momentum_test_3D (N_3D , nmax , lmax , bk , mass , K);

    cout << endl << "Tables functions momentum test_3D (u du)" << endl;

    tables_functions_u_du_momentum_test_3D (N_3D , nmax , lmax , bk , mass , K);

    cout << endl << "Tables functions momentum test_3D (u du d2u)" << endl;

    tables_functions_u_du_d2u_OBMEs_momentum_test_3D (N_3D , nmax , lmax , bk , mass , K);


    cout.precision (15);
    
    cout << endl << "HO matrix elements test involving j0 (3D)" << endl;

    tables_functions_j0_OBMEs_test_3D (N_3D , b , R , q);	

    cout << endl << "Quadrupole operator test" << endl << endl;
    
    quadrupole_operator_test (N_3D , R);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


