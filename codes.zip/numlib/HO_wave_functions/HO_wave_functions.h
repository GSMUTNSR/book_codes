#ifndef HO_WAVEFUNCTIONS_H
#define HO_WAVEFUNCTIONS_H

namespace HO_wave_functions
{
  double hbar_omega_calc (const bool is_it_electron , const double mass_modif , const double particle_mass_for_calc , const double b);

  namespace HO_1D
  {
    double y (const double b  , const int n , const double x);
      
    double dy (const double b  , const int n , const double x);

    double d2y (const double b  , const int n , const double x);

    void y_single_x_tables_calc (const double b  , const double x , class array<double> &HO_wfs);

    void y_x_tables_calc (const double b  , const class array<double> &x_tab , class array<double> &wfs);

    void y_x_tables_calc (const double b  , const class array<double> &x_tab , class array<double> &wfs);

    void y_dy_single_x_tables_calc (
				    const double b ,
				    const double x , 
				    class array<double> &wfs , 
				    class array<double> &dwfs);

    void y_dy_x_tables_calc (
			     const double b , 
			     const class array<double> &x_tab , 
			     class array<double> &wfs , 
			     class array<double> &dwfs);

    void y_dy_d2y_x_tables_calc (
				 const double b , 
				 const class array<double> &x_tab , 
				 class array<double> &wfs , 
				 class array<double> &dwfs , 
				 class array<double> &d2wfs);

    double OBME_kinetic_HO_calc (const int n_in , const int n_out , const double hbar_omega);

    double OBME_x2_HO_calc (const int n_in , const int n_out , const double b_lab_shell);
  }

  namespace HO_3D
  {
    double C0_calc          (const double b  , const int n , const int l);
    double C0_momentum_calc (const double bk , const int n , const int l);

    double u          (const double b  , const int n , const int l , const double r);
    double u_momentum (const double bk , const int n , const int l , const double k);

    double du          (const double b  , const int n , const int l , const double r);
    double du_momentum (const double bk , const int n , const int l , const double k);

    double d2u          (const double b  , const int n , const int l , const double r);
    double d2u_momentum (const double bk , const int n , const int l , const double k);

    void u_single_r_tables_calc (const double b  , const int l , const double r , class array<double> &HO_wfs);
    void u_single_k_tables_calc (const double bk , const int l , const double k , class array<double> &HO_wfs);

    void u_r_tables_calc (const double b  , const int l , const class array<double> &r_tab , class array<double> &wfs);
    void u_k_tables_calc (const double bk , const int l , const class array<double> &k_tab , class array<double> &wfs);

    void u_r_tables_calc (const double b  , const class array<double> &r_tab , class array<double> &wfs);
    void u_k_tables_calc (const double bk , const class array<double> &k_tab , class array<double> &wfs);

    void u_du_single_r_tables_calc (
				    const double b , 
				    const int l , 
				    const double r , 
				    class array<double> &wfs , 
				    class array<double> &dwfs);

    void u_du_single_k_tables_calc (
				    const double bk , 
				    const int l , 
				    const double k , 
				    class array<double> &wfs , 
				    class array<double> &dwfs);

    void u_du_r_tables_calc (
			     const double b , 
			     const int l , 
			     const class array<double> &r_tab , 
			     class array<double> &wfs , 
			     class array<double> &dwfs);

    void u_du_k_tables_calc (
			     const double bk , 
			     const int l , 
			     const class array<double> &k_tab , 
			     class array<double> &wfs , 
			     class array<double> &dwfs);

    void u_du_r_tables_calc (
			     const double b , 
			     const class array<double> &r_tab , 
			     class array<double> &wfs , 
			     class array<double> &dwfs);

    void u_du_k_tables_calc (
			     const double bk , 
			     const class array<double> &k_tab , 
			     class array<double> &wfs , 
			     class array<double> &dwfs);

    void u_du_d2u_r_tables_calc (
				 const double b , 
				 const int l , 
				 const class array<double> &r_tab , 
				 class array<double> &wfs , 
				 class array<double> &dwfs , 
				 class array<double> &d2wfs);

    void u_du_d2u_k_tables_calc (
				 const double b , 
				 const int l , 
				 const class array<double> &k_tab , 
				 class array<double> &wfs , 
				 class array<double> &dwfs , 
				 class array<double> &d2wfs);

    void u_du_d2u_r_tables_calc (
				 const double b , 
				 const class array<double> &r_tab , 
				 class array<double> &wfs , 
				 class array<double> &dwfs , 
				 class array<double> &d2wfs);

    void u_du_d2u_k_tables_calc (
				 const double b , 
				 const class array<double> &k_tab , 
				 class array<double> &wfs , 
				 class array<double> &dwfs , 
				 class array<double> &d2wfs);

    double OBME_kinetic_HO_calc (const int l , const int n_in , const int n_out , const double hbar_omega);

    double OBME_r2_HO_calc (const int l , const int n_in , const int n_out , const double b_lab_shell);

    double r2_radial_integral_same_major_shell_b_is_one_calc (
							      const int n_in  , const int l_in ,
							      const int n_out , const int l_out);
    double OBME_q_HO_reduced_in_l_calc (
					const int n_in  , const int l_in ,
					const int n_out , const int l_out);
 
    double OBME_q_HO_reduced_in_j_calc (
					const int n_in  , const int l_in  , const double j_in ,
					const int n_out , const int l_out , const double j_out);
 
    double OBME_q2_HO_calc (const int n , const int l);
      
    double TBME_q1_scalar_q2_HO_calc (
				      const int na , const int la ,
				      const int nb , const int lb , 
				      const int nc , const int lc ,
				      const int nd , const int ld , 
				      const int L);
      
    double TBME_q1_scalar_q2_HO_calc (
				      const int na , const int la , const double ja ,
				      const int nb , const int lb , const double jb , 
				      const int nc , const int lc , const double jc ,
				      const int nd , const int ld , const double jd , 
				      const int J);
 
    double TBME_q1_scalar_q2_HO_antisymmetrized_calc (
						      const int na , const int la , const double ja ,
						      const int nb , const int lb , const double jb , 
						      const int nc , const int lc , const double jc ,
						      const int nd , const int ld , const double jd , 
						      const int J);
 
    complex<double> j0_ME_calc (const double b , const complex<double> &q);
	
    complex<double> hat_j0_derivative_ME_calc (const double b , const complex<double> &q);

    complex<double> r_hat_j0_ME_calc (const double b , const complex<double> &q);

    complex<double> hat_j0_ME_calc (const double b , const complex<double> &q);

    complex<double> hat_j0_over_r_ME_calc (const double b , const complex<double> &q);
	
    complex<double> r_j0_ME_calc (const double b , const complex<double> &q);
  
    double j0_ME_calc (const double b , const double q);
	
    double hat_j0_derivative_ME_calc (const double b , const double q);

    double r_hat_j0_ME_calc (const double b , const double q);

    double hat_j0_ME_calc (const double b , const double q);

    double hat_j0_over_r_ME_calc (const double b , const double q);
	
    double r_j0_ME_calc (const double b , const double q);
  }
}

#endif
