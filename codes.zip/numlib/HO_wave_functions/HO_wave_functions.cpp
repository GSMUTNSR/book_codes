#include "../numlib_def/numlib_def.h"

// HO wave functions in coordinate space and momentum space are equal up to a phase.
// I included them in the 3D case as they are used to calculate GSM matrix elements in k-space, so that it is convenient to have them explicitely coded.
// They are calculated from the r-space routines and the phase is added afterwards.


// Renormalized Hermite polynomials are considered for 1D HO wave functions (see Numerical Recipes)
// ------------------------------------------------------------------------------------------------
// The HO norm besides b-dependent terms is included therein.



// Calculation of hbar omega (b) from the kinetic factor and b (hbar omega)
// ------------------------------------------------------------------------
// It is the standard formula: hbar omega = 2/[kf.b^2]
// where kf = kinetic factor = 2 [cluster effective mass in amu]/hbar^2
//
// Variables
// ---------
// particle : type of cluster
// mass_modif : recoil correction in amu
// particle_mass_for_calc : mass of the cluster in amu 
// b: HO length in fm
// hbar_omega : hbar imega in MeV
// kinetic_factor : kinetic factor equal to 2 [cluster effective mass in amu]/hbar^2 

double HO_wave_functions::hbar_omega_calc (
					   const bool is_it_electron ,
					   const double mass_modif ,
					   const double particle_mass_for_calc ,
					   const double b)
{
  const double kinetic_factor = kinetic_factor_calc (is_it_electron , mass_modif , particle_mass_for_calc);
  
  const double hbar_omega = 2.0/(kinetic_factor*b*b);

  return hbar_omega;
}





// Calculation of yn(x) (HO). 
// ------------------------- - 
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// n, l : quantum numbers of the HO state.
// x, xi, xi_square : abscissa (fm), x/b
// y_HO : returned value

double HO_wave_functions::HO_1D::y (
				    const double b ,
				    const int n ,
				    const double x)
{
  const double xi = x/b;
  
  const double xi_square = xi*xi;
    
  const double y_HO = exp (-0.5*xi_square) * Gauss_Hermite::poly (n , xi) / sqrt (b);
  
  return y_HO;
}






// Calculation of yn'(x)(HO) 
// ---------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// n, l : quantum numbers of the HO state.
// x, xi, xi_square : abscissa (fm), x/b
// dy_HO : returned value

double HO_wave_functions::HO_1D::dy (
				     const double b ,
				     const int n ,
				     const double x) 
{ 
  const double xi = x/b;
  
  const double xi_square = xi * xi;

  const double dy_HO = exp (-0.5*xi_square) * (Gauss_Hermite::poly_der (n , xi) - xi * Gauss_Hermite::poly (n , xi))/(b*sqrt (b));

  return dy_HO;
} 







// Calculation of yn''(x) (HO). 
// ----------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// b, b2, b4: HO length (fm), b^2, b^4
// fx : x^2/b^4 - 1/b^2
// one_over_b2 , two_over_b2 : 1/(b^2) , 2/(b^2)
// n : quantum numbers of the HO state.
// x : abscissa (fm).
// fx : x^2/b^4 - 1/b^2
// d2y_HO : returned value

double HO_wave_functions::HO_1D::d2y (
				      const double b ,
				      const int n ,
				      const double x) 
{
  const double b2 = b * b;
  
  const double b4 = b2 * b2;
  
  const double one_over_b2 = 1.0/b2;
  const double two_over_b2 = 2.0/b2;
  
  const double x2 = x * x;
  
  const double fx = x2/b4 - one_over_b2;
  
  const double d2y_HO = (fx - n * two_over_b2) * y (b , n , x);

  return d2y_HO;
} 






// Calculation of a table of yn(x) (HO) for all n from 0 to n_max for a single x value
// ---------------------------------------------------------------------------------------
// 
// The Hermite polynomials are calculated with the recursion relation from 0 to n_max.
// 
//
// Variables:
// ----------
// n_max : number of n to calculate
// b : parameter of the HO potential (fm).
// n : quantum numbers of the HO state.
// x, xi, xi_square : abscissa (fm), x/b, [x/b]^2.
// norm_HO_factor : common factor to all HO wfs of all n
// Hermite_poly_table : table of Hermite polynomials H[n](xi) for n in [0:n_max].
// np1 , sqrt_two_over_np1 , sqrt_n_over_np1: n+1, sqrt (2/(n+1)), sqrt (n/(n+1))

void HO_wave_functions::HO_1D::y_single_x_tables_calc (
						       const double b ,
						       const double x ,
						       class array<double> &HO_wfs)
{
  const int n_max = HO_wfs.dimension(0) - 1;

  const double xi = x/b;
  
  const double xi_square = xi * xi;
  
  class array<double> Hermite_poly_table(n_max + 1);

  const double norm_HO_factor = exp (-0.5*xi_square) / sqrt (b);
  
  Hermite_poly_table(0) = Gauss_Hermite::poly (0 , xi);
  
  HO_wfs(0) = norm_HO_factor*Hermite_poly_table(0);

  if (n_max == 0) return;

  Hermite_poly_table(1) = Gauss_Hermite::poly (1 , xi);

  for (int n = 1 ; n < n_max ; n++)
    {
      const double np1 = n + 1;
      
      const double sqrt_two_over_np1 = sqrt (2.0/np1);
      
      const double sqrt_n_over_np1 = sqrt (n/np1);
	  
      HO_wfs(n) = norm_HO_factor * Hermite_poly_table(n);

      Hermite_poly_table(n + 1) = xi * sqrt_two_over_np1 * Hermite_poly_table(n) - sqrt_n_over_np1 * Hermite_poly_table(n - 1);
    }
  
  HO_wfs(n_max) = norm_HO_factor * Hermite_poly_table(n_max);
}













// Calculation of a table of yn(x) for all n from 0 to n_max and a table of x values
// ---------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// b: HO length (fm)
// r_tab : table of x values
// HO_wfs : tables of HO functions
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_n : HO functions for a given r and n from 0 to nmax_HO
// x, x2 : x_tab(i), x^2 

void HO_wave_functions::HO_1D::y_x_tables_calc (
						const double b ,
						const class array<double> &x_tab ,
						class array<double> &HO_wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  class array<double> HO_wfs_n(nmax_HO + 1);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      y_single_x_tables_calc (b , x , HO_wfs_n);

      for (int n = 0 ; n <= nmax_HO ; n++) HO_wfs(n , i) = HO_wfs_n(n);
    }
}










// Calculation of a table of yn(x) and yn'(x) for all n from 0 to n_max and a single x value
// -----------------------------------------------------------------------------------------
// 
// The Hermite polynomials and derivatives are calculated with the recursion relation from 0 to n_max.
// 
//
// Variables:
// ----------
// b: HO length (fm)
// x_tab : table of x values
// HO_wfs : tables of HO functions
// nmax_HO: maximal n considered
// N: number of x values
// norm_HO_factor : common factor to all HO wfs of all n
// norm_HO_factor_der : common factor to all HO wfs derivatives of all n
// HO_wfs_n : HO functions for a given r and n from 0 to nmax_HO
// x, x2 : x_tab(i), x^2
// Hermite_poly_table, dHermite_poly_table : table of Hermite polynomials H[n](xi) and derivatives for n in [0:n_max].
// Hn, dHn: Hermite polynomial and derivative of degree n

void HO_wave_functions::HO_1D::y_dy_single_x_tables_calc (
							  const double b , 
							  const double x , 
							  class array<double> &HO_wfs , 
							  class array<double> &HO_dwfs)
{
  const int n_max = HO_wfs.dimension(0) - 1;

  const double xi = x/b;
  
  const double xi_square = xi * xi;

  const double norm_HO_factor = exp (-0.5*xi_square) / sqrt (b);
  
  const double norm_HO_factor_der = norm_HO_factor/b;
  
  class array<double>  Hermite_poly_table(n_max + 1);
  class array<double> dHermite_poly_table(n_max + 1);

  Hermite_poly_table (0) = Gauss_Hermite::poly     (0 , xi);  
  dHermite_poly_table(0) = Gauss_Hermite::poly_der (0 , xi);
  
  
  HO_wfs(0) = norm_HO_factor*Hermite_poly_table(0);

  HO_dwfs(0) = -HO_wfs(0)*xi/b;
  
  if (n_max == 0) return;

  
  Hermite_poly_table (1) = Gauss_Hermite::poly     (1 , xi);
  dHermite_poly_table(1) = Gauss_Hermite::poly_der (1 , xi);

  for (int n = 1 ; n < n_max ; n++)
    { 
      const double np1 = n + 1;
      
      const double sqrt_two_over_np1 = sqrt (2.0/np1);
      
      const double xi_sqrt_two_over_np1 = xi*sqrt_two_over_np1;
      
      const double sqrt_n_over_np1 = sqrt (n/np1);

      const double  Hn =  Hermite_poly_table(n);
      const double dHn = dHermite_poly_table(n);
   
      HO_wfs(n)  = norm_HO_factor * Hn;

      HO_dwfs(n) = norm_HO_factor_der * (dHn  - xi*Hn);

      Hermite_poly_table (n + 1) = xi_sqrt_two_over_np1 *  Hermite_poly_table(n) - sqrt_n_over_np1 *  Hermite_poly_table(n - 1);
      dHermite_poly_table(n + 1) = xi_sqrt_two_over_np1 * dHermite_poly_table(n) - sqrt_n_over_np1 * dHermite_poly_table(n - 1) + sqrt_two_over_np1 * Hermite_poly_table(n);
    }
  
  HO_wfs (n_max) = norm_HO_factor * Hermite_poly_table(n_max);
  
  HO_dwfs(n_max) = norm_HO_factor_der * (dHermite_poly_table(n_max) - xi*Hermite_poly_table(n_max));
}








// Calculation of a table of yn(x), yn'(x) for all n from 0 to n_max and a table of x values
// -----------------------------------------------------------------------------------------
//
// Variables:
// ----------
// b: HO length (fm)
// x_tab : table of x values
// HO_wfs, HO_dwfs : tables of HO functions and first derivatives
// nmax_HO: maximal n considered
// N: number of x values
// HO_wfs_n, HO_dwfs_n : HO functions and derivatives for a given x and n from 0 to nmax_HO
// x, x2 : x_tab(i), x^2

void HO_wave_functions::HO_1D::y_dy_x_tables_calc (
						   const double b , 
						   const class array<double> &x_tab , 
						   class array<double> &HO_wfs , 
						   class array<double> &HO_dwfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  class array<double> HO_wfs_n(nmax_HO + 1);
  
  class array<double> HO_dwfs_n(nmax_HO + 1);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      y_dy_single_x_tables_calc (b , x , HO_wfs_n , HO_dwfs_n);

      for (int n = 0 ; n <= nmax_HO ; n++)
	{
	  HO_wfs(n , i) = HO_wfs_n(n);

	  HO_dwfs(n , i) = HO_dwfs_n(n);
	}
    }
}









// Calculation of a table of yn(x), yn'(x) and u''(n, l)(x) (HO) for all n from 0 to n_max and a table of x values
// --------------------------------------------------------------------------------------------------------------- - 
//
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// b, b2, b4: HO length (fm), b^2, b^4
// n : quantum numbers of the HO state.
// fx : x^2/b^4 - 1/b^2
// one_over_b2 , two_over_b2 : 1/(b^2) , 2/(b^2)
// x_tab : table of x values
// HO_wfs, HO_dwfs, HO_d2wfs : tables of HO functions, first and second derivatives
// nmax_HO: maximal n considered
// N: number of x values
// x, x2 : x_tab(i), x^2

void HO_wave_functions::HO_1D::y_dy_d2y_x_tables_calc (
						       const double b , 
						       const class array<double> &x_tab , 
						       class array<double> &HO_wfs , 
						       class array<double> &HO_dwfs , 
						       class array<double> &HO_d2wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;

  const unsigned int N = HO_wfs.dimension (1);

  const double b2 = b * b;
  
  const double b4 = b2 * b2;
  
  const double one_over_b2 = 1.0/b2;
  const double two_over_b2 = 2.0/b2;

  y_dy_x_tables_calc (b , x_tab , HO_wfs , HO_dwfs);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double x2 = x * x;
      
      const double fx = x2/b4 - one_over_b2;

      for (int n = 0 ; n <= nmax_HO ; n++) HO_d2wfs(n , i) = (fx - n * two_over_b2) * HO_wfs(n , i);
    }
}




// <n' HO | p^2/(2 m) | n HO> matrix element. It is analytical.

double HO_wave_functions::HO_1D::OBME_kinetic_HO_calc (
						       const int n_in ,
						       const int n_out ,
						       const double hbar_omega)
{
  if (n_in == n_out - 2) 
    {
      const double OBME_kinetic = -0.25*sqrt (n_out*(n_out - 1))*hbar_omega;
      
      return OBME_kinetic;
    }
  else if (n_in == n_out) 
    {
      const double OBME_kinetic = 0.5*(n_out + 0.5)*hbar_omega;

      return OBME_kinetic;
    }
  else if (n_in == n_out + 2) 
    {
      const double OBME_kinetic = -0.25*sqrt (n_in*(n_in - 1))*hbar_omega;

      return OBME_kinetic;
    }
  else 
    return 0.0;
}




// <n' HO | x^2 | n HO> matrix element. It is analytical.

double HO_wave_functions::HO_1D::OBME_x2_HO_calc (const int n_in , const int n_out , const double b)
{
  const double b2 = b*b;

  if (n_in == n_out - 2) 
    {
      const double OBME_x2 = 0.5*sqrt (n_out*(n_out - 1))*b2;

      return OBME_x2;
    }
  else if (n_in == n_out) 
    {
      const double OBME_x2 = (n_out + 0.5)*b2;

      return OBME_x2;
    }
  else if (n_in == n_out + 2) 
    {
      const double OBME_x2 = 0.5*sqrt (n_in*(n_in - 1))*b2;

      return OBME_x2;
    }
  else 
    return 0.0;
}











// Calculation of the constant C0 so u(n, l)(r or k) -> C0.pow (r or k, l + 1) for r or k -> 0
// ----------------------------------------------------------------------------------

double HO_wave_functions::HO_3D::C0_calc (
					  const double b ,
					  const int n ,
					  const int l)
{
  const double norm_HO = sqrt (2.0 * exp (lgamma (n + 1.0) - lgamma (n + l + 1.5))/b);
  
  const double Laguerre_poly_zero = Gauss_Laguerre::poly (n , l + 0.5 , 0.0)/pow (b , l + 1);

  const double C0 = norm_HO * Laguerre_poly_zero;

  return C0;
}

double HO_wave_functions::HO_3D::C0_momentum_calc (
						   const double bk ,
						   const int n ,
						   const int l)
{
  return (minus_one_pow (n) * C0_calc (bk , n , l));
}





// Calculation of u(n, l)(r or k) (HO). 
// --------------------------------- 
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// bk : parameter of the HO potential (fm^{ - 1}).
// n, l : quantum numbers of the HO state.
// r, rho, rho_square : radius (fm), r/b, [r/b]^2.
// k , kappa, kappa_suqare : momentum (fm^{ - 1}), k/bk, [k/bk]^2.
// u_HO : returned value

double HO_wave_functions::HO_3D::u (
				    const double b ,
				    const int n ,
				    const int l ,
				    const double r)
{
  const double norm_HO = sqrt (2.0 * exp (lgamma (n + 1.0) - lgamma (n + l + 1.5))/b);

  const double rho = r/b;
  
  const double rho_square = rho * rho;
  
  const double u_HO = norm_HO * pow (rho , l + 1) * exp (-0.5*rho_square) * Gauss_Laguerre::poly (n , l + 0.5 , rho_square);

  return u_HO;
}



double HO_wave_functions::HO_3D::u_momentum (
					     const double bk ,
					     const int n ,
					     const int l ,
					     const double k)
{
  return (minus_one_pow (n) * u (bk , n , l , k));
}





// Calculation of u'(n, l)(r or k) (HO). 
// ---------------------------------- 
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// bk : parameter of the HO potential (fm^{ - 1}).
// n, l : quantum numbers of the HO state.
// r, rho, rho_square : radius (fm), r/b, [r/b]^2.
// k , kappa, kappa_suqare : momentum (fm^{ - 1}), k/bk, [k/bk]^2.
// u_HO : returned value
// du_HO : returned value

double HO_wave_functions::HO_3D::du (
				     const double b ,
				     const int n ,
				     const int l ,
				     const double r) 
{ 
  const double norm_HO = sqrt (2.0 * exp (lgamma (n + 1.0) - lgamma (n + l + 1.5))/b)/b;

  const double rho = r/b;
  
  const double rho_square = rho * rho;

  const double Laguerre_term = Gauss_Laguerre::poly (n , l + 0.5 , rho_square) * (l + 1.0 - rho_square) + 2.0 * rho_square * Gauss_Laguerre::poly_der (n , l + 0.5 , rho_square);

  const double du_HO = norm_HO * pow (rho , l) * exp (-0.5*rho_square) * Laguerre_term;

  return du_HO;
} 





double HO_wave_functions::HO_3D::du_momentum (
					      const double bk ,
					      const int n ,
					      const int l ,
					      const double k) 
{ 
  return (minus_one_pow (n) * du (bk , n , l , k));
}





// Calculation of u''(n, l)(r or k) (HO). 
// -----------------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// b, b2, b4: HO length (fm), b^2, b^4
// bk, bk2, bk4: HO momentum (fm^{ - 1}), bk^2, bk^4
// n, l : quantum numbers of the HO state.
// r : radius (fm).
// k : momentum (fm^{ - 1})
// llp1: l(l + 1)
// fr : l(l+1)/r2 + r^2/b^4 - (2 * l + 3)/b2
// fk : l(l+1)/k^2 + k^2/bk^4 - (2l + 3)/bk^2
// four_over_bk2 : 4/bk^2
// two_l_p3_over_bk2: (2l + 3)/bk^2 
// four_over_b2 : 4/b^2
// two_l_p3_over_b2 : (2l + 3)/b^2
// d2u_HO : returned value

double HO_wave_functions::HO_3D::d2u (
				      const double b ,
				      const int n ,
				      const int l ,
				      const double r) 
{
  if (r == 0.0)
    {
      return (l == 1) ? (2.0 * C0_calc (b , n , l)) : (0.0);
    }

  const double llp1 = l * (l + 1);
  
  const double b2 = b * b;
  
  const double b4 = b2 * b2;
  
  const double four_over_b2 = 4.0/b2;
  
  const double two_l_p3_over_b2 = (2 * l + 3)/b2;

  const double r2 = r * r;
  
  const double fr = llp1/r2 + r2/b4 - two_l_p3_over_b2;
  
  const double d2u_HO = (fr - n * four_over_b2) * u (b , n , l , r);

  return d2u_HO;
} 





double HO_wave_functions::HO_3D::d2u_momentum (
					       const double bk ,
					       const int n ,
					       const int l ,
					       const double k) 
{ 
  return (minus_one_pow (n) * d2u (bk , n , l , k));
}





// Calculation of a table of u(n, l)(r or k) (HO) for all n from 0 to n_max for a single r or k value
// ---------------------------------------------------------------------------------------------
// 
// The Laguerre polynomials are calculated with the recursion relation from 0 to n_max.
// 
//
// Variables:
// ----------
// a : l + 0.5
// 
// minus_rho2_plus_ap1 : - [r/b]^2 + a + 1
// n_max : number of n to calculate
// b : parameter of the HO potential (fm).
// bk : parameter of the HO potential (fm^{ - 1}).
// n, l : quantum numbers of the HO state.
// norm_HO_factor : common factor to all HO wfs of all n
// r or k, rho, rho_square : radius (fm) or momentum (fm^(-1)), r/b, [r/b]^2.
// factor : pow (rho or kappa , l + 1) * exp (-(rho^2 or kappa^2)/2)
// Laguerre_poly_table : table of Laguerre polynomials P[n, l + 0.5](rho_square) for n in [0:n_max].
// m_kappa2_plus_ap1 : - [k/bk]^2 + a + 1


void HO_wave_functions::HO_3D::u_single_r_tables_calc (
						       const double b ,
						       const int l ,
						       const double r ,
						       class array<double> &HO_wfs)
{
  const int n_max = HO_wfs.dimension(0) - 1;

  const double rho = r/b;
  
  const double rho_square = rho * rho;
  
  const double a = l + 0.5;

  const double minus_rho2_plus_ap1 = - rho_square + a + 1.0;

  const double factor = pow (rho , l + 1) * exp (-0.5*rho_square);

  class array<double> Laguerre_poly_table(n_max + 1);

  Laguerre_poly_table(0) = Gauss_Laguerre::poly (0 , a , rho_square);

  double norm_HO_factor = sqrt (2.0 * exp ( - lgamma (l + 1.5))/b) * factor;
  
  HO_wfs(0) = norm_HO_factor;

  if (n_max == 0) return;

  Laguerre_poly_table(1) = Gauss_Laguerre::poly (1 , a , rho_square);

  for (int n = 1 ; n < n_max ; n++)
    {
      norm_HO_factor *= sqrt (n/(n + a));

      HO_wfs(n) = norm_HO_factor * Laguerre_poly_table(n);

      Laguerre_poly_table(n + 1) = ((minus_rho2_plus_ap1 + 2 * n) * Laguerre_poly_table(n) - (n + a) * Laguerre_poly_table(n - 1))/(n + 1.0);
    }

  norm_HO_factor *= sqrt (n_max/(n_max + a));
  
  HO_wfs(n_max) = norm_HO_factor * Laguerre_poly_table(n_max);
}





void HO_wave_functions::HO_3D::u_single_k_tables_calc (
						       const double bk ,
						       const int l ,
						       const double k ,
						       class array<double> &HO_wfs)
{
  u_single_r_tables_calc (bk , l , k , HO_wfs);

  const int n_max = HO_wfs.dimension(0) - 1;
  
  for (int n = 1 ; n <= n_max ; n += 2) HO_wfs(n) = -HO_wfs(n);
}









// Calculation of a table of u(n, l)(r or k) for all n from 0 to n_max and a table of r or k values
// --------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// b: HO length (fm)
// bk: HO momentum (fm^{ - 1})
// r_tab, k_tab : table of r or k values
// HO_wfs : tables of HO functions
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_n : HO functions for a given r and n from 0 to nmax_HO
// r, r2 : r_tab(i), r^2

void HO_wave_functions::HO_3D::u_r_tables_calc (
						const double b ,
						const int l ,
						const class array<double> &r_tab ,
						class array<double> &HO_wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  class array<double> HO_wfs_n(nmax_HO + 1);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double r = r_tab(i);

      u_single_r_tables_calc (b , l , r , HO_wfs_n);

      for (int n = 0 ; n <= nmax_HO ; n++) HO_wfs(n , i) = HO_wfs_n(n);
    }
}






void HO_wave_functions::HO_3D::u_k_tables_calc (
						const double bk ,
						const int l ,
						const class array<double> &k_tab ,
						class array<double> &HO_wfs)
{
  u_r_tables_calc (bk , l , k_tab , HO_wfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (unsigned int i = 0 ; i < N ; i++)
      HO_wfs(n , i) = -HO_wfs(n , i);
}









// Calculation of a table of u(n, l)(r or k) for all n from 0 to n_max and a table of l and r or k values
// --------------------------------------------------------------------------------------------------
// Variables:
// ----------
// lmax_HO: largest orbital momentum
// b: HO length (fm)
// bk: HO momentum (fm^{ - 1})
// r_tab, k_tab : table of r or k values
// HO_wfs : tables of HO functions
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_one_l : HO functions for a given l and n in 0 to nmax_HO and r in r_tab
// r, r2 : r_tab(i), r^2

void HO_wave_functions::HO_3D::u_r_tables_calc (
						const double b ,
						const class array<double> &r_tab ,
						class array<double> &HO_wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;

  const unsigned int N = HO_wfs.dimension (2);

  class array<double> HO_wfs_one_l(nmax_HO + 1 , N);

  for (int l = 0 ; l <= lmax_HO ; l ++ )
    {
      u_r_tables_calc (b , l , r_tab , HO_wfs_one_l);

      for (int n = 0 ; n <= nmax_HO ; n++) 
	for (unsigned int i = 0 ; i < N ; i++)
	  HO_wfs(n , l , i) = HO_wfs_one_l(n , i);
    } 
}





void HO_wave_functions::HO_3D::u_k_tables_calc (
						const double bk ,
						const class array<double> &k_tab ,
						class array<double> &HO_wfs)
{
  u_r_tables_calc (bk , k_tab , HO_wfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;
  
  const unsigned int N = HO_wfs.dimension (2);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (int l = 0 ; l <= lmax_HO ; l++)
      for (unsigned int i = 0 ; i < N ; i++)
	HO_wfs(n , l , i) = -HO_wfs(n , l , i);
}




// Calculation of a table of u(n, l)(r or k) and u'(n, l)(r) (HO) for all n from 0 to n_max for a single r or k value
// ------------------------------------------------------------------------------------------------------------
// 
// The Laguerre polynomials and derivatives are calculated with the recursion relation from 0 to n_max.
// 
//
// Variables:
// ----------
// a : l + 0.5
// 
// minus_rho2_plus_ap1 : - [r/b]^2 + a + 1
// n_max : number of n to calculate
// b : parameter of the HO potential (fm).
// bk : parameter of the HO potential (fm^(-1)).
// n, l : quantum numbers of the HO state.
// r, rho, rho_square, lp1_minus_rho_square, two_rho_square : radius (fm), r/b, [r/b]^2, l + 1 - [r/b]^2, 2.[r/b]^2.
// Laguerre_poly_table, dLaguerre_poly_table : table of Laguerre polynomials P[n, l + 0.5](rho_square) and derivatives with respect to rho^2 for n in [0:n_max].
// Ln, dLn: Laguerre polynomial and derivative of degree n
// n, l : quantum numbers of the HO state.
// N: number of r or k values
// norm_HO_factor : common factor to all HO wfs and derivatives of all n


void HO_wave_functions::HO_3D::u_du_single_r_tables_calc (
							  const double b , 
							  const int l , 
							  const double r , 
							  class array<double> &HO_wfs , 
							  class array<double> &HO_dwfs)
{
  const int n_max = HO_wfs.dimension(0) - 1;

  const double rho = r/b;

  const double rho_square = rho * rho;

  const double a = l + 0.5;

  const double minus_rho2_plus_ap1 = - rho_square + a + 1.0;

  const double lp1_minus_rho_square = l + 1.0 - rho_square;

  const double two_rho_square = 2.0 * rho_square;

  class array<double>  Laguerre_poly_table(n_max + 1);
  class array<double> dLaguerre_poly_table(n_max + 1);

  Laguerre_poly_table (0) = Gauss_Laguerre::poly     (0 , a , rho_square);
  dLaguerre_poly_table(0) = Gauss_Laguerre::poly_der (0 , a , rho_square);

  double norm_HO_factor = sqrt (2.0 * exp (-lgamma (l + 1.5))/b) * pow (rho , l) * exp (-0.5*rho_square)/b;
  
  HO_wfs(0) = norm_HO_factor * r;
  
  HO_dwfs(0) = norm_HO_factor * (Laguerre_poly_table(0) * lp1_minus_rho_square + two_rho_square * dLaguerre_poly_table(0));

  if (n_max == 0) return;

  Laguerre_poly_table (1) = Gauss_Laguerre::poly     (1 , a , rho_square);
  dLaguerre_poly_table(1) = Gauss_Laguerre::poly_der (1 , a , rho_square);

  for (int n = 1 ; n < n_max ; n++)
    { 
      norm_HO_factor *= sqrt (n/(n + a));
 
      const double one_over_np1 = 1.0/(n + 1);

      const double n_plus_a = n + a;

      const double minus_rho2_plus_ap1_plus_2n = minus_rho2_plus_ap1 + 2 * n;

      const double  Ln =  Laguerre_poly_table(n);
      const double dLn = dLaguerre_poly_table(n);

      HO_wfs(n)  = norm_HO_factor * r * Ln;
      HO_dwfs(n) = norm_HO_factor * (Ln * lp1_minus_rho_square + two_rho_square * dLn);

      Laguerre_poly_table (n + 1) = (minus_rho2_plus_ap1_plus_2n * Ln  - n_plus_a *  Laguerre_poly_table(n - 1))      * one_over_np1;
      dLaguerre_poly_table(n + 1) = (minus_rho2_plus_ap1_plus_2n * dLn - n_plus_a * dLaguerre_poly_table(n - 1) - Ln) * one_over_np1;
    }

  norm_HO_factor *= sqrt (n_max/(n_max + a));
    
  HO_wfs(n_max) = norm_HO_factor * r * Laguerre_poly_table(n_max);

  HO_dwfs(n_max) = norm_HO_factor * (Laguerre_poly_table(n_max) * lp1_minus_rho_square + two_rho_square * dLaguerre_poly_table(n_max));
}





void HO_wave_functions::HO_3D::u_du_single_k_tables_calc (
							  const double bk , 
							  const int l , 
							  const double k , 
							  class array<double> &HO_wfs , 
							  class array<double> &HO_dwfs)
{
  u_du_single_r_tables_calc (bk , l , k , HO_wfs , HO_dwfs);

  const int n_max = HO_wfs.dimension(0) - 1;
  
  for (int n = 1 ; n <= n_max ; n += 2)
    {
      HO_wfs (n) = -HO_wfs (n);
      HO_dwfs(n) = -HO_dwfs(n);
    }
}


// Calculation of a table of u(n, l)(r or k) and u'(n, l)(r or k) for all n from 0 to n_max and a table of r or k values
// ------------------------------------------------------------------------------------------------------------ - 
// Variables:
// ----------
// l: orbital momentum
// b: HO length (fm)
// bk: HO momentum (fm^{ - 1})
// r_tab, k_tab : table of r or k values
// HO_wfs, HO_dwfs : tables of HO functions and first derivatives
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_n, HO_dwfs_n : HO functions and derivatives for a given r and n from 0 to nmax_HO
// r, r2 : r_tab(i), r^2

void HO_wave_functions::HO_3D::u_du_r_tables_calc (
						   const double b , 
						   const int l , 
						   const class array<double> &r_tab , 
						   class array<double> &HO_wfs , 
						   class array<double> &HO_dwfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;

  const unsigned int N = HO_wfs.dimension (1);

  class array<double> HO_wfs_n(nmax_HO + 1);

  class array<double> HO_dwfs_n(nmax_HO + 1);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double r = r_tab(i);
      
      u_du_single_r_tables_calc (b , l , r , HO_wfs_n , HO_dwfs_n);

      for (int n = 0 ; n <= nmax_HO ; n++)
	{
	  HO_wfs(n , i) = HO_wfs_n(n);
	  
	  HO_dwfs(n , i) = HO_dwfs_n(n);
	}
    }
}




void HO_wave_functions::HO_3D::u_du_k_tables_calc (
						   const double bk , 
						   const int l , 
						   const class array<double> &k_tab , 
						   class array<double> &HO_wfs , 
						   class array<double> &HO_dwfs)
{
  u_du_r_tables_calc (bk , l , k_tab , HO_wfs , HO_dwfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (unsigned int i = 0 ; i < N ; i++)
      {
	HO_wfs (n , i) = -HO_wfs (n , i);
	HO_dwfs(n , i) = -HO_dwfs(n , i);
      }
}




// Calculation of a table of u(n, l)(r or k) and u'(n, l)(r or k) for all n from 0 to n_max and a table of l and r or k values
// ------------------------------------------------------------------------------------------------------------------ - 
// Variables:
// ----------
// lmax_HO: largest orbital momentum
// b: HO length (fm)
// bk: HO momentum (fm^{ - 1})
// r_tab, k_tab : table of r or k values
// HO_wfs, HO_dwfs : tables of HO functions and first derivatives
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_one_l, HO_dwfs_one_l : HO functions and derivatives for a given l and n in 0 to nmax_HO and r in r_tab
// r, r2 : r_tab(i), r^2

void HO_wave_functions::HO_3D::u_du_r_tables_calc (
						   const double b , 
						   const class array<double> &r_tab , 
						   class array<double> &HO_wfs , 
						   class array<double> &HO_dwfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;

  const unsigned int N = HO_wfs.dimension (2);

  class array<double> HO_wfs_one_l(nmax_HO + 1 , N);
  
  class array<double> HO_dwfs_one_l(nmax_HO + 1 , N);

  for (int l = 0 ; l <= lmax_HO ; l ++ )
    {
      u_du_r_tables_calc (b , l , r_tab , HO_wfs_one_l , HO_dwfs_one_l);

      for (int n = 0 ; n <= nmax_HO ; n++) 
	{
	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      HO_wfs(n , l , i) = HO_wfs_one_l(n , i);
	      
	      HO_dwfs(n , l , i) = HO_dwfs_one_l(n , i);
	    }
	}
    } 
}






void HO_wave_functions::HO_3D::u_du_k_tables_calc (
						   const double bk , 
						   const class array<double> &k_tab , 
						   class array<double> &HO_wfs , 
						   class array<double> &HO_dwfs)
{
  u_du_r_tables_calc (bk , k_tab , HO_wfs , HO_dwfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;
  
  const unsigned int N = HO_wfs.dimension (2);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (int l = 0 ; l <= lmax_HO ; l ++ )
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  HO_wfs (n , l , i) = -HO_wfs (n , l , i);
	  HO_dwfs(n , l , i) = -HO_dwfs(n , l , i);
	}
}




// Calculation of a table of u(n, l)(r or k), u'(n, l)(r or k) and u''(n, l)(r or k) (HO) for all n from 0 to n_max and a table of r or k values
// -------------------------------------------------------------------------------------------------------------------------------- - 
// Variables:
// ----------
// l: orbital momentum
// b, b2, b4: HO length (fm), b^2, b^4
// bk : HO momentum (fm^{ - 1})
// r_tab, k_tab : table of r or k values
// HO_wfs, HO_dwfs, HO_d2wfs : tables of HO functions, first and second derivatives
// nmax_HO: maximal n considered
// N: number of r values
// llp1: l(l + 1)
// HO_wfs_one_l, HO_dwfs_one_l : HO functions and derivatives for a given l and n in 0 to nmax_HO and r in r_tab
// r, r2 : r_tab(i), r^2
// fr : l(l+1)/r^2 + r^2/b^4 - (2l + 3)/b^2
// four_over_b2 : 4/b^2
// two_l_p3_over_b2: (2l + 3)/b^2

void HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (
						       const double b , 
						       const int l , 
						       const class array<double> &r_tab , 
						       class array<double> &HO_wfs , 
						       class array<double> &HO_dwfs , 
						       class array<double> &HO_d2wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  const double llp1 = l * (l + 1);
  
  const double b2 = b * b;
  
  const double b4 = b2 * b2;
  
  const double four_over_b2 = 4.0/b2;
  
  const double two_l_p3_over_b2 = (2 * l + 3)/b2;

  u_du_r_tables_calc (b , l , r_tab , HO_wfs , HO_dwfs);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double r = r_tab(i);

      if (r != 0.0)
	{
	  const double r2 = r * r;
	  
	  const double fr = llp1/r2 + r2/b4 - two_l_p3_over_b2;

	  for (int n = 0 ; n <= nmax_HO ; n++) HO_d2wfs(n , i) = (fr - n * four_over_b2) * HO_wfs(n , i);
	}
      else if (l == 1)
	{
	  for (int n = 0 ; n <= nmax_HO ; n++) HO_d2wfs(n , i) = 2.0 * C0_calc (b , n , l);
	}
      else
	{
	  for (int n = 0 ; n <= nmax_HO ; n++) HO_d2wfs(n , i) = 0.0;
	}
    }
}




void HO_wave_functions::HO_3D::u_du_d2u_k_tables_calc (
						       const double bk , 
						       const int l , 
						       const class array<double> &k_tab , 
						       class array<double> &HO_wfs , 
						       class array<double> &HO_dwfs , 
						       class array<double> &HO_d2wfs)
{
  u_du_d2u_r_tables_calc (bk , l , k_tab , HO_wfs , HO_dwfs , HO_d2wfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  
  const unsigned int N = HO_wfs.dimension (1);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (unsigned int i = 0 ; i < N ; i++)
      {
	HO_wfs  (n , i) = -HO_wfs  (n , i);
	HO_dwfs (n , i) = -HO_dwfs (n , i);
	HO_d2wfs(n , i) = -HO_d2wfs(n , i);
      }
}





// Calculation of a table of u(n, l)(r or k), u'(n, l)(r or k) and u''(n, l)(r or k) (HO) for all n from 0 to n_max and a table of l and r or k values
// -------------------------------------------------------------------------------------------------------------------------------------- - 
// Variables:
// ----------
// lmax_HO: maximal orbital momentum
// r_tab, k_tab : table of r or k values
// HO_wfs, HO_dwfs, HO_d2wfs : tables of HO functions, first and second derivatives
// nmax_HO: maximal n considered
// N: number of r values
// HO_wfs_one_l, HO_dwfs_one_l : HO functions and derivatives for a given l and n from 0 to nmax_HO and r in r_tab

void HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (
						       const double b , 
						       const class array<double> &r_tab , 
						       class array<double> &HO_wfs , 
						       class array<double> &HO_dwfs , 
						       class array<double> &HO_d2wfs)
{
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;

  const unsigned int N = HO_wfs.dimension (2);

  class array<double> HO_wfs_one_l(nmax_HO + 1 , N);

  class array<double> HO_dwfs_one_l(nmax_HO + 1 , N);

  class array<double> HO_d2wfs_one_l(nmax_HO + 1 , N);

  for (int l = 0 ; l <= lmax_HO ; l ++ )
    {
      u_du_d2u_r_tables_calc (b , l , r_tab , HO_wfs_one_l , HO_dwfs_one_l , HO_d2wfs_one_l);

      for (int n = 0 ; n <= nmax_HO ; n++) 
	{
	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      HO_wfs  (n , l , i) = HO_wfs_one_l  (n , i);
	      HO_dwfs (n , l , i) = HO_dwfs_one_l (n , i);
	      HO_d2wfs(n , l , i) = HO_d2wfs_one_l(n , i);
	    }
	}
    }
}


void HO_wave_functions::HO_3D::u_du_d2u_k_tables_calc (
						       const double bk , 
						       const class array<double> &k_tab , 
						       class array<double> &HO_wfs , 
						       class array<double> &HO_dwfs , 
						       class array<double> &HO_d2wfs)
{
  u_du_d2u_r_tables_calc (bk , k_tab , HO_wfs , HO_dwfs , HO_d2wfs);
    
  const int nmax_HO = HO_wfs.dimension (0) - 1;
  const int lmax_HO = HO_wfs.dimension (1) - 1;

  const unsigned int N = HO_wfs.dimension (2);

  for (int n = 1 ; n <= nmax_HO ; n += 2)
    for (int l = 0 ; l <= lmax_HO ; l ++ )
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  HO_wfs  (n , l , i) = -HO_wfs  (n , l , i);
	  HO_dwfs (n , l , i) = -HO_dwfs (n , l , i);
	  HO_d2wfs(n , l , i) = -HO_d2wfs(n , l , i);
	}
}


// <n' l HO | p^2/(2 m) | n l HO> matrix element. It is analytical.

double HO_wave_functions::HO_3D::OBME_kinetic_HO_calc (
						       const int l ,
						       const int n_in ,
						       const int n_out ,
						       const double hbar_omega)
{
  if (n_in == n_out - 1) 
    {
      const double OBME_kinetic = 0.5*sqrt (n_out*(n_out + l + 0.5))*hbar_omega;
      
      return OBME_kinetic;
    }
  else if (n_in == n_out) 
    {
      const double OBME_kinetic = (n_out + 0.5*l + 0.75)*hbar_omega;

      return OBME_kinetic;
    }
  else if (n_in == n_out + 1) 
    {
      const double OBME_kinetic = 0.5*sqrt ((n_out + 1)*(n_out + l + 1.5))*hbar_omega;

      return OBME_kinetic;
    }
  else 
    return 0.0;
}




// <n' l HO | r^2 | n l HO> matrix element. It is analytical.

double HO_wave_functions::HO_3D::OBME_r2_HO_calc (const int l , const int n_in , const int n_out , const double b)
{
  const double b2 = b*b;

  if (n_in == n_out - 1) 
    {
      const double OBME_r2 = -sqrt (n_out*(n_out + l + 0.5))*b2;

      return OBME_r2;
    }
  else if (n_in == n_out) 
    {
      const double OBME_r2 = (2*n_out + l + 1.5)*b2;

      return OBME_r2;
    }
  else if (n_in == n_out + 1) 
    {
      const double OBME_r2 = -sqrt ((n_out + 1)*(n_out + l + 1.5))*b2;

      return OBME_r2;
    }
  else 
    return 0.0;
}




// Calculation of the r^2 integral between HO states of the same HO major shell with b=1.
// --------------------------------------------------------------------------------------
// If l_in != l_out, the integrand is even so that one integrates with a Gauss-Hermite integration.
// The integral is exact for a number of points equal to E[HO] + 3.

double HO_wave_functions::HO_3D::r2_radial_integral_same_major_shell_b_is_one_calc (
										    const int n_in  , const int l_in ,
										    const int n_out , const int l_out)
{
  const int E_in  = 2*n_in  + l_in;
  const int E_out = 2*n_out + l_out;
  
  if (E_in != E_out) error_message_print_abort ("HO states must belong to the same HO major shell in HO_wave_functions::HO_3D::r2_radial_integral_same_major_shell_b_is_one_calc");
  
  const double norm_factor = sqrt (exp (lgamma (n_in + 1.0) + lgamma (n_out + 1.0) - lgamma (n_in + l_in + 1.5) - lgamma (n_out + l_out + 1.5)));

  const int l_exponent = (l_in + l_out)/2 + 2;

  const double l_in_plus_half  = l_in  + 0.5;
  const double l_out_plus_half = l_out + 0.5;
  
  const unsigned int N = E_in + 3;
 
  class array<double> r_table(N);
  class array<double> w_table(N);
    
  Gauss_Hermite::abscissas_weights_tables_calc (r_table , w_table);

  double OBME_r2 = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double r = r_table(i);
      const double w = w_table(i);

      const double r2 = r*r;

      OBME_r2 += pow (r2 , l_exponent)*Gauss_Laguerre::poly (n_in , l_in_plus_half , r2)*Gauss_Laguerre::poly (n_out , l_out_plus_half , r2)*w;
    }

  OBME_r2 *= norm_factor;
  
  return OBME_r2;
}




// <n' l' HO || q || n l HO> = b^(-2) <n' l' HO || r^2 Y2(\hat{r}) || n l HO> + b^2 <n' l' HO || k^2 Y2(\hat{k}) || n l HO> matrix element.
// q is the quadrupole operator. It is closed in a major shell and is the building block of the SU(3) Q.Q interaction.
// The matrix element is equal to 2.b^(-2) <n' l' HO || r^2 Y2(\hat{r}) || n l HO> on a major shell and zero otherwise.
// This arises because HO wave functions are multiplied by (-1)^n due to their radial/momentum part and by (-i)^l due to their angular part.
// b is not given a input as it cancels out in the q matrix element. Hence, one uses b = 1.
// The r^2 integral is calculated either from OBME_r2_HO_calc if l_in = l_out.
// If l_in != l_out, the integrand is even so that one integrates with a Gauss-Hermite integration.
// The integral is exact for a number of points equal to E[HO] + 3.
// The q^2 operator matrix element is calculated with the Wigner-Eckhart theorem using l-coupled q matrix elements.
// As one has only one (l,j) state per major shell, the q^2 operator is diagonal.
// The q^2 operator matrix element is independent of the value of j, so that it is function of n and l only.
// The two-body matrix elements q1.q2 are also calculated with l-coupling and j-coupling.


double HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_l_calc (
							      const int n_in  , const int l_in ,
							      const int n_out , const int l_out)
{
  const int E_in  = 2*n_in  + l_in;
  const int E_out = 2*n_out + l_out;

  if (E_in != E_out) return 0.0;

  if (abs (l_in - l_out) > 2) return 0.0;
  
  if (l_in + l_out < 2) return 0.0;
  
  const double OBME_Y2 = angular_matrix_elements::OBME_YL_reduced_in_l (2 , l_in , l_out);

  if (OBME_Y2 == 0.0) return 0.0;

  const double sqrt_16_Pi_over_5 = 3.1706618380848088;
    
  const double OBME_r2 = (l_in == l_out) ? (2*n_in + l_in + 1.5) : (r2_radial_integral_same_major_shell_b_is_one_calc (n_in , l_in , n_out , l_out));
      
  const double OBME_q = sqrt_16_Pi_over_5*OBME_Y2*OBME_r2;
      
  return OBME_q;
}


double HO_wave_functions::HO_3D::OBME_q_HO_reduced_in_j_calc (
							      const int n_in  , const int l_in  , const double j_in ,
							      const int n_out , const int l_out , const double j_out)
{
  const int E_in  = 2*n_in  + l_in;
  const int E_out = 2*n_out + l_out;

  if (E_in != E_out) return 0.0;

  if (abs (l_in - l_out) > 2) return 0.0;
  
  if (l_in + l_out < 2) return 0.0;
  
  const double OBME_Y2 = angular_matrix_elements::OBME_YL_reduced_in_j (2 , l_in , j_in , l_out , j_out);

  if (OBME_Y2 == 0.0) return 0.0;
  
  const double sqrt_16_Pi_over_5 = 3.1706618380848088;
  
  const double OBME_r2 = (l_in == l_out) ? (2*n_in + l_in + 1.5) : (r2_radial_integral_same_major_shell_b_is_one_calc (n_in , l_in , n_out , l_out));
      
  const double OBME_q = sqrt_16_Pi_over_5*OBME_Y2*OBME_r2;
      
  return OBME_q;
}


double HO_wave_functions::HO_3D::OBME_q2_HO_calc (const int n , const int l)
{
  const int E = 2*n + l;

  const int lmin = (l%2 == 0) ? (0) : (1);

  double OBME_q2 = 0.0;
  
  for (int lp = lmin ; lp <= E ; lp += 2)
    {
      const int np = (E - lp)/2;

      const double OBME_q = OBME_q_HO_reduced_in_l_calc (n , l , np , lp);
  
      OBME_q2 += OBME_q*OBME_q;
    }

  OBME_q2 /= 2*l + 1;
  
  return OBME_q2;
}




double HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_calc (
							    const int na , const int la ,
							    const int nb , const int lb , 
							    const int nc , const int lc ,
							    const int nd , const int ld , 
							    const int L)
{
  const double q1_reduced_in_l = OBME_q_HO_reduced_in_l_calc (na , la , nc , lc);
  const double q2_reduced_in_l = OBME_q_HO_reduced_in_l_calc (nb , lb , nd , ld);

  const double q1_q2_L_ME = Wigner_signs::Oa_scalar_Ob_ME_calc (2 , la , lb , L , lc , ld , L , q1_reduced_in_l , q2_reduced_in_l);

  return q1_q2_L_ME;
}



double HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_calc (
							    const int na , const int la , const double ja ,
							    const int nb , const int lb , const double jb , 
							    const int nc , const int lc , const double jc ,
							    const int nd , const int ld , const double jd , 
							    const int J)
{
  const double q1_reduced_in_j = OBME_q_HO_reduced_in_j_calc (na , la , ja , nc , lc , jc);
  const double q2_reduced_in_j = OBME_q_HO_reduced_in_j_calc (nb , lb , jb , nd , ld , jd);

  const double q1_q2_J_ME = Wigner_signs::Oa_scalar_Ob_ME_calc (2 , ja , jb , J , jc , jd , J , q1_reduced_in_j , q2_reduced_in_j);

  return q1_q2_J_ME;
}


double HO_wave_functions::HO_3D::TBME_q1_scalar_q2_HO_antisymmetrized_calc (
									    const int na , const int la , const double ja ,
									    const int nb , const int lb , const double jb , 
									    const int nc , const int lc , const double jc ,
									    const int nd , const int ld , const double jd , 
									    const int J)
{
  const bool sa_equal_sb = same_nlj (na , la , ja , nb , lb , jb);
  const bool sc_equal_sd = same_nlj (nc , lc , jc , nd , ld , jd);

  const int T = 1;

  if (sc_equal_sd)
    {
      if ((J + T)%2 == 0) return 0.0;

      const double antisymmetry_norm_in = M_SQRT1_2;

      const double antisymmetry_norm_out = (sa_equal_sb) ? (M_SQRT1_2) : (1.0);

      const double antisymmetry_norm = 2.0*antisymmetry_norm_in*antisymmetry_norm_out;

      const double TBME = antisymmetry_norm*TBME_q1_scalar_q2_HO_calc (na , la , ja , nb , lb , jb , nc , lc , jc , nd , ld , jd , J);
      
      return TBME;
    }

  if (sa_equal_sb)
    {
      if ((J + T)%2 == 0) return 0.0;

      const double TBME = M_SQRT2*TBME_q1_scalar_q2_HO_calc (na , la , ja , nb , lb , jb , nc , lc , jc , nd , ld , jd , J);

      return TBME;
    }

  const double TBME_direct   = TBME_q1_scalar_q2_HO_calc (na , la , ja , nb , lb , jb , nc , lc , jc , nd , ld , jd , J);
  const double TBME_exchange = TBME_q1_scalar_q2_HO_calc (nb , lb , jb , na , la , ja , nc , lc , jc , nd , ld , jd , J);

  const double TBME = TBME_direct - minus_one_pow (ja + jb - J)*TBME_exchange;

  return TBME;
}






// Ricatti-Bessel center of mass matrix elements 
// ---------------------------------------------
// In order to calculation EM operators between two intrinsic cluster states <int | O_EM_int | int>
// one calculates firstly <CM-0s-HO int | O_EM | CM-0s-HO int>.
// This separates in products of <int | O_EM_int | int> times <CM-0s-HO | O_EM_CM | CM-0s-HO> matrix elements, 
// where O_EM_CM is j0(q r), d(r.j0(q r))/dr = cos (q r), r.\hat{j0}(q r) = r.sin (q r), \hat{j0}(q r)/r = q.sin (q r), r.j0(q r) = sin (q r) / q
// <CM-0s-HO | O_EM_CM | CM-0s-HO> matrix elements are analytical.
//
// Variables and special values:
// ----------------------------
// q : photon impulsion
// b : oscillator length in Fermi
// x : (q.b)/2

complex<double> HO_wave_functions::HO_3D::j0_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> x = 0.5*q*b , x2 = x*x , j0_ME = exp (-x2);

  return j0_ME;
}

complex<double> HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> x = 0.5*q*b , x2 = x*x;

  const complex<double> hat_j0_derivative_ME = (1.0 - 2.0*x2)*exp (-x2);

  return hat_j0_derivative_ME;
}

complex<double> HO_wave_functions::HO_3D::r_hat_j0_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> x = 0.5*q*b , x2 = x*x;

  const complex<double> r_hat_j0_ME = 2.0*b*x*(1.5 - x2)*exp (-x2);

  return r_hat_j0_ME;
}

complex<double> HO_wave_functions::HO_3D::hat_j0_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> x = 0.5*q*b , x2 = x*x , Dawson_integral_x = Dawson_integral_calc (x);

  const complex<double> hat_j0_ME = M_2_SQRTPI*(x + (1.0 - 2.0*x2)*Dawson_integral_x);

  return hat_j0_ME;
}

complex<double> HO_wave_functions::HO_3D::hat_j0_over_r_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> j0_ME = j0_ME_calc (b , q) , hat_j0_over_r_ME = q*j0_ME;

  return hat_j0_over_r_ME;
}

complex<double> HO_wave_functions::HO_3D::r_j0_ME_calc (const double b , const complex<double> &q)
{
  const complex<double> hat_j0_ME = hat_j0_ME_calc (b , q) , r_j0_ME = hat_j0_ME/q;

  return r_j0_ME;
}


double HO_wave_functions::HO_3D::j0_ME_calc (const double b , const double q)
{
  const double x = 0.5*q*b , x2 = x*x , j0_ME = exp (-x2);

  return j0_ME;
}

double HO_wave_functions::HO_3D::hat_j0_derivative_ME_calc (const double b , const double q)
{
  const double x = 0.5*q*b , x2 = x*x;

  const double hat_j0_derivative_ME = (1.0 - 2.0*x2)*exp (-x2);

  return hat_j0_derivative_ME;
}

double HO_wave_functions::HO_3D::r_hat_j0_ME_calc (const double b , const double q)
{
  const double x = 0.5*q*b , x2 = x*x;

  const double r_hat_j0_ME = 2.0*b*x*(1.5 - x2)*exp (-x2);

  return r_hat_j0_ME;
}

double HO_wave_functions::HO_3D::hat_j0_ME_calc (const double b , const double q)
{
  const double x = 0.5*q*b , x2 = x*x , Dawson_integral_x = real (Dawson_integral_calc (x));

  const double hat_j0_ME = M_2_SQRTPI*(x + (1.0 - 2.0*x2)*Dawson_integral_x);

  return hat_j0_ME;
}

double HO_wave_functions::HO_3D::hat_j0_over_r_ME_calc (const double b , const double q)
{
  const double j0_ME = j0_ME_calc (b , q) , hat_j0_over_r_ME = q*j0_ME;

  return hat_j0_over_r_ME;
}

double HO_wave_functions::HO_3D::r_j0_ME_calc (const double b , const double q)
{
  const double hat_j0_ME = hat_j0_ME_calc (b , q) , r_j0_ME = hat_j0_ME/q;

  return r_j0_ME;
}

