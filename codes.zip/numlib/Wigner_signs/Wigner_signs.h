#ifndef WIGNER_SIGNS_H
#define WIGNER_SIGNS_H

namespace Wigner_signs
{
  double factorial (const double x);

  double double_factorial (const double x);

  bool is_it_triangle_integer (
			       const int j1 , 
			       const int j2 , 
			       const int j3);

  bool is_it_triangle (
		       const double j1 , 
		       const double j2 , 
		       const double j3);

  bool is_it_integer (const double x);

  void Wigner_3j_tab_calc (
			   const double j2 , 
			   const double j3 , 
			   const double m1 , 
			   const double m2 , 
			   const double m3 , 
			   class array<double> &Wig_table);

  double Wigner_3j (
		    const double j1 , 
		    const double j2 , 
		    const double j3 , 
		    const double m1 , 
		    const double m2 , 
		    const double m3);

  double Clebsch_Gordan (
			 const double j1 , 
			 const double m1 , 
			 const double j2 , 
			 const double m2 , 
			 const double J , 
			 const double M);

  void Wigner_6j_tab_calc (
			   const double j2 , 
			   const double j3 , 
			   const double l1 , 
			   const double l2 , 
			   const double l3 , 
			   class array<double> &Wig_table);

  double Wigner_6j (
		    const double j1 , 
		    const double j2 , 
		    const double j3 , 
		    const double l1 , 
		    const double l2 , 
		    const double l3);

  double Wigner_9j (
		    const double j1 , 
		    const double j2 , 
		    const double J12 , 
		    const double j3 , 
		    const double j4 , 
		    const double J34 , 
		    const double J13 , 
		    const double J24 , 
		    const double J);

  double ME_dereduced (
		       const double ME_reduced , 
		       const double J , 
		       const double MJ , 
		       const double ji , 
		       const double mi , 
		       const double jf , 
		       const double mf);

  complex<double> ME_dereduced (
				const complex<double> &ME_reduced , 
				const double J , 
				const double MJ , 
				const double ji , 
				const double mi , 
				const double jf , 
				const double mf);

  double ME_reduced (
		     const double ME_non_reduced , 
		     const double J , 
		     const double MJ , 
		     const double ji , 
		     const double mi , 
		     const double jf , 
		     const double mf);

  complex<double> ME_reduced (
			      const complex<double> &ME_non_reduced , 
			      const double J , 
			      const double MJ , 
			      const double ji , 
			      const double mi , 
			      const double jf , 
			      const double mf);

  double Oa_scalar_Ob_ME_calc (
			       const double k , 
			       const double ja_i , 
			       const double jb_i , 
			       const double Ji , 
			       const double ja_f , 
			       const double jb_f , 
			       const double Jf , 
			       const double O1a_reduced_OBME , 
			       const double O2b_reduced_OBME);

  double Oa_reduced_ME_calc (
			     const double k , 
			     const double ja_i , 
			     const double jb_i , 
			     const double Ji , 
			     const double ja_f , 
			     const double jb_f , 
			     const double Jf , 
			     const double O1a_reduced_OBME); 

  double Ob_reduced_ME_calc (
			     const double k , 
			     const double ja_i , 
			     const double jb_i , 
			     const double Ji , 
			     const double ja_f , 
			     const double jb_f , 
			     const double Jf , 
			     const double O2b_reduced_OBME); 

  double Oa_tensor_Ob_reduced_ME_calc (
				       const double k1 , 
				       const double k2 ,
				       const double k , 
				       const double ja_i , 
				       const double jb_i , 
				       const double Ji , 
				       const double ja_f , 
				       const double jb_f , 
				       const double Jf , 
				       const double O1a_reduced_OBME , 
				       const double O2b_reduced_OBME);

  double O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (
							const double k1 , 
							const double k2 ,
							const double k12 ,  
							const double k3 ,
							const double k , 
							const double ja_i , 
							const double jb_i , 
							const double Ji , 
							const double ja_f , 
							const double jb_f , 
							const double Jf , 
							const double O1a_reduced_OBME , 
							const class array<double> &O2b_tensor_O3b_reduced_OBMEs);

  double O1a_tensor_O2b_k3_scalar_O3b_ME_calc (
					       const double k1 , 
					       const double k2 , 
					       const double k3 , 
					       const double ja_i , 
					       const double jb_i , 
					       const double Ji , 
					       const double ja_f , 
					       const double jb_f , 
					       const double Jf , 
					       const double O1a_reduced_OBME , 
					       const double O2b_tensor_O3b_reduced_OBME);

  double O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (
							const double k1 , 
							const double k2 , 
							const double k3 , 
							const double k23 ,
							const double k , 
							const double ja_i , 
							const double jb_i , 
							const double Ji , 
							const double ja_f , 
							const double jb_f , 
							const double Jf , 
							const class array<double> &O1a_tensor_O2a_reduced_OBMEs , 
							const double O3b_reduced_OBME);

  double O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (
						       const double k1 , 
						       const double k2 , 
						       const double k3 , 
						       const double ja_i , 
						       const double jb_i , 
						       const double Ji , 
						       const double ja_f , 
						       const double jb_f , 
						       const double Jf , 
						       const double O1a_tensor_O2a_reduced_OBME , 
						       const double O3b_reduced_OBME);

  double O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (
								       const double k1 , 
								       const double k2 ,
								       const double k12 ,  
								       const double k3 ,  
								       const double k4 , 
								       const double k34 ,
								       const double k , 
								       const double ja_i , 
								       const double jb_i , 
								       const double Ji , 
								       const double ja_f , 
								       const double jb_f , 
								       const double Jf , 
								       const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
								       const class array<double> &O2b_tensor_O4b_reduced_OBMEs);

  double O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (
							   const double k1 , 
							   const double k2 , 
							   const double k , 
							   const double k3 , 
							   const double k4 , 
							   const double ja_i , 
							   const double jb_i , 
							   const double Ji , 
							   const double ja_f , 
							   const double jb_f , 
							   const double Jf , 
							   const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
							   const class array<double> &O2b_tensor_O4b_reduced_OBMEs);

  double O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (
							  const double k1 , 
							  const double k2 ,
							  const double k , 
							  const double l , 
							  const double ja_i , 
							  const double jb_i , 
							  const double Ji , 
							  const double ja_f , 
							  const double jb_f , 
							  const double Jf , 
							  const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
							  const class array<double> &O2b_tensor_O4b_reduced_OBMEs);

  complex<double> Oa_scalar_Ob_ME_calc (
					const double k , 
					const double ja_i , 
					const double jb_i , 
					const double Ji , 
					const double ja_f , 
					const double jb_f , 
					const double Jf , 
					const complex<double> &O1a_reduced_OBME , 
					const complex<double> &O2b_reduced_OBME);

  complex<double> Oa_reduced_ME_calc (
				      const double k , 
				      const double ja_i , 
				      const double jb_i , 
				      const double Ji , 
				      const double ja_f , 
				      const double jb_f , 
				      const double Jf , 
				      const complex<double> &O1a_reduced_OBME); 

  complex<double> Ob_reduced_ME_calc (
				      const double k , 
				      const double ja_i , 
				      const double jb_i , 
				      const double Ji , 
				      const double ja_f , 
				      const double jb_f , 
				      const double Jf , 
				      const complex<double> &O2b_reduced_OBME); 

  complex<double> Oa_tensor_Ob_reduced_ME_calc (
						const double k1 , 
						const double k2 ,
						const double k , 
						const double ja_i , 
						const double jb_i , 
						const double Ji , 
						const double ja_f , 
						const double jb_f , 
						const double Jf , 
						const complex<double> &O1a_reduced_OBME , 
						const complex<double> &O2b_reduced_OBME);

  complex<double> O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (
								 const double k1 , 
								 const double k2 ,
								 const double k12 ,
								 const double k3 , 
								 const double k , 
								 const double ja_i , 
								 const double jb_i , 
								 const double Ji , 
								 const double ja_f , 
								 const double jb_f , 
								 const double Jf , 
								 const complex<double> &O1a_reduced_OBME , 
								 const class array<complex<double> > &O2b_tensor_O3b_reduced_OBMEs);

  complex<double> O1a_tensor_O2b_k3_scalar_O3b_ME_calc (
							const double k1 , 
							const double k2 , 
							const double k3 , 
							const double ja_i , 
							const double jb_i , 
							const double Ji , 
							const double ja_f , 
							const double jb_f , 
							const double Jf , 
							const complex<double> &O1a_reduced_OBME , 
							const complex<double> &O2b_tensor_O3b_reduced_OBME);

  complex<double> O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (
								 const double k1 , 
								 const double k2 , 
								 const double k3 , 
								 const double k23 ,
								 const double k , 
								 const double ja_i , 
								 const double jb_i , 
								 const double Ji , 
								 const double ja_f , 
								 const double jb_f , 
								 const double Jf , 
								 const class array<complex<double> > &O1a_tensor_O2a_reduced_OBMEs , 
								 const complex<double> &O3b_reduced_OBME);

  complex<double> O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (
								const double k1 , 
								const double k2 , 
								const double k3 , 
								const double ja_i , 
								const double jb_i , 
								const double Ji , 
								const double ja_f , 
								const double jb_f , 
								const double Jf , 
								const complex<double> &O1a_tensor_O2a_reduced_OBME , 
								const complex<double> &O3b_reduced_OBME);

  complex<double> O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (
										const double k1 , 
										const double k2 ,
										const double k12 ,  
										const double k3 ,  
										const double k4 , 
										const double k34 ,
										const double k , 
										const double ja_i , 
										const double jb_i , 
										const double Ji , 
										const double ja_f , 
										const double jb_f , 
										const double Jf , 
										const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
										const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs);

  complex<double> O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (
								    const double k1 , 
								    const double k2 , 
								    const double k , 
								    const double k3 , 
								    const double k4 ,
								    const double ja_i , 
								    const double jb_i , 
								    const double Ji , 
								    const double ja_f , 
								    const double jb_f , 
								    const double Jf , 
								    const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
								    const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs);

  complex<double> O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (
								   const double k1 , 
								   const double k2 ,
								   const double k , 
								   const double l , 
								   const double ja_i , 
								   const double jb_i , 
								   const double Ji , 
								   const double ja_f , 
								   const double jb_f , 
								   const double Jf , 
								   const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
								   const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs);

  double Wigner_d_small (
			 const double J , 
			 const double M , 
			 const double Mp , 
			 const double beta_rad);

  complex<double> Wigner_D (
			    const double J , 
			    const double M , 
			    const double Mp , 
			    const double alpha_rad , 
			    const double beta_rad , 
			    const double gamma_rad);
}


#endif
