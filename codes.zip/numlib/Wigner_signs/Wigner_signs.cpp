#include "../numlib_def/numlib_def.h"




// Factorial n! for a double x=n which is in fact an integer.
// ----------------------------------------------------------
double Wigner_signs::factorial (const double x)
{
  const int n = make_int (x);
  
  double fact = 1.0;

  for (int i = 1 ; i <= n ; i++) fact *= i;

  return fact;
}

// Double factorial n!! for a double x=n which is in fact an integer.
// ------------------------------------------------------------------
double Wigner_signs::double_factorial (const double x)
{
  const int n = make_int (x);
  
  double double_fact = 1.0;

  for (int i = n ; i > 0 ; i -= 2) double_fact *= i;

  return double_fact;
}


// Test to know if the three j's verify the triangle relation (integers)
// ---------------------------------------------------------------------
bool Wigner_signs::is_it_triangle_integer (
					   const int j1 , 
					   const int j2 , 
					   const int j3)
{
  return ((abs (j1 - j2) <= j3) && (j1 + j2 >= j3));
}


// Test to know if the three j's verify the triangle relation.
// -----------------------------------------------------------
bool Wigner_signs::is_it_triangle (
				   const double j1 , 
				   const double j2 , 
				   const double j3)
{
  return (is_it_integer (j1 + j2 + j3) && (make_int (abs (j1 - j2) - j3) <= 0) && (make_int (j1 + j2 - j3) >= 0));
}


// Test to know if a double is a integer.
// -----------------------------------------
bool Wigner_signs::is_it_integer (const double x)
{
  return (abs (x - rint (x)) < precision);
}


// Wigner 3j table.
// ----------------
// See K. Schulten , R.G. Gordon , Comput. Phys. Commun. , Vol. 11 , (1976) p. 269 for method and notations.
// This a very stable method , with full numerical accuracy for parameters ~ 1000.
// One must have jmin <= jmax. No test is made.
//
// All non trivially zero Wigner 3j symbols W(j , j2 , j3 , m1 , m2 , m3) are calculated , with |j2-j3| <= j <= j2+j3 .
//
// If max (|m1| , |j2-j3|) = j2+j3 , there is only only symbol in the table equal to (-1)^(j2-j3-m1)/sqrt[2.[j2+j3] + 1].
//
// In other cases , the following recurrence relation is used : 
// j.A(j + 1).W(j + 1) + B(j).W(j) + (j + 1).A(j).W(j - 1) = 0 , for jmin = max (|m1| , |j2-j3|) < j < jmax = j2+j3 , with :
// W(j) = Wigner_3j (j , j2 , j3 , m1 , m2 , m3).
// A(j) = sqrt ([j - (j2-j3)^2][(j2+j3 + 1)^2 - j^2][j^2 - m1^2])
// B(j) = -(2j + 1)[m1.j2.(j2 + 1) - m1.j3.(j3 + 1) - j.(j + 1).(m3-m2)]
//
// The recurrence relation is stable only for increasing |W(j)| , so that forward and backward recursions are used.
//
// For forward recursion : W(jmin) = 1 (arbitrary value to be normalized).
//                         W(jmin + 1) = -B(jmin)/jmin/A(jmin + 1) if jmin > 0 , as W(jmin - 1) = 0 and W(jmin) = 1 , -(m3-m2)/A(jmin + 1) if jmin = 0 , 
//                         The formula for jmin = 0 is the limit of -B(j)/j/A(j + 1) for j2=j3 (necessary to have jmin=0) with j -> 0.
//                         There is no problem of other zero denominator as A(j + 1) > 0 for jmin < j < jmax.
//
// For backward recursion : W(jmax) = 1 (arbitrary value to be normalized).
//                          W(jmax - 1) = -B(jmax)/[jmax + 1]/A(jmax) , as W(jmax + 1) = 0 and W(jmax) = 1.
//                          There is no problem of zero denominator as A(j) > 0 for jmin < j < jmax.
//
// In order to avoid overflows , W[forward/backward] is multiplied by 1E-5 in case |W[forward/backward](j)| > 1E5 during recursion.
//
// For large angular momenta , |W(j)| increases very quickly at jmin and jmax , so that both recursions are stable
// until an intermediate j=j_int. It is determined with the forward recursion with the condition |B(j_int)/j_int/A(j_int + 1)| minimal.
// In order to avoid side effects , j_int can be a bit before or after the true minimum.
// With both recursions , W[forward] is known up to a normalization constant from jmin to j_int and so is W[backward] from j_int to jmax.
// W[forward] and W[backward] are matched at j_int using the value of lambda giving the minimum of :
// \sum_{i \in {-1 , 0 , 1}} (lambda.W[forward](j_int+i) - W[backward](j_int+i))^2
// W[forward/backward](j_int+i) are set to 0 if j_int+i < jmin or j_int+i > jmax for i \in {-1 , 0 , 1}.
// This expression insures that the denominator of the lambda expression cannot be zero or too small.
// One then has : lambda = [\sum_{i \in {-1 , 0 , 1}} W[forward](j_int+i).W[backward](j_int+i)]/[\sum_{i \in {-1 , 0 , 1}} W[forward](j_int+i)^2].
// For small angular momenta , the method works also as one cannot have instabilities in this case.
//
// After matching W[forward] and W[backward] , the norm of W is calculated with the conditions :
// \sum_{j : jmin->jmax} (2j + 1).W(j)^2 = 1 (normality of Wigner 3j symbols)
// sign (W(jmax)) = (-1)^(j2-j3-m1) (phase convention)
//
// Variables
// ---------
// j2 , j3 , m1 , m2 , m3 : parameters of the Wigner 3j symbol , so it is : | j  j2 j3 |
//                                                                 | m1 m2 m3 |
// jmin0 , jmin , jmax : |j2-j3| , max(|m1| , |j2-j3|) , j2+j3
// N : number of j's between jmin and jmax. It is jmax-jmin + 1.
// Wig_table : table of Wigner 3j symbols between jmin and jmax to be calculated. Wig_table(i) = W(jmin+i) , i in [0:N - 1].
// jmin0_square , B_const , m_const , jmax_p_1_square , m1_square : constants used in A and B tables. They are (j2-j3)^2 , m1.j2.(j2 + 1) - m1.j3.(j3 + 1) , (jmax + 1)^2 , m1^2.
// A , B , Wig_forw , Wig_back : tables A , B and Wigner signs for forward and backward recursions.
// j , j_square , Wig_j : values of j , j^2 , and Wigner sign of j for loops with jmin < j < jmax.
// i0 , int : j_int = jmin + i_int , with i_int = i0 to be determined , i_int is const but i0 is not.
// is_it_max : false if one has not reached the minimal value of |B(j)/j/A(j + 1)| , true if one has.
// one_over_den : 1/j/A(j + 1) for forward recursion and 1/[j + 1]/A(j) for backward recursion.
// alpha , beta : -B(j)/j/A(j + 1) and -(j + 1).A(j)/j/A(j + 1) for forward recursion , -j.A(j + 1)/[j + 1]/A(j) and -B(j)/j/A(j + 1) for backward recursion.
// abs_alpha , abs_alpha_bef , abs_alpha_bef_bef : |B(j)/j/A(j + 1)| , |B(j - 1)/[j - 1]/A(j)| and |B(j-2)/[j-2]/A(j - 1)|. 
//                                             They are used to determine the minimal value of |B(j)/j/A(j + 1)| during forward recursion.
//                                             The bef are initialized to INFINITE (=1E300).
// num_int_m1 , den_int_m1 , den_int_p1 , num_int_p1 : W[forward](j_int+i).W[backward](j_int+i)] and W[forward](j_int+i)^2 for i=-1 and i=1.
// lambda : matching constant for W[forward] and W[backward]
// norm_square : \sum_{j : jmin->jmax} (2j + 1).W(j)^2 
// one_over_norm_wig : (-1)^(j2-j3-m1).sign (W(jmax))/sqrt[\sum_{j : jmin->jmax} (2j + 1).W(j)^2]


void Wigner_signs::Wigner_3j_tab_calc (
				       const double j2 , 
				       const double j3 , 
				       const double m1 , 
				       const double m2 , 
				       const double m3 , 
				       class array<double> &Wig_table)
{
  const double jmin0 = abs (j2 - j3);

  const double jmin = max (jmin0 , abs (m1));

  const double jmax = j2 + j3;

  const int N = make_int (jmax - jmin) + 1;

  if (N == 1) 
    {
      Wig_table(0) = minus_one_pow (j2 - j3 - m1)/sqrt (2.0*jmax + 1.0); 

      return;
    }

  const double jmin0_square = jmin0*jmin0;

  const double B_const = m1*(j2*(j2 + 1) - j3*(j3 + 1));

  const double m_const = m3 - m2;

  const double jmax_p_1_square = (jmax + 1.0)*(jmax + 1.0);

  const double m1_square = m1*m1;

  class array<double> A(N);
  class array<double> B(N);

  class array<double> Wig_forw(N);
  class array<double> Wig_back(N);

  for (int i = 0 ; i < N ; i++)
    {
      const double j = i + jmin;

      const double j_square = j*j;

      A(i) = sqrt (abs ((j_square - jmin0_square)*(jmax_p_1_square - j_square)*(j_square - m1_square)));

      B(i) = -(j + j + 1.0)*(B_const - (j_square + j)*m_const);
    }

  Wig_forw(0) = Wig_back(N - 1) = 1.0;

  Wig_forw(1) = (jmin == 0.0) ? (-m_const/A(1)) : (-B(0)/jmin/A(1));

  Wig_back(N-2) = -B(N - 1)/A(N - 1)/(jmax + 1.0);

  int i0 = 1;

  bool is_it_max = false;

  double abs_alpha_bef = INFINITE;

  double abs_alpha_bef_bef = INFINITE;

  while ((!is_it_max) && (i0 < N - 1))
    {
      const double j = jmin + i0;

      const double one_over_den = 1.0/(A(i0 + 1)*j);

      const double alpha = -B(i0)*one_over_den;

      const double beta = -(j + 1.0)*A(i0)*one_over_den;

      const double abs_alpha = abs (alpha);

      Wig_forw(i0 + 1) = alpha*Wig_forw(i0) + beta*Wig_forw(i0 - 1);

      if (abs (Wig_forw(i0 + 1)) > 1E5) 
	{
	  for (int ii = 0 ; ii <= i0 + 1 ; ii++) Wig_forw(ii) *= 1E-5;
	}

      if ((abs_alpha_bef < abs_alpha_bef_bef) && (abs_alpha_bef < abs_alpha)) is_it_max = true;

      abs_alpha_bef_bef = abs_alpha_bef;
      
      abs_alpha_bef = abs_alpha;

      i0++;
    }

  const int i_int = i0;

  if (i_int + 1 < N)
    {
      const double j = jmin + i_int;

      const double one_over_den = 1.0/(A(i_int + 1)*j);

      const double alpha = -B(i_int)*one_over_den;

      const double beta = -(j + 1.0)*A(i_int)*one_over_den;

      Wig_forw(i_int + 1) = alpha*Wig_forw(i_int) + beta*Wig_forw(i_int - 1);
    }

  for (int i = N-2 ; i >= i_int ; i--)
    {
      const double j = jmin + i;

      const double one_over_den = 1.0/(A(i)*(j + 1.0));

      const double alpha = -B(i)*one_over_den;

      const double beta = -j*A(i + 1)*one_over_den;

      Wig_back(i - 1) = beta*Wig_back(i + 1) + alpha*Wig_back(i);

      if (abs (Wig_back(i - 1)) > 1E5) 
	{
	  for (int ii = i - 1 ; ii < N ; ii++) Wig_back(ii) *= 1E-5;
	}
    }

  const double num_int_p1 = (i_int + 1 < N) ? (Wig_forw(i_int + 1)*Wig_back(i_int + 1)) : (0);
  const double den_int_p1 = (i_int + 1 < N) ? (Wig_forw(i_int + 1)*Wig_forw(i_int + 1)) : (0);

  const double num_int_m1 = (i_int     >= 1) ? (Wig_forw(i_int - 1)*Wig_back(i_int - 1)) : (0);
  const double den_int_m1 = (i_int - 1 >= 0) ? (Wig_forw(i_int - 1)*Wig_forw(i_int - 1)) : (0);

  const double lambda = (num_int_p1 + Wig_forw(i_int)*Wig_back(i_int) + num_int_m1)/(den_int_p1 + Wig_forw(i_int)*Wig_forw(i_int) + den_int_m1);

  for (int i = 0 ; i <= i_int ; i++) Wig_forw(i) *= lambda;

  double norm_square = 0.0;
  
  for (int i = 0 ; i < N ; i++)
    {
      const double j = jmin + i;

      const double Wig_j = (i <= i_int) ? (Wig_forw(i)) : (Wig_back(i));

      norm_square += (2.0*j + 1.0)*Wig_j*Wig_j;
    }

  const double one_over_norm_wig = minus_one_pow (j2 - j3 - m1)*SIGN (Wig_back(N - 1))/sqrt (norm_square);

  for (int i = 0 ; i < N ; i++) Wig_table(i) = (i <= i_int) ? (Wig_forw(i)*one_over_norm_wig) : (Wig_back(i)*one_over_norm_wig);
}









// Wigner 3j.
// ----------------
// See K. Schulten , R.G. Gordon , Comput. Phys. Commun. , Vol. 11 , (1976) p. 269 for method and notations.
//
// First , it is checked if the Wigner 3j is not a trivial zero , in which case 0 is returned.
// In other cases , one uses the method explained in Wigner_3j_tab_calc.
// One chooses the even permutation of angular momenta which demands the least number of calculations in Wigner_3j_tab_calc.
// It is the one which makes the dimension N of Wig_table as small as possible.
//
// Variables
// ---------
// j1 , j2 , j3 , m1 , m2 , m3 : parameters of the Wigner 3j symbol , so it is : | j1 j2 j3 |
//                                                                    | m1 m2 m3 |
// m_sum : m1 + m2 + m3
// jmin0_12 , jmin_12 , jmax_12 : |j1-j2| , max(|m3| , |j1-j2|) , j1+j2
// jmin0_23 , jmin_23 , jmax_23 : |j2-j3| , max(|m1| , |j2-j3|) , j2+j3
// jmin0_13 , jmin_13 , jmax_13 : |j1-j3| , max(|m2| , |j1-j3|) , j1+j3
// N_12 : number of j's between jmin_12 and jmax_12. It is jmax_12-jmin_12 + 1.
// N_23 : number of j's between jmin_23 and jmax_23. It is jmax_23-jmin_23 + 1.
// N_13 : number of j's between jmin_13 and jmax_13. It is jmax_13-jmin_13 + 1.
// N : minimum of N_12 , N_23 , N_13
// Wig_table : table of Wigner 3j of N elements.
// j1_index : index of j1 in Wig_table. It is j1-jmin_23.
// j2_index : index of j2 in Wig_table. It is j2-jmin_13.
// j3_index : index of j3 in Wig_table. It is j3-jmin_12.

double Wigner_signs::Wigner_3j (
				const double j1 , 
				const double j2 , 
				const double j3 , 
				const double m1 , 
				const double m2 , 
				const double m3)
{
  const double m_sum = m1 + m2 + m3;

  if (!is_it_integer (m_sum) || !is_it_triangle (j1 , j2 , j3) || !is_it_integer (j1 - m1) || !is_it_integer (j2 - m2) || !is_it_integer (j3 - m3)) return 0.0;

  if ((rint (m_sum) != 0.0) || (rint (abs (m1) - j1) > 0.0) || (rint (abs (m2) - j2) > 0.0) || (rint (abs (m3) - j3) > 0.0)) return 0.0;

  const double jmin0_12 = abs (j1 - j2) , jmin_12 = max (jmin0_12 , abs (m3)) , jmax_12 = j1 + j2;
  const double jmin0_23 = abs (j2 - j3) , jmin_23 = max (jmin0_23 , abs (m1)) , jmax_23 = j2 + j3;
  const double jmin0_13 = abs (j1 - j3) , jmin_13 = max (jmin0_13 , abs (m2)) , jmax_13 = j1 + j3;

  const int N_12 = make_int (jmax_12 - jmin_12) + 1;
  const int N_23 = make_int (jmax_23 - jmin_23) + 1;
  const int N_13 = make_int (jmax_13 - jmin_13) + 1;

  const int N = min (N_12 , min (N_13 , N_23));

  class array<double> Wig_table(N);

  if (N == N_12)
    {
      Wigner_3j_tab_calc (j1 , j2 , m3 , m1 , m2 , Wig_table);

      const int j3_index = make_int (j3 - jmin_12);

      return Wig_table(j3_index);
    }	

  if (N == N_13)
    {
      Wigner_3j_tab_calc (j3 , j1 , m2 , m3 , m1 , Wig_table);

      const int j2_index = make_int (j2 - jmin_13);

      return Wig_table(j2_index);
    }	

  if (N == N_23)
    {
      Wigner_3j_tab_calc (j2 , j3 , m1 , m2 , m3 , Wig_table);

      const int j1_index = make_int (j1 - jmin_23);

      return Wig_table(j1_index);
    }	

  return NADA;
}








// Clebsch - Gordan.
// -----------------
// It is calculated with the corresponding 3j.

double Wigner_signs::Clebsch_Gordan (
				     const double j1 , 
				     const double m1 , 
				     const double j2 , 
				     const double m2 , 
				     const double J , 
				     const double M)
{
  return hat (J)*minus_one_pow (j1 - j2 + M)*Wigner_3j (j1 , j2 , J , m1 , m2 , -M);
}





// Wigner 6j table
// ---------------
// See K. Schulten , R.G. Gordon , Comput. Phys. Commun. , Vol. 11 , (1976) p. 269 for method and notations.
// This a very stable method , with full numerical accuracy for parameters ~ 1000.
// One must have jmin <= jmax. No test is made.
//
// All non trivially zero Wigner 6j symbols W(j , j2 , j3 , l1 , l2 , l3) are calculated , with |j2-j3| <= j <= j2+j3 .
//
// If max (|j2-j3| , |l2-l3|) = min (j2+j3 , l2+l3) , there is one symbol in the table equal to (-1)^(j2+j3+l2+l3)/sqrt[(2.[j2+j3] + 1).(2.l1 + 1)].
//
// In other cases , the following recurrence relation is used : 
// j.E(j + 1).W(j + 1) + F(j).W(j) + (j + 1).E(j).W(j - 1) = 0 , for  jmin = max (|j2-j3| , |l2-l3|) < j < jmax = min (j2+j3 , l2+l3) , with :
// W(j) = Wigner_6j (j , j2 , j3 , l1 , l2 , l3).
// E(j) = sqrt ([j^2 - (j2-j3)^2].[(j2+j3 + 1)^2 - j^2].[j^2 - (l2-l3)^2].[(l2+l3 + 1)^2 - j^2])
// F(j) = (2.j + 1).[j(j + 1)[-j(j + 1)+j2(j2 + 1)+j3(j3 + 1)] + l2(l2 + 1)[j(j + 1)+j2(j2 + 1)-j3(j3 + 1)] + l3(l3 + 1)[j(j + 1)-j2(j2 + 1)+j3(j3 + 1)] - 2.j(j + 1).l1(l1 + 1)]
// 
// This relation is stable only for increasing |W(j)| , so that forward and backward recursions are used.
//
// For forward recursion : W(jmin) = 1 (arbitrary value to be normalized).
//                         W(jmin + 1) = -F(jmin)/jmin/E(jmin + 1) if jmin > 0 , as W(jmin - 1) = 0 and W(jmin) = 1 , 2[l1(l1 + 1)-l2(l2 + 1)-j2(j2 + 1)]/E(jmin + 1) if jmin = 0.
//                         The formula for jmin = 0 is the limit of -F(j)/j/E(j + 1) for j2=j3 and l2=l3 (necessary to have jmin=0) for j -> 0.
//                         There is no other problem of zero denominator as E(j + 1) > 0 for jmin < j < jmax.
//
// For backward recursion : W(jmax) = 1 (arbitrary value to be normalized).
//                          W(jmax - 1) = -F(jmax)/[jmax + 1]/E(jmax) , as W(jmax + 1) = 0 and W(jmax) = 1.
//                          There is no problem of zero denominator as E(j) > 0 for jmin < j < jmax.
//
// In order to avoid overflows , W[forward/backward] is multiplied by 1E-5 in case |W[forward/backward](j)| > 1E5 during recursion.
//
// For large angular momenta , |W(j)| increases very quickly at jmin and jmax , so that both recursions are stable
// until an intermediate j=j_int. It is determined with the forward recursion with condition |F(j_int)/j_int/E(j_int + 1)| minimal.
// In order to avoid side effects , j_int can be a bit before or after the true minimum.
// With both recursions , W[forward] is known up to a normalization constant from jmin to j_int and so is W[backward] from j_int to jmax.
// W[forward] and W[backward] are matched at j_int using the value of lambda giving the minimum of :
// \sum_{i \in {-1 , 0 , 1}} (lambda.W[forward](j_int+i) - W[backward](j_int+i))^2
// This expression insures that the denominator of the lambda expression is not zero or too small.
// W[forward/backward](j_int+i) are set to 0 if j_int+i < jmin or j_int+i > jmax for i \in {-1 , 0 , 1}.
// One then has : lambda = [\sum_{i \in {-1 , 0 , 1}} W[forward](j_int+i).W[backward](j_int+i)]/[\sum_{i \in {-1 , 0 , 1}} W[forward](j_int+i)^2].
// For small angular momenta , the method works also as one cannot have instabilities in this case.
//
// After matching W[forward] and W[backward] , the norm of W is calculated with the conditions :
// \sum_{j : jmin->jmax} (2j + 1).(2.l1 + 1).W(j)^2 = 1 (normality of Wigner 6j symbols)
// sign (W(jmax)) = (-1)^(j2+j3+l2+l3) (phase convention)
//
// Variables
// ---------
// j , j2 , j3 , l1 , l2 , l3 : parameters of the Wigner 6j symbol , so it is : | j  j2 j3 |
//                                                                              | l1 l2 l3 |
//
// jmin0 , lmin , jmin , jmax0 , lmax , jmax : |j2-j3| , |l2-l3| , max(|j2-j3| , |l2-l3|) , j2+j3 , l2+l3 , min(l2+l3 , j2+j3).
// N : number of j's between jmin and jmax. It is jmax-jmin + 1.
// Wig_table : table of Wigner 6j symbols between jmin and jmax to be calculated. Wig_table(i) = W(jmin+i) , i in [0:N - 1].
// jmin0_square , jmax0_p_1_square , lmin_square : constants used in E and F tables. They are (j2-j3)^2 , (j2+j3 + 1)^2 , (l2-l3)^2
// j2_j2_p1 , j3_j3_p1 , l1_l1_p1 , l2_l2_p1 : constants used in E and F tables. They are j2(j2 + 1) , j3(j3 + 1) , l1(l1 + 1) , l2(l2 + 1)
// jjp1_l1_l1_p1 : j(j + 1).l1(l1 + 1)
// E , F , Wig_forw , Wig_back : tables E , F and Wigner signs for forward and backward recursions.
// j , j_square , jjp1 , Wig_j : values of j , j^2 , j(j + 1) and Wigner sign of j for loops with jmin < j < jmax.
// i0 , int : j_int = jmin + i_int , with i_int = i0 to be determined , i_int is const but i0 is not.
// is_it_max : false if one has not reached the minimal value of |F(j)/j/E(j + 1)| , true if one has.
// one_over_den : 1/j/E(j + 1) for forward recursion and 1/[j + 1]/E(j) for backward recursion.
// alpha , beta : -F(j)/j/E(j + 1) and -(j + 1).E(j)/j/E(j + 1) for forward recursion , -j.E(j + 1)/[j + 1]/E(j) and -F(j)/j/E(j + 1) for backward recursion.
// abs_alpha , abs_alpha_bef , abs_alpha_bef_bef : |F(j)/j/E(j + 1)| , |F(j - 1)/[j - 1]/E(j)| and |F(j-2)/[j-2]/E(j - 1)|. 
//                                             They are used to determine the minimal value of |F(j)/j/E(j + 1)| during forward recursion.
//                                             The bef are initialized to INFINITE (=1E300).
// num_int_m1 , den_int_m1 , den_int_p1 , num_int_p1 : W[forward](j_int+i).W[backward](j_int+i)] and W[forward](j_int+i)^2 for i=-1 and i=1.
// lambda : matching constant for W[forward] and W[backward]
// norm_square : \sum_{j : jmin->jmax} (2j + 1).(2.l1 + 1).W(j)^2 
// one_over_norm_wig : (-1)^(j2+j3+l2+l3).sign (W(jmax))/sqrt[\sum_{j : jmin->jmax} (2j + 1).(2.l1 + 1).W(j)^2]

void Wigner_signs::Wigner_6j_tab_calc (
				       const double j2 , 
				       const double j3 , 
				       const double l1 , 
				       const double l2 , 
				       const double l3 , 
				       class array<double> &Wig_table)
{
  const double jmin0 = abs (j2 - j3);

  const double lmin = abs (l2 - l3);

  const double jmin = max (jmin0 , lmin);

  const double jmax0 = j2 + j3;

  const double lmax = l2 + l3;

  const double jmax = min (jmax0 , lmax);

  const int N = make_int (jmax - jmin) + 1;

  if (N == 1) 
    {
      Wig_table(0) = minus_one_pow (j2 + j3 + l2 + l3)/sqrt ((2.0*jmax + 1.0)*(2.0*l1 + 1.0)); 

      return;
    }

  const double jmin0_square = jmin0*jmin0;

  const double jmax0_p_1_square = (jmax0 + 1.0)*(jmax0 + 1.0);

  const double lmin_square = lmin*lmin;

  const double lmax_p_1_square = (lmax + 1.0)*(lmax + 1.0);
  
  const double j2_j2_p1 = j2*(j2 + 1.0);
  const double j3_j3_p1 = j3*(j3 + 1.0);
  
  const double l1_l1_p1 = l1*(l1 + 1.0);
  const double l2_l2_p1 = l2*(l2 + 1.0);
  const double l3_l3_p1 = l3*(l3 + 1.0);
  
  class array<double> E(N);
  class array<double> F(N);
  
  class array<double> Wig_forw(N);
  class array<double> Wig_back(N);

  for (int i = 0 ; i < N ; i++)
    {
      const double j = i + jmin;

      const double j_square = j*j;

      const double jjp1 = j_square + j;

      const double jjp1_l1_l1_p1 = jjp1*l1_l1_p1;

      E(i) = sqrt ((j_square - jmin0_square)*(j_square - lmin_square)*(jmax0_p_1_square - j_square)*(lmax_p_1_square - j_square));

      F(i) = (j + j + 1.0)*(jjp1*(-jjp1 + j2_j2_p1 + j3_j3_p1) + l2_l2_p1*(jjp1 + j2_j2_p1 - j3_j3_p1) + l3_l3_p1*(jjp1 - j2_j2_p1 + j3_j3_p1) - jjp1_l1_l1_p1 - jjp1_l1_l1_p1);
    }

  Wig_forw(0) = Wig_back(N - 1) = 1.0;
  
  Wig_forw(1) = (jmin == 0.0) ? (2.0*(l1_l1_p1 - l2_l2_p1 - j2_j2_p1)/E(1)) : (-F(0)/jmin/E(1));
  
  Wig_back(N-2) = -F(N - 1)/E(N - 1)/(jmax + 1.0);

  int i0 = 1;
  
  bool is_it_max = false;

  double abs_alpha_bef = INFINITE;

  double abs_alpha_bef_bef = INFINITE;

  while ((!is_it_max) && (i0 < N - 1))
    {
      const double j = jmin + i0;

      const double one_over_den = 1.0/(E(i0 + 1)*j);

      const double alpha = -F(i0)*one_over_den;

      const double beta = -(j + 1.0)*E(i0)*one_over_den;

      const double abs_alpha = abs (alpha);

      Wig_forw(i0 + 1) = alpha*Wig_forw(i0) + beta*Wig_forw(i0 - 1);

      if (abs (Wig_forw(i0 + 1)) > 1E5) 
	{
	  for (int ii = 0 ; ii <= i0 + 1 ; ii++) Wig_forw(ii) *= 1E-5;
	}

      if ((abs_alpha_bef < abs_alpha_bef_bef) && (abs_alpha_bef < abs_alpha)) is_it_max = true;

      abs_alpha_bef_bef = abs_alpha_bef;
      
      abs_alpha_bef = abs_alpha;
      
      i0++;
    }

  const int i_int = i0;

  if (i_int + 1 < N)
    {
      const double j = jmin + i_int;

      const double one_over_den = 1.0/(E(i_int + 1)*j);

      const double alpha = -F(i_int)*one_over_den;

      const double beta = -(j + 1.0)*E(i_int)*one_over_den;
      
      Wig_forw(i_int + 1) = alpha*Wig_forw(i_int) + beta*Wig_forw(i_int - 1);
    }

  for (int i = N - 2 ; i >= i_int ; i--)
    {
      const double j = jmin + i;

      const double one_over_den = 1.0/(E(i)*(j + 1.0));

      const double alpha = -F(i)*one_over_den;

      const double beta = -j*E(i + 1)*one_over_den;

      Wig_back(i - 1) = beta*Wig_back(i + 1) + alpha*Wig_back(i);

      if (abs (Wig_back(i - 1)) > 1E5) 
	{
	  for (int ii = i - 1 ; ii < N ; ii++) Wig_back(ii) *= 1E-5;
	}
    }

  const double num_int_p1 = (i_int + 1 < N) ? (Wig_forw(i_int + 1)*Wig_back(i_int + 1)) : (0);
  const double den_int_p1 = (i_int + 1 < N) ? (Wig_forw(i_int + 1)*Wig_forw(i_int + 1)) : (0);

  const double num_int_m1 = (i_int     >= 1) ? (Wig_forw(i_int - 1)*Wig_back(i_int - 1)) : (0);
  const double den_int_m1 = (i_int - 1 >= 0) ? (Wig_forw(i_int - 1)*Wig_forw(i_int - 1)) : (0);

  const double lambda = (num_int_p1 + Wig_forw(i_int)*Wig_back(i_int) + num_int_m1)/(den_int_p1 + Wig_forw(i_int)*Wig_forw(i_int) + den_int_m1);
  
  for (int i = 0 ; i <= i_int ; i++) Wig_forw(i) *= lambda;

  double norm_square = 0.0;

  for (int i = 0 ; i < N ; i++)
    {
      const double j = jmin + i;

      const double Wig_j = (i <= i_int) ? (Wig_forw(i)) : (Wig_back(i));

      norm_square += (j + j + 1.0)*Wig_j*Wig_j;
    }

  norm_square *= l1 + l1 + 1.0;

  const double one_over_norm_wig = minus_one_pow (j2 + j3 + l2 + l3)*SIGN (Wig_back(N - 1))/sqrt (norm_square);

  for (int i = 0 ; i < N ; i++) Wig_table(i) = (i <= i_int) ? (Wig_forw(i)*one_over_norm_wig) : (Wig_back(i)*one_over_norm_wig);
}










// Wigner 6j.
// ----------
// See K. Schulten , R.G. Gordon , Comput. Phys. Commun. , Vol. 11 , (1976) p. 269 for method and notations.
//
// First , it is checked if the Wigner 6j is not a trivial zero , in which case 0 is returned.
// In other cases , one uses the method explained above.
// One chooses the column permutation of angular momenta which demands the least number of calculations in Wigner_6j_tab_calc.
// It is the one which makes the dimension N of Wig_table as small as possible.
//
// Variables
// ---------
// j1 , j2 , j3 , l1 , l2 , l3 : parameters of the Wigner 6j symbol , so it is : | j1 j2 j3 |
//                                                                               | l1 l2 l3 |
//
// jmin0_12 , lmin_12 , jmin_12 , jmax0_12 , lmax_12 , jmax_12 : |j1-j2| , |l1-l2| , max(|j1-j2| , |l1-l2|) , j1+j2 , l1+l2 , min(l1+l2 , j1-j2).
// jmin0_23 , lmin_23 , jmin_23 , jmax0_23 , lmax_23 , jmax_23 : |j2-j3| , |l2-l3| , max(|j2-j3| , |l2-l3|) , j2+j3 , l2+l3 , min(l2+l3 , j2-j3).
// jmin0_13 , lmin_13 , jmin_13 , jmax0_13 , lmax_13 , jmax_13 : |j1-j3| , |l1-l3| , max(|j1-j3| , |l1-l3|) , j1+j3 , l1+l3 , min(l1+l3 , j1-j3).
// N_12 : number of j's between jmin_12 and jmax_12. It is jmax_12-jmin_12 + 1.
// N_23 : number of j's between jmin_23 and jmax_23. It is jmax_23-jmin_23 + 1.
// N_13 : number of j's between jmin_13 and jmax_13. It is jmax_13-jmin_13 + 1.
// N : minimum of N_12 , N_23 , N_13
// Wig_table : table of Wigner 6j of N elements.
// j1_index : index of j1 in Wig_table. It is j1-jmin_23.
// j2_index : index of j2 in Wig_table. It is j2-jmin_13.
// j3_index : index of j3 in Wig_table. It is j3-jmin_12.

double Wigner_signs::Wigner_6j (
				const double j1 , 
				const double j2 , 
				const double j3 , 
				const double l1 , 
				const double l2 , 
				const double l3)
{
  if ((!is_it_triangle (j1 , j2 , j3)) || (!is_it_triangle (j1 , l2 , l3)) || (!is_it_triangle (l1 , j2 , l3)) || (!is_it_triangle (l1 , l2 , j3))) return 0.0;

  if ((!is_it_integer (j1 + j2 + j3)) || (!is_it_integer (j1 + l2 + l3)) || (!is_it_integer (l1 + j2 + l3)) || (!is_it_integer (l1 + l2 + j3))) return 0.0;

  const double jmin0_12 = abs (j1 - j2) , lmin_12 = abs (l1 - l2) , jmin_12 = max (jmin0_12 , lmin_12) , jmax0_12 = j1 + j2 , lmax_12 = l1 + l2 , jmax_12 = min (jmax0_12 , lmax_12);
  const double jmin0_23 = abs (j2 - j3) , lmin_23 = abs (l2 - l3) , jmin_23 = max (jmin0_23 , lmin_23) , jmax0_23 = j2 + j3 , lmax_23 = l2 + l3 , jmax_23 = min (jmax0_23 , lmax_23);
  const double jmin0_13 = abs (j1 - j3) , lmin_13 = abs (l1 - l3) , jmin_13 = max (jmin0_13 , lmin_13) , jmax0_13 = j1 + j3 , lmax_13 = l1 + l3 , jmax_13 = min (jmax0_13 , lmax_13);

  const int N_12 = make_int (jmax_12 - jmin_12) + 1;
  const int N_23 = make_int (jmax_23 - jmin_23) + 1;
  const int N_13 = make_int (jmax_13 - jmin_13) + 1;

  const int N = min (N_12 , min (N_13 , N_23));

  class array<double> Wig_table(N);

  if (N == N_12)
    {
      Wigner_6j_tab_calc (j1 , j2 , l3 , l1 , l2 , Wig_table);

      const int j3_index = make_int (j3 - jmin_12);
      
      return Wig_table(j3_index);
    }	

  if (N == N_13)
    {
      Wigner_6j_tab_calc (j1 , j3 , l2 , l1 , l3 , Wig_table);

      const int j2_index = make_int (j2 - jmin_13);
      
      return Wig_table(j2_index);
    }	

  if (N == N_23)
    {
      Wigner_6j_tab_calc (j2 , j3 , l1 , l2 , l3 , Wig_table);

      const int j1_index = make_int (j1 - jmin_23);
      
      return Wig_table(j1_index);
    }	

  return NADA;
}











// Wigner 9j.
// ----------
// It is calculated with 6j's : formula (41) p.917 in Messiah 2.
// Tables of Wigner 6j's are calculated with recursion formulas , 
// so one table costs the calculation of one Wigner 6j with the above routine.

double Wigner_signs::Wigner_9j (
				const double j1 , 
				const double j2 , 
				const double J12 , 
				const double j3 , 
				const double j4 , 
				const double J34 , 
				const double J13 , 
				const double J24 , 
				const double J)
{
  if (!is_it_triangle (j1 , j2 , J12) || !is_it_triangle (j3 , j4 , J34) || !is_it_triangle (J13 , J24 , J)) return 0.0; 
  if (!is_it_triangle (j1 , j3 , J13) || !is_it_triangle (j2 , j4 , J24) || !is_it_triangle (J12 , J34 , J)) return 0.0; 

  if (!is_it_integer (j1 + j2 + J12) || !is_it_integer (j3 + j4 + J34) || !is_it_integer (J13 + J24 + J)) return 0.0;
  if (!is_it_integer (j1 + j3 + J13) || !is_it_integer (j2 + j4 + J24) || !is_it_integer (J12 + J34 + J)) return 0.0;

  const double gmin_j1 = abs (j1 - J)   , gmax_j1 = j1 + J;
  const double gmin_j2 = abs (j2 - J34) , gmax_j2 = j2 + J34;
  const double gmin_j3 = abs (j3 - J24) , gmax_j3 = j3 + J24;

  const double gmin1 = max (gmin_j2 , gmin_j3) , gmax1 = min (gmax_j2 , gmax_j3);
  const double gmin2 = max (gmin_j1 , gmin_j3) , gmax2 = min (gmax_j1 , gmax_j3);
  const double gmin3 = max (gmin_j1 , gmin_j2) , gmax3 = min (gmax_j1 , gmax_j2);

  const int N1 = make_int (gmax1 - gmin1) + 1;
  const int N2 = make_int (gmax2 - gmin2) + 1;
  const int N3 = make_int (gmax3 - gmin3) + 1;
  
  class array<double> Wig_6j_table_1(N1);
  class array<double> Wig_6j_table_2(N2);
  class array<double> Wig_6j_table_3(N3);

  Wigner_6j_tab_calc (j3  , J24 , j4  , j2  , J34 , Wig_6j_table_1);
  Wigner_6j_tab_calc (j1  , J   , J13 , J24 , j3  , Wig_6j_table_2);
  Wigner_6j_tab_calc (J34 , j2  , J12 , j1  , J   , Wig_6j_table_3);

  const double gmin = max (gmin1 , max (gmin2 , gmin3));
  const double gmax = min (gmax1 , min (gmax2 , gmax3));
  
  const int i_max = make_int (gmax - gmin);

  const int shift_1 = make_int (gmin - gmin1);
  const int shift_2 = make_int (gmin - gmin2);
  const int shift_3 = make_int (gmin - gmin3);

  double Wigner_sign_no_phase = 0.0;

  for (int i = 0 ; i <= i_max ; i++)
    {
      const double g = gmin + i;
      
      Wigner_sign_no_phase += (g + g + 1.0)*Wig_6j_table_1(i + shift_1)*Wig_6j_table_2(i + shift_2)*Wig_6j_table_3(i + shift_3);
    }

  return (is_it_integer (gmin)) ? (Wigner_sign_no_phase) : (-Wigner_sign_no_phase);
}









// Dereduction of a reduced matrix element.
// ----------------------------------------
// From <jf||O[J]||ji> , one calculates <jf mf|O[J , MJ]|ji mi>
// with the formula : 
// <jf mf|O[J , MJ]|ji mi> = (-1)^(jf-mf) . Wigner_3j (jf , J , ji , -mf , MJ , mi) . <jf||O[J]||ji>.
//
// One considers the two cases of <jf||O[J]||ji> double and complex.
// Variables
// ---------
// J , MJ : rank of O[J] and its projection on the z axis.
// ji , mi : angular momentum and its projection on the z axis of |i>.
// jf , mf : angular momentum and its projection on the z axis of |f>.
// ME_reduced : <jf||O[J]||ji>.
// ME_dereduced_val : <jf mf|O[J , MJ]|ji mi>.

double Wigner_signs::ME_dereduced (
				   const double ME_reduced , 
				   const double J , 
				   const double MJ , 
				   const double ji , 
				   const double mi , 
				   const double jf , 
				   const double mf)
{
  const double dereducing_term = minus_one_pow (jf - mf)*Wigner_3j (jf , J , ji , -mf , MJ , mi);

  const double ME_dereduced_val = ME_reduced*dereducing_term;

  return ME_dereduced_val;
}


complex<double> Wigner_signs::ME_dereduced (
					    const complex<double> &ME_reduced , 
					    const double J , 
					    const double MJ , 
					    const double ji , 
					    const double mi , 
					    const double jf , 
					    const double mf)
{
  const double dereducing_term = minus_one_pow (jf - mf)*Wigner_3j (jf , J , ji , -mf , MJ , mi);

  const complex<double> ME_dereduced_val = ME_reduced*dereducing_term;

  return ME_dereduced_val;
}



// Reduction of a reduced matrix element.
// ----------------------------------------
// From <jf mf|O[J , MJ]|ji mi> , one calculates <jf||O[J]||ji>
// with the formula : 
// <jf||O[J]||ji> = (-1)^(jf-mf) . <jf mf|O[J , MJ]|ji mi> / Wigner_3j (jf , J , ji , -mf , MJ , mi).
// Wigner_3j (jf , J , ji , -mf , MJ , mi) has to be non zero. No check is made.
//
// One considers the two cases of <jf mf|O[J , MJ]|ji mi> double and complex.
// Variables
// ---------
// J , MJ : rank of O[J] and its projection on the z axis.
// ji , mi : angular momentum and its projection on the z axis of |i>.
// jf , mf : angular momentum and its projection on the z axis of |f>.
// ME_reduced_val : <jf||O[J]||ji>.
// ME_non_reduced : <jf mf|O[J , MJ]|ji mi>.

double Wigner_signs::ME_reduced (
				 const double ME_non_reduced , 
				 const double J , 
				 const double MJ , 
				 const double ji , 
				 const double mi , 
				 const double jf , 
				 const double mf)
{
  const double reducing_term = minus_one_pow (jf - mf)/Wigner_3j (jf , J , ji , -mf , MJ , mi);

  const double ME_reduced_val = ME_non_reduced*reducing_term;

  return ME_reduced_val;
}


complex<double> Wigner_signs::ME_reduced (
					  const complex<double> &ME_non_reduced , 
					  const double J , 
					  const double MJ , 
					  const double ji , 
					  const double mi , 
					  const double jf , 
					  const double mf)
{
  const double reducing_term = minus_one_pow (jf - mf)/Wigner_3j (jf , J , ji , -mf , MJ , mi);

  const complex<double> ME_reduced_val = ME_non_reduced*reducing_term;

  return ME_reduced_val;
}







// Use of the Wigner Eckhart theorem to calculate matrix elements functions of irreducible sub-matrix elements
// -----------------------------------------------------------------------------------------------------------
// Versions for real and complex matrix elements are provided.



// <ja_f jb_f J | Oa^k . Ob^k | ja_i jb_i J>
// -----------------------------------------
// Oa and Ob are spherical tensors of rank k coupled to zero acting on systems a and b respectively.
// It is equal to (-1)^(jb_f + ja_i + J) . Wigner_6j (ja_f , jb_f , J , jb_i , ja_i , k) . <ja_f || Oa^k || ja_i> . <jb_f || Ob^k || jb_i>_J

double Wigner_signs::Oa_scalar_Ob_ME_calc (
					   const double k , 
					   const double ja_i , 
					   const double jb_i , 
					   const double Ji , 
					   const double ja_f , 
					   const double jb_f , 
					   const double Jf , 
					   const double Oa_reduced_OBME , 
					   const double Ob_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  const int phase = minus_one_pow (jb_f + ja_i + Jf);

  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , jb_i , ja_i , k);

  const double ME = phase * Wig_6j * Oa_reduced_OBME * Ob_reduced_OBME;

  return ME;
}






// <ja_f jb_f Jf || Oa^k tensor Ib || ja_i jb_i Ji>
// ------------------------------------------------
// Oa^k is a spherical tensor of rank k acting on the first system a. Ib is identity acting on the second system b.
// It is equal to (-1)^(ja_f + jb_f + Ji + k) . Wigner_6j (ja_f , jb_f , Jf , Ji , k , ja_i) . <ja_f || Oa^k || ja_i> . delta (jb_i , jb_f)

double Wigner_signs::Oa_reduced_ME_calc (
					 const double k , 
					 const double ja_i , 
					 const double jb_i , 
					 const double Ji , 
					 const double ja_f , 
					 const double jb_f , 
					 const double Jf , 
					 const double Oa_reduced_OBME) 
{
  if (rint (jb_i - jb_f) != 0.0) return 0.0;

  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const int phase = minus_one_pow (ja_f + jb_f + Ji + k);

  const double hats = hat (Ji)*hat (Jf);

  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , Ji , k , ja_i);

  const double ME = phase * hats * Wig_6j * Oa_reduced_OBME;

  return ME;
}






// <ja_f jb_f Jf || Ia tensor Ob^k || ja_i jb_i Ji>
// ------------------------------------------------
// Ia is identity acting on the first system a. Ob^k is a spherical tensor of rank k acting on the second system b.
// It is equal to (-1)^(ja_i + jb_i + Jf + k) . hat (Ji) . hat (Jf) . Wigner_6j (ja_f , jb_f , Jf , k , Ji , jb_i) . delta (ja_i , ja_f) . <jb_f || Ob^k || jb_i>

double Wigner_signs::Ob_reduced_ME_calc (
					 const double k , 
					 const double ja_i , 
					 const double jb_i , 
					 const double Ji , 
					 const double ja_f , 
					 const double jb_f , 
					 const double Jf , 
					 const double Ob_reduced_OBME) 
{
  if (rint (ja_i - ja_f) != 0.0) return 0.0;

  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const int phase = minus_one_pow (ja_i + jb_i + Jf + k);

  const double hats = hat (Ji)*hat (Jf);

  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , k , Ji , jb_i);

  const double ME = phase * hats * Wig_6j * Ob_reduced_OBME;

  return ME;
}


// <ja_f jb_f Jf || [Oa^ka x Ob^kb]^k || ja_i jb_i Ji>
// ---------------------------------------------------
// Oa and Ob are spherical tensors of rank ka and kb , acting on systems a and b , respectively coupled to k .
// It is equal to hat (Ji) . hat (Jf) . hat (k) .  Wigner_9j (ja_f , jb_f , Jf , ja_i , jb_i , J , ka , kb , k) . <ja_f || Oa^k || ja_i> . <jb_f || Ob^k || jb_i>_J

double Wigner_signs::Oa_tensor_Ob_reduced_ME_calc (
						   const double ka , 
						   const double kb ,
						   const double k , 
						   const double ja_i , 
						   const double jb_i , 
						   const double Ji , 
						   const double ja_f , 
						   const double jb_f , 
						   const double Jf , 
						   const double Oa_reduced_OBME , 
						   const double Ob_reduced_OBME)
{	
  if (!is_it_triangle (ka , kb , k)) return 0.0;
  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const double hats = hat (Ji)*hat (Jf)*hat (k);

  const double Wig_9j = Wigner_9j (ja_f , jb_f , Jf , ja_i , jb_i , Ji , ka , kb , k);

  const double ME = hats * Wig_9j * Oa_reduced_OBME * Ob_reduced_OBME;

  return ME;
}




// <ja_f jb_f Jf || [[O1a^k1 x O2b^k2]^k12 x O3b^k3]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k12.
// O3b is a spherical tensor of rank k3 coupled to O1a x O2b to k.
// O1a acts on system a , O2b and O3b act on system b.
// Three-angular momentum recoupling is used to deal with [O1a^k1 x [O2b^k2 x O3b^k3]^k23]^k.
// [O1a^k1 x [O2b^k2 x O3b^k3]^k23]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a , O2b and O3b reduced matrix elements.
// O2b_tensor_O3b_reduced_OBMEs contains [O2b^k2 x O3b^k3]^k23 reduced OBMEs for k23 in |k2 - k3| to k2 + k3.

double Wigner_signs::O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (
								    const double k1 , 
								    const double k2 ,
								    const double k12 ,
								    const double k3 , 
								    const double k , 
								    const double ja_i , 
								    const double jb_i , 
								    const double Ji , 
								    const double ja_f , 
								    const double jb_f , 
								    const double Jf , 
								    const double Oa_reduced_OBME , 
								    const class array<double> &O2b_tensor_O3b_reduced_OBMEs)
{
  if (!is_it_triangle (k1 , k2 , k12)) return 0.0;
  if (!is_it_triangle (k12 , k3 , k))  return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k23_min_k2_k3 = abs (k2 - k3);

  const double k23_max_k2_k3 = k2 + k3;

  const double k23_min_k1_k = abs (k1 - k);

  const double k23_max_k1_k = k1 + k;

  const double k23_min = max (k23_min_k2_k3 , k23_min_k1_k);
  const double k23_max = min (k23_max_k2_k3 , k23_max_k1_k);

  const double k23_diff = k23_max - k23_min;

  if (rint (k23_diff) < 0.0) return 0.0;

  const unsigned int N23 = make_uns_int (k23_diff) + 1;

  class array<double> Wig_6j_table(N23);

  Wigner_6j_tab_calc (k2 , k3 , k12 , k , k1 , Wig_6j_table);

  double ME = 0.0;

  for (unsigned int i23 = 0 ; i23 < N23 ; i23++)
    {
      const double k23 = k23_min + i23;

      const double hat_k23 = hat (k23);

      const double Wig_6j = Wig_6j_table(i23);

      const unsigned int O2b_tensor_O3b_index = make_uns_int (k23 - k23_min_k2_k3);

      const double O2b_tensor_O3b_reduced_OBME = O2b_tensor_O3b_reduced_OBMEs(O2b_tensor_O3b_index);

      const double O1a_tensor_O2b_tensor_O3b_k23_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k1 , k23 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , Oa_reduced_OBME , O2b_tensor_O3b_reduced_OBME);

      ME += hat_k23*Wig_6j*O1a_tensor_O2b_tensor_O3b_k23_reduced_ME;
    }

  const int phase = minus_one_pow (k1 + k2 + k3 + k);

  const double hat_k12 = hat (k12);

  ME *= phase*hat_k12;

  return ME;
}





// <ja_f jb_f J | [O1a^k1 x O2b^k2]^k3 . O3b^k3 | ja_i jb_i J>
// --------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k3.
// O3b is a spherical tensor of rank k3 which form a scalar product with O1a x O2b.
// O1a acts on system a , O2b and O3b act on system b.
// [O1a^k1 x O2b^k2]^k3 . O3b^k3 is proportional to O1a^k1 . [O2b^k2 x O3b^k3]^k1 , which can be treated with the Wigner-Eckhart theorem.

double Wigner_signs::O1a_tensor_O2b_k3_scalar_O3b_ME_calc (
							   const double k1 , 
							   const double k2 , 
							   const double k3 , 
							   const double ja_i , 
							   const double jb_i , 
							   const double Ji , 
							   const double ja_f , 
							   const double jb_f , 
							   const double Jf , 
							   const double O1a_reduced_OBME , 
							   const double O2b_tensor_O3b_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_triangle (k1 , k2 , k3)) return 0.0;

  if (!is_it_integer (k3 - k1)) error_message_print_abort ("Complex phase encountered in double Wigner_signs::O1a_tensor_O2b_k3_scalar_O3b_ME_calc");

  const double O1a_scalar_O2b_tensor_O3b_k3_ME = Oa_scalar_Ob_ME_calc (k1 , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_reduced_OBME , O2b_tensor_O3b_reduced_OBME);

  const double ME = O1a_scalar_O2b_tensor_O3b_k3_ME*minus_one_pow (k3 - k1)*hat (k3)/hat(k1);

  return ME;
}






// <ja_f jb_f Jf || [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------
// O2a and O3b are spherical tensors of rank k2 and k3 respectively coupled to k23.
// O1a is a spherical tensor of rank k1 coupled to O2a x O3b to k.
// O1a and O2a act on system a , O3b acts on system b.
// Three-angular momentum recoupling is used to deal with [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k.
// [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a , O2a and O3b reduced matrix elements.
// O1a_tensor_O2a_reduced_OBMEs contains [O1a^k1 x O2a^k2]^k12 reduced OBMEs for k12 in |k1 - k2| to k1 + k2.

double Wigner_signs::O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (
								    const double k1 , 
								    const double k2 , 
								    const double k3 , 
								    const double k23 ,
								    const double k , 
								    const double ja_i , 
								    const double jb_i , 
								    const double Ji , 
								    const double ja_f , 
								    const double jb_f , 
								    const double Jf , 
								    const class array<double> &O1a_tensor_O2a_reduced_OBMEs , 
								    const double O3b_reduced_OBME)
{
  if (!is_it_triangle (k2 , k3 , k23)) return 0.0;
  if (!is_it_triangle (k1 , k23 , k))  return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k12_min_k1_k2 = abs (k1 - k2);

  const double k12_max_k1_k2 = k1 + k2;

  const double k12_min_k3_k = abs (k3 - k);

  const double k12_max_k3_k = k3 + k;

  const double k12_min = max (k12_min_k1_k2 , k12_min_k3_k);
  const double k12_max = min (k12_max_k1_k2 , k12_max_k3_k);

  const double k12_diff = k12_max - k12_min;

  if (rint (k12_diff) < 0.0) return 0.0;

  const unsigned int N12 = make_uns_int (k12_diff) + 1;

  class array<double> Wig_6j_table(N12);

  Wigner_6j_tab_calc (k1 , k2 , k23 , k3 , k , Wig_6j_table);

  double ME = 0.0;

  for (unsigned int i12 = 0 ; i12 < N12 ; i12++)
    {
      const double k12 = k12_min + i12;

      const double hat_k12 = hat (k12);

      const double Wig_6j = Wig_6j_table(i12);

      const unsigned int O1a_tensor_O2a_index = make_uns_int (k12 - k12_min_k1_k2);

      const double O1a_tensor_O2a_reduced_OBME = O1a_tensor_O2a_reduced_OBMEs(O1a_tensor_O2a_index);

      const double O1a_tensor_O2a_k12_tensor_O3b_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k12 , k3 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O3b_reduced_OBME , O1a_tensor_O2a_reduced_OBME);

      ME += hat_k12*Wig_6j*O1a_tensor_O2a_k12_tensor_O3b_reduced_ME;
    }

  const int phase = minus_one_pow (k1 + k2 + k3 + k);
  const double hat_k23 = hat (k23);

  ME *= phase*hat_k23;

  return ME;
}









// <ja_f jb_f J | O1a^k1 . [O2a^k2 x O3b^k3]^k1 | ja_i jb_i J>
// --------------------------------------------------------
// O2a and O3b are spherical tensors of rank k2 and k3 respectively coupled to k1.
// O1a is a spherical tensor of rank k1 which form a scalar product with O2a x O3b.
// O1a and O2a act on system a , O3b acts on system b.
// O1a^k1 . [O2a^k2 x O3b^k3]^k1 is proportional to [O1a^k1 x O2a^k2]^k3 . O3b^k3 , which can be treated with the Wigner-Eckhart theorem.

double Wigner_signs::O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (
								   const double k1 , 
								   const double k2 , 
								   const double k3 , 
								   const double ja_i , 
								   const double jb_i , 
								   const double Ji , 
								   const double ja_f , 
								   const double jb_f , 
								   const double Jf , 
								   const double O1a_tensor_O2a_reduced_OBME , 
								   const double O3b_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_triangle (k1 , k2 , k3)) return 0.0;

  if (!is_it_integer (k1 - k3)) error_message_print_abort ("Complex phase encountered in double Wigner_signs::O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc");

  const double O1a_scalar_O2a_k1_tensor_O3b_ME = Oa_scalar_Ob_ME_calc (k3 , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O3b_reduced_OBME , O1a_tensor_O2a_reduced_OBME);

  const double ME = O1a_scalar_O2a_k1_tensor_O3b_ME*minus_one_pow (k1 - k3)*hat (k1)/hat(k3);

  return ME;
}








// <ja_f jb_f Jf || [[O1a^k1 x O2b^k2]^k12 x [O3a^k3 x O4b^k4]^k34]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k12.
// O3a and O4b are spherical tensors of rank k3 and k4 respectively coupled to k34.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [[O1a^k1 x O3a^k3]^k13 x [O2b^k2 x O4b^k4]^k24]^k.
// [[O1a^k1 x O3a^k3]^k13 x [O2b^k2 x O4b^k4]^k24]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k13 reduced OBMEs for k13 in |k1 - k3| to k1 + k3.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k24 reduced OBMEs for k24 in |k2 - k4| to k2 + k4.

double Wigner_signs::O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (
										   const double k1 , 
										   const double k2 ,
										   const double k12 ,  
										   const double k3 ,  
										   const double k4 , 
										   const double k34 ,
										   const double k , 
										   const double ja_i , 
										   const double jb_i , 
										   const double Ji , 
										   const double ja_f , 
										   const double jb_f , 
										   const double Jf , 
										   const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
										   const class array<double> &O2b_tensor_O4b_reduced_OBMEs)
{
  if (!is_it_triangle (k1 , k2 , k12)) return 0.0;
  if (!is_it_triangle (k3 , k4 , k34)) return 0.0;
  if (!is_it_triangle (k12 , k34 , k)) return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k13_min = abs (k1 - k3);

  const double k13_max = k1 + k3;

  const double k24_min_k2_k4 = abs (k2 - k4);

  const double k24_max_k2_k4 = k2 + k4;

  const double k13_diff = k13_max - k13_min;

  if (rint (k13_diff) < 0.0) return 0.0;

  const unsigned int N_k13 = make_uns_int (k13_diff) + 1;

  double ME = 0.0;

  for (unsigned int i13 = 0 ; i13 < N_k13 ; i13++)
    {
      const double k13 = k13_min + i13;

      const double hat_k13 = hat (k13);

      const double k24_min_k13_k = abs (k13 - k);

      const double k24_max_k13_k = k13 + k;

      const double k24_min = max (k24_min_k2_k4 , k24_min_k13_k);
      const double k24_max = min (k24_max_k2_k4 , k24_max_k13_k);

      const double k24_diff = k24_max - k24_min;

      if (rint (k24_diff) < 0.0) continue;

      const unsigned int N_k24 = make_uns_int (k24_diff) + 1;

      const unsigned int O1a_tensor_O3a_index = i13;

      const double O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      double sub_ME = 0.0;

      for (unsigned int i24 = 0 ; i24 < N_k24 ; i24++)
	{
	  const double k24 = k24_min + i24 , hat_k24 = hat (k24);

	  const unsigned int O2b_tensor_O4b_index = make_uns_int (k24 - k24_min_k2_k4);

	  const double O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

	  const double Wig_9j = Wigner_9j (k1 , k2 , k12 , k3 , k4 , k34 , k13 , k24 , k);

	  const double O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k13 , k24 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

	  sub_ME += hat_k24*Wig_9j*O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME;
	}

      ME += sub_ME*hat_k13;
    }

  const double hats = hat (k12)*hat (k34);

  ME *= hats;

  return ME;
}






// <ja_f jb_f J | [[O1a^k1 x O2b^k2]^k . [O3a^k3 x O4b^k4]^k | ja_i jb_i J>
// --------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k.
// O3a and O4b are spherical tensors of rank k3 and k4 respectively coupled to k.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [O1a^k1 x O3a^k3]^k' . [O2b^k2 x O4b^k4]^k'.
// [O1a^k1 x O3a^k3]^k' . [O2b^k2 x O4b^k4]^k' is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from  O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k' reduced OBMEs for k' in |k1 - k3| to k1 + k3.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k' reduced OBMEs for k' in |k2 - k4| to k2 + k4.

double Wigner_signs::O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (
								       const double k1 , 
								       const double k2 , 
								       const double k , 
								       const double k3 , 
								       const double k4 , 
								       const double ja_i , 
								       const double jb_i , 
								       const double Ji , 
								       const double ja_f , 
								       const double jb_f , 
								       const double Jf , 
								       const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
								       const class array<double> &O2b_tensor_O4b_reduced_OBMEs)
{	
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_integer (k2 + k3)) error_message_print_abort ("Complex phase encountered in double Wigner_signs::O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc");

  if (!is_it_triangle (k1 , k2 , k)) return 0.0;
  if (!is_it_triangle (k3 , k4 , k)) return 0.0;
  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const double kp_min_k1_k3 = abs (k1 - k3) , kp_max_k1_k3 = k1 + k3;
  const double kp_min_k2_k4 = abs (k2 - k4) , kp_max_k2_k4 = k2 + k4;

  const double kp_min = max (kp_min_k1_k3 , kp_min_k2_k4);
  const double kp_max = min (kp_max_k1_k3 , kp_max_k2_k4);
  
  const double kp_diff = kp_max - kp_min;

  if (rint (kp_diff) < 0.0) return 0.0;

  const unsigned int Np = make_uns_int (kp_diff) + 1;

  double ME = 0.0;

  for (unsigned int ip = 0 ; ip < Np ; ip++)
    {
      const double kp = kp_min + ip , two_kp = 2.0*k;

      const unsigned int O1a_tensor_O3a_index = make_uns_int (kp - kp_min_k1_k3);
      
      const double O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      const unsigned int O2b_tensor_O4b_index = make_uns_int (kp - kp_min_k2_k4);

      const double O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

      const double Wig_6j = Wigner_6j (k1 , k2 , k , k4 , k3 , kp);

      const double O1a_tensor_O3a_kp_scalar_O2b_tensor_O4b_kp_ME = Oa_scalar_Ob_ME_calc (kp , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

      ME += (two_kp + 1.0) * minus_one_pow (k2 + k3 + two_kp) * Wig_6j * O1a_tensor_O3a_kp_scalar_O2b_tensor_O4b_kp_ME;
    }

  return ME;
}






// <ja_f jb_f Jf || [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l) || ja_i jb_i Ji>
// -----------------------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k.
// O3a and O4b are spherical tensors of rank l.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l).
// The Wigner 9j sign becomes a Wigner 6j sign due to the presence of a scalar product.
// [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l) is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k13 reduced OBMEs for k13 in |k1 - l| to k1 + l.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k24 reduced OBMEs for k24 in |k2 - l| to k2 + l.

double Wigner_signs::O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (
								      const double k1 , 
								      const double k2 ,
								      const double k , 
								      const double l , 
								      const double ja_i , 
								      const double jb_i , 
								      const double Ji , 
								      const double ja_f , 
								      const double jb_f , 
								      const double Jf , 
								      const class array<double> &O1a_tensor_O3a_reduced_OBMEs , 
								      const class array<double> &O2b_tensor_O4b_reduced_OBMEs)
{
  if (!is_it_integer (l)) error_message_print_abort ("Complex phase encountered in double Wigner_signs::O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc");

  if (!is_it_triangle (k1 , k2 , k)) return 0.0;

  const double k13_min = abs (k1 - l);

  const double k13_max = k1 + l;

  const double k_plus_k1 = k + k1;

  const double k24_min_k2_l = abs (k2 - l);

  const double k24_max_k2_l = k2 + l;

  const double k13_diff = k13_max - k13_min;

  if (rint (k13_diff) < 0.0) return 0.0;

  const unsigned int N_k13 = make_uns_int (k13_diff) + 1;

  double ME = 0.0;

  for (unsigned int i13 = 0 ; i13 < N_k13 ; i13++)
    {
      const double k13 = k13_min + i13;

      const double hat_k13 = hat (k13);

      const double k24_min_k13_k = abs (k13 - k);

      const double k24_max_k13_k = k13 + k;
      
      const double k24_min = max (k24_min_k2_l , k24_min_k13_k);
      const double k24_max = min (k24_max_k2_l , k24_max_k13_k);
      
      const double k24_diff = k24_max - k24_min;

      if (rint (k24_diff) < 0.0) continue;

      const unsigned int N_k24 = make_uns_int (k24_diff) + 1;

      const unsigned int O1a_tensor_O3a_index = i13;

      const double O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      class array<double> Wig_6j_table(N_k24);

      Wigner_6j_tab_calc (k13 , k , k1 , k2 , l , Wig_6j_table);

      double sub_ME = 0.0;

      for (unsigned int i24 = 0 ; i24 < N_k24 ; i24++)
	{
	  const double k24 = k24_min + i24;

	  const double hat_k24 = hat (k24);

	  const unsigned int O2b_tensor_O4b_index = make_uns_int (k24 - k24_min_k2_l);
	  
	  const double O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

	  const double Wig_6j = Wig_6j_table(i24);

	  const int phase = minus_one_pow (k24 + k_plus_k1);
	  
	  const double O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k13 , k24 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

	  sub_ME += phase*hat_k24*Wig_6j*O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME;
	}

      ME += sub_ME*hat_k13;
    }

  return ME;
}








// <ja_f jb_f J | Oa^k . Ob^k | ja_i jb_i J>
// -----------------------------------------
// Oa and Ob are spherical tensors of rank k coupled to zero acting on systems a and b respectively.
// It is equal to (-1)^(jb_f + ja_i + J) . Wigner_6j (ja_f , jb_f , J , jb_i , ja_i , k) . <ja_f || Oa^k || ja_i> . <jb_f || Ob^k || jb_i>_J

complex<double> Wigner_signs::Oa_scalar_Ob_ME_calc (
						    const double k , 
						    const double ja_i , 
						    const double jb_i , 
						    const double Ji , 
						    const double ja_f , 
						    const double jb_f , 
						    const double Jf , 
						    const complex<double> &Oa_reduced_OBME , 
						    const complex<double> &Ob_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  const int phase = minus_one_pow (jb_f + ja_i + Jf);
  
  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , jb_i , ja_i , k);

  const complex<double> ME = phase * Wig_6j * Oa_reduced_OBME * Ob_reduced_OBME;

  return ME;
}








// <ja_f jb_f Jf || Oa^k tensor Ib || ja_i jb_i Ji>
// ------------------------------------------------
// Oa^k is a spherical tensor of rank k acting on the first system a. Ib is identity acting on the second system b.
// It is equal to (-1)^(ja_f + jb_f + Ji + k) . Wigner_6j (ja_f , jb_f , Jf , Ji , k , ja_i) . <ja_f || Oa^k || ja_i> . delta (jb_i , jb_f)

complex<double> Wigner_signs::Oa_reduced_ME_calc (
						  const double k , 
						  const double ja_i , 
						  const double jb_i , 
						  const double Ji , 
						  const double ja_f , 
						  const double jb_f , 
						  const double Jf , 
						  const complex<double> &Oa_reduced_OBME) 
{
  if (rint (jb_i - jb_f) != 0.0) return 0.0;

  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const int phase = minus_one_pow (ja_f + jb_f + Ji + k);
  
  const double hats = hat (Ji)*hat (Jf);

  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , Ji , k , ja_i);

  const complex<double> ME = phase * hats * Wig_6j * Oa_reduced_OBME;

  return ME;
}







// <ja_f jb_f Jf || Ia tensor Ob^k || ja_i jb_i Ji>
// ------------------------------------------------
// Ia is identity acting on the first system a. Ob^k is a spherical tensor of rank k acting on the second system b.
// It is equal to (-1)^(ja_i + jb_i + Jf + k) . hat (Ji) . hat (Jf) . Wigner_6j (ja_f , jb_f , Jf , k , Ji , jb_i) . delta (ja_i , ja_f) . <jb_f || Ob^k || jb_i>

complex<double> Wigner_signs::Ob_reduced_ME_calc (
						  const double k , 
						  const double ja_i , 
						  const double jb_i , 
						  const double Ji , 
						  const double ja_f , 
						  const double jb_f , 
						  const double Jf , 
						  const complex<double> &Ob_reduced_OBME) 
{
  if (rint (ja_i - ja_f) != 0.0) return 0.0;

  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const int phase = minus_one_pow (ja_i + jb_i + Jf + k);
  
  const double hats = hat (Ji)*hat (Jf);

  const double Wig_6j = Wigner_6j (ja_f , jb_f , Jf , k , Ji , jb_i);

  const complex<double> ME = phase * hats * Wig_6j * Ob_reduced_OBME;

  return ME;
}






// <ja_f jb_f Jf || [Oa^ka x Ob^kb]^k || ja_i jb_i Ji>
// ---------------------------------------------------
// Oa and Ob are spherical tensors of rank ka and kb , acting on systems a and b , respectively coupled to k .
// It is equal to hat (Ji) . hat (Jf) . hat (k) .  Wigner_9j (ja_f , jb_f , Jf , ja_i , jb_i , J , ka , kb , k) . <ja_f || Oa^k || ja_i> . <jb_f || Ob^k || jb_i>_J

complex<double> Wigner_signs::Oa_tensor_Ob_reduced_ME_calc (
							    const double ka , 
							    const double kb ,
							    const double k , 
							    const double ja_i , 
							    const double jb_i , 
							    const double Ji , 
							    const double ja_f , 
							    const double jb_f , 
							    const double Jf , 
							    const complex<double> &Oa_reduced_OBME , 
							    const complex<double> &Ob_reduced_OBME)
{
  if (!is_it_triangle (ka , kb , k)) return 0.0;
  if (!is_it_triangle (Jf , k , Ji)) return 0.0;

  const double hats = hat (Ji)*hat (Jf)*hat (k);
  
  const double Wig_9j = Wigner_9j (ja_f , jb_f , Jf , ja_i , jb_i , Ji , ka , kb , k);

  const complex<double> ME = hats * Wig_9j * Oa_reduced_OBME * Ob_reduced_OBME;

  return ME;
}





// <ja_f jb_f Jf || [[O1a^k1 x O2b^k2]^k12 x O3b^k3]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k12.
// O3b is a spherical tensor of rank k3 coupled to O1a x O2b to k.
// O1a acts on system a , O2b and O3b act on system b.
// Three-angular momentum recoupling is used to deal with [O1a^k1 x [O2b^k2 x O3b^k3]^k23]^k.
// [O1a^k1 x [O2b^k2 x O3b^k3]^k23]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a , O2b and O3b reduced matrix elements.
// O2b_tensor_O3b_reduced_OBMEs contains [O2b^k2 x O3b^k3]^k23 reduced OBMEs for k23 in |k2 - k3| to k2 + k3.

complex<double> Wigner_signs::O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (
									     const double k1 , 
									     const double k2 , 
									     const double k12 , 
									     const double k3 ,
									     const double k , 
									     const double ja_i , 
									     const double jb_i , 
									     const double Ji , 
									     const double ja_f , 
									     const double jb_f , 
									     const double Jf , 
									     const complex<double> &Oa_reduced_OBME , 
									     const class array<complex<double> > &O2b_tensor_O3b_reduced_OBMEs)
{
  if (!is_it_triangle (k1 , k2 , k12)) return 0.0;
  if (!is_it_triangle (k12 , k3 , k))  return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k23_min_k2_k3 = abs (k2 - k3);

  const double k23_max_k2_k3 = k2 + k3;

  const double k23_min_k1_k = abs (k1 - k);

  const double k23_max_k1_k = k1 + k;

  const double k23_min = max (k23_min_k2_k3 , k23_min_k1_k);
  const double k23_max = min (k23_max_k2_k3 , k23_max_k1_k);
  
  const double k23_diff = k23_max - k23_min;

  if (rint (k23_diff) < 0.0) return 0.0;

  const unsigned int N23 = make_uns_int (k23_max - k23_min) + 1;

  class array<double> Wig_6j_table(N23);

  Wigner_6j_tab_calc (k2 , k3 , k12 , k , k1 , Wig_6j_table);

  complex<double> ME = 0.0;

  for (unsigned int i23 = 0 ; i23 < N23 ; i23++)
    {
      const double k23 = k23_min + i23;

      const double hat_k23 = hat (k23);

      const double Wig_6j = Wig_6j_table(i23);

      const int O2b_tensor_O3b_index = make_uns_int (k23 - k23_min_k2_k3);
      
      const complex<double> O2b_tensor_O3b_reduced_OBME = O2b_tensor_O3b_reduced_OBMEs(O2b_tensor_O3b_index);

      const complex<double> O1a_tensor_O2b_tensor_O3b_k23_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k1 , k23 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , Oa_reduced_OBME , O2b_tensor_O3b_reduced_OBME);

      ME += hat_k23*Wig_6j*O1a_tensor_O2b_tensor_O3b_k23_reduced_ME;
    }

  const int phase = minus_one_pow (k1 + k2 + k3 + k);
  
  const double hat_k12 = hat (k12);

  ME *= phase*hat_k12;

  return ME;
}







// <ja_f jb_f J | [O1a^k1 x O2b^k2]^k3 . O3b^k3 | ja_i jb_i J>
// --------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k3.
// O3b is a spherical tensor of rank k3 which form a scalar product with O1a x O2b.
// O1a acts on system a , O2b and O3b act on system b.
// [O1a^k1 x O2b^k2]^k3 . O3b^k3 is proportional to O1a^k1 . [O2b^k2 x O3b^k3]^k1 , which can be treated with the Wigner-Eckhart theorem.

complex<double> Wigner_signs::O1a_tensor_O2b_k3_scalar_O3b_ME_calc (
								    const double k1 , 
								    const double k2 , 
								    const double k3 , 
								    const double ja_i , 
								    const double jb_i , 
								    const double Ji , 
								    const double ja_f , 
								    const double jb_f , 
								    const double Jf , 
								    const complex<double> &O1a_reduced_OBME , 
								    const complex<double> &O2b_tensor_O3b_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_triangle (k1 , k2 , k3)) return 0.0;

  if (!is_it_integer (k3 - k1)) error_message_print_abort ("Complex phase encountered in complex<double> Wigner_signs::O1a_tensor_O2b_k3_scalar_O3b_ME_calc");

  const complex<double> O1a_scalar_O2b_tensor_O3b_k3_ME = Oa_scalar_Ob_ME_calc (k1 , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_reduced_OBME , O2b_tensor_O3b_reduced_OBME);

  const complex<double> ME = O1a_scalar_O2b_tensor_O3b_k3_ME*hat (k3)/hat(k1)*minus_one_pow (k3 - k1);

  return ME;
}




// <ja_f jb_f Jf || [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------
// O2a and O3b are spherical tensors of rank k2 and k3 respectively coupled to k23.
// O1a is a spherical tensor of rank k1 coupled to O2a x O3b to k.
// O1a and O2a act on system a , O3b acts on system b.
// Three-angular momentum recoupling is used to deal with [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k.
// [O1a^k1 x [O2a^k2 x O3b^k3]^k23]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a , O2a and O3b reduced matrix elements.
// O1a_tensor_O2a_reduced_OBMEs contains [O1a^k1 x O2a^k2]^k12 reduced OBMEs for k12 in |k1 - k2| to k1 + k2.

complex<double> Wigner_signs::O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (
									     const double k1 , 
									     const double k2 , 
									     const double k3 , 
									     const double k23 ,
									     const double k , 
									     const double ja_i , 
									     const double jb_i , 
									     const double Ji , 
									     const double ja_f , 
									     const double jb_f , 
									     const double Jf , 
									     const class array<complex<double> > &O1a_tensor_O2a_reduced_OBMEs , 
									     const complex<double> &O3b_reduced_OBME)
{
  if (!is_it_triangle (k2 , k3 , k23)) return 0.0;
  if (!is_it_triangle (k1 , k23 , k))  return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k12_min_k1_k2 = abs (k1 - k2);

  const double k12_max_k1_k2 = k1 + k2;

  const double k12_min_k3_k = abs (k3 - k);

  const double k12_max_k3_k = k3 + k;

  const double k12_min = max (k12_min_k1_k2 , k12_min_k3_k);
  const double k12_max = min (k12_max_k1_k2 , k12_max_k3_k);

  const double k12_diff = k12_max - k12_min;

  if (rint (k12_diff) < 0.0) return 0.0;

  const unsigned int N12 = make_uns_int (k12_diff) + 1;

  class array<double> Wig_6j_table(N12);

  Wigner_6j_tab_calc (k1 , k2 , k23 , k3 , k , Wig_6j_table);

  complex<double> ME = 0.0;

  for (unsigned int i12 = 0 ; i12 < N12 ; i12++)
    {
      const double k12 = k12_min + i12;

      const double hat_k12 = hat (k12);

      const double Wig_6j = Wig_6j_table(i12);

      const unsigned int O1a_tensor_O2_index = make_uns_int (k12 - k12_min_k1_k2);
      
      const complex<double> O1a_tensor_O2a_reduced_OBME = O1a_tensor_O2a_reduced_OBMEs(O1a_tensor_O2_index);

      const complex<double> O1a_tensor_O2a_k12_tensor_O3b_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k12 , k3 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O3b_reduced_OBME , O1a_tensor_O2a_reduced_OBME);

      ME += hat_k12*Wig_6j*O1a_tensor_O2a_k12_tensor_O3b_reduced_ME;
    }

  const int phase = minus_one_pow (k1 + k2 + k3 + k);
  
  const double hat_k23 = hat (k23);

  ME *= phase*hat_k23;

  return ME;
}








// <ja_f jb_f J | O1a^k1 . [O2a^k2 x O3b^k3]^k1 | ja_i jb_i J>
// --------------------------------------------------------
// O2a and O3b are spherical tensors of rank k2 and k3 respectively coupled to k1.
// O1a is a spherical tensor of rank k1 which form a scalar product with O2a x O3b.
// O1a and O2a act on system a , O3b acts on system b.
// O1a^k1 . [O2a^k2 x O3b^k3]^k1 is proportional to [O1a^k1 x O2a^k2]^k3 . O3b^k3 , which can be treated with the Wigner-Eckhart theorem.

complex<double> Wigner_signs::O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (
									    const double k1 , 
									    const double k2 , 
									    const double k3 , 
									    const double ja_i , 
									    const double jb_i , 
									    const double Ji , 
									    const double ja_f , 
									    const double jb_f , 
									    const double Jf , 
									    const complex<double> &O1a_tensor_O2a_reduced_OBME , 
									    const complex<double> &O3b_reduced_OBME)
{
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_triangle (k1 , k2 , k3)) return 0.0;

  if (!is_it_integer (k1 - k3)) error_message_print_abort ("Complex phase encountered in complex<double> Wigner_signs::O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc");

  const complex<double> O1a_scalar_O2a_k1_tensor_O3b_ME = Oa_scalar_Ob_ME_calc (k3 , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O3b_reduced_OBME , O1a_tensor_O2a_reduced_OBME);

  const complex<double> ME = O1a_scalar_O2a_k1_tensor_O3b_ME*minus_one_pow (k1 - k3)*hat (k1)/hat(k3);

  return ME;
}




// <ja_f jb_f Jf || [[O1a^k1 x O2b^k2]^k12 x [O3a^k3 x O4b^k4]^k34]^k || ja_i jb_i Ji>
// -----------------------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k12.
// O3a and O4b are spherical tensors of rank k3 and k4 respectively coupled to k34.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [[O1a^k1 x O3a^k3]^k13 x [O2b^k2 x O4b^k4]^k24]^k.
// [[O1a^k1 x O3a^k3]^k13 x [O2b^k2 x O4b^k4]^k24]^k is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k13 reduced OBMEs for k13 in |k1 - k3| to k1 + k3.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k24 reduced OBMEs for k24 in |k2 - k4| to k2 + k4.

complex<double> Wigner_signs::O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (
											    const double k1 , 
											    const double k2 ,
											    const double k12 ,  
											    const double k3 ,  
											    const double k4 , 
											    const double k34 ,
											    const double k , 
											    const double ja_i , 
											    const double jb_i , 
											    const double Ji , 
											    const double ja_f , 
											    const double jb_f , 
											    const double Jf , 
											    const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
											    const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs)
{
  if (!is_it_triangle (k1 , k2 , k12)) return 0.0;
  if (!is_it_triangle (k3 , k4 , k34)) return 0.0;
  if (!is_it_triangle (k12 , k34 , k)) return 0.0;
  if (!is_it_triangle (Jf , k , Ji))   return 0.0;

  const double k13_min = abs (k1 - k3);

  const double k13_max = k1 + k3;

  const double k24_min_k2_k4 = abs (k2 - k4);

  const double k24_max_k2_k4 = k2 + k4;

  const double k13_diff = k13_max - k13_min;

  if (rint (k13_diff) < 0.0) return 0.0;

  const unsigned int N_k13 = make_uns_int (k13_diff) + 1;

  complex<double> ME = 0.0;

  for (unsigned int i13 = 0 ; i13 < N_k13 ; i13++)
    {
      const double k13 = k13_min + i13;

      const double hat_k13 = hat (k13);

      const unsigned int O1a_tensor_O3a_index = i13;
      
      const complex<double> O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      const double k24_min_k13_k = abs (k13 - k);

      const double k24_max_k13_k = k13 + k;

      const double k24_min = max (k24_min_k2_k4 , k24_min_k13_k);
      const double k24_max = min (k24_max_k2_k4 , k24_max_k13_k);
      
      const double k24_diff = k24_max - k24_min;

      if (rint (k24_diff) < 0.0) continue;

      const unsigned int N_k24 = make_uns_int (k24_diff) + 1;

      complex<double> sub_ME = 0.0;

      for (unsigned int i24 = 0 ; i24 < N_k24 ; i24++)
	{
	  const double k24 = k24_min + i24;

	  const double hat_k24 = hat (k24);

	  const unsigned int O2b_tensor_O4b_index = make_uns_int (k24 - k24_min_k2_k4);

	  const complex<double> O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

	  const double Wig_9j = Wigner_9j (k1 , k2 , k12 , k3 , k4 , k34 , k13 , k24 , k);
	  
	  const complex<double> O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k13 , k24 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf ,
														 O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

	  sub_ME += hat_k24*Wig_9j*O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME;
	}

      ME += sub_ME*hat_k13;
    }

  const double hats = hat (k12)*hat (k34);

  ME *= hats;

  return ME;
}





// <ja_f jb_f J | [[O1a^k1 x O2b^k2]^k . [O3a^k3 x O4b^k4]^k | ja_i jb_i J>
// --------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k.
// O3a and O4b are spherical tensors of rank k3 and k4 respectively coupled to k.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [O1a^k1 x O3a^k3]^k' . [O2b^k2 x O4b^k4]^k'.
// [O1a^k1 x O3a^k3]^k' . [O2b^k2 x O4b^k4]^k' is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from  O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k' reduced OBMEs for k' in |k1 - k3| to k1 + k3.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k' reduced OBMEs for k' in |k2 - k4| to k2 + k4.

complex<double> Wigner_signs::O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (
										const double k1 , 
										const double k2 , 
										const double k , 
										const double k3 , 
										const double k4 , 
										const double ja_i , 
										const double jb_i , 
										const double Ji , 
										const double ja_f , 
										const double jb_f , 
										const double Jf , 
										const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
										const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs)
{	
  if (rint (Ji - Jf) != 0.0) return 0.0;

  if (!is_it_integer (k2 + k3)) error_message_print_abort ("Complex phase encountered in complex<double> Wigner_signs::O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc");

  if (!is_it_triangle (k1 , k2 , k)) return 0.0;
  if (!is_it_triangle (k3 , k4 , k)) return 0.0;

  const double kp_min_k1_k3 = abs (k1 - k3) , kp_max_k1_k3 = k1 + k3;
  const double kp_min_k2_k4 = abs (k2 - k4) , kp_max_k2_k4 = k2 + k4;

  const double kp_min = max (kp_min_k1_k3 , kp_min_k2_k4);
  const double kp_max = min (kp_max_k1_k3 , kp_max_k2_k4);
  
  const double kp_diff = kp_max - kp_min;

  if (rint (kp_diff) < 0.0) return 0.0;

  const unsigned int Np = make_uns_int (kp_diff) + 1;

  complex<double> ME = 0.0;

  for (unsigned int ip = 0 ; ip < Np ; ip++)
    {
      const double kp = kp_min + ip;

      const double two_kp = 2.0*kp;

      const unsigned int O1a_tensor_O3a_index = make_uns_int (kp - kp_min_k1_k3);

      const complex<double> O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      const unsigned int O2b_tensor_O4b_index = make_uns_int (kp - kp_min_k2_k4);

      const complex<double> O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

      const double Wig_6j = Wigner_6j (k1 , k2 , k , k4 , k3 , kp);
      
      const complex<double> O1a_tensor_O3a_kp_scalar_O2b_tensor_O4b_kp_ME = Oa_scalar_Ob_ME_calc (kp , ja_i , jb_i , Ji , ja_f , jb_f , Jf , O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

      ME += (two_kp + 1.0) * minus_one_pow (k2 + k3 + two_kp) * Wig_6j * O1a_tensor_O3a_kp_scalar_O2b_tensor_O4b_kp_ME;
    }

  return ME;
}





// <ja_f jb_f Jf || [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l) || ja_i jb_i Ji>
// -----------------------------------------------------------------------------------
// O1a and O2b are spherical tensors of rank k1 and k2 respectively coupled to k.
// O3a and O4b are spherical tensors of rank l.
// O1a and O3a act on system a , O2b and O4b act on system b.
// Four-angular momentum recoupling is used to deal with [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l).
// The Wigner 9j sign becomes a Wigner 6j sign due to the presence of a scalar product.
// [O1a^k1 x O2b^k2]^k . (O3a^l . O4b^l) is separated in two operators acting on system a and b separately.
// Thus , the Wigner-Eckhart theorem can be used to calculate it from O1a x O3a and O2b x O4b reduced matrix elements.
// O1a_tensor_O3a_reduced_OBMEs contains [O1a^k1 x O3a^k3]^k13 reduced OBMEs for k13 in |k1 - l| to k1 + l.
// O2b_tensor_O4b_reduced_OBMEs contains [O2b^k2 x O4b^k4]^k24 reduced OBMEs for k24 in |k2 - l| to k2 + l.

complex<double> Wigner_signs::O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (
									       const double k1 , 
									       const double k2 ,
									       const double k , 
									       const double l , 
									       const double ja_i , 
									       const double jb_i , 
									       const double Ji , 
									       const double ja_f , 
									       const double jb_f , 
									       const double Jf , 
									       const class array<complex<double> > &O1a_tensor_O3a_reduced_OBMEs , 
									       const class array<complex<double> > &O2b_tensor_O4b_reduced_OBMEs)
{
  if (!is_it_integer (l)) error_message_print_abort ("Complex phase encountered in complex<double> Wigner_signs::O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc");

  if (!is_it_triangle (k1 , k2 , k)) return 0.0;

  const double k13_min = abs (k1 - l);

  const double k13_max = k1 + l;

  const double k_plus_k1 = k + k1;

  const double k24_min_k2_l = abs (k2 - l);

  const double k24_max_k2_l = k2 + l;

  const double k13_diff = k13_max - k13_min;

  if (rint (k13_diff) < 0.0) return 0.0;

  const unsigned int N_k13 = make_uns_int (k13_diff) + 1;

  complex<double> ME = 0.0;

  for (unsigned int i13 = 0 ; i13 < N_k13 ; i13++)
    {
      const double k13 = k13_min + i13;

      const double hat_k13 = hat (k13);

      const double k24_min_k13_k = abs (k13 - k);

      const double k24_max_k13_k = k13 + k;

      const double k24_min = max (k24_min_k2_l , k24_min_k13_k);
      const double k24_max = min (k24_max_k2_l , k24_max_k13_k);

      const double k24_diff = k24_max - k24_min;

      if (rint (k24_diff) < 0.0) continue;

      const unsigned int N_k24 = make_uns_int (k24_diff) + 1;

      const unsigned int O1a_tensor_O3a_index = i13;
      
      const complex<double> O1a_tensor_O3a_reduced_OBME = O1a_tensor_O3a_reduced_OBMEs(O1a_tensor_O3a_index);

      class array<double> Wig_6j_table(N_k24);

      Wigner_6j_tab_calc (k13 , k , k1 , k2 , l , Wig_6j_table);

      complex<double> sub_ME = 0.0;

      for (unsigned int i24 = 0 ; i24 < N_k24 ; i24++)
	{
	  const double k24 = k24_min + i24;

	  const double hat_k24 = hat (k24);

	  const unsigned int O2b_tensor_O4b_index = make_uns_int (k24 - k24_min_k2_l);
	  
	  const complex<double> O2b_tensor_O4b_reduced_OBME = O2b_tensor_O4b_reduced_OBMEs(O2b_tensor_O4b_index);

	  const double Wig_6j = Wig_6j_table(i24);

	  const int phase = minus_one_pow (k24 + k_plus_k1);
	  
	  const complex<double> O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME = Oa_tensor_Ob_reduced_ME_calc (k13 , k24 , k , ja_i , jb_i , Ji , ja_f , jb_f , Jf ,
														 O1a_tensor_O3a_reduced_OBME , O2b_tensor_O4b_reduced_OBME);

	  sub_ME += phase*hat_k24*Wig_6j*O1a_tensor_O3a_k13_O2b_tensor_O4b_k24_reduced_ME;
	}

      ME += sub_ME*hat_k13;
    }

  return ME;
}




//--// small Wigner d-matrix d_{M , M'}^{J} (beta)
//--// it is related to the Wigner D-matrix by:
//
// D_{M , M'}^{J} (alpha , beta , gamma) = e^{-i M alpha} d_{M , M'}^{J} (beta) e^{-i M' gamma}
//
//--// see "Quantum theory of angular momentum" (D. A. Varshalovich , A. N. Moskalev and V. K. Khersonskii) p.77
double Wigner_signs::Wigner_d_small (
				     const double J , 
				     const double M , 
				     const double Mp , 
				     const double beta_rad)
{
  if ((beta_rad < 0.0) || (beta_rad > M_PI)) error_message_print_abort ("beta_rad must be in [0:Pi] in Wigner_d_small.");

  if ((rint (J - abs (M)) < 0.0) || (rint (J - abs (Mp)) < 0.0)) return 0;
  
  if (beta_rad == 0.0) return (rint (M - Mp) == 0.0) ? (1.0) : (0.0);

  const int two_J = make_int (2.0 * J);

  const int M_plus_Mp = make_int (M + Mp);

  const int J_plus_M  = make_int (J + M);
  const int J_minus_M = make_int (J - M);

  const int J_plus_Mp  = make_int (J + Mp);
  const int J_minus_Mp = make_int (J - Mp);

  const double factorial_product = factorial (J_plus_M) * factorial (J_minus_M) * factorial (J_plus_Mp) * factorial (J_minus_Mp);
  
  const double const_term = minus_one_pow (J_plus_M) * sqrt (factorial_product);	

  const double half_beta_rad = 0.5 * beta_rad;

  const double cos_half_beta_rad = cos (half_beta_rad);
  const double sin_half_beta_rad = sin (half_beta_rad);

  const double cos_half_beta_rad_2 = cos_half_beta_rad*cos_half_beta_rad;
  const double sin_half_beta_rad_2 = sin_half_beta_rad*sin_half_beta_rad;

  const int k_low = max (0 , M_plus_Mp);

  const int k_high = min (J_plus_M , J_plus_Mp);

  const int two_k_low = 2 * k_low;

  double factorial_k = factorial (k_low);
  double factorial_k_minus_MMp = factorial (k_low - M_plus_Mp);

  double factorial_JM_minus_k  = factorial (J_plus_M  - k_low);
  double factorial_JMp_minus_k = factorial (J_plus_Mp - k_low);

  double pow_cos_half_beta_rad = pow (cos_half_beta_rad , two_k_low - M_plus_Mp);
  
  double pow_sin_half_beta_rad = pow (sin_half_beta_rad , M_plus_Mp + two_J - two_k_low);

  double sum_term = 0.0;

  for (int k = k_low ; k < k_high ; k++)
    {
      sum_term += minus_one_pow (k) * pow_cos_half_beta_rad * pow_sin_half_beta_rad / (factorial_k * factorial_JM_minus_k * factorial_JMp_minus_k * factorial_k_minus_MMp);

      const int kp1 = k + 1;

      factorial_k *= kp1;

      factorial_k_minus_MMp *= kp1 - M_plus_Mp;

      factorial_JM_minus_k  /= J_plus_M  - k;
      factorial_JMp_minus_k /= J_plus_Mp - k;

      pow_cos_half_beta_rad *= cos_half_beta_rad_2;
      pow_sin_half_beta_rad /= sin_half_beta_rad_2;
    }

  sum_term += minus_one_pow (k_high) * pow_cos_half_beta_rad * pow_sin_half_beta_rad / (factorial_k * factorial_JM_minus_k * factorial_JMp_minus_k * factorial_k_minus_MMp);

  const double d = const_term * sum_term;

  return d;
}




//--// Wigner D-matrix or D-function D_{M , M'}^{J} (alpha , beta , gamma)
//--// its elements are the matrix elements of the rotation operator \hat{D} (alpha , beta , gamma) in the JM representation
//--// the alpha , beta and gamma parameters are the Euler angles which specify the rotation
//--// typically:
//
// \Psi_{J , M'} (a' , b' , c') = \sum_{M = -J}^{J} \Psi_{J , M} (a , b , c) D_{M , M'}^{J} (alpha , beta , gamma)
//
// with (a , b) and (a' , b') the polar angles in the initial/final rotated systems
//--// see "Quantum theory of angular momentum" (D. A. Varshalovich , A. N. Moskalev and V. K. Khersonskii) p.77
complex<double> Wigner_signs::Wigner_D (
					const double J , 
					const double M , 
					const double Mp , 
					const double alpha_rad , 
					const double beta_rad , 
					const double gamma_rad)
{
  const complex<double> I (0.0 , 1.0);
  
  const complex<double> Wigner_D_value = exp (-I * M * alpha_rad) * Wigner_d_small (J , M , Mp , beta_rad) * exp (-I * Mp * gamma_rad);

  return Wigner_D_value;
}


