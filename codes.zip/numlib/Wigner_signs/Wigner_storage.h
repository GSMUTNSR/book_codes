#ifndef WIGNERSTORAGE_H
#define WIGNERSTORAGE_H

namespace Wigner_storage
{
  void sort (const int dimension , int tab[])
  {
    for (int i = 1 ; i < dimension ; i++)
      {
	int s = tab[i];

	int ii = i;

	int other_s;
	
	while ((ii > 0) && ((other_s = tab[ii - 1]) > s)) tab[ii] = other_s , ii--;

	tab[ii] = s;
      }
  }  

  class three_j
  {
  public:
    three_j (const double Jmax) 
    {
      const int two_Jmax = make_uns_int (2.0*Jmax);

      const int dimension = (two_Jmax*(274 + two_Jmax*(225 + two_Jmax*(85 + two_Jmax*(15 + two_Jmax)))))/120 + 1;

      table = new double [dimension];
      
      for (unsigned int i = 0 ; i < dimension ; i++) table[i] = 0.0;

      for (unsigned int S = 0 ; S <= two_Jmax ; S +  + )
	for (unsigned int B = S ; B <= two_Jmax ; B +  + )
	  for (unsigned int T = B ; T <= two_Jmax ; T +  + )
	    for (unsigned int X = T ; X <= two_Jmax ; X +  + )
	      for (unsigned int L = X ; L <= two_Jmax ; L +  + )
		{
		  const unsigned int index = (L*(24 + L*(50 + L*(35 + L*(10 + L)))))/120 + (X*(6 + X*(11 + X*(6 + X))))/24 + (T*(2 + T*(3 + T)))/6 + (B*(B + 1))/2 + S;
		  
		  const double j1 = 0.5*(L + X + B - T);

		  const double j2 = 0.5*(X + B + S - T);

		  const double j3 = 0.5*(L + S);

		  const double m1 = j1 - X;

		  const double m2 = j2 - B;

		  const double m3 = T - j3;

		  table[index] = Wigner_3j (j1 , j2 , j3 , m1 , m2 , m3);
		}
    }

    ~three_j ()
    {
      delete [] table;
    }


    double operator() (const double j1 , const double j2 , const double j3 , const double m1 , const double m2 , const double m3) const
    { 
      const int two_j1 = make_int (j1 + j1) , two_j2 = make_int (j2 + j2) , two_j3 = make_int (j3 + j3);
      const int two_m1 = make_int (m1 + m1) , two_m2 = make_int (m2 + m2) , two_m3 = make_int (m3 + m3);

      if ((two_m1 + two_m2 + two_m3 != 0) || ((two_j1 - two_m1)%2 != 0) || ((two_j2 - two_m2)%2 != 0) || ((two_j3 - two_m3)%2 != 0)) return 0.0;
      
      if ((abs (two_m1) > two_j1) || (abs (two_m2) > two_j2) || (abs (two_m3) > two_j3) || (two_j3 < abs (two_j1 - two_j2)) || (two_j3 > two_j1 + two_j2)) return 0.0;

      const int J = (two_j1 + two_j2 + two_j3)/2;

      const int bin_m1_pow_J = J%2;

      const int j1_m1 = (two_j1 - two_m1)/2;
      const int j2_m2 = (two_j2 - two_m2)/2;

      const int j3_m3 = J - j1_m1 - j2_m2;

      int Regge[3][3] = {{J - two_j1 , J - two_j2 , J - two_j3} , {j1_m1 , j2_m2 , j3_m3} , {j1_m1 + two_m1 , j2_m2 + two_m2 , j3_m3 + two_m3}};

      int S0 = 1000000 , iS , jS;

      for (int i = 0 ; i < 3 ; i++)
	for (int j = 0 ; j < 3 ; j +  + )
	  {
	    const int Regge_try = Regge[i][j];

	    if (S0 > Regge_try)
	      {
		S0 = Regge_try;

		iS = i;
		jS = j;
	      }
	  }

      int L0 = -1 , iL , jL;
      
      for (int k = 0 ; k < 3 ; k +  + )
	{
	  const int Regge_try_line = Regge[k][jS];
	  const int Regge_try_col = Regge[iS][k];
	  
	  if (L0 < Regge_try_line)
	    {
	      L0 = Regge_try_line;

	      iL = k;
	      jL = jS;
	    }
	  
	  if (L0 < Regge_try_col)
	    {
	      L0 = Regge_try_col;

	      iL = iS;
	      jL = k;
	    }
	}

      if (iS != iL)
	{
	  const int temp_01 = Regge[0][1];
	  const int temp_02 = Regge[0][2];
	  const int temp_12 = Regge[1][2];

	  const int j = jS;
	  
	  Regge[0][1] = Regge[1][0] , Regge[1][0] = temp_01;	  
	  Regge[0][2] = Regge[2][0] , Regge[2][0] = temp_02;	  
	  Regge[1][2] = Regge[2][1] , Regge[2][1] = temp_12;
	  
	  jS = iS;
	  jL = iL;
	  iS = iL = j;
	}

      const int bin_ph = ((((jS == 1) && (jL == 0)) || ((jS == 0) && (jL == 2)) || ((jS == 2) && (jL == 1)))) ? (bin_m1_pow_J) : (0);
      
      const int iS1 = (iS + 1)%3 , iS2 = (iS + 2)%3 , lc = (jS != jL) ? (3 - jL - jS) : (0);

      const int Regge_10 = Regge[iS1][jS] , Regge_11 = Regge[iS1][jL] , Regge_12 = Regge[iS1][lc];
      const int Regge_20 = Regge[iS2][jS] , Regge_21 = Regge[iS2][jL] , Regge_22 = Regge[iS2][lc];

      if ((Regge_11 < Regge_21) || ((Regge_11 == Regge_21) && (Regge_12 <= Regge_22)))
	{
	  const unsigned int S = S0;
	  const unsigned int L = L0;

	  const unsigned int X = Regge_10;
	  const unsigned int B = Regge_11;
	  const unsigned int T = Regge_22;
	  
	  const unsigned int index = (L*(24 + L*(50 + L*(35 + L*(10 + L)))))/120 + (X*(6 + X*(11 + X*(6 + X))))/24 + (T*(2 + T*(3 + T)))/6 + (B*(B + 1))/2 + S;

	  return (bin_ph == 0) ? (table[index]) : ( - table[index]);
	}
      else
	{
	  const unsigned int S = S0;
	  const unsigned int L = L0;
	  
	  const unsigned int X = Regge_20;
	  const unsigned int B = Regge_21;
	  const unsigned int T = Regge_12;
	  
	  const unsigned int index = (L*(24 + L*(50 + L*(35 + L*(10 + L)))))/120 + (X*(6 + X*(11 + X*(6 + X))))/24 + (T*(2 + T*(3 + T)))/6 + (B*(B + 1))/2 + S;

	  return (bin_ph == bin_m1_pow_J) ? (table[index]) : ( - table[index]);
	}
    }
  private:
    double *table;
  };






  class six_j
  {
  public:
    six_j (const double Jmax) 
    {
      const unsigned int two_Jmax = make_uns_int (2*Jmax);
      
      const unsigned int dimension = (two_Jmax*(1764 + two_Jmax*(1624 + two_Jmax*(735 + two_Jmax*(175 + two_Jmax*(21 + two_Jmax))))))/720 + 1;

      table = new double [dimension];
      for (unsigned int i = 0 ; i < dimension ; i++) table[i] = 0.0;

      for (unsigned int S = 0 ; S <= two_Jmax ; S +  + )
	for (unsigned int B = S ; B <= two_Jmax ; B +  + )
	  for (unsigned int T = B ; T <= two_Jmax ; T +  + )
	    for (unsigned int X = T ; X <= two_Jmax ; X +  + )
	      for (unsigned int L = X ; L <= two_Jmax ; L +  + )
		for (unsigned int E = L ; E <= two_Jmax ; E +  + )
		  {
		    const unsigned int index = (E*(120 + E*(274 + E*(225 + E*(85 + E*(15 + E))))))/720 + (L*(24 + L*(50 + L*(35 + L*(10 + L)))))/120 + (X*(6 + X*(11 + X*(6 + X))))/24 + (T*(2 + T*(3 + T)))/6 + (B*(B + 1))/2 + S;

		    const double j1 = 0.5*(T + L);
		    const double j2 = 0.5*(B + E);
		    const double j3 = 0.5*(B + T + L + E) - X;
		    const double j4 = 0.5*(S + B + L - X);
		    const double j5 = 0.5*(S + T + E - X);
		    const double j6 = 0.5*(S + L + E - X);

		    table[index] = Wigner_6j (j1 , j2 , j3 , j4 , j5 , j6);
		  }      
    }

    ~six_j ()
    {
      delete [] table;
    }

    double operator() (const double j1 , const double j2 , const double j3 , const double j4 , const double j5 , const double j6) const
    { 
      const int two_j1 = make_int (j1 + j1) , two_j2 = make_int (j2 + j2) , two_j3 = make_int (j3 + j3);
      const int two_j4 = make_int (j4 + j4) , two_j5 = make_int (j5 + j5) , two_j6 = make_int (j6 + j6);

      if ((two_j3 < abs (two_j1 - two_j2)) || (two_j3 > two_j1 + two_j2) || (two_j6 < abs (two_j1 - two_j5)) || (two_j6 > two_j1 + two_j5)) return 0.0;
      if ((two_j6 < abs (two_j4 - two_j2)) || (two_j6 > two_j4 + two_j2) || (two_j3 < abs (two_j4 - two_j5)) || (two_j3 > two_j4 + two_j5)) return 0.0;
      
      if (((two_j1 + two_j2 + two_j3)%2 != 0) || ((two_j1 + two_j5 + two_j6)%2 != 0) || ((two_j4 + two_j2 + two_j6)%2 != 0) || ((two_j4 + two_j5 + two_j3)%2 != 0)) return 0.0;

      int b1 = (two_j1 + two_j2 + two_j3)/2;
      int b2 = (two_j1 + two_j5 + two_j6)/2;
      int b3 = (two_j2 + two_j4 + two_j6)/2;
      
      int b4 = b1 + b2 + b3 - two_j1 - two_j2 - two_j6;
      
      int a1 = b1 + b4 - two_j3;
      int a2 = b1 + b3 - two_j2;
      int a3 = b1 + b2 - two_j1;

      int alpha[] = {a1 , a2 , a3};
      int beta [] = {b1 , b2 , b3 , b4};

      sort (3 , alpha);
      sort (4 , beta);

      a1 = alpha[0];
      a2 = alpha[1];
      a3 = alpha[2];

      b4 = beta[0];
      b3 = beta[1];
      b2 = beta[2];
      b1 = beta[3];

      const unsigned int S = a1 - b1;
      const unsigned int B = a1 - b2;
      const unsigned int T = a1 - b3;
      const unsigned int X = a1 - b4;
      const unsigned int L = a2 - b4;
      const unsigned int E = a3 - b4;

      const unsigned int index = (E*(120 + E*(274 + E*(225 + E*(85 + E*(15 + E))))))/720 + (L*(24 + L*(50 + L*(35 + L*(10 + L)))))/120 + (X*(6 + X*(11 + X*(6 + X))))/24 + (T*(2 + T*(3 + T)))/6 + (B*(B + 1))/2 + S;

      return table[index];
    }

  private:
    double *table;
  };
}


#endif
