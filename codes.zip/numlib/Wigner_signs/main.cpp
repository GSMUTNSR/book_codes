#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


using namespace Wigner_signs;
using namespace string_routines;

string jm_space_str (const double jm)
{    
  const int two_jm = make_int (2*jm);

  if (two_jm == 0)
    return "0    "; // Not in the even case to avoid seeing -0 on screen.
  else if (two_jm%2 == 0)
    {
      string result = make_string (jm) + "  ";
      
      if (two_jm < 20) result += " ";
      if (two_jm >= 0) result += " ";
      
      return result;
    }
  else
    {
      string result = make_string (two_jm) + "/2";
      
      if (two_jm < 10) result += " ";
      if (two_jm >= 0) result += " ";
      
      return result;
    }
}


void Wigner_3j_test (const int jmax , const double sample)
{
  double max_Wigner_3j_test = 0.0;

  for (double ja = 0.0 ; rint (ja - jmax) <= 0.0 ; ja += 0.5)
    for (double jb = 0.0 ; rint (jb - jmax) <= 0.0 ; jb += 0.5)
      for (double ma = -ja ; rint (ma - ja) <= 0.0 ; ma += 1.0)
	for (double mb = -jb ; rint (mb - jb) <= 0.0 ; mb += 1.0)
	  for (double mc = -ja ; rint (mc - ja) <= 0.0 ; mc += 1.0)
	    if (random_number<double> () < sample)
	      {
		const double m = -ma - mb;
		
		const double md = -mc - m;

		if (rint (abs (md) - jb) > 0.0) continue;

		double Wigner_3j_test = 0.0;

		for (double j = abs (ja - jb) ; rint (j - ja - jb) <= 0.0 ; j += 1.0) Wigner_3j_test += (2.0 * j + 1.0)*Wigner_3j (ja , jb , j , ma , mb , m)*Wigner_3j (ja , jb , j , mc , md , m);

		if ((rint (ma - mc) == 0.0) && (rint (mb - md) == 0.0)) Wigner_3j_test -= 1.0;
  
		Wigner_3j_test = abs (Wigner_3j_test);
			
		max_Wigner_3j_test = max (Wigner_3j_test , max_Wigner_3j_test);

		cout << "ja:" << jm_space_str (ja) << " ma:" << jm_space_str (ma) << " mc:" << jm_space_str (mc) << " jb:" << jm_space_str (jb) << " mb:" << jm_space_str (mb) << " md:" << jm_space_str (md) << "     test:" << Wigner_3j_test << endl;
	      }

  if (max_Wigner_3j_test > precision) error_message_print_abort ("Problem with Wigner 3j's");

  cout << endl << "Maximal Wigner 3j test : " << max_Wigner_3j_test << endl;
}


void Wigner_6j_test (const int jmax , const double sample)
{
  double max_Wigner_6j_test = 0.0;

  for (double ja = 0.0 ; rint (ja - jmax) <= 0.0 ; ja += 0.5)
    for (double je = 0.0 ; rint (je - jmax) <= 0.0 ; je += 0.5)
      for (double jf = 0.0 ; rint (jf - jmax) <= 0.0 ; jf += 0.5)
	if (is_it_triangle (ja , je , jf))
	  for (double jg = 0.0 ; rint (jg - jmax) <= 0.0 ; jg += 0.5)
	    if (is_it_triangle (ja , je , jg))
	      for (double jb = 0.0 ; rint (jb - jmax) <= 0.0 ; jb += 0.5)
		for (double jd = 0.0 ; rint (jd - jmax) <= 0.0 ; jd += 0.5)
		  if (is_it_triangle (jb , jd , jf) && is_it_triangle (jb , jd , jg))
		    if (random_number<double> () < sample)
		      {
			double Wigner_6j_test = 0.0;

			for (double jc = max (abs (ja - jb) , abs (jd - je)) ; rint (jc - min (ja + jb , jd + je)) <= 0.0 ; jc += 1.0)
			  {
			    Wigner_6j_test += (2.0 * jc + 1.0)*Wigner_6j (ja , jb , jc , jd , je , jf)*Wigner_6j (ja , jb , jc , jd , je , jg);
			  }

			if (rint (jf - jg) == 0.0) Wigner_6j_test -= 1.0/(2.0 * jf + 1.0);

			Wigner_6j_test = abs (Wigner_6j_test);
			
			max_Wigner_6j_test = max (Wigner_6j_test , max_Wigner_6j_test);

			cout << "ja:" << jm_space_str (ja) << " jb:" << jm_space_str (jb) << " jd:" << jm_space_str (jd) << " je:" << jm_space_str (je) << " jf:" << jm_space_str (jf) << " jg:" << jm_space_str (jg) << "     test:" << Wigner_6j_test << endl;
		      }

  if (max_Wigner_6j_test > precision) error_message_print_abort ("Problem with Wigner 6j's");
  
  cout << endl << "Maximal Wigner 6j test : " << max_Wigner_6j_test << endl;
}



void Wigner_9j_test (const int jmax , const double sample)
{
  double max_Wigner_9j_test = 0.0;

  for (double ja = 0.0 ; rint (ja - jmax) <= 0.0 ; ja += 0.5)
    for (double jb = 0.0 ; rint (jb - jmax) <= 0.0 ; jb += 0.5)
      for (double jc = abs (ja - jb) ; rint (jc - ja - jb) <= 0.0 ; jc += 1.0)
	for (double jk = abs (ja - jb) ; rint (jk - ja - jb) <= 0.0 ; jk += 1.0)
	  for (double jd = 0.0 ; rint (jd - jmax) <= 0.0 ; jd += 0.5)
	    for (double je = 0.0 ; rint (je - jmax) <= 0.0 ; je += 0.5)
	      for (double jf = abs (jd - je) ; rint (jf - jd - je) <= 0.0 ; jf += 1.0)
		for (double jl = abs (jd - je) ; rint (jl - jd - je) ; jl += 1.0)
		  for (double ji = max (abs (jc - jf) , abs (jk - jl)) ; rint (ji - min (jc + jf , jk + jl)) <= 0.0 ; ji += 1.0)
		    if (random_number<double> () < sample)
		      {
			double Wigner_9j_test = 0.0;

			for (double jg = abs (ja - jd) ; rint (jg - ja - jd) <= 0.0 ; jg += 1.0)
			  for (double jh = max (abs (jb - je) , abs (jg - ji)) ; rint (jh - min (jb + je , jg + ji)) <= 0.0 ; jh += 1.0)
			    Wigner_9j_test += (2.0 * jg + 1.0)*(2.0 * jh + 1.0)*Wigner_9j (ja , jb , jc , jd , je , jf , jg , jh , ji)*Wigner_9j (ja , jb , jk , jd , je , jl , jg , jh , ji);

			if ((rint (jc - jk) == 0.0) && (rint (jf - jl) == 0.0)) Wigner_9j_test -= 1.0/(2.0 * jc + 1.0)/(2.0 * jf + 1.0);

			Wigner_9j_test = abs (Wigner_9j_test);
		
			max_Wigner_9j_test = max (Wigner_9j_test , max_Wigner_9j_test);

			cout << "ja:" << jm_space_str (ja) << " jb:" << jm_space_str (jb) << " jc:" << jm_space_str (jc) << " jd:" << jm_space_str (jd) << " "
			     << "je:" << jm_space_str (je) << " jf:" << jm_space_str (jf) << " ji:" << jm_space_str (ji) << " jl:" << jm_space_str (jl) << " "
			     << "     test:" << Wigner_9j_test << endl;
		      }
	
  if (max_Wigner_9j_test > precision) error_message_print_abort ("Problem with Wigner 9j's");
  
  cout << endl << "Maximal Wigner 9j test : " << max_Wigner_9j_test << endl;
}


void Clebsch_Gordan_test (const int jmax , const double sample)
{
  double max_Clebsch_Gordan_test = 0.0;
  
  for (double ja = 0.0 ; rint (ja - jmax) <= 0.0 ; ja += 0.5)
    for (double jb = 0.0 ; rint (jb - jmax) <= 0.0 ; jb += 0.5)
      for (double ma = -ja ; rint (ma - ja) <= 0.0 ; ma += 1.0)
	for (double mb = -jb ; rint (mb - jb) <= 0.0 ; mb += 1.0)
	  for (double mc = -ja ; rint (mc - ja) <= 0.0 ; mc += 1.0)
	    if (random_number<double> () < sample)
	      {
		const double m = ma + mb;

		const double md = mc - m;
		
		if (rint (abs (md) - jb) > 0.0) continue;

		double Clebsch_Gordan_test = 0.0;

		for (double j = abs (ja - jb) ; rint (j - ja - jb) <= 0.0 ; j += 1.0) Clebsch_Gordan_test += Clebsch_Gordan (ja , ma , jb , mb , j , m)*Clebsch_Gordan (ja , mc , jb , md , j , m);
		
		if ((rint (ma - mc) == 0.0) && (rint (mb - md) == 0.0)) Clebsch_Gordan_test -= 1.0;

		Clebsch_Gordan_test = abs (Clebsch_Gordan_test);
							  
		max_Clebsch_Gordan_test = max (Clebsch_Gordan_test , max_Clebsch_Gordan_test);

		cout << "ja:" << jm_space_str (ja) << " ma:" << jm_space_str (ma) << " mc:" << jm_space_str (mc) << " jb:" << jm_space_str (jb) << " mb:" << jm_space_str (mb) << " md:" << jm_space_str (md) << "     test:" << Clebsch_Gordan_test << endl;
	      }
	
  if (max_Clebsch_Gordan_test > precision) error_message_print_abort ("Problem with Clebsch-Gordan's");

  cout << endl << "Maximal Clebsch Gordan test : " << max_Clebsch_Gordan_test << endl;
}





// One uses the relation D(J1,M'[1],M1).D(J2,M'[2],M2) = \sum_{J3,M'[3],M3} (2.J3 + 1).Wigner_3j (J1 , J2 , J3 , M1 , M2 , M3).Wigner_D (J3 , M'[3] , M3 , alpha_rad , beta_rad , gamma_rad)*.Wigner_3j (J1 , J2 , J3 , M'[1] , M'[2] , M'[3])

void Wigner_d_test (const int jmax , const double sample_for_zero_J1 , const double sample_for_non_zero_J1)
{
  const complex<double> I(0,1);
	  
  const double alpha_rad = 1.0;	
  const double beta_rad = 2.0;	
  const double gamma_rad = 3.0;	
  
  double max_Wigner_D_matrix_test = 0.0;
  
  for (int J2 = 0 ; J2 <= jmax ; J2++)
    for (int M2 = -J2 ; M2 <= J2 ; M2++)
      for (int Mp2 = -J2 ; Mp2 <= J2 ; Mp2++)
	if (random_number<double> () < sample_for_zero_J1)
	  {
	    const complex<double> Wigner_D_val_1 = Wigner_D (0  , 0   , 0  , alpha_rad , beta_rad , gamma_rad);
	    const complex<double> Wigner_D_val_2 = Wigner_D (J2 , Mp2 , M2 , alpha_rad , beta_rad , gamma_rad);
	  		    
	    const complex<double> Wigner_D_matrix_product = minus_one_pow (M2 + Mp2)*conj (Wigner_D (J2 , -Mp2 , -M2 , alpha_rad , beta_rad , gamma_rad));
	    
	    const double Wigner_D_matrix_test = inf_norm (Wigner_D_matrix_product - Wigner_D_val_1*Wigner_D_val_2);
			    
	    cout << "J1:0     M'[1]:0     M1:0     J2:" << jm_space_str (J2) << " M'[2]:" << jm_space_str (Mp2) << " M2:" << jm_space_str (M2) << "     test:" << Wigner_D_matrix_test << endl;

	    max_Wigner_D_matrix_test = max (Wigner_D_matrix_test , max_Wigner_D_matrix_test);
	  }
  
  for (int J1 = 1 ; J1 <= jmax ; J1++)
    for (int M1 = -J1 ; M1 <= J1 ; M1++)
      for (int Mp1 = -J1 ; Mp1 <= J1 ; Mp1++)
	for (int J2 = 1 ; J2 <= jmax ; J2++)
	  for (int M2 = -J2 ; M2 <= J2 ; M2++)
	    for (int Mp2 = -J2 ; Mp2 <= J2 ; Mp2++)
	      if (random_number<double> () < sample_for_non_zero_J1)
		{
		  const complex<double> Wigner_D_val_1 = Wigner_D (J1 , Mp1 , M1 , alpha_rad , beta_rad , gamma_rad);
		  const complex<double> Wigner_D_val_2 = Wigner_D (J2 , Mp2 , M2 , alpha_rad , beta_rad , gamma_rad);

		  const int J3_min = abs (J1 - J2);
					    
		  const int J3_max = J1 + J2;

		  const int M3  = -M1 - M2;
		    
		  const int Mp3 = -Mp1 - Mp2;
		    
		  complex<double> Wigner_D_matrix_product = 0.0;
		    
		  for (int J3 = J3_min ; J3 <= J3_max ; J3++) Wigner_D_matrix_product += (2*J3 + 1)*Wigner_3j (J1 , J2 , J3 , M1 , M2 , M3)*conj (Wigner_D (J3 , Mp3 , M3 , alpha_rad , beta_rad , gamma_rad))*Wigner_3j (J1 , J2 , J3 , Mp1 , Mp2 , Mp3);
		    
		  const double Wigner_D_matrix_test = inf_norm (Wigner_D_matrix_product - Wigner_D_val_1*Wigner_D_val_2);
			    
		  cout << "J1:" << jm_space_str (J1) << " M'[1]:" << jm_space_str (Mp1) << " M1:" << jm_space_str (M1) << " "
		       << "J2:" << jm_space_str (J2) << " M'[2]:" << jm_space_str (Mp2) << " M2:" << jm_space_str (M2) << "     test:" << Wigner_D_matrix_test << endl;

		  max_Wigner_D_matrix_test = max (Wigner_D_matrix_test , max_Wigner_D_matrix_test);
		}
  
  if (max_Wigner_D_matrix_test > precision) error_message_print_abort ("Problem with Wigner D matrices");
  
  cout << endl << "Maximal Wigner D matrix test : " << max_Wigner_D_matrix_test << endl;
}





void reduced_MEs_double_test (const int l , const double j , const double m)
{
  const double j_reduced = ME_reduced (m , 1 , 0 , j , m , j , m);
  
  const double test_j_reduced = abs (sqrt (j*(j + 1)*(2*j + 1))/j_reduced - 1.0);

  if (test_j_reduced > precision) error_message_print_abort ("Problem with ME_reduced (double)");

  const double j_dereduced = ME_dereduced (sqrt (j*(j + 1)*(2*j + 1)) , 1 , 0 , j , m , j , m);

  const double test_j_dereduced = abs (m/j_dereduced - 1.0);

  if (test_j_dereduced > precision) error_message_print_abort ("Problem with ME_dereduced (double)");

  const double s_reduced = sqrt (1.5);

  const double l_reduced = sqrt (l*(l + 1)*(2*l + 1));

  const double s_lj_reduced = s_reduced*hat (j)*hat (j)*minus_one_pow (l + j + 1.5)*Wigner_6j (0.5 , 0.5 , 1 , j , j , l);

  const double l_lj_reduced = l_reduced*hat (j)*hat (j)*minus_one_pow (l + j + 1.5)*Wigner_6j (l , l , 1 , j , j , 0.5);

  const double l_scalar_s_lj = Oa_scalar_Ob_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_test = abs (0.5*(j*(j+1) - l*(l+1) - 0.75)/l_scalar_s_lj - 1.0);

  if (l_scalar_s_test > precision) error_message_print_abort ("Problem with Oa_scalar_Ob_ME_calc (double)");

  const double l_lj_reduced_2 = Oa_reduced_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , l_reduced);

  const double l_lj_reduced_test = abs (l_lj_reduced/l_lj_reduced_2 - 1.0);

  if (l_lj_reduced_test > precision) error_message_print_abort ("Problem with Ob_reduced_ME_calc (double)");

  const double s_lj_reduced_2 = Ob_reduced_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , s_reduced);

  const double s_lj_reduced_test = abs (s_lj_reduced/s_lj_reduced_2 - 1.0);

  if (s_lj_reduced_test > precision) error_message_print_abort ("Problem with Ob_reduced_ME_calc (double)");

  const double l_scalar_s_lj_2 = Oa_tensor_Ob_reduced_ME_calc (1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_test = abs (l_scalar_s_lj/l_scalar_s_lj_2 - 1.0);

  if (l_scalar_s_lj_from_tensor_test > precision) error_message_print_abort ("Problem with Oa_tensor_Ob_reduced_ME_calc (double)");

  class array<double> s_tab(1);
  class array<double> l_tab(1);

  s_tab(0) = s_reduced;
  l_tab(0) = l_reduced;

  const double l_scalar_s_lj_3 = O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_tab)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_3_test = abs (l_scalar_s_lj/l_scalar_s_lj_3 - 1.0);

  if (l_scalar_s_lj_from_tensor_3_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (double)");

  const double l_scalar_s_lj_4 = O1a_tensor_O2b_k3_scalar_O3b_ME_calc  (1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_lj_from_scalar_4_test = abs (l_scalar_s_lj/l_scalar_s_lj_4 - 1.0);

  if (l_scalar_s_lj_from_scalar_4_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k3_scalar_O3b_ME_calc (double)");

  const double l_scalar_s_lj_5 = O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab , s_reduced)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_5_test = abs (l_scalar_s_lj/l_scalar_s_lj_5 - 1.0);

  if (l_scalar_s_lj_from_tensor_5_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (double)");

  const double l_scalar_s_lj_6 = O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc  (1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_lj_from_scalar_6_test = abs (l_scalar_s_lj/l_scalar_s_lj_6 - 1.0);

  if (l_scalar_s_lj_from_scalar_6_test > precision) error_message_print_abort ("Problem with O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (double)");

  const double l_scalar_s_lj_7 = O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (1 , 0 , 1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab , s_tab)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_7_test = abs (l_scalar_s_lj/l_scalar_s_lj_7 - 1.0);

  if (l_scalar_s_lj_from_tensor_7_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (double)");

  const double l_scalar_s_lj_8 = O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc  (1 , 0 , 1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_tab , s_tab);

  const double l_scalar_s_lj_from_scalar_8_test = abs (l_scalar_s_lj/l_scalar_s_lj_8 - 1.0);

  if (l_scalar_s_lj_from_scalar_8_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (double)");

  const double l_scalar_s_lj_9 = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (0 , 0 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_tab , s_tab)/hat (j);

  const double l_scalar_s_lj_from_tensor_9_test = abs (l_scalar_s_lj/l_scalar_s_lj_9 - 1.0);

  if (l_scalar_s_lj_from_tensor_9_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (double)");

  const double l_scalar_s_lj_10 = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (1 , 1 , 0 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab , s_tab)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_10_test = abs (l_scalar_s_lj/l_scalar_s_lj_10 - 1.0);

  if (l_scalar_s_lj_from_tensor_10_test > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (double)");
}







void reduced_MEs_complex_test (const int l , const double j , const double m)
{
  const complex<double> j_reduced_complex = ME_reduced (complex<double> (m) , 1 , 0 , j , m , j , m);

  const double test_j_reduced_complex = abs (sqrt (j*(j + 1)*(2*j + 1))/j_reduced_complex - 1.0);

  if (test_j_reduced_complex > precision) error_message_print_abort ("Problem with ME_reduced (complex)");

  const complex<double> j_dereduced_complex = ME_dereduced (complex<double> (sqrt (j*(j + 1)*(2*j + 1))) , 1 , 0 , j , m , j , m);

  const double test_j_dereduced_complex = abs (m/j_dereduced_complex - 1.0);

  if (test_j_dereduced_complex > precision) error_message_print_abort ("Problem with ME_dereduced (complex)");

  const complex<double> s_reduced = sqrt (1.5);

  const complex<double> l_reduced = sqrt (l*(l + 1)*(2*l + 1));

  const complex<double> s_lj_reduced = s_reduced*hat (j)*hat (j)*minus_one_pow (l + j + 1.5)*Wigner_6j (0.5 , 0.5 , 1 , j , j , l);

  const complex<double> l_lj_reduced = l_reduced*hat (j)*hat (j)*minus_one_pow (l + j + 1.5)*Wigner_6j (l , l , 1 , j , j , 0.5);

  const complex<double> l_scalar_s_lj_complex = Oa_scalar_Ob_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_test_complex = abs (0.5*(j*(j+1) - l*(l+1) - 0.75)/l_scalar_s_lj_complex - 1.0);

  if (l_scalar_s_test_complex > precision) error_message_print_abort ("Problem with Oa_scalar_Ob_ME_calc (complex)");

  const complex<double> l_lj_reduced_2_complex = Oa_reduced_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , l_reduced);

  const double l_lj_reduced_test_complex = abs (l_lj_reduced/l_lj_reduced_2_complex - 1.0);

  if (l_lj_reduced_test_complex > precision) error_message_print_abort ("Problem with Ob_reduced_ME_calc (complex)");

  const complex<double> s_lj_reduced_2_complex = Ob_reduced_ME_calc (1 , l , 0.5 , j , l , 0.5 , j , s_reduced);

  const double s_lj_reduced_test_complex = abs (s_lj_reduced/s_lj_reduced_2_complex - 1.0);

  if (s_lj_reduced_test_complex > precision) error_message_print_abort ("Problem with Ob_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_complex_2 = Oa_tensor_Ob_reduced_ME_calc (1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_complex_2 - 1.0);

  if (l_scalar_s_lj_from_tensor_test_complex > precision) error_message_print_abort ("Problem with Oa_tensor_Ob_reduced_ME_calc (complex)");

  class array<complex<double> > s_tab_complex(1);
  class array<complex<double> > l_tab_complex(1);

  s_tab_complex(0) = s_reduced;
  l_tab_complex(0) = l_reduced;

  const complex<double> l_scalar_s_lj_3_complex = O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_tab_complex)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_3_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_3_complex - 1.0);

  if (l_scalar_s_lj_from_tensor_3_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k12_tensor_O3b_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_4_complex = O1a_tensor_O2b_k3_scalar_O3b_ME_calc (1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_lj_from_scalar_4_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_4_complex - 1.0);

  if (l_scalar_s_lj_from_scalar_4_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k3_scalar_O3b_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_5_complex = O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab_complex , s_reduced)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_5_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_5_complex - 1.0);

  if (l_scalar_s_lj_from_tensor_5_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2a_tensor_O3b_k23_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_6_complex = O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_reduced , s_reduced);

  const double l_scalar_s_lj_from_scalar_6_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_6_complex - 1.0);

  if (l_scalar_s_lj_from_scalar_6_test_complex > precision) error_message_print_abort ("Problem with O1a_scalar_O2a_tensor_O3b_k1_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_7_complex = O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (1 , 0 , 1 , 0 , 1 , 1 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab_complex , s_tab_complex)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_7_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_7_complex - 1.0);

  if (l_scalar_s_lj_from_tensor_7_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k12_tensor_O3a_tensor_O4b_k34_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_8_complex = O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (1 , 0 , 1 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_tab_complex , s_tab_complex);

  const double l_scalar_s_lj_from_scalar_8_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_8_complex - 1.0);

  if (l_scalar_s_lj_from_scalar_8_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_scalar_O3a_tensor_O4b_k_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_9_complex = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (0 , 0 , 0 , 1 , l , 0.5 , j , l , 0.5 , j , l_tab_complex , s_tab_complex)/hat (j);

  const double l_scalar_s_lj_from_tensor_9_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_9_complex - 1.0);

  if (l_scalar_s_lj_from_tensor_9_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (complex)");

  const complex<double> l_scalar_s_lj_10_complex = O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (1 , 1 , 0 , 0 , l , 0.5 , j , l , 0.5 , j , l_tab_complex , s_tab_complex)*minus_one_pow (1)*hat (1)/hat (j);

  const double l_scalar_s_lj_from_tensor_10_test_complex = abs (l_scalar_s_lj_complex/l_scalar_s_lj_10_complex - 1.0);

  if (l_scalar_s_lj_from_tensor_10_test_complex > precision) error_message_print_abort ("Problem with O1a_tensor_O2b_k_O3a_scalar_O4b_reduced_ME_calc (complex)");
}









#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
 
    cout.precision (15);

    seed ();

    const int N = 8;

    const double test_factorial = abs (exp (lgamma (N+1))/factorial (N) - 1.0);
    
    if (test_factorial > precision) error_message_print_abort ("Problem with factorial");

    const double test_double_factorial = abs (factorial (2*N)/pow (2 , N)/factorial (N)/double_factorial (2*N - 1) - 1.0);

    if (test_double_factorial > precision) error_message_print_abort ("Problem with double_factorial");

    const double a = 3.5 , b = 4.5 , c = 2;

    if (!is_it_triangle (a , b , c)) error_message_print_abort ("Problem with is_it_triangle or is_it_integer");
	
    const int ai = 3 , bi = 4 , ci = 5;

    if (!is_it_triangle_integer (ai , bi , ci)) error_message_print_abort ("Problem with is_it_triangle_integer");

    const int jmax = 5;

    const double sample_3j = 0.002;
    const double sample_6j = 0.001;
    const double sample_9j = 0.000002;

    const double sample_d_for_zero_J1 = 0.02;
    
    const double sample_d_for_non_zero_J1 = 0.001;

    const double sample_CG = 0.002;

    cout << "jmax : " << jmax << endl;
    
    cout << "sample_3j : " << sample_3j << endl;

    cout << "sample_6j : " << sample_6j << endl;

    cout << "sample_9j : " << sample_9j << endl;

    cout << "sample_d_for_zero_J1 : " << sample_d_for_zero_J1 << endl;
    
    cout << "sample_d_for_non_zero_J1 : " << sample_d_for_non_zero_J1 << endl;

    cout << endl << endl << "Wigner 3j tests" << endl;
    cout                 << "---------------" << endl << endl;

    Wigner_3j_test (jmax , sample_3j);

    cout << endl << endl << "Wigner 6j tests" << endl;
    cout                 << "---------------" << endl << endl;

    Wigner_6j_test (jmax , sample_6j);

    cout << endl << endl << "Wigner 9j tests" << endl;
    cout                 << "---------------" << endl << endl;

    Wigner_9j_test (jmax , sample_9j);

    cout << endl << endl << "Clebsch Gordan tests" << endl;
    cout                 << "--------------------" << endl << endl;

    Clebsch_Gordan_test (jmax , sample_CG);

    cout << endl << endl << "Wigner d tests" << endl;
    cout                 << "--------------" << endl << endl;

    Wigner_d_test (jmax , sample_d_for_zero_J1 , sample_d_for_non_zero_J1);

    const int l = 8;

    const double j = 8.5;
    const double m = 7.5;

    reduced_MEs_double_test (l , j , m);

    reduced_MEs_complex_test (l , j , m);

    cout << endl << "All tests are correct." << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
