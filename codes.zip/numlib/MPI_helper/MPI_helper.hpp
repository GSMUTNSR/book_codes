#ifndef MPIHELPER_HPP
#define MPIHELPER_HPP

#ifdef UseMPI

namespace MPI_helper
{
  void Init (int &argc , char ** &argv);

  void Init_thread (int &argc , char ** &argv , const int required);
  
  unsigned int Comm_size (const MPI_Comm MPI_C);

  unsigned int Comm_rank (const MPI_Comm MPI_C);

  void Finalize ();

  void Abort ();

  void Barrier (const MPI_Comm MPI_C);
  
  void Barrier ();

  double Wtime ();

  MPI_Comm Comm_split (const unsigned int color , const int process , const MPI_Comm MPI_C_old);

  MPI_Group Comm_group (const MPI_Comm MPI_C);

  MPI_Comm Comm_create (const MPI_Comm MPI_C_old , const MPI_Group G);
  
  void Comm_free (MPI_Comm &MPI_C);

  bool Group_order_members_compare (const MPI_Group G1 , const MPI_Group G2);

  bool Group_members_compare (const MPI_Group G1 , const MPI_Group G2);

  MPI_Group Group_difference (const MPI_Group G1 , const MPI_Group G2);

  MPI_Group Group_excl (const MPI_Group G , const int n_ranks , int ranks[]);
  
  MPI_Group Group_union (const MPI_Group G1 , const MPI_Group G2);
		       
  MPI_Group Group_intersection (const MPI_Group G1 , const MPI_Group G2);
  
  MPI_Group Group_incl (const MPI_Group G , const int n_ranks , int ranks[]);

  unsigned int Get_Group_size (const MPI_Group G);

  unsigned int Get_Group_rank (const MPI_Group G);
  
  void Group_free (MPI_Group &G);
  
  MPI_Aint Get_address (void *A);

  MPI_Datatype Type_create_struct (const unsigned int N_members , int block_lengths[] , MPI_Aint address_displacements[] , MPI_Datatype types[]);

  void Type_commit (MPI_Datatype &T);

  void Type_free (MPI_Datatype &T);

  void initialization (int &argc , char ** &argv);

  void string_Bcast (string &T , const unsigned int Send_process , const unsigned int process , const MPI_Comm MPI_C);

  template<typename T> MPI_Datatype MPI_equivalent_type ();

  template<> MPI_Datatype MPI_equivalent_type<bool> ();
  template<> MPI_Datatype MPI_equivalent_type<signed char> ();
  template<> MPI_Datatype MPI_equivalent_type<wchar_t> ();
  template<> MPI_Datatype MPI_equivalent_type<unsigned char> ();
  template<> MPI_Datatype MPI_equivalent_type<unsigned short int> ();
  template<> MPI_Datatype MPI_equivalent_type<unsigned int> ();
  template<> MPI_Datatype MPI_equivalent_type<unsigned long int> ();
  template<> MPI_Datatype MPI_equivalent_type<char> ();
  template<> MPI_Datatype MPI_equivalent_type<short int> ();
  template<> MPI_Datatype MPI_equivalent_type<int> ();
  template<> MPI_Datatype MPI_equivalent_type<long int> ();
  template<> MPI_Datatype MPI_equivalent_type<float> ();
  template<> MPI_Datatype MPI_equivalent_type<double> ();
  template<> MPI_Datatype MPI_equivalent_type<long double> ();
  template<> MPI_Datatype MPI_equivalent_type<complex<float> > ();
  template<> MPI_Datatype MPI_equivalent_type<complex<double> > ();
  template<> MPI_Datatype MPI_equivalent_type<complex<long double> > ();

  template<typename T> void Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  template<typename T> void Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Send (const unsigned long int N , T * const table , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  template<typename T> void Send (const unsigned long int N , T * const table , const unsigned int Recv_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  template<typename T> void Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Recv (const unsigned long int N , T * const table , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  template<typename T> void Recv (const unsigned long int N , T * const table , const unsigned int Send_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  template<typename T> void Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);
  
  template<typename T> void Sendrecv (const unsigned long int N_in , T * const table_in , const unsigned long int N_out , T * const table_out ,
				      const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  
  template<typename T> void Sendrecv (const unsigned long int N_in , T * const table_in , const unsigned long int N_out , T * const table_out ,
				      const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  template<typename T> void Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);
  
  template<typename T> void Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  
  template<typename T> void Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process ,
					      const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Bcast (T &x , const unsigned int Send_process , const MPI_Comm MPI_C);
  template<typename T> void Bcast (T &x , const unsigned int Send_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Comm MPI_C);
  template<typename T> void Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Comm MPI_C);
  template<typename T> void Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  template<typename T> void Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C);
  template<typename T> void Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  template<typename T> void Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C);
  template<typename T> void Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template <typename T> void Allreduce (T &x , MPI_Op op , const MPI_Comm MPI_C);
  template <typename T> void Allreduce (T &x , MPI_Op op , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template <typename T> void Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Comm MPI_C);
  template <typename T> void Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C);

  template<typename T> void enum_Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Send (const unsigned long int N , T *const table , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);

  template<typename T> void enum_Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Recv (const unsigned long int N , T *const table , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);

  template<typename T> void enum_Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Sendrecv (const unsigned long int N_in , T * const table_in , const unsigned long int N_out , T * const table_out ,
					   const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  template<typename T> void enum_Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  template<typename T> void enum_Bcast (T &x , const unsigned int Send_process , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Comm MPI_C);

  template<typename T> void enum_Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Comm MPI_C);

  template<typename T> void enum_Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);
  
  template<typename T> void enum_Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C);
  
  template <typename T> void enum_Allreduce (T &x , MPI_Op op , const MPI_Comm MPI_C);
  
  template <typename T> void enum_Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Comm MPI_C);
}





// Wrappers of C language MPI standard routines.
// One can transfer a single element and not only arrays, by using its address as array pointer internally.
// Zero dimension arrays are handled by simply ignoring them.
// Status is ignored, as a failed MPI transfer leads to a code crash in practice. 

template<typename T>
void MPI_helper::Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Send (x , Recv_process , tag , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Send (&x , 1 , MPI_T_type , Recv_process , tag , MPI_C);
}

template<typename T>
void MPI_helper::Send (const unsigned long int N , T *const table , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Send (N , table , Recv_process , tag , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Send (const unsigned long int N , T *const table , const unsigned int Recv_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if (N == 0) return;

  MPI_Send (table , N , MPI_T_type , Recv_process , tag , MPI_C);
}







template<typename T>
void MPI_helper::Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Recv (x , Send_process , tag , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Recv (&x , 1 , MPI_T_type , Send_process , tag , MPI_C , MPI_STATUS_IGNORE);
}

template<typename T>
void MPI_helper::Recv (const unsigned long int N , T *const table , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Recv (N , table , Send_process , tag , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Recv (const unsigned long int N , T *const table , const unsigned int Send_process , const int tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if (N == 0) return;

  MPI_Recv (table , N , MPI_T_type , Send_process , tag , MPI_C , MPI_STATUS_IGNORE);
}
	
template<typename T>
void MPI_helper::Bcast (T &x , const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Bcast (x , Send_process , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Bcast (T &x , const unsigned int Send_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Bcast (&x , 1 , MPI_T_type , Send_process , MPI_C);
}

template<typename T>
void MPI_helper::Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();
      
  Bcast (N , table , Send_process , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if (N == 0) return;

  MPI_Bcast (table , N , MPI_T_type , Send_process , MPI_C);
}







template<typename T>
void MPI_helper::Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Sendrecv (x_in , x_out , Send_process , Recv_process , Send_tag , Recv_tag , MPI_T_type , MPI_C);
}


template<typename T>
void MPI_helper::Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Sendrecv (&x_in , 1 , MPI_T_type , Recv_process , Send_tag , &x_out , 1 , MPI_T_type , Send_process , Recv_tag , MPI_C , MPI_STATUS_IGNORE);
}



template<typename T>
void MPI_helper::Sendrecv (const unsigned long int N_in , T * const table_in , const unsigned long int N_out , T * const table_out ,
			   const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Sendrecv (N_in , table_in , N_out , table_out , Send_process , Recv_process , Send_tag , Recv_tag , MPI_T_type , MPI_C);
}


template<typename T>
void MPI_helper::Sendrecv (const unsigned long int N_in , T * const table_in , const unsigned long int N_out , T * const table_out , 
			   const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if ((N_in == 0) || (N_out == 0)) return;

  MPI_Sendrecv (table_in , N_in , MPI_T_type , Recv_process , Send_tag , table_out , N_out , MPI_T_type , Send_process , Recv_tag , MPI_C , MPI_STATUS_IGNORE);
}



template<typename T>
void MPI_helper::Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Sendrecv_replace (x , Send_process , Recv_process , Send_tag , Recv_tag , MPI_T_type , MPI_C);
}


template<typename T>
void MPI_helper::Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Sendrecv_replace (&x , 1 , MPI_T_type , Recv_process , Send_tag , Send_process , Recv_tag , MPI_C , MPI_STATUS_IGNORE);
}



template<typename T>
void MPI_helper::Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Sendrecv_replace (N , table , Send_process , Recv_process , Send_tag , Recv_tag , MPI_T_type , MPI_C);
}


template<typename T>
void MPI_helper::Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process ,
				   const int Send_tag , const int Recv_tag , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if (N == 0) return;

  MPI_Sendrecv_replace (table , N , MPI_T_type , Recv_process , Send_tag , Send_process , Recv_tag , MPI_C , MPI_STATUS_IGNORE);
}







template<typename T>
void MPI_helper::Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Allgatherv (N , table , group_processes_number , MPI_T_type , MPI_C);
}



// I added all the calculations of received elements numbers and displacements to the MPI distribution itself.
// Arrays are always separated in well defined parts, whose first and last elements in nodes are given by basic_first_index_determine_for_MPI and basic_last_index_determine_for_MPI (see basic_maths.cpp). 
// Arrays are also always transfered in place in this context, and copied to another array afterwards if necessary.

template<typename T>
void MPI_helper::Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{  
  if (N == 0) return;

  int * const received_elements_numbers = new int [group_processes_number];
  
  int * const displacements = new int [group_processes_number];

  const unsigned int active_Send_process_number = min (static_cast<unsigned long int> (group_processes_number) , N);

  for (unsigned int Send_process = 0 ; Send_process < active_Send_process_number ; Send_process ++ )
    {
      const unsigned long int first_index_Send_process = basic_first_index_determine_for_MPI (N , group_processes_number , Send_process);
      const unsigned long int last_index_Send_process  = basic_last_index_determine_for_MPI  (N , group_processes_number , Send_process);
      
      const unsigned long int elements_number_Send_process = (last_index_Send_process - first_index_Send_process) + 1;

      received_elements_numbers[Send_process] = elements_number_Send_process;
      
      displacements[Send_process] = (Send_process > 0) ? (displacements[Send_process - 1] + received_elements_numbers[Send_process - 1]) : (0);
    }

  for (unsigned int Send_process = active_Send_process_number ; Send_process < group_processes_number ; Send_process++) 
    received_elements_numbers[Send_process] = displacements[Send_process] = 0;

  MPI_Allgatherv (MPI_IN_PLACE , 0 , MPI_DATATYPE_NULL , table , received_elements_numbers , displacements , MPI_T_type , MPI_C);

  delete [] received_elements_numbers;

  delete [] displacements;
}











template<typename T>
void MPI_helper::Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Reduce (x , op , Recv_process , process , MPI_T_type , MPI_C);
}



// I chose to use in-place reduction in the receiving process so that a single element is used. It is copied to another element afterwards if necessary.

template<typename T>
void MPI_helper::Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{ 
  if (process == Recv_process)
    MPI_Reduce (MPI_IN_PLACE , &x , 1 , MPI_T_type , op , Recv_process , MPI_C);
  else
    MPI_Reduce (&x , NULL , 1 , MPI_T_type , op , Recv_process , MPI_C);
}



template<typename T>
void MPI_helper::Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Reduce (x_in , x_out , op , Recv_process , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{ 
  MPI_Reduce (&x_in , &x_out , 1 , MPI_T_type , op , Recv_process , MPI_C);
}

template<typename T>
void MPI_helper::Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Reduce (N , table , op , Recv_process , process , MPI_T_type , MPI_C);
}


// I chose to use in-place reduction in the receiving process so that a single array is used. It is copied to another array afterwards if necessary.

template<typename T>
void MPI_helper::Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{ 
  if (N == 0) return; 

  if (process == Recv_process)
    MPI_Reduce (MPI_IN_PLACE , table , N , MPI_T_type , op , Recv_process , MPI_C);
  else
    MPI_Reduce (table , NULL , N , MPI_T_type , op , Recv_process , MPI_C);
}


template<typename T>
void MPI_helper::Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Reduce (N , table_in , table_out , op , Recv_process , MPI_T_type , MPI_C);
}

template<typename T>
void MPI_helper::Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{ 
  if (N == 0) return; 

  MPI_Reduce (table_in , table_out , N , MPI_T_type , op , Recv_process , MPI_C);
}



template <typename T>
void MPI_helper::Allreduce (T &x , MPI_Op op , const MPI_Comm MPI_C)
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Allreduce (x , op , MPI_T_type , MPI_C);
}

template <typename T>
void MPI_helper::Allreduce (T &x , MPI_Op op , 	const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  MPI_Allreduce (MPI_IN_PLACE , &x , 1 , MPI_T_type , op , MPI_C);
}

template <typename T>
void MPI_helper::Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Comm MPI_C)	
{
  const MPI_Datatype MPI_T_type = MPI_equivalent_type<T> ();

  Allreduce (N , table , op , MPI_T_type , MPI_C);	
}

template <typename T>
void MPI_helper::Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Datatype MPI_T_type , const MPI_Comm MPI_C)
{
  if (N == 0) return;

  MPI_Allreduce (MPI_IN_PLACE , table , N , MPI_T_type , op , MPI_C);
}







// There are no standard MPI routines for enumerations.
// They are then replaced by integers, which are transfered, and copied to the enumeration data with a static cast.
// T must be an enumeration in enum_... routines. No test is made.

template<typename T>
void MPI_helper::enum_Send (T &x , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  int x_int = x;
	
  Send (x_int , Recv_process , tag , MPI_INT , MPI_C);

  x = static_cast<T> (x_int);
}

template<typename T>
void MPI_helper::enum_Send (const unsigned long int N , T *const table , const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Send (N , table_int , Recv_process , tag , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}





template<typename T>
void MPI_helper::enum_Recv (T &x , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  int x_int = x;

  Recv (x_int , Send_process , tag , MPI_INT , MPI_C);

  x = static_cast<T> (x_int);
}

template<typename T>
void MPI_helper::enum_Recv (const unsigned long int N , T *const table , const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Recv (N , table_int , Send_process , tag , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}



template<typename T>
void MPI_helper::enum_Sendrecv (T &x_in , T &x_out , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  int x_in_int = x_in , x_out_int = 0;
  
  Sendrecv (x_in_int , x_out_int , Send_process , Recv_process , Send_tag , Recv_tag , MPI_INT , MPI_C);
  
  x_out = static_cast<T> (x_out_int);
}



template<typename T>
void MPI_helper::enum_Sendrecv (const unsigned long int N_in , T * const table_in ,
				const unsigned long int N_out , T * const table_out ,
				const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  int *const table_in_int = new int [N_in];
  
  int *const table_out_int = new int [N_out];

  for (unsigned long int i = 0 ; i < N_in ; i++) table_in_int[i] = table_in[i];
  
  Sendrecv (N_in , table_in_int , N_out , table_out_int , Send_process , Recv_process , Send_tag , Recv_tag , MPI_INT , MPI_C);
  
  for (unsigned long int i = 0 ; i < N_out ; i++) table_out[i] =  static_cast<T> (table_out_int[i]);
  
  delete [] table_in_int;
  
  delete [] table_out_int;
}




template<typename T>
void MPI_helper::enum_Sendrecv_replace (T &x , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  int x_int = x;
  
  Sendrecv_replace (x_int , Send_process , Recv_process , Send_tag , Recv_tag , MPI_INT , MPI_C);
  
  x = static_cast<T> (x_int);
}



template<typename T>
void MPI_helper::enum_Sendrecv_replace (const unsigned long int N , T * const table , const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];
  
  Sendrecv_replace (N , table_int , Send_process , Recv_process , Send_tag , Recv_tag , MPI_INT , MPI_C);
  
  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}



template<typename T>
void MPI_helper::enum_Bcast (T &x , const unsigned int Send_process , const MPI_Comm MPI_C)
{
  int x_int = x;

  Bcast (x_int , Send_process , MPI_INT , MPI_C);

  x = static_cast<T> (x_int);
}






template<typename T>
void MPI_helper::enum_Bcast (const unsigned long int N , T * const table , const unsigned int Send_process , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Bcast (N , table_int , Send_process , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}






template<typename T>
void MPI_helper::enum_Allgatherv (const unsigned long int N , T * const table , const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Allgatherv (N , table_int , group_processes_number , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}






template<typename T>
void MPI_helper::enum_Reduce (T &x , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  int x_int = x;

  Reduce (x_int , op , Recv_process , process , MPI_INT , MPI_C);

  x = static_cast<T> (x_int);
}

template<typename T>
void MPI_helper::enum_Reduce (T &x_in , T &x_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C)
{
  int x_in_int = x_in , x_out_int = 0;

  Reduce (x_in_int , x_out_int , op ,  Recv_process , MPI_INT , MPI_C);

  x_out = static_cast<T> (x_out_int);
}

template<typename T>
void MPI_helper::enum_Reduce (const unsigned long int N , T * const table , MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Reduce (N , table_int , op , Recv_process , process , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}

template<typename T>
void MPI_helper::enum_Reduce (const unsigned long int N , T *const table_in , T *const table_out , MPI_Op op , const unsigned int Recv_process , const MPI_Comm MPI_C)
{
  int *const table_in_int = new int [N];
  
  int *const table_out_int = new int [N];
	
  for (unsigned long int i = 0 ; i < N ; i++) table_in_int[i] = table_in[i];

  Reduce (N , table_in_int , table_out_int , op , Recv_process , MPI_INT , MPI_C);

  for (unsigned long int i = 0 ; i < N ; i++) table_out[i] =  static_cast<T> (table_out_int[i]);

  delete [] table_in_int;
  
  delete [] table_out_int;
}







template <typename T>
void MPI_helper::enum_Allreduce (T &x , MPI_Op op , const MPI_Comm MPI_C)
{
  int x_int = x;

  Allreduce (x_int , op , MPI_INT , MPI_C);

  x = static_cast<T> (x_int);
}

template <typename T>
void MPI_helper::enum_Allreduce (const unsigned long int N , T * const table , MPI_Op op , const MPI_Comm MPI_C)	
{
  int *const table_int = new int [N];
  
  for (unsigned long int i = 0 ; i < N ; i++) table_int[i] = table[i];

  Allreduce (N , table_int , op , MPI_INT , MPI_C);	

  for (unsigned long int i = 0 ; i < N ; i++) table[i] = static_cast<T> (table_int[i]);
  
  delete [] table_int;
}

#endif



#endif
