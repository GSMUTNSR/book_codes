#include "../numlib_def/numlib_def.h"

#ifdef UseMPI

using namespace string_routines;

// The MPI_helper consists in wrappers of C language MPI standard routines.
// Typically, I replaced pointers by references and some values are returned instead of having a varying parameter in routines.
// I also put MPI_COMM_WORLD as default communicator in Abort () and Barrier (), as it is the one which is most often used. Barrier with a fixed communicator exists nevertheless.
// Group_members_compare returns true if Groups are identical or similar (same members, but in a different order).

void MPI_helper::Init (int &argc , char ** &argv)
{
  MPI_Init (&argc , &argv);
}

void MPI_helper::Init_thread (int &argc , char ** &argv , const int required)
{
  int provided = 0;
  
  MPI_Init_thread (&argc , &argv , required , &provided);
}

unsigned int MPI_helper::Comm_size (const MPI_Comm MPI_C)
{
  int size = 0;

  MPI_Comm_size (MPI_C , &size);

  return make_uns_int (size);
}

unsigned int MPI_helper::Comm_rank (const MPI_Comm MPI_C)
{
  int rank = 0;

  MPI_Comm_rank (MPI_C , &rank);

  return make_uns_int (rank);
}

void MPI_helper::Finalize ()
{
  MPI_Finalize ();
}

void MPI_helper::Abort ()
{
  MPI_Abort (MPI_COMM_WORLD , 1);
}

void MPI_helper::Barrier (const MPI_Comm MPI_C)
{
  MPI_Barrier (MPI_C);
}

void MPI_helper::Barrier ()
{
  MPI_Barrier (MPI_COMM_WORLD);
}

double MPI_helper::Wtime ()
{
  return MPI_Wtime ();
}

MPI_Comm MPI_helper::Comm_split (const unsigned int color , const int process , const MPI_Comm MPI_C_old)
{
  MPI_Comm MPI_C_new;
  
  MPI_Comm_split (MPI_C_old , color , process , &MPI_C_new);

  return MPI_C_new;
}

MPI_Group MPI_helper::Comm_group (const MPI_Comm MPI_C)
{
  MPI_Group G;
  
  MPI_Comm_group (MPI_C , &G);

  return G;
}  

MPI_Comm MPI_helper::Comm_create (const MPI_Comm MPI_C_old , const MPI_Group G)
{
  MPI_Comm MPI_C_new;
  
  MPI_Comm_create (MPI_C_old , G , &MPI_C_new);

  return MPI_C_new;
}

void MPI_helper::Comm_free (MPI_Comm &MPI_C)
{
  MPI_Comm_free (&MPI_C);
}

bool MPI_helper::Group_order_members_compare (const MPI_Group G1 , const MPI_Group G2)
{
  int result;
  
  MPI_Group_compare (G1 , G2 , &result);

  return ((result == MPI_IDENT) ? (true) : (false));
}

bool MPI_helper::Group_members_compare (const MPI_Group G1 , const MPI_Group G2)
{
  int result;
  
  MPI_Group_compare (G1 , G2 , &result);

  return (((result == MPI_IDENT) || (result == MPI_SIMILAR)) ? (true) : (false));
}

MPI_Group MPI_helper::Group_difference (const MPI_Group G1 , const MPI_Group G2)
{
  MPI_Group new_G;

  MPI_Group_difference (G1 , G2 , &new_G);

  return new_G;
}

MPI_Group MPI_helper::Group_excl (const MPI_Group G , const int n_ranks , int ranks[])
{
  MPI_Group new_G;

  MPI_Group_excl(G , n_ranks , ranks , &new_G);

  return new_G;
}

MPI_Group MPI_helper::Group_union (const MPI_Group G1 , const MPI_Group G2)
{
  MPI_Group new_G;

  MPI_Group_union (G1 , G2 , &new_G);

  return new_G;
}

MPI_Group MPI_helper::Group_intersection (const MPI_Group G1 , const MPI_Group G2)
{
  MPI_Group new_G;

  MPI_Group_intersection (G1 , G2 , &new_G);

  return new_G;
}

MPI_Group MPI_helper::Group_incl (const MPI_Group G , const int n_ranks , int ranks[])
{
  MPI_Group new_G;

  MPI_Group_incl(G , n_ranks , ranks , &new_G);

  return new_G;
}

unsigned int MPI_helper::Get_Group_size (const MPI_Group G)
{
  int size = 0;
  
  MPI_Group_size (G , &size);

  return make_uns_int (size);
}

unsigned int MPI_helper::Get_Group_rank (const MPI_Group G)
{
  int rank = 0;
  
  MPI_Group_rank (G , &rank);

  return make_uns_int (rank);
}

void MPI_helper::Group_free (MPI_Group &G)
{
  MPI_Group_free (&G);
}

MPI_Aint MPI_helper::Get_address (void *A)
{
  MPI_Aint A_address;

  MPI_Get_address (A , &A_address);

  return A_address;
}

MPI_Datatype MPI_helper::Type_create_struct (const unsigned int N_members , int block_lengths[] , MPI_Aint address_displacements[] , MPI_Datatype types[])
{
  MPI_Datatype T;

  MPI_Type_create_struct (N_members , block_lengths , address_displacements , types , &T);

  return T;
}

void MPI_helper::Type_commit (MPI_Datatype &T)
{
  MPI_Type_commit (&T);
}

void MPI_helper::Type_free (MPI_Datatype &T)
{
  MPI_Type_free (&T);
}








// Initialization of MPI run
// -------------------------
// This routine is used with MPI or hybrid MPI/OpenMP compilations. 
// Indeed, Init is used with MPI only and Init_thread with hybrid MPI/OpenMP using MPI_THREAD_FUNNELED, where only the master thread can make MPI calls.
// MASTER_THREAD is obtained from omp_get_thread_num () inside an omp master zone with OpenMP or is put to zero otherwise.
// The booleans is_it_MPI_parallelized_init and is_it_MPI_parallelized are put to true.
//
// The boolean is_it_MPI_parallelized_linear_algebra is put to false. 
// It is used only in matrices.hpp and total_diagonalization.hpp, for matrix multiplication for example, outside an MPI call and has to be put to true with MPI_parallelization_linear_algebra_enabled ().
// In order not to have race conditions, it has to be put to false afterwards with MPI_parallelization_linear_algebra_disabled ().
//
// The print of numbers on screen is set at 15 digits and "true, false" print of booleans is set up as well with boolalpha.

void MPI_helper::initialization (int &argc , char ** &argv)
{
#ifdef UseOpenMP

#pragma omp parallel
  {
#pragma omp master
    {
      Init_thread (argc , argv , MPI_THREAD_FUNNELED);
      
      MASTER_THREAD = omp_get_thread_num ();
    }
  }
  
#else

  Init (argc , argv);

  MASTER_THREAD = 0;
  
#endif
  
  NUMBER_OF_PROCESSES = Comm_size (MPI_COMM_WORLD);

  THIS_PROCESS = Comm_rank (MPI_COMM_WORLD);

  is_it_MPI_parallelized_init = is_it_MPI_parallelized = true;
  
  is_it_MPI_parallelized_linear_algebra = false;

  cout.precision (15); 

  cout << boolalpha;
}






// String Bcast
// ------------
// There is no standard MPI routine to cast a string. 
// Hence, a simple one is done here. 
//
// One adds one to the string length so that one can print strings with a slash at the end without problems.
// Zero length strings can also be handled this way.
// It creates no problem as a reference to a null character is sent if the position of a character is the length of the string.
//
// One firstly casts the string length plus one.
// Then, one allocates an array of char of the latter dimension (it is larger than zero).
// char is built-in so that it can be cast with MPI standard routines.
// The array of char is assigned to the string after the cast and deallocated at the end of the routine.

void MPI_helper::string_Bcast (
			       string &T ,
			       const unsigned int Send_process ,
			       const unsigned int process ,
			       const MPI_Comm MPI_C)
{
  unsigned int length_plus_one = T.length () + 1;

  Bcast<unsigned int> (length_plus_one , Send_process , MPI_C);

  char *const T_char = new char[length_plus_one];

  if (process == Send_process) strcpy (T_char , T.c_str());
 
  Bcast<char> (length_plus_one , T_char , Send_process , MPI_C);

  if (process != Send_process) T = T_char; 

  delete [] T_char;
}










// The next template specializations allow to provide with the MPI type used for MPI transfer as function of built-in type. 
// This is very practical when arrays of generic type are transfered with MPI.

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<bool> ()
{
  return MPI_C_BOOL;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<signed char> ()
{
  return MPI_CHAR;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<wchar_t> ()
{
  return MPI_WCHAR;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<unsigned char> ()
{
  return MPI_UNSIGNED_CHAR;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<unsigned short int> ()
{
  return MPI_UNSIGNED_SHORT;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<unsigned int> ()
{
  return MPI_UNSIGNED;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<unsigned long int> ()
{
  return MPI_UNSIGNED_LONG;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<char> ()
{
  return MPI_CHAR;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<short int> ()
{
  return MPI_SHORT;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<int> ()
{
  return MPI_INT;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<long int> ()
{
  return MPI_LONG;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<float> ()
{
  return MPI_FLOAT;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<double> ()
{
  return MPI_DOUBLE;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<long double> ()
{
  return MPI_LONG_DOUBLE;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<complex<float> > ()
{
  return MPI_COMPLEX;
}; 

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<complex<double> > ()
{
  return MPI_DOUBLE_COMPLEX;
};

template<> MPI_Datatype MPI_helper::MPI_equivalent_type<complex<long double> > ()
{
  return MPI_C_LONG_DOUBLE_COMPLEX;
};

#endif
