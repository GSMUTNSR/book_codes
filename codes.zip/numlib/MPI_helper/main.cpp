#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI

template<class C>
void table_init (const C a , const unsigned int N , C table[])
{
  for (unsigned int i = 0 ; i < N ; i++) table[i] = a;
}



template<class C>
void table_init (const unsigned int N , const C table_test[] , C table[])
{
  for (unsigned int i = 0 ; i < N ; i++) table[i] = table_test[i];
}



template<class C>
void table_init (const unsigned int first_index , const unsigned int last_index , const C table_test[] , C table[])
{
  for (unsigned int i = first_index ; i <= last_index ; i++) table[i] = table_test[i];
}



template<class C>
void transfer_check (const unsigned int N , const string &transfer_str , const C T[] , const C T_test[])
{
  for (unsigned int i = 0 ; i < N ; i++)
    {
      if (T[i] != T_test[i]) error_message_print_abort ("Error with table transfer related to " + transfer_str);
    }
}





template<class C>
void transfer_check (const string &transfer_str , const C x , const C x_test)
{
  if (x != x_test) error_message_print_abort ("Error with element transfer related to " + transfer_str);
}




void table_transfer_tests (const unsigned int N)
{
  int *const T = new int [N];
  int *const Tp = new int [N];
  int *const T_test = new int [N];

  const unsigned int first_index = basic_first_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = basic_last_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int process_a = 0;
  const unsigned int process_b = 1;	

  table_init<int> (1 , N , T_test);
  table_init<int> (0 , N , T);
  
  if (THIS_PROCESS == process_a) MPI_helper::Send<int> (N , T_test , process_b , 1 , MPI_COMM_WORLD);  
  if (THIS_PROCESS == process_b) MPI_helper::Recv<int> (N , T      , process_a , 1 , MPI_COMM_WORLD);

  if (THIS_PROCESS == process_b) transfer_check<int> (N , "Send/Recv" , T , T_test);

  if (THIS_PROCESS == process_a) table_init<int> (0 , N , T_test);
  if (THIS_PROCESS == process_b) table_init<int> (1 , N , T_test);
  
  if (THIS_PROCESS == process_a) MPI_helper::Sendrecv<int> (N , T_test , N , T , process_b , process_b , 2 , 3 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) MPI_helper::Sendrecv<int> (N , T_test , N , T , process_a , process_a , 3 , 2 , MPI_COMM_WORLD);
  
  if (THIS_PROCESS == process_a) table_init<int> (1 , N , T_test) , transfer_check<int> (N , "Sendrecv" , T , T_test);
  if (THIS_PROCESS == process_b) table_init<int> (0 , N , T_test) , transfer_check<int> (N , "Sendrecv" , T , T_test);
  
  
  if (THIS_PROCESS == process_a) table_init<int> (0 , N , T);
  if (THIS_PROCESS == process_b) table_init<int> (1 , N , T);
  
  if (THIS_PROCESS == process_a) MPI_helper::Sendrecv_replace<int> (N , T , process_b , process_b , 2 , 3 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) MPI_helper::Sendrecv_replace<int> (N , T , process_a , process_a , 3 , 2 , MPI_COMM_WORLD);
  
  if (THIS_PROCESS == process_a) table_init<int> (1 , N , T_test) , transfer_check<int> (N , "Sendrecv_replace" , T , T_test);
  if (THIS_PROCESS == process_b) table_init<int> (0 , N , T_test) , transfer_check<int> (N , "Sendrecv_replace" , T , T_test);
  
  
  table_init<int> (0 , N , T);
  table_init<int> (1 , N , T_test);

  if (THIS_PROCESS == MASTER_PROCESS) table_init<int> (N , T_test , T);

  MPI_helper::Bcast<int> (N , T , MASTER_PROCESS , MPI_COMM_WORLD);

  transfer_check<int> (N , "Bcast" , T , T_test);

  table_init<int> (0 , N , T);
  table_init<int> (1 , N , T_test);
  table_init<int> (first_index , last_index , T_test , T);

  MPI_helper::Allgatherv<int> (N , T , NUMBER_OF_PROCESSES , MPI_COMM_WORLD);

  transfer_check<int> (N , "Allgatherv" , T , T_test);

  table_init<int> (0 , N , T);
  table_init<int> (1 , N , T_test);
  table_init<int> (first_index , last_index , T_test , T);

  MPI_helper::Reduce<int> (N , T , Tp , MPI_SUM , MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS == MASTER_PROCESS) transfer_check<int> (N , "Reduce in->out" , Tp , T_test);

  table_init<int> (THIS_PROCESS , N , T);
  table_init<int> (NUMBER_OF_PROCESSES-1 , N , T_test);

  MPI_helper::Reduce<int> (N , T , MPI_MAX , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS == MASTER_PROCESS) transfer_check<int> (N , "Reduce in place" , T , T_test);

  table_init<int> (0 , N , T);
  table_init<int> (1 , N , T_test);
  table_init<int> (first_index , last_index , T_test , T);

  MPI_helper::Allreduce<int> (N , T , MPI_SUM , MPI_COMM_WORLD);

  transfer_check<int> (N , "Allreduce" , T , T_test);

  table_init<int> (THIS_PROCESS , N , T);
  table_init<int> (NUMBER_OF_PROCESSES-1 , N , T_test);

  MPI_helper::Allreduce<int> (N , T , MPI_MAX , MPI_COMM_WORLD);

  transfer_check<int> (N , "Allreduce" , T , T_test);
	
  delete [] T;
  delete [] Tp;
  delete [] T_test;
}




void element_transfer_tests ()
{
  const unsigned int process_a = 0;
  const unsigned int process_b = 1;	

  int x  = 0;
  int xp = 0;
  
  int x_test = 0;
	
  x = 0;

  x_test = 1;
  
  if (THIS_PROCESS == process_a) MPI_helper::Send<int> (x_test , process_b , 10 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) MPI_helper::Recv<int> (x      , process_a , 10 , MPI_COMM_WORLD);
  
  if (THIS_PROCESS == process_b) transfer_check<int> ("Send/Recv" , x , x_test);

  if (THIS_PROCESS == process_a) x_test = 0;
  if (THIS_PROCESS == process_b) x_test = 1;
  
  if (THIS_PROCESS == process_a) MPI_helper::Sendrecv<int> (x_test , x , process_b , process_b , 10 , 20 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) MPI_helper::Sendrecv<int> (x_test , x , process_a , process_a , 20 , 10 , MPI_COMM_WORLD);
  
  if (THIS_PROCESS == process_a) x_test = 1 , transfer_check<int> ("Sendrecv" , x , x_test);
  if (THIS_PROCESS == process_b) x_test = 0 , transfer_check<int> ("Sendrecv" , x , x_test);

  if (THIS_PROCESS == process_a) x = 0;
  if (THIS_PROCESS == process_b) x = 1;
  
  if (THIS_PROCESS == process_a) MPI_helper::Sendrecv_replace<int> (x , process_b , process_b , 10 , 20 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) MPI_helper::Sendrecv_replace<int> (x , process_a , process_a , 20 , 10 , MPI_COMM_WORLD);

  if (THIS_PROCESS == process_a) x_test = 1 , transfer_check<int> ("Sendrecv_replace" , x , x_test);
  if (THIS_PROCESS == process_b) x_test = 0 , transfer_check<int> ("Sendrecv_replace" , x , x_test);
	
  x = 0;

  x_test = 1;

  if (THIS_PROCESS == MASTER_PROCESS) x = 1;

  MPI_helper::Bcast<int> (x , MASTER_PROCESS , MPI_COMM_WORLD);

  transfer_check<int> ("Bcast" , x , x_test);

  x = (THIS_PROCESS == MASTER_PROCESS) ? (1) : (0);

  x_test = 1;

  MPI_helper::Reduce<int> (x , xp , MPI_SUM , MASTER_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS == MASTER_PROCESS) transfer_check<int> ("Reduce in->out" , xp , x_test);

  x = (THIS_PROCESS == MASTER_PROCESS) ? (1) : (0);

  x_test = 1;

  MPI_helper::Reduce<int> (x , MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS == MASTER_PROCESS) transfer_check<int> ("Reduce in place" , x , x_test);

  x = THIS_PROCESS;

  x_test = NUMBER_OF_PROCESSES-1;

  MPI_helper::Reduce<int> (x , MPI_MAX , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  if (THIS_PROCESS == MASTER_PROCESS) transfer_check<int> ("Reduce in place" , x , x_test);

  x = 1;

  x_test = NUMBER_OF_PROCESSES;

  MPI_helper::Allreduce<int> (x , MPI_SUM , MPI_COMM_WORLD);

  transfer_check<int> ("Alleduce" , x , x_test);

  x = THIS_PROCESS;

  x_test = NUMBER_OF_PROCESSES-1;

  MPI_helper::Allreduce<int> (x , MPI_MAX , MPI_COMM_WORLD);

  transfer_check<int> ("Reduce in place" , x , x_test);
  
  string T = "";
    
  if (THIS_PROCESS == MASTER_PROCESS) T = "Test with slash /";
  
  MPI_helper::string_Bcast (T , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  transfer_check<string> ("string Bcast" , T , "Test with slash /");
}




struct test_substruct
{
  test_substruct () {}

  test_substruct (const int x0 , const int y0 , const unsigned char z0 , const unsigned char z1)
  {
    x = x0;
    y = y0;
    
    z[0] = z0;
    z[1] = z1;
  }

  void operator = (const struct test_substruct &A)
  {
    x = A.x;
    y = A.y;
    
    z[0] = A.z[0];
    z[1] = A.z[1];
  }

  int x;
  int y;
  
  unsigned char z[2];
};



struct test_struct
{
  test_struct () {}

  test_struct (const int a0 , const unsigned char b0 , const unsigned short int c0 , const unsigned short int c1 , const unsigned int d0 , const struct test_substruct &T0)
  {
    a = a0;
    b = b0;
    
    c[0] = c0;
    c[1] = c1;

    d = d0;

    T = T0;
  }
  
  test_struct (const struct test_struct &A)
  {
    a = A.a;
    b = A.b;
    
    c[0] = A.c[0];
    c[1] = A.c[1];

    d = A.d;
    T = A.T;
  }
 
  void operator = (const struct test_struct &A)
  {
    a = A.a;
    b = A.b;
    
    c[0] = A.c[0];
    c[1] = A.c[1];

    d = A.d;
    T = A.T;
  }
  
  int a;
  
  unsigned char b;

  unsigned short int c[2];

  unsigned int d;
  
  struct test_substruct T;
};





bool operator != (const struct test_substruct &A , const struct test_substruct &B)
{
  if (A.x != B.x) return true;
  if (A.y != B.y) return true;
  
  if (A.z[0] != B.z[0]) return true;
  if (A.z[1] != B.z[1]) return true;

  return false;
}


bool operator != (const struct test_struct &A , const struct test_struct &B)
{
  if (A.a != B.a) return true;
  if (A.b != B.b) return true;

  if (A.c[0] != B.c[0]) return true;
  if (A.c[1] != B.c[1]) return true;

  if (A.d != B.d) return true;
  if (A.T != B.T) return true;

  return false;
}

MPI_Datatype MPI_Datatype_test_substruct_create ()
{
  const unsigned int N_members = 3;

  const MPI_Datatype MPI_int = MPI_helper::MPI_equivalent_type<int> ();

  const MPI_Datatype MPI_unsigned_char = MPI_helper::MPI_equivalent_type<unsigned char> ();

  MPI_Datatype types[N_members] = {MPI_int , MPI_int , MPI_unsigned_char};

  int block_lengths[N_members] = {1 , 1 , 2};
 
  class test_substruct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];
 
  address_displacements[0] = MPI_helper::Get_address (&A.x) - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.y) - A_address;
  address_displacements[2] = MPI_helper::Get_address (&A.z) - A_address;
 
  MPI_Datatype MPI_Datatype_test_substruct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_Datatype_test_substruct;
}



void test_commit_type (const unsigned int N)
{	
  const struct test_substruct x_sub(3 , 4 , 5 , 1);
  const struct test_substruct z_sub(0 , 0 , 0 , 0);
  
  const struct test_struct x(30 , 40 , 50 , 10 , 20 , x_sub);
  const struct test_struct z(0 , 0 , 0 , 0 , 0 , z_sub);

  struct test_struct *const T      = new struct test_struct [N];
  struct test_struct *const T_test = new struct test_struct [N];

  const unsigned int first_index = basic_first_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = basic_last_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS);

  table_init<struct test_struct> (z , N , T);
  table_init<struct test_struct> (x , N , T_test);

  table_init<struct test_struct> (first_index , last_index , T_test , T);

  const unsigned int N_members = 5;

  const MPI_Datatype MPI_int = MPI_helper::MPI_equivalent_type<int> ();

  const MPI_Datatype MPI_unsigned_char = MPI_helper::MPI_equivalent_type<unsigned char> ();

  const MPI_Datatype MPI_unsigned_short_int = MPI_helper::MPI_equivalent_type<unsigned short int> ();

  const MPI_Datatype MPI_unsigned_int = MPI_helper::MPI_equivalent_type<unsigned int> ();

  const MPI_Datatype MPI_test_substruct = MPI_Datatype_test_substruct_create ();

  MPI_Datatype types[N_members] = {MPI_int , MPI_unsigned_char , MPI_unsigned_short_int , MPI_unsigned_int , MPI_test_substruct};

  int block_lengths[N_members] = {1 , 1 , 2 , 1 , 1};
 
  class test_struct A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];
 
  address_displacements[0] = MPI_helper::Get_address (&A.a) - A_address;
  address_displacements[1] = MPI_helper::Get_address (&A.b) - A_address;
  address_displacements[2] = MPI_helper::Get_address (&A.c) - A_address;
  address_displacements[3] = MPI_helper::Get_address (&A.d) - A_address;
  address_displacements[4] = MPI_helper::Get_address (&A.T) - A_address;
 
  MPI_Datatype MPI_test_struct = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  MPI_helper::Type_commit (MPI_test_struct);

  MPI_helper::Allgatherv (N , T , NUMBER_OF_PROCESSES , MPI_test_struct , MPI_COMM_WORLD);

  MPI_helper::Type_free (MPI_test_struct);

  transfer_check<struct test_struct> (N , "Allgatherv committed type" , T , T_test);

  delete [] T;
  delete [] T_test;
}

#endif




#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

#ifdef UseMPI
    
    if (NUMBER_OF_PROCESSES == 1) error_message_print_abort ("MPI tests with at least two processes");

    const unsigned int N = 9;

    element_transfer_tests ();

    table_transfer_tests (N);

    test_commit_type (N);
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << "All MPI_helper tests are successful."<<endl;

    MPI_helper::Finalize ();
#endif
  }

