#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#endif

    OpenMP_initialization ();

    const double p_mass = 1.123;
    const double n_mass = 1.234;

    const double core_mass = 4.567;

    const int Z = 9;

    const int N = 12;

    const enum particle_type pi = PROTON;
    
    if (inf_norm (COSM_to_lab_kinetic_factor_calc (p_mass , n_mass , core_mass , pi) - (1.0 + mass_projectile_determine (pi , p_mass , n_mass) / core_mass)) > precision)
      error_message_print_abort ("Problem with COSM_to_lab_kinetic_factor_calc");

    if (inf_norm (COSM_to_lab_kinetic_factor_calc (p_mass , n_mass , core_mass , pi)*lab_to_COSM_kinetic_factor_calc (p_mass , n_mass , core_mass , pi) - 1.0) > precision)
      error_message_print_abort ("Problem with lab_to_COSM_kinetic_factor_calc");

    if (inf_norm (CM_to_lab_kinetic_factor_calc (p_mass , n_mass , Z , N , pi) - (1.0 + mass_projectile_determine (pi , p_mass , n_mass) / mass_target_determine (Z , N , pi , p_mass , n_mass))) > precision)
      error_message_print_abort ("Problem with CM_to_lab_kinetic_factor_calc");

    if (inf_norm (CM_to_lab_kinetic_factor_calc (p_mass , n_mass , Z , N , pi)*lab_to_CM_kinetic_factor_calc (p_mass , n_mass , Z , N , pi) - 1.0) > precision)
      error_message_print_abort ("Problem with lab_to_CM_kinetic_factor_calc");
    
    if (inf_norm (CM_to_COSM_kinetic_factor_calc (p_mass , n_mass , core_mass , Z , N , pi) - CM_to_lab_kinetic_factor_calc (p_mass , n_mass , Z , N , pi)/COSM_to_lab_kinetic_factor_calc (p_mass , n_mass , core_mass , pi)) > precision)
      error_message_print_abort ("Problem with CM_to_COSM_kinetic_factor_calc");

    if (inf_norm (CM_to_COSM_kinetic_factor_calc (p_mass , n_mass , core_mass , Z , N , pi)*COSM_to_CM_kinetic_factor_calc (p_mass , n_mass , core_mass , Z , N , pi) - 1.0) > precision)
      error_message_print_abort ("Problem with COSM_to_CM_kinetic_factor_calc");
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

