#ifndef REFERENCEFRAMECHANGECOEFFICIENTS_H 
#define REFERENCEFRAMECHANGECOEFFICIENTS_H 



// factor related to the change of reference frame from laboratory to COSM
// -----------------------------------------------------------------------
double COSM_to_lab_kinetic_factor_calc (
                                        const double prot_mass_for_calc , 
                                        const double neut_mass_for_calc , 
                                        const double core_mass , 
                                        const enum particle_type projectile);

double lab_to_COSM_kinetic_factor_calc (
                                        const double prot_mass_for_calc , 
                                        const double neut_mass_for_calc , 
                                        const double core_mass , 
                                        const enum particle_type projectile);




// factor related to the change of reference frame from CM to laboratory
// ---------------------------------------------------------------------
double CM_to_lab_kinetic_factor_calc (
                                      const double prot_mass_for_calc , 
                                      const double neut_mass_for_calc , 
                                      const int Z , 
                                      const int N , 
                                      const enum particle_type projectile);

double lab_to_CM_kinetic_factor_calc (
                                      const double prot_mass_for_calc , 
                                      const double neut_mass_for_calc , 
                                      const int Z , 
                                      const int N , 
                                      const enum particle_type projectile);




// factor related to the change of reference frame from CM to COSM
// ---------------------------------------------------------------
double CM_to_COSM_kinetic_factor_calc (
                                       const double prot_mass_for_calc , 
                                       const double neut_mass_for_calc , 
                                       const double core_mass , 
                                       const int Z , 
                                       const int N , 
                                       const enum particle_type projectile);

double COSM_to_CM_kinetic_factor_calc (
                                       const double prot_mass_for_calc , 
                                       const double neut_mass_for_calc , 
                                       const double core_mass , 
                                       const int Z , 
                                       const int N , 
                                       const enum particle_type projectile);


#endif
