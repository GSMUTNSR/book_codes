#include "../numlib_def/numlib_def.h"



// factor related to the change of reference frame from laboratory to COSM
// -----------------------------------------------------------------------

double COSM_to_lab_kinetic_factor_calc (
					const double prot_mass_for_calc , 
					const double neut_mass_for_calc , 
					const double core_mass , 
					const enum particle_type projectile)
{
  const double mass_projectile = mass_projectile_determine (projectile , prot_mass_for_calc , neut_mass_for_calc);

  const double COSM_to_lab_kinetic_factor = 1.0 + mass_projectile / core_mass;

  return COSM_to_lab_kinetic_factor;
}

double lab_to_COSM_kinetic_factor_calc (
					const double prot_mass_for_calc , 
					const double neut_mass_for_calc , 
					const double core_mass , 
					const enum particle_type projectile)
{
  return 1.0/COSM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , core_mass ,  projectile);
}







// factor related to the change of reference frame from CM to laboratory
// ---------------------------------------------------------------------

double CM_to_lab_kinetic_factor_calc (
				      const double prot_mass_for_calc , 
				      const double neut_mass_for_calc , 
				      const int Z , 
				      const int N , 
				      const enum particle_type projectile)
{
  const double mass_projectile = mass_projectile_determine (projectile , prot_mass_for_calc , neut_mass_for_calc);

  const double mass_target = mass_target_determine (Z , N , projectile , prot_mass_for_calc , neut_mass_for_calc);

  const double CM_to_lab_kinetic_factor = 1.0 + mass_projectile / mass_target;

  return CM_to_lab_kinetic_factor;
}

double lab_to_CM_kinetic_factor_calc (
				      const double prot_mass_for_calc , 
				      const double neut_mass_for_calc , 
				      const int Z , 
				      const int N , 
				      const enum particle_type projectile)
{
  return 1.0/CM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Z , N , projectile);
}








// factor related to the change of reference frame from CM to COSM
// ---------------------------------------------------------------

double CM_to_COSM_kinetic_factor_calc (
				       const double prot_mass_for_calc , 
				       const double neut_mass_for_calc , 
				       const double core_mass , 
				       const int Z , 
				       const int N , 
				       const enum particle_type projectile)
{
  const double COSM_to_lab_kinetic_factor = COSM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , core_mass , projectile);

  const double CM_to_lab_kinetic_factor = CM_to_lab_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , Z , N , projectile);

  const double CM_to_COSM_kinetic_factor = CM_to_lab_kinetic_factor/COSM_to_lab_kinetic_factor;

  return CM_to_COSM_kinetic_factor;
}

double COSM_to_CM_kinetic_factor_calc (
				       const double prot_mass_for_calc , 
				       const double neut_mass_for_calc , 
				       const double core_mass , 
				       const int Z , 
				       const int N , 
				       const enum particle_type projectile)
{
  return 1.0/CM_to_COSM_kinetic_factor_calc (prot_mass_for_calc , neut_mass_for_calc , core_mass , Z , N , projectile);
}


