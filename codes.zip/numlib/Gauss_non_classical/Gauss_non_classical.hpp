#ifndef GAUSS_NON_CLASSICAL_H
#define GAUSS_NON_CLASSICAL_H

namespace Gauss_non_classical
{
  template<typename SCALAR_TYPE>
  SCALAR_TYPE poly (
		    const int degree ,
		    const class array<SCALAR_TYPE> &a_table , 
		    const class array<SCALAR_TYPE> &b_table ,
		    const double x);

  template<typename SCALAR_TYPE>
  SCALAR_TYPE scalar_product_calc (
				   const class array<double> &w_table_GL , 
				   const class array<SCALAR_TYPE> &weight_function_table_GL , 
				   const class array<SCALAR_TYPE> &f_table ,
				   const class array<SCALAR_TYPE> &g_table);
  
  template<typename SCALAR_TYPE>
  SCALAR_TYPE weight_function_integral_calc (
					     const class array<double> &w_table_GL , 
					     const class array<SCALAR_TYPE> &weight_function_table_GL);
    
  template<typename SCALAR_TYPE>
  void a_b_tables_calc (
			const class array<double> &x_table_GL , 
			const class array<double> &w_table_GL , 
			const class array<SCALAR_TYPE> &weight_function_table_GL , 
			class array<SCALAR_TYPE> &a_table , 
			class array<SCALAR_TYPE> &b_table);

  template<typename SCALAR_TYPE>
  void abscissas_weights_tables_calc (
				      const class array<double> &x_table_GL ,
				      const class array<double> &w_table_GL ,
				      const class array<SCALAR_TYPE> &weight_function_table_GL ,
				      class array<SCALAR_TYPE> &x_table , 
				      class array<SCALAR_TYPE> &w_table);
}







// Gauss non classical orthogonal polynomial
// ----------------------------------------- 
// The following recurrence relation is used :
// P(i + 1 , x) = (x - a(i)).P(i , x) - b(i).P(i - 1 , x) for i > 0.
// P(0 , x) = 1. This value is directly returned if the degree of the polynomial is 0.
// P(1 , x) = x - a(0). This value is directly returned if the degree of the polynomial is 1.
//
// Variable
// --------
// degree : degree of the Gauss non classical orthogonal polynomial
// a_table : table of <x P(i , x) | P(i , x)> / <P(i , x) | P(i , x)> , 0 <= i < degree. 
// b_table : table of <P(i , x) | P(i , x)> / <P(i-1 , x) | P(i-1 , x)> , 0 <= i < degree. 
// x : variable of the Gauss non classical orthogonal polynomial
// poly_1_x : P(1 , x)
// i , poly_im1 , poly_i , poly_ip1 : Gauss non classical orthogonal polynomial of degree i - 1 , i , i + 1. i goes from 1 to degree-1 , with degree > 1.
// a0: a_table(0)
// ai : a_table(i)
// bi : b_table(i)
// At the end , poly_ip1 is returned.

template<typename SCALAR_TYPE>
SCALAR_TYPE Gauss_non_classical::poly (
				       const int degree ,				  
				       const class array<SCALAR_TYPE> &a_table , 
				       const class array<SCALAR_TYPE> &b_table ,
				       const double x)
{
  if (degree == 0)
    return 1.0; 
  else
    {
      const SCALAR_TYPE &a0 = a_table(0);
	 
      SCALAR_TYPE poly_im1 = 0.0;

      SCALAR_TYPE poly_i = 1.0;

      SCALAR_TYPE poly_ip1 = x - a0;

      for (int i = 1 ; i < degree ; i++)
	{
	  const SCALAR_TYPE &ai = a_table(i);
	  const SCALAR_TYPE &bi = b_table(i);

	  poly_im1 = poly_i;

	  poly_i = poly_ip1;
	  
	  poly_ip1 = (x - ai)*poly_i - bi*poly_im1;
	}

      return poly_ip1;
    }
}


// Calculation of the scalar product of two functions with Gauss non classical quadrature
// --------------------------------------------------------------------------------------
// This is the integral <f|g> = \int f(x) g(x) w(x) dx.
// It is calculated with Gauss-Legendre integration using a sufficiently large number of points N_GL.
// f_table, g_table and weight_function_table_GL are all defined with Gauss-Legendre abscissas.
//
// Variables
// --------- 
// w_table_GL : table of Gauss-Legendre weights to calculate \int f(x) g(x) w(x) dx.
// weight_function_table_GL : Gauss-Legendre non classical weight
// N_GL : number of points in the Gauss-Legendre quadrature.
// scalar_product : returned <f|g>
// wi_GL : w_table_GL(i)
// wx , fx , gx: w(x) , f(x), g(x) in <f|g> = \int f(x) g(x) w(x) dx.

template<typename SCALAR_TYPE>
SCALAR_TYPE Gauss_non_classical::scalar_product_calc (
						      const class array<double> &w_table_GL , 
						      const class array<SCALAR_TYPE> &weight_function_table_GL , 
						      const class array<SCALAR_TYPE> &f_table ,
						      const class array<SCALAR_TYPE> &g_table)
{
  const unsigned int N_GL = w_table_GL.dimension (0);

  SCALAR_TYPE scalar_product = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double wi_GL = w_table_GL(i);
      
      const SCALAR_TYPE &wx = weight_function_table_GL(i);
      
      const SCALAR_TYPE &fx = f_table(i);
      const SCALAR_TYPE &gx = g_table(i);

      scalar_product += fx*gx*wx*wi_GL;
    }

  return scalar_product;
}





// Calculation of \int w(x) dx.
// --------------------------------------
// It is calculated with Gauss-Legendre integration using a sufficiently large number of points N_GL.
// f_table, g_table and weight_function_table_GL are all defined with Gauss-Legendre abscissas.
//
// Variables
// --------- 
// w_table_GL : table of Gauss-Legendre weights to calculate \int w(x) dx.
// weight_function_table_GL : Gauss-Legendre non classical weight
// N_GL : number of points in the Gauss-Legendre quadrature.
// scalar_product : returned <f|g>
// wi_GL : w_table_GL(i)
// wx: w(x) in \int w(x) dx.

template<typename SCALAR_TYPE>
SCALAR_TYPE Gauss_non_classical::weight_function_integral_calc (
								const class array<double> &w_table_GL , 
								const class array<SCALAR_TYPE> &weight_function_table_GL)
{
  const unsigned int N_GL = w_table_GL.dimension (0);

  SCALAR_TYPE weight_function_integral = 0.0;

  for (unsigned int i = 0 ; i < N_GL ; i++)
    {
      const double wi_GL = w_table_GL(i);

      const SCALAR_TYPE &wx = weight_function_table_GL(i);

      weight_function_integral += wx*wi_GL;
    }

  return weight_function_integral;
}




// Calculation of the tables of coefficients entering Gauss non classical orthogonal polynomials
// ---------------------------------------------------------------------------------------------
// One has P(i + 1 , x) = (x - a(i)).P(i , x) - b(i).P(i - 1 , x) for i > 0 which defines orthogonal polynomials.
// The following numbers are thus calculated here:
// a(i) = <x P(i , x) | P(i , x)> / <P(i , x) | P(i , x)> , 0 <= i < N
// b(i) = <P(i , x) | P(i , x)> / <P(i-1 , x) | P(i-1 , x)> , 0 <= i < N
//
// Variables
// --------- 
// x_table_GL : table of Gauss-Legendre abscissas to calculate \int f(x) g(x) w(x) dx.
// w_table_GL : table of Gauss-Legendre weights to calculate \int f(x) g(x) w(x) dx.
// weight_function_table_GL : Gauss-Legendre non classical weight
// N_GL : number of points in the Gauss-Legendre quadrature.
// N : number of points in the Gauss non classical quadrature.
// pi_x: P(i , x)
// pi_scalar_pi , p_im1_scalar_p_im1  : <P(i , x) | P(i , x)> , <P(i-1 , x) | P(i-1 , x)>
// xpi_scalar_pi : <x P(i , x) | P(i , x)>
// a_table: table of a(i) coefficients
// b_table: table of b(i) coefficients
// p_table : table of P(i , x) values, for x in Gauss-Legendre abscissas. It contains N_GL numbers.
// xp_table : table of x P(i , x) values, for x in Gauss-Legendre abscissas. It contains N_GL numbers.

template<typename SCALAR_TYPE>
void Gauss_non_classical::a_b_tables_calc (
					   const class array<double> &x_table_GL , 
					   const class array<double> &w_table_GL , 
					   const class array<SCALAR_TYPE> &weight_function_table_GL , 
					   class array<SCALAR_TYPE> &a_table , 
					   class array<SCALAR_TYPE> &b_table)
{
  const unsigned int N_GL = weight_function_table_GL.dimension (0);
  
  const unsigned int N = a_table.dimension (0);

  class array<SCALAR_TYPE> p_table(N_GL);
  
  class array<SCALAR_TYPE> xp_table(N_GL);

  p_table = 1.0;
  
  xp_table = x_table_GL;
      
  const SCALAR_TYPE  p0_scalar_p0 = scalar_product_calc (w_table_GL , weight_function_table_GL , p_table  , p_table);
  const SCALAR_TYPE xp0_scalar_p0 = scalar_product_calc (w_table_GL , weight_function_table_GL , p_table , xp_table);

  a_table(0) = xp0_scalar_p0/p0_scalar_p0;
      
  b_table(0) = 0.0;

  SCALAR_TYPE p_im1_scalar_p_im1 = p0_scalar_p0;
  	
  for (unsigned int i = 1 ; i < N ; i++) 
    {
      for (unsigned int j = 0 ; j < N_GL ; j++)
	{
	  const double x = x_table_GL(j);

	  const SCALAR_TYPE pi_x = poly (i , a_table , b_table , x);
	  
	  p_table(j) = pi_x;

	  xp_table(j) = x*pi_x;
	}

      const SCALAR_TYPE  pi_scalar_pi = scalar_product_calc (w_table_GL , weight_function_table_GL , p_table  , p_table);
      const SCALAR_TYPE xpi_scalar_pi = scalar_product_calc (w_table_GL , weight_function_table_GL , p_table , xp_table);

      a_table(i) = xpi_scalar_pi/pi_scalar_pi;
      
      b_table(i) = pi_scalar_pi/p_im1_scalar_p_im1;

      p_im1_scalar_p_im1 = pi_scalar_pi;      
    }
}






// Calculation of the abcissas and weights of the Gauss quadrature for non classical weights
// -----------------------------------------------------------------------------------------
// These are the abcissas and weights of the Gauss quadrature with a given numerical weight w(x).
// N points are considered for the non classical Gauss quadrature.
// The computed Gauss absissas and weights corresponds to the integration of \int f(x) w(x) dx.
// The weight function w(x) must be given as input. 
// All scalar products involving w(x) are calculated with Gauss-Legendre integration using a sufficiently large number of points N_GL.
// Abscissas and weights are calculated by diagonalizing a tridiagonal matrix of dimension N.
// See Numerical Recipes for the method.
//
// Variables
// --------- 
// N_GL : number of points in the Gauss-Legendre quadrature.
// N, Nm1 : number of points in the non classical Gauss quadrature, N-1.
// x_table_GL : table of Gauss-Legendre abscissas.
// w_table_GL : table of Gauss-Legendre weights.
// weight_function_table_GL: table of weight function values w(x) for x in x_table_GL 
// x_table : table of abscissas of non classical points of the function to integrate.
// w_table : table of non classical weights of the function to integrate.
// a_table :     table of a(i) coefficients entering Gauss non classical orthogonal polynomials
// b_work_table: table of b(i) coefficients entering Gauss non classical orthogonal polynomials, put to sqrt (b(i+1)) for 0 <= i < N-1 afterwards.
// P_Jacobi: matrix of Jacobi eigenvectors
// P_Ji, P_Ji_0: Jacobi eigenvector of index i,  P_Ji(0)

template<typename SCALAR_TYPE>
void Gauss_non_classical::abscissas_weights_tables_calc (
							 const class array<double> &x_table_GL ,
							 const class array<double> &w_table_GL ,
							 const class array<SCALAR_TYPE> &weight_function_table_GL ,
							 class array<SCALAR_TYPE> &x_table , 
							 class array<SCALAR_TYPE> &w_table)
{
  const unsigned int N = x_table.dimension (0);

  const unsigned int Nm1 = N - 1;
  
  class array<SCALAR_TYPE> a_table(N);
  
  class array<SCALAR_TYPE> b_work_table(N);
  
  a_b_tables_calc (x_table_GL , w_table_GL , weight_function_table_GL , a_table , b_work_table);      
  
  for (unsigned int i = 0 ; i < Nm1 ; i++) b_work_table(i) = sqrt (b_work_table(i + 1));
  
  b_work_table(Nm1) = 0.0;
    
  class matrix<SCALAR_TYPE> P_Jacobi(N);
  
  total_diagonalization::symmetric::all_eigenpairs (b_work_table , a_table , P_Jacobi , x_table);
    
  const SCALAR_TYPE weight_function_integral = weight_function_integral_calc (w_table_GL , weight_function_table_GL);
      
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<SCALAR_TYPE> &P_Ji = P_Jacobi.eigenvector (i);

      const SCALAR_TYPE &P_Ji_0 = P_Ji(0);
  
      w_table(i) = weight_function_integral*P_Ji_0*P_Ji_0;
    }
}

#endif

