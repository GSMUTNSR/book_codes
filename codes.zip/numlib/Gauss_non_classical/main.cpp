#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);
    
    const unsigned int N = 30;

    const unsigned int N_GL = 100;

    const double x_max = 2.0;
    
    const double alpha = 5.0;
      
    class array<double> x_tab_GL(N_GL);
    class array<double> w_tab_GL(N_GL);
    
    Gauss_Legendre::abscissas_weights_tables_calc (0.0 , x_max , x_tab_GL , w_tab_GL);
	    
    class array<double> weight_function_tab_GL(N_GL);

    for (unsigned int i = 0 ; i < N_GL ; i++) weight_function_tab_GL(i) = exp (-20*x_tab_GL(i));
    
    double integral_Gauss_Legendre = 0.0;
    
    for (unsigned int i = 0 ; i < N_GL ; i++) integral_Gauss_Legendre += cos (alpha*x_tab_GL(i))*weight_function_tab_GL(i)*w_tab_GL(i);
	
    cout << "cos (" << alpha << "x) exp(-20x) is integrated numerically with Gauss-Legendre and Gauss with w(x) = exp(-20x) between x_min = 0 and x_max = " << x_max << "." << endl << endl;
    
    cout << "n    integral (Gauss-Legendre with n)  integral (Gauss-Legendre with N[GL] = " << N_GL << ")    test " << endl << endl;

    for (unsigned int n = 1 ; n < N ; n++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);

	class array<double> weight_function_tab(n);
	
	Gauss_Legendre::abscissas_weights_tables_calc (0.0 , x_max , x_tab , w_tab);
		
	for (unsigned int i = 0 ; i < n ; i++) weight_function_tab(i) = exp (-20*x_tab(i));
    
	double integral = 0.0;
	
	for (unsigned int i = 0 ; i < n ; i++) integral += cos (alpha*x_tab(i))*weight_function_tab(i)*w_tab(i);
	
	cout << n << " " << integral << " " << integral_Gauss_Legendre << " " << inf_norm (integral/integral_Gauss_Legendre - 1.0) << endl;
      }

    cout << endl << endl;
    
    cout << "n    integral (Gauss non classical)  integral (Gauss-Legendre with N[GL] = " << N_GL << ")    test " << endl << endl;

    const unsigned int N_NC = 10;
    
    for (unsigned int n = 1 ; n <= N_NC ; n++)
      {	
	class array<double> x_tab(n);
	class array<double> w_tab(n);
	
	Gauss_non_classical::abscissas_weights_tables_calc (x_tab_GL , w_tab_GL , weight_function_tab_GL , x_tab , w_tab);
	
	double integral = 0.0;
	
	for (unsigned int i = 0 ; i < n ; i++) integral += cos (alpha*x_tab(i))*w_tab(i);
	
	cout << n << " " << integral << " " << integral_Gauss_Legendre << " " << inf_norm (integral/integral_Gauss_Legendre - 1.0) << endl;
      }
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

