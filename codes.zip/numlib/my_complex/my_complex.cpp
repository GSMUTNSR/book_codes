#include "numlib_def/numlib_def.h"
#include "my_complex.h"

using namespace string_routines;

// Class defining the my_complex number type
// -----------------------------------------

double inf_norm (const my_complex &z)
{
  const double Re_z = real (z) , abs_Re_z = abs (Re_z);
  const double Im_z = imag (z) , abs_Im_z = abs (Im_z);

  const double inf_norm_z = max (abs_Re_z , abs_Im_z);
  
  return inf_norm_z;
}


double abs (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  const double abs_x = abs (x);
  const double abs_y = abs (y);
  
  if (y == 0.0) return abs_x;
  if (x == 0.0) return abs_y;

  if (abs_x >= abs_y)
    {
      const double z_ratio = y/x;

      return abs_x*sqrt (1.0 + z_ratio*z_ratio);
    }
  else 
    {
      const double z_ratio = x/y;

      return abs_y*sqrt (1.0 + z_ratio*z_ratio);
    }
}


template <> my_complex generate_scalar<my_complex> (const double x , const double y)
{
  return my_complex (x , y);
}



ostream & operator << (ostream &os , const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if (y == 0.0) 
    return os << x;
  else
    return os << "(" << x << "," << y << ")";
}


istream & operator >> (istream &is , my_complex &z)
{
  char c;
  is >> c;

  if (c != '(')
    {
      is.putback (c);

      is >> z.re;

      z.im = 0.0;

      return is;
    }
  else
    {
      is >> z.re >> c;

      switch (c)
	{
	case ')': 
	  {
	    z.im = 0.0; 

	    return is;
	  }

	case ',': 
	  {
	    is >> z.im >> c;

	    if (c == ')') 
	      return is; 
	    else 
	      is.setstate (ios::failbit);

	    break;
	  }

	default: is.setstate (ios::failbit);
	}
    }

  return is;
}

my_complex polar(const double r , const double theta)
{
  const double re = r*cos (theta);
  const double im = r*sin (theta);

  return my_complex (re , im);
}

my_complex exp (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);
  
  const double exp_x = exp (x);

  return polar (exp_x , y);
}

my_complex expm1 (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((abs (x) >= 1.0) || (abs (y) >= 1.0))
    {
      const my_complex expm1_z = exp (z) - 1.0;
  
      return expm1_z;
    }
  
  const double half_y = 0.5 * y;
  
  const double expm1_x = expm1 (x);
  
  const double exp_x = 1.0 + expm1_x;
  
  const double two_exp_x = 2.0 * exp_x;
  
  const double sin_y_over_two = sin (half_y);
  
  const double sin_y_over_two_square = sin_y_over_two * sin_y_over_two;
  
  const double sin_y = sin (y);

  const double Re_expm1_z = expm1_x - two_exp_x * sin_y_over_two_square;
  
  const double Im_expm1_z = exp_x * sin_y;

  return my_complex (Re_expm1_z , Im_expm1_z);
}











my_complex cosh (const my_complex &z)
{ 
  const double x = real (z);
  const double y = imag (z);

  const double Re_cosh_z = cosh (x)*cos (y);
  const double Im_cosh_z = sinh (x)*sin (y);

  return my_complex (Re_cosh_z , Im_cosh_z);
}

my_complex sinh (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  const double Re_sinh_z = sinh (x)*cos (y);
  const double Im_sinh_z = cosh (x)*sin (y);
  
  return my_complex (Re_sinh_z , Im_sinh_z);
}


my_complex tanh (const my_complex &z)
{ 
  const double x = real (z);

  if (abs (x) < 0.1) 
    return sinh (z)/cosh (z);
  else if (x < 0.0)
    {
      const my_complex two_z = 2.0*z;
      
      const my_complex tanh_z = expm1 (two_z)/(exp (two_z) + 1.0);
      
      return tanh_z;
    }
  else
    {
      const my_complex minus_two_z = -2.0*z;
            
      const my_complex tanh_z = -expm1 (minus_two_z)/(exp (minus_two_z) + 1.0);
      
      return tanh_z;
    }
}




my_complex cos (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  const double Re_cos_z =  cos (x)*cosh (y);
  const double Im_cos_z = -sin (x)*sinh (y);
  
  return my_complex (Re_cos_z , Im_cos_z);
}

my_complex sin (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  const double Re_sin_z = sin (x)*cosh (y);
  const double Im_sin_z = cos (x)*sinh (y);
  
  return my_complex (Re_sin_z , Im_sin_z);
}

my_complex tan (const my_complex &z)
{
  const double y = imag (z);

  if (abs (y) < 0.1) 
    return sin (z)/cos (z);
  else if (y > 0.0)
    {      
      const my_complex two_Iz(-2.0*imag (z) , 2.0*real (z));

      const my_complex I_tan_z = expm1 (two_Iz)/(exp (two_Iz) + 1.0);

      const my_complex tan_z(imag (I_tan_z) , -real (I_tan_z));
      
      return tan_z;
    }
  else
    {
      const my_complex minus_two_Iz(2.0*imag (z) , -2.0*real (z));
      
      const my_complex minus_I_tan_z = expm1 (minus_two_Iz)/(exp (minus_two_Iz) + 1.0);

      const my_complex tan_z(-imag (minus_I_tan_z) , real (minus_I_tan_z));
      
      return tan_z;
    }
}




my_complex log (const my_complex &z)
{ 
  const double x = real (z);
  const double y = imag (z);

  const double abs_x = abs (x);
  const double abs_y = abs (y);

  if (abs_x >= abs_y)
    {
      const double z_ratio = y/x;

      const double Re_log_z = log (abs_x) + 0.5*log1p (z_ratio*z_ratio);
      
      const double Im_log_z = atan2 (y , x);

      return my_complex (Re_log_z , Im_log_z);
    }
  else 
    {
      const double z_ratio = x/y;

      const double Re_log_z = log (abs_y) + 0.5*log1p (z_ratio*z_ratio);
      
      const double Im_log_z = atan2 (y , x);

      return my_complex (Re_log_z , Im_log_z);
    }
}




my_complex log10 (const my_complex &z)
{ 
  const my_complex log10_z = log (z)/M_LN10;
      
  return log10_z;
}





my_complex log1p (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z); 
  
  if ((abs (x) >= 1.0) || (abs (y) >= 1.0))
    {
      const my_complex log1p_z = log (1.0 + z);
      
      return log1p_z;
    }

  const double xp1 = 1.0 + x;

  const double log1p_x = log1p (x);

  const double y_over_xp1 = y/xp1;

  const double y_over_xp1_square = y_over_xp1 * y_over_xp1;

  const double log1p_y_over_xp1_square = log1p (y_over_xp1_square);

  const double half_log1p_y_over_xp1_square = 0.5*log1p_y_over_xp1_square; 

  const double Re_log1p_z = log1p_x + half_log1p_y_over_xp1_square;

  const double Im_log1p_z = atan2 (y , xp1);
  
  return my_complex (Re_log1p_z , Im_log1p_z);
}


my_complex pow (const my_complex &z , const unsigned int N)
{
  if (z == 0.0) 
    {
      if (N == 0) 
	return 1.0;
      else 
	return 0.0;
    }
    
  my_complex pow_z = 1.0;
  
  for (unsigned int i = 0 ; i < N ; i++) pow_z *= z;

  return pow_z;
}




my_complex pow (const my_complex &z , const int n)
{
  if (z == 0.0) 
    {
      if (n == 0) 
	return 1.0;
      else if (n > 0) 
	return 0.0;
      else
	error_message_print_abort ("0^a undefined with n = " + make_string<int> (n));
    }
    
  const int N = abs (n);

  const my_complex zz = (n >= 0) ? (z) : (1.0/z);

  my_complex pow_z = 1.0;
  
  for (int i = 0 ; i < N ; i++) pow_z *= zz;

  return pow_z;
}





my_complex pow (const my_complex &z , const double a)
{
  if (z == 0.0)
    {
      if (a == 0.0) 
	return 1.0;
      else if (a > 0.0) 
	return 0.0;
      else 
	error_message_print_abort ("0^a undefined with a = " + make_string<double> (a));
    }

  const int n = static_cast<int> (rint (a));

  if (a == n) 
    return pow (z , n);
  else
    return exp (a*log (z));
}




my_complex pow (const double x , const my_complex &a)
{
  if (x == 0.0)
    {
      if (a == 0.0) 
	return 1.0;
      else if (real (a) > 0.0) 
	return 0.0;
      else
	error_message_print_abort ("0^a undefined with a = " + make_string<my_complex> (a));
    }

  const int n = static_cast<int> (rint (real (a)));

  if (a == n) 
    {
      const int N = abs (n);
      
      const double xx = (n >= 0) ? (x) : (1.0/x);

      double pow_z = 1.0;
      
      for (int i = 0 ; i < N ; i++) pow_z *= xx;

      return pow_z;
    }
  else
    return exp (a*log (x));
}




my_complex pow (const my_complex &z , const my_complex &a)
{
  if (z == 0.0)
    {
      if (a == 0.0) 
	return 1.0;
      else if (real (a) > 0.0) 
	return 0.0;
      else 
	error_message_print_abort ("0^a undefined with a = " + make_string<my_complex> (a));
    }

  const int n = static_cast<int> (rint (real (a)));

  if (a == n) 
    return pow (z , n);
  else
    return exp (a*log (z));
}





my_complex cbrt (const my_complex &z)
{
  if (imag (z) == 0.0)
    {
      const double x = real (z);

      return cbrt (x);
    }
  
  const double r = abs (z);

  const double theta = arg (z);

  const double cbrt_r = cbrt (r);

  const double theta_over_three = 0.3333333333333333 * theta;

  return polar (cbrt_r , theta_over_three);
}





my_complex sqrt (const my_complex &z)
{
  if (z == 0.0) return 0.0;

  const double x = real (z);
  const double y = imag (z);
  
  const double abs_x = abs (x);
  const double abs_y = abs (y);

  if (abs_x >= abs_y)
    {
      const double abs_z_ratio = abs_y/abs_x;

      const double w = sqrt (abs_x)*sqrt (0.5*(1.0 + sqrt (1.0 + abs_z_ratio*abs_z_ratio))); 
      
      if (x >= 0.0)
	return my_complex (w , y*0.5/w);
      else if (y >= 0.0)
	return my_complex (abs_y*0.5/w , w);
      else
	return my_complex (abs_y*0.5/w , -w);
    }
  else
    {
      const double abs_z_ratio = abs_x/abs_y;

      const double w = sqrt (abs_y)*sqrt (0.5*(abs_z_ratio + sqrt (1.0 + abs_z_ratio*abs_z_ratio)));

      if (x >= 0.0)
	return my_complex (w , y*0.5/w);
      else if (y >= 0.0)
	return my_complex (abs_y*0.5/w , w);
      else
	return my_complex (abs_y*0.5/w , -w);
    }
}

// Sqrt function with its cut on ]-i.oo:0[
// --------------------------------------- - 

my_complex sqrt_mod (const my_complex &z)
{
  if (real (z) >= 0.0) 
    {
      return sqrt (z);
    }
  else
    {
      const my_complex sqrt_mz = sqrt (-z);

      const double Re_sqrt_mz = real (sqrt_mz);
      const double Im_sqrt_mz = imag (sqrt_mz);
  
      return my_complex (-Im_sqrt_mz , Re_sqrt_mz);
    }
}

my_complex hypot (const my_complex &z1 , const my_complex &z2)
{
  const double max_inf_norm = max (inf_norm (z1) , inf_norm (z2));
  
  if ((max_inf_norm > SQRT_SMALL) && (max_inf_norm < SQRT_INFINITE))
    {
      const my_complex norm_z1_z2 = z1*z1 + z2*z2;
      
      const my_complex hypot_z1_z2 = sqrt (norm_z1_z2);
        
      return hypot_z1_z2;
    }
  else
    {
      const double one_over_max_inf_norm = 1.0/max_inf_norm;

      const my_complex z1_renorm = z1*one_over_max_inf_norm;
      const my_complex z2_renorm = z2*one_over_max_inf_norm;

      const my_complex norm_z1_z2_renorm = z1_renorm*z1_renorm + z2_renorm*z2_renorm;
      
      const my_complex hypot_z1_z2 = max_inf_norm*sqrt (norm_z1_z2_renorm);
      
      return hypot_z1_z2;
    }
}



my_complex acosh (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (x >= 1.0)) return acosh (x);

  const my_complex z2 = z*z;
  
  const my_complex z2_minus_one = z2 - 1.0;
  
  const my_complex sqrt_z2_minus_one = sqrt (z2_minus_one);
  
  const my_complex z_plus_sqrt_z2_minus_one = z + sqrt_z2_minus_one;
      
  return log (z_plus_sqrt_z2_minus_one);
}

my_complex asinh (const my_complex &z)
{
  if (imag (z) == 0.0) return asinh (real (z));

  const my_complex z2 = z*z;

  const my_complex z2_plus_one = z2 + 1.0;
  
  const my_complex sqrt_z2_plus_one = sqrt (z2_plus_one);
  
  const my_complex one_plus_sqrt_z2_plus_one = 1.0 + sqrt_z2_plus_one;
  
  const my_complex z_plus_z2_over_sqrt_z2_plus_one = z + z2/one_plus_sqrt_z2_plus_one;
  
  return log1p (z_plus_z2_over_sqrt_z2_plus_one);
}

my_complex atanh (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (abs (x) <= 1.0)) return atanh (x);

  const my_complex two_z = 2.0*z;

  const my_complex one_minus_z = 1.0 - z;

  const my_complex two_z_over_one_minus_z = two_z/one_minus_z;

  const my_complex log1p_two_z_over_one_minus_z = log1p (two_z_over_one_minus_z);

  const my_complex half_log1p_two_z_over_one_minus_z = 0.5 * log1p_two_z_over_one_minus_z;
  
  return half_log1p_two_z_over_one_minus_z;
}







my_complex acos (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (abs (x) <= 1.0)) return acos (x);

  const my_complex one_minus_z2 = 1.0 - z*z;

  const my_complex sqrt_one_minus_z2 = sqrt (one_minus_z2);

  const double Re_sqrt_one_minus_z2 = real (sqrt_one_minus_z2);
  const double Im_sqrt_one_minus_z2 = imag (sqrt_one_minus_z2);
  
  const my_complex I_sqrt_one_minus_z2(-Im_sqrt_one_minus_z2 , Re_sqrt_one_minus_z2);
  
  const my_complex z_plus_I_sqrt_one_minus_z2 = z + I_sqrt_one_minus_z2;

  const my_complex log_z_plus_I_sqrt_one_minus_z2 = log (z_plus_I_sqrt_one_minus_z2);

  const double Re_log_z_plus_I_sqrt_one_minus_z2 = real (log_z_plus_I_sqrt_one_minus_z2);
  const double Im_log_z_plus_I_sqrt_one_minus_z2 = imag (log_z_plus_I_sqrt_one_minus_z2);
  
  return my_complex (Im_log_z_plus_I_sqrt_one_minus_z2 , -Re_log_z_plus_I_sqrt_one_minus_z2);
}


my_complex asin (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  if ((y == 0.0) && (abs (x) <= 1.0)) return asin (x);

  const my_complex Iz(-y , x);

  const my_complex asinh_z = asinh (Iz);

  const double Re_asinh_z = real (asinh_z);
  const double Im_asinh_z = imag (asinh_z);
  
  return my_complex (Im_asinh_z , -Re_asinh_z);
}


my_complex atan (const my_complex &z)
{
  if (imag (z) == 0.0) return atan (real (z));

  const double x = real (z);
  const double y = imag (z);
  
  const my_complex Iz(-y , x);

  const my_complex atanh_z = atanh (Iz);
  
  const double Re_atanh_z = real (atanh_z);
  const double Im_atanh_z = imag (atanh_z);
  
  return my_complex (Im_atanh_z , -Re_atanh_z);
}

double used_memory_calc (const my_complex &T)
{
  return sizeof (T)/1000000.0;
}
