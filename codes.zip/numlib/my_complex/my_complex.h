#ifndef MYCOMPLEX_H
#define MYCOMPLEX_H

class my_complex
{
public:
  my_complex () {}
  
  my_complex (const my_complex &z) : re (z.re) ,  im (z.im) {}
  
  my_complex (const double a , const double b) : re (a) ,  im (b) {}
  
  my_complex (const double a) : re (a) ,  im (0.0) {}
  
  my_complex & operator  = (const my_complex &z);
  my_complex & operator += (const my_complex &z);
  my_complex & operator -= (const my_complex &z);
  my_complex & operator *= (const my_complex &z);
  my_complex & operator /= (const my_complex &z);
  
  my_complex & operator  = (const double x);
  my_complex & operator += (const double x);
  my_complex & operator -= (const double x);
  my_complex & operator *= (const double x);
  my_complex & operator /= (const double x);
  
  friend double real (const my_complex &z);
  friend double imag (const my_complex &z);
  
  friend istream & operator >> (istream &is , my_complex &z);
  
  friend double used_memory_calc (const my_complex &T);
  
private:
  double re;
  double im;
};

inline double real (const my_complex &z)
{
  return z.re;
}

inline double real (const double x)
{
  return x;
}

inline double imag (const my_complex &z)
{
  return z.im;
}

inline double imag (const double)
{
  return 0.0;
}

inline my_complex conj (const my_complex &z)
{
  return my_complex (real (z) , -imag (z));
}

inline double conj (const double x)
{
  return x;
}

inline bool finite (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  return (finite (x) && finite (y));
}

inline double arg (const my_complex &z)
{
  const double res = atan2 (imag (z) , real (z));
  
  return res;
}

inline double arg (const double x)
{
  const double res = (x >= 0.0) ? (0.0) : (M_PI);
  
  return res;
}

inline my_complex & my_complex::operator = (const double x)
{
  re = x;
  im = 0.0;

  return *this;
}

inline my_complex & my_complex::operator += (const double x)
{
  re += x;

  return  *this;
}

inline my_complex & my_complex::operator -= (const double x)
{
  re -= x;

  return  *this; 
}

inline my_complex & my_complex::operator *= (const double x)
{
  re *= x;
  im *= x; 

  return *this;
}

inline my_complex & my_complex::operator /= (const double x)
{
  re /= x;
  im /= x;

  return *this;
}

inline my_complex & my_complex::operator = (const my_complex &z)
{
  re = real (z);
  im = imag (z);

  return *this;
}

inline my_complex & my_complex::operator += (const my_complex &z)
{
  re += real (z);
  im += imag (z);

  return  *this;
}

inline my_complex & my_complex::operator -= (const my_complex &z)
{
  re -= real (z);
  im -= imag (z);

  return  *this; 
}

inline my_complex & my_complex::operator *= (const my_complex &z)
{
  const double x = real (z);
  const double y = imag (z);

  const double Re_res = re*x - im*y;
  const double Im_res = re*y + im*x;

  re = Re_res;
  im = Im_res;

  return *this;
}

inline my_complex & my_complex::operator /= (const my_complex &z)
{ 
  const double x = real (z);
  const double y = imag (z);

  const double abs_x = abs (x);
  const double abs_y = abs (y);
  
  if (abs_x >= abs_y)
    {
      const double z_ratio = y/x;

      const double z_norm_scaled = x + y*z_ratio;
      
      const double z_ratio_scaled = z_ratio/z_norm_scaled;

      const double Re_res = re/z_norm_scaled + im*z_ratio_scaled;
      const double Im_res = im/z_norm_scaled - re*z_ratio_scaled;

      re = Re_res;
      im = Im_res;
    }
  else
    {
      const double z_ratio = x/y;

      const double z_norm_scaled = x*z_ratio + y;

      const double z_ratio_scaled = z_ratio/z_norm_scaled;
      
      const double Re_res = re*z_ratio_scaled + im/z_norm_scaled;
      const double Im_res = im*z_ratio_scaled - re/z_norm_scaled;

      re = Re_res;
      im = Im_res;
    }

  return *this;
}

inline my_complex operator + (const my_complex &z , const double x)
{
  my_complex res = z;

  res += x;

  return res;
}

inline my_complex operator - (const my_complex &z , const double x)
{
  my_complex res = z;

  res -= x;

  return res;
}

inline my_complex operator * (const my_complex &z , const double x)
{
  my_complex res = z;

  res *= x;

  return res;
}

inline my_complex operator / (const my_complex &z , const double x)
{
  my_complex res = z;

  res /= x;

  return res;
}

inline my_complex operator + (const double x , const my_complex &z)
{
  my_complex res = x;

  res += z;

  return res;
}

inline my_complex operator - (const double x , const my_complex &z)
{
  my_complex res = x;

  res -= z;

  return res;
}

inline my_complex operator * (const double x , const my_complex &z)
{
  my_complex res = x;

  res *= z;

  return res;
}

inline my_complex operator / (const double x , const my_complex &z)
{
  my_complex res = x;

  res /= z;

  return res;
}

inline my_complex operator + (const my_complex &z)
{
  return z;
}

inline my_complex operator - (const my_complex &z)
{
  return my_complex (-real (z) , -imag (z));
}

inline my_complex operator + (const my_complex &z1 , const my_complex &z2)
{
  my_complex res = z1;

  res += z2;

  return res;
}

inline my_complex operator - (const my_complex &z1 , const my_complex &z2)
{
  my_complex res = z1;

  res -= z2;

  return res;
}

inline my_complex operator * (const my_complex &z1 , const my_complex &z2)
{
  my_complex res = z1;

  res *= z2;

  return res;
}

inline my_complex operator / (const my_complex &z1 , const my_complex &z2)
{
  my_complex res = z1;
  
  res /= z2;

  return res;
}

inline bool operator == (const my_complex &z1 , const my_complex &z2)
{
  return (real (z1) == real (z2)) && (imag (z1) == imag (z2));
}

inline bool operator != (const my_complex &z1 , const my_complex &z2)
{
  return (real (z1) != real (z2)) || (imag (z1) != imag (z2));
}

inline bool operator == (const my_complex &z , const double x)
{
  return (real (z) == x) && (imag (z) == 0.0);
}

inline bool operator != (const my_complex &z , const double x)
{
  return (real (z) != x) || (imag (z) != 0.0);
}

inline bool operator == (const double x , const my_complex &z)
{
  return (x == real (z)) && (0.0 == imag (z));
}

inline bool operator != (const double x , const my_complex &z)
{
  return (x != real (z)) || (0.0 != imag (z));
}

inline double norm (const my_complex &x)
{
  return (real (x)*real (x) + imag (x)*imag (x));
}

inline double norm_c (const my_complex &x)
{
  return norm (x);
}

inline double real_dc (const my_complex &x)
{
  return real (x);
}

inline double imag_dc (const my_complex &x)
{
  return imag (x);
}

inline my_complex conj_dc (const my_complex &x)
{
  return conj (x);
}

inline double norm_dc (const my_complex &x)
{
  return norm (x);
}

double abs (const my_complex &z);

double norm_c (const my_complex &x);

double real_dc (const my_complex &x);

double imag_dc (const my_complex &x);

my_complex conj_dc (const my_complex &x);

double norm_dc (const my_complex &x);

double inf_norm (const my_complex &z);

ostream & operator << (ostream &os , const my_complex &z);

istream & operator >> (istream &is , my_complex &z);

my_complex polar(const double r , const double theta);

my_complex exp (const my_complex &z);

my_complex expm1 (const my_complex &z);

my_complex cosh (const my_complex &z);

my_complex sinh (const my_complex &z);

my_complex tanh (const my_complex &z);

my_complex cos (const my_complex &z);

my_complex sin (const my_complex &z);

my_complex tan (const my_complex &z);

my_complex log (const my_complex &z);

my_complex log10 (const my_complex &z);

my_complex log1p (const my_complex &z);

my_complex pow (const my_complex &z , const unsigned int N);

my_complex pow (const my_complex &z , const int n);

my_complex pow (const my_complex &z , const double a);

my_complex pow (const double x , const my_complex &a);

my_complex pow (const my_complex &z , const my_complex &a);

my_complex cbrt (const my_complex &z);

my_complex sqrt (const my_complex &z);

my_complex hypot (const my_complex &z1 , const my_complex &z2);

my_complex acosh (const my_complex &z);

my_complex asinh (const my_complex &z);

my_complex atanh (const my_complex &z);

my_complex acos (const my_complex &z);

my_complex asin (const my_complex &z);

my_complex atan (const my_complex &z);

#endif
