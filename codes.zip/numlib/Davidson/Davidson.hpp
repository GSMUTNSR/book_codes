#ifndef DAVIDSON_HPP
#define DAVIDSON_HPP

namespace Davidson
{	
  template <typename SCALAR_TYPE>
  class vector_class<SCALAR_TYPE> A_app_minus_E_inverse_calc (
							      const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
							      const class matrix<SCALAR_TYPE> &P_subspace , 
							      const class array<SCALAR_TYPE> &A_diagonal_part , 
							      const SCALAR_TYPE &E , 
							      const class vector_class<SCALAR_TYPE> &Res);

  template <typename SCALAR_TYPE>
  void eigenvalue_Res_test (
			    const bool is_there_cout , 
			    const unsigned int Davidson_dimension , 
			    const class matrix<SCALAR_TYPE> &Davidson , 
			    const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
			    const class array<class vector_class<SCALAR_TYPE> > &AV_tab , 
			    class vector_class<SCALAR_TYPE> &Res , 
			    SCALAR_TYPE &E , 
			    double &test);

  template <typename SCALAR_TYPE>
  void eigenpair_calc (
		       const unsigned int Davidson_dimension , 
		       const class matrix<SCALAR_TYPE> &Davidson , 
		       const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
		       SCALAR_TYPE &eigenvalue , 
		       class vector_class<SCALAR_TYPE> &eigenvector);

  template <typename SCALAR_TYPE>
  void Davidson_matrix_calc (
			     const bool is_there_cout , 
			     const bool is_it_sparse , 
			     const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
			     const class matrix<SCALAR_TYPE> &P_subspace , 
			     const class vector_class<SCALAR_TYPE> &pivot , 
			     const double eigenvector_precision , 
			     const class matrix<SCALAR_TYPE> &A , 
			     const class sparse_matrix<SCALAR_TYPE> &As , 
			     const class array<SCALAR_TYPE> &A_diagonal_part , 
			     class matrix<SCALAR_TYPE> &Davidson , 
			     class array<class vector_class<SCALAR_TYPE> > &V_tab , 
			     class array<class vector_class<SCALAR_TYPE> > &AV_tab , 
			     unsigned int &Davidson_dimension , 
			     double &test);

  template <typename SCALAR_TYPE>
  void iterative_diagonalization_largest_overlap (
						  const bool is_there_cout , 
						  const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
						  const class matrix<SCALAR_TYPE> &P_subspace , 
						  const unsigned int N_restarts , 
						  const double eigenvector_precision , 
						  const unsigned int max_dimension , 
						  const class matrix<SCALAR_TYPE> &A , 
						  SCALAR_TYPE &eigenvalue , 
						  class vector_class<SCALAR_TYPE> &eigenvector);

  template <typename SCALAR_TYPE>
  void iterative_diagonalization_largest_overlap (
						  const bool is_there_cout , 
						  const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
						  const class matrix<SCALAR_TYPE> &P_subspace , 
						  const unsigned int N_restarts , 
						  const double eigenvector_precision , 
						  const unsigned int max_dimension , 	
						  const class sparse_matrix<SCALAR_TYPE> &A , 
						  SCALAR_TYPE &eigenvalue , 
						  class vector_class<SCALAR_TYPE> &eigenvector);
}









// Calculation of the new Davidson vector via the inversion of (A_app - E)
// -----------------------------------------------------------------------
// One wants to calculate the new Davidson vector |V> = (A_app - E)^(-1) |Res> (up to orthogonalization and normalization),
// where |Res> is the residue A.|Psi> - E.|Psi>, with |Psi> the current value of the considered eigenvector of A, and A_app is an approximation of A quick to invert.
// The approximate A matrix, A_app, is equal to A in a small subspace of A, while the rest of A_app is just the diagonal of A and zeros for its off-diagonal matrix elements.
// (A_app - E) is then fast to invert.
//
//
// In the small subspace of A, one has |Res>_{subspace} = \sum_{i \in subspace} c(i)_{subspace} |Psi(i)>_{subspace},
// with |Psi(i)>_{subspace} the eigenvectors of A, of eigenvalue E(i)_{subspace}, so that |V>_{subspace} = \sum_{i \in subspace} c(i)_{subspace}/(E(i)_{subspace} - E) |Psi(i)>_{subspace}
//
// In the rest of the space, (A_app - E) is a diagonal matrix, readily inverted, which provides the rest of |V>.
//
// The |V> vector is then returned.
// 
// Variables
// ---------
// eigenvalue_subspace_tab: eigenvalues of A restricted to a small subspace
// P_subspace: matrix of the eigenvectors of A restricted to a small subspace
// A_diagonal_part: diagonal of A
// E: current eigenvalue of the considered eigenvector of A
// Res: residue equal to A.|Psi> - E.|Psi>, with |Psi> the current value of the considered eigenvector of A
// subspace_dimension: dimension of the considered small subspace
// dimension: dimension of A
// Res_subspace: Res restricted to the considered small subspace
// A_app_minus_E_inv_Res_subspace: |V> = (A_app - E)^(-1) |Res> restricted to the considered small subspace.
//                                 It is calculated as |V>_{subspace} = \sum_{i \in subspace} c(i)_{subspace}/(E(i)_{subspace} - E) |Psi(i)>_{subspace}
// eigenvector_subspace: i-th eigenvector of A restricted to the considered small subspace, which is |Psi(i)>_{subspace}
// Res_eigenvector_overlap: <Res | eigenvector_subspace>
// eigenvalue_subspace: eigenvalue of eigenvector_subspace in the considered small subspace, which is E(i)_{subspace}
// eigenvalue_difference:  E(i)_{subspace} - E
// factor: value of c(i)_{subspace}/(E(i)_{subspace} - E)
// A_app_minus_E_inv_Res: vector |V> solution of (A_app - E) |V> = |Res>; returned vector

template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> Davidson::A_app_minus_E_inverse_calc (
								      const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
								      const class matrix<SCALAR_TYPE> &P_subspace , 
								      const class array<SCALAR_TYPE> &A_diagonal_part , 
								      const SCALAR_TYPE &E , 
								      const class vector_class<SCALAR_TYPE> &Res)
{
  const unsigned int subspace_dimension = eigenvalue_subspace_tab.dimension (0);
  
  const unsigned int dimension = Res.get_dimension ();

  class vector_class<SCALAR_TYPE> Res_subspace(subspace_dimension);
  class vector_class<SCALAR_TYPE> A_app_minus_E_inv_Res_subspace(subspace_dimension);
  
  class vector_class<SCALAR_TYPE> A_app_minus_E_inv_Res(dimension);
  
  Res_subspace.assign (Res);
  A_app_minus_E_inv_Res_subspace = 0.0;

  for (unsigned int i = 0 ; i < subspace_dimension ; i++)
    {
      const class vector_class<SCALAR_TYPE> &eigenvector_subspace = P_subspace.row_vector (i); 

      const SCALAR_TYPE Res_eigenvector_overlap = Res_subspace*eigenvector_subspace;

      const SCALAR_TYPE eigenvalue_subspace = eigenvalue_subspace_tab(i);
      
      const SCALAR_TYPE eigenvalue_difference = eigenvalue_subspace - E;

      const SCALAR_TYPE factor = Res_eigenvector_overlap/eigenvalue_difference;

      A_app_minus_E_inv_Res_subspace += factor*eigenvector_subspace;
    }

  A_app_minus_E_inv_Res.assign (A_app_minus_E_inv_Res_subspace);

  for (unsigned int i = subspace_dimension ; i < dimension ; i++) A_app_minus_E_inv_Res(i) = Res(i)/(A_diagonal_part(i) - E);
  
  return A_app_minus_E_inv_Res;
}











// Calculation of the residue |Res> = A|Psi> - E|Psi>
// ----------------------------------------------------
// The A matrix is firstly exactly diagonalized in the basis of Davidson vectors, then providing with the sought eigenvector |Psi> and its eigenvalue E.
// |Psi> is identified with the overlap method, i.e. it is the eigenvector with the largest overlap with the pivot, the first Davidson vector.
// One has here the Davidson vectors |V(i)> and the A times Davidson vectors |AV(i)> = A|V(i)>.
// As |Psi> = \sum_{i} c_i |V(i)>, A|Psi> = \sum_{i} c_i |AV(i)>, so that |Res> = \sum_{i} c_i (|AV(i)> - E |V(i)>)
// The test to quantify the quality of |Psi> is |c_{Davidson_dimension - 1}|oo, as the components of Davidson basis vectors are supposed to decrease quickly.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// Davidson_dimension, Davidson_dimension_minus_one : current number of Davidson vectors, Davidson_dimension - 1
// Davidson : matrix containing the matrix A to diagonalize in the basis of Davidson vectors
// V_tab  : array of the previously calculated |V(i)> Davidson vectors
// AV_tab : array of the previously calculated A|V(i)> vectors
// Res: residue which will be equal to A.|Psi> - E.|Psi>
// E: will contain the current eigenvalue of the considered eigenvector |Psi> of A
// test : value testing if the calculated eigenvector with Davidson vectors is an eigenvector of the considered matrix
//        As |Psi> = \sum_{i = 0}^{Davidson dimension - 1} c_i |V(i)>, it is the maximal value of |c_{Davidson dimension - 1}|oo
// Davidson_small : same as Davidson, but its dimension is Davidson_dimension. This is necessary for the used diagonalization routine.
// E_tab_small: eigenvalues of the Davidson matrix
// i_max: index of the Davidson matrix eigenvector with the largest overlap with the first Davidson vector: it defines |Psi>.
// eigenvector_Davidson: Davidson matrix eigenvector of index i_max, i.e. |Psi> in the basis of Davidson vectors
// eigenvector_Davidson_last_Davidson_vector_overlap: component of the last Davidson basis vector of eigenvector_Davidson, i.e. |Psi> in the basis of Davidson vectors
// test : infinite norm of the component of the last Davidson basis vector of |Psi>
// component_i: component of the i-th |V(i)> Davidson vector, i.e. c_i in |Psi> = \sum_{i} c_i |V(i)>
// Vi : i-th Davidson vector |V(i)>
// AVi: i-th A times Davidson vector A|V(i)>
// Pivot_overlap: <V(0)|Psi> overlap
// 

template <typename SCALAR_TYPE>
void Davidson::eigenvalue_Res_test (
				    const bool is_there_cout , 
				    const unsigned int Davidson_dimension , 
				    const class matrix<SCALAR_TYPE> &Davidson , 
				    const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
				    const class array<class vector_class<SCALAR_TYPE> > &AV_tab , 
				    class vector_class<SCALAR_TYPE> &Res , 
				    SCALAR_TYPE &E , 
				    double &test)
{  
  class matrix<SCALAR_TYPE> Davidson_small(Davidson_dimension);

  Davidson_small.assign (Davidson);

  class array<SCALAR_TYPE> E_tab_small(Davidson_dimension);
  total_diagonalization::all_eigenpairs (Davidson_small , E_tab_small);

  const unsigned int Davidson_dimension_minus_one = Davidson_dimension - 1;
  
  const unsigned int i_max = maximal_overlap_eigenvector_index_determine (Davidson_small , 0);

  E = E_tab_small(i_max);  

  const class vector_class<SCALAR_TYPE> &eigenvector_Davidson = Davidson_small.eigenvector(i_max);
  
  const SCALAR_TYPE eigenvector_Davidson_last_Davidson_vector_overlap = eigenvector_Davidson(Davidson_dimension_minus_one);
  
  test = inf_norm (eigenvector_Davidson_last_Davidson_vector_overlap);

  Res = 0.0;

  for (unsigned int i = 0 ; i < Davidson_dimension ; i++) 
    {
      const SCALAR_TYPE component_i = eigenvector_Davidson(i);
      
      const class vector_class<SCALAR_TYPE> &Vi = V_tab(i);
      const class vector_class<SCALAR_TYPE> &AVi = AV_tab(i); 

      Res += component_i*(AVi - E*Vi);
    }

  const SCALAR_TYPE Pivot_overlap = eigenvector_Davidson(0);

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) 
    cout << "Iteration " << Davidson_dimension-1 << " E : " << E << " Pivot overlap : " << Pivot_overlap << " test:" << test << endl;
}









// Calculation of the eigenvector of the considered matrix from the calculated Davidson vectors
// --------------------------------------------------------------------------------------------
// One has here the matrix A to diagonalize in the basis of Davidson vectors.
// One will then calculate the sought eigenvector |Psi> and its eigenvalue by exact diagonalization. As the Davidson matrix is small, it is very fast.
// |Psi> is identified with the overlap method, i.e. it is the eigenvector with the largest overlap with the pivot, the first Davidson vector.
// Its phase is fixed with good_phase (see array_vector_class.hpp).
//
// Variables
// ---------
// Davidson_dimension : current number of Davidson vectors
// Davidson: matrix A to diagonalize in the basis of Davidson vectors.
// V_tab : array of the previously calculated |V(i)> Davidson vectors
// eigenvalue : will contain the eigenvalue of the sought eigenvector |Psi> of the matrix A to diagonalize
// eigenvector : will contain the eigenvector of the matrix A to diagonalize
// Davidson_small : same as the Davidson matrix, but its dimension is Davidson_dimension. This is necessary for the used diagonalization routine.
// eigenvalue_tab_small : eigenvalues of Davidson_small
// i_max: index of the Davidson matrix eigenvector with the largest overlap with the first Davidson vector: it defines |Psi>.
// eigenvector_Davidson: Davidson matrix eigenvector of index i_max, i.e. |Psi> in the basis of Davidson vectors
// Vi : i-th Davidson vector |V(i)>

template <typename SCALAR_TYPE>
void Davidson::eigenpair_calc (
			       const unsigned int Davidson_dimension , 
			       const class matrix<SCALAR_TYPE> &Davidson , 
			       const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
			       SCALAR_TYPE &eigenvalue , 
			       class vector_class<SCALAR_TYPE> &eigenvector)
{
  class matrix<SCALAR_TYPE> Davidson_small(Davidson_dimension);

  Davidson_small.assign (Davidson);

  class array<SCALAR_TYPE> eigenvalue_tab_small(Davidson_dimension);

  total_diagonalization::all_eigenpairs (Davidson_small , eigenvalue_tab_small);

  const unsigned int i_max = maximal_overlap_eigenvector_index_determine (Davidson_small , 0);

  eigenvalue = eigenvalue_tab_small(i_max);

  const class vector_class<SCALAR_TYPE> &eigenvector_Davidson = Davidson_small.eigenvector(i_max);

  eigenvector = 0.0;

  for (unsigned int i = 0 ; i < Davidson_dimension ; i++) 
    {
      class vector_class<SCALAR_TYPE> &Vi = V_tab(i);

      eigenvector += eigenvector_Davidson(i)*Vi;
    } 

  eigenvector.good_phase ();
}















// Diagonalization of the matrix to diagonalize via the Davidson method
// -------------------------------------------------------------------
// The matrix A hereby diagonalized with the Davidson method.
// One starts with a pivot for the |V(0)> Davidson vector, which is also allocated if needed.
// One calculates and stores A|V(0)> and the diagonal matrix element <V(0) | A | V(0)>.
// One calculates the residue A.|V(0)> - E.|V(0)>, with E = <V(0) | A | V(0)> here.
// If is it smaller than the numerical precision, |V(0)> is the eigenvector |Psi> and E is its eigenvalue, so that one stops here.
// sqrt_precision is added to E to avoid having a non-invertible A_app matrix (see A_app_minus_E_inverse_calc).  
// Afterwards, one loops over all the available Davidson vectors.
//
// In this loop : 
// 
// One uses the standard formula : 
//
// |V(i)> = (A_app - E)^(-1) |Res>, where |Res> = A.|Psi> - E.|Psi>, with |Psi> the current value of the considered eigenvector of A, and A_app is an approximation of A quick to invert (see A_app_minus_E_inverse_calc).
//
// |V(i)> is then orthogonalized with respect to the previous |V(j)>_{j < i} Davidson vectors with the modified Gram-Schmidt method, and then normalized.
//
// One then calculates and stores <V(i) | A | V(j)> for j <= i.
//
// The A matrix in the basis of Davidson vectors is then diagonalized.
// |Psi> is identified with the overlap method, i.e. it is the eigenvector with the largest overlap with the pivot, the first Davidson vector.
// One then checks if its eigenvector |Psi> has converged.
// If it is converged or if one has arrived to the last available Davidson vector, one leaves the loop.
// Davidson_dimension is put to 1 if it is still zero here, as we have at least one Davidson vector at this point.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// is_it_sparse : true if one uses a sparse matrix for A, false if not
// eigenvalue_subspace_tab: will contain the eigenvalues of A restricted to a small subspace
// P_subspace: will contain the matrix of eigenvectors of A restricted to a small subspace
// pivot: first Davidson vector, supposed to have a large overlap with exact eigenvector |Psi>
// eigenvector_precision : demanded precision for the eigenvectors of A calculated with the Davidson method
// A : matrix to diagonalize (full matrix case)
// As : matrix to diagonalize (sparse matrix case)
// A_diagonal_part : diagonal part of A. It is used to apply (A_app - E)^(-1) (see A_app_minus_E_inverse_calc).
// Davidson : matrix which will contain the matrix A to diagonalize in the basis of Davidson vectors
// V_tab : array which will contain the |V(i)> Davidson vectors to calculate
// AV_tab : array which will contain the A.|V(i)> vectors
// Davidson_dimension : number of Davidson vectors which will be calculated
// test : infinite norm of the component of the last Davidson basis vector of the sought eigenvector |Psi>
// dimension : dimension of the A matrix to diagonalize
// max_dimension : maximal number of Davidson vectors, and hence maximal dimension of the Davidson matrix
// V0, AV0 : first Davidson vector |V(0)>, A.|V(0)>
// E: eigenvalue of |Psi>
// Res: residue A.|Psi> - E.|Psi>
// Vi, AVi : i-th Davidson vector |V(i)>, A.|V(i)>
// overlap: <V(i)|V(ii)>, with |V(i)> orthogonalized with respect to the Davidson vectors of indices smaller than ii at this point
// Vii: previously calculated ii-th Davidson vector with 0 <= ii < i.
//      It is used to orthogonalize |V(i)> with respect to the previous Davidson vectors (first declaration) and to calculate  <V(i) | A | V(ii)> for ii <= i (second declaration).

template <typename SCALAR_TYPE>
void Davidson::Davidson_matrix_calc (
				     const bool is_there_cout , 
				     const bool is_it_sparse ,
				     const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
				     const class matrix<SCALAR_TYPE> &P_subspace , 
				     const class vector_class<SCALAR_TYPE> &pivot , 
				     const double eigenvector_precision , 
				     const class matrix<SCALAR_TYPE> &A , 
				     const class sparse_matrix<SCALAR_TYPE> &As , 
				     const class array<SCALAR_TYPE> &A_diagonal_part , 
				     class matrix<SCALAR_TYPE> &Davidson , 
				     class array<class vector_class<SCALAR_TYPE> > &V_tab , 
				     class array<class vector_class<SCALAR_TYPE> > &AV_tab , 
				     unsigned int &Davidson_dimension , 
				     double &test)
{
  const unsigned int dimension = (is_it_sparse) ? (As.get_dimension ()) : (A.get_dimension ());
  const unsigned int max_dimension = Davidson.get_dimension ();

  class vector_class<SCALAR_TYPE> &V0 = V_tab(0) , &AV0 = AV_tab(0);
  
  if (!V0.is_it_filled ()) V0.allocate (dimension);
  if (!AV0.is_it_filled ()) AV0.allocate (dimension);

  V0 = pivot;
  AV0 = (is_it_sparse) ? (As*V0) : (A*V0);

  Davidson(0 , 0) = (V0*AV0);
  
  SCALAR_TYPE E = Davidson(0 , 0);

  class vector_class<SCALAR_TYPE> Res = AV0 - E*V0;

  const double Res_norm = Res.infinite_norm ();

  if (Res_norm < precision)
    {
      Davidson_dimension = 1;
      
      return;
    }

  E += sqrt_precision;

  for (unsigned int i = 1 ; ((i < max_dimension) && (test > eigenvector_precision)) ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = V_tab(i) , &AVi = AV_tab(i);
      
      if (!Vi.is_it_filled ()) Vi.allocate (dimension);
      if (!AVi.is_it_filled ()) AVi.allocate (dimension);

      Vi = A_app_minus_E_inverse_calc (eigenvalue_subspace_tab , P_subspace , A_diagonal_part , E , Res);
            
      for (unsigned int ii = 0 ; ii < i ; ii++)
	{
	  const class vector_class<SCALAR_TYPE> &Vii = V_tab(ii);
	  
	  const SCALAR_TYPE overlap = (Vi*Vii);
	  
	  Vi -= overlap*Vii;
	}

      Vi.normalization ();
      
      AVi = (is_it_sparse) ? (As*Vi) : (A*Vi);

      Davidson_dimension = i+1;

      for (unsigned int ii = 0 ; ii < Davidson_dimension ; ii++) 
	{
	  const class vector_class<SCALAR_TYPE> &Vii = V_tab(ii);
	  
	  Davidson(i , ii) = Davidson(ii , i) = (Vii*AVi);
	}

      eigenvalue_Res_test (is_there_cout , Davidson_dimension , Davidson , V_tab , AV_tab , Res , E , test);
    }

  if (Davidson_dimension == 0) Davidson_dimension = 1;
}







// Matrix diagonalization using the Davidson method
// -----------------------------------------------
// The first following routine is for a full A matrix and the second following routine for a sparse A matrix. They are the same otherwise.
// One loops over the number of demanded starts and a Davidson process is launched each time to calculate the demanded eigenvectors of A (see tridiagonalization and lowest_eigenvectors_calc routines).
// For the first start, one uses a random pivot, and the previously calculated eigenvector is used for restarts.  
// One leaves the loop if one has reached convergence or if all restarts have been made.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// eigenvalue_subspace_tab: eigenvalues of A restricted to a small subspace
// P_subspace: matrix of the eigenvectors of A restricted to a small subspace
// N_restarts, N_restarts_plus_one: number of restarted calculations, N_restarts + 1
// eigenvector_precision : demanded precision for the eigenvectors of A calculated with the Davidson method
// max_dimension : maximal number of Davidson vectors, and hence maximal dimension of the Davidson matrix
// A: matrix to diagonalize (full in the first following routine, sparse in the second following routine)
// E: will contain the current eigenvalue of the considered eigenvector |Psi> of A
// eigenvector : will contain the eigenvector of the matrix A to diagonalize 
// dimension : dimension of the A matrix to diagonalize
// dummy_matrix: dummy variable for a matrix
// A_diagonal_part: diagonal of A
// Davidson : matrix which will contain the matrix A to diagonalize in the basis of Davidson vectors
// Davidson_dimension : current number of Davidson vectors
// V_tab : array which will contain the |V(i)> Davidson vectors to calculate
// AV_tab : array which will contain the A.|V(i)> vectors
// Davidson_dimension : number of Davidson vectors which will be calculated


template <typename SCALAR_TYPE>
void Davidson::iterative_diagonalization_largest_overlap (
							  const bool is_there_cout , 
							  const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
							  const class matrix<SCALAR_TYPE> &P_subspace , 
							  const unsigned int N_restarts , 
							  const double eigenvector_precision , 
							  const unsigned int max_dimension , 
							  const class matrix<SCALAR_TYPE> &A , 
							  SCALAR_TYPE &E , 
							  class vector_class<SCALAR_TYPE> &eigenvector)
{	
  const class sparse_matrix<SCALAR_TYPE> dummy_matrix;

  const unsigned int N = A.get_dimension ();

  class array<SCALAR_TYPE> A_diagonal_part(N);

  A.diagonal_part (A_diagonal_part);

  double test = INFINITE;

  class matrix<SCALAR_TYPE> Davidson(max_dimension);
  
  class array<class vector_class<SCALAR_TYPE> > V_tab(max_dimension) , AV_tab(max_dimension);

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) cout << "Pivot eigenvalue : " << E << " Pivot overlap : 1" << endl << endl;

  for (unsigned int r = 0 ; ((r < N_restarts+1) && (test > eigenvector_precision)) ; r++)
    {
      unsigned int Davidson_dimension = 0;

      Davidson = 0.0;

      Davidson_matrix_calc (is_there_cout , false , eigenvalue_subspace_tab , P_subspace , eigenvector , eigenvector_precision , A , dummy_matrix , A_diagonal_part , Davidson , V_tab , AV_tab , Davidson_dimension , test);
      
      eigenpair_calc (Davidson_dimension , Davidson , V_tab , E , eigenvector);
    }
}





template <typename SCALAR_TYPE>
void Davidson::iterative_diagonalization_largest_overlap (
							  const bool is_there_cout , 
							  const class array<SCALAR_TYPE> &eigenvalue_subspace_tab , 
							  const class matrix<SCALAR_TYPE> &P_subspace , 
							  const unsigned int N_restarts , 
							  const double eigenvector_precision , 
							  const unsigned int max_dimension , 
							  const class sparse_matrix<SCALAR_TYPE> &A , 
							  SCALAR_TYPE &E , 
							  class vector_class<SCALAR_TYPE> &eigenvector)
{
  const class matrix<SCALAR_TYPE> dummy_matrix;

  const unsigned int N = A.get_dimension ();

  class array<SCALAR_TYPE> A_diagonal_part(N);

  A.diagonal_part (A_diagonal_part);

  double test = INFINITE;

  class matrix<SCALAR_TYPE> Davidson(max_dimension);
  
  class array<class vector_class<SCALAR_TYPE> > V_tab(max_dimension) , AV_tab(max_dimension);

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) cout << "Pivot eigenvalue : " << E << " Pivot overlap : 1" << endl << endl;

  for (unsigned int r = 0 ; ((r < N_restarts+1) && (test > eigenvector_precision)) ; r++)
    {
      unsigned int Davidson_dimension = 0;

      Davidson = 0.0;

      Davidson_matrix_calc (is_there_cout , true , eigenvalue_subspace_tab , P_subspace , eigenvector , eigenvector_precision , dummy_matrix , A , A_diagonal_part , Davidson , V_tab , AV_tab , Davidson_dimension , test);

      eigenpair_calc (Davidson_dimension , Davidson , V_tab , E , eigenvector);
    }
}




#endif
