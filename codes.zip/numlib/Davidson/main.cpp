#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

void diagonalization_full_matrix_test (
				       const bool is_there_cout , 
				       const double eigenvector_precision , 
				       const unsigned int N_restarts , 
				       const unsigned int N_subspace , 
				       const unsigned int N , 
				       const double max_dimension , 
				       const unsigned int eigenvector_index)
{
  class matrix<complex<double> > M(N);

  M.random_matrix ();
  
  M *= complex<double> (1 , 0.1);

  for (unsigned int i = 0 ; i < N ; i++) M(i , i) += complex<double> (i%100+1 , 1) + random_number<double> ();

  M /= M.infinite_norm ();

  M.symmetrize ();

  class array<complex<double> > eigenvalue_subspace_tab(N_subspace);

  class matrix<complex<double> > P_subspace(N_subspace);

  P_subspace.assign (M);

  total_diagonalization::all_eigenpairs (P_subspace , eigenvalue_subspace_tab);

  const complex<double> &eigenvalue_start = eigenvalue_subspace_tab(eigenvector_index);

  const vector_class<complex<double> > &eigenvector_start_subspace = (P_subspace.eigenvector(eigenvector_index));

  class vector_class<complex<double> > eigenvector_start(N);

  eigenvector_start.assign (eigenvector_start_subspace);

  complex<double> eigenvalue = eigenvalue_start;

  class vector_class<complex<double> > eigenvector = eigenvector_start;

  Davidson::iterative_diagonalization_largest_overlap (is_there_cout , eigenvalue_subspace_tab , P_subspace , N_restarts , eigenvector_precision , max_dimension , M , eigenvalue , eigenvector);

  const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

  cout << endl << "starting eigenvalue:" << eigenvalue_start << " eigenvalue:" << eigenvalue << " |<V|Vstart>|oo:" << inf_norm (eigenvector*eigenvector_start) << " |A.V - E.V|oo:" << Res.infinite_norm () << endl;
}





void diagonalization_sparse_matrix_test (
					 const bool is_there_cout , 
					 const double eigenvector_precision , 
					 const unsigned int N_restarts , 
					 const unsigned int N_subspace , 
					 const unsigned int N , 
					 const double zero_probability ,
					 const double max_dimension , 
					 const unsigned int eigenvector_index)
{
  class matrix<complex<double> > M_full(N);
  
  M_full.symmetric_random_matrix ();
  
  M_full.put_zeros_symmetrically_with_probability (zero_probability);
    
  for (unsigned int i = 0 ; i < N ; i++) M_full(i , i) += complex<double> (i + 1 , 1) + random_number<double> ();
  
  class sparse_matrix<complex<double> > M = M_full;
    
  M *= complex<double> (1 , 0.1);

  M /= M.infinite_norm ();

  class array<complex<double> > eigenvalue_subspace_tab(N_subspace);
  
  class matrix<complex<double> > P_subspace(N_subspace);

  P_subspace.assign (M);

  total_diagonalization::all_eigenpairs (P_subspace , eigenvalue_subspace_tab);

  const complex<double> &eigenvalue_start = eigenvalue_subspace_tab(eigenvector_index);

  const vector_class<complex<double> > &eigenvector_start_subspace = (P_subspace.eigenvector(eigenvector_index));

  class vector_class<complex<double> > eigenvector_start(N);

  eigenvector_start.assign (eigenvector_start_subspace);

  complex<double> eigenvalue = eigenvalue_start;

  class vector_class<complex<double> > eigenvector = eigenvector_start;

  Davidson::iterative_diagonalization_largest_overlap (is_there_cout , eigenvalue_subspace_tab , P_subspace , N_restarts , eigenvector_precision , max_dimension , M , eigenvalue , eigenvector);

  const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

  cout << endl << "starting eigenvalue:" << eigenvalue_start << " eigenvalue:" << eigenvalue << " |<V|Vstart>|oo:" << inf_norm (eigenvector*eigenvector_start) << " |A.V - E.V|oo:" << Res.infinite_norm () << endl;
}






#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const unsigned int N_restarts = 5;
    const unsigned int N = 200;
    const unsigned int N_subspace = 10;
    const unsigned int eigenvector_index = 3;

    const double vector_precision = 1E-7;
    const double max_dimension = 50;
    const double zero_probability = 0.01;

    cout.precision (15);
    seed ();
    
    cout << endl << "is_there_cout = true" << endl;

    cout << endl << "diagonalization full matrix test" << endl;

    diagonalization_full_matrix_test (true , vector_precision , N_restarts , N_subspace , N , max_dimension , eigenvector_index);

    cout << endl << "diagonalization sparse matrix test" << endl;

    diagonalization_sparse_matrix_test (true , vector_precision , N_restarts , N_subspace , N , zero_probability , max_dimension , eigenvector_index);	

    cout << endl << "is_there_cout = false" << endl;

    cout << endl << "diagonalization full matrix test" << endl;

    diagonalization_full_matrix_test (false , vector_precision , N_restarts , N_subspace , N , max_dimension , eigenvector_index);

    cout << endl << "diagonalization sparse matrix test" << endl;

    diagonalization_sparse_matrix_test (false , vector_precision , N_restarts , N_subspace , N , zero_probability , max_dimension , eigenvector_index);	
   
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
