#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  MPI_parallelization_linear_algebra_enabled ();

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
  
    //OpenMP_parallelization_linear_algebra_enabled ();

    seed ();

    const complex<double> a(4.7 , 3.8) , b(7.8 , -3.9) , c(2.4 , -1.2);

    const unsigned int blocks_number = 3;
    
    class array<unsigned int> block_dimensions(blocks_number);

    for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + 1;
    
    const unsigned int N = block_dimensions.sum ();

    class block_matrix<complex<double> > M(block_dimensions);
    
    M.random_matrix ();

    M *= complex<double> (4 , 6);

    block_matrix<complex<double> > A = b*M , B = A;

    if (!(A == B)) error_message_print_abort ("Problem in class block_matrix with ==");

    if (A != B) error_message_print_abort ("Problem in class block_matrix with !");

    if (A.is_it_real ()) error_message_print_abort ("Problem in class block_matrix with is_it_real");
    
    A += a*M;
    A -= a*M;

    A *= b;
    A /= b;

    A -= b*M;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , += , -= , *= or /=");

    A = b*M;

    A = -A;

    A = A + a*M;
    A = A - a*M;

    A = A*b;
    A = A/b;

    A = A + b*M;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - , * or /");

    class block_sparse_matrix<complex<double> > A_sp = A , B_sp = A , M_sp = M;
    
    A += a*M_sp;
    A -= a*M_sp;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , += , -= (block_matrix, block_sparse_matrix");

    A = +M_sp;

    if ((A - M_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - (block_matrix, block_sparse_matrix) (1)");

    A = -M_sp;

    if ((A + M_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - (block_matrix, block_sparse_matrix) (2)");

    A.identity ();

    A = A + a*M_sp;
    A = A - a*M_sp;

    if ((A - identity<complex<double> > (block_dimensions)).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - (block_matrix, block_sparse_matrix) (3)");

    B = A_sp + a*M;

    A = B - a*M;

    if ((A - A_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - (block_matrix, block_sparse_matrix) (4)");

    B = A_sp - a*M;

    A = B + a*M;

    if ((A - A_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , + , - (block_matrix, block_sparse_matrix) (5)");

    A.zero ();

    unsigned int d = 0;
        
    for(unsigned int matrix_index = 0 ; matrix_index < blocks_number ; matrix_index++)
      {
	const unsigned int d_matrix_index = (block_dimensions(matrix_index)*(block_dimensions(matrix_index) - 1))/2.0;

	d += d_matrix_index;
	
	unsigned int k = 0;
    
	for (unsigned int i = 0 ; i < block_dimensions(matrix_index) ; i++) 
	  for (unsigned int j = 0 ; j < block_dimensions(matrix_index) ; j++) 
	    if (k++ < d_matrix_index) 
	      A(matrix_index)(i , j) = a;
      }
    
    if (A.non_zeros_number_calc () != d) error_message_print_abort ("Problem in class block_matrix with non_zeros_number_calc");

    if (inf_norm (A.non_zeros_proportion () - 100.0*d/static_cast<double> (N*N)) > 1E-13) error_message_print_abort ("Problem in class block_matrix with non_zeros_number_proportion");

    A.identity ();

    if (!A.is_it_diagonal ()) error_message_print_abort ("Problem in class block_matrix with is_it_diagonal"); 

    A -= identity<complex<double> > (block_dimensions);

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with identity");

    A.scalar (a);

    A -= scalar<complex<double> > (block_dimensions , a);

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with scalar");

    A = M + B;

    A *= b;
    A /= b;

    A = A - M - B;

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with = , += , -= , *= or /=");

    B = -A;

    M = B + A;

    if (M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with unary -");

    M.random_matrix ();

    M.symmetrize ();

    if (!M.is_it_symmetric ()) error_message_print_abort ("Problem in class block_matrix with is_it_symmetric"); 

    M.random_matrix ();    

    M.hermitize ();

    if (!M.is_it_hermitian ()) error_message_print_abort ("Problem in class block_matrix with is_it_hermitian"); 

    M.symmetric_random_matrix ();

    if (!M.is_it_symmetric ()) error_message_print_abort ("Problem in class block_matrix with is_it_symmetric"); 

    M.hermitian_random_matrix ();

    if (!M.is_it_hermitian ()) error_message_print_abort ("Problem in class block_matrix with is_it_hermitian");
    
    M.antisymmetrize ();

    if (!M.is_it_antisymmetric ()) error_message_print_abort ("Problem in class block_matrix with is_it_antisymmetric"); 

    M.antisymmetric_random_matrix ();

    if (!M.is_it_antisymmetric ()) error_message_print_abort ("Problem in class block_matrix with is_it_antisymmetric"); 

    M *= a;

    A = M;

    A.transpose ();

    B = transpose (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in transpose");

    M.random_matrix ();

    M *= a;

    A = M;

    A.conjugate ();

    B = conj (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with conjugate"); 

    M.random_matrix ();

    M *= a;

    A = M;

    A.dagger ();

    B = dagger (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with dagger"); 

    class block_matrix<double> Re_M(block_dimensions);
    class block_matrix<double> Im_M(block_dimensions);

    Re_M = real<double , complex<double> > (M);
    Im_M = imag<double , complex<double> > (M);

    class block_matrix<complex<double> > M_test = complex_matrix<double , complex<double> > (Re_M , Im_M);

    A = M - M_test;	

    if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with real , imag or complex_matrix");

    if (!Re_M.is_it_real ()) error_message_print_abort ("Problem in class block_matrix with is_it_real");

    class block_matrix<unsigned int> C(block_dimensions);

    C.identity ();

    Re_M = convert<unsigned int , double> (C);

    Re_M -= identity<double> (block_dimensions);

    if (Re_M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with convert"); 

    unsigned int T = C.trace ();

    if (T != N) error_message_print_abort ("Problem in class block_matrix with trace"); 

    class vector_class<complex<double> > V(N);

    V.random_vector ();

    M.random_matrix ();

    A = M;
    B = M;
    
    complex<double> exact_determinant = 1.0;
    
    for(unsigned int i = 0 ; i < blocks_number ; i++) exact_determinant *= A(i).determinant ();

    if (inf_norm (M.determinant ()/exact_determinant - 1.0) > 1E-13) error_message_print_abort ("Problem in class block_matrix with determinant (LU)"); 

    M = B;
    
    complex<double> log_Det_no_phase = 0.0;  

    int phase = 1;

    M.log_scaled_determinant_and_phase (log_Det_no_phase , phase);    

    if (inf_norm (phase*exp (log_Det_no_phase)/exact_determinant - 1.0) > 1E-13) error_message_print_abort ("Problem in class block_matrix with log_scaled_determinant_and_phase (LU)"); 
    
    M.random_matrix ();

    M *= complex<double> (1 , -0.2);
    
    A = M;

    M.inverse ();

    B = inverse (A) - M;

    if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with inverse (external) or inverse (member class)");
    
    B = A*M; 

    A.identity ();

    B -= A;

    if (B.infinite_norm ()/N > 1E-13) error_message_print_abort ("Problem in class block_matrix with inverse (member class)"); 
    
    class array<unsigned int> block_dimensions_row(blocks_number);
    class array<unsigned int> block_dimensions_column(blocks_number);
    
    class array<unsigned int> non_trivial_zeros_numbers_r(blocks_number);
    class array<unsigned int> non_trivial_zeros_numbers_c(blocks_number);

    for(unsigned int i = 0 ; i < blocks_number ; i++)
      {
	block_dimensions_row(i) = i + 2;
	block_dimensions_column(i) = i + 3;

	non_trivial_zeros_numbers_r(i) = (block_dimensions_row(i)*block_dimensions(i))/2;
	non_trivial_zeros_numbers_c(i) = (block_dimensions(i)*block_dimensions_column(i))/2;
      }
    
    const unsigned int Nr = block_dimensions_row.sum ();
    const unsigned int Nc = block_dimensions_column.sum ();
    
    class block_matrix<complex<double> > Ar(block_dimensions_row , block_dimensions);
    class block_matrix<complex<double> > Br(block_dimensions     , block_dimensions_column);
    class block_matrix<complex<double> > Cr(block_dimensions_row , block_dimensions_column);

    class matrix<complex<double> > Cr_check(Nr , Nc);

    Ar.random_matrix ();
    Br.random_matrix ();

    Cr = Ar*Br;

    Cr_check = 0.0;

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	for (unsigned int k = 0 ; k < N ; k++)
	  Cr_check(i , j) += Ar.matrix_element_determine(i , k)*Br.matrix_element_determine(k , j);

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine (i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with operator * (A*B)");

    Cr.random_matrix ();

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) = Cr.matrix_element_determine(i , j);
    
    const unsigned int row_vector_index = Cr.get_dimension_row ()/2;
    
    Cr.multiply_scalar_row_vector (row_vector_index , M_PI);
    
    Cr_check.row_vector (row_vector_index) *= M_PI;
    
    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine(i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with multiply_scalar_row_vector"); 
    
    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) = Cr.matrix_element_determine(i , j);
        
    Cr.divide_scalar_row_vector (row_vector_index , M_PI);
    
    Cr_check.row_vector (row_vector_index) /= M_PI;

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine(i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with multiply_scalar_row_vector"); 
    
    Ar.put_zeros_with_probability (0.5);
    Br.put_zeros_with_probability (0.5);
    
    class block_sparse_matrix<complex<double> > Ar_sp = Ar;
    class block_sparse_matrix<complex<double> > Br_sp = Br;
        
    Cr = Ar_sp*Br;

    Cr_check = 0.0;

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	for (unsigned int k = 0 ; k < N ; k++)
	  Cr_check(i , j) += Ar_sp.matrix_element_determine(i , k)*Br.matrix_element_determine(k , j);

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine (i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with operator * (A[sparse]*B)");

    Cr = Ar*Br_sp;

    Cr_check = 0.0;

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	for (unsigned int k = 0 ; k < N ; k++)
	  Cr_check(i , j) +=  Ar.matrix_element_determine(i , k)*Br_sp.matrix_element_determine(k , j);

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine (i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with operator * (A*B[sparse])");

    Cr = Ar_sp*Br_sp;

    Cr_check = 0.0;

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	for (unsigned int k = 0 ; k < N ; k++)
	  Cr_check(i , j) +=  Ar_sp.matrix_element_determine(i , k)*Br_sp.matrix_element_determine(k , j);

    for (unsigned int i = 0 ; i < Nr ; i++)
      for (unsigned int j = 0 ; j < Nc ; j++)
	Cr_check(i , j) -= Cr.matrix_element_determine (i , j);
    
    if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class block_matrix with operator * (A[sparse]*B[sparse])");

    class array<complex<double> > A_diagonal_init(N);
    
    A.diagonal_part (A_diagonal_init);

    A.add_scalar_diagonal_part (a);
    
    A.remove_scalar_diagonal_part (a);

    for (unsigned int i = 0 ; i < N ; i++)
      if (inf_norm (A.matrix_element_determine (i , i) - A_diagonal_init(i)) > 1E-13)
	error_message_print_abort ("Problem in class block_matrix with add/remove_scalar_diagonal_part"); 
    
    A.multiply_scalar_diagonal_part (a);
    
    A.divide_scalar_diagonal_part (a);
    
    for (unsigned int i = 0 ; i < N ; i++)
      if (inf_norm (A.matrix_element_determine (i , i) - A_diagonal_init(i)) > 1E-13)
	error_message_print_abort ("Problem in class block_matrix with multiply/divide_scalar_diagonal_part");
    
    A.put_scalar_diagonal_part (a);
    
    for (unsigned int i = 0 ; i < N ; i++)
      if (inf_norm (A.matrix_element_determine (i , i) - a) > 1E-13)
	error_message_print_abort ("Problem in class block_matrix with put_scalar_diagonal_part");
    
    A.identity ();

    if (maximal_overlap_eigenvector_index_determine (A , N/2) != N/2) error_message_print_abort ("Problem with maximal_overlap_eigenvector_index_determine (block matrices)");
        
    complex<double> AB_scalar_product_1 = 0.0;
    complex<double> AB_scalar_product_2 = 0.0;
  
    complex<double> M_norm_1 = 0.0;
    complex<double> M_norm_2 = 0.0;
    
    A.random_matrix ();
    B.random_matrix ();    
  
    A.put_zeros_with_probability (0.5);
    B.put_zeros_with_probability (0.5);

    A_sp.deallocate ();
    B_sp.deallocate ();
      
    A_sp.allocate_fill (A);
    B_sp.allocate_fill (B);

    M = A*transpose (B);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product (A , B);
  
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product (full , full)");
    
    M = A_sp*transpose (B);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product (A_sp , B);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product (sparse , full)");

    M = A*transpose (B_sp);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product (A , B_sp);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product (full , sparse)");

    M = A_sp*transpose (B_sp);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product (A_sp , B_sp);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product (sparse , sparse)");

    M = A*dagger (B);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A , B);
  
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product_hermitian (full , full)");
    
    M = A_sp*dagger (B);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A_sp , B);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product_hermitian (sparse , full)");

    M = A*dagger (B_sp);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A , B_sp);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product_hermitian (full , sparse)");

    M = A_sp*dagger (B_sp);

    AB_scalar_product_1 = M.trace ();

    AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A_sp , B_sp);
    
    if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_scalar_product_hermitian (sparse , sparse)");

    M_norm_1 = sqrt (Frobenius_scalar_product (M , M));

    M_norm_2 = M.Frobenius_norm ();
  
    if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_norm (full)");
    
    M_norm_1 = sqrt (Frobenius_scalar_product_hermitian (M , M));

    M_norm_2 = M.Frobenius_norm_hermitian ();
    
    if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_norm_hermitian (full)");

    M_sp.deallocate ();

    M_sp.allocate_fill (M);
  
    M_norm_1 = sqrt (Frobenius_scalar_product (M_sp , M_sp));

    M_norm_2 = M_sp.Frobenius_norm ();
  
    if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_norm (sparse)");
    
    M_norm_1 = sqrt (Frobenius_scalar_product_hermitian (M_sp , M_sp));

    M_norm_2 = M_sp.Frobenius_norm_hermitian ();
    
    if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class block_matrix with Frobenius_norm_hermitian (sparse)");
    
    const complex<double> A_sum = A.sum ();
  
    complex<double> A_sum_try = 0.0;
  
    for (unsigned int i = 0 ; i < N ; i++)
      for (unsigned int j = 0 ; j < N ; j++)
	A_sum_try += A_sp.matrix_element_determine (i , j);

    if (inf_norm (A_sum - A_sum_try ) > precision) error_message_print_abort ("Problem in class block_matrix with sum");

    class block_matrix<double> Y(block_dimensions);
  
    Y.random_matrix ();

    const double Y_min = Y.min ();
    const double Y_max = Y.max ();

    for (unsigned int i = 0 ; i < N ; i++)
      for (unsigned int j = 0 ; j < N ; j++)
	{
	  if (Y.matrix_element_determine (i,j) < Y_min) error_message_print_abort ("Problem in class block_matrix with min (member class)");
	  if (Y.matrix_element_determine (i,j) > Y_max) error_message_print_abort ("Problem in class block_matrix with max (member class)");
	}

    if (THIS_PROCESS == MASTER_PROCESS) cout << "All block matrix class tests are correct." << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

  
