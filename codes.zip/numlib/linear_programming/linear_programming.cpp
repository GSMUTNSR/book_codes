#include "../../numlib/numlib_def/numlib_def.h"

void linear_programming::diagonal_preconditioning (			 
						   const class matrix<double> &A_diagonal ,	 
						   class matrix<double> &X)
{
  const unsigned int N = A_diagonal.get_dimension ();
  
  for (unsigned int i = 0 ; i < N ; i++)
    for (unsigned int j = 0 ; j < N ; j++)
      if (A_diagonal(i , j) != 0.0) X(i , j) /= A_diagonal(i , j);
}


void linear_programming::A_Gamma_calc (
				       const class array<class matrix<double> > &A_conditions ,
				       const class matrix<double> &A_Gamma_zero ,
				       const class matrix<double> &Gamma ,
				       class matrix<double> &A_Gamma)
{
  const unsigned int N_conditions = A_conditions.dimension (0);

  A_Gamma = A_Gamma_zero;
  
  for (unsigned int i = 0 ; i < N_conditions ; i++)
    for (unsigned int j = 0 ; j < N_conditions ; j++)
      {      
	const class matrix<double> &A_condition_ij = A_conditions(i , j);
	
	A_Gamma(i , j) += Frobenius_scalar_product (A_condition_ij , Gamma);
      }
}


void linear_programming::A_Gamma_gradients_alloc_calc (
						       const class array<class matrix<double> > &A_conditions ,
						       class array<class matrix<double> > &A_Gamma_gradients)
{   
  const unsigned int N_conditions = A_conditions.dimension (0);
  
  const unsigned int N = A_Gamma_gradients.dimension (0);

  class matrix<double> Gamma(N);
  
  class matrix<double> A_Gamma_gradients_ij(N_conditions);
  
  class matrix<double> A_Gamma_zero(N_conditions);
  
  A_Gamma_zero = 0.0;
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      Gamma = 0.0;
	
      Gamma(i , i) = 1.0;
	
      A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma_gradients_ij);
  
      A_Gamma_gradients(i , i).allocate_fill (A_Gamma_gradients_ij);
    }
  
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i < j ; i++)
      {
	Gamma = 0.0;
	
	Gamma(i , j) = Gamma(j , i) = 1.0;
	
	A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma_gradients_ij);

	A_Gamma_gradients(i , j).allocate_fill (A_Gamma_gradients_ij);
      }
}








double linear_programming::log_barrier::F_calc (
						const double t ,
						const class matrix<double> &H ,
						const class matrix<double> &Gamma ,
						const class matrix<double> &A_Gamma)
{
  const double F0 = Frobenius_scalar_product (H , Gamma);
  
  class matrix<double> A_Gamma_copy = A_Gamma;

  double log_Det_A_Gamma;
  
  int dummy_phase;

  A_Gamma_copy.log_scaled_determinant_and_phase (log_Det_A_Gamma , dummy_phase);
  
  const double F = F0 - t*log_Det_A_Gamma;
  
  return F;
}




void linear_programming::log_barrier::F_der_calc (
						  const double t ,
						  const class matrix<double> &H ,
						  const class matrix<double> &A_Gamma_inv ,
						  const class array<class matrix<double> > &A_Gamma_gradients ,
						  class matrix<double> &F_der)
{
  const unsigned int N = H.get_dimension ();
    
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class matrix<double> &A_Gamma_gradients_ii = A_Gamma_gradients(i , i);
	
      F_der(i , i) = H(i , i) - t*Frobenius_scalar_product (A_Gamma_inv , A_Gamma_gradients_ii);
    }
  
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i < j ; i++)
      {
	const class matrix<double> &A_Gamma_gradients_ij = A_Gamma_gradients(i , j);
	
	F_der(i , j) = F_der(j , i) = 2.0*H(i , j) - t*Frobenius_scalar_product (A_Gamma_inv , A_Gamma_gradients_ij);
      }
}



void linear_programming::log_barrier::Hessian_diagonal_calc (
							     const double t ,
							     const class matrix<double> &A_Gamma_inv ,
							     const class array<class matrix<double> > &A_Gamma_gradients ,
							     class matrix<double> &Hessian_diagonal)
{
  const unsigned int N_conditions = A_Gamma_inv.get_dimension ();
  
  const unsigned int N = Hessian_diagonal.get_dimension ();

  class matrix<double> P(N_conditions);
  
  class matrix<double> P_transpose(N_conditions);
    
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i <= j ; i++)
      {
	const class matrix<double> &A_Gamma_gradients_ij = A_Gamma_gradients(i , j);
	
	P = A_Gamma_inv*A_Gamma_gradients_ij;

	P_transpose = P;
	P_transpose.transpose ();
	
	Hessian_diagonal(i , j) = Hessian_diagonal(j , i) = Frobenius_scalar_product (P , P_transpose);
      }

  Hessian_diagonal *= t;
}




void linear_programming::log_barrier::Hessian_vector_apply (
							    const double t ,
							    const class array<class matrix<double> > &A_conditions ,
							    const class matrix<double> &A_Gamma_zero ,
							    const class matrix<double> &A_Gamma_inv ,
							    const class array<class matrix<double> > &A_Gamma_gradients ,
							    const class matrix<double> &X ,
							    class matrix<double> &Hessian_X)
{
  const unsigned int N = X.get_dimension ();

  const unsigned int N_conditions = A_conditions.dimension (0);

  class array<double> X_diagonal(N);
  
  X.diagonal_part (X_diagonal);
  
  class matrix<double> X_mod = 2.0*X;

  X_mod.remove_array_diagonal_part (X_diagonal);
  
  class matrix<double> Delta(N_conditions);

  A_Gamma_calc (A_conditions , A_Gamma_zero , X_mod , Delta);
      
  Delta -= A_Gamma_zero;
  
  const class matrix<double> V = A_Gamma_inv*Delta*A_Gamma_inv;
  
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i <= j ; i++)
      {
	const class matrix<double> &A_Gamma_gradients_ij = A_Gamma_gradients(i , j);
	
	Hessian_X(i , j) = Hessian_X(j , i) = Frobenius_scalar_product (V , A_Gamma_gradients_ij);
      }

  Hessian_X *= t;
}










void linear_programming::log_barrier::Hessian_linear_system_solve_biconjugate_gradient_stabilized (
												   const double alpha_LM,
												   const double t ,
												   const class array<class matrix<double> > &A_conditions ,
												   const class matrix<double> &A_Gamma_zero ,
												   const class matrix<double> &A_Gamma_inv ,
												   const class array<class matrix<double> > &A_Gamma_gradients ,
												   const class matrix<double> &Hessian_diagonal ,
												   class matrix<double> &F_der ,
												   class matrix<double> &Delta_Gamma)
{
  const double BiCG_precision = 1E-7;
    
  const unsigned int N = F_der.get_dimension ();
    
  const unsigned int iter_max = 500;
  
  diagonal_preconditioning (Hessian_diagonal , F_der);
  
  class matrix<double> R = F_der , Hes_Delta_Gamma = F_der;

  Delta_Gamma = F_der;

  Hessian_vector_apply (t , A_conditions , A_Gamma_zero , A_Gamma_inv , A_Gamma_gradients , Delta_Gamma , Hes_Delta_Gamma);
  
  diagonal_preconditioning (Hessian_diagonal , Hes_Delta_Gamma);
  
  R                = Delta_Gamma;
  R               *= alpha_LM;
  Hes_Delta_Gamma += R;
        
  R  = F_der;
  R -= Hes_Delta_Gamma;
  
  if (R.infinite_norm () < BiCG_precision) return;
  
  class matrix<double> P(N) , S(N) , U(N) , V(N);
  
  F_der = R;

  V = 0.0;
  P = 0.0;
  
  double alpha = 1.0 , omega = 1.0 , rho_bef = 1.0;
  
  for (unsigned int i = 0 ; i < iter_max ; i++) 	
    {      
      const double rho = Frobenius_scalar_product (F_der , R);

      const double beta = (rho/rho_bef)*(alpha/omega);

      S  = V;
      S *= omega;

      U  = P;
      U -= S;
      
      S  = U;
      S *= beta;
      
      P  = R;
      P += S;
            
      Hessian_vector_apply (t , A_conditions , A_Gamma_zero , A_Gamma_inv , A_Gamma_gradients , P , V);
  
      diagonal_preconditioning (Hessian_diagonal , V);
  
      S  = P;
      S *= alpha_LM;
      V += S;
      
      alpha = rho/Frobenius_scalar_product (F_der , V);

      S  = P;
      S *= alpha;
      
      Delta_Gamma += S;

      U  = V;
      U *= alpha;

      Hes_Delta_Gamma += U;

      S  = Hes_Delta_Gamma;
      S -= F_der;

      const double Res_inf_norm_1 = S.infinite_norm ();

      // if (Res_inf_norm_1 < BiCG_precision) cout << "Hessian BiCG iteration (log barrier - 1) : " << i << " test : " << Res_inf_norm_1 << endl;
	      
      if (Res_inf_norm_1 < BiCG_precision) return;
      
      S  = R;
      S -= U;

      Hessian_vector_apply (t , A_conditions , A_Gamma_zero , A_Gamma_inv , A_Gamma_gradients , S , R);
      
      diagonal_preconditioning (Hessian_diagonal , R);
  
      U  = S;
      U *= alpha_LM;
      R += U;
      
      const double R_scalar_S = Frobenius_scalar_product (R , S);

      const double R_scalar_R = R.Frobenius_squared_norm ();
      
      omega = R_scalar_S/R_scalar_R;

      U  = S;
      U *= omega;
      
      Delta_Gamma += U;

      U  = R;
      U *= omega;

      Hes_Delta_Gamma += U;

      const double Res_inf_norm_2 = U.infinite_norm ();
            
      // if (Res_inf_norm_2 < BiCG_precision) cout << "Hessian BiCG iteration (log barrier - 2) : " << i << " test : " << Res_inf_norm_2 << endl;
      
      if (Res_inf_norm_2 < BiCG_precision) return;
      
      R  = S;
      R -= U;
            
      rho_bef = rho;          
    }
      
  error_message_print_abort ("Too many iterations in the Hessian linear system of log barrier optimization");      
}




void linear_programming::log_barrier::optimization (
						    const double optimization_precision ,
						    const double alpha_LM,
						    const double t_min ,
						    const double t_max ,
						    const double t_step ,
						    const class matrix<double> &H ,
						    const class array<class matrix<double> > &A_conditions ,
						    const class matrix<double> &A_Gamma_zero ,
						    class matrix<double> &Gamma)
{  
  const unsigned int iter_max = 5000;
  
  const unsigned int N = H.get_dimension ();
  
  const unsigned int N_conditions = A_conditions.dimension (0);

  class array<class matrix<double> > A_Gamma_gradients(N , N);

  A_Gamma_gradients_alloc_calc (A_conditions , A_Gamma_gradients);
  
  class matrix<double> A_Gamma(N_conditions) , A_Gamma_inv(N_conditions) , B_Gamma(N_conditions);
  
  class matrix<double> Delta_Gamma(N) , F_der(N) , Hessian_diagonal(N);
 
  class array<double> Delta_Gamma_diagonal_part(N);
  
  Gamma = 0.1;

  double t = t_max;

  cout << endl << "Log barrier method" << endl;
	  
  cout << "------------------" << endl << endl;
      
  unsigned int iter = 0;
    
  while (t > t_min)
    {  
      double test = INFINITE;
	  
      A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma);
  
      A_Gamma_inv = A_Gamma;
      A_Gamma_inv.inverse ();
  
      F_der_calc (t , H , A_Gamma_inv , A_Gamma_gradients , F_der);
      
      while ((test > optimization_precision) && (iter++ < iter_max))
	{
	  Hessian_diagonal_calc (t , A_Gamma_inv , A_Gamma_gradients , Hessian_diagonal);
      
	  Hessian_linear_system_solve_biconjugate_gradient_stabilized (alpha_LM , t , A_conditions , A_Gamma_zero , A_Gamma_inv , A_Gamma_gradients , Hessian_diagonal , F_der , Delta_Gamma);

	  Delta_Gamma.diagonal_part (Delta_Gamma_diagonal_part);
	  
	  Delta_Gamma *= 2.0;
	  
	  Delta_Gamma.remove_array_diagonal_part (Delta_Gamma_diagonal_part);
    
	  Gamma -= Delta_Gamma;

	  A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma);

	  A_Gamma_inv = A_Gamma;
	  A_Gamma_inv.inverse ();
      
	  F_der_calc (t , H , A_Gamma_inv , A_Gamma_gradients , F_der);
      
	  const double F = F_calc (t , H , Gamma , A_Gamma);
      
	  const double F_der_norm = F_der.infinite_norm ();
      
	  B_Gamma = A_Gamma;

	  double log_Det_A_Gamma;
  
	  int dummy_phase;

	  B_Gamma.log_scaled_determinant_and_phase (log_Det_A_Gamma , dummy_phase);
  
	  cout << "Iteration : " << iter << "    t:" << t << "    F : " << F << "    ||grad[F]|| : " << F_der_norm << "    ln[det[A[Gamma]]] : " << log_Det_A_Gamma << endl;

	  test = F_der_norm;
	}

      t *= t_step;
    }
  
  cout << endl;
  
  cout << "F" << endl << F_calc (t , H , Gamma , A_Gamma) << endl << endl;
  
  cout << "Gamma" << endl << Gamma << endl;
  
  A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma);
	  
  class array<double> A_Gamma_eigenvalues(N_conditions);

  total_diagonalization::all_eigenvalues (A_Gamma , A_Gamma_eigenvalues);
  
  cout << "A[Gamma] eigenvalues" << endl << A_Gamma_eigenvalues << endl;
  
}




double linear_programming::augmented_Lagrangian::F_calc (
							 const class matrix<double> &H ,
							 const class matrix<double> &Gamma ,
							 const class matrix<double> &X_minus_A_Gamma ,
							 const class matrix<double> &Lambda_plus_half_sigma_X_minus_A_Gamma)
{
  const double F0 = Frobenius_scalar_product (H , Gamma);
	
  const double Lambda_plus_half_sigma_X_minus_A_Gamma_term = Frobenius_scalar_product (Lambda_plus_half_sigma_X_minus_A_Gamma , X_minus_A_Gamma);
  
  const double F = F0 + Lambda_plus_half_sigma_X_minus_A_Gamma_term;
  
  return F;
}




void linear_programming::augmented_Lagrangian::F_der_calc (
							   const class matrix<double> &H ,
							   const class matrix<double> &Lambda_plus_sigma_X_minus_A_Gamma ,
							   const class array<class matrix<double> > &A_Gamma_gradients ,
							   class matrix<double> &F_der)
{
  const unsigned int N = H.get_dimension ();
	    
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class matrix<double> &A_Gamma_gradients_ii = A_Gamma_gradients(i , i);
	
      F_der(i , i) = H(i , i) - Frobenius_scalar_product (Lambda_plus_sigma_X_minus_A_Gamma , A_Gamma_gradients_ii);
    }
  
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i < j ; i++)
      {
	const class matrix<double> &A_Gamma_gradients_ij = A_Gamma_gradients(i , j);
	
	F_der(i , j) = F_der(j , i) = 2.0*H(i , j) - Frobenius_scalar_product (Lambda_plus_sigma_X_minus_A_Gamma , A_Gamma_gradients_ij);
      }
}



void linear_programming::augmented_Lagrangian::Hessian_diagonal_calc (
								      const double sigma ,
								      const class array<class matrix<double> > &A_Gamma_gradients ,
								      class matrix<double> &Hessian_diagonal)
{
  const unsigned int N = Hessian_diagonal.get_dimension ();
    
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i <= j ; i++)
      Hessian_diagonal(i , j) = Hessian_diagonal(j , i) = A_Gamma_gradients(i , j).Frobenius_squared_norm ();

  Hessian_diagonal *= sigma;
}




void linear_programming::augmented_Lagrangian::Hessian_vector_apply (
								     const double sigma ,
								     const class array<class matrix<double> > &A_conditions ,
								     const class matrix<double> &A_Gamma_zero ,
								     const class array<class matrix<double> > &A_Gamma_gradients ,
								     const class matrix<double> &X ,
								     class matrix<double> &Hessian_X)
{
  const unsigned int N = X.get_dimension ();

  const unsigned int N_conditions = A_conditions.dimension (0);

  class array<double> X_diagonal(N);
  
  X.diagonal_part (X_diagonal);
  
  class matrix<double> X_mod = 2.0*X;

  X_mod.remove_array_diagonal_part (X_diagonal);
  
  class matrix<double> Delta(N_conditions);

  A_Gamma_calc (A_conditions , A_Gamma_zero , X_mod , Delta);
      
  Delta -= A_Gamma_zero;
    
  for (unsigned int j = 0 ; j < N ; j++)
    for (unsigned int i = 0 ; i <= j ; i++)
      {
	const class matrix<double> &A_Gamma_gradients_ij = A_Gamma_gradients(i , j);
	
	Hessian_X(i , j) = Hessian_X(j , i) = Frobenius_scalar_product (Delta , A_Gamma_gradients_ij);
      }

  Hessian_X *= sigma;
}










void linear_programming::augmented_Lagrangian::Hessian_linear_system_solve_biconjugate_gradient_stabilized (
													    const double alpha_LM,
													    const double sigma ,
													    const class array<class matrix<double> > &A_conditions ,
													    const class matrix<double> &A_Gamma_zero ,
													    const class array<class matrix<double> > &A_Gamma_gradients ,
													    const class matrix<double> &Hessian_diagonal ,
													    class matrix<double> &F_der ,
													    class matrix<double> &Delta_Gamma)
{
  const double BiCG_precision = 1E-7;
    
  const unsigned int N = F_der.get_dimension ();
    
  const unsigned int iter_max = 500;
  
  diagonal_preconditioning (Hessian_diagonal , F_der);
  
  class matrix<double> R = F_der , Hes_Delta_Gamma = F_der;

  Delta_Gamma = F_der;

  Hessian_vector_apply (sigma , A_conditions , A_Gamma_zero , A_Gamma_gradients , Delta_Gamma , Hes_Delta_Gamma);
  
  diagonal_preconditioning (Hessian_diagonal , Hes_Delta_Gamma);
  
  R                = Delta_Gamma;
  R               *= alpha_LM;
  Hes_Delta_Gamma += R;
        
  R  = F_der;
  R -= Hes_Delta_Gamma;
  
  if (R.infinite_norm () < BiCG_precision) return;
  
  class matrix<double> P(N) , S(N) , U(N) , V(N);
  
  F_der = R;

  V = 0.0;
  P = 0.0;
  
  double alpha = 1.0 , omega = 1.0 , rho_bef = 1.0;
  
  for (unsigned int i = 0 ; i < iter_max ; i++) 	
    {      
      const double rho = Frobenius_scalar_product (F_der , R);

      const double beta = (rho/rho_bef)*(alpha/omega);

      S  = V;
      S *= omega;

      U  = P;
      U -= S;
      
      S  = U;
      S *= beta;
      
      P  = R;
      P += S;
            
      Hessian_vector_apply (sigma , A_conditions , A_Gamma_zero , A_Gamma_gradients , P , V);
  
      diagonal_preconditioning (Hessian_diagonal , V);
  
      S  = P;
      S *= alpha_LM;
      V += S;
      
      alpha = rho/Frobenius_scalar_product (F_der , V);

      S  = P;
      S *= alpha;
      
      Delta_Gamma += S;

      U  = V;
      U *= alpha;

      Hes_Delta_Gamma += U;

      S  = Hes_Delta_Gamma;
      S -= F_der;

      const double Res_inf_norm_1 = S.infinite_norm ();
      
      //if (Res_inf_norm_1 < BiCG_precision) cout << "Hessian BiCG iteration (augmented Lagrangian - 1) : " << i << " test : " << Res_inf_norm_1 << endl;
	
      if (Res_inf_norm_1 < BiCG_precision) return;

      S  = R;
      S -= U;

      Hessian_vector_apply (sigma , A_conditions , A_Gamma_zero , A_Gamma_gradients , S , R);
      
      diagonal_preconditioning (Hessian_diagonal , R);
  
      U  = S;
      U *= alpha_LM;
      R += U;
      
      const double R_scalar_S = Frobenius_scalar_product (R , S);

      const double R_scalar_R = R.Frobenius_squared_norm ();
      
      omega = R_scalar_S/R_scalar_R;

      U  = S;
      U *= omega;
      
      Delta_Gamma += U;

      U  = R;
      U *= omega;

      Hes_Delta_Gamma += U;
      
      const double Res_inf_norm_2 = U.infinite_norm ();
      
      //if (Res_inf_norm_2 < BiCG_precision) cout << "Hessian BiCG iteration (augmented Lagrangian - 2) : " << i << " test : " << Res_inf_norm_2 << endl;
      
      if (Res_inf_norm_2 < BiCG_precision) return;
      
      R  = S;
      R -= U;
            
      rho_bef = rho;          
    }
      
  error_message_print_abort ("Too many iterations in the Hessian linear system of augmented Lagrangian optimization");      
}




void linear_programming::augmented_Lagrangian::optimization (
							     const double optimization_precision ,
							     const double alpha_LM,
							     const double sigma_init ,
							     const double sigma_step ,
							     const class matrix<double> &Gamma_init ,
							     const class matrix<double> &H ,
							     const class array<class matrix<double> > &A_conditions ,
							     const class matrix<double> &A_Gamma_zero)
{  
  const unsigned int iter_max = 100000;
  
  const unsigned int N = H.get_dimension ();
  
  const unsigned int N_conditions = A_conditions.dimension (0);

  class array<class matrix<double> > A_Gamma_gradients(N , N);
  
  class matrix<double> A_Gamma(N_conditions) , Lambda(N_conditions) , X_minus_A_Gamma(N_conditions) , sqrt_X_minus_A_Gamma(N_conditions);
  
  class matrix<double> Lambda_plus_half_sigma_X_minus_A_Gamma(N_conditions) , Lambda_plus_sigma_X_minus_A_Gamma(N_conditions);
  
  class matrix<double> Gamma(N) , Delta_Gamma(N) , F_der(N) , Hessian_diagonal(N);
 
  class array<double> Delta_Gamma_diagonal_part(N);
  
  double sigma = sigma_init;
  
  double test = INFINITE;

  unsigned int iter = 0;
  
  Gamma = Gamma_init;
	    
  A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma);
    
  A_Gamma_gradients_alloc_calc (A_conditions , A_Gamma_gradients);
  
  Lambda = 0.0;
  
  X_minus_A_Gamma = 0.0;
  
  Lambda_plus_sigma_X_minus_A_Gamma = 0.0;
  
  F_der_calc (H , Lambda_plus_sigma_X_minus_A_Gamma , A_Gamma_gradients , F_der);
      
  cout << endl << "Augmented Lagrangian method" << endl;

  cout << "---------------------------" << endl << endl;
              
  while ((test > optimization_precision) && (iter++ < iter_max))
    {
      Hessian_diagonal_calc (sigma , A_Gamma_gradients , Hessian_diagonal);
	
      Hessian_linear_system_solve_biconjugate_gradient_stabilized (alpha_LM , sigma , A_conditions , A_Gamma_zero , A_Gamma_gradients , Hessian_diagonal , F_der , Delta_Gamma);
            
      Delta_Gamma.diagonal_part (Delta_Gamma_diagonal_part);
	  
      Delta_Gamma *= 2.0;
	  
      Delta_Gamma.remove_array_diagonal_part (Delta_Gamma_diagonal_part);
    
      Gamma -= Delta_Gamma;

      A_Gamma_calc (A_conditions , A_Gamma_zero , Gamma , A_Gamma);
      
      X_minus_A_Gamma = A_Gamma - Lambda/sigma;
      
      sqrt_X_minus_A_Gamma = sqrt (X_minus_A_Gamma);
      
      X_minus_A_Gamma = sqrt_X_minus_A_Gamma*sqrt_X_minus_A_Gamma;
      
      X_minus_A_Gamma -= A_Gamma;
      
      Lambda_plus_sigma_X_minus_A_Gamma = Lambda + sigma*X_minus_A_Gamma;
  
      Lambda_plus_half_sigma_X_minus_A_Gamma = Lambda + 0.5*sigma*X_minus_A_Gamma;
  
      F_der_calc (H , Lambda_plus_sigma_X_minus_A_Gamma , A_Gamma_gradients , F_der);
      
      const double F = F_calc (H , Gamma , X_minus_A_Gamma , Lambda_plus_half_sigma_X_minus_A_Gamma);
	  
      const double F_der_norm = F_der.infinite_norm ();
	  
      const double X_minus_A_Gamma_norm = X_minus_A_Gamma.infinite_norm ();
      
      if (F_der_norm >= 10.0*X_minus_A_Gamma_norm)
	sigma /= sigma_step;
      else if (F_der_norm <= 0.1*X_minus_A_Gamma_norm)
	sigma *= sigma_step;
      else
	Lambda += sigma*X_minus_A_Gamma;
      
      test = max (F_der_norm , X_minus_A_Gamma_norm);
      
      cout << "Iteration : " << iter << "    sigma : " << sigma << "    F : " << F << "    ||grad[F]|| : " << F_der_norm << "    ||X - A[Gamma]|| : " << X_minus_A_Gamma_norm << endl;
    }
 
  cout << endl;
    
  cout << "F" << endl << F_calc (H , Gamma , X_minus_A_Gamma , Lambda_plus_half_sigma_X_minus_A_Gamma) << endl << endl;
  
  cout << "Gamma" << endl << Gamma << endl;
  
  class array<double> A_Gamma_eigenvalues(N_conditions);

  total_diagonalization::all_eigenvalues (A_Gamma , A_Gamma_eigenvalues);
  
  cout << "A[Gamma] eigenvalues" << endl << A_Gamma_eigenvalues << endl;
}


