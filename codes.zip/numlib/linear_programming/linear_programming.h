#ifndef LINEAR_PROGRAMMING_H
#define LINEAR_PROGRAMMING_H

namespace linear_programming
{
  void diagonal_preconditioning (			 
				 const class matrix<double> &A_diagonal ,	 
				 class matrix<double> &X);
  
  void A_Gamma_calc (
		     const class array<class matrix<double> > &A_conditions ,
		     const class matrix<double> &A_Gamma_zero ,
		     const class matrix<double> &Gamma ,
		     class matrix<double> &A_Gamma);

  void A_Gamma_gradients_alloc_calc (
				     const class array<class matrix<double> > &A_conditions ,
				     class array<class matrix<double> > &A_Gamma_gradients);
  
  namespace log_barrier
  {    
    double F_calc (
		   const double t ,
		   const class matrix<double> &H ,
		   const class matrix<double> &Gamma ,
		   const class matrix<double> &A_Gamma);

    void F_der_calc (
		     const double t ,
		     const class matrix<double> &H ,
		     const class matrix<double> &A_Gamma_inv ,
		     const class array<class matrix<double> > &A_Gamma_gradients ,
		     class matrix<double> &F_der);

    void Hessian_diagonal_calc (
				const double t ,
				const class matrix<double> &A_Gamma_inv ,
				const class array<class matrix<double> > &A_Gamma_gradients ,
				class matrix<double> &Hessian_diagonal);

    void Hessian_vector_apply (
			       const double t ,
			       const class array<class matrix<double> > &A_conditions ,
			       const class matrix<double> &A_Gamma_zero ,
			       const class matrix<double> &A_Gamma_inv ,
			       const class array<class matrix<double> > &A_Gamma_gradients ,
			       const class matrix<double> &X ,
			       class matrix<double> &Hessian_X);

    void Hessian_linear_system_solve_biconjugate_gradient_stabilized (
								      const double alpha_LM,
								      const double t ,
								      const class array<class matrix<double> > &A_conditions ,
								      const class matrix<double> &A_Gamma_zero ,
								      const class matrix<double> &A_Gamma_inv ,
								      const class array<class matrix<double> > &A_Gamma_gradients ,
								      const class matrix<double> &Hessian_diagonal ,
								      class matrix<double> &F_der ,
								      class matrix<double> &Delta_Gamma);

    void optimization (
		       const double optimization_precision ,
		       const double alpha_LM,
		       const double t_min ,
		       const double t_max ,
		       const double t_step ,
		       const class matrix<double> &H ,
		       const class array<class matrix<double> > &A_conditions ,
		       const class matrix<double> &A_Gamma_zero ,
		       class matrix<double> &Gamma);
  }

  
  namespace augmented_Lagrangian
  {    
    double F_calc (
		   const class matrix<double> &H ,
		   const class matrix<double> &Gamma ,
		   const class matrix<double> &X_minus_A_Gamma ,
		   const class matrix<double> &Lambda_plus_half_sigma_X_minus_A_Gamma);



    void F_der_calc (
		     const class matrix<double> &H ,
		     const class matrix<double> &Lambda_plus_sigma_X_minus_A_Gamma ,
		     const class array<class matrix<double> > &A_Gamma_gradients ,
		     class matrix<double> &F_der);



    void Hessian_diagonal_calc (
				const double sigma ,
				const class array<class matrix<double> > &A_Gamma_gradients ,
				class matrix<double> &Hessian_diagonal);



    void Hessian_vector_apply (
			       const double sigma ,
			       const class array<class matrix<double> > &A_conditions ,
			       const class matrix<double> &A_Gamma_zero ,
			       const class array<class matrix<double> > &A_Gamma_gradients ,
			       const class matrix<double> &X ,
			       class matrix<double> &Hessian_X);






    void Hessian_linear_system_solve_biconjugate_gradient_stabilized (
								      const double alpha_LM,
								      const double sigma ,
								      const class array<class matrix<double> > &A_conditions ,
								      const class matrix<double> &A_Gamma_zero ,
								      const class array<class matrix<double> > &A_Gamma_gradients ,
								      const class matrix<double> &Hessian_diagonal ,
								      class matrix<double> &F_der ,
								      class matrix<double> &Delta_Gamma);


    void optimization (
		       const double optimization_precision ,
		       const double alpha_LM,
		       const double sigma_init ,
		       const double sigma_step ,
		       const class matrix<double> &Gamma_init ,
		       const class matrix<double> &H ,
		       const class array<class matrix<double> > &A_conditions ,
		       const class matrix<double> &A_Gamma_zero);
  }
}

#endif
