#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


using namespace linear_programming;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Sequential calculation only");

    seed (0);
    
    const double optimization_precision_log_barrier = 1E-2;
    
    const double optimization_precision_augmented_Lagrangian = 1E-6;
    
    const double alpha_LM = 0;
    
    const double t_max = 1;
    
    const double t_min = 0.1;
    
    const double t_step = 0.9;

    const double sigma_init = 0.1;
    
    const double sigma_step = 1.25;
    
    const unsigned int N = 5;
    
    const unsigned int N_conditions = 15;

    const bool is_there_log_barrier = false;

    class matrix<double> A_Gamma_zero(N_conditions);

    A_Gamma_zero.symmetric_random_matrix ();

    A_Gamma_zero *= 0.01;

    A_Gamma_zero.add_scalar_diagonal_part (2.0);

    class matrix<double> H(N);

    H.symmetric_random_matrix ();

    H *= -0.1;

    H.remove_scalar_diagonal_part (1.0);
    
    class array<class matrix<double> > A_conditions(N_conditions , N_conditions);
    
    for (unsigned int i = 0 ; i < N_conditions ; i++)
      for (unsigned int j = 0 ; j < N_conditions ; j++)
	A_conditions(i , j).allocate (N);
    
    for (unsigned int i = 0 ; i < N_conditions ; i++)
      for (unsigned int j = 0 ; j <= i ; j++)
	{
	  A_conditions(i , j).symmetric_random_matrix ();
	      
	  A_conditions(j , i) = A_conditions(i , j);
	}

    class matrix<double> Gamma(N);
    
    if (is_there_log_barrier)
      log_barrier::optimization (optimization_precision_log_barrier , alpha_LM , t_min , t_max , t_step , H , A_conditions , A_Gamma_zero , Gamma);
    else
      Gamma = 0.5;
    
    augmented_Lagrangian::optimization (optimization_precision_augmented_Lagrangian , alpha_LM , sigma_init , sigma_step , Gamma , H , A_conditions , A_Gamma_zero);
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }




