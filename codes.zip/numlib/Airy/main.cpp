#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
    
    cout.precision (6);

    const unsigned int Nx = 10;
    const unsigned int Ny = 10;

    const double x_min = -5 , x_max = 5 , x_step = (x_max - x_min)/static_cast<double> (Nx-1);
    const double y_min = -1 , y_max = 1 , y_step = (y_max - y_min)/static_cast<double> (Ny-1);

    const double Ai_zero_exact = pow (3.0 , -2.0/3.0)*exp (-lgamma (2.0/3.0));
    const double Bi_zero_exact = pow (3.0 , -1.0/6.0)*exp (-lgamma (2.0/3.0));

    const double dAi_zero_exact = -pow (3.0 , -1.0/3.0)*exp (-lgamma (1.0/3.0));
    const double dBi_zero_exact =  pow (3.0 ,  1.0/6.0)*exp (-lgamma (1.0/3.0));

    class Coulomb_wave_functions cwf(true , -0.16666666666666667 , 0.0);

    complex<double> Ai_zero , dAi_zero , Bi_zero , dBi_zero;

    Airy::Ai_dAi (cwf , 0.0 , Ai_zero , dAi_zero);
    Airy::Bi_dBi (cwf , 0.0 , Bi_zero , dBi_zero);
		
    cout << "Ai(0)  : " << Ai_zero  << " precision : " << inf_norm (Ai_zero - Ai_zero_exact)   << endl;
    cout << "Bi(0)  : " << Bi_zero  << " precision : " << inf_norm (Bi_zero - Bi_zero_exact)   << endl;

    cout << "Ai'(0) : " << dAi_zero << " precision : " << inf_norm (dAi_zero - dAi_zero_exact) << endl;
    cout << "Bi'(0) : " << dBi_zero << " precision : " << inf_norm (dBi_zero - dBi_zero_exact) << endl << endl;

    cout << "z   Ai(z)   Ai'(z)   Bi(z)   Bi'(z)   precision" << endl;

    for (unsigned int ix = 0 ; ix < Nx ; ix++) 
      for (unsigned int iy = 0 ; iy < Ny ; iy++)
	{
	  const double x = x_min + ix*x_step;
	  const double y = y_min + iy*y_step;
	  
	  const complex<double> z(x , y);

	  complex<double> Ai , dAi , Bi , dBi;
			
	  Airy::Ai_dAi (cwf , z , Ai , dAi);
	  Airy::Bi_dBi (cwf , z , Bi , dBi);

	  const complex<double> Wronskian = Ai*dBi - Bi*dAi;

	  cout << z << "   " << Ai << "   " << dAi << "   " << Bi << "   " << dBi << "   "  << inf_norm (Wronskian - M_1_PI) << endl;
	}

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



