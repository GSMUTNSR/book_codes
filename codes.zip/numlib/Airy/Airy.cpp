#include "../numlib_def/numlib_def.h"

// Basis functions
// ---------------
// regular   : F(omega =  1 , z) = f(z) = Ai(z)
// irregular : F(omega = -1 , z) = g(z) = [i.Ai(z) + Bi(z)].sqrt (Pi).exp (-i.Pi/12)



// Calculation of the following scaled Airy functions with power series 
// --------------------------------------------------------------------
// It is used for |z| <= 1.
//
// f(x)=\sum a[n] , n in [0: + oo[ , where : 
// a[0]=f_in_zero_omega.
// a[1]=df_in_zero_omega.x.
// a[2]=0.0
// a[n]=(x^3).a[n - 3]/(n(n - 1)) , n>=3.
// 
// Variables:
// -- -- -- -- -- 
// omega : 1 if one calculates the regular function , -1 if one calculate the irregular function , having a pure incoming behavior in + oo.
// z : variable of the Airy function.
// f , df : will contain the values of the basis function and derivative in z , regular ones if omega = 1 , irregular ones if omega = -1.
// f_in_zero_omega , df_in_zero_omega : basis function and derivative in 0 , regular ones if omega = 1 , irregular ones if omega = -1 (see below).
// one_over_z , z_cube : 1/z , z^3.
// n : index of the power series term. It begins at three.
// an , an_minus_three , an_minus_two , an_minus_one , n_n_minus_one : a[n] , a[n - 3] , a[n - 2] , a[n - 1] , n(n - 1).
// It is |a[n - 3]|oo + |a[n - 2]|oo + |a[n - 1]|oo , as one of the three can be zero even before convergence.
//
// Analytical expressions in z=0
// -- -- -- -- -- -- -- -- -- --
//
// Ai(0)  = 3^(-2/3)  / Gamma (2/3)
// Ai'(0) = -3^(-1/3) / Gamma (1/3)
// Bi(0)  = 3^(-1/6)  / Gamma (2/3)
// Bi'(0) = 3^(1/6)   / Gamma (1/3)
//
// f_in_zero = Ai(0)
// df_in_zero = Ai'(0)
//
// g_in_zero  = [i.Ai(0)  + Bi(0)].sqrt (Pi).exp (-i.Pi/12)
// dg_in_zero = [i.Ai'(0) + Bi'(0)].sqrt (Pi).exp (-i.Pi/12)


void Airy::power_series (
			 const int omega ,
			 const complex<double> &z ,
			 complex<double> &F_omega ,
			 complex<double> &dF_omega)
{ 
  const complex<double> f_in_zero = 0.3550280538878172;
  const complex<double> df_in_zero = -0.2588194037928068;

  const complex<double> g_in_zero(1.215657914671025 , 0.3257345565086039);
  const complex<double> dg_in_zero(0.6487640355701874 , -0.6487640355701874);

  const complex<double> F_omega_in_zero = (omega == 1) ? (f_in_zero) : (g_in_zero);
  const complex<double> dF_omega_in_zero = (omega == 1) ? (df_in_zero) : (dg_in_zero);

  if (z == 0.0)
    {
      F_omega = F_omega_in_zero;
      dF_omega = dF_omega_in_zero;

      return;
    }

  const complex<double> one_over_z = 1.0/z;
  const complex<double> z_cube = z * z * z;

  int n = 3;

  complex<double> an_minus_three = F_omega_in_zero;
  complex<double> an_minus_two = dF_omega_in_zero * z;
  complex<double> an_minus_one = 0.0;

  F_omega = an_minus_three + an_minus_two;
  dF_omega = an_minus_two;

  while (inf_norm (an_minus_three) + inf_norm (an_minus_two) + inf_norm (an_minus_one) > 1E-15)
    {
      const double n_n_minus_one = n * (n - 1.0);
      const complex<double> an = z_cube * an_minus_three/n_n_minus_one;

      F_omega += an;
      dF_omega += n * an;

      n++ ;
      an_minus_three = an_minus_two;
      an_minus_two = an_minus_one;
      an_minus_one = an;
    }

  dF_omega *= one_over_z;
}





// Calculation of the following Airy functions
// -------------------------------------------
// _regular function   : A[z] and dA/dz[z] with omega =  1.
// _irregular function : B[z] and dB/dz[z] with omega = -1. B[z] is different from Bi[z].
//
// A[z] = z^(-1/4).H+[l = -1/6 , eta = 0 , 2/3.I.z^(3/2)] on the positive real axis.
// B[z] = z^(-1/4).H-[l = -1/6 , eta = 0 , 2/3.I.z^(3/2)] on the positive real axis.
//
// The Coulomb wave function class must be given as input.
//
// If |z| <= 1 , one calculates the Airy function and derivative with power series.
// If |z|  > 1 , one calculates the Airy function and derivative with H + and H - .
//
// If arg(z) is equal to 2/3 Pi or 4/3 Pi, the calculation can be unstable.
//
// Variables:
// ----------
// omega : 1 for the regular function , -1 for the irregular function.
// z : variable of the Airy function.
// cwf : Coulomb wave function with l = -1/6 and eta = 0.
// F_omega , dF_omega : will contain the values A(z) and A'(z) if omega=1 , B(z) and B'(z) if omega = -1.
// Pi_over_three : Pi/3
// reg_norm_const : normalization constant for Ai , so one has the standard Ai at the end of the calculation.
// z_pow_3I2 , z_pow_minus_1I4 , I_z_pow_3I2 , chi : z^{3/2} , z^{1/4} , i.z^{3/2} , (2i/3).z^{3/2}.
// H_omega , dH_omega : H+(chi) and H+'(chi) if omega = 1 , H-(chi) and H-'(chi) if omega = -1.
// Hplus , dHplus , Hminus , dHminus : H+(chi) , H+'(chi) , H-(chi) and H-'(chi).

void Airy::out_in_basis_functions (
				   const int omega , 
				   class Coulomb_wave_functions &cwf , 
				   const complex<double> &z , 
				   complex<double> &F_omega , 
				   complex<double> &dF_omega)
{
  if ((inf_norm (cwf.get_l () + 0.1666666666666667) > 1E-15) || (cwf.get_eta () != 0.0) || (!cwf.get_is_it_normalized ()))
    {
      error_message_print_abort ("Improper Coulomb wave function class for Airy functions.");
    }

  if (abs (z) <= 1)
    {
      power_series (omega , z , F_omega , dF_omega);

      return;
    }

  const double Pi_over_three = 1.0471975511965977;

  const complex<double> reg_norm_const(0.2724826448360259 , -0.07301150463530962);

  const complex<double> sqrt_z = sqrt (z);

  const complex<double> z_pow_3I2 = z * sqrt_z;

  const complex<double> z_pow_minus_1I4 = 1.0/sqrt (sqrt_z);

  const complex<double> exp_I_two_Pi_over_three(-0.5 , 0.866025403784439);

  const complex<double> I_z_pow_3I2(-imag (z_pow_3I2) , real (z_pow_3I2));

  const complex<double> chi = 0.666666666666667 * I_z_pow_3I2;

  const complex<double> exp_I_Pi_over_three(0.5 , 0.866025403784439);

  if (arg (z) < Pi_over_three)
    {
      complex<double> H_omega;
      complex<double> dH_omega;

      cwf.H_dH (omega , chi , H_omega , dH_omega);

      F_omega = z_pow_minus_1I4 * H_omega;

      dF_omega = (-0.25 * H_omega + I_z_pow_3I2 * dH_omega) * z_pow_minus_1I4/z;
    }
  else if (omega == -1)
    {
      complex<double> Hplus;
      complex<double> dHplus;

      cwf.H_dH (1 , chi , Hplus , dHplus);

      F_omega = z_pow_minus_1I4 * Hplus * exp_I_Pi_over_three;

      dF_omega = (-0.25 * Hplus + I_z_pow_3I2 * dHplus) * exp_I_Pi_over_three * z_pow_minus_1I4/z;
    }
  else
    { 
      complex<double> Hplus;
      complex<double> dHplus;
      complex<double> Hminus;
      complex<double> dHminus;

      cwf.H_dH ( 1 , chi , Hplus  , dHplus);
      cwf.H_dH (-1 , chi , Hminus , dHminus);

      F_omega = z_pow_minus_1I4 * (Hplus + Hminus * exp_I_two_Pi_over_three);

      dF_omega = (-0.25 * Hplus + I_z_pow_3I2 * dHplus + (-0.25 * Hminus + I_z_pow_3I2 * dHminus) * exp_I_two_Pi_over_three) * z_pow_minus_1I4/z;
    }

  if (omega == 1)
    {
      F_omega  *= reg_norm_const;
      dF_omega *= reg_norm_const;
    }
}






// Calculation of the regular Airy function and derivative :
// -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
// This is just a call of out_in_basis_functions with omega = 1.
//
// Variables:
// -- -- -- -- -- 
// z : variable of the Airy function.
// cwf : Coulomb wave function with is_it_normalized = true , l= - 1/6 and eta = 0.
// Ai , dAi : will contain the values Ai(z) and Ai'(z)

void Airy::Ai_dAi (class Coulomb_wave_functions &cwf , const complex<double> &z , complex<double> &Ai , complex<double> &dAi)
{
  out_in_basis_functions (1 , cwf , z , Ai , dAi);
}







// Calculation of the irregular Airy function Bi(z) and derivative
// ---------------------------------------------------------------
// One uses out_in_basis_functions with omega = 1 (regular) and omega = -1 (irregular) to obtain a basis of functions.
// Then:
// Bi(z)  = -i.f(z)  + exp (i.Pi/12)/sqrt (Pi).g(z)
// Bi'(z) = -i.f'(z) + exp (i.Pi/12)/sqrt (Pi).g'(z).
//
// Variables:
// -- -- -- -- -- 
// z : variable of the Airy function.
// f_factor : -i
// g_factor : exp (i.Pi/12)/sqrt (Pi)
// cwf : Coulomb wave function with is_it_normalized = true , l = - 1/6 and eta = 0.
// Bi , dBi : will contain the values Bi(z) and Bi'(z)

void Airy::Bi_dBi (
		   class Coulomb_wave_functions &cwf ,
		   const complex<double> &z ,
		   complex<double> &Bi ,
		   complex<double> &dBi)
{
  const complex<double> f_factor(0 , - 1.0);

  const complex<double> g_factor(0.544965289672052 , 0.146023009270619);

  complex<double> f;
  complex<double> df;

  complex<double> g;
  complex<double> dg;

  out_in_basis_functions (1  , cwf , z , f , df);
  out_in_basis_functions (-1 , cwf , z , g , dg);

  Bi  = f_factor * f  + g_factor * g;
  dBi = f_factor * df + g_factor * dg;
}



