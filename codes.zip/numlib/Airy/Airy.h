#ifndef AIRY_H
#define AIRY_H

namespace Airy
{
  void power_series (
		     const int omega ,
		     const complex<double> &z ,
		     complex<double> &f ,
		     complex<double> &df);

  void out_in_basis_functions (
			       const int omega , 
			       class Coulomb_wave_functions &cwf , 
			       const complex<double> &z , 
			       complex<double> &f , 
			       complex<double> &df);

  void Ai_dAi (
	       class Coulomb_wave_functions &cwf ,
	       const complex<double> &z ,
	       complex<double> &Ai ,
	       complex<double> &dAi);

  void Bi_dBi (
	       class Coulomb_wave_functions &cwf ,
	       const complex<double> &z ,
	       complex<double> &Bi ,
	       complex<double> &dBi);
}

#endif


