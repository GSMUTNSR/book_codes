#ifndef LANCZOS_HPP
#define LANCZOS_HPP

using namespace total_diagonalization;

namespace Lanczos
{	
  template <typename SCALAR_TYPE>
  void Lanczos_matrix_diagonal_test (
				     const bool is_there_cout , 
				     const unsigned int dimension , 
				     const unsigned int vectors_to_find_number , 
				     const unsigned int Lanczos_dimension , 
				     const class array<SCALAR_TYPE> &diagonal_tab , 
				     const class array<SCALAR_TYPE> &off_diagonal_tab , 
				     class array<SCALAR_TYPE> &eigenvalue_work_tab , 
				     double &test);

  template <typename SCALAR_TYPE>
  void lowest_eigenvectors_calc (
				 const unsigned int Lanczos_dimension , 
				 const class array<SCALAR_TYPE> &diagonal_tab , 
				 const class array<SCALAR_TYPE> &off_diagonal_tab , 
				 const class array<SCALAR_TYPE> &eigenvalue_tab , 
				 const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
				 class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab);

  template <typename SCALAR_TYPE>
  class vector_class<SCALAR_TYPE> pivot_calc (
					      const bool is_it_restart , 
					      const unsigned int dimension , 
					      const class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab);

  template <typename SCALAR_TYPE>
  void tridiagonalization (
			   const bool is_there_cout , 
			   const bool is_it_restart , 
			   const bool is_it_sparse , 
			   const double eigenvector_precision , 
			   const unsigned int vectors_to_find_number , 
			   const class matrix<SCALAR_TYPE> &A , 
			   const class sparse_matrix<SCALAR_TYPE> &As , 
			   const class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab , 
			   class array<SCALAR_TYPE> &diagonal_tab , 
			   class array<SCALAR_TYPE> &off_diagonal_tab , 
			   class array<SCALAR_TYPE> &eigenvalue_work_tab , 
			   class array<class vector_class<SCALAR_TYPE> > &V_tab , 
			   unsigned int &Lanczos_dimension , 
			   double &test);

  template <typename SCALAR_TYPE>
  void iterative_diagonalization_lowest_states (
						const bool is_there_cout , 
						const unsigned int N_restarts , 
						const double eigenvector_precision , 
						const unsigned int max_dimension , 
						const class matrix<SCALAR_TYPE> &A , 
						class array<SCALAR_TYPE> &eigenvalue_tab , 
						class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab);

  template <typename SCALAR_TYPE>
  void iterative_diagonalization_lowest_states (
						const bool is_there_cout , 
						const unsigned int N_restarts , 
						const double eigenvector_precision , 
						const unsigned int max_dimension , 
						const class sparse_matrix<SCALAR_TYPE> &A , 
						class array<SCALAR_TYPE> &eigenvalue_tab , 
						class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab);
}











// Test if the calculated eigenvectors with Lanczos vectors are eigenvectors of the considered matrix
// --------------------------------------------------------------------------------------------------
// If one has less Lanczos vectors (Lanczos dimension) than eigenvectors, we cannot have all eigenvectors so that an arbitrary value of INFINITE is assigned to test.
// Otherwise, one diagonalizes exactly the tridiagonal matrix formed by the Lanczos vectors previously calculated (diagonal_tab and off_diagonal_tab).
// As it is the best calculation so far, obtained eigenvalues are put in eigenvalue_tab as output.
// Then, test is calculated as being the infinite norm of the component of the last calculated Lanczos vector for all considered eigenvectors.
// Indeed, the components of the basis Lanczos vectors are supposed to decrease very fast, so that it is a genuine test.
// If the Lanczos dimension is equal to the matrix dimension, the calculation is exact so that test is zero by definition.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// dimension : dimension of the A matrix to diagonalize
// vectors_to_find_number : number of eigenvectors that one wants to calculate 
// Lanczos_dimension, Lanczos_dimension_minus_one : current number of Lanczos vectors, Lanczos_dimension - 1
// diagonal_tab : diagonal_tab(i) = <V(i) | A | V(i)>, the diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// off_diagonal_tab : off_diagonal_tab(i-1) = <V(i) | A | V(i-1)>, the off-diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// eigenvalue_tab : will contain the eigenvalues of the matrix A to diagonalize in the basis of Lanczos vectors
// test : value testing if the calculated eigenvectors with Lanczos vectors are eigenvectors of the considered matrix
//        If Lanczos dimension < dimension, it is INFINITE by definition;
//        If Lanczos dimension is the dimension of the considered A matrix, it is zero by definition;
//        In the general case, if an eigenvector |Psi> = \sum_{i = 0}^{Lanczos dimension - 1} c_i |V(i)>, it is the maximal value of |c_{Lanczos dimension - 1}|oo, considering all |Psi> vectors.
// diagonal_tab_small , off_diagonal_tab_small : same as diagonal_tab and off_diagonal_tab, but their dimension is Lanczos_dimension. This is necessary for the used diagonalization routine.
// Lanczos : matrix initially containing the matrix A to diagonalize in the basis of Lanczos vectors, and containing its eigenvectors after diagonalization
// eigenvector_i : i-th eigenvector of the matrix A to diagonalize in the basis of Lanczos vectors

template <typename SCALAR_TYPE>
void Lanczos::Lanczos_matrix_diagonal_test (
					    const bool is_there_cout , 
					    const unsigned int dimension , 
					    const unsigned int vectors_to_find_number , 
					    const unsigned int Lanczos_dimension , 
					    const class array<SCALAR_TYPE> &diagonal_tab , 
					    const class array<SCALAR_TYPE> &off_diagonal_tab , 
					    class array<SCALAR_TYPE> &eigenvalue_tab , 
					    double &test)
{
  if (Lanczos_dimension < vectors_to_find_number)
    {
      test = INFINITE;
      
      return;
    }

  class array<SCALAR_TYPE> diagonal_tab_small(Lanczos_dimension) , off_diagonal_tab_small(Lanczos_dimension) , eigenvalue_tab_small(Lanczos_dimension);

  diagonal_tab_small.assign (diagonal_tab);
  off_diagonal_tab_small.assign (off_diagonal_tab);

  class matrix<SCALAR_TYPE> Lanczos(Lanczos_dimension);
  symmetric::all_eigenpairs (off_diagonal_tab_small , diagonal_tab_small , Lanczos , eigenvalue_tab_small);

  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++) eigenvalue_tab(i) = eigenvalue_tab_small(i);

  test = 0.0;

  if (Lanczos_dimension < dimension) 
    {
      const unsigned int Lanczos_dimension_minus_one = Lanczos_dimension - 1;
      
      for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
	{
	  const class vector_class<SCALAR_TYPE> &eigenvector_i =  Lanczos.eigenvector(i);
	  const SCALAR_TYPE eigenvector_i_last_Lanczos_vector_overlap = eigenvector_i(Lanczos_dimension_minus_one);

	  test = max (test , inf_norm (eigenvector_i_last_Lanczos_vector_overlap));
	}
    }

  if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) cout << Lanczos_dimension << " Lanczos iterations. test:" << test << endl;
}






// Calculation of the eigenvectors of the considered matrix from the calculated Lanczos vectors
// --------------------------------------------------------------------------------------------
// One has here the diagonal and off-diagonal matrix elements of the matrix A to diagonalize in the basis of Lanczos vectors and its eigenvalues, which converge to the lowest eigenvalues of A.
// One will then calculate its associated eigenvectors by inverse iteration. As the Lanczos matrix is tridiagonal, it is very fast.
// Their phase is fixed with good_phase (see array_vector_class.hpp).
//
// Variables
// ---------
// Lanczos_dimension : current number of Lanczos vectors
// diagonal_tab : diagonal_tab(i) = <V(i) | A | V(i)>, the diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// off_diagonal_tab : off_diagonal_tab(i-1) = <V(i) | A | V(i-1)>, the off-diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// eigenvalue_tab : eigenvalues of the matrix A to diagonalize in the basis of Lanczos vectors 
// V_tab : array of the previously calculated |V(i)> Lanczos vectors
// eigenvector_tab : will contain the eigenvectors of the matrix A to diagonalize
// vectors_to_find_number : number of eigenvectors that one wants to calculate 
// diagonal_tab_small , off_diagonal_tab_small : same as diagonal_tab and off_diagonal_tab, but their dimension is Lanczos_dimension. This is necessary for the used inverse iteration routine.
// eigenvector_Lanczos : eigenvector of the matrix A to diagonalize in the basis of Lanczos vectors returned by the inverse iteration routine.
// Vii : ii-th Lanczos vector |V(ii)>

template <typename SCALAR_TYPE>
void Lanczos::lowest_eigenvectors_calc (
					const unsigned int Lanczos_dimension , 
					const class array<SCALAR_TYPE> &diagonal_tab , 
					const class array<SCALAR_TYPE> &off_diagonal_tab , 
					const class array<SCALAR_TYPE> &eigenvalue_tab , 
					const class array<class vector_class<SCALAR_TYPE> > &V_tab , 
					class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab)
{
  const unsigned int vectors_to_find_number = eigenvector_tab.dimension (0);

  class array<SCALAR_TYPE> diagonal_tab_small(Lanczos_dimension);
  
  class array<SCALAR_TYPE> off_diagonal_tab_small(Lanczos_dimension);

  diagonal_tab_small.assign (diagonal_tab);
  
  off_diagonal_tab_small.assign (off_diagonal_tab);
  
  const double minimal_eigenvalue_difference = minimal_eigenvalue_difference_determine (eigenvalue_tab);
  
  const double minimal_eigenvalue_difference_one_thousandth = minimal_eigenvalue_difference*0.001;

  class vector_class<SCALAR_TYPE> eigenvector_Lanczos_small(Lanczos_dimension);
  
  class array<SCALAR_TYPE> diagonal_tab_shifted_small(Lanczos_dimension);
      
  class array<SCALAR_TYPE> off_diagonal_work_table = off_diagonal_tab_small;
  
  class array<SCALAR_TYPE> diagonal_work_table = diagonal_tab_small;
      
  class vector_class<SCALAR_TYPE> work_vector(Lanczos_dimension);
      
  for (unsigned int i = 0 ; i < vectors_to_find_number ; i++)
    {	
      const SCALAR_TYPE &eigenvalue_i = eigenvalue_tab(i);
	  
      const double Re_eigenvalue_i = real_dc (eigenvalue_i);
	  
      const double abs_eigenvalue_shift = min (abs (Re_eigenvalue_i)*minimal_eigenvalue_difference_one_thousandth , 0.001);
      
      const double eigenvalue_shift = SIGN (Re_eigenvalue_i)*abs_eigenvalue_shift;
      
      const SCALAR_TYPE eigenvalue_shifted = eigenvalue_i + eigenvalue_shift;
  
      diagonal_tab_shifted_small = diagonal_tab_small;
      
      diagonal_tab_shifted_small -= eigenvalue_shifted;
	  
      symmetric::eigenvector_tridiagonal_calc (off_diagonal_tab_small , diagonal_tab_shifted_small , off_diagonal_work_table , diagonal_work_table , work_vector , eigenvector_Lanczos_small);

      class vector_class<SCALAR_TYPE> &eigenvector_i = eigenvector_tab(i);

      eigenvector_i = 0.0;

      for (unsigned int ii = 0 ; ii < Lanczos_dimension ; ii++) 
	{
	  class vector_class<SCALAR_TYPE> &Vii = V_tab(ii);
	  
	  eigenvector_i += eigenvector_Lanczos_small(ii)*Vii;
	} 

      eigenvector_i.good_phase ();
    }
}








// Calculation of the pivot of the Lanczos method
// ----------------------------------------------
// If it is a new calculation, is it a random pivot, normalized afterwards.
// Otherwise, if one restarts the calculation, it is the sum of the previously calculated eigenvectors, normalized afterwards.
// Indeed, the latter one is supposed to contain a large part of the exact eigenvectors.
// The pivot is then returned.
//
// Variables
// ---------
// is_it_restart :  true if it is a restarted calculation, false if not
// dimension : full matrix dimension
// eigenvector_tab : previously calculated eigenvectors of the matrix A to diagonalize
// vectors_to_find_number : number of eigenvectors that one wants to calculate
// pivot : pivot of the Lanczos method. It is returned.
// eigenvector_i : i-th previously calculated eigenvector of the matrix A to diagonalize

template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> Lanczos::pivot_calc (
						     const bool is_it_restart , 
						     const unsigned int dimension , 
						     const class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab)
{
  const unsigned int vectors_to_find_number = eigenvector_tab.dimension (0);

  class vector_class<SCALAR_TYPE> pivot(dimension);

  if (is_it_restart)
    {
      pivot = 0.0;

      for (unsigned int i = 0 ; i < vectors_to_find_number ; i++) 
	{
	  class vector_class<SCALAR_TYPE> &eigenvector_i = eigenvector_tab(i);
	  pivot += eigenvector_i;
	}
    }
  else
    {
      if (THIS_PROCESS == MASTER_PROCESS) pivot.random_vector ();
	
#ifdef UseMPI
      if (is_it_MPI_parallelized) pivot.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
    }

  pivot.normalization ();

  return pivot;
}












// Tridiagonalization of the matrix to diagonalize via the Lanczos method
// ----------------------------------------------------------------------
// The matrix A to diagonalize is hereby put to tridiagonal form with the Lanczos method.
// One starts with a pivot for the |V(0)> Lanczos vector, which is also allocated if needed.
// One calculates and stores A|V(0)> and the diagonal matrix element <V(0) | A | V(0)>.
// If the dimension of A is 1, one stops here.
// Afterwards, one loops over all the available Lanczos vectors.
//
// In this loop : 
// 
// One uses the standard formulas : 
//
// |V(1)> = A|V(0)> - <V(0) | A | V(0)> |V(0)>
//
// |V(i)> = A|V(i-1)> - <V(i-1) | A | V(i-1)> |V(i-1)> - <V(i-1) | A | V(i-2)> |V(i-2)>, i >= 2; |V(i)> is allocated at first if needed.
//
// |V(i)> is then orthogonalized with respect to the previous |V(j)>_{j < i} Lanczos vectors with the modified Gram-Schmidt method, and then normalized.
//
// One then calculates and stores <V(i) | A | V(i-1)>, A|V(i)>, <V(i) | A | V(i)>.
//
// The tridiagonalized A matrix in the basis of Lanczos vectors is then diagonalized and one checks if its eigenvectors are converged.
// If they are converged or if one has arrived to the last available Lanczos vector, one leaves the loop.
// Lanczos_dimension is put to 1 if it is still zero here, as we have at least one Lanczos vector at this point.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// is_it_restart : true if it is a restarted calculation, false if not
// is_it_sparse : true if one uses a sparse matrix for A, false if not
// eigenvector_precision : demanded precision for the eigenvectors of A calculated with the Lanczos method
// vectors_to_find_number : number of eigenvectors that one wants to calculate
// A : matrix to diagonalize (full matrix case)
// As : matrix to diagonalize (sparse matrix case)
// eigenvector_tab : previously calculated eigenvectors of the matrix A to diagonalize
// diagonal_tab : diagonal_tab(i) will be <V(i) | A | V(i)>, the diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// off_diagonal_tab : off_diagonal_tab(i-1) will be <V(i) | A | V(i-1)>, the off-diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// eigenvalue_work_tab : will contain the eigenvalues of the matrix A to diagonalize in the basis of Lanczos vectors
// V_tab : array of the |V(i)> Lanczos vectors to calculate
// Lanczos_dimension : number of Lanczos vectors which will be calculated
// test : value testing if the calculated eigenvectors with Lanczos vectors are eigenvectors of the considered matrix
//        If Lanczos dimension < dimension, it is INFINITE by definition;
//        If Lanczos dimension is the dimension of the considered A matrix, it is zero by definition;
//        As an eigenvector |Psi> = \sum_{i = 0}^{Lanczos dimension - 1} c_i |V(i)>, it is the maximal value of |c_{Lanczos dimension - 1}|oo, considering all |Psi> vectors.
// dimension : dimension of the A matrix to diagonalize
// max_dimension : maximal number of Lanczos vectors, and hence maximal dimension of the Lanczos matrix
// dummy_vector: dummy variable for a vector 
// V0 : first Lanczos vector |V(0)>
// AV: vector where A|V(i)> is stored.
// im1, im2, ip1: i-1, i-2 (NADA if i == 1) , i+1 in the loop on Lanczos vectors, for 1 <= i < max_dimension.
// Vi, Vim1, Vim2: i-th, (i-1)-th, (i-2)-th (dummy_vector if i == 1) Lanczos vectors
// Vii: previously calculated ii-th Lanczos vector with 0 <= ii < i, used to orthogonalize |V(i)> with respect to the previous Lanczos vectors.
// overlap: <V(i)|V(ii)>, with |V(i)> orthogonalized with respect to the Lanczos vectors of indices smaller than ii at this point

template <typename SCALAR_TYPE>
void Lanczos::tridiagonalization (
				  const bool is_there_cout , 
				  const bool is_it_restart , 
				  const bool is_it_sparse , 
				  const double eigenvector_precision , 
				  const unsigned int vectors_to_find_number , 
				  const class matrix<SCALAR_TYPE> &A , 
				  const class sparse_matrix<SCALAR_TYPE> &As , 
				  const class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab , 
				  class array<SCALAR_TYPE> &diagonal_tab , 
				  class array<SCALAR_TYPE> &off_diagonal_tab , 
				  class array<SCALAR_TYPE> &eigenvalue_work_tab , 
				  class array<class vector_class<SCALAR_TYPE> > &V_tab , 
				  unsigned int &Lanczos_dimension , 
				  double &test)
{
  const unsigned int dimension = (is_it_sparse) ? (As.get_dimension ()) : (A.get_dimension ());

  const unsigned int max_dimension = diagonal_tab.dimension (0);
  
  const class vector_class<SCALAR_TYPE> dummy_vector;

  class vector_class<SCALAR_TYPE> &V0 = V_tab(0);
  
  if (!V0.is_it_filled ()) V0.allocate (dimension);

  V0 = pivot_calc (is_it_restart , dimension , eigenvector_tab);

  class vector_class<SCALAR_TYPE> AV = (is_it_sparse) ? (As*V0) : (A*V0);

  diagonal_tab(0) = (V0*AV);

  if (max_dimension == 1)
    {
      eigenvalue_work_tab(0) = diagonal_tab(0);

      Lanczos_dimension = 1;
      
      return;
    }

  for (unsigned int i = 1 ; ((i < max_dimension) && (test > eigenvector_precision)) ; i++)
    {
      const unsigned int im1 = i - 1 , im2 = (i >= 2) ? (i - 2) : (NADA) , ip1 = i + 1;
      
      class vector_class<SCALAR_TYPE> &Vi = V_tab(i);
      
      if (!Vi.is_it_filled ()) Vi.allocate (dimension);

      const class vector_class<SCALAR_TYPE> &Vim1 = V_tab(im1);
      const class vector_class<SCALAR_TYPE> &Vim2 = (i >= 2) ? (V_tab(im2)) : (dummy_vector);

      if (i >= 2)
	Vi = AV - diagonal_tab(im1)*Vim1 - off_diagonal_tab(im2)*Vim2;
      else
	Vi = AV - diagonal_tab(im1)*Vim1;

      for (unsigned int ii = 0 ; ii < i ; ii++)
	{
	  const class vector_class<SCALAR_TYPE> &Vii = V_tab(ii);
	  
	  const SCALAR_TYPE overlap = (Vi*Vii);
	  
	  Vi -= overlap*Vii;
	}

      Vi.normalization ();
      
      off_diagonal_tab(im1) = (Vi*AV);
      
      AV = (is_it_sparse) ? (As*Vi) : (A*Vi);
      
      diagonal_tab(i) = (Vi*AV);
      
      Lanczos_dimension = ip1;

      Lanczos_matrix_diagonal_test (is_there_cout , dimension , vectors_to_find_number , Lanczos_dimension , diagonal_tab , off_diagonal_tab , eigenvalue_work_tab , test);
    }

  if (Lanczos_dimension == 0) Lanczos_dimension = 1;
}












// Matrix diagonalization using the Lanczos method
// -----------------------------------------------
// The first following routine is for a full A matrix and the second following routine for a sparse A matrix. They are the same otherwise.
// One loops over the number of demanded starts and a Lanczos process is launched each time to calculate the demanded eigenvectors of A (see tridiagonalization and lowest_eigenvectors_calc routines).
// For the first start, one uses a random pivot, and the normalized sum of previously calculated eigenvectors is used for restarts.  
// One leaves the loop if one has reached convergence or if all restarts have been made.
//
// Variables
// ---------
// is_there_cout : true if one prints information on screen, false if not
// N_restarts, N_restarts_plus_one: number of restarted calculations, N_restarts + 1
// eigenvector_precision : demanded precision for the eigenvectors of A calculated with the Lanczos method
// max_dimension : maximal number of Lanczos vectors, and hence maximal dimension of the Lanczos matrix
// A: matrix to diagonalize (full in the first following routine, sparse in the second following routine)
// eigenvalue_tab : will contain the eigenvalues of the matrix A to diagonalize
// eigenvector_tab : will contain the eigenvectors of the matrix A to diagonalize
// dummy_matrix: dummy variable for a matrix
// vectors_to_find_number : number of eigenvectors that one wants to calculate
// test : value testing if the calculated eigenvectors with Lanczos vectors are eigenvectors of the considered matrix
//        If Lanczos dimension < dimension, it is INFINITE by definition;
//        If Lanczos dimension is the dimension of the considered A matrix, it is zero by definition;
//        In the general case, if an eigenvector |Psi> = \sum_{i = 0}^{Lanczos dimension - 1} c_i |V(i)>, it is the maximal value of |c_{Lanczos dimension - 1}|oo, considering all |Psi> vectors.
// V_tab : array of the |V(i)> Lanczos vectors to calculate
// diagonal_tab : diagonal_tab(i) will be <V(i) | A | V(i)>, the diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// off_diagonal_tab : off_diagonal_tab(i-1) will be <V(i) | A | V(i-1)>, the off-diagonal matrix elements of the matrix A to diagonalize in the basis of |V(i)> Lanczos vectors
// is_it_restart : true if it is a restarted calculation, false if not
// Lanczos_dimension : current number of Lanczos vectors


template <typename SCALAR_TYPE>
void Lanczos::iterative_diagonalization_lowest_states (
						       const bool is_there_cout , 
						       const unsigned int N_restarts , 
						       const double eigenvector_precision , 
						       const unsigned int max_dimension , 
						       const class matrix<SCALAR_TYPE> &A , 
						       class array<SCALAR_TYPE> &eigenvalue_tab , 
						       class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab)
{	
  const class sparse_matrix<SCALAR_TYPE> dummy_matrix;
  
  const unsigned int vectors_to_find_number = eigenvector_tab.dimension (0);

  const unsigned int N_restarts_plus_one = N_restarts + 1;
  
  double test = INFINITE;

  class array<class vector_class<SCALAR_TYPE> > V_tab(max_dimension);

  class array<SCALAR_TYPE> diagonal_tab(max_dimension) , off_diagonal_tab(max_dimension);

  for (unsigned int r = 0 ; ((r < N_restarts_plus_one) && (test > eigenvector_precision)) ; r++)
    {
      const bool is_it_restart = (r > 0);

      unsigned int Lanczos_dimension = 0;

      tridiagonalization (is_there_cout , is_it_restart , false , eigenvector_precision , vectors_to_find_number ,
			  A , dummy_matrix , eigenvector_tab , diagonal_tab , off_diagonal_tab , eigenvalue_tab , V_tab , Lanczos_dimension , test);

      lowest_eigenvectors_calc (Lanczos_dimension , diagonal_tab , off_diagonal_tab , eigenvalue_tab , V_tab , eigenvector_tab);
      
      if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) cout << endl;
    }
}







template <typename SCALAR_TYPE>
void Lanczos::iterative_diagonalization_lowest_states (
						       const bool is_there_cout , 
						       const unsigned int N_restarts , 
						       const double eigenvector_precision , 
						       const unsigned int max_dimension , 
						       const class sparse_matrix<SCALAR_TYPE> &A , 
						       class array<SCALAR_TYPE> &eigenvalue_tab , 
						       class array<class vector_class<SCALAR_TYPE> > &eigenvector_tab)
{
  const class matrix<SCALAR_TYPE> dummy_matrix;

  const unsigned int vectors_to_find_number = eigenvector_tab.dimension (0);
  
  const unsigned int N_restarts_plus_one = N_restarts + 1;

  double test = INFINITE;

  class array<class vector_class<SCALAR_TYPE> > V_tab(max_dimension);

  class array<SCALAR_TYPE> diagonal_tab(max_dimension) , off_diagonal_tab(max_dimension);

  for (unsigned int r = 0 ; ((r < N_restarts_plus_one) && (test > eigenvector_precision)) ; r++)
    {
      const bool is_it_restart = (r > 0);

      unsigned int Lanczos_dimension = 0;

      tridiagonalization (is_there_cout , is_it_restart , true , eigenvector_precision , vectors_to_find_number , dummy_matrix ,
			  A , eigenvector_tab , diagonal_tab , off_diagonal_tab , eigenvalue_tab , V_tab , Lanczos_dimension , test);

      lowest_eigenvectors_calc (Lanczos_dimension , diagonal_tab , off_diagonal_tab , eigenvalue_tab , V_tab , eigenvector_tab);

      if (is_there_cout && (THIS_PROCESS == MASTER_PROCESS)) cout << endl;
    }
}











#endif
