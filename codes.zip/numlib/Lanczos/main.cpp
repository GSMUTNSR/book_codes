#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

void full_matrix_test (
		       const bool is_there_cout , 
		       const double vector_solution_precision , 
		       const unsigned int N_restarts , 
		       const unsigned int N , 
		       const unsigned int eigenvector_number , 
		       const double max_dimension)
{
  class matrix<complex<double> > M(N);

  M.random_matrix ();

  M *= complex<double> (1 , 0.1);

  for (unsigned int i = 0 ; i < N ; i++) M(i , i) += complex<double> (i%100+1 , 1) + random_number<double> ();

  M /= M.infinite_norm ();

  M.symmetrize ();

  class array<complex<double> > eigenvalue_tab(eigenvector_number);

  class array<class vector_class<complex<double> > > eigenvector_tab(eigenvector_number);

  for (unsigned int i = 0 ; i < eigenvector_number ; i++) eigenvector_tab(i).allocate (N);

  Lanczos::iterative_diagonalization_lowest_states (is_there_cout , N_restarts , vector_solution_precision , max_dimension , M , eigenvalue_tab , eigenvector_tab);

  cout << endl;
  
  for (unsigned int i = 0 ; i < eigenvector_number ; i++)
    {
      const complex<double> &eigenvalue = eigenvalue_tab(i);

      const class vector_class<complex<double> > &eigenvector = eigenvector_tab(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      cout << "i:" << i << " eigenvalue:" << eigenvalue << " |A.V - E.V|oo:" << Res.infinite_norm () << endl;
    }
}





void sparse_matrix_test (
			 const bool is_there_cout , 
			 const double vector_solution_precision , 
			 const unsigned int N_restarts , 
			 const unsigned int N , 
			 const unsigned int eigenvector_number , 
			 const double zero_probability ,
			 const double max_dimension)
{
  class matrix<complex<double> > M_full(N);
  
  M_full.symmetric_random_matrix ();

  M_full.put_zeros_symmetrically_with_probability (zero_probability);
    
  for (unsigned int i = 0 ; i < N ; i++) M_full(i , i) += complex<double> (i + 1 , 1) + random_number<double> ();
  
  class sparse_matrix<complex<double> > M = M_full;
    
  M *= complex<double> (1 , 0.1);

  M /= M.infinite_norm ();

  class array<complex<double> > eigenvalue_tab(eigenvector_number);

  class array<class vector_class<complex<double> > > eigenvector_tab(eigenvector_number);

  for (unsigned int i = 0 ; i < eigenvector_number ; i++) eigenvector_tab(i).allocate (N);

  Lanczos::iterative_diagonalization_lowest_states (is_there_cout , N_restarts , vector_solution_precision , max_dimension , M , eigenvalue_tab , eigenvector_tab);

  cout << endl;
  
  for (unsigned int i = 0 ; i < eigenvector_number ; i++)
    {
      const complex<double> &eigenvalue = eigenvalue_tab(i);

      const class vector_class<complex<double> > &eigenvector = eigenvector_tab(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      cout << "i:" << i << " eigenvalue:" << eigenvalue << " |A.V - E.V|oo:" << Res.infinite_norm () << endl;
    }
}






#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();

    const unsigned int N_restarts = 5;

    const unsigned int N = 200;

    const unsigned int eigenvector_number = 3;

    const double vector_solution_precision = 1E-7;

    const double max_dimension = 70;

    const double zero_probability = 0.01;

    cout.precision (15);

    seed ();

    cout << endl << "is_there_cout = true" << endl;

    cout << endl << "full matrix test" << endl;

    full_matrix_test (true , vector_solution_precision , N_restarts , N , eigenvector_number , max_dimension);

    cout << endl << "sparse matrix test" << endl;

    sparse_matrix_test (true , vector_solution_precision , N_restarts , N , eigenvector_number , zero_probability , max_dimension);	

    cout << endl << "is_there_cout = false" << endl;

    cout << endl << "full matrix test" << endl;

    full_matrix_test (false , vector_solution_precision , N_restarts , N , eigenvector_number , max_dimension);

    cout << endl << "sparse matrix test" << endl;

    sparse_matrix_test (false , vector_solution_precision , N_restarts , N , eigenvector_number , zero_probability , max_dimension);	

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
