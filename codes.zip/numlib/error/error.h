#ifndef YANNENERROR_H
#define YANNENERROR_H




/*-----------------*/
/* Error namespace */
/*----------------------------------------------------------------------------*/

namespace error {
  void abort ();
  void abort (const string &message);
  void abort2 (const string &message);
}



#endif
