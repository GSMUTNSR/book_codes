#include "../numlib_def/numlib_def.h"




/*--------------------------*/
/* Namespace error routines */
/*----------------------------------------------------------------------------*/

/* Abort */
void error::abort ()
{
#ifdef UseMPI
  MPI_helper::Abort();
#else
  std::abort();
#endif
}



/* Abort and print error message */
void error::abort (const string &message)
{
#ifdef UseMPI
  usleep(1000*THIS_PROCESS);
  cerr << "MPI process:" << THIS_PROCESS << " " << message << endl;
#else
  cerr << message << endl;
#endif
  error::abort();
}

/* Abort and print error message */
void error::abort2 (const string &message)
{
#ifdef UseMPI
  usleep(1000*THIS_PROCESS);
  cerr<<endl<<endl;
  cerr<<"--------------------------------------------------------------------------------"<<endl;
  cerr<<" MPI process:"<<THIS_PROCESS<<". "<<message<<endl;
  cerr<<"--------------------------------------------------------------------------------"<<endl;
  cerr<<endl;
#else
  cerr<<endl<<endl;
  cerr<<"--------------------------------------------------------------------------------"<<endl;
  cerr<<" "<<message<<endl;
  cerr<<"--------------------------------------------------------------------------------"<<endl;
  cerr<<endl;
#endif
  abort();
}
