#include "../numlib_def/numlib_def.h"


// Jacobi polynomial
// ------------------ - 
// The following recurrence relation is used :
// c(i).P(i+1, x) = (d(i) + e(i).x).x.P(i, x) - f(i).P(i-1, x) for i > 0, where:
//
// c(i) = 2.(i + 1).(i + alpha + beta + 1).(2.i + alpha + beta)
// d(i) = (2.i + alpha + beta + 1).(alpha^2 − beta^2)
// e(i) = (2.i + alpha + beta).(2.i + alpha + beta + 1).(2.i + alpha + beta + 2)
// f(i) = 2.(i + alpha).(i + beta).(2.i + alpha + beta + 2)
//
// P(0, x) = 1. This value is directly returned if the degree of the polynomial is 0.
//
// Variable
// --------
// degree : degree of the Jacobi polynomial
// alpha, beta: parameters of the Jacobi polynomials
// x : variable of the Jacobi polynomial
// i, poly_im1, poly_i, poly_ip1 : Jacobi polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// two_alpha, alpha_plus_beta, alpha_square_minus_beta_square: 2.alpha , alpha + beta, alpha^2 − beta^2
//
// two_i, ip1, two_ip1, two_i_plus_alpha_plus_beta, two_i_plus_alpha_plus_beta_plus_one, two_i_plus_alpha_plus_beta_plus_two :
// 2.i, i+1, 2(i+1), (2.i+ alpha + beta), (2.i + alpha + beta + 1), (2.i + alpha + beta + 2)
//
// ci, di, ei, fi: coefficients c(i), d(i), e(i), f(i) (see above)
// di_plus_ei_x : d(i) + e(i).x

double Gauss_Jacobi::poly (const int degree , const double alpha , const double beta , const double x)
{
  if (degree == 0) return 1.0; 

  const double alpha_plus_beta = alpha + beta;
  
  const double two_alpha = 2.0*alpha;
      
  const double alpha_square_minus_beta_square = alpha*alpha - beta*beta;

  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = 0.5*(alpha - beta + (2.0 + alpha_plus_beta)*x);

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double two_i = 2 * i;
	  
      const double two_ip1 = 2 * ip1;

      const double two_i_plus_alpha_plus_beta = two_i + alpha_plus_beta;
	  
      const double two_i_plus_alpha_plus_beta_plus_one = two_i_plus_alpha_plus_beta + 1;
      const double two_i_plus_alpha_plus_beta_plus_two = two_i_plus_alpha_plus_beta + 2;
	  
      const double ci = two_ip1*(ip1 + alpha_plus_beta)*two_i_plus_alpha_plus_beta;
  
      const double di = two_i_plus_alpha_plus_beta_plus_one*alpha_square_minus_beta_square;

      const double ei = two_i_plus_alpha_plus_beta*two_i_plus_alpha_plus_beta_plus_one*two_i_plus_alpha_plus_beta_plus_two;

      const double fi = (two_i + two_alpha)*(i + beta)*two_i_plus_alpha_plus_beta_plus_two;
	  
      const double di_plus_ei_x = di + ei*x;
	  
      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_ip1 = (di_plus_ei_x*poly_i - fi*poly_im1)/ci;
    }

  return poly_ip1;
}








// Derivative of the Jacobi polynomial
// --------------------------------------
// The following recurrence relations are used :
// c(i).P(i+1, x) = (d(i) + e(i).x).P(i, x) - f(i).P(i-1, x) for i > 0,
// c(i).P'(i+1, x) = (d(i) + e(i).x).P'(i, x) - f(i).P'(i-1, x) + e(i).P(i, x) for i > 0,
//
// where:
//
// c(i) = 2(i + 1).(i + alpha + beta + 1)(2.i + alpha + beta)
// d(i) = (2.i + alpha + beta + 1).(alpha^2 − beta^2)
// e(i) = (2.i + alpha + beta).(2.i + alpha + beta + 1).(2.i + alpha + beta + 2)
// f(i) = 2(i + alpha).(i + beta).(2.i + alpha + beta + 2)
//
// P'(0, x) = 0. This value is directly returned if the degree of the polynomial is 0.
//
// I do not use the formula P'(i,x) = (i.(alpha - beta - (2.i + alpha + beta).x).P(i,x) + 2.(i + alpha).(i + beta).P(i-1,x))/(2.i + alpha + beta.(1.0 - x^2)) for i > 0
// as it is unstable for 2.i + alpha + beta.(1.0 - x^2) ~ 0.
//
// Variable
// --------
// degree : degree of the Jacobi polynomial
// alpha, beta: parameters of the Jacobi polynomials
// x : variable of the Jacobi polynomial
// i, poly_im1, poly_i, poly_ip1 : Jacobi polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// two_alpha , alpha_plus_beta, alpha_square_minus_beta_square, two_degree_plus_alpha_plus_beta: 2.alpha, alpha - beta, alpha + beta, alpha^2 − beta^2, 2.degree + alpha + beta
//
// two_i, ip1, two_ip1, two_i_plus_alpha_plus_beta, two_i_plus_alpha_plus_beta_plus_one, two_i_plus_alpha_plus_beta_plus_two :
// 2.i, i+1, 2(i+1), (2.i+ alpha + beta), (2.i + alpha + beta + 1), (2.i + alpha + beta + 2)
//
// ci, di, ei, fi: coefficients c(i), d(i), e(i), f(i) (see above)
// di_plus_ei_x : d(i) + e(i).x


double Gauss_Jacobi::poly_der (const int degree , const double alpha , const double beta , const double x)
{
  if (degree == 0) return 0.0;
  
  const double alpha_plus_beta = alpha + beta;
  
  const double two_alpha = 2.0*alpha;
      
  const double alpha_square_minus_beta_square = alpha*alpha - beta*beta;
      
  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = 0.5*(alpha - beta + (2.0 + alpha_plus_beta)*x);
      
  double poly_der_im1 = 0.0;

  double poly_der_i = 0.0;

  double poly_der_ip1 = 1.0 + 0.5*alpha_plus_beta;

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double two_i = 2 * i;
	  
      const double two_ip1 = 2 * ip1;

      const double two_i_plus_alpha_plus_beta = two_i + alpha_plus_beta;
	  
      const double two_i_plus_alpha_plus_beta_plus_one = two_i_plus_alpha_plus_beta + 1;
      const double two_i_plus_alpha_plus_beta_plus_two = two_i_plus_alpha_plus_beta + 2;
	  
      const double ci = two_ip1*(ip1 + alpha_plus_beta)*two_i_plus_alpha_plus_beta;
  
      const double di = two_i_plus_alpha_plus_beta_plus_one*alpha_square_minus_beta_square;

      const double ei = two_i_plus_alpha_plus_beta*two_i_plus_alpha_plus_beta_plus_one*two_i_plus_alpha_plus_beta_plus_two;

      const double fi = (two_i + two_alpha)*(i + beta)*two_i_plus_alpha_plus_beta_plus_two;
	  
      const double di_plus_ei_x = di + ei*x;
	  
      poly_im1 = poly_i;
	  
      poly_der_im1 = poly_der_i;

      poly_i = poly_ip1;
	  
      poly_der_i = poly_der_ip1;
	  
      poly_ip1 = (di_plus_ei_x*poly_i - fi*poly_im1)/ci;
	  
      poly_der_ip1 = (di_plus_ei_x*poly_der_i - fi*poly_der_im1 + ei*poly_i)/ci;
    }
 
  return poly_der_ip1;
}




// Polynomial and derivative of the Jacobi polynomial of order degree and degree - 1
// -----------------------------------------------------------------------------------
// The following recurrence relation is used :
// c(i).P(i+1, x) = (d(i) + e(i).x).x.P(i, x) - f(i).P(i-1, x) for i > 0,
// P'(i,x) = (i.(alpha - beta - (2.i + alpha + beta).x).P(i,x) + 2.(i + alpha).(i + beta).P(i-1,x))/(2.i + alpha + beta.(1.0 - x^2)) for i > 0
//
// where:
//
// c(i) = 2(i + 1).(i + alpha + beta + 1)(2.i + alpha + beta)
// d(i) = (2.i + alpha + beta + 1).(alpha^2 − beta^2)
// e(i) = (2.i + alpha + beta).(2.i + alpha + beta + 1).(2.i + alpha + beta + 2)
// f(i) = 2(i + alpha).(i + beta).(2.i + alpha + beta + 2)
//
// P(0,x) = 1
// P'(0, x) = 0
//
// I do not use the formula P'(i,x) = (i.(alpha - beta - (2.i + alpha + beta).x).P(i,x) + 2.(i + alpha).(i + beta).P(i-1,x))/(2.i + alpha + beta.(1.0 - x^2)) for i > 0
// as it is unstable for 2.i + alpha + beta.(1.0 - x^2) ~ 0.
//
// Variable
// --------
// degree : degree of the Jacobi polynomial
// alpha, beta: parameters of the Jacobi polynomials
// x : variable of the Jacobi polynomial
// i, poly_im1, poly_i, poly_ip1 : Jacobi polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// two_alpha: 2.alpha
// alpha_minus_beta, alpha_plus_beta, alpha_square_minus_beta_square, two_degree_plus_alpha_plus_beta: alpha - beta, alpha + beta, alpha^2 − beta^2, 2.degree + alpha + beta
//
// two_i, ip1, two_ip1, two_i_plus_alpha_plus_beta, two_i_plus_alpha_plus_beta_plus_one, two_i_plus_alpha_plus_beta_plus_two :
// 2.i, i+1, 2(i+1), (2.i+ alpha + beta), (2.i + alpha + beta + 1), (2.i + alpha + beta + 2)
//
// ci, di, ei, fi: coefficients c(i), d(i), e(i), f(i) (see above)
// di_plus_ei_x : d(i) + e(i).x;
// P_lower: Jacobi polynomial of order degree - 1 to calculate
// P, dP: Jacobi polynomial and derivative of order degree to calculate

void Gauss_Jacobi::P_lower_P_dP (
				 const int degree ,
				 const double alpha ,
				 const double beta ,
				 const double x ,
				 double &P_lower ,
				 double &P ,
				 double &dP)
{  
  if (degree == 0) error_message_print_abort ("Gauss_Jacobi::P_lower_P_dP undefined for degree = 0");

  const double alpha_plus_beta = alpha + beta;
      
  const double two_alpha = 2.0*alpha;
  
  const double alpha_square_minus_beta_square = alpha*alpha - beta*beta;
      
  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = 0.5*(alpha - beta + (2.0 + alpha_plus_beta)*x);

  double poly_der_im1 = 0.0;

  double poly_der_i = 0.0;

  double poly_der_ip1 = 1.0 + 0.5*alpha_plus_beta;
      
  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double two_i = 2 * i;
	  
      const double two_ip1 = 2 * ip1;

      const double two_i_plus_alpha_plus_beta = two_i + alpha_plus_beta;
	  
      const double two_i_plus_alpha_plus_beta_plus_one = two_i_plus_alpha_plus_beta + 1;
      const double two_i_plus_alpha_plus_beta_plus_two = two_i_plus_alpha_plus_beta + 2;
	  
      const double ci = two_ip1*(ip1 + alpha_plus_beta)*two_i_plus_alpha_plus_beta;
  
      const double di = two_i_plus_alpha_plus_beta_plus_one*alpha_square_minus_beta_square;

      const double ei = two_i_plus_alpha_plus_beta*two_i_plus_alpha_plus_beta_plus_one*two_i_plus_alpha_plus_beta_plus_two;

      const double fi = (two_i + two_alpha)*(i + beta)*two_i_plus_alpha_plus_beta_plus_two;
	  
      const double di_plus_ei_x = di + ei*x;
	  
      poly_im1 = poly_i;
	  
      poly_der_im1 = poly_der_i;

      poly_i = poly_ip1;
	  
      poly_der_i = poly_der_ip1;
	  
      poly_ip1 = (di_plus_ei_x*poly_i - fi*poly_im1)/ci;
	  
      poly_der_ip1 = (di_plus_ei_x*poly_der_i - fi*poly_der_im1 + ei*poly_i)/ci;
    }

  P_lower = poly_i;
      
  P = poly_ip1;
      
  dP = poly_der_ip1;
}



// Calculation of the abscissas and weights of the Gauss-Jacobi quadrature
// ---------------------------------------------------------------------------
// These are the abscissas and weights of the Gauss-Jacobi quadrature on ]-1:1[.
// I use the Golub-Welsch method as it is more stable than the Numerical Recipes method for large N, alpha, beta.
// Moreover, the Golub-Welsch method is as good for small or moderate values of N, alpha, beta and even comparable in speed, as it is slower by only 20% - 30% typically.
// Also, only eigenvalues are needed, as there is a closed form formula for weights when the root is known.
// Refinement of roots with the Newton method is done to be sure to have maximal precision.
// Polynomials overflow typically where integrands are negligible. Weights are then put to zero therein.
// If alpha + beta is an integer, the method can be unstable as one can have zeros appearing in denominators or on the diagonal of the Jacobi matrix.
// Hence, alpha is changed by about 10^(-13) for alpha + beta not to be an integer. 
// It does not matter afterwards as one uses the Newton method on roots.
//
// The routine has been tested successfully for N <= 1000 and alpha, beta ~ 100.
//
// Variables
// -------- - 
// N : number of points in the Gauss-Jacobi quadrature
//
// one_over_N: 1/N
// alpha, beta: parameters of the Jacobi polynomials
// alpha_plus_beta : alpha + beta
// x_table : table of Gauss-Jacobi abscissas.
// w_table : table of Gauss-Jacobi weights.
// debut, end : limits of the integral.
// count : The Newton method stops if count >= 5 as starting points are close to their exact value.
// P_lower: Laguerre polynomial of order N-1
// P, dP, ratio: Jacobi polynomial and derivative, P/dP
// a_table, sqrt_b_table: arrays of a[i] and sqrt(b[i]) for the Golub-Welsch matrix
// xi, wi : i-th root of the Jacobi polynomial and its weight. xi is refined with the Newton method. A precision of 1e-16 is demanded.
// alpha_mod: alpha.(1 + 10^(-13)) + 10^(-13) if alpha + beta is an integer, alpha if not. The second 10^(-13) is included in case alpha ~ 0.
// two_alpha_mod, alpha_plus_beta_mod, alpha_square_minus_beta_square_mod: 2.alpha_mod , alpha_mod + beta, alpha_mod^2 − beta^2
//
// two_i, im1, two_im1, two_i_plus_alpha_plus_beta_mod, two_i_plus_alpha_plus_beta_plus_one_mod, two_i_plus_alpha_plus_beta_plus_two_mod
// two_im1_plus_alpha_plus_beta_mod, two_im1_plus_alpha_plus_beta_plus_one_mod, two_im1_plus_alpha_plus_beta_plus_two_mod :
// 2.i, i-1, 2(i-1), (2.i+ alpha_mod + beta), (2.i + alpha_mod + beta + 1), (2.i + alpha_mod + beta + 2), (2.(i-1)+ alpha_mod + beta),
// (2.(i-1) + alpha_mod + beta + 1), (2.(i-1) + alpha_mod + beta + 2), 
//
// d0, e0, ci, di, ei, fi, c_im1, e_im1: coefficients d(0), e(0), c(i), d(i), e(i), f(i), c(i-1), e(i-1) (see above)

void Gauss_Jacobi::abscissas_weights_tables_calc (
						  const double alpha ,
						  const double beta , 
						  class array<double> &x_table , 
						  class array<double> &w_table)
{    
  const unsigned int N = x_table.dimension (0);

  if (N == 0) return;
      
  if (alpha <= -1.0) error_message_print_abort ("One has to have alpha > -1 in Gauss_Jacobi::abscissas_weights_tables_calc for integrals to converge");
  if (beta  <= -1.0) error_message_print_abort ("One has to have beta > -1 in Gauss_Jacobi::abscissas_weights_tables_calc for integrals to converge");
  
  const double alpha_plus_beta = alpha + beta;
      
  const double weight_factor = exp (lgamma (alpha + N) + lgamma (beta + N) - lgamma (N + 1.0) - lgamma (N + alpha_plus_beta + 1.0))*(2*N + alpha_plus_beta)*pow (2.0 , alpha_plus_beta);
 
  const double alpha_mod = (abs (alpha_plus_beta - make_int (alpha_plus_beta)) < 1E-13) ? (alpha*(1.0 + 1E-13) + 1E-13) : (alpha);
      
  const double two_alpha_mod = 2.0*alpha_mod;
  
  const double alpha_plus_beta_mod = alpha_mod + beta;
  
  const double alpha_square_minus_beta_square_mod = alpha_mod*alpha_mod - beta*beta;
  
  const unsigned int Nm1 = N - 1;
    
  class array<double> a_table(N);

  class array<double> sqrt_b_table(Nm1);
  	  
  const double d0 = (alpha_plus_beta_mod + 1.0)*alpha_square_minus_beta_square_mod;
      
  const double e0 = alpha_plus_beta_mod*(alpha_plus_beta_mod + 1.0)*(alpha_plus_beta_mod + 2.0);
	  
  a_table(0) = -d0/e0;
	  
  w_table = 0.0;

  for (unsigned int i = 1 ; i < N ; i++)
    {
      const double two_im1 = 2 * (i - 1);
	  
      const double two_i = 2 * i;

      const double two_i_plus_alpha_plus_beta_mod = two_i + alpha_plus_beta_mod;
	  
      const double two_i_plus_alpha_plus_beta_mod_plus_one = two_i_plus_alpha_plus_beta_mod + 1;
      const double two_i_plus_alpha_plus_beta_mod_plus_two = two_i_plus_alpha_plus_beta_mod + 2;
	  
      const double two_im1_plus_alpha_plus_beta_mod = two_im1 + alpha_plus_beta_mod;
	  
      const double two_im1_plus_alpha_plus_beta_mod_plus_one = two_im1_plus_alpha_plus_beta_mod + 1;
      const double two_im1_plus_alpha_plus_beta_mod_plus_two = two_im1_plus_alpha_plus_beta_mod + 2;
	  
      const double c_im1 = two_i*(i + alpha_plus_beta_mod)*two_im1_plus_alpha_plus_beta_mod;
  
      const double e_im1 = two_im1_plus_alpha_plus_beta_mod*two_im1_plus_alpha_plus_beta_mod_plus_one*two_im1_plus_alpha_plus_beta_mod_plus_two;
	  
      const double di = two_i_plus_alpha_plus_beta_mod_plus_one*alpha_square_minus_beta_square_mod;

      const double ei = two_i_plus_alpha_plus_beta_mod*two_i_plus_alpha_plus_beta_mod_plus_one*two_i_plus_alpha_plus_beta_mod_plus_two;

      const double fi = (two_i + two_alpha_mod)*(i + beta)*two_i_plus_alpha_plus_beta_mod_plus_two;

      a_table(i) = -di/ei;

      sqrt_b_table(i - 1) = sqrt (abs ((c_im1/e_im1)*(fi/ei)));
    }
    
  total_diagonalization::symmetric::all_eigenvalues (sqrt_b_table , a_table , x_table);
            
  for (unsigned int i = 0 ; i < N ; i++) 
    {
      double &xi = x_table(i);

      unsigned int count = 0;

      double P_lower = 0.0;
      
      double P = 0.0;
 
      double dP = 0.0;

      double ratio = 1.0;
 
      while ((abs (ratio) > 1E-16) && (count++ < 5))
	{
	  P_lower_P_dP (N , alpha , beta , xi , P_lower , P , dP);

	  ratio = P/dP;

	  if (finite (ratio))
	    xi -= ratio;
	  else
	    break;
	}
      
      x_table(i) = xi;
 
      const double wi = weight_factor/(dP*P_lower);
	    
      if (finite (wi)) w_table(i) = wi;
    }
}



