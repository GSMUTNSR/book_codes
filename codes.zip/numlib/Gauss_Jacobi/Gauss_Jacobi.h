#ifndef GAUSS_JACOBI_H
#define GAUSS_JACOBI_H

namespace Gauss_Jacobi
{
  double poly (
	       const int degree ,
	       const double alpha ,
	       const double beta ,
	       const double x);

  double poly_der (
		   const int degree ,
		   const double alpha ,
		   const double beta ,
		   const double x);

  void P_lower_P_dP (
		     const int degree ,
		     const double alpha ,
		     const double beta ,
		     const double x ,
		     double &P_lower ,
		     double &P ,
		     double &dP);
  
  void abscissas_weights_tables_calc (
				      const double alpha ,
				      const double beta , 
				      class array<double> &x_table , 
				      class array<double> &w_table);
}

#endif

