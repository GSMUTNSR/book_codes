#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;





#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#endif

    OpenMP_initialization ();

    cout.precision (8);

    const unsigned int N = 100;

    class array<double> x_tab(N);
    class array<double> w_tab(N);
    
    cout << "Gauss-Jacobi is tested with Gauss-Legendre (GL) (alpha = beta = 0) and Gauss-Chebyshev of first and second kind (GC1, GC2, alpha = beta = -/+ 1/2)" << endl << endl;

    for (unsigned int n = 1 ; n <= N ; n++)
      {
	class array<double> x_tab_GL(n) , x_tab_GC1(n) , x_tab_GC2(n) , x_tab_GJ_GL(n) , x_tab_GJ_GC1(n) , x_tab_GJ_GC2(n);
	class array<double> w_tab_GL(n) , w_tab_GC1(n) , w_tab_GC2(n) , w_tab_GJ_GL(n) , w_tab_GJ_GC1(n) , w_tab_GJ_GC2(n);

	Gauss_Legendre::abscissas_weights_tables_calc (-1.0 , 1.0 , x_tab_GL , w_tab_GL);
	
	Gauss_Chebyshev::abscissas_weights_tables_calc (1 , x_tab_GC1 , w_tab_GC1);
	Gauss_Chebyshev::abscissas_weights_tables_calc (2 , x_tab_GC2 , w_tab_GC2);

	Gauss_Jacobi::abscissas_weights_tables_calc ( 0   ,  0   , x_tab_GJ_GL  , w_tab_GJ_GL);
	Gauss_Jacobi::abscissas_weights_tables_calc (-0.5 , -0.5 , x_tab_GJ_GC1 , w_tab_GJ_GC1);
	Gauss_Jacobi::abscissas_weights_tables_calc ( 0.5 ,  0.5 , x_tab_GJ_GC2 , w_tab_GJ_GC2);

	const class array<double> test_x_array_GL  = x_tab_GJ_GL  - x_tab_GL;
	const class array<double> test_w_array_GL  = w_tab_GJ_GL  - w_tab_GL;
	const class array<double> test_x_array_GC1 = x_tab_GJ_GC1 - x_tab_GC1;
	const class array<double> test_w_array_GC1 = w_tab_GJ_GC1 - w_tab_GC1;
	const class array<double> test_x_array_GC2 = x_tab_GJ_GC2 - x_tab_GC2;
	const class array<double> test_w_array_GC2 = w_tab_GJ_GC2 - w_tab_GC2;
	
	double test_GL = 0.0;
	double test_GC1 = 0.0;
	double test_GC2 = 0.0;

	for (unsigned int i = 0 ; i < n ; i++)
	  {
	    test_GL  = max (test_GL  , abs (test_x_array_GL(i)));
	    test_GL  = max (test_GL  , abs (test_w_array_GL(i)));
	    test_GC1 = max (test_GC1 , abs (test_x_array_GC1(i)));
	    test_GC1 = max (test_GC1 , abs (test_w_array_GC1(i)));
	    test_GC2 = max (test_GC2 , abs (test_x_array_GC2(i)));
	    test_GC2 = max (test_GC2 , abs (test_w_array_GC2(i)));
	  }
		
	cout << "Number of points : " << n << "   test[GL] : " << test_GL << "   test[GC1] : " << test_GC1 << "   test[GC2] : " << test_GC2 << endl;

	if (test_GL  > precision) error_message_print_abort ("Problem with Gauss-Legendre");
	if (test_GC1 > precision) error_message_print_abort ("Problem with Gauss-Chebyshev of first kind");
	if (test_GC2 > precision) error_message_print_abort ("Problem with Gauss-Chebyshev of second kind");
      }

    cout.precision (15);
    
    const unsigned int N_GL = 50;
    
    const unsigned int N_GC = 50;
    
    class array<double> x_tab_GL(N_GL);
    class array<double> w_tab_GL(N_GL);

    Gauss_Legendre::abscissas_weights_tables_calc (-1.0 , 1.0 , x_tab_GL , w_tab_GL);

    cout << endl;

    cout << "cos (x) (1-x)^alpha (1+x)^beta is integrated with Gauss-Jacobi with alpha, beta positive integers." << endl;
    
    cout << "Gauss-Legendre integration with " << N_GL << " points provides with a quasi-exact integral." << endl << endl;
    
    cout << "Gauss-Jacobi number of points   Gauss-Jacobi integral   Gauss-Legendre integral    test"  << endl << endl;

    const unsigned int max_integer = 100;

    seed ();
    
    const int alpha = rand_int (max_integer);
    const int beta = rand_int (max_integer);    
	  
    cout << "alpha = " << alpha << "     beta = " << beta << endl << endl;
	    
    double integral_GL = 0.0;

    for (unsigned int i = 0 ; i < N_GL ; i++)
      {
	const double x = x_tab_GL(i);
	const double w = w_tab_GL(i);
	      
	integral_GL += pow (1.0 - x , alpha)*pow (1.0 + x , beta)*cos (x)*w;
      }
	      
    for (unsigned int n = 1 ; n <= N_GC ; n++)
      {
	class array<double> x_tab_GJ(n);
	class array<double> w_tab_GJ(n);

	Gauss_Jacobi::abscissas_weights_tables_calc (alpha , beta , x_tab_GJ , w_tab_GJ);
	      
	double integral_GJ = 0.0;
	      
	for (unsigned int i = 0 ; i < n ; i++) integral_GJ += cos (x_tab_GJ(i))*w_tab_GJ(i);
	      
	cout << n << "   " << integral_GJ << "   " << integral_GL << "   " << inf_norm (integral_GJ/integral_GL - 1.0) << endl;
      }
    
    cout.precision (8);
    
    cout << endl << "L(n,alpha,beta,x) and L'(n,alpha,beta,x) test from a standard relation" << endl << endl;
  
    seed ();
    
    for (int n = 1 ; n <= 10 ; n++)
      {
	const double alpha = random_number<double> ();
      
	const double beta = random_number<double> ();
      
	const double x = random_number<double> ();

	const double L_nm1_x = Gauss_Jacobi::poly (n-1 , alpha , beta , x);
      
	const double Ln_x = Gauss_Jacobi::poly (n , alpha , beta , x);
	
	const double Ln_der_x = Gauss_Jacobi::poly_der (n , alpha , beta , x);

	const double Ln_der_x_relation = (n*(alpha - beta - (2*n + alpha + beta)*x)*Ln_x + 2.0*(n + alpha)*(n + beta)*L_nm1_x)/((2*n + alpha + beta)*(1.0 - x*x));

	double L_nm1_x_test , Ln_x_test , Ln_der_x_test;

	Gauss_Jacobi::P_lower_P_dP (n , alpha , beta , x , L_nm1_x_test , Ln_x_test , Ln_der_x_test);

	if (abs (L_nm1_x - L_nm1_x_test) + abs (Ln_x - Ln_x_test) + abs (Ln_der_x - Ln_der_x_test) > 1E-12) error_message_print_abort ("Problem with Gauss-Jacobi polynomials and/or derivatives"); 
  
	const double test = inf_norm (Ln_der_x_relation/Ln_der_x - 1.0);
	
	cout << "n:" << n << "   alpha : " << alpha << "   beta : " << beta << "   x : " << x << "   L(n,x) : " << Ln_x << "   L'(n,x) : " << Ln_der_x << "   test : " << test << endl;
      }
  
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

