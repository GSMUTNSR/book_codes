#ifndef CONST_H
#define CONST_H





// all constant values in the code

// dummy variable
const int NADA = 666;

//arbitrary maximal angular momentum
const int INFINITE_J = 65535;

const unsigned short int OUT_OF_CONFIGURATION = 65535;
const unsigned short int OUT_OF_RANGE = 65535;
const unsigned int INFINITE_PAIR_INDEX = 4294967295;  
const unsigned int INFINITE_INDEX = 4294967295;  
const unsigned int NO_VALENCE_NUCLEONS = 65535;  

//maximal number of closure terms for GSM vector operators
const unsigned int CLOSURE_TERMS_MAX = 10;

const double precision = 1E-10;
const double sqrt_precision = 1E-5;
const double SMALL = 1E-300;
const double INFINITE = 1E300;
const double SQRT_SMALL = 1E-150;
const double SQRT_INFINITE = 1E150;

// 2.amu/(hbar)^2 [MeV^(-1).fm^(-2)]
const double two_amu_over_hbar_square = 0.0478450427;

// = e/(4.pi.eps0) in MeV.fm
const double Coulomb_constant = 1.43997847;

// proton mass [amu]
const double proton_mass = 1.00783;

// neutron mass [amu]
const double neutron_mass = 1.00866;

// diproton mass [amu]
const double diproton_mass = 2.01566;

// electron mass [MeV/c^2 !!]
const double electron_mass = 0.510998902;

// atomic mass unit [MeV/c^2]
const double amu = 931.49432;

// fine structure constant
const double fine_struct_const = 0.00729735253;

// hbar.c [MeV.fm]
const double hbar_c = 197.327053;

// Compton wavelength of the electron over 2Pi [fm]
const double Compton_wavelength_electron = 386.1592678;

// dimensionless coupling constants in beta transition 
const double ga_over_gv_vacuum = -1.25995;
const double nuclear_matter_beta_quenching = 0.77;
const double ga_over_gv = ga_over_gv_vacuum*nuclear_matter_beta_quenching;

// Bohr magneton
const double half_nuclear_magneton = 0.5*hbar_c/(proton_mass*amu);

// cosines and sines of the complex scaling angles
// Angles of index 0,1,2,3 are: Pi/4, 3Pi/4, -3Pi/4 , -Pi/4
const double cos_theta_tab[4] = {M_SQRT1_2 , -M_SQRT1_2 , -M_SQRT1_2 ,  M_SQRT1_2};
const double sin_theta_tab[4] = {M_SQRT1_2 ,  M_SQRT1_2 , -M_SQRT1_2 , -M_SQRT1_2};


const double a_0 = 0.529177208e-10 ; // [m]
const double diel = 1./(4. * M_PI * 8.854187817e-12); // [F.m^ - 1]
const double electron_charge_Coulomb = 1.602176487e-19; // [C]
const double Rydberg_hc = 13.605691; // [eV]
const double beta_eV = (hbar_c * hbar_c * 1e-24)/(2. * electron_mass * a_0 * a_0); // [eV]
const double const_dimensionless_equation = (Coulomb_constant * 1e-9)/(Rydberg_hc * a_0); // [without units] = 2
const double const_V0_dimensionless = 1./const_dimensionless_equation; // [without units] = 0.5

// constant for deformed_WS potential (to have energy in unit of 0.0479 MeV)
// 1.0 / ((h c)^2 / (2 m_n c^2 fm^2))
// almost equal to two_amu_over_hbar_square
const double const_factor_deformed_WS = (2 * neutron_mass * amu) / (hbar_c * hbar_c);


const unsigned int MASTER_PROCESS = 0;


// the keyword "extern" means that the makefile searches the definition in an other place
// but it knows that they exist somewhere
extern unsigned int MASTER_THREAD , NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS;
extern bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
extern bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
extern bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;


#endif


