#include "../numlib_def/numlib_def.h"

extern string STORAGE_DIR;

using namespace string_routines;
using namespace Wigner_signs;

correlated_state_str::correlated_state_str ()
  : Z (0) , 
    N (0) , 
    BP (2) , 
    J (0.0) , 
    vector_index (OUT_OF_RANGE) , 
    Re_E (INFINITE) , 
    Im_E (0.0) , 
    weight (0.0) , 
    experimental_energy (0.0) , 
    energy_error (0.0) , 
    is_it_optimization_reference_state (false) , 
    is_it_filled (false)
{}

correlated_state_str::correlated_state_str (
					    const int Z_c , 
					    const int N_c , 
					    const unsigned int BP_c , 
					    const double J_c , 
					    const unsigned int vector_index_c , 
					    const complex<double> &E_c , 
					    const double weight_c , 
					    const double experimental_energy_c , 
					    const double energy_error_c ,
					    const bool is_it_optimization_reference_state_c)
{
  initialize (Z_c , N_c , BP_c , J_c , vector_index_c , E_c , weight_c , experimental_energy_c , energy_error_c , is_it_optimization_reference_state_c);
}

correlated_state_str::correlated_state_str (const class correlated_state_str &X)
{
  initialize (X);
}

void correlated_state_str::initialize (
				       const int Z_c , 
				       const int N_c , 
				       const unsigned int BP_c , 
				       const double J_c , 
				       const unsigned int vector_index_c , 
				       const complex<double> &E_c , 
				       const double weight_c , 
				       const double experimental_energy_c , 
				       const double energy_error_c ,
				       const bool is_it_optimization_reference_state_c)
{
  Z = Z_c; 
  N = N_c; 
  BP = BP_c; 
  J = J_c; 
  vector_index = vector_index_c; 
  Re_E = real (E_c); 
  Im_E = imag (E_c); 
  weight = weight_c; 
  experimental_energy = experimental_energy_c; 
  energy_error = energy_error_c; 
  is_it_optimization_reference_state = is_it_optimization_reference_state_c;
  is_it_filled = true;
}

void correlated_state_str::initialize (const class correlated_state_str &X)
{
  Z = X.Z; 
  N = X.N; 
  BP = X.BP; 
  J = X.J;
  vector_index = X.vector_index; 
  Re_E = X.Re_E; 
  Im_E = X.Im_E; 
  weight = X.weight; 
  experimental_energy = X.experimental_energy; 
  energy_error = X.energy_error; 
  is_it_optimization_reference_state = X.is_it_optimization_reference_state;
  is_it_filled = X.is_it_filled;
}

void correlated_state_str::operator = (const class correlated_state_str &X)
{
  initialize (X);
}

ostream & operator << (ostream &os , const class correlated_state_str &PSI_qn)
{
  return os << "Z:" << PSI_qn.get_Z () << " N:" << PSI_qn.get_N () << " " << J_Pi_vector_index_string (PSI_qn.get_BP () , PSI_qn.get_J () , PSI_qn.get_vector_index ());
}




#ifdef UseMPI

MPI_Datatype MPI_Datatype_correlated_state_str_create ()
{
  const unsigned int N_members = 12;

  const MPI_Datatype MPI_int     = MPI_helper::MPI_equivalent_type<int> ();
  const MPI_Datatype MPI_uns_int = MPI_helper::MPI_equivalent_type<unsigned int> ();
  const MPI_Datatype MPI_double  = MPI_helper::MPI_equivalent_type<double> ();
  const MPI_Datatype MPI_bool    = MPI_helper::MPI_equivalent_type<bool> ();

  MPI_Datatype types[N_members] = {MPI_int , MPI_int ,
				   MPI_uns_int ,
				   MPI_double ,
				   MPI_uns_int ,
				   MPI_double , MPI_double , MPI_double , MPI_double , MPI_double ,
				   MPI_bool , MPI_bool};

  int block_lengths[N_members] = {1 , 1 ,
				  1 ,
				  1 ,
				  1 ,
				  1 , 1 , 1 , 1 , 1 ,
				  1 , 1};

  class correlated_state_str A;

  MPI_Aint A_address = MPI_helper::Get_address (&A);

  MPI_Aint address_displacements[N_members];

  address_displacements[0]  = MPI_helper::Get_address (&A.Z)                                  - A_address;
  address_displacements[1]  = MPI_helper::Get_address (&A.N)                                  - A_address;
  address_displacements[2]  = MPI_helper::Get_address (&A.BP)                                 - A_address;
  address_displacements[3]  = MPI_helper::Get_address (&A.J)                                  - A_address;
  address_displacements[4]  = MPI_helper::Get_address (&A.vector_index)                       - A_address;
  address_displacements[5]  = MPI_helper::Get_address (&A.Re_E)                               - A_address;
  address_displacements[6]  = MPI_helper::Get_address (&A.Im_E)                               - A_address;
  address_displacements[7]  = MPI_helper::Get_address (&A.weight)                             - A_address;
  address_displacements[8]  = MPI_helper::Get_address (&A.experimental_energy)                - A_address;
  address_displacements[9]  = MPI_helper::Get_address (&A.energy_error)                       - A_address;
  address_displacements[10] = MPI_helper::Get_address (&A.is_it_optimization_reference_state) - A_address;
  address_displacements[11] = MPI_helper::Get_address (&A.is_it_filled)                       - A_address;

  const MPI_Datatype MPI_correlated_state_str = MPI_helper::Type_create_struct (N_members , block_lengths , address_displacements , types);

  return MPI_correlated_state_str;
}

#endif



double used_memory_calc (const class correlated_state_str &T)
{
  return sizeof (T)/1000000.0;
}



class correlated_state_str correlated_state_routines::PSI_quantum_numbers_find (
										const int Z , 
										const int N , 
										const unsigned int BP , 
										const double J , 
										const unsigned int vector_index , 
										const class array<class correlated_state_str > &qn_tab)
{
  const unsigned int dimension = qn_tab.dimension_total ();

  unsigned int i = 0;

  while ((i < dimension) && ((Z != qn_tab[i].get_Z ()) || (N != qn_tab[i].get_N ()) || !same_BP_J_vector_index (BP , J ,vector_index , qn_tab[i].get_BP () , qn_tab[i].get_J () , qn_tab[i].get_vector_index ())))
    {
      i++;	
    }

  if (i == dimension)
    {
      error_message_print_abort ("No quantum numbers " + J_Pi_vector_index_string (BP , J , vector_index) + " for Z=" + make_string<int> (Z) + " N=" + make_string<int> (N) + " available in qn_tab in PSI_quantum_numbers_find.");
    }

  return qn_tab[i];
}




void correlated_state_routines::eigenvectors_sort (
						   const int low , 
						   const int high , 
						   class array<correlated_state_str > &qn_tab)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot_eigenvalue = real_dc (qn_tab(pivot_index).get_E ());

  int i_sort = low;
  int j_sort = high;

  do
    {
      double E_i_sort = real_dc (qn_tab(i_sort).get_E ());
      double E_j_sort = real_dc (qn_tab(j_sort).get_E ());

      while ((E_i_sort < pivot_eigenvalue) && (abs (E_i_sort - pivot_eigenvalue) > precision)) E_i_sort = real_dc (qn_tab(++i_sort).get_E ());
      while ((E_j_sort > pivot_eigenvalue) && (abs (E_j_sort - pivot_eigenvalue) > precision)) E_j_sort = real_dc (qn_tab(--j_sort).get_E ());

      if (i_sort <= j_sort)
	{
	  swap<class correlated_state_str > (qn_tab(i_sort) , qn_tab(j_sort));

	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) eigenvectors_sort (low , j_sort , qn_tab);
  
  if (i_sort < high) eigenvectors_sort (i_sort , high , qn_tab);   
}





void correlated_state_routines::eigenvectors_sorted_printed (const bool is_it_Jmin , const class array<correlated_state_str > &qn_tab) 
{
  const unsigned int eigenvectors_number = qn_tab.dimension_total ();

  if (eigenvectors_number == 0) return;

  class array<correlated_state_str > qn_tab_1D(eigenvectors_number);

  for (unsigned int i = 0 ; i < eigenvectors_number ; i++) qn_tab_1D(i).initialize (qn_tab[i]);

  eigenvectors_sort (0 , eigenvectors_number - 1 , qn_tab_1D);

  const class correlated_state_str &qn_gs = qn_tab_1D(0);
  
  const complex<double> E_gs = qn_gs.get_E ();

  for (unsigned int i = 0 ; i < eigenvectors_number ; i++)
    {
      const class correlated_state_str &qn = qn_tab_1D(i);
      
      if (!qn.get_is_it_filled ()) continue;

      const int Z = qn.get_Z ();
      const int N = qn.get_N ();

      const unsigned int BP = qn.get_BP ();

      const unsigned int vector_index = qn.get_vector_index ();

      const double J = qn.get_J ();

      const complex<double> &E = qn.get_E ();

      if (is_it_Jmin)
	cout << "Z:" << Z << " N:" << N << "   J[min] Pi (index):" << J_Pi_vector_index_string (BP , J , vector_index);
      else
	cout << "Z:" << Z << " N:" << N << "   J Pi (index):" << J_Pi_vector_index_string (BP , J , vector_index);
	
      if (imag_dc (E) == 0.0) 
	cout << "   E:" << real_dc (E) << " MeV" << "   E:" << real_dc (E) - real_dc (E_gs) << " MeV" << endl;
      else
	cout << "   E:" << real_dc (E) << " MeV" << " G:" << -2000.0*imag_dc (E) << " keV" << "   E:" << real_dc (E) - real_dc (E_gs) << " MeV G:" << -2000.0*imag_dc (E) << " keV" << endl;
      
    }//loop on the eigenvector index

  cout << endl;
}




string correlated_state_routines::PSI_quantum_numbers_string (const class correlated_state_str &PSI_qn)
{
  if (!PSI_qn.get_is_it_filled ()) return "";

  const int Z = PSI_qn.get_Z ();

  const int N = PSI_qn.get_N ();
  
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();

  const double J = PSI_qn.get_J ();

  const string PSI_qn_str = "Z:" + make_string<int> (Z) + " N:" + make_string<int> (N) + " " + J_Pi_vector_index_string (BP , J , vector_index);

  return PSI_qn_str;
}






string correlated_state_routines::PSI_quantum_numbers_string_for_file_name (const class correlated_state_str &PSI_qn)
{
  if (!PSI_qn.get_is_it_filled ()) return "";

  const int Z = PSI_qn.get_Z ();

  const int N = PSI_qn.get_N ();
      
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();

  const double J = PSI_qn.get_J ();

  const string PSI_qn_str = "Z" + make_string<int> (Z) + "_N" + make_string<int> (N) + "_" + J_Pi_vector_index_string_for_file_name (BP , J , vector_index);

  return PSI_qn_str;
}





string correlated_state_routines::PSI_quantum_numbers_string (
							      const class correlated_state_str &PSI_qn ,
							      const double M)
{
  if (!PSI_qn.get_is_it_filled ()) return "";

  const int Z = PSI_qn.get_Z ();

  const int N = PSI_qn.get_N ();
  
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();

  const double J = PSI_qn.get_J ();

  const string PSI_qn_str = "Z:" + make_string<int> (Z) + " N:" + make_string<int> (N) + " " + JM_Pi_vector_index_string (BP , J , vector_index , M);

  return PSI_qn_str;
}






string correlated_state_routines::PSI_quantum_numbers_string_for_file_name (
									    const class correlated_state_str &PSI_qn ,
									    const double M)
{
  if (!PSI_qn.get_is_it_filled ()) return "";

  const int Z = PSI_qn.get_Z ();

  const int N = PSI_qn.get_N ();
  
  const unsigned int BP = PSI_qn.get_BP ();

  const unsigned int vector_index = PSI_qn.get_vector_index ();

  const double J = PSI_qn.get_J ();

  const string PSI_qn_str = "Z" + make_string<int> (Z) + "_N" + make_string<int> (N) + "_" + JM_Pi_vector_index_string_for_file_name (BP , J , vector_index , M);

  return PSI_qn_str;
}




string correlated_state_routines::file_name_eigenvector_string (
								const bool full_common_vectors_used_in_file ,
								const string &debut_eigenvector_string , 
								const class correlated_state_str &PSI_qn)
{
  if (!PSI_qn.get_is_it_filled ()) return "";

  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);

  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn);
  
  const string eigenvector_str = STORAGE_DIR + node_string + debut_eigenvector_string + "_" + PSI_qn_string;

  return eigenvector_str; 
}




string correlated_state_routines::file_name_eigenvector_string (
								const bool full_common_vectors_used_in_file ,
								const string &debut_eigenvector_string , 
								const class correlated_state_str &PSI_qn , 
								const double M)
{	
  if (!PSI_qn.get_is_it_filled ()) return "";
  
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);

  const string PSI_qn_string = PSI_quantum_numbers_string_for_file_name (PSI_qn , M);
  
  const string eigenvector_str = STORAGE_DIR + node_string + debut_eigenvector_string + "_" + PSI_qn_string;

  return eigenvector_str; 
}




void correlated_state_routines::GSM_vector_eigenenergy_average_n_scat_copy_disk (
										 const string eigenvector_energy_string , 
										 const class correlated_state_str &PSI_qn , 
										 const complex<double> &average_n_scat) 
{
#ifdef UseMPI
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in GSM_vector_eigenenergy_average_n_scat_copy_disk.");
#endif

  const string file_name = file_name_eigenvector_string (true , eigenvector_energy_string , PSI_qn);

  const complex<double> &E = PSI_qn.get_E ();

  ofstream energy_pole_type_file(file_name.c_str() , ios::out);

  energy_pole_type_file.precision (15);

  energy_pole_type_file << E << " " << average_n_scat << endl;

  energy_pole_type_file.close ();
}




// Write all energies in one file if one calculates all eigenstate energies
// ------------------------------------------------------------------------
// One writes: Re[E] Im[E] in one file for each J-Pi occurrence.
// The name of one file is of the form all_energies_Z2_N4_0+.dat .
 
void correlated_state_routines::all_energies_copy_to_files (
							    const int Z ,
							    const int N ,
							    const class array<unsigned int> &BP_eigenset_tab ,
							    const class array<double> &J_eigenset_tab ,
							    const class array<unsigned long int> &dimensions_good_J , 
							    const class array<class correlated_state_str> &PSI_qn_tab)
{  
  const unsigned int eigensets_number = BP_eigenset_tab.dimension (0);
  
  const unsigned int n_scat_max = dimensions_good_J.dimension (1) - 1;
    
  for (unsigned int eigenset_index = 0 ; eigenset_index < eigensets_number ; eigenset_index++)
    {
      const unsigned int BP = BP_eigenset_tab(eigenset_index);
      
      const double J = J_eigenset_tab(eigenset_index);
     
      const unsigned int dimension_good_J = dimensions_good_J(BP , n_scat_max , J);
	  
      const string energies_file_str = "all_energies_Z" + make_string<int> (Z) + "_N" + make_string<int> (N) + "_" + J_Pi_string_for_file_name (BP , J) + ".dat";
	  
      ofstream energies_file(energies_file_str.c_str() , ios::out);

      energies_file.precision (15);
	  
      for (unsigned int i = 0 ; i < dimension_good_J ; i++)
	{
	  const class correlated_state_str &PSI_qn = PSI_qn_tab(eigenset_index , i);
	      
	  const complex<double> E = PSI_qn.get_E ();

	  if (imag_dc (E) == 0.0) 
	    energies_file << real_dc (E) << endl;
	  else
	    energies_file << real_dc (E) << " " <<imag_dc (E) << endl;		
	}
    }
}





// Name of the file when one will store [a+[nljm]|Psi[in]>]^J[out] or [a[nljm]|Psi[in]>]^J[out]
// --------------------------------------------------------------------------------------------
//
// The file name is of the form (ignoring workspace directory name): 
// "..._1s1I2_proton_applied_to_1I2+_0_target_coupled_to_1+_1"   for proton 1s1/2 state, J[in] = 1/2 for ground state target, coupled to J[out] = M[out] = 1.
// "..._1s1I2_proton_removed_from_1I2+_0_target_coupled_to_1+_1" for proton 1s1/2 state, J[in] = 1/2 for ground state target, coupled to J[out] = M[out] = 1.
//
// If 2D partitioning is used, one stores vectors in subdirectories of the form "node_4/" in the workspace directory so that one node reads only its own files. It is taken into account with node_string.
//
// Variables
// ---------
// node_string: string of the form "node_4/" (for node 4) to store data in the node subdirectory, empty string otherwise
// full_common_vectors_used_in_file: true if all vectors are stored in one file for all nodes, false if they stored in the node subdirectory, as in 2D partitioning (MPI only)
// file_name_debut: beginning of the name of the file
// particle: proton or neutron
// n,l,j: principal quantum number, orbital and total angular momenta of the projectile/ejectile
// bp, BP_IN, BP_OUT: binary parities (see observables_basic_functions.cpp for definition) of the projectile/ejectile, |Psi[in]> and [a+[nljm]|Psi[in]>]^J[out]
// lj: partial wave string of the form "s1I2" for the projectile/ejectile
// PSI_IN_qn: class correlated_state_str, containing data about the |Psi[in]> GSM vectors, such as Z,N,BP,J ... 
// PSI_projectile_string, PSI_IN_string: parts of the file name concerning projectile/ejectile ("1s1I2_proton" above) and target only ("1I2+_0" above)
// J_OUT,M_OUT,JM_Pi_OUT_string: J[out], M[out], part of the file name providing with J-Pi[out] M[out] ("1+_1" above) 
// file_name: returned name of the file

string PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (
								  const bool full_common_vectors_used_in_file , 
								  const string &file_name_debut , 
								  const int n ,
								  const int l ,
								  const double j ,
								  const enum particle_type particle , 
								  const class correlated_state_str &PSI_IN_qn ,
								  const double J_OUT , 
								  const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
    
  const unsigned int BP_OUT = binary_parity_product (BP_IN , bp);

  const string lj = angular_state_for_file_name (l , j);

  const string PSI_IN_string = correlated_state_routines::PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);	

  const string PSI_projectile_string = make_string<int> (n) + lj + "_" + make_string <enum particle_type> (particle);

  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + PSI_projectile_string + "_applied_to_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}

string PSI_OUT_coupled_to_J_file_name_a_nucleon_determine (
							   const bool full_common_vectors_used_in_file , 
							   const string &file_name_debut ,  
							   const int n ,
							   const int l ,
							   const double j ,
							   const enum particle_type particle , 
							   const class correlated_state_str &PSI_IN_qn ,
							   const double J_OUT , 
							   const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);
  
  const unsigned int BP_IN = PSI_IN_qn.get_BP ();
  
  const unsigned int bp = binary_parity_from_orbital_angular_momentum (l);
    
  const unsigned int BP_OUT = binary_parity_product (BP_IN , bp);

  const string lj = angular_state_for_file_name (l , j);

  const string PSI_IN_string = correlated_state_routines::PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);	

  const string PSI_projectile_string = make_string<int> (n) + lj + "_" + make_string <enum particle_type> (particle);

  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + PSI_projectile_string + "_removed_from_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}











// Name of the file when one will store [A+[Psi(cluster)]|Psi[in]>]^J[out] or [A[Psi(cluster)]|Psi[in]>]^J[out] for |Psi[cluster]> = |NCM_HO LCM Psi[intrinsic]>
// -------------------------------------------------------------------------------------------------------------------------------------------------------------
// |Psi[cluster]> is separated in HO center of mass part and intrinsic part using the HO basis.
//
// The file name is of the form (ignoring workspace directory name): 
// "..._deuteron_4_3S1_1_applied_to_1I2+_0_target_coupled_to_1I2+_1I2"   for deuteron ground state, NCM_HO = 4, LCM = 0, J[in] = 1/2 for ground state target, coupled to J[out] = M[out] = 1/2.
// "..._deuteron_4_3S1_1_removed_from_1I2+_0_target_coupled_to_1I2+_1I2" for deuteron ground state, NCM_HO = 4, LCM = 0, J[in] = 1/2 for ground state target, coupled to J[out] = M[out] = 1/2.
//
// If 2D partitioning is used, one stores vectors in subdirectories of the form "node_4/" in the workspace directory so that one node reads only its own files. It is taken into account with node_string.
//
// Variables
// ---------
// node_string: string of the form "node_4/" (for node 4) to store data in the node subdirectory, empty string otherwise
// full_common_vectors_used_in_file: true if all vectors are stored in one file for all nodes, false if they stored in the node subdirectory, as in 2D partitioning (MPI only)
// file_name_debut: beginning of the name of the file
// cluster: type of cluster added to the |Psi[in]> target: proton, neutron, deuteron, alpha, ...
// BP_cluster, BP_IN, BP_OUT: binary parities (see observables_basic_functions.cpp for definition) of the cluster, |Psi[in]> and [a+[nljm]|Psi[in]>]^J[out]
// NCM_HO, LCM: principal quantum number and orbital angular momentum of the center of mass state  |NCM_HO LCM>
// PSI_cluster_qn, PSI_IN_qn: class correlated_state_str, containing data about the |Psi[cluster]> and |Psi[in]> GSM vectors, such as Z,N,BP,J ... 
// J_cluster: total angular momentum of |Psi[cluster]>
// cluster_string, PSI_IN_string: parts of the file name concerning cluster ("deuteron_4_3S1_1" above) and target only ("1I2+_0" above)
// J_OUT,M_OUT,JM_Pi_OUT_string: J[out], M[out], part of the file name providing with J-Pi[out] M[out] ("1I2+_1I2" above) 
// file_name: returned name of the file

string PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (
									      const bool full_common_vectors_used_in_file , 
									      const string &file_name_debut , 
									      const enum particle_type cluster , 
									      const int NCM_HO , 
									      const int LCM , 
									      const class correlated_state_str &PSI_cluster_qn , 
									      const class correlated_state_str &PSI_IN_qn ,
									      const double J_OUT , 
									      const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const unsigned int BP_OUT = binary_parity_product (BP_IN , BP_cluster);

  const double J_cluster = PSI_cluster_qn.get_J ();

  const string cluster_string = intrinsic_CM_cluster_string_for_file_name (cluster , NCM_HO , LCM , J_cluster);

  const string PSI_IN_string = correlated_state_routines::PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);

  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + cluster_string + "_applied_to_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}

string PSI_OUT_coupled_to_J_file_name_A_cluster_CM_relative_determine (
								       const bool full_common_vectors_used_in_file , 
								       const string &file_name_debut , 
								       const enum particle_type cluster , 
								       const int NCM_HO , 
								       const int LCM , 
								       const class correlated_state_str &PSI_cluster_qn , 
								       const class correlated_state_str &PSI_IN_qn ,
								       const double J_OUT , 
								       const double M_OUT)
{
  const string node_string = node_string_determine (full_common_vectors_used_in_file , THIS_PROCESS);

  const unsigned int BP_IN = PSI_IN_qn.get_BP ();

  const unsigned int BP_cluster = PSI_cluster_qn.get_BP ();

  const unsigned int BP_OUT = binary_parity_product (BP_IN , BP_cluster);

  const double J_cluster = PSI_cluster_qn.get_J ();

  const string cluster_string = intrinsic_CM_cluster_string_for_file_name (cluster , NCM_HO , LCM , J_cluster);
  
  const string PSI_IN_string = correlated_state_routines::PSI_quantum_numbers_string_for_file_name (PSI_IN_qn);
  
  const string JM_Pi_OUT_string = JM_Pi_string_for_file_name (BP_OUT , J_OUT , M_OUT);
  
  const string file_name = STORAGE_DIR + node_string + file_name_debut + "_" + cluster_string + "_removed_from_" + PSI_IN_string + "_target_coupled_to_" + JM_Pi_OUT_string;

  return file_name;
}










// Print on screen of electromagnetic transition
// ---------------------------------------------
// The electromagnetic transition is printed on screen in eV, Weisskopf_units, e^2 fm^(2L) for electric and mu[n] c^(-2) fm^(2L - 2) for magnetic.
//
// The electromagnetic transition value in eV comes from a multiplication of the electromagnetic transition by:
// 8E6 . M_PI . q^(2L + 1) . (L + 1)/L/((2*L + 1)!! ^ 2) . (fine structure constant) . (hbar c)
//
// One uses the standard formulas for Weisskopf_units:
// One Weisskopf unit is :
// Electric: 1.2^(2L) 4 Pi/((3/(L+3))^2)/(A^(2L/3))
// Magnetic: 0.1 . Pi / (1.2^(2L-2))/((3/(L+3))^2)/(A^((2L-2)/3))
//
// Variables
// ---------
// EM: electric or magnetic
// q: linear momentum of the emitted photon. It is equal to (E_in - E_out)/(hbar c), with E_in and E_out the energies of the in and out many-body states. One takes q->0 with long-wavelength approximation.
// L: orbital angular momentum of the electromagnetic transition (L=1 for M1, E1, L=2 for E2 ...)
// is_it_longwavelength_approximation: true if long-wavelength approximation is used, false if not
// A: number of nucleons of the nucleus
// PSI_IN_qn, PSI_OUT_qn: structures containing quantum numbers of the many-body in and out states
// B: squared electromagnetic transition amplitude
// BP_IN, BP_OUT: binary parity of the many-body in and out states (see observables_basic_functions.cpp for definition)
// vector_index_IN, vector_index_OUT: vector indices of the many-body in and out states
// J_IN, J_OUT: total angular momenta of the many-body in and out states
// BEM: electromagnetic transition value, which is B/(2.J_IN + 1), in e^2 fm^(2L) for electric and mu[n] c^(-2) fm^(2L - 2) for magnetic.
// BEM_eV, BEM_Weisskopf_units: electromagnetic transition value in eV, Weisskopf_units

void print_B_G (
		const enum EM_type EM ,
		const double q ,  
		const int L , 
		const bool is_it_longwavelength_approximation ,  
		const int A , 
		const class correlated_state_str &PSI_IN_qn , 
		const class correlated_state_str &PSI_OUT_qn , 
		const double B)
{
  if (is_it_longwavelength_approximation)
    cout << "long wavelength approximation , ";
  else
    cout << "no long wavelength approximation , ";

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();
  
  const unsigned int vector_index_IN  = PSI_IN_qn.get_vector_index ();
  const unsigned int vector_index_OUT = PSI_OUT_qn.get_vector_index ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const double BEM = B/(2.0*J_IN + 1.0);

  const double BEM_eV = BEM*8E6*M_PI*pow (q , 2*L + 1)*(L + 1.0)/L/pow (double_factorial (2*L + 1) , 2)*fine_struct_const*hbar_c;
  
  cout << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " : ";
	
  switch (EM)
    {
    case ELECTRIC:
      {
	const double BEM_Weisskopf_units = BEM/pow (1.2 , 2*L)*4.0*M_PI/pow (3.0/(L + 3.0) , 2)/pow (A , 2.0*L/3.0);
	
	cout << " B(E" << L << ") = " << BEM << " e^2 fm^" << 2*L << " = " << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;
      } break;

    case MAGNETIC:
      {
	const double BEM_Weisskopf_units = BEM*0.1*M_PI/pow (1.2 , 2*L - 2)/pow (3.0/(L + 3.0) , 2)/pow (A , (2.0*L - 2)/3.0);
	
	if (L == 1) cout << " B(M" << L << ") = " << BEM << " mu[n] c^(-2) = "                      << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;
	if (L != 1) cout << " B(M" << L << ") = " << BEM << " mu[n] c^(-2) fm^" << 2*L - 2 << " = " << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;

      } break;

    default: abort_all ();
    }
}

void print_B_G (
		const enum EM_type EM ,
		const complex<double> &q ,  
		const int L , 
		const bool is_it_longwavelength_approximation ,  
		const int A , 
		const class correlated_state_str &PSI_IN_qn , 
		const class correlated_state_str &PSI_OUT_qn , 
		const complex<double> &B)
{
  if (is_it_longwavelength_approximation)
    cout << "long wavelength approximation , ";
  else
    cout << "no long wavelength approximation , ";

  const unsigned int BP_IN  = PSI_IN_qn.get_BP ();
  const unsigned int BP_OUT = PSI_OUT_qn.get_BP ();
  
  const unsigned int vector_index_IN  = PSI_IN_qn.get_vector_index ();
  const unsigned int vector_index_OUT = PSI_OUT_qn.get_vector_index ();
  
  const double J_IN  = PSI_IN_qn.get_J ();
  const double J_OUT = PSI_OUT_qn.get_J ();

  const complex<double> BEM = B/(2.0*J_IN + 1.0);

  const complex<double> BEM_eV = BEM*8E6*M_PI*pow (q , 2*L + 1)*(L + 1.0)/L/pow (double_factorial (2*L + 1) , 2)*fine_struct_const*hbar_c;
	
  cout << J_Pi_vector_index_string (BP_IN , J_IN , vector_index_IN) << " --> " << J_Pi_vector_index_string (BP_OUT , J_OUT , vector_index_OUT) << " : ";

  switch (EM)
    {
    case ELECTRIC:
      {
	const complex<double> BEM_Weisskopf_units = BEM/pow (1.2 , 2*L)*4.0*M_PI/pow (3.0/(L + 3.0) , 2)/pow (A , 2.0*L/3.0);
	
	cout << " B(E" << L << ") = " << BEM << " e^2 fm^" << 2*L << " = " << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;
      } break;

    case MAGNETIC:
      {
	const complex<double> BEM_Weisskopf_units = BEM*0.1*M_PI/pow (1.2 , 2*L - 2)/pow (3.0/(L + 3.0) , 2)/pow (A , (2.0*L - 2)/3.0);
	
	if (L == 1) cout << " B(M" << L << ") = " << BEM << " mu[n] c^(-2) = "                      << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;
	if (L != 1) cout << " B(M" << L << ") = " << BEM << " mu[n] c^(-2) fm^" << 2*L - 2 << " = " << BEM_Weisskopf_units << " W.u." << endl << "G = " << BEM_eV << " eV" << endl << endl;

      } break;

    default: abort_all ();
    }
}













// Print on file of electromagnetic transition amplitudes
// ------------------------------------------------------
// Electromagnetic transition amplitudes per radius (no radial integration) are printed on file in eV^(1/2), Weisskopf_units^(1/2), e fm^(L) for electric and mu[n]^(1/2) c^(-1) fm^(L - 1) for magnetic.
//
// The electromagnetic transition value in eV comes from a multiplication of the electromagnetic transition by:
// sqrt (8E6 . M_PI . q^(2L + 1) . (L + 1)/L/((2*L + 1)!! ^ 2) . (fine structure constant) . (hbar c))
//
// One uses the standard formulas for Weisskopf_units:
// One Weisskopf unit is :
// Electric: sqrt (1.2^(2L) 4 Pi/((3/(L+3))^2)/(A^(2L/3)))
// Magnetic: sqrt (0.1 . Pi / (1.2^(2L-2))/((3/(L+3))^2)/(A^((2L-2)/3)))
//
// double and complex versions are provided.
//
// Variables
// ---------
// EM: electric or magnetic
// q: linear momentum of the emitted photon. It is equal to (E_in - E_out)/(hbar c), with E_in and E_out the energies of the in and out many-body states. One takes q->0 with long-wavelength approximation.
// L: orbital angular momentum of the electromagnetic transition (L=1 for M1, E1, L=2 for E2 ...)
// is_it_longwavelength_approximation: true if long-wavelength approximation is used, false if not
// A: number of nucleons of the nucleus
// J_IN: total angular momentum of the many-body in state
// r_tab: radii on [0:R], with R the rotation point
// B_amplitude_tab: electromagnetic transition amplitudes
// EM_strength_string: name of the file where on stores electromagnetic transition amplitudes
// Nr: number of radii on [0:R], with R the rotation point
// EM_strength_file: file where on stores electromagnetic transition amplitudes
// B_amplitude: electromagnetic transition amplitude
// BEM: electromagnetic transition amplitude with J_IN taken into account, which is B_amplitude/(2.J_IN + 1), in e fm^(L) for electric and mu[n]^(1/2) c^(-1) fm^(L - 1) for magnetic.
// BEM_amplitude_eV, BEM_amplitude_Weisskopf_units: electromagnetic transition value in eV^(1/2), Weisskopf_units^(1/2)

void print_B_G_amplitude_tab (
			      const enum EM_type EM ,
			      const double q , 
			      const int L ,  
			      const int A , 
			      const double J_IN , 
			      const class array<double> &r_tab , 
			      const class array<double> &B_amplitude_tab , 
			      const string EM_strength_string)
{
  const unsigned int Nr = r_tab.dimension (0);

  ofstream EM_strength_file(EM_strength_string.c_str ());
  
  EM_strength_file.precision (15);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const double r = r_tab(i);
      
      const double B_amplitude = B_amplitude_tab(i);

      const double BEM_amplitude = B_amplitude/(2.0*J_IN + 1.0);

      const double BEM_amplitude_eV = BEM_amplitude*sqrt (8E6*M_PI*pow (q , 2*L + 1)*(L + 1.0)/L*fine_struct_const*hbar_c)/double_factorial (2*L + 1);
	    
      switch (EM)
	{
	case ELECTRIC:
	  {
	    const double BEM_amplitude_Weisskopf_units = BEM_amplitude*sqrt (1.0/pow (1.2 , 2*L)*4.0*M_PI/pow (3.0/(L + 3.0) , 2)/pow (A , 2.0*L/3.0));
	    
	    EM_strength_file << r << " " << BEM_amplitude << " " << BEM_amplitude_Weisskopf_units << " " << BEM_amplitude_eV << endl;
	  } break;

	case MAGNETIC: 
	  {
	    const double BEM_amplitude_Weisskopf_units = BEM_amplitude*sqrt (0.1*M_PI/pow (1.2 , 2*L - 2)/pow (3.0/(L + 3.0) , 2)/pow (A , (2.0*L - 2)/3.0));
	   	    
	    EM_strength_file << r << " " << BEM_amplitude << " " << BEM_amplitude_Weisskopf_units << " " << BEM_amplitude_eV << endl;
	  } break;

	default: abort_all ();
	}
    } 

  EM_strength_file.close ();
}




void print_B_G_amplitude_tab (
			      const enum EM_type EM ,
			      const complex<double> &q , 
			      const int L ,  
			      const int A , 
			      const double J_IN , 
			      const class array<double> &r_tab , 
			      const class array<complex<double> > &B_amplitude_tab , 
			      const string EM_strength_string)
{
  const unsigned int Nr = r_tab.dimension (0);

  ofstream EM_strength_file(EM_strength_string.c_str ());
  
  EM_strength_file.precision (15);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const double r = r_tab(i);
      
      const complex<double> B_amplitude = B_amplitude_tab(i);

      const complex<double> BEM_amplitude = B_amplitude/(2.0*J_IN + 1.0);

      const complex<double> BEM_amplitude_eV = BEM_amplitude*sqrt (8E6*M_PI*pow (q , 2*L + 1)*(L + 1.0)/L*fine_struct_const*hbar_c)/double_factorial (2*L + 1);
	    
      switch (EM)
	{
	case ELECTRIC:
	  {
	    const complex<double> BEM_amplitude_Weisskopf_units = BEM_amplitude*sqrt (1.0/pow (1.2 , 2*L)*4.0*M_PI/pow (3.0/(L + 3.0) , 2)/pow (A , 2.0*L/3.0));
	    
	    EM_strength_file << r << " "
			     << real (BEM_amplitude)                 << " " << imag (BEM_amplitude)                 << " "
			     << real (BEM_amplitude_Weisskopf_units) << " " << imag (BEM_amplitude_Weisskopf_units) << " "
			     << real (BEM_amplitude_eV)              << " " << imag (BEM_amplitude_eV)              << endl;
	  } break;

	case MAGNETIC: 
	  {
	    const complex<double> BEM_amplitude_Weisskopf_units = BEM_amplitude*sqrt (0.1*M_PI/pow (1.2 , 2*L - 2)/pow (3.0/(L + 3.0) , 2)/pow (A , (2.0*L - 2)/3.0));	    
	    
	    EM_strength_file << r << " "
			     << real (BEM_amplitude)                 << " " << imag (BEM_amplitude)                 << " "
			     << real (BEM_amplitude_Weisskopf_units) << " " << imag (BEM_amplitude_Weisskopf_units) << " "
			     << real (BEM_amplitude_eV)              << " " << imag (BEM_amplitude_eV)              << endl;
	  } break;

	default: abort_all ();
	}
    } 

  EM_strength_file.close ();
}


