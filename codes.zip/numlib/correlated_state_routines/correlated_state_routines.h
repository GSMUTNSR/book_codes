
#ifndef CORRELATED_STATE_ROUTINES_H
#define CORRELATED_STATE_ROUTINES_H

extern string STORAGE_DIR;

class correlated_state_str
{
public:
  correlated_state_str ();

  correlated_state_str (
			const int Z_c , 
			const int N_c , 
			const unsigned int BP_c , 
			const double J_c , 
			const unsigned int vector_index_c , 
			const complex<double> &E_c , 
			const double weight_c , 
			const double experimental_energy_c , 
			const double energy_error_c , 
			const bool is_it_optimization_reference_state_c);

  correlated_state_str (const class correlated_state_str &X);

  void initialize (
		   const int Z_c , 
		   const int N_c , 
		   const unsigned int BP_c , 
		   const double J_c , 
		   const unsigned int vector_index_c , 
		   const complex<double> &E_c , 
		   const double weight_c , 
		   const double experimental_energy_c , 
		   const double energy_error_c , 
		   const bool is_it_optimization_reference_state_c);

  void initialize (const class correlated_state_str &X);
  
  void operator = (const class correlated_state_str &X);

  int get_Z () const
  {
    return Z;
  }

  int get_N () const
  {
    return N;
  }

  unsigned int get_BP () const
  {
    return BP;
  }

  double get_J () const
  {
    return J;
  }

  unsigned int get_vector_index () const
  {
    return vector_index;
  }

  complex<double> get_E () const
  {
    return complex<double> (Re_E , Im_E);
  }

  double get_weight () const
  {
    return weight;
  }

  double get_experimental_energy () const
  {
    return experimental_energy;
  }

  double get_energy_error () const
  {
    return energy_error;
  }

  bool get_is_it_optimization_reference_state () const
  {
    return is_it_optimization_reference_state;
  }

  bool get_is_it_filled () const
  {
    return is_it_filled;
  }

#ifdef UseMPI
  friend MPI_Datatype MPI_Datatype_correlated_state_str_create ();
#endif

private:

  int Z;
  int N;

  unsigned int BP;
  
  double J;

  unsigned int vector_index;

  double Re_E;
  double Im_E;

  double weight;

  double experimental_energy;

  double energy_error;

  bool is_it_optimization_reference_state;

  bool is_it_filled;
};

ostream & operator << (ostream &os , const class correlated_state_str &PSI_qn);

#ifdef UseMPI
MPI_Datatype MPI_Datatype_correlated_state_str_create ();
#endif

double used_memory_calc (const class correlated_state_str &T);

namespace correlated_state_routines
{
  class correlated_state_str PSI_quantum_numbers_find (
						       const int Z , 
						       const int N , 
						       const unsigned int BP , 
						       const double J , 
						       const unsigned int vector_index , 
						       const class array<class correlated_state_str> &qn_tab);

  void eigenvectors_sort (
			  const int low , 
			  const int high , 
			  class array<correlated_state_str> &qn_tab);

  void eigenvectors_sorted_printed (const bool is_it_Jmin , const class array<class correlated_state_str> &qn_tab); 

  string PSI_quantum_numbers_string (const class correlated_state_str &PSI_qn);

  string PSI_quantum_numbers_string_for_file_name (const class correlated_state_str &PSI_qn);

  string PSI_quantum_numbers_string (
				     const class correlated_state_str &PSI_qn ,
				     const double M);

  string PSI_quantum_numbers_string_for_file_name (
						   const class correlated_state_str &PSI_qn ,
						   const double M);

  string file_name_eigenvector_string (
				       const bool full_common_vectors_used_in_file ,
				       const string &debut_eigenvector_string , 
				       const class correlated_state_str &PSI_qn);

  string file_name_eigenvector_string (
				       const bool full_common_vectors_used_in_file ,
				       const string &debut_eigenvector_string , 
				       const class correlated_state_str &PSI_qn , 
				       const double M);

  void GSM_vector_eigenenergy_average_n_scat_copy_disk (
							const string eigenvector_energy_string , 
							const class correlated_state_str &PSI_qn , 
							const complex<double> &average_n_scat);
  void all_energies_copy_to_files (      
				   const int Z ,
				   const int N ,
				   const class array<unsigned int> &BP_eigenset_tab ,
				   const class array<double> &J_eigenset_tab ,
				   const class array<unsigned long int> &dimensions_good_J ,
				   const class array<class correlated_state_str> &PSI_qn_tab);  
}

string PSI_OUT_coupled_to_J_file_name_a_dagger_nucleon_determine (
								  const bool full_common_vectors_used_in_file , 
								  const string &file_name_debut , 
								  const int n ,
								  const int l ,
								  const double j ,
								  const enum particle_type particle , 
								  const class correlated_state_str &PSI_IN_qn ,
								  const double J_OUT , 
								  const double M_OUT);

string PSI_OUT_coupled_to_J_file_name_a_nucleon_determine (
							   const bool full_common_vectors_used_in_file , 
							   const string &file_name_debut , 
							   const int n ,
							   const int l ,
							   const double j ,
							   const enum particle_type particle , 
							   const class correlated_state_str &PSI_IN_qn ,
							   const double J_OUT , 
							   const double M_OUT);

string PSI_OUT_coupled_to_J_file_name_A_dagger_cluster_CM_relative_determine (
									      const bool full_common_vectors_used_in_file , 
									      const string &file_name_debut , 
									      const enum particle_type cluster , 
									      const int NCM_HO , 
									      const int LCM , 
									      const class correlated_state_str &PSI_cluster_qn , 
									      const class correlated_state_str &PSI_IN_qn ,
									      const double J_OUT , 
									      const double M_OUT);

string PSI_OUT_coupled_to_J_file_name_A_cluster_CM_relative_determine (
								       const bool full_common_vectors_used_in_file , 
								       const string &file_name_debut , 
								       const enum particle_type cluster , 
								       const int NCM_HO , 
								       const int LCM , 
								       const class correlated_state_str &PSI_cluster_qn , 
								       const class correlated_state_str &PSI_IN_qn ,
								       const double J_OUT , 
								       const double M_OUT);

void print_B_G (
		const enum EM_type EM ,
		const double q ,  
		const int L ,  
		const bool is_it_longwavelength_approximation , 
		const int A , 
		const class correlated_state_str &PSI_IN_qn , 
		const class correlated_state_str &PSI_OUT_qn , 
		const double B);

void print_B_G (
		const enum EM_type EM ,
		const complex<double> &q ,  
		const int L ,  
		const bool is_it_longwavelength_approximation , 
		const int A , 
		const class correlated_state_str &PSI_IN_qn , 
		const class correlated_state_str &PSI_OUT_qn , 
		const complex<double> &B);

void print_B_G_amplitude_tab (
			      const enum EM_type EM ,
			      const double q , 
			      const int L ,  
			      const int A , 
			      const double J_IN , 
			      const class array<double> &r_tab , 
			      const class array<double> &B_amplitude_tab , 
			      const string EM_strength_string);

void print_B_G_amplitude_tab (
			      const enum EM_type EM ,
			      const complex<double> &q , 
			      const int L ,  
			      const int A , 
			      const double J_IN , 
			      const class array<double> &r_tab , 
			      const class array<complex<double> > &B_amplitude_tab , 
			      const string EM_strength_string);
#endif
