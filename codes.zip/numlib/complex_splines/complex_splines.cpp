#include "../numlib_def/numlib_def.h"


// Class splines approximating a function given by a set of points. 
//------------------------------------------------------------------
// Complex type for all data
// Pointers are used instead of class array. It is more suitable for tables of splines coefficients, used in polynomial_evaluation.
// Other tables are defined as pointers for consistency in the class.
// T derivative and primitive of the spline function can be calculated exactly. The primitive of the splines is zero for its first point.

// Constructor:
// ------------
// There are two constructors : 
// 1) The derivatives at the interval limits are given (dF0 and dF_Nm1), and then the fit is optimal.
// 2) They are not given, and are approximated with a 3 point formula within the constructor.
// The fit is less precise at the limits of the intervals.
//
//
// Variables :
// ---------- - 
// N : number of points of the discretized function.
// r_table, F_table : tables of N points having the abscissas and values of F.
// dr_0, dr_1 : r_table(1) - r_table(0), dr_2 = r_table(2) - r_table(0).
// dF0 : approximate first derivative of F at the first point.
// Nm3 : N - 3
// dr_Nm2, dr_Nm3 : r_table(Nm2) - r_table(Nm1), dr_Nm3 = r_table(Nm3) - r_table(Nm1).
// dF_Nm1 : approximate first derivative of F at the last point.



// Constructor:
// ------------
// There are two constructors : 
// 1) The derivatives at the interval limits are given (dF0 and dF_Nm1),  and then the fit is optimal.
// 2) They are not given,  and are approximated with a 3 point formula within the constructor.
//    The fit is less precise at the limits of the intervals.
//
//
// Variables :
// -----------
// N : number of points of the discretized function.
// r_table, F_table : tables of N points having the abscissas and values of F.
// dr_0, dr_1 : r_table(1) - r_table(0), dr_2 = r_table(2) - r_table(0).
// dF0 : approximate first derivative of F at the first point.
// Nm3 : N-3
// dr_Nm2, dr_Nm3 : r_table(Nm2) - r_table(Nm1), dr_Nm3 = r_table(Nm3) - r_table(Nm1).
// dF_Nm1 : approximate first derivative of F at the last point.

complex_splines_class::complex_splines_class () : N (0) , Nm1 (0) , Nm2 (0) , r0 (0.0) , r_Nm1 (0) , is_it_equally_spaced (false) {}

complex_splines_class::complex_splines_class (
					      const class array<complex<double> > &r_table_c , 
					      const class array<complex<double> > &F_table)
{
  allocate_calc (r_table_c , F_table);
}




complex_splines_class::complex_splines_class (
					      const class array<complex<double> > &r_table_c , 
					      const class array<complex<double> > &F_table , 
					      const complex<double> &dF0 , 
					      const complex<double> &dF_Nm1)
{
  allocate_calc (r_table_c , F_table , dF0 , dF_Nm1);
}


complex_splines_class::complex_splines_class (const class complex_splines_class &X)
{
  allocate_fill (X);
}




void complex_splines_class::allocate_calc (
					   const class array<complex<double> > &r_table_c , 
					   const class array<complex<double> > &F_table)
{ 
  r_table.allocate_fill (r_table_c);
  
  N = r_table.dimension (0);

  if (N < 3) error_message_print_abort ("The number of points must be larger than 3 in complex_splines_class::allocate_calc (1)");

  for (unsigned int i = 1 ; i < N ; i++) if (r_table(i) == r_table(i-1)) error_message_print_abort ("Two mesh points are equal in complex_splines_class::allocate_calc (1)");
  
  Nm1 = N - 1;
  Nm2 = N - 2; 
  r0 = r_table(0); 
  r_Nm1 = r_table(Nm1);
  is_it_equally_spaced = r_table.is_it_equally_spaced ();
  one_over_step = 1.0/(r_table(1) - r_table(0));
  
  const unsigned int Nm3 = N - 3;
  
  const complex<double> dF0    = three_point_derivative (r_table(0)   , F_table(0)   , r_table(1)   , F_table(1)   , r_table(2)   , F_table(2));
  const complex<double> dF_Nm1 = three_point_derivative (r_table(Nm1) , F_table(Nm1) , r_table(Nm2) , F_table(Nm2) , r_table(Nm3) , F_table(Nm3));

  splines_alloc_calc (F_table , dF0 , dF_Nm1);

  splines_derivative_primitive_tables_alloc_calc ();
}




void complex_splines_class::allocate_calc (
					   const class array<complex<double> > &r_table_c , 
					   const class array<complex<double> > &F_table , 
					   const complex<double> &dF0 , 
					   const complex<double> &dF_Nm1)
{
  r_table.allocate_fill (r_table_c);
  
  N = r_table.dimension (0);

  if (N < 2) error_message_print_abort ("The number of points must be larger than 2 in complex_splines_class::allocate_calc (2)");

  for (unsigned int i = 1 ; i < N ; i++) if (r_table(i) == r_table(i-1)) error_message_print_abort ("Two mesh points are equal in complex_splines_class::allocate_calc (2)");
  
  Nm1 = N - 1;
  Nm2 = N - 2; 
  r0 = r_table(0); 
  r_Nm1 = r_table(Nm1);
  is_it_equally_spaced = r_table.is_it_equally_spaced ();
  one_over_step = 1.0/(r_table(1) - r_table(0));
  
  splines_alloc_calc (F_table , dF0 , dF_Nm1);
    
  splines_derivative_primitive_tables_alloc_calc ();
}





void complex_splines_class::allocate_fill (const class complex_splines_class &X)
{
  N = X.N;
  Nm1 = X.Nm1;
  Nm2 = X.Nm2;
  r0 = X.r0;
  r_Nm1 = X.r_Nm1;
  is_it_equally_spaced = X.is_it_equally_spaced;
  one_over_step = X.one_over_step;
  
  r_table.allocate_fill (X.r_table);

  splines_coeff_tab.allocate_fill (X.splines_coeff_tab);
  
  splines_coeff_derivative_tab.allocate_fill (X.splines_coeff_derivative_tab);
  
  splines_coeff_primitive_tab.allocate_fill (X.splines_coeff_primitive_tab);
}


void complex_splines_class::deallocate ()
{
  r_table.deallocate ();
  
  splines_coeff_tab.deallocate ();
  
  splines_coeff_derivative_tab.deallocate ();
  
  splines_coeff_primitive_tab.deallocate ();
  
  N = 0;
  Nm1 = 0;
  Nm2 = 0;
  r0 = 0.0;
  r_Nm1 = 0;
  one_over_step = 0.0;
  is_it_equally_spaced = false;
}
  


// Determination of the cubic splines approximating the discrete function F_table. 
// -------------------------------------------------------------------------------
// The Thomas algorithm (tridiagonal LU decomposition) is used to solve the tridiagonal linear system. 
// See Numerical Recipes for splines formulas. 
// 
// Variables:
// ----------
// e, f, g : subdiagonal, diagonal and superdiagonal part of the tridiagonal matrix defining the splines coefficients.
// b : right-hand vector part of the (e, f, g) tridiagonal linear system to solve.
// x : vector solution of the (e, f, g) tridiagonal linear system to solve.
// Dr_deb, Dr_end : r_table(1) - r_table(0),  r_table(N-1) - r_table(N-2)
// Dr_ip1, Dr_i : r_table(i+1) - r_table(i),  r_table(i) - r_table(i-1)
// Dr, one_over_Dr : r_table(i+1) - r_table(i), 1/[r_table(i+1) - r_table(i)]
// splines_coeff_i : complex<double> table splines_coeff_tab[i] having the 4 spline coefficients for each interval i.

void complex_splines_class::splines_alloc_calc (
						const class array<complex<double> > &F_table , 
						const complex<double> &dF0 , 
						const complex<double> &dF_Nm1)
{
  class array<complex<double> > e(N) , f(N) , g(N);
  
  class vector_class<complex<double> > b(N);

  const complex<double> Dr_deb = r_table(1)   - r_table(0);
  const complex<double> Dr_end = r_table(Nm1) - r_table(Nm2);
  
  f(0) = -0.333333333333333*Dr_deb;
  g(0) = -0.166666666666667*Dr_deb; 
  b(0) = dF0 - (F_table(1) - F_table(0))/Dr_deb;

  e(Nm2) = 0.166666666666667*Dr_end;
  f(Nm1) = 0.333333333333333*Dr_end;
  b(Nm1) = dF_Nm1 - (F_table(Nm1) - F_table(Nm2))/Dr_end;
	
  for (unsigned int i = 1 ; i < Nm1 ; i++)
    {
      const unsigned int im1 = i-1;

      const complex<double> Dr_ip1 = r_table(i+1) - r_table(i);
      const complex<double> Dr_i   = r_table(i)   - r_table(im1);

      e(im1) = (i > 1) ? (g(im1)) : (-g(0));
      f(i) = 0.333333333333333*(Dr_ip1 + Dr_i);
      g(i) = 0.166666666666667*Dr_ip1;
      b(i) = (F_table(i+1) - F_table(i))/Dr_ip1 - (F_table(i) - F_table(im1))/Dr_i;
    }

  const class vector_class<complex<double> > x = tridiagonal_linear_system_solution (e , f , g , b);
  
  splines_coeff_tab.allocate (Nm1 , 4);
    
  for (unsigned int i = 0 ; i < Nm1 ; i++)
    {   
      const complex<double> Dr = r_table(i+1) - r_table(i) , one_over_Dr = 1.0/Dr;
      
      splines_coeff_tab(i , 3) = 0.166666666666667*(x(i+1) - x(i))*one_over_Dr;
      splines_coeff_tab(i , 2) = 0.5*x(i);
      splines_coeff_tab(i , 1) = (F_table(i+1) - F_table(i))*one_over_Dr - (splines_coeff_tab(i , 3)*Dr + splines_coeff_tab(i , 2))*Dr;
      splines_coeff_tab(i , 0) = F_table(i);
    }
}






// Determination of the derivative and primitiveitive of splines 
// --------------------------------------------------------
// Direct differentiation or derivation of the cubic splines is used

void complex_splines_class::splines_derivative_primitive_tables_alloc_calc ()
{
  splines_coeff_derivative_tab.allocate (Nm1 , 3);
  
  for (unsigned int i = 0 ; i < Nm1 ; i++) 
    for (unsigned int j = 0 ; j < 2 ; j++)
      {
	const unsigned int jp1 = j + 1;
	
	splines_coeff_derivative_tab(i , j) = jp1*splines_coeff_tab(i , jp1);
      }
  
  splines_coeff_primitive_tab.allocate (Nm1 , 5);
  
  if (Nm1 > 0)
    {
      splines_coeff_primitive_tab(0 , 0) = 0.0;

      for (unsigned int j = 1 ; j < 5 ; j++)
	{
	  const unsigned int jm1 = j - 1;
	  
	  splines_coeff_primitive_tab(0 , j) = splines_coeff_tab(0 , jm1)/static_cast<double> (j);
	}
    }
  
  for (unsigned int i = 1 ; i < Nm1 ; i++)
    {
      const unsigned int im1 = i - 1;
      
      splines_coeff_primitive_tab(i , 0) = polynomial_evaluation_indexed<complex<double> > (im1 , 4 , splines_coeff_primitive_tab , r_table(i) - r_table(im1));
      
      for (unsigned int j = 1 ; j < 5 ; j++)
	{
	  const unsigned int jm1 = j - 1;
	  
	  splines_coeff_primitive_tab(i , j) = splines_coeff_tab(i , jm1)/static_cast<double> (j);
	}
    }
}






// Calculation of a function f in r by spline interpolation.
// -----------------------------------------------------------
// Knowing r,  the interval i in which r is is the largest integer close to (r - r0)*one_over_step if one has equally spaced abscissas, 
// except if (r - r0)*one_over_step = N-1 : the interval index is then N-2 because of side effects.
// If one does not have equally spaced abscissas,  one has to find r with a bisection method.
//
// f can F, F' or its primitiveitive IF.
// 
// Variables :
// -----------
// i, x : x=r-r_table(i),  with i the interval index : r >= r_table(i),  and r < r_table(i+1) if r < r_table(N-1). 
// If r < r0 or r > r_Nm1,  one uses respectively the spline of i=0 or i=N-2. 
// fr : f(r) calculated by splines interpolation.

complex<double> complex_splines_class::f_interpolated_r (const class array<complex<double > > &coeffs , const complex<double> &r) const
{
  const unsigned int degree = coeffs.dimension (1) - 1;
  
  if (is_it_equally_spaced) 
    {
      const int i = make_int (floor (real ((r - r0)*one_over_step)));

      if (i >= make_int (Nm1)) 
	return polynomial_evaluation_indexed<complex<double> > (Nm2 , degree , coeffs , r - r_table(Nm2));
      else if (i <= 0)
	return polynomial_evaluation_indexed<complex<double> > (0   , degree , coeffs , r - r_table(0));
      else
	return polynomial_evaluation_indexed<complex<double> > (i   , degree , coeffs , r - r_table(i));
    }
  else
    {
      if (real ((r - r_Nm1)*one_over_step) > 0.0) return polynomial_evaluation_indexed<complex<double> > (Nm2 , degree , coeffs , r - r_table(Nm2));
      if (real ((r - r0)*one_over_step) < 0.0)    return polynomial_evaluation_indexed<complex<double> > (0   , degree , coeffs , r - r_table(0));

      unsigned int i_deb = 0 , i_end = Nm1;
      double x_deb = real ((r - r0) * one_over_step);

      do
	{
	  const unsigned int i_mid = i_deb + (i_end - i_deb)/2;
	  const double x_mid = real ((r - r_table(i_mid)) * one_over_step);
 
	  if (SIGN (x_deb) != SIGN (x_mid))
	    i_end = i_mid;
	  else 
	    {
	      i_deb = i_mid;
	      x_deb = x_mid;
	    }
	}
      while ((i_end - i_deb) > 1);

      return polynomial_evaluation_indexed<complex<double> > (i_deb , degree , coeffs , r - r_table(i_deb));
    }
}








complex<double> complex_splines_class::operator () (const complex<double> &r) const
{
  return f_interpolated_r (splines_coeff_tab , r);
}

complex<double> complex_splines_class::derivative (const complex<double> &r) const
{
  return f_interpolated_r (splines_coeff_derivative_tab , r);
}

complex<double> complex_splines_class::primitive (const complex<double> &r) const
{
  return f_interpolated_r (splines_coeff_primitive_tab , r);
}



#ifdef UseMPI

void complex_splines_class::allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  MPI_helper::Bcast<unsigned int> (N , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm2 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r0 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r_Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<bool> (is_it_equally_spaced , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (one_over_step , sending_process , MPI_COMM_WORLD);
  
  if (THIS_PROCESS != sending_process)
    {
      r_table.allocate (N);
      splines_coeff_tab.allocate (Nm1 , 4);
      splines_coeff_derivative_tab.allocate (Nm1 , 3);
      splines_coeff_primitive_tab.allocate (Nm1 , 5);
    }
  
  r_table.MPI_Bcast (sending_process , MPI_C);
  splines_coeff_tab.MPI_Bcast (sending_process , MPI_C);
  splines_coeff_derivative_tab.MPI_Bcast (sending_process , MPI_C);
  splines_coeff_primitive_tab.MPI_Bcast (sending_process , MPI_C);
}

#endif


double used_memory_calc (const class complex_splines_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.r_table) + used_memory_calc (T.splines_coeff_tab) + used_memory_calc (T.splines_coeff_derivative_tab) + used_memory_calc (T.splines_coeff_primitive_tab) - (sizeof (T.r_table) + sizeof (T.splines_coeff_tab) + sizeof (T.splines_coeff_derivative_tab) + sizeof (T.splines_coeff_primitive_tab))/1000000.0);
}


// Class calculating moments of a function from its spline approximation
// ----------------------------------------------------------------------
// One calculates here \int_{r0}^{r} f(x) x^alpha dx ,  
// where f(x) is given from its spline approximation and alpha is an integer.
//



// Constructor:
// ------------
// 
// Variables :
// -----------
// alpha : used moment in \int_{r0}^{r} f(x) x^alpha dx
// F : spline class containing the spline approximation of f(x)
// N : number of points

complex_splines_moment_class::complex_splines_moment_class () : N (0) , Nm1 (0) , Nm2 (0) , r0 (0.0) , r_Nm1 (0.0) , one_over_step (0.0) , is_it_equally_spaced (false) {}

complex_splines_moment_class::complex_splines_moment_class (const int alpha_c , const class complex_splines_class &F)
{
  allocate_calc (alpha_c , F);
}


complex_splines_moment_class::complex_splines_moment_class (const class complex_splines_moment_class &X)
{
  allocate_fill (X);
}


void complex_splines_moment_class::allocate_calc (const int alpha_c , const class complex_splines_class &F)
{
  alpha = alpha_c; 
  N = F.N;
  Nm1 = F.Nm1;
  Nm2 = F.Nm2;
  r0 = F.r0;
  r_Nm1 = F.r_Nm1;
  one_over_step = F.one_over_step;
  is_it_equally_spaced = F.is_it_equally_spaced;

  r_table.allocate_fill (F.r_table);

  coeff_r_basis_tab.allocate (Nm1 , 4);
  r_alpha_powers_tab.allocate (Nm1 , 4);
  log_r_tab.allocate (Nm1);

  moments_tab.allocate (Nm1);
    
  for (unsigned int i = 0 ; i < Nm1 ; i++) 
    {
      const complex<double> ri = r_table(i) , ri_2 = ri*ri , ri_3 = ri*ri_2;
      const complex<double> splines_coeff_i0 = F.splines_coeff_tab(i , 0) , splines_coeff_i1 = F.splines_coeff_tab(i , 1);
      const complex<double> splines_coeff_i2 = F.splines_coeff_tab(i , 2) , splines_coeff_i3 = F.splines_coeff_tab(i , 3);
      
      coeff_r_basis_tab(i , 0) = -splines_coeff_i3*ri_3 + splines_coeff_i2*ri_2 - splines_coeff_i1*ri + splines_coeff_i0;
      coeff_r_basis_tab(i , 1) = 3.0*splines_coeff_i3*ri_2 - 2.0*splines_coeff_i2*ri + splines_coeff_i1;
      coeff_r_basis_tab(i , 2) = -3.0*splines_coeff_i3*ri + splines_coeff_i2;
      coeff_r_basis_tab(i , 3) = splines_coeff_i3;
      
      r_alpha_powers_tab(i , 0) = pow (ri , alpha + 1) ,  r_alpha_powers_tab(i , 1) = pow (ri , alpha + 2);
      r_alpha_powers_tab(i , 2) = pow (ri , alpha + 3) ,  r_alpha_powers_tab(i , 3) = pow (ri , alpha + 4);
      
      log_r_tab(i) = log (ri);
    }
  
  moments_tab(0) = 0.0;
  
  for (unsigned int i = 1 ; i < Nm1 ; i++) 
    {
      const unsigned int im1 = i-1;
      const int alpha_plus_one = alpha + 1 , alpha_plus_two = alpha + 2 , alpha_plus_three = alpha + 3 , alpha_plus_four = alpha + 4;
      
      const complex<double> log_r_im1 = log_r_tab(im1) , log_ri = log_r_tab(i);
	
      const complex<double> r_im1_pow_alpha_plus_one = r_alpha_powers_tab(im1 , 0) , r_im1_pow_alpha_plus_two = r_alpha_powers_tab(im1 , 1);
      const complex<double> r_im1_pow_alpha_plus_three = r_alpha_powers_tab(im1 , 2) , r_im1_pow_alpha_plus_four = r_alpha_powers_tab(im1 , 3);
      const complex<double> ri_pow_alpha_plus_one = r_alpha_powers_tab(i , 0) , ri_pow_alpha_plus_two = r_alpha_powers_tab(i , 1);
      const complex<double> ri_pow_alpha_plus_three = r_alpha_powers_tab(i , 2) , ri_pow_alpha_plus_four = r_alpha_powers_tab(i , 3);
      
      const complex<double> coeff_r_basis_im1_0 = coeff_r_basis_tab(im1 , 0) , coeff_r_basis_im1_1 = coeff_r_basis_tab(im1 , 1);
      const complex<double> coeff_r_basis_im1_2 = coeff_r_basis_tab(im1 , 2) , coeff_r_basis_im1_3 = coeff_r_basis_tab(im1 , 3);
      
      const complex<double> I0 = (alpha_plus_one == 0)   ? (log_ri - log_r_im1) : ((ri_pow_alpha_plus_one   - r_im1_pow_alpha_plus_one)/alpha_plus_one);
      const complex<double> I1 = (alpha_plus_two == 0)   ? (log_ri - log_r_im1) : ((ri_pow_alpha_plus_two   - r_im1_pow_alpha_plus_two)/alpha_plus_two);
      const complex<double> I2 = (alpha_plus_three == 0) ? (log_ri - log_r_im1) : ((ri_pow_alpha_plus_three - r_im1_pow_alpha_plus_three)/alpha_plus_three);
      const complex<double> I3 = (alpha_plus_four == 0)  ? (log_ri - log_r_im1) : ((ri_pow_alpha_plus_four  - r_im1_pow_alpha_plus_four)/alpha_plus_four);
      
      moments_tab(i) = moments_tab(im1) + coeff_r_basis_im1_0*I0 + coeff_r_basis_im1_1*I1 + coeff_r_basis_im1_2*I2 + coeff_r_basis_im1_3*I3;
    }
}





void complex_splines_moment_class::allocate_fill (const class complex_splines_moment_class &X)
{
  alpha = X.alpha; 
  N = X.N; 
  Nm1 = X.Nm1; 
  Nm2 = X.Nm2; 
  r0 = X.r0; 
  r_Nm1 = X.r_Nm1; 
  one_over_step = X.one_over_step; 
  is_it_equally_spaced = X.is_it_equally_spaced;
  
  r_table.allocate_fill (X.r_table);
  
  coeff_r_basis_tab.allocate_fill (X.coeff_r_basis_tab);
  
  r_alpha_powers_tab.allocate_fill (X.r_alpha_powers_tab);
 
  log_r_tab.allocate_fill (X.log_r_tab);
 
  moments_tab.allocate_fill (X.moments_tab);
}





void complex_splines_moment_class::deallocate ()
{
  r_table.deallocate ();
  
  coeff_r_basis_tab.deallocate ();
  
  r_alpha_powers_tab.deallocate ();
  
  log_r_tab.deallocate ();
  
  moments_tab.deallocate ();
  
  alpha = 0.0;
  N = 0;
  Nm1 = 0;
  Nm2 = 0;
  r0 = 0.0;
  r_Nm1 = 0;
  one_over_step = 0.0;
  is_it_equally_spaced = false;
}











// Calculation of the function F in r by spline interpolation.
// -----------------------------------------------------------
// Knowing r,  the interval i in which r is is the largest integer close to (r - r0)*one_over_step if one has equally spaced abscissas, 
// except if (r - r0)*one_over_step = N-1 : the interval index is then N-2 because of boundary effects.
// If one does not have equally spaced abscissas,  one has to find r with a bisection method.
// 
// Variables :
// -----------
// i, x : x = r-r_table(i),  with i the interval index : r >= r_table(i),  and r < r_table(i+1) if r < r_table(N-1). 
// If r < r0 or r > r_Nm1,  one uses respectively the spline of i = 0 or i = N-2. 

complex<double> complex_splines_moment_class::operator () (const complex<double> &r) const
{
  if (is_it_equally_spaced) 
    {
      const int i = make_int (floor (real ((r - r0)*one_over_step)));

      if (i >= make_int (Nm1)) 
	return moment_calc (Nm2 , r);
      else if (i <= 0)
	return moment_calc (0 , r);
      else
	return moment_calc (i , r);
    }
  else
    {
      if (real ((r - r_Nm1)*one_over_step) > 0.0) return moment_calc (Nm2 , r);
      if (real ((r - r0)*one_over_step) < 0.0)    return moment_calc (0 , r);

      unsigned int i_deb = 0 , i_end = Nm1;
      double x_deb = real ((r - r0) * one_over_step);

      do
	{
	  const unsigned int i_mid = i_deb + (i_end - i_deb)/2;
	  const double x_mid = real ((r - r_table(i_mid)) * one_over_step);

	  if (SIGN (x_deb) != SIGN (x_mid))
	    i_end = i_mid;
	  else 
	    {
	      i_deb = i_mid;
	      x_deb = x_mid;
	    }
	}
      while ((i_end - i_deb) > 1);

      return moment_calc (i_deb , r);
    }
}



complex<double> complex_splines_moment_class::moment_calc (const unsigned int i , const complex<double> &r) const
{
  const int alpha_plus_one = alpha + 1 , alpha_plus_two = alpha + 2 , alpha_plus_three = alpha + 3 , alpha_plus_four = alpha + 4;

  const complex<double> log_ri = log_r_tab(i);
  const complex<double> r_pow_alpha_plus_one = pow (r , alpha_plus_one) , r_pow_alpha_plus_two = r*r_pow_alpha_plus_one;
  const complex<double> r_pow_alpha_plus_three = r*r_pow_alpha_plus_two , r_pow_alpha_plus_four = r*r_pow_alpha_plus_three;

  const complex<double> ri_pow_alpha_plus_one = r_alpha_powers_tab(i , 0) , ri_pow_alpha_plus_two = r_alpha_powers_tab(i , 1);
  const complex<double> ri_pow_alpha_plus_three = r_alpha_powers_tab(i , 2) , ri_pow_alpha_plus_four = r_alpha_powers_tab(i , 3);

  const complex<double> coeff_r_basis_i0 = coeff_r_basis_tab(i , 0) , coeff_r_basis_i1 = coeff_r_basis_tab(i , 1);
  const complex<double> coeff_r_basis_i2 = coeff_r_basis_tab(i , 2) , coeff_r_basis_i3 = coeff_r_basis_tab(i , 3);

  const complex<double> I0 = (alpha_plus_one == 0)   ? (log (r) - log_ri) : ((r_pow_alpha_plus_one   - ri_pow_alpha_plus_one)/alpha_plus_one);
  const complex<double> I1 = (alpha_plus_two == 0)   ? (log (r) - log_ri) : ((r_pow_alpha_plus_two   - ri_pow_alpha_plus_two)/alpha_plus_two);
  const complex<double> I2 = (alpha_plus_three == 0) ? (log (r) - log_ri) : ((r_pow_alpha_plus_three - ri_pow_alpha_plus_three)/alpha_plus_three);
  const complex<double> I3 = (alpha_plus_four == 0)  ? (log (r) - log_ri) : ((r_pow_alpha_plus_four  - ri_pow_alpha_plus_four)/alpha_plus_four);

  const complex<double> moment = moments_tab(i) + coeff_r_basis_i0*I0 + coeff_r_basis_i1*I1 + coeff_r_basis_i2*I2 + coeff_r_basis_i3*I3;

  return moment;
}




#ifdef UseMPI

void complex_splines_moment_class::allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  MPI_helper::Bcast<int> (alpha , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (N , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm2 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r0 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r_Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<bool> (is_it_equally_spaced , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (one_over_step , sending_process , MPI_COMM_WORLD);
  
  if (THIS_PROCESS != sending_process)
    {
      r_table.allocate (N);
      coeff_r_basis_tab.allocate (Nm1 , 4);
      r_alpha_powers_tab.allocate (Nm1 , 4);
      log_r_tab.allocate (Nm1);
      moments_tab.allocate (Nm1);
    }
  
  r_table.MPI_Bcast (sending_process , MPI_C);
  coeff_r_basis_tab.MPI_Bcast (sending_process , MPI_C);
  r_alpha_powers_tab.MPI_Bcast (sending_process , MPI_C);
  log_r_tab.MPI_Bcast (sending_process , MPI_C);
  moments_tab.MPI_Bcast (sending_process , MPI_C);
}

#endif


double used_memory_calc (const class complex_splines_moment_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.r_table) + used_memory_calc (T.log_r_tab) + used_memory_calc (T.r_alpha_powers_tab) + used_memory_calc (T.coeff_r_basis_tab) + used_memory_calc (T.moments_tab) - (sizeof (T.r_table) + sizeof (T.log_r_tab) + sizeof (T.r_alpha_powers_tab) + sizeof (T.coeff_r_basis_tab) + sizeof (T.moments_tab))/1000000.0);
}





// Class calculating a scaled integrated function from its spline approximation
// ----------------------------------------------------------------------------
// One calculates here \int_{r0}^{r} f(x) exp (alpha.(x-r)) dx ,  
// where f(x) is given from its spline approximation and alpha is complex
// alpha must be non-zero.



// Constructor:
// ------------
//
// Variables :
// -----------
// alpha : used exponent in \int_{r0}^{r} f(x) exp (alpha.(x-r)) dx
// F : spline class containing the spline approximation of f(x)
// N : number of points

complex_splines_scaled_integration_class::complex_splines_scaled_integration_class () : N (0) , Nm1 (0) , Nm2 (0) , r0 (0.0) , r_Nm1 (0.0) , one_over_step (0.0) , is_it_equally_spaced (false) {}

complex_splines_scaled_integration_class::complex_splines_scaled_integration_class (const complex<double> &alpha_c , const class complex_splines_class &F)
{
  allocate_calc (alpha_c , F);
}

complex_splines_scaled_integration_class::complex_splines_scaled_integration_class (const class complex_splines_scaled_integration_class &X)
{
  allocate_fill (X);
}





void complex_splines_scaled_integration_class::allocate_calc (const complex<double> &alpha_c , const class complex_splines_class &F)
{
  if (alpha_c == 0.0) error_message_print_abort ("alpha must be non-zero in complex_splines_scaled_integration_class.");
    
  alpha = alpha_c; 
  N = F.N; 
  Nm1 = F.Nm1; 
  Nm2 = F.Nm2; 
  r0 = F.r0; 
  r_Nm1 = F.r_Nm1; 
  one_over_step = F.one_over_step; 
  is_it_equally_spaced = F.is_it_equally_spaced;

  r_table.allocate_fill (F.r_table);

  splines_coeff_tab.allocate_fill (F.splines_coeff_tab);

  scaled_integrals_tab.allocate (Nm2);

  for (unsigned int i = 0 ; i < Nm2 ; i++) 
    {
      const complex<double> ri = r_table(i) , r_ip1 = r_table(i+1) , d = r_ip1 - ri;
      const complex<double> exp_alpha_d = exp (alpha*d) , d_exp_alpha_d = d*exp_alpha_d , d2_exp_alpha_d = d*d_exp_alpha_d , d3_exp_alpha_d = d*d2_exp_alpha_d;

      const complex<double> splines_coeff_i0 = splines_coeff_tab(i , 0) , splines_coeff_i1 = splines_coeff_tab(i , 1);
      const complex<double> splines_coeff_i2 = splines_coeff_tab(i , 2) , splines_coeff_i3 = splines_coeff_tab(i , 3);

      const complex<double> I0 = (exp_alpha_d - 1.0)/alpha , I1 = (d_exp_alpha_d - I0)/alpha , I2 = (d2_exp_alpha_d - 2.0*I1)/alpha , I3 = (d3_exp_alpha_d - 3.0*I2)/alpha;

      scaled_integrals_tab(i) = splines_coeff_i0*I0 + splines_coeff_i1*I1 + splines_coeff_i2*I2 + splines_coeff_i3*I3;
    }
}




void complex_splines_scaled_integration_class::allocate_fill (const class complex_splines_scaled_integration_class &X)
{   
  alpha = X.alpha; 
  N = X.N; 
  Nm1 = X.Nm1; 
  Nm2 = X.Nm2; 
  r0 = X.r0; 
  r_Nm1 = X.r_Nm1; 
  one_over_step = X.one_over_step; 
  is_it_equally_spaced = X.is_it_equally_spaced;

  r_table.allocate_fill (X.r_table);
    
  splines_coeff_tab.allocate_fill (X.splines_coeff_tab);

  scaled_integrals_tab.allocate_fill (X.scaled_integrals_tab);
}




void complex_splines_scaled_integration_class::deallocate ()
{
  r_table.deallocate ();
  
  splines_coeff_tab.deallocate ();
  
  scaled_integrals_tab.deallocate ();

  alpha = 0.0;
  N = 0;
  Nm1 = 0;
  Nm2 = 0;
  r0 = 0.0;
  r_Nm1 = 0;
  one_over_step = 0.0;
  is_it_equally_spaced = false;
}




// Calculation of the function F in r by spline interpolation.
// -----------------------------------------------------------
// Knowing r,  the interval i in which r is is the largest integer close to (r - r0)*one_over_step if one has equally spaced abscissas, 
// except if (r - r)0*one_over_step = N-1 : the interval index is then N-2 because of boundary effects.
// If one does not have equally spaced abscissas,  one has to find r with a bisection method.
// 
// Variables :
// -----------
// i, x : x = r-r_table(i),  with i the interval index : r >= r_table(i),  and r < r_table(i+1) if r < r_table(N-1).
// If r < r0 or r > r_Nm1,  one uses respectively the spline of i = 0 or i = N-2. 

complex<double> complex_splines_scaled_integration_class::operator () (const complex<double> &r) const
{
  if (is_it_equally_spaced) 
    {
      const int i = make_int (floor (real ((r - r0)*one_over_step)));

      if (i >= make_int (Nm1)) 
	return scaled_integral_calc (Nm2 , r);
      else if (i <= 0)
	return scaled_integral_calc (0 , r);
      else
	return scaled_integral_calc (i , r);
    }
  else
    {
      if (real ((r - r_Nm1)*one_over_step) > 0.0) return scaled_integral_calc (Nm2 , r);
      if (real ((r - r0)*one_over_step) < 0.0)    return scaled_integral_calc (0 , r);

      unsigned int i_deb = 0 , i_end = Nm1;
      double x_deb = real ((r - r0) * one_over_step);

      do
	{
	  const unsigned int i_mid = i_deb + (i_end - i_deb)/2;
	  const double x_mid = real ((r - r_table(i_mid)) * one_over_step);

	  if (SIGN (x_deb) != SIGN (x_mid))
	    i_end = i_mid;
	  else 
	    {
	      i_deb = i_mid;
	      x_deb = x_mid;
	    }
	}
      while ((i_end - i_deb) > 1);

      return scaled_integral_calc (i_deb , r);
    }
}



complex<double> complex_splines_scaled_integration_class::scaled_integral_calc (const unsigned int i , const complex<double> &r) const
{
  const complex<double> ri = r_table(i) , d = r - ri , d2 = d*d , d3 = d*d2;
  
  const complex<double> scaled_I0 = (1.0 - exp (-alpha*d))/alpha;
  const complex<double> scaled_I1 = (d - scaled_I0)/alpha;  
  const complex<double> scaled_I2 = (d2 - 2.0*scaled_I1)/alpha;
  const complex<double> scaled_I3 = (d3 - 3.0*scaled_I2)/alpha;

  const complex<double> splines_coeff_i0 = splines_coeff_tab(i , 0) , splines_coeff_i1 = splines_coeff_tab(i , 1);
  const complex<double> splines_coeff_i2 = splines_coeff_tab(i , 2) , splines_coeff_i3 = splines_coeff_tab(i , 3);

  complex<double> scaled_integral = 0.0;

  for (unsigned int j = 0 ; j < i ; j++)
    {
      const complex<double> rj = r_table(j);
      scaled_integral += exp (alpha*(rj - r))*scaled_integrals_tab(j);
    }

  scaled_integral += splines_coeff_i0*scaled_I0 + splines_coeff_i1*scaled_I1 + splines_coeff_i2*scaled_I2 + splines_coeff_i3*scaled_I3;

  return scaled_integral;
}







#ifdef UseMPI

void complex_splines_scaled_integration_class::allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C)
{
  MPI_helper::Bcast<complex<double> > (alpha , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (N , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<unsigned int> (Nm2 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r0 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (r_Nm1 , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<bool> (is_it_equally_spaced , sending_process , MPI_COMM_WORLD);
  MPI_helper::Bcast<complex<double> > (one_over_step , sending_process , MPI_COMM_WORLD);
  
  if (THIS_PROCESS != sending_process)
    {
      r_table.allocate (N);
      splines_coeff_tab.allocate (Nm1 , 4);
      scaled_integrals_tab.allocate (Nm2);
    }
  
  r_table.MPI_Bcast (sending_process , MPI_C);
  splines_coeff_tab.MPI_Bcast (sending_process , MPI_C);
  scaled_integrals_tab.MPI_Bcast (sending_process , MPI_C);
}

#endif

double used_memory_calc (const class complex_splines_scaled_integration_class &T)
{
  return (sizeof (T)/1000000.0 + used_memory_calc (T.r_table) + used_memory_calc (T.splines_coeff_tab) + used_memory_calc (T.scaled_integrals_tab) - (sizeof (T.r_table) + sizeof (T.splines_coeff_tab) + sizeof (T.scaled_integrals_tab))/1000000.0);
}

