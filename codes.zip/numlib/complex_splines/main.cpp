#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
    
    const unsigned int N = 1000 ;
    const unsigned int N_big = 5677;

    const double xmin = 1;
    const double xmax = 10;

    const double theta = 0.125*M_PI;

    const double cos_theta = cos (theta);
    const double sin_theta = sin (theta);

    const double sample = 0.005;

    const complex<double> exp_Itheta(cos_theta , sin_theta);

    const complex<double> step = (xmax - xmin)*exp_Itheta/static_cast<double> (N - 1);

    const complex<double> step_big = (xmax - xmin)*exp_Itheta/static_cast<double> (N_big - 1);

    const int alpha = 3;
    
    const complex<double> beta(1.1 , 0.1);

    class array<complex<double> > r_tab(N);
    class array<complex<double> > f_tab(N);
    class array<complex<double> > g_tab(N);

    for (unsigned int i = 0 ; i < N ; i++)
      {
	const complex<double> r = (xmin + i*step)*exp_Itheta;
	
	r_tab(i) = r;
	f_tab(i) = pow (r , beta);
	g_tab(i) = pow (r , beta+1);
      }

    const complex<double> r_deb = r_tab(0) , r_end = r_tab(N-1);

    const class complex_splines_class f1_splines(r_tab , f_tab);
    const class complex_splines_class f2_splines(r_tab , f_tab , beta*pow (r_deb , beta-1) , beta*pow (r_end , beta-1));
    const class complex_splines_class g2_splines(r_tab , g_tab , (beta+1)*pow (r_deb , beta) , (beta+1)*pow (r_end , beta));
    
    const class complex_splines_moment_class moments(alpha , f2_splines);

    const class complex_splines_scaled_integration_class f_scaled(alpha , f2_splines);
    const class complex_splines_scaled_integration_class g_scaled(alpha , g2_splines);

    for (unsigned int i = 0 ; i < N_big ; i++)
      if (random_number<double> () < sample)
	{
	  const complex<double> z = (xmin + i*step_big)*exp_Itheta;

	  const complex<double> f1_z      = f1_splines(z);
	  const complex<double> f1_z_der  = f1_splines.derivative (z);
	  const complex<double> f1_z_prim = f1_splines.primitive (z);

	  const complex<double> f2_z      = f2_splines(z);
	  const complex<double> f2_z_der  = f2_splines.derivative (z);
	  const complex<double> f2_z_prim = f2_splines.primitive (z);
	  
	  const complex<double> f2_moment = moments(z);

	  const complex<double> f_z = pow (z , beta);

	  const complex<double> f_z_der = beta*pow (z , beta-1);

	  const complex<double> f_z_prim = pow (z , beta + 1)/(beta + 1) - pow (r_deb , beta + 1)/(beta + 1);
	  
	  const complex<double> f_moment = pow (z , alpha + beta + 1)/(alpha + beta + 1) - pow (r_deb , alpha + beta + 1)/(alpha + beta + 1);

	  const complex<double> f_scaled_z = f_scaled(z) , g_scaled_z = g_scaled(z);

	  //f_scaled_z_test is obtained from f_scaled_z via an integration by parts: t^beta is integrated and exp (alpha*(t - z)) differentiated.
	  
	  const complex<double> f_scaled_z_test = pow (z , beta + 1)/(beta + 1) - pow (r_deb , beta + 1)/(beta + 1)*exp (alpha*(r_deb - z)) - alpha/(beta+1)*g_scaled_z;

	  cout << " z : " << z << " f1 precision : "           << (inf_norm (f1_z - f_z))           << endl;
	  cout << " z : " << z << " f1' precision : "          << (inf_norm (f1_z_der - f_z_der))   << endl;
	  cout << " z : " << z << " f1 primitive precision : " << (inf_norm (f1_z_prim - f_z_prim)) << endl;

	  cout << " z : " << z << " f2 precision : "           << (inf_norm (f2_z - f_z))           << endl;
	  cout << " z : " << z << " f2' precision : "          << (inf_norm (f2_z_der - f_z_der))   << endl;
	  cout << " z : " << z << " f2 primitive precision : " << (inf_norm (f2_z_prim - f_z_prim)) << endl;

	  cout << " z : " << z << " f moment precision : " << (inf_norm (f2_moment - f_moment)) << endl;

	  cout << " z : " << z << " f scaled integral precision : " << (inf_norm (f_scaled_z - f_scaled_z_test)) << endl << endl;
	}

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
