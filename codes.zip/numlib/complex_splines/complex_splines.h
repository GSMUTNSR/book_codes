#ifndef COMPLEX_SPLINES_H
#define COMPLEX_SPLINES_H

// Class splines approximating a function given by a set of points. 
//------------------------------------------------------------------
// Complex type for all data
// Pointers are used instead of class array. It is more suitable for tables of splines coefficients, used in polynomial_evaluation.
// Other tables are defined as pointers for consistency in the class.
// T derivative and primitive of the spline function can be calculated exactly. The primitive of the splines is zero for its first point.

class complex_splines_class
{
public:

  // Constructor:
  // ------------
  // There are two constructors : 
  // 1) The derivatives at the interval limits are given (dF0 and dF_Nm1), and then the fit is optimal.
  // 2) They are not given, and are approximated with a 3 point formula within the constructor.
  //    The fit is less precise at the limits of the intervals.
  //
  //
  // Variables :
  // -----------
  // N : number of points of the discretized function.
  // r_table, F_table : tables of N points having the abscissas and values of F.
  // dr_0, dr_1 : r_table(1) - r_table(0), dr_2 = r_table(2) - r_table(0).
  // dF0 : approximate first derivative of F at the first point.
  // Nm3 : N-3
  // dr_Nm2, dr_Nm3 : r_table(Nm2) - r_table(Nm1), dr_Nm3 = r_table(Nm3) - r_table(Nm1).
  // dF_Nm1 : approximate first derivative of F at the last point.
  
  complex_splines_class ();
  
  complex_splines_class (
			 const class array<complex<double> > &r_table_c , 
			 const class array<complex<double> > &F_table);

  complex_splines_class (
			 const class array<complex<double> > &r_table_c , 
			 const class array<complex<double> > &F_table , 
			 const complex<double> &dF0 , 
			 const complex<double> &dF_Nm1);

  complex_splines_class (const class complex_splines_class &X);

  void allocate_calc (
		      const class array<complex<double> > &r_table_c , 
		      const class array<complex<double> > &F_table);

  void allocate_calc (
		      const class array<complex<double> > &r_table_c , 
		      const class array<complex<double> > &F_table , 
		      const complex<double> &dF0 , 
		      const complex<double> &dF_Nm1);

  void allocate_fill (const class complex_splines_class &X);

  void deallocate ();
  
  unsigned int get_N () const
  {
    return N;
  }
  
  complex<double> operator () (const complex<double> &r) const;
  complex<double> derivative (const complex<double> &r) const;
  complex<double> primitive (const complex<double> &r) const;

  friend class complex_splines_moment_class;
  friend class complex_splines_scaled_integration_class;
  
#ifdef UseMPI
  void allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class complex_splines_class &T);
  
private:
  
  unsigned int N , Nm1 , Nm2; // number of points of the discretized function ,  N-1 ,  N-2.
  complex<double> r0 , r_Nm1; // r0 = r_table(0), r_Nm1 = r_table(N-1).

  class array<complex<double> > r_table; // r_table : table containing the values of the abscissas.

  complex<double> one_over_step; // inverse of the length of the interval r_table(1) - r_table(0). 
                                 // It is the inverse of the table step if one has equally spaced abscissas.
  bool is_it_equally_spaced;     // true if one has equally spaced abscissas ,  false if not.

  class array<complex<double> > splines_coeff_tab;            // table containing the coefficients of the interpolating polynomials.
  class array<complex<double> > splines_coeff_derivative_tab; // table containing the coefficients of the derivative of the interpolating polynomials.
  class array<complex<double> > splines_coeff_primitive_tab;  // table containing the coefficients of the primitiveitive interpolating polynomials vanishing in r0.

  void splines_alloc_calc (const class array<complex<double> > &F_table , const complex<double> &dF0 , const complex<double> &dF_Nm1);
  
  void splines_derivative_primitive_tables_alloc_calc ();

  complex<double> f_interpolated_r (const class array<complex<double > > &coeffs , const complex<double> &r) const;
};





// Class calculating moments of a function from its spline approximation
// ----------------------------------------------------------------------
// One calculates here \int_{r0}^{r} f(x) x^alpha dx ,  
// where f(x) is given from its spline approximation and alpha is an integer.
//




class complex_splines_moment_class
{
public:

  // Constructor:
  // ------------
  //
  // Variables :
  // -----------
  // alpha : used moment in \int_{r0}^{r} f(x) x^alpha dx
  // F : spline class containing the spline approximation of f(x)
  // N : number of points
  
  complex_splines_moment_class ();
  complex_splines_moment_class (const int alpha_c , const class complex_splines_class &F);
  complex_splines_moment_class (const class complex_splines_moment_class &X);

  void allocate_calc (const int alpha_c , const class complex_splines_class &F);

  void allocate_fill (const class complex_splines_moment_class &X);

  void deallocate ();

  complex<double> operator() (const complex<double> &r) const;
 
#ifdef UseMPI
  void allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
#endif
  
  friend double used_memory_calc (const class complex_splines_moment_class &T);
  
private:
  int alpha; // used moment in \int_{r0}^{r} f(x) x^alpha dx

  unsigned int N , Nm1 , Nm2; // number of points of the discretized function ,  N-1 ,  N-2.

  complex<double> r0 , r_Nm1; // r0 = r_table(0),  r_Nm1 = r_table(N-1).
  
  class array<complex<double> > r_table;    // r_table : table containing the values of the abscissas.
  class array<complex<double> > log_r_tab;  // logarithms of r_table(i)

  complex<double> one_over_step; // inverse of the length of the interval r_table(1) - r_table(0). 
                                 // It is the inverse of the table step if one has equally spaced abscissas.
  
  bool is_it_equally_spaced;     // true if one has equally spaced abscissas ,  false if not.

  class array<complex<double> > r_alpha_powers_tab; // table containing r_table(i)^{alpha+n} ,  with n in {1 , 2 , 3 , 4}
  class array<complex<double> > coeff_r_basis_tab;  // table containing the coefficients of the interpolating polynomials as a polynomial in r.
  
  class array<complex<double> > moments_tab;        // values of \int_{r0}^{r_table(i)} f(x) x^alpha dx

  complex<double> moment_calc (const unsigned int i , const complex<double> &r) const;
};






// Class calculating a scaled integrated function from its spline approximation
// ----------------------------------------------------------------------------
// complex<double> : double or complex.
// One calculates here \int_{r0}^{r} f(x) exp (alpha.(x-r)) dx ,  
// where f(x) is given from its spline approximation and alpha is complex
// alpha must be non-zero.


class complex_splines_scaled_integration_class
{
public:

  // Constructor:
  // ------------
  //
  // Variables :
  // -----------
  // alpha : used exponent in \int_{r0}^{r} f(x) exp (alpha.(x-r)) dx
  // F : spline class containing the spline approximation of f(x)
  // N : number of points
  
  complex_splines_scaled_integration_class ();
  complex_splines_scaled_integration_class (const complex<double> &alpha_c , const class complex_splines_class &F);
  complex_splines_scaled_integration_class (const class complex_splines_scaled_integration_class &X);

  void allocate_calc (const complex<double> &alpha_c , const class complex_splines_class &F);

  void allocate_fill (const class complex_splines_scaled_integration_class &X);

  void deallocate ();
  
  complex<double> operator () (const complex<double> &r) const;
    
#ifdef UseMPI
  void allocate_MPI_Bcast (const unsigned int sending_process , const MPI_Comm MPI_C);
#endif

  friend double used_memory_calc (const class complex_splines_scaled_integration_class &T);
  
private:
  
  complex<double> alpha;       // used exponent in \int_{r0}^{r} f(x) exp (alpha.(x-r)) dx

  unsigned int N , Nm1 , Nm2;  // number of points of the discretized function ,  N-1 ,  N-2.

  complex<double> r0 , r_Nm1;  // r0 = r_table(0),  r_Nm1 = r_table(N-1).
  
  class array<complex<double> > r_table; // r_table : table containing the values of the abscissas.

  complex<double> one_over_step; // inverse of the length of the interval r_table(1) - r_table(0). 
                                 // It is the inverse of the table step if one has equally spaced abscissas.
  
  bool is_it_equally_spaced;     // true if one has equally spaced abscissas ,  false if not.

  class array<complex<double> > splines_coeff_tab;    // table containing the splines coefficients
  class array<complex<double> > scaled_integrals_tab; // values of \int_{r_table(i-1)}^{r_table(i)} f(x) exp (alpha.(x-r_table(i))) dx for i > 0. It is zero by definition for i = 0

  complex<double> scaled_integral_calc (const unsigned int i , const complex<double> &r) const;
};



#endif
