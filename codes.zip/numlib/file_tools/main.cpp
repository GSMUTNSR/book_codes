#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    if (elements_number<string> ("test_file") != 116) error_message_print_abort ("Problem with elements_number");
    
    if (lines_number<string> ("test_file") != 13) error_message_print_abort ("Problem with lines_number");

    const unsigned int N = 32;
    
    int *T = new int [N];

    for (unsigned int i = 0 ; i < N ; i++) T[i] = i;

    basic_copy_disk<int> ("test_unformatted_file" , N , T);

    unsigned int dimension;

    int *T_copy = NULL;

    alloc_read_disk<int> ("test_unformatted_file" , dimension , T_copy);

    if (dimension != N) error_message_print_abort ("Problem with alloc_read_disk (dimension)");

    for (unsigned int i = 0 ; i < N ; i++)
      {
	if (T[i] != T_copy[i]) error_message_print_abort ("Problem with alloc_read_disk (table)");
      }
    
    basic_read_disk<int> ("test_unformatted_file" , T_copy);

    for (unsigned int i = 0 ; i < N ; i++)
      {
	if (T[i] != T_copy[i]) error_message_print_abort ("Problem with basic_read_disk (without dimension)");
      }
    basic_read_disk<int> ("test_unformatted_file" , dimension , T_copy);

    for (unsigned int i = 0 ; i < N ; i++)
      {
	if (T[i] != T_copy[i]) error_message_print_abort ("Problem with basic_read_disk (with dimension)");
      }
    
    delete [] T;
    delete [] T_copy;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
