#include "../numlib_def/numlib_def.h"

// Check if file exists
// --------------------
void file_existence_check (const string &file_name , const ifstream &file)
{
  if (!file)
    error_message_print_abort ("Impossible to open " + file_name);
}




// Search for a string in a file
// ---------------------------- - 
void seek_string (const string &word , ifstream &file_in)
{ 
#ifdef UseMPI
  if (THIS_PROCESS != MASTER_PROCESS) error_message_print_abort ("Only master process in seek_string.");
#endif

  string reader;

  do
    {
      file_in >> reader;

      if (file_in.eof ())
	error_message_print_abort ("String '" + word + "' not found");
    }
  while (reader != word);
}





// Storage of the dimension of a table on a file

void dimension_copy_disk (const string &file_name , const unsigned int dimension)
{ 
  ofstream dimension_file(file_name.c_str() , ios::out);

  dimension_file << dimension << endl;
}



// Determination of the dimension of a table from the file where it is stored.

unsigned int dimension_read_disk (const string &file_name)
{ 
  ifstream dimension_file(file_name.c_str() , ios::in);

  file_existence_check (file_name , dimension_file);

  unsigned int dimension = 0;

  dimension_file >> dimension;

  return dimension;
}

unsigned int dimension_read_disk (const bool full_common_vectors_used_in_file , const string &file_name)
{
  if (full_common_vectors_used_in_file)
    {
      unsigned int dimension = 0;
      
      if (THIS_PROCESS == MASTER_PROCESS) dimension = dimension_read_disk (file_name);
      
#ifdef UseMPI
      MPI_helper::Bcast<unsigned int> (dimension , MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      return dimension;
    }
  else
    return dimension_read_disk (file_name);
}



// Determination of the dimension of a GSM vector from the file where it is stored.
// One can also read the file from the master process only and Bcast the dimension to all nodes.

unsigned int space_dimension_read_disk (
					const int Zval ,
					const int Nval ,
					const string &file_name)
{ 
  if ((Zval == 0) && (Nval == 0)) return 1;

  if (Zval == 0) return space_dimension_read_disk (Nval , file_name);
  if (Nval == 0) return space_dimension_read_disk (Zval , file_name);

  ifstream space_dimension_file(file_name.c_str() , ios::in);

  file_existence_check (file_name , space_dimension_file);

  unsigned int space_dimension = 0;

  space_dimension_file >> space_dimension;

  return space_dimension;
}




unsigned int space_dimension_read_disk (
					const bool full_common_vectors_used_in_file ,
					const int Zval ,
					const int Nval ,
					const string &file_name)
{
  if (full_common_vectors_used_in_file)
    {
      unsigned int space_dimension = 0;
      
      if (THIS_PROCESS == MASTER_PROCESS) space_dimension = space_dimension_read_disk (Zval , Nval , file_name);
      
#ifdef UseMPI
      MPI_helper::Bcast<unsigned int> (space_dimension , MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      return space_dimension;
    }
  else
    return space_dimension_read_disk (Zval , Nval , file_name);
}






unsigned int space_dimension_read_disk (
					const int Nval_mu ,
					const string &file_name)
{ 
  if (Nval_mu == 0) return 1;

  ifstream space_dimension_file(file_name.c_str() , ios::in);

  file_existence_check (file_name , space_dimension_file);

  unsigned int space_dimension = 0;

  space_dimension_file >> space_dimension;

  return space_dimension;
}


unsigned int space_dimension_read_disk (
					const bool full_common_vectors_used_in_file ,
					const int Nval_mu ,
					const string &file_name)
{
  if (full_common_vectors_used_in_file)
    {
      unsigned int space_dimension = 0;
  
      if (THIS_PROCESS == MASTER_PROCESS) space_dimension = space_dimension_read_disk (Nval_mu , file_name);

#ifdef UseMPI
      MPI_helper::Bcast<unsigned int> (space_dimension , MASTER_PROCESS , MPI_COMM_WORLD);
#endif

      return space_dimension;
    }
  else
    return space_dimension_read_disk (Nval_mu , file_name);
}




