#ifndef FILE_TOOLS_H
#define FILE_TOOLS_H

// Check if file exists
void file_existence_check (const string &file_name , const ifstream &file);

// seek_string. 
void seek_string (const string &word , ifstream &file_in);

// Storage of the dimension of a table on a file
void dimension_copy_disk (const string &file_name , const unsigned int dimension);
  
// Determination of the dimension of a table from the file where it is stored.
unsigned int dimension_read_disk (const string &file_name);
unsigned int dimension_read_disk (const bool full_common_vectors_used_in_file , const string &file_name);

// Determination of the dimension of a GSM vector from the file where it is stored.
// One can also read the file from the master process only and Bcast the dimension to all nodes.

unsigned int space_dimension_read_disk (const int Zval_parent , const int Nval_parent , const string &file_name);
unsigned int space_dimension_read_disk (const bool full_common_vectors_used_in_file , const int Zval_parent , const int Nval_parent , const string &file_name);

unsigned int space_dimension_read_disk (const int Nval_mu_parent , const string &file_name);
unsigned int space_dimension_read_disk (const bool full_common_vectors_used_in_file , const int Nval_mu_parent , const string &file_name);





// Storage of a table as unformatted data on disk. 
template<typename T>
void basic_copy_disk (const string &file_name , const unsigned int dimension , const T table[])
{
  ofstream file (file_name.c_str() , ios::binary);
  if (table != NULL) file.write (reinterpret_cast<char * > (const_cast<T * > (table)) , sizeof (T) * dimension);
  file.close();
}





/* Allocation and reading of a table stored as unformatted data on disk.
   The dimension is the number of characters of the file over the size of the type of the table. */

template<typename T>
void alloc_read_disk (const string &file_name , unsigned int &dimension , T * & table) 
{
  ifstream file(file_name.c_str() , ios::binary);
  file_existence_check (file_name , file);

  file.seekg (0 , ios::end);
  const unsigned int length = file.tellg();
  file.seekg (0 , ios::beg);

  dimension = length/sizeof (T);
  table = (dimension > 0) ? (new T [dimension]) : (NULL);

  if (dimension > 0) file.read (reinterpret_cast<char * > (table) , length);
  file.close ();
}







// Reading of a table stored as unformatted data on disk.
// -------------------------------------------------------------------- - 
// The table , already allocated if its dimension is larger than zero , is read from a file.

template<typename T>
void basic_read_disk (const string &file_name , T table[])
{
  ifstream file(file_name.c_str() , ios::binary);
  file_existence_check (file_name , file);

  file.seekg (0 , ios::end);

  const unsigned int length = file.tellg();

  if (length > 0) 
    {
      file.seekg (0 , ios::beg);
      file.read (reinterpret_cast<char * > (table) , length);
    }

  file.close ();
}





template<typename T>
void basic_read_disk (const string &file_name , const unsigned int dimension , T table[])
{
  ifstream file(file_name.c_str() , ios::binary);
  file_existence_check (file_name , file);

  if (dimension > 0) file.read (reinterpret_cast<char * > (table) , sizeof (T)*dimension);
  file.close ();
}







// Dimension of a table stored in a formatted file
// -----------------------------------------------

template<typename T>
unsigned int elements_number (const string &file_name)
{
  ifstream file(file_name.c_str ());
  file_existence_check (file_name , file);

  unsigned int number = 0;
  T dummy;
  
  while (!file.eof ())
    {
      file >> dummy;
      
      number++ ;
    }
  
  if (number > 0) number--;

  file.close ();

  return number;
}









// Number of lines in a formatted file
// -----------------------------------

template<typename T>
unsigned int lines_number (const string &file_name)
{
  ifstream file(file_name.c_str ());
  file_existence_check (file_name , file);

  file.unsetf (ios_base::skipws);
  const unsigned number = count (istream_iterator<char> (file) , istream_iterator<char> () , '\n');

  file.close ();

  return number;
}


#endif


