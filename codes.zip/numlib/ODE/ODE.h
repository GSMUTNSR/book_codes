#ifndef ODE_H
#define ODE_H

class ODE_integration
{
public:

  ODE_integration ();
  
  ODE_integration (
		   const void * ptr_c ,
		   complex<double> (* F_ptr_c) (const void * , const complex<double> & , const complex<double> &));

  ~ODE_integration ();

  void initialize (
		   const void * ptr_c ,
		   complex<double> (* F_ptr_c) (const void * , const complex<double> & , const complex<double> &));

  bool is_it_filled () const
  {
    return (ptr != NULL);
  }
 
  void operator() (
		   const complex<double> &z0 , 
		   const complex<double> &u0 , 
		   const complex<double> &du0 , 
		   const complex<double> &z , 
		   complex<double> &u , 
		   complex<double> &du) const;

private:

  complex<double> extrapolation_in_zero (const unsigned int n , const complex<double> T[]) const;

  void integration_Henrici (
			    const unsigned int m , 
			    const complex<double> &h , 
			    const complex<double> &z0 , 
			    const complex<double> &u0 , 
			    const complex<double> &du0 , 
			    const complex<double> &z , 
			    complex<double> &u , 
			    complex<double> &du) const;

  const void * ptr;                                                                            // pointer to a class containing all the parmeters related to the function to integrate

  complex<double> (* F_ptr) (const void * , const complex<double> & , const complex<double> &); // pointer to the function F(z,u) to integrate in the equation u''(z) = F(z,u(z))

  unsigned int m_tab[7];                   // integers used in the extrapolation method.

  double one_over_m_tab[7];                // doubles used in the extrapolation method.

  double interpolation_term_tab[28];       // doubles used in the extrapolation method.

  mutable complex<double>  u_end[7];       // complex numbers used for the extrapolation of u(r)
  mutable complex<double> du_end[7];       // complex numbers used for the extrapolation of u'(r)

  mutable complex<double> H_over_m_tab[7]; // complex numbers storing H/m, when one integrates from r0 to r = r0 + m.H
};

double used_memory_calc (const class ODE_integration &T);

#endif
