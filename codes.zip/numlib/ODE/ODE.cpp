#include "../numlib_def/numlib_def.h"



// Class allowing to integrate an equation of the form u''(z) = F(z,u(z))
// ----------------------------------------------------------------------
// One uses the Burlisch-Stoer-Henrici method , where one integrates on different meshes
// with the Henrici method , and then use the Richardson method to extrapolate the final result.





ODE_integration::ODE_integration () : ptr (NULL) , F_ptr (NULL) 
{
  for (int i = 0 ; i < 28 ; i++) interpolation_term_tab[i] = 0.0;

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 0.0;

      one_over_m_tab[k] = 0.0;

      u_end[k] = 0.0;

      du_end[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}

ODE_integration::ODE_integration (
				  const void * ptr_c ,
				  complex<double> (* F_ptr_c) (const void * , const complex<double> & , const complex<double> &))

  : ptr (ptr_c) ,
    F_ptr (F_ptr_c)
{
  for (int n = 0 ; n < 8 ; n++)
    for (int i = 0 ; i < n ; i++)
      {
	const int i_plus_one = i + 1;

	double interpolation_term = 1.0;

	for (int ii = 0 ; ii < n ; ii++)
	  {
	    if (i != ii) interpolation_term *= i_plus_one/static_cast<double> (i - ii);
	  }

	interpolation_term_tab[Richardson_interpolation_index (n , i)] = interpolation_term;
      }

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 2*(k + 1);
      
      one_over_m_tab[k] = 1.0/static_cast<double> (m_tab[k]);

      u_end[k] = 0.0;

      du_end[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}

ODE_integration::~ODE_integration () {}

void ODE_integration::initialize (
				  const void * ptr_c ,
				  complex<double> (* F_ptr_c) (const void * , const complex<double> & , const complex<double> &))


{
  ptr = ptr_c;
  
  F_ptr = F_ptr_c;
  
  for (int n = 0 ; n < 8 ; n++)
    for (int i = 0 ; i < n ; i++)
      {
	const int i_plus_one = i + 1;

	double interpolation_term = 1.0;

	for (int ii = 0 ; ii < n ; ii++)
	  {
	    if (i != ii) interpolation_term *= i_plus_one/static_cast<double> (i - ii);
	  }

	interpolation_term_tab[Richardson_interpolation_index (n , i)] = interpolation_term;
      }

  for (unsigned int k = 0 ; k < 7 ; k++)
    {
      m_tab[k] = 2*(k + 1);
      
      one_over_m_tab[k] = 1.0/static_cast<double> (m_tab[k]);

      u_end[k] = 0.0;

      du_end[k] = 0.0;

      H_over_m_tab[k] = 0.0;
    }
}


// Extrapolation in h=0 of a table of function values h close to h=0
// -----------------------------------------------------------------
//
// Variables:
// ----------
// n : number of points of the function f near h=0. It smaller or equal to 8.
// T : table containing the points f[h(0)]...f[h(n-1)] close to h=0.
// f_in_zero : extrapolated value of the points f[h(0)]...f[h(n-1)] in h=0.


complex<double> ODE_integration::extrapolation_in_zero (const unsigned int n , const complex<double> T[]) const
{  
  complex<double> f_in_zero = 0.0;

  for (unsigned int i = 0 ; i < n ; i++) f_in_zero += interpolation_term_tab[Richardson_interpolation_index (n , i)]*T[i];

  return f_in_zero;
}





// Integration with discretization of u''(z)=F(z , u(z)) with the Henrici method.
// ----------------------------------------------------------------------------
//
// See Numerical Recipes for the method.
//
// Initials conditions : z0 , u(z0) , du/dz(z0).
// Obtained functions : z , u(z) , du/dz(z).
//
// Variables:
// ----------
// m : number of intervals between z0 and z
// h : integration step (z-z0)/m .
// z0 , u0 , du0 : z0 , u(z0) , du/dz(z0).
// z , u , du : z , u(z) , du/dz(z).
// ri : radius inside [z0:r]. It is z0 + i.h .
// h_square : h*h
// half_h = 0.5*h
// delta : value used in the Henrici method.

void ODE_integration::integration_Henrici (
					   const unsigned int m , 
					   const complex<double> &h , 
					   const complex<double> &z0 , 
					   const complex<double> &u0 , 
					   const complex<double> &du0 , 
					   const complex<double> &r , 
					   complex<double> &u , 
					   complex<double> &du) const
{
  complex<double> (& F) (const void * , const complex<double> & , const complex<double> &) = *F_ptr;
  
  const complex<double> h_square = h*h;

  const complex<double> half_h = 0.5*h;

  complex<double> delta = h*(du0 + half_h*F (ptr , z0 , u0));

  u = u0 + delta;

  for (unsigned int i = 1 ; i < m ; i++)
    {
      const complex<double> ri = z0 + i*h;

      delta += h_square*F (ptr , ri , u);
      
      u += delta;
    }

  du = delta/h + half_h*F (ptr , r , u);
}







// Integration of u''(z) = F(z , u(z)) with the Bulirsch-Stoer method.
// -----------------------------------------------------------------
//
// Initials conditions : z0 , u0=u(z0) , du0=du/dz(z0)
// Obtained functions : z , u=u(z) , du=du/dz(z)
//
// See Numerical Recipes for the method.
//
// Variables:
// ---------- 
// z0 , u0 , du0 : z0 , u(z0) , du/dz(z0).
// z , u , du : z , u(z) , du/dz(z).
// H , z_debut , z_end , u_debut , du_debut : length of an integration interval , debut and end of the integration interval , u(z_debut) , u'(z_debut).
//                                    H is equal to z-z0 at the beginning and is divided by 2 each time the extrapolation fails with 16 sub-intervals 
//                                    between z_debut and z_end. If H = [z - z0]/N , with N=2 , 4 , 8 , 16 , ... , 
//                                    the integration intervals are [z_debut = z0:z_end = z0+H] , ... , [z_debut = z0+(N-1).H , z_end = z].
// u_end , du_end , k : tables of u(z_end) and u'(z_end) values calculated with the Henrici method with 2 , 4 , 6 , ... , 2(k+1) sub-intervals between z_debut and z_end , 
//                  with 0 <= k <= 7.
// H_over_m_tab : H/m for m=2 , 4 , 6 , ... , 16.
// inf_norm_half_H : |H/2|oo. It is used to know if z = z_debut up to numerical accuracy , as one has |r-z_debut|oo <= |H/2|oo for this case only.
// u_extrapolated , u_extrapolated_next : values of u extrapolated from the points of the table u_end with k and k->k+1 points , k >= 2.
// test : test to know if the method worked , i.e. , |u_extrapolated/u_extrapolated_next - 1|oo < precision.
// du_extrapolated_next : value of u'(z_end) extrapolated from k points of the table du_end , k >= 3.
// z_debut_plus_H : z_debut+H. z_debut+H at the end of integration is not necessarily z because of numerical cancellations.
//                             In this case , z_end must be put equal to z.

void ODE_integration::operator () (
				   const complex<double> &z0 , 
				   const complex<double> &u0 , 
				   const complex<double> &du0 , 
				   const complex<double> &z , 
				   complex<double> &u , 
				   complex<double> &du) const
{
  if (z == z0) 
    {
      u = u0; 
      du = du0; 

      return;
    }

  complex<double> z_debut = z0;

  complex<double>  u_debut =  u0;
  complex<double> du_debut = du0;

  complex<double> H = z - z0;

  complex<double>  u_extrapolated_next =  u0;
  complex<double> du_extrapolated_next = du0;

  double test = INFINITE;

  while (test > precision)
    {
      for (unsigned int k = 0 ; k < 7 ; k++) H_over_m_tab[k] = H*one_over_m_tab[k];

      const double inf_norm_half_H = inf_norm (H_over_m_tab[0]);

      while (inf_norm (z_debut - z) > inf_norm_half_H)
	{
	  const complex<double> z_debut_plus_H = z_debut + H;

	  const complex<double> z_end = (inf_norm (z - z_debut_plus_H) > inf_norm_half_H) ? (z_debut_plus_H) : (z);

	  integration_Henrici (2 , H_over_m_tab[0] , z_debut , u_debut , du_debut , z_end , u_end[0] , du_end[0]);
	  integration_Henrici (4 , H_over_m_tab[1] , z_debut , u_debut , du_debut , z_end , u_end[1] , du_end[1]);

	  complex<double> u_extrapolated = extrapolation_in_zero (2 , u_end);

	  unsigned int k = 2;

	  do
	    {
	      integration_Henrici (m_tab[k] , H_over_m_tab[k] , z_debut , u_debut , du_debut , z_end , u_end[k] , du_end[k]);

	      u_extrapolated_next = extrapolation_in_zero (++k , u_end);

	      test = inf_norm (u_extrapolated/u_extrapolated_next - 1.0);

	      u_extrapolated = u_extrapolated_next;
	    }
	  while ((test > precision) && (k < 7));

	  z_debut += H;

	  du_extrapolated_next = extrapolation_in_zero (k , du_end);

	  u_debut  =  u_extrapolated_next;
	  du_debut = du_extrapolated_next;
	}

      H *= 0.5;
      
      z_debut = z0;

      u_debut  =  u0;
      du_debut = du0;
    }

  u  =  u_extrapolated_next;
  du = du_extrapolated_next;
}


double used_memory_calc (const class ODE_integration &T)
{
  return sizeof (T)/1000000.0;
}





