#ifndef GAUSS_LEGENDRE_HPP
#define GAUSS_LEGENDRE_HPP

namespace Gauss_Legendre
{
  double poly (const int degree , const double x);
  
  double poly_der (const int degree , const double x);

  void P_dP (const int degree , const double x , double &P , double &dP);
  
  template<typename SCALAR_TYPE>
  void abscissas_weights_tables_calc (
				      const SCALAR_TYPE &debut , 
				      const SCALAR_TYPE &end , 
				      class array<SCALAR_TYPE> &x_table , 
				      class array<SCALAR_TYPE> &w_table);
  
  void k_w_tab_contour_calc (
			     const double power ,
			     const double d ,
			     const double k_deb , 
			     const complex<double> &k_peak , 
			     const double k_end , 
			     class array<complex<double> > &k_tab , 
			     class array<complex<double> > &w_tab);

  void k_w_tab_segment_part_calc (
				  const unsigned int N_shift ,
				  const unsigned int N_segment ,
				  const complex<double> &k_deb , 
				  const complex<double> &k_end , 
				  class array<complex<double> > &k_tab , 
				  class array<complex<double> > &w_tab);
}






// Calculation of the abscissas and weights of the Gauss-Legendre quadrature
// -------------------------------------------------------------------------
// These are the abscissas and weights of the Gauss-Legendre quadrature.
// They are scaled at the end to map ]-1:1[ into ]debut:end[ linearly.
// The starting points are from F. G. Tricomi, Sugli zeri dei polinomi sferici ed ultrasferici, Ann. Mat. Pura. Appl., 31 (1950),pp. 93–97.
// They are : (1 - (N-1)/N^3 + 39/(384.N^4) + 28/(384.N^4.sin^2(phi[i]))).cos (phi[i]), with phi[i] = [Pi/(N + 0.5)].(N - 0.25 - i).
// Unless N is very small, the Newton method converges in 1-3 iterations typically.
// Not more than 4 iterations are needed, so that a maximum of 10 iterations is tolerated in the routine.
// The routine has been tested successfully for N <= 4000.
//
// Variables
// -------- - 
// N, N2, N3, N4, Nm1 : number of points in the Gauss-Legendre quadrature, its square, cube, fourth power,  N-1
// Pi_over_N_plus_half, N_minus_quarter: Pi/(N + 0.5) , N - 0.25
// Nm1_over_2: (N-1)/2
// Nm1_minus_i: N - 1 - i
// x_table : table of Gauss - Legendre abscissas.
// w_table : table of Gauss - Legendre weights.
// debut, end : limits of the integral.
// count : The Newton method stops if count >= 10. Indeed, the starting point is very precise.
// root_poly : i-th root of the Legendre polynomial
//             It is refined with the Newton method. A precision of 1e-16 is demanded.
// P, dP, ratio: Legendre polynomial and derivative, P/dP
// phi_i, cos_phi_i, sin_square_phi_i:  Pi/(N + 0.5).(N - 0.25 - i), its cosine, its sine squared
// N4_384, N4_384_inv_28 : 384.N^4 , 29/(384.N^4)
// root_N_expansion_first_term : 1 - (N-1)/N^3 + 39/(384.N^4).
// length, half_length : end - debut, (end - debut)/2

template<typename SCALAR_TYPE>
void Gauss_Legendre::abscissas_weights_tables_calc (
						    const SCALAR_TYPE &debut , 
						    const SCALAR_TYPE &end , 
						    class array<SCALAR_TYPE> &x_table , 
						    class array<SCALAR_TYPE> &w_table)
{
  const unsigned int N = x_table.dimension (0);

  if (N == 0) return;
  
  const SCALAR_TYPE length = end - debut;
  
  const SCALAR_TYPE half_length = 0.5*length;
  
  const double Pi_over_N_plus_half = M_PI/(N + 0.5);

  const double N_minus_quarter = N - 0.25;
    
  const unsigned int Nm1 = N - 1;
  
  const unsigned int Nm1_over_two = Nm1/2;

  const double N2 = N*N;
  const double N3 = N2*N;
  const double N4 = N3*N;
  
  const double N4_384 = 384.0*N4;
  
  const double N4_384_inv_28 = 28.0/N4_384;

  const double root_N_expansion_first_term = 1.0 - 0.125*Nm1/N3 + 39.0/N4_384;
  	  
  for (unsigned int i = 0 ; i <= Nm1_over_two ; i++) 
    {
      const unsigned int Nm1_minus_i = Nm1 - i;

      const double phi_i = Pi_over_N_plus_half*(N_minus_quarter - i);

      const double cos_phi_i = cos (phi_i);
	
      const double sin_square_phi_i = 1.0 - cos_phi_i*cos_phi_i;
      
      unsigned int count = 0;

      double root_poly = (root_N_expansion_first_term + N4_384_inv_28/sin_square_phi_i)*cos_phi_i;
                  
      double P = 0.0;
 
      double dP = 0.0;

      double ratio = 1.0;
      
      while ((abs (ratio) > 1E-16) && (count++ < 10))
	{
	  P_dP (N , root_poly , P , dP);

	  ratio = P/dP;

	  root_poly -= ratio;
	}
            
      x_table(i) = root_poly;

      x_table(Nm1_minus_i) = -root_poly;
            
      w_table(Nm1_minus_i) = w_table(i) = 2.0/((1.0 - root_poly*root_poly)*dP*dP);
    }

  x_table *= half_length;

  x_table += debut + half_length;

  w_table *= half_length;
}




#endif

