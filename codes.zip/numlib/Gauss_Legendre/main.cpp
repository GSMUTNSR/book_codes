#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void test_precision_double ()
{
  cout.precision (15);

  const unsigned int N = 500;
  
  const double xmin = 1.0;
  const double xmax = 12.0;

  const double exact_integral = sin (xmax) - sin (xmin);
  
  cout << "cos (x) is integrated numerically and exactly between xmin = " << xmin << " and xmax = " << xmax << "." << endl << endl;

  cout << "Gauss-Legendre number of points   Gauss-Legendre integral   exact integral    test"  << endl << endl;
  
  for (unsigned int n = 0 ; n <= N ; n++)
    {
      class array<double> x_tab(n);
      class array<double> w_tab(n);
	
      Gauss_Legendre::abscissas_weights_tables_calc (xmin , xmax , x_tab , w_tab);

      complex<double> integral = 0.0;

      for (unsigned int i = 0 ; i < n ; i++) integral += cos (x_tab(i))*w_tab(i);

      cout << n << " " << integral << " " << exact_integral << " " << inf_norm (integral/exact_integral - 1.0) << endl;
    }
  
  cout << endl << "P(n,x) and P'(n,x) test from a standard relation" << endl << endl;

  cout.precision (8);
  
  seed ();
    
  for (int n = 1 ; n <= 10 ; n++)
    {
      const double x = random_number<double> ();

      const double P_nm1_x = Gauss_Legendre::poly (n-1 , x);
      
      const double Pn_x = Gauss_Legendre::poly (n , x);
	
      const double Pn_der_x = Gauss_Legendre::poly_der (n , x);

      double Pn_x_test , Pn_der_x_test;

      Gauss_Legendre::P_dP (n , x , Pn_x_test , Pn_der_x_test);
      
      if (abs (Pn_x - Pn_x_test) + abs (Pn_der_x - Pn_der_x_test) > 1E-12) error_message_print_abort ("Problem with Gauss-Legendre polynomials and/or derivatives");
	
      const double test = inf_norm (n*(x*Pn_x - P_nm1_x)/(x*x - 1.0)/Pn_der_x - 1.0);
	
      cout << "n : " << " " << n << "   x : " << x << "   P(n,x) : " << Pn_x << "   P'(n,x) : " << Pn_der_x << "   test : " << test << endl;
    }  
}







void test_precision_complex ()
{
  cout.precision (15);

  const unsigned int N = 200;
    
  const complex<double> zmin(1 , -0.4);
  const complex<double> zmax(12 , 0.7);

  const complex<double> exact_integral = sin (zmax) - sin (zmin);
  
  cout << "cos (z) is integrated numerically and exactly between zmin = " << zmin << " and zmax = " << zmax << "." << endl << endl;

  cout << "Gauss-Legendre number of points   Gauss-Legendre integral   exact integral    test"  << endl << endl;

  for (unsigned int n = 1 ; n <= N ; n ++)
    {
      class array<complex<double> > z_tab(n);
      class array<complex<double> > w_tab(n);
	
      Gauss_Legendre::abscissas_weights_tables_calc (zmin , zmax , z_tab , w_tab);

      complex<double> integral = 0.0;

      for (unsigned int i = 0 ; i < n ; i++) integral += cos (z_tab(i))*w_tab(i);

      cout << n << " " << integral << " " << exact_integral << " " << inf_norm (integral/exact_integral - 1.0) << endl;
    }
}











complex<double> complex_scaled_integral_calc (
					      const double R , 
					      const double theta ,
					      const complex<double> &k , 
					      const class array<double> &xm4_table ,
					      const class array<double> &w_table)
{
  const unsigned int N = xm4_table.dimension (0);

  const complex<double> Ik(-imag (k), real (k));

  const complex<double> Itheta(0 , theta);

  const complex<double> exp_Itheta = exp (Itheta);

  complex<double> integral = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const complex<double> z = R + (xm4_table(i) - R)*exp_Itheta;

      integral += exp (Ik*z)*w_table(i);
    }

  integral *= 4.0*exp_Itheta;

  return integral;
}






void complex_scaling_for_plots (
				const double R , 
				const complex<double> &k , 
				const unsigned int N)
{
  const double precision_for_plot = 1E-14;

  class array<double> x_table(N);
  class array<double> xm4_table(N);
  class array<double> w_table(N);
	
  Gauss_Legendre::abscissas_weights_tables_calc (0.0 , pow (R , -0.25) , x_table , w_table);

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double x = x_table(i);

      const double xm4 = pow (x , -4);

      xm4_table(i) = xm4;
 
      w_table(i) *= xm4/x;
    }

  const complex<double> Ik(-imag (k), real (k));

  const complex<double> analytical_integral = -exp (Ik*R)/Ik;

  const double theta_k = -arg (k);

  cout << endl << "Optimal complex scaling angle : theta[k] = " << theta_k*180.0/M_PI << " degrees" << endl;
	
  const unsigned int N_theta = 500;

  const double step_theta = M_PI/static_cast<double> (N_theta - 1);

  ofstream out_file("out_complex_scaling.dat");

  out_file.precision (15);

  for (unsigned int i = 0 ; i < N_theta ; i++)
    {
      const double theta = theta_k + i*step_theta;

      const complex<double> numerical_integral = complex_scaled_integral_calc (R , theta , k , xm4_table , w_table);

      const double test_integral = inf_norm (1.0 - numerical_integral/analytical_integral);

      const double test_integral_for_plot = max (test_integral , precision_for_plot);

      if (finite (test_integral) && (test_integral < 1.0)) out_file << theta*180.0/M_PI << " " << real (numerical_integral) << " " << imag (numerical_integral) << " " << test_integral_for_plot << endl;
    }
}








#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    string calculation_str;
    
    cin >> calculation_str;

    if (calculation_str == "test.precision")
      {
	test_precision_double ();

	cout << endl;
	
	test_precision_complex ();
      }
    else if (calculation_str == "plot")
      {
	double R;
	cin >> R;
	word_check_print<double> ("(R)" , R);

	complex<double> k;
	cin >> k;
	word_check_print<complex<double> > ("(k)" , k);

	unsigned int N;
	cin >> N;
	word_check_print<unsigned int> ("(Gauss.Legendre.points)" , N);
	
	complex_scaling_for_plots (R , k , N);
      }
    else
      error_message_print_abort ("Bad option");


#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

