#include "../numlib_def/numlib_def.h"


// Legendre polynomial
// ------------------ - 
// The following recurrence relation is used :
// (i+1).P(i+1, x) = (2i+1).x.P(i, x) - i.P(i-1, x) for i > 0.
//
// P(0, x) = 1. This value is directly returned if the degree of the polynomial is 0.
//
// Variable
// --------
// degree : degree of the Legendre polynomial
// x : variable of the Legendre polynomial
// i, poly_im1, poly_i, poly_ip1 : Legendre polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// two_ip1, ip1, one_over_ip1 : 2.i+1, i+1, 1/[i+1]

double Gauss_Legendre::poly (const int degree , const double x)
{
  if (degree == 0) return 1.0;

  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = x;

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double two_ip1 = 2 * i + 1;

      const double one_over_ip1 = 1.0/ip1;

      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_ip1 = (two_ip1 * x * poly_i - i * poly_im1) * one_over_ip1;
    }

  return poly_ip1;
}








// Derivative of the Legendre polynomial
// --------------------------------------
// The following recurrence relations are used :
// (i+1).P(i+1 , x) = (2i+1).x.P(i , x) - i.P(i-1 , x) for i > 0.
// P'(i+1 , x) = x.P'(i , x) + (i+1).P(i , x) for i > 0.
//
// P(0 , x) = 1. 
//
// P'(0 , x) = 0. This value is directly returned if the degree of the polynomial is 0.
//
// I do not use the formula P'(i+1 , x) = (i+1).(x.P(i+1 , x) - P(i , x))/(x^2 - 1) as it is unstable for |x| ~ 1.
//
// Variable
// --------
// degree : degree of the Legendre polynomial
// x : variable of the Legendre polynomial derivative
// i , poly_im1 , poly_i , poly_ip1 : Legendre polynomial of degree i-1 , i , i+1. i goes from 1 to degree-1 , with degree > 1.
// poly_der_i , poly_der_ip1 : Derivatives of Legendre polynomial of degree i , i+1. i goes from 1 to degree-1 , with degree > 1.
// At the end , poly_der_ip1 is returned.
// two_ip1 , ip1 , one_over_ip1 : 2.i+1 , i+1 , 1/[i+1]

double Gauss_Legendre::poly_der (const int degree , const double x)
{
  if (degree == 0) return 0.0;

  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = x;

  double poly_der_i = 0.0;

  double poly_der_ip1 = 1.0;

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double two_ip1 = 2 * i + 1;

      const double one_over_ip1 = 1.0/ip1;

      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_der_i = poly_der_ip1;
	  
      poly_ip1 = (two_ip1 * x * poly_i - i * poly_im1) * one_over_ip1;
	  
      poly_der_ip1 = x*poly_der_i + ip1*poly_i;
    }
      
  return poly_der_ip1;
}




// Polynomial and derivative of the Legendre polynomial
// ----------------------------------------------------
// The following recurrence relations are used :
// (i+1).P(i+1, x) = (2i+1).x.P(i, x) - i.P(i-1, x) for i > 0.
// P'(i+1, x) = x.P'(i, x) + (i+1).P(i, x) for i > 0.
// 
// P(0, x) = 1, P'(0, x) = 0. These values are directly returned if the degree of the polynomial is 0.
//
// I do not use the formula P'(i+1 , x) = (i+1).(x.P(i+1 , x) - P(i , x))/(x^2 - 1) as it is unstable for |x| ~ 1.
//
// Variable
// --------
// degree : degree of the Legendre polynomial, not of the derivative of the Legendre.
// x : variable of the Legendre polynomial derivative
// i, poly_im1, poly_i, poly_ip1 : Legendre polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// poly_der_i, poly_der_ip1 : Derivatives of Legendre polynomial of degree i, i+1. i goes from 1 to degree-1, with degree > 1.
// two_ip1, ip1, one_over_ip1 : 2.i+1, i+1, 1/[i+1]
// P, dP: Legendre polynomial and derivative to calculate


void Gauss_Legendre::P_dP (const int degree , const double x , double &P , double &dP)
{
  if (degree == 0)
    {
      P = 1.0;
      
      dP = 0.0;
    }    
  else
    {
      double poly_im1 = 0.0;

      double poly_i = 1.0;

      double poly_ip1 = x;

      double poly_der_i = 0.0;

      double poly_der_ip1 = 1.0;
      
      for (int i = 1 ; i < degree ; i++)
	{
	  const double ip1 = i + 1;

	  const double two_ip1 = 2 * i + 1;

	  const double one_over_ip1 = 1.0/ip1;

	  poly_im1 = poly_i;

	  poly_i = poly_ip1;
	  
	  poly_der_i = poly_der_ip1;
	  
	  poly_ip1 = (two_ip1 * x * poly_i - i * poly_im1) * one_over_ip1;
	  
	  poly_der_ip1 = x*poly_der_i + ip1*poly_i;
	}

      P = poly_ip1;

      dP = poly_der_ip1;
    }
}











// Calculation of the Gauss momenta and weights of a given Berggren basis contour
// ------------------------------------------------------------------------------

void Gauss_Legendre::k_w_tab_contour_calc (
					   const double power ,
					   const double d ,
					   const double k_deb , 
					   const complex<double> &k_peak , 
					   const double k_end , 
					   class array<complex<double> > &k_tab , 
					   class array<complex<double> > &w_tab)

{  
  const unsigned int N_scat = k_tab.dimension (0);
  
  class array<double> kr_tab(N_scat);

  class array<double> wkr_tab(N_scat);
  
  abscissas_weights_tables_calc (k_deb , k_end , kr_tab , wkr_tab);
      
  for (unsigned int i = 0 ; i < N_scat ; i++)
    {
      const double kr = kr_tab(i);
      
      const double wkr = wkr_tab(i);
      
      const complex<double> weight_function = contour_k_calc_der (power , d , k_deb , k_peak , k_end , kr);
        
      k_tab(i) = contour_k_calc (power , d , k_deb , k_peak , k_end , kr);
      
      w_tab(i) = wkr*weight_function;
    }
}










// Calculation of the Gauss momenta and weights of a part of a Berggren basis contour
// ---------------------------------------------------------------------------------

void Gauss_Legendre::k_w_tab_segment_part_calc (
						const unsigned int N_shift ,
						const unsigned int N_segment , 
						const complex<double> &k_deb , 
						const complex<double> &k_end , 
						class array<complex<double> > &k_tab , 
						class array<complex<double> > &w_tab)

{
  class array<complex<double> > k_tab_partial(N_segment);
  class array<complex<double> > w_tab_partial(N_segment);

  abscissas_weights_tables_calc (k_deb , k_end , k_tab_partial , w_tab_partial);
  
  for (unsigned int i = 0 ; i < N_segment ; i++)
    {
      const unsigned int index = N_shift + i;
      
      k_tab(index) = k_tab_partial(i);
      w_tab(index) = w_tab_partial(i);
    }
}






