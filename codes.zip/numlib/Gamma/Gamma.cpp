#include "../numlib_def/numlib_def.h"

using namespace string_routines;

// Logarithm of Gamma[z] and Gamma inverse function
// ------------------------------------------------
// For log[Gamma[z]], if z is not finite or is a negative integer, the program returns an error message and stops.
// The Lanczos method is used. Precision : ~ 1E-15
// The method works for Re[z] >= 0.5 .
// If Re[z] <= 0.5, one uses the formula Gamma[z].Gamma[1 - z] = Pi/sin (Pi.z).
// log[sin(Pi.z)] is calculated with the Kolbig method (K.S. Kolbig, Comp. Phys. Comm., Vol. 4, p.221 (1972)) : 
// If z = x + iy and y >= 0, log[sin(Pi.z)] = log[sin(Pi.eps)] - i.Pi.n, with z = n + eps so 0 <= Re[eps] < 1 and n integer.
// If y > 110, log[sin(Pi.z)] = - i.Pi.z + log[0.5] + i.Pi/2 numerically so that no overflow can occur.
// If z = x + iy and y < 0, log[Gamma(z)] = [log[Gamma(z * )]] *, so that one can use the previous formula with z * .
//
// For Gamma inverse, Lanczos method is also used with Euler reflection formula.
// sin (Pi.z) is calculated as sin (Pi.(z - n)) to avoid inaccuracy
// with z = n + eps with n integer and |eps| as small as possible.
//
// Variables:
// ----------
// x, y: Re[z], Im[z]
// log_sqrt_2Pi, log_Pi : log[sqrt(2.Pi)], log(Pi).
// sum : Rational function in the Lanczos method
// log_Gamma_z : log[Gamma(z)] value.
// c : table containing the fifteen coefficients in the expansion used in the Lanczos method.
// eps, n : z = n + eps so 0 <= Re[eps] < 1 and n integer for Log[Gamma].
// z=n + eps and n integer so |eps| is as small as possible for Gamma_inv.
// log_const : log[0.5] + i.Pi/2
// g : coefficient used in the Lanczos formula. It is here 607/128.
// z, z_m_0p5, z_p_g_m0p5, zm1 : argument of the Gamma function, z - 0.5, z - 0.5 + g, z - 1 

complex<double> log_Gamma (const complex<double> &z)
{
  if (!finite (z)) error_message_print_abort ("z is not finite in log_Gamma.");

  const double x = real (z);
  const double y = imag (z);

  if ((z == rint (x)) && (x <= 0)) error_message_print_abort ("z is negative integer in log_Gamma.");

  if (x >= 0.5)
    {
      const double log_sqrt_2Pi = 0.91893853320467274177;

      const double g = 4.7421875;

      const complex<double> z_m_0p5 = z - 0.5;

      const complex<double> z_pg_m0p5 = z_m_0p5 + g;

      const complex<double> zm1 = z - 1.0;

      const double c[15] = {0.99999999999999709182 , 
			    57.156235665862923517 , 
			    - 59.597960355475491248 , 
			    14.136097974741747174 , 
			    - 0.49191381609762019978 , 
			    0.33994649984811888699e-4 , 
			    0.46523628927048575665e-4 , 
			    - 0.98374475304879564677e-4 , 
			    0.15808870322491248884e-3 , 
			    - 0.21026444172410488319e-3 , 
			    0.21743961811521264320e-3 , 
			    - 0.16431810653676389022e-3 , 
			    0.84418223983852743293e-4 , 
			    - 0.26190838401581408670e-4 , 
			    0.36899182659531622704e-5};

      complex<double> sum = c[0];
      
      for (int i = 1 ; i < 15 ; i++) sum += c[i]/(zm1 + i);

      const complex<double> log_Gamma_z = log_sqrt_2Pi + log (sum) + z_m_0p5 * log (z_pg_m0p5) - z_pg_m0p5;

      return log_Gamma_z;
    }
  else if (y >= 0.0)
    {
      const int n = (x < rint (x)) ? (static_cast<int> (rint (x)) - 1) : (static_cast<int> (rint (x)));

      const double log_Pi = 1.1447298858494002;

      const complex<double> log_const( - M_LN2 , M_PI_2);

      const complex<double> i_Pi(0.0 , M_PI);

      const complex<double> eps = z - n;

      const complex<double> log_sin_Pi_z = (y > 110) ? ( - i_Pi * z + log_const) : (log (sin (M_PI * eps)) - i_Pi * n);

      const complex<double> log_Gamma_z = log_Pi - log_sin_Pi_z - log_Gamma (1.0 - z);

      return log_Gamma_z;
    }
  else
    {
      return conj (log_Gamma (conj (z)));
    }
}




complex<double> Gamma_inv (const complex<double> &z)
{
  if (!finite (z)) error_message_print_abort ("z is not finite in Gamma_inv.");

  const double x = real (z);

  if (x >= 0.5)
    {
      const double log_sqrt_2Pi = 0.91893853320467274177;

      const double g = 4.7421875;

      const complex<double> z_m_0p5 = z - 0.5;

      const complex<double> z_pg_m0p5 = z_m_0p5 + g;

      const complex<double> zm1 = z - 1.0;

      const double c[15] = {0.99999999999999709182 , 
			    57.156235665862923517 , 
			    - 59.597960355475491248 , 
			    14.136097974741747174 , 
			    - 0.49191381609762019978 , 
			    0.33994649984811888699e-4 , 
			    0.46523628927048575665e-4 , 
			    - 0.98374475304879564677e-4 , 
			    0.15808870322491248884e-3 , 
			    - 0.21026444172410488319e-3 , 
			    0.21743961811521264320e-3 , 
			    - 0.16431810653676389022e-3 , 
			    0.84418223983852743293e-4 , 
			    - 0.26190838401581408670e-4 , 
			    0.36899182659531622704e-5};

      complex<double> sum = c[0];
      
      for (int i = 1 ; i < 15 ; i++) sum += c[i]/(zm1 + i);

      const complex<double> Gamma_inv_z = exp (z_pg_m0p5 - z_m_0p5 * log (z_pg_m0p5) - log_sqrt_2Pi)/sum;

      return Gamma_inv_z;
    }
  else
    {
      const int n = static_cast<int> (rint (x));

      const complex<double> eps = z - n;

      if (n%2 == 0)
	return (sin (M_PI * eps) * M_1_PI)/Gamma_inv (1.0 - z);
      else
	return (-sin (M_PI * eps) * M_1_PI)/Gamma_inv (1.0 - z);
    }
}









// Lower incomplete Gamma function : power series
// ----------------------------------------------
// The lower incomplete Gamma function power series of gamma(a, z) is calculated.
// It is stable for |z/[a + 1]| <= 1.
//
// PS(a, z) = sum_{n=0}^{+oo} z^n/[a.(a + 1)...(a + n)]
//
// Variables 
// -------- - 
// a, z : arguments of the function
// Re_a : real part of a.
// cn, sum, prec_sum: term of the series, series itself, precision demanded, which is 1E-15.|c[0]|oo.
// n: index of the series

complex<double> gamma_incomplete_power_series (const complex<double> &a , const complex<double> &z)
{ 
  const double Re_a = real (a);

  if ((a == rint (Re_a)) && (Re_a <= 0)) error_message_print_abort ("a is negative integer in gamma_incomplete_power_series.");

  complex<double> cn = 1.0/a;

  complex<double> sum = cn;

  const double prec_sum = 1E-15 * inf_norm (cn);

  int n = 1;

  while (inf_norm (cn) > prec_sum)
    {
      cn *= z/(a + n);

      sum += cn;

      n++;
    }

  return sum;
}









// Upper incomplete Gamma function : continued fraction
// ----------------------------------------------------
// The upper incomplete Gamma function continued fraction of Gamma(a, z) is calculated.
// It is stable for |z/[a + 1]| >= 1.
//
// CF(a, z) = z + 1 - a + 1(a - 1)/(z - a + 3) + 2(a - 2)/(z - a + 5) + 3(a - 3)/(z - a + 7) + ... n(a - n)/(z - a + (2n + 1)) + ...
// One uses the notation : CF(a, z) = b[0] + a[1]/b[1] + a[2]/b[2] + ... a[n]/b[n] + .... in the routine.
// One uses Lentz's method for the calculation of the continued fraction.
//
// Variables 
// -------- - 
// small, large: very small and large numbers to avoid overflows in the Lentz method.
// a, z, z_minus_a : arguments of the function, z - a
// n, two_n_p1, test: index of the continued fraction, 2.n + 1, test of convergence of the continued fraction.
// b0, an, bn, bn_plus_an_D, bn_plus_an_over_Cn, Delta_n : variables entering the Lentz method.
// fn: continued fraction

complex<double> Gamma_incomplete_continued_fraction (
						     const complex<double> &a ,
						     const complex<double> &z)
{
  const double small = 1E-50;

  const double large = 1E50;

  const complex<double> z_minus_a = z - a;

  const complex<double> b0 = z_minus_a + 1.0;
  
  complex<double> fn = (b0 != 0.0) ? (b0) : (small);

  complex<double> Cn = fn;
  
  complex<double> Dn = 0.0; 

  int n = 1;
  
  double test;

  do
    {
      const int two_n_p1 = 2 * n + 1;

      const complex<double> an = n * (a - n);

      const complex<double> bn = z_minus_a + two_n_p1;

      const complex<double> bn_plus_an_Dn = bn + an * Dn;

      const complex<double> bn_plus_an_over_Cn = bn + an/Cn;

      Dn = (bn_plus_an_Dn != 0.0) ? (1.0/bn_plus_an_Dn) : (large);
      
      Cn = (bn_plus_an_over_Cn != 0.0) ? (bn_plus_an_over_Cn) : (small);

      const complex<double> Delta_n = Dn * Cn;

      fn *= Delta_n;

      test = inf_norm (1.0 - Delta_n);

      n++;
    }
  while (test > 1E-15);

  return fn;
}





// Incomplete Gamma functions
// --------------------------
// gamma(a, x) = int_{0}^{x} exp( - t).t^(a - 1) dt, Re(a) > 0, x real.
// For |x/(a + 1)| <= 1 : gamma(a, x) = exp( - x).x^a.sum_{n=0}^{+oo} x^n/[a.(a + 1)...(a + n)]. 
//
// Gamma(a, x) = int_{x}^{+oo} exp( - t).t^(a - 1) dt, Re(a) > 0, x real.
// For |x/(a + 1)| >= 1 : Gamma(a, x) = exp( - x).x^a/[x + 1 - a + 1(a - 1)/(x - a + 3) + 2(a - 2)/(x - a + 5) + 3(a - 3)/(x - a + 7) + ... n(a - n)/(x - a + (2n + 1)) + ...]
//
// If a is a negative integer, Gamma(a, x) is defined but the continued fraction method has to be used.
//
// One uses the relation gamma(a, x) + Gamma(a, x) = Gamma(a) for cases not considered above.
// Analytic continuations of gamma(a, z) and Gamma(a, z) for complex values of z are immediate, replacing x by z in numerical expressions.
//
// Variables 
// -------- - 
// a, z : arguments of the function
// abs_z_over_a_p1: |z/[a + 1]|
// res: value of the incomplete Gamma function
// Gamma_a, Gamma_incomplete_az: Gamma function Gamma(a), upper incomplete Gamma function Gamma_incomplete(a, z)

complex<double> gamma_incomplete (
				  const complex<double> &a ,
				  const complex<double> &z)
{
  if (z == 0.0)
    {
      if (real (a) > 0.0) 
	return 0.0;
      else
	error_message_print_abort ("gamma_inc(a , 0) undefined for Re[a] <= 0. Re[a]=" + make_string<double> (real (a)));
    }

  const double abs_z_over_a_p1 = abs (z/(a + 1.0));

  if (abs_z_over_a_p1 <= 1.0)
    {
      const complex<double> res = exp ( - z + a * log (z)) * gamma_incomplete_power_series (a , z);

      return res;
    }
  else
    {
      const complex<double> Gamma_a = exp (log_Gamma (a));
      
      const complex<double> Gamma_incomplete_az = exp ( - z + a * log (z))/Gamma_incomplete_continued_fraction (a , z);
      
      const complex<double> res = Gamma_a - Gamma_incomplete_az;

      return res;
    }
}







// Exponential integral E1 function : power series
// ---------------------------------------------- - 
// The exponential integral function is calculated with the power series formula.
// It is stable for |z| <= 1, z non zero.
// E1(z) = -gamma - log (z) - sum_{n=1}^{+oo} (-z)^n/[n.n!]
//
// Variables 
// -------- - 
// z : argument of the function
// gamma: Euler - Mascheroni constant
// n, cn, sum: index of the series, term of the series, series itself.

complex<double> E1_power_series (const complex<double> &z)
{ 
  const double gamma = 5.7721566490153286e-1;

  complex<double> cn = 1.0;
  
  complex<double> sum = -gamma - log (z);

  int n = 1;

  while (inf_norm (cn) > 1E-15)
    {
      cn *= -z/n;

      sum -= cn/n;

      n++;
    }

  return sum;
}









// Incomplete Gamma function for "a" negative integer
// --------------------------------------------------
// The upper incomplete Gamma function is defined for "a" negative integer and z non zero.
// However, if |z| <= 1, one cannot use the lower incomplete gamma function to calculate it.
// The latter is indeed undefined for "a" negative integer, and the continued fraction formula unstable for |z| ~ 0.
// Thus, one has to use recurrence relations on "a" to calculate it.
// If a = 0, one has the relation Gamma_incomplete(0, z) = E1(z) and one uses E1_power_series.
// If a <= - 1, one uses the following recurrence relation : 
// Gamma_incomplete(n, z) = [Gamma_incomplete(n + 1, z) - exp(-z).z^n]/n, n <= -2
//
// Variables 
// -------- - 
// a, z : arguments of the function
// z_pow_n: z^n, with n in [a: -1]
// res: returned function

complex<double> Gamma_incomplete_a_negative_integer_small_z (
							     const int a ,
							     const complex<double> &z)
{ 
  const complex<double> exp_mz = exp (-z);

  complex<double> res = E1_power_series (z);
  
  complex<double> z_pow_n = 1.0;

  for (int n = -1 ; n >= a ; n--)
    {
      z_pow_n /= z;
      
      res = (res - exp_mz * z_pow_n)/n;
    }

  return res;
}




complex<double> Gamma_incomplete (
				  const complex<double> &a ,
				  const complex<double> &z)
{
  if (z == 0.0) 
    {
      const complex<double> Gamma_a = exp (log_Gamma (a));

      return Gamma_a;
    }

  const double Re_a = real (a);
	
  if ((a == rint (Re_a)) && (Re_a <= 0))
    {
      if (abs (z) >= 1.0)
	{
	  const complex<double> res = exp (-z + a * log (z))/Gamma_incomplete_continued_fraction (a , z);

	  return res;
	}
      else
	{
	  const int na = static_cast<int> (Re_a);

	  return Gamma_incomplete_a_negative_integer_small_z (na , z);
	}
    }

  const double abs_z_over_a_p1 = abs (z/(a + 1.0));

  if (abs_z_over_a_p1 >= 1.0)
    {
      const complex<double> res = exp (-z + a * log (z))/Gamma_incomplete_continued_fraction (a , z);

      return res;
    }
  else
    {
      const complex<double> Gamma_a = exp (log_Gamma (a));

      const complex<double> gamma_incomplete_az = exp (-z + a * log (z)) * gamma_incomplete_power_series (a , z);

      const complex<double> res = Gamma_a - gamma_incomplete_az;

      return res;
    }
}






// Exponential integral E1(z)
// -------------------------
// It is \int_{z}^{+oo} exp(-t)/t dt.
// It is also Gamma_incomplete(0, z).

complex<double> E1 (const complex<double> &z)
{
  if (abs (z) <= 1.0)
    return E1_power_series (z);
  else
    {
      const complex<double> res = exp (-z)/Gamma_incomplete_continued_fraction (0.0 , z);

      return res;
    }
}






// Error function
// --------------------
// It is 2/sqrt(Pi) \int_{0}^{z} exp(-t^2) dt.
// It is also gamma_inc (1/2, x^2)/sqrt (Pi)

complex<double> erf (const complex<double> &z)
{
  const double sqrt_Pi_inv = 5.6418958354775629E-1;

  const complex<double> z2 = z*z;

  const complex<double> erf_z = gamma_incomplete (0.5 , z2)*sqrt_Pi_inv;
  
  return erf_z;
}






// Dawson generalized integral
// ---------------------------
// D(z) = exp (-z^p) \int_{0}^{z} exp (t^p) dt
//
// Power series and continued fraction are used.
// Power series are tested against the Dawson differential equation and returned of its test is smaller than 10^(-10).
// The continued fraction formula is returned otherwise.
// The code typically works for small imaginary parts of z and p and with |p| <= 3.
// Users should test in the region of interest before use.
//
// Variables
// ---------
// p, z: parameters of the generalized Dawson integral
// PS_test: test of the Dawson power series


complex<double> Dawson_generalized_integral_calc (
						  const complex<double> &p ,
						  const complex<double> &z)
{
  const double PS_test = Dawson_generalized_integral_power_series_test_calc (p , z);
  
  if (PS_test < precision) return Dawson_generalized_integral_power_series (p , z);

  return Dawson_generalized_integral_continued_fraction (p , z);
}











// Generalized Dawson integral : continued fraction
// ------------------------------------------------
// The continued fraction formula is D(z) = z / (1/p + z^p) + (-z^p) / (1/p + 1 + z^p) + ... + (- n z^p) / (1/p + n + z^p) - ...
//
// Variables 
// ---------
// z, z_pow_p: argument of the function, z^p
// one_over_p: 1/p
// small, large: very small and large numbers to avoid overflows in the Lentz method.
// n, test: index of the continued fraction, test of convergence of the continued fraction.
// b0, an, bn, bn_plus_an_D, bn_plus_an_over_Cn, Delta_n : variables entering the Lentz method.
// fn: continued fraction
// Dz: return value

complex<double> Dawson_generalized_integral_continued_fraction (
								const complex<double> &p ,
								const complex<double> &z)
{
  const complex<double> z_pow_p = pow (z , p);

  const complex<double> one_over_p = 1.0/p; 
    
  const double small = 1E-50;

  const double large = 1E50;
  
  complex<double> fn = small;

  complex<double> Cn = fn;

  complex<double> Dn = 0.0; 

  int n = 1;
  
  double test;

  do
    {
      const complex<double> an = -n * z_pow_p;

      const complex<double> bn = one_over_p + n + z_pow_p;

      const complex<double> bn_plus_an_Dn = bn + an * Dn;

      const complex<double> bn_plus_an_over_Cn = bn + an/Cn;

      Dn = (bn_plus_an_Dn != 0.0) ? (1.0/bn_plus_an_Dn) : (large);

      Cn = (bn_plus_an_over_Cn != 0.0) ? (bn_plus_an_over_Cn) : (small);
  
      const complex<double> Delta_n = Dn * Cn;

      fn *= Delta_n;

      test = inf_norm (1.0 - Delta_n);

      n++;
    }
  while (test > 1E-15);
    
  const complex<double> Dz = z/(1.0 + p*(z_pow_p + fn));
  
  return Dz;
}











// Generalized Dawson integral : power series
// ------------------------------------------
// D(z) = exp (-z^p) \int_{0}^{z} exp (t^p) dt
//
// \int_{0}^{z} exp (t^p) dt = sum_{n=0}^{ + oo} z^(np + 1)/((np + 1) n!) = z sum_{n=0}^{ + oo} cn/(np + 1)
// A test using the Dawson equation is provided.
//
// Variables 
// ---------
// z, z_pow_p, exp_minus_z_pow_p, p_times_z_pow_p_minus_one : argument of the function, z^p, exp (-z^p), p.z^(p-1) 
// cn, an, sum: subterm of the series equal to (z^p)^n/(n!), term of the series, series itself
// Dz : result
// an_der, sum_der, Dz_der: same for derivative
// n: index of the series
// np : n*p

complex<double> Dawson_generalized_integral_power_series (
							  const complex<double> &p ,
							  const complex<double> &z)
{
  const complex<double> z_pow_p = pow (z , p);

  const complex<double> exp_minus_z_pow_p = exp (-z_pow_p);

  int n = 1;

  complex<double> an = 1.0;

  complex<double> cn = an;

  complex<double> sum = an;

  while (inf_norm (an) > 1E-16)
    {
      const complex<double> np = n*p;

      cn *= z_pow_p/n;

      an = cn/(np + 1.0);

      sum += an;

      n++;
    }

  const complex<double> Dz = z*exp_minus_z_pow_p*sum;

  return Dz;
}

double Dawson_generalized_integral_power_series_test_calc (
							   const complex<double> &p ,
							   const complex<double> &z)
{
  if (z == 0.0) return 0.0;

  const complex<double> z_pow_p = pow (z , p);

  const complex<double> exp_minus_z_pow_p = exp (-z_pow_p);

  int n = 1;

  complex<double> an = 1.0;
  
  complex<double> an_der = 0.0;

  complex<double> cn = an;

  complex<double> sum = an;

  complex<double> sum_der = an_der;

  while (inf_norm (an) + inf_norm (an_der) > 1E-16)
    {
      const complex<double> np = n*p;

      cn *= z_pow_p/n;
      
      an = cn/(np + 1.0);

      an_der = np*an;

      sum += an;

      sum_der += an_der;

      n++;
    }

  sum_der += sum;

  sum *= z;

  const complex<double> p_times_z_pow_p_minus_one = p*z_pow_p/z;
  
  const complex<double> Dz = exp_minus_z_pow_p*sum;
  
  const complex<double> Dz_der = exp_minus_z_pow_p*(sum_der - p_times_z_pow_p_minus_one*sum);

  const double test = inf_norm ((Dz_der - 1.0)/Dz + p_times_z_pow_p_minus_one);

  return test;
}








// Dawson integral
// ---------------
// Particular case of the generalized Dawson integral, with p=2.

complex<double> Dawson_integral_calc (const complex<double> &z)
{
  return Dawson_generalized_integral_calc (2 , z);
}
