#ifndef GAMMA_H
#define GAMMA_H

complex<double> log_Gamma (const complex<double> &z);

complex<double> Gamma_inv (const complex<double> &z);

complex<double> gamma_incomplete_power_series (const complex<double> &a , const complex<double> &z);

complex<double> Gamma_incomplete_continued_fraction (const complex<double> &a , const complex<double> &z);

complex<double> gamma_incomplete (const complex<double> &a , const complex<double> &z);

complex<double> E1_power_series (const complex<double> &z);

complex<double> Gamma_incomplete_a_negative_integer_small_z (const int a , const complex<double> &z);

complex<double> Gamma_incomplete (const complex<double> &a , const complex<double> &z);

complex<double> E1 (const complex<double> &z);

complex<double> erf (const complex<double> &z);

complex<double> Dawson_generalized_integral_continued_fraction (const complex<double> &p , const complex<double> &z);

complex<double> Dawson_generalized_integral_power_series (const complex<double> &p , const complex<double> &z);

double Dawson_generalized_integral_power_series_test_calc (const complex<double> &p , const complex<double> &z);

complex<double> Dawson_generalized_integral_calc (const complex<double> &p , const complex<double> &z);

complex<double> Dawson_integral_calc (const complex<double> &z);

#endif

