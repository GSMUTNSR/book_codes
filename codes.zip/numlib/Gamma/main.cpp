#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void Dawson_generalized_integral_test (
				       const unsigned int N ,
				       const complex<double> &p,
				       const double R ,
				       const double theta)
{
  const double step = R/static_cast<double> (N - 1);

  const double precision_der = 1E-3;
  
  cout << "Generalized Dawson integral test. R:" << R << endl << endl;

  for (unsigned int i = 1 ; i < N ; i++)
    {
      const double r = step*i;

      const complex<double> z = polar (r , theta);

      const complex<double> zpp = z*(1.0 + 2.0*precision_der);
      const complex<double> zmm = z*(1.0 - 2.0*precision_der);
      
      const complex<double> zp = z*(1.0 + precision_der);
      const complex<double> zm = z*(1.0 - precision_der);

      const complex<double> Dz = Dawson_generalized_integral_calc (p , z);
      
      const complex<double> Dzpp = Dawson_generalized_integral_calc (p , zpp);
      const complex<double> Dzmm = Dawson_generalized_integral_calc (p , zmm);
      
      const complex<double> Dzp = Dawson_generalized_integral_calc (p , zp);
      const complex<double> Dzm = Dawson_generalized_integral_calc (p , zm);

      const complex<double> Dz_der = (-Dzpp + 8.0*Dzp - 8.0*Dzm + Dzmm)/(12.0*z*precision_der);
	
      const double test_Dz = inf_norm ((Dz_der - 1.0)/Dz + p*pow (z , p - 1.0));

      if (test_Dz > sqrt_precision) error_message_print_abort ("Problem in Dawson_generalized_integral_calc");

      cout << "z:" << z << "   D(z):" << Dz << "   test D(z):" << test_Dz << endl;
    }
}












#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    const unsigned int N_Dawson = 500;

    const complex<double> p(1.9 , 0.1);
    
    const double R = 20;

    const double theta = 0.05*M_PI;
        
    Dawson_generalized_integral_test (N_Dawson , p , R , theta);

    const unsigned int N = 10;
    
    const double xmin = -5.1247 , xmax = 5 , step_x = (xmax - xmin)/static_cast<double> (N-1);
    const double ymin = -5.1247 , ymax = 5 , step_y = (ymax - ymin)/static_cast<double> (N-1);

    const complex<double> l(2.0 , -1.2);
    const complex<double> s(0.2 , -0.03);
    
    cout << endl;
    
    cout << "l : " << l << " (Large modulus case)" << endl;
    cout << "s : " << s << " (small modulus case)" << endl << endl;

    const complex<double> Dl_1 = Dawson_generalized_integral_calc (2 , l);
    const complex<double> Ds_1 = Dawson_generalized_integral_calc (2 , s);
    
    const complex<double> Dl = Dawson_integral_calc (l);
    const complex<double> Ds = Dawson_integral_calc (s);

    const double test_Dl = inf_norm (Dl_1/Dl - 1.0);
    const double test_Ds = inf_norm (Ds_1/Ds - 1.0);
    
    if (test_Dl > precision) error_message_print_abort ("Problem in Dawson_integral_calc (l)");
    if (test_Ds > precision) error_message_print_abort ("Problem in Dawson_integral_calc (s)");
    
    cout << "D(l):" << Dl << "   test D(l):" << test_Dl << endl;
    cout << "D(s):" << Ds << "   test D(s):" << test_Ds << endl;

    cout << endl;
    
    cout << "Duplication formula testing for log[Gamma] and Gamma." << endl;
    
    cout << "One has : Gamma(z).Gamma(z+1/2) = 2^(1-2z) sqrt (Pi) Gamma(2z)" << endl << endl;

    for (unsigned int ix = 0 ; ix < N ; ix++) 
      for (unsigned int iy = 0 ; iy < N ; iy++) 
	{
	  const double x = xmin + ix*step_x;
	  const double y = ymin + iy*step_y;

	  const complex<double> z(x , y);

	  const complex<double> Gamma_inv_z = Gamma_inv (z);

	  const double test_duplication_formula_log = inf_norm (log_Gamma (z) + log_Gamma (z + 0.5) - (1 - 2.0*z)*M_LN2 - 0.5*log (M_PI) - log_Gamma (2.0*z));
	  
	  const double test_duplication_formula = inf_norm (Gamma_inv_z*Gamma_inv (z + 0.5)*pow (2.0 , 1.0 - 2.0*z)*sqrt (M_PI)/Gamma_inv (2.0*z) - 1.0);

	  const complex<double> Gamma_from_inc_l = gamma_incomplete (z , l) + Gamma_incomplete (z , l);
	  const complex<double> Gamma_from_inc_s = gamma_incomplete (z , s) + Gamma_incomplete (z , s);
	  
	  const double test_incomplete_Gamma_l = inf_norm (Gamma_from_inc_l*Gamma_inv_z - 1.0);	  
	  const double test_incomplete_Gamma_s = inf_norm (Gamma_from_inc_s*Gamma_inv_z - 1.0);

	  const double test_incomplete_Gamma_zero = inf_norm (Gamma_incomplete (z , 0.0)*Gamma_inv_z - 1.0);
	  
	  if (test_duplication_formula_log > precision) error_message_print_abort ("Problem in log_Gamma");
	  if (test_duplication_formula     > precision) error_message_print_abort ("Problem in Gamma_inv");
	  
	  if (test_incomplete_Gamma_l      > precision)      error_message_print_abort ("Problem in gamma_incomplete or Gamma_incomplete (z , l)");
	  if (test_incomplete_Gamma_s      > sqrt_precision) error_message_print_abort ("Problem in gamma_incomplete or Gamma_incomplete (z , s)");
	  
	  if (test_incomplete_Gamma_zero   > precision) error_message_print_abort ("Problem in Gamma_incomplete (0)");
      
	  cout << "z : "<< z << endl; 

	  cout << "log Gamma test : " << test_duplication_formula_log << endl;

	  cout << "Gamma test : " << test_duplication_formula << endl;
	  
	  cout << "Incomplete Gamma test (l) : " << test_incomplete_Gamma_l << endl;
	  cout << "Incomplete Gamma test (s) : " << test_incomplete_Gamma_s << endl;
	  
	  cout << "Incomplete Gamma test (0) : " << test_incomplete_Gamma_zero << endl << endl;
	}

    cout << "Negative integer incomplete Gamma test." << endl;

    cout << "Continued fractions and power series are both precise for Gamma_incomplete(n=0 , l and p)." << endl;

    cout << "Both are used to test Gamma_incomplete(n=0 , l and p)." << endl;

    cout << "One uses E1(z) = Gamma_incomplete(0 , z)." << endl;

    cout << "The equality Gamma_incomplete(n-1 , z) = [Gamma_incomplete(n , z) - exp( - z).z^(n-1)]/(n-1) is used for testing when n <= -1" << endl << endl;

    const double test_zero_l = inf_norm (Gamma_incomplete (0 , l)/E1 (l) - 1.0);
    const double test_zero_s = inf_norm (Gamma_incomplete (0 , s)/E1 (s) - 1.0);

    cout << " n : 0    Incomplete Gamma test (l) : " << test_zero_l  << "   Incomplete Gamma test (s) : " << test_zero_s << endl;

    for (int n = -1 ; n >= -10 ; n--)
      {
	const double test_l = inf_norm ((Gamma_incomplete (n , l) - exp(-l)*pow (l , n-1))/((n-1)*Gamma_incomplete (n-1 , l)) - 1.0);
	const double test_s = inf_norm ((Gamma_incomplete (n , s) - exp(-s)*pow (s , n-1))/((n-1)*Gamma_incomplete (n-1 , s)) - 1.0);

	if (test_l > precision) error_message_print_abort ("Problem in Gamma_incomplete (n , l)");
	if (test_s > precision) error_message_print_abort ("Problem in Gamma_incomplete (n , s)");
	  
	cout << " n : " << n << "   Incomplete Gamma test (l) : " << test_l  << "   Incomplete Gamma test (s) : " << test_s << endl;
      }

    const double two_over_sqrt_Pi = 1.12837916709551257390;

    const double x = 0.00123456;
    const double y = 3.45678901;

    const complex<double> zx(x , precision);
    const complex<double> zy(y , precision);
    
    const complex<double> erf_zx = erf (zx);
    const complex<double> erf_zy = erf (zy);

    const double erf_x = real (erf_zx);
    const double erf_y = real (erf_zy);
    
    const double erf_x_der_num = imag (erf_zx)/precision;
    const double erf_y_der_num = imag (erf_zy)/precision;
    
    const double erf_x_der_exact = exp (-x*x)*two_over_sqrt_Pi;
    const double erf_y_der_exact = exp (-y*y)*two_over_sqrt_Pi;
    
    const double erf_x_test = max (abs (erf (x)/erf_x - 1.0) , abs (erf_x_der_exact/erf_x_der_num - 1.0));
    const double erf_y_test = max (abs (erf (y)/erf_y - 1.0) , abs (erf_y_der_exact/erf_y_der_num - 1.0));

    const double E1_x_der_num = imag (E1 (zx))/precision;
    const double E1_y_der_num = imag (E1 (zy))/precision;
    
    const double E1_x_der_exact = exp (-x)/x;
    const double E1_y_der_exact = exp (-y)/y;
    
    const double E1_x_test = abs (E1_x_der_exact/E1_x_der_num + 1.0);
    const double E1_y_test = abs (E1_y_der_exact/E1_y_der_num + 1.0);
    
    if (erf_x_test > precision) error_message_print_abort ("Problem in erf (x)");
    if (erf_y_test > precision) error_message_print_abort ("Problem in erf (y)");
    
    if (E1_x_test > precision) error_message_print_abort ("Problem in E1 (x)");
    if (E1_y_test > precision) error_message_print_abort ("Problem in E1 (y)");
    
    cout << endl << "x : " << x << "   complex erf test:" << erf_x_test << "   E1 derivative test:" << E1_x_test << endl;
    cout <<         "y : " << y << "   complex erf test:" << erf_y_test << "   E1 derivative test:" << E1_y_test << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

