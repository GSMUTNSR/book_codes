#ifndef ANGULAR_MATRIX_ELEMENTS_H
#define ANGULAR_MATRIX_ELEMENTS_H

namespace angular_matrix_elements
{
  double OBME_j_reduced (const double j);

  double OBME_l_reduced_in_j (
			      const int li , const double ji ,
			      const int lf , const double jf);

  double OBME_sigma_reduced_in_j (
				  const int li , const double ji ,
				  const int lf , const double jf);

  double OBME_YL_reduced_in_l (
			       const int L ,
			       const int li ,
			       const int lf);

  double OBME_YL_reduced_in_j (
			       const int L ,
			       const int li , const double ji ,
			       const int lf , const double jf);

  double OBME_YL_square (
			 const int L ,
			 const int l);
 
  double OBME_YL_tensor_s_reduced_in_j (
					const int L ,
					const int Lc ,
					const int li ,
					const double ji ,
					const int lf ,
					const double jf);

  double OBME_YL_tensor_l_reduced_in_l (
					const int L ,
					const int Lc ,
					const int li ,
					const int lf);

  double OBME_YL_tensor_l_reduced_in_j (
					const int L ,
					const int Lc ,
					const int li , const double ji ,
					const int lf , const double jf);

  double OBME_s_scalar_e_reduced_in_j (
				       const int li , const double ji ,
				       const int lf , const double jf);
  
  double YL1_tensor_YL2_reduced_in_l (
				      const int L1 ,
				      const int L2 ,
				      const int L ,
				      const int li ,
				      const int lf);

  double YL1_tensor_YL2_reduced_in_j (
				      const int L1 ,
				      const int L2 ,
				      const int L ,
				      const int li , const double ji ,
				      const int lf , const double jf);

  double Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (
						       const int la , const int lb ,
						       const int lc , const int ld ,
						       const int l ,
						       const int L);

  double Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (
						       const int la , const double ja ,
						       const int lb , const double jb , 
						       const int lc , const double jc ,
						       const int ld , const double jd , 
						       const int l ,
						       const int J);

  double sigma_1_sigma_2_calc (
			       const int la , const double ja ,
			       const int lb , const double jb , 
			       const int lc , const double jc ,
			       const int ld , const double jd , 
			       const int J);
  
  double Psigma (
		 const int la , const double ja ,
		 const int lb , const double jb , 
		 const int lc , const double jc ,
		 const int ld , const double jd , 
		 const int J);

  double P_lambda_rotor_tensor_spinless_part_calc (
						   const int lambda ,
						   const int j ,  const int l ,
						   const int jp , const int lp ,
						   const int J);

  void P_lambda_rotor_tensor_spinless_part_tab_calc (
						     const int J ,
						     class array<double> &P_lambda_rotor_point_part_tab);

  double P_lambda_rotor_tensor_part_calc (
					  const int lambda ,
					  const int jr  , const int l ,  const double j ,
					  const int jrp , const int lp , const double jp ,
					  const double J);
  
  double P_lambda_static_calc (const int lambda ,
			       const int l ,  const double j ,
			       const int lp , const double jp ,
			       const double K);
}

#endif


