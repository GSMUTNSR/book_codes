#include "../numlib_def/numlib_def.h"

using namespace Wigner_signs;

// This namespace is to calculate angular matrix elements using the Wigner-Eckart theorem.
// One only considers scalar operators or reduced matrix elements issued from tensor operators, i.e. matrix elements independent of angular momentum projections.
// Indeed, typically, operators entering physical observables are tensor operators and associated matrix elements can be reduced in observable formulas. 
// M-dependent angular matrix elements are considered on a case by case basis in other parts of the code when necessary.
//
// Standard notations are used:
//
// OBME means one-body matrix element.
// l is for orbital angular momentum, s is spin 1/2 and j = l + s unless explicitly stated. Same for l' and j'.
// li, ji are for initial states and lf, jf are for final states.
// la , ja , lb, jb , J  are for initial states |a b> and lc, jc ,ld , jd are for final states |c d>. Both are coupled to J: ja + jb = J and jc + jd = J.
// jr (jr') is for rotor angular momentum and l (l') is for particle angular momentum initial (final) states. Both are coupled to J: jr + l = J and jrp + lp = J.









// <j || j || j> 
// ---------------
// The numerical value of <j || j || j> = sqrt (j.(j + 1).(2.j + 1)) is returned if j <= 21/2, which is the most common case.
// Otherwise, sqrt (j.(j + 1).(2.j + 1)) is calculated
//
// Variables
// ---------
// two_j: the integer 2.j

double angular_matrix_elements::OBME_j_reduced (const double j)
{
  const int two_j = make_int (2 * j);

  switch (two_j)
    {
    case 0  : return 0.0;
    case 1  : return 1.22474487139158904909;
    case 2  : return 2.44948974278317809819;
    case 3  : return 3.87298334620741688517;
    case 4  : return 5.47722557505166113456;
    case 5  : return 7.24568837309471928685;
    case 6  : return 9.16515138991168001317;
    case 7  : return 11.22497216032182415675;
    case 8  : return 13.41640786499873817845;
    case 9  : return 15.73213272255227320487;
    case 10 : return 18.16590212458494999253;
    case 11 : return 20.71231517720797913215;
    case 12 : return 23.36664289109584522132;
    case 13 : return 26.12470095522626264689;
    case 14 : return 28.98275349237887714743;
    case 15 : return 31.93743884534262399814;
    case 16 : return 34.98571136907180282524;
    case 17 : return 38.12479508141650326737;
    case 18 : return 41.35214625627066530386;
    case 19 : return 44.66542286825458904355;
    case 20 : return 48.06245936279166311884;
    case 21 : return 51.54124561940659966921;
    default : return sqrt (j * (j + 1.0) * (2.0 * j + 1.0));
    }
}








// <lf jf || l || li ji> 
// ---------------------
// One uses the Wigner-Eckart theorem expressing <lf jf || l || li ji> from <lf || l || li>, using the fact that l is spin independent.
//
// Variables
// ---------
// l_reduced_in_l: <lf || l || li> 
// reduced_OBME: <lf jf || l || li ji> 

double angular_matrix_elements::OBME_l_reduced_in_j (
						     const int li , const double ji ,
						     const int lf , const double jf)
{
  if (li != lf) return 0.0;
  
  const double l_reduced_in_l = OBME_j_reduced (li);

  const double reduced_OBME = Oa_reduced_ME_calc (1 , li , 0.5 , ji , lf , 0.5 , jf , l_reduced_in_l);

  return reduced_OBME;
}







// <lf jf || sigma || li ji>
// -------------------------
// One has sigma = 2.s .
//
// One uses the Wigner-Eckart theorem expressing <lf jf || sigma || li ji> from <1/2 || sigma || 1/2>, using the fact that s depends on spin only (see Ob_reduced_ME_calc in Wigner_signs.cpp).
//
// Variables
// ---------
// sigma_reduced_in_s: <1/2 || sigma || 1/2>
// reduced_OBME: <lf jf || sigma || li ji>

double angular_matrix_elements::OBME_sigma_reduced_in_j (
							 const int li , const double ji ,
							 const int lf , const double jf)
{
  if (li != lf) return 0.0;
  
  const double sigma_reduced_in_s = 2.0*OBME_j_reduced (0.5);

  const double reduced_OBME = Ob_reduced_ME_calc (1 , li , 0.5 , ji , lf , 0.5 , jf , sigma_reduced_in_s);

  return reduced_OBME;
}









// <lf || YL || li>
// -----------------
// One uses the direct analytical formula for <lf || YL || li>:
//
// <lf || YL || li> = (-1)^lf \hat{lf} \hat{li} \hat{L} Wigner_3j (lf , L , li , 0 , 0 , 0) / (4 pi) 
//
// Variables
// ---------
// phase : (-1)^lf
// sqrt_four_pi_inv : 1 / (4 pi) 
// hats_product_over_sqrt_four_pi : \hat{lf} \hat{li} \hat{L} / (4 pi) 
// Wigner_3j_value : Wigner_3j (lf , L , li , 0 , 0 , 0)
// reduced_OBME: <lf || YL || li>
  
double angular_matrix_elements::OBME_YL_reduced_in_l (
						      const int L ,
						      const int li ,
						      const int lf)
{
  const int phase = minus_one_pow (lf);

  const double sqrt_four_pi_inv = 0.2820947917738781;
  
  const double hats_product_over_sqrt_four_pi = hat (lf) * hat (li) * hat (L) * sqrt_four_pi_inv;

  const double Wigner_3j_value = Wigner_3j (lf , L , li , 0.0 , 0.0 , 0.0);

  const double reduced_OBME = phase * hats_product_over_sqrt_four_pi * Wigner_3j_value;

  return reduced_OBME;
}







// <lf jf || YL || li ji>
// ----------------------
// One has to have li + lf + L even and the triangular relations verified for |li si ji> and |lf sf jf> otherwise it is zero.
// These requirements must indeed be checked in the first place, as the occurring Wigner sign does not necessarily vanish if it is not the case.
//
// One uses the direct analytical formula for <lf jf || YL || li ji>:
//
// <lf jf || YL || li ji> = (-1)^(jf + 1/2) \hat{jf} \hat{ji} \hat{L} Wigner_3j (jf , L , ji , 1/2 , 0 , -1/2) / (4 pi) 
//
// Variables
// ---------
// phase : (-1)^(-1)^(jf + 1/2)
// sqrt_four_pi_inv : 1 / (4 pi) 
// hats_product_over_sqrt_four_pi : \hat{jf} \hat{ji} \hat{L} / (4 pi) 
// Wigner_3j_value : Wigner_3j (jf , L , ji , 1/2 , 0 , -1/2)
// reduced_OBME: <lf jf || YL || li ji>

double angular_matrix_elements::OBME_YL_reduced_in_j (
						      const int L ,
						      const int li , const double ji ,
						      const int lf , const double jf)
{
  if ((li + lf + L) % 2 == 1) return 0.0;

  if (!is_it_triangle (li , 0.5 , ji)) return 0.0;
  if (!is_it_triangle (lf , 0.5 , jf)) return 0.0;

  const int phase = minus_one_pow (jf + 0.5);

  const double sqrt_four_pi_inv = 0.2820947917738781;
  
  const double hats_product_over_sqrt_four_pi = hat (jf) * hat (ji) * hat (L) * sqrt_four_pi_inv;

  const double Wigner_3j_value = Wigner_3j (jf , L , ji , 0.5 , 0.0 , -0.5);

  const double reduced_OBME = phase * hats_product_over_sqrt_four_pi * Wigner_3j_value;

  return reduced_OBME;
}











// <l | YL^2 | l>
// -------------------
//
// This expression is calculated with the Wigner-Eckart theorem using coupled operators acting on the same space, in which an identity relation |l'> <l'| enters:
// <l | YL^2 | l> = (1/(2l + 1)) \sum_{l'} <l' || YL || l>^2
//
// <l j | YL^2 | l j> = <l | YL^2 | l> as the OBME does not depend on spin and one has a scalar.
//
// Variables
// ---------
// lmin, lmax: |l - L| , l + L
// lp: l' angular orbital momentum of the identity relation above
// OBME_YL_reduced: <l || YL || l'>
// OBME: <l | YL^2 | l>
  
double angular_matrix_elements::OBME_YL_square (
						const int L ,
						const int l)
{
  const int lmin = abs (l - L);

  const int lmax = l + L;
  
  double OBME = 0.0;  

  for (int lp = lmin ; lp <= lmax ; lp += 2)
    {
      const double OBME_YL_reduced = OBME_YL_reduced_in_l (L , lp , l);

      OBME += OBME_YL_reduced*OBME_YL_reduced;
    }

  OBME /= 2*l + 1;
  
  return OBME;
}











// <lf jf || [YLc x s]^L || li ji>
// ------------------------------------
//
// One uses the Wigner-Eckart theorem expressing <lf jf || [YLc x s]^L || li ji> from <lf || YLc || li> and <sf || s || si> ,
// using the fact that YLc and s act on space and spin coordinates, respectively.
//
// Variables
// ---------
// OBME_YL_reduced_in_l_part : <lf || YLc || li>
// spin_reduced_in_s: <1/2 || s || 1/2>
// reduced_OBME: <lf jf || [YLc x s]^L || li ji>

double angular_matrix_elements::OBME_YL_tensor_s_reduced_in_j (
							       const int L ,
							       const int Lc ,
							       const int li , const double ji ,
							       const int lf , const double jf)
{	
  const double OBME_YL_reduced_in_l_part = OBME_YL_reduced_in_l (Lc , li , lf);
  
  const double spin_reduced_in_s = OBME_j_reduced (0.5);

  const double reduced_OBME = Oa_tensor_Ob_reduced_ME_calc (Lc , 1 , L , li , 0.5 , ji , lf , 0.5 , jf , OBME_YL_reduced_in_l_part , spin_reduced_in_s);

  return reduced_OBME;
}
















// <lf || [YLc x l]^L || li>
// -------------------------------
// This expression is calculated with the Wigner-Eckart theorem using coupled operators acting on the same space, in which an identity relation |l'> <l'| enters.
//
// One must have l' = li as an <l' || l || li> matrix element occurs , so that one obtains a product of <lf || YLc || li>, <lf || l || li> and recoupling terms.
//
// One has: <lf || [YLc x l]^L || li> = <lf || YLc || li>  <lf || l || li> (-1)^(lf + L + li) \hat{l} Wigner_6j (Lc , 1 , L , li , lf , li)
//
// Variables
// ---------
// OBME_YL_reduced_in_l_part : <lf || YLc || li>
// li_reduced_in_l : <li || l || li> phase : (-1)^(lf + L + li)
// Wigner_6j_value : Wigner_3j (Lc , 1 , L , li , lf , li)
// reduced_OBME: <lf || [YLc x l]^L || li>

double angular_matrix_elements::OBME_YL_tensor_l_reduced_in_l (
							       const int L ,
							       const int Lc ,
							       const int li ,
							       const int lf)
{	
  const double OBME_YL_reduced_in_l_part = OBME_YL_reduced_in_l (Lc , li , lf);
  
  const double li_reduced_in_l = OBME_j_reduced (li);

  const int phase = minus_one_pow (lf + L + li);

  const double hat_L = hat (L);
  
  const double Wigner_6j_value = Wigner_6j (Lc , 1 , L , li , lf , li);

  const double reduced_OBME = phase * hat_L * Wigner_6j_value * OBME_YL_reduced_in_l_part * li_reduced_in_l;

  return reduced_OBME;
}








// <lf jf || [YLc x l]^L || li ji>
// ------------------------------------
//
// One uses the Wigner-Eckart theorem expressing <lf jf || [YLc x l]^L || li ji> from <1/2 || s || 1/2> and <lf || [YLc x l]^L || li>, using the fact that s depends on spin only.
//
// Variables
// ---------
// OBME_YL_tensor_l_reduced_in_l_part: <lf || [YLc x l]^L || li>
// reduced_OBME: <lf jf || [YLc x l]^L || li ji>

double angular_matrix_elements::OBME_YL_tensor_l_reduced_in_j (
							       const int L ,
							       const int Lc ,
							       const int li , const double ji ,
							       const int lf , const double jf)
{
  const double OBME_YL_tensor_l_reduced_in_l_part = OBME_YL_tensor_l_reduced_in_l (L , Lc , li , lf);

  const double reduced_OBME = Oa_reduced_ME_calc (L , li , 0.5 , ji , lf , 0.5 , jf , OBME_YL_tensor_l_reduced_in_l_part);

  return reduced_OBME;
}


















// <lf jf || s.e || li ji>
// -----------------------
//
// e = Y1 sqrt(4 pi / 3) is the z unit vector.
//
// One uses the Wigner-Eckart theorem expressing <lf jf | s.e | li ji> = <lf jf | e.s | li ji> from <lf || e || li> and <1/2 || s || 1/2> , 
// using the fact that e and s act on space and spin coordinates, respectively.
//
// Then <lf jf || s.e || li ji> = \hat{jf} <lf jf | s.e | li ji> .
//
// Variables
// ---------
// Y1_norm_factor : sqrt(4 pi / 3)
// spin_reduced_in_s : <1/2 || s || 1/2>
// OBME_Y1_reduced_in_l : <lf || Y1 || li>
// OBME_e_reduced_in_l : <lf || e || li>
// OBME: <lf jf | s.e | li ji>
// reduced_OBME: <lf jf || s.e || li ji>
 
double angular_matrix_elements::OBME_s_scalar_e_reduced_in_j (
							      const int li , const double ji ,
							      const int lf , const double jf)
{	
  const double Y1_norm_factor = 2.046653415892977;
  
  const double spin_reduced_in_s = OBME_j_reduced (0.5);

  const double OBME_Y1_reduced_in_l = OBME_YL_reduced_in_l (1 , li , lf);

  const double OBME_e_reduced_in_l = Y1_norm_factor * OBME_Y1_reduced_in_l;

  const double OBME = Oa_scalar_Ob_ME_calc (1 , li , 0.5 , ji , lf , 0.5 , jf , OBME_e_reduced_in_l , spin_reduced_in_s);
  
  const double reduced_OBME = hat (jf) * OBME;

  return reduced_OBME;
}




// <lf || [YL1 x YL2]^L || li>
// ---------------------------
// The Gaunt series formula is used:
//
// <lf || [YL1 x YL2]^L || li> =  (-1)^(L1 - L2) [\hat{L1} \hat{L2} / (4 Pi)] Wigner_3j (L1 , L2 , L , 0 , 0 , 0) <lf || YL || li>
//
// Variables
// ---------
// phase : (-1)^(L1 - L2)
// OBME_YL_reduced_in_l_part : <lf || YL || li>
// sqrt_four_pi_inv : 1 / (4 Pi)
// hats_product_over_sqrt_four_pi : [\hat{L1} \hat{L2} / (4 Pi)]
// reduced_OBME: <lf || [YL1 x YL2]^L || li>

double angular_matrix_elements::YL1_tensor_YL2_reduced_in_l (
							     const int L1 ,
							     const int L2 ,
							     const int L ,
							     const int li ,
							     const int lf)
{
  const int phase = minus_one_pow (L1 - L2);

  const double Wigner_3j_value = Wigner_3j (L1 , L2 , L , 0 , 0 , 0);

  const double OBME_YL_reduced_in_l_part = OBME_YL_reduced_in_l (L , li , lf);

  const double sqrt_four_pi_inv = 0.2820947917738781;
  
  const double hats_product_over_sqrt_four_pi = hat (L1) * hat (L2) * sqrt_four_pi_inv;

  const double reduced_OBME = phase * hats_product_over_sqrt_four_pi * Wigner_3j_value * OBME_YL_reduced_in_l_part;

  return reduced_OBME;
}









// <lf jf || [YL1 x YL2]^L || li ji>
// ---------------------------------
// The Gaunt series formula is used:
//
// <lf jf || [YL1 x YL2]^L || li ji> =  (-1)^(L1 - L2)[\hat{L1} \hat{L2} / (4 Pi)] Wigner_3j (L1 , L2 , L , 0 , 0 , 0) <lf jf || YL || li ji>
//
// Variables
// ---------
// phase : (-1)^(L1 - L2)
// OBME_YL_reduced_in_j_part : <lf jf || YL || li ji>
// sqrt_four_pi_inv : 1 / (4 Pi)
// hats_product_over_sqrt_four_pi : [\hat{L1} \hat{L2} / (4 Pi)]
// reduced_OBME: <lf jf || [YL1 x YL2]^L || li ji>

double angular_matrix_elements::YL1_tensor_YL2_reduced_in_j (
							     const int L1 ,
							     const int L2 ,
							     const int L ,
							     const int li , const double ji ,
							     const int lf , const double jf)
{
  const int phase = minus_one_pow (L1 - L2);

  const double Wigner_3j_value = Wigner_3j (L1 , L2 , L , 0 , 0 , 0);
  
  const double OBME_YL_reduced_in_j_part = OBME_YL_reduced_in_j (L , li , ji , lf , jf);

  const double sqrt_four_pi_inv = 0.2820947917738781;
  
  const double hats_product_over_sqrt_four_pi = hat (L1) * hat (L2) * sqrt_four_pi_inv;

  const double reduced_OBME = phase * hats_product_over_sqrt_four_pi * Wigner_3j_value * OBME_YL_reduced_in_j_part;

  return reduced_OBME;
}







// <lc ld | Yl(1).Yl(2) | la lb>_L . 4 Pi/(2l+1)
// ---------------------------------------------------------
// One uses the Wigner-Eckart theorem expressing <lc ld | Yl(1).Yl(2) | la lb>_L from <lc || Yl || la> and <ld || Yl || lb>.
//
// Variables
// ---------
// Yl1_reduced_in_l : <lc || Yl || la>
// Yl2_reduced_in_l : <ld || Yl || lb>
// Yl1_Yl2_L_ME : <lc ld | Yl(1).Yl(2) | la lb>_L
// Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME : Yl1_Yl2_L_ME . (4 Pi) / (2 l + 1), which is returned

double angular_matrix_elements::Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (
									      const int la , const int lb ,
									      const int lc , const int ld ,
									      const int l ,
									      const int L)
{
  const double Yl1_reduced_in_l = OBME_YL_reduced_in_l (l , la , lc);
  const double Yl2_reduced_in_l = OBME_YL_reduced_in_l (l , lb , ld);

  const double Yl1_Yl2_L_ME = Oa_scalar_Ob_ME_calc (l , la , lb , L , lc , ld , L , Yl1_reduced_in_l , Yl2_reduced_in_l);

  const double four_Pi = 12.566370614359173;

  const double norm_inv = four_Pi / (2*l + 1);

  const double Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME = Yl1_Yl2_L_ME * norm_inv;

  return Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME;
}



// <lc jc ld jd | Yl(1).Yl(2) | la ja lb jb>_J . 4 Pi/(2l+1)
// ---------------------------------------------------------
// One uses the Wigner-Eckart theorem expressing <lc jc ld jd | Yl(1).Yl(2) | la ja lb jb>_J from <lc jc || Yl || la ja> and <ld jd || Yl || lb jb>.
//
// Variables
// ---------
// Yl1_reduced_in_j : <lc jc || Yl || la ja>
// Yl2_reduced_in_j : <ld jd || Yl || lb jb>
// Yl1_Yl2_J_ME : <lc jc ld jd | Yl(1).Yl(2) | la ja lb jb>_J
// Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME : Yl1_Yl2_J_ME . (4 Pi) / (2 l + 1), which is returned

double angular_matrix_elements::Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (
									      const int la , const double ja ,
									      const int lb , const double jb , 
									      const int lc , const double jc ,
									      const int ld , const double jd , 
									      const int l ,
									      const int J)
{
  const double Yl1_reduced_in_j = OBME_YL_reduced_in_j (l , la , ja , lc , jc);
  const double Yl2_reduced_in_j = OBME_YL_reduced_in_j (l , lb , jb , ld , jd);

  const double Yl1_Yl2_J_ME = Oa_scalar_Ob_ME_calc (l , ja , jb , J , jc , jd , J , Yl1_reduced_in_j , Yl2_reduced_in_j);

  const double four_Pi = 12.566370614359173;

  const double norm_inv = four_Pi / (2*l + 1);

  const double Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME = Yl1_Yl2_J_ME * norm_inv;

  return Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_ME;
}







// <lc jc ld jd | sigma1.sigma2 | la ja lb jb>_J
// --------------------------------------
// One must have la = lc and lb = ld, as the sigma product depends on spin only. It is checked first.
//
// One uses the Wigner-Eckart theorem expressing <lc jc ld jd | sigma_1 . sigma_2 | la ja lb jb>_J from <lc jc || sigma || la ja> and <ld jd || sigma || lb jb>.
//
// Variables
// ---------
// J : total angular momentum J = ja + jb = jc + jd
// sigma_1_reduced_in_j : <lc jc || sigma || la ja>
// sigma_2_reduced_in_j : <ld jd || sigma || lb jb>
// sigma_1_sigma_2_J_ME : <lc jc ld jd | sigma_1 . sigma_2 | la ja lb jb>_J

double angular_matrix_elements::sigma_1_sigma_2_calc (
						      const int la , const double ja ,
						      const int lb , const double jb , 
						      const int lc , const double jc ,
						      const int ld , const double jd , 
						      const int J)
{
  if (la != lc) return 0.0;
  if (lb != ld) return 0.0;

  const double sigma_1_reduced_in_j = OBME_sigma_reduced_in_j (la , ja , lc , jc);
  const double sigma_2_reduced_in_j = OBME_sigma_reduced_in_j (lb , jb , ld , jd);

  const double sigma_1_sigma_2_J_ME = Oa_scalar_Ob_ME_calc (1 , ja , jb , J , jc , jd , J , sigma_1_reduced_in_j , sigma_2_reduced_in_j);

  return sigma_1_sigma_2_J_ME;
}







// <lc jc ld jd | Psigma | la ja lb jb>_J
// --------------------------------------
// Psigma = (1 + sigma_1 . sigma_2)/2, which exchanges particle spins.
//
// One must have la = lc and lb = ld, as the sigma product depends on spin only. It is checked first.
//
// One calculates <lc jc ld jd | sigma_1 . sigma_2 | la ja lb jb>_J from sigma_product.
//
// Then <lc jc ld jd | Psigma | la ja lb jb>_J = [\delta (ja jc) \delta (jb jd) - <lc jc ld jd | sigma_1 . sigma_2 | la ja lb jb>_J]/2 (la = lc and lb = ld here)
//
// Variables
// ---------
// J : total angular momentum J = ja + jb = jc + jd
// is_jc_equal_to_ja : true if jc = ja, false if not
// is_jd_equal_to_jb : true if jd = jb, false if not
// sigma_1_sigma_2_J_ME : <lc jc ld jd | sigma_1 . sigma_2 | la ja lb jb>_J
// Psigma_J_ME : <lc jc ld jd | Psigma | la ja lb jb>_J

double angular_matrix_elements::Psigma (
					const int la , const double ja ,
					const int lb , const double jb , 
					const int lc , const double jc ,
					const int ld , const double jd , 
					const int J)
{
  if (la != lc) return 0.0;
  if (lb != ld) return 0.0;

  const double is_jc_equal_to_ja = (make_int (jc - ja) == 0.0);
  const double is_jd_equal_to_jb = (make_int (jd - jb) == 0.0);

  const double sigma_1_sigma_2_J_ME = sigma_1_sigma_2_calc (la , ja , lb , jb , lc , jc , ld , jd , J);

  const double Psigma_J_ME = (is_jc_equal_to_ja && is_jd_equal_to_jb) ? (0.5 + 0.5*sigma_1_sigma_2_J_ME) : (0.5*sigma_1_sigma_2_J_ME);

  return Psigma_J_ME;
}







// < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J . [(4 Pi)/(2.lambda + 1)]
// ------------------------------------------------------------------------------------
// One deals with a spinless particle + rotor system, with a particle having a l (l') orbital angular momentum and a rotor with a jr (jr') orbital angular momentum, with everything coupled to J.
//
// One uses the Wigner-Eckart theorem expressing < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J from <jr' || YLambda || jr> and <l' || YLambda || l>.
//
// Variables
// ---------
// lambda: multipole integer used in YLambda(rotor).YLambda(particle)
// YLambda_rotor_reduced_in_l : <jr' || YLambda || jr>
// YLambda_particle_reduced_in_l : <l' || YLambda || l>
// YLambda_rotor_YLambda_particle_J_ME : < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J
// four_Pi : 4 Pi
// norm_inv : (4 Pi)/(2.lambda + 1)
// P_lambda_rotor_spinless_tensor_part : < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J . [(4 Pi)/(2.lambda + 1)]

double angular_matrix_elements::P_lambda_rotor_tensor_spinless_part_calc (const int lambda ,
									  const int jr  , const int l ,
									  const int jrp , const int lp ,
									  const int J)
{
  const double YLambda_rotor_reduced_in_l    = OBME_YL_reduced_in_l (lambda , jr , jrp);
  const double YLambda_particle_reduced_in_l = OBME_YL_reduced_in_l (lambda , l  , lp);

  const double YLambda_rotor_YLambda_particle_J_ME = Oa_scalar_Ob_ME_calc (lambda , jr , l , J , jrp , lp , J , YLambda_rotor_reduced_in_l , YLambda_particle_reduced_in_l);

  const double four_Pi = 12.566370614359173;

  const double norm_inv = four_Pi / (2*lambda + 1);

  const double P_lambda_rotor_spinless_tensor_part = YLambda_rotor_YLambda_particle_J_ME * norm_inv;

  return P_lambda_rotor_spinless_tensor_part;
}







// Table of < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J . [(4 Pi)/(2.lambda + 1)]
// ---------------------------------------------------------------------------------------------
// All the values < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J . [(4 Pi)/(2.lambda + 1)] for a spinless particle and fixed J and l,l' <= lmax are calculated and stored.
// Then jmax = J + l and jmax' = J + l' for fixed l and l'. Parity must be conserved, so that one must have (-1)^(jr' + jr + lambda) = (-1)^(l' + l + lambda) = 1.
//
// Variables:
// ---------
// P_lambda_rotor_spinless_tensor_part_tab: array where the < jr' , l' | YLambda(rotor).YLambda(particle) | jr , l >_J . [(4 Pi)/(2.lambda + 1)] are stored
//                                          one uses P_lambda_rotor_spinless_tensor_part_tab(lambda , j , l , jp , lp)
//
// lmax: maximal value of l,l'
// jmax_l, jmax_lp: maximal values of jr and jr', equal to J + l and J + l'
// lambda_min_jr , lambda_max_jr: minimal and maximal values of jr and jr' couplings equal to |jr - jr'| and jr + jr'
// lambda_min_l  , lambda_max_l : minimal and maximal values of l  and l'  couplings equal to |l  - l'|  and l  + l'
// lambda_min , lambda_max: minimal and maximal values of lambda in YLambda(rotor).YLambda(particle), equal to max (lambda_min_jr , lambda_min_l) and min (lambda_max_jr , lambda_max_l)

void angular_matrix_elements::P_lambda_rotor_tensor_spinless_part_tab_calc (
									    const int J ,
									    class array<double> &P_lambda_rotor_spinless_tensor_part_tab)
{
  P_lambda_rotor_spinless_tensor_part_tab = 0.0;

  const int lmax = P_lambda_rotor_spinless_tensor_part_tab.dimension (2) - 1;

  for (int l = 0 ; l <= lmax ; l++)
    for (int lp = 0 ; lp <= lmax ; lp++)
      {
	const int jr_max_l  = J + l;
	const int jr_max_lp = J + lp;

	for (int jr = 0 ; jr <= jr_max_l ; jr++)
	  for (int jrp = 0 ; jrp <= jr_max_lp ; jrp++)
	    {
	      const int lambda_min_jr = abs (jrp - jr) , lambda_max_jr = jr + jrp;
	      const int lambda_min_l  = abs (lp  - l)  , lambda_max_l  = l  + lp;
	      
	      const int lambda_min = max (lambda_min_jr , lambda_min_l);
	      const int lambda_max = min (lambda_max_jr , lambda_max_l);

	      for (int lambda = lambda_min ; lambda <= lambda_max ; lambda++)
		{
		  if ((minus_one_pow (jrp + jr + lambda) == 1) && (minus_one_pow (lp + l + lambda) == 1))
		    P_lambda_rotor_spinless_tensor_part_tab(lambda , jr , l , jrp , lp) = P_lambda_rotor_tensor_spinless_part_calc(lambda , jr , l , jrp , lp , J);
		}
	    }
      }
}






// < jr' , l ' j' | YLambda(rotor).YLambda(particle) | jr , l j >_J . [(4 Pi)/(2.lambda + 1)]
// ------------------------------------------------------------------------------------------
// One deals with a particle with spin 1/2 + rotor system, with a particle having a l (l') orbital angular momentum and a rotor with a jr (jr') orbital angular momentum, with everything coupled to J.
//
// One uses the Wigner-Eckart theorem expressing < jr' , j' (l' , s') | YLambda(rotor).YLambda(particle) | jr , j (l , s) >_J from <jr' || YLambda || jr> and <l' j' || YLambda || l j>.
//
// Variables
// ---------
// lambda: multipole integer used in YLambda(rotor).YLambda(particle)
// OBME_Y_lambda_particle : <l' j' || YLambda || l j>
// OBME_Y_lambda_rotor : <jr' || YLambda || jr>
// Lambda_rotor_YLambda_particle_J_ME :  < jr' , j' (l' , s') | YLambda(rotor).YLambda(particle) | jr , j (l , s) >_J
// four_Pi : 4 Pi
// norm_inv : (4 Pi)/(2.lambda + 1)
// P_lambda_rotor_tensor_part : < jr' , l ' j' | YLambda(rotor).YLambda(particle) | jr , l j >_J . [(4 Pi)/(2.lambda + 1)]

double angular_matrix_elements::P_lambda_rotor_tensor_part_calc (const int lambda ,
								 const int jr  , const int l ,  const double j ,
								 const int jrp , const int lp , const double jp ,
								 const double J)
{
  const double OBME_Y_lambda_particle = OBME_YL_reduced_in_j (lambda , l , j , lp , jp);
  
  const double OBME_Y_lambda_rotor = OBME_YL_reduced_in_l (lambda , jr , jrp);

  const double YLambda_rotor_YLambda_particle_J_ME = Oa_scalar_Ob_ME_calc (lambda , jr , j , J , jrp , jp , J , OBME_Y_lambda_rotor , OBME_Y_lambda_particle);

  const double four_Pi = 12.566370614359173;

  const double norm_inv = four_Pi / (2*lambda + 1);

  const double P_lambda_rotor_tensor_part = YLambda_rotor_YLambda_particle_J_ME  * norm_inv;

  return P_lambda_rotor_tensor_part;
}









// < l' j' K | Y(Lambda , 0)(particle) | l j K> . sqrt [(4 Pi)/(2.lambda + 1)]
// ----------------------------------------------------------------------
// One deals with a particle with spin 1/2 in a static picture for the nucleus, with a particle having a l (l') orbital angular momentum. K is a good quantum number.
//
// One uses the Wigner-Eckart theorem expressing < l' j' K | Y(Lambda , 0) | l j K> from < l' j'|| YLambda || l j> .
//
// Variables
// ---------
// lambda: multipole integer used in YLambda
// OBME_Y_lambda_particle_reduced : <l' j' || YLambda || l j>
// OBME_Y_lambda_particle : < l' j' K | Y(Lambda , 0) | l j K>
// P_lambda_static : < l' j' K | Y(Lambda , 0) | l j K> . [(4 Pi)/(2.lambda + 1)]
// four_Pi : 4 Pi
// norm_inv : sqrt ((4 Pi)/(2.lambda + 1))


double angular_matrix_elements::P_lambda_static_calc (const int lambda ,
						      const int l ,  const double j ,
						      const int lp , const double jp ,
						      const double K)
{
  const double OBME_Y_lambda_particle_reduced = OBME_YL_reduced_in_j (lambda , l , j , lp , jp);
  
  const double OBME_Y_lambda_particle = ME_dereduced (OBME_Y_lambda_particle_reduced , lambda , 0.0 , j , K , jp , K);

  const double four_Pi = 12.566370614359173;

  const double norm_inv = sqrt (four_Pi / (2*lambda + 1));

  const double P_lambda_static_part = OBME_Y_lambda_particle  * norm_inv;

  return P_lambda_static_part;
}





