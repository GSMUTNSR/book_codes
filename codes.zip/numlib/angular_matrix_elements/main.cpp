#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace angular_matrix_elements;
using namespace Wigner_signs;



void sigma_reduced_in_j_test (const int lmax)
{	
  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from <lf jf m | sigma_z | li ji m>

  double test_all = 0.0;

  for (int li = 0 ; li <= lmax ; li++)
    for (int lf = max (li-1,0) ; lf <= li+1 ; lf++)
      for (double ji = (li == 0) ? (0.5) : (li-0.5) ; rint (ji - li - 0.5) <= 0.0 ; ji++)
	for (double jf = (lf == 0) ? (0.5) : (lf-0.5) ; rint (jf - lf - 0.5) <= 0.0 ; jf++)
	  {
	    const double OBME_sigma = OBME_sigma_reduced_in_j (li , ji , lf , jf);

	    const double m = min (ji , jf);

	    const double spin = 0.5;

	    const double ms_plus  =  0.5;
	    const double ms_minus = -0.5;
	  
	    const int ml_plus  = make_int (m - ms_plus);
	    const int ml_minus = make_int (m - ms_minus);

	    const double CGs_plus  = Clebsch_Gordan (lf , ml_plus  , spin , ms_plus  , jf , m)*Clebsch_Gordan (li , ml_plus  , spin , ms_plus  , ji , m);
	    const double CGs_minus = Clebsch_Gordan (lf , ml_minus , spin , ms_minus , jf , m)*Clebsch_Gordan (li , ml_minus , spin , ms_minus , ji , m);

	    const double OBME_sigma_z_plus  = (li == lf) ? (2.0*ms_plus*CGs_plus)   : (0.0);
	    const double OBME_sigma_z_minus = (li == lf) ? (2.0*ms_minus*CGs_minus) : (0.0);
	  
	    const double OBME_sigma_z = (li == lf) ? (OBME_sigma_z_plus + OBME_sigma_z_minus) : (0.0);

	    const double OBME_sigma_test = (li == lf) ? (ME_reduced (OBME_sigma_z , 1 , 0 , ji , m , jf , m)) : (0.0);

	    const double test = abs (OBME_sigma - OBME_sigma_test);

	    test_all = max (test_all , test);
	  }	

  if (test_all > precision) error_message_print_abort ("Problem in sigma_reduced_in_j_test");
  
  cout << "Test of <lf jf || sigma || li ji> matrix elements : " << test_all << endl << endl;
}






void OBME_l_reduced_in_j_test (const int lmax)
{	
  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from <lf jf m | lz | li ji m>

  double test_all = 0.0;

  for (int li = 0 ; li <= lmax ; li++)
    for (int lf = max (li-1,0) ; lf <= li+1 ; lf++)
      for (double ji = (li == 0) ? (0.5) : (li-0.5) ; rint (ji - li - 0.5) <= 0.0 ; ji++)
	for (double jf = (lf == 0) ? (0.5) : (lf-0.5) ; rint (jf - lf - 0.5) <= 0.0 ; jf++)
	  {
	    const double OBME_l = OBME_l_reduced_in_j (li , ji , lf , jf);

	    const double m = min (ji , jf);

	    const double spin = 0.5;

	    const double ms_plus  = 0.5;
	    const double ms_minus = -0.5;

	    const int ml_plus  = make_int (m - ms_plus);
	    const int ml_minus = make_int (m - ms_minus);

	    const double CGs_plus  = Clebsch_Gordan (lf , ml_plus  , spin , ms_plus  , jf , m)*Clebsch_Gordan (li , ml_plus  , spin , ms_plus  , ji , m);
	    const double CGs_minus = Clebsch_Gordan (lf , ml_minus , spin , ms_minus , jf , m)*Clebsch_Gordan (li , ml_minus , spin , ms_minus , ji , m);

	    const double OBME_lz_plus  = (li == lf) ? (ml_plus*CGs_plus)   : (0.0);
	    const double OBME_lz_minus = (li == lf) ? (ml_minus*CGs_minus) : (0.0);
	  
	    const double OBME_lz = (li == lf) ? (OBME_lz_plus + OBME_lz_minus) : (0.0);

	    const double OBME_l_test = (li == lf) ? (ME_reduced (OBME_lz , 1 , 0 , ji , m , jf , m)) : (0.0);

	    const double test = abs (OBME_l - OBME_l_test);

	    test_all = max (test_all , test);
	  }

  if (test_all > precision) error_message_print_abort ("Problem in OBME_l_reduced_in_j_test");
  
  cout << "Test of <lf jf || l || li ji> and <lf || l || li> matrix elements : " << test_all << endl << endl;
}




void OBME_YL_reduced_in_j_test (const int lmax , const double sample)
{	
  // Method: <lf jf || YL || li ji> from direct formula and from Wigner-Eckhart theorem using <lf || YL || li> matrix elements

  double test_all = 0.0;

  for (int li = 0 ; li <= lmax ; li++)
    for (int lf = 0 ; lf <= lmax ; lf++)
      for (double ji = (li == 0) ? (0.5) : (li-0.5) ; rint (ji - li - 0.5) <= 0.0 ; ji++)
	for (double jf = (lf == 0) ? (0.5) : (lf-0.5) ; rint (jf - lf - 0.5) <= 0.0 ; jf++)
	  for (int L = abs (make_int (ji - jf)) ; L <= make_int (ji + jf) ; L++)
	    if (random_number<double> () < sample)
	      {
		const double OBME_YL_j = OBME_YL_reduced_in_j (L , li , ji , lf , jf);
		
		const double OBME_YL_l = OBME_YL_reduced_in_l (L , li , lf);
		
		const double OBME_YL_j_test = Oa_reduced_ME_calc (L , li , 0.5 , ji , lf , 0.5 , jf , OBME_YL_l); 
		
		const double test = abs (OBME_YL_j - OBME_YL_j_test);
		  
		test_all = max (test_all , test);
	      }

  if (test_all > precision) error_message_print_abort ("Problem in OBME_YL_reduced_in_j_test");
  
  cout << "Test of <lf || YL || li>, <lf jf || YL || li ji> : " << test_all << endl << endl;
}





void OBME_YL_square_test (const int lmax)
{	
  const double Y0_square = 0.07957747154594766788;

  // Method: particular case : Lc = 0 , L = 1 so that YL^2 is a constant

  double test_all = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    {
      const double OBME_YL_square_l = OBME_YL_square (0 , l);

      const double test = abs (OBME_YL_square_l - Y0_square);
      
      test_all = max (test_all , test);
    }

  if (test_all > precision) error_message_print_abort ("Problem in OBME_YL_square_test");
  
  cout << "Test of <l | YL^2 | l> : L = 0 : " << test_all << endl << endl;
}





void OBME_YL_tensor_s_test (const int lmax)
{	
  const double Y0 = 0.28209479177387814347;

  // Method: particular case : Lc = 0 , L = 1 so that  [YLc x s]^L is proportional to s

  double test_all = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    for (double ji = (l == 0) ? (0.5) : (l-0.5) ; rint (ji - l - 0.5) <= 0.0 ; ji++)
      for (double jf = (l == 0) ? (0.5) : (l-0.5) ; rint (jf - l - 0.5) <= 0.0 ; jf++)
	{
	  const double OBME_Y0_s = OBME_YL_tensor_s_reduced_in_j (1 , 0 , l , ji , l , jf);

	  const double s_reduced = OBME_j_reduced (0.5);

	  const double OBME_Y0_s_test = Y0*Ob_reduced_ME_calc (1 , l , 0.5 , ji , l , 0.5 , jf , s_reduced); 

	  const double test = abs (OBME_Y0_s - OBME_Y0_s_test);

	  test_all = max (test_all , test);
	}
  
  if (test_all > precision) error_message_print_abort ("Problem in OBME_YL_tensor_s_test");

  cout << "Test of <lf jf || [YLc x s]^L || li ji> matrix elements : Lc = 0 , L = 1 : " << test_all << endl << endl;
}








void OBME_YL_tensor_l_test (const int lmax)
{	
  const double Y0 = 0.28209479177387814347;

  // Method: particular case : Lc = 0 , L = 1 so that [YLc x l]^L is proportional to l

  double test_all = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    for (double ji = (l == 0) ? (0.5) : (l-0.5) ; rint (ji - l - 0.5) <= 0.0 ; ji++)
      for (double jf = (l == 0) ? (0.5) : (l-0.5) ; rint (jf - l - 0.5) <= 0.0 ; jf++)
	{
	  const double OBME_Y0_l = OBME_YL_tensor_l_reduced_in_j (1 , 0 , l , ji , l , jf);

	  const double OBME_Y0_l_test = Y0*OBME_l_reduced_in_j (l , ji , l , jf);

	  const double test = abs (OBME_Y0_l - OBME_Y0_l_test);

	  test_all = max (test_all , test);
	}

  if (test_all > precision) error_message_print_abort ("Problem in OBME_YL_tensor_l_test");
  
  cout << "Test of <lf || [YLc x l]^L || li>, <lf jf || [YLc x l]^L || li ji> matrix elements : Lc = 0 , L = 1 : " << test_all << endl << endl;
}








void OBME_s_scalar_e_test (const int lmax)
{	
  const double spin_reduced_in_s = OBME_j_reduced (0.5);
  
  const double sqrt_four_Pi = 3.54490770181103205458;

  // Method: <lf jf || s.e || li ji> from direct formula and from Wigner-Eckhart theorem

  double test_all = 0.0;

  for (int li = 0 ; li <= lmax ; li++)
    for (int lf = 0 ; lf <= lmax ; lf++)
      if ((li + lf)%2 == 1)
	for (double ji = (li == 0) ? (0.5) : (li-0.5) ; rint (ji - li - 0.5) <= 0.0 ; ji++)
	  for (double jf = (lf == 0) ? (0.5) : (lf-0.5) ; rint (jf - lf - 0.5) <= 0.0 ; jf++)
	    if (rint (ji - jf) == 0.0)
	      {	
		const double OBME_s_e = OBME_s_scalar_e_reduced_in_j (li , ji , lf , jf);

		const double OBME_Y1_reduced_in_l = OBME_YL_reduced_in_l (1 , li , lf);

		const double OBME_s_e_test = -sqrt_four_Pi*Oa_tensor_Ob_reduced_ME_calc (1 , 1 , 0 , li , 0.5 , ji , lf , 0.5 , jf , OBME_Y1_reduced_in_l , spin_reduced_in_s);

		const double test = abs (OBME_s_e - OBME_s_e_test);

		test_all = max (test_all , test);
	      }

  if (test_all > precision) error_message_print_abort ("Problem in OBME_s_scalar_e_test");
  
  cout << "Test of <lf jf || s.e || li ji> matrix elements : " << test_all << endl << endl;
}






void YL1_tensor_YL2_reduced_test (const int lmax , const double sample)
{	
  const double Y0 = 0.28209479177387814347;

  // Method: particular case : <lf || [YL x Y0]^L || li> = <lf || [Y0 x YL]^L || li> where L1 = L, L2 = 0 and L1 = 0 , L2 = L.

  double test_all = 0.0;

  for (int li = 0 ; li <= lmax ; li++)
    for (int lf = 0 ; lf <= lmax ; lf++)
      for (double ji = (li == 0) ? (0.5) : (li-0.5) ; rint (ji - li - 0.5) <= 0.0 ; ji++)
	for (double jf = (lf == 0) ? (0.5) : (lf-0.5) ; rint (jf - lf - 0.5) <= 0.0 ; jf++)
	  for (int L = abs (make_int (ji - jf)) ; L <= make_int (ji + jf) ; L++)
	    if ((li + L + lf)%2 == 0)
	      if (random_number<double> () < sample)
		{
		  const double Y0_tensor_YL_reduced_in_j = YL1_tensor_YL2_reduced_in_j (0 , L , L , li , ji , lf , jf);

		  const double YL_tensor_Y0_reduced_in_j = YL1_tensor_YL2_reduced_in_j (L , 0 , L , li , ji , lf , jf);

		  const double YL_reduced_in_j = OBME_YL_reduced_in_j (L , li , ji , lf , jf) , Y0_tensor_YL_reduced_in_j_test = Y0*YL_reduced_in_j;

		  const double test = max (abs (Y0_tensor_YL_reduced_in_j_test - Y0_tensor_YL_reduced_in_j) , abs (Y0_tensor_YL_reduced_in_j_test - YL_tensor_Y0_reduced_in_j));

		  test_all = max (test_all , test);
		}

  if (test_all > precision) error_message_print_abort ("Problem in YL1_tensor_YL2_reduced_test");
  
  cout << "Test of <lf jf || [YL1 x YL2]^L || li ji> matrix elements : L1 = 0 or L , L2 = L or 0 : " << test_all << endl << endl;
}







void Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_L_test (const int lmax , const double sample)
{	
  const double four_Pi = 12.566370614359173;

  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from <lc ld || \sum_{ml} Yl_ml(1).Yl_(-ml)(2) || la lb>_(L ML)

  double test_all = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  if ((la + lb)%2 == (lc + ld)%2)
	    {
	      const int lmin_op_ac = abs (la - lc);
	      const int lmin_op_bd = abs (lb - ld);

	      const int lmax_op_ac = la + lc;
	      const int lmax_op_bd = lb + ld;
	      
	      const int lmin_op = max (lmin_op_ac , lmin_op_bd);
	      const int lmax_op = min (lmax_op_ac , lmax_op_bd);

	      for (int l = lmin_op ; l <= lmax_op ; l++)
		if (((la + lc + l)%2 == 0) && ((lb + ld + l)%2 == 0))
		  {
		    const int Lmin_ab = abs (la - lb);
		    const int Lmin_cd = abs (lc - ld);		    

		    const int Lmax_ab = la + lb;		    
		    const int Lmax_cd = lc + ld;
		    
		    const int Lmin = max (Lmin_ab , Lmin_cd);
		    const int Lmax = min (Lmax_ab , Lmax_cd);

		    for (int L = Lmin ; L <= Lmax ; L++)
		      {	
			if (random_number<double> () < sample)
			  {
			    const double TBME = Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (la , lb , lc , ld , l , L);

			    const double ML = L;

			    double TBME_test = 0.0;

			    for (int ml = -l ; ml <= l ; ml++)
			      for (double ml_a = -la ; ml_a <= la ; ml_a++)
				{
				  const double ml_b = ML - ml_a;
				  const double ml_c = ml + ml_a;
				  const double ml_d = ML - ml_c;

				  if (rint (abs (ml_b) - lb) > 0.0) continue;
				  if (rint (abs (ml_c) - lc) > 0.0) continue;
				  if (rint (abs (ml_d) - ld) > 0.0) continue;

				  const double OBME_Yl_ml_ac_reduced = OBME_YL_reduced_in_l (l , la , lc);

				  const double OBME_Yl_minus_ml_bd_reduced = OBME_YL_reduced_in_l (l , lb , ld);

				  const double OBME_Yl_ml_ac = ME_dereduced (OBME_Yl_ml_ac_reduced , l , ml , la , ml_a , lc , ml_c);
				  
				  const double OBME_Yl_minus_ml_bd = ME_dereduced (OBME_Yl_minus_ml_bd_reduced , l , -ml , lb , ml_b , ld , ml_d);

				  const double CGs = Clebsch_Gordan (la , ml_a , lb , ml_b , L , ML) * Clebsch_Gordan (lc , ml_c , ld , ml_d , L , ML);

				  TBME_test += minus_one_pow (ml) * CGs * OBME_Yl_ml_ac * OBME_Yl_minus_ml_bd;
				}

			    TBME_test *= four_Pi / (2*l + 1);

			    const double test = abs (TBME - TBME_test);

			    test_all = max (test_all , test);
			  }
		      }
		  }
	    }

  if (test_all > precision) error_message_print_abort ("Problem in Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_L_test");
  
  cout << "Test of <lc ld || 4 Pi/(2l+1) (Yl(1).Yl(2)) || la lb>_L matrix elements : " << test_all << endl << endl;
}






void Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_J_test (const int lmax , const double sample)
{	
  const double four_Pi = 12.566370614359173;

  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from <lc jc ld jd || \sum_{ml} Yl_ml(1).Yl_(-ml)(2) || la ja lb jb>_(JM)

  double test_all = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = 0 ; lc <= lmax ; lc++)
	for (int ld = 0 ; ld <= lmax ; ld++)
	  if ((la + lb)%2 == (lc + ld)%2)
	    {
	      for (double ja = (la == 0) ? (0.5) : (la-0.5) ; rint (ja - la - 0.5) <= 0.0 ; ja++)
		for (double jb = (lb == 0) ? (0.5) : (lb-0.5) ; rint (jb - lb - 0.5) <= 0.0 ; jb++)
		  for (double jc = (lc == 0) ? (0.5) : (lc-0.5) ; rint (jc - lc - 0.5) <= 0.0 ; jc++)
		    for (double jd = (ld == 0) ? (0.5) : (ld-0.5) ; rint (jd - ld - 0.5) <= 0.0 ; jd++)
		      {
			const int lmin_op_ac = abs (make_int (ja - jc)); 
			const int lmin_op_bd = abs (make_int (jb - jd)); 

			const int lmax_op_ac = make_int (ja + jc); 
			const int lmax_op_bd = make_int (jb + jd);

			const int lmin_op = max (lmin_op_ac , lmin_op_bd); 
			const int lmax_op = min (lmax_op_ac , lmax_op_bd);

			for (int l = lmin_op ; l <= lmax_op ; l++)
			  if (((la + lc + l)%2 == 0) && ((lb + ld + l)%2 == 0))
			    {
			      const int Jmin_ab = abs (make_int (ja - jb));
			      const int Jmin_cd = abs (make_int (jc - jd)); 
 
			      const int Jmax_ab = make_int (ja + jb); 
			      const int Jmax_cd = make_int (jc + jd);

			      const int Jmin = max (Jmin_ab , Jmin_cd); 
			      const int Jmax = min (Jmax_ab , Jmax_cd);

			      for (int J = Jmin ; J <= Jmax ; J++)
				{	
				  if (random_number<double> () < sample)
				    {
				      const double TBME = Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one (la , ja , lb , jb , lc , jc , ld , jd , l , J);

				      const double M = J;

				      double TBME_test = 0.0;

				      for (int ml = -l ; ml <= l ; ml++)
					for (double ma = -ja ; rint (ma - ja) <= 0.0 ; ma += 1.0)
					  {
					    const double mb = M - ma; 

					    const double mc = ml + ma; 

					    const double md = M - mc;

					    if (rint (abs (mb) - jb) > 0.0) continue;
					    if (rint (abs (mc) - jc) > 0.0) continue;
					    if (rint (abs (md) - jd) > 0.0) continue;

					    const double OBME_Yl_ml_ac_reduced = OBME_YL_reduced_in_j (l , la , ja , lc , jc); 

					    const double OBME_Yl_minus_ml_bd_reduced = OBME_YL_reduced_in_j (l , lb , jb , ld , jd); 

					    const double OBME_Yl_ml_ac = ME_dereduced (OBME_Yl_ml_ac_reduced , l , ml , ja , ma , jc , mc);
					    
					    const double OBME_Yl_minus_ml_bd = ME_dereduced (OBME_Yl_minus_ml_bd_reduced , l , -ml , jb , mb , jd , md);

					    const double CGs = Clebsch_Gordan (ja , ma , jb , mb , J , M) * Clebsch_Gordan (jc , mc , jd , md , J , M);

					    TBME_test += minus_one_pow (ml) * CGs * OBME_Yl_ml_ac * OBME_Yl_minus_ml_bd;
					  }

				      TBME_test *= four_Pi / (2*l + 1);

				      const double test = abs (TBME - TBME_test);

				      test_all = max (test_all , test);
				    }
				}
			    }
		      }
	    }

  if (test_all > precision) error_message_print_abort ("Problem in Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_J_test");
  
  cout << "Test of <lc jc ld jd || 4 Pi/(2l+1) (Yl(1).Yl(2)) || la ja lb jb>_J matrix elements : " << test_all << endl << endl;
}






void sigma_1_sigma_2_test (const int lmax , const double sample)
{
  // Method: calculation in LS scheme using Wigner 9j coefficients

  double test_all = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = min (la-1,0) ; lc <= la+1 ; lc++)
	for (int ld = min (lb-1,0) ; ld <= lb+1 ; ld++)
	  for (double ja = (la == 0) ? (0.5) : (la-0.5) ; rint (ja - la - 0.5) <= 0.0 ; ja++)
	    for (double jb = (lb == 0) ? (0.5) : (lb-0.5) ; rint (jb - lb - 0.5) <= 0.0 ; jb++)
	      for (double jc = (lc == 0) ? (0.5) : (lc-0.5) ; rint (jc - lc - 0.5) <= 0.0 ; jc++)
		for (double jd = (ld == 0) ? (0.5) : (ld-0.5) ; rint (jd - ld - 0.5) <= 0.0 ; jd++)
		  {
		    const double hats_js = hat (ja)*hat (jb)*hat (jc)*hat (jd);

		    const int Jmin_ab = abs (make_int (ja - jb));
		    const int Jmin_cd = abs (make_int (jc - jd)); 
 
		    const int Jmax_ab = make_int (ja + jb); 
		    const int Jmax_cd = make_int (jc + jd);

		    const int Jmin = max (Jmin_ab , Jmin_cd); 
		    const int Jmax = min (Jmax_ab , Jmax_cd);

		    const double delta_abcd = (same_lj (la , ja , lc , jc) && same_lj (lb , jb , ld , jd)) ? (1.0) : (0.0);
		  
		    for (int J = Jmin ; J <= Jmax ; J++)
		      {	
			if (random_number<double> () < sample)
			  {
			    const double TBME = sigma_1_sigma_2_calc (la , ja , lb , jb , lc , jc , ld , jd , J);

			    const int Lmin_ab = abs (la - lb);
			    const int Lmin_cd = abs (lc - ld);

			    const int Lmax_ab = la + lb;
			    const int Lmax_cd = lc + ld;

			    const int Lmin = max (Lmin_ab , Lmin_cd);
			    const int Lmax = min (Lmax_ab , Lmax_cd);

			    double TBME_test = 0.0;

			    if ((la == lc) && (lb == ld))
			      {
				for (int L = Lmin ; L <= Lmax ; L++)
				  {
				    const int hats_L = 2*L + 1;

				    for (int S = 0 ; S <= 1 ; S++)
				      {
					const double TBME_sigma_1_sigma_2_calc_coupled_to_S = 2.0*minus_one_pow (S+1) - delta_abcd;

					const int hats_S = 2*S + 1;

					const double Wig_9j_ab = Wigner_9j (la , 0.5 , ja , lb , 0.5 , jb , L , S , J);
					const double Wig_9j_cd = Wigner_9j (lc , 0.5 , jc , ld , 0.5 , jd , L , S , J);

					TBME_test += hats_js*hats_S*hats_L*Wig_9j_ab*Wig_9j_cd*TBME_sigma_1_sigma_2_calc_coupled_to_S;
				      }
				  }
			      }
			    
			    const double test = abs (TBME - TBME_test);

			    test_all = max (test_all , test);
			  }
		      }
		  }

  if (test_all > precision) error_message_print_abort ("Problem in sigma_1_sigma_2_test");
  
  cout << "Test of <lc jc ld jd || sigma(1).sigma(2) || la ja lb jb>_J matrix elements : " << test_all << endl << endl;
}





void Psigma_test (const int lmax , const double sample)
{
  // Method: calculation in LS scheme using Wigner 9j coefficients

  double test_all = 0.0;

  for (int la = 0 ; la <= lmax ; la++)
    for (int lb = 0 ; lb <= lmax ; lb++)
      for (int lc = min (la-1,0) ; lc <= la+1 ; lc++)
	for (int ld = min (lb-1,0) ; ld <= lb+1 ; ld++)
	  for (double ja = (la == 0) ? (0.5) : (la-0.5) ; rint (ja - la - 0.5) <= 0.0 ; ja++)
	    for (double jb = (lb == 0) ? (0.5) : (lb-0.5) ; rint (jb - lb - 0.5) <= 0.0 ; jb++)
	      for (double jc = (lc == 0) ? (0.5) : (lc-0.5) ; rint (jc - lc - 0.5) <= 0.0 ; jc++)
		for (double jd = (ld == 0) ? (0.5) : (ld-0.5) ; rint (jd - ld - 0.5) <= 0.0 ; jd++)
		  {
		    const double hats_js = hat (ja)*hat (jb)*hat (jc)*hat (jd);

		    const int Jmin_ab = abs (make_int (ja - jb));
		    const int Jmin_cd = abs (make_int (jc - jd)); 
 
		    const int Jmax_ab = make_int (ja + jb); 
		    const int Jmax_cd = make_int (jc + jd);

		    const int Jmin = max (Jmin_ab , Jmin_cd); 
		    const int Jmax = min (Jmax_ab , Jmax_cd);

		    for (int J = Jmin ; J <= Jmax ; J++)
		      {	
			if (random_number<double> () < sample)
			  {
			    const double TBME = Psigma (la , ja , lb , jb , lc , jc , ld , jd , J);

			    const int Lmin_ab = abs (la - lb);
			    const int Lmin_cd = abs (lc - ld);

			    const int Lmax_ab = la + lb;
			    const int Lmax_cd = lc + ld;

			    const int Lmin = max (Lmin_ab , Lmin_cd);
			    const int Lmax = min (Lmax_ab , Lmax_cd);

			    double TBME_test = 0.0;

			    if ((la == lc) && (lb == ld))
			      {
				for (int L = Lmin ; L <= Lmax ; L++)
				  {
				    const int hats_L = 2*L + 1;

				    for (int S = 0 ; S <= 1 ; S++)
				      {
					const double TBME_Psigma_coupled_to_S = minus_one_pow (S+1);

					const int hats_S = 2*S + 1;

					const double Wig_9j_ab = Wigner_9j (la , 0.5 , ja , lb , 0.5 , jb , L , S , J);
					const double Wig_9j_cd = Wigner_9j (lc , 0.5 , jc , ld , 0.5 , jd , L , S , J);

					TBME_test += hats_js*hats_S*hats_L*Wig_9j_ab*Wig_9j_cd*TBME_Psigma_coupled_to_S;
				      }
				  }
			      }
			    
			    const double test = abs (TBME - TBME_test);

			    test_all = max (test_all , test);
			  }
		      }
		  }

  if (test_all > precision) error_message_print_abort ("Problem in Psigma_test");
  
  cout << "Test of <lc jc ld jd || Psigma || la ja lb jb>_J matrix elements : " << test_all << endl << endl;
}




void P_lambda_rotor_tensor_spinless_part_test (const int lmax , const double sample)
{	
  const double four_Pi = 12.566370614359173;

  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from < j' l' || \sum_{ml} Yl_ml(1).Yl_(-ml)(2) || j l>_(JM)

  double test_all = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    for (int lp = 0 ; lp <= lmax ; lp++)
      for (int j = 0 ; j <= lmax ; j++)
	for (int jp = 0 ; jp <= lmax ; jp++)
	  if ((l + j)%2 == (lp + lp)%2)
	    {
	      const int lambda_min_op_l = abs (l - lp);
	      const int lambda_min_op_j = abs (j - jp); 
 
	      const int lambda_max_op_l = l + lp; 
	      const int lambda_max_op_j = j + jp;

	      const int lambda_min_op = max (lambda_min_op_l , lambda_min_op_j); 
	      const int lambda_max_op = min (lambda_max_op_l , lambda_max_op_j);

	      for (int lambda = lambda_min_op ; lambda <= lambda_max_op ; lambda++)
		if (((l + lp + lambda)%2 == 0) && ((j + jp + lambda)%2 == 0))
		  {
		    const int Jmin_lj = abs (l - j);

		    const int Jmin_lp_jp = abs (lp - jp); 
 
		    const int Jmax_lj = l + j; 

		    const int Jmax_lp_jp = lp + jp;

		    const int Jmin = max (Jmin_lj , Jmin_lp_jp); 
		    const int Jmax = min (Jmax_lj , Jmax_lp_jp);

		    for (int J = Jmin ; J <= Jmax ; J++)
		      {	
			if (random_number<double> () < sample)
			  {
			    const double P_lambda_rotor_tensor_spinless_part = P_lambda_rotor_tensor_spinless_part_calc (lambda , j , l , jp , lp , J);

			    const int M = J;

			    double P_lambda_rotor_tensor_spinless_part_test = 0.0;

			    for (int m_lambda = -lambda ; m_lambda <= lambda ; m_lambda++)
			      for (int m = -l ; m <= l ; m++)
				{
				  const int mj = M - m , mp = m_lambda + m , mjp = M - mp;

				  if (abs (mj) > j) continue;
				  if (abs (mp) > lp) continue;
				  if (abs (mjp) > jp) continue;

				  const double OBME_Ylm_lambda_l_reduced = OBME_YL_reduced_in_l (lambda , l , lp);

				  const double OBME_Yl_minus_m_lambda_j_reduced = OBME_YL_reduced_in_l (lambda , j , jp);

				  const double OBME_Ylm_lambda_l = ME_dereduced (OBME_Ylm_lambda_l_reduced , lambda , m_lambda , l , m , lp , mp);
								  
				  const double OBME_Yl_minus_m_lambda_j = ME_dereduced (OBME_Yl_minus_m_lambda_j_reduced , lambda , -m_lambda , j , mj , jp , mjp);

				  const double CGs = Clebsch_Gordan (j , mj , l , m , J , M) * Clebsch_Gordan (jp , mjp , lp , mp , J , M);

				  P_lambda_rotor_tensor_spinless_part_test += minus_one_pow (m_lambda) * CGs * OBME_Ylm_lambda_l * OBME_Yl_minus_m_lambda_j;
				}

			    P_lambda_rotor_tensor_spinless_part_test *= four_Pi / (2*lambda + 1);

			    const double test = abs (P_lambda_rotor_tensor_spinless_part - P_lambda_rotor_tensor_spinless_part_test);

			    test_all = max (test_all , test);
			  }
		      }
		  }
	    }
  
  if (test_all > precision) error_message_print_abort ("Problem in P_lambda_rotor_tensor_spinless_part_test");

  cout << "Test of <j' l' | 4 Pi/(2 lambda+1) Ylambda(rotor).Ylambda(particle) | j l>_J matrix elements : " << test_all << endl << endl;
}




void P_lambda_rotor_tensor_part_test (const int lmax , const double sample)
{	
  const double four_Pi = 12.566370614359173;

  // Method: direct recalculation with Clebsch-Gordan and Wigner-Eckhart theorem from < jr' , j' (l' , s') || \sum_{ml} Yl_ml(1).Yl_(-ml)(2) || jr , j (l , s)>_(JM)

  double test_all = 0.0;

  for (int l = 0 ; l <= lmax ; l++)
    for (int lp = 0 ; lp <= lmax ; lp++)
      for (int jr = 0 ; jr <= lmax ; jr++)
	for (int jrp = 0 ; jrp <= lmax ; jrp++)
	  if ((l + jr)%2 == (lp + lp)%2)
	    for (double j = (l == 0) ? (0.5) : (l-0.5) ; rint (j - l - 0.5) <= 0.0 ; j++)
	      for (double jp = (lp == 0) ? (0.5) : (lp-0.5) ; rint (jp - lp - 0.5) <= 0.0 ; jp++)
		{
		  const int lambda_min_op_j = abs (make_int (j - jp)); 
		  const int lambda_max_op_j = make_int (j + jp); 

		  const int lambda_min_op_jr = abs (jr - jrp); 
		  const int lambda_max_op_jr = jr + jrp;

		  const int lambda_min_op = max (lambda_min_op_j , lambda_min_op_jr); 
		  const int lambda_max_op = min (lambda_max_op_j , lambda_max_op_jr);

		  for (int lambda = lambda_min_op ; lambda <= lambda_max_op ; lambda++)
		    if (((l + lp + lambda)%2 == 0) && ((jr + jrp + lambda)%2 == 0))
		      {
			const double Jmin_j_jr = abs (j - jr); 
			const double Jmax_j_jr = j + jr; 

			const double Jmin_jp_jrp = abs (jp - jrp); 
			const double Jmax_jp_jrp = jp + jrp;

			const double Jmin = max (Jmin_j_jr , Jmin_jp_jrp); 
			const double Jmax = min (Jmax_j_jr , Jmax_jp_jrp);

			for (double J = Jmin ; rint (J - Jmax) <= 0.0 ; J += 1.0)
			  if (random_number<double> () < sample)
			    {
			      const double P_lambda_rotor_tensor_part = P_lambda_rotor_tensor_part_calc (lambda , jr , l , j , jrp , lp , jp , J) , M = J;

			      double P_lambda_rotor_tensor_part_test = 0.0;

			      for (int m_lambda = -lambda ; m_lambda <= lambda ; m_lambda++)
				for (double m = -j ; rint (m - j) <= 0.0 ; m += 1.0)
				  {		
				    const int mjr = make_int (M - m);
				    
				    const double mp = m_lambda + m;

				    const int mjrp = make_int (M - mp);

				    if (abs (mjr) > jr) continue;
				    
				    if (make_int (abs (mp) - jp) > 0.0) continue;

				    if (abs (mjrp) > jrp) continue;

				    const double OBME_Ylm_lambda_j_reduced = OBME_YL_reduced_in_j (lambda , l , j , lp , jp);

				    const double OBME_Yl_minus_m_lambda_jr_reduced = OBME_YL_reduced_in_l (lambda , jr , jrp);

				    const double OBME_Ylm_lambda_j = ME_dereduced (OBME_Ylm_lambda_j_reduced , lambda , m_lambda , j , m , jp , mp);
				    
				    const double OBME_Yl_minus_m_lambda_jr = ME_dereduced (OBME_Yl_minus_m_lambda_jr_reduced , lambda , -m_lambda , jr , mjr , jrp , mjrp);

				    const double CGs = Clebsch_Gordan (jr , mjr , j , m , J , M) * Clebsch_Gordan (jrp , mjrp , jp , mp , J , M);

				    P_lambda_rotor_tensor_part_test += minus_one_pow (m_lambda) * CGs * OBME_Ylm_lambda_j * OBME_Yl_minus_m_lambda_jr;
				  }

			      P_lambda_rotor_tensor_part_test *= four_Pi / (2*lambda + 1);

			      const double test = abs (P_lambda_rotor_tensor_part - P_lambda_rotor_tensor_part_test);

			      test_all = max (test_all , test);
			    }
		      }
		}

  if (test_all > precision) error_message_print_abort ("Problem in P_lambda_rotor_tensor_part_test");
  
  cout << "Test of <jr' , j' (l' , s') | 4 Pi/(2 lambda+1) Ylambda(rotor).Ylambda(particle) | jr , j (l , s)>_J matrix elements : " << test_all << endl << endl;
}



#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
    
    cout.precision (15);

    srand48 (time (NULL));

    const int lmax = 12;
    
    const double sample_YL_j = 0.05;

    const double sample_scalar_TBME_coupled_to_L = 0.0005;

    const double sample_YL1_tensor_YL2 = 0.05;

    const double sample_scalar_TBME_coupled_to_J = 0.00005;

    const double sample_sigma_1_sigma_2 = 0.005;
    
    const double sample_Psigma = 0.005;

    const double sample_P_lambda_rotor_tensor_spinless_part = 0.001;

    const double sample_P_lambda_rotor_tensor_part = 0.0005;

    sigma_reduced_in_j_test (lmax);

    OBME_l_reduced_in_j_test (lmax);

    OBME_YL_reduced_in_j_test (lmax , sample_YL_j);

    OBME_YL_square_test (lmax);
    
    OBME_YL_tensor_s_test (lmax);

    OBME_YL_tensor_l_test (lmax);

    OBME_s_scalar_e_test (lmax);

    YL1_tensor_YL2_reduced_test (lmax , sample_YL1_tensor_YL2);

    Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_L_test (lmax , sample_scalar_TBME_coupled_to_L);
    Yl_1_scalar_Yl_2_four_Pi_over_two_l_plus_one_coupled_to_J_test (lmax , sample_scalar_TBME_coupled_to_J);
    
    sigma_1_sigma_2_test (lmax , sample_sigma_1_sigma_2);
    
    Psigma_test (lmax , sample_Psigma);

    P_lambda_rotor_tensor_spinless_part_test (lmax , sample_P_lambda_rotor_tensor_spinless_part);

    P_lambda_rotor_tensor_part_test (lmax , sample_P_lambda_rotor_tensor_part);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
