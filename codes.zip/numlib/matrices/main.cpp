#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void tests_1 ()
{
  const complex<double> a(4.7 , 3.8) , b(7.8 , -3.9) , c(2.4 , -1.2);
    
  class matrix<complex<double> > M2(2) , A2(2) , B2(2);
    
  M2 = identity<complex<double> > (2) + a;

  const complex<double> exact_determinant_2 = 2*a + 1.0;

  if (inf_norm (M2.determinant ()/exact_determinant_2 - 1.0) > 1E-13) error_message_print_abort ("Problem in class matrix with determinant (dimension 2)"); 

  M2 = identity<complex<double> > (2) + a;

  complex<double> log_Det_no_phase = 0.0;

  int phase = 1;

  M2.log_scaled_determinant_and_phase (log_Det_no_phase , phase);

  if (inf_norm (phase*exp (log_Det_no_phase)/exact_determinant_2) - 1.0 > 1E-13) error_message_print_abort ("Problem in class matrix with log_scaled_determinant_and_phase (dimension 2)"); 
  
  M2.random_matrix ();

  M2 *= complex<double> (1 , -0.2);

  A2 = M2;

  M2.inverse ();

  B2 = inverse (A2) - M2;

  if (B2.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with inverse (dimension 2)"); 

  const unsigned int Nr = 17;

  const unsigned int Nc = 17;

  class matrix<complex<double> > M(Nr , Nc);

  M.random_matrix ();

  M *= complex<double> (4 , 6);

  matrix<complex<double> > A = b*M , B = A;

  if (!(A == B)) error_message_print_abort ("Problem in class matrix with ==");

  if (A != B) error_message_print_abort ("Problem in class matrix with !");

  if (A.is_it_real ()) error_message_print_abort ("Problem in class matrix with is_it_real");

  B = +A;

  A = B;

  A = -A;

  A = -A;

  A += a*M;

  A -= a*M;

  A *= b;

  A /= b;

  A += c;

  A -= c;

  A -= b*M;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , += , -= , *= or /=");

  A = b*M;

  A = c + A;

  A = c - A;

  A = A + a*M;

  A = A - a*M;

  A = A*b;

  A = A/b;

  A = A + c;

  A = A - c;

  A = A + b*M;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - , * or /");

  class sparse_matrix<complex<double> > A_sp = A , B_sp = A , M_sp = M;

  A += a*M_sp;
  A -= a*M_sp;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , += , -= (matrix, sparse_matrix");

  A = +M_sp;
  
  if ((A - M_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - (matrix, sparse_matrix) (1)");

  A = -M_sp;

  if ((A + M_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - (matrix, sparse_matrix) (2)");

  const unsigned int N = 7;
  
  class matrix<complex<double> > A0(N);

  A0.identity ();

  class sparse_matrix<complex<double> > M0_sp = A0;

  A0 = A0 + a*M0_sp;
  A0 = A0 - a*M0_sp;
  
  if ((A0 - identity<complex<double> > (N)).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - (matrix, sparse_matrix) (3)");
  
  B = A_sp + a*M;

  A = B - a*M;

  if ((A - A_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - (matrix, sparse_matrix) (4)");

  B = A_sp - a*M;

  A = B + a*M;

  if ((A - A_sp).infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , + , - (matrix, sparse_matrix) (5)");
}








void tests_2 ()
{
  const complex<double> a(4.7 , 3.8) , b(7.8 , -3.9) , c(2.4 , -1.2);

  const double e = 7.8;
  
  const unsigned int N = 17;
  
  class matrix<complex<double> > A(N) , B(N) , M(N);
  
  A = 0.0;
    
  const unsigned int d = N*(N-1)/2.0;

  unsigned int k = 0;

  for (unsigned int i = 0 ; i < N ; i++) 
    for (unsigned int j = 0 ; j < N ; j++) 
      if (k++ < d) 
	A(i , j) = a;

  if (A.non_zeros_number_calc () != d) error_message_print_abort ("Problem in class matrix with non_zeros_number_calc");

  if (inf_norm (A.non_zeros_proportion () - 100.0*d/static_cast<double> (N*N)) > 1E-13) error_message_print_abort ("Problem in class matrix with non_zeros_number_proportion");

  A.identity ();

  if (!A.is_it_diagonal ()) error_message_print_abort ("Problem in class matrix with is_it_diagonal"); 

  A -= identity<complex<double> > (N);

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with identity");

  A.scalar (a);

  A -= scalar<complex<double> > (N , a);

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with scalar");

  A = M + B;

  A *= b;

  A /= b;

  A += e;

  A -= e;

  A = A - M - B;

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with = , += , -= , *= or /=");

  B = -A;

  M = B + A;

  if (M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with unary -");

  M.random_matrix ();

  M.symmetrize ();

  if (!M.is_it_symmetric ()) error_message_print_abort ("Problem in class matrix with is_it_symmetric"); 

  M.random_matrix ();    

  M.hermitize ();

  if (!M.is_it_hermitian ()) error_message_print_abort ("Problem in class matrix with is_it_hermitian"); 

  M.symmetric_random_matrix ();

  if (!M.is_it_symmetric ()) error_message_print_abort ("Problem in class matrix with is_it_symmetric"); 

  M.hermitian_random_matrix ();

  if (!M.is_it_hermitian ()) error_message_print_abort ("Problem in class matrix with is_it_hermitian");
    
  M.antisymmetrize ();

  if (!M.is_it_antisymmetric ()) error_message_print_abort ("Problem in class matrix with is_it_antisymmetric"); 

  M.antisymmetric_random_matrix ();

  if (!M.is_it_antisymmetric ()) error_message_print_abort ("Problem in class matrix with is_it_antisymmetric"); 

  M *= a;

  A = M;

  A.transpose ();

  B = transpose (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in transpose");

  M.random_matrix ();

  M *= a;

  A = M;

  A.conjugate ();

  B = conj (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with conjugate"); 

  M.random_matrix ();

  M *= a;

  A = M;

  A.dagger ();

  B = dagger (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with dagger"); 

  class matrix<double> Re_M(N);
  class matrix<double> Im_M(N);

  Re_M = real<double , complex<double> > (M);
  Im_M = imag<double , complex<double> > (M);
  
  class matrix<complex<double> > M_test = complex_matrix<double , complex<double> > (Re_M , Im_M);
  
  A = M - M_test;	

  if (A.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with real , imag or complex_matrix");

  if (!Re_M.is_it_real ()) error_message_print_abort ("Problem in class matrix with is_it_real");

  class matrix<unsigned int> C(N);

  C.identity ();

  Re_M = convert<unsigned int , double> (C);

  Re_M -= identity<double> (N);

  if (Re_M.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with convert"); 

  unsigned int T = C.trace ();

  if (T != N) error_message_print_abort ("Problem in class matrix with trace"); 

  class vector_class<complex<double> > V(N);

  V.random_vector ();
    
  M = identity<complex<double> > (N) + complex<double> (e);

  const complex<double> exact_determinant_e = N*e + 1.0;

  M.Cholesky_decompose ();

  if (!M.is_it_Cholesky_decomposed ()) error_message_print_abort ("M should be Cholesky decomposed");

  if (inf_norm (M.determinant ()/exact_determinant_e - 1.0) > 1E-13) error_message_print_abort ("Problem in class matrix with determinant (Cholesky)"); 
    
  M = identity<complex<double> > (N) + complex<double> (e);  

  complex<double> log_Det_no_phase = 0.0;  

  int phase = 1;

  M.Cholesky_decompose ();

  if (!M.is_it_Cholesky_decomposed ()) error_message_print_abort ("M should be Cholesky decomposed");

  if (inf_norm (M.determinant ()/exact_determinant_e - 1.0) > 1E-13) error_message_print_abort ("Problem in class matrix with log_scaled_determinant_and_phase (Cholesky)"); 

  M = identity<complex<double> > (N) + a;

  const complex<double> exact_determinant_a = N*a + 1.0;

  M.LU_decompose ();

  if (!M.is_it_LU_decomposed ()) error_message_print_abort ("M should be LU decomposed");

  if (inf_norm (M.determinant ()/exact_determinant_a - 1.0) > 1E-13) error_message_print_abort ("Problem in class matrix with determinant (LU)"); 

  M = identity<complex<double> > (N) + a;    

  log_Det_no_phase = 0.0;  

  phase = 1;

  M.log_scaled_determinant_and_phase (log_Det_no_phase , phase);
    
  if (inf_norm (phase*exp (log_Det_no_phase)/exact_determinant_a - 1.0) > 1E-13) error_message_print_abort ("Problem in class matrix with log_scaled_determinant_and_phase (LU)"); 
    
  M.random_matrix ();

  M *= complex<double> (1 , -0.2);

  A = M;

  M.inverse ();

  B = inverse (A) - M;

  if (B.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with inverse (external) or inverse (member class)");
    
  B = A*M;

  A.identity ();

  B -= A;

  if (B.infinite_norm ()/N > 1E-13) error_message_print_abort ("Problem in class matrix with inverse (member class)");

  class matrix<double> Y(N , N+2);
  
  Y.random_matrix ();

  const double Y_min = Y.min ();
  const double Y_max = Y.max ();

  for (unsigned int i = 0 ; i < N ; i++)
    for (unsigned int j = 0 ; j < N+2 ; j++)
      {
	if (Y(i,j) < Y_min) error_message_print_abort ("Problem in class matrix with min (member class)");
	if (Y(i,j) > Y_max) error_message_print_abort ("Problem in class matrix with max (member class)");
      }
}







void tests_3 ()
{
  const complex<double> a(3.7 , 7.8);
  
  const unsigned int Nr = 12 , Nc = 5 , N = 7;

  class matrix<complex<double> > A(N) , Ar(Nr , N) , Br(N , Nc) , Cr(Nr , Nc) , Cr_check(Nr , Nc);

  A.random_matrix ();
  
  Ar.random_matrix ();
  Br.random_matrix ();
  Cr = Ar*Br;

  Cr_check = 0.0;

  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      for (unsigned int k = 0 ; k < N ; k++)
	Cr_check(i , j) += Ar(i , k)*Br(k , j);

  Cr_check -= Cr;

  if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with operator * (A*B)"); 
    
  Ar.put_zeros_with_probability (0.5);
  Br.put_zeros_with_probability (0.5);
    
  class sparse_matrix<complex<double> > Ar_sp = Ar;
  class sparse_matrix<complex<double> > Br_sp = Br;
    
  Cr = Ar_sp*Br;

  Cr_check = 0.0;

  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      for (unsigned int k = 0 ; k < N ; k++)
	Cr_check(i , j) += Ar_sp.matrix_element_determine (i , k)*Br(k , j);

  Cr_check -= Cr;

  if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with operator * (A[sparse]*B)");

  Cr = Ar*Br_sp;

  Cr_check = 0.0;

  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      for (unsigned int k = 0 ; k < N ; k++)
	Cr_check(i , j) += Ar(i , k)*Br_sp.matrix_element_determine (k , j);

  Cr_check -= Cr;

  if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with operator * (A*B[sparse])");

  Cr = Ar_sp*Br_sp;

  Cr_check = 0.0;

  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      for (unsigned int k = 0 ; k < N ; k++)
	Cr_check(i , j) += Ar_sp.matrix_element_determine (i , k)*Br_sp.matrix_element_determine (k , j);

  Cr_check -= Cr;

  if (Cr_check.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class matrix with operator * (A[sparse]*B[sparse])");

  class array<complex<double> > A_diagonal_init(N);
  
  A.diagonal_part (A_diagonal_init);

  A.add_scalar_diagonal_part (a);
  
  A.remove_scalar_diagonal_part (a);

  for (unsigned int i = 0 ; i < N ; i++)
    if (inf_norm (A(i , i) - A_diagonal_init(i)) > 1E-13)
      error_message_print_abort ("Problem in class matrix with add/remove_scalar_diagonal_part"); 
    
  A.multiply_scalar_diagonal_part (a);

  A.divide_scalar_diagonal_part (a);
    
  for (unsigned int i = 0 ; i < N ; i++)
    if (inf_norm (A(i , i) - A_diagonal_init(i)) > 1E-13)
      error_message_print_abort ("Problem in class matrix with multiply/divide_scalar_diagonal_part");
    
  A.put_scalar_diagonal_part (a);
    
  for (unsigned int i = 0 ; i < N ; i++)
    if (inf_norm (A(i , i) - a) > 1E-13)
      error_message_print_abort ("Problem in class matrix with put_scalar_diagonal_part");
    
  A.identity ();

  if (maximal_overlap_eigenvector_index_determine (A , N/2) != N/2) error_message_print_abort ("Problem with maximal_overlap_eigenvector_index_determine");

}







void tests_4 ()
{
  const unsigned int Nr = 12;
  const unsigned int Nc = 17;
  
  class matrix<complex<double> > A(Nr , Nc);
  class matrix<complex<double> > B(Nr , Nc);
     
  complex<double> AB_scalar_product_1 = 0.0;
  complex<double> AB_scalar_product_2 = 0.0;
  
  complex<double> M_norm_1 = 0.0;
  complex<double> M_norm_2 = 0.0;
    
  A.random_matrix ();
  B.random_matrix ();    
  
  A.put_zeros_with_probability (0.5);
  B.put_zeros_with_probability (0.5);
      
  class sparse_matrix<complex<double> > A_sp = A;
  class sparse_matrix<complex<double> > B_sp = B;
  
  class matrix<complex<double> > M = A*transpose (B);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product (A , B);
  
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product (full , full)");
    
  M = A_sp*transpose (B);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product (A_sp , B);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product (sparse , full)");

  M = A*transpose (B_sp);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product (A , B_sp);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product (full , sparse)");

  M = A_sp*transpose (B_sp);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product (A_sp , B_sp);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product (sparse , sparse)");

  M = A*dagger (B);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A , B);
  
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product_hermitian (full , full)");
    
  M = A_sp*dagger (B);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A_sp , B);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product_hermitian (sparse , full)");

  M = A*dagger (B_sp);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A , B_sp);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product_hermitian (full , sparse)");

  M = A_sp*dagger (B_sp);

  AB_scalar_product_1 = M.trace ();

  AB_scalar_product_2 = Frobenius_scalar_product_hermitian (A_sp , B_sp);
    
  if (inf_norm (AB_scalar_product_1 - AB_scalar_product_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_scalar_product_hermitian (sparse , sparse)");

  M_norm_1 = sqrt (Frobenius_scalar_product (M , M));

  M_norm_2 = M.Frobenius_norm ();
  
  if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_norm (full)");
    
  M_norm_1 = sqrt (Frobenius_scalar_product_hermitian (M , M));

  M_norm_2 = M.Frobenius_norm_hermitian ();
    
  if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_norm_hermitian (full)");
      
  class sparse_matrix<complex<double> > M_sp = M;
  
  M_norm_1 = sqrt (Frobenius_scalar_product (M_sp , M_sp));

  M_norm_2 = M_sp.Frobenius_norm ();
  
  if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_norm (sparse)");
    
  M_norm_1 = sqrt (Frobenius_scalar_product_hermitian (M_sp , M_sp));

  M_norm_2 = M_sp.Frobenius_norm_hermitian ();
    
  if (inf_norm (M_norm_1 - M_norm_2) > 1E-13) error_message_print_abort ("Problem in class matrix with Frobenius_norm_hermitian (sparse)");
    
  A = A_sp;

  if (!(A    == A_sp)) error_message_print_abort ("Problem in class matrix with == (full , sparse) (1)");
  if (!(A_sp == A   )) error_message_print_abort ("Problem in class matrix with == (sparse, full) (1)");
    
  if (A    != A_sp) error_message_print_abort ("Problem in class matrix with ! (full , sparse) (1)");
  if (A_sp != A   ) error_message_print_abort ("Problem in class matrix with ! (sparse , full) (1)");
    
  class array<unsigned int> row_indices(6); 

  class array<unsigned int> column_indices(6);
    
  class array<complex<double> > matrix_elements(6);

  row_indices(0) = 2 , column_indices(0) = 4 , matrix_elements(0) = 5;
  row_indices(1) = 0 , column_indices(1) = 1 , matrix_elements(1) = 3;
  row_indices(2) = 0 , column_indices(2) = 2 , matrix_elements(2) = 9;
  row_indices(3) = 1 , column_indices(3) = 3 , matrix_elements(3) = 7;
  row_indices(4) = 1 , column_indices(4) = 2 , matrix_elements(4) = 5;
  row_indices(5) = 0 , column_indices(5) = 0 , matrix_elements(5) = 1;

  A_sp.deallocate ();
    
  A_sp.allocate_fill (A.get_dimension_row () , A.get_dimension_column () , row_indices , column_indices , matrix_elements);

  A = A_sp;
    
  if (!(A == A_sp)) error_message_print_abort ("Problem in class matrix with == (full , sparse) (2)");
  if (!(A_sp == A)) error_message_print_abort ("Problem in class matrix with == (sparse, full) (2)");
    
  if (A != A_sp) error_message_print_abort ("Problem in class matrix with ! (full , sparse) (2)");
  if (A_sp != A) error_message_print_abort ("Problem in class matrix with ! (sparse , full) (2)");
    
  A = A_sp;

  A_sp.indices_matrix_sort ();
    
  if (!(A    == A_sp)) error_message_print_abort ("Problem in class matrix with == (full , sparse) (3)");
  if (!(A_sp == A   )) error_message_print_abort ("Problem in class matrix with == (sparse, full) (3)");
    
  if (A    != A_sp) error_message_print_abort ("Problem in class matrix with ! (full , sparse) (3)");
  if (A_sp != A   ) error_message_print_abort ("Problem in class matrix with ! (sparse , full) (3)");

  A.random_matrix ();

  const complex<double> A_sum = A.sum ();
  
  const complex<double> A_product = A.product ();

  complex<double> A_sum_check = 0.0;
  
  complex<double> A_product_check = 1.0;
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      {
	A_sum_check += A(i,j);
	
	A_product_check *= A(i,j);
      }

  if (inf_norm (A_sum     - A_sum_check    ) > precision) error_message_print_abort ("Problem in class matrix with sum");
  if (inf_norm (A_product - A_product_check) > precision) error_message_print_abort ("Problem in class matrix with product");
}








#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  MPI_parallelization_linear_algebra_enabled ();

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
  
    OpenMP_parallelization_linear_algebra_enabled ();

#ifdef UseOpenMP
    OpenMP_set_threads_number (4);
#endif

    tests_1 ();
    tests_2 ();
    tests_3 ();
    tests_4 ();
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << "All matrix class tests are correct." << endl;
    
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

