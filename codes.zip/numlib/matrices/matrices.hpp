#ifndef MATRIX_HPP
#define MATRIX_HPP

extern bool is_it_OpenMP_parallelized_linear_algebra , is_it_MPI_parallelized_linear_algebra;

using namespace string_routines;

// Only operations scaling like N^2 (matrix times vector) or N^3 (matrix times matrix) are parallelized at linear algebra level.

// Class describing a matrix, square or not
// ----------------------------------------
// SCALAR_TYPE must be double or complex.
// One cannot mix different scalar types in routines.
// Use convert or complex_matrix to go from one scalar type to an another.
// Use constructor or operator = to go from sparse_matrix to matrix class.

// Many temporaries are created in the binary operators +,-,*,/ ...
// Unless dimensions are small (100-200 or less typically) and routines are not often called (10,000 times or more typically),
// one should not use routines creating temporaries unless one is sure that it creates no time/memory lag, as in "const class matrix<double> A = B+C;" for example, or if it is clearly negligible.
// Indeed, the number of elements grows like the square of dimension, so that allocation/deallocation can be costly even with matrices of moderate dimension.
// On the contrary, array and vectors have a number of elements equal to dimension, so that the use of temporaries therein does not create efficiency issues in most cases.
// Binary operators have nevertheless been coded as they are very practical in small applications or to test codes, for example.
// In any case, it is always possible to avoid temporaries using operator =, +=, -=, *=, /=, matrix_multiplication, ...

template <typename SCALAR_TYPE>
class matrix
{
public:

  explicit matrix () :
    is_it_Cholesky_decomposed_local (false) ,
    determinant_phase (1) ,
    row_permutation (NULL) {}

  explicit matrix (const unsigned int dimension) :
    is_it_Cholesky_decomposed_local (false) ,
    determinant_phase (1) ,
    row_permutation (NULL)
  {
    allocate (dimension);
  }

  explicit matrix (const unsigned int dimension_row , const unsigned int dimension_column) :
    is_it_Cholesky_decomposed_local (false) ,
    determinant_phase (1) ,
    row_permutation (NULL)
  {
    allocate (dimension_row , dimension_column);
  }

  matrix (const class matrix<SCALAR_TYPE> &X) :
    is_it_Cholesky_decomposed_local (false) ,
    determinant_phase (1) ,
    row_permutation (NULL)
  {
    allocate_fill (X);
  }

  matrix (const class sparse_matrix<SCALAR_TYPE> &X) :
    is_it_Cholesky_decomposed_local (false) ,
    determinant_phase (1) ,
    row_permutation (NULL)
  {
    allocate_fill (X);
  }

  ~matrix () {}

  void allocate (const unsigned int dimension)
  {
    if (table.is_it_filled ()) error_message_print_abort ("A matrix cannot be allocated twice in matrix::allocate (1)");
    
    table.allocate (dimension);

    for (unsigned int i = 0 ; i < dimension ; i++) table(i).allocate (dimension);

    LU_Cholesky_data_reinitialize ();
  }

  void allocate (const unsigned int dimension_row , const unsigned int dimension_column)
  {
    if (table.is_it_filled ()) error_message_print_abort ("A matrix cannot be allocated twice in matrix::allocate (2)");

    table.allocate (dimension_row);

    for (unsigned int i = 0 ; i < dimension_row ; i++) table(i).allocate (dimension_column);
    
    LU_Cholesky_data_reinitialize ();
  }

  void allocate_fill (const class matrix &X)
  {
    if (table.is_it_filled ()) error_message_print_abort ("A matrix cannot be allocated twice in matrix::allocate_fill (1)");

    is_it_Cholesky_decomposed_local = X.is_it_Cholesky_decomposed_local;

    determinant_phase = X.determinant_phase;

    const unsigned int dimension_row = X.get_dimension_row ();
    
    table.allocate (dimension_row);

    for (unsigned int i = 0 ; i < dimension_row ; i++) table(i).allocate_fill (X.table(i));

    if (X.row_permutation != NULL)
      {
	row_permutation = new unsigned int [dimension_row];
	
	for (unsigned int i = 0 ; i < dimension_row ; i++) row_permutation[i] = X.row_permutation[i];
      }
  }

  void allocate_fill (const class sparse_matrix<SCALAR_TYPE> &X)
  {
    if (table.is_it_filled ()) error_message_print_abort ("A matrix cannot be allocated twice in matrix::allocate_fill (2)");

    const unsigned int dimension_row = X.get_dimension_row ();
    
    const unsigned int dimension_column = X.get_dimension_column ();
    
    table.allocate (dimension_row);

    for (unsigned int i = 0 ; i < dimension_row ; i++) table(i).allocate (dimension_column);

    class matrix<SCALAR_TYPE> &M = *this;
    
    M = 0.0;

    const unsigned int non_trivial_zeros_number = X.get_non_trivial_zeros_number ();
        
    for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
      {
	const unsigned int i = X.get_row_index (index);

	const unsigned int j = X.get_column_index (index);
	
	M(i , j) = X.get_matrix_element (index);
      }
    
    LU_Cholesky_data_reinitialize ();
  }

  void deallocate ()
  {
    const unsigned int dimension_row = get_dimension_row ();
    
    for (unsigned int i = 0 ; i < dimension_row ; i++) table(i).deallocate ();

    table.deallocate ();

    delete [] row_permutation;
        
    is_it_Cholesky_decomposed_local = false;
    
    determinant_phase = 1;

    row_permutation = NULL;
  }

  // matrix elements number of the matrix
  
  unsigned int get_matrix_elements_number () const
  {
    const unsigned int dimension_row = get_dimension_row ();
    
    const unsigned int dimension_column = get_dimension_column ();
    
    const unsigned int matrix_elements_number = dimension_row*dimension_column;
    
    return matrix_elements_number;
  }
  
  unsigned int get_dimension () const
  {
    const unsigned int dimension_row = get_dimension_row ();
    
    const unsigned int dimension_column = get_dimension_column ();
    
    if (dimension_row != dimension_column) error_message_print_abort ("get_dimension () is used with square matrices only.");
    
    return dimension_row;
  }

  unsigned int get_dimension_row () const
  {
    return table.dimension (0);
  }

  unsigned int get_dimension_column () const
  {
    if (table.dimension (0) == 0) return 0;
    
    return table(0).get_dimension ();
  }

  bool is_it_LU_decomposed () const
  {
    return (row_permutation != NULL);
  }

  bool is_it_Cholesky_decomposed () const
  {
    return is_it_Cholesky_decomposed_local;
  }

  bool is_it_filled () const
  {
    return (table.is_it_filled ());
  }
  
  class matrix& operator += (const class matrix &);
  class matrix& operator += (const class sparse_matrix<SCALAR_TYPE> &);
  class matrix& operator += (const SCALAR_TYPE &);

  class matrix& operator -= (const class matrix &);
  class matrix& operator -= (const class sparse_matrix<SCALAR_TYPE> &);
  class matrix& operator -= (const SCALAR_TYPE &);

  class matrix& operator *= (const SCALAR_TYPE &);
  class matrix& operator /= (const SCALAR_TYPE &);

  const class matrix& operator = (const class matrix &);
  const class matrix& operator = (const class sparse_matrix<SCALAR_TYPE> &);
  const class matrix& operator = (const SCALAR_TYPE &);

  SCALAR_TYPE & operator () (const unsigned int , const unsigned int) const;
  
  void diagonal_part (class array<SCALAR_TYPE> &) const;

  void put_scalar_diagonal_part (const SCALAR_TYPE &x);
  void add_scalar_diagonal_part (const SCALAR_TYPE &x);
  void remove_scalar_diagonal_part (const SCALAR_TYPE &x);
  void multiply_scalar_diagonal_part (const SCALAR_TYPE &x);
  void divide_scalar_diagonal_part (const SCALAR_TYPE &x);
  
  void put_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void add_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void remove_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T);
  void divide_array_diagonal_part (const class array<SCALAR_TYPE> &T);

  void identity ();
  void scalar (const SCALAR_TYPE &x);

  void symmetrize ();
  void antisymmetrize ();
  void hermitize ();
  void transpose ();
  void conjugate ();
  void dagger ();

  SCALAR_TYPE trace () const;
  
  double infinite_norm () const;
  
  SCALAR_TYPE Frobenius_squared_norm () const;
  
  SCALAR_TYPE Frobenius_norm () const;
  
  double Frobenius_squared_norm_hermitian () const;
  
  double Frobenius_norm_hermitian () const;
  
  unsigned int non_zeros_number_calc () const;

  double non_zeros_proportion () const;

  bool is_it_real () const;
  bool is_it_diagonal () const;
  bool is_it_symmetric () const;
  bool is_it_antisymmetric () const;
  bool is_it_hermitian () const;
  bool isfinite () const;

  class vector_class<SCALAR_TYPE> & eigenvector (const unsigned int i) const;
  class vector_class<SCALAR_TYPE> & row_vector (const unsigned int i) const;

  // The column vector is copied from the matrix to an output vector or is returned , as it is not part of the class. 

  class vector_class<SCALAR_TYPE> column_vector (const unsigned int j) const;
  
  void column_vector (const unsigned int j , class vector_class<SCALAR_TYPE> &V) const;

  void LU_decompose ();
  
  void Cholesky_decompose ();
  
  void LU_backsubstitute (const class vector_class<SCALAR_TYPE> &B , class vector_class<SCALAR_TYPE> &X) const;
  
  void Cholesky_backsubstitute (const class vector_class<SCALAR_TYPE> &B , class vector_class<SCALAR_TYPE> &X) const;
  
  void inverse ();
  
  SCALAR_TYPE determinant  ();

  SCALAR_TYPE min () const;
  SCALAR_TYPE max () const;
  
  SCALAR_TYPE sum () const;

  SCALAR_TYPE product () const;

  void log_scaled_determinant_and_phase (SCALAR_TYPE &log_Det_no_phase , int &phase);

  unsigned int first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const;
  unsigned int active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const;

  void random_matrix ();
  void pseudo_random_matrix ();
  void symmetric_random_matrix ();
  void symmetric_pseudo_random_matrix ();
  void antisymmetric_random_matrix ();
  void antisymmetric_pseudo_random_matrix ();
  void hermitian_random_matrix ();
  void hermitian_pseudo_random_matrix ();
  
  void put_zeros_with_probability (const double zeros_probability);
  void put_zeros_symmetrically_with_probability (const double zeros_probability);
  
  void assign (const class matrix<SCALAR_TYPE> &A);
  void reverse_vectors_order ();

  void tridiagonal (
		    const class array<SCALAR_TYPE> &lower_off_diagonal_tab ,
		    const class array<SCALAR_TYPE> &diagonal_tab ,  
		    const class array<SCALAR_TYPE> &upper_off_diagonal_tab);

  void tridiagonal (
		    const class array<SCALAR_TYPE> &off_diagonal_tab ,
		    const class array<SCALAR_TYPE> &diagonal_tab);

  void tridiagonal_hermitian (
			      const class array<SCALAR_TYPE> &off_diagonal_tab ,
			      const class array<SCALAR_TYPE> &diagonal_tab);
  
  void read_disk (const string &file_name);

  void copy_disk (const string &file_name) const;
  
#ifdef UseMPI
  void MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C);
  void MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C);

  void MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C);

  void MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C);

  void MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C);

  void MPI_Reduce    (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C);

  void MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C);
#endif 

  void LU_Cholesky_data_reinitialize ();
  
  void matrix_scaling (const class matrix<SCALAR_TYPE> &A);
  
  template <typename C>
  friend double used_memory_calc (const class matrix<C> &T);
    
private:
  
  // true if the matrix has been Cholesky decomposed , false if not.
  bool is_it_Cholesky_decomposed_local;

  // phase of the determinant of the matrix. It is (-1)^(number of row permutations) during LU decomposition.
  char determinant_phase;

  // components of the matrix.
  class array<class vector_class<SCALAR_TYPE> > table;

  // integers used in the LU decomposition and the linear system solver from the LU decomposed matrix.
  // It is allocated only in LU_decompose, as it is used only with LU decomposition.
  unsigned int * row_permutation;
};


// Reinitialize all data related to linear system solution so as one can reuse the matrix for LU/Cholesky decomposition
// --------------------------------------------------------------------------------------------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::LU_Cholesky_data_reinitialize ()
{
  is_it_Cholesky_decomposed_local = false;
  
  determinant_phase = 1;
  
  delete [] row_permutation;

  row_permutation = NULL;
}



template <typename SCALAR_TYPE>
void linear_system_solution_calc (class matrix<SCALAR_TYPE> &A , const class vector_class<SCALAR_TYPE> &B , class vector_class<SCALAR_TYPE> &X);

// "()" overloading.
// -----------------
// A(i , j) is returned as Ai(j) , with Ai a vector.

template <typename SCALAR_TYPE>
SCALAR_TYPE & matrix<SCALAR_TYPE>::operator () (const unsigned int i , const unsigned int j) const
{
  const class vector_class<SCALAR_TYPE> &Ai = row_vector (i);

  return Ai(j);
}


// "=" overloading.
// ----------------
template <typename SCALAR_TYPE>
const class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator = (const class matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
    
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator = (full)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator = (full)");
   
  is_it_Cholesky_decomposed_local = A.is_it_Cholesky_decomposed_local;

  determinant_phase = A.determinant_phase;

  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) = A.row_vector(i);
  
  if (A.row_permutation != NULL)
    {
      if (row_permutation == NULL) row_permutation = new unsigned int [dimension_row];
      
      for (unsigned int i = 0 ; i < dimension_row ; i++) row_permutation[i] = A.row_permutation[i];
    }
  else
    {
      delete [] row_permutation;
      
      row_permutation = NULL;
    }
    
  return *this;
}




// "=" overloading (from sparse matrix)
// ------------------------------------
template <typename SCALAR_TYPE>
const class matrix<SCALAR_TYPE> & matrix<SCALAR_TYPE>::operator = (const class sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator = (sparse)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator = (sparse)");
 
  LU_Cholesky_data_reinitialize ();
    
  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  const unsigned int non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
    
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = A.get_row_index (index);

      const unsigned int j = A.get_column_index (index);

      M(i , j) = A.get_matrix_element (index);
    }
  
  return *this;
}



// "=" overloading.
// ----------------
// All components are put equal to the same value.
// LU decomposition is put to false.

template <typename SCALAR_TYPE>
const class matrix<SCALAR_TYPE> & matrix<SCALAR_TYPE>::operator = (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  LU_Cholesky_data_reinitialize ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) = x;
    
  return *this;
}



// "+=" overloading.
// ----------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator += (const class matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
    
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator += (full , full)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator += (full , full)");  
  
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator += (full , full)");
    
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) += A.row_vector(i);

  return *this;
}


template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator += (const class sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator += (full , sparse)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator += (full , sparse)");  
  
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator += (full , sparse)");
    
  const unsigned int non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
    
  class matrix<SCALAR_TYPE> &M = *this;
    
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = A.get_row_index (index);

      const unsigned int j = A.get_column_index (index);

      M(i , j) += A.get_matrix_element (index);
    }
  
  return *this;
}





// "-=" overloading.
// ----------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator -= (const class matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator -= (full , full)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator -= (full , full)");  
  
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator -= (full , full)");
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) -= A.row_vector(i);

  return *this;
}



template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator -= (const class sparse_matrix<SCALAR_TYPE> &A)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != A.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator -= (full , sparse)");
  
  if (dimension_column != A.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator -= (full , sparse)");  
  
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator -= (full , sparse)");
 
  const unsigned int non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
    
  class matrix<SCALAR_TYPE> &M = *this;
    
  for (unsigned int index = 0 ; index < non_trivial_zeros_number ; index++)
    {
      const unsigned int i = A.get_row_index (index);

      const unsigned int j = A.get_column_index (index);

      M(i , j) -= A.get_matrix_element (index);
    }
  
  return *this;
}





// "+=" overloading : M plus SCALAR_TYPE
// ------------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator += (const SCALAR_TYPE &x)
{
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator += (scalar)");
  
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) += x; 

  return *this;
}


// "-=" overloading : M minus SCALAR_TYPE
// ------------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator -= (const SCALAR_TYPE &x)
{
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator -= (scalar)");
  
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) -= x;

  return *this;
}


// "*=" overloading : M times SCALAR_TYPE.
// ---------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator *= (const SCALAR_TYPE &x)
{
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator *= (scalar)");
  
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) *= x;

  return *this;  
}





// "/=" overloading: M over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE>& matrix<SCALAR_TYPE>::operator /= (const SCALAR_TYPE &x)
{
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in operator /= (scalar)");
  
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector(i) /= x;

  return *this;  
}


// Standard MPI routines (see MPI_helper)
// --------------------------------------


template <typename SCALAR_TYPE>
unsigned int matrix<SCALAR_TYPE>::first_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  return basic_first_index_determine_for_MPI (dimension_row*dimension_column , group_processes_number , process);
}

template <typename SCALAR_TYPE>
unsigned int matrix<SCALAR_TYPE>::last_index_determine_for_MPI (const unsigned int group_processes_number , const unsigned int process) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  return basic_last_index_determine_for_MPI (dimension_row*dimension_column , group_processes_number , process);
}

template <typename SCALAR_TYPE>
unsigned int matrix<SCALAR_TYPE>::active_process_determine_for_MPI (const unsigned int group_processes_number , const unsigned int index) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  return basic_active_process_determine_for_MPI (dimension_row*dimension_column , group_processes_number , index);
}



#ifdef UseMPI

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Send (const unsigned int Recv_process , const int tag , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  MPI_helper::Send<bool> (is_it_Cholesky_decomposed_local , Recv_process , tag , MPI_C);

  MPI_helper::Send<char> (determinant_phase , Recv_process , tag , MPI_C);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Send (Recv_process , tag , MPI_C);
    }

  if (row_permutation != NULL) MPI_helper::Send<unsigned int> (dimension_row , row_permutation , Recv_process , tag , MPI_C);
}



template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Recv (const unsigned int Send_process , const int tag , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  MPI_helper::Recv<bool> (is_it_Cholesky_decomposed_local , Send_process , tag , MPI_C);

  MPI_helper::Recv<char> (determinant_phase , Send_process , tag , MPI_C);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Recv (Send_process , tag , MPI_C);
    }

  if (row_permutation != NULL) MPI_helper::Recv<unsigned int> (dimension_row , row_permutation , Send_process , tag , MPI_C);
}





template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Sendrecv_replace (const unsigned int Send_process , const unsigned int Recv_process , const int Send_tag , const int Recv_tag , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  MPI_helper::Sendrecv_replace<bool> (is_it_Cholesky_decomposed_local , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);

  MPI_helper::Sendrecv_replace<char> (determinant_phase , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Sendrecv_replace (Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
    }

  if (row_permutation != NULL) MPI_helper::Sendrecv_replace<unsigned int> (dimension_row , row_permutation , Send_process , Recv_process , Send_tag , Recv_tag , MPI_C);
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Bcast (const unsigned int Send_process , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  MPI_helper::Bcast<bool> (is_it_Cholesky_decomposed_local , Send_process , MPI_C);

  MPI_helper::Bcast<char> (determinant_phase , Send_process , MPI_C);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Bcast (Send_process , MPI_C);
    }

  if (row_permutation != NULL) MPI_helper::Bcast<unsigned int> (dimension_row , row_permutation ,  Send_process , MPI_C);
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Reduce (MPI_Op op , const unsigned int Recv_process , const unsigned int process , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Reduce (op , Recv_process , process , MPI_C);
    }
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Allreduce (MPI_Op op , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Allreduce (op , MPI_C);
    }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::MPI_Allgatherv (const unsigned int group_processes_number , const MPI_Comm MPI_C)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.MPI_Allgatherv (group_processes_number , MPI_C);
    }
}

#endif



// "+" overloading.
// ----------------
template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator + (const class matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
    
  M += B;

  return M;
}


template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator + (const class matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M += B;

  return M;
}


template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator + (const class sparse_matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M += B;

  return M;
}


template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator + (const class matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M += x;

  return M;
}

template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator + (const SCALAR_TYPE &x , const class matrix<SCALAR_TYPE> &A) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M += x;

  return M;
}




// "-" overloading.
// ----------------  
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> operator - (const class matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M -= B;

  return M;
}

template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator - (const class matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M -= B;

  return M;
}


template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator - (const class sparse_matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M -= B;

  return M;
}




template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator - (const class matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x) 
{ 
  class matrix<SCALAR_TYPE> M = A;

  M -= x;

  return M;
}


template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator - (const SCALAR_TYPE &x , const class matrix<SCALAR_TYPE> &A) 
{
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = A.get_dimension_column ();

  class matrix<SCALAR_TYPE> M(Nr , Nc);

  M = x;
  
  M -= A;

  return M;
}





// "*" overloading : A times B.
// ----------------------------
// A matrix A of dimension Nr*N is multiplied by a matrix B of dimension N*Nc, providing with a matrix of dimension Nr*Nc.
// A*B is calculated as the concatenation of all scalar products A.row_vector (i) * B.column_vector (j).
// In order for scalar product to be the fastest, the column vectors of B are copied to a temporary vector.
// Thus, the indices of A.row_vector (i) and B.column_vector (j) are contiguous and that no lengthy search inside matrices occurs.
// As a matrix is an array of vectors, the operation A.row_vector (i) * B.column_vector (j) is quick to calculate.
// The cost of copying B to temporary vectors is negligible, as it is linear in Nc, whereas the matrix product costs Nr*N*Nc multiplications.
//
// A routine without creation of a returned temporary matrix can be used as well.
//
// A and B can be sparse matrices as well. The result is always a full matrix.
// Sparse times sparse might be slow due to the many comparisons occurring there. 
// If sparsity is not small (i.e. ~ N^{3/2} or more), it can be more efficient to store one sparse matrix in a full matrix.


template <typename SCALAR_TYPE> 
class matrix<SCALAR_TYPE> operator * (const class matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{  
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();
  
  class matrix<SCALAR_TYPE> M(Nr , Nc);

  matrix_multiplication (A , B , M);

  return M;
}


template <typename SCALAR_TYPE> 
class matrix<SCALAR_TYPE> operator * (const class sparse_matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B) 
{  
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();
  
  class matrix<SCALAR_TYPE> M(Nr , Nc);

  matrix_multiplication (A , B , M);

  return M;
}


template <typename SCALAR_TYPE> 
class matrix<SCALAR_TYPE> operator * (const class matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{  
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();
  
  class matrix<SCALAR_TYPE> M(Nr , Nc);

  matrix_multiplication (A , B , M);

  return M;
}



template <typename SCALAR_TYPE> 
class matrix<SCALAR_TYPE> operator * (const class sparse_matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B) 
{   
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();
  
  class matrix<SCALAR_TYPE> M(Nr , Nc);

  matrix_multiplication (A , B , M);

  return M;
}



template <typename SCALAR_TYPE> 
void matrix_multiplication (
			    const class matrix<SCALAR_TYPE> &A ,
			    const class matrix<SCALAR_TYPE> &B ,
			    class matrix<SCALAR_TYPE> &M)
{  
  if (A.get_dimension_column () != B.get_dimension_row ()) error_message_print_abort ("Column dimension of A and row dimension of B must be equal for matrix multiplication (A full , B full)");
  
  if (M.get_dimension_row () != A.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and M must be equal for matrix multiplication (A full , B full)");
  
  if (M.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of B and M must be equal for matrix multiplication (A full , B full)");
  
  const unsigned int N_common = A.get_dimension_column ();
 
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();

  const unsigned int i_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (Nr , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int i_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (Nr , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (Nr - 1);
		
  const bool is_i_end_smaller_than_Nr = (i_end < Nr);

  M.LU_Cholesky_data_reinitialize ();
  
  M = 0.0;

  if (is_i_end_smaller_than_Nr)
    {
      class array<class vector_class<SCALAR_TYPE> > Bj_array(NUMBER_OF_THREADS);

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Bj_array(i_thread).allocate (N_common);
      
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int j = 0 ; j < Nc ; j++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	    
	  class vector_class<SCALAR_TYPE> &Bj = Bj_array(i_thread);
	  
	  B.column_vector (j , Bj);
  
	  for (unsigned int i = i_debut ; i <= i_end ; i++) 
	    {
	      const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	      
	      M(i , j) = Ai*Bj;
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) M.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
}



template <typename SCALAR_TYPE> 
void matrix_multiplication (
			    const class sparse_matrix<SCALAR_TYPE> &A ,
			    const class matrix<SCALAR_TYPE> &B ,
			    class matrix<SCALAR_TYPE> &M)
{  
  if (A.get_dimension_column () != B.get_dimension_row ()) error_message_print_abort ("Column dimension of A[sparse] and row dimension of B must be equal for matrix multiplication (A sparse, B full)");

  if (M.get_dimension_row () != A.get_dimension_row ()) error_message_print_abort ("Row dimensions of A[sparse] and M must be equal for matrix multiplication (A sparse, B full)");
  
  if (M.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of B and M must be equal for matrix multiplication (A sparse, B full)");
  
  M.LU_Cholesky_data_reinitialize ();
    
  M = 0.0;
  
  const unsigned int N_common = A.get_dimension_column ();
 
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = B.get_dimension_column ();

  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();

  if (A_non_trivial_zeros_number == 0) return;
  
  const unsigned int A_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int A_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (A_non_trivial_zeros_number - 1);
		
  const bool is_A_index_end_smaller_than_A_non_trivial_zeros_number = (A_index_end < A_non_trivial_zeros_number);
  
  if (is_A_index_end_smaller_than_A_non_trivial_zeros_number)
    {
      class array<class vector_class<SCALAR_TYPE> >   Bj_array(NUMBER_OF_THREADS);
      class array<class vector_class<SCALAR_TYPE> > MT_j_array(NUMBER_OF_THREADS);

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++)
	{
	  Bj_array(i_thread).allocate (N_common);
	  
	  MT_j_array(i_thread).allocate (Nr);
	}
      
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int j = 0 ; j < Nc ; j++)
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();
	    
	  class vector_class<SCALAR_TYPE> &Bj = Bj_array(i_thread);
	  
	  class vector_class<SCALAR_TYPE> &MT_j = MT_j_array(i_thread);
	  
	  B.column_vector (j , Bj);

	  MT_j = 0.0;
	  
	  for (unsigned int A_index = A_index_debut ; A_index <= A_index_end ; A_index++)
	    {
	      const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	      const unsigned int i = A.get_row_index (A_index);
	      
	      const unsigned int k = A.get_column_index (A_index);
	            
	      MT_j(i) += Aik*Bj(k);
	    }

	  for (unsigned int i = 0 ; i < Nr ; i++) M(i , j) = MT_j(i);
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) M.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
}






template <typename SCALAR_TYPE> 
void matrix_multiplication (
			    const class matrix<SCALAR_TYPE> &A ,
			    const class sparse_matrix<SCALAR_TYPE> &B ,
			    class matrix<SCALAR_TYPE> &M)
{  
  if (A.get_dimension_column () != B.get_dimension_row ()) error_message_print_abort ("Column dimension of A and row dimension of B[sparse] must be equal for matrix multiplication (A full , B sparse)");

  if (M.get_dimension_row () != A.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and M must be equal for matrix multiplication (A full , B sparse)");
  
  if (M.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of B[sparse] and M must be equal for matrix multiplication (A full , B sparse)");
     
  M.LU_Cholesky_data_reinitialize ();
  
  M = 0.0;
  
  const unsigned int Nr = A.get_dimension_row ();

  const unsigned int B_non_trivial_zeros_number = B.get_non_trivial_zeros_number ();
  
  if (B_non_trivial_zeros_number == 0) return;
  
  const unsigned int B_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int B_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (B_non_trivial_zeros_number - 1);
		
  const bool is_B_index_end_smaller_than_B_non_trivial_zeros_number = (B_index_end < B_non_trivial_zeros_number);
    	  	  
  if (is_B_index_end_smaller_than_B_non_trivial_zeros_number)
    {      
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int i = 0 ; i < Nr ; i++)
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	  
	  class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);
	  
	  for (unsigned int B_index = B_index_debut ; B_index <= B_index_end ; B_index++)
	    {
	      const SCALAR_TYPE &Bkj = B.get_matrix_element (B_index);
	      
	      const unsigned int k = B.get_row_index (B_index);
	      
	      const unsigned int j = B.get_column_index (B_index);
	            
	      Mi(j) += Ai(k)*Bkj;
	    }	     
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) M.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
}





template <typename SCALAR_TYPE> 
void matrix_multiplication (
			    const class sparse_matrix<SCALAR_TYPE> &A ,
			    const class sparse_matrix<SCALAR_TYPE> &B ,
			    class matrix<SCALAR_TYPE> &M)
{  
  if (A.get_dimension_column () != B.get_dimension_row ()) error_message_print_abort ("Column dimension of A[sparse] and row dimension of B[sparse] must be equal for matrix multiplication (A sparse , B sparse)");
 
  if (M.get_dimension_row () != A.get_dimension_row ()) error_message_print_abort ("Row dimensions of A[sparse] and M must be equal for matrix multiplication (A sparse , B sparse)");
  
  if (M.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of B[sparse] and M must be equal for matrix multiplication (A sparse , B sparse)");
    
  M.LU_Cholesky_data_reinitialize ();
  
  M = 0.0;
  
  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();
  const unsigned int B_non_trivial_zeros_number = B.get_non_trivial_zeros_number ();
  
  if ((A_non_trivial_zeros_number == 0) || (B_non_trivial_zeros_number == 0)) return;

  const unsigned int B_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int B_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (B_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (B_non_trivial_zeros_number - 1);
		
  const bool is_B_index_end_smaller_than_B_non_trivial_zeros_number = (B_index_end < B_non_trivial_zeros_number);
      
  if (is_B_index_end_smaller_than_B_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int A_index = 0 ; A_index < A_non_trivial_zeros_number ; A_index++)
	{
	  const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	  const unsigned int i = A.get_row_index (A_index);
	      
	  const unsigned int k = A.get_column_index (A_index);

	  class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);
	  
	  for (unsigned int B_index = B_index_debut ; B_index <= B_index_end ; B_index++)
	    {
	      if (B.get_row_index (B_index) == k)
		{
		  const SCALAR_TYPE &Bkj = B.get_matrix_element (B_index);
		      
		  const unsigned int j = B.get_column_index (B_index);
		  
#ifdef UseOpenMP    
#pragma omp critical
#endif
		  Mi(j) += Aik*Bkj;
		}
	    }
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) M.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
}



// Frobenius scalar_product Tr (A A^T) or Tr (A A^\dagger) (hermitian)


template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product (
				      const class matrix<SCALAR_TYPE> &A ,
				      const class matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Frobenius scalar product (A full , B full)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A and B must be equal for Frobenius scalar product (A full , B full)");  
    
  const unsigned int Nr = A.get_dimension_row ();
  
  const unsigned int Nc = A.get_dimension_column ();

  const unsigned int k_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (Nc , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int k_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (Nc , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (Nc - 1);
		
  const bool is_k_end_smaller_than_Nc = (k_end < Nc);

  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;

  if (is_k_end_smaller_than_Nc)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int i = 0 ; i < Nr ; i++) 
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	  const class vector_class<SCALAR_TYPE> &Bi = B.row_vector (i);

	  SCALAR_TYPE Ai_Bi = 0.0;
	  
	  for (unsigned int k = k_debut ; k <= k_end ; k++) Ai_Bi += Ai(k)*Bi(k);
  
	  Re_scalar_product += real_dc (Ai_Bi);
	  Im_scalar_product += imag_dc (Ai_Bi);
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif

  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);
  
  return scalar_product;
}






template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product (
				      const class sparse_matrix<SCALAR_TYPE> &A ,
				      const class matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Frobenius scalar product (A sparse , B full)");
      
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A[sparse] B must be equal for Frobenius scalar product (A sparse, B full)");
  
  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();

  if (A_non_trivial_zeros_number == 0) return 0.0;

  const unsigned int Nc = B.get_dimension_column ();

  if (Nc == 0) return 0.0;
 
  const unsigned int A_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int A_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (A_non_trivial_zeros_number - 1);
		
  const bool is_A_index_end_smaller_than_A_non_trivial_zeros_number = (A_index_end < A_non_trivial_zeros_number);
  
  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;
  
  if (is_A_index_end_smaller_than_A_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int A_index = A_index_debut ; A_index <= A_index_end ; A_index++)
	{
	  const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	  const unsigned int i = A.get_row_index (A_index);
	      
	  const unsigned int k = A.get_column_index (A_index);
	  	  
	  const SCALAR_TYPE Aik_Bik = Aik*B(i , k);
	  
	  Re_scalar_product += real_dc (Aik_Bik);
	  Im_scalar_product += imag_dc (Aik_Bik);	
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif

  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);

  return scalar_product;
}






template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product (
				      const class matrix<SCALAR_TYPE> &A ,
				      const class sparse_matrix<SCALAR_TYPE> &B)
{
  return Frobenius_scalar_product (B , A);
}





template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product_hermitian (
						const class matrix<SCALAR_TYPE> &A ,
						const class matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Hermitian Frobenius scalar product (A full , B full)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A and B must be equal for Hermitian Frobenius scalar product (A full , B full)");
    
  const unsigned int Nr = A.get_dimension_row ();
  
  const unsigned int Nc = A.get_dimension_column ();

  const unsigned int k_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (Nc , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int k_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (Nc , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (Nc - 1);
		
  const bool is_k_end_smaller_than_Nc = (k_end < Nc);

  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;

  if (is_k_end_smaller_than_Nc)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int i = 0 ; i < Nr ; i++) 
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	  const class vector_class<SCALAR_TYPE> &Bi = B.row_vector (i);

	  SCALAR_TYPE Ai_Bi = 0.0;
	  
	  for (unsigned int k = k_debut ; k <= k_end ; k++) Ai_Bi += Ai(k)*conj (Bi(k));
  
	  Re_scalar_product += real_dc (Ai_Bi);
	  Im_scalar_product += imag_dc (Ai_Bi);
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif

  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);
  
  return scalar_product;
}






template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product_hermitian (
						const class sparse_matrix<SCALAR_TYPE> &A ,
						const class matrix<SCALAR_TYPE> &B)
{  
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions of A and B must be equal for Hermitian Frobenius scalar product (A sparse , B full)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions of A and B must be equal for Hermitian Frobenius scalar product (A sparse , B full)");
      
  const unsigned int A_non_trivial_zeros_number = A.get_non_trivial_zeros_number ();

  if (A_non_trivial_zeros_number == 0) return 0.0;
  
  const unsigned int A_index_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int A_index_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (A_non_trivial_zeros_number , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (A_non_trivial_zeros_number - 1);
		
  const bool is_A_index_end_smaller_than_A_non_trivial_zeros_number = (A_index_end < A_non_trivial_zeros_number);
  
  double Re_scalar_product = 0.0;
  double Im_scalar_product = 0.0;
  
  if (is_A_index_end_smaller_than_A_non_trivial_zeros_number)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_scalar_product,Im_scalar_product)
#endif
      for (unsigned int A_index = A_index_debut ; A_index <= A_index_end ; A_index++)
	{
	  const SCALAR_TYPE &Aik = A.get_matrix_element (A_index);
	      
	  const unsigned int i = A.get_row_index (A_index);
	      
	  const unsigned int k = A.get_column_index (A_index);
	  	  
	  const SCALAR_TYPE Aik_Bik = Aik*conj (B(i , k));
	  
	  Re_scalar_product += real_dc (Aik_Bik);
	  Im_scalar_product += imag_dc (Aik_Bik);	
	}
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_scalar_product , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_scalar_product , MPI_SUM , MPI_COMM_WORLD);
#endif

  const SCALAR_TYPE scalar_product = generate_scalar<SCALAR_TYPE> (Re_scalar_product , Im_scalar_product);

  return scalar_product;
}






template <typename SCALAR_TYPE> 
SCALAR_TYPE Frobenius_scalar_product_hermitian (
						const class matrix<SCALAR_TYPE> &A ,
						const class sparse_matrix<SCALAR_TYPE> &B)
{
  return conj (Frobenius_scalar_product_hermitian (B , A));
}







// "*" overloading : A times SCALAR_TYPE.
// --------------------------------------
template <typename SCALAR_TYPE>  
class matrix<SCALAR_TYPE> operator * (const class matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x)
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M *= x;

  return M;
}




// "*" overloading : SCALAR_TYPE times A.
// --------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> operator * (const SCALAR_TYPE &x , const class matrix<SCALAR_TYPE> &A) 
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M *= x;

  return M;
}






// "/" overloading : A over SCALAR_TYPE.
// -------------------------------------
template <typename SCALAR_TYPE> 
class matrix<SCALAR_TYPE> operator / (const class matrix<SCALAR_TYPE> &A , const SCALAR_TYPE &x) 
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
    
  M /= x;

  return M;
}






// scalar_productace of the matrix
// -------------------
template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::trace () const
{	
  const class matrix<SCALAR_TYPE> &A = *this;
  
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("trace member function is used with square matrices only");

  SCALAR_TYPE trace_value = 0.0;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) trace_value += A(i , i);
  
  return trace_value;
}








// Frobenius squared norm: scalar_product(A A^T) or scalar_product (A A^\dagger) (hermitian)

template <typename SCALAR_TYPE> 
SCALAR_TYPE matrix<SCALAR_TYPE>::Frobenius_squared_norm () const
{
  const class matrix<SCALAR_TYPE> &A = *this;
  
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("Row and column dimension of A must be equal for Frobenius squared norm");
    
  const unsigned int N = A.get_dimension_row ();

  const unsigned int k_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int k_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (N , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (N - 1);
		
  const bool is_k_end_smaller_than_N = (k_end < N);

  double Re_Frobenius_squared_norm = 0.0;
  double Im_Frobenius_squared_norm = 0.0;

  if (is_k_end_smaller_than_N)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Re_Frobenius_squared_norm,Im_Frobenius_squared_norm)
#endif
      for (unsigned int i = 0 ; i < N ; i++) 
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  SCALAR_TYPE Ai_squared_norm = 0.0;
	  
	  for (unsigned int k = k_debut ; k <= k_end ; k++)
	    {	      
	      const SCALAR_TYPE Aik = Ai(k);

	      Ai_squared_norm += Aik*Aik;
	    }
	  
	  Re_Frobenius_squared_norm += real_dc (Ai_squared_norm);
	  Im_Frobenius_squared_norm += imag_dc (Ai_squared_norm);
	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Re_Frobenius_squared_norm , MPI_SUM , MPI_COMM_WORLD);
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Im_Frobenius_squared_norm , MPI_SUM , MPI_COMM_WORLD);
#endif
  
  const SCALAR_TYPE Frobenius_squared_norm_value = generate_scalar<SCALAR_TYPE> (Re_Frobenius_squared_norm , Im_Frobenius_squared_norm);
        
  return Frobenius_squared_norm_value;
}



template <typename SCALAR_TYPE> 
SCALAR_TYPE matrix<SCALAR_TYPE>::Frobenius_norm () const
{
  const SCALAR_TYPE Frobenius_squared_norm_value = Frobenius_squared_norm ();
    
  const SCALAR_TYPE Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}





template <typename SCALAR_TYPE> 
double matrix<SCALAR_TYPE>::Frobenius_squared_norm_hermitian () const
{
  const class matrix<SCALAR_TYPE> &A = *this;
  
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("Row and column dimension of A must be equal for Hermitian Frobenius squared norm");
      
  const unsigned int N = A.get_dimension_row ();
  
  const unsigned int k_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (N , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int k_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (N , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (N - 1);
		
  const bool is_k_end_smaller_than_N = (k_end < N);

  double Frobenius_squared_norm_value = 0.0;

  if (is_k_end_smaller_than_N)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra) reduction (+:Frobenius_squared_norm_value)
#endif
      for (unsigned int i = 0 ; i < N ; i++) 
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	  
	  for (unsigned int k = k_debut ; k <= k_end ; k++) Frobenius_squared_norm_value += norm (Ai(k));
  	}
    }

#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) MPI_helper::Allreduce (Frobenius_squared_norm_value , MPI_SUM , MPI_COMM_WORLD);
#endif
      
  return Frobenius_squared_norm_value;
}




template <typename SCALAR_TYPE> 
double matrix<SCALAR_TYPE>::Frobenius_norm_hermitian () const
{
  const double Frobenius_squared_norm_value = Frobenius_squared_norm_hermitian ();
    
  const double Frobenius_norm_value = sqrt (Frobenius_squared_norm_value);
      
  return Frobenius_norm_value;  
}









// Infinite norm.
// --------------
// It is the largest component |M(i , j)|oo , with i.j in [0:M.dimension-1]^2.
// Note that infinite_norm is usually denoted as the max norm in the litterature.
// One should then pay attention that it is not submultiplicative, i.e. that one does not have in general AB.infinite_norm () <= A.infinite_norm () . B.infinite_norm (), with AB = A.B .

template <typename SCALAR_TYPE>
double matrix<SCALAR_TYPE>::infinite_norm () const 
{  
  const unsigned int dimension_row = get_dimension_row ();
  
  double norm = 0.0;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = row_vector (i);

      const double inf_norm_Mi = Mi.infinite_norm ();

      if (!finite (inf_norm_Mi)) return inf_norm_Mi;

      if (norm < inf_norm_Mi) norm = inf_norm_Mi;
    }

  return norm;
}


// Number of non zero matrix elements
// ----------------------------------
template <typename SCALAR_TYPE>
unsigned int matrix<SCALAR_TYPE>::non_zeros_number_calc () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  const class matrix<SCALAR_TYPE> &M = *this;

  unsigned int non_zeros_number = 0;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);

      for (unsigned int j = 0 ; j < dimension_column; j++)
	{
	  if (Mi(j) != 0) non_zeros_number++;
	}
    }

  return non_zeros_number;
}



// Proportion of non zero matrix elements in per cent.
// ---------------------------------------------------
template <typename SCALAR_TYPE>
double matrix<SCALAR_TYPE>::non_zeros_proportion () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  const class matrix<SCALAR_TYPE> &M = *this;

  double proportion = 0;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);

      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  if (Mi(j) != 0) proportion += 100.0;
	}
    }

  proportion /= dimension_row*dimension_column;

  return proportion;
}


// Check if M is a real matrix
// ---------------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::is_it_real () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);

      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  if (imag_dc (Mi(j)) != 0) return false;
	}
    }

  return true;
}

// Check if M is diagonal
// ----------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::is_it_diagonal () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("is_it_diagonal function is used with square matrices only");

  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);

      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  if ((i != j) && (Mi(j) != 0)) return false;
	}
    }

  return true;
}

// Check if M is symmetric
// -----------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::is_it_symmetric () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("is_it_symmetric function is used with square matrices only");

  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j < i ; j++)
      {
	if (M(i , j) != M(j , i)) return false;
      }

  return true;
}



// Check if M is symmetric
// -----------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::is_it_antisymmetric () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("is_it_symmetric function is used with square matrices only");

  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j <= i ; j++)
      {
	if (M(i , j) != -M(j , i)) return false;
      }

  return true;
}




// Check if M is hermitian
// -----------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::is_it_hermitian () const 
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("is_it_hermitian function is used with square matrices only");

  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j <= i ; j++)
      {
	if (M(i , j) != conj_dc (M(j , i))) return false;
      }

  return true;
}






// Check if M is finite
// ---------------------
template <typename SCALAR_TYPE>
bool matrix<SCALAR_TYPE>::isfinite () const 
{
  const unsigned int dimension_row = get_dimension_row ();
  
  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);

      if (!Mi.isfinite ()) return false;
    }

  return true;
}


// Returns the diagonal of the matrix as an array
// ----------------------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::diagonal_part (class array<SCALAR_TYPE> &diagonal_array) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("diagonal_part for square matrices only");
  
  const class matrix<SCALAR_TYPE> &A = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++) diagonal_array(i) = A(i , i);
}


// put a scalar to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::put_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("put a scalar to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) = x;
}

// add a scalar to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::add_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("add a scalar to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) += x;
}


// remove a scalar from the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::remove_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("remove a scalar to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) -= x;
}


// multiply a scalar to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::multiply_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("multiply a scalar to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) *= x;
}


// divide the diagonal by a scalar
// -------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::divide_scalar_diagonal_part (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("divide the diagonal_part by a scalar for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) /= x;
}





// put an array to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::put_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("put an array to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) = T(i);
}

// add an array to the diagonal
// ----------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::add_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("add an array to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) += T(i);
}


// remove an array from the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::remove_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("remove an array to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) -= T(i);
}


// multiply an array to the diagonal
// ---------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::multiply_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("multiply an array to diagonal_part for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) *= T(i);
}


// divide the diagonal by an array
// ---------------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::divide_array_diagonal_part (const class array<SCALAR_TYPE> &T)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("divide the diagonal_part by an array for square matrices only");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) A(i , i) /= T(i);
}






// Identity initialization.
// ------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::identity ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("identity member function is used with square matrices only");
 
  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  M.put_scalar_diagonal_part (1.0);
}

template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> identity (const unsigned int N)
{
  class matrix<SCALAR_TYPE> M(N);

  M.identity ();

  return M;
}



// Scalar initialization.
// ------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::scalar (const SCALAR_TYPE &x)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("scalar member function is used with square matrices only");

  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  M.put_scalar_diagonal_part (x);
}

template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> scalar (const unsigned int N , const SCALAR_TYPE &x)
{
  class matrix<SCALAR_TYPE> M(N);

  M.scalar (x);

  return M;
}



// Unary +
// -------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> operator + (const class matrix<SCALAR_TYPE> &A)
{
  return A;
}

// Unary -
// -------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> operator - (const class matrix<SCALAR_TYPE> &A)
{
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = A.get_dimension_column ();
  
  class matrix<SCALAR_TYPE> M(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
      
      class vector_class<SCALAR_TYPE> &Mi = M.row_vector (i);
      
      for (unsigned int j = 0 ; j < Nc ; j++) Mi(j) = -Ai(j);
    }

  return M;
}




// Matrix symmetrization
// ---------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::symmetrize ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("symmetrize member function is used with square matrices only");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in symmetrize (member)");
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j < i ; j++)
      {
	SCALAR_TYPE &Mij = M(i , j);
	SCALAR_TYPE &Mji = M(j , i);

	const SCALAR_TYPE new_ME = 0.5*(Mij + Mji);

	Mij = Mji = new_ME;
      }
}



// Matrix antisymmetrization
// ---------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::antisymmetrize ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("antisymmetrize member function is used with square matrices only");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in antisymmetrize (member)");
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      M(i , i) = 0.0;
      
      for (unsigned int j = 0 ; j < i ; j++)
	{
	  SCALAR_TYPE &Mij = M(i , j);
	  SCALAR_TYPE &Mji = M(j , i);

	  const SCALAR_TYPE new_ME = 0.5*(Mij - Mji);

	  Mij =  new_ME;
	  Mji = -new_ME;
	}
    }
}


// Matrix hermitization
// --------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::hermitize ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("hermitize member function is used with square matrices only");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in hermitize (member)");
  
  class matrix<SCALAR_TYPE> &M = *this;
    
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      M(i , i) = real_dc (M(i , i));
      
      for (unsigned int j = 0 ; j < i ; j++)
	{
	  SCALAR_TYPE &Mij = M(i , j);
	  SCALAR_TYPE &Mji = M(j , i);

	  const SCALAR_TYPE new_Mij = 0.5*(Mij + conj_dc (Mji));

	  Mij = new_Mij;	
	  Mji = conj_dc (Mij);
	}
    }
}


// Matrix transpose.
// -----------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::transpose ()
{	
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("transpose member function is used with square matrices only. Use external transpose function for non square matrices");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in transpose (member)");
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j < i ; j++)
      {
	SCALAR_TYPE &Mij = M(i , j);
	SCALAR_TYPE &Mji = M(j , i);

	const SCALAR_TYPE temp = Mij;

	Mij = Mji;

	Mji = temp;
      }
}






// Matrix conjugate.
// -----------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::conjugate ()
{
  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in conjugate (member)");
  
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) row_vector (i) = conj (row_vector (i));
}






// Matrix hermitian conjugate.
// --------------------------
template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::dagger ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("dagger member function is used with square matrices only. Use external dagger function for non square matrices");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in dagger (member)");
  
  transpose ();
  conjugate ();
}




// Matrix transpose returned.
// --------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> transpose (const class matrix<SCALAR_TYPE> &A)
{	
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = A.get_dimension_column ();

  class matrix<SCALAR_TYPE> M(Nc , Nr);
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    for (unsigned int j = 0 ; j < Nc ; j++)
      M(j , i) = A(i , j);
  
  return M;
}






// Matrix conjugate returned.
// --------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> conj (const class matrix<SCALAR_TYPE> &A)
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M.conjugate ();

  return M;
}


// Matrix hermitian conjugate returned.
// ------------------------------------
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> dagger (const class matrix<SCALAR_TYPE> &A)
{
  class matrix<SCALAR_TYPE> M = transpose (A);
  
  M.LU_Cholesky_data_reinitialize ();
  
  M.conjugate ();
  
  return M;
}



// Matrix real part returned
// -------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class matrix<SCALAR_TYPE> real (const class matrix<COMPLEX_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();
  const unsigned int Nc = M.get_dimension_column ();

  class matrix<SCALAR_TYPE> Re_M(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++) Re_M.row_vector (i) = real<SCALAR_TYPE , COMPLEX_TYPE> (M.row_vector (i));

  return Re_M;
}


// Matrix imaginary part returned
// ------------------------------
template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class matrix<SCALAR_TYPE> imag (const class matrix<COMPLEX_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();
  const unsigned int Nc = M.get_dimension_column ();

  class matrix<SCALAR_TYPE> Im_M(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++) Im_M.row_vector (i) = imag<SCALAR_TYPE , COMPLEX_TYPE> (M.row_vector (i));

  return Im_M;
}



// Conversion of one scalar type to another
// ----------------------------------------
template <typename IN_SCALAR_TYPE , typename OUT_SCALAR_TYPE>
class matrix<OUT_SCALAR_TYPE> convert (const class matrix<IN_SCALAR_TYPE> &M_in)
{
  const unsigned int Nr = M_in.get_dimension_row ();
  const unsigned int Nc = M_in.get_dimension_column ();

  class matrix<OUT_SCALAR_TYPE> M_out(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++) M_out.row_vector (i) = convert<IN_SCALAR_TYPE , OUT_SCALAR_TYPE> (M_in.row_vector (i));

  return M_out;
}



// Complex matrix returned from real and/or imaginary parts
// --------------------------------------------------------

template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class matrix<COMPLEX_TYPE> complex_matrix (const class matrix<SCALAR_TYPE> &Re_M)
{	
  const unsigned int Nr = Re_M.get_dimension_row ();
  const unsigned int Nc = Re_M.get_dimension_column ();

  class matrix<COMPLEX_TYPE> M(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++) M.row_vector (i) = complex_vector<SCALAR_TYPE , COMPLEX_TYPE> (Re_M.row_vector (i));

  return M;
}






template <typename SCALAR_TYPE , typename COMPLEX_TYPE>
class matrix<COMPLEX_TYPE> complex_matrix (const class matrix<SCALAR_TYPE> &Re_M , const class matrix<SCALAR_TYPE> &Im_M)
{	
  const unsigned int Nr = Re_M.get_dimension_row ();
  const unsigned int Nc = Re_M.get_dimension_column ();

  class matrix<COMPLEX_TYPE> M(Nr , Nc);

  for (unsigned int i = 0 ; i < Nr ; i++) M.row_vector (i) = complex_vector<SCALAR_TYPE , COMPLEX_TYPE> (Re_M.row_vector (i) , Im_M.row_vector (i));

  return M;
}












// Eigenvector of the matrix.
// --------------------------
// It is meaningful only if the matrix has been diagonalized.

template <typename SCALAR_TYPE> 
class vector_class<SCALAR_TYPE> & matrix<SCALAR_TYPE>::eigenvector (const unsigned int i) const
{	
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("eigenvector function is used with square matrices only");

  if (is_it_LU_decomposed () || is_it_Cholesky_decomposed_local) error_message_print_abort ("Output matrix cannot be LU/Cholesky decomposed in eigenvector");
  
  return row_vector(i);
}



// Row vector of the matrix.
// --------------------------

template <typename SCALAR_TYPE> 
class vector_class<SCALAR_TYPE> & matrix<SCALAR_TYPE>::row_vector (const unsigned int i) const
{
  return table(i);
}





// Column vector of the matrix.
// ----------------------------
// Note that it is not a reference on an object, but a created vector or an output vector to which part of the matrix is copied.

template <typename SCALAR_TYPE> 
void matrix<SCALAR_TYPE>::column_vector (
					 const unsigned int j ,
					 class vector_class<SCALAR_TYPE> &V) const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  const class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++) V(i) = M(i , j);
}




template <typename SCALAR_TYPE> 
class vector_class<SCALAR_TYPE> matrix<SCALAR_TYPE>::column_vector (const unsigned int j) const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  class vector_class<SCALAR_TYPE> V(dimension_row);

  column_vector (j , V);
  
  return V;
}







// V=AX.
// -----
template <typename SCALAR_TYPE>
class vector_class<SCALAR_TYPE> operator * (const class matrix<SCALAR_TYPE> &A , const class vector_class<SCALAR_TYPE> &X)
{  
  if (A.get_dimension_column () != X.get_dimension ()) error_message_print_abort ("Column dimension of A and dimension of X must be equal for matrix-vector multiplication");
  
  const unsigned int Nr = A.get_dimension_row ();

  const unsigned int i_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (Nr , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int i_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (Nr , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (Nr - 1);

  class vector_class<SCALAR_TYPE> V(Nr);

  V = 0.0;
  
  if (i_end < Nr)
    {
#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int i = i_debut ; i <= i_end ; i++) V(i) = A.row_vector(i)*X;
    }
 
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) V.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);
#endif
  
  return V;
}




//  M << print overload.
// ---------------------
template <typename SCALAR_TYPE>
ostream & operator << (ostream &os , const class matrix<SCALAR_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();

  for (unsigned int i = 0 ; i < Nr ; i++) os << M.row_vector(i) << endl;

  return os;
}




//  M >> get overload.
// -------------------
template <typename SCALAR_TYPE>
istream & operator >> (istream &is , class matrix<SCALAR_TYPE> &M)
{
  const unsigned int Nr = M.get_dimension_row ();

  for (unsigned int i = 0 ; i < Nr ; i++) is >> M.row_vector(i);

  return is;
}









// LU decomposition
// ----------------
// LU decomposition is not done for diagonal matrices as it is useless there.
// One can LU decompose a tridiagonal matrix, even though the Thomas algorithm can be used instead (see matrices_add.hpp).
// A = LU, where L is lower has only 1's on its diagonal and U is upper.
// L besides its diagonal and U are stored in A.
// One first normalizes the matrix with respect to A_infinite_norm, which cannot be zero, as otherwise A is diagonal.
// It is always more stable to use a matrix whose elements are equal to one or smaller in infinite norm.
// Then, one use Crout's algorithm with implicit pivoting.
// It is my implementation, so that there are no copyright issues.
//
// The implicit pivots are set to the inverse of the infinite norms of the rows of the matrices.
// One then obtains A/||A||oo = LU.
// Thus, one demands U -> U .||A||oo to have A = LU. L cannot change as it has 1's on its diagonal,
// As L and U are used independently during backsubstitution, this cannot lead to instabilities.
// Cost is about N^3/3.

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::LU_decompose ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row <= 2) error_message_print_abort ("Dimension >= 3 for LU decomposition");

  if (dimension_row != dimension_column) error_message_print_abort ("LU decomposition is used with square matrices only");

  if (is_it_LU_decomposed ()) error_message_print_abort ("LU decomposition cannot be used for an already LU decomposed matrix");
  
  if (is_it_Cholesky_decomposed_local) error_message_print_abort ("LU decomposition cannot be used for a Cholesky decomposed matrix");
  
  if (is_it_diagonal ()) error_message_print_abort ("LU decomposition cannot be used for a diagonal matrix");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  const double A_infinite_norm = A.infinite_norm ();
  
  A /= A_infinite_norm;

  const unsigned int dimension_column_minus_one = dimension_column - 1;
  
  class array<double> Pivoting_table(dimension_row);

  row_permutation = new unsigned int [dimension_row];
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
      
      Pivoting_table(i) = 1.0/Ai.infinite_norm ();

      row_permutation[i] = i;
 
      if (!finite (Pivoting_table(i))) error_message_print_abort ("Row with only zeros in LU decomposition");
    }
  
  class vector_class<SCALAR_TYPE> transpose_Aj(dimension_row); // The use of this vector to partially store the matrix greatly accelerates calculations.
      
  for (unsigned int j = 0 ; j < dimension_column_minus_one ; j++)
    {     
      unsigned int i_pivot = j;

      double pivot = 0;

      for (unsigned int i = j ; i < dimension_row ; i++)
	{
	  const double pivot_test = Pivoting_table(i)*inf_norm (A(i , j));
	  	      
	  if (pivot_test > pivot)
	    {
	      pivot = pivot_test;

	      i_pivot = i;
	    }
	}
      
      if (i_pivot != j) 
	{
	  swap<class vector_class<SCALAR_TYPE> > (row_vector(j) , row_vector(i_pivot));

	  determinant_phase = -determinant_phase;
	  
	  Pivoting_table(i_pivot) = Pivoting_table(j);
      
	  row_permutation[j] = i_pivot;
	}
      
      const unsigned int jp1 = j + 1;
      	  
      for (unsigned int i = 0 ; i <= j ; i++)
	{
	  class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  SCALAR_TYPE &Aij = Ai(j);
	  	  
	  for (unsigned int k = 0 ; k < i ; k++) Aij -= Ai(k)*transpose_Aj(k);

	  transpose_Aj(i) = A(i , j);
	}
	  
      for (unsigned int i = jp1 ; i < dimension_row ; i++)
	{
	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  SCALAR_TYPE &Aij = Ai(j);
	  
	  for (unsigned int k = 0 ; k < j ; k++) Aij -= Ai(k)*transpose_Aj(k);
	}
            
      const SCALAR_TYPE &Ajj = A(j , j);
      
      if (Ajj != 0.0)
	{
	  for (unsigned int i = jp1 ; i < dimension_row ; i++) A(i , j) /= Ajj;
	}
      else
	{
	  for (unsigned int i = jp1 ; i < dimension_row ; i++) A(i , j) *= 1E50;
	}
    }

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

      SCALAR_TYPE &Ai_dimension_column_minus_one = Ai(dimension_column_minus_one);
      
      for (unsigned int k = 0 ; k < i ; k++) Ai_dimension_column_minus_one -= Ai(k)*transpose_Aj(k);
      
      transpose_Aj(i) = A(i , dimension_column_minus_one);
    }

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
      
      for (unsigned int j = i ; j < dimension_column ; j++) Ai(j) *= A_infinite_norm;
    }
}










// Backsubtitution phase of a linear system solution calculation using LU decomposition
// ------------------------------------------------------------------------------------
// The routine returns the solution X of AX = B .
// A must be LU decomposed at this level.
// The calculation cost is about N^2.

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::LU_backsubstitute (const class vector_class<SCALAR_TYPE> &B , class vector_class<SCALAR_TYPE> &X) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (!is_it_LU_decomposed ()) error_message_print_abort ("The matrix must be LU decomposed for LU backsubstitution");
  
  if (dimension_row != dimension_column) error_message_print_abort ("Square matrices only for LU backsubstitution");
  
  if (dimension_row != B.get_dimension ()) error_message_print_abort ("Matrix and vector must have the same dimension for LU backsubstitution");
 
  X = B;

  const unsigned int dimension_row_minus_one = dimension_row - 1;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const unsigned int ip = row_permutation[i];

      const class vector_class<SCALAR_TYPE> &LU_i = row_vector (i);
      
      SCALAR_TYPE &Xi  = X(i);
      SCALAR_TYPE &Xip = X(ip);
      
      swap<SCALAR_TYPE> (Xi , Xip);

      for (unsigned int j = 0 ; j < i ; j++) Xi -= LU_i(j)*X(j);
    }
  
  for (unsigned int i = dimension_row_minus_one ; i <= dimension_row_minus_one ; i--)
    {
      const unsigned int ip1 = i + 1;
      
      const class vector_class<SCALAR_TYPE> &LU_i = row_vector (i);
      
      SCALAR_TYPE &Xi = X(i);

      for (unsigned int j = ip1 ; j < dimension_column ; j++) Xi -= LU_i(j)*X(j);
      
      Xi /= LU_i(i);
    }
}








// Cholesky decomposition
// ----------------------
// Cost is about N^3/6.
// No pivoting is done here.
// If Cholesly decomposition fails, one uses LU decomposition, where pivoting is done, so that it creates no problem.
// It is my implementation, so that there are no copyright issues.
//
// Cholesly decomposition is not done for diagonal matrices as it is useless there.
// One uses L.L^T for symmetric matrices and L.L^+ for hermitian matrices.
// One first normalizes the matrix with respect to A_infinite_norm, which cannot be zero, as otherwise A is diagonal.
// It is always more stable to use a matrix whose elements are equal to one or smaller in infinite norm.
// Cholesky decomposition can fail, as is the case for real non-positive definite matrices.
// If the matrix is hermitian, it has to be positive definite.
// Hence, if its diagonal has a negative number, no Cholesky decomposition is possible and one directly leaves the routine.
// If an infinite number is found, the Cholesky decomposition failed.
// However, it can still be wrong even if all numbers are finite.
// Thus, one checks if the diagonal of the matrix is correct up to 10^(-10) in relative value.
// The Cholesky decomposition fails if it is not the case.
// If the Cholesky decomposition fails, A is put back to its initial value.
// If the norm of a diagonal element is less than in 10^(-13), its associated off-diagonal terms are put to zero.
// 
// If the Cholesky decomposition succeeds, L and L^T/L^+ are stored in A at the end of the calculation.
// As L is upper diagonal, L^T/L^+ is lower diagonal, so that one can store their off-diagonal matrix elements which are not trivially equal to zero.
// As their diagonal matrix elememts are the same, they are stored in the diagonal of A.
// L and LT/L^+ are multiplied by sqrt (A_infinite_norm) at the end.


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::Cholesky_decompose ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row <= 2) error_message_print_abort ("Dimension >= 3 in for Cholesky decomposition");
  
  if (dimension_row != dimension_column) error_message_print_abort ("Cholesky decomposition is used with square matrices only");
  
  if (is_it_LU_decomposed ()) error_message_print_abort ("Cholesky decomposition cannot be used for an LU decomposed matrix");
  
  if (is_it_Cholesky_decomposed_local) error_message_print_abort ("Cholesky decomposition cannot be used for an already Cholesky decomposed matrix");
  
  if (is_it_diagonal ()) error_message_print_abort ("Cholesky decomposition cannot be used for a diagonal matrix");
  
  class matrix<SCALAR_TYPE> &A = *this;
  
  const bool is_A_symmetric = A.is_it_symmetric ();
  const bool is_A_hermitian = A.is_it_hermitian ();
  
  if (is_A_hermitian)
    {
      for (unsigned int i = 0 ; i < dimension_row ; i++)
	{
	  if (real_dc (A(i , i)) < 0.0) return;
	}
    }
  
  if (!is_A_symmetric && !is_A_hermitian) error_message_print_abort ("Cholesky decomposition for symmetric or hermitian matrices only");
  
  const double A_infinite_norm = A.infinite_norm ();

  A /= A_infinite_norm;

  class array<SCALAR_TYPE> A_diagonal_part(dimension_row);
    
  A.diagonal_part (A_diagonal_part);
  
  bool has_Cholesky_decomposition_failed = false;

  for (unsigned int i = 0 ; (!has_Cholesky_decomposition_failed) && (i < dimension_row) ; i++)
    {
      class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
      
      SCALAR_TYPE Aik_Aik_sum = 0.0;
	  
      if (is_A_symmetric)
	{
	  for (unsigned int k = 0 ; k < i ; k++) Aik_Aik_sum += Ai(k)*Ai(k);
	}
      else if (is_A_hermitian)
	{
	  for (unsigned int k = 0 ; k < i ; k++) Aik_Aik_sum += norm_dc (Ai(k));
	}
      
      SCALAR_TYPE &Aii = Ai(i);
	        
      Aii = sqrt (Aii - Aik_Aik_sum);

      if (!finite (Aii))
	{
	  has_Cholesky_decomposition_failed = true;

	  break;
	}
      
      if (!has_Cholesky_decomposition_failed)
	{
	  const SCALAR_TYPE &Aii_initial = A_diagonal_part(i);
	  
	  const SCALAR_TYPE Aii_from_Cholesky = (is_A_symmetric) ? (Aii*Aii + Aik_Aik_sum) : (norm_dc (Aii) + Aik_Aik_sum);

	  has_Cholesky_decomposition_failed = (inf_norm (Aii_initial - Aii_from_Cholesky) > precision);
	}
      
      const unsigned int ip1 = i + 1;
      
      if (inf_norm (Aii) > 1E-13)
	{
	  for (unsigned int j = ip1 ; (!has_Cholesky_decomposition_failed) && (j < dimension_column) ; j++)
	    {
	      class vector_class<SCALAR_TYPE> &Aj = A.row_vector (j);
      
	      SCALAR_TYPE &Aji = Aj(i);
	  
	      if (is_A_symmetric)
		{
		  for (unsigned int k = 0 ; k < i ; k++) Aji -= Ai(k)*Aj(k);
		}	  
	      else if (is_A_hermitian)
		{
		  for (unsigned int k = 0 ; k < i ; k++) Aji -= conj_dc (Ai(k))*Aj(k);
		}
	  
	      Aji /= Aii;
	  
	      if (!finite (Aji))
		{
		  has_Cholesky_decomposition_failed = true;
	      
		  break;
		}
	    }
	}
      else
	{	    
	  for (unsigned int j = ip1 ; (!has_Cholesky_decomposition_failed) && (j < dimension_column) ; j++) A(j , i) = 0.0;
	}
    }
    
  if (has_Cholesky_decomposition_failed)
    {
      for (unsigned int i = 0 ; i < dimension_row ; i++)
	{	  
	  const unsigned int ip1 = i + 1;
      
	  class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  Ai(i) = A_diagonal_part(i);
	  
	  if (is_A_symmetric)
	    {
	      for (unsigned int j = ip1 ; j < dimension_column ; j++) A(j , i) = Ai(j);
	    }	  
	  else if (is_A_hermitian)
	    {
	      for (unsigned int j = ip1 ; j < dimension_column ; j++) A(j , i) = conj_dc (Ai(j));
	    }
	}
      
      A *= A_infinite_norm;
    }
  else
    {
      for (unsigned int i = 0 ; i < dimension_row ; i++)
	{
	  const unsigned int ip1 = i + 1;
      
	  class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
      
	  if (is_A_symmetric)
	    {
	      for (unsigned int j = ip1 ; j < dimension_column ; j++) Ai(j) = A(j , i);
	    }	  
	  else if (is_A_hermitian)
	    {
	      for (unsigned int j = ip1 ; j < dimension_column ; j++) Ai(j) = conj_dc (A(j , i));
	    }
	}
  
      A *= sqrt (A_infinite_norm);
      
      is_it_Cholesky_decomposed_local = true;
    }
}









// Backsubtitution phase of a linear system solution calculation using Cholesky decomposition
// ------------------------------------------------------------------------------------------
// The routine returns the solution X of AX = B .
// A must be Cholesky decomposed at this level.
// The calculation cost is about N^2.

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::Cholesky_backsubstitute (const class vector_class<SCALAR_TYPE> &B , class vector_class<SCALAR_TYPE> &X) const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (!is_it_Cholesky_decomposed_local) error_message_print_abort ("The matrix must be Cholesky decomposed for Cholesky backsubstitution");
  
  if (dimension_row != dimension_column) error_message_print_abort ("Square matrices only for Cholesky backsubstitution");
  
  if (dimension_row != B.get_dimension ()) error_message_print_abort ("Matrix and vector must have the same dimension for Cholesky backsubstitution");
 
  X = B;

  const unsigned int dimension_row_minus_one = dimension_row - 1;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {      
      const class vector_class<SCALAR_TYPE> &Cholesky_i = row_vector (i);
      
      SCALAR_TYPE &Xi = X(i);

      for (unsigned int j = 0 ; j < i ; j++) Xi -= Cholesky_i(j)*X(j);

      Xi /= Cholesky_i(i);
    }
  
  for (unsigned int i = dimension_row_minus_one ; i <= dimension_row_minus_one ; i--)
    {
      const unsigned int ip1 = i + 1;

      const class vector_class<SCALAR_TYPE> &Cholesky_i = row_vector (i);
      
      SCALAR_TYPE &Xi = X(i);

      for (unsigned int j = ip1 ; j < dimension_column ; j++) Xi -= Cholesky_i(j)*X(j);
      
      Xi /= Cholesky_i(i);
    }
}









// Calculation of the determinant of the matrix
// --------------------------------------------
// The determinant is exactly calculated for dimensions 0, 1 and 2. It is 1 for dimension 0 by convention.
// These cases can indeed never be LU/Cholesky decomposed.
// If the matrix is diagonal, it can never be LU/Cholesky decomposed.
// If the matrix is not diagonal and not already LU/Cholesky decomposed, Cholesky decomposition is tried first for symmetric or hermitian matrices.
// If it fails, LU decomposition is used instead.
//
// Then, if one diagonal element is zero, one returns zero.
// If the product of diagonal elements is infinite (overflow) or zero (underflow) otherwise, one sums the logarithms of the diagonal elements, multiplied by +/-1 so that their real part is positive or zero.
// This is called the logarithm of the scaled determinant.
// As diagonal elements are non-zero here, their imaginary part is not zero if their real part is. 
// The sum of logarithms is then exponentiated, and multiplied by a phase equal to +/- 1 to reobtain the product of diagonal elements.
// It is the determinant if the matrix is diagonal, and it is returned.
// It is squared if Cholesky decomposition is used, so that one has the determinant and it is returned.
// It is multiplied by a phase equal to +/1 if LU decomposition is used because of pivoting, so that one has the determinant and it is returned.
//
// The logarithm of the scaled determinant and its phase can also be calculated, in case the determinant itself overflows or underflows.



template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::determinant ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("determinant is used with square matrices only");

  const class matrix <SCALAR_TYPE> &A = *this;

  if (dimension_row == 0) return 1.0;
  if (dimension_row == 1) return A(0 , 0);

  if (dimension_row == 2)
    {
      const SCALAR_TYPE Det = A(0 , 0)*A(1 , 1) - A(0 , 1)*A(1 , 0);

      return Det;
    }
  
  const bool is_A_diagonal = is_it_diagonal ();
      
  if (!is_A_diagonal)
    {
      if (!is_it_Cholesky_decomposed_local && !is_it_LU_decomposed ())
	{
	  if (is_it_symmetric () || is_it_hermitian ()) Cholesky_decompose ();
	  
	  if (!is_it_Cholesky_decomposed_local) LU_decompose ();
	}
    }
      
  class array<SCALAR_TYPE> A_diagonal_part(dimension_row);
    
  A.diagonal_part (A_diagonal_part);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      if (A_diagonal_part(i) == 0.0) return 0.0;
    }
      
  const SCALAR_TYPE diagonal_elements_product = A_diagonal_part.product ();

  if (!finite (diagonal_elements_product) || (diagonal_elements_product == 0.0))
    {
      int phase = 1;
	  
      SCALAR_TYPE log_Det_no_phase = 0.0;
	  	  
      for (unsigned int i = 0 ; i < dimension_row ; i++)
	{
	  if (real_dc (A_diagonal_part(i)) >= 0.0)
	    log_Det_no_phase += log (A_diagonal_part(i));
	  else
	    {		 
	      log_Det_no_phase += log (-A_diagonal_part(i));
		  
	      phase = -phase;
	    }
	}
	
      if (is_it_Cholesky_decomposed_local) log_Det_no_phase += log_Det_no_phase;

      if (is_it_LU_decomposed ()) phase *= determinant_phase;

      const SCALAR_TYPE Det = phase*exp (log_Det_no_phase);
	  
      return Det;
    }
  else
    {  
      if (is_A_diagonal) return diagonal_elements_product;
	
      if (is_it_Cholesky_decomposed_local)
	{
	  const SCALAR_TYPE Det = diagonal_elements_product*diagonal_elements_product;

	  return Det;
	}

      if (is_it_LU_decomposed ())
	{
	  const SCALAR_TYPE Det = determinant_phase*diagonal_elements_product;

	  return Det;
	}
      
      error_message_print_abort ("The matrix should be LU/Cholesky decomposed in determinant");
       
      return NADA;
    }
}












template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::log_scaled_determinant_and_phase (SCALAR_TYPE &log_Det_no_phase , int &phase)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("log_determinant_and_phase is used with square matrices only");

  const class matrix <SCALAR_TYPE> &A = *this;

  log_Det_no_phase = 0.0;
  
  phase = 1;

  if (dimension_row == 0) return;
  
  if (dimension_row == 1)
    {
      const SCALAR_TYPE &A00 = A(0 , 0);
 
      if (real_dc (A00) >= 0.0)
	log_Det_no_phase = log (A00);
      else
	{
	  log_Det_no_phase = log (-A00);

	  phase = -1;
	}

      return;
    }

  if (dimension_row == 2)
    {
      const SCALAR_TYPE Det = A(0 , 0)*A(1 , 1) - A(0 , 1)*A(1 , 0);

      if (real_dc (Det) >= 0.0)
	log_Det_no_phase = log (Det);
      else
	{
	  log_Det_no_phase = log (-Det);

	  phase = -1;
	}
      
      return;
    }

  const bool is_A_diagonal = is_it_diagonal ();
      
  if (!is_A_diagonal)
    {
      if (!is_it_Cholesky_decomposed_local && !is_it_LU_decomposed ())
	{
	  if (is_it_symmetric () || is_it_hermitian ()) Cholesky_decompose ();
	  
	  if (!is_it_Cholesky_decomposed_local) LU_decompose ();
	}
    }
      
  class array<SCALAR_TYPE> A_diagonal_part(dimension_row);
    
  A.diagonal_part (A_diagonal_part);

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      if (real_dc (A_diagonal_part(i)) >= 0.0)
	log_Det_no_phase += log (A_diagonal_part(i));
      else
	{		 
	  log_Det_no_phase += log (-A_diagonal_part(i));
		  
	  phase = -phase;
	}
    }
            
  if (is_A_diagonal) return;
	
  if (is_it_Cholesky_decomposed_local)
    {
      log_Det_no_phase += log_Det_no_phase;

      return;
    }

  if (is_it_LU_decomposed ())
    {
      phase *= determinant_phase;

      return;
    }
      
  error_message_print_abort ("The matrix should be LU/Cholesky decomposed in log_scaled_determinant_and_phase");
}





// Minimal and maximal values of matrix
// ------------------------------------

template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::min () const
{
  const unsigned int dimension_row = get_dimension_row ();
        
  if (dimension_row == 0) error_message_print_abort ("min function not defined for matrix without rows");

  const class vector_class<SCALAR_TYPE> &A0 = row_vector (0);
  
  SCALAR_TYPE A_min = A0.min ();

  for (unsigned int i = 1 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = row_vector (i);

      const SCALAR_TYPE Ai_min = Ai.min ();
  
      if (A_min > Ai_min) A_min = Ai_min;
    }

  return A_min;
}


template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::max () const
{
  const unsigned int dimension_row = get_dimension_row ();
        
  if (dimension_row == 0) error_message_print_abort ("max function not defined for matrix without rows");
  
  const class vector_class<SCALAR_TYPE> &A0 = row_vector (0);
  
  SCALAR_TYPE A_max = A0.max ();

  for (unsigned int i = 1 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = row_vector (i);

      const SCALAR_TYPE Ai_max = Ai.max ();
  
      if (A_max < Ai_max) A_max = Ai_max;
    }

  return A_max;
}



// Sum and product of matrix elements
// ------------------------------------



template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::sum () const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  SCALAR_TYPE A_sum = 0.0;

  for (unsigned int i = 0 ; i < dimension_row ; i++) A_sum += row_vector (i).sum ();

  return A_sum;
}


template <typename SCALAR_TYPE>
SCALAR_TYPE matrix<SCALAR_TYPE>::product () const
{
  const unsigned int dimension_row = get_dimension_row ();
    
  SCALAR_TYPE A_product = 1.0;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      A_product *= row_vector (i).product ();

      if (A_product == 0.0) return 0.0;
    }
  
  return A_product;
}


// Matrix inverse calculated
// -------------------------

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::inverse ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("inverse is used with square matrices only");

  class matrix<SCALAR_TYPE> &A = *this;

  if (is_it_Cholesky_decomposed_local || is_it_LU_decomposed ()) error_message_print_abort ("One cannot invert an LU/Cholesky decomposed matrix (member)");
      
  if (is_it_diagonal ())
    {
      for (unsigned int i = 0 ; i < dimension_row ; i++)
	{
	  SCALAR_TYPE &Aii = A(i , i);
	    
	  Aii = 1.0/Aii;
	}
    }
  else if (dimension_row == 2)
    {
      const SCALAR_TYPE A00 = A(0 , 0);
      const SCALAR_TYPE A01 = A(0 , 1);
      const SCALAR_TYPE A10 = A(1 , 0);
      const SCALAR_TYPE A11 = A(1 , 1);

      const SCALAR_TYPE A_determinant = A00*A11 - A01*A10;

      A(0 , 0) =  A11/A_determinant;
      A(0 , 1) = -A01/A_determinant;
      A(1 , 0) = -A10/A_determinant;
      A(1 , 1) =  A00/A_determinant;
    }
  else
    {
      const unsigned int i_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (dimension_row , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
      const unsigned int i_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (dimension_row , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (dimension_row - 1);
  
      const bool is_i_end_smaller_than_dimension_row = (i_end < dimension_row);
  
      class matrix<SCALAR_TYPE> M = A;
      
      if (M.is_it_symmetric () || M.is_it_hermitian ()) M.Cholesky_decompose ();
      
      if (!M.is_it_Cholesky_decomposed ()) M.LU_decompose ();

      A = 0.0;
      
      class array<class vector_class<SCALAR_TYPE> > V_array(NUMBER_OF_THREADS);

      for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) V_array(i_thread).allocate (dimension_row);

      if (is_i_end_smaller_than_dimension_row)
	{
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
	  for (unsigned int i = i_debut ; i <= i_end ; i++) 
	    {
	      const unsigned int i_thread = OpenMP_thread_number_determine ();
	    
	      class vector_class<SCALAR_TYPE> &V = V_array(i_thread);
	  
	      V = 0.0;

	      V(i) = 1.0;

	      linear_system_solution_calc<SCALAR_TYPE> (M , V , row_vector(i));
	    }
	}
      
#ifdef UseMPI
      if (is_it_MPI_parallelized_linear_algebra) MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif
  
      transpose ();
    }
}


// Matrix inverse returned.
// -----------------------
//
template <typename SCALAR_TYPE>
class matrix<SCALAR_TYPE> inverse (const class matrix<SCALAR_TYPE> &A)
{
  class matrix<SCALAR_TYPE> M = A;

  M.LU_Cholesky_data_reinitialize ();
  
  M.inverse ();

  return M;
}




//  Matrix randomly initialized.
// ------------------------

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::random_matrix ()
{
  const unsigned int dimension_row = get_dimension_row ();
  
  LU_Cholesky_data_reinitialize ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.random_vector ();
    }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::pseudo_random_matrix ()
{
  seed (0);
  
  random_matrix ();
  
  seed ();
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::symmetric_random_matrix ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("symmetric_random_matrix is used with square matrices only");

  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      M(i , i) = random_number<SCALAR_TYPE> () - 0.5;
      
      for (unsigned int j = 0 ; j < i ; j++)
	M(i , j) = M(j , i) = random_number<SCALAR_TYPE> () - 0.5;
    }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::symmetric_pseudo_random_matrix ()
{
  seed (0);
  
  symmetric_random_matrix ();
  
  seed ();
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::antisymmetric_random_matrix ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("antisymmetric_random_matrix is used with square matrices only");

  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      M(i , i) = 0.0;
      
      for (unsigned int j = 0 ; j < i ; j++)
	{
	  M(i , j) = random_number<SCALAR_TYPE> () - 0.5;
	
	  M(j , i) = -M(i , j);
	}
    }
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::antisymmetric_pseudo_random_matrix ()
{
  seed (0);
  
  antisymmetric_random_matrix ();
  
  seed ();
}



template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::hermitian_random_matrix ()
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("hermitian_random_matrix is used with square matrices only");

  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      M(i , i) = real_dc (random_number<SCALAR_TYPE> ()) - 0.5;
      
      for (unsigned int j = 0 ; j < i ; j++)
	{
	  M(i , j) = random_number<SCALAR_TYPE> () - 0.5;
	
	  M(j , i) = conj_dc (M(i , j));
	}
    }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::hermitian_pseudo_random_matrix ()
{
  seed (0);
  
  hermitian_random_matrix ();
  
  seed ();
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::put_zeros_with_probability (const double zeros_probability)
{
  if ((zeros_probability < 0.0) || (zeros_probability > 1.0)) error_message_print_abort ("The probability of zeros is between 0% and 100% in put_zeros_with_probability");

  const unsigned int dimension_row = get_dimension_row ();
  
  const unsigned int dimension_column = get_dimension_column ();
    
  LU_Cholesky_data_reinitialize ();
  
  class matrix<SCALAR_TYPE> &M = *this;
  
  if (zeros_probability == 0.0) return;

  if (zeros_probability == 1.0)
    {
      M = 0.0;

      return;
    }

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j < dimension_column ; j++)
      {
	if (random_number<double> () < zeros_probability) M(i , j) = 0.0;
      }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::put_zeros_symmetrically_with_probability (const double zeros_probability)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("put_zeros_symmetrically_with_probability is used with square matrices only");

  if ((zeros_probability < 0.0) || (zeros_probability > 1.0)) error_message_print_abort ("The probability of zeros is between 0% and 100% in put_zeros_symmetrically_with_probability");

  LU_Cholesky_data_reinitialize ();

  class matrix<SCALAR_TYPE> &M = *this;

  if (zeros_probability == 0.0) return;

  if (zeros_probability == 1.0)
    {
      M = 0.0;

      return;
    }
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    for (unsigned int j = 0 ; j <= i ; j++)
      {
	if (random_number<double> () < zeros_probability) M(i , j) = M(j , i) = 0.0;
      }
}



// Determination of the index of the vector of maximal overlap with an approximate vector
// --------------------------------------------------------------------------------------
// P is the matrix of eigenvectors.
// <eigenvector_i|V_reference> , with V_reference the basis vector of index V_reference_index ,
// and eigenvector_i the eigenvector P.eigenvector(i) , is the overlap for which |<eigenvector_i|V_reference>| is maximal.
// The index i for which |<eigenvector_i|V_reference>| is maximal , i_max , is returned.

template <typename SCALAR_TYPE>
unsigned int maximal_overlap_eigenvector_index_determine (
							  const class matrix<SCALAR_TYPE> &P , 
							  const unsigned int V_reference_index)
{
  if (P.get_dimension_row () != P.get_dimension_column ()) error_message_print_abort ("maximal_overlap_eigenvector_index_determine function is used with square matrices only");

  const unsigned int dimension = P.get_dimension_row ();

  double inf_norm_overlap_max = 0.0; 

  unsigned int i_max = 0;

  for (unsigned int i = 0 ; i < dimension ; i++)
    {    
      const class vector_class<SCALAR_TYPE> &eigenvector_i = P.eigenvector(i);

      const SCALAR_TYPE eigenvector_i_V_reference_overlap = eigenvector_i(V_reference_index);

      const double inf_norm_overlap = inf_norm (eigenvector_i_V_reference_overlap);

      if (inf_norm_overlap > inf_norm_overlap_max) 
	{
	  inf_norm_overlap_max = inf_norm_overlap;

	  i_max = i;
	}
    }

  return i_max;
}



// assignment
// ----------
// A is assigned on B if A.dimension > B.dimension , that is B(i , j) = A(i , j) when available while remaining components of A are ignored.
// A is copied to B if A.dimension < B.dimension , remaining components being ignored

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::assign (const class matrix<SCALAR_TYPE> &A)
{
  if (is_it_Cholesky_decomposed_local || is_it_LU_decomposed ()) error_message_print_abort ("One cannot assign a matrix to an LU/Cholesky decomposed matrix");
  
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  class matrix<SCALAR_TYPE> &B = *this;

  const unsigned int smallest_dimension_row = ::min (dimension_row , A.get_dimension_row ());

  const unsigned int smallest_dimension_column = ::min (dimension_column , A.get_dimension_column ());

  for (unsigned int i = 0 ; i < smallest_dimension_row ; i++)
    for (unsigned int j = 0 ; j < smallest_dimension_column ; j++)
      B(i , j) = A(i , j); 
}




template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::reverse_vectors_order ()
{
  const unsigned int dimension_row = get_dimension_row ();
  
  if (dimension_row == 0) return;

  if (is_it_Cholesky_decomposed_local || is_it_LU_decomposed ()) error_message_print_abort ("One cannot use reverse_vectors_order with an LU/Cholesky decomposed matrix");
  
  const unsigned int half_dimension = dimension_row/2;
  
  const unsigned int dimension_row_minus_one = dimension_row - 1;

  for (unsigned int i = 0 ; i < half_dimension ; i++) swap<class vector_class<SCALAR_TYPE> > (row_vector(i) , row_vector(dimension_row_minus_one - i));
}





// Create a tridiagonal matrix from the arrays containing its diagonal and off-diagonal parts.
// Non-symmetric and symmetric cases are included.

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::tridiagonal (
				       const class array<SCALAR_TYPE> &lower_off_diagonal_tab , 
				       const class array<SCALAR_TYPE> &diagonal_tab , 
				       const class array<SCALAR_TYPE> &upper_off_diagonal_tab)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("tridiagonal is used with square matrices only");
  
  if (dimension_row == 0) return;

  LU_Cholesky_data_reinitialize ();
  
  const unsigned int dimension_row_minus_one = dimension_row - 1;

  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  M.put_array_diagonal_part (diagonal_tab);

  for (unsigned int i = 0 ; i < dimension_row_minus_one ; i++) 	
    {
      M(i , i+1) = upper_off_diagonal_tab(i);	
      M(i+1 , i) = lower_off_diagonal_tab(i);
    }
}



template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::tridiagonal (
				       const class array<SCALAR_TYPE> &off_diagonal_tab ,
				       const class array<SCALAR_TYPE> &diagonal_tab)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
  
  if (dimension_row != dimension_column) error_message_print_abort ("tridiagonal is used with square matrices only");

  if (dimension_row == 0) return;

  LU_Cholesky_data_reinitialize ();
  
  const unsigned int dimension_row_minus_one = dimension_row - 1;

  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  M.put_array_diagonal_part (diagonal_tab);

  for (unsigned int i = 0 ; i < dimension_row_minus_one ; i++) M(i , i+1) = M(i+1 , i) = off_diagonal_tab(i);
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::tridiagonal_hermitian (
						 const class array<SCALAR_TYPE> &off_diagonal_tab ,
						 const class array<SCALAR_TYPE> &diagonal_tab)
{
  const unsigned int dimension_row = get_dimension_row ();
    
  const unsigned int dimension_column = get_dimension_column ();
    
  if (dimension_row != dimension_column) error_message_print_abort ("tridiagonal_hermitian is used with square matrices only");

  if (dimension_row == 0) return;

  LU_Cholesky_data_reinitialize ();
  
  const unsigned int dimension_row_minus_one = dimension_row - 1;

  class matrix<SCALAR_TYPE> &M = *this;

  M = 0.0;

  M.put_array_diagonal_part (diagonal_tab);

  for (unsigned int i = 0 ; i < dimension_row_minus_one ; i++)
    {
      const SCALAR_TYPE off_diagonal = off_diagonal_tab(i);
      
      M(i , i+1) = off_diagonal;
      M(i+1 , i) = conj_dc (off_diagonal);
    }
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::read_disk (const string &file_name)
{
  const unsigned int dimension_row = get_dimension_row ();
  
  LU_Cholesky_data_reinitialize ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) 
    {
      class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.read_disk (file_name + "_" + make_string<unsigned int> (i));
    }
}

template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::copy_disk (const string &file_name) const
{
  const unsigned int dimension_row = get_dimension_row ();
  
  for (unsigned int i = 0 ; i < dimension_row ; i++) 
    {
      const class vector_class<SCALAR_TYPE> &Vi = row_vector(i);

      Vi.copy_disk (file_name + "_" + make_string<unsigned int> (i));
    }
}


template <typename SCALAR_TYPE>
void matrix<SCALAR_TYPE>::matrix_scaling (const class matrix<SCALAR_TYPE> &A)
{  
  const unsigned int dimension_row = get_dimension_row ();
  
  const unsigned int dimension_column = get_dimension_column ();
    
  class matrix<SCALAR_TYPE> &X = *this;
  
  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
	  
      class vector_class<SCALAR_TYPE> &Xi = X.row_vector (i);
	  
      for (unsigned int j = 0 ; j < dimension_column ; j++)
	{
	  const SCALAR_TYPE &Aij = Ai(j);
	  
	  if (Aij != 0.0) Xi(j) /= Ai(j);
	}
    }
}





// "==" overloading
// ----------------

template <typename SCALAR_TYPE>
bool operator == (const class matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B)
{
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator == (full , full)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator == (full , full)");  
   
  const unsigned int dimension_row = A.get_dimension_row ();

  for (unsigned int i = 0 ; i < dimension_row ; i++)
    {
      if (A.row_vector(i) != B.row_vector(i)) return false;
    }

  return true;
}




template <typename SCALAR_TYPE>
bool operator == (const class matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B)
{
  if (A.get_dimension_row () != B.get_dimension_row ()) error_message_print_abort ("Row dimensions must be equal in operator = (full , sparse)");
  
  if (A.get_dimension_column () != B.get_dimension_column ()) error_message_print_abort ("Column dimensions must be equal in operator = (full , sparse)");
  
  const unsigned int Nr = A.get_dimension_row ();
  const unsigned int Nc = A.get_dimension_column ();
    
  const bool are_B_indices_matrix_sorted = B.are_indices_matrix_sorted ();
  
  class sparse_matrix<SCALAR_TYPE> B_prime;

  if (!are_B_indices_matrix_sorted)
    {
      B_prime.allocate_fill (B);
  
      B_prime.indices_matrix_sort ();
    }

  const class sparse_matrix<SCALAR_TYPE> &B_sorted = (are_B_indices_matrix_sorted) ? (B) : (B_prime);
  
  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < Nr ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);
  
      for (unsigned int j = 0 ; j < Nc ; j++)
	{
	  const unsigned int index_iA_jA = j + Nc*i;
		
	  unsigned int index_iB_jB = B_sorted.get_column_index (index) + Nc*B_sorted.get_row_index (index);

	  while (index_iB_jB < index_iA_jA)
	    {
	      index++;
	      
	      index_iB_jB = B_sorted.get_column_index (index) + Nc*B_sorted.get_row_index (index);
	    }
		
	  const SCALAR_TYPE Bij = (index_iA_jA == index_iB_jB) ? (B_sorted.get_matrix_element (index)) : (0.0);
	  
	  if (Ai(j) != Bij) return false;
	}
    }
  
  return true;
}

template <typename SCALAR_TYPE>
bool operator == (const class sparse_matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B)
{
  return (B == A);
}





 
template <typename SCALAR_TYPE>
bool operator != (const class matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B)
{
  return (!(A == B));
}

template <typename SCALAR_TYPE>
bool operator != (const class matrix<SCALAR_TYPE> &A , const class sparse_matrix<SCALAR_TYPE> &B)
{
  return (!(A == B));
}

template <typename SCALAR_TYPE>
bool operator != (const class sparse_matrix<SCALAR_TYPE> &A , const class matrix<SCALAR_TYPE> &B)
{
  return (!(A == B));
}





// Similarity transformation from one basis to another using arrays to store matrices
// ----------------------------------------------------------------------------------
// With matrices, one has A_out = P . A_in . transpose (P) or A_out = P . A_in . dagger (P) (eigenvectors are stored as row vectors)
// One uses arrays to store matrices, so that one uses temporary matrices A_in and A_out for the calculation.
// No memory optimization is done, one needs 4 temporary matrices + the 2 initial arrays for the calculation.
// Symmetric and hermitian routines are available.

template <typename SCALAR_TYPE>
void similarity_transformation_with_arrays (
					    const class array<SCALAR_TYPE> &input_array,
					    const class matrix<SCALAR_TYPE> &P ,
					    class array<SCALAR_TYPE> &output_array)
{
  if (P.get_dimension_row () != P.get_dimension_column ()) error_message_print_abort ("P must be a square matrix in similarity_transformation_with_arrays");
  
  const unsigned int dimension = P.get_dimension_row ();

  if ((input_array.dimension (0) != dimension) ||  (input_array.dimension (1) != dimension) || (output_array.dimension (0) != dimension) || (output_array.dimension (1) != dimension))
    error_message_print_abort ("P , input_array and output_array must have the same dimensions in similarity_transformation_with_arrays");

  class matrix<SCALAR_TYPE> input_matrix(dimension);

  for (unsigned int i = 0 ; i < dimension ; i++)
    for (unsigned int j = 0 ; j < dimension ; j++)
      input_matrix(i , j) = input_array(i , j); 
    
  const class matrix<SCALAR_TYPE> output_matrix = P*input_matrix*transpose (P);
  
  for (unsigned int i = 0 ; i < dimension ; i++)
    for (unsigned int j = 0 ; j < dimension ; j++)
      output_array(i , j) = output_matrix(i , j); 
}



template <typename SCALAR_TYPE>
void similarity_transformation_with_arrays_hermitian (
						      const class array<SCALAR_TYPE> &input_array,
						      const class matrix<SCALAR_TYPE> &P ,
						      class array<SCALAR_TYPE> &output_array)
{
  
  if (P.get_dimension_row () != P.get_dimension_column ()) error_message_print_abort ("P must be a square matrix in similarity_transformation_with_arrays_hermitian");
  
  const unsigned int dimension = P.get_dimension_row ();
  
  if ((input_array.dimension (0) != dimension) ||  (input_array.dimension (1) != dimension) || (output_array.dimension (0) != dimension) || (output_array.dimension (1) != dimension))
    error_message_print_abort ("P , input_array and output_array must have the same dimensions in similarity_transformation_with_arrays_hermitian");

  class matrix<SCALAR_TYPE> input_matrix(dimension);

  for (unsigned int i = 0 ; i < dimension ; i++)
    for (unsigned int j = 0 ; j < dimension ; j++)
      input_matrix(i , j) = input_array(i , j); 
  
  const class matrix<SCALAR_TYPE> output_matrix = P*input_matrix*dagger (P);

  for (unsigned int i = 0 ; i < dimension ; i++)
    for (unsigned int j = 0 ; j < dimension ; j++)
      output_array(i , j) = output_matrix(i , j); 
}







template <typename SCALAR_TYPE>
double used_memory_calc (const class matrix<SCALAR_TYPE> &T)
{
  const unsigned int row_permutation_elements_number = (T.row_permutation != NULL) ? (T.get_dimension_row ()) : (0);
  
  return ((sizeof (T) + row_permutation_elements_number*sizeof (unsigned int))/1000000.0 + used_memory_calc (T.table));
}




#endif

