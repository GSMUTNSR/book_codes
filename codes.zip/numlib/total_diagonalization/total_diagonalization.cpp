#include "../numlib_def/numlib_def.h"



// One can directly call routines with complex matrix in the symmetric or complex hermitian case.
// The matrix is separated in real and imaginary parts and one calls other routines.
// A is copied to Ar and Ai (A = Ar + i.Ai) and deallocated when Ar and Ai only are used.
// It is reallocated afterwards, so that Ar + i.Ai -> A for the new Ar, Ai.
// This creates no memory time/issue as one needs two to seven real matrices in the routines called afterwards, so that one can tolerate an additional matrix here.


void total_diagonalization::all_eigenpairs_Householder (
							class matrix<double> &A , 
							class array<double> &eigenvalues)
  
{
  symmetric::all_eigenpairs_Householder (A , eigenvalues);
}




void total_diagonalization::all_eigenpairs_Lanczos (
						    class matrix<double> &A , 			        
						    class array<double> &eigenvalues)
  
{
  symmetric::all_eigenpairs_Lanczos (A , eigenvalues);
}




  
void total_diagonalization::all_eigenpairs_Newton (
						   class matrix<double> &A , 			       
						   class array<double> &eigenvalues)
  
{
  symmetric::all_eigenpairs_Newton (A , eigenvalues);
}




void total_diagonalization::all_eigenpairs (
					    class matrix<double> &A , 		        
					    class array<double> &eigenvalues)
  
{
  symmetric::all_eigenpairs (A , eigenvalues);
}




void total_diagonalization::all_eigenvalues_Householder (
							 class matrix<double> &A , 
							 class array<double> &eigenvalues)
  
{
  symmetric::all_eigenvalues_Householder (A , eigenvalues);
}
  



void total_diagonalization::all_eigenvalues_Lanczos (
						     class matrix<double> &A , 				 
						     class array<double> &eigenvalues)
  
{
  symmetric::all_eigenvalues_Lanczos (A , eigenvalues);
}




void total_diagonalization::all_eigenvalues (
					     class matrix<double> &A , 			 
					     class array<double> &eigenvalues)
  
{
  symmetric::all_eigenvalues (A , eigenvalues);
}








void total_diagonalization::all_eigenpairs_Householder (
							class matrix<complex<double> > &A , 
							class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenpairs_Householder (A , eigenvalues);
  else if (A.is_it_hermitian ())
    {
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
      
      hermitian::all_eigenpairs_Householder (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenpairs_Householder (complex)");
}




void total_diagonalization::all_eigenpairs_Lanczos (
						    class matrix<complex<double> > &A , 
						    class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenpairs_Lanczos (A , eigenvalues);
  else if (A.is_it_hermitian ())
    {
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenpairs_Lanczos (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenpairs_Lanczos (complex)");
}




  
void total_diagonalization::all_eigenpairs_Newton (
						   class matrix<complex<double> > &A ,
						   class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenpairs_Newton (A , eigenvalues);
  else if (A.is_it_hermitian ())
    { 
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenpairs_Newton (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenpairs_Newton (complex)");
}




void total_diagonalization::all_eigenpairs (
					    class matrix<complex<double> > &A , 		        
					    class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenpairs (A , eigenvalues);
  else if (A.is_it_hermitian ())
    { 
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenpairs (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenpairs (complex)");
}




void total_diagonalization::all_eigenvalues_Householder (
							 class matrix<complex<double> > &A , 
							 class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenvalues_Householder (A , eigenvalues);
  else if (A.is_it_hermitian ())
    {  
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenvalues_Householder (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenvalues_Householder (complex)");
}
  



void total_diagonalization::all_eigenvalues_Lanczos (
						     class matrix<complex<double> > &A , 
						     class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenvalues_Lanczos (A , eigenvalues);
  else if (A.is_it_hermitian ())
    {   
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenvalues_Lanczos (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenvalues_Lanczos (complex)");
}




void total_diagonalization::all_eigenvalues (
					     class matrix<complex<double> > &A , 			 
					     class array<complex<double> > &eigenvalues)
  
{
  if (A.is_it_symmetric ())
    symmetric::all_eigenvalues (A , eigenvalues);
  else if (A.is_it_hermitian ())
    {   
      class matrix<double> Ar = real<double , complex<double> > (A);
      class matrix<double> Ai = imag<double , complex<double> > (A);
  
      A.deallocate ();

      const unsigned int N = eigenvalues.dimension (0);
       
      class array<double> eigenvalues_r(N);
       
      hermitian::all_eigenvalues (Ar , Ai , eigenvalues_r);

      const class matrix<complex<double> > A_new = complex_matrix<double , complex<double> > (Ar , Ai);
  
      Ar.deallocate ();
      Ai.deallocate ();

      eigenvalues = complex_array<double , complex<double> > (eigenvalues_r);
  
      A.allocate_fill (A_new);
    }
  else	
    error_message_print_abort ("A must be symmetric or hermitian in all_eigenvalues (complex)");
}
