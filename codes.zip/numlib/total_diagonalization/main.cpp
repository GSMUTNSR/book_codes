#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;




void eigenpairs_full_matrix_test_symmetric (
					    const class matrix<double> &M , 
					    const class matrix<double> &P , 
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = M.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<double> &eigenvector = P.eigenvector (i);

      const double eigenvalue = eigenvalues(i);

      const double eigenvalue_only = eigenvalues_only(i);

      const class vector_class<double> Res = M*eigenvector - eigenvalue*eigenvector;

      const double test = inf_norm (eigenvalue - eigenvalue_only) + Res.infinite_norm ();

      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector " << i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "    precision : " << test << endl;
    }
}





void eigenpairs_full_matrix_test_symmetric (
					    const class block_matrix<double> &M , 
					    const class block_matrix<double> &P , 
					    const class array<double> &eigenvalues ,
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = M.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<double> &M_block = M(i);
      const class matrix<double> &P_block = P(i);

      const unsigned int M_block_dimension = M_block.get_dimension ();

      class array<double> eigenvalues_block(M_block_dimension);
      
      class array<double> eigenvalues_only_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_symmetric (M_block , P_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}








void eigenpairs_tridiagonal_test_symmetric (
					    const class array<double> &off_diagonal_tab , 
					    const class array<double> &diagonal_tab , 
					    const class matrix<double> &P , 
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = diagonal_tab.dimension (0);

  class matrix<double> M(N);
  
  M.tridiagonal (off_diagonal_tab , diagonal_tab);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<double> &eigenvector = P.eigenvector (i);

      const double eigenvalue = eigenvalues(i);

      const double eigenvalue_only = eigenvalues_only(i);

      const class vector_class<double> Res = M*eigenvector - eigenvalue*eigenvector;

      const double test = inf_norm (eigenvalue - eigenvalue_only) + Res.infinite_norm ();
      
      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector " << i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "    precision : " << test << endl;
    }
}

void eigenpairs_full_matrix_test_symmetric (
					    const class matrix<complex<double> > &M , 
					    const class matrix<complex<double> > &P , 
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = M.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);
      
      const complex<double> &eigenvalue = eigenvalues(i);
      
      const complex<double> &eigenvalue_only = eigenvalues_only(i);
      
      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      const double test = inf_norm (eigenvalue - eigenvalue_only) + Res.infinite_norm ();
      
      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector " << i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "    precision : " << test << endl;
    }
}




void eigenpairs_full_matrix_test_symmetric (
					    const class block_matrix<complex<double> > &M , 
					    const class block_matrix<complex<double> > &P , 
					    const class array<complex<double> > &eigenvalues ,
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = M.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<complex<double> > &M_block = M(i);
      const class matrix<complex<double> > &P_block = P(i);

      const unsigned int M_block_dimension = M_block.get_dimension ();

      class array<complex<double> > eigenvalues_block(M_block_dimension);
      
      class array<complex<double> > eigenvalues_only_block(M_block_dimension);

      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_symmetric (M_block , P_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}










void eigenpairs_tridiagonal_test_symmetric (
					    const class array<complex<double> > &off_diagonal_tab , 
					    const class array<complex<double> > &diagonal_tab , 
					    const class matrix<complex<double> > &P , 
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = diagonal_tab.dimension (0);

  class matrix<complex<double> > M(N);

  M.tridiagonal (off_diagonal_tab , diagonal_tab);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);

      const complex<double> &eigenvalue = eigenvalues(i);

      const complex<double> &eigenvalue_only = eigenvalues_only(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      const double test = inf_norm (eigenvalue - eigenvalue_only) + Res.infinite_norm ();
      
      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector " << i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "    precision : " << test  << endl;
    }
}









void double_test_symmetric (const unsigned int N , const bool is_it_diagonal , double &test_all)
{
  class matrix<double> M(N);
  
  class array<double> eigenvalues(N);
  
  class array<double> eigenvalues_only(N);

  class array<double> diagonal_tab(N);

  class array<double> off_diagonal_tab(N);
  
  diagonal_tab.random_array ();
      
  if (is_it_diagonal)
    {
      M = 0.0;

      M.put_array_diagonal_part (diagonal_tab);
    }
  else
    M.symmetric_random_matrix ();

  class matrix<double> P = M;

  if (N >= 1)
    {
      const unsigned int Nm1 = N-1;

      if (is_it_diagonal)
	off_diagonal_tab = 0.0;
      else
	{
	  off_diagonal_tab.random_array ();

	  off_diagonal_tab *= 0.1;
	}
      
      off_diagonal_tab(Nm1) = 0.0;
    }

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

  total_diagonalization::symmetric::all_eigenvalues (off_diagonal_tab , diagonal_tab , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Tridiagonal matrix" << endl;

  total_diagonalization::symmetric::all_eigenpairs (off_diagonal_tab , diagonal_tab , P , eigenvalues);

  eigenpairs_tridiagonal_test_symmetric (off_diagonal_tab , diagonal_tab , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Tridiagonal matrix (inverse iteration)" << endl;

  total_diagonalization::symmetric::all_eigenpairs_inverse_iteration (off_diagonal_tab , diagonal_tab , P , eigenvalues);

  eigenpairs_tridiagonal_test_symmetric (off_diagonal_tab , diagonal_tab , P , eigenvalues , eigenvalues_only , test_all);

  if (!is_it_diagonal)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
      
      class array<double> M_diagonal(N);
      
      for (unsigned int i = 0 ; i < N/2 ; i++) M_diagonal(i) = 1E10;
      for (unsigned int i = N/2 ; i < N ; i++) M_diagonal(i) = 2E10;
      
      class matrix<double> M(N);
      
      M.symmetric_random_matrix ();
      
      M.put_array_diagonal_part (M_diagonal);

      M /= 1E10;

      P = M;
      total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
      P = M;
      total_diagonalization::all_eigenpairs (P , eigenvalues);
      
      eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
      P = M;
      total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

      eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);
    }
}






void complex_test_symmetric (const unsigned int N , const bool is_it_diagonal , double &test_all)
{
  class matrix<complex<double> > M(N);

  class array<complex<double> > eigenvalues(N);

  class array<complex<double> > eigenvalues_only(N);

  class array<complex<double> > diagonal_tab(N);
  
  class array<complex<double> > off_diagonal_tab(N);
  
  diagonal_tab.random_array ();
      
  if (is_it_diagonal)
    {
      M = 0.0;

      M.put_array_diagonal_part (diagonal_tab);
    }
  else
    {
      class matrix<double> Mr(N);
      class matrix<double> Mi(N);
      
      Mr.symmetric_random_matrix ();
      Mi.symmetric_random_matrix ();
      
      Mi *= 0.1;
      
      M = complex_matrix<double,complex<double> > (Mr , Mi);
    }

  class matrix<complex<double> > P = M;

  if (N >= 1)
    {
      const unsigned int Nm1 = N-1;

      if (is_it_diagonal)
	off_diagonal_tab = 0.0;
      else
	{
	  off_diagonal_tab.random_array ();

	  off_diagonal_tab *= 0.1;
	}
      
      off_diagonal_tab(Nm1) = 0.0;
    }
    
  total_diagonalization::all_eigenvalues (P , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

  if (!is_it_diagonal)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
      
      class array<double> Mr_diagonal(N);
      class array<double> Mi_diagonal(N);
      
      for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
      for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;
      
      for (unsigned int i = 0 ; i < N/2 ; i++) Mi_diagonal(i) = 5E4;
      for (unsigned int i = N/2 ; i < N ; i++) Mi_diagonal(i) = 1E10;
      
      class matrix<double> Mr(N) , Mi(N);
      
      Mr.symmetric_random_matrix ();	       
      Mi.symmetric_random_matrix ();
      
      Mr.put_array_diagonal_part (Mr_diagonal);
      Mi.put_array_diagonal_part (Mi_diagonal);

      Mr /= 1E10;
      Mi /= 1E10;
      
      M = complex_matrix<double,complex<double> > (Mr , Mi);

      P = M;
      total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
      P = M;
      total_diagonalization::all_eigenpairs (P , eigenvalues);
      
      eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
      P = M;
      total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

      eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);
    }

  total_diagonalization::symmetric::all_eigenvalues (off_diagonal_tab , diagonal_tab , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Tridiagonal matrix" << endl;

  total_diagonalization::symmetric::all_eigenpairs (off_diagonal_tab , diagonal_tab , P , eigenvalues);

  eigenpairs_tridiagonal_test_symmetric (off_diagonal_tab , diagonal_tab , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Tridiagonal matrix (inverse iteration)" << endl;

  total_diagonalization::symmetric::all_eigenpairs_inverse_iteration (off_diagonal_tab , diagonal_tab , P , eigenvalues);

  eigenpairs_tridiagonal_test_symmetric (off_diagonal_tab , diagonal_tab , P , eigenvalues , eigenvalues_only , test_all);
}







void eigenpairs_full_matrix_test_hermitian (
					    const class matrix<complex<double> > &Mr , 
					    const class matrix<complex<double> > &Mi , 
					    const class matrix<complex<double> > &Pr , 
					    const class matrix<complex<double> > &Pi , 
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = Mr.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<complex<double> > &eigenvector_r = Pr.eigenvector (i);
      const class vector_class<complex<double> > &eigenvector_i = Pi.eigenvector (i);

      const complex<double> &eigenvalue = eigenvalues(i);
      const complex<double> &eigenvalue_only = eigenvalues_only(i);

      const class vector_class<complex<double> > Res_r = Mr*eigenvector_r - Mi*eigenvector_i - eigenvalue*eigenvector_r;
      const class vector_class<complex<double> > Res_i = Mi*eigenvector_r + Mr*eigenvector_i - eigenvalue*eigenvector_i;

      const double test = max (Res_r.infinite_norm () , Res_i.infinite_norm ());

      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector "<< i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "   precision : " << test << endl;
    }
}





void eigenpairs_full_matrix_test_hermitian (
					    const class block_matrix<complex<double> > &Mr , 
					    const class block_matrix<complex<double> > &Mi , 
					    const class block_matrix<complex<double> > &Pr , 
					    const class block_matrix<complex<double> > &Pi , 
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = Mr.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<complex<double> > &Mr_block = Mr(i);
      const class matrix<complex<double> > &Mi_block = Mi(i);
      
      const class matrix<complex<double> > &Pr_block = Pr(i);
      const class matrix<complex<double> > &Pi_block = Pi(i);

      const unsigned int M_block_dimension = Mr_block.get_dimension ();

      class array<complex<double> > eigenvalues_block(M_block_dimension);
      
      class array<complex<double> > eigenvalues_only_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_hermitian (Mr_block , Mi_block , Pr_block , Pi_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}







void eigenpairs_full_matrix_test_hermitian (
					    const class matrix<complex<double> > &M , 
					    const class matrix<complex<double> > &P ,
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = M.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);
      
      const double eigenvalue = eigenvalues(i);
      const double eigenvalue_only = eigenvalues_only(i);

      const class vector_class<complex<double> > Res = M*eigenvector - complex<double> (eigenvalue)*eigenvector;

      const double test = Res.infinite_norm ();

      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector "<< i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "   precision : " << test << endl;
    }
}








void eigenpairs_full_matrix_test_hermitian (
					    const class block_matrix<complex<double> > &M , 
					    const class block_matrix<complex<double> > &P ,
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = M.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<complex<double> > &M_block = M(i);
      const class matrix<complex<double> > &P_block = P(i);

      const unsigned int M_block_dimension = M_block.get_dimension ();

      class array<double> eigenvalues_block(M_block_dimension);
      
      class array<double> eigenvalues_only_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_hermitian (M_block , P_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}





void eigenpairs_full_matrix_test_hermitian (
					    const class matrix<complex<double> > &M , 
					    const class matrix<complex<double> > &P ,
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = M.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);
      
      const complex<double> &eigenvalue = eigenvalues(i);
      const complex<double> &eigenvalue_only = eigenvalues_only(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      const double test = Res.infinite_norm ();

      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector "<< i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "   precision : " << test << endl;
    }
}



void eigenpairs_full_matrix_test_hermitian (
					    const class block_matrix<complex<double> > &M , 
					    const class block_matrix<complex<double> > &P , 
					    const class array<complex<double> > &eigenvalues , 
					    const class array<complex<double> > &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = M.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<complex<double> > &M_block = M(i);
      const class matrix<complex<double> > &P_block = P(i);

      const unsigned int M_block_dimension = M_block.get_dimension ();

      class array<complex<double> > eigenvalues_block(M_block_dimension);
      
      class array<complex<double> > eigenvalues_only_block(M_block_dimension);
            
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_hermitian (M_block , P_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}






void eigenpairs_full_matrix_test_hermitian (
					    const class matrix<double> &Mr , 
					    const class matrix<double> &Mi , 
					    const class matrix<double> &Pr , 
					    const class matrix<double> &Pi , 
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int N = Mr.get_dimension ();

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const class vector_class<double> &eigenvector_r = Pr.eigenvector (i);
      const class vector_class<double> &eigenvector_i = Pi.eigenvector (i);

      const double eigenvalue = eigenvalues(i);

      const double eigenvalue_only = eigenvalues_only(i);

      const class vector_class<double> Res_r = Mr*eigenvector_r - Mi*eigenvector_i - eigenvalue*eigenvector_r;
      const class vector_class<double> Res_i = Mi*eigenvector_r + Mr*eigenvector_i - eigenvalue*eigenvector_i;

      const double test = max (Res_r.infinite_norm () , Res_i.infinite_norm ());

      test_all = max (test_all , test);
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << "Eigenvector "<< i << "   eigenvalue : " << eigenvalue <<  "   eigenvalue (no eigenvector case) : " << eigenvalue_only << "   precision : " << test << endl;
    }
}





void eigenpairs_full_matrix_test_hermitian (
					    const class block_matrix<double> &Mr , 
					    const class block_matrix<double> &Mi , 
					    const class block_matrix<double> &Pr , 
					    const class block_matrix<double> &Pi , 
					    const class array<double> &eigenvalues , 
					    const class array<double> &eigenvalues_only ,
					    double &test_all)
{
  const unsigned int blocks_number = Mr.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {      
      const class matrix<double> &Mr_block = Mr(i);
      const class matrix<double> &Mi_block = Mi(i);
      
      const class matrix<double> &Pr_block = Pr(i);
      const class matrix<double> &Pi_block = Pi(i);

      const unsigned int M_block_dimension = Mr_block.get_dimension ();

      class array<double> eigenvalues_block(M_block_dimension);
      
      class array<double> eigenvalues_only_block(M_block_dimension);
      
      for (unsigned int ii = 0 ; ii < M_block_dimension ; ii++)
	{
	  eigenvalues_block(ii) = eigenvalues(index);
	  
	  eigenvalues_only_block(ii) = eigenvalues_only(index);
	  
	  index++;
	}
      
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Block " << i << endl;
      
      eigenpairs_full_matrix_test_hermitian (Mr_block , Mi_block , Pr_block , Pi_block , eigenvalues_block , eigenvalues_only_block , test_all);
    }
}














void double_test_hermitian (const unsigned int N , const bool is_it_diagonal , double &test_all)
{
  class matrix<double> Mr(N);
  class matrix<double> Mi(N);

  class array<double> eigenvalues(N);
  
  class array<double> eigenvalues_only(N);

  class array<double> diagonal_tab(N);
  
  diagonal_tab.random_array ();
  
  if (is_it_diagonal)
    {
      Mr = 0.0;
      Mi = 0.0;

      Mr.put_array_diagonal_part (diagonal_tab);
    }
  else
    {
      Mr.symmetric_random_matrix ();
      
      Mi.antisymmetric_random_matrix ();
    }

  class matrix<double> Pr = Mr;
  class matrix<double> Pi = Mi;

  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);

  if (!is_it_diagonal)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
      Mr.symmetric_random_matrix ();	       
      Mi.antisymmetric_random_matrix ();
      
      Mr += 0.46;
      Mi *= 0.13;
    
      class array<double> Mr_diagonal(N);
      
      for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
      for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;

      Mr.put_array_diagonal_part (Mr_diagonal);
      
      Mr /= 1E10;
      Mi /= 1E10;
      
      Pr = Mr;
      Pi = Mi;

      total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);
  
      Pr = Mr;
      Pi = Mi;
      
      total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);
      
      eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
  
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
      Pr = Mr;
      Pi = Mi;

      total_diagonalization::hermitian::all_eigenpairs_Newton (Pr , Pi , eigenvalues);

      eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
    }
}











void complex_test_hermitian (const unsigned int N , const bool is_it_diagonal , double &test_all)
{
  class matrix<complex<double> > M(N);

  class array<complex<double> > eigenvalues(N);
  
  class array<complex<double> > eigenvalues_only(N);

  
  if (is_it_diagonal)
    {
      class array<double> diagonal_r_tab(N);
    
      diagonal_r_tab.random_array ();
  
      const class array<complex<double> > diagonal_tab = complex_array<double , complex<double> > (diagonal_r_tab);
  
      M = 0.0;

      M.put_array_diagonal_part (diagonal_tab);
    }
  else
    M.hermitian_random_matrix ();

  class matrix<complex<double> > P = M;

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);

  if (!is_it_diagonal)
    {
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
      M.hermitian_random_matrix ();	 
      
      M += 0.46;
    
      class array<complex<double> > M_diagonal(N);
      
      for (unsigned int i = 0 ; i < N/2 ; i++) M_diagonal(i) = 1E10;
      for (unsigned int i = N/2 ; i < N ; i++) M_diagonal(i) = 2E10;

      M.put_array_diagonal_part (M_diagonal);
      
      M /= 1E10;
      
      P = M;
      
      total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
      P = M;

      total_diagonalization::all_eigenpairs (P , eigenvalues);
      
      eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);
   
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
      P = M;

      total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

      eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);
    }
}










void bicomplex_test_hermitian (const unsigned int N , const bool is_it_diagonal , double &test_all)
{
  class matrix<complex<double> > Mr(N);
  class matrix<complex<double> > Mi(N);

  class array<complex<double> > eigenvalues(N);
  
  class array<complex<double> > eigenvalues_only(N);

  class array<complex<double> > diagonal_tab(N);
    
  diagonal_tab.random_array ();
  
  if (is_it_diagonal)
    {
      Mr = 0.0;
      Mi = 0.0;
      
      Mr.put_array_diagonal_part (diagonal_tab);
    }
  else
    {
      Mr.symmetric_random_matrix ();
      
      Mi.antisymmetric_random_matrix ();

      Mr += complex<double> (1    , -0.46);
      Mi *= complex<double> (0.13 , -0.78);
    }

  class matrix<complex<double> > Pr = Mr;
  class matrix<complex<double> > Pi = Mi;

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;
      
  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);

  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
  
  if (!is_it_diagonal)
    {  
      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
      Mr.symmetric_random_matrix ();	       
      
      Mi.antisymmetric_random_matrix ();
      
      Mr += complex<double> (1    , -0.046);
      Mi *= complex<double> (0.13 , -0.078);
    
      class array<complex<double> > Mr_diagonal(N);
            
      for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
      for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;

      Mr.put_array_diagonal_part (Mr_diagonal);
      
      Mr /= 1E10;
      Mi /= 1E10;
      
      Pr = Mr;
      Pi = Mi;
      
      total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);
  
      Pr = Mr;
      Pi = Mi;

      total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);
      
      eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);

      if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;

      Pr = Mr;
      Pi = Mi;

      total_diagonalization::hermitian::all_eigenpairs_Newton (Pr , Pi , eigenvalues);
      
      eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
    }
}







void double_test_block_symmetric (const class array<unsigned int> &block_dimensions , double &test_all)
{
  const unsigned int N = block_dimensions.sum ();
  
  class block_matrix<double> M(block_dimensions);
  
  class array<double> eigenvalues(N);

  class array<double> eigenvalues_only(N);

  M.symmetric_random_matrix ();

  class block_matrix<double> P = M;

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
    
  class array<double> M_diagonal(N);
  
  for (unsigned int i = 0 ; i < N/2 ; i++) M_diagonal(i) = 1E10;
  for (unsigned int i = N/2 ; i < N ; i++) M_diagonal(i) = 2E10;
      
  M.symmetric_random_matrix ();	       
  
  M.put_array_diagonal_part (M_diagonal);
  
  M /= 1E10;
  
  P = M;

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);
  
  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
  P = M;

  total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);
  
  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);
}







void complex_test_block_symmetric (const class array<unsigned int> &block_dimensions , double &test_all)
{
  const unsigned int N = block_dimensions.sum ();
  
  class block_matrix<complex<double> > M(block_dimensions);

  class array<complex<double> > eigenvalues(N);

  class array<complex<double> > eigenvalues_only(N);

  class block_matrix<double> Mr(block_dimensions);
  class block_matrix<double> Mi(block_dimensions);
      
  Mr.symmetric_random_matrix ();
  Mi.symmetric_random_matrix ();
      
  Mi *= 0.1;
      
  M = complex_matrix<double,complex<double> > (Mr , Mi);

  class block_matrix<complex<double> > P = M;

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
      
  class array<double> Mr_diagonal(N);
  class array<double> Mi_diagonal(N);
      
  for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
  for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;
      
  for (unsigned int i = 0 ; i < N/2 ; i++) Mi_diagonal(i) = 5E4;
  for (unsigned int i = N/2 ; i < N ; i++) Mi_diagonal(i) = 1E10;
      
  Mr.symmetric_random_matrix ();	       
  Mi.symmetric_random_matrix ();
      
  Mr.put_array_diagonal_part (Mr_diagonal);
  Mi.put_array_diagonal_part (Mi_diagonal);

  Mr /= 1E10;
  Mi /= 1E10;
      
  M = complex_matrix<double,complex<double> > (Mr , Mi);

  P = M;
  
  total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);
      
  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
  P = M;

  total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

  eigenpairs_full_matrix_test_symmetric (M , P , eigenvalues , eigenvalues_only , test_all);
}






void double_test_block_hermitian (const class array<unsigned int> &block_dimensions , double &test_all)
{
  const unsigned int N = block_dimensions.sum ();
  
  class block_matrix<double> Mr(block_dimensions);
  class block_matrix<double> Mi(block_dimensions);

  class array<double> eigenvalues(N);

  class array<double> eigenvalues_only(N);

  Mr.symmetric_random_matrix ();
  
  Mi.antisymmetric_random_matrix ();

  class block_matrix<double> Pr = Mr;
  class block_matrix<double> Pi = Mi;

  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
  Mr.symmetric_random_matrix ();
  
  Mi.antisymmetric_random_matrix ();
      
  Mi *= 0.13;
    
  class array<double> Mr_diagonal(N);
      
  for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
  for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;

  Mr.put_array_diagonal_part (Mr_diagonal);
      
  Mr /= 1E10;
  Mi /= 1E10;
      
  Pr = Mr;
  Pi = Mi;
  
  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);
  
  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);
      
  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs_Newton (Pr , Pi , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
}










void complex_test_block_hermitian (const class array<unsigned int> &block_dimensions , double &test_all)
{
  const unsigned int N = block_dimensions.sum ();
  
  class block_matrix<complex<double> > M(block_dimensions);

  class array<complex<double> > eigenvalues(N);
  
  class array<complex<double> > eigenvalues_only(N);

  M.hermitian_random_matrix ();

  class block_matrix<complex<double> > P = M;

  total_diagonalization::all_eigenvalues (P , eigenvalues_only);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;

  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
  M.hermitian_random_matrix ();	 
    
  class array<complex<double> > M_diagonal(N);
      
  for (unsigned int i = 0 ; i < N/2 ; i++) M_diagonal(i) = 1E10;
  for (unsigned int i = N/2 ; i < N ; i++) M_diagonal(i) = 2E10;

  M.put_array_diagonal_part (M_diagonal);
      
  M /= 1E10;
      
  P = M;
  
  total_diagonalization::all_eigenvalues (P , eigenvalues_only);
  
  P = M;

  total_diagonalization::all_eigenpairs (P , eigenvalues);
      
  eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);
   
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;
  
  P = M;

  total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (M , P , eigenvalues , eigenvalues_only , test_all);
}





void bicomplex_test_block_hermitian (const class array<unsigned int> &block_dimensions , double &test_all)
{
  const unsigned int N = block_dimensions.sum ();
  
  class block_matrix<complex<double> > Mr(block_dimensions);
  class block_matrix<complex<double> > Mi(block_dimensions);

  class array<complex<double> > eigenvalues(N);
  class array<complex<double> > eigenvalues_only(N);

  Mr.symmetric_random_matrix ();
  Mi.antisymmetric_random_matrix ();

  class block_matrix<complex<double> > Pr = Mr;
  class block_matrix<complex<double> > Pi = Mi;

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix" << endl;
      
  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);

  Pr = Mr;
  Pi = Mi;

  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);

  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
  
  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues)" << endl;
            
  Mr.symmetric_random_matrix ();
  
  Mi.antisymmetric_random_matrix ();
      
  Mi *= complex<double> (0.13 , -0.078);
    
  class array<complex<double> > Mr_diagonal(N);
            
  for (unsigned int i = 0 ; i < N/2 ; i++) Mr_diagonal(i) = 1E10;
  for (unsigned int i = N/2 ; i < N ; i++) Mr_diagonal(i) = 2E10;

  Mr.put_array_diagonal_part (Mr_diagonal);
      
  Mr /= 1E10;
  Mi /= 1E10;
      
  Pr = Mr;
  Pi = Mi;
  
  total_diagonalization::hermitian::all_eigenvalues (Pr , Pi , eigenvalues_only);
  
  Pr = Mr;
  Pi = Mi;
  
  total_diagonalization::hermitian::all_eigenpairs (Pr , Pi , eigenvalues);
      
  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);

  if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Full matrix (close eigenvalues with Newton)" << endl;

  Pr = Mr;
  Pi = Mi;
  
  total_diagonalization::hermitian::all_eigenpairs_Newton (Pr , Pi , eigenvalues);
      
  eigenpairs_full_matrix_test_hermitian (Mr , Mi , Pr , Pi , eigenvalues , eigenvalues_only , test_all);
}










#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();    
   
    seed ();
    
    /* 
       {
       const unsigned int N = 1000;
       class matrix<double> M(N);
       M.symmetric_random_matrix ();
       class array<double> eigenvalues(N);
       total_diagonalization::all_eigenpairs_Lanczos (M , eigenvalues);
       return 0;
       }

       {
       OpenMP_parallelization_linear_algebra_enabled ();

       OpenMP_set_threads_number (4);

       //MPI_parallelization_linear_algebra_enabled ();

       const unsigned int N = 1000;

       class matrix<complex<double> > M(N);
      
       M.symmetric_random_matrix ();
     
       //for (unsigned int i = 0 ; i < N ; i++) M(i , i) += 100.0*(i + 1)/static_cast<double> (N);
            
       class matrix<complex<double> > P = M;

       class array<complex<double> > eigenvalues(N);
      
       //total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);

       total_diagonalization::all_eigenpairs_Lanczos (P , eigenvalues);
      
       class matrix<complex<double> > D(N);
       D = 0.0;
       for (unsigned int i = 0 ; i < N ; i++) D(i , i) = i%10 + 1E-8*random_number<complex<double> > ();
     
       M = transpose (P)*D*P;
       M.symmetrize ();
     
       P = M;
       total_diagonalization::all_eigenpairs_Newton (P , eigenvalues);
     
       if (THIS_PROCESS == MASTER_PROCESS) cout << "Minimal eigenvalue difference  : " << total_diagonalization::minimal_eigenvalue_difference_determine (eigenvalues) << endl;
            
       double P_precision_min = INFINITE;
     
       double P_precision_max = 0.0; 
     
       double P_precision_sum = 0.0;
       double P_precision_squares_sum = 0.0;
     
       for (unsigned int i = 0 ; i < N ; i++)
       {
       const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);

       const complex<double> eigenvalue = eigenvalues(i);

       const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;
	  
       const double P_precision = Res.infinite_norm ();

       P_precision_sum += P_precision;
	 
       P_precision_squares_sum += P_precision*P_precision;
     
       P_precision_min = min (P_precision_min , P_precision);
	 
       P_precision_max = max (P_precision_max , P_precision);
       }
      
       const double P_precision_average = P_precision_sum/N;
      
       const double P_precision_sigma = statistical_sigma_calc (N , P_precision_sum , P_precision_squares_sum);
	  
       if (THIS_PROCESS == MASTER_PROCESS)
       {
       cout << "Eigenvectors precision min     : " << P_precision_min     << endl;
       cout << "Eigenvectors precision max     : " << P_precision_max     << endl;
       cout << "Eigenvectors precision average : " << P_precision_average << endl;
       cout << "Eigenvectors precision sigma   : " << P_precision_sigma   << endl;
       }
     
       #ifdef UseMPI
       MPI_helper::Finalize ();
       #endif
    
       return 0;
       }
    */

    /*
      {
      OpenMP_parallelization_enabled ();

      OpenMP_set_threads_number (40);
       
      cout.precision (4);

      const unsigned int N_tries = 50;

      const unsigned int N_first = 100;
      
      const unsigned int Nmax = 1000;
      
      const unsigned int N_step = 50;
      
      const unsigned int N_number = (Nmax - N_first)/N_step + 1;
	  
      class array<class array<double> > Householder_time_diagonalization_tabs(N_number);
      class array<class array<double> > Lanczos_time_diagonalization_tabs(N_number);
      
      class array<class array<double> > Householder_precision_diagonalization_inf_norm_tabs(N_number);
      class array<class array<double> > Lanczos_precision_diagonalization_inf_norm_tabs(N_number);

      for (unsigned int N = N_first ; N <= Nmax ; N += N_step)
      {
      const unsigned int index = (N - N_first)/N_step;
	      
      class array<double> &Householder_time_diagonalization_tab = Householder_time_diagonalization_tabs(index);
      class array<double> &Lanczos_time_diagonalization_tab = Lanczos_time_diagonalization_tabs(index);
      
      class array<double> &Householder_precision_diagonalization_inf_norm_tab = Householder_precision_diagonalization_inf_norm_tabs(index);
      class array<double> &Lanczos_precision_diagonalization_inf_norm_tab = Lanczos_precision_diagonalization_inf_norm_tabs(index);
	      
      Householder_time_diagonalization_tab.allocate (N_tries);
      Lanczos_time_diagonalization_tab.allocate (N_tries);
      
      Householder_precision_diagonalization_inf_norm_tab.allocate (N_tries);
      Lanczos_precision_diagonalization_inf_norm_tab.allocate (N_tries);
      }
	  
      #ifdef UseOpenMP    
      #pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
      #endif
      for (unsigned int i_try = 0 ; i_try < N_tries ; i_try++)
      {            
      seed (i_try);
	        
      for (unsigned int N = N_first ; N <= Nmax ; N += N_step)
      {
      const unsigned int index = (N - N_first)/N_step;
	      
      class array<double> &Householder_time_diagonalization_tab = Householder_time_diagonalization_tabs(index);
	      
      class array<double> &Lanczos_time_diagonalization_tab = Lanczos_time_diagonalization_tabs(index);
      
      class array<double> &Householder_precision_diagonalization_inf_norm_tab = Householder_precision_diagonalization_inf_norm_tabs(index);

      class array<double> &Lanczos_precision_diagonalization_inf_norm_tab = Lanczos_precision_diagonalization_inf_norm_tabs(index);
	  
      class array<complex<double> > eigenvalues(N);

      class matrix<complex<double> > P(N);
	  
      class array<complex<double> > diagonal(N);

      class array<complex<double> > off_diagonal(N);	  

      diagonal.random_array ();

      diagonal -= complex<double> (0.5 , 0.5);

      off_diagonal.random_array ();

      off_diagonal -= complex<double> (0.5 , 0.5);

      off_diagonal(N-1) = 0.0;
	  
      class matrix<complex<double> > M(N);
	  
      M.symmetric_random_matrix ();

      M -= complex<double> (0.5 , 0.5);

      //M = complex_matrix<double , complex<double> > (real<double , complex<double> > (M) , 0.1*imag<double , complex<double> > (M));

      M *= 0.02;

      for (unsigned int i = 0 ; i < N ; i++) M(i,i) += 200.0*random_number<double> ();

      class matrix<complex<double> > M_copy = M;

      P = M;
      
      const double Householder_time_0 = absolute_time_determine ();

      total_diagonalization::symmetric::all_eigenpairs_Householder (P , eigenvalues);

      const double Householder_time_1 = absolute_time_determine ();

      const double Householder_time_diagonalization = Householder_time_1 - Householder_time_0;

      double Householder_precision_diagonalization_inf_norm = 0.0;

      for (unsigned int i = 0 ; i < N ; i++)
      {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);

      const complex<double> eigenvalue = eigenvalues(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;
	      
      Householder_precision_diagonalization_inf_norm = max (Householder_precision_diagonalization_inf_norm , Res.infinite_norm ());
      }
      
      M = M_copy;
	  
      P = M;
	  
      const double Lanczos_time_0 = absolute_time_determine ();
      
      total_diagonalization::symmetric::all_eigenpairs_Lanczos (P , eigenvalues);

      const double Lanczos_time_1 = absolute_time_determine ();

      const double Lanczos_time_diagonalization = Lanczos_time_1 - Lanczos_time_0;

      double Lanczos_precision_diagonalization_inf_norm = 0.0;

      for (unsigned int i = 0 ; i < N ; i++)
      {
      const class vector_class<complex<double> > &eigenvector = P.eigenvector (i);
		  
      const complex<double> eigenvalue = eigenvalues(i);

      const class vector_class<complex<double> > Res = M*eigenvector - eigenvalue*eigenvector;

      Lanczos_precision_diagonalization_inf_norm = max (Lanczos_precision_diagonalization_inf_norm ,  Res.infinite_norm ());
      }

      Householder_time_diagonalization_tab(i_try) = Householder_time_diagonalization;
	      
      Lanczos_time_diagonalization_tab(i_try) = Lanczos_time_diagonalization;
      
      Householder_precision_diagonalization_inf_norm_tab(i_try) = Householder_precision_diagonalization_inf_norm;

      Lanczos_precision_diagonalization_inf_norm_tab(i_try) = Lanczos_precision_diagonalization_inf_norm;
      }

      #ifdef UseOpenMP    
      #pragma omp critical
      #endif
      cout << "Try " << i_try << " done" << endl;	
      }

      cout << endl;
      
      for (unsigned int N = N_first ; N <= Nmax ; N += N_step)
      {
      const unsigned int index = (N - N_first)/N_step;
	  
      const class array<double> &Householder_time_diagonalization_tab = Householder_time_diagonalization_tabs(index);
	  
      const class array<double> &Lanczos_time_diagonalization_tab = Lanczos_time_diagonalization_tabs(index);
      
      const class array<double> &Householder_precision_diagonalization_inf_norm_tab = Householder_precision_diagonalization_inf_norm_tabs(index);

      const class array<double> &Lanczos_precision_diagonalization_inf_norm_tab = Lanczos_precision_diagonalization_inf_norm_tabs(index);
	      
      cout << N << "  "
      << Householder_time_diagonalization_tab.max () << "  "
      << Householder_precision_diagonalization_inf_norm_tab.max () << "    "
      << Lanczos_time_diagonalization_tab.max () << " "
      << Lanczos_precision_diagonalization_inf_norm_tab.max () << endl;
      }

      exit (1);
      }
    */
    
    double test_all = 0.0;

    for (unsigned int N = 0 ; N <= 10 ; N++)
      {
	if (THIS_PROCESS == MASTER_PROCESS) cout << "N : " << N << endl << endl;

	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Real symmetric (diagonal matrix): " << endl;

	double_test_symmetric (N , true , test_all);

	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex symmetric (diagonal matrix): " << endl;

	complex_test_symmetric (N , true , test_all);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Real symmetric : " << endl;

	double_test_symmetric (N , false , test_all);

	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex symmetric : " << endl;

	complex_test_symmetric (N , false , test_all);
        
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex Hermitian (real and imaginary parts separated) (diagonal case) : " << endl << endl;

	double_test_hermitian (N , true , test_all);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex Hermitian (diagonal case) : " << endl << endl;

	complex_test_hermitian (N , true , test_all);

	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Bicomplex Hermitian (diagonal case)  : " << endl;

	bicomplex_test_hermitian (N , true , test_all);
		
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex Hermitian (real and imaginary parts separated) : " << endl;

	double_test_hermitian (N , false , test_all);
	
	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex Hermitian : " << endl;

	complex_test_hermitian (N , false , test_all);

	if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Bicomplex Hermitian : " << endl;

	bicomplex_test_hermitian (N , false , test_all);
	
	if (test_all > 1E-7) error_message_print_abort ("Test too large : " + make_string<double> (test_all));
      }

    const unsigned int blocks_number = 5;

    class array<unsigned int> block_dimensions(blocks_number);

    for(unsigned int i = 0 ; i < blocks_number ; i++) block_dimensions(i) = i + 10;

    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Real block symmetric : " << endl;

    double_test_block_symmetric (block_dimensions , test_all);

    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex block symmetric : " << endl;

    complex_test_block_symmetric (block_dimensions , test_all);
	
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex Hermitian (real and imaginary parts separated) : " << endl << endl;

    double_test_block_hermitian (block_dimensions , test_all);
	
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Complex block Hermitian : " << endl;

    complex_test_block_hermitian (block_dimensions , test_all);
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Bicomplex block Hermitian : " << endl;

    bicomplex_test_block_hermitian (block_dimensions , test_all);
	
    if (test_all > 1E-7) error_message_print_abort ("Test too large : " + make_string<double> (test_all));
	
    if (THIS_PROCESS == MASTER_PROCESS) cout << endl << "Test of all calculations: " << test_all << endl << endl;
    	
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



