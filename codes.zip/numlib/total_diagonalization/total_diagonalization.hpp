#ifndef TOTALDIAGONALIZATION_HPP
#define TOTALDIAGONALIZATION_HPP


// Namespace of routines diagonalizing a real or complex symmetric matrix.
// -----------------------------------------------------------------------
// One can have tridiagonal or general matrices.
// One can have eigenvalues (semi diagonalization) or eigenvalues and eigenvectors (diagonalization).
// The method is to use the Householder or Lanczos method to put the matrix under tridiagonal form (if not already)
// and after use the QL diagonalization procedure with the tridiagonal matrix.
// Eigenvectors are normalized with the Berggren norm.
// Eigenvectors and eigenvalues are sorted according to the real part of the eigenvalues by default.
// Use eigenvalues_abs_sort or eigenpairs_abs_sort to sort according to the modulus of the eigenvalues.
// All matrices are normalized with respect to their infinite norm to stabilize calculations.
// Inverse iteration is used with a tridiagonal matrix if eigenvalues are not too close to each other in the complex case as it is faster than QL therein.
//
//
//
// Full matrices
// -------------
// Cost of calculation of eigenvalues only for large dimension N is around:
// 0.5 N^3 for Householder + QL (real)
// 1.5 N^3 for Lanczos     + QL (real)
// 1.5 N^3 for Householder + QL (complex)
// 5   N^3 for Lanczos     + QL (complex)
//
// Cost of calculation of eigenvalues and eigenvectors for large dimension N is around:
// 1.5 N^3 for Householder + QL (real)
// 2   N^3 for Lanczos     + QL (real)
// 5   N^3 for Householder + QL (complex)
// 7.5 N^3 for Lanczos     + QL (complex)
//
// The Householder method cannot be parallelized but the Lanczos method is, as matrix-vector multiplication is straightforward to parallelize.
// Parallelization is applied when linear algebra parallelization is enabled.
//
// Inverse iteration for tridiagonal matrices was used in these tests as degeneracy rarely occurs in practice.
//
//
//
// Householder + QL is used by default for real symmetric matrices as it is very stable.
//
// Lanczos is typically more stable than Householder for complex symmetric matrices.
// Hence it is always used for complex symmetric matrices by default except for dimension two as there Householder is exact.
// Full reorthogonalization is used to avoid numerical inaccuracies.
//
// Householder and Lanczos methods can be directly used for the real or complex case.
// For example, Householder is stable for matrices with equal eigenvalues up to numerical precision, while Lanczos cannot be used therein.
// Householder can be used in the complex case and eigenvalues only if one does not want to store an additional matrix, at the price of a lower precision.
//



// Namespace of routines diagonalizing a complex hermitian matrix.
// ---------------------------------------------------------------
// If SCALAR_TYPE = double: A = Ar + i.Ai complex hermitian with Ar symmetric and Ai antisymmetric real matrices
// One can have eigenvalues (semi diagonalization) or eigenvalues and eigenvectors (diagonalization).
// The method is to use the Householder or Lanczos method to put the matrix under tridiagonal form , 
// and after use the real symmetric diagonalization procedures for the tridiagonal matrix.
// Eigenvectors are normalized with the hermitian norm.
//
// If SCALAR_TYPE = complex<double>: the matrices Ar and Ai are complex , so that the above methods are analytically continued.
// A = Ar + i.Ai bicomplex hermitian with Ar symmetric and Ai antisymmetric complex matrices. The complex unit is then not the same in A = Ar + i.Ai (noted i) and in Ar, Ai (complex matrices).
// Eigenvectors and eigenvalues are sorted according to the real part of the eigenvalues.
// Use eigenpairs_abs_sort to sort according to the modulus of the eigenvalues.
//
//
//
// Householder + QL is used by default for complex hermitian matrices as it is very stable.
//
// Lanczos is typically more stable than Householder for bicomplex hermitian matrices.
// Hence it is always used for bicomplex hermitian matrices by default except for dimension two as there Householder is exact.
// Full reorthogonalization is used to avoid numerical inaccuracies.
//
// Householder and Lanczos methods can be directly used for the complex or bicomplex case.
// For example, Householder is stable for matrices with equal eigenvalues up to numerical precision, while Lanczos cannot be used therein.
// Householder can be used in the bicomplex case and eigenvalues only if one does not want to store an additional matrix, at the price of a lower precision.
//








namespace total_diagonalization
{
  namespace symmetric
  {
    template <typename SCALAR_TYPE>
    void orthogonalization_CGS (
				const unsigned int n , 
				class array<class vector_class<SCALAR_TYPE> > &Vn_work_tab ,
				class matrix<SCALAR_TYPE> &P);
  
    template <typename SCALAR_TYPE> 
    bool is_it_diagonal_tridiagonal_case_determine (const unsigned int N , const class array<SCALAR_TYPE> &off_diagonal);

    template <typename SCALAR_TYPE> 
    double inf_norm_tridiagonal_determine (
					   const class array<SCALAR_TYPE> &diagonal ,
					   const class array<SCALAR_TYPE> &off_diagonal);

    template <typename SCALAR_TYPE> 
    void tridiagonal_Lanczos (
			      class matrix<SCALAR_TYPE> &A , 
			      class array<SCALAR_TYPE> &diagonal , 
			      class array<SCALAR_TYPE> &off_diagonal);
  
    template <typename SCALAR_TYPE> 
    void tridiagonal_Householder (
				  const bool is_it_only_eigenvalues , 
				  class matrix<SCALAR_TYPE> &A , 
				  class array<SCALAR_TYPE> &diagonal , 
				  class array<SCALAR_TYPE> &off_diagonal);

    template <typename SCALAR_TYPE> 
    void QL_diagonalization (
			     const bool is_it_only_eigenvalues , 
			     const class array<SCALAR_TYPE> &diagonal , 
			     const class array<SCALAR_TYPE> &off_diagonal , 
			     class array<SCALAR_TYPE> &eigenvalues , 
			     class matrix<SCALAR_TYPE> &V);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs_tridiagonal_initial_basis (
						   const bool is_it_full_case , 
						   const bool is_it_inverse_iteration_only , 
						   const class array<SCALAR_TYPE> &off_diagonal , 
						   const class array<SCALAR_TYPE> &diagonal , 
						   class matrix<SCALAR_TYPE> &V ,
						   class array<SCALAR_TYPE> &eigenvalues);


    template <typename SCALAR_TYPE> 
    void eigenvector_tridiagonal_calc (
				       const class array<SCALAR_TYPE> &off_diagonal ,  
				       const class array<SCALAR_TYPE> &diagonal_shifted , 
				       class array<SCALAR_TYPE> &off_diagonal_work_table ,
				       class array<SCALAR_TYPE> &diagonal_work_table ,
				       class vector_class<SCALAR_TYPE> &Y ,
				       class vector_class<SCALAR_TYPE> &X);
    
    template <typename SCALAR_TYPE> 
    class vector_class<SCALAR_TYPE> eigenvector_tridiagonal_calc (
								  const SCALAR_TYPE eigenvalue , 
								  const double eigenvalue_shift , 
								  const class array<SCALAR_TYPE> &diagonal , 
								  const class array<SCALAR_TYPE> &off_diagonal);
  
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Householder (
				     class matrix<SCALAR_TYPE> &A ,
				     class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Lanczos (
				 class matrix<SCALAR_TYPE> &A ,
				 class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs (
			 class matrix<SCALAR_TYPE> &A ,
			 class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs (
			 const class array<SCALAR_TYPE> &off_diagonal , 
			 const class array<SCALAR_TYPE> &diagonal , 
			 class matrix<SCALAR_TYPE> &A , 
			 class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void eigenpair_inverse_iteration_refinement (
						 const double precision_inverse_iteration ,
						 const unsigned int i ,
						 const class matrix<SCALAR_TYPE> &A_copy ,
						 class matrix<SCALAR_TYPE> &A_eigenvalue_i , 
						 class matrix<SCALAR_TYPE> &P ,
						 class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Newton (
				class matrix<SCALAR_TYPE> &A , 
				class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs_inverse_iteration ( 
					   const class array<SCALAR_TYPE> &off_diagonal ,
					   const class array<SCALAR_TYPE> &diagonal , 
					   class matrix<SCALAR_TYPE> &A , 	 
					   class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Householder (
				      class matrix<SCALAR_TYPE> &A ,
				      class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Lanczos (
				  class matrix<SCALAR_TYPE> &A ,
				  class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenvalues (
			  class matrix<SCALAR_TYPE> &A ,
			  class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenvalues (
			  const class array<SCALAR_TYPE> &off_diagonal , 
			  const class array<SCALAR_TYPE> &diagonal , 
			  class array<SCALAR_TYPE> &eigenvalues);
  }

  namespace hermitian
  {
    template <typename SCALAR_TYPE>
    void orthogonalization_CGS (
				const unsigned int n , 
				class array<class vector_class<SCALAR_TYPE> > &Vn_rr_work_tab ,
				class array<class vector_class<SCALAR_TYPE> > &Vn_ri_work_tab ,
				class array<class vector_class<SCALAR_TYPE> > &Vn_ir_work_tab ,
				class array<class vector_class<SCALAR_TYPE> > &Vn_ii_work_tab ,
				class matrix<SCALAR_TYPE> &Pr , 
				class matrix<SCALAR_TYPE> &Pi);
  
    template <typename SCALAR_TYPE> 
    void eigenpairs_real_sort (
			       const int low ,
			       const int high , 
			       class matrix<SCALAR_TYPE> &Ar , 
			       class matrix<SCALAR_TYPE> &Ai , 
			       class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void eigenpairs_abs_sort (
			      const int low ,
			      const int high , 
			      class matrix<SCALAR_TYPE> &Ar , 
			      class matrix<SCALAR_TYPE> &Ai , 
			      class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void tridiagonal_Lanczos (
			      class matrix<SCALAR_TYPE> &Ar , 
			      class matrix<SCALAR_TYPE> &Ai , 
			      class array<SCALAR_TYPE> &diagonal , 
			      class array<SCALAR_TYPE> &off_diagonal);

    template <typename SCALAR_TYPE> 
    void tridiagonal_Householder (
				  class matrix<SCALAR_TYPE> &Ar , 
				  class matrix<SCALAR_TYPE> &Ai , 
				  class array<SCALAR_TYPE> &tau_1 , 
				  class array<SCALAR_TYPE> &tau_2 , 
				  class array<SCALAR_TYPE> &diagonal , 
				  class array<SCALAR_TYPE> &off_diagonal);

    template <typename SCALAR_TYPE> 
    void back_transform_eigenvectors (
				      const class matrix<SCALAR_TYPE> &Ar , 
				      const class matrix<SCALAR_TYPE> &Ai , 
				      const class array<SCALAR_TYPE> &tau_1 , 
				      const class array<SCALAR_TYPE> &tau_2 , 
				      class matrix<SCALAR_TYPE> &Vr , 
				      class matrix<SCALAR_TYPE> &Vi);
    
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Householder (
				     class matrix<SCALAR_TYPE> &Ar , 
				     class matrix<SCALAR_TYPE> &Ai , 
				     class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Lanczos (
				 class matrix<SCALAR_TYPE> &Ar , 
				 class matrix<SCALAR_TYPE> &Ai , 
				 class array<SCALAR_TYPE> &eigenvalues);

    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Newton (
				class matrix<SCALAR_TYPE> &Ar , 
				class matrix<SCALAR_TYPE> &Ai , 
				class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenpairs (
			 class matrix<SCALAR_TYPE> &Ar , 
			 class matrix<SCALAR_TYPE> &Ai , 
			 class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Householder (
				      class matrix<SCALAR_TYPE> &Ar , 
				      class matrix<SCALAR_TYPE> &Ai , 
				      class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Lanczos (
				  class matrix<SCALAR_TYPE> &Ar , 
				  class matrix<SCALAR_TYPE> &Ai , 
				  class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues (
			  class matrix<SCALAR_TYPE> &Ar , 
			  class matrix<SCALAR_TYPE> &Ai , 
			  class array<SCALAR_TYPE> &eigenvalues);
    
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Householder (
				     class block_matrix<SCALAR_TYPE> &Ar , 
				     class block_matrix<SCALAR_TYPE> &Ai , 			       
				     class array<SCALAR_TYPE> &eigenvalues);
    
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Newton (
				class block_matrix<SCALAR_TYPE> &Ar , 
				class block_matrix<SCALAR_TYPE> &Ai , 			       
				class array<SCALAR_TYPE> &eigenvalues);
    
    template <typename SCALAR_TYPE> 
    void all_eigenpairs_Lanczos (
				 class block_matrix<SCALAR_TYPE> &Ar , 
				 class block_matrix<SCALAR_TYPE> &Ai , 			       
				 class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenpairs (
			 class block_matrix<SCALAR_TYPE> &Ar , 
			 class block_matrix<SCALAR_TYPE> &Ai ,	        
			 class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Householder (
				      class block_matrix<SCALAR_TYPE> &Ar , 
				      class block_matrix<SCALAR_TYPE> &Ai , 				     
				      class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues_Lanczos (
				  class block_matrix<SCALAR_TYPE> &Ar , 
				  class block_matrix<SCALAR_TYPE> &Ai , 
				  class block_matrix<SCALAR_TYPE> &A , 				 
				  class array<SCALAR_TYPE> &eigenvalues);
  
    template <typename SCALAR_TYPE> 
    void all_eigenvalues (
			  class block_matrix<SCALAR_TYPE> &Ar , 
			  class block_matrix<SCALAR_TYPE> &Ai , 		 
			  class array<SCALAR_TYPE> &eigenvalues);
  }

  template <typename SCALAR_TYPE> 
  double minimal_eigenvalue_difference_determine (const class array<SCALAR_TYPE> &eigenvalues);

  template <typename SCALAR_TYPE> 
  void eigenvalues_real_sort (
			      const int low ,
			      const int high , 
			      class array<SCALAR_TYPE> &eigenvalues);

  template <typename SCALAR_TYPE> 
  void eigenvalues_abs_sort (
			     const int low ,
			     const int high , 
			     class array<SCALAR_TYPE> &eigenvalues);

  template <typename SCALAR_TYPE> 
  void eigenpairs_real_sort (
			     const int low ,
			     const int high , 
			     class matrix<SCALAR_TYPE> &A , 
			     class array<SCALAR_TYPE> &eigenvalues);

  template <typename SCALAR_TYPE> 
  void eigenpairs_abs_sort (
			    const int low ,
			    const int high , 
			    class matrix<SCALAR_TYPE> &A , 
			    class array<SCALAR_TYPE> &eigenvalues);

  void all_eigenpairs_Householder (
				   class matrix<double> &A , 				    
				   class array<double> &eigenvalues);
  
  void all_eigenpairs_Lanczos (
			       class matrix<double> &A , 			        
			       class array<double> &eigenvalues);

  void all_eigenpairs_Newton (
			      class matrix<double> &A , 			       
			      class array<double> &eigenvalues);
  
  void all_eigenpairs (
		       class matrix<double> &A , 		        
		       class array<double> &eigenvalues);
  
  void all_eigenvalues_Householder (
				    class matrix<double> &A , 				     
				    class array<double> &eigenvalues);
  
  void all_eigenvalues_Lanczos (
				class matrix<double> &A , 				 
				class array<double> &eigenvalues);
  
  void all_eigenvalues (
			class matrix<double> &A , 			 
			class array<double> &eigenvalues);
  
  void all_eigenpairs_Householder (
				   class matrix<complex<double> > &A , 				    
				   class array<complex<double> > &eigenvalues);
  
  void all_eigenpairs_Lanczos (
			       class matrix<complex<double> > &A , 			        
			       class array<complex<double> > &eigenvalues);

  void all_eigenpairs_Newton (
			      class matrix<complex<double> > &A , 			       
			      class array<complex<double> > &eigenvalues);
  
  void all_eigenpairs (
		       class matrix<complex<double> > &A , 		        
		       class array<complex<double> > &eigenvalues);
  
  void all_eigenvalues_Householder (
				    class matrix<complex<double> > &A , 				     
				    class array<complex<double> > &eigenvalues);
  
  void all_eigenvalues_Lanczos (
				class matrix<complex<double> > &A , 				 
				class array<complex<double> > &eigenvalues);
  
  void all_eigenvalues (
			class matrix<complex<double> > &A , 			 
			class array<complex<double> > &eigenvalues);

  template <typename SCALAR_TYPE> 
  void all_eigenpairs_Householder (
				   class block_matrix<SCALAR_TYPE> &A , 				    
				   class array<SCALAR_TYPE> &eigenvalues);
  
  template <typename SCALAR_TYPE> 
  void all_eigenpairs_Lanczos (
			       class block_matrix<SCALAR_TYPE> &A , 			        
			       class array<SCALAR_TYPE> &eigenvalues);

  template <typename SCALAR_TYPE> 
  void all_eigenpairs_Newton (
			      class block_matrix<SCALAR_TYPE> &A , 			       
			      class array<SCALAR_TYPE> &eigenvalues);
  
  template <typename SCALAR_TYPE> 
  void all_eigenpairs (
		       class block_matrix<SCALAR_TYPE> &A , 		        
		       class array<SCALAR_TYPE> &eigenvalues);
  
  template <typename SCALAR_TYPE> 
  void all_eigenvalues_Householder (
				    class block_matrix<SCALAR_TYPE> &A , 				     
				    class array<SCALAR_TYPE> &eigenvalues);
  
  template <typename SCALAR_TYPE> 
  void all_eigenvalues_Lanczos (
				class block_matrix<SCALAR_TYPE> &A , 				 
				class array<SCALAR_TYPE> &eigenvalues);
  
  template <typename SCALAR_TYPE> 
  void all_eigenvalues (
			class block_matrix<SCALAR_TYPE> &A , 			 
			class array<SCALAR_TYPE> &eigenvalues);
}





// Classical Gram-Schmidt orthogonalization of the n-th vector of a transformation matrix with respect to the previous ones.
// --------------------------------------------------------------------------------------------------------------------------------------
// Classical Gram-Schmidt orthogonalization is unstable unless overlaps are very small.
// Hence, it is used only with the Lanczos method, where overlaps are zero theoretically.
// Its fundamental advantage is that it can be easily parallelized.
//
// Conversely, one should use modified Gram-Schmidt orthogonalization when overlaps are not equal to zero theoretically, as in the Davidson method.
// However, parallelization cannot be used therein.

template <typename SCALAR_TYPE>
void total_diagonalization::symmetric::orthogonalization_CGS (
							      const unsigned int n , 
							      class array<class vector_class<SCALAR_TYPE> > &Vn_work_tab ,
							      class matrix<SCALAR_TYPE> &P)
{
  if (P.is_it_Cholesky_decomposed () || P.is_it_LU_decomposed ()) error_message_print_abort ("One cannot use total_diagonalization::symmetric::orthogonalization_CGS with LU/Cholesky decomposed matrices");
  
  const unsigned int N = P.get_dimension ();

  const unsigned int i_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (n , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int i_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (n , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (n - 1);

  const bool is_i_end_smaller_than_n = (i_end < n);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Vn_work_tab(i_thread) = 0.0;

  class vector_class<SCALAR_TYPE> &Vn_work_zero = Vn_work_tab(0);

  class vector_class<SCALAR_TYPE> &Vn = P.row_vector (n);

  if (is_i_end_smaller_than_n)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int i = i_debut ; i <= i_end ; i++) 
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  const class vector_class<SCALAR_TYPE> &Vi = P.row_vector (i);
      
	  const SCALAR_TYPE overlap = Vn*Vi;

	  class vector_class<SCALAR_TYPE> &Vn_work = Vn_work_tab(i_thread);

	  for (unsigned int j = 0 ; j < N ; j++) Vn_work(j) += overlap*Vi(j);
	}
    
      for (unsigned int i_thread = 1 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Vn_work_zero += Vn_work_tab(i_thread);
    }
  
#ifdef UseMPI
  if (is_it_MPI_parallelized_linear_algebra) Vn_work_zero.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
#endif

  Vn -= Vn_work_zero;
}



// Minimal norm difference between eigenvalues
// -------------------------------------------
// This value is used in order to know if one must use QL or inverse iteration to calculate eigenvectors.
// Eigenvalues must be ordered.
// INFINITE is arbitrarily returned if one has only one eigenvalue.
//
// Variables :
// -----------
// eigenvalues : eigenvalues must be ordered

template <typename SCALAR_TYPE> 
double total_diagonalization::minimal_eigenvalue_difference_determine (const class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = eigenvalues.dimension (0);

  double minimal_eigenvalue_difference = INFINITE;

  for (unsigned int i = 1 ; i < N ; i++)
    {
      const double minimal_eigenvalue_difference_try = inf_norm (eigenvalues(i) - eigenvalues(i - 1));
      
      if (minimal_eigenvalue_difference_try < minimal_eigenvalue_difference) minimal_eigenvalue_difference = minimal_eigenvalue_difference_try;
    }

  return minimal_eigenvalue_difference;
}







// Test if a tridiagonal matrix stored from its diagonal and off-diagonal arrays is diagonal
// -----------------------------------------------------------------------------------------
//
// Variables :
// -----------
// N: dimension of the matrix to diagonalize. 
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix. Its dimension can be N or N-1.

template <typename SCALAR_TYPE> 
bool total_diagonalization::symmetric::is_it_diagonal_tridiagonal_case_determine (const unsigned int N , const class array<SCALAR_TYPE> &off_diagonal)
{
  if (N == 0) return true;
  
  const unsigned int Nm1 = N - 1;
  
  for (unsigned int i = 0 ; i < Nm1 ; i++) 
    {
      if (off_diagonal(i) != 0.0) return false;
    }

  return true;
}







// Infinite norm of a tridiagonal matrix stored frim its diagonal and off-diagonal arrays
// --------------------------------------------------------------------------------------
//
// Variables :
// -----------
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// inf_norm_tridiagonal : infinite norm of the tridiagonal matrix

template <typename SCALAR_TYPE> 
double total_diagonalization::symmetric::inf_norm_tridiagonal_determine (
									 const class array<SCALAR_TYPE> &diagonal ,
									 const class array<SCALAR_TYPE> &off_diagonal)
{
  const unsigned int N = diagonal.dimension (0);

  const unsigned int Nm1 = N - 1;

  double inf_norm_tridiagonal = 0.0;

  for (unsigned int i = 0 ; i < N   ; i++) inf_norm_tridiagonal = max (inf_norm_tridiagonal , inf_norm (diagonal(i)));
  for (unsigned int i = 0 ; i < Nm1 ; i++) inf_norm_tridiagonal = max (inf_norm_tridiagonal , inf_norm (off_diagonal(i)));

  return inf_norm_tridiagonal;
}










// Sort of eigenvalues and/or eigenvectors.
// ----------------------------------------
// Quicksort is used to sort eigenvalues and/or eigenvectors.
// The sort is made with the real part or the modulus of eigenvalues.
//
// Variables :
// -----------
// low , high : boundaries used in Quicksort.
// pivot_eigenvalue : Quicksort pivot = real (eigenvalues((low + high)/2))
// eigenvalues : set of eigenvalues to sort.

template <typename SCALAR_TYPE> 
void total_diagonalization::eigenvalues_real_sort (
						   const int low ,
						   const int high , 
						   class array<SCALAR_TYPE> &eigenvalues)
{
  eigenvalues.quick_sort_by_real_part (low , high);
}







template <typename SCALAR_TYPE> 
void total_diagonalization::eigenvalues_abs_sort (
						  const int low ,
						  const int high , 
						  class array<SCALAR_TYPE> &eigenvalues)
{
  eigenvalues.quick_sort_by_abs (low , high);
}







template <typename SCALAR_TYPE> 
void total_diagonalization::eigenpairs_real_sort (
						  const int low ,
						  const int high , 
						  class matrix<SCALAR_TYPE> &A , 
						  class array<SCALAR_TYPE> &eigenvalues)
{
  const int pivot_index = low + (high - low)/2;
  
  int i_sort = low;
  int j_sort = high;

  const double pivot = real_dc (eigenvalues(pivot_index));
 
  do
    {
      while ((real_dc (eigenvalues(i_sort)) < pivot) && (abs (real_dc (eigenvalues(i_sort)) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (eigenvalues(j_sort)) > pivot) && (abs (real_dc (eigenvalues(j_sort)) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<SCALAR_TYPE> (eigenvalues(i_sort) , eigenvalues(j_sort));
	  
	  swap<class vector_class<SCALAR_TYPE> > (A.eigenvector(i_sort) , A.eigenvector(j_sort));
	  
	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) eigenpairs_real_sort (low , j_sort , A , eigenvalues);

  if (i_sort < high) eigenpairs_real_sort (i_sort , high , A , eigenvalues); 
}







template <typename SCALAR_TYPE> 
void total_diagonalization::eigenpairs_abs_sort (
						 const int low ,
						 const int high , 
						 class matrix<SCALAR_TYPE> &A , 
						 class array<SCALAR_TYPE> &eigenvalues)
{
  const int pivot_index = low + (high - low)/2;

  const double pivot = abs (eigenvalues(pivot_index));
  
  int i_sort = low;
  int j_sort = high;

  do
    {
      while ((abs (eigenvalues(i_sort)) < pivot) && (abs (abs (eigenvalues(i_sort)) - pivot) > 1E-14)) i_sort++;
      while ((abs (eigenvalues(j_sort)) > pivot) && (abs (abs (eigenvalues(j_sort)) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<SCALAR_TYPE> (eigenvalues(i_sort) , eigenvalues(j_sort));

	  swap<class vector_class<SCALAR_TYPE> > (A.eigenvector(i_sort) , A.eigenvector(j_sort));

	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) eigenpairs_abs_sort (low , j_sort , A , eigenvalues);

  if (i_sort < high) eigenpairs_abs_sort (i_sort , high , A , eigenvalues); 
}









// Tridiagonalization of a general symmetric matrix.
// -------------------------------------------------
// The Lanczos method is used here.
// It is generalized to the complex case.
// Full reorthogonalization is used to avoid numerical inaccuracies.
// The same random vector is used for all nodes in an MPI calculation so that they all have the same results numerically.
// It is recommended for complex matrices with well separated eigenvalues.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.
//
// Variables :
// -----------
// A : matrix to diagonalize. 
//     It contains at the end the matrix of transformation from the total matrix to the tridiagonal matrix.
// diagonal : It will contain at the end the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : It will contain at the end the off diagonal matrix elements of the tridiagonal matrix.


template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::tridiagonal_Lanczos (
							    class matrix<SCALAR_TYPE> &A , 
							    class array<SCALAR_TYPE> &diagonal , 
							    class array<SCALAR_TYPE> &off_diagonal)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("total_diagonalization::symmetric::tridiagonal_Lanczos is used with square matrices only");

  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in total_diagonalization::symmetric::tridiagonal_Lanczos");
  if (!A.isfinite ())        error_message_print_abort ("The matrix is not finite in total_diagonalization::symmetric::tridiagonal_Lanczos");

  const unsigned int N = A.get_dimension ();

  class matrix<SCALAR_TYPE> P(N);

  class array<class vector_class<SCALAR_TYPE> > Vi_work_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) Vi_work_tab(i_thread).allocate (N);

  class vector_class<SCALAR_TYPE> &V0 = P.row_vector (0);
  class vector_class<SCALAR_TYPE> &V1 = P.row_vector (1);

  V0.pseudo_real_random_vector ();
  
  V0.normalization ();
  
  class vector_class<SCALAR_TYPE> AV = A*V0;

  diagonal(0) = V0*AV;

  const SCALAR_TYPE &diagonal_zero = diagonal(0);
      
  for (unsigned int i = 0 ; i < N ; i++) V1(i) = AV(i) - diagonal_zero*V0(i);

  orthogonalization_CGS (1 , Vi_work_tab , P);

  V1.normalization ();

  off_diagonal(0) = V1*AV;

  AV = A*V1;

  diagonal(1) = V1*AV;

  off_diagonal(1) = 0.0;

  for (unsigned int i = 2 ; i < N ; i++)
    {
      const unsigned int im1 = i - 1;
      const unsigned int im2 = i - 2;
      
      const SCALAR_TYPE &diagonal_im1 = diagonal(im1);

      const SCALAR_TYPE &off_diagonal_im2 = off_diagonal(im2);
      
      const class vector_class<SCALAR_TYPE> &Vim2 = P.row_vector (im2);
      const class vector_class<SCALAR_TYPE> &Vim1 = P.row_vector (im1);

      class vector_class<SCALAR_TYPE> &Vi = P.row_vector (i);
      
      for (unsigned int ii = 0 ; ii < N ; ii++) Vi(ii) = AV(ii) - diagonal_im1*Vim1(ii) - off_diagonal_im2*Vim2(ii);
      
      orthogonalization_CGS (i , Vi_work_tab , P);
            
      Vi.normalization ();
      
      off_diagonal(im1) = Vi*AV;
      
      AV = A*Vi;

      diagonal(i) = Vi*AV;

      off_diagonal(i) = 0.0;
    }

  A = P;
}








// Tridiagonalization of a general symmetric matrix.
// -------------------------------------------------
// The Householder method is used here.
// It is generalized to the complex case.
// The two next routines are adaptations of the freely available FORTRAN Netlib routine tred2.
// It is stable for real symmetric matrices.
// It is possible to use Householder in the complex case to obtain all eigenvectors.
// It is typically relatively imprecise compared to the Lanczos-QL method by two orders of magnitude for complex symmetric matrices of moderate of large dimension, i.e. more than 100.
// However, it is recommended for complex matrices of small dimension, i.e. smaller than 100, and eigenvalues very close to each other.
//
// Variables :
// -----------
// A : matrix to diagonalize. 
//     It contains at the end the matrix of transformation from the total matrix to the tridiagonal matrix.
//
// diagonal : It will contain at the end the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : It will contain at the end the off diagonal matrix elements of the tridiagonal matrix.


template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::tridiagonal_Householder (
								const bool is_it_only_eigenvalues , 
								class matrix<SCALAR_TYPE> &A , 
								class array<SCALAR_TYPE> &diagonal , 
								class array<SCALAR_TYPE> &off_diagonal)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("total_diagonalization::symmetric::tridiagonal_Householder is used with square matrices only");
  
  if (!A.is_it_symmetric ()) error_message_print_abort ("The matrix is not symmetric in total_diagonalization::symmetric::tridiagonal_Householder");
  if (!A.isfinite ())        error_message_print_abort ("The matrix is not finite in total_diagonalization::symmetric::tridiagonal_Householder");

  const unsigned int N = A.get_dimension ();

  const unsigned int Nm1 = N - 1; 

  for (unsigned int i = 0 ; i < N ; i++) diagonal(i) = A(i , Nm1);

  for (unsigned int i = Nm1 ; i >= 1 ; i--)
    {
      const unsigned int im1 = i - 1;
      
      SCALAR_TYPE h = 0.0;

      SCALAR_TYPE &diagonal_i = diagonal(i);

      SCALAR_TYPE &off_diagonal_i = off_diagonal(i);

      class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

      if (i == 1) 
	{
	  off_diagonal_i = diagonal(im1);
	  
	  for (unsigned int j = 0 ; j < i ; j++)
	    {
	      diagonal(j) = A(j , im1);

	      Ai(j) = A(j , i) = 0.0;
	    }
	}
      else
	{
	  SCALAR_TYPE &diagonal_im1 = diagonal(im1);

	  double scale = 0.0;

	  for (unsigned int k = 0 ; k < i ; k++) scale += inf_norm (diagonal(k));

	  if (scale == 0.0) 
	    {
	      off_diagonal_i = diagonal_im1;
	      
	      for (unsigned int j = 0 ; j < i ; j++)
		{
		  diagonal(j) = A(j , im1);

		  Ai(j) = A(j , i) = 0.0;
		}
	    }
	  else
	    {	
	      for (unsigned int k = 0 ; k < i ; k++) 
		{
		  SCALAR_TYPE &diagonal_k = diagonal(k);

		  diagonal_k /= scale;

		  h += diagonal_k*diagonal_k;
		}

	      const SCALAR_TYPE sqrt_h = sqrt (h);
	      
	      const SCALAR_TYPE f = diagonal_im1;

	      const SCALAR_TYPE g = (inf_norm (f - sqrt_h) > inf_norm (f + sqrt_h)) ? (sqrt_h) : (-sqrt_h);

	      off_diagonal_i = g*scale;

	      h -= f*g;

	      diagonal_im1 = f - g;

	      const SCALAR_TYPE one_over_h = 1.0/h;
	      
	      for (unsigned int j = 0 ; j < i ; j++) off_diagonal(j) = 0.0;

	      for (unsigned int j = 0 ; j < i ; j++) 
		{
		  const unsigned int jp1 = j + 1;

		  const SCALAR_TYPE &diagonal_j = diagonal(j);
		  
		  SCALAR_TYPE &off_diagonal_j = off_diagonal(j);

		  const class vector_class<SCALAR_TYPE> &Aj = A.row_vector (j);
		  
		  SCALAR_TYPE gg = off_diagonal_j + Aj(j)*diagonal_j;
		  
		  Ai(j) = diagonal_j;

		  if (j < im1)
		    {
		      for (unsigned int k = jp1 ; k < i ; k++) 
			{
			  const SCALAR_TYPE &Ajk = Aj(k);

			  gg += Ajk*diagonal(k);

			  off_diagonal(k) += Ajk*diagonal_j;
			}
		    }
		    
		  off_diagonal_j = gg; 
		}
	 
	      SCALAR_TYPE ff = 0.0;
	      
	      for (unsigned int j = 0 ; j < i ; j++) 
		{
		  SCALAR_TYPE &off_diagonal_j = off_diagonal(j);

		  off_diagonal_j *= one_over_h;

		  ff += off_diagonal_j*diagonal(j);
		}

	      const SCALAR_TYPE hh = 0.5*ff*one_over_h;

	      for (unsigned int j = 0 ; j < i ; j++) off_diagonal(j) -= hh*diagonal(j);

	      for (unsigned int j = 0 ; j < i ; j++) 
		{
		  const SCALAR_TYPE &off_diagonal_j = off_diagonal(j);
		  
		  SCALAR_TYPE &diagonal_j = diagonal(j);
		  
		  class vector_class<SCALAR_TYPE> &Aj = A.row_vector (j);

		  for (unsigned int k = j ; k < i ; k++) Aj(k) -= diagonal_j*off_diagonal(k) + off_diagonal_j*diagonal(k);
		  
		  diagonal_j = Aj(im1);

		  Aj(i) = 0.0;
		}
	    }
	}
      
      diagonal_i = h;
    }

  off_diagonal(0) = 0.0;
  
  if (is_it_only_eigenvalues)
    {
      A.diagonal_part (diagonal);
    }
  else
    {
      for (unsigned int i = 1 ; i < N ; i++)
	{  
	  const unsigned int im1 = i - 1;

	  const SCALAR_TYPE &h = diagonal(i);

	  const class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  const class vector_class<SCALAR_TYPE> &A_im1 = A.row_vector (im1);

	  SCALAR_TYPE &A_im1_im1 = A_im1(im1);
      
	  A_im1(Nm1) = A_im1_im1;

	  A_im1_im1 = 1.0;

	  if (h != 0.0)
	    {
	      const SCALAR_TYPE one_over_h = 1.0/h;
      
	      for (unsigned int k = 0 ; k < i ; k++) diagonal(k) = Ai(k)*one_over_h;

	      for (unsigned int j = 0 ; j < i ; j++)
		{
		  const class vector_class<SCALAR_TYPE> &Aj = A.row_vector (j);

		  SCALAR_TYPE g = 0.0;

		  for (unsigned int k = 0 ; k < i ; k++) g += Ai(k)*Aj(k);
  
		  for (unsigned int k = 0 ; k < i ; k++) Aj(k) -= g*diagonal(k);
		}
		  
	      for (unsigned int k = 0 ; k < i ; k++) Ai(k) = 0.0;
	    }
	}

      for (unsigned int i = 0 ; i < Nm1 ; i++) 
	{
	  class vector_class<SCALAR_TYPE> &Ai = A.row_vector (i);

	  SCALAR_TYPE &Ai_Nm1 = Ai(Nm1);
      
	  diagonal(i) = Ai_Nm1;

	  Ai_Nm1 = 0.0;
	}

      SCALAR_TYPE &A_Nm1_Nm1 = A(Nm1 , Nm1);
      
      diagonal(Nm1) = A_Nm1_Nm1;

      A_Nm1_Nm1 = 1.0;
    }
}






// Diagonalization of a tridiagonal symmetric matrix.
// --------------------------------------------------
// The QL diagonalization with implicit shifts method is used here.
// This routine is an adaptation of the freely available FORTRAN Netlib routine imtql2.
// It is generalized to the complex case.
// Only eigenvalues or eigenvalues and eigenvectors can calculated in QL_diagonalization.
// It is stable for both real and complex symmetric matrices.
// However, diagonalization usually takes a long time for complex matrices due to additional complex multiplications.
// Shift-and-invert is preferred if eigenvalues are well separated.
//
// Variables :
// -----------
// V : Matrix which will contain eigenvectors in QL_diagonalization if eigenvectors are calculated.
//     In this case, it must contain the vectors of the initial basis used, in practice Householder vectors, Lanczos vectors, or unit vectors for initially tridiagonal matrices.
//     If no eigenvectors are calculated, A is dummy.
//
// diagonal, diagonal_work, eigenvalues : Array of the diagonal matrix elements of the tridiagonal matrix.
//                                        diagonal_work is a reference on the eigenvalues array.
//                                        Indeed, it contains the diagonal matrix elements at first and will contain at the end the eigenvalues of the tridiagonal matrix.
// off_diagonal, off_diagonal_work : Array of the off diagonal matrix elements of the tridiagonal matrix.
//                                   off_diagonal_work contains the off-diagonal matrix elements at first and is meaningless at the end.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::QL_diagonalization (
							   const bool is_it_only_eigenvalues , 
							   const class array<SCALAR_TYPE> &diagonal , 
							   const class array<SCALAR_TYPE> &off_diagonal , 
							   class array<SCALAR_TYPE> &eigenvalues , 
							   class matrix<SCALAR_TYPE> &V)
{   
  const unsigned int N = diagonal.dimension (0);

  eigenvalues = diagonal;

  class array<SCALAR_TYPE> &diagonal_work = eigenvalues;
  
  class array<SCALAR_TYPE> off_diagonal_work = off_diagonal;
      
  const unsigned int Nm1 = N - 1;
  
  for (unsigned int l = 0 ; l < N ; l++)
    { 
      unsigned int count = 0;
      
      while (true)
	{
	  unsigned int m = l;

	  while ((m < Nm1) && (inf_norm (off_diagonal_work(m))/(inf_norm (diagonal_work(m)) + inf_norm (diagonal_work(m + 1))) >= 1E-13)) m++;
	  
	  if (m == l) break;
	  
	  if (count++ == 30) error_message_print_abort ("No convergence in total_diagonalization::symmetric::QL_diagonalization");

	  if ((!finite (diagonal_work(m))) || (!finite (off_diagonal_work(m)))) error_message_print_abort ("Infinite numbers encountered in total_diagonalization::symmetric::QL_diagonalization");

	  const unsigned int lp1 = l + 1;
	      
	  SCALAR_TYPE &diagonal_work_l   = diagonal_work(l);	      
	  SCALAR_TYPE &diagonal_work_m   = diagonal_work(m);
	  SCALAR_TYPE &diagonal_work_lp1 = diagonal_work(lp1);
	      
	  SCALAR_TYPE &off_diagonal_work_l = off_diagonal_work(l);	      
	  SCALAR_TYPE &off_diagonal_work_m = off_diagonal_work(m);
	      
	  const SCALAR_TYPE e = (diagonal_work_lp1 - diagonal_work_l)/(2.0*off_diagonal_work_l);
	        
	  const SCALAR_TYPE he = hypot (1.0 , e);
	  
	  const SCALAR_TYPE e_plus_he  = e + he;
	  const SCALAR_TYPE e_minus_he = e - he;
	  
	  SCALAR_TYPE g = (inf_norm (e_plus_he) > inf_norm (e_minus_he)) ? (off_diagonal_work_l/e_plus_he) : (off_diagonal_work_l/e_minus_he);

	  g += diagonal_work_m - diagonal_work_l;
	  
	  unsigned int i = m - 1;

	  bool is_r_zero = false;

	  SCALAR_TYPE s = 1.0 , c = 1.0 , p = 0.0;

	  while ((i >= l) && (i < N) && !is_r_zero)
	    {
	      const unsigned int ip1 = i + 1;
		      
	      const SCALAR_TYPE &off_diagonal_work_i = off_diagonal_work(i);
		  
	      SCALAR_TYPE &off_diagonal_work_ip1 = off_diagonal_work(ip1);
		  
	      SCALAR_TYPE &diagonal_work_ip1 = diagonal_work(ip1);
	      
	      const SCALAR_TYPE f = s*off_diagonal_work_i;
	      		  
	      const SCALAR_TYPE r = hypot (f , g);
		  
	      is_r_zero = (r == 0.0);
	      
	      if (!is_r_zero)
		{		      
		  const SCALAR_TYPE &diagonal_work_i = diagonal_work(i);
		  		  
		  const SCALAR_TYPE b = c*off_diagonal_work_i;
		  
		  const SCALAR_TYPE one_over_r = 1.0/r;		      		  

		  off_diagonal_work_ip1 = r;
		      
		  s = f*one_over_r; 
		  c = g*one_over_r;

		  g = diagonal_work_ip1 - p;

		  const SCALAR_TYPE t = (diagonal_work_i - g)*s + 2.0*c*b;

		  p = s*t;

		  diagonal_work_ip1 = g + p; 

		  g = c*t - b;

		  if (!is_it_only_eigenvalues)
		    {
		      class vector_class<SCALAR_TYPE> &Vi = V.row_vector (i);

		      class vector_class<SCALAR_TYPE> &V_ip1 = V.row_vector (ip1);
			  
		      for (unsigned int k = 0 ; k < N ; k++)
			{
			  const SCALAR_TYPE V_ip1_k = V_ip1(k);
			  
			  const SCALAR_TYPE Vik = Vi(k);
			  
			  Vi   (k) = c*Vik - s*V_ip1_k;
			  V_ip1(k) = s*Vik + c*V_ip1_k;
			}
		    }
		  
		  i--;
		}
	      else 
		{		      
		  off_diagonal_work_ip1 = 0.0;
		      
		  diagonal_work_ip1 -= p;

		  off_diagonal_work_m = 0.0;
		}
	    }

	  if ((i < l) || !is_r_zero)
	    {
	      diagonal_work_l -= p;

	      off_diagonal_work_l = g;

	      off_diagonal_work_m = 0.0;
	    }
	}
    }
}




// Diagonalization of a general matrix.
// ------------------------------------
// Sorted eigenvalues and eigenvectors with the Householder/Lanczos + QL/inverse iteration method.
// The sort is made with the real part of eigenvalues.
// Real symmetric matrices are diagonalized with Householder + QL method or inverse iteration method.
// Complex symmetric matrices are diagonalized with the Lanczos + QL or inverse iteration method.
// Inverse iteration can be used only if eigenvalues are well separated, by more than 10^(-5) in practice.
// Inverse iteration is used for complex symmetric matrices as it is typically faster than QL.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.
//
// Variables :
// -----------
// A: matrix to diagonalize
//
// V : Matrix which will contain eigenvectors if eigenvectors are calculated.
//     It must contain the vectors of the initial basis used, in practice Householder vectors, Lanczos vectors, or unit vectors for initially tridiagonal matrices.
//
// P : Matrix of basis change: tridiagonal basis to canonical basis
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// N , Nm1 , A_infinite_norm : dimension of A , N-1 , infinite norm of A.
// minimal_eigenvalue_difference : smallest value of differences of eigenvalues to see if inverse iteration can be used to obtain eigenvectors.
// minimal_eigenvalue_difference_one_thousandth: minimal_eigenvalue_difference.10^(-3).
// eigenvalue_i , Re_eigenvalue_i  : eigenvalues(i), its real part
// smallest_abs_Re_eigenvalue_i_one: min (1 , |Re[eigenvalues[i]]|). It is used for the shift for inverse iteration, which must be smaller than 0.1 (see eigenvector_tridiagonal_calc).
//
// eigenvalue_shift, abs_eigenvalue_shift : value used to slightly change eigenvalues for inverse iteration and its modulus.
//                                          abs_eigenvalue_shift = min_{all eigenvalues} (|Re[eigenvalue]|.minimal_eigenvalue_difference.10^(-3) , 10^(-3)), so that abs_eigenvalue_shift <= 10^(-3).
//                                          eigenvalue_shift = sign (Re[eigenvalue]).abs_eigenvalue_shift. Then, adding eigenvalue_shift to eigenvalue makes the result slightly depart from the initial eigenvalue.
//
// eigenvalue_shifted: eigenvalue_i + eigenvalue_shift, for inverse iteration
//
// renormalized_matrix_trace_over_N: One supposes that ||A||oo = 1 here, i.e. that the renormalization A -> A/||A||oo has already been already done.
//                                   ||A||oo is given by infinite_norm (), so that it is not the spectral norm, but the maximal value of |A(i,j)| \forall(i,j).
//                                   The value renormalized_matrix_trace_over_N is equal to Tr(A)/N by definition.
//                                   The value z = Tr(A)/N minimizes \sum_i |lambda[i] - z|^2 \forall z, with lambda[i] the eigenvalues of A.
//                                   The A -> A - (Tr(A)/N).Id change just generates a constant shift of eigenvalues and leaves eigenvectors unchanged, so that diagonalizing A or A - (Tr(A)/N).Id are theoretically equivalent.
//                                   The eigenvalues of A - (Tr(A)/N).Id are closer to each other compared to those of A.
//                                   Hence, Tr(A)/N is removed from the diagonal of A in order to avoid to have min |lambda[i]| ~ 0 and max |lambda[i]| ~ 1 or larger.
//                                   Indeed, the latter situation can lead to a loss of precision when considering complex symmetric matrices.
//                                   The A -> A - (Tr(A)/N).Id change has never seen to make precision worse (that is one or several orders of magnitude larger).
//                                   Hence, it is always done. It has been checked in tests that this shift gives an overall better precision without creating local inaccuracies.
 
template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs_tridiagonal_initial_basis (
										 const bool is_it_full_case , 
										 const bool is_it_inverse_iteration_only , 
										 const class array<SCALAR_TYPE> &off_diagonal , 
										 const class array<SCALAR_TYPE> &diagonal , 
										 class matrix<SCALAR_TYPE> &V ,
										 class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = V.get_dimension ();

  QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , V);
      
  const double minimal_eigenvalue_difference = minimal_eigenvalue_difference_determine (eigenvalues);
  
  if (!is_it_inverse_iteration_only && (minimal_eigenvalue_difference < sqrt_precision))
    QL_diagonalization (false , diagonal , off_diagonal , eigenvalues , V);
  else
    {
      class matrix<SCALAR_TYPE> P;
	
      if (is_it_full_case)
	{
	  V.transpose ();
	  
	  P.allocate_fill (V);
	}

      const double minimal_eigenvalue_difference_one_thousandth = minimal_eigenvalue_difference*0.001;		  

      class array<SCALAR_TYPE> diagonal_shifted(N);
  
      class array<SCALAR_TYPE> off_diagonal_work_table = off_diagonal;
  
      class array<SCALAR_TYPE> diagonal_work_table = diagonal;
  
      class vector_class<SCALAR_TYPE> V_work(N);
  
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const SCALAR_TYPE &eigenvalue_i = eigenvalues(i);
	  
	  const double Re_eigenvalue_i = real_dc (eigenvalue_i);
	  	  
	  const double abs_eigenvalue_shift = min (abs (Re_eigenvalue_i)*minimal_eigenvalue_difference_one_thousandth , 0.001);
	  
	  const double eigenvalue_shift = SIGN (Re_eigenvalue_i)*abs_eigenvalue_shift;
	  
	  const SCALAR_TYPE eigenvalue_i_shifted = eigenvalue_i + eigenvalue_shift;
  
	  class vector_class<SCALAR_TYPE> &Vi = V.eigenvector(i);

	  diagonal_shifted = diagonal;
	  
	  diagonal_shifted -= eigenvalue_i_shifted;
	  
	  eigenvector_tridiagonal_calc (off_diagonal , diagonal_shifted , off_diagonal_work_table , diagonal_work_table , V_work , Vi);
	}
 
      if (is_it_full_case)
	{
	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      class vector_class<SCALAR_TYPE> &Vi = V.eigenvector(i);
	  
	      Vi = P*Vi;
	    }
	}    
    }
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      class vector_class<SCALAR_TYPE> &Vi = V.eigenvector(i);
	  
      Vi.good_phase ();
    }
}









// Eigenvector from inverse iteration in the tridiagonal case
// ----------------------------------------------------------
// The eigenvector associated to the eigenvalue eigenvalue is found by inverse iteration.
// One considers the matrix A tridiagonal symmetric , of values diagonal and off_diagonal.
// The shift of the eigenvalue must be smaller than 0.1 but larger than zero.
// If eigenvalues are very close, with a difference of less than 10^(-5) in absolute value, the method might not converge,
// A typically good value is 10^(-3) times the difference of the two closest eigenvalues in absolute value, or 10^(-3) if it is too large.
// The linear system AX = E[shifted].X + X normalization is iterated 15 times at most to insure convergence (15 iterations with a 0.1 shift => ~ 10^(-15) precision).
// It is stopped when its normalized solution X does not vary by more than 10^(-14).
// It is stable as long as the shifted eigenvalue is not too far from the the eigenvalue, without being equal to the eigenvalue.
// Hence, one always demands abs_eigenvalue_shift to be smaller than 0.1 and positive. The test is done with 0.1 + 10^(-15).
//
// Variables :
// -----------
// eigenvalue : eigenvalue of the eigenvector to find.
// eigenvalue_shift: value of the shift of the eigenvalue for A-E[shifted].I to be invertible. It is a double for simplicity.
// abs_eigenvalue_shift: |eigenvalue_shift|
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// diagonal_shifted : diagonal - eigenvalue_shifted
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// off_diagonal_work_table , diagonal_work_table : work arrays used in the Thomas algorithm (see tridiagonal_linear_system_solution_calc and Thomas_decompose)
// eigenvalue_shifted: eigenvalue + eigenvalue_shift
// count: number of iterations, which must be smaller than 15 (see above).
// N : dimension of the matrix
// X, Y, test : Solution of the linear system (A-I.E)X = Y, with Y = normalized X of the previous iteration. test is equal to |X - Y|oo. X is initialized randomly.
// maximal_loop_number : maximal number of loops if convergence is not obtained after loop_number iterations. It is fixed at 15.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::eigenvector_tridiagonal_calc (
								     const class array<SCALAR_TYPE> &off_diagonal ,  
								     const class array<SCALAR_TYPE> &diagonal_shifted , 
								     class array<SCALAR_TYPE> &off_diagonal_work_table ,
								     class array<SCALAR_TYPE> &diagonal_work_table ,
								     class vector_class<SCALAR_TYPE> &Y ,
								     class vector_class<SCALAR_TYPE> &X)
{
  const unsigned int N = X.get_dimension ();
  
  if (N == 1)
    {
      X(0) = 1.0;
      
      return;
    }
  
  const unsigned int maximal_loop_number = 15;  
    
  X.pseudo_real_random_vector ();

  X.normalization ();
  
  unsigned int count = 0;

  double test = INFINITE;
  
  do
    {      
      Y = X;
      
      tridiagonal_linear_system_solution_calc (off_diagonal , diagonal_shifted , off_diagonal , off_diagonal_work_table , diagonal_work_table , Y , X);
      
      X.normalization ();

      Y -= X;
      
      test = Y.infinite_norm ();
    }
  while ((test > 1E-14) && (count++ < maximal_loop_number));
    
  X.good_phase ();
}


template <typename SCALAR_TYPE> 
class vector_class<SCALAR_TYPE> total_diagonalization::symmetric::eigenvector_tridiagonal_calc (
												const SCALAR_TYPE eigenvalue , 
												const double eigenvalue_shift , 
												const class array<SCALAR_TYPE> &diagonal , 
												const class array<SCALAR_TYPE> &off_diagonal)
{
  const double abs_eigenvalue_shift = abs (eigenvalue_shift);
  
  if ((abs_eigenvalue_shift == 0.0) || (abs_eigenvalue_shift > 0.100000000000001))
    error_message_print_abort ("One must have 0 < |eigenvalue_shift| < 0.1 in total_diagonalization::symmetric::eigenvector_tridiagonal_calc");
  
  const unsigned int N = diagonal.dimension (0);
  
  const SCALAR_TYPE eigenvalue_shifted = eigenvalue + eigenvalue_shift;    

  const class array<SCALAR_TYPE> diagonal_shifted = diagonal - eigenvalue_shifted;
  
  class array<SCALAR_TYPE> off_diagonal_work_table = off_diagonal;
  
  class array<SCALAR_TYPE> diagonal_work_table = diagonal;
  
  class vector_class<SCALAR_TYPE> Y(N);
  class vector_class<SCALAR_TYPE> X(N);
  
  eigenvector_tridiagonal_calc (off_diagonal , diagonal_shifted , off_diagonal_work_table , diagonal_work_table , Y , X);

  return X;
}






template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs_Householder (
								   class matrix<SCALAR_TYPE> &A ,
								   class array<SCALAR_TYPE> &eigenvalues)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("total_diagonalization::symmetric::all_eigenpairs_Householder is used with square matrices only");

  const unsigned int N = A.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  if (A.is_it_diagonal ()) // The zero matrix case is included ...
    {
      A.diagonal_part (eigenvalues);

      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::symmetric::all_eigenpairs_Householder (diagonal case)");
  
      A.identity ();

      eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
  
      return;
    }
  
  const double A_infinite_norm = A.infinite_norm ();

  A /= A_infinite_norm;
  
  class array<SCALAR_TYPE> diagonal(N);
      
  class array<SCALAR_TYPE> off_diagonal(N);

  const SCALAR_TYPE renormalized_matrix_trace_over_N = A.trace ()/static_cast<double> (N);
      
  A.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
  
  tridiagonal_Householder (false , A , diagonal , off_diagonal);
      
  for (unsigned int i = 1 ; i < N ; i++) off_diagonal(i - 1) = off_diagonal(i);

  off_diagonal(Nm1) = 0.0;

  if (A.is_it_real ())
    {
      QL_diagonalization (false , diagonal , off_diagonal , eigenvalues , A);

      eigenvalues += renormalized_matrix_trace_over_N;
	  	  
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  class vector_class<SCALAR_TYPE> &Vi = A.eigenvector(i);
	  
	  Vi.good_phase ();
	}
    }
  else
    {
      all_eigenpairs_tridiagonal_initial_basis (true , false , off_diagonal , diagonal , A , eigenvalues);
      
      eigenvalues += renormalized_matrix_trace_over_N;
    }
  
  eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
  
  eigenvalues *= A_infinite_norm;
}





template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs_Lanczos (
							       class matrix<SCALAR_TYPE> &A ,
							       class array<SCALAR_TYPE> &eigenvalues)
{
  if (A.get_dimension_row () != A.get_dimension_column ()) error_message_print_abort ("total_diagonalization::symmetric::all_eigenpairs_Lanczos is used with square matrices only");

  const unsigned int N = A.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  if (A.is_it_diagonal ()) // The zero matrix case is included ...
    {
      A.diagonal_part (eigenvalues);

      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::symmetric::all_eigenpairs_Lanczos (diagonal case)");
      
      A.identity ();
      
      eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);

      return;
    }

  const double A_infinite_norm = A.infinite_norm ();
  
  A /= A_infinite_norm;

  class array<SCALAR_TYPE> diagonal(N);
  
  class array<SCALAR_TYPE> off_diagonal(N);
  
  const SCALAR_TYPE renormalized_matrix_trace_over_N = A.trace ()/static_cast<double> (N);
  
  A.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
  
  tridiagonal_Lanczos (A , diagonal , off_diagonal);
  
  all_eigenpairs_tridiagonal_initial_basis (true , false , off_diagonal , diagonal , A , eigenvalues);
  
  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
  
  eigenvalues *= A_infinite_norm;
}










// Diagonalization of a full matrix.
// ---------------------------------
// The Lanczos method is typically more stable than Householder for complex symmetric matrices.
// Hence it is always used for complex symmetric matrices by default except for dimension two as there Householder is exact.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs (
						       class matrix<SCALAR_TYPE> &A ,
						       class array<SCALAR_TYPE> &eigenvalues)
{
  if (A.is_it_real () || (A.get_dimension () == 2))
    all_eigenpairs_Householder (A , eigenvalues);
  else
    all_eigenpairs_Lanczos (A , eigenvalues);
}









// Diagonalization of a tridiagonal matrix.
// ----------------------------------------
// Sorted eigenvalues and eigenvectors with the QL method and inverse iteration.
// The sort is made with the real part of eigenvalues.
//
// Variables :
// -----------
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// diagonal_renormalized : Copy of diagonal renormalized to the infinite norm of the matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// off_diagonal_renormalized : Copy of off_diagonal renormalized to the infinite norm of the matrix.
// A : It will contain at the end the sorted normalized eigenvectors of the tridiagonal matrix.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs (
						       const class array<SCALAR_TYPE> &off_diagonal , 
						       const class array<SCALAR_TYPE> &diagonal , 
						       class matrix<SCALAR_TYPE> &A , 
						       class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = A.get_dimension ();
  
  if (N == 0) return;
  
  const unsigned int Nm1 = N - 1;
  
  A.identity ();

  if (is_it_diagonal_tridiagonal_case_determine (N , off_diagonal)) // The zero matrix case is included ...
    {
      eigenvalues = diagonal;

      eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);

      return;
    }
  
  const double inf_norm_tridiagonal = inf_norm_tridiagonal_determine (diagonal , off_diagonal);

  class array<SCALAR_TYPE> diagonal_renormalized(N);
  
  class array<SCALAR_TYPE> off_diagonal_renormalized(N);
  
  diagonal_renormalized = diagonal;
  
  diagonal_renormalized /= inf_norm_tridiagonal;
	
  off_diagonal_renormalized.assign (off_diagonal);
  
  off_diagonal_renormalized(Nm1) = 0.0;
  
  off_diagonal_renormalized /= inf_norm_tridiagonal;

  const SCALAR_TYPE renormalized_matrix_trace_over_N = diagonal_renormalized.sum ()/static_cast<double> (N);

  diagonal_renormalized -= renormalized_matrix_trace_over_N;
	  
  all_eigenpairs_tridiagonal_initial_basis (false , false , off_diagonal_renormalized , diagonal_renormalized , A , eigenvalues);

  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
      
  eigenvalues *= inf_norm_tridiagonal;
}











// Diagonalization of a full matrix with the Newton method
// -------------------------------------------------------
// One calculates firstly eigenvalues with the Householder +_QL method.
// One diagonalizes the matrix with the Lanczos + QL method afterwards if eigenvalues are not too close, i.e. by less than 10^(-12).
// One can consider than eigenvalues are different therein as the precision used in QL is 10^(-13).
// Otherwise, one uses Householder + QL for full diagonalization.
// Then, one uses the Newton method of Ogita, T., Aishima, K.: Iterative refinement for symmetric eigenvalue decomposition. Jpn. J. Ind. Appl. Math. 35(3), 1007–1035 (2018).
// I use max norm (infinite_norm () in the code) instead of the spectral hermitian norm for the calculation of omega (see referenced paper for the use of different norms). 
// Even though the use of max norm is not equivalent to that of the spectral hermitian norm, it was numerically checked that the use of max norm leads to converging results.
// I always normalize eigenvectors, so that R(i,i) = E(i,i) = 0 (notations of the referenced paper).
//
// A precision of 10^(-14) is demanded. One quits the Newton method after 5 iterations, as it usually converges quickly.
// If the Newton test is larger than the previous one, it means that the method no longer improves eigenpairs as the Newton method is supposed to converge quickly.
// One quits the Newton routine in this case, assuming that eigenpairs are sufficiently correct.
//
// The additional cost is about 4.N^3 multiplications per iteration, and one has about 3-5 iterations.
// Hence, the method costs about 15-20 N^3 multiplications, about 2-3 times more than Lanczos + QL.
// One also needs to store 4 additional matrices.
//
// The Newton method is fully parallelized for the O(N^3) operations (in particular matrix multiplications) except for:
// 1) The Householder + QL method, used if eigenvalues are closer than 10^(-12).
// 2) The QL method, used along with the Lanczos method for full diagonalization if eigenvalues are closer than 10^(-5).
// Hence, the Newton method is much slower if eigenvalues are closer than 10^(-5).
// Thus, this routine is not used by default.
//
// Variables :
// -----------
// N , Nm1 , A_infinite_norm : dimension of A , N - 1 , infinite norm of A.
// minimal_eigenvalue_difference : smallest value of differences of eigenvalues
// A_copy : copy of the matrix to diagonalize, denoted as A in other routines.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// Res : residue A.eigenvector - eigenvalue.eigenvector
// R , S , E: matrices used in the Newton method. Notations are the same as in the referenced paper, except for S, which becomes S -> S - D afterwards, with D the array of eigenvalues.
// M: work matrix to store M = A*B to avoid the temporaries induced by operator * with matrices
// P, P_transpose : Matrix of normalized eigenvectors to refine and its transpose. P_transpose is a reference to E as they are used independently.
// are_eigenvalues_close: true if the eigenvalues difference is smaller than omega, false if not
// count , maximal_loop_number : number and maximal number of loops if convergence is not obtained after loop_number iterations. The latter is fixed at 5.
// test_eigenvectors: test of eigenvectors calculated with Householder + QL or Lanczos + QL. It is the maximal value of all the supremum norms of eigenvector residues.
// omega: 2(||S||oo + ||R||oo) used to identify multiple eigenvalues (see referenced paper and above).
// test_Newton, tes_Newton_bef: test of the Newton method of the current and previous iterations. The test is the supremum norm of E.


template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs_Newton (
							      class matrix<SCALAR_TYPE> &A , 
							      class array<SCALAR_TYPE> &eigenvalues)
{ 
  const unsigned int N = A.get_dimension ();

  if (N == 0) return;
  
  const unsigned int Nm1 = N - 1;
  
  if (A.is_it_diagonal ()) // The zero matrix case is included ...
    {
      A.diagonal_part (eigenvalues);
      
      A.identity ();
      
      eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
      
      return;
    }
  
  const double A_infinite_norm = A.infinite_norm ();
  
  A /= A_infinite_norm;
    
  const class matrix<SCALAR_TYPE> A_copy = A;
  
  all_eigenvalues_Householder (A , eigenvalues);
  
  const double minimal_eigenvalue_difference = minimal_eigenvalue_difference_determine (eigenvalues);  
  
  A = A_copy;
  
  if (minimal_eigenvalue_difference < 1E-12)
    all_eigenpairs_Householder (A , eigenvalues);
  else  
    all_eigenpairs_Lanczos (A , eigenvalues);
  
  const unsigned int maximal_loop_number = 5;
  
  unsigned int count = 0;

  class matrix<SCALAR_TYPE> R(N) , S(N) , E(N) , M(N);
    
  double test_Newton     = INFINITE;
  double test_Newton_bef = INFINITE;
  
  class matrix<SCALAR_TYPE> &P_transpose = E;
  
  while ((test_Newton > 1E-14) && (count++ < maximal_loop_number))
    {
      P_transpose = A;      

      A.transpose ();
      
      class matrix<SCALAR_TYPE> &P = A;

      matrix_multiplication (P_transpose , A_copy , M);
      S = M;      

      matrix_multiplication (S , P , M);
      S = M;

      S.diagonal_part (eigenvalues);
      
      S.put_scalar_diagonal_part (0.0);
      
      R.identity ();
  
      matrix_multiplication (P_transpose , P , M);  
      R -= M;
      
      const double omega = 2.0*(R.infinite_norm () + S.infinite_norm ());
      
      E.put_scalar_diagonal_part (0.0);
  
      for (unsigned int i = 0 ; i < N ; i++)
	for (unsigned int j = 0 ; j < i ; j++)
	  {
	    const SCALAR_TYPE eigenvalue_i = eigenvalues(i);
	    const SCALAR_TYPE eigenvalue_j = eigenvalues(j);

	    const SCALAR_TYPE eigenvalue_difference = eigenvalue_j - eigenvalue_i;

	    const bool are_eigenvalues_close = (abs (eigenvalue_difference) <= omega);
	    
	    E(i , j) = (are_eigenvalues_close) ? (0.5*R(i , j)) : ( (S(i , j) + eigenvalue_j*R(i , j))/eigenvalue_difference);
 	    E(j , i) = (are_eigenvalues_close) ? (0.5*R(j , i)) : (-(S(j , i) + eigenvalue_i*R(j , i))/eigenvalue_difference);
	  }
      
      test_Newton_bef = test_Newton;
      
      test_Newton = E.infinite_norm ();
                  
      if (test_Newton < test_Newton_bef)
	{
	  matrix_multiplication (P , E , M);      
	  P += M;

	  A.transpose ();
      
	  for (unsigned int i = 0 ; i < N ; i++) A.eigenvector (i).normalization ();	
	}
      else
	{
	  A.transpose ();

	  break;
	}
    }
  
  eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);  
  
  eigenvalues *= A_infinite_norm;  
}




// Diagonalization of a tridiagonal matrix with inverse iteration
// --------------------------------------------------------------
// QL semi diagonalization is done to obtain eigenvalues.
// Inverse iteration then provides with eigenvectors.
//
// Variables :
// -----------
// A : It will contain at the end the sorted normalized eigenvectors of the total matrix.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// diagonal_renormalized : Copy of diagonal renormalized to the infinite norm of the matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// off_diagonal_renormalized : Copy of off_diagonal renormalized to the infinite norm of the matrix.
// N , Nm1 , A_infinite_norm : dimension of A , N - 1 , infinite norm of A.
// eigenvalue_shifted : eigenvalue changed by a small value for inverse iteration

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenpairs_inverse_iteration ( 
									 const class array<SCALAR_TYPE> &off_diagonal ,
									 const class array<SCALAR_TYPE> &diagonal , 
									 class matrix<SCALAR_TYPE> &A , 	 
									 class array<SCALAR_TYPE> &eigenvalues)
{ 
  const unsigned int N = A.get_dimension ();
  
  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  A.identity ();
  
  if (is_it_diagonal_tridiagonal_case_determine (N , off_diagonal)) // The zero matrix case is included ...
    {
      eigenvalues = diagonal;
      
      eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);

      return;
    }
  
  const double inf_norm_tridiagonal = inf_norm_tridiagonal_determine (diagonal , off_diagonal);
  
  class array<SCALAR_TYPE> diagonal_renormalized(N);
  
  class array<SCALAR_TYPE> off_diagonal_renormalized(N);
  
  diagonal_renormalized = diagonal;
  
  diagonal_renormalized /= inf_norm_tridiagonal;

  off_diagonal_renormalized.assign (off_diagonal);
  
  off_diagonal_renormalized(Nm1) = 0.0;
  
  off_diagonal_renormalized /= inf_norm_tridiagonal;

  const SCALAR_TYPE renormalized_matrix_trace_over_N = diagonal_renormalized.sum ()/static_cast<double> (N);
  
  diagonal_renormalized -= renormalized_matrix_trace_over_N;
  
  all_eigenpairs_tridiagonal_initial_basis (false , true , off_diagonal_renormalized , diagonal_renormalized , A , eigenvalues);
  
  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenpairs_real_sort (0 , Nm1 , A , eigenvalues);
      
  eigenvalues *= inf_norm_tridiagonal;
}















// Semi diagonalization of a general matrix.
// -----------------------------------------
// Sorted eigenvalues with the Householder (real) or Lanczos (complex) + QL method.
// The sort is made with the real part of eigenvalues.

//
// Variables :
// -----------
// A : Matrix to diagonalize. It is erased at the end of the calculation.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// N , Nm1 , A_infinite_norm : dimension of A , N - 1 , infinite norm of A.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenvalues_Householder (
								    class matrix<SCALAR_TYPE> &A ,
								    class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = A.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  if (A.is_it_diagonal ()) // The zero matrix case is included ...
    {
      A.diagonal_part (eigenvalues);
      
      eigenvalues_real_sort (0 , Nm1 , eigenvalues);

      return;
    }
  
  const double A_infinite_norm = A.infinite_norm ();

  A /= A_infinite_norm;

  class array<SCALAR_TYPE> diagonal(N);

  class array<SCALAR_TYPE> off_diagonal(N);

  const SCALAR_TYPE renormalized_matrix_trace_over_N = A.trace ()/static_cast<double> (N);
      
  A.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
      
  tridiagonal_Householder (true , A , diagonal , off_diagonal); 
  
  for (unsigned int i = 1 ; i < N ; i++) off_diagonal(i - 1) = off_diagonal(i);

  off_diagonal(Nm1) = 0.0;

  QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , A);
      
  eigenvalues += renormalized_matrix_trace_over_N;    

  eigenvalues *= A_infinite_norm;

  eigenvalues_real_sort (0 , Nm1 , eigenvalues);
}









// Semi diagonalization of a full matrix.
// -------------------------------------
// The Lanczos method is unstable with zero or very small (~machine precision) eigenvalues, so that it is better to use Householder in this case.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenvalues_Lanczos (
								class matrix<SCALAR_TYPE> &A ,
								class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = A.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  if (A.is_it_diagonal ()) // The zero matrix case is included ...
    {
      A.diagonal_part (eigenvalues);
      
      eigenvalues_real_sort (0 , Nm1 , eigenvalues);

      return;
    }
  
  const double A_infinite_norm = A.infinite_norm ();

  A /= A_infinite_norm;

  class array<SCALAR_TYPE> diagonal(N);

  class array<SCALAR_TYPE> off_diagonal(N);

  const SCALAR_TYPE renormalized_matrix_trace_over_N = A.trace ()/static_cast<double> (N);
      
  A.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
      
  tridiagonal_Lanczos (A , diagonal , off_diagonal);

  QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , A);

  eigenvalues += renormalized_matrix_trace_over_N;      

  eigenvalues *= A_infinite_norm;

  eigenvalues_real_sort (0 , Nm1 , eigenvalues);
}





template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenvalues (
							class matrix<SCALAR_TYPE> &A ,
							class array<SCALAR_TYPE> &eigenvalues)
{  
  if (A.is_it_real ())
    all_eigenvalues_Householder (A , eigenvalues);
  else
    all_eigenvalues_Lanczos (A , eigenvalues);
}




// Semi diagonalization of a tridiagonal matrix.
// ---------------------------------------------
// Sorted eigenvalues with the QL method.
// The sort is made with the real part of eigenvalues.
//
// Variables :
// -----------
// diagonal : Array of the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.
// off_diagonal_renormalized : Copy of off_diagonal renormalized to the infinite norm of the matrix.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.

template <typename SCALAR_TYPE> 
void total_diagonalization::symmetric::all_eigenvalues (
							const class array<SCALAR_TYPE> &off_diagonal , 
							const class array<SCALAR_TYPE> &diagonal , 
							class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int N = diagonal.dimension (0);

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
    
  if (is_it_diagonal_tridiagonal_case_determine (N , off_diagonal)) // The zero matrix case is included ...
    {
      eigenvalues = diagonal;
      
      eigenvalues_real_sort (0 , Nm1 , eigenvalues);

      return;
    }
  
  const double inf_norm_tridiagonal = inf_norm_tridiagonal_determine (diagonal , off_diagonal);
  
  class array<SCALAR_TYPE> diagonal_renormalized(N);
  
  class array<SCALAR_TYPE> off_diagonal_renormalized(N);
  
  diagonal_renormalized = diagonal;
  
  diagonal_renormalized /= inf_norm_tridiagonal;

  off_diagonal_renormalized.assign (off_diagonal);
  
  off_diagonal_renormalized(Nm1) = 0.0;
  
  off_diagonal_renormalized /= inf_norm_tridiagonal;

  const SCALAR_TYPE renormalized_matrix_trace_over_N = diagonal_renormalized.sum ()/static_cast<double> (N);
  
  class matrix<SCALAR_TYPE> dummy_matrix;
  
  diagonal_renormalized -= renormalized_matrix_trace_over_N;
  
  QL_diagonalization (true , diagonal_renormalized , off_diagonal_renormalized , eigenvalues , dummy_matrix);
  
  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenvalues *= inf_norm_tridiagonal;
  
  eigenvalues_real_sort (0 , Nm1 , eigenvalues);
}



template <typename SCALAR_TYPE>
void total_diagonalization::hermitian::orthogonalization_CGS (
							      const unsigned int n , 
							      class array<class vector_class<SCALAR_TYPE> > &Vn_rr_work_tab ,
							      class array<class vector_class<SCALAR_TYPE> > &Vn_ri_work_tab ,
							      class array<class vector_class<SCALAR_TYPE> > &Vn_ir_work_tab ,
							      class array<class vector_class<SCALAR_TYPE> > &Vn_ii_work_tab ,
							      class matrix<SCALAR_TYPE> &Pr , 
							      class matrix<SCALAR_TYPE> &Pi)
{
  if (Pr.is_it_Cholesky_decomposed () || Pr.is_it_LU_decomposed () || Pi.is_it_Cholesky_decomposed () || Pi.is_it_LU_decomposed ())
    error_message_print_abort ("One cannot use total_diagonalization::hermitian::orthogonalization_CGS with LU/Cholesky decomposed matrices");
  
  const unsigned int N = Pr.get_dimension ();

  const unsigned int i_debut = (is_it_MPI_parallelized_linear_algebra) ? (basic_first_index_determine_for_MPI (n , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (0);
  const unsigned int i_end   = (is_it_MPI_parallelized_linear_algebra) ? (basic_last_index_determine_for_MPI  (n , NUMBER_OF_PROCESSES , THIS_PROCESS)) : (n - 1);

  const bool is_i_end_smaller_than_n = (i_end < n);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) 
    {
      Vn_rr_work_tab(i_thread) = 0.0;
      Vn_ri_work_tab(i_thread) = 0.0;
      Vn_ir_work_tab(i_thread) = 0.0;
      Vn_ii_work_tab(i_thread) = 0.0;
    }

  class vector_class<SCALAR_TYPE> &Vn_rr_work_zero = Vn_rr_work_tab(0);
  class vector_class<SCALAR_TYPE> &Vn_ri_work_zero = Vn_ri_work_tab(0);
  class vector_class<SCALAR_TYPE> &Vn_ir_work_zero = Vn_ir_work_tab(0);
  class vector_class<SCALAR_TYPE> &Vn_ii_work_zero = Vn_ii_work_tab(0);

  class vector_class<SCALAR_TYPE> &Vn_r = Pr.row_vector (n);
  class vector_class<SCALAR_TYPE> &Vn_i = Pi.row_vector (n);
  
  if (is_i_end_smaller_than_n)
    {
#ifdef UseOpenMP    
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized_linear_algebra)
#endif
      for (unsigned int i = i_debut ; i <= i_end ; i++) 
	{
	  const unsigned int i_thread = OpenMP_thread_number_determine ();

	  const class vector_class<SCALAR_TYPE> &Vi_r = Pr.row_vector (i);
	  const class vector_class<SCALAR_TYPE> &Vi_i = Pi.row_vector (i);
	      
	  const SCALAR_TYPE overlap_r = Vi_r*Vn_r + Vi_i*Vn_i;
	  const SCALAR_TYPE overlap_i = Vi_r*Vn_i - Vi_i*Vn_r;
	      
	  class vector_class<SCALAR_TYPE> &Vn_rr_work = Vn_rr_work_tab(i_thread);
	  class vector_class<SCALAR_TYPE> &Vn_ri_work = Vn_ri_work_tab(i_thread);
	  class vector_class<SCALAR_TYPE> &Vn_ir_work = Vn_ir_work_tab(i_thread);
	  class vector_class<SCALAR_TYPE> &Vn_ii_work = Vn_ii_work_tab(i_thread);

	  for (unsigned int j = 0 ; j < N ; j++)
	    {
	      Vn_rr_work(j) += overlap_r*Vi_r(j);
	      Vn_ri_work(j) += overlap_r*Vi_i(j);
	      Vn_ir_work(j) += overlap_i*Vi_r(j);
	      Vn_ii_work(j) += overlap_i*Vi_i(j);
	    }
	}
      
      for (unsigned int i_thread = 1 ; i_thread < NUMBER_OF_THREADS ; i_thread++) 
	{
	  Vn_rr_work_zero += Vn_rr_work_tab(i_thread);
	  Vn_ri_work_zero += Vn_ri_work_tab(i_thread);
	  Vn_ir_work_zero += Vn_ir_work_tab(i_thread);
	  Vn_ii_work_zero += Vn_ii_work_tab(i_thread);
	}
    }
  
#ifdef UseMPI
  
  if (is_it_MPI_parallelized_linear_algebra) 
    {
      Vn_rr_work_zero.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      Vn_ri_work_zero.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      Vn_ir_work_zero.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
      Vn_ii_work_zero.MPI_Allreduce (MPI_SUM , MPI_COMM_WORLD);
    }
  
#endif

  Vn_r -= Vn_rr_work_zero;
  Vn_r += Vn_ii_work_zero;
      
  Vn_i -= Vn_ri_work_zero;
  Vn_i -= Vn_ir_work_zero;
}






// Sort of eigenvalues and eigenvectors.
// -------------------------------------
// Quicksort is used to sort eigenvalues and/or eigenvectors.
// The sort is made with the real part of eigenvalues.
//
// Variables :
// -----------
// low , high : boundaries used in Quicksort.
// pivot : Quicksort pivot = real (eigenvalues((low + high)/2))
// eigenvalues : set of eigenvalues to sort.


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::eigenpairs_real_sort (
							     const int low ,
							     const int high , 
							     class matrix<SCALAR_TYPE> &Ar , 
							     class matrix<SCALAR_TYPE> &Ai , 
							     class array<SCALAR_TYPE> &eigenvalues)
{
  int i_sort = low;
  int j_sort = high;

  const unsigned int pivot_index = (i_sort + j_sort)/2;

  const double pivot = real_dc (eigenvalues(pivot_index));
  
  do
    {
      while ((real_dc (eigenvalues(i_sort)) < pivot) && (abs (real_dc (eigenvalues(i_sort)) - pivot) > 1E-14)) i_sort++;
      while ((real_dc (eigenvalues(j_sort)) > pivot) && (abs (real_dc (eigenvalues(j_sort)) - pivot) > 1E-14)) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap<SCALAR_TYPE> (eigenvalues(i_sort) , eigenvalues(j_sort));

	  swap<class vector_class<SCALAR_TYPE> > (Ar.eigenvector(i_sort) , Ar.eigenvector(j_sort));
	  swap<class vector_class<SCALAR_TYPE> > (Ai.eigenvector(i_sort) , Ai.eigenvector(j_sort));

	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) eigenpairs_real_sort (low , j_sort , Ar , Ai , eigenvalues);

  if (i_sort < high) eigenpairs_real_sort (i_sort , high , Ar , Ai , eigenvalues); 
}






// Tridiagonalization of a general symmetric matrix.
// -------------------------------------------------
// The Lanczos method is used here.
// It is generalized to the complex case.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.
//
// Variables :
// -----------
// Ar , Ai : matrices to diagonalize. Ar is the symmetric part and Ai is the antisymmetric part (A = Ar + i.Ai for complex hermitian case). 
//           Ar and Ai contain at the end the matrix of transformation from the total matrix to the tridiagonal matrix.
// diagonal : It will contain at the end the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : It will contain at the end the off diagonal matrix elements of the tridiagonal matrix.


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::tridiagonal_Lanczos (
							    class matrix<SCALAR_TYPE> &Ar , 
							    class matrix<SCALAR_TYPE> &Ai , 
							    class array<SCALAR_TYPE> &diagonal , 
							    class array<SCALAR_TYPE> &off_diagonal)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::tridiagonal_Lanczos is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::tridiagonal_Lanczos is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::tridiagonal_Lanczos (real part)");
  if (!Ai.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::tridiagonal_Lanczos (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in total_diagonalization::hermitian::tridiagonal_Lanczos");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in total_diagonalization::hermitian::tridiagonal_Lanczos");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::tridiagonal_Lanczos");
  
  const unsigned int N = Ar.get_dimension (); 

  class matrix<SCALAR_TYPE> Pr(N);
  class matrix<SCALAR_TYPE> Pi(N);

  class array<vector_class<SCALAR_TYPE> > Vj_rr_work_tab(NUMBER_OF_THREADS);
  class array<vector_class<SCALAR_TYPE> > Vj_ri_work_tab(NUMBER_OF_THREADS);
  class array<vector_class<SCALAR_TYPE> > Vj_ir_work_tab(NUMBER_OF_THREADS);
  class array<vector_class<SCALAR_TYPE> > Vj_ii_work_tab(NUMBER_OF_THREADS);

  for (unsigned int i_thread = 0 ; i_thread < NUMBER_OF_THREADS ; i_thread++) 
    {
      Vj_rr_work_tab(i_thread).allocate (N);
      Vj_ri_work_tab(i_thread).allocate (N);
      Vj_ir_work_tab(i_thread).allocate (N);
      Vj_ii_work_tab(i_thread).allocate (N);
    }

  class vector_class<SCALAR_TYPE> &V0_r = Pr.row_vector (0) , &V0_i = Pi.row_vector (0);
  class vector_class<SCALAR_TYPE> &V1_r = Pr.row_vector (1) , &V1_i = Pi.row_vector (1);

  V0_r.pseudo_real_random_vector ();

  V0_r.normalization ();
   
  V0_i = 0.0;

  class vector_class<SCALAR_TYPE> AVr = Ar*V0_r;
  class vector_class<SCALAR_TYPE> AVi = Ai*V0_r;

  diagonal(0) = V0_r*AVr + V0_i*AVi;

  const SCALAR_TYPE diagonal_zero = diagonal(0);

  for (unsigned int j = 0 ; j < N ; j++)
    {
      V1_r(j) = AVr(j) - diagonal_zero*V0_r(j);
      V1_i(j) = AVi(j) - diagonal_zero*V0_i(j);
    }
  
  orthogonalization_CGS (1 , Vj_rr_work_tab , Vj_ri_work_tab , Vj_ir_work_tab , Vj_ii_work_tab , Pr , Pi);

  const SCALAR_TYPE V1_norm = sqrt (V1_r*V1_r + V1_i*V1_i);

  V1_r /= V1_norm;
  V1_i /= V1_norm;

  off_diagonal(0) = V1_r*AVr + V1_i*AVi;

  AVr  = Ar*V1_r;
  AVr -= Ai*V1_i;
  AVi =  Ar*V1_i;
  AVi += Ai*V1_r;
  
  diagonal(1) = V1_r*AVr + V1_i*AVi;

  off_diagonal(1) = 0.0;

  for (unsigned int j = 2 ; j < N ; j++)
    {
      const unsigned int jm1 = j - 1;
      const unsigned int jm2 = j - 2;
      
      const SCALAR_TYPE &diagonal_jm1 = diagonal(jm1);

      const SCALAR_TYPE &off_diagonal_jm2 = off_diagonal(jm2);

      const class vector_class<SCALAR_TYPE> &Vjm2_r = Pr.row_vector (jm2) , &Vjm2_i = Pi.row_vector (jm2);
      const class vector_class<SCALAR_TYPE> &Vjm1_r = Pr.row_vector (jm1) , &Vjm1_i = Pi.row_vector (jm1);
      
      class vector_class<SCALAR_TYPE> &Vj_r = Pr.row_vector (j);
      class vector_class<SCALAR_TYPE> &Vj_i = Pi.row_vector (j);

      for (unsigned int jj = 0 ; jj < N ; jj++)
	{
	  Vj_r(jj) = AVr(jj) - diagonal_jm1*Vjm1_r(jj) - off_diagonal_jm2*Vjm2_r(jj);      
	  Vj_i(jj) = AVi(jj) - diagonal_jm1*Vjm1_i(jj) - off_diagonal_jm2*Vjm2_i(jj);
	}
      
      orthogonalization_CGS (j , Vj_rr_work_tab , Vj_ri_work_tab , Vj_ir_work_tab , Vj_ii_work_tab , Pr , Pi);

      const SCALAR_TYPE Vj_norm = sqrt (Vj_r*Vj_r + Vj_i*Vj_i);

      Vj_r /= Vj_norm;
      Vj_i /= Vj_norm;

      off_diagonal(jm1) = Vj_r*AVr + Vj_i*AVi;
      
      AVr  = Ar*Vj_r;
      AVr -= Ai*Vj_i;
      AVi =  Ar*Vj_i;
      AVi += Ai*Vj_r;
        
      diagonal(j) = Vj_r*AVr + Vj_i*AVi;
      
      off_diagonal(j) = 0.0;
    }

  Ar = Pr;
  Ai = Pi;
}






// Tridiagonalization of a general symmetric matrix.
// -------------------------------------------------
// The Householder method is used here.
// It is generalized to the complex case.
// The routine is an adaptation of the freely available FORTRAN Netlib routine htridi.
//
// Variables :
// -----------
// Ar , Ai : Ar is the symmetric part and Ai is the antisymmetric part of the (Ar , Ai) operator (Ar + i.Ai for real hermitian case). 
//           Ar and Ai contain at the end the matrix of transformation from the total matrix to the tridiagonal matrix.
// tau_1 , tau_2 : helper arrays for matrix transformation
// diagonal : It will contain at the end the diagonal matrix elements of the tridiagonal matrix.
// off_diagonal : It will contain at the end the off diagonal matrix elements of the tridiagonal matrix.


template <typename SCALAR_TYPE>
void total_diagonalization::hermitian::tridiagonal_Householder (
								class matrix<SCALAR_TYPE> &Ar , 
								class matrix<SCALAR_TYPE> &Ai , 
								class array<SCALAR_TYPE> &tau_1 , 
								class array<SCALAR_TYPE> &tau_2 , 
								class array<SCALAR_TYPE> &diagonal , 
								class array<SCALAR_TYPE> &off_diagonal)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::tridiagonal_Lanczos is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::tridiagonal_Lanczos is used with square matrices only (imaginary part)");

  if (!Ar.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::tridiagonal_Lanczos (real part)");
  if (!Ai.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::tridiagonal_Lanczos (imaginary part)");

  if (!Ar.is_it_symmetric ())     error_message_print_abort ("The real part of the matrix is not symmetric in total_diagonalization::hermitian::tridiagonal_Lanczos");
  if (!Ai.is_it_antisymmetric ()) error_message_print_abort ("The imaginary part of the matrix is not antisymmetric in total_diagonalization::hermitian::tridiagonal_Lanczos");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::tridiagonal_Lanczos");

  const unsigned int N = Ar.get_dimension ();

  const unsigned int Nm1 = N - 1; 

  tau_1(Nm1) = 1.0;
  tau_2(Nm1) = 0.0;

  Ar.diagonal_part (diagonal);

  for (unsigned int i = Nm1 ; i <= Nm1 ; i--)
    {     
      class vector_class<SCALAR_TYPE> &Ar_i = Ar.row_vector (i);
      class vector_class<SCALAR_TYPE> &Ai_i = Ai.row_vector (i);

      SCALAR_TYPE &Ar_ii = Ar_i(i);
      SCALAR_TYPE &Ai_ii = Ai_i(i);
      
      SCALAR_TYPE &tau_1i = tau_1(i);
      SCALAR_TYPE &tau_2i = tau_2(i);

      SCALAR_TYPE &diagonal_i = diagonal(i);

      SCALAR_TYPE &off_diagonal_i = off_diagonal(i);

      if (i == 0)
	{
	  const SCALAR_TYPE diagonal_i_bef = diagonal_i;
	  
	  off_diagonal_i = Ai_i(i) = 0.0;

	  diagonal_i = Ar_i(i);

	  Ar_i(i) = diagonal_i_bef;
	}
      else
	{
	  const unsigned int l = i - 1;

	  SCALAR_TYPE &Ar_il = Ar_i(l);
	  SCALAR_TYPE &Ai_il = Ai_i(l);

	  SCALAR_TYPE &tau_1l = tau_1(l);
	  SCALAR_TYPE &tau_2l = tau_2(l);

	  double scale = 0.0;
	  
	  for (unsigned int k = 0 ; k < i ; k++) scale += inf_norm (Ar(k , i)) + inf_norm (Ai(k , i));

	  if (scale == 0.0) 
	    {
	      const SCALAR_TYPE diagonal_i_bef = diagonal_i;

	      tau_1l = 1.0;

	      tau_2l = off_diagonal_i = Ai_ii = 0.0;

	      diagonal_i = Ar_ii;

	      Ar_ii = diagonal_i_bef;
	    }
	  else
	    {
	      SCALAR_TYPE h = 0.0;
	      
	      SCALAR_TYPE si = 0.0;

	      for (unsigned int k = 0 ; k < i ; k++) 
		{
		  SCALAR_TYPE &Ar_ik = Ar_i(k);
		  SCALAR_TYPE &Ai_ik = Ai_i(k);
		  
		  Ar_ik /= scale;
		  Ai_ik /= scale;
		  
		  h += Ar_ik*Ar_ik + Ai_ik*Ai_ik;
		}

	      const SCALAR_TYPE f = hypot (Ar_il , Ai_il);
	      
	      const bool is_f_zero = (f == 0.0);
	      
	      const bool is_i_one = (i == 1);

	      const SCALAR_TYPE sh = sqrt (h);

	      off_diagonal_i = scale*sh;

	      if (!is_f_zero)
		{	      
		  const SCALAR_TYPE g = 1.0 + sh/f;
	      
		  tau_1l = (Ai_il*tau_2i - Ar_il*tau_1i)/f;
		  
		  si = (Ar_il*tau_2i + Ai_il*tau_1i)/f;
		  
		  h += f*sh;
		  
		  Ar_il *= g;
		  Ai_il *= g;

		  if (is_i_one)
		    {
		      const SCALAR_TYPE diagonal_i_bef = diagonal_i;
		      
		      for (unsigned int k = 0 ; k < i ; k++)
			{
			  Ar_i(k) *= scale;
			  Ai_i(k) *= scale;
			}
		      
		      tau_2l = -si;

		      diagonal_i = Ar_ii;

		      Ar_ii = diagonal_i_bef;

		      Ai_ii = scale*sqrt (h);
		    }
		}
	      else
		{
		  tau_1l = -tau_1i;

		  si = tau_2i;

		  Ar_il = sh;
		}
	      
	      if (!is_i_one || is_f_zero)
		{
		  SCALAR_TYPE ff = 0.0;

		  for (unsigned int j = 0 ; j < i ; j++) 
		    { 
		      SCALAR_TYPE gg  = 0.0;
		      SCALAR_TYPE ggi = 0.0;

		      const class vector_class<SCALAR_TYPE> &Ar_j = Ar.row_vector (j);
		      const class vector_class<SCALAR_TYPE> &Ai_j = Ai.row_vector (j);

		      for (unsigned int k = 0 ; k <= j ; k++)
			{
			  const SCALAR_TYPE Ar_ik = Ar_i(k);
			  const SCALAR_TYPE Ai_ik = Ai_i(k);
			  
			  const SCALAR_TYPE Ar_jk = Ar_j(k);
			  const SCALAR_TYPE Ai_jk = Ai_j(k);
			  
			  gg  += Ar_jk*Ar_ik + Ai_jk*Ai_ik;
			  ggi += Ai_jk*Ar_ik - Ar_jk*Ai_ik;
			}

		      const unsigned int jp1 = j+1;

		      if (l >= jp1)
			{
			  for (unsigned int k = jp1 ; k < i ; k++)
			    {
			      const SCALAR_TYPE Ar_ik = Ar_i(k);
			      const SCALAR_TYPE Ai_ik = Ai_i(k);
			      
			      const SCALAR_TYPE Ar_kj = Ar(k , j);
			      const SCALAR_TYPE Ai_kj = Ai(k , j);
			      
			      gg  += Ar_kj*Ar_ik - Ai_kj*Ai_ik;
			      ggi -= Ar_kj*Ai_ik + Ai_kj*Ar_ik;
			    }
			}

		      SCALAR_TYPE &off_diagonal_j = off_diagonal(j);
		      
		      SCALAR_TYPE &tau_2j = tau_2(j);
		      
		      off_diagonal_j = gg/h;
		      
		      tau_2j = ggi/h;
		      
		      ff += off_diagonal_j*Ar_i(j) - tau_2j*Ai_i(j);
		    }

		  const SCALAR_TYPE hh = 0.5*ff/h;

		  for (unsigned int j = 0 ; j < i ; j++)
		    {	
		      SCALAR_TYPE &off_diagonal_j = off_diagonal(j);

		      SCALAR_TYPE &tau_2j = tau_2(j);
		      
		      class vector_class<SCALAR_TYPE> &Ar_j = Ar.row_vector (j);
		      class vector_class<SCALAR_TYPE> &Ai_j = Ai.row_vector (j);

		      const SCALAR_TYPE fff = Ar_i(j);

		      const SCALAR_TYPE gg = off_diagonal_j - hh*fff;

		      const SCALAR_TYPE fffi = -Ai_i(j);

		      const SCALAR_TYPE ggi = tau_2j - hh*fffi;
		      
		      off_diagonal_j = gg;
		      
		      tau_2j = -ggi;

		      for (unsigned int k = 0 ; k <= j ; k++)
			{
			  const SCALAR_TYPE off_diagonal_k = off_diagonal(k);
			  
			  const SCALAR_TYPE tau_2k = tau_2(k);
			  
			  SCALAR_TYPE &Ar_ik = Ar_i(k);
			  SCALAR_TYPE &Ai_ik = Ai_i(k);
			  
			  SCALAR_TYPE &Ar_jk = Ar_j(k);
			  SCALAR_TYPE &Ai_jk = Ai_j(k);
			  
			  Ar_jk -= fff*off_diagonal_k + gg*Ar_ik - fffi*tau_2k - ggi*Ai_ik;

			  Ai_jk -= fff*tau_2k + gg*Ai_ik + fffi*off_diagonal_k + ggi*Ar_ik;
			}
		    }

		  for (unsigned int k = 0 ; k < i ; k++)
		    {
		      Ar_i(k) *= scale;
		      Ai_i(k) *= scale;
		    }
		  
		  const SCALAR_TYPE diagonal_i_bef = diagonal_i;
		  
		  tau_2l = -si;

		  diagonal_i = Ar_ii;

		  Ar_ii = diagonal_i_bef;

		  Ai_ii = scale*sqrt (h);
		}
	    }
	}
    }
}






// Back transformation of tridiagonal matrix eigenvectors
// ------------------------------------------------------
// Calculation of the eigenvectors of the (Ar , Ai) operator from the eigenvectors of the associated tridigonal matrix.
// The routine is an adaptation of the freely available FORTRAN Netlib routine htribk.
// All vectors are back transformed.
//
// Variables :
// -----------
// Ar , Ai : Ar and Ai contain the matrix of transformation from the total matrix to the tridiagonal matrix.
// Vr , Vi : Vr and Vi contain at the end the eigenvectors of the initial operator (Ar , Ai).
// tau_1 , tau_2 : helper arrays for matrix transformation


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::back_transform_eigenvectors (
								    const class matrix<SCALAR_TYPE> &Ar , 
								    const class matrix<SCALAR_TYPE> &Ai , 
								    const class array<SCALAR_TYPE> &tau_1 , 
								    const class array<SCALAR_TYPE> &tau_2 , 
								    class matrix<SCALAR_TYPE> &Vr , 
								    class matrix<SCALAR_TYPE> &Vi)
{
  const unsigned int N = Ar.get_dimension ();

  for (unsigned int k = 0 ; k < N ; k++)
    {
      const SCALAR_TYPE tau_1k = tau_1(k);

      const SCALAR_TYPE minus_tau_2k = -tau_2(k);
      
      for (unsigned int j = 0 ; j < N ; j++) 
	{
	  SCALAR_TYPE &Vr_jk = Vr(j , k);
	  
	  Vi(j , k) = Vr_jk*minus_tau_2k;

	  Vr_jk *= tau_1k;
	}
    }

  for (unsigned int i = 1 ; i < N ; i++)
    {
      const class vector_class<SCALAR_TYPE> &Ar_i = Ar.row_vector (i);
      const class vector_class<SCALAR_TYPE> &Ai_i = Ai.row_vector (i);
      
      const SCALAR_TYPE h = Ai_i(i);

      if (h != 0.0)
	{
	  const SCALAR_TYPE h_square = h*h;
      
	  for (unsigned int j = 0 ; j < N ; j++)
	    {
	      SCALAR_TYPE s  = 0.0;
	      SCALAR_TYPE si = 0.0;

	      class vector_class<SCALAR_TYPE> &Vr_j = Vr.row_vector (j);
	      class vector_class<SCALAR_TYPE> &Vi_j = Vi.row_vector (j);

	      for (unsigned int k = 0 ; k < i ; k++)
		{
		  const SCALAR_TYPE Ar_ik = Ar_i(k);
		  const SCALAR_TYPE Ai_ik = Ai_i(k);

		  const SCALAR_TYPE Vr_jk = Vr_j(k);
		  const SCALAR_TYPE Vi_jk = Vi_j(k);
		  
		  s  += Ar_ik*Vr_jk - Ai_ik*Vi_jk;
		  si += Ar_ik*Vi_jk + Ai_ik*Vr_jk;
		}

	      s  /= h_square;
	      si /= h_square;

	      for (unsigned int k = 0 ; k < i ; k++)
		{
		  const SCALAR_TYPE Ar_ik = Ar_i(k);
		  const SCALAR_TYPE Ai_ik = Ai_i(k);
		  
		  Vr_j(k) -=  s*Ar_ik  + si*Ai_ik;
		  Vi_j(k) -= si*Ar_ik  - s*Ai_ik;
		}
	    }
	}
    }
}






// Diagonalization of a general matrix.
// ------------------------------------
// Sorted eigenvalues and eigenvectors with the Householder/Lanczos + QL/inverse iteration method.
// The sort is made with the real part of eigenvalues.
// Complex hermitian matrices are diagonalized with Householder + QL method or inverse iteration method.
// Bicomplex hermitian matrices are diagonalized with the Lanczos + QL or inverse iteration method.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.
// Inverse iteration can be used only if eigenvalues are well separated, by more than 10^(-5) in practice.
// Inverse iteration is used for bicomplex hermitian matrices as it is typically faster than QL.
//
// Variables :
// -----------
// Ar , Ai : Ar is the symmetric part and Ai is the antisymmetric part of the (Ar , Ai) operator (Ar + i.Ai for real hermitian case). 
//         Ar and Ai contain at the end the sorted eigenvectors of the operator.
// tau_1 , tau_2 : helper arrays for matrix transformation
// Vr , Vi : Vr and Vi contain at the end the eigenvectors of the initial operator (Ar , Ai) , wichi are then put in Ar and Ai.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Householder (
								   class matrix<SCALAR_TYPE> &Ar , 
								   class matrix<SCALAR_TYPE> &Ai , 
								   class array<SCALAR_TYPE> &eigenvalues)
{  
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Householder is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Householder is used with square matrices only (imaginary part)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::all_eigenpairs_Householder");
   
  const unsigned int N = Ar.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;

  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0))
    {
      Ar.diagonal_part (eigenvalues);

      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::all_eigenpairs_Householder (diagonal case)");
      
      Ar.identity ();
      
      eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);

      return;
    }

  const double A_infinite_norm = max (Ar.infinite_norm () , Ai.infinite_norm ());
  
  Ar /= A_infinite_norm;
  Ai /= A_infinite_norm;
  
  const SCALAR_TYPE renormalized_matrix_trace_over_N = Ar.trace ()/static_cast<double> (N);
      
  Ar.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
  
  class array<SCALAR_TYPE> tau_1(N);
  class array<SCALAR_TYPE> tau_2(N);

  class array<SCALAR_TYPE> diagonal(N);
  class array<SCALAR_TYPE> off_diagonal(N);

  tridiagonal_Householder (Ar , Ai , tau_1 , tau_2 , diagonal , off_diagonal);
  
  for (unsigned int i = 1 ; i < N ; i++) off_diagonal(i-1) = off_diagonal(i);
  
  off_diagonal(Nm1) = 0.0;

  class matrix<SCALAR_TYPE> Vr(N);
  class matrix<SCALAR_TYPE> Vi(N);

  Vr.identity ();

  Vi = 0.0;
  
  symmetric::QL_diagonalization (false , diagonal , off_diagonal , eigenvalues , Vr);          

  eigenvalues += renormalized_matrix_trace_over_N;
      
  back_transform_eigenvectors (Ar , Ai , tau_1 , tau_2 , Vr , Vi);

  Ar = Vr;
  Ai = Vi;
  
  eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);
  
  eigenvalues *= A_infinite_norm;
}






template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Lanczos (
							       class matrix<SCALAR_TYPE> &Ar , 
							       class matrix<SCALAR_TYPE> &Ai , 
							       class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Lanczos is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Lanczos is used with square matrices only (imaginary part)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::all_eigenpairs_Householder");
  
  const unsigned int N = Ar.get_dimension ();

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;

  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0))
    {
      Ar.diagonal_part (eigenvalues);
      
      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::all_eigenpairs_Lanczos (diagonal case)");
      
      Ar.identity ();
      
      eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);

      return;
    }
  
  const double A_infinite_norm = max (Ar.infinite_norm () , Ai.infinite_norm ());
  
  Ar /= A_infinite_norm;
  Ai /= A_infinite_norm;
      
  class array<SCALAR_TYPE> diagonal(N);

  class array<SCALAR_TYPE> off_diagonal(N);

  const SCALAR_TYPE renormalized_matrix_trace_over_N = Ar.trace ()/static_cast<double> (N);
  
  Ar.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
  
  tridiagonal_Lanczos (Ar , Ai , diagonal , off_diagonal);
  
  symmetric::QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , Ar);

  eigenvalues_real_sort (0 , Nm1 , eigenvalues);

  const double minimal_eigenvalue_difference = minimal_eigenvalue_difference_determine (eigenvalues);
 
  if (minimal_eigenvalue_difference < sqrt_precision)
    { 
      class matrix<SCALAR_TYPE> Vr(N);

      Vr.identity ();

      symmetric::QL_diagonalization (false , diagonal , off_diagonal , eigenvalues , Vr);
	  
      Ar = Vr*Ar;
      Ai = Vr*Ai;
	  
      eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);	  
    }
  else
    {
      const double minimal_eigenvalue_difference_one_thousandth = minimal_eigenvalue_difference*0.001;
      
      Ar.transpose ();
      Ai.transpose ();
      
      const class matrix<SCALAR_TYPE> Pr = Ar;
      const class matrix<SCALAR_TYPE> Pi = Ai;

      class vector_class<SCALAR_TYPE> eigenvector_tridiagonal_j(N);
      
      class array<SCALAR_TYPE> diagonal_shifted(N);
  
      class array<SCALAR_TYPE> off_diagonal_work_table = off_diagonal;
  
      class array<SCALAR_TYPE> diagonal_work_table = diagonal;
  
      class vector_class<SCALAR_TYPE> work_vector(N);
      
      for (unsigned int j = 0 ; j < N ; j++)
	{
	  const SCALAR_TYPE &eigenvalue_j = eigenvalues(j);
	  	      
	  const double Re_eigenvalue_j = real_dc (eigenvalue_j);
	  
	  const double abs_eigenvalue_shift = min (abs (Re_eigenvalue_j)*minimal_eigenvalue_difference_one_thousandth , 0.001);
	      
	  const double eigenvalue_shift = SIGN (Re_eigenvalue_j)*abs_eigenvalue_shift;
	      
	  const SCALAR_TYPE eigenvalue_shifted = eigenvalue_j + eigenvalue_shift;
  
	  diagonal_shifted = diagonal;
	  
	  diagonal_shifted -= eigenvalue_shifted;
	  
	  symmetric::eigenvector_tridiagonal_calc (off_diagonal , diagonal_shifted , off_diagonal_work_table , diagonal_work_table , work_vector , eigenvector_tridiagonal_j);
	  
	  Ar.eigenvector(j) = Pr*eigenvector_tridiagonal_j;
	  Ai.eigenvector(j) = Pi*eigenvector_tridiagonal_j;
	}
    }
  
  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenvalues *= A_infinite_norm;
}








// Diagonalization of a full matrix with the Newton method
// -------------------------------------------------------
// One calculates firstly eigenvalues with the Householder +_QL method.
// One diagonalizes the matrix with the Lanczos + QL method afterwards if eigenvalues are not too close, i.e. by less than 10^(-12).
// One can consider than eigenvalues are different therein as the precision used in QL is 10^(-13).
// Otherwise, one uses Householder + QL for full diagonalization.
// Then, one uses the Newton method of Ogita, T., Aishima, K.: Iterative refinement for symmetric eigenvalue decomposition. Jpn. J. Ind. Appl. Math. 35(3), 1007–1035 (2018).
// I use max norm (infinite_norm () in the code) instead of the spectral hermitian norm for the calculation of omega (see referenced paper for the use of different norms). 
// Even though the use of max norm is not equivalent to that of the spectral hermitian norm, it was numerically checked that the use of max norm leads to converging results.
// I always normalize eigenvectors, so that R(i,i) = E(i,i) = 0 (notations of the referenced paper).
//
// A precision of 10^(-14) is demanded. One quits the Newton method after 5 iterations, as it usually converges quickly.
// If the Newton test is larger than the previous one, it means that the method no longer improves eigenpairs as the Newton method is supposed to converge quickly.
// One quits the Newton routine in this case, assuming that eigenpairs are sufficiently correct.
//
// The additional cost is about 8.N^3 multiplications per iteration, and one has about 3-5 iterations.
// Hence, the method costs about 30-40 N^3 multiplications, about 2-3 times more than Lanczos + QL.
// One also needs to store 7 additional matrices.
//
// The Newton method is fully parallelized for the O(N^3) operations (in particular matrix multiplications) except for:
// 1) The Householder + QL method, used if eigenvalues are closer than 10^(-12).
// 2) The QL method, used along with the Lanczos method for full diagonalization if eigenvalues are closer than 10^(-5).
// Hence, the Newton method is much slower if eigenvalues are closer than 10^(-5).
// Thus, this routine is not used by default.
//
// Variables :
// -----------
// N , Nm1 , A_infinite_norm : dimension of A , N - 1 , infinite norm of A.
// minimal_eigenvalue_difference : smallest value of differences of eigenvalues
// Ar_copy, Ai_copy: copy of the matrix to diagonalize (real and imaginary parts), denoted as Ar, Ai in other routines.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// Res : residue A.eigenvector - eigenvalue.eigenvector
//
// Rr , Sr , Er, Ri , Si , Ei: matrices used in the Newton method (real and imaginary parts).
//                             Notations are the same as in the referenced paper, except for S, which becomes S -> S - D afterwards, with D the array of eigenvalues.
//                             Rr, Ri are also used as temporary matrices.
//
// Pr, Pi, Pr_transpose, Pi_transpose : Matrix of normalized eigenvectors to refine and its transpose (real and imaginary parts).
//                                      Pr_transpose, Pi_transpose are references to Er, Ei as they are used independently.
//
// M: work matrix to store M = A*B to avoid the temporaries induced by operator *  with matrices
//
// are_eigenvalues_close: true if the eigenvalues difference is smaller than omega, false if not
// count , maximal_loop_number : number and maximal number of loops if convergence is not obtained after loop_number iterations. The latter is fixed at 5.
// test_eigenvectors: test of eigenvectors calculated with Householder + QL or Lanczos + QL. It is the maximal value of all the supremum norms of eigenvector residues.
// omega: 2(||S||oo + ||R||oo) used to identify multiple eigenvalues (see referenced paper and above).
// test_Newton, tes_Newton_bef: test of the Newton method of the current and previous iterations. The test is the supremum norm of E.


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Newton (
							      class matrix<SCALAR_TYPE> &Ar , 
							      class matrix<SCALAR_TYPE> &Ai , 
							      class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Newton is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenpairs_Newton is used with square matrices only (imaginary part)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::all_eigenpairs_Newton");
 
  const unsigned int N = Ar.get_dimension ();
  
  if (N == 0) return;
  
  const unsigned int Nm1 = N - 1;
  
  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0)) // The zero matrix case is included ...
    {
      Ar.diagonal_part (eigenvalues);
      
      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::all_eigenpairs_Newton (diagonal case)");
      
      Ar.identity ();
      
      eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);
      
      return;
    }
  
  const double A_infinite_norm = max (Ar.infinite_norm () , Ai.infinite_norm ());
  
  Ar /= A_infinite_norm;
  Ai /= A_infinite_norm;
    
  const class matrix<SCALAR_TYPE> Ar_copy = Ar;
  const class matrix<SCALAR_TYPE> Ai_copy = Ai;
  
  all_eigenvalues_Householder (Ar , Ai , eigenvalues);
  
  const double minimal_eigenvalue_difference = minimal_eigenvalue_difference_determine (eigenvalues);  
  
  Ar = Ar_copy;
  Ai = Ai_copy;
  
  if (minimal_eigenvalue_difference < 1E-12)
    all_eigenpairs_Householder (Ar , Ai , eigenvalues);
  else  
    all_eigenpairs_Lanczos (Ar , Ai , eigenvalues);

  const unsigned int maximal_loop_number = 5;
  
  unsigned int count = 0;

  class matrix<SCALAR_TYPE> Rr(N) , Sr(N) , Er(N) , Ri(N) , Si(N) , Ei(N) , M(N);
    
  double test_Newton     = INFINITE;
  double test_Newton_bef = INFINITE;
  
  class matrix<SCALAR_TYPE> &Pr_transpose = Er;
  class matrix<SCALAR_TYPE> &Pi_transpose = Ei;
    
  while ((test_Newton > 1E-14) && (count++ < maximal_loop_number))
    {
      Pr_transpose = Ar;
      Pi_transpose = Ai;

      Ar.transpose ();
      Ai.transpose ();
      
      class matrix<SCALAR_TYPE> &Pr = Ar;
      class matrix<SCALAR_TYPE> &Pi = Ai;
              
      matrix_multiplication (Pr_transpose , Ar_copy , M) , Sr  = M;
      matrix_multiplication (Pi_transpose , Ai_copy , M) , Sr += M;
      
      matrix_multiplication (Pr_transpose , Ai_copy , M) , Si  = M;
      matrix_multiplication (Pi_transpose , Ar_copy , M) , Si -= M;
      
      matrix_multiplication (Sr , Pr , M) , Rr  = M;      
      matrix_multiplication (Si , Pi , M) , Rr -= M;

      matrix_multiplication (Si , Pr , M) , Ri  = M;      
      matrix_multiplication (Sr , Pi , M) , Ri += M;
      
      Sr = Rr;
      Si = Ri;
      
      Sr.diagonal_part (eigenvalues);
      
      Sr.put_scalar_diagonal_part (0.0);

      Rr.identity ();
      
      matrix_multiplication (Pr_transpose , Pr , M) , Rr -= M;      
      matrix_multiplication (Pi_transpose , Pi , M) , Rr -= M;
      
      matrix_multiplication (Pi_transpose , Pr , M) , Ri  = M;      
      matrix_multiplication (Pr_transpose , Pi , M) , Ri -= M;
            
      const double R_infinite_norm = max (Rr.infinite_norm () , Ri.infinite_norm ());
      const double S_infinite_norm = max (Sr.infinite_norm () , Si.infinite_norm ());
      
      const double omega = 2.0*(R_infinite_norm + S_infinite_norm);
      
      Er.put_scalar_diagonal_part (0.0);
      Ei.put_scalar_diagonal_part (0.0);
  
      for (unsigned int i = 0 ; i < N ; i++)
	for (unsigned int j = 0 ; j < i ; j++)
	  {
	    const SCALAR_TYPE eigenvalue_i = eigenvalues(i);
	    const SCALAR_TYPE eigenvalue_j = eigenvalues(j);
	    
	    const SCALAR_TYPE eigenvalue_difference = eigenvalue_j - eigenvalue_i;

	    const bool are_eigenvalues_close = (abs (eigenvalue_difference) <= omega);
	    
	    Er(i , j) = (are_eigenvalues_close) ? (0.5*Rr(i , j)) : ( (Sr(i , j) + eigenvalue_j*Rr(i , j))/eigenvalue_difference);
	    Er(j , i) = (are_eigenvalues_close) ? (0.5*Rr(j , i)) : (-(Sr(j , i) + eigenvalue_i*Rr(j , i))/eigenvalue_difference);
	    
	    Ei(i , j) = (are_eigenvalues_close) ? (0.5*Ri(i , j)) : ( (Si(i , j) + eigenvalue_j*Ri(i , j))/eigenvalue_difference);
	    Ei(j , i) = (are_eigenvalues_close) ? (0.5*Ri(j , i)) : (-(Si(j , i) + eigenvalue_i*Ri(j , i))/eigenvalue_difference);
	  }      
	  
      test_Newton_bef = test_Newton;
      
      test_Newton = max (Er.infinite_norm () , Ei.infinite_norm ());
      
      if (test_Newton < test_Newton_bef)
	{
	  matrix_multiplication (Pr , Er , M) , Rr  = M;	  
	  matrix_multiplication (Pi , Ei , M) , Rr -= M;

	  matrix_multiplication (Pi , Er , M) , Ri  = M;	  
	  matrix_multiplication (Pr , Ei , M) , Ri += M;
      
	  Pr += Rr;
	  Pi += Ri;

	  Ar.transpose ();
	  Ai.transpose ();
      
	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      class vector_class<SCALAR_TYPE> &Vr = Ar.eigenvector (i);
	      class vector_class<SCALAR_TYPE> &Vi = Ai.eigenvector (i);

	      const SCALAR_TYPE V_norm = sqrt (Vr*Vr + Vi*Vi);

	      Vr /= V_norm;
	      Vi /= V_norm;
	    }
	}
      else
	{
	  Ar.transpose ();
	  Ai.transpose ();

	  break;
	}
    }
  
  eigenpairs_real_sort (0 , Nm1 , Ar , Ai , eigenvalues);
  
  eigenvalues *= A_infinite_norm;  
}







// Diagonalization of a full matrix.
// ---------------------------------
// The Lanczos method is typically more stable than Householder for bicomplex hermitian matrices.
// Hence it is always used for bicomplex hermitian matrices by default except for dimension two as there Householder is exact.
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs (
						       class matrix<SCALAR_TYPE> &Ar , 
						       class matrix<SCALAR_TYPE> &Ai , 
						       class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.is_it_real () && Ai.is_it_real ())
    all_eigenpairs_Householder (Ar , Ai , eigenvalues);
  else 
    all_eigenpairs_Lanczos (Ar , Ai , eigenvalues);
}











// Semi diagonalization of a general matrix.
// -----------------------------------------
// Sorted eigenvalues with the Householder + QL method.
// The sort is made with the real part of eigenvalues.
//
// Variables :
// -----------
// Ar , Ai : matrices to diagonalize. Ar is the symmetric part and Ai is the antisymmetric part (A = Ar + i.Ai for complex hermitian case). 
//           Ar and Ai are destroyed at the end of the calculation.
// eigenvalues : It will contain at the end the sorted eigenvalues of the tridiagonal matrix.
// tau_1 , tau_2 : helper arrays for matrix transformation
// off_diagonal : Array of the off diagonal matrix elements of the tridiagonal matrix.

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues_Householder (
								    class matrix<SCALAR_TYPE> &Ar , 
								    class matrix<SCALAR_TYPE> &Ai , 
								    class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenvalues_Householder is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenvalues_Householder is used with square matrices only (imaginary part)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::all_eigenvalues_Householder");

  const unsigned int N = Ar.get_dimension ();
  
  const unsigned int Nm1 = N - 1;

  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0))
    {
      Ar.diagonal_part (eigenvalues);
      
      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::all_eigenvalues_Householder (diagonal case)");
      
      eigenvalues_real_sort (0 , Nm1 , eigenvalues);

      return;
    }
  
  const double A_infinite_norm = max (Ar.infinite_norm () , Ai.infinite_norm ());
  
  Ar /= A_infinite_norm;
  Ai /= A_infinite_norm;
      
  const SCALAR_TYPE renormalized_matrix_trace_over_N = Ar.trace ()/static_cast<double> (N);
      
  Ar.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
      
  class array<SCALAR_TYPE> tau_1(N);
  class array<SCALAR_TYPE> tau_2(N);

  class array<SCALAR_TYPE> diagonal(N);
  class array<SCALAR_TYPE> off_diagonal(N);

  tridiagonal_Householder (Ar , Ai , tau_1 , tau_2 , diagonal , off_diagonal);
  
  for (unsigned int i = 1 ; i < N ; i++) off_diagonal(i-1) = off_diagonal(i);
  
  off_diagonal(Nm1) = 0.0;

  symmetric::QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , Ar);

  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenvalues_real_sort (0 , Nm1 , eigenvalues);
  
  eigenvalues *= A_infinite_norm;
}





// Semi diagonalization of a full matrix.
// -------------------------------------
// The Lanczos method is nevertheless unstable with almost zero or very close (i.e. around machine precision) eigenvalues, so that it is better to use Householder in this case.


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues_Lanczos (
								class matrix<SCALAR_TYPE> &Ar , 
								class matrix<SCALAR_TYPE> &Ai , 
								class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.get_dimension_row () != Ar.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenvalues_Lanczos is used with square matrices only (real part)");
  if (Ai.get_dimension_row () != Ai.get_dimension_column ()) error_message_print_abort ("total_diagonalization::hermitian::all_eigenvalues_Lanczos is used with square matrices only (imaginary part)");

  if (Ar.get_dimension () != Ai.get_dimension ()) error_message_print_abort ("The matrix real and imaginary parts do not have the same dimensions in total_diagonalization::hermitian::all_eigenvalues_Householder");
  
  const unsigned int N = Ar.get_dimension ();

  const unsigned int Nm1 = N - 1;

  if (Ar.is_it_diagonal () && (Ai.infinite_norm () == 0.0))
    {
      Ar.diagonal_part (eigenvalues);
      
      if (!eigenvalues.isfinite ()) error_message_print_abort ("The matrix is not finite in total_diagonalization::hermitian::all_eigenvalues_Lanczos (diagonal case)");
      
      eigenvalues_real_sort (0 , Nm1 , eigenvalues);

      return;
    }

  const double A_infinite_norm = max (Ar.infinite_norm () , Ai.infinite_norm ());
  
  Ar /= A_infinite_norm;
  Ai /= A_infinite_norm;
      
  const SCALAR_TYPE renormalized_matrix_trace_over_N = Ar.trace ()/static_cast<double> (N);
      
  Ar.remove_scalar_diagonal_part (renormalized_matrix_trace_over_N);
  
  class array<SCALAR_TYPE> diagonal(N);
  
  class array<SCALAR_TYPE> off_diagonal(N);

  tridiagonal_Lanczos (Ar , Ai , diagonal , off_diagonal);

  symmetric::QL_diagonalization (true , diagonal , off_diagonal , eigenvalues , Ar);
  
  eigenvalues += renormalized_matrix_trace_over_N;
  
  eigenvalues_real_sort (0 , Nm1 , eigenvalues);
  
  eigenvalues *= A_infinite_norm;
}






// Semi diagonalization of a tridiagonal matrix.
// ---------------------------------------------
// Sorted eigenvalues with the QL method.
// The sort is made with the real part of eigenvalues.
//
// Variables :
// -----------
// Ar , Ai : matrices to diagonalize. Ar is the symmetric part and Ai is the antisymmetric part (A = Ar + i.Ai for complex hermitian case). 
//           Ar and Ai are destroyed at the end of the calculation.
// eigenvalues : It will contain at the end the sorted eigenvalues of the matrix.

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues (
							class matrix<SCALAR_TYPE> &Ar , 
							class matrix<SCALAR_TYPE> &Ai , 
							class array<SCALAR_TYPE> &eigenvalues)
{
  if (Ar.is_it_real () && Ai.is_it_real ())
    all_eigenvalues_Householder (Ar , Ai , eigenvalues);
  else
    all_eigenvalues_Lanczos (Ar , Ai , eigenvalues);
}










// Diagonalization of block matrices separating real and imaginary parts in the hermitian case
// -------------------------------------------------------------------------------------------
// One diagonalizes the matrices on each block one by one.

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Householder (
								   class block_matrix<SCALAR_TYPE> &Ar , 
								   class block_matrix<SCALAR_TYPE> &Ai , 			       
								   class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Householder (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Lanczos (
							       class block_matrix<SCALAR_TYPE> &Ar , 
							       class block_matrix<SCALAR_TYPE> &Ai , 			       
							       class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Lanczos (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs_Newton (
							      class block_matrix<SCALAR_TYPE> &Ar , 
							      class block_matrix<SCALAR_TYPE> &Ai , 			       
							      class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Newton (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenpairs (
						       class block_matrix<SCALAR_TYPE> &Ar , 
						       class block_matrix<SCALAR_TYPE> &Ai , 			       
						       class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues_Householder (
								    class block_matrix<SCALAR_TYPE> &Ar , 
								    class block_matrix<SCALAR_TYPE> &Ai , 			       
								    class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues_Householder (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}


template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues_Lanczos (
								class block_matrix<SCALAR_TYPE> &Ar , 
								class block_matrix<SCALAR_TYPE> &Ai , 			       
								class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues_Lanczos (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}

template <typename SCALAR_TYPE> 
void total_diagonalization::hermitian::all_eigenvalues (
							class block_matrix<SCALAR_TYPE> &Ar , 
							class block_matrix<SCALAR_TYPE> &Ai , 			       
							class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = Ar.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &Ar_block = Ar(i);
      class matrix<SCALAR_TYPE> &Ai_block = Ai(i);
      
      const unsigned int A_block_dimension = Ar_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues (Ar_block , Ai_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}











// Diagonalization of block matrices
// ---------------------------------
// One diagonalizes the matrices on each block one by one.

template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenpairs_Householder (
							class block_matrix<SCALAR_TYPE> &A , 			        
							class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Householder (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}

template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenpairs_Lanczos (
						    class block_matrix<SCALAR_TYPE> &A , 			        
						    class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Lanczos (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}

template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenpairs_Newton (
						   class block_matrix<SCALAR_TYPE> &A , 			       
						   class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs_Newton (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}
  
template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenpairs (
					    class block_matrix<SCALAR_TYPE> &A , 		        
					    class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenpairs (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}
  
template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenvalues_Householder (
							 class block_matrix<SCALAR_TYPE> &A , 				     
							 class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues_Householder (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}
  
template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenvalues_Lanczos (
						     class block_matrix<SCALAR_TYPE> &A , 				 
						     class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues_Lanczos (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}
  
template <typename SCALAR_TYPE> 
void total_diagonalization::all_eigenvalues (
					     class block_matrix<SCALAR_TYPE> &A , 			 
					     class array<SCALAR_TYPE> &eigenvalues)
{
  const unsigned int blocks_number = A.get_blocks_number ();

  unsigned int index = 0;
  
  for (unsigned int i = 0 ; i < blocks_number ; i++)
    {  
      class matrix<SCALAR_TYPE> &A_block = A(i);
      
      const unsigned int A_block_dimension = A_block.get_dimension ();

      class array<SCALAR_TYPE> eigenvalues_block(A_block_dimension);

      all_eigenvalues (A_block , eigenvalues_block);
      
      for (unsigned int ii = 0 ; ii < A_block_dimension ; ii++) eigenvalues(index++) = eigenvalues_block(ii);
    }
}





#endif



