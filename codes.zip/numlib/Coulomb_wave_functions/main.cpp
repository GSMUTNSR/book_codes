#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;



void F_dF_power_series_test (
			     const complex<double> &l ,
			     const complex<double> &eta ,
			     const complex<double> &z ,
			     complex<double> &F ,
			     complex<double> &dF)
{
  const complex<double> log_Cl_eta = log_Cl_eta_calc (l , eta);

  const complex<double> Cl_eta = exp (log_Cl_eta);
  
  if (z == 0.0)
    {
      if (l == 0)
	{
	  F = 0.0;
	  
	  dF = 1.0;
	}
      else if (real (l) > 0)
	{
	  F  = 0.0;
	  dF = 0.0;
	}
      else
	error_message_print_abort ("F(z=0) and/or F'(z=0) are undefined.");
    }
  else
    {
      const complex<double> z_square = z * z;
      
      const complex<double> z_two_eta = 2.0 * eta * z;

      int n = 2;

      complex<double> an_minus_two = 1.0;

      complex<double> an_minus_one = z * eta/(l + 1.0);

      F = an_minus_two + an_minus_one;

      dF = (l + 1.0) * an_minus_two + (l + 2.0) * an_minus_one;

      while (inf_norm (an_minus_two * (n + l - 1.0)) + inf_norm (an_minus_one * (n + l)) > precision)
	{
	  const complex<double> an = (z_two_eta * an_minus_one- an_minus_two * z_square)/(n * (n + l + l + 1.0));

	  F += an;
	  
	  dF += an * (n + l + 1.0);

	  n ++ ;

	  an_minus_two = an_minus_one;
	  an_minus_one = an;
	}

      const complex<double> z_pow_l_plus_one = pow (z , l + 1.0);
      
      F  *= z_pow_l_plus_one;
      dF *= z_pow_l_plus_one/z; 

      if ((Cl_eta == 0.0) || !finite (Cl_eta))
	{
	  F  = exp (log_Cl_eta + log  (F));
	  dF = exp (log_Cl_eta + log (dF));
	}
      else
	{
	  F  *= Cl_eta;
	  dF *= Cl_eta;
	}
    }
}




complex<double> continued_fraction_h_test (
					   const complex<double> &l ,
					   const complex<double> &eta ,
					   const complex<double> &z ,
					   const int omega)
{
  const double small = 1E-50;
  const double large = 1E50;

  const complex<double> I_omega(0.0 , omega);

  const complex<double> two_I_omega(0.0 , 2.0 * omega);

  const complex<double> I_omega_eta = I_omega * eta;

  const complex<double> a = I_omega_eta + l + 1.0;
  const complex<double> c = I_omega_eta - l;

  const complex<double> z_minus_eta = z - eta;

  const complex<double> two_z_minus_eta = 2.0 * z_minus_eta;

  complex<double> b0 = z_minus_eta;

  complex<double> hn = (b0 != 0.0) ? (b0) : (small);

  complex<double> Cn = hn;

  complex<double> Dn = 0.0;

  int n = 1;

  double test;

  do
    {
      const int nm1 = n - 1;

      const complex<double> an = (a + nm1) * (c + nm1);

      const complex<double> bn = two_z_minus_eta + n * two_I_omega;

      const complex<double> bn_plus_an_Dn = bn + an * Dn;

      const complex<double> bn_plus_an_over_Cn = bn + an/Cn;

      Dn = (bn_plus_an_Dn != 0.0) ? (1.0/bn_plus_an_Dn) : (large);

      Cn = (bn_plus_an_over_Cn != 0.0) ? (bn_plus_an_over_Cn) : (small);

      const complex<double> Delta_n = Dn * Cn;

      hn *= Delta_n;

      test = inf_norm (1.0 - Delta_n);

      n++;
    }
  while (test > 1e-15);

  const complex<double> h = hn * I_omega/z;
  
  return h;
}



void test_precision_large_imaginary_parts ()
{
  cout.precision (10);
  
  cout << boolalpha;

  const complex<double> l(1.2 , 0.1) , eta (3.0 , 0.2) , k(0.1 , -0.3) , I(0 , 1);

  const complex<double> Wc = Whittaker_const_calc (l , eta) , Cl_eta = exp (log_Cl_eta_calc (l , eta)) , Cl_eta_inv = 1.0/Cl_eta;

  const unsigned int N = 10;
  
  const double xmin = -15.12345678 , xmax = 15.12345678 , step_x = (xmax - xmin)/static_cast<double> (N-1);
  const double ymin = -15.12345678 , ymax = 15.12345678 , step_y = (ymax - ymin)/static_cast<double> (N-1);
	    
  cout << endl << "Large imaginary parts " << endl << endl;
     
  cout << "l : " << l << endl;
  cout << "eta : " << eta << endl;
  cout << "k : " << k << endl << endl;
  
  for (unsigned int i_norm = 0 ; i_norm <= 1 ; i_norm++)
    {
      const bool is_it_normalized = (i_norm == 0);

      class Coulomb_wave_functions cwf_l  (is_it_normalized , l   , eta);
      class Coulomb_wave_functions cwf_lp1(is_it_normalized , l+1 , eta);
	
      class Coulomb_wave_functions cwf_l_minus(is_it_normalized , l , -eta);//endl
		  
      cout << endl << "is_it_normalized : " << is_it_normalized << endl << endl;

      cout << "z   test functions     test derivatives    Wronskian test   test functions (kz)    test derivatives (kz)" << endl << endl;

      for (unsigned int ix = 0 ; ix < N ; ix++) 
	for (unsigned int iy = 0 ; iy < N ; iy++) 
	  {
	    const double x = xmin + ix*step_x;
	    const double y = ymin + iy*step_y;
	    
	    const complex<double> z(x , y);

	    const complex<double> kz = k*z;

	    const complex<double> unscale_p = exp ( I * (z - eta * (M_LN2 + log (z))));
	    const complex<double> unscale_m = exp (-I * (z - eta * (M_LN2 + log (z))));

	    const complex<double> unscale_kz_p = exp ( I * (kz - eta * (M_LN2 + log (kz))));
	    const complex<double> unscale_kz_m = exp (-I * (kz - eta * (M_LN2 + log (kz))));

	    complex<double> F , dF , Hp , dHp , Hp_s , dHp_s , Wm   , dWm;
	    complex<double> G , dG , Hm , dHm , Hm_s , dHm_s , Wm_s , dWm_s;

	    cwf_l.F_dF (z , F , dF);
	    cwf_l.G_dG (z , G , dG);
	    
	    cwf_l.H_dH ( 1 , z , Hp , dHp);
	    cwf_l.H_dH (-1 , z , Hm , dHm);

	    cwf_l.Wm_dWm (z , Wm , dWm);

	    cwf_l.H_dH_scaled ( 1 , z , Hp_s , dHp_s);
	    cwf_l.H_dH_scaled (-1 , z , Hm_s , dHm_s);
	    
	    cwf_l.Wm_dWm_scaled (z , Wm_s , dWm_s);

	    if (!is_it_normalized)
	      {
		F *= Cl_eta , dF *= Cl_eta;
		
		G *= Cl_eta_inv , dG *= Cl_eta_inv;
		
		Hp *= Cl_eta_inv , dHp *= Cl_eta_inv;
		Hm *= Cl_eta_inv , dHm *= Cl_eta_inv;
		Wm *= Cl_eta_inv , dWm *= Cl_eta_inv;

		Hp_s *= Cl_eta_inv , dHp_s *= Cl_eta_inv;
		Hm_s *= Cl_eta_inv , dHm_s *= Cl_eta_inv;
		Wm_s *= Cl_eta_inv , dWm_s *= Cl_eta_inv;
	      }
	      
	    const double test = (inf_norm ((G + I*F)/Hp - 1.0)
				 + inf_norm ((G - I*F)/Hm - 1.0)
				 + inf_norm (Hp_s*unscale_p/Hp - 1.0)
				 + inf_norm (Hm_s*unscale_m/Hm - 1.0)
				 + inf_norm (Wc*Hp/Wm - 1.0)
				 + inf_norm (Wc*Hp_s/Wm_s - 1.0))/6.0;
	    
	    const double test_der = (inf_norm ((dG + I*dF)/dHp - 1.0)
				     + inf_norm ((dG - I*dF)/dHm - 1.0)
				     + inf_norm (dHp_s*unscale_p/dHp - 1.0)
				     + inf_norm (dHm_s*unscale_m/dHm - 1.0)
				     + inf_norm (Wc*dHp/dWm - 1.0)
				     + inf_norm (Wc*dHp_s/dWm_s - 1.0))/6.0; 

	    const double Wt = Wronskian_test (z , cwf_l , cwf_lp1);

	    cwf_l.F_kz_dF_kz (k , z , F , dF);
	    cwf_l.G_kz_dG_kz (k , z , G , dG);
	    
	    cwf_l.H_kz_dH_kz ( 1 , k , z , Hp , dHp);
	    cwf_l.H_kz_dH_kz (-1 , k , z , Hm , dHm);
	    
	    cwf_l.Wm_kz_dWm_kz (k , z , Wm , dWm);

	    cwf_l.H_kz_dH_kz_scaled ( 1 , k , z , Hp_s , dHp_s);
	    cwf_l.H_kz_dH_kz_scaled (-1 , k , z , Hm_s , dHm_s);
	    
	    cwf_l.Wm_kz_dWm_kz_scaled (k , z , Wm_s , dWm_s);

	    if (!is_it_normalized)
	      {
		F *= Cl_eta , dF *= Cl_eta;
		
		G *= Cl_eta_inv , dG *= Cl_eta_inv;

		Hp *= Cl_eta_inv , dHp *= Cl_eta_inv;
		Hm *= Cl_eta_inv , dHm *= Cl_eta_inv;
		Wm *= Cl_eta_inv , dWm *= Cl_eta_inv;

		Hp_s *= Cl_eta_inv , dHp_s *= Cl_eta_inv;
		Hm_s *= Cl_eta_inv , dHm_s *= Cl_eta_inv;
		Wm_s *= Cl_eta_inv , dWm_s *= Cl_eta_inv;
	      }

	    const double test_kz = (inf_norm ((G + I*F)/Hp - 1.0)
				    + inf_norm ((G - I*F)/Hm - 1.0)
				    + inf_norm (Hp_s*unscale_kz_p/Hp - 1.0)
				    + inf_norm (Hm_s*unscale_kz_m/Hm - 1.0)
				    + inf_norm (Wc*Hp/Wm - 1.0)
				    + inf_norm (Wc*Hp_s/Wm_s - 1.0))/6.0;
	    
	    const double test_der_kz = (inf_norm ((dG + I*dF)/dHp - 1.0)
					+ inf_norm ((dG - I*dF)/dHm - 1.0)
					+ inf_norm (dHp_s*unscale_kz_p/dHp - 1.0)
					+ inf_norm (dHm_s*unscale_kz_m/dHm - 1.0)
					+ inf_norm (Wc*dHp/dWm - 1.0)
					+ inf_norm (Wc*dHp_s/dWm_s - 1.0))/6.0; 

	    cout << z << "   " << test << "   " << test_der << "   " << Wt << "   " << test_kz << "   " << test_der_kz << endl;
	  }

    }
}






void test_precision_small_imaginary_parts ()
{
  cout.precision (10);
  
  cout << boolalpha;

  const complex<double> l(1.2 , 1E-8);

  const complex<double> eta (3.0 , 1E-8);
  
  const complex<double> k(0.8 , -1E-8) , I(0 , 1);

  const complex<double> Wc = Whittaker_const_calc (l , eta);

  const complex<double> Cl_eta = exp (log_Cl_eta_calc (l , eta));

  const complex<double> Cl_eta_inv = 1.0/Cl_eta;

  const unsigned int N = 10;
  
  const double xmin = 0.01 , xmax = 0.1512345678    , step_x = (xmax - xmin)/static_cast<double> (N-1);
  const double ymin = 1E-8 , ymax = 1.5123456781E-8 , step_y = (ymax - ymin)/static_cast<double> (N-1);
	    
  cout << endl << "Small imaginary parts " << endl << endl;
  
  cout << "l : " << l << endl;
  
  cout << "eta : " << eta << endl;

  cout << "k : " << k << endl << endl;

  class Coulomb_wave_functions cwf_l  (true , l   , eta);
  class Coulomb_wave_functions cwf_lp1(true , l+1 , eta);
	
  class Coulomb_wave_functions cwf_l_minus(true , l , -eta);//endl
		 
  for (unsigned int i_norm = 0 ; i_norm <= 1 ; i_norm++)
    {
      const bool is_it_normalized = (i_norm == 0);

      cout << endl << "is_it_normalized : " << is_it_normalized << endl << endl;
      
      cout << "z   test functions     test derivatives    Wronskian test   test functions (kz)    test derivatives (kz)" << endl << endl;

      for (unsigned int ix = 0 ; ix < N ; ix++) 
	for (unsigned int iy = 0 ; iy < N ; iy++) 
	  {
	    const double x = xmin + ix*step_x;
	    const double y = ymin + iy*step_y;
	    
	    const complex<double> z(x , y);

	    const complex<double> kz = k*z;
	
	    complex<double> F , dF , Hp , dHp , Hp_s , dHp_s , Wm   , dWm   , F0 , dF0 , Hp0 , dHp0 , Hp_s0 , dHp_s0 , Wm0   , dWm0   , hp0 , f0;
	    complex<double> G , dG , Hm , dHm , Hm_s , dHm_s , Wm_s , dWm_s , G0 , dG0 , Hm0 , dHm0 , Hm_s0 , dHm_s0 , Wm_s0 , dWm_s0 , hm0;

	    cwf_l.F_dF (z , F , dF);
	    cwf_l.G_dG (z , G , dG);
	    
	    cwf_l.H_dH ( 1 , z , Hp , dHp);
	    cwf_l.H_dH (-1 , z , Hm , dHm);

	    cwf_l.Wm_dWm (z , Wm , dWm);
	
	    F_dF_power_series_test (l , eta , z , F0 , dF0);

	    f0 = dF0/F0;

	    hp0 = continued_fraction_h_test (l , eta , z ,  1);
	    hm0 = continued_fraction_h_test (l , eta , z , -1);
		
	    Hp0  = 1.0/(F0 * (f0 - hp0));
	    Hm0  = 1.0/(F0 * (f0 - hm0));
	
	    dHp0 = hp0*Hp0;
	    dHm0 = hm0*Hm0;
		
	    G0  =  (Hp0 +  Hm0)/2.0;
	    dG0 = (dHp0 + dHm0)/2.0;

	    Wm0  =  Hp0*Wc;
	    dWm0 = dHp0*Wc;
	
	    if (!is_it_normalized)
	      {
		F *= Cl_eta , dF *= Cl_eta;
		
		G *= Cl_eta_inv , dG *= Cl_eta_inv;

		Hp *= Cl_eta_inv , dHp *= Cl_eta_inv;
		Hm *= Cl_eta_inv , dHm *= Cl_eta_inv;
		Wm *= Cl_eta_inv , dWm *= Cl_eta_inv;
		
		F0 *= Cl_eta , dF0 *= Cl_eta;
		
		G0 *= Cl_eta_inv , dG0 *= Cl_eta_inv;

		Hp0 *= Cl_eta_inv , dHp0 *= Cl_eta_inv;
		Hm0 *= Cl_eta_inv , dHm0 *= Cl_eta_inv;
		Wm0 *= Cl_eta_inv , dWm0 *= Cl_eta_inv;
	      }
	    
	    const double test = (abs ((real (F)/real (F0) - 1.0)) + abs ((imag (F)/imag (F0) - 1.0)) 	    
				 + abs ((real (G)/real (G0) - 1.0)) + abs ((imag (G)/imag (G0) - 1.0))  
				 + abs ((real (Hp)/real (Hp0) - 1.0)) + abs ((imag (Hp)/imag (Hp0) - 1.0))  	    
				 + abs ((real (Hm)/real (Hm0) - 1.0)) + abs ((imag (Hm)/imag (Hm0) - 1.0))	    
				 + abs ((real (Wm)/real (Wm0) - 1.0)) + abs ((imag (Wm)/imag (Wm0) - 1.0)))/10.0;
	
	    const double test_der = (abs ((real (dF)/real (dF0) - 1.0)) + abs ((imag (dF)/imag (dF0) - 1.0)) 	    
				     + abs ((real (dG)/real (dG0) - 1.0)) + abs ((imag (dG)/imag (dG0) - 1.0))  
				     + abs ((real (dHp)/real (dHp0) - 1.0)) + abs ((imag (dHp)/imag (dHp0) - 1.0))  	    
				     + abs ((real (dHm)/real (dHm0) - 1.0)) + abs ((imag (dHm)/imag (dHm0) - 1.0))	    
				     + abs ((real (dWm)/real (dWm0) - 1.0)) + abs ((imag (dWm)/imag (dWm0) - 1.0)))/10.0;
	
	    const double Wt = Wronskian_test (z , cwf_l , cwf_lp1);

	    cwf_l.F_kz_dF_kz (k , z , F , dF);
	    cwf_l.G_kz_dG_kz (k , z , G , dG);
	    
	    cwf_l.H_kz_dH_kz ( 1 , k , z , Hp , dHp);
	    cwf_l.H_kz_dH_kz (-1 , k , z , Hm , dHm);
	    
	    cwf_l.Wm_kz_dWm_kz (k , z , Wm , dWm);

	    F_dF_power_series_test (l , eta , kz , F0 , dF0);
	
	    f0 = dF0/F0;

	    hp0 = continued_fraction_h_test (l , eta , kz ,  1);
	    hm0 = continued_fraction_h_test (l , eta , kz , -1);
	
	    Hp0  = 1.0/(F0 * (f0 - hp0));
	    Hm0  = 1.0/(F0 * (f0 - hm0));

	    dF0 *= k;
	
	    dHp0 = hp0*Hp0*k;
	    dHm0 = hm0*Hm0*k;
	
	    G0  =  (Hp0 +  Hm0)/2.0;
	    dG0 = (dHp0 + dHm0)/2.0;

	    Wm0  =  Hp0*Wc;
	    dWm0 = dHp0*Wc;

	    if (!is_it_normalized)
	      {
		F *= Cl_eta , dF *= Cl_eta;
		
		G *= Cl_eta_inv , dG *= Cl_eta_inv;

		Hp *= Cl_eta_inv , dHp *= Cl_eta_inv;
		Hm *= Cl_eta_inv , dHm *= Cl_eta_inv;
		Wm *= Cl_eta_inv , dWm *= Cl_eta_inv;
		
		F0 *= Cl_eta , dF0 *= Cl_eta;
		
		G0 *= Cl_eta_inv , dG0 *= Cl_eta_inv;

		Hp0 *= Cl_eta_inv , dHp0 *= Cl_eta_inv;
		Hm0 *= Cl_eta_inv , dHm0 *= Cl_eta_inv;
		Wm0 *= Cl_eta_inv , dWm0 *= Cl_eta_inv;
	      }
	    
	    const double test_kz = (abs ((real (F)/real (F0) - 1.0)) + abs ((imag (F)/imag (F0) - 1.0)) 	    
				    + abs ((real (G)/real (G0) - 1.0)) + abs ((imag (G)/imag (G0) - 1.0))  
				    + abs ((real (Hp)/real (Hp0) - 1.0)) + abs ((imag (Hp)/imag (Hp0) - 1.0))  	    
				    + abs ((real (Hm)/real (Hm0) - 1.0)) + abs ((imag (Hm)/imag (Hm0) - 1.0))	    
				    + abs ((real (Wm)/real (Wm0) - 1.0)) + abs ((imag (Wm)/imag (Wm0) - 1.0)))/10.0;
	    
	    const double test_der_kz = (abs ((real (dF)/real (dF0) - 1.0)) + abs ((imag (dF)/imag (dF0) - 1.0)) 	    
					+ abs ((real (dG)/real (dG0) - 1.0)) + abs ((imag (dG)/imag (dG0) - 1.0))  
					+ abs ((real (dHp)/real (dHp0) - 1.0)) + abs ((imag (dHp)/imag (dHp0) - 1.0))  	    
					+ abs ((real (dHm)/real (dHm0) - 1.0)) + abs ((imag (dHm)/imag (dHm0) - 1.0))	    
					+ abs ((real (dWm)/real (dWm0) - 1.0)) + abs ((imag (dWm)/imag (dWm0) - 1.0)))/10.0;
	    
	    cout << z << "   " << test << "   " << test_der << "   " << Wt << "   " << test_kz << "   " << test_der_kz << endl;
	  }
    }
}







void data_for_plots (
		     const complex<double> &l , 
		     const complex<double> &eta ,
		     const unsigned int N_theta)
{
  const double R = abs (eta) + sqrt (abs (l*(l+1) + abs (eta*eta)));

  class Coulomb_wave_functions cwf(true , l , eta);

  const double step_theta = M_PI/static_cast<double> (N_theta - 1);

  ofstream out_file("out_cwf.dat");

  out_file.precision (15);

  complex<double> F , dF , Hp , dHp;
  complex<double> G , dG , Hm , dHm;
	    
  for (unsigned int i = 0 ; i < N_theta ; i++)
    {
      const double theta = i*step_theta;

      const complex<double> z = polar (R , theta);

      cwf.F_dF (z , F , dF);
      cwf.G_dG (z , G , dG);
      cwf.H_dH (1 , z , Hp , dHp);
      cwf.H_dH (-1 , z , Hm , dHm);

      out_file << theta*180.0/M_PI << " " 
	       << log10 (abs (F))  << " " << log10 (abs (dF)) << " "
	       << log10 (abs (G))  << " " << log10 (abs (dG)) << " "
	       << log10 (abs (Hp)) << " " << log10 (abs (dHp)) << " "
	       << log10 (abs (Hm)) << " " << log10 (abs (dHm)) << endl;	    
    }

  out_file << endl;

  for (unsigned int i = 0 ; i < N_theta ; i++)
    {
      const double theta = i*step_theta + M_PI + precision;

      const complex<double> z = polar (R , theta);
	    
      cwf.F_dF (z , F , dF);
      cwf.G_dG (z , G , dG);
      
      cwf.H_dH ( 1 , z , Hp , dHp);
      cwf.H_dH (-1 , z , Hm , dHm);

      out_file << theta*180.0/M_PI << " " 
	       << log10 (abs (F))  << " " << log10 (abs (dF)) << " "
	       << log10 (abs (G))  << " " << log10 (abs (dG)) << " "
	       << log10 (abs (Hp)) << " " << log10 (abs (dHp)) << " "
	       << log10 (abs (Hm)) << " " << log10 (abs (dHm)) << endl;
    }
}


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    string calculation_str;
    
    cin >> calculation_str;

    if (calculation_str == "test.precision")
      {
	test_precision_large_imaginary_parts ();
	test_precision_small_imaginary_parts ();
      }
    else if (calculation_str == "plot")
      {
	complex<double> l , eta;

	cin >> l;

	word_check_print<complex<double> > ("(l)" , l);

	cin >> eta;

	word_check_print<complex<double> > ("(eta)" , eta);

	unsigned int N_theta;

	cin >> N_theta;

	word_check_print<unsigned int> ("(contour.points)" , N_theta);

	data_for_plots (l , eta , N_theta);
      }
    else
      error_message_print_abort ("Bad option");

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
