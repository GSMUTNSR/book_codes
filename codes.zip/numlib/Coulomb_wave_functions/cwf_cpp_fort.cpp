#include "complex_functions.H"
#include "cwfcomp.H"




extern "C" void f_df_not_norm_(const int &l , const complex<double> &eta , const complex<double> &z , complex<double> &F , complex<double> &dF)
{
  class Coulomb_wave_functions cwf(false , l , eta);

  cwf.F_dF (z , F , dF);
}

extern "C" void f_df_norm_(const int &l , const complex<double> &eta , const complex<double> &z , complex<double> &F , complex<double> &dF)
{
  class Coulomb_wave_functions cwf(true , l , eta);

  cwf.F_dF (z , F , dF);
}

extern "C" void f_df_table_not_norm_(const int &l , const complex<double> &eta , const unsigned int &N , const complex<double> z[] , complex<double> F[] , complex<double> dF[])
{
  class Coulomb_wave_functions cwf(false , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.F_dF (z[i] , F[i] , dF[i]);
    }
}

extern "C" void f_df_table_norm_(const int &l , const complex<double> &eta , const unsigned int &N , const complex<double> z[] , complex<double> F[] , complex<double> dF[])
{
  class Coulomb_wave_functions cwf(true , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.F_dF (z[i] , F[i] , dF[i]);
    }
}










extern "C" void g_dg_not_norm_(const int &l , const complex<double> &eta , const complex<double> &z , complex<double> &G , complex<double> &dG)
{
  class Coulomb_wave_functions cwf(false , l , eta);

  cwf.G_dG (z , G , dG);
}

extern "C" void g_dg_norm_(const int &l , const complex<double> &eta , const complex<double> &z , complex<double> &G , complex<double> &dG)
{
  class Coulomb_wave_functions cwf(true , l , eta);

  cwf.G_dG (z , G , dG);
}


extern "C" void g_dg_table_not_norm_(const int &l , const complex<double> &eta , const unsigned int &N , const complex<double> z[] , complex<double> G[] , complex<double> dG[])
{
  class Coulomb_wave_functions cwf(false , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.G_dG (z[i] , G[i] , dG[i]);
    }
}

extern "C" void g_dg_table_norm_(const int &l , const complex<double> &eta , const unsigned int &N , const complex<double> z[] , complex<double> G[] , complex<double> dG[])
{
  class Coulomb_wave_functions cwf(true , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.G_dG (z[i] , G[i] , dG[i]);
    }
}








extern "C" void h_dh_not_norm_(const int &l , const complex<double> &eta , const int &omega , const complex<double> &z , complex<double> &H , complex<double> &dH)
{
  class Coulomb_wave_functions cwf(false , l , eta);

  cwf.H_dH (omega , z , H , dH);
}

extern "C" void h_dh_norm_(const int &l , const complex<double> &eta , const int &omega , const complex<double> &z , complex<double> &H , complex<double> &dH)
{
  class Coulomb_wave_functions cwf(true , l , eta);

  cwf.H_dH (omega , z , H , dH);
}


extern "C" void h_dh_table_not_norm_(const int &l , const complex<double> &eta , const int &omega , const unsigned int &N , const complex<double> z[] , complex<double> H[] , complex<double> dH[])
{
  class Coulomb_wave_functions cwf(false , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.H_dH (omega , z[i] , H[i] , dH[i]);
    }
}

extern "C" void h_dh_table_norm_(const int &l , const complex<double> &eta , const int &omega , const unsigned int &N , const complex<double> z[] , complex<double> H[] , complex<double> dH[])
{
  class Coulomb_wave_functions cwf(true , l , eta);

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      cwf.H_dH (omega , z[i] , H[i] , dH[i]);
    }
}



extern "C" void cwf_l_tables_(const int &l_deb , const int &Nl , const complex<double> &eta , const complex<double> &z , complex<double> * const F_tab , complex<double> * const dF_tab , complex<double> * const G_tab , complex<double> * const dG_tab , complex<double> * const Hp_tab , complex<double> * const dHp_tab , complex<double> * const Hm_tab , complex<double> * const dHm_tab)
{
  cwf_l_tables_recurrence_relations (l_deb , Nl , eta , true , z , F_tab , dF_tab , G_tab , dG_tab , Hp_tab , dHp_tab , Hm_tab , dHm_tab);
}


extern "C" void cwf_l_z_tables_(const int &l_deb , const int &Nl , const complex<double> &eta , const int &Nz , const complex<double> z_tab[] , complex<double> * const F_one_dim_tab , complex<double> * const dF_one_dim_tab , complex<double> * const G_one_dim_tab , complex<double> * const dG_one_dim_tab , complex<double> * const Hp_one_dim_tab , complex<double> * const dHp_one_dim_tab , complex<double> * const Hm_one_dim_tab , complex<double> * const dHm_one_dim_tab)
{ 
  complex<double> * * F_tab = new complex<double> * [Nz];
  complex<double> * * dF_tab = new complex<double> * [Nz];
  complex<double> * * G_tab = new complex<double> * [Nz];
  complex<double> * * dG_tab = new complex<double> * [Nz];
  complex<double> * * Hp_tab = new complex<double> * [Nz];
  complex<double> * * dHp_tab = new complex<double> * [Nz];
  complex<double> * * Hm_tab = new complex<double> * [Nz];
  complex<double> * * dHm_tab = new complex<double> * [Nz];

  for (unsigned int iz = 0 ; iz < Nz ; iz ++ )
    {
      F_tab[iz] = new complex<double> [Nl];
      dF_tab[iz] = new complex<double> [Nl];
      G_tab[iz] = new complex<double> [Nl];
      dG_tab[iz] = new complex<double> [Nl];
      Hp_tab[iz] = new complex<double> [Nl];
      dHp_tab[iz] = new complex<double> [Nl];
      Hm_tab[iz] = new complex<double> [Nl];
      dHm_tab[iz] = new complex<double> [Nl];
    }

  cwf_l_tables_recurrence_relations (l_deb , Nl , eta , true , Nz , z_tab , F_tab , dF_tab , G_tab , dG_tab , Hp_tab , dHp_tab , Hm_tab , dHm_tab);

  for (unsigned int iz = 0 ; iz < Nz ; iz ++ )
    {
      for (unsigned int il = 0 ; il < Nl ; il ++ )
	{
	  F_one_dim_tab[il + Nl * iz] = F_tab[iz][il];
	  dF_one_dim_tab[il + Nl * iz] = dF_tab[iz][il];
	  G_one_dim_tab[il + Nl * iz] = G_tab[iz][il];
	  dG_one_dim_tab[il + Nl * iz] = dG_tab[iz][il];
	  Hp_one_dim_tab[il + Nl * iz] = Hp_tab[iz][il];
	  dHp_one_dim_tab[il + Nl * iz] = dHp_tab[iz][il];
	  Hm_one_dim_tab[il + Nl * iz] = Hm_tab[iz][il];
	  dHm_one_dim_tab[il + Nl * iz] = dHm_tab[iz][il];
	} 
    }

  for (unsigned int iz = 0 ; iz < Nz ; iz ++ )
    {
      delete [] F_tab[iz];
      delete [] dF_tab[iz];
      delete [] G_tab[iz];
      delete [] dG_tab[iz];
      delete [] Hp_tab[iz];
      delete [] dHp_tab[iz];
      delete [] Hm_tab[iz];
      delete [] dHm_tab[iz];
    }

  delete [] F_tab;
  delete [] dF_tab;
  delete [] G_tab;
  delete [] dG_tab;
  delete [] Hp_tab;
  delete [] dHp_tab;
  delete [] Hm_tab;
  delete [] dHm_tab;
}

