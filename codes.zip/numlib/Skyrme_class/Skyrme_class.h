#ifndef SKYRME_CLASS_H
#define SKYRME_CLASS_H

class Skyrme_class
{
public:
  
  Skyrme_class ();
    
  Skyrme_class (
		const double t0_c ,
		const double x0_c , 
		const double t1_c ,
		const double x1_c , 
		const double t2_c ,
		const double x2_c , 
		const double t3_c ,
		const double x3_c ,
		const double WLS_c ,
		const double alpha_c ,
		const double R0_c ,
		const double R_max_c);

  Skyrme_class (
		const double t0_c ,
		const double x0_c , 
		const double t1_c ,
		const double x1_c , 
		const double t2_c ,
		const double x2_c , 
		const double t3_c ,
		const double x3_c ,
		const double WLS_c ,
		const double alpha_c , 
		const double t0_pairing_c ,
		const double t3_pairing_c ,
		const double alpha_pairing_c ,
		const double E_cut_c , 
		const double R0_c ,
		const double R_max_c);

  void initialize (
		   const double t0_c ,
		   const double x0_c , 
		   const double t1_c ,
		   const double x1_c , 
		   const double t2_c ,
		   const double x2_c , 
		   const double t3_c ,
		   const double x3_c ,
		   const double WLS_c ,
		   const double alpha_c , 
		   const double t0_pairing_c ,
		   const double t3_pairing_c ,
		   const double alpha_pairing_c ,
		   const double E_cut_c , 
		   const double R0_c ,
		   const double R_max_c);
  
  double get_t0 () const
  {
    return t0;
  }
  
  double get_x0 () const
  {
    return x0;
  }
  
  double get_t1 () const
  {
    return t1;
  }
  
  double get_x1 () const
  {
    return x1;
  }
  
  double get_t2 () const
  {
    return t2;
  }
  
  double get_x2 () const
  {
    return x2;
  }
  
  double get_t3 () const
  {
    return t3;
  }
  
  double get_x3 () const
  {
    return x3;
  }
  
  double get_WLS () const
  {
    return WLS;
  }
  
  double get_alpha () const
  {
    return alpha;
  }
  
  double get_t0_pairing () const
  {
    return t0_pairing;
  }
  
  double get_t3_pairing () const
  {
    return t3_pairing;
  }
  
  double get_alpha_pairing () const
  {
    return alpha_pairing;
  }
  
  double get_E_cut () const
  {
    return E_cut;
  }
  
  double get_R0 () const
  {
    return R0;
  }
  
  double get_R_max () const
  {
    return R_max;
  }
  
private:
  
  double t0 , x0 , t1 , x1 , t2 , x2 , t3 , x3 , WLS , alpha , t0_pairing , t3_pairing , alpha_pairing , E_cut , R0 , R_max;
};

double used_memory_calc (const class Skyrme_class &T);


#endif


