#include "../numlib_def/numlib_def.h"

Skyrme_class::Skyrme_class () :
  t0 (0.0) ,
  x0 (0.0) ,
  t1 (0.0) ,
  x1 (0.0) ,
  t2 (0.0) ,
  x2 (0.0) ,
  t3 (0.0) ,
  x3 (0.0) ,
  WLS (0.0) ,
  alpha (0.0) , 
  t0_pairing (0.0) ,
  t3_pairing (0.0) ,
  alpha_pairing (0.0) ,
  E_cut (0.0) , 
  R0 (0.0) ,
  R_max (0.0) {}

Skyrme_class::Skyrme_class (
			    const double t0_c ,
			    const double x0_c , 
			    const double t1_c ,
			    const double x1_c , 
			    const double t2_c ,
			    const double x2_c , 
			    const double t3_c ,
			    const double x3_c ,
			    const double WLS_c ,
			    const double alpha_c ,
			    const double R0_c ,
			    const double R_max_c)
{
  initialize (t0_c , x0_c , t1_c , x1_c , t2_c , x2_c , t3_c , x3_c , WLS_c , alpha_c , 0.0 , 0.0 , 0.0 , 0.0 , R0_c , R_max_c);
}


Skyrme_class::Skyrme_class (
			    const double t0_c ,
			    const double x0_c , 
			    const double t1_c ,
			    const double x1_c , 
			    const double t2_c ,
			    const double x2_c , 
			    const double t3_c ,
			    const double x3_c ,
			    const double WLS_c ,
			    const double alpha_c ,
			    const double t0_pairing_c ,
			    const double t3_pairing_c ,
			    const double alpha_pairing_c ,
			    const double E_cut_c , 
			    const double R0_c ,
			    const double R_max_c)
{
  initialize (t0_c , x0_c , t1_c , x1_c , t2_c , x2_c , t3_c , x3_c , WLS_c , alpha_c , t0_pairing_c , t3_pairing_c , alpha_pairing_c , E_cut_c , R0_c , R_max_c);
}


void Skyrme_class::initialize (
			       const double t0_c ,
			       const double x0_c , 
			       const double t1_c ,
			       const double x1_c , 
			       const double t2_c ,
			       const double x2_c , 
			       const double t3_c ,
			       const double x3_c ,
			       const double WLS_c ,
			       const double alpha_c ,
			       const double t0_pairing_c ,
			       const double t3_pairing_c ,
			       const double alpha_pairing_c ,
			       const double E_cut_c , 
			       const double R0_c ,
			       const double R_max_c)
{
  t0 = t0_c;
  x0 = x0_c;
  t1 = t1_c;
  x1 = x1_c;
  t2 = t2_c;
  x2 = x2_c;
  t3 = t3_c;
  x3 = x3_c;
  WLS = WLS_c;
  alpha = alpha_c; 
  t0_pairing = t0_pairing_c;
  t3_pairing = t3_pairing_c;
  alpha_pairing = alpha_pairing_c;
  E_cut = E_cut_c; 
  R0 = R0_c;
  R_max = R_max_c;
}


double used_memory_calc (const class Skyrme_class &T)
{
  return sizeof (T)/1000000.0;
}
