#include "../numlib_def/numlib_def.h"


// Y[l , m](theta , phi) = PYlm(cos theta) e^(i m phi) (*)
// When m is an index of a table , one must have m >= 0. One uses symmetry formulas for m < 0 otherwise.
// All values involving l < |m| are put to zero.
// PYlm(x) , the returned value , is the associated Legendre function renormalized to 1/(2 Pi) , so that (*) is verified.
// PYlm(x) is available for -1 <= x <= 1 and derivatives PYlm'(x) and PYlm''(x) for -1 <= x <= 1 (m even) and -1 < x < 1 (m odd)
//
// PYlm functions are obtained from Legendre functions: PYlm = norm_const_calc (l , m) . Plm
// Plm are implemented first , and PYlm is deduced from Plm afterwards.


// Calculation of the normalization constant
// -----------------------------------------
// It is : (-1)^m (2m - 1)!! sqrt[(2l + 1) (l-m)! / (4 Pi (l+m)!)] if l >= m > 0
//         sqrt[(2l + 1)/(4 Pi)] if l >= m = 0
//         0 if l < m
//
// Variables:
// ----------
// l , m , m_bin_phase : orbital and azimuthal angular momenta
// log_l_minus_m_fact , log_l_minus_m_fact: log[(l - m)! , log[(l + m)!]
// log_two_m_minus_one_double_fact: log[(2m - 1)!!] 
// norm_const_no_phase: normalization constant up to the (-1)^m phase

double spherical_harmonics::norm_const_calc (const int l , const int m)
{
  if (l < m) return 0.0;

  const double log_l_minus_m_fact = lgamma (l - m + 1.0);

  const double log_l_plus_m_fact = lgamma (l + m + 1.0);
  
  const double log_two_m_minus_one_double_fact = (m > 0) ? (lgamma (2.0*m) - lgamma (m) - (m-1)*M_LN2) : (0.0);

  const double fact_ratio = exp (log_two_m_minus_one_double_fact + 0.5*(log_l_minus_m_fact - log_l_plus_m_fact));  

  const double norm_const_no_phase = sqrt ((2.0*l + 1.0)/(4.0*M_PI))*fact_ratio;

  const double norm_const = (m%2 == 0) ? (norm_const_no_phase) : (-norm_const_no_phase);

  return norm_const; 
}


// Calculation of the associated Legendre function P(l , m , x)
// ------------------------------------------------------------
// The following recurrence relation is used : 
// (ll-m).P(ll , m , x) = x(2ll + 1).P(ll-1 , m , x) - (ll + m - 1).P(ll-2 , m , x) for ll > m+1.
// P(m , m , x) = (1 - x^2)^(m/2) for P = Plm.  This value is directly returned if l = m.
// P(m , m , x) = norm_const(l , m) (1 - x^2)^(m/2) for P = PYlm.  This value is directly returned if l = m.
// P(m+1 , m , x) = x (2m + 1) P(m , m , x). This value is directly returned if l = m + 1.
//
// 
// Variables:
// ----------
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const: normalization constant
// mp2 : m + 2.
// Pmm_x , Pmp1m_x: P(m , m , x) and P(m+1 , m , x)
// ll , Plm_ll , Plm_llm1 , Plm_llm2 : associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1.
//                                  ll goes from m to l.
// x : variable of the associated Legendre function.

double spherical_harmonics::Plm (const int l , const int m , const double x)
{
  if (m < 0) return (minus_one_pow (m)*Plm (l , -m , x));

  if (l < m) return 0.0;

  const double Pmm_x = pow (sqrt (1.0 - x*x) , m);
  
  if (l == m) return Pmm_x;

  const double Pmp1m_x = (2*m + 1)*x*Pmm_x;
  
  if (l == m+1) return Pmp1m_x;

  const int mm1 = m - 1;
  const int mp2 = m + 2;

  double Plm_llm1 = Pmp1m_x;

  double Plm_llm2 = Pmm_x;

  double Plm_ll = 0.0;

  for (int ll = mp2 ; ll <= l ; ll++)
    {
      Plm_ll = (x*(2*ll - 1)*Plm_llm1 - (ll + mm1)*Plm_llm2)/static_cast<double> (ll - m);

      Plm_llm2 = Plm_llm1;

      Plm_llm1 = Plm_ll;
    }
  
  return Plm_ll;
}

double spherical_harmonics::PYlm (const int l , const int m , const double x)
{
  if (m < 0) 
    return (minus_one_pow (m)*PYlm (l , -m , x));
  else
    return (Plm(l , m , x)*norm_const_calc (l , m));
}



// Calculation of the associated Legendre function derivative dP(l , m , x)/dx
// -----------------------------------------------------------------------
// The following recurrences relations are used : 
// (ll-m).P'(ll , m , x) = x(2ll + 1).P'(ll-1 , m , x) - (ll + m -1).P'(ll-2 , m , x) + (2ll + 1).P(ll-1 , m , x) for ll > m+1.
// (ll-m).P(ll , m , x) = x(2ll + 1).P(ll-1 , m , x) - (ll + m -1).P(ll-2 , m , x) for ll > m+1.
// P(m , m , x) = norm_const(l , m) (1 - x^2)^(m/2).
// P'(m , m , x) = -norm_const(l , m) m x (1 - x^2)^(m/2 - 1).  This value is directly returned if l = m.
// P(m+1 , m , x) = x (2m + 1) P(m , m , x).
// P'(m+1 , m , x) = (2m + 1) [P(m , m , x) + x.P'(m , m , x)]. This value is directly returned if l = m + 1.
//
// 
// Variables:
// ----------
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 : m + 2.
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x: P(m , m , x) , P(m+1 , m , x) and derivatives
// ll , Plm_ll , Plm_llm1 , Plm_llm2 , dPlm_ll , dPlm_llm1 , dPlm_llm2 : 
//                                 associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1 and derivatives.
//                                 ll goes from m to l.
// x : variable of the associated Legendre function.
// ll_minus_m_inv: 1/(ll - m) for ll >= m+2

double spherical_harmonics::Plm_der (const int l , const int m , const double x)
{	
  if (m < 0) return (minus_one_pow (m)*Plm_der (l , -m , x));

  if (l < m) return 0.0;

  const int mm2 = m - 2;
  
  const double sqrt_one_mx2 = sqrt (1.0 - x*x);

  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);
  
  if (l == m) return dPmm_x;

  const double Pmm_x = pow (sqrt_one_mx2 , m);

  const double dPmp1m_x = (2*m + 1)*(x*dPmm_x + Pmm_x);
  
  if (l == m+1) return dPmp1m_x;

  const double Pmp1m_x = (2*m + 1)*x*Pmm_x;
  
  const int mm1 = m - 1;
  const int mp2 = m + 2;

  double dPlm_llm1 = dPmp1m_x;

  double dPlm_llm2 = dPmm_x;

  double dPlm_ll = 0.0;

  double Plm_llm1 = Pmp1m_x;

  double Plm_llm2 = Pmm_x;

  double Plm_ll = 0.0;

  for (int ll = mp2 ; ll <= l ; ll++)
    {
      const int two_ll_m1 = 2*ll - 1;

      const int ll_plus_mm1 = ll + mm1;

      const double ll_minus_m_inv = 1.0/static_cast<double> (ll - m);

      dPlm_ll = (two_ll_m1*(x*dPlm_llm1 + Plm_llm1) - ll_plus_mm1*dPlm_llm2)*ll_minus_m_inv;

      Plm_ll = (two_ll_m1*x*Plm_llm1 - ll_plus_mm1*Plm_llm2)*ll_minus_m_inv;

      dPlm_llm2 = dPlm_llm1;

      dPlm_llm1 = dPlm_ll;

      Plm_llm2 = Plm_llm1;

      Plm_llm1 = Plm_ll;
    }

  return dPlm_ll;
}


double spherical_harmonics::PYlm_der (const int l , const int m , const double x)
{
  if (m < 0) 
    return (minus_one_pow (m)*PYlm_der (l , -m , x));
  else
    return (Plm_der(l , m , x)*norm_const_calc (l , m));
}









// Calculation of the associated Legendre function second derivative d2P(l , m , x)/dx2
// --------------------------------------------------------------------------------
// The following recurrences relations are used : 
// (ll-m).P''(ll , m , x) = x(2ll + 1).P''(ll-1 , m , x) - (ll + m -1).P''(ll-2 , m , x) + 2.(2ll + 1).P'(ll-1 , m , x) for ll > m+1.
// (ll-m).P'(ll , m , x) = x(2ll + 1).P'(ll-1 , m , x) - (ll + m -1).P'(ll-2 , m , x) + (2ll + 1).P(ll-1 , m , x) for ll > m+1.
// (ll-m).P(ll , m , x) = x(2ll + 1).P(ll-1 , m , x) - (ll + m -1).P(ll-2 , m , x) for ll > m+1.
// P(m , m , x) = norm_const(l , m) (1 - x^2)^(m/2).
// P'(m , m , x) = -norm_const(l , m) m x (1 - x^2)^(m/2 - 1).  
// P''(m , m , x) = norm_const(l , m) m (1 - x^2)^(m/2 - 4) [ (m-2).x^2 - (1 - x^2)].  This value is directly returned if l = m.
// P(m+1 , m , x) = x (2m + 1) P(m , m , x).
// P'(m+1 , m , x) = (2m + 1) [P(m , m , x) + x.P'(m , m , x)].
// P''(m+1 , m , x) = (2m + 1) [2.P'(m , m , x) + x.P''(m , m , x)]. This value is directly returned if l = m + 1.
//
// 
// Variables:
// ----------
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 : m + 2.
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x , d2Pmm_x , d2Pmp1m_x: P(m , m , x) , P(m+1 , m , x) , first and second derivatives
// m_minus_two_term: (m-2).x^2.(1 - x^2)^(m/2 - 4) if m != 2 , and 0 if m=2 (then OK if x^2 = 1).
// ll , Plm_ll , Plm_llm1 , Plm_llm2 , dPlm_ll , dPlm_llm1 , dPlm_llm2 , d2Plm_ll , d2Plm_llm1 , d2Plm_llm2 : 
//                                 associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1 and derivatives.
//                                 ll goes from m to l.
// x : variable of the associated Legendre function.
// ll_minus_m_inv: 1/(ll - m) for ll >= m+2

double spherical_harmonics::Plm_2der (const int l , const int m , const double x)
{
  if (m < 0) return (minus_one_pow (m)*Plm_2der (l , -m , x));

  if (l < m) return 0.0;
  
  const int mm2 = m - 2;
  const int mm4 = m - 4;
  
  const double sqrt_one_mx2 = sqrt (1.0 - x*x);

  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

  const double m_minus_two_term = (m != 2) ? (mm2*x*x*pow (sqrt_one_mx2 , mm4)) : (0.0);

  const double d2Pmm_x = (m > 0) ? (m*(m_minus_two_term - pow (sqrt_one_mx2 , mm2))) : (0.0);

  if (l == m) return d2Pmm_x;

  const double Pmm_x = pow (sqrt_one_mx2 , m);

  const double dPmp1m_x = (2*m + 1)*(x*dPmm_x + Pmm_x);

  const double d2Pmp1m_x = (2*m + 1)*(x*d2Pmm_x + 2.0*dPmm_x);

  if (l == m + 1) return d2Pmp1m_x;

  const double Pmp1m_x = (2*m + 1)*x*Pmm_x;

  const int mm1 = m - 1;
  const int mp2 = m + 2;

  double d2Plm_llm1 = d2Pmp1m_x;

  double d2Plm_llm2 = d2Pmm_x;

  double d2Plm_ll = NADA;

  double dPlm_llm1 = dPmp1m_x;

  double dPlm_llm2 = dPmm_x;

  double dPlm_ll = 0.0;

  double Plm_llm1 = Pmp1m_x;

  double Plm_llm2 = Pmm_x;

  double Plm_ll = NADA;

  for (int ll = mp2 ; ll <= l ; ll++)
    {
      const int two_ll_m1 = 2*ll - 1;

      const int ll_plus_mm1 = ll + mm1;

      const double ll_minus_m_inv = 1.0/static_cast<double> (ll - m);

      d2Plm_ll = (two_ll_m1*(x*d2Plm_llm1 + 2.0*dPlm_llm1) - ll_plus_mm1*d2Plm_llm2)*ll_minus_m_inv;

      dPlm_ll = (two_ll_m1*(x*dPlm_llm1 + Plm_llm1) - ll_plus_mm1*dPlm_llm2)*ll_minus_m_inv;

      Plm_ll = (two_ll_m1*x*Plm_llm1 - ll_plus_mm1*Plm_llm2)*ll_minus_m_inv;

      d2Plm_llm2 = d2Plm_llm1;

      d2Plm_llm1 = d2Plm_ll;

      dPlm_llm2 = dPlm_llm1;

      dPlm_llm1 = dPlm_ll;

      Plm_llm2 = Plm_llm1;

      Plm_llm1 = Plm_ll;
    }

  return d2Plm_ll;
}



double spherical_harmonics::PYlm_2der (const int l , const int m , const double x)
{
  if (m < 0) 
    return (minus_one_pow (m)*PYlm_2der (l , -m , x));
  else
    return (Plm_2der(l , m , x)*norm_const_calc (l , m));
}



// Calculation of the associated Legendre function P(l , m , x) for a table of x values
// --------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab: table of x and associated Legendre functions values 
//              One has: x_tab(i) , Plm_tab(i) , i in [0:N-1] , with N = x_tab.dimension (0)
// N: number of x values
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const: normalization constant
// mp2 : m + 2.
// Pmm_x , Pmp1m_x: P(m , m , x) and P(m+1 , m , x)
// ll , Plm_ll , Plm_llm1 , Plm_llm2 : associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1.
//                                  ll goes from m to l.
// x : variable of the associated Legendre function.

void spherical_harmonics::Plm_tables_calc (
					   const int l , 
					   const int m , 
					   const class array<double> &x_tab , 
					   class array<double> &Plm_tab)
{
  if (m < 0) 
    {
      Plm_tables_calc (l , -m , x_tab , Plm_tab);

      Plm_tab *= minus_one_pow (m);

      return ;
    }

  const unsigned int N = x_tab.dimension (0);

  Plm_tab = 0.0;

  if (l < m) return;

  const int mm1 = m - 1;
  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double Pmm_x = pow (sqrt (1.0 - x*x) , m);

      if (l == m) 
	Plm_tab(i) = Pmm_x;
      else
	{
	  const double Pmp1m_x = (2*m + 1)*x*Pmm_x;

	  if (l == m+1) 
	    Plm_tab(i) = Pmp1m_x;
	  else
	    {
	      const int mp2 = m + 2;

	      double Plm_llm1 = Pmp1m_x;

	      double Plm_llm2 = Pmm_x;

	      double Plm_ll = 0.0;

	      for (int ll = mp2 ; ll <= l ; ll++)
		{
		  Plm_ll = (x*(2*ll - 1)*Plm_llm1 - (ll + mm1)*Plm_llm2)/static_cast<double> (ll - m);
		  
		  Plm_llm2 = Plm_llm1;
		  
		  Plm_llm1 = Plm_ll;
		}
	      
	      Plm_tab(i) = Plm_ll;
	    }
	}
    }
}


void spherical_harmonics::PYlm_tables_calc (
					    const int l , 
					    const int m , 
					    const class array<double> &x_tab , 
					    class array<double> &PYlm_tab)
{
  if (m < 0) 
    {
      PYlm_tables_calc (l , -m , x_tab , PYlm_tab);

      PYlm_tab *= minus_one_pow (m);
    }
  else
    {	
      Plm_tables_calc (l , m , x_tab , PYlm_tab);

      PYlm_tab *= norm_const_calc (l , m);
    }
}


// Calculation of the associated Legendre function P(l , m , x) for a table of l and x values
// ---------------------------------------------------------------------------------------
//
// Variables:
// ----------
// x_tab , Plm_tab: table of x and associated Legendre functions values 
//              One has: x_tab(i) , Plm_tab(l , i) , i in [0:N-1] , l in [0:lmax] , with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1
// N , lmax: number of x values , maximal orbital angular momentum
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const: normalization constant
// mp2 : m + 2.
// Pmm_x , Pmp1m_x: P(m , m , x) and P(m+1 , m , x)
// x : variable of the associated Legendre function.


void spherical_harmonics::Plm_tables_calc (const int m , const class array<double> &x_tab , class array<double> &Plm_tab)
{
  if (m < 0) 
    {
      Plm_tables_calc (-m , x_tab , Plm_tab);

      Plm_tab *= minus_one_pow (m);

      return ;
    }

  const int lmax = Plm_tab.dimension (0) - 1;

  const unsigned int N = x_tab.dimension (0);

  const int mm1 = m - 1;
  
  Plm_tab = 0.0;

  if (m <= lmax)
    {
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const double x = x_tab(i);

	  const double Pmm_x = pow (sqrt (1.0 - x*x) , m);

	  Plm_tab(m , i) = Pmm_x;

	  if (m < lmax)
	    {
	      const double Pmp1m_x = (2*m + 1)*x*Pmm_x;
	      
	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      Plm_tab(mp1 , i) = Pmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		Plm_tab(l , i) = (x*(2*l - 1)*Plm_tab(l-1 , i) - (l + mm1)*Plm_tab(l-2 , i))/static_cast<double> (l - m);
	    }
	}
    }
}


void spherical_harmonics::PYlm_tables_calc (
					    const int m , 
					    const class array<double> &x_tab , 
					    class array<double> &PYlm_tab)
{	
  if (m < 0) 
    {
      PYlm_tables_calc (-m , x_tab , PYlm_tab);

      PYlm_tab *= minus_one_pow (m);
    }
  else
    {	
      Plm_tables_calc (m , x_tab , PYlm_tab);

      const int lmax = PYlm_tab.dimension (0) - 1;

      const unsigned int N = x_tab.dimension (0);

      for (int l = m ; l <= lmax ; l++)
	{
	  const double norm_const = norm_const_calc (l , m);

	  for (unsigned int i = 0 ; i < N ; i++) 
	    PYlm_tab(l , i) *= norm_const;
	}
    }
}



// Calculation of the associated Legendre function P(l , m , x) for a table of l , m and x values
// -----------------------------------------------------------------------------------------
//
// Variables:
// ----------
// x_tab , Plm_tab: table of x and associated Legendre functions values 
//              One has: x_tab(i) , Plm_tab(l , m , i) , i in [0:N-1] , l in [0:lmax] , m in [0:m_max] , 
//                       with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1 and m_max = Plm_tab.dimension (1) - 1
// N , lmax , m_max: number of x values , maximal orbital and azimuthal angular momentum
// m_max_l: maximal physical value of m; it is min(lmax , m_max)
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const: normalization constant
// mp2 : m + 2.
// Pmm_x , Pmp1m_x: P(m , m , x) and P(m+1 , m , x)
// x : variable of the associated Legendre function.

void spherical_harmonics::Plm_tables_calc (const class array<double> &x_tab , class array<double> &Plm_tab)
{
  const int lmax = Plm_tab.dimension (0) - 1;

  const int m_max = Plm_tab.dimension (1) - 1;

  const int m_max_l = min (lmax , m_max);

  const unsigned int N = x_tab.dimension (0);
  
  Plm_tab = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i); 

      for (int m = 0 ; m <= m_max_l ; m++)
	{
	  const int mm1 = m - 1;
  
	  const double Pmm_x = pow (sqrt (1.0 - x*x) , m);

	  Plm_tab(m , m , i) = Pmm_x;

	  if (m < lmax)
	    {
	      const double Pmp1m_x = (2*m + 1)*x*Pmm_x;

	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      Plm_tab(mp1 , m , i) = Pmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		Plm_tab(l , m , i) = (x*(2*l - 1)*Plm_tab(l-1 , m , i) - (l + mm1)*Plm_tab(l-2 , m , i))/static_cast<double> (l - m);
	    }
	}
    }
}

void spherical_harmonics::PYlm_tables_calc (const class array<double> &x_tab , class array<double> &PYlm_tab)
{
  Plm_tables_calc (x_tab , PYlm_tab);

  const int lmax = PYlm_tab.dimension (0) - 1;

  const int m_max = PYlm_tab.dimension (1) - 1;

  const unsigned int N = x_tab.dimension (0);

  for (int m = 0 ; m <= m_max ; m++)
    for (int l = m ; l <= lmax ; l++)
      {
	const double norm_const = norm_const_calc (l , m);

	for (unsigned int i = 0 ; i < N ; i++) 
	  PYlm_tab(l , m , i) *= norm_const;
      }
}


// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx for a table of x values
// ----------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab: table of x and associated Legendre functions and derivatives values 
//                     One has: x_tab(i) , (d)Plm_tab(i) , i in [0:N-1] , with N = x_tab.dimension (0)
// N: number of x values
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// two_m_p1: 2.m + 1
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 : m + 2.
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x: P(m , m , x) , P(m+1 , m , x) , P'(m , m , x) and P'(m+1 , m , x)
// ll , Plm_ll , Plm_llm1 , Plm_llm2 , dPlm_ll , dPlm_llm1 , dPlm_llm2 : associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1.
//                                  ll goes from m to l.
// x : variable of the associated Legendre function.
// ll_minus_m_inv: 1/(ll - m) for ll >= m+2

void spherical_harmonics::Plm_dPlm_tables_calc (
						const int l , 
						const int m , 
						const class array<double> &x_tab , 
						class array<double> &Plm_tab , 
						class array<double> &dPlm_tab)
{
  if (m < 0) 
    {
      Plm_dPlm_tables_calc (l , -m , x_tab , Plm_tab , dPlm_tab);

      const int m_phase = minus_one_pow (m);

      Plm_tab *= m_phase;

      dPlm_tab *= m_phase;

      return;
    }

  const unsigned int N = x_tab.dimension (0);

  const int mm1 = m - 1;
  const int mm2 = m - 2;
  
  Plm_tab = 0.0;

  dPlm_tab = 0.0;

  if (l < m) return;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double sqrt_one_mx2 = sqrt (1.0 - x*x);

      const double Pmm_x = pow (sqrt_one_mx2 , m);

      const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

      if (l == m) 
	Plm_tab(i) = Pmm_x , dPlm_tab(i) = dPmm_x;
      else
	{
	  const int mp1 = m + 1;
	  
	  const int two_m_p1 = 2*m + 1;

	  const double Pmp1m_x = two_m_p1*x*Pmm_x;

	  const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	  if (l == mp1)
	    {
	      Plm_tab(i) = Pmp1m_x;

	      dPlm_tab(i) = dPmp1m_x;
	    }
	  else
	    {
	      const int mp2 = m + 2;

	      double dPlm_llm1 = dPmp1m_x;

	      double dPlm_llm2 = dPmm_x;

	      double dPlm_ll = 0.0;

	      double Plm_llm1 = Pmp1m_x;

	      double Plm_llm2 = Pmm_x;

	      double Plm_ll = 0.0;

	      for (int ll = mp2 ; ll <= l ; ll++)
		{
		  const int two_ll_m1 = 2*ll - 1;

		  const int ll_plus_mm1 = ll + mm1;

		  const double ll_minus_m_inv = 1.0/static_cast<double> (ll - m);

		  dPlm_ll = (two_ll_m1*(x*dPlm_llm1 + Plm_llm1) - ll_plus_mm1*dPlm_llm2)*ll_minus_m_inv;

		  Plm_ll = (two_ll_m1*x*Plm_llm1 - ll_plus_mm1*Plm_llm2)*ll_minus_m_inv;

		  dPlm_llm2 = dPlm_llm1;

		  dPlm_llm1 = dPlm_ll;

		  Plm_llm2 = Plm_llm1;

		  Plm_llm1 = Plm_ll;
		}

	      Plm_tab(i) = Plm_ll;

	      dPlm_tab(i) = dPlm_ll;
	    }
	}
    }
}


void spherical_harmonics::PYlm_dPYlm_tables_calc (
						  const int l , 
						  const int m , 
						  const class array<double> &x_tab , 
						  class array<double> &PYlm_tab , 
						  class array<double> &dPYlm_tab)
{
  if (m < 0) 
    {
      PYlm_dPYlm_tables_calc (l , -m , x_tab , PYlm_tab , dPYlm_tab);

      const int m_phase = minus_one_pow (m);

      PYlm_tab  *= m_phase;
      dPYlm_tab *= m_phase;
    }
  else
    {	
      Plm_dPlm_tables_calc (l , -m , x_tab , PYlm_tab , dPYlm_tab);

      const double norm_const = norm_const_calc (l , m);

      PYlm_tab  *= norm_const;
      dPYlm_tab *= norm_const;
    }
}




// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx for a table of x and l values
// -----------------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab: table of x and associated Legendre functions and derivatives values 
//                     One has: x_tab(i) , (d)Plm_tab(l , i) , i in [0:N-1] , l in [0:lmax] , with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1
// N , lmax: number of x values , maximal orbital angular momentum
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 , two_m_p1 , two_l_m1 , l_plus_mm1 , lm1 , lm2: m + 2 , 2.m + 1 , 2.l - 1 , l + m - 1 , l - 1 , l - 2
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x: P(m , m , x) , P(m+1 , m , x) , P'(m , m , x) and P'(m+1 , m , x)
// x : variable of the associated Legendre function.
// l_minus_m_inv: 1/(l - m) for l >= m+2

void spherical_harmonics::Plm_dPlm_tables_calc (
						const int m , 
						const class array<double> &x_tab , 
						class array<double> &Plm_tab , 
						class array<double> &dPlm_tab)
{
  if (m < 0) 
    {
      Plm_dPlm_tables_calc (-m , x_tab , Plm_tab , dPlm_tab);

      const int m_phase = minus_one_pow (m);

      Plm_tab  *= m_phase;
      dPlm_tab *= m_phase;

      return ;
    }

  const int lmax = Plm_tab.dimension (0) - 1;

  const unsigned int N = x_tab.dimension (0);

  const int mm1 = m - 1;
  const int mm2 = m - 2;
  
  Plm_tab  = 0.0;
  dPlm_tab = 0.0;

  if (m <= lmax)
    {
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const double x = x_tab(i);

	  const double sqrt_one_mx2 = sqrt (1.0 - x*x);

	  const double Pmm_x = pow (sqrt_one_mx2 , m);

	  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

	  Plm_tab(m , i) = Pmm_x;
	
	  dPlm_tab(m , i) = dPmm_x;

	  if (m < lmax)
	    {
	      const int two_m_p1 = 2*m + 1;

	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      const double Pmp1m_x = two_m_p1*x*Pmm_x;

	      const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	      Plm_tab(mp1 , i) = Pmp1m_x;

	      dPlm_tab(mp1 , i) = dPmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		{
		  const int two_l_m1 = 2*l - 1;

		  const int l_plus_mm1 = l + mm1;
		
		  const int lm1 = l - 1;
		  const int lm2 = l - 2;

		  const double l_minus_m_inv = 1.0/static_cast<double> (l - m);

		  dPlm_tab(l , i) = (two_l_m1*(x*dPlm_tab(lm1 , i) + Plm_tab(lm1 , i)) - l_plus_mm1*dPlm_tab(lm2 , i))*l_minus_m_inv;

		  Plm_tab(l , i) = (two_l_m1*x*Plm_tab(lm1 , i) - l_plus_mm1*Plm_tab(lm2 , i))*l_minus_m_inv;
		}
	    }
	}
    }
}


void spherical_harmonics::PYlm_dPYlm_tables_calc (
						  const int m , 
						  const class array<double> &x_tab , 
						  class array<double> &PYlm_tab , 
						  class array<double> &dPYlm_tab)
{
  if (m < 0) 
    {
      PYlm_dPYlm_tables_calc (-m , x_tab , PYlm_tab , dPYlm_tab);

      const int m_phase = minus_one_pow (m);

      PYlm_tab  *= m_phase;
      dPYlm_tab *= m_phase;
    }
  else
    {	
      Plm_dPlm_tables_calc (m , x_tab , PYlm_tab , dPYlm_tab);

      const int lmax = PYlm_tab.dimension (0) - 1;

      const unsigned int N = x_tab.dimension (0);

      for (int l = m ; l <= lmax ; l++)
	{
	  const double norm_const = norm_const_calc (l , m);

	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      PYlm_tab (l , i) *= norm_const;
	      dPYlm_tab(l , i) *= norm_const;
	    }
	}
    }
}






// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx for a table of x and l values
// -----------------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab: table of x and associated Legendre functions and derivatives values 
//              One has: x_tab(i) , (d)Plm_tab(l , m , i) , i in [0:N-1] , l in [0:lmax] , m in [0:m_max] , 
//                       with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1 and m_max = Plm_tab.dimension (1) - 1
// N , lmax , m_max: number of x values , maximal orbital and azimuthal angular momentum
// m_max_l: maximal physical value of m; it is min(lmax , m_max)
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// mp2 , two_m_p1 , two_l_m1 , l_plus_mm1 , lm1 , lm2: m + 2 , 2.m + 1 , 2.l - 1 , l + m - 1 , l - 1 , l - 2
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x: P(m , m , x) , P(m+1 , m , x) , P'(m , m , x) and P'(m+1 , m , x)
// x : variable of the associated Legendre function.
// l_minus_m_inv: 1/(l - m) for l >= m+2

void spherical_harmonics::Plm_dPlm_tables_calc (
						const class array<double> &x_tab , 
						class array<double> &Plm_tab , 
						class array<double> &dPlm_tab)
{
  const int lmax = Plm_tab.dimension (0) - 1;

  const int m_max = Plm_tab.dimension (1) - 1;

  const int m_max_l = min (lmax , m_max);

  const unsigned int N = x_tab.dimension (0);
  
  Plm_tab  = 0.0;
  dPlm_tab = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double sqrt_one_mx2 = sqrt (1.0 - x*x); 

      for (int m = 0 ; m <= m_max_l ; m++)
	{
	  const int mm1 = m - 1;
	  const int mm2 = m - 2;
	  
	  const double Pmm_x = pow (sqrt_one_mx2 , m);

	  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

	  Plm_tab(m , m , i) = Pmm_x , dPlm_tab(m , m , i) = dPmm_x;

	  if (m < lmax)
	    {
	      const int two_m_p1 = 2*m + 1;

	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      const double Pmp1m_x = two_m_p1*x*Pmm_x;

	      const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	      Plm_tab(mp1 , m , i) = Pmp1m_x;

	      dPlm_tab(mp1 , m , i) = dPmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		{
		  const int two_l_m1 = 2*l - 1;

		  const int l_plus_mm1 = l + mm1;

		  const int lm1 = l - 1;
		  const int lm2 = l - 2;

		  const double l_minus_m_inv = 1.0/static_cast<double> (l - m);

		  dPlm_tab(l , m , i) = (two_l_m1*(x*dPlm_tab(lm1 , m , i) + Plm_tab(lm1 , m , i)) - l_plus_mm1*dPlm_tab(lm2 , m , i))*l_minus_m_inv;

		  Plm_tab(l , m , i) = (two_l_m1*x*Plm_tab(lm1 , m , i) - l_plus_mm1*Plm_tab(lm2 , m , i))*l_minus_m_inv;
		}
	    }
	} 
    }
}



void spherical_harmonics::PYlm_dPYlm_tables_calc (
						  const class array<double> &x_tab , 
						  class array<double> &PYlm_tab , 
						  class array<double> &dPYlm_tab)
{
  Plm_dPlm_tables_calc (x_tab , PYlm_tab , dPYlm_tab);

  const int lmax = PYlm_tab.dimension (0) - 1;

  const int m_max = PYlm_tab.dimension (1) - 1;

  const unsigned int N = x_tab.dimension (0);

  for (int m = 0 ; m <= m_max ; m++)
    for (int l = m ; l <= lmax ; l++)
      {
	const double norm_const = norm_const_calc (l , m);

	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    PYlm_tab (l , m , i) *= norm_const;
	    dPYlm_tab(l , m , i) *= norm_const;
	  }
      }
}






// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx , d2P(l , m , x)/dx2 for a table of x values
// --------------------------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab: table of x and associated Legendre functions and derivatives values 
//                     One has: x_tab(i) , (d)Plm_tab(i) , i in [0:N-1] , with N = x_tab.dimension (0)
// N: number of x values
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// two_m_p1: 2.m + 1
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 : m + 2.
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x , d2Pmm_x , d2Pmp1m_x: P(m , m , x) , P(m+1 , m , x) , first and second derivatives
// m_minus_two_term: (m-2).x^2.(1 - x^2)^(m/2 - 4) if m != 2 , and 0 if m=2 (then OK if x^2 = 1).
// ll , Plm_ll , Plm_llm1 , Plm_llm2 , dPlm_ll , dPlm_llm1 , dPlm_llm2 , d2Plm_ll , d2Plm_llm1 , d2Plm_llm2 : 
//                                                                 associated Legendre functions of degree ll , ll - 1 and ll - 2 , ll > m + 1.
//                                                                 ll goes from m to l.
// x : variable of the associated Legendre function.
// ll_minus_m_inv: 1/(ll - m) for ll >= m+2

void spherical_harmonics::Plm_dPlm_d2Plm_tables_calc (
						      const int l , 
						      const int m , 
						      const class array<double> &x_tab , 
						      class array<double> &Plm_tab , 
						      class array<double> &dPlm_tab , 
						      class array<double> &d2Plm_tab)
{
  if (m < 0) 
    {
      Plm_dPlm_d2Plm_tables_calc (l , -m , x_tab , Plm_tab , dPlm_tab , d2Plm_tab);

      const int m_phase = minus_one_pow (m);
      
      Plm_tab   *= m_phase;
      dPlm_tab  *= m_phase;
      d2Plm_tab *= m_phase;

      return;
    }

  const unsigned int N = x_tab.dimension (0);

  Plm_tab   = 0.0;
  dPlm_tab  = 0.0;
  d2Plm_tab = 0.0;

  if (l < m) return;

  const int mm1 = m - 1;
  const int mm2 = m - 2;
  const int mm4 = m - 4;
	  
  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double sqrt_one_mx2 = sqrt (1.0 - x*x);

      const double Pmm_x = pow (sqrt_one_mx2 , m);

      const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0); 

      const double m_minus_two_term = (m != 2) ? (mm2*x*x*pow (sqrt_one_mx2 , mm4)) : (0.0);

      const double d2Pmm_x = (m > 0) ? (m*(m_minus_two_term - pow (sqrt_one_mx2 , mm2))) : (0.0);

      if (l == m)
	{
	  Plm_tab(i) = Pmm_x;

	  dPlm_tab(i) = dPmm_x;

	  d2Plm_tab(i) = d2Pmm_x;
	}
      else
	{
	  const int mp1 = m + 1;
	  
	  const int two_m_p1 = 2*m + 1;

	  const double Pmp1m_x = two_m_p1*x*Pmm_x;

	  const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	  const double d2Pmp1m_x = two_m_p1*(x*d2Pmm_x + 2.0*dPmm_x);

	  if (l == mp1)
	    {
	      Plm_tab(i) = Pmp1m_x;

	      dPlm_tab(i) = dPmp1m_x;

	      d2Plm_tab(i) = d2Pmp1m_x;
	    }
	  else
	    {
	      const int mp2 = m + 2;

	      double d2Plm_llm1 = d2Pmp1m_x;
	      double d2Plm_llm2 = d2Pmm_x;
	      double d2Plm_ll   = 0.0;

	      double dPlm_llm1 = dPmp1m_x;
	      double dPlm_llm2 = dPmm_x;
	      double dPlm_ll   = 0.0;

	      double Plm_llm1 = Pmp1m_x;
	      double Plm_llm2 = Pmm_x;
	      double Plm_ll   = 0.0;

	      for (int ll = mp2 ; ll <= l ; ll++)
		{
		  const int two_ll_m1 = 2*ll - 1;

		  const int ll_plus_mm1 = ll + mm1;

		  const double ll_minus_m_inv = 1.0/static_cast<double> (ll - m);

		  d2Plm_ll = (two_ll_m1*(x*d2Plm_llm1 + 2.0*dPlm_llm1) - ll_plus_mm1*d2Plm_llm2)*ll_minus_m_inv;

		  dPlm_ll = (two_ll_m1*(x*dPlm_llm1 + Plm_llm1) - ll_plus_mm1*dPlm_llm2)*ll_minus_m_inv;

		  Plm_ll = (two_ll_m1*x*Plm_llm1 - ll_plus_mm1*Plm_llm2)*ll_minus_m_inv;

		  d2Plm_llm2 = d2Plm_llm1;
		  d2Plm_llm1 = d2Plm_ll;

		  dPlm_llm2 = dPlm_llm1;
		  dPlm_llm1 = dPlm_ll;

		  Plm_llm2 = Plm_llm1;
		  Plm_llm1 = Plm_ll;
		}

	      Plm_tab(i) = Plm_ll;
	      
	      dPlm_tab(i) = dPlm_ll;
	      
	      d2Plm_tab(i) = d2Plm_ll;
	    }
	}
    }
}




void spherical_harmonics::PYlm_dPYlm_d2PYlm_tables_calc (
							 const int l , 
							 const int m , 
							 const class array<double> &x_tab , 
							 class array<double> &PYlm_tab , 
							 class array<double> &dPYlm_tab , 
							 class array<double> &d2PYlm_tab)
{
  if (m < 0) 
    {
      PYlm_dPYlm_d2PYlm_tables_calc (l , -m , x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

      const int m_phase = minus_one_pow (m);

      PYlm_tab   *= m_phase;
      dPYlm_tab  *= m_phase;
      d2PYlm_tab *= m_phase;
    }
  else
    {	
      Plm_dPlm_d2Plm_tables_calc (l , m , x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

      const double norm_const = norm_const_calc (l , m);

      PYlm_tab   *= norm_const;
      dPYlm_tab  *= norm_const;
      d2PYlm_tab *= norm_const;
    }
}



// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx , d2P(l , m , x)/dx2 for a table of x and l values
// --------------------------------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab , d2Plm_tab: table of x and associated Legendre functions , first and second derivatives values 
//                             One has: x_tab(i) , (d(2))Plm_tab(l , i) , i in [0:N-1] , l in [0:lmax] , with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1
// N , lmax: number of x values , maximal orbital angular momentum
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// mp2 , two_m_p1 , two_l_m1 , l_plus_mm1 , lm1 , lm2: m + 2 , 2.m + 1 , 2.l - 1 , l + m - 1 , l - 1 , l - 2
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x , d2Pmm_x , d2Pmp1m_x: P(m , m , x) , P(m+1 , m , x) , first and second derivatives
// m_minus_two_term: (m-2).x^2.(1 - x^2)^(m/2 - 4) if m != 2 , and 0 if m=2 (then OK if x^2 = 1).
// x : variable of the associated Legendre function.
// l_minus_m_inv: 1/(l - m) for l >= m+2

void spherical_harmonics::Plm_dPlm_d2Plm_tables_calc (
						      const int m , 
						      const class array<double> &x_tab , 
						      class array<double> &Plm_tab , 
						      class array<double> &dPlm_tab , 
						      class array<double> &d2Plm_tab)
{
  if (m < 0) 
    {
      Plm_dPlm_d2Plm_tables_calc (-m , x_tab , Plm_tab , dPlm_tab , d2Plm_tab);

      const int m_phase = minus_one_pow (m);

      Plm_tab   *= m_phase;
      dPlm_tab  *= m_phase;
      d2Plm_tab *= m_phase;

      return ;
    }

  const int lmax = Plm_tab.dimension (0) - 1;

  const unsigned int N = x_tab.dimension (0);

  Plm_tab   = 0.0;
  dPlm_tab  = 0.0;
  d2Plm_tab = 0.0;

  if (m <= lmax)
    {
      const int mm1 = m - 1;
      const int mm2 = m - 2;
      const int mm4 = m - 4;
  
      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const double x = x_tab(i);

	  const double sqrt_one_mx2 = sqrt (1.0 - x*x);

	  const double Pmm_x = pow (sqrt_one_mx2 , m);

	  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

	  const double m_minus_two_term = (m != 2) ? (mm2*x*x*pow (sqrt_one_mx2 , mm4)) : (0.0);

	  const double d2Pmm_x = (m > 0) ? (m*(m_minus_two_term - pow (sqrt_one_mx2 , mm2))) : (0.0);

	  Plm_tab(m , i) = Pmm_x;
	  
	  dPlm_tab(m , i) = dPmm_x;
	  
	  d2Plm_tab(m , i) = d2Pmm_x;

	  if (m < lmax)
	    {
	      const int two_m_p1 = 2*m + 1;

	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      const double Pmp1m_x = two_m_p1*x*Pmm_x;

	      const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	      const double d2Pmp1m_x = two_m_p1*(x*d2Pmm_x + 2.0*dPmm_x);

	      Plm_tab(mp1 , i) = Pmp1m_x;
	      
	      dPlm_tab(mp1 , i) = dPmp1m_x;
	      
	      d2Plm_tab(mp1 , i) = d2Pmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		{
		  const int two_l_m1 = 2*l - 1;

		  const int l_plus_mm1 = l + mm1;

		  const int lm1 = l - 1;
		  const int lm2 = l - 2;

		  const double l_minus_m_inv = 1.0/static_cast<double> (l - m);

		  d2Plm_tab(l , i) = (two_l_m1*(x*d2Plm_tab(lm1 , i) + 2.0*dPlm_tab(lm1 , i)) - l_plus_mm1*d2Plm_tab(lm2 , i))*l_minus_m_inv;

		  dPlm_tab(l , i) = (two_l_m1*(x*dPlm_tab(lm1 , i) + Plm_tab(lm1 , i)) - l_plus_mm1*dPlm_tab(lm2 , i))*l_minus_m_inv;

		  Plm_tab(l , i) = (two_l_m1*x*Plm_tab(lm1 , i) - l_plus_mm1*Plm_tab(lm2 , i))*l_minus_m_inv;
		}
	    }
	}
    }
}




void spherical_harmonics::PYlm_dPYlm_d2PYlm_tables_calc (
							 const int m , 
							 const class array<double> &x_tab , 
							 class array<double> &PYlm_tab , 
							 class array<double> &dPYlm_tab , 
							 class array<double> &d2PYlm_tab)
{
  if (m < 0) 
    {
      PYlm_dPYlm_d2PYlm_tables_calc (-m , x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

      const int m_phase = minus_one_pow (m);

      PYlm_tab   *= m_phase;
      dPYlm_tab  *= m_phase;
      d2PYlm_tab *= m_phase;
    }
  else
    {	
      Plm_dPlm_d2Plm_tables_calc (m , x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

      const int lmax = PYlm_tab.dimension (0) - 1;

      const unsigned int N = x_tab.dimension (0);

      for (int l = m ; l <= lmax ; l++)
	{
	  const double norm_const = norm_const_calc (l , m);

	  for (unsigned int i = 0 ; i < N ; i++)
	    {
	      PYlm_tab(l , i)   *= norm_const;
	      dPYlm_tab(l , i)  *= norm_const;
	      d2PYlm_tab(l , i) *= norm_const;
	    }
	}
    }
}






// Calculation of the associated Legendre function P(l , m , x) , dP(l , m , x)/dx , d2P(l , m , x)/dx2 for a table of x and l values
// --------------------------------------------------------------------------------------------------------------------
// 
// Variables:
// ----------
// x_tab , Plm_tab , dPlm_tab , d2Plm_tab: table of x and associated Legendre functions , first and second derivatives values 
//              One has: x_tab(i) , (d(2))Plm_tab(l , m , i) , i in [0:N-1] , l in [0:lmax] , m in [0:m_max] , 
//                       with N = x_tab.dimension (0) and lmax = Plm_tab.dimension (0) - 1 and m_max = Plm_tab.dimension (1) - 1
// N , lmax , m_max: number of x values , maximal orbital and azimuthal angular momentum
// m_max_l: maximal physical value of m; it is min(lmax , m_max)
// l , m , x : orbital , azimuthal angular momenta , argument of the associated Legendre function
// mp2 , two_m_p1 , two_l_m1 , l_plus_mm1 , lm1 , lm2: m + 2 , 2.m + 1 , 2.l - 1 , l + m - 1 , l - 1 , l - 2
// norm_const , sqrt_one_mx2: normalization constant , sqrt(1-x^2)
// Pmm_x , Pmp1m_x , dPmm_x , dPmp1m_x , d2Pmm_x , d2Pmp1m_x: P(m , m , x) , P(m+1 , m , x) , first and second derivatives
// m_minus_two_term: (m-2).x^2.(1 - x^2)^(m/2 - 4) if m != 2 , and 0 if m=2 (then OK if x^2 = 1).
// x : variable of the associated Legendre function.
// l_minus_m_inv: 1/(l - m) for l >= m+2

void spherical_harmonics::Plm_dPlm_d2Plm_tables_calc (
						      const class array<double> &x_tab , 
						      class array<double> &Plm_tab , 
						      class array<double> &dPlm_tab , 
						      class array<double> &d2Plm_tab)
{
  const int lmax = Plm_tab.dimension (0) - 1;

  const int m_max = Plm_tab.dimension (1) - 1;

  const int m_max_l = min (lmax , m_max);

  const unsigned int N = x_tab.dimension (0);

  Plm_tab   = 0.0;
  dPlm_tab  = 0.0;
  d2Plm_tab = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double x = x_tab(i);

      const double sqrt_one_mx2 = sqrt (1.0 - x*x); 

      for (int m = 0 ; m <= m_max_l ; m++)
	{
	  const int mm1 = m - 1;
	  const int mm2 = m - 2;
	  const int mm4 = m - 4;
	  
	  const double Pmm_x = pow (sqrt_one_mx2 , m);

	  const double dPmm_x = (m > 0) ? (-m*x*pow (sqrt_one_mx2 , mm2)) : (0.0);

	  const double m_minus_two_term = (m != 2) ? (mm2*x*x*pow (sqrt_one_mx2 , mm4)) : (0.0);

	  const double d2Pmm_x = (m > 0) ? (m*(m_minus_two_term - pow (sqrt_one_mx2 , mm2))) : (0.0);

	  Plm_tab(m , m , i) = Pmm_x;

	  dPlm_tab(m , m , i) = dPmm_x;

	  d2Plm_tab(m , m , i) = d2Pmm_x;

	  if (m < lmax)
	    {
	      const int two_m_p1 = 2*m + 1;

	      const int mp1 = m + 1;
	      const int mp2 = m + 2;

	      const double Pmp1m_x = two_m_p1*x*Pmm_x;

	      const double dPmp1m_x = two_m_p1*(x*dPmm_x + Pmm_x);

	      const double d2Pmp1m_x = two_m_p1*(x*d2Pmm_x + 2.0*dPmm_x);

	      Plm_tab(mp1 , m , i) = Pmp1m_x;
	      
	      dPlm_tab(mp1 , m , i) = dPmp1m_x;

	      d2Plm_tab(mp1 , m , i) = d2Pmp1m_x;

	      for (int l = mp2 ; l <= lmax ; l++)
		{
		  const int two_l_m1 = 2*l - 1;

		  const int l_plus_mm1 = l + mm1;

		  const int lm1 = l - 1;

		  const int lm2 = l - 2;

		  const double l_minus_m_inv = 1.0/static_cast<double> (l - m);

		  d2Plm_tab(l , m , i) = (two_l_m1*(x*d2Plm_tab(lm1 , m , i) + 2.0*dPlm_tab(lm1 , m , i)) - l_plus_mm1*d2Plm_tab(lm2 , m , i))*l_minus_m_inv;

		  dPlm_tab(l , m , i) = (two_l_m1*(x*dPlm_tab(lm1 , m , i) + Plm_tab(lm1 , m , i)) - l_plus_mm1*dPlm_tab(lm2 , m , i))*l_minus_m_inv;

		  Plm_tab(l , m , i) = (two_l_m1*x*Plm_tab(lm1 , m , i) - l_plus_mm1*Plm_tab(lm2 , m , i))*l_minus_m_inv;
		}
	    }
	} 
    }
}




void spherical_harmonics::PYlm_dPYlm_d2PYlm_tables_calc (
							 const class array<double> &x_tab , 
							 class array<double> &PYlm_tab , 
							 class array<double> &dPYlm_tab , 
							 class array<double> &d2PYlm_tab)
{
  Plm_dPlm_d2Plm_tables_calc (x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

  const int lmax = PYlm_tab.dimension (0) - 1;

  const int m_max = PYlm_tab.dimension (1) - 1;

  const unsigned int N = x_tab.dimension (0);

  for (int m = 0 ; m <= m_max ; m++)
    for (int l = m ; l <= lmax ; l++)
      {
	const double norm_const = norm_const_calc (l , m);

	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    PYlm_tab  (l , m , i) *= norm_const;
	    dPYlm_tab (l , m , i) *= norm_const;
	    d2PYlm_tab(l , m , i) *= norm_const;
	  }
      }
}


