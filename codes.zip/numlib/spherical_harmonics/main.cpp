#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void fixed_functions_test (
			   const class array<double> &x_tab , 
			   const class array<double> &w_tab , 
			   const int m , 
			   const int l , 
			   const int lp)
{
  if (abs (m) > l) return;
  
  const unsigned int N = x_tab.dimension (0);

  double I0 = 0.0;
  double I1 = 0.0;
  double I2 = 0.0;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double x = x_tab(i);
      const double w = w_tab(i);

      const double PYlm   = spherical_harmonics::PYlm      (l , m , x);
      const double dPYlm  = spherical_harmonics::PYlm_der  (l , m , x);
      const double d2PYlm = spherical_harmonics::PYlm_2der (l , m , x);

      const double PYlpm = spherical_harmonics::PYlm (lp , m , x);

      I0 += PYlm*PYlpm*w;
      I1 += PYlm*dPYlm*w;
      
      I2 += PYlpm*((1.0 - x*x)*d2PYlm - 2.0*x*dPYlm - m*m/(1.0 - x*x)*PYlm)*w;
    }

  if (l == lp)
    {
      I0 -= 0.5*M_1_PI;

      I2 += l*(l+1)*0.5*M_1_PI;
    }
  
  I0 = abs (I0);
  I1 = abs (I1);
  I2 = abs (I2);
  
  if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision)) error_message_print_abort ("Problem in fixed_functions_test");

  cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << "  I1 = " << I1 << "  I2 = " << I2 << endl;
}



void tables_functions_PYlm_fixed_m_test (
					 const class array<double> &x_tab , 
					 const class array<double> &w_tab , 
					 const int m , 
					 const int l_max)
{
  const int abs_m = abs (m);
  
  if (abs_m > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double> PYlm_tab(l_max+1 , N);

  spherical_harmonics::PYlm_tables_calc (m , x_tab , PYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      {
	if ((abs_m <= l) && (abs_m <= lp))
	  {
	    double I0 = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double w = w_tab(i);

		const double PYlm  = PYlm_tab(l  , i);
		const double PYlpm = PYlm_tab(lp , i);

		I0 += PYlm*PYlpm*w;
	      }

	    if (l == lp) I0 -= 0.5*M_1_PI;

	    I0 = abs (I0);
  
	    if (I0 > sqrt_precision) error_message_print_abort ("Problem in tables_functions_PYlm_fixed_m_test");
  
	    cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << endl;
	  }
      }
}
    

void tables_functions_PYlm_dPYlm_fixed_m_test (
					       const class array<double> &x_tab , 
					       const class array<double> &w_tab , 
					       const int m , 
					       const int l_max)
{
  const int abs_m = abs (m);
  
  if (abs_m > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double>  PYlm_tab(l_max+1 , N);
  class array<double> dPYlm_tab(l_max+1 , N);

  spherical_harmonics::PYlm_dPYlm_tables_calc (m , x_tab , PYlm_tab , dPYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      {
	if ((abs_m <= l) && (abs_m <= lp))
	  {
	    double I0 = 0.0 , I1 = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double w = w_tab(i);

		const double PYlm  =  PYlm_tab(l  , i);
		const double dPYlm = dPYlm_tab(l , i);

		const double PYlpm = PYlm_tab(lp , i);

		I0 += PYlm*PYlpm*w;
		I1 += PYlm*dPYlm*w;
	      }

	    if (l == lp) I0 -= 0.5*M_1_PI;

	    I0 = abs (I0);
	    I1 = abs (I1);
  
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision)) error_message_print_abort ("Problem in tables_functions_PYlm_dPYlm_fixed_m_test");
  
	    cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << "  I1 = " << I1 << endl;
	  }
      }
}


void tables_functions_PYlm_dPYlm_d2PYlm_fixed_m_test (
						      const class array<double> &x_tab , 
						      const class array<double> &w_tab , 
						      const int m , 
						      const int l_max)
{
  const int abs_m = abs (m);
  
  if (abs_m > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double>   PYlm_tab(l_max+1 , N);
  class array<double>  dPYlm_tab(l_max+1 , N);
  class array<double> d2PYlm_tab(l_max+1 , N);

  spherical_harmonics::PYlm_dPYlm_d2PYlm_tables_calc (m , x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      {
	if ((abs_m <= l) && (abs_m <= lp))
	  {
	    double I0 = 0.0;
	    double I1 = 0.0;
	    double I2 = 0.0;

	    for (unsigned int i = 0 ; i < N ; i++) 
	      {
		const double x = x_tab(i);
		const double w = w_tab(i);

		const double PYlm   =   PYlm_tab(l , i);
		const double dPYlm  =  dPYlm_tab(l , i);
		const double d2PYlm = d2PYlm_tab(l , i);

		const double PYlpm = PYlm_tab(lp , i);

		I0 += PYlm*PYlpm*w;
		I1 += PYlm*dPYlm*w;
		
		I2 += PYlpm*((1.0 - x*x)*d2PYlm - 2.0*x*dPYlm - m*m/(1.0 - x*x)*PYlm)*w;
	      }

	    if (l == lp) I0 -= 0.5*M_1_PI , I2 += l*(l+1)*0.5*M_1_PI;

	    I0 = abs (I0);
	    I1 = abs (I1);
	    I2 = abs (I2);
  
	    if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision)) error_message_print_abort ("Problem in tables_functions_PYlm_dPYlm_d2PYlm_fixed_m_test");
  
	    cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << "  I1 = " << I1 << "  I2 = " << I2 << endl;
	  }
      }
}
  

void tables_functions_PYlm_test (
				 const class array<double> &x_tab , 
				 const class array<double> &w_tab , 	
				 const int l_max , 
				 const int m_max)
{
  if (abs (m_max) > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double> PYlm_tab(l_max+1 , m_max+1 , N);

  spherical_harmonics::PYlm_tables_calc (x_tab , PYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      for (int m = 0 ; m <= m_max ; m++)
	{
	  if ((m <= l) && (m <= lp))
	    {
	      double I0 = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double w = w_tab(i);

		  const double PYlm  = PYlm_tab(l  , m , i);
		  const double PYlpm = PYlm_tab(lp , m , i);

		  I0 += PYlm*PYlpm*w;
		}

	      if (l == lp) I0 -= 0.5*M_1_PI;

	      I0 = abs (I0);
  
	      if (I0 > sqrt_precision) error_message_print_abort ("Problem in tables_functions_PYlm_test");
	    
	      cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << endl;
	    }
	}
}




 
void tables_functions_PYlm_dPYlm_test (
				       const class array<double> &x_tab , 
				       const class array<double> &w_tab , 	
				       const int l_max , 
				       const int m_max)
{
  if (abs (m_max) > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double>  PYlm_tab(l_max+1 , m_max+1 , N);
  class array<double> dPYlm_tab(l_max+1 , m_max+1 , N);

  spherical_harmonics::PYlm_dPYlm_tables_calc (x_tab , PYlm_tab , dPYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      for (int m = 0 ; m <= m_max ; m++)
	{
	  if ((m <= l) && (m <= lp))
	    {
	      double I0 = 0.0 , I1 = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double w = w_tab(i);

		  const double PYlm  =  PYlm_tab(l , m , i);
		  const double dPYlm = dPYlm_tab(l , m , i);

		  const double PYlpm = PYlm_tab(lp , m , i);

		  I0 += PYlm*PYlpm*w;
		  I1 += PYlm*dPYlm*w;
		}

	      if (l == lp) I0 -= 0.5*M_1_PI;

	      I0 = abs (I0);
	      I1 = abs (I1);
  
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision)) error_message_print_abort ("Problem in tables_functions_PYlm_dPYlm_test");
  
	      cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << "  I1 = " << I1 << endl;
	    }
	}
}
 


void tables_functions_PYlm_dPYlm_d2PYlm_test (
					      const class array<double> &x_tab , 
					      const class array<double> &w_tab , 	
					      const int l_max , 
					      const int m_max)
{
  if (abs (m_max) > l_max) return;
  
  const unsigned int N = x_tab.dimension (0);

  class array<double>   PYlm_tab(l_max+1 , m_max+1 , N);
  class array<double>  dPYlm_tab(l_max+1 , m_max+1 , N);
  class array<double> d2PYlm_tab(l_max+1 , m_max+1 , N);

  spherical_harmonics::PYlm_dPYlm_d2PYlm_tables_calc (x_tab , PYlm_tab , dPYlm_tab , d2PYlm_tab);

  for (int l = 0 ; l <= l_max ; l++)
    for (int lp = 0 ; lp <= l ; lp++)
      for (int m = 0 ; m <= m_max ; m++)
	{
	  if ((m <= l) && (m <= lp))
	    {
	      double I0 = 0.0;
	      double I1 = 0.0;
	      double I2 = 0.0;

	      for (unsigned int i = 0 ; i < N ; i++) 
		{
		  const double x = x_tab(i);
		  const double w = w_tab(i);

		  const double PYlm   =   PYlm_tab(l , m , i);
		  const double dPYlm  =  dPYlm_tab(l , m , i);
		  const double d2PYlm = d2PYlm_tab(l , m , i);

		  const double PYlpm = PYlm_tab(lp , m , i);

		  I0 += PYlm*PYlpm*w;
		  I1 += PYlm*dPYlm*w;
		  
		  I2 += PYlpm*((1.0 - x*x)*d2PYlm - 2.0*x*dPYlm - m*m/(1.0 - x*x)*PYlm)*w;
		}

	      if (l == lp) I0 -= 0.5*M_1_PI , I2 += l*(l+1)*0.5*M_1_PI;

	      I0 = abs (I0);
	      I1 = abs (I1);
	      I2 = abs (I2);
  
	      if ((I0 > sqrt_precision) || (I1 > sqrt_precision) || (I2 > sqrt_precision)) error_message_print_abort ("Problem in tables_functions_PYlm_dPYlm_d2PYlm_test");
  
	      cout << "m:"<< m << "  l:"<< l << "  l':"<< lp << "  I0 = " << I0 << "  I1 = " << I1 << "  I2 = " << I2 << endl;
	    }
	}
}





#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    seed ();
    
    cout.precision (15);

    cout << "Tests for spherical harmonics are made with orthogonality and integration by parts." << endl << endl;
    
    cout << "I0 = (1/2 Pi).(int Ylm*(theta , phi) Yl'm(theta , phi) dOmega - delta(l , l')) = 0" << endl;

    cout << "I1 = (1/2 Pi).(int Ylm*(theta , phi) Yl'm'(theta , phi) dOmega) = 0" << endl;

    cout << "I2 = (1/2 Pi).(int Yl'm*(theta , phi) [(1-x^2) Ylm''(theta , phi) - 2x Ylm'(theta , phi) - m^2/(1 - x^2) Ylm(theta , phi)] dOmega + delta(l , l').l(l+1)) = 0" << endl << endl;
    
    cout << "One must have |m| <= l, as otherwise Ylm(theta , phi) = 0." << endl << endl;
    
    const unsigned int N = 100;

    const int lp = 6;
    
    const int l = 7;

    const int l_max = 10;
    const int m_max = 10;

    class array<double> x_tab(N);
    class array<double> w_tab(N);

    Gauss_Legendre::abscissas_weights_tables_calc (-1.0 , 1.0 , x_tab , w_tab);

    cout << "N:" << N << "  l:" << l << "  l':" << lp << "  l_max:" << l_max << "  m_max:" << m_max << endl;

    cout << endl << "Fixed functions test" << endl;

    for (int m = -l ; m <= l ; m++) fixed_functions_test (x_tab , w_tab , m , l , lp);

    cout << endl << "Tables functions fixed m test (u)" << endl;

    for (int m = -l_max ; m <= l_max ; m++) tables_functions_PYlm_fixed_m_test (x_tab , w_tab , m , l_max);

    cout << endl << "Tables functions fixed m test (u du)" << endl;

    for (int m = -l_max ; m <= l_max ; m++) tables_functions_PYlm_dPYlm_fixed_m_test (x_tab , w_tab , m , l_max);

    cout << endl << "Tables functions fixed m test (u du d2u)" << endl;

    for (int m = -l_max ; m <= l_max ; m++) tables_functions_PYlm_dPYlm_d2PYlm_fixed_m_test (x_tab , w_tab , m , l_max);

    cout << endl << "Tables functions test (u)" << endl;

    tables_functions_PYlm_test (x_tab , w_tab , l_max , m_max);

    cout << endl << "Tables functions test (u du)" << endl;

    tables_functions_PYlm_dPYlm_test (x_tab , w_tab , l_max , m_max);

    cout << endl << "Tables functions test (u du d2u)" << endl;

    tables_functions_PYlm_dPYlm_d2PYlm_test (x_tab , w_tab , l_max , m_max);	

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

