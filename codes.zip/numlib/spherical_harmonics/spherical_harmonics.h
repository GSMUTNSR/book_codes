#ifndef SPHERICAL_HARMONICS_H
#define SPHERICAL_HARMONICS_H

namespace spherical_harmonics
{
  double norm_const_calc (const int l , const int m);

  double Plm (const int l , const int m , const double x);
  double PYlm (const int l , const int m , const double x);

  double Plm_der (const int l , const int m , const double x);
  double PYlm_der (const int l , const int m , const double x);

  double Plm_2der (const int l , const int m , const double x);
  double PYlm_2der (const int l , const int m , const double x);

  void Plm_tables_calc (const int l , const int m , const class array<double> &x_tab , class array<double> &Plm_tab);
  void PYlm_tables_calc (const int l , const int m , const class array<double> &x_tab , class array<double> &PYlm_tab);

  void Plm_tables_calc (const int m , const class array<double> &x_tab , class array<double> &Plm_tab);
  void PYlm_tables_calc (const int m , const class array<double> &x_tab , class array<double> &PYlm_tab);

  void Plm_tables_calc (const class array<double> &x_tab , class array<double> &Plm_tab);
  void PYlm_tables_calc (const class array<double> &x_tab , class array<double> &PYlm_tab);

  void Plm_dPlm_tables_calc (
			     const int l , 
			     const int m , 
			     const class array<double> &x_tab , 
			     class array<double> &Plm_tab , 
			     class array<double> &dPlm_tab);

  void PYlm_dPYlm_tables_calc (
			       const int l , 
			       const int m , 
			       const class array<double> &x_tab , 
			       class array<double> &PYlm_tab , 
			       class array<double> &dPYlm_tab);

  void Plm_dPlm_tables_calc (
			     const int m , 
			     const class array<double> &x_tab , 
			     class array<double> &Plm_tab , 
			     class array<double> &dPlm_tab);

  void PYlm_dPYlm_tables_calc (
			       const int m , 
			       const class array<double> &x_tab , 
			       class array<double> &PYlm_tab , 
			       class array<double> &dPYlm_tab);

  void Plm_dPlm_tables_calc (
			     const class array<double> &x_tab , 
			     class array<double> &Plm_tab , 
			     class array<double> &dPlm_tab);

  void PYlm_dPYlm_tables_calc (
			       const class array<double> &x_tab , 
			       class array<double> &PYlm_tab , 
			       class array<double> &dPYlm_tab);

  void Plm_dPlm_d2Plm_tables_calc (
				   const int l , 
				   const int m , 
				   const class array<double> &x_tab , 
				   class array<double> &Plm_tab , 
				   class array<double> &dPlm_tab , 
				   class array<double> &d2Plm_tab);

  void PYlm_dPYlm_d2PYlm_tables_calc (
				      const int l , 
				      const int m , 
				      const class array<double> &x_tab , 
				      class array<double> &PYlm_tab , 
				      class array<double> &dPYlm_tab , 
				      class array<double> &d2PYlm_tab);

  void Plm_dPlm_d2Plm_tables_calc (
				   const int m , 
				   const class array<double> &x_tab , 
				   class array<double> &Plm_tab , 
				   class array<double> &dPlm_tab , 
				   class array<double> &d2Plm_tab);

  void PYlm_dPYlm_d2PYlm_tables_calc (
				      const int m , 
				      const class array<double> &x_tab , 
				      class array<double> &PYlm_tab , 
				      class array<double> &dPYlm_tab , 
				      class array<double> &d2PYlm_tab);

  void Plm_dPlm_d2Plm_tables_calc (
				   const class array<double> &x_tab , 
				   class array<double> &Plm_tab , 
				   class array<double> &dPlm_tab , 
				   class array<double> &d2Plm_tab);

  void PYlm_dPYlm_d2PYlm_tables_calc (
				      const class array<double> &x_tab , 
				      class array<double> &PYlm_tab , 
				      class array<double> &dPYlm_tab , 
				      class array<double> &d2PYlm_tab);
}

#endif
