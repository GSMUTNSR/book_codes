#include "../numlib_def/numlib_def.h"

// Renormalized Hermite polynomials are considered (see Numerical Recipes)
// -----------------------------------------------------------------------
// 

// Hermite polynomial
// ------------------ - 
// The following recurrence relation is used :
// P(i+1, x) = x.sqrt (2/(i+1)).P(i, x) - sqrt (i/(i+1)).P(i-1, x) for i > 0.
// P(0, x) = pi^(-1/4). This value is directly returned if the degree of the polynomial is 0.
//
// Variable
// --------
// degree : degree of the Hermite polynomial
// x : variable of the Hermite polynomial
// i, poly_im1, poly_i, poly_ip1 : Hermite polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// ip1 , sqrt_two_over_ip1 , sqrt_i_over_ip1: i+1 , sqrt (2/(i+1)) , sqrt (i/(i+1))

double Gauss_Hermite::poly (const int degree , const double x)
{
  if (degree == 0) return 0.7511255444649425;  

  double poly_im1 = 0.0;

  double poly_i = 0.7511255444649425;

  double poly_ip1 = 1.0622519320271969*x;

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double sqrt_two_over_ip1 = sqrt (2.0/ip1);

      const double sqrt_i_over_ip1 = sqrt (i/ip1);

      poly_im1 = poly_i;

      poly_i = poly_ip1;

      poly_ip1 = x * sqrt_two_over_ip1 * poly_i - sqrt_i_over_ip1 * poly_im1;
    }

  return poly_ip1;
}








// Derivative of the Hermite polynomial
// --------------------------------------
// The following recurrence relation is used :
// P(i+1, x) = x.sqrt (2/(i+1)).P(i, x) - sqrt (i/(i+1)).P(i-1, x) for i > 0.
//
// P(0, x) = pi^(-1/4). 
// P'(0 , x) = 0. This value is directly returned if the degree of the polynomial is 0.
//
// One uses the formula P'(i+1 , x) = sqrt(2.(i+1)).P(i, x) for i > 0 for the derivative.
//
// Variable
// --------
// degree : degree of the Hermite polynomial , not of the derivative of the Hermite.
// x : variable of the Hermite polynomial derivative
// i , poly_im1 , poly_i , poly_ip1 : Hermite polynomial of degree i-1 , i , i+1. i goes from 1 to degree-1 , with degree > 1.
// ip1 , sqrt_two_over_ip1 , sqrt_i_over_ip1 : i+1 , sqrt (2/(i+1)) , sqrt (i/(i+1)) 
// dP: derivative of the Laguerre polynomial of degree "degree". Returned value.

double Gauss_Hermite::poly_der (const int degree , const double x)
{ 
  if (degree == 0) return 0.0;
  
  double poly_im1 = 0.0;

  double poly_i = 0.7511255444649425;

  double poly_ip1 = 1.0622519320271969*x;

  for (int i = 1 ; i < degree ; i++)
    {
      const double ip1 = i + 1;

      const double sqrt_two_over_ip1 = sqrt (2.0/ip1);

      const double sqrt_i_over_ip1 = sqrt (i/ip1);
	  
      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_ip1 = x * sqrt_two_over_ip1 * poly_i - sqrt_i_over_ip1 * poly_im1;
    }

  const double dP = sqrt (2*degree)*poly_i;
 
  return dP;
}




// Polynomial and derivative of the Hermite polynomial
// ----------------------------------------------------
// The following recurrence relation is used :
// P(i+1, x) = x.sqrt (2/(i+1)).P(i, x) - sqrt (i/(i+1)).P(i-1, x) for i > 0.
//
// P(0, x) = pi^(-1/4) , P'(0 , x) = pi^(-1/4). These values are directly returned if the degree of the polynomial is 0.
//
// One uses the formula P'(i+1 , x) = sqrt(2.(i+1)).P(i, x) for i > 0 for the derivative.
//
//
// Variable
// --------
// degree : degree of the Hermite polynomial, not of the derivative of the Hermite.
// x : variable of the Hermite polynomial derivative
// i, poly_im1, poly_i, poly_ip1 : Hermite polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.
// ip1 , sqrt_two_over_ip1 , sqrt_i_over_ip1 : i+1 , sqrt (2/(i+1)) , sqrt (i/(i+1)) 
// P, dP: Hermite polynomial and derivative to calculate

void Gauss_Hermite::P_dP (const int degree , const double x , double &P , double &dP)
{  
  if (degree == 0)
    {
      P = 0.7511255444649425;
      
      dP = 0.0;  
    }
  else
    {
      double poly_im1 = 0.0;

      double poly_i = 0.7511255444649425;

      double poly_ip1 = 1.0622519320271969*x;
      
      for (int i = 1 ; i < degree ; i++)
	{
	  const double ip1 = i + 1;

	  const double sqrt_two_over_ip1 = sqrt (2.0/ip1);

	  const double sqrt_i_over_ip1 = sqrt (i/ip1);
	  
	  poly_im1 = poly_i;
	  
	  poly_i = poly_ip1;
	  
	  poly_ip1 = x * sqrt_two_over_ip1 * poly_i - sqrt_i_over_ip1 * poly_im1;
	}

      P = poly_ip1;

      dP = sqrt (2*degree)*poly_i;
    }
}










// Calculation of the abscissas and weights of the Gauss-Hermite quadrature
// --------------------------------------------------------------------------
// These are the abscissas and weights of the Gauss-Hermite quadrature on ]-oo:+oo[.
// Arrays with N <= 20 are directly provided as they occur most often.
// Otherwise, I use the Golub-Welsch method as it is more stable than the Numerical Recipes method for large N.
// Moreover, the Golub-Welsch method is as good for N ~ 10 and even comparable in speed, even though it is usually slower strictly speaking.
// Also, only eigenvalues are needed, as there is a closed form formula for weights when the root is known.
// Refinement of roots with the Newton method is done to be sure to have maximal precision.
// Polynomials can overflow, but typically where integrands are negligible. Weights are then put to zero therein.
// The diagonal of the Jacobi matrix is replaced by small numbers around 10^(-13) so that its elements are not equal to zero and different.
// It does not matter afterwards as one uses the Newton method on roots.
// The routine has been tested successfully for N <= 1000.
//
// Variables
// -------- - 
// N , Nm1 , Nm1_over_two : number of points in the Gauss-Hermite quadrature, N-1, (N-1)/2
// x_table : table of Gauss-Hermite abscissas.
// w_table : table of Gauss-Hermite weights.
// count : The Newton method stops if count >= 5 as starting points are very close to their exact value.
// xi, wi : i-th root of the Hermite polynomial and its weight. xi is refined with the Newton method. A precision of 1e-16 is demanded.
// P, dP, ratio: Hermite polynomial and derivative, P/dP
// Nm1_minus_i: Index of the abscissa so that x_table(i) = x_table(N-1 - xi)
// a_table, sqrt_b_table: arrays of a[i] and sqrt(b[i]) for the Golub-Welsch matrix
// dP_0,...,2: polynomial derivatives for x_table(0,...,2)

void Gauss_Hermite::abscissas_weights_tables_calc (
						   class array<double> &x_table , 
						   class array<double> &w_table)
{
  const unsigned int N = x_table.dimension (0);

  if (N == 0) return;

  const unsigned int Nm1 = N - 1;
  
  const unsigned int Nm1_over_two = Nm1/2;
	
  switch (N)
    {
    case 1:
      {
	x_table(0) = 0.0 , w_table(0) = 1.7724538509055157;
      } break;

    case 2:
      {
	x_table(1) = 0.70710678118654735 , w_table(1) = 0.8862269254527575;
      } break;

    case 3:
      {
	x_table(1) = 0.0                , w_table(1) = 1.1816359006036772;
	x_table(2) = 1.2247448713915889 , w_table(2) = 0.29540897515091896;
      } break;

    case 4:
      {
	x_table(2) = 0.52464762327529013 , w_table(2) = 0.80491409000551239;
	x_table(3) = 1.6506801238857844  , w_table(3) = 0.081312835447245074;
      } break;

    case 5:
      {
	x_table(2) = 0.0                , w_table(2) = 0.94530872048294168;
	x_table(3) = 0.9585724646138184 , w_table(3) = 0.39361932315224063;
	x_table(4) = 2.0201828704560856 , w_table(4) = 0.019953242059045865;
      } break;

    case 6:
      {
	x_table(3) = 0.4360774119276164 , w_table(3) = 0.72462959522439219;
	x_table(4) = 1.3358490740136968 , w_table(4) = 0.1570673203228565;
	x_table(5) = 2.3506049736744923 , w_table(5) = 0.0045300099055088352;
      } break;

    case 7:
      {
	x_table(3) = 0.0                 , w_table(3) = 0.81026461755680712;
	x_table(4) = 0.81628788285896448 , w_table(4) = 0.42560725261012727;
	x_table(5) = 1.6735516287674714  , w_table(5) = 0.054515582819126954;
	x_table(6) = 2.6519613568352334  , w_table(6) = 0.0009717812450995134;
      } break;

    case 8:
      {
	x_table(4) = 0.38118699020732205 , w_table(4) = 0.66114701255824093;
	x_table(5) = 1.1571937124467802  , w_table(5) = 0.2078023258148915;
	x_table(6) = 1.9816567566958427  , w_table(6) = 0.01707798300741346;
	x_table(7) = 2.9306374202572441  , w_table(7) = 0.00019960407221136694;
      } break;

    case 9:
      {
	x_table(4) = 0.0                 , w_table(4) = 0.72023521560605075;
	x_table(5) = 0.72355101875283745 , w_table(5) = 0.43265155900255553;
	x_table(6) = 1.4685532892166679  , w_table(6) = 0.088474527394376432;
	x_table(7) = 2.2665805845318432  , w_table(7) = 0.0049436242755369264;
	x_table(8) = 3.1909932017815277  , w_table(8) = 3.9606977263264358e-05;
      } break;

    case 10:
      {
	x_table(5) = 0.34290132722370453 , w_table(5) = 0.61086263373532546;
	x_table(6) = 1.0366108297895136  , w_table(6) = 0.2401386110823141;
	x_table(7) = 1.7566836492998816  , w_table(7) = 0.033874394455481044;
	x_table(8) = 2.5327316742327897  , w_table(8) = 0.0013436457467812248;
	x_table(9) = 3.4361591188377374  , w_table(9) = 7.6404328552326308e-06;
      } break;

    case 11:
      {
	x_table(5)  = 0.0                 , w_table(5)  = 0.6547592869145914;
	x_table(6)  = 0.65680956688209968 , w_table(6)  = 0.42935975235612461;
	x_table(7)  = 1.3265570844949328  , w_table(7)  = 0.11722787516770837;
	x_table(8)  = 2.0259480158257555  , w_table(8)  = 0.0119113954449115;
	x_table(9)  = 2.7832900997816519  , w_table(9)  = 0.00034681946632334447;
	x_table(10) = 3.6684708465595826  , w_table(10) = 1.4395603937142546e-06;
      } break;

    case 12:
      {
	x_table(6)  = 0.31424037625435908 , w_table(6)  = 0.57013523626247964;
	x_table(7)  = 0.94778839124016367 , w_table(7)  = 0.26049231026416064;
	x_table(8)  = 1.5976826351526048  , w_table(8)  = 0.051607985615883867;
	x_table(9)  = 2.2795070805010598  , w_table(9)  = 0.0039053905846290634;
	x_table(10) = 3.0206370251208896  , w_table(10) = 8.5736870435878642e-05;
	x_table(11) = 3.8897248978697818  , w_table(11) = 2.658551684356306e-07;
      } break;

    case 13:
      {
	x_table(6)  = 0.0                , w_table(6)  = 0.6043931879211617;
	x_table(7)  = 0.60576387917106   , w_table(7)  = 0.42161629689854291;
	x_table(8)  = 1.2200550365907483 , w_table(8)  = 0.14032332068702325;
	x_table(9)  = 1.8531076516015121 , w_table(9)  = 0.020862775296169912;
	x_table(10) = 2.519735685678238  , w_table(10) = 0.0012074599927193825;
	x_table(11) = 3.2466089783724099 , w_table(11) = 2.0430360402707036e-05;
	x_table(12) = 4.1013375961786398 , w_table(12) = 4.8257318500731119e-08;
      } break;

    case 14:
      {
	x_table(7)  = 0.29174551067256199 , w_table(7)  = 0.53640590971208979;
	x_table(8)  = 0.87871378732939931 , w_table(8)  = 0.2731056090642463;
	x_table(9)  = 1.4766827311411408  , w_table(9)  = 0.068505534223465114;
	x_table(10) = 2.0951832585077166  , w_table(10) = 0.0078500547264579324;
	x_table(11) = 2.7484707249854026  , w_table(11) = 0.0003550926135519228;
	x_table(12) = 3.4626569336022706  , w_table(12) = 4.7164843550189047e-06;
	x_table(13) = 4.3044485704736317  , w_table(13) = 8.6285911681251272e-09;
      } break;

    case 15:
      {
	x_table(7) = 0.0                 , w_table(7)  = 0.56410030872641737;
	x_table(8) = 0.56506958325557566 , w_table(8)  = 0.41202868749889848;
	x_table(9) = 1.1361155852109206  , w_table(9)  = 0.15848891579593552;
	x_table(10) = 1.7199925751864888 , w_table(10) = 0.030780033872546048;
	x_table(11) = 2.3257324861738575 , w_table(11) = 0.0027780688429127711;
	x_table(12) = 2.9671669279056032 , w_table(12) = 0.00010000444123249972;
	x_table(13) = 3.6699503734044527 , w_table(13) = 1.0591155477110629e-06;
	x_table(14) = 4.499990707309391  , w_table(14) = 1.5224758042535015e-09;
      } break;

    case 16:
      {
	x_table(8) = 0.27348104613815244 , w_table(8)  = 0.50792947901661356;
	x_table(9) = 0.82295144914465579 , w_table(9)  = 0.28064745852853318;
	x_table(10) = 1.3802585391988806 , w_table(10) = 0.083810041398985777;
	x_table(11) = 1.9517879909162539 , w_table(11) = 0.012880311535509949;
	x_table(12) = 2.5462021578474814 , w_table(12) = 0.00093228400862417778;
	x_table(13) = 3.176999161979956  , w_table(13) = 2.7118600925378746e-05;
	x_table(14) = 3.8694479048601225 , w_table(14) = 2.3209808448651982e-07;
	x_table(15) = 4.6887389393058188 , w_table(15) = 2.65480747401116e-10;
      } break;

    case 17:
      {
	x_table(8) = 0.0                 , w_table(8)  = 0.53091793762486339;
	x_table(9) = 0.53163300134265468 , w_table(9)  = 0.40182646947041184;
	x_table(10) = 1.0676487257434504 , w_table(10) = 0.1726482976700969;
	x_table(11) = 1.6129243142212313 , w_table(11) = 0.040920034149756243;
	x_table(12) = 2.1735028266666205 , w_table(12) = 0.0050673499576275195;
	x_table(13) = 2.7577629157038888 , w_table(13) = 0.00029864328669775188;
	x_table(14) = 3.3789320911414942 , w_table(14) = 7.112289140021289e-06;
	x_table(15) = 4.0619466758754745 , w_table(15) = 4.9770789816307679e-08;
	x_table(16) = 4.8713451936744034 , w_table(16) = 4.5805789307986084e-11;
      } break;

    case 18:
      {
	x_table(9)  = 0.25826775051909673 , w_table(9)  = 0.48349569472545545;
	x_table(10) = 0.77668291926741162 , w_table(10) = 0.28480728566997926;
	x_table(11) = 1.3009208583896175  , w_table(11) = 0.097301747641315342;
	x_table(12) = 1.8355316042616288  , w_table(12) = 0.018640042387544589;
	x_table(13) = 2.3862990891666862  , w_table(13) = 0.0018885226302684096;
	x_table(14) = 2.9613775055316069  , w_table(14) = 9.1811268679293622e-05;
	x_table(15) = 3.573769068486266   , w_table(15) = 1.8106544810934254e-06;
	x_table(16) = 4.248117873568126   , w_table(16) = 1.0467205795792129e-08;
	x_table(17) = 5.0483640088744668  , w_table(17) = 7.8281997721158611e-12;
      } break;

    case 19:
      {
	x_table(9)  = 0.0                 , w_table(9)  = 0.50297488827618653;
	x_table(10) = 0.50352016342388817 , w_table(10) = 0.39160898861303023;
	x_table(11) = 1.0103683871343112  , w_table(11) = 0.18363270130699691;
	x_table(12) = 1.5241706193935329  , w_table(12) = 0.050810386909051999;
	x_table(13) = 2.0492317098506194  , w_table(13) = 0.0079888667777229666;
	x_table(14) = 2.5911337897945423  , w_table(14) = 0.00067087752140718182;
	x_table(15) = 3.1578488183476021  , w_table(15) = 2.7209197763161631e-05;
	x_table(16) = 3.7621873519640201  , w_table(16) = 4.4882431472231205e-07;
	x_table(17) = 4.4285328066037799  , w_table(17) = 2.1630510098635314e-09;
	x_table(18) = 5.2202716905374817  , w_table(18) = 1.3262970944985264e-12;
      } break;

    case 20:
      {
	x_table(10) = 0.24534070830090124 , w_table(10) = 0.46224366960060992;
	x_table(11) = 0.73747372854539428 , w_table(11) = 0.28667550536283404;
	x_table(12) = 1.2340762153953229  , w_table(12) = 0.10901720602002318;
	x_table(13) = 1.7385377121165861  , w_table(13) = 0.024810520887463588;
	x_table(14) = 2.2549740020892757  , w_table(14) = 0.0032437733422378489;
	x_table(15) = 2.7888060584281305  , w_table(15) = 0.00022833863601635354;
	x_table(16) = 3.3478545673832163  , w_table(16) = 7.8025564785320751e-06;
	x_table(17) = 3.9447640401156252  , w_table(17) = 1.0860693707692769e-07;
	x_table(18) = 4.6036824495507442  , w_table(18) = 4.3993409922731856e-10;
	x_table(19) = 5.3874808900112328  , w_table(19) = 2.2293936455341513e-13;
      } break;
      
    default:
      {  
	class array<double> a_table(N);

	a_table = 1E-13;
	
	for (unsigned int i = 0 ; i < N ; i++) a_table(i) *= i%20 - 10;
	
	class array<double> sqrt_b_table(Nm1);

	sqrt_b_table = M_SQRT1_2;
  
	for (unsigned int i = 0 ; i < Nm1 ; i++) sqrt_b_table(i) *= sqrt (i + 1.0);
  
	total_diagonalization::symmetric::all_eigenvalues (sqrt_b_table , a_table , x_table);

	w_table = 0.0;

	for (unsigned int i = Nm1_over_two ; i < N ; i++) 
	  {  
	    double &xi = x_table(i);
	    
	    unsigned int count = 0;
            
	    double P = 0.0;
 
	    double dP = 0.0;

	    double ratio = 1.0;
	    
	    while ((abs (ratio) > 1E-16) && (count++ < 5))
	      {
		P_dP (N , xi , P , dP);

		ratio = P/dP;

		if (finite (ratio))
		  xi -= ratio;
		else
		  break;
	      }

	    x_table(i) = xi;
	    
	    const double wi = 2.0/(dP*dP);
	    
	    if (finite (wi)) w_table(i) = wi;
	  }
      } break;
    }
  
  for (unsigned int i = 0 ; i <= Nm1_over_two ; i++) 
    {
      const unsigned int Nm1_minus_i = Nm1 - i;
	    
      x_table(i) = -x_table(Nm1_minus_i);	    
      w_table(i) =  w_table(Nm1_minus_i);
    }
}


