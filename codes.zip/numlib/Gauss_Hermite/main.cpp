#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;




#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    seed ();

    cout.precision (17);
    
    const unsigned int N = 100;
    
    const double alpha = 1.5486;
    
    const double two_alpha = 2.0*alpha;
      
    const complex<double> exact_integral = sqrt (M_PI)*exp (alpha*alpha);
    
    cout << "exp (2.alpha.x) exp(-x^2) is integrated numerically and exactly on ]-oo:+oo[" << endl << endl;

    cout << "Gauss-Hermite number of points   Gauss-Hermite integral   exact integral    test"  << endl << endl;

    for (unsigned int n = 0 ; n <= N ; n ++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);
	
	Gauss_Hermite::abscissas_weights_tables_calc (x_tab , w_tab);
			
	complex<double> integral = 0.0;

	for (unsigned int i = 0 ; i < n ; i++) integral += exp (two_alpha*x_tab(i))*w_tab(i);
      
	cout << n << " " << integral << " " << exact_integral << " " << inf_norm (integral/exact_integral - 1.0) << endl;
      }
    
    																     
    for (int n = 1 ; n <= 10 ; n++)
      {
	const double x = random_number<double> ();

	const double P = Gauss_Hermite::poly (n , x);
	
	const double dP = Gauss_Hermite::poly_der (n , x);

	double P_test , dP_test;

	Gauss_Hermite::P_dP (n , x , P_test , dP_test);

	if (abs (P - P_test) + abs (dP - dP_test) > 1E-12) error_message_print_abort ("Problem with Gauss-Hermite polynomials and/or derivatives"); 
      }

    
    const double zero_degree_test = 0.5*(abs (Gauss_Hermite::poly (0 , 1.234) - pow (M_PI,-0.25)) + abs (Gauss_Hermite::poly_der (0 , 1.234)));
    
    cout << endl << "n=0 test:" << zero_degree_test << endl << endl;
    
    cout << "Check that Gauss-Hermite polynomials and their derivatives vanish and test of their norms from Gauss-Hermite weights and standard relations" << endl;
																				     
    for (int n = 1 ; n <= 10 ; n++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);
	
	Gauss_Hermite::abscissas_weights_tables_calc (x_tab , w_tab);

	double test_roots = 0.0;

	for (int i = 0 ; i < n ; i++) test_roots += 0.5*(abs (Gauss_Hermite::poly (n , x_tab(i))) + abs (Gauss_Hermite::poly_der (n+1 , x_tab(i))));
	
	double test_norms = 0.0;

	for (int i = 0 ; i < n ; i++) test_norms += abs (w_tab(i)*Gauss_Hermite::poly_der (n , x_tab(i))*Gauss_Hermite::poly_der (n , x_tab(i)) - 2.0);
	
	for (int i = 0 ; i < n ; i++) test_norms += abs (Gauss_Hermite::poly_der (n , x_tab(i) + sqrt_precision)/Gauss_Hermite::poly (n-1 , x_tab(i) + sqrt_precision) - sqrt (2*n));
	
	test_norms /= 2*n;
	
	cout << "n:" << " " << n << " test[roots]:" << test_roots << " test[norms]:" << test_norms << endl;
      }  

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

