#ifndef STATOPTIMIZER_H
#define STATOPTIMIZER_H




/*----------------------------------------*/
/* Optimizing class + statistical studies */
/*----------------------------------------------------------------------------*/
class StatOptimizer : public Optimizer
{
public:
  /* Constructors and destructors */
  explicit StatOptimizer (const OptimizingData data);
  StatOptimizer (const Array<unsigned int> &ndataTab, const unsigned int nparams);
  ~StatOptimizer ();
    
    
  /* Main routine + explicit destructor */
  void solve ();
  void finalize ();

    
  /* Class-member setters */
  /* -- Parameter setter and getter */
  void setVector (const Vect<double> &params);
  void getVector (Vect<double> &params) const;
  void setInitialVector (const Vect<double> &params);
    
  /* -- Objective and gradient pointers on functions - simple version and with user class context */
  void setResidualsRoutine (void (*f)(const Vect<double>&,Vect<double>&));
  void setResidualsRoutine (void *const ctx , void (*f)(const void*,const Vect<double>&,Vect<double>&));
    
  void setJacobianRoutine  (void (*j)(const Vect<double>&,Matrix<double>&));
  void setJacobianRoutine  (void *const ctx , void (*j)(const void*,const Vect<double>&,Matrix<double>&));
    
    
  /* -- Options */
  void setMethod               (const OptimizingMethod method);
  void setMaxIterations        (const unsigned int nItermax);
  void setConvergencePrecision (const double prec);
  void setSvdPrecision         (const double prec);
  void setPrintingOption       (const PrintingOption option);
    
  /* -- All of the previous options alltogether */
  void setOptions (const OptimizingMethod m, const ConvergenceData d, const PrintingOption p=STANDARD);

    
    
private:
  /* Numbers of data and parameters */
  const unsigned int  ndataTypes;
  const bool          isOneDataType;
    
  Array<unsigned int> *ndataTab;
    
    
  /* Context = interface given by the user. Should be the same for all 
     calculated values and jacobian calculating routines */
  void *ctx;
    
    
  /* Calculated values, adopted errors and jacobian */
  /* The jacobian here is the jacobian of the observables */
  Array<Array<double> *>  *calcValues;
  Array<Array<double> *>  *adErrors;
  Array<Matrix<double> *> *jac;
    
    
  /* chi2-related data */
  Array<double> *chi2All;
  Array<double> *stypAll;
    
    
  /* Weights */
  /* These are not the standard weights (those weights should be included in the adopted errors) */
  /* These are the weights on the Styp in the end */
  Array<double> *weights;
    
    
  /* Covariance matrix */
  Matrix<double> *cov;
  Matrix<double> *corr;                // Normalized covariance matrix
  Array<double>  *paramUncertainties;
    
    
    
    
  /*-------------------------------*/
  /* Class option related routines */
  /*------------------------------------------------------------------------*/
    
  /* Check class settings */
  void checkVector (unsigned int &nErrors, string &errorString);
  void checkResidualsRoutine (unsigned int &nErrors, string &errorString);
  void checkJacobianRoutine (unsigned int &nErrors, string &errorString);
  void checkClassSettings ();
    

  /*------------------*/
  /* Data calculation */
  /*------------------------------------------------------------------------*/

  /* Residuals and jacobian - pointer versions */
  void (*computeResidualsNoCtx)   (                 const Vect<double> &params, Vect<double> &res);
  void (*computeResidualsWithCtx) (const void *ctx, const Vect<double> &params, Vect<double> &res);
  void (*computeJacobianNoCtx)    (                 const Vect<double> &params, Matrix<double> &jac);
  void (*computeJacobianWithCtx)  (const void *ctx, const Vect<double> &params, Matrix<double> &jac);
    
  /* Residuals and jacobian - shortcut versions */
  void computeResiduals ();
  void computeJacobianData ();
    
  /* Chi2 related data */
  void computeChi2Data ();
  void computeGradChi2Data ();
    
  /* All data */
  void compute ();
    

    
  /*-----------------*/
  /* Scaling routine */
  /*------------------------------------------------------------------------*/
  Vect<double> getRescaledVector (const Vect<double> &scaledV) const;
    

  /*-----------------------*/
  /* Gauss-Newton routines */
  /*------------------------------------------------------------------------*/
    
  /* One-iteration routines */
  void applyOverDeterminedGaussNewton ();
  void applyUnderDeterminedGaussNewton ();
  void applyGaussNewton ();
    
  /* Main routine  */
  void solveGaussNewton ();
    
    
    
  /*-------------------*/
  /* POUNDerS routines */
  /*------------------------------------------------------------------------*/

#ifdef UsePetsc
  /* Simple Petsc from/to user vector conversion routines*/
  PetscErrorCode transfer (const Vect<double> &v, VecP vP) const;
  PetscErrorCode transfer (const VecP vP, Vect<double> &v) const;

  /* Compute - Petsc version */
  static PetscErrorCode computeMasterP (Tao tao, VecP paramsP, VecP resP, void *ctx);
  PetscErrorCode computeSlavesP ();
  PetscErrorCode stopSlavesP ();
    
  /* Main routine */
  PetscErrorCode solvePounders ();
#endif
    
    
    
  /*-------------------------*/
  /* Ouput printing routines */
  /*------------------------------------------------------------------------*/
    
  /* Basic printing routines */
  void printParams () const;
  void printResiduals () const;
  void printJacobian () const;
  void printChi2Data () const;
  void printBestIterationData () const;
  void printConvergenceData () const;
    
  /* Class options printing routines */
  void printEndOfLine (const bool isDatumSet) const;
  void printAllClassOptions () const;
    
  /* Print iteration data and results */
  void printIterationData () const;
  void printResults () const;
};

/*----------------------------------------------------------------------------*/

#endif
