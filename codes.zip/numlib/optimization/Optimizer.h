#ifndef OPTIMIZER_H
#define OPTIMIZER_H




/*------------------*/
/* Optimizing class */
/*----------------------------------------------------------------------------*/
class Optimizer
{
public:
  /* Constructors and destructors */
  explicit Optimizer (const unsigned int ndata, const unsigned int nparams);
  explicit Optimizer (const OptimizingData data);
  ~Optimizer ();
    
    
  /* Main routine + explicit destructor */
  virtual void solve ();
  virtual void finalize ();

    
  /* Class-member setters */
  /* -- Parameter setter and getter */
  void setVector (const Vect<double> &params);
  void setInitialVector (const Vect<double> &params);
  const Vect<double>& getVector () const;

    
  /* -- Objective and gradient pointers on functions - simple version and with user class context */
  void setResidualsRoutine (void (*f)(const Vect<double>&,Vect<double>&));
  void setResidualsRoutine (void *const ctx , void (*f)(const void*,const Vect<double>&,Vect<double>&));
    
  void setJacobianRoutine  (void (*j)(const Vect<double>&,Matrix<double>&));
  void setJacobianRoutine  (void *const ctx , void (*j)(const void*,const Vect<double>&,Matrix<double>&));
    
    
  /* -- Options */
  void setMethod               (const OptimizingMethod method);
  void setMaxIterations        (const unsigned int nItermax);
  void setConvergencePrecision (const double prec);
  void setSvdPrecision         (const double prec);
  void setPrintingOption       (const PrintingOption option);
    
  /* -- All of the previous options alltogether */
  void setOptions (const OptimizingMethod m, const ConvergenceData d, const PrintingOption p=STANDARD);
    
    
  /* -- Reinitialize class memory of previous iterations (Tao) */
  void resetMemory ();
    
protected:
  /* Numbers of data and parameters */
  const unsigned int ndata,nparams;
  const unsigned int ndof;
    
  /* Optimizing method and printing option */
  OptimizingMethod method;
  bool             useDerivatives;
  PrintingOption   printingOption;
    
    
  /* Context = interface given by the user */
  void *resCtx;
  void *jacCtx;
    
    
  /* Parameters, Delta Parameters */
  Vect<double> params,paramsBest;
  Vect<double> dparams,dparamsScaled;
    
  /* Residual vector and jacobian matrix */
  Vect<double>   res;
  Matrix<double> jac,scaledJac;
    

#ifdef UsePetsc
  /* ndata, nparams Petsc versions */
  PetscInt ndataP;
  PetscInt nparamsP;
    
  /* For history printing */
  PetscBool printhistory;
  PetscInt  nhist;
  PetscReal hist[100],resid[100];
#ifdef UseNewPetsc
  PetscInt  lits[100];  // holds # of linear iterations for each Tao iteration
#endif
    
  /* Petsc vector version, and tao class */
  VecP paramsP;
  VecP resP;
  Tao  tao;
#endif

    
  /* chi2-related data */
  double chi2,chi2Best;
  double normGradChi2;
    
  Array<double> gradChi2;
    
  /* Convergence data */
  unsigned int nIterMax,iter,iterBest;
  double       precConv;
  double       precSvd;

    
  /* Test booleans */
  bool isInitialVectorSet;
  bool isResidualsRoutineSet,isJacobianRoutineSet;
  bool isResidualContextSet,isJacobianContextSet;
  bool isMethodSet;
  bool isnIterMaxSet,isPrecConvSet,isPrecSvdSet;
  bool isClassSet;
  bool isClassCleared;
    
    
  /* MPI tags (arbitrary values) */
  int tagActive,tagDie;
    
    
    
  /*-------------------------------*/
  /* Class option related routines */
  /*------------------------------------------------------------------------*/
    
  /* Check class settings */
  void checkVector (unsigned int &nErrors, string &errorString) const;
  void checkResidualsRoutine (unsigned int &nErrors, string &errorString) const;
  void checkJacobianRoutine (unsigned int &nErrors, string &errorString) const;
  void checkClassSettings ();
  bool isLastIterationTheBest () const;
    

  /*------------------*/
  /* Data calculation */
  /*------------------------------------------------------------------------*/

  /* Residuals and jacobian - pointer versions */
  void (*computeResidualsNoCtx)   (                 const Vect<double> &params, Vect<double> &res);
  void (*computeResidualsWithCtx) (const void *ctx, const Vect<double> &params, Vect<double> &res);
  void (*computeJacobianNoCtx)    (                 const Vect<double> &params, Matrix<double> &jac);
  void (*computeJacobianWithCtx)  (const void *ctx, const Vect<double> &params, Matrix<double> &jac);
    
  /* Residuals and jacobian - shortcut versions */
  void computeResiduals ();
  void computeJacobianData ();
    
  /* Chi2 related data */
  void computeChi2Data ();
  void computeGradChi2Data ();
    
  /* All data */
  void compute ();
    

    
  /*-----------------*/
  /* Scaling routine */
  /*------------------------------------------------------------------------*/
  Vect<double> getRescaledVector (const Vect<double> &scaledV) const;
    

  /*-----------------------*/
  /* Gauss-Newton routines */
  /*------------------------------------------------------------------------*/
    
  /* One-iteration routines */
  void applyOverDeterminedGaussNewton ();
  void applyUnderDeterminedGaussNewton ();
  void applyGaussNewton ();
    
  /* Main routine  */
  void solveGaussNewton ();
    
    
    
  /*-------------------*/
  /* POUNDerS routines */
  /*------------------------------------------------------------------------*/

#ifdef UsePetsc
  /* Simple Petsc from/to user vector conversion routines*/
  PetscErrorCode transfer (const Vect<double> &v, VecP vP) const;
  PetscErrorCode transfer (const VecP vP, Vect<double> &v) const;
    
  /* General routines */
  PetscErrorCode setTaoOptions ();
  PetscErrorCode taoView ();


  /* Compute residuals - Petsc version */
  static PetscErrorCode computeMasterP (Tao tao, VecP paramsP, VecP resP, void *ctx);
  void computeSlavesP ();
  void stopSlavesP ();
    
  /* Main routine */
  void solvePounders ();
#endif
    
    

  /*-------------------------*/
  /* Ouput printing routines */
  /*------------------------------------------------------------------------*/
    
  /* Basic printing routines */
  void printParams () const;
  void printResiduals () const;
  void printJacobian () const;
  void printChi2Data () const;
  void printBestIterationData () const;
  void printConvergenceData () const;
    
  /* Class options printing routines */
  void printEndOfLine (const bool isDatumSet) const;
  void printAllClassOptions () const;
    
  /* Print iteration data and results */
  void printIterationData () const;
  void printResults () const;
};

/*----------------------------------------------------------------------------*/

#endif
