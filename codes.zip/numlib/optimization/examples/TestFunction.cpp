#include "./lib.h"



/*------------------------------*/
/* Constructors and destructors */
/*----------------------------------------------------------------------------*/


/* Constructor */
TestFunction::TestFunction (const OptimizingData data)
  : ndata (data.ndata),
    nparams (data.nparams),
    isThereScaling (false)
{
  /* Alpha parameters: set of positive random numbers close to 2 */
  alpha.allocate(ndata,nparams);
  for (unsigned int i=0; i<ndata; ++i) {
    for (unsigned int j=0; j<nparams; ++j) {
      alpha(i,j) = 2. + 0.5*random_number<double> ();
    }
  }
    
  /* Weights are random but close to uniformity */
  weights.allocate(ndata);
  for (unsigned int i=0; i<ndata; ++i) {
    weights(i) = 1. + 0.1*random_number<double> ();
  }
  weights /= weights.sum();
    
  /* Scales are put to one */
  scales.allocate(nparams);
  for (unsigned int i=0; i<nparams; ++i) {
    scales(i) = 1.;
  }
}




/* Standard destructor */
TestFunction::~TestFunction ()
{}





/*---------*/
/* Setters */
/*----------------------------------------------------------------------------*/

/* Scale setter */
void TestFunction::setScales (const Array<double> &s)
{
  /* Test */
  if (s.dimension_total() != nparams) {
    error::abort2("Wrong parameter dimension given in TestFunction::setScales.");
  }
    
  /* Fill params */
  for (unsigned int i=0; i<nparams; ++i) {
    scales(i) = s(i);
  }
    
  /* Test boolean put to true */
  isThereScaling = true;
}





/*----------------*/
/* Main functions */
/*----------------------------------------------------------------------------*/


/* Compute residuals from params, store the residuals in res */
/* F(x) = [F_i](x), i = 0,.,ndata-1,
   - X = [X_j], j = 0,.,nparams-1, the parameter vector,
   - F_i(x) = w(i) . \sum_j sin^2 ( alpha(i,j).(X_j - \pi) ),
   - alpha(i,j) is a set of positive random numbers close to 2
   - w(i) are the weights */
void TestFunction::getResiduals (const Vect<double> &scaledParams, Vect<double> &res) const
{
  /* Rescaled parameters */
  Vect<double> params = scaledParams;
  if (isThereScaling) {
    for (unsigned int i=0; i<nparams; ++i)
      params(i) = scales(i) * scaledParams(i);
  }
    
    
  /* Compute residuals */
  for (unsigned int i=0; i<ndata; ++i) {
    const double sqrt_w = sqrt(weights(i));
        
    double Fi=0.;
    for (unsigned int j=0; j<nparams; ++j) {
      const double a = alpha(i,j);
      const double x = params(j);
      const double sin_a_xMinusPi = sin(a*(x-M_PI));
            
      Fi += sin_a_xMinusPi * sin_a_xMinusPi;
    }
        
    Fi *= sqrt_w;
        
    /* Fill residuals */
    res(i) = Fi;
  }
    
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout.precision(2);
    cout<<endl<<endl<<endl<<endl;
    cout<<scientific<<"Parameter vector minus Pi           : "<< params - M_PI <<endl;
    cout<<scientific<<"Calculated values (without weights) : ";

    for (unsigned int i=0; i<ndata; ++i) {
      cout<< res(i) / sqrt(weights(i)) <<" ";
    }
    cout<<endl<<endl<<endl;
  }
}


/* Compute Jacobian from params, store the Jacobian in jac */
void TestFunction::getJacobian (const Vect<double> &scaledParams, Matrix<double> &jac) const
{
  /* Rescaled parameters */
  Vect<double> params = scaledParams;
  if (isThereScaling) {
    for (unsigned int i=0; i<nparams; ++i)
      params(i) = scales(i) * scaledParams(i);
  }
    
  /* Compute unscaled Jacobian */
  for (unsigned int i=0; i<ndata; ++i) {
    const double sqrt_w = sqrt(weights(i));
        
    for (unsigned int j=0; j<nparams; ++j) {
      const double a = alpha(i,j);
      const double x = params(j);
      const double sin_a_xMinusPi = sin(a*(x-M_PI));
      const double cos_a_xMinusPi = cos(a*(x-M_PI));
            
      /* Fill Jacobian */
      jac(i,j) = sqrt_w * 2. * a * cos_a_xMinusPi * sin_a_xMinusPi ;
    }
  }
    
  /* Scale the Jacobian */
  if (isThereScaling) {
    for (unsigned int j=0; j<nparams; ++j) {
      const double scale = scales(j);
      for (unsigned int i=0; i<ndata; ++i) {
	jac(i,j) *= scale;
      }
    }
  }
}

