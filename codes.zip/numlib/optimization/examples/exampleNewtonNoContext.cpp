#include "./lib.h"



/* Residuals and Jacobian computing routines */
/* The functions are made static so that they are only defined in this file */
/* Residuals and Jacobian should include everything (f.eg. information
   related to the weights) as the optimizing class is general. */
static void computeResiduals (const Vect<double> &params, Vect<double> &res);
static void computeJacobian  (const Vect<double> &params, Matrix<double> &jac);


/* Printing routines */
static void printStart ();
static void printEnd ();


/* alpha parameters and the WEIGHTS are defined as global objects as it is
   simpler for the example with no user class context. */
Array<double> ALPHAS;
Array<double> WEIGHTS;




/*---------------*/
/* Main function */
/*----------------------------------------------------------------------------*/

/* Gauss-Newton method */
/* The chi2 to minimize is a formula that can be coded directly.
   No need for an interface/context class */

/* Search for the minimum of chi2 = ||F||^2
   where F(x) = [F_i](x), i = 0,.,ndata-1,
   - X = [X_j], j = 0,.,nparams-1, the parameter vector,
   - F_i(x) = w(i) . \sum_j sin^2 ( alpha(i,j).(X_j - \pi) ),
   - alpha(i,j) is a set of positive random numbers close to 2
   - w(i) are the weights 
   The minimum is a zero of F that occurs when X_j = \pi \forall j*/
/* alpha and the weights are defined as global pointers in the main.cpp file for
   simplicity. Otherwise a context class would have been needed. See example with 
   context for such an example. */

void exampleNewtonNoContext ()
{
  /*----------------*/
  /* Main variables */
  /*------------------------------------------------------------------------*/

  /* Number of data and parameters */
  const unsigned int ndata   = 5;
  const unsigned int nparams = 3;
    
  OptimizingData optimizingData;
  optimizingData.ndata   = ndata;
  optimizingData.nparams = nparams;
    
  /* Options */
  /* Only Gauss-Newton method is implemented at the moment */
  /* printingOption = MINIMUM <-> the user use his own printing routines */
  /* Other options are STANDARD and VERBOSE */
  const OptimizingMethod method = GAUSSNEWTON;
  const PrintingOption printingOption = MINIMUM;
    
  /* Convergence data 
     Default values are chosen if not given, as for SVD precision here */
  ConvergenceData convergenceData;
  convergenceData.nIterMax = 100;
  convergenceData.precision = 1e-9;
  //convergenceData.precisionSvd = 1e-5;
    
  /* Initial parameters: params = 0.5*Pi*random[0,1] */
  Vect<double> params (nparams);
  params.randomFill();
  params *= 0.5;
  params += M_PI;

    
  /* Alpha parameters (global variable */
  ALPHAS.allocate(ndata,nparams);
  for (unsigned int i=0; i<ndata; ++i) {
    for (unsigned int j=0; j<nparams; ++j) {
      ALPHAS(i,j) = 2. + 0.5*random_number<double> ();
    }
  }
    
  /* Weights (global variable) */
  WEIGHTS.allocate(ndata);
  for (unsigned int i=0; i<ndata; ++i) {
    WEIGHTS(i) = 1. + 0.1*random_number<double> ();
  }
  WEIGHTS /= WEIGHTS.sum();
    
 
    
  /*----------------------*/
  /* User output printing */
  /*------------------------------------------------------------------------*/
  printStart();
    
    
    
  /*----------------------*/
  /* Optimizing procedure */
  /*------------------------------------------------------------------------*/

  /* Optimizing class */
  Optimizer solver(optimizingData);
    
  /* Set options */
  /* printingOption put to STANDARD if not given */
  // solver.setOptions(method,convergenceData) // sets printingOption to STANDARD
  /* Each option can be set separately too */
  solver.setOptions(method,convergenceData,printingOption);
    
  /* Compulsory settings */
  solver.setInitialVector(params);
  solver.setResidualsRoutine(computeResiduals);
  solver.setJacobianRoutine(computeJacobian);
    
  /* Solve and get the final parameters */
  solver.solve();
    
    
  /* Get parameters */
  const Vect<double> &finalParams = solver.getVector();
  params = finalParams;
    
    
  /* Finalize/deallocate */
  solver.finalize();
    
    
  /*----------------------*/
  /* User output printing */
  /*------------------------------------------------------------------------*/
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout.precision(2);
    cout<<scientific<<"   Final parameter vector minus Pi : "<< params - M_PI <<endl;
  }
    
  printEnd();
}




/*------------------------------------------*/
/* Residual and Jacobian computing routines */
/*----------------------------------------------------------------------------*/


/* Compute residuals from params, store the residuals in res */
/* F(x) = [F_i](x), i = 0,.,ndata-1,
   - X = [X_j], j = 0,.,nparams-1, the parameter vector,
   - F_i(x) = w(i) . \sum_j sin^2 ( alpha(i,j).(X_j - \pi) ),
   - alpha(i,j) is a set of positive random numbers close to 2
   - w(i) are the weights */
void computeResiduals (const Vect<double> &params, Vect<double> &res)
{
  /* Main variables */
  const unsigned int nparams = params.get_dimension ();
  const unsigned int ndata = res.get_dimension ();
    
  /* Fill residuals */
  for (unsigned int i=0; i<ndata; ++i) {
    const double sqrt_w = sqrt(WEIGHTS(i));

    double Fi=0.;
    for (unsigned int j=0; j<nparams; ++j) {
      const double a = ALPHAS(i,j);
      const double x = params(j);
      const double sin_a_xMinusPi = sin(a*(x-M_PI));
            
      Fi += sin_a_xMinusPi * sin_a_xMinusPi;
    }
        
    Fi *= sqrt_w;
        
    /* Fill residuals */
    res(i) = Fi;
  }
    
    
  /* Output printing as printingOption was set to MINIMUM in Optimizer */
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout.precision(2);
    cout<<endl<<endl;
    cout<<scientific<<"Parameter vector minus Pi           : "<< params - M_PI <<endl;
    cout<<scientific<<"Calculated values (without weights) : ";
    for (unsigned int i=0; i<ndata; ++i) {
      cout<< res(i) / sqrt(WEIGHTS(i)) <<" ";
    }
    cout<<endl<<endl;
  }
}




/* Compute Jacobian from params, store the Jacobian in jac */
void computeJacobian (const Vect<double> &params, Matrix<double> &jac)
{
  /* Main variables */
  const unsigned int nparams = params.get_dimension ();
  const unsigned int ndata = jac.get_dimension_row ();
    
  /* Fill Jacobian */
  for (unsigned int i=0; i<ndata; ++i) {
    const double sqrt_w = sqrt(WEIGHTS(i));
        
    for (unsigned int j=0; j<nparams; ++j) {
      const double a = ALPHAS(i,j);
      const double x = params(j);
      const double sin_a_xMinusPi = sin(a*(x-M_PI));
      const double cos_a_xMinusPi = cos(a*(x-M_PI));
            
      /* Fill Jacobian */
      jac(i,j) = sqrt_w * 2. * a * cos_a_xMinusPi * sin_a_xMinusPi ;
    }
  }
}





/*-------------------*/
/* Printing routines */
/*----------------------------------------------------------------------------*/

void printStart ()
{
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout<<endl<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"   Gauss-Newton optimization example with no user class context (Simple case)   "<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<endl<<endl;
    cout<<"The chi2 to minimize is a formula that can be coded directly."<<endl;
    cout<<"No need for an interface/context class in the Optimizer class."<<endl<<endl<<endl;
        
    cout<<"One searches for the minimum of chi2 = ||F||^2"<<endl;
    cout<<"where F(x) = [F_i](x), i = 0,.,ndata-1,"<<endl;
    cout<<"- X = [X_j], j = 0,.,nparams-1, the parameter vector,"<<endl;
    cout<<"- F_i(x) = w(i) . \\sum_j sin^2 ( alpha(i,j).(X_j - \\pi) ),"<<endl;
    cout<<"- alpha(i,j) is a set of positive random numbers close to 2"<<endl;
    cout<<"- w(i) are random weights."<<endl<<endl;
        
    cout<<"The minimum is a zero of F that occurs when X_j = \\pi \\forall j"<<endl<<endl<<endl;

    cout<<"Printing option in Optimizer put to MINIMUM (User printing)"<<endl;
    cout<<endl<<endl;
  }
}



void printEnd ()
{
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout<<endl<<endl<<endl<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"                            End of first example                                "<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<endl<<endl<<endl<<endl<<endl;
  }
}

