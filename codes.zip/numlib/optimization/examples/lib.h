#ifndef OPTIMIZERLIB_H
#define OPTIMIZERLIB_H


#include "../../numlib_def/numlib_def.h"
#include "./example.h"
#include "./TestFunction.h"


#endif
