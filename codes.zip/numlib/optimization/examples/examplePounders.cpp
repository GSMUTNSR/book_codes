#include "./lib.h"


#ifdef UsePetsc


/* Residuals and Jacobian computing routines */
/* The functions are made static so that they are only defined in this file */
/* Residuals should include everything (f.eg. information related 
   to the weights) as the optimizing class is general. */
static void computeResiduals (const void *ctx, const Vect<double> &params, Vect<double> &res);


/* Printing routines */
static void printStart ();
static void printEnd ();





/*---------------*/
/* Main function */
/*----------------------------------------------------------------------------*/

/* The chi2 to minimize has to be computed through a class (the context or 
   interface) with its own parameters. 
   The context here is the class TestFunction. */
/* Search for the minimum of chi2=||F||^2, where F is calculated
   through the user context class TestFunction */
/* The minimization is done using the POUNDerS algorithm */

void examplePounders ()
{
  /*----------------*/
  /* Main variables */
  /*------------------------------------------------------------------------*/

  /* Number of data and parameters */
  const unsigned int ndata   = 5;
  const unsigned int nparams = 3;
    
  OptimizingData optimizingData;
  optimizingData.ndata   = ndata;
  optimizingData.nparams = nparams;
    
  /* Options */
  /* Only Gauss-Newton method is implemented at the moment */
  const OptimizingMethod method = POUNDERS;

  /* Convergence data
     Default values are chosen if not given */
  ConvergenceData convergenceData;
  convergenceData.nIterMax = 100;
  convergenceData.precision = 1e-5;
    
  /* Initial parameters: params = 0.5*random[0,1] + Pi */
  Vect<double> params (nparams);
  params.randomFill();
  params *= 0.5;
  params += M_PI;
    
  /* For POUNDerS, it is best that the parameters are scaled to values 
     that are expected to lie within the unit hypercube [0,1]^n. 
     Here, the scaling factor is equal to Pi for all parameters */
  Array<double> scales (nparams);
  scales = M_PI;
    
  /* Scaling of the parameters */
  for (unsigned int i=0; i<nparams; ++i) {
    params(i) /= scales(i);
  }
    
    
    
  /*----------------------*/
  /* User output printing */
  /*------------------------------------------------------------------------*/
  printStart();
    
    
    
  /*--------------*/
  /* User context */
  /* Interface that calculates all the data */
  /*------------------------------------------------------------------------*/
    
  TestFunction testFunction(optimizingData);
  testFunction.setScales(scales);
    
    
    
  /*----------------------*/
  /* Optimizing procedure */
  /*------------------------------------------------------------------------*/

  /* Optimizing class */
  Optimizer solver(optimizingData);
    
  /* Set options */
  /* printingOption put to STANDARD if not given */
  // const PrintingOption printingOption = STANDARD;
  // solver.setOptions(method,convergenceData,printingOption);
  /* Each option can be set separately too */
  solver.setOptions(method,convergenceData);

  /* Compulsory settings */
  solver.setInitialVector(params);
  solver.setResidualsRoutine( (void*)&testFunction , computeResiduals );
    
    
  /* Solve and get parameters */
  solver.solve();
    
    
  /* Get parameters */
  const Vect<double> &finalParams = solver.getVector();
  params = finalParams;
    
    
  /* Finalize/destroy */
  solver.finalize();
    
    
  /*----------------------*/
  /* User output printing */
  /*------------------------------------------------------------------------*/
    
  /* Rescale the parameters */
  for (unsigned int i=0; i<nparams; ++i) {
    params(i) *= scales(i);
  }
    
  /* Print */
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout<<"   Final parameter vector minus Pi : "<< params - M_PI <<endl;
  }
    
  printEnd();
}




/*------------------------------------------*/
/* Residual and Jacobian computing routines */
/*----------------------------------------------------------------------------*/


/* Compute residuals from params through the user class context ctx, and store 
   the residuals in res */
void computeResiduals (const void *ctx, const Vect<double> &params, Vect<double> &res)
{
  /* User context */
  TestFunction *testFunction = (TestFunction*)ctx;
    
  /* Get the residuals as computed in the context class. */
  testFunction->getResiduals(params,res);
}






/*-------------------*/
/* Printing routines */
/*----------------------------------------------------------------------------*/

void printStart ()
{
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout<<endl<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"                        Optimization example with POUNDerS                      "<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<endl<<endl;
    cout<<"The chi2 to minimize is computed through the user-defined"<<endl;
    cout<<"interface/context TestFunction class."<<endl;
        
    cout<<"One searches for the minimum of chi2 = ||F||^2"<<endl;
    cout<<"where F(x) = [F_i](x), i = 0,.,ndata-1,"<<endl;
    cout<<"- X = [X_j], j = 0,.,nparams-1, the parameter vector,"<<endl;
    cout<<"- F_i(x) = w(i) . \\sum_j sin^2 ( alpha(i,j).(X_j - \\pi) ),"<<endl;
    cout<<"- alpha(i,j) is a set of positive random numbers close to 2"<<endl;
    cout<<"- w(i) are random weights."<<endl<<endl;
        
    cout<<"The minimum is a zero of F that occurs when X_j = \\pi \\forall j"<<endl<<endl<<endl;
        
    cout<<"Printing option in Optimizer put to STANDARD."<<endl;
    cout<<"The parameters are scaled by Pi when given in Optimizer (hence the "<<endl;
    cout<<"difference between Optimizer and the user output). "<<endl;
    cout<<endl<<endl;
  }
}



void printEnd ()
{
  if (THIS_PROCESS == MASTER_PROCESS) {
    cout<<endl<<endl<<endl<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"                          End of example with POUNDerS                          "<<endl;
    cout<<"                                                                                "<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<endl<<endl<<endl<<endl<<endl;
  }
}



#endif

