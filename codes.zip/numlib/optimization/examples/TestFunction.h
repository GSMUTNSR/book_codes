#ifndef TESTFUNCTION_H
#define TESTFUNCTION_H



/*---------------------*/
/* Test function class */
/*----------------------------------------------------------------------------*/

/* Calculates F(x) = [F_i](x), i = 0,.,ndata-1, and the Jacobian:
   - X = [X_j], j = 0,.,nparams-1, the parameter vector,
   - F_i(x) = w(i) . \sum_j sin^2 ( alpha(i,j).(X_j - \pi) ),
   - alpha(i,j) is a set of positive random numbers close to 2
   - w(i) are the weights */

class TestFunction
{
public:
  /* Constructors and destructors */
  explicit TestFunction (const OptimizingData data);
  ~TestFunction ();
    
  /* Main routines */
  void getResiduals (const Vect<double> &scaledParams, Vect<double> &res) const;
  void getJacobian  (const Vect<double> &scaledParams, Matrix<double> &jac) const;
    
  /* Scales setter */
  void setScales (const Array<double> &scales);
    
private:
  /* Numbers of data and parameters */
  const unsigned int ndata,nparams;
    
  /* Scaling boolean */
  bool isThereScaling;

  /* alpha parameters and weights, randomly defined at construction */
  Array<double> alpha;
  Array<double> weights;
    
  /* Scales */
  Array<double> scales;
};

/*----------------------------------------------------------------------------*/

#endif
