#include "./lib.h"



/* Global variables */
unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;
double       reference_time;
//static char  help[]="";



/*---------------*/
/* Main function */
/*----------------------------------------------------------------------------*/
/* Search for the minimum of chi2 = ||F||^2
   where F(x) = [F_i](x), i = 0,.,ndata-1,
   - X = [X_j], j = 0,.,nparams-1, the parameter vector,
   - F_i(x) = w(i) . \sum_j sin^2 ( alpha(i,j).(X_j - \pi) ),
   - alpha(i,j) is a set of positive random numbers close to 2
   - w(i) are the weights
   The minimum is a zero of F that occurs when X_j = \pi \forall j*/
/* Three examples are given. 
   - One using the Gauss-Newton method without context, where the function
   to minimize is given by a simple formula 
   - One using the Gauss-Newton method with a class context where the
   function has to be computed through a class
   - And one using the POUNDerS algorithm (with a context). */


#ifdef UseMPI
int main (int argc,char **argv)
{
  /*------------------*/
  /* Inititialization */
  /*------------------------------------------------------------------------*/
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();
#endif
    OpenMP_initialization ();
        
    /* Initialize PETSc */
#ifdef UsePetsc
    PetscInitialize(&argc,&argv,(char *)0,help);
#endif

        
    /*------------------------------------------------------------------*/
    /* Example 1: Newton method, no context, simple case. See .cpp file */
    /* The function to minimize is a formula that can be coded directly */
    /*--------------------------------------------------------------------*/
    exampleNewtonNoContext();

        
    /*-------------------------------------------------------------------*/
    /* Example 2: Newton method with a user class context. See .cpp file */
    /* The function is calculated through a complicated class */
    /*--------------------------------------------------------------------*/
    exampleNewtonWithContext();
        
        
#ifdef UsePetsc
    /*-------------------------------------*/
    /* Example 3: Using POUNDerS algorithm */
    /*--------------------------------------------------------------------*/
    examplePounders();
#endif
        
        
        
    /*--------------*/
    /* Finalization */
    /*--------------------------------------------------------------------*/

    /* TAO and PETSc*/
#ifdef UsePetsc
    PetscFinalize();
#endif
        
    /* MPI */
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

