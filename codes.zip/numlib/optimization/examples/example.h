#ifndef OPTIMIZEREXAMPLE_H
#define OPTIMIZEREXAMPLE_H


/* Two applications of the Optimizer class:
   _ one without context (simple case) for which the function to
   minimize is a simple formula that can be coded directly,
   _ and one with a user class context */
void exampleNewtonNoContext ();
void exampleNewtonWithContext ();

#ifdef UsePetsc
void examplePounders ();
#endif


#endif
