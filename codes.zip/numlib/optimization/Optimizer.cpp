#include "../numlib_def/numlib_def.h"



/*------------------------------*/
/* Constructors and destructors */
/*----------------------------------------------------------------------------*/


/* Primary constructor */
Optimizer::Optimizer (const unsigned int nd, const unsigned int np)
  : ndata (nd),
    nparams (np),
    ndof (ndata - nparams),
    method (GAUSSNEWTON),
    useDerivatives (true),
    printingOption (STANDARD),
    resCtx (NULL),
    jacCtx (NULL),
#ifdef UsePetsc
    ndataP (ndata),
    nparamsP (nparams),
    printhistory (PETSC_FALSE),
#endif
    chi2 (INFINITE),
    chi2Best (INFINITE),
    normGradChi2 (INFINITE),
    nIterMax (1000),
    iter (0),
    iterBest (0),
    precConv (PRECISION),
    precSvd (1E-5),
    isInitialVectorSet (false),
    isResidualsRoutineSet (false),
    isJacobianRoutineSet (false),
    isResidualContextSet (false),
    isJacobianContextSet (false),
    isMethodSet (false),
    isnIterMaxSet (false),
    isPrecConvSet (false),
    isPrecSvdSet (false),
    isClassSet (false),
    isClassCleared (false),
    tagActive (1000),
    tagDie (2000)
{
  /* Tests */
  if (ndata == 0) {error::abort2("In Optimizer, ndata was not set.");}
  if (nparams == 0) {error::abort2("In Optimizer, nparams was not set.");}
    
  /*----------------------------------------*/
  /* Set arrays and initialize them to zero */
  /*------------------------------------------------------------------------*/
  params.allocate(nparams)          ; params=0.;
  paramsBest.allocate(nparams)      ; paramsBest=0.;
  dparams.allocate(nparams)         ; dparams=0.;
  dparamsScaled.allocate(nparams)   ; dparamsScaled=0.;
  res.allocate(ndata)               ; res=0.;
  jac.allocate(ndata,nparams)       ; jac=0.;
  scaledJac.allocate(ndata,nparams) ; scaledJac=0.;
  gradChi2.allocate(nparams)        ; gradChi2=0.;
    
    
#ifdef UsePetsc
  /*------------------------*/
  /* Petsc/Tao constructors */
  /*------------------------------------------------------------------------*/
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* allocate paramP Petsc vector on all nodes */
  VecallocateSeq(PETSC_COMM_SELF,nparamsP,&paramsP);

  /* allocate tao and resP vector on master node */
  if (THIS_PROCESS == MASTER_PROCESS) {
    VecallocateSeq(PETSC_COMM_SELF,ndataP,&resP);
    Taoallocate(PETSC_COMM_SELF,&tao);
  }
#endif
}




/* Secondary constructor */
Optimizer::Optimizer (const OptimizingData data)
  : ndata (data.ndata),
    nparams (data.nparams),
    ndof (ndata - nparams),
    method (GAUSSNEWTON),
    useDerivatives (true),
    printingOption (STANDARD),
    resCtx (NULL),
    jacCtx (NULL),
#ifdef UsePetsc
    ndataP (ndata),
    nparamsP (nparams),
    printhistory (PETSC_FALSE),
#endif
    chi2 (INFINITE),
    chi2Best (INFINITE),
    normGradChi2 (INFINITE),
    nIterMax (1000),
    iter (0),
    iterBest (0),
    precConv (PRECISION),
    precSvd (1E-5),
    isInitialVectorSet (false),
    isResidualsRoutineSet (false),
    isJacobianRoutineSet (false),
    isResidualContextSet (false),
    isJacobianContextSet (false),
    isMethodSet (false),
    isnIterMaxSet (false),
    isPrecConvSet (false),
    isPrecSvdSet (false),
    isClassSet (false),
    isClassCleared (false),
    tagActive (1000),
    tagDie (2000)
{
  /* Tests */
  if (ndata == 0) {error::abort2("In Optimizer, ndata was not set.");}
  if (nparams == 0) {error::abort2("In Optimizer, nparams was not set.");}
    
  /*----------------------------------------*/
  /* Set arrays and initialize them to zero */
  /*------------------------------------------------------------------------*/
  params.allocate(nparams)          ; params=0.;
  paramsBest.allocate(nparams)      ; paramsBest=0.;
  dparams.allocate(nparams)         ; dparams=0.;
  dparamsScaled.allocate(nparams)   ; dparamsScaled=0.;
  res.allocate(ndata)               ; res=0.;
  jac.allocate(ndata,nparams)       ; jac=0.;
  scaledJac.allocate(ndata,nparams) ; scaledJac=0.;
  gradChi2.allocate(nparams)        ; gradChi2=0.;
    
    
#ifdef UsePetsc
  /*------------------------*/
  /* Petsc/Tao constructors */
  /*------------------------------------------------------------------------*/
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* allocate paramP Petsc vector on all nodes */
  VecallocateSeq(PETSC_COMM_SELF,nparamsP,&paramsP);
    
  /* allocate tao and resP vector on master node */
  if (THIS_PROCESS == MASTER_PROCESS) {
    VecallocateSeq(PETSC_COMM_SELF,ndataP,&resP);
    Taoallocate(PETSC_COMM_SELF,&tao);
  }
#endif
}





/* Standard destructor */
Optimizer::~Optimizer ()
{
  finalize();
}



/* Explicit destructor */
void Optimizer::finalize ()
{
  /* Check if class was already cleared */
  if (isClassCleared) return;

  /* Delete arrays */
  params.deallocate();
  paramsBest.deallocate();
  dparams.deallocate();
  dparamsScaled.deallocate();
  res.deallocate();
  jac.deallocate();
  scaledJac.deallocate();
  gradChi2.deallocate();
    
#ifdef UsePetsc
  /*-----------------------*/
  /* Petsc/Tao destructors */
  /*------------------------------------------------------------------------*/
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Delete tao and resP vector on master node */
  if (THIS_PROCESS == MASTER_PROCESS) {
    Taodeallocate(&tao);
    Vecdeallocate(&resP);
  }
    
  /* deallocate paramP vector on all nodes */
  Vecdeallocate(&paramsP);
#endif
    
  isClassCleared = true;
}





/*--------------------*/
/* Main class setters */
/*----------------------------------------------------------------------------*/


/* Set parameter vector */
void Optimizer::setVector (const Vect<double> &p)
{
  /* Test */
  if (p.get_dimension () != nparams) {
    error::abort2("Wrong parameter dimension given in Optimizer::SetInitialVector.");
  }
    
  /* Fill params */
  for (unsigned int i=0; i<nparams; ++i) {
    params(i) = p(i);
  }
}




/* Set initial parameter vector */
void Optimizer::setInitialVector (const Vect<double> &p)
{
  /* Set vector*/
  setVector(p);
  isInitialVectorSet = true;
}




/* Get parameter vector */
const Vect<double>& Optimizer::getVector () const
{
  return params;
}






/* Set residuals routine - no user context */
void Optimizer::setResidualsRoutine (void (*f)(const Vect<double>&,Vect<double>&))
{
  /* Set routine */
  computeResidualsNoCtx = f;
  isResidualsRoutineSet = true;
}




/* Set residuals routine with user context */
void Optimizer::setResidualsRoutine (void *const ctx , void (*f)(const void*,const Vect<double>&,Vect<double>&))
{
  /* Set routine */
  computeResidualsWithCtx = f;
  isResidualsRoutineSet = true;
    
  /* Set context */
  resCtx = ctx;
  isResidualContextSet = true;
}





/* Set jacobian routine - no user context */
void Optimizer::setJacobianRoutine (void (*j)(const Vect<double>&,Matrix<double>&))
{
  /* Set routine */
  computeJacobianNoCtx = j;
  isJacobianRoutineSet = true;
}




/* Set jacobian routine with user context */
void Optimizer::setJacobianRoutine (void *const ctx , void (*j)(const void*,const Vect<double>&,Matrix<double>&))
{
  /* Set routine */
  computeJacobianWithCtx = j;
  isJacobianRoutineSet = true;
    
  /* Set context */
  jacCtx = ctx;
  isJacobianContextSet = true;
}







/*----------------*/
/* Option setters */
/*----------------------------------------------------------------------------*/


/* Set method */
void Optimizer::setMethod (const OptimizingMethod m)
{
  /* Set method */
  method = m;
  isMethodSet = true;
    
  /* Set useDerivatives boolean */
  if (m == POUNDERS) {
    useDerivatives = false;
  }
    
    
  /* Check errors */
  if (m == POUNDERS) {
    bool isPoundersSet = false;
#ifdef UsePetsc
    isPoundersSet = true;
#endif
    if (isPoundersSet == false) {
      error::abort2("Petsc libraries must be included to use POUNDerS in Optimizer.");
    }
  }
}



/* Set max iterations */
void Optimizer::setMaxIterations (const unsigned int n)
{
  /* Return if the value was not initialized (Default value considered) */
  if (n == 0) return;
    
  /* Set the value and put boolean to true */
  nIterMax = n;
  isnIterMaxSet = true;
}




/* Set convergence precision */
void Optimizer::setConvergencePrecision (const double p)
{
  /* Return if the value was not initialized (Default value considered) */
  if (p == -1.) return;
    
  /* Set the value and put boolean to true */
  precConv = p;
  isPrecConvSet = true;
}




/* Set SVD precision */
void Optimizer::setSvdPrecision (const double p)
{
  /* Return if the value was not initialized (Default value considered) */
  if (p == -1.) return;
    
  /* Set the value and put boolean to true */
  precSvd = p;
  isPrecSvdSet = true;
}



/* Set printing options */
void Optimizer::setPrintingOption (const PrintingOption p)
{
  printingOption = p;
}



/* Set all options */
/* Printing option set to STANDARD (in .h declaration) if not given */
void Optimizer::setOptions (const OptimizingMethod m, const ConvergenceData data, const PrintingOption p)
{
  setMethod(m);
  setMaxIterations(data.nIterMax);
  setConvergencePrecision(data.precision);
  setSvdPrecision(data.precisionSvd);
  setPrintingOption(p);
}





/* Reinitalize the class memory of previous iterations */
void Optimizer::resetMemory ()
{
  /* Useless for Gauss-Newton which does not keep the memory of 
     previous iterations */
  if (method == GAUSSNEWTON) {
    return;
  }
    
#ifdef UsePetsc
  /* deallocate and reallocate Tao */
  if (method == POUNDERS) {
    PetscFunctionBegin;
        
    if (THIS_PROCESS == MASTER_PROCESS) {
      Taodeallocate(&tao);
      Taoallocate(PETSC_COMM_SELF,&tao);
    }
  }
#endif
}



/*---------------------------------------*/
/* Check if class has been correctly set */
/*----------------------------------------------------------------------------*/


void Optimizer::checkVector (unsigned int &nErrors, string &errorString) const
{
  if (!isInitialVectorSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "initial vector";
    ++nErrors;
  }
}


void Optimizer::checkResidualsRoutine (unsigned int &nErrors, string &errorString) const
{
  if (!isResidualsRoutineSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "residual routine";
    ++nErrors;
  }
}


void Optimizer::checkJacobianRoutine (unsigned int &nErrors, string &errorString) const
{
  if (!isJacobianRoutineSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "jacobian routine";
    ++nErrors;
  }
}




void Optimizer::checkClassSettings ()
{
  /* No new check if all checks have already been done */
  if (isClassSet) return;
    
    
  /* Error variables */
  unsigned int nErrors=0;
  string s;
    
  /* Perform tests */
  checkVector(nErrors,s);
  checkResidualsRoutine(nErrors,s);
  if (useDerivatives) {
    checkJacobianRoutine(nErrors,s);
  }
    
    
  /* Return if no errors */
  if (nErrors == 0) {
    isClassSet = true;
    return;
  }
    
    
  /* Abort otherwise */
  string message = "In Optimizer, ";
  message += nErrors;
  message += " compulsory member(s) were not set: ";
  message += s;
  message += ".";
    
  error::abort2(message);
}




/* Public test function. Should be used when all calculation is done. */
bool Optimizer::isLastIterationTheBest () const
{
  if (iter == iterBest) {
    return true;
  }
    
  return false;
}




/*---------------------------------------------------------*/
/* Residuals, Jacobian and chi2 related computing routines */
/*----------------------------------------------------------------------------*/


/* Compute residuals */
void Optimizer::computeResiduals ()
{
  /* Compute residuals, fill res */
  /* Residuals are computed outside the class with the function pointers */
  if (isResidualContextSet) {computeResidualsWithCtx(resCtx,params,res);}
  else                      {computeResidualsNoCtx(params,res);}
}




/* Compute the jacobian and scaled jacobian */
void Optimizer::computeJacobianData ()
{
  /* Compute the jacobian, fill jac */
  /* The jacobian is computed outside the class with the function pointers */
  if (isJacobianContextSet) {computeJacobianWithCtx(jacCtx,params,jac);}
  else                      {computeJacobianNoCtx(params,jac);}
    
  /* Compute the scaled Jacobian */
  scaledJac = jac;
  for (unsigned int ip=0; ip<nparams; ++ip) {
    const double param = params(ip);
    if (param != 0.0) {
      for (unsigned int id=0; id<ndata; ++id) {
	scaledJac(id,ip) *= param;
      }
    }
  }
}




/* Compute chi2, and get best iteration data */
void Optimizer::computeChi2Data ()
{
  /* Calculate chi2 */
  chi2=0.;
  for (unsigned int i=0; i<ndata; ++i) {
    chi2 += res(i) * res(i);
  }
    
  /* Get chi2Best and best iteration index */
  if (chi2 < chi2Best) {
    chi2Best = chi2;
    iterBest = iter;
    paramsBest = params;
  }
}




/* Compute chi2 gradient and its norm */
void Optimizer::computeGradChi2Data ()
{
  /* Calculate chi2 gradient and square norm */
  double normSquare=0.;
    
  for (unsigned int ip=0; ip<nparams; ++ip) {
    double dchi2dp=0.;
    for (unsigned int id=0; id<ndata; ++id) {
      dchi2dp += 2. * jac(id,ip) * res(id);
    }
        
    /* Fill chi2 gradient */
    gradChi2(ip) = dchi2dp;
        
    /* Add to squared norm */
    normSquare += dchi2dp * dchi2dp;
  }
    
    
  /* Get the norm of chi2 */
  normGradChi2 = sqrt(normSquare);
}




/* Compute all data */
void Optimizer::compute ()
{
  computeResiduals();
  computeChi2Data();
    
  if (useDerivatives) {
    computeJacobianData();
    computeGradChi2Data();
  }
}





/*-------------------------------------------------------------------*/
/* Routine that help with the (re)scaling of the parameters to unity */
/*----------------------------------------------------------------------------*/

/* Rescale the parameter-type vector */
Vect<double> Optimizer::getRescaledVector (const Vect<double> &scaledV) const
{
  /* Compute the rescaled parameter vector */
  Vect<double> V = scaledV;
  for (unsigned int ip=0; ip<nparams; ++ip) {
    const double param = params(ip);
    if (param != 0.0) {
      V(ip) *= param;
    }
  }
    
  /* Return */
  return V;
}





/*----------------------*/
/*----------------------*/
/* Main solving routine */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


void Optimizer::solve ()
{
  /* Tests and output printing */
  printAllClassOptions();
  checkClassSettings();
    
  /* Use corresponding solver */
  switch (method) {
  case GAUSSNEWTON: {solveGaussNewton(); break;}
#ifdef UsePetsc
  case POUNDERS:    {solvePounders(); break;}
#endif
  default: {
    error::abort2("Method not recognized in Optimizer::solve.");
    break;
  }
  }
}



