#include "../numlib_def/numlib_def.h"



/*--------------------------*/
/*--------------------------*/
/* Output printing routines */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


/*--------------------------*/
/* Basic printing functions */
/*----------------------------------------------------------------------------*/


/* Print parameters */
void Optimizer::printParams () const
{
  cout.precision(6);
  cout<<"   Parameters  : ";
  for (unsigned int i=0; i<nparams; ++i) {
    cout<<params(i)<<" ";
  }
  cout<<endl;
}



/* Print residuals */
void Optimizer::printResiduals () const
{
  cout.precision(6);
  cout<<"   Residuals   : ";
  for (unsigned int i=0; i<ndata; ++i) {
    cout<<res(i)<<" ";
  }
  cout<<endl;
}



/* Print Jacobian */
void Optimizer::printJacobian () const
{
  /* Return if it is a derivative-free method */
  if (!useDerivatives) return;
    
  /* Print */
  cout.precision(6);
  cout<<"   Jacobian    : "<<endl;
  for (unsigned int id=0; id<ndata; ++id) {
    cout<<"   ";
    for (unsigned int ip=0; ip<nparams; ++ip) {
      cout<<jac(id,ip)<<" ";
    }
    cout<<endl;
  }
  cout<<endl;
}



/* Print chi2 data */
void Optimizer::printChi2Data () const
{
  cout.precision(6);
  cout<<scientific<<"   Convergence : chi2="<<chi2;
  if (useDerivatives) {
    cout<<scientific<<", ||grad(chi2)||="<<normGradChi2;
  }
  cout<<fixed<<endl;
}



/* Print best iteration data */
void Optimizer::printBestIterationData () const
{
  cout.precision(8);
    
  /* Print best iteration */
  cout<<"   A better minimum was found previously."<<endl;
  cout<<"   Best iteration: "<<iterBest<<":"<<endl;
    
  /* Print best parameter vector */
  cout<<"   Best parameter vector: ";
  for (unsigned int i=0; i<nparams; ++i) {
    cout<<paramsBest(i)<<" ";
  }
    
  /* Print corresponding chi2 */
  cout<<"- "<<"chi2 = "<<chi2Best<<endl;
}



/* Print convergence tests */
void Optimizer::printConvergenceData () const
{
  cout<<scientific;
  cout<<"   ||Residual difference||              : "<< sqrt(chi2) <<endl;
  cout<<"   ||Residual difference||oo            : "<< res.infNorm() <<endl;
  cout<<"   ||Parameters relative difference||oo : "<< dparamsScaled.infNorm() <<endl;
    
  if (useDerivatives) {
    cout<<"   ||grad(chi2)|| (Convergence test)    : "<< normGradChi2 <<endl;
  }
}





/*---------------------------------*/
/* Class options printing routines */
/*----------------------------------------------------------------------------*/


/* Print whether an option was given by the user or not (default) */
void Optimizer::printEndOfLine (const bool isDatumSet) const
{
  if (isDatumSet) {cout<<endl;}
  else            {cout<<" (default)"<<endl;}
}




/* Print class options (First output printing) */
void Optimizer::printAllClassOptions () const
{
  /* No printing if printingOption = NONE */
  if (printingOption == NONE) {return;}

  /* Print on output */
  cout.precision(0);
  cout<<endl<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"                                                                                "<<endl;
  cout<<"                            Initiating optimization                             "<<endl;
  cout<<"                                                                                "<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<endl<<endl;
    
  cout<<" >  Method                       : "<<method   ; printEndOfLine(isMethodSet);
  cout<<" >  Maximum number of iterations : "<<nIterMax ; printEndOfLine(isnIterMaxSet);
  cout<<scientific;
  cout<<" >  Convergence precision        : "<<precConv ; printEndOfLine(isPrecConvSet);
    
  if (method == GAUSSNEWTON) {
    cout<<" >  SVD precision                : "<<precSvd  ; printEndOfLine(isPrecSvdSet);
  }
    
  cout<<endl<<endl;
}





/*---------------------------------*/
/* Iteration data printing routine */
/*----------------------------------------------------------------------------*/


/* printIterationData */
void Optimizer::printIterationData () const
{
  /* Return if not master process */
  if (THIS_PROCESS != MASTER_PROCESS) return;
    
    
  /* Number of function evaluations */
  cout<<">  Function evaluation #"<<iter<<endl;
    
  /* Print convergence data depending on the printing option asked */
  switch (printingOption) {
  case NONE: {
    printChi2Data();
    break;
  }
  case MINIMUM: {
    printChi2Data();
    break;
  }
            
  case STANDARD: {
    cout<<endl;
    printParams();
    printResiduals(); cout<<endl;
    printChi2Data(); cout<<endl;
    break;
  }
            
  case VERBOSE: {
    cout<<endl<<endl;
    printParams();
    printResiduals(); cout<<endl;
    printJacobian(); cout<<endl;
    printChi2Data(); cout<<endl;
    printConvergenceData();
            
    if (iter != iterBest) {
      cout<<endl;
      printBestIterationData();
    }
            
    cout<<endl<<endl;
    break;
  }
            
  default: {
    error::abort2("Printing option not recognized in Optimizer.");
    break;
  }
  }

  cout<<endl;
}






/*--------------------------*/
/* Results printing routine */
/*----------------------------------------------------------------------------*/

void Optimizer::printResults () const
{
  /* cout options */
  cout.setf(ios::fixed);
  cout.fill(' ');
    
  /* Print on output */
  cout<<endl<<endl<<endl<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout                                                                                    <<endl;
  cout<<"                         Results of the optimization                            "<<endl;
  if (method == POUNDERS) {
    cout<<"                  (See Pounders output for more information)                    "<<endl;
  }
  cout                                                                                    <<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<endl<<endl;
    
    
  /* Number of iterations */
  cout<<"   Number of iterations : "<<iter<<endl<<endl;

  if (iter == nIterMax) {
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<" Results are NOT converged. "<<endl;
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<endl<<endl;
  }
    
    
  /* Print convergence data depending on the printing option asked */
  switch (printingOption) {
  case NONE: {
    printChi2Data();
    break;
  }
        
  case MINIMUM: {
    printChi2Data();
    break;
  }
            
  case STANDARD: {
    printChi2Data(); cout<<endl;
    printParams();
    printResiduals(); cout<<endl<<endl;
    printConvergenceData(); cout<<endl;
    break;
  }
            
  case VERBOSE: {
    printChi2Data(); cout<<endl;
    printParams();
    printResiduals(); cout<<endl;
    printJacobian(); cout<<endl;
    printConvergenceData(); cout<<endl;
    break;
  }
            
  default: {
    error::abort2("Printing option not recognized in Optimizer.");
    break;
  }
  }
    
  /* Case when a better minimum was found in a previous iteration */
  if (iter != iterBest) {
    cout<<endl;
    printBestIterationData();
  }
    
  cout<<endl;
}
