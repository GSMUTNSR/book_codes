#include "../numlib_def/numlib_def.h"




/*-----------------------*/
/*-----------------------*/
/* Gauss-Newton routines */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


/* One-iteration Gauss-Newton for the overdetermined (ndata > nparams) case */
void Optimizer::applyOverDeterminedGaussNewton ()
{
  /* References, J is the scaled Jacobian */
  const Vect<double>   &F = res;
  const Matrix<double> &J = scaledJac;
    
  /* Vectors and matrices used for the Newton method */
  const Matrix<double> tJ = transpose(J);
  Matrix<double>       tJJ = tJ * J; tJJ.symmetrize();  // Extra-symmetrization
  const Vect<double>   tJF = tJ * F;

    
  /* Get scaled parameters and rescale */
  solveLinear(tJJ,tJF,precSvd,dparamsScaled);
  dparams = getRescaledVector(dparamsScaled);
    
  /* Get the new set of parameters */
  params -= dparams;
}




/* One-iteration Gauss-Newton for the underdetermined (ndata < nparams) case */
void Optimizer::applyUnderDeterminedGaussNewton ()
{
  /* References, J is the scaled Jacobian */
  const Vect<double>   &F = res;
  const Matrix<double> &J = scaledJac;
    
  /* Vectors and matrices used for the Newton method */
  const Matrix<double> tJ = transpose(J);
  Matrix<double>       JtJ = J * tJ; JtJ.symmetrize();  // Extra-symmetrization
  Vect<double>         invJtJ_F = F;
    
  solveLinear(JtJ,F,precSvd,invJtJ_F);
    
  /* Get scaled parameters and rescale */
  dparamsScaled = tJ * invJtJ_F;
  dparams = getRescaledVector(dparamsScaled);
    
  /* Get the new set of parameters */
  params -= dparams;
}




/* One-iteration Gauss-Newton */
void Optimizer::applyGaussNewton ()
{
  if (ndof > 0) {applyOverDeterminedGaussNewton();}
  else          {applyUnderDeterminedGaussNewton();}
}





/* Main Gauss-Newton solver routine */
void Optimizer::solveGaussNewton ()
{
  /* First computation */
  compute();
  printIterationData();
  ++iter;
    
  /* Newton optimization */
  while ((iter <= nIterMax) && (normGradChi2 > precConv)) {
    /* Apply Gauss-Newton, compute, print and increment iter */
    applyGaussNewton();
    compute();
    printIterationData();
    ++iter;
  }
    
  /* Recover correct iteration index */
  --iter;
    
  /* Print results */
  printResults();
}

