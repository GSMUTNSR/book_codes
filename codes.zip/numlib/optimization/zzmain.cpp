#include "./lib.h"



/* Global variables */
unsigned int NUMBER_OF_PROCESSES,THIS_PROCESS,NUMBER_OF_THREADS;
bool         is_it_MPI_parallelized,is_it_OpenMP_parallelized;
double       reference_time;
string       STORAGE_DIR;
static char  help[]="";



/*---------------*/
/* Main function */
/*----------------------------------------------------------------------------*/

#ifdef UseMPI
int main (int argc,char **argv)
{
  /*------------------*/
  /* Inititialization */
  /*------------------------------------------------------------------------*/
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();
#endif
    OpenMP_initialization ();
        
    /* Initialize PETSc */
#ifdef UsePetsc
    PetscInitialize(&argc,&argv,(char *)0,help);
#endif

        
    cout << "Optimization files are compiling." << endl;
        

    /* Finalize TAO and PETSc*/
#ifdef UsePetsc
    PetscFinalize();
#endif
        
    /* Finalize MPI */
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

