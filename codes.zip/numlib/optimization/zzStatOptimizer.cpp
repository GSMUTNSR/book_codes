#include "../numlib_def/numlib_def.h"





/*------------------------------*/
/* Constructors and destructors */
/*----------------------------------------------------------------------------*/


/* Constructor */
StatOptimizer::StatOptimizer (const OptimizingData data) : Optimizer (data),
							   ndataTypes (1),
							   isOneDataType (true),
							   ndataTab (NULL),
							   ctx (NULL),

							   useDerivatives (true),
							   printingOption (STANDARD),
							   resCtx (NULL),
							   jacCtx (NULL),
							   params (NULL),
							   paramsBest (NULL),
							   dparams (NULL),
							   dparamsScaled (NULL),
							   res (NULL),
							   jac (NULL),
							   scaledJac (NULL),
#ifdef UsePetsc
							   ndataP (data.ndata),
							   nparamsP (data.nparams),
							   printhistory (PETSC_FALSE),
#endif
							   chi2 (INFINITE),
							   chi2Best (INFINITE),
							   normGradChi2 (INFINITE),
							   gradChi2 (NULL),
							   nIterMax (1000),
							   iter (0),
							   iterBest (0),
							   precConv (PRECISION),
							   precSvd (1E-5),
							   isInitialVectorSet (false),
							   isResidualsRoutineSet (false),
							   isJacobianRoutineSet (false),
							   isResidualContextSet (false),
							   isJacobianContextSet (false),
							   isMethodSet (false),
							   isnIterMaxSet (false),
							   isPrecConvSet (false),
							   isPrecSvdSet (false),
							   isClassSet (false),
							   isClassCleared (false),
							   tagActive (1000),
							   tagDie (2000)





							   ctx(NULL),
  resAll(NULL),
  jacAll(NULL),

  chi2 (INFINITE),
  chi2Best (INFINITE),
  normGradChi2 (INFINITE),
  nIterMax (1000),
  iter (0),
  iterBest (0),
  precConv (PRECISION),
  precSvd (1E-5),
  isInitialVectorSet (false),
  isResidualsRoutineSet (false),
  isJacobianRoutineSet (false),
  isResidualContextSet (false),
  isJacobianContextSet (false),
  isMethodSet (false),
  isnIterMaxSet (false),
  isPrecConvSet (false),
  isPrecSvdSet (false),
  isClassSet (false),
  isClassCleared (false),
  tagActive (1000),
  tagDie (2000),
  resCtx(NULL),
  jacCtx(NULL),
  paramsBest(NULL),
  dparams(NULL),
  dparamsScaled(NULL),
  res(NULL),
  jac(NULL),
  scaledJac(NULL),
  gradChi2(NULL)
{

    
  nDataTab = new Array<unsigned int> (ndataTypes);
  ndataTab(0) = ndata;
    
    

    
    
  calcValues = new Array<Array<double> *> (ndataTypes);
  adErrors   = new Array<Array<double> *> (ndataTypes);
  jac        = new Array<Matrix<double> *> (ndataTypes);
    
  for (unsigned int i=0; i<ndataTypes; ++i) {
    const unsigned int nd = ndataTab(i);
    calcValues(i) = new Array<double> (nd)   ; *(calcValues(i))=0.;
    adErrors(i) = new Array<double> (nd)     ; *(adErrors(i))=0.;
    jac(i) = new Matrix<double> (nd,nparams) ; *(jac(i))=0.;
  }
    
    
  chi2All = new Array<double> (ndataTypes) ; *chi2All=0.;
  stypAll = new Array<double> (ndataTypes) ; *stypAll=0.;
  weights = new Array<double> (ndataTypes) ; *weights=0.;
    
    
  cov = new Matrix<double> (nparams)               ; *cov=0.;
  corr = new Matrix<double> (nparams)              ; *corr=0.;
  paramUncertainties = new Array<double> (nparams) ; *paramUncertainties=0.;
    
    
    
  /* Create pointers and initialize them to zero */

}





/* Constructor */
StatOptimizer::StatOptimizer (const Array<unsigned int> &ndataTab_, const unsigned int np) : Optimizer (ndataTab_.sum(),np),
											     ndataTypes (ndataTab_.getDimension()),
											     isOneDataType (ndataTypes == 1),
											     ndataTab (NULL),
											     ctx (NULL),


											     ctx (NULL),
											     params(NULL),


{
    
  nDataTab = new Array<unsigned int> (ndataTypes);
  ndataTab = ndataTab_;
    
    
  /* Tests */
  if (nparams == 0) {error::abort2("In StatOptimizer, nparams was not set.");}
    
    
  /* Number of data */
  nDataAll=0;
  for (unsigned int i=0; i<ndataTypes; ++i) {
    const unsigned int ndata = ndataTypes(i);
    nDataAll += ndata;
  }
    
  /* Number of degrees of freedom */
  ndof = ndataAll - nparams;
    
    
    
    
  nDataTab = new Array<unsigned int> (ndataTypes);
  ndataTab(0) = ndataAll;
    
    
  /* Create pointers and initialize them to zero */
    
    
    
    
    
  params = new Vect<double> (nparams)            ; *params=0.;
  paramsBest = new Vect<double> (nparams)        ; *paramsBest=0.;
  dparams = new Vect<double> (nparams)           ; *dparams=0.;
  dparamsScaled = new Vect<double> (nparams)     ; *dparamsScaled=0.;
  res = new Vect<double> (ndata)                 ; *res=0.;
  jac = new Matrix<double> (ndata,nparams)       ; *jac=0.;
  scaledJac = new Matrix<double> (ndata,nparams) ; *scaledJac=0.;
  gradChi2 = new Array<double> (nparams)         ; *gradChi2=0.;
}






											     /* Standard destructor */
											     StatOptimizer::StatOptimizer ()
											     {
											       finalize();
											     }



/* Destructor routine */
void StatOptimizer::finalize ()
{
    
    
    
  /* Delete */
  /* The user contexts should NOT be deleted */
  if (!isClassCleared) {
    delete params;
    delete paramsBest;
    delete dparams;
    delete dparamsScaled;
    delete res;
    delete jac;
    delete gradChi2;
  }
    
  /* Set isClassCleared to true */
  isClassCleared = true;
}







void StatOptimizer::checkCtx (void *const c)
{
  /* If the context was not set yet, there test is ok */
  if (ctx == NULL) {
    return;
  }
    
  if (ctx != c) {
    error::abort2("There should be only one context in StatOptimizer.");
  }
    
}




/*--------------------*/
/* Main class setters */
/*----------------------------------------------------------------------------*/






/* Set parameter vector */
void Optimizer::setVector (const Vect<double> &p)
{
  /* Test */
  if (p.dimension != nparams) {
    error::abort2("Wrong parameter dimension given in Optimizer::SetInitialVector.");
  }
    
  /* Fill params */
  for (unsigned int i=0; i<nparams; ++i) {
    (*params)(i) = p(i);
  }
}




/* Set initial parameter vector */
void Optimizer::setInitialVector (const Vect<double> &p)
{
  /* Set vector*/
  setVector(p);
  isInitialVectorSet = true;
}




/* Get parameter vector */
void Optimizer::getVector (Vect<double> &p) const
{
  /* Test */
  if (p.dimension != nparams) {
    error::abort2("Wrong parameter dimension in Optimizer::GetVector.");
  }
    
  /* Fill params */
  for (unsigned int i=0; i<nparams; ++i) {
    p(i) = (*params)(i);
  }
}





/* Set residuals routine - no user context */
void Optimizer::setResidualsRoutine (void (*f)(const Vect<double>&,Vect<double>&))
{
  /* Set routine */
  computeResidualsNoCtx = f;
  isResidualsRoutineSet = true;
}




/* Set residuals routine with user context */
void Optimizer::setResidualsRoutine (void *const ctx , void (*f)(const void*,const Vect<double>&,Vect<double>&))
{
  /* Set routine */
  computeResidualsWithCtx = f;
  isResidualsRoutineSet = true;
    
  /* Set context */
  resCtx = ctx;
  isResidualContextSet = true;
}





/* Set jacobian routine - no user context */
void Optimizer::setJacobianRoutine (void (*j)(const Vect<double>&,Matrix<double>&))
{
  /* Set routine */
  computeJacobianNoCtx = j;
  isJacobianRoutineSet = true;
}




/* Set jacobian routine with user context */
void Optimizer::setJacobianRoutine (void *const ctx , void (*j)(const void*,const Vect<double>&,Matrix<double>&))
{
  /* Set routine */
  computeJacobianWithCtx = j;
  isJacobianRoutineSet = true;
    
  /* Set context */
  jacCtx = ctx;
  isJacobianContextSet = true;
}







/*----------------*/
/* Option setters */
/*----------------------------------------------------------------------------*/


/* Set method */
void Optimizer::setMethod (const OptimizingMethod m)
{
  /* Set method */
  method = m;
  isMethodSet = true;
    
  /* Set useDerivatives boolean */
  if (m == POUNDERS) {
    useDerivatives = false;
  }
    
    
  /* Check errors */
  if (m == POUNDERS) {
    bool isPoundersSet = false;
#ifdef UsePetsc
    isPoundersSet = true;
#endif
    if (isPoundersSet == false) {
      error::abort2("Petsc libraries must be included to use POUNDerS in Optimizer.");
    }
  }
}



/* Set max iterations */
void Optimizer::setMaxIterations (const unsigned int n)
{
  /* Return if the value was not initialized (Default value considered) */
  if (n == 0) return;
    
  /* Set the value and put boolean to true */
  nIterMax = n;
  isnIterMaxSet = true;
}




/* Set convergence precision */
void Optimizer::setConvergencePrecision (const double p)
{
  /* Return if the value was not initialized (Default value considered) */
  if (p == -1.) return;
    
  /* Set the value and put boolean to true */
  precConv = p;
  isPrecConvSet = true;
}




/* Set SVD precision */
void Optimizer::setSvdPrecision (const double p)
{
  /* Return if the value was not initialized (Default value considered) */
  if (p == -1.) return;
    
  /* Set the value and put boolean to true */
  precSvd = p;
  isPrecSvdSet = true;
}



/* Set printing options */
void Optimizer::setPrintingOption (const PrintingOption p)
{
  printingOption = p;
}



/* Set all options */
/* Printing option set to STANDARD (in .h declaration) if not given */
void Optimizer::setOptions (const OptimizingMethod m, const ConvergenceData data, const PrintingOption p)
{
  setMethod(m);
  setMaxIterations(data.nIterMax);
  setConvergencePrecision(data.precision);
  setSvdPrecision(data.precisionSvd);
  setPrintingOption(p);
}







/*---------------------------------------*/
/* Check if class has been correctly set */
/*----------------------------------------------------------------------------*/


void Optimizer::checkVector (unsigned int &nErrors, string &errorString)
{
  if (!isInitialVectorSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "initial vector";
    ++nErrors;
  }
}


void Optimizer::checkResidualsRoutine (unsigned int &nErrors, string &errorString)
{
  if (!isResidualsRoutineSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "residual routine";
    ++nErrors;
  }
}


void Optimizer::checkJacobianRoutine (unsigned int &nErrors, string &errorString)
{
  if (!isJacobianRoutineSet) {
    if (nErrors != 0) {errorString += ", ";}
    errorString += "jacobian routine";
    ++nErrors;
  }
}




void Optimizer::checkClassSettings ()
{
  /* No new check if all checks have already been done */
  if (isClassSet) return;
    
    
  /* Error variables */
  unsigned int nErrors=0;
  string s;
    
  /* Perform tests */
  checkVector(nErrors,s);
  checkResidualsRoutine(nErrors,s);
  if (useDerivatives) {
    checkJacobianRoutine(nErrors,s);
  }
    
    
  /* Return if no errors */
  if (nErrors == 0) {
    isClassSet = true;
    return;
  }
    
    
  /* Abort otherwise */
  string message = "In Optimizer, ";
  message += nErrors;
  message += " compulsory member(s) were not set: ";
  message += s;
  message += ".";
    
  error::abort2(message);
}






/*---------------------------------------------------------*/
/* Residuals, Jacobian and chi2 related computing routines */
/*----------------------------------------------------------------------------*/


/* Compute residuals */
void Optimizer::computeResiduals ()
{
  /* Compute residuals, fill *res */
  /* Residuals are computed outside the class with the function pointers */
  if (isResidualContextSet) {computeResidualsWithCtx(resCtx,*params,*res);}
  else                      {computeResidualsNoCtx(*params,*res);}
}




/* Compute the jacobian and scaled jacobian */
void Optimizer::computeJacobianData ()
{
  /* Compute the jacobian, fill *jac */
  /* The jacobian is computed outside the class with the function pointers */
  if (isJacobianContextSet) {computeJacobianWithCtx(jacCtx,*params,*jac);}
  else                      {computeJacobianNoCtx(*params,*jac);}
    
  /* Compute the scaled Jacobian */
  *scaledJac = *jac;
  for (unsigned int ip=0; ip<nparams; ++ip) {
    const double param = (*params)(ip);
    if (param != 0.0) {
      for (unsigned int id=0; id<ndata; ++id) {
	(*scaledJac)(id,ip) *= param;
      }
    }
  }
}




/* Compute chi2, and get best iteration data */
void Optimizer::computeChi2Data ()
{
  /* Calculate chi2 */
  chi2=0.;
  for (unsigned int i=0; i<ndata; ++i) {
    chi2 += (*res)(i) * (*res)(i);
  }
    
  /* Get chi2Best and best iteration index */
  if (chi2 < chi2Best) {
    chi2Best = chi2;
    iterBest = iter;
    *paramsBest = *params;
  }
}




/* Compute chi2 gradient and its norm */
void Optimizer::computeGradChi2Data ()
{
  /* Calculate chi2 gradient and square norm */
  double normSquare=0.;
    
  for (unsigned int ip=0; ip<nparams; ++ip) {
    double dchi2dp=0.;
    for (unsigned int id=0; id<ndata; ++id) {
      dchi2dp += 2. * (*jac)(id,ip) * (*res)(id);
    }
        
    /* Fill chi2 gradient */
    (*gradChi2)(ip) = dchi2dp;
        
    /* Add to squared norm */
    normSquare += dchi2dp * dchi2dp;
  }
    
    
  /* Get the norm of chi2 */
  normGradChi2 = sqrt(normSquare);
}




/* Compute all data */
void Optimizer::compute ()
{
  computeResiduals();
  computeChi2Data();
    
  if (useDerivatives) {
    computeJacobianData();
    computeGradChi2Data();
  }
}





/*-------------------------------------------------------------------*/
/* Routine that help with the (re)scaling of the parameters to unity */
/*----------------------------------------------------------------------------*/

/* Rescale the parameter-type vector */
Vect<double> Optimizer::getRescaledVector (const Vect<double> &scaledV) const
{
  /* Compute the rescaled parameter vector */
  Vect<double> V = scaledV;
  for (unsigned int ip=0; ip<nparams; ++ip) {
    const double param = (*params)(ip);
    if (param != 0.0) {
      V(ip) *= param;
    }
  }
    
  /* Return */
  return V;
}





/*----------------------*/
/*----------------------*/
/* Main solving routine */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


void Optimizer::solve ()
{
  /* Tests and output printing */
  printAllClassOptions();
  checkClassSettings();
    
  /* Use corresponding solver */
  switch (method) {
  case GAUSSNEWTON: {solveGaussNewton(); break;}
#ifdef UsePetsc
  case POUNDERS:    {solvePounders(); break;}
#endif
  default: {
    error::abort2("Method not recognized in Optimizer::solve.");
    break;
  }
  }
    
    
    
  if (!(optimizer::isLastIterationBest) {
      cout<<"Be careful"<<endl;
    }
    
    }



