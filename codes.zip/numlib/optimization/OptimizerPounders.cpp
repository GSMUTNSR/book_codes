#include "../numlib_def/numlib_def.h"


#ifdef UsePetsc


/*-------------------------*/
/*-------------------------*/
/* POUNDerS based routines */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/


/*------------------------------------------------------*/
/* Simple Petsc from/to user vector conversion routines */
/*----------------------------------------------------------------------------*/

/* Convert the values of a Vect/vector_class v to a Petsc vector vP */
PetscErrorCode Optimizer::transfer (const Vect<double> &v, VecP vP) const
{
  /* General variables */
  PetscReal *tempP;     // intermediate array

  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Construct the intermediate array tempP (fill it with dummies from vP) */
  VecGetArray(vP,&tempP);
    
  /* Fill the intermediate array tempP */
  for (unsigned int i=0; i<v.dimension; ++i) {
    PetscInt iP = i;
    tempP[iP] = v(i);
  }
    
  /* Fill the Petsc vector, restore intermediate array and return */
  VecRestoreArray(vP,&tempP);
  PetscFunctionReturn(0);
}




/* Transfer the values of a Petsc vector vP to a Vect/vector_class v */
PetscErrorCode Optimizer::transfer (const VecP vP, Vect<double> &v) const
{
  /* General variables */
  PetscReal *tempP;     // intermediate array
    
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Fill the intermediate array tempP from vP */
  VecGetArray(vP,&tempP);
    
  /* Fill the vector v */
  for (unsigned int i=0; i<v.dimension; ++i) {
    PetscInt iP = i;
    v(i) = tempP[iP];
  }
    
  /* (Fill the Petsc vector), restore intermediate array and return */
  VecRestoreArray(vP,&tempP);
  PetscFunctionReturn(0);
}





/*------------------*/
/* General routines */
/*----------------------------------------------------------------------------*/


/* Set Tao options */
PetscErrorCode Optimizer::setTaoOptions ()
{
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Set method in tao to Pounders */
  TaoSetType(tao,TAOPOUNDERS);
    
  /* Set the options from Optimizer to Tao:
     . from the command line arguments,
     . max number of iterations,
     . tolerance: made on the estimated gradient norm (gatol) */
  TaoSetFromOptions(tao);
  TaoSetMaximumIterations(tao,nIterMax);
  TaoSetTolerances(tao,0.,0.,precConv,0.,0.);  // (tao,fatol,frtol,gatol,grtol,gttol)
    
    
  /* History printing */
  /* Gets options from the line command */
  PetscOptionsGetBool(NULL,"-printhistory",&printhistory,0);
    
#ifdef UseOldPetsc
  TaoSetHistory(tao,hist,resid,0,100,PETSC_TRUE);
#endif
    
#ifdef UseNewPetsc
  TaoSetConvergenceHistory(tao,hist,resid,0,lits,100,PETSC_TRUE);
#endif
    
    
  /* Return */
  PetscFunctionReturn(0);
}




/* Tao history printing */
PetscErrorCode Optimizer::taoView ()
{
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Tao history printing */
  if (printhistory) {
#ifdef UseOldPetsc
    TaoGetHistory(tao,0,0,0,&nhist);
#endif
#ifdef UseNewPetsc
    TaoGetConvergenceHistory(tao,0,0,0,0,&nhist);
#endif
    for (PetscInt i=0; i<nhist; ++i) {
      PetscPrintf(PETSC_COMM_WORLD,"%g\t%g\n",(double)hist[i],(double)resid[i]);
    }
  }

  /* Tao view */
  TaoView(tao,PETSC_VIEWER_STDOUT_SELF);
    
  /* Return */
  PetscFunctionReturn(0);
}








/*------------------------------*/
/* Residuals computing routines */
/*----------------------------------------------------------------------------*/


/* Residual computing routine for master node */
PetscErrorCode Optimizer::computeMasterP (Tao tao, VecP paramsP, VecP resP, void *ctx)
{
  /* Petsc context is the same class optimizer */
  Optimizer *optimizer = (Optimizer*)ctx;
    
  /* Optimizer references */
  const unsigned int nparams_  = optimizer->nparams;
  Vect<double> &res_           = optimizer->res;
  Vect<double> &params_        = optimizer->params;
  Vect<double> &dparams_       = optimizer->dparams;
  Vect<double> &dparamsScaled_ = optimizer->dparamsScaled;
    
  PetscInt     nparamsP_       = optimizer->nparamsP;

    
  /* General variables */
  PetscReal *tempP;  // intermediate array
    
    
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Give signal to slave processes */
  PetscInt tag = optimizer->tagActive;
  MPI_Barrier(PETSC_COMM_WORLD);
  MPI_Bcast(&tag,1,MPI_INT,MASTER_PROCESS,PETSC_COMM_WORLD);
  MPI_Barrier(PETSC_COMM_WORLD);
    
  /* Fill the intermediate array tempP */
  VecGetArray(paramsP,&tempP);
    
  /* Broadcast the array to the slave processes */
  MPI_Bcast(tempP,nparamsP_,MPIU_REAL,MASTER_PROCESS,PETSC_COMM_WORLD);
  MPI_Barrier(PETSC_COMM_WORLD);
    
    
  /* Prepare the calculation of dparams and dparamsScaled */
  dparams_ = params_;
    
    
  /* Set Optimizer::params tp the new set of parameters */
  optimizer->transfer(paramsP,params_);
    
    
  /* Get dparams and dparamsScaled */
  dparams_ -= params_;
  dparamsScaled_ = dparams_;
  for (unsigned int i=0; i<nparams_; ++i) {
    dparamsScaled_(i) /= params_(i);
  }
    
  /* Compute, print and increment iter */
  optimizer->compute();
  optimizer->printIterationData();
  ++(optimizer->iter);
    
    
  /* Transfer the residuals to the Petsc vector-variable resP */
  optimizer->transfer(res_,resP);
    
    
  /* (Fill the Petsc vector), restore intermediate array and return */
  VecRestoreArray(paramsP,&tempP);
  PetscFunctionReturn(0);
}





/* Residual computing routine for slave nodes */
void Optimizer::computeSlavesP ()
{
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Compute if signal from the master node says so */
  /* Tag to continue or quit the loop */
  PetscInt tag = tagActive;
  while (tag != tagDie) {
    /* Get the signal from the master process */
    MPI_Barrier(PETSC_COMM_WORLD);
    MPI_Bcast(&tag,1,MPI_INT,MASTER_PROCESS,PETSC_COMM_WORLD);
    MPI_Barrier(PETSC_COMM_WORLD);
        
    if (tag != tagDie) {
      PetscReal *tempP; // intermediate array
      VecGetArray(paramsP,&tempP);

      /* Get the parameters from the master node */
      MPI_Bcast(tempP,nparamsP,MPIU_REAL,MASTER_PROCESS,PETSC_COMM_WORLD);
      MPI_Barrier(PETSC_COMM_WORLD);
            
      /* Fill the Petsc vector, restore intermediate array */
      VecRestoreArray(paramsP,&tempP);
            
      /* Set Optimizer::params tp the new set of parameters */
      transfer(paramsP,params);
            
      /* Compute, print and increment iter */
      compute();
      printIterationData();
      ++iter;
    }
  }
}




/* Dispatch stop signal (from master node to slave nodes) */
void Optimizer::stopSlavesP ()
{
  /* PETSc starting function */
  PetscFunctionBegin;
    
  /* Dispatch stop signal to slave processes */
  PetscInt tag = tagDie;
  MPI_Barrier(PETSC_COMM_WORLD);
  MPI_Bcast(&tag,1,MPI_INT,MASTER_PROCESS,PETSC_COMM_WORLD);
  MPI_Barrier(PETSC_COMM_WORLD);
}







/*------------------------------*/
/*------------------------------*/
/* Main POUNDerS solver routine */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

void Optimizer::solvePounders ()
{
  /* PETSc starting function */
  PetscFunctionBegin;
    
    
  /*----------------*/
  /* On master node:
     . run optimization on master process
     . run the master process's calculation part */
  /*------------------------------------------------------------------------*/
  if (THIS_PROCESS == MASTER_PROCESS) {

    /*-----------------------------*/
    /* Set tao data from Optimizer */
    /*--------------------------------------------------------------------*/
    /*-- General options */
    setTaoOptions();
        
    /*-- Initial parameter vector */
    transfer(params,paramsP);
    TaoSetInitialVector(tao,paramsP);
        
    /*-- Residual routine */
    TaoSetSeparableObjectiveRoutine(tao,resP,computeMasterP,(void*)this);

        
        
    /*--------------------------*/
    /*--------------------------*/
    /* Perform the optimization */
    /*--------------------------------------------------------------------*/
    /*--------------------------------------------------------------------*/
    TaoSolve(tao);
    taoView();
        
 
        
    /*-------------------------------------*/
    /* Send stop signal to slave processes */
    /*--------------------------------------------------------------------*/
    stopSlavesP();
  }
    
    
  /*----------------*/
  /* On slave nodes:
     . run the calculation (no optimization) */
  /*------------------------------------------------------------------------*/
  else {
    computeSlavesP();
  }
    
    
  /*---------------------------------------------------*/
  /* Recover correct iteration index and print results */
  /*------------------------------------------------------------------------*/
  --iter;
  printResults();
}



#endif
