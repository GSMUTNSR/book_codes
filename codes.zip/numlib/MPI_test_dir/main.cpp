#include "numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();
    
    const unsigned int N_MPI = 10000000;
    
    const unsigned int N_OpenMP = 50000;

    const double step_OpenMP = 1E-6/N_OpenMP;
    
#ifdef UseOpenMP

    const unsigned int N_threads = 1;

    OpenMP_set_threads_number (N_threads);

#endif

    if (THIS_PROCESS == MASTER_PROCESS)
      {
	cout << "Number of processes:" << NUMBER_OF_PROCESSES << endl;
	
	cout << "Number of threads:" << NUMBER_OF_THREADS << endl << endl;
	
	cout << "N.transfer[MPI]: " << N_MPI << endl;

	cout << "N.calculation[OpenMP]: " << N_OpenMP << endl << endl;
      }
    
    class array<complex<double> > T_MPI(N_MPI);

    if (THIS_PROCESS == MASTER_PROCESS) T_MPI = complex<double> (M_PI , M_PI);
    
    const double t0 = absolute_time_determine ();
    
#ifdef UseMPI
    T_MPI.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);
#endif
    
    const double t1 = absolute_time_determine ();
    
    const double t_MPI = t1 - t0;
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << "t[MPI Bcast communications]:" << t_MPI << " s" << endl;

    class array<complex<double> > T_OpenMP(N_OpenMP);

    T_OpenMP = complex<double> (M_PI , M_PI);
    
    const double t2 = absolute_time_determine ();

#ifdef UseOpenMP
#pragma omp parallel for default(shared) if (is_it_OpenMP_parallelized)
#endif
    for (unsigned int i = 0 ; i < N_OpenMP ; i++)
      {
	const complex<double> x(1.0 + i*step_OpenMP , step_OpenMP);
	
	for (unsigned int j = 0 ; j < N_OpenMP ; j++) T_OpenMP(i) *= x;
      }

    const double t3 = absolute_time_determine ();
    
    const double t_OpenMP = t3 - t2;
    
    if (THIS_PROCESS == MASTER_PROCESS) cout << "t[OpenMP multiplications]:" << t_OpenMP << " s" << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
