#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


void eigenvalues_eigenvectors_2x2_calc_print (
					      const double real_a_min , 
					      const double imag_a ,
					      const double step_real_a ,
					      const unsigned int i ,
					      ofstream &out_file)
{
  const double real_a = real_a_min + i*step_real_a;

  const complex<double> a(real_a , imag_a);

  const complex<double> one_plus_a_square = 1.0 + a*a;

  const complex<double> sqrt_one_plus_a_square = sqrt (one_plus_a_square);

  const complex<double> eigenvalue_0 = 1.0 + sqrt_one_plus_a_square;
  const complex<double> eigenvalue_1 = 1.0 - sqrt_one_plus_a_square;

  const complex<double> squared_norm_eigenvectors = 2.0*(one_plus_a_square - sqrt_one_plus_a_square);

  const complex<double> norm_eigenvectors = sqrt (squared_norm_eigenvectors);

  const complex<double> eigenvector_00 = -1.0 + sqrt_one_plus_a_square;
  const complex<double> eigenvector_01 = a;

  const complex<double> eigenvector_10 = -eigenvector_01;
  const complex<double> eigenvector_11 =  eigenvector_00;

  out_file << real_a << " "
	   << real (eigenvalue_0) << " " << imag (eigenvalue_0) << " "
	   << real (eigenvalue_1) << " " << imag (eigenvalue_1) << " "
	   << real (norm_eigenvectors) << " " 
	   << imag (norm_eigenvectors)
	   << real (eigenvector_00) << " " << imag (eigenvector_00) << " " << real (eigenvector_01) << " " << imag (eigenvector_01) << " "
	   << real (eigenvector_10) << " " << imag (eigenvector_10) << " " << real (eigenvector_11) << " " << imag (eigenvector_11) << endl;
}



void eigenvalues_for_plot_2x2 (
			       const double imag_a , 
			       const double real_a_min , 
			       const double real_a_max ,
			       const unsigned int N)
{ 
  const double real_a_min_small = -0.01;
  const double real_a_max_small =  0.01;

  const double step_real_a = (real_a_max - real_a_min)/static_cast<double> (N - 1);

  const double step_real_a_small_negative = -real_a_min_small/static_cast<double> (N - 1);
  const double step_real_a_small_positive =  real_a_max_small/static_cast<double> (N - 1);

  const unsigned int N_first_part = make_uns_int ((real_a_min_small - real_a_min)/step_real_a);

  const unsigned int deb_last_part = make_uns_int ((real_a_max_small - real_a_min)/step_real_a);

  ofstream out_file("out_2x2.dat");

  out_file.precision (15);

  for (unsigned int i = 0             ; i < N_first_part ; i++) eigenvalues_eigenvectors_2x2_calc_print (real_a_min       , imag_a , step_real_a                , i , out_file);
  for (unsigned int i = 0             ; i < N            ; i++) eigenvalues_eigenvectors_2x2_calc_print (real_a_min_small , imag_a , step_real_a_small_negative , i , out_file);
  for (unsigned int i = 0             ; i < N            ; i++) eigenvalues_eigenvectors_2x2_calc_print (0                , imag_a , step_real_a_small_positive , i , out_file);
  for (unsigned int i = deb_last_part ; i < N            ; i++) eigenvalues_eigenvectors_2x2_calc_print (real_a_min       , imag_a , step_real_a                , i , out_file);
}





complex<double> d_exc_non_degenerate_calc (
					   const unsigned int root_index,
					   const complex<double> &a ,
					   const complex<double> &b ,
					   const complex<double> &c)
{
  const complex<double> alpha = a*a + b*b + c*c + a*b;

  const complex<double> beta = (a + b)*(a*b - c*c);

  const complex<double> a_minus_b = a - b;

  const complex<double> beta_minus_b_alpha = beta - b*alpha;

  const complex<double> C_d4 = a_minus_b*a_minus_b + 4.0*c*c;

  const complex<double> C_d2 = 2.0*(beta_minus_b_alpha*a_minus_b + 2.0*alpha*c*c);

  const complex<double> C_d0 = beta_minus_b_alpha*beta_minus_b_alpha;

  if (inf_norm (C_d4) > 1E-15)
    {
      complex<double> d_exc_square_12 = 0.0;
      complex<double> d_exc_square_34 = 0.0;

      const complex<double> Cr_d2 = 2.0*(beta_minus_b_alpha*a_minus_b + 2.0*alpha*c*c)/C_d4;

      const complex<double> Cr_d0 = beta_minus_b_alpha*beta_minus_b_alpha/C_d4;

      roots_polynomial_degree_two (Cr_d2 , Cr_d0 , d_exc_square_12 , d_exc_square_34);

      switch (root_index)
	{
	case 1: return  sqrt (d_exc_square_12); 
	case 2: return -sqrt (d_exc_square_12); 
	case 3: return  sqrt (d_exc_square_34); 
	case 4: return -sqrt (d_exc_square_34); 

	default: abort_all ();
	}
    }
  else if (inf_norm (C_d2) > 1E-15)
    {
      const complex<double> d_exc_square = -C_d0/C_d2;

      switch (root_index)
	{
	case 1: return  sqrt (d_exc_square); 
	case 2: return -sqrt (d_exc_square); 

	default: error_message_print_abort ("d has only two roots here: choose d.root.index = 1 or 2");
	}
    }
  else if (inf_norm (C_d0) > 1E-15)
    {
      cout << "Case without exceptional points" << endl;

      exit (1);
    }

  return NADA;
}



complex<double> e_non_degenerate_calc (
				       const int cde_zero_sign ,
				       const complex<double> &a ,
				       const complex<double> &b ,
				       const complex<double> &c , 
				       const complex<double> &d_exc)
{
  const complex<double> I(0,1);

  const complex<double> alpha = a*a + b*b + c*c + a*b;
  const complex<double> beta = (a + b)*(a*b - c*c);

  const complex<double> e_no_phase = I*sqrt (alpha + d_exc*d_exc);

  const complex<double> cde_exc_no_phase = c*d_exc*e_no_phase;

  if (inf_norm (cde_exc_no_phase) < 1E-15)
    {
      const complex<double> e = e_no_phase*cde_zero_sign;

      return e;
    }

  const complex<double> two_cde_exc_no_phase = 2.0*c*d_exc*e_no_phase;

  const complex<double> right_hand_side_second_equation = beta + a*d_exc*d_exc + b*e_no_phase*e_no_phase;

  const complex<double> second_equation_plus  = right_hand_side_second_equation - two_cde_exc_no_phase;
  const complex<double> second_equation_minus = right_hand_side_second_equation + two_cde_exc_no_phase;

  const complex<double> e = (inf_norm (second_equation_plus) <= inf_norm (second_equation_minus)) ? (e_no_phase) : (-e_no_phase);   

  return e;
}






bool are_roots_Newton_separated ( 
				 const complex<double> &p ,
				 const complex<double> &q ,  
				 const complex<double> &e0 ,
				 const complex<double> &e1 , 
				 const complex<double> &e2)
{
  const complex<double> e0_square = e0*e0 , de0 = (q + e0*(p + e0_square))/(2.0*e0_square + p);
  const complex<double> e1_square = e1*e1 , de1 = (q + e1*(p + e1_square))/(2.0*e1_square + p);
  const complex<double> e2_square = e2*e2 , de2 = (q + e2*(p + e2_square))/(2.0*e2_square + p);

  const double inf_norm_e0 = inf_norm (e0);
  const double inf_norm_e1 = inf_norm (e1);
  const double inf_norm_e2 = inf_norm (e2);

  const double e0_e1_maximal_accepted_change = (inf_norm_e0 < inf_norm_e1) ? (0.999*abs (1.0 - e0/e1)) : (0.999*abs (1.0 - e1/e0));
  const double e1_e2_maximal_accepted_change = (inf_norm_e1 < inf_norm_e2) ? (0.999*abs (1.0 - e1/e2)) : (0.999*abs (1.0 - e2/e1));
  const double e0_e2_maximal_accepted_change = (inf_norm_e2 < inf_norm_e0) ? (0.999*abs (1.0 - e2/e0)) : (0.999*abs (1.0 - e0/e2));

  const double abs_de0_over_e0 = abs (de0/e0);
  const double abs_de1_over_e1 = abs (de1/e1);
  const double abs_de2_over_e2 = abs (de2/e2);

  if (abs_de0_over_e0 > e0_e1_maximal_accepted_change) return false;
  if (abs_de0_over_e0 > e0_e2_maximal_accepted_change) return false;

  if (abs_de1_over_e1 > e0_e1_maximal_accepted_change) return false;
  if (abs_de1_over_e1 > e1_e2_maximal_accepted_change) return false;

  if (abs_de2_over_e2 > e0_e2_maximal_accepted_change) return false;
  if (abs_de2_over_e2 > e1_e2_maximal_accepted_change) return false;

  return true;
}




void root_Newton_method (
			 const complex<double> &p ,
			 const complex<double> &q ,  
			 complex<double> &e_root)
{
  double test = 1.0;

  unsigned int count = 0;

  while (test > 1E-15)
    {
      const complex<double> e_root_square = e_root*e_root;
      
      const complex<double> de_root = (q + e_root*(p + e_root_square))/(2.0*e_root_square + p);
	  
      e_root -= 0.3*de_root;
	  	  
      test = inf_norm (de_root/e_root);

      if (count++ > 1000) error_message_print_abort ("No convergence in the Newton method for eigenvalues in root_Newton_method");
    }
}





void find_all_roots_Newton_method (
				   const complex<double> &p ,
				   const complex<double> &q ,  
				   complex<double> &e0 ,
				   complex<double> &e1 ,
				   complex<double> &e2)
{
  if (!are_roots_Newton_separated (p , q , e0 , e1 , e2)) 
    error_message_print_abort ("Eigenvalues might be mixed using the Newton method. Start with a smaller maximal epsilon, larger minimal epsilon modulus and/or larger modulus step.");

  const double inf_norm_e0 = inf_norm (e0);
  const double inf_norm_e1 = inf_norm (e1);
  const double inf_norm_e2 = inf_norm (e2);

  if ((inf_norm_e0 <= inf_norm_e1) && (inf_norm_e0 <= inf_norm_e2))
    {
      root_Newton_method (p , q , e1);
      root_Newton_method (p , q , e2);

      e0 = -q/(e1*e2);
    }
  else if ((inf_norm_e1 <= inf_norm_e0) && (inf_norm_e1 <= inf_norm_e2))
    {
      root_Newton_method (p , q , e0);
      root_Newton_method (p , q , e2);

      e1 = -q/(e0*e2);
    }
  else
    {
      root_Newton_method (p , q , e0);
      root_Newton_method (p , q , e1);

      e2 = -q/(e0*e1);
    }
}





void general_3x3 (
		  const bool is_it_degenerate ,
		  const unsigned int root_index,
		  const int cde_zero_sign ,
		  const complex<double> &a ,
		  const complex<double> &b ,
		  const complex<double> &c , 
		  const complex<double> &e_degenerate ,  
		  const double abs_eps_max ,  
		  const double abs_eps_min ,  
		  const double abs_eps_step , 
		  const double arg_eps)
{
  const complex<double> I(0,1);

  class matrix<complex<double> > A(3);

  const complex<double> e_phase = (is_it_degenerate) ? (c/a) : (NADA);

  const complex<double> d_exc = (is_it_degenerate) ? (e_phase*e_degenerate) : (d_exc_non_degenerate_calc (root_index, a , b , c));

  const complex<double> e = (is_it_degenerate) ? (e_degenerate) : (e_non_degenerate_calc (cde_zero_sign , a , b , c , d_exc));

  ofstream out_file("out_general_3x3.dat");

  out_file.precision (15);

  const complex<double> ce_minus_da_exc_numerical = c*e - d_exc*a;
  
  const complex<double> ce_minus_da_exc = (inf_norm (ce_minus_da_exc_numerical) > 1E-15) ? (ce_minus_da_exc_numerical)   : (0.0);

  const complex<double> C_e_degree_two_exc_numerical = 3.0*(a*b - c*c);

  const complex<double> C_e_degree_three_exc_numerical = -2.0*(a + b);

  const complex<double> norm_eps_degree_one_exc_numerical = 2.0*c*(c*d_exc - b*e) - 2.0*a*ce_minus_da_exc;

  const complex<double> norm_eps_degree_two_exc_numerical = a*a + c*c;

  const complex<double> C_e_degree_two_exc   = (inf_norm (C_e_degree_two_exc_numerical)   > 1E-15) ? (C_e_degree_two_exc_numerical)   : (0.0);
  const complex<double> C_e_degree_three_exc = (inf_norm (C_e_degree_three_exc_numerical) > 1E-15) ? (C_e_degree_three_exc_numerical) : (0.0);

  const complex<double> norm_eps_degree_one_exc = (inf_norm (norm_eps_degree_one_exc_numerical) > 1E-15) ? (norm_eps_degree_one_exc_numerical) : (0.0);
  const complex<double> norm_eps_degree_two_exc = (inf_norm (norm_eps_degree_two_exc_numerical) > 1E-15) ? (norm_eps_degree_two_exc_numerical) : (0.0);

  complex<double> eps = abs_eps_max*exp (I*arg_eps);

  complex<double> e0 , e1 , e2;

  bool is_it_first_point = true;

  do
    {
      const double abs_eps = abs (eps);

      const complex<double> d = d_exc + eps;

      A(0,0) = a , A(0,1) = c , A(0,2) = e;
      A(1,0) = c , A(1,1) = b , A(1,2) = d;
      A(2,0) = e , A(2,1) = d , A(2,2) = -a-b;
            
      cout << endl << "eps=" << eps << endl << endl;

      cout << "Matrix" << endl << endl << A << endl;

      const complex<double> p = -eps*(2.0*d_exc + eps);

      const complex<double> q = eps*(-2.0*ce_minus_da_exc + a*eps);

      if (inf_norm (q) < 1E-320) error_message_print_abort ("epsilon is too small for calculations to be numerically stable. Start with a larger minimal epsilon modulus."); 

      if (is_it_first_point) roots_polynomial_degree_three (0.0 , p , q , e0 , e1 , e2);

      find_all_roots_Newton_method (p , q , e0 , e1 , e2);

      class vector_class<complex<double> > eigenvector_0(3);
      class vector_class<complex<double> > eigenvector_1(3);
      class vector_class<complex<double> > eigenvector_2(3);

      eigenvector_0(0) = c*d - e*(b - e0);
      eigenvector_1(0) = c*d - e*(b - e1);
      eigenvector_2(0) = c*d - e*(b - e2);

      eigenvector_0(1) = d*(e0 - a) + c*e;
      eigenvector_1(1) = d*(e1 - a) + c*e;
      eigenvector_2(1) = d*(e2 - a) + c*e;

      eigenvector_0(2) = (b - e0)*(a - e0) - c*c;
      eigenvector_1(2) = (b - e1)*(a - e1) - c*c;
      eigenvector_2(2) = (b - e2)*(a - e2) - c*c;
        
      cout << "1st eigenvalue: " << e0 << endl;
      cout << "2nd eigenvalue: " << e1 << endl;
      cout << "3rd eigenvalue: " << e2 << endl << endl; 

      const complex<double> C_e_degree_one   = eps*(4.0*ce_minus_da_exc - 2.0*a*eps);
      const complex<double> C_e_degree_two   = C_e_degree_two_exc + eps*(2.0*d_exc + eps);
      const complex<double> C_e_degree_three = C_e_degree_three_exc;

      const complex<double> norm_eps_term = eps*(norm_eps_degree_one_exc + eps*norm_eps_degree_two_exc);
      
      const complex<double> norm_e0_factor = C_e_degree_one + e0*(C_e_degree_two + e0*(C_e_degree_three + e0));
      const complex<double> norm_e1_factor = C_e_degree_one + e1*(C_e_degree_two + e1*(C_e_degree_three + e1));
      const complex<double> norm_e2_factor = C_e_degree_one + e2*(C_e_degree_two + e2*(C_e_degree_three + e2));

      const complex<double> squared_norm_0 = norm_eps_term + e0*norm_e0_factor;
      const complex<double> squared_norm_1 = norm_eps_term + e1*norm_e1_factor;
      const complex<double> squared_norm_2 = norm_eps_term + e2*norm_e2_factor;

      const double abs_e0 = abs (e0);
      const double abs_e1 = abs (e1);
      const double abs_e2 = abs (e2);

      const double abs_norm_0 = (norm_eps_term != 0.0) ? (sqrt (abs (squared_norm_0))) : (sqrt (abs_e0)*sqrt (abs (norm_e0_factor)));
      const double abs_norm_1 = (norm_eps_term != 0.0) ? (sqrt (abs (squared_norm_1))) : (sqrt (abs_e1)*sqrt (abs (norm_e1_factor)));
      const double abs_norm_2 = (norm_eps_term != 0.0) ? (sqrt (abs (squared_norm_2))) : (sqrt (abs_e2)*sqrt (abs (norm_e2_factor)));

      if (abs_eps > sqrt_precision)
	{
	  cout << endl << endl << "Numerical check with direct formulas as |eps| > 10^(-5)" << endl;
	  cout << "1st eigenvector.      norm test: " << inf_norm (eigenvector_0*eigenvector_0 - squared_norm_0) << "         eigenvector test:" << (A*eigenvector_0 - e0*eigenvector_0).infinite_norm () << endl;
	  cout << "2nd eigenvector.      norm test: " << inf_norm (eigenvector_1*eigenvector_1 - squared_norm_1) << "         eigenvector test:" << (A*eigenvector_1 - e1*eigenvector_1).infinite_norm () << endl;
	  cout << "3rd eigenvector.      norm test: " << inf_norm (eigenvector_2*eigenvector_2 - squared_norm_2) << "         eigenvector test:" << (A*eigenvector_2 - e2*eigenvector_2).infinite_norm () << endl;
	}  

      out_file << abs_eps << " " 
	       << abs_e0 << " " << arg (e0) << " " 
	       << abs_e1 << " " << arg (e1) << " " 
	       << abs_e2 << " " << arg (e2) << " "
	       << abs_norm_0 << " " 
	       << abs_norm_1 << " " 
	       << abs_norm_2 << " " 
	       << real (eigenvector_0(0)) << " " << imag (eigenvector_0(0)) << " " << real (eigenvector_0(1)) << " " << imag (eigenvector_0(1)) << " " << real (eigenvector_0(2)) << " " << imag (eigenvector_0(2)) << " " 
	       << real (eigenvector_1(0)) << " " << imag (eigenvector_1(0)) << " " << real (eigenvector_1(1)) << " " << imag (eigenvector_1(1)) << " " << real (eigenvector_1(2)) << " " << imag (eigenvector_1(2)) << " " 
	       << real (eigenvector_2(0)) << " " << imag (eigenvector_2(0)) << " " << real (eigenvector_2(1)) << " " << imag (eigenvector_2(1)) << " " << real (eigenvector_2(2)) << " " << imag (eigenvector_2(2)) << endl; 

      eps *= abs_eps_step;

      is_it_first_point = false;
    }
  while (abs (eps) > abs_eps_min);
}




complex<double> b0_determine (const unsigned b0_index)
{
  switch (b0_index)
    {
    case 1: return -1.67765069880406;

    case 2: return complex<double> (0.0888253494020299,0.538651906424982);

    case 3: return complex<double> (0.0888253494020299,-0.538651906424982);

    default:abort_all ();
    }

  return NADA;
}




void off_diagonal_identical_3x3 (
				 const unsigned b0_index , 
				 const double abs_eps_max , 
				 const double abs_eps_min , 
				 const double abs_eps_step , 
				 const double arg_eps)
{  
  const complex<double> I(0,1);

  const complex<double> b0 = b0_determine (b0_index) , b0_p1 = 1.0 + b0 , six_b0 = 6.0*b0 , six_b0_p3 = six_b0 + 3.0;
      
  ofstream out_file("out_off_diagonal_identical_3x3.dat");

  out_file.precision (15);

  complex<double> eps = abs_eps_max*exp (I*arg_eps);

  cout << endl;

  do
    {
      const double abs_eps = abs (eps);

      const complex<double> b = b0 + eps , b2 = b*b;

      const complex<double> a = -0.5 + 0.5*I*sqrt (12.0*b2 + 3.0);

      const complex<double> ap1 = a + 1.0 , two_ap1 = 2.0*ap1 , a_ap4_p1 = a*(a + 4.0) + 1.0;

      const complex<double> root_cubed = eps*(six_b0*b0_p1 + eps*(six_b0_p3 + 2.0*eps));

      const complex<double> two_root_cubed = 2.0*root_cubed;

      class matrix<complex<double> > A(3);
      
      A = b;

      A(0 , 0) = 1;
      A(1 , 1) = a;
      A(2 , 2) = -a-1;

      cout << endl << "eps=" << eps << endl << endl;

      cout << "Matrix" << endl << endl << A << endl;

      const complex<double> ap1_root_cubed_over_b2 = ap1*root_cubed/b2;

      const complex<double> j (-0.5 ,  0.8660254037844386);
      const complex<double> j2(-0.5 , -0.8660254037844386);
      
      const complex<double> e0 = cbrt (root_cubed);

      const complex<double> e1 = j*e0;
      const complex<double> e2 = j2*e0;

      class vector_class<complex<double> > eigenvector_0(3);
      class vector_class<complex<double> > eigenvector_1(3);
      class vector_class<complex<double> > eigenvector_2(3);

      eigenvector_0(0) = a - e0 - b;
      eigenvector_1(0) = a - e1 - b;
      eigenvector_2(0) = a - e2 - b;

      eigenvector_0(1) = 1.0 - e0 - b;
      eigenvector_1(1) = 1.0 - e1 - b;
      eigenvector_2(1) = 1.0 - e2 - b;

      eigenvector_0(2) = b - (1.0 - e0)*(a - e0)/b;
      eigenvector_1(2) = b - (1.0 - e1)*(a - e1)/b;
      eigenvector_2(2) = b - (1.0 - e2)*(a - e2)/b;
        
      cout << "1st eigenvalue: " << e0 << endl;
      cout << "2nd eigenvalue: " << e1 << endl;
      cout << "3rd eigenvalue: " << e2 << endl << endl; 
    
      const complex<double> norm_e0_factor = (two_root_cubed + e0*(a_ap4_p1 + e0*(-two_ap1 + e0)))/b2;
      const complex<double> norm_e1_factor = (two_root_cubed + e1*(a_ap4_p1 + e1*(-two_ap1 + e1)))/b2;
      const complex<double> norm_e2_factor = (two_root_cubed + e2*(a_ap4_p1 + e2*(-two_ap1 + e2)))/b2;

      const complex<double> squared_norm_0 = -ap1_root_cubed_over_b2 + e0*norm_e0_factor;
      const complex<double> squared_norm_1 = -ap1_root_cubed_over_b2 + e1*norm_e1_factor;
      const complex<double> squared_norm_2 = -ap1_root_cubed_over_b2 + e2*norm_e2_factor;

      const double abs_e0 = abs (e0);
      const double abs_e1 = abs (e1);
      const double abs_e2 = abs (e2);

      const double abs_norm_0 = (ap1_root_cubed_over_b2 != 0.0) ? (sqrt (abs (squared_norm_0))) : (sqrt (abs_e0)*sqrt (abs (norm_e0_factor)));
      const double abs_norm_1 = (ap1_root_cubed_over_b2 != 0.0) ? (sqrt (abs (squared_norm_1))) : (sqrt (abs_e1)*sqrt (abs (norm_e1_factor)));
      const double abs_norm_2 = (ap1_root_cubed_over_b2 != 0.0) ? (sqrt (abs (squared_norm_2))) : (sqrt (abs_e2)*sqrt (abs (norm_e2_factor)));

      if (abs_eps > sqrt_precision)
	{
	  cout << endl << endl << "Numerical check with direct formulas as |eps| > 10^(-5)" << endl;
	  cout << "1st eigenvector.      norm test: " << inf_norm (eigenvector_0*eigenvector_0 - squared_norm_0) << "         eigenvector test:" << (A*eigenvector_0 - e0*eigenvector_0).infinite_norm () << endl;
	  cout << "2nd eigenvector.      norm test: " << inf_norm (eigenvector_1*eigenvector_1 - squared_norm_1) << "         eigenvector test:" << (A*eigenvector_1 - e1*eigenvector_1).infinite_norm () << endl;
	  cout << "3rd eigenvector.      norm test: " << inf_norm (eigenvector_2*eigenvector_2 - squared_norm_2) << "         eigenvector test:" << (A*eigenvector_2 - e2*eigenvector_2).infinite_norm () << endl;
	}  

      cout << endl << endl;

      out_file << abs_eps << " " 
	       << abs_e0 << " " << arg (e0) << " " 
	       << abs_e1 << " " << arg (e1) << " " 
	       << abs_e2 << " " << arg (e2) << " "
	       << abs_norm_0 << " " 
	       << abs_norm_1 << " " 
	       << abs_norm_2 << " " 
	       << real (eigenvector_0(0)) << " " << imag (eigenvector_0(0)) << " " << real (eigenvector_0(1)) << " " << imag (eigenvector_0(1)) << " " << real (eigenvector_0(2)) << " " << imag (eigenvector_0(2)) << " " 
	       << real (eigenvector_1(0)) << " " << imag (eigenvector_1(0)) << " " << real (eigenvector_1(1)) << " " << imag (eigenvector_1(1)) << " " << real (eigenvector_1(2)) << " " << imag (eigenvector_1(2)) << " " 
	       << real (eigenvector_2(0)) << " " << imag (eigenvector_2(0)) << " " << real (eigenvector_2(1)) << " " << imag (eigenvector_2(1)) << " " << real (eigenvector_2(2)) << " " << imag (eigenvector_2(2)) << endl; 

      eps *= abs_eps_step;
    }
  while (abs (eps) > abs_eps_min);
}






#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    string calculation_str;
    cin >> calculation_str;

    if (calculation_str == "2x2.plot")
      {	
	double imag_a;
	cin >> imag_a;
	word_check_print<double> ("(a.imaginary.part)" , imag_a);

	double real_a_min;
	cin >> real_a_min;
	word_check_print<double> ("(a.minimal.real.part)" , real_a_min);

	double real_a_max;
	cin >> real_a_max;
	word_check_print<double> ("(a.maximal.real.part)" , real_a_max);

	unsigned int N;
	cin >> N;
	word_check_print<unsigned int> ("(matrices.number)" , N);

	eigenvalues_for_plot_2x2 (imag_a , real_a_min , real_a_max , N);
      }
    else if (calculation_str == "3x3.general")
      {
	const bool is_it_degenerate = bool_determination ("degenerate.case");

	complex<double> a , b , c , e_degenerate = 0.0;

	int root_index = 0 , cde_zero_sign = 1;

	cin >> a;
	word_check_print<complex<double> > ("(a)" , a);

	cin >> b;
	word_check_print<complex<double> > ("(b)" , b);

	cin >> c;
	word_check_print<complex<double> > ("(c)" , c);

	const bool is_it_degenerate_check = ((inf_norm (a + b) < 1E-15) && (inf_norm (a*a + c*c) < 1E-15));

	if (is_it_degenerate_check && !is_it_degenerate) error_message_print_abort ("The matrix is degenerate: one has a+b ~ 0 and a^2 + c^2 ~ 0: wrong input in 3x3.general");

	if (!is_it_degenerate_check && is_it_degenerate) error_message_print_abort ("The matrix is not degenerate: one must have a+b ~ 0 and a^2 + c^2 ~ 0: wrong input in 3x3.general");

	if (is_it_degenerate)
	  {
	    if (a == 0.0) error_message_print_abort ("a must be non-zero in the degenerate case for a 3x3 exceptional point to occur in 3x3.general");

	    cin >> e_degenerate;
	    word_check_print<complex<double> > ("(e)" , e_degenerate);

	    if (e_degenerate == 0.0) error_message_print_abort ("e must be non-zero in the degenerate case for a 3x3 exceptional point to occur in 3x3.general");
	  }
	else
	  {	   
	    cin >> root_index;
	    word_check_print<complex<double> > ("(d.root.index)" , root_index);
	   
	    if ((root_index != 1) && (root_index != 2) && (root_index != 3) && (root_index != 4)) error_message_print_abort ("d root index must be 1,2,3,4 in the non-degenerate case in 3x3.general"); 

	    cin >> cde_zero_sign;
	    word_check_print<int> ("(cde.zero.sign)" , cde_zero_sign);

	    if (abs (cde_zero_sign) != 1) error_message_print_abort ("The sign of the e sqrt for cde = 0 is +/-1 in 3x3.general");
	  }

	double abs_eps_max , abs_eps_min , abs_eps_step , arg_eps;

	cin >> abs_eps_max;
	word_check_print<double> ("(maximal.epsilon.modulus)" , abs_eps_max);

	cin >> abs_eps_min;
	word_check_print<double> ("(minimal.epsilon.modulus)" , abs_eps_min);

	cin >> abs_eps_step;
	word_check_print<double> ("(epsilon.modulus.step)" , abs_eps_step);

	cin >> arg_eps;
	word_check_print<double> ("(epsilon.argument.in.degrees)" , arg_eps);

	if ((abs_eps_step <= 0.0) || (abs_eps_step >= 1.0)) error_message_print_abort ("Epsilon step must be in ]0:1[");

	if ((abs_eps_max <= 0.0) || (abs_eps_min <= 0.0)) error_message_print_abort ("Epsilon values must be positive in 3x3.general");

	if ((abs_eps_max < abs_eps_min)) error_message_print_abort ("maximal.epsilon.modulus must be larger than minimal.epsilon.modulus in 3x3.general");

	arg_eps *= M_PI/180.0;

	general_3x3 (is_it_degenerate , root_index , cde_zero_sign , a , b , c , e_degenerate , abs_eps_max , abs_eps_min , abs_eps_step , arg_eps);
      }
    else if (calculation_str == "3x3.off.diagonal.identical")
      {
	unsigned int b0_index;	
	cin >> b0_index;
	word_check_print<unsigned int> ("(b0.index)" , b0_index);

	double abs_eps_max , abs_eps_min , abs_eps_step , arg_eps;

	cin >> abs_eps_max;
	word_check_print<double> ("(maximal.epsilon.modulus)" , abs_eps_max);

	cin >> abs_eps_min;
	word_check_print<double> ("(minimal.epsilon.modulus)" , abs_eps_min);

	cin >> abs_eps_step;
	word_check_print<double> ("(epsilon.modulus.step)" , abs_eps_step);

	cin >> arg_eps;
	word_check_print<double> ("(epsilon.argument.in.degrees)" , arg_eps);
	
	if ((abs_eps_step <= 0.0) || (abs_eps_step >= 1.0)) error_message_print_abort ("Epsilon step must be in ]0:1[");

	if ((abs_eps_max <= 0.0) || (abs_eps_min <= 0.0)) error_message_print_abort ("Epsilon values must be positive in 3x3.off.diagonal.identical");

	arg_eps *= M_PI/180.0;

	off_diagonal_identical_3x3 (b0_index , abs_eps_max , abs_eps_min , abs_eps_step , arg_eps);
      } 
    else
      error_message_print_abort ("Bad option");

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



