// The LST function f(r) is firstly calculated from the algebraic equation \int_0^r rho(r') dr' = \int_0^{f(r)} rho_HO(r') dr'
// rho_HO(r) and rho(r) come from a spherical HFB calculation using a HO basis for rho_HO(r), and using a PTG basis for rho(r) typically.
// One uses splines to solve the algebraic equation.
// However, one has to differentiate f(r) three times to obtain to u_THO(r), u_THO'(r) and u_THO''(r), and the multi-differentiation of splines is not precise.
// Hence, f(r) is fitted to the ansatz r*F(r) + sqrt (kappa*r)*(1.0 - F(r)), where F(r) is a Fermi function.
// The diffuseness has to be large, otherwise one has discontinuities in the density.

class THO_class
{
public:
  THO_class ();

  THO_class (
	     const double b_HO_c ,
	     const double R_max_rho_c ,
	     const string &file_name);

  THO_class (
	     const double b_HO_c , 
	     const class array<double> &r_tab ,
	     const class array<double> &rho_tab , 
	     const class array<double> &r_HO_tab ,
	     const class array<double> &rho_HO_tab);

  THO_class (const class THO_class &X);

  void initialize (
		   const double b_HO_c , 
		   const class array<double> &r_tab ,
		   const class array<double> &rho_tab , 
		   const class array<double> &r_HO_tab ,
		   const class array<double> &rho_HO_tab);

  void initialize (const class THO_class &X);
  
  void operator = (const class THO_class &X);

  double get_R_max_rho () const
  {
    return R_max_rho;
  }
  
  double get_b_HO () const
  {
    return b_HO;
  }

  double get_mu () const
  {
    return mu;
  }
  
  double get_kappa () const
  {
    return kappa;
  }
  
  double get_R () const
  {
    return R;
  }

  double f_calc (const double r) const;
  double df_calc (const double r) const;
  double d2f_calc (const double r) const;
  double d3f_calc (const double r) const;

  double u   (const int n , const int l , const double r) const;
  double du  (const int n , const int l , const double r) const;
  double d2u (const int n , const int l , const double r) const;

  void u_r_tables_calc (
			const int l ,
			const class array<double> &r_tab ,
			class array<double> &wfs) const;
  
  void u_r_tables_calc (
			const class array<double> &r_tab ,
			class array<double> &wfs) const;

  void u_du_r_tables_calc (
			   const int l ,
			   const class array<double> &r_tab ,
			   class array<double> &wfs ,
			   class array<double> &dwfs) const;

  void u_du_r_tables_calc (
			   const class array<double> &r_tab ,
			   class array<double> &wfs ,
			   class array<double> &dwfs) const;

  void u_du_d2u_r_tables_calc (
			       const int l , 
			       const class array<double> &r_tab , 
			       class array<double> &wfs , 
			       class array<double> &dwfs , 
			       class array<double> &d2wfs) const;

  void u_du_d2u_r_tables_calc (
			       const class array<double> &r_tab , 
			       class array<double> &wfs , 
			       class array<double> &dwfs , 
			       class array<double> &d2wfs) const;

private:
  
  double b_HO , R_max_rho , kappa , mu , R;
};

