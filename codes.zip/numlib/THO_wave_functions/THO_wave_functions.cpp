#include "../numlib_def/numlib_def.h"

// The LST function f(r) is firstly calculated from the algebraic equation \int_0^r rho(r') dr' = \int_0^{f(r)} rho_HO(r') dr'
// rho_HO(r) and rho(r) come from a spherical HFB calculation using a HO basis for rho_HO(r), and using a PTG basis for rho(r) typically.
// One uses splines to solve the integral equation above with the Newton method.
// One splines rho(r) and rho_HO(r) from r = Rmax and r = Rmax[HO], respectively, to r = 0.
// Then, integrals of rho(r) and rho[HO](r) increase from very small numbers to numbers close to 1.
// The first value of f(r) is determined by bisection, which is then refined with the Newton method.
// One must use a very fine mesh for radii in order to have sufficiently precise splines (~1000 radii for Rmax ~ 30 fm and Rmax[HO] ~ 50 fm).
// Hence, one can also assume that the mesh is sufficiently fine for each previous f(r) value found with r = r[bef] to be a good starting point for the Newton method to find f(r) with the current r.
// However, one has to differentiate f(r) three times to obtain to u_THO(r), u_THO'(r) and u_THO''(r), and the multi-differentiation of splines is not precise.
// Hence, f(r) is fitted to the ansatz r.F(r) + sqrt (10^(-5) + kappa.r).(1 - F(r)), where F(r) is a Fermi function of diffuseness mu and radius R.
// Indeed, one always has f(r) ~ r for small r (rho(r) ~ rho_HO(r) at short distances) and f(r) ~ sqrt (kappa.r) for large r (exponential decrease of rho(r) at large distances.
// The 10^(-5) shift is there to avoid divergence of derivative of f(r) for r -> 0.
// A global point-by-point fit of R, kappa and mu is used as it is unstable to fit otherwise.


using namespace string_routines;

THO_class::THO_class () :
  b_HO (0.0) ,
  R_max_rho (0.0) ,
  kappa (0.0) ,
  mu (0.0) ,
  R (0.0)
{}



THO_class::THO_class (
		      const double b_HO_c , 
		      const class array<double> &r_tab ,
		      const class array<double> &rho_tab , 
		      const class array<double> &r_HO_tab ,
		      const class array<double> &rho_HO_tab)
{
  initialize (b_HO_c , r_tab , rho_tab , r_HO_tab , rho_HO_tab);
}


void THO_class::initialize (
			    const double b_HO_c , 
			    const class array<double> &r_tab ,
			    const class array<double> &rho_tab , 
			    const class array<double> &r_HO_tab ,
			    const class array<double> &rho_HO_tab)
{
  b_HO = b_HO_c;
  
  R_max_rho = r_tab(r_tab.dimension (0) - 1);

  if (R_max_rho < 10.0) error_message_print_abort ("R_max_rho must be at least 10 fm in THO_class::initialize");

  const unsigned int N = r_tab.dimension (0);

  if (N <= 2) error_message_print_abort ("N must be at least 3 in THO_class::initialize");

  const unsigned int Nm1 = N - 1;
  const unsigned int Nm2 = N - 2;
  const unsigned int Nm3 = N - 3;

  const unsigned int N_HO = r_HO_tab.dimension (0);

  const unsigned int N_HO_m1 = N_HO - 1;

  const double R_max_rho_HO = r_HO_tab(N_HO_m1);

  if (N == N_HO)
    {
      bool equal_densities = true;
  
      for (unsigned int i = 0 ; i < N ; i++) equal_densities = equal_densities && (abs (rho_tab(i) - rho_HO_tab(i)) < precision);

      if (equal_densities)
	{
	  kappa = 0.0;
	  
	  mu = precision;
	  
	  R = R_max_rho;

	  return;
	}
    }
  
  class array<double> r_opp_tab(N);
  class array<double> r_square_rho_opp_tab(N);
      
  class array<double> r_opp_HO_tab(N_HO);
  class array<double> r_square_rho_HO_opp_tab(N_HO);
      
  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const unsigned int ii = Nm1 - i;

      const double r = r_tab(ii);
	  
      const double r_square = r*r;

      r_opp_tab(i) = R_max_rho - r;

      r_square_rho_opp_tab(i) = r_square*rho_tab(ii);
    }

  for (unsigned int i = 0 ; i < N_HO ; i++) 
    {
      const unsigned int ii = N_HO_m1 - i;
	  
      const double r = r_HO_tab(ii);

      const double r_square = r*r;

      r_opp_HO_tab(i) = R_max_rho_HO - r;

      r_square_rho_HO_opp_tab(i) = r_square*rho_HO_tab(ii);
    }

  class array<double> f_opp_tab(N);

  class array<double> f_tab(N);
      
  const class splines_class<double> r_square_rho_opp_splines(r_opp_tab , r_square_rho_opp_tab);

  const class splines_class<double> r_square_rho_HO_opp_splines(r_opp_HO_tab , r_square_rho_HO_opp_tab);

  const double r_square_rho_integral = r_square_rho_opp_splines.primitive (R_max_rho);
  
  const double r_square_rho_HO_integral = r_square_rho_HO_opp_splines.primitive (R_max_rho_HO);
  
  if (abs (r_square_rho_HO_integral - r_square_rho_integral) > 0.01) error_message_print_abort ("rho(r) and rho[HO](r) are not properly normalized in THO_class::initialize");    
      
  const double r1 = r_opp_tab(1);

  const double r_square_rho_primitive_r1 = r_square_rho_opp_splines.primitive (r1);
      
  double f_value_debut = 0.0;
  
  double f_value_end = R_max_rho_HO;

  double F_debut = r_square_rho_HO_opp_splines.primitive (f_value_debut) - r_square_rho_primitive_r1;
	  
  double f_value = 0.0;
  
  while (abs (1.0 - f_value_debut/f_value_end) > 0.01)
    {
      f_value = f_value_debut + 0.5*(f_value_end - f_value_debut);
      
      const double F = r_square_rho_HO_opp_splines.primitive (f_value) - r_square_rho_primitive_r1;
	  
      if (SIGN (F_debut) != SIGN (F))
	f_value_end = f_value;
      else
	{
	  f_value_debut = f_value;

	  F_debut = F;
	}
    }
      
  for (unsigned int i = 1 ; i < Nm1 ; i++)
    {
      const double r = r_opp_tab(i);

      const double r_square_rho_primitive_r = r_square_rho_opp_splines.primitive (r);
      
      unsigned int count = 0;

      double test = 1.0;      
	  
      while (test > precision)
	{
	  const double F = r_square_rho_HO_opp_splines.primitive (f_value) - r_square_rho_primitive_r;
	  
	  const double dF = r_square_rho_HO_opp_splines(f_value);
	  
	  const double F_over_dF = F/dF;
	      
	  f_value -= F_over_dF;

	  test = abs (F_over_dF);
	  
	  if (!finite (test)) error_message_print_abort ("Infinities encountered when solving the LST equation with the Newton method in THO_class::initialize");

	  if (count++ > 1000) error_message_print_abort ("Too many iterations to solve the LST equation with the Newton method in THO_class::initialize");
	}
	  
      f_opp_tab(i) = f_value;
    }
      
  f_opp_tab(0) = 2.0*f_opp_tab(1) - f_opp_tab(2);

  f_opp_tab(Nm1) = 2.0*f_opp_tab(Nm2) - f_opp_tab(Nm3);

  const double r0 = r_tab(0);
      
  const class splines_class<double> f_opp_splines(r_opp_tab , f_opp_tab);
      
  const double shift = f_opp_splines(R_max_rho - r0);

  for (unsigned int i = 0 ; i < N ; i++)
    {
      const double ri = r_tab(i);
	  
      f_tab(i) = shift - f_opp_splines(R_max_rho - ri);
    }

  const unsigned int N_try = 30;
  
  const double N_try_minus_one_double = N_try - 1;
  
  double mu_min = 5.0;
  double mu_max = 20.0;
  
  double kappa_min = 0.0;
  double kappa_max = 100.0;
  
  double R_min = 0.0;
  double R_max = 100.0;
  
  double cost_function_fit = INFINITE;
  
  for (unsigned int i_fit = 0 ; i_fit < 2 ; i_fit++)
    {  
      const double step_mu = (mu_max - mu_min)/N_try_minus_one_double;
      
      const double step_kappa = (kappa_max - kappa_min)/N_try_minus_one_double;
            
      const double step_R = (R_max - R_min)/N_try_minus_one_double;   
  
      for (unsigned int i_mu_try = 0 ; i_mu_try < N_try ; i_mu_try++)
	for (unsigned int iR_try = 0 ; iR_try < N_try ; iR_try++)
	  for (unsigned int i_kappa_try = 0 ; i_kappa_try < N_try ; i_kappa_try++)
	    {
	      const double mu_bef = mu;
	  
	      const double kappa_bef = kappa;
	    	      
	      const double R_bef = R;
      	    
	      const double mu_try = mu_min + i_mu_try*step_mu;
	  
	      const double kappa_try = kappa_min + i_kappa_try*step_kappa;
	    		
	      const double R_try = R_min + iR_try*step_R;		
		    
	      mu = mu_try;
	  
	      kappa = kappa_try;
	    	      
	      R = R_try;
      
	      double cost_function_try = 0.0;
	  
	      for (unsigned int i = 0 ; i < N ; i++)
		{
		  const double ri = r_tab(i);
	      
		  const double f_ri = f_tab(i);
	      
		  const double f_ri_try = f_calc (ri);
	  
		  cost_function_try += abs (f_ri - f_ri_try); 
		}
      
	      if (cost_function_try > cost_function_fit)
		{
		  mu = mu_bef;
	    
		  kappa = kappa_bef;
		    		
		  R = R_bef;		
		}
	      else
		cost_function_fit = cost_function_try;
	    }
      
      mu_min = mu - step_mu;
      mu_max = mu + step_mu;
      
      kappa_min = kappa - step_kappa;
      kappa_max = kappa + step_kappa;
      	  
      R_min = R - step_R;
      R_max = R + step_R;      
    }
}




void THO_class::initialize (const class THO_class &X)
{
  b_HO = X.b_HO;
  
  R_max_rho = X.R_max_rho;
  
  R = X.R;
    
  mu = X.mu;

  kappa = X.kappa;
}

void THO_class::operator = (const class THO_class &X)
{
  initialize (X);
}



double THO_class::f_calc (const double r) const
{  
  const double Fermi_r = Fermi_like_function (R , mu , r);
  
  const double sqrt_kappa_r_shifted = sqrt (sqrt_precision + kappa*r);
   
  const double fr = r*Fermi_r + sqrt_kappa_r_shifted*(1.0 - Fermi_r);
		
  return fr;
}



double THO_class::df_calc (const double r) const
{
  const double Fermi_r = Fermi_like_function (R , mu , r);
  
  const double Fermi_der_r = Fermi_like_function_der (R , mu , r);
  
  const double sqrt_kappa_r_shifted = sqrt (sqrt_precision + kappa*r);
  
  const double dfr = Fermi_r + (r - sqrt_kappa_r_shifted)*Fermi_der_r + 0.5*kappa/sqrt_kappa_r_shifted*(1.0 - Fermi_r);
    
  return dfr;
}



double THO_class::d2f_calc (const double r) const
{
  const double Fermi_r = Fermi_like_function (R , mu , r);
  
  const double Fermi_der_r = Fermi_like_function_der (R , mu , r);
  
  const double Fermi_2der_r = Fermi_like_function_2der (R , mu , r);
  
  const double sqrt_kappa_r_shifted = sqrt (sqrt_precision + kappa*r);
  
  const double d2fr = (r - sqrt_kappa_r_shifted)*Fermi_2der_r + (2.0 - kappa/sqrt_kappa_r_shifted)*Fermi_der_r - 0.25*kappa*(1.0 - Fermi_r)/(r*sqrt_kappa_r_shifted);
  
  return d2fr;
}



double THO_class::d3f_calc (const double r) const
{
  const double Fermi_r = Fermi_like_function (R , mu , r);
  
  const double Fermi_der_r = Fermi_like_function_der (R , mu , r);
  
  const double Fermi_2der_r = Fermi_like_function_2der (R , mu , r);
  
  const double Fermi_3der_r = Fermi_like_function_3der (R , mu , r);
  
  const double sqrt_kappa_r_shifted = sqrt (sqrt_precision + kappa*r);
    
  const double d3fr = (r - sqrt_kappa_r_shifted)*Fermi_3der_r + (3.0 - 1.5*kappa/sqrt_kappa_r_shifted)*Fermi_2der_r + 0.75*kappa*Fermi_der_r/(r*sqrt_kappa_r_shifted) + 0.375*kappa/(r*r*sqrt_kappa_r_shifted)*(1.0 - Fermi_r);
  
  return d3fr;
}





// Calculation of u(n , l) (THO).     
// ---------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// n , l : quantum numbers of the HO state.
// r : radius (fm)
// fr , dfr : local scaling function f(r) and first derivative.
// sqrt_dfr : sqrt (dfr)
// u_HO_scaled : HO wave function calculated in f(r)
// u_THO : returned value

double THO_class::u (const int n , const int l , const double r) const
{
  const double fr = f_calc (r);

  const double dfr = df_calc (r);

  const double sqrt_dfr = sqrt (dfr);

  const double u_HO_scaled = HO_wave_functions::HO_3D::u (b_HO , n , l , fr);

  const double u_THO = sqrt_dfr*u_HO_scaled;

  return u_THO;
}




// Calculation of du(n , l)/dr (THO). 
// -------------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// n , l : quantum numbers of the HO state.
// r : radius (fm).
// fr , dfr , d2fr : local scaling function f(r) and derivatives.
// sqrt_dfr : sqrt (dfr)
// u_HO_scaled , du_HO_scaled : HO wave function and first derivative calculated in f(r)
// du_THO : returned value

double THO_class::du (const int n , const int l , const double r) const   
{  
  const double fr = f_calc (r);

  const double dfr = df_calc (r);

  const double d2fr = d2f_calc (r);
  
  const double sqrt_dfr = sqrt (dfr);
  
  const double  u_HO_scaled = HO_wave_functions::HO_3D::u  (b_HO , n , l , fr);
  const double du_HO_scaled = HO_wave_functions::HO_3D::du (b_HO , n , l , fr);

  const double du_THO = 0.5*d2fr*u_HO_scaled/sqrt_dfr + dfr*sqrt_dfr*du_HO_scaled;

  return du_THO;
}      




// Calculation of d2u(n , l)/d2r (THO). 
// ---------------------------------
// 
// Variables:
// ----------
// b : parameter of the HO potential (fm).
// n , l : quantum numbers of the HO state.
// r : radius (fm).
// fr , dfr , d2fr , d3fr : local scaling function f(r) and derivatives.
// sqrt_dfr : sqrt (dfr)
// u_HO_scaled , du_HO_scaled , d2u_HO_scaled : HO wave function ,  first and second derivative calculated in f(r)
// d2u_THO : returned value

double THO_class::d2u (const int n , const int l , const double r) const
{  
  const double fr = f_calc (r);

  const double dfr = df_calc (r);

  const double d2fr = d2f_calc (r);
  
  const double d3fr = d3f_calc (r);
  
  const double sqrt_dfr = sqrt (dfr);
  
  const double   u_HO_scaled = HO_wave_functions::HO_3D::u   (b_HO , n , l , fr);
  const double  du_HO_scaled = HO_wave_functions::HO_3D::du  (b_HO , n , l , fr);
  const double d2u_HO_scaled = HO_wave_functions::HO_3D::d2u (b_HO , n , l , fr);

  const double d2u_THO = (0.5*d3fr - 0.25*d2fr*d2fr/dfr)*u_HO_scaled/sqrt_dfr + 2.0*d2fr*sqrt_dfr*du_HO_scaled + dfr*dfr*sqrt_dfr*d2u_HO_scaled;

  return d2u_THO;
}












// Calculation of a table of u(n , l)(r) (THO) for all n from 0 until n_max and a table of r values
// ------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs : tables of THO functions

void THO_class::u_r_tables_calc (const int l , const class array<double> &r_tab , class array<double> &THO_wfs) const
{ 
  const int nmax_THO = THO_wfs.dimension(0) - 1;
  
  const unsigned int N = THO_wfs.dimension(1);

  class array<double> fr_table(N);

  for (unsigned int i = 0 ; i < N ; i++) fr_table(i) = f_calc (r_tab(i));

  HO_wave_functions::HO_3D::u_r_tables_calc (b_HO , l , fr_table , THO_wfs);

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double r = r_tab(i);

      const double dfr = df_calc (r);

      const double sqrt_dfr = sqrt (dfr);
      
      for (int n = 0 ; n <= nmax_THO ; n++) THO_wfs(n , i) *= sqrt_dfr;
    }
}






// Calculation of a table of u(n , l)(r) (THO) for all n from 0 until n_max and a table of r and l values
// ------------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// lmax_THO: maximal orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs : tables of THO functions

void THO_class::u_r_tables_calc (const class array<double> &r_tab , class array<double> &THO_wfs) const
{
  const int nmax_THO = THO_wfs.dimension(0) - 1;
  
  const int nmax_THO_plus_one = nmax_THO + 1;

  const int lmax_THO =  THO_wfs.dimension(1) - 1;

  const unsigned int N = THO_wfs.dimension(2);

  class array<double> THO_wfs_one_l(nmax_THO_plus_one , N);

  for (int l = 0 ; l <= lmax_THO ; l++)
    {
      u_r_tables_calc (l , r_tab , THO_wfs_one_l);

      for (int n = 0 ; n <= nmax_THO ; n++)
	for (unsigned int i = 0 ; i < N ; i++) 
	  THO_wfs(n , l , i) = THO_wfs_one_l(n , i);
    }
}






// Calculation of a table of u(n , l)(r) and u'(n , l)(r) (THO) for all n from 0 until n_max and a table of r values
// -----------------------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs , THO_dwfs : tables of THO functions and first derivatives

void THO_class::u_du_r_tables_calc (
				    const int l , 
				    const class array<double> &r_tab , 
				    class array<double> &THO_wfs , 
				    class array<double> &THO_dwfs) const
{
  const int nmax_THO = THO_wfs.dimension(0) - 1;
  
  const unsigned int N = THO_wfs.dimension(1);

  class array<double> fr_table(N);

  for (unsigned int i = 0 ; i < N ; i++) fr_table(i) = f_calc (r_tab(i));

  HO_wave_functions::HO_3D::u_du_r_tables_calc (b_HO , l , fr_table , THO_wfs , THO_dwfs);

  for (unsigned int i = 0 ; i < N ; i++) 
    { 
      const double r = r_tab(i);

      const double dfr = df_calc (r);

      const double d2fr = d2f_calc (r);

      const double sqrt_dfr = sqrt (dfr);

      for (int n = 0 ; n <= nmax_THO ; n++)
	{
	  THO_dwfs(n , i) = 0.5*d2fr*THO_wfs(n , i)/sqrt_dfr + dfr*sqrt_dfr*THO_dwfs(n , i);

	  THO_wfs(n , i) *= sqrt_dfr;
	}
    }
}


// Calculation of a table of u(n , l)(r) and u'(n , l)(r) (THO) for all n from 0 until n_max and a table of r and l values
// -----------------------------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs , THO_dwfs : tables of THO functions and first derivatives

void THO_class::u_du_r_tables_calc (
				    const class array<double> &r_tab , 
				    class array<double> &THO_wfs , 
				    class array<double> &THO_dwfs) const
{
  const int nmax_THO = THO_wfs.dimension(0) - 1;

  const int nmax_THO_plus_one = nmax_THO + 1;
  
  const int lmax_THO =  THO_wfs.dimension(1) - 1;

  const unsigned int N = THO_wfs.dimension(2);

  class array<double> THO_wfs_one_l(nmax_THO_plus_one , N);

  class array<double> THO_dwfs_one_l(nmax_THO_plus_one , N);

  for (int l = 0 ; l <= lmax_THO ; l++)
    {
      u_du_r_tables_calc (l , r_tab , THO_wfs_one_l , THO_dwfs_one_l);

      for (int n = 0 ; n <= nmax_THO ; n++)
	for (unsigned int i = 0 ; i < N ; i++) 
	  {
	    THO_wfs(n , l , i) = THO_wfs_one_l(n , i);

	    THO_dwfs(n , l , i) = THO_dwfs_one_l(n , i);
	  }
    }
}








// Calculation of a table of u(n , l)(r) ,  u'(n , l)(r) and u''(n , l)(r) (THO) for all n from 0 until n_max and a table of r values
// ----------------------------------------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs , THO_dwfs , THO_d2wfs : tables of THO functions ,  first and second derivatives

void THO_class::u_du_d2u_r_tables_calc (
					const int l , 
					const class array<double> &r_tab , 
					class array<double> &THO_wfs , 
					class array<double> &THO_dwfs , 
					class array<double> &THO_d2wfs) const
{
  const int nmax_THO = THO_wfs.dimension(0) - 1;
  
  const unsigned int N = THO_wfs.dimension(1);

  class array<double> fr_table(N);

  for (unsigned int i = 0 ; i < N ; i++) fr_table(i) = f_calc (r_tab(i));

  HO_wave_functions::HO_3D::u_du_d2u_r_tables_calc (b_HO , l , fr_table , THO_wfs , THO_dwfs , THO_d2wfs);

  for (unsigned int i = 0 ; i < N ; i++) 
    { 
      const double r = r_tab(i);

      const double dfr = df_calc (r);

      const double d2fr = d2f_calc (r);
      
      const double d3fr = d3f_calc (r);

      const double sqrt_dfr = sqrt (dfr);
      
      for (int n = 0 ; n <= nmax_THO ; n++) 
	{
	  THO_d2wfs(n , i) = (0.5*d3fr - 0.25*d2fr*d2fr/dfr)*THO_wfs(n , i)/sqrt_dfr + 2.0*d2fr*sqrt_dfr*THO_dwfs(n , i) + dfr*dfr*sqrt_dfr*THO_d2wfs(n , i);

	  THO_dwfs(n , i) = 0.5*d2fr*THO_wfs(n , i)/sqrt_dfr + dfr*sqrt_dfr*THO_dwfs(n , i);

	  THO_wfs(n , i) *= sqrt_dfr;
	}
    }
}




// Calculation of a table of u(n , l)(r) ,  u'(n , l)(r) and u''(n , l)(r) (THO) for all n from 0 until n_max and a table of r and l values
// ----------------------------------------------------------------------------------------------------------------------------------------
// Variables:
// ----------
// l: orbital momentum
// r_tab : table of r values
// fr_table : table of scaling function f(r) values
// THO_wfs , THO_dwfs , THO_d2wfs : tables of THO functions ,  first and second derivatives

void THO_class::u_du_d2u_r_tables_calc (
					const class array<double> &r_tab , 
					class array<double> &THO_wfs , 
					class array<double> &THO_dwfs , 
					class array<double> &THO_d2wfs) const
{
  const int nmax_THO = THO_wfs.dimension(0) - 1;
  
  const int nmax_THO_plus_one = nmax_THO + 1;

  const int lmax_THO =  THO_wfs.dimension(1) - 1;

  const unsigned int N = THO_wfs.dimension(2);

  class array<double> THO_wfs_one_l(nmax_THO_plus_one , N);

  class array<double> THO_dwfs_one_l(nmax_THO_plus_one , N);
  
  class array<double> THO_d2wfs_one_l(nmax_THO_plus_one , N);
  
  for (int l = 0 ; l <= lmax_THO ; l++)
    {
      u_du_d2u_r_tables_calc (l , r_tab , THO_wfs_one_l , THO_dwfs_one_l , THO_d2wfs_one_l);

      for (int n = 0 ; n <= nmax_THO ; n++)
	for (unsigned int i = 0 ; i < N ; i++)
	  {
	    THO_wfs(n , l , i) = THO_wfs_one_l(n , i);

	    THO_dwfs(n , l , i) = THO_dwfs_one_l(n , i);

	    THO_d2wfs(n , l , i) = THO_d2wfs_one_l(n , i);
	  }
    }
}


