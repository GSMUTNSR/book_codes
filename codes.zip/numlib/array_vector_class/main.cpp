#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

void array_test ()
{
  const int N = 5;
  
  const int N0 = 3;
  const int N1 = 2;
  const int N2 = 3;
  const int N3 = 2;
  const int N4 = 2;
  const int N5 = 3;
  const int N6 = 2;
  const int N7 = 2;
  const int N8 = 3;

  class array<int> T0(N0);
  class array<int> T1(N0 , N1);
  class array<int> T2(N0 , N1 , N2);
  class array<int> T3(N0 , N1 , N2 , N3);
  class array<int> T4(N0 , N1 , N2 , N3 , N4);
  class array<int> T5(N0 , N1 , N2 , N3 , N4 , N5);
  class array<int> T6(N0 , N1 , N2 , N3 , N4 , N5 , N6);
  class array<int> T7(N0 , N1 , N2 , N3 , N4 , N5 , N6 , N7);
  class array<int> T8(N0 , N1 , N2 , N3 , N4 , N5 , N6 , N7 , N8);

  T0 = 1;

  if (!T0.isfinite ()) error_message_print_abort ("Problem in array with isfinite");

  class array<complex<double> > X(N);

  X = complex<double> (4.7 , 3.8);

  if (X.is_it_real ()) error_message_print_abort ("Problem in array with is_it_real");
  
  class array<complex<double> > V(N);

  V = complex<double> (4.7 , 3.98);
  
  class array<double> Re_V(N);
  class array<double> Im_V(N);

  Re_V = real<double , complex<double> > (V);
  Im_V = imag<double , complex<double> > (V);

  class array<complex<double> > V_test = complex_array<double , complex<double> > (Re_V , Im_V);

  X = V - V_test;

  if (X.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class array with real , imag or complex_array");

  if (!Re_V.is_it_real ()) error_message_print_abort ("Problem in class array with is_it_real");

  class array<unsigned int> Z(N);

  Z = 0.0;

  Z(0) = 1;

  Re_V = convert<unsigned int , double> (Z);

  Re_V(0) -= 1.0;

  if (Re_V.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class array with convert");
  
  for (unsigned int i = 0 ; i < T0.dimension_total () ; i++) T0[i] = rand ();
  for (unsigned int i = 0 ; i < T1.dimension_total () ; i++) T1[i] = rand ();
  for (unsigned int i = 0 ; i < T2.dimension_total () ; i++) T2[i] = rand ();
  for (unsigned int i = 0 ; i < T3.dimension_total () ; i++) T3[i] = rand ();
  for (unsigned int i = 0 ; i < T4.dimension_total () ; i++) T4[i] = rand ();
  for (unsigned int i = 0 ; i < T5.dimension_total () ; i++) T5[i] = rand ();
  for (unsigned int i = 0 ; i < T6.dimension_total () ; i++) T6[i] = rand ();
  for (unsigned int i = 0 ; i < T7.dimension_total () ; i++) T7[i] = rand ();
  for (unsigned int i = 0 ; i < T8.dimension_total () ; i++) T8[i] = rand ();
  
  for (unsigned int i0 = 0 ; i0 < T0.dimension (0) ; i0++)
    {
      if (T0(i0) != T0[T0.index_determine(i0)])
	error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 1)");
    }

  for (unsigned int i0 = 0 ; i0 < T1.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T1.dimension (1) ; i1++)
      {
	if (T1(i0 , i1) != T1[T1.index_determine(i0 , i1)])
	  error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 2)");
      }

  for (unsigned int i0 = 0 ; i0 < T2.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T2.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T2.dimension (2) ; i2++)
	{
	  if (T2(i0 , i1 , i2) != T2[T2.index_determine(i0 , i1 , i2)])
	    error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 3)");
	}

  for (unsigned int i0 = 0 ; i0 < T3.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T3.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T3.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T3.dimension (3) ; i3++)
	  {
	    if (T3(i0 , i1 , i2 , i3) != T3[T3.index_determine(i0 , i1 , i2 , i3)])
	      error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 4)");
	  }

  for (unsigned int i0 = 0 ; i0 < T4.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T4.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T4.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T4.dimension (3) ; i3++)
	  for (unsigned int i4 = 0 ; i4 < T4.dimension (4) ; i4++)
	    {
	      if (T4(i0 , i1 , i2 , i3 , i4) != T4[T4.index_determine(i0 , i1 , i2 , i3 , i4)])
		error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 5)");
	    }

  for (unsigned int i0 = 0 ; i0 < T5.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T5.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T5.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T5.dimension (3) ; i3++)
	  for (unsigned int i4 = 0 ; i4 < T5.dimension (4) ; i4++)
	    for (unsigned int i5 = 0 ; i5 < T5.dimension (5) ; i5++)
	      {
		if (T5(i0 , i1 , i2 , i3 , i4 , i5) != T5[T5.index_determine(i0 , i1 , i2 , i3 , i4 , i5)])
		  error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 6)");
	      }

  for (unsigned int i0 = 0 ; i0 < T6.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T6.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T6.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T6.dimension (3) ; i3++)
	  for (unsigned int i4 = 0 ; i4 < T6.dimension (4) ; i4++)
	    for (unsigned int i5 = 0 ; i5 < T6.dimension (5) ; i5++)
	      for (unsigned int i6 = 0 ; i6 < T6.dimension (6) ; i6++)
		{
		  if (T6(i0 , i1 , i2 , i3 , i4 , i5 , i6) != T6[T6.index_determine(i0 , i1 , i2 , i3 , i4 , i5 , i6)])
		    error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 7)");
		}

  for (unsigned int i0 = 0 ; i0 < T7.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T7.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T7.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T7.dimension (3) ; i3++)
	  for (unsigned int i4 = 0 ; i4 < T7.dimension (4) ; i4++)
	    for (unsigned int i5 = 0 ; i5 < T7.dimension (5) ; i5++)
	      for (unsigned int i6 = 0 ; i6 < T7.dimension (6) ; i6++)
		for (unsigned int i7 = 0 ; i7 < T7.dimension (7) ; i7++)
		  {
		    if (T7(i0 , i1 , i2 , i3 , i4 , i5 , i6 , i7) != T7[T7.index_determine(i0 , i1 , i2 , i3 , i4 , i5 , i6 , i7)])
		      error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 8)");
		  }

  for (unsigned int i0 = 0 ; i0 < T8.dimension (0) ; i0++)
    for (unsigned int i1 = 0 ; i1 < T8.dimension (1) ; i1++)
      for (unsigned int i2 = 0 ; i2 < T8.dimension (2) ; i2++)
	for (unsigned int i3 = 0 ; i3 < T8.dimension (3) ; i3++)
	  for (unsigned int i4 = 0 ; i4 < T8.dimension (4) ; i4++)
	    for (unsigned int i5 = 0 ; i5 < T8.dimension (5) ; i5++)
	      for (unsigned int i6 = 0 ; i6 < T8.dimension (6) ; i6++)
		for (unsigned int i7 = 0 ; i7 < T8.dimension (7) ; i7++)
		  for (unsigned int i8 = 0 ; i8 < T8.dimension (8) ; i8++)
		    {
		      if (T8(i0 , i1 , i2 , i3 , i4 , i5 , i6 , i7 , i8) != T8[T8.index_determine(i0 , i1 , i2 , i3 , i4 , i5 , i6 , i7 , i8)])
			error_message_print_abort ("Problem in array with dimension_total , dimension , index_determine or operator () (dimension 9)");
		    }

  class array<int> T(N);
  
  for (int i = 0 ; i < N ; i++) T[i] = (i+2)%N;

  class array<int> T_test = T;

  if (T_test != T) error_message_print_abort ("Problem in array with constructor operator or !=");

  T_test = T;
  
  if (T_test != T) error_message_print_abort ("Problem in array with operator=");

  {
    class array<class array<int> > A(1);

    A(0).allocate (2);
    
    A.deallocate_object_elements (); 
  }

  T_test += T;
  T_test -= T;
  
  T_test += 3;
  T_test -= 3;

  T_test *= 2;
  T_test /= 2;

  if (T_test != T) error_message_print_abort ("Problem in array with operators += , -= , *= or /=");

  T.quick_sort (0 , N-1);

  for (int i = 0 ; i < N ; i++)
    {
      if (T[i] != i) error_message_print_abort ("Problem in array with quicksort");
    }
  
  if (T.max () != N-1) error_message_print_abort ("Problem in array with max");
  if (T.min () != 0  ) error_message_print_abort ("Problem in array with min");

#ifdef UseMPI

  if (NUMBER_OF_PROCESSES == 1) error_message_print_abort ("MPI tests with at least two processes.");

  const unsigned int first_index = T.first_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);
  
  const unsigned int last_index = T.last_index_determine_for_MPI (NUMBER_OF_PROCESSES , THIS_PROCESS);

  const unsigned int process_a = 0 , process_b = 1;	

  for (int i = 0 ; i < N ; i++) T_test(i) = i*i;

  T = 0;

  if (THIS_PROCESS == process_a) T = T_test;

  if (THIS_PROCESS == process_a) T.MPI_Send (process_b , 1 , MPI_COMM_WORLD);
  if (THIS_PROCESS == process_b) T.MPI_Recv (process_a , 1 , MPI_COMM_WORLD);

  if ((THIS_PROCESS == process_b) && (T != T_test)) error_message_print_abort ("Problem in array with MPI_Send/MPI_Recv");

  T = 0;

  if (THIS_PROCESS == MASTER_PROCESS) T = T_test;

  T.MPI_Bcast (MASTER_PROCESS , MPI_COMM_WORLD);

  if (T != T_test) error_message_print_abort ("Problem in array with MPI_Bcast");

  T = 0;

  for (unsigned int i = first_index ; i <= last_index ; i++) T(i) = T_test(i);

  T.MPI_Allgatherv (NUMBER_OF_PROCESSES , MPI_COMM_WORLD);

  if (T != T_test) error_message_print_abort ("Problem in array with MPI_Allgatherv");

  T = 0;

  for (unsigned int i = first_index ; i <= last_index ; i++) T(i) = T_test(i);

  T.MPI_Reduce (MPI_SUM , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  if ((THIS_PROCESS == MASTER_PROCESS) && (T != T_test)) error_message_print_abort ("Problem in array with MPI_Reduce (sum)");

  T_test = NUMBER_OF_PROCESSES-1;

  T = THIS_PROCESS;

  T.MPI_Reduce (MPI_MAX , MASTER_PROCESS , THIS_PROCESS , MPI_COMM_WORLD);

  if ((THIS_PROCESS == MASTER_PROCESS) && (T != T_test)) error_message_print_abort ("Problem in array with MPI_Reduce (max)");

  T_test = NUMBER_OF_PROCESSES-1;

  T = THIS_PROCESS;

  T.MPI_Allreduce (MPI_MAX , MPI_COMM_WORLD);

  if (T != T_test) error_message_print_abort ("Problem in array with MPI_Reduce (max)");

#endif

  if (THIS_PROCESS == MASTER_PROCESS) cout << "All array tests are successful." << endl;
}






void vector_class_test ()
{
  const unsigned int N = 17;

  class vector_class<complex<double> > V(N);

  V.random_vector ();

  V *= complex<double> (4 , 6);

  if (!V.isfinite ()) error_message_print_abort ("Problem in class vector_class with isfinite");
  
  const complex<double> a(4.7 ,  3.8);
  const complex<double> b(7.8 , -3.9);
  const complex<double> c(2.4 , -1.2);

  const double e = 7.8;

  class vector_class<complex<double> > X = b*V;
  class vector_class<complex<double> > Y = X;

  if (!(X == Y)) error_message_print_abort ("Problem in class vector_class with ==");

  if (X != Y) error_message_print_abort ("Problem in class vector_class with !");

  if (X.is_it_real ()) error_message_print_abort ("Problem in class vector_class with is_it_real");

  if (sqrt (X*X) != X.dot_product_norm ()) error_message_print_abort ("Problem in class vector_class with dot_product_norm");
  
  if (sqrt (conj (X)*X) != X.hermitian_product_norm ()) error_message_print_abort ("Problem in class vector_class with hermitian_product_norm");

  X += a*V;
  X -= a*V;
  
  X *= b;
  X /= b;

  X += c;
  X -= c;

  X -= b*V;

  if (X.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with = , += , -= , *= or /=");

  X = b*V;

  X = c + X;
  X = c - X;

  X = X + a*V;
  X = X - a*V;

  X = X*b;
  X = X/b;

  X = X + c;
  X = X - c;

  X = X + b*V;

  if (X.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with = , + , - , * or /");

  X = V + Y;

  X *= b;
  X /= b;

  X += e;
  X -= e;

  X = X - V - Y;

  if (X.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with = , += , -= , *= or /=");

  Y = -X;

  V = Y + X;

  if (V.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with unary -");

  V.random_vector ();

  V *= a;

  X = V;

  X.conjugate ();

  Y = conj (X) - V;

  if (Y.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with conjugate"); 

  class vector_class<double> Re_V(N);
  class vector_class<double> Im_V(N);

  Re_V = real<double , complex<double> > (V);
  Im_V = imag<double , complex<double> > (V);

  class vector_class<complex<double> > V_test = complex_vector<double , complex<double> > (Re_V , Im_V);

  X = V - V_test;	

  if (X.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with real , imag or complex_vector_class");

  if (!Re_V.is_it_real ()) error_message_print_abort ("Problem in class vector_class with is_it_real");

  class vector_class<unsigned int> Z(N);

  Z = 0.0;

  Z(0) = 1;

  Re_V = convert<unsigned int , double> (Z);

  Re_V(0) -= 1.0;

  if (Re_V.infinite_norm () > 1E-13) error_message_print_abort ("Problem in class vector_class with convert"); 

  if (THIS_PROCESS == MASTER_PROCESS) cout << "All vector_class class tests are correct." << endl;
}


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    array_test ();
    
    vector_class_test ();
  }



