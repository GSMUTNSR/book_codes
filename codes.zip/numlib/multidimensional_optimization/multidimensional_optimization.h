#ifndef MULTIDIMENSIONAL_OPTIMIZATION_H
#define MULTIDIMENSIONAL_OPTIMIZATION_H

namespace multidimensional_optimization
{
  // cost functions
  // --------------

  double cost_function_calc (
			     const void *const ptr ,
			     double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
			     const class array<double> &weights ,
			     const class vector_class<double> &parameters);

  class vector_class<double> cost_function_grad_calc (
						      const void *const ptr ,
						      double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
						      class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
						      const class array<double> &weights ,
						      const class vector_class<double> &parameters);

  // Newton method
  // -------------

  namespace Newton_method
  {
    // Jacobian matrix
    // ---------------

    class matrix<double> G_calc (
				 const void *const ptr ,
				 class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
				 const unsigned int N_conditions , 
				 const unsigned int N_parameters , 
				 const class array<double> &weights ,
				 const class vector_class<double> &parameters);

    // Scaled Jacobian matrix
    // ----------------------

    class matrix<double> scaled_G_calc (
					const class matrix<double> &G ,
					const class vector_class<double> &parameters);

    // Scaled vector of differences (the dx in x + dx) in the Newton method
    // --------------------------------------------------------------------

    class vector_class<double> delta_parameters_scaled_calc (
							     const double SVD_precision , 
							     const class vector_class<double> &parameters , 
							     const class vector_class<double> &f_tab , 
							     const class matrix<double> &G);

    // Unscale the vector of differences (the dx in x + dx) in the Newton method
    // -------------------------------------------------------------------------

    class vector_class<double> delta_parameters_unscale (
							 const class vector_class<double> &parameters , 
							 const class vector_class<double> &delta_parameters_scaled);

    // Newton iterative method
    // -----------------------

    void calc_print (
		     const void *const ptr ,
		     double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
		     class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
		     const double SVD_precision , 
		     const double precision_Newton , 
		     const class array<double> &weights ,
		     class vector_class<double> &parameters);
  }

  namespace Nelder_Mead
  {
    void parameters_tab_sort (
			      const int low , 
			      const int high , 
			      class array<double> &cost_function_tab , 
			      class array<class vector_class<double> > &Nelder_Mead_parameters_tab);

    class vector_class<double> parameters_centroid_calc (const class array<class vector_class<double> > &Nelder_Mead_parameters_tab);

    void parameters_calc_print (
				const void *const ptr ,
				double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
				class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
				const double relative_step , 
				const double precision_Nelder_Mead ,
				const class array<double> &weights ,
				class vector_class<double> &parameters);
  }

  namespace conjugate_gradient
  {
    void linear_minimization_parameters_calc (
					      const void *const ptr ,
					      double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
					      class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
					      const class array<double> &weights ,
					      const class vector_class<double> &parameters_dir , 
					      class vector_class<double> &parameters , 
					      class vector_class<double> &cost_function_grad , 
					      double &grad_scalar_dir);

    void parameters_calc_print (
				const void *const ptr ,
				double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
				class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
				const double precision_conjugate_gradient , 
				const class array<double> &weights ,
				class vector_class<double> &parameters_dir , 
				class vector_class<double> &parameters);
  }
}

#endif
