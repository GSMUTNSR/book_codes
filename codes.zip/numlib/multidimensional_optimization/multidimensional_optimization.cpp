#include "../../numlib/numlib_def/numlib_def.h"

//==============================================================================
// Functions for optimization



// cost functions
// --------------

double multidimensional_optimization::cost_function_calc (
							  const void *const ptr ,
							  double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
							  const class array<double> &weights ,
							  const class vector_class<double> &parameters)
{
  const unsigned int N_conditions = weights.dimension (0);

  double cost_function = 0.0;

  for (unsigned int i = 0 ; i < N_conditions ; i++)
    {
      const double component = generic_component_calc (ptr , i , weights , parameters);

      cost_function += component*component;
    }

  cost_function /= N_conditions;

  return cost_function;
}

class vector_class<double> multidimensional_optimization::cost_function_grad_calc (
										   const void *const ptr ,
										   double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
										   class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
										   const class array<double> &weights ,
										   const class vector_class<double> &parameters)
{
  const unsigned int N_conditions = weights.dimension (0) , N_parameters = parameters.get_dimension ();

  class vector_class<double> cost_function_grad(N_parameters);
  cost_function_grad = 0.0;

  for (unsigned int i = 0 ; i < N_conditions ; i++)
    {
      const double component = generic_component_calc (ptr , i , weights , parameters);
      
      const double two_component = 2.0*component;
      
      const class vector_class<double> component_grad = generic_component_grad_calc (ptr , i , weights , parameters);

      cost_function_grad += two_component*component_grad;
    }

  cost_function_grad /= N_conditions;

  return cost_function_grad;
}



// Newton method
// -------------

// Jacobian matrix
// ---------------

class matrix<double> multidimensional_optimization::Newton_method::G_calc (
									   const void *const ptr ,
									   class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
									   const unsigned int N_conditions , 
									   const unsigned int N_parameters , 
									   const class array<double> &weights ,
									   const class vector_class<double> &parameters)
{
  class matrix<double> G(N_conditions , N_parameters);

  G = 0.0;

  for (unsigned int i = 0 ; i < N_conditions ; i++)
    G.row_vector (i) = generic_component_grad_calc (ptr , i , weights , parameters);

  return G;
}




// Scaled Jacobian matrix
// ----------------------

class matrix<double> multidimensional_optimization::Newton_method::scaled_G_calc (
										  const class matrix<double> &G ,
										  const class vector_class<double> &parameters)
{
  const unsigned int N_conditions = G.get_dimension_row ();
  
  const unsigned int N_parameters = G.get_dimension_column ();

  class matrix<double> scaled_G = G ;

  for(unsigned int j = 0 ; j < N_parameters ; j++) 
    {
      const double parameter = parameters(j);

      if (parameter != 0.0) 
	{
	  for(unsigned int i = 0 ; i < N_conditions ; i++) scaled_G(i , j) *= parameter;
	}
    }

  return scaled_G;
}




// Scaled vector of differences (the dx in x + dx) in the Newton method
// --------------------------------------------------------------------

class vector_class<double> multidimensional_optimization::Newton_method::delta_parameters_scaled_calc (
												       const double SVD_precision , 
												       const class vector_class<double> &parameters , 
												       const class vector_class<double> &f_tab , 
												       const class matrix<double> &G)
{
  const unsigned int N_states_to_fit = G.get_dimension_row ();

  const unsigned int N_parameters = G.get_dimension_column ();

  const class matrix<double> scaled_G = scaled_G_calc (G , parameters);

  const class matrix<double> scaled_G_transpose = transpose (scaled_G);

  if (N_states_to_fit < N_parameters)
    {	
      class matrix<double> scaled_G_tG = scaled_G*scaled_G_transpose;

      scaled_G_tG.symmetrize ();

      class vector_class<double> scaled_G_tG_inv_f_tab(N_states_to_fit);
	
      linear_system_SVD_solution_calc (scaled_G_tG ,  f_tab ,  SVD_precision , scaled_G_tG_inv_f_tab);

      const class vector_class<double> delta_parameters_scaled = scaled_G_transpose*scaled_G_tG_inv_f_tab;

      return delta_parameters_scaled;
    }
  else
    {	
      class matrix<double> scaled_tG_G = scaled_G_transpose*scaled_G;

      scaled_tG_G.symmetrize ();
      
      const class vector_class<double> scaled_tG_f_tab = scaled_G_transpose*f_tab;

      class vector_class<double> delta_parameters_scaled(N_parameters);
      
      linear_system_SVD_solution_calc (scaled_tG_G ,  scaled_tG_f_tab , SVD_precision , delta_parameters_scaled);

      return delta_parameters_scaled;
    }
}



// Unscale the vector of differences (the dx in x + dx) in the Newton method
// -------------------------------------------------------------------------

class vector_class<double> multidimensional_optimization::Newton_method::delta_parameters_unscale (
												   const class vector_class<double> &parameters , 
												   const class vector_class<double> &delta_parameters_scaled)
{
  const unsigned int N_parameters = parameters.get_dimension ();

  class vector_class<double> delta_parameters = delta_parameters_scaled;

  for(unsigned int j = 0; j < N_parameters ; j++) 
    {
      const double parameter = parameters(j);

      if (parameter != 0.0) delta_parameters(j) *= parameter;
    }

  return delta_parameters;
}



// Newton iterative method
// -----------------------

void multidimensional_optimization::Newton_method::calc_print (
							       const void *const ptr ,
							       double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
							       class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
							       const double SVD_precision , 
							       const double precision_Newton , 
							       const class array<double> &weights ,
							       class vector_class<double> &parameters)
{
  const unsigned int N_conditions = weights.dimension (0);
  
  const unsigned int N_parameters = parameters.get_dimension ();

  class vector_class<double> f_tab(N_conditions);
  
  class vector_class<double> delta_parameters(N_parameters);

  unsigned int iter = 0;
  
  double test = 1.0;

  while ((test > precision_Newton) && (iter++ < 100))
    {
      for (unsigned int i = 0 ; i < N_conditions  ; i++) f_tab(i) = generic_component_calc (ptr , i , weights , parameters);

      const class matrix<double> G = G_calc (ptr , generic_component_grad_calc , N_conditions , N_parameters , weights , parameters);

      const class vector_class<double> delta_parameters_scaled = delta_parameters_scaled_calc (SVD_precision , parameters , f_tab , G);

      const class vector_class<double> delta_parameters = delta_parameters_unscale (parameters , delta_parameters_scaled);

      parameters -= delta_parameters;

      test = min (delta_parameters.infinite_norm () , f_tab.infinite_norm ());

      if (THIS_PROCESS == MASTER_PROCESS)
	cout << "Newton iteration : " << iter << " ||f.values|| : " << f_tab.infinite_norm () << " ||delta.parameters||oo : " << delta_parameters.infinite_norm () << endl;
    }

  const double chi = sqrt (cost_function_calc (ptr , generic_component_calc , weights , parameters));

  const class vector_class<double> cost_function_grad = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters);

  const double cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

  if (THIS_PROCESS == MASTER_PROCESS)
    cout << endl << "chi : " << chi << " ||grad (chi^2)|| : " << cost_grad_norm << endl;
}



void multidimensional_optimization::Nelder_Mead::parameters_tab_sort (
								      const int low , 
								      const int high , 
								      class array<double> &cost_function_tab , 
								      class array<class vector_class<double> > &parameters_tab)
{
  const int pivot_index = low + (high - low)/2;

  const double cost_function_pivot = cost_function_tab(pivot_index);

  int i_sort = low;
  int j_sort = high;

  do
    {
      while (cost_function_tab(i_sort) < cost_function_pivot) i_sort++;
      while (cost_function_tab(j_sort) > cost_function_pivot) j_sort--;

      if (i_sort <= j_sort)
	{
	  swap (cost_function_tab(i_sort) , cost_function_tab(j_sort));

	  swap (parameters_tab(i_sort) , parameters_tab(j_sort));

	  i_sort++;
	  j_sort--;
	}
    }
  while (i_sort <= j_sort);

  if (low < j_sort) parameters_tab_sort (low , j_sort , cost_function_tab , parameters_tab);

  if (i_sort < high) parameters_tab_sort (i_sort , high , cost_function_tab , parameters_tab); 
}



class vector_class<double> multidimensional_optimization::Nelder_Mead::parameters_centroid_calc (const class array<class vector_class<double> > &parameters_tab)
{
  const unsigned int N_parameters = parameters_tab.dimension (0) - 1;

  class vector_class<double> parameters_centroid(N_parameters);

  parameters_centroid = 0.0;

  for (unsigned int i = 0 ; i < N_parameters ; i++)
    {
      const class vector_class<double> &parameters_i = parameters_tab(i);

      parameters_centroid += parameters_i;
    }

  parameters_centroid /= N_parameters;

  return parameters_centroid;
}








void multidimensional_optimization::Nelder_Mead::parameters_calc_print (
									const void *const ptr ,
									double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
									class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
									const double relative_step , 
									const double precision_Nelder_Mead ,
									const class array<double> &weights ,
									class vector_class<double> &parameters)
{
  const unsigned int N_parameters = parameters.get_dimension ();

  const unsigned int N_parameters_plus_one = N_parameters + 1;

  class array<class vector_class<double> > parameters_tab(N_parameters_plus_one);

  class array<double> cost_function_tab(N_parameters_plus_one);

  cost_function_tab = cost_function_calc (ptr , generic_component_calc , weights , parameters);

  for (unsigned int i = 0 ; i <= N_parameters ; i++)
    {
      class vector_class<double> &parameters_i = parameters_tab(i);

      parameters_i.allocate_fill (parameters);

      if (i < N_parameters)
	{
	  parameters_i(i) += parameters_i(i)*relative_step;			

	  cost_function_tab(i) = cost_function_calc (ptr , generic_component_calc , weights , parameters_i);
	}
    }

  parameters_tab_sort (0 , N_parameters , cost_function_tab , parameters_tab);

  double chi = 1.0;

  unsigned int iter = 0;

  while ((chi > precision_Nelder_Mead) && (iter++ < 10000))
    {
      const class vector_class<double> parameters_centroid = parameters_centroid_calc (parameters_tab);

      class vector_class<double> &parameters_last = parameters_tab(N_parameters);

      double &cost_function_last = cost_function_tab(N_parameters);

      const class vector_class<double> parameters_last_centroid_diff = parameters_centroid - parameters_last;

      const class vector_class<double> parameters_reflection = parameters_centroid + parameters_last_centroid_diff;

      const double cost_function_reflection = cost_function_calc (ptr , generic_component_calc , weights , parameters_reflection);

      if (cost_function_reflection < cost_function_last)
	{
	  const class vector_class<double> parameters_expanded = parameters_centroid + 2.0*parameters_last_centroid_diff;

	  const double cost_function_expanded = cost_function_calc (ptr , generic_component_calc , weights , parameters_expanded);

	  if (cost_function_expanded < cost_function_reflection)
	    parameters_last = parameters_expanded , cost_function_last = cost_function_expanded;
	  else
	    parameters_last = parameters_reflection , cost_function_last = cost_function_reflection;
	}
      else
	{
	  const class vector_class<double> parameters_contraction = parameters_centroid - 0.5*parameters_last_centroid_diff;

	  const double cost_function_contraction = cost_function_calc (ptr , generic_component_calc , weights , parameters_contraction);

	  if (cost_function_contraction <= cost_function_last)
	    parameters_last = parameters_contraction ,  cost_function_last = cost_function_contraction;
	  else
	    {	
	      const class vector_class<double> &parameters_first = parameters_tab(0);

	      for (unsigned int i = 1 ; i <= N_parameters ; i++)
		{
		  class vector_class<double> &parameters_i = parameters_tab(i);

		  parameters_i = parameters_first + 0.5*(parameters_i - parameters_first);

		  cost_function_tab(i) = cost_function_calc (ptr , generic_component_calc ,weights ,  parameters_i);
		}
	    }
	}

      parameters_tab_sort (0 , N_parameters , cost_function_tab , parameters_tab);

      const class vector_class<double> &parameters_first = parameters_tab(0);

      const double cost_function_first = cost_function_tab(0);

      parameters = parameters_first;

      chi = sqrt (cost_function_first);

      if (THIS_PROCESS == MASTER_PROCESS)
	cout << "Nelder Mead iteration : " << iter << " chi : " << chi << endl;
    }

  const class vector_class<double> cost_function_grad = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters);

  const double cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

  if (THIS_PROCESS == MASTER_PROCESS)
    cout << endl << "Nelder Mead iteration : " << iter << " chi : " << chi << " ||grad (chi^2)|| : " << cost_grad_norm << endl;
}













void multidimensional_optimization::conjugate_gradient::linear_minimization_parameters_calc (
											     const void *const ptr ,
											     double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
											     class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
											     const class array<double> &weights ,
											     const class vector_class<double> &parameters_dir , 
											     class vector_class<double> &parameters , 
											     class vector_class<double> &cost_function_grad , 
											     double &grad_scalar_dir)
{
  const class vector_class<double> parameters_init = parameters;

  double x_min = 0.0 , x_min_bef = 0.0 , grad_scalar_dir_bef = grad_scalar_dir , dx_min = 0.001;
  class vector_class<double> parameters_bef = parameters , cost_function_grad_bef = cost_function_grad;

  unsigned int iter = 0;

  while ((abs (dx_min) > 0.0001) && (iter++ < 100))
    {
      x_min -= dx_min;

      parameters = parameters_init + x_min*parameters_dir;

      cost_function_grad = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters);

      const class vector_class<double> cost_function_grad_der = (cost_function_grad - cost_function_grad_bef)/(x_min - x_min_bef);

      grad_scalar_dir = cost_function_grad_der*cost_function_grad;

      const double grad_scalar_dir_der = (grad_scalar_dir - grad_scalar_dir_bef)/(x_min - x_min_bef);

      dx_min = grad_scalar_dir/grad_scalar_dir_der;

      x_min_bef = x_min;

      grad_scalar_dir_bef = grad_scalar_dir;

      cost_function_grad_bef = cost_function_grad;
    }

  if (abs (x_min) < 0.05*sqrt (parameters_init*parameters_init))
    {
      const unsigned int N_parameters = parameters.get_dimension ();

      if (THIS_PROCESS == MASTER_PROCESS)
	{
	  cout << "----------------------------------------------------------" << endl;
	  cout << "Random variation of parameters" << endl;

	  for (unsigned int s = 0 ; s < N_parameters ; s++) parameters_bef(s) *= 1.0 + 0.05*random_number<double> ();
	}

      cost_function_grad_bef = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters_bef);

      parameters = parameters_bef + 0.001*parameters_dir;

      cost_function_grad = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters);

      const class vector_class<double> cost_function_grad_der = (cost_function_grad - cost_function_grad_bef)/0.001;

      grad_scalar_dir = cost_function_grad_der*cost_function_grad;
    }
}






void multidimensional_optimization::conjugate_gradient::parameters_calc_print (
									       const void *const ptr ,
									       double (&generic_component_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
									       class vector_class<double> (&generic_component_grad_calc) (const void *const , const unsigned int , const class array<double> & , const class vector_class<double> &) ,
									       const double precision_conjugate_gradient , 
									       const class array<double> &weights ,
									       class vector_class<double> &parameters_dir , 
									       class vector_class<double> &parameters)
{
  class vector_class<double> cost_function_grad = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters);

  const double eps = 0.001;

  const class vector_class<double> parameters_eps = parameters + eps*parameters_dir;

  const class vector_class<double> cost_function_grad_eps = cost_function_grad_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters_eps);

  class vector_class<double> cost_function_grad_der = (cost_function_grad_eps - cost_function_grad)/eps;

  double grad_scalar_dir = cost_function_grad_der*cost_function_grad;

  class vector_class<double> parameters_bef = parameters;

  class vector_class<double> cost_function_grad_bef = cost_function_grad;

  unsigned int iter = 0;
  
  double cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

  double chi = 1.0;

  while ((cost_grad_norm > precision_conjugate_gradient) && (iter++ < 1000))
    {
      linear_minimization_parameters_calc (ptr , generic_component_calc , generic_component_grad_calc , weights , parameters_dir , parameters , cost_function_grad , grad_scalar_dir);

      const class vector_class<double> cost_function_grad_diff = cost_function_grad - cost_function_grad_bef;

      const double conjugate_gradient_factor = -(cost_function_grad_diff*cost_function_grad)/(cost_grad_norm*cost_grad_norm);

      parameters_dir = -cost_function_grad + conjugate_gradient_factor*parameters_dir;

      cost_function_grad_bef = cost_function_grad , parameters_bef = parameters;

      cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

      chi = sqrt (cost_function_calc (ptr , generic_component_calc , weights , parameters));

      if (THIS_PROCESS == MASTER_PROCESS)
	cout << "conjugate gradient iteration : " << iter << " chi : " << chi << " ||grad (chi^2)|| : " << cost_grad_norm << endl;
    }
}


