#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace multidimensional_optimization;

//==============================================================================
// Starts functions for optimization

// Test function to optimize
// -------------------------

class F_test_class
{
public:

  F_test_class (const class array<double> &alpha_tab_c);

  ~F_test_class ();

  double component_calc (const unsigned int i , const class array<double> &weights , const class vector_class<double> &parameters) const;

  class vector_class<double> component_grad_calc (const unsigned int i , const class array<double> &weights , const class vector_class<double> &parameters) const;

private:
  const class array<double> &alpha_tab;

  const unsigned int N_conditions;
  const unsigned int N_parameters;
};



F_test_class::F_test_class (const class array<double> &alpha_tab_c)
  :
  alpha_tab (alpha_tab_c) ,
  N_conditions (alpha_tab.dimension (0)) ,
  N_parameters (alpha_tab.dimension (1)) {}



F_test_class::~F_test_class () {}




double F_test_class::component_calc (const unsigned int i , const class array<double> &weights , const class vector_class<double> &parameters) const
{
  double component = 0.0;

  for (unsigned int j = 0 ; j < N_parameters ; j++)
    {
      const double alpha_ij = alpha_tab(i,j);
      
      const double parameter_j = parameters(j);
      
      const double sin_alpha_parameter_minus_Pi_ij = sin (alpha_ij*(parameter_j - M_PI));

      component += sin_alpha_parameter_minus_Pi_ij*sin_alpha_parameter_minus_Pi_ij;
    }

  component *= sqrt (weights(i));

  return component;
}





class vector_class<double> F_test_class::component_grad_calc (const unsigned int i ,  const class array<double> &weights , const class vector_class<double> &parameters) const
{
  class vector_class<double> component_grad(N_parameters);

  for (unsigned int j = 0 ; j < N_parameters ; j++)
    {
      const double alpha_ij = alpha_tab(i , j);

      const double parameter_j = parameters(j);

      const double sin_alpha_parameter_minus_Pi_ij = sin (alpha_ij*(parameter_j - M_PI));
      const double cos_alpha_parameter_minus_Pi_ij = cos (alpha_ij*(parameter_j - M_PI));

      component_grad(j) = 2.0*alpha_ij*sin_alpha_parameter_minus_Pi_ij*cos_alpha_parameter_minus_Pi_ij;
    }

  component_grad *= sqrt (weights(i));

  return component_grad;
}



// Non-member functions related to F_test to be used in references to functions
// ----------------------------------------------------------------------------

double F_component_calc (const void *const ptr , const unsigned int i , const class array<double> &weights , const class vector_class<double> &parameters)
{
  const class F_test_class &F_test = *(static_cast<const class F_test_class *> (ptr));

  return F_test.component_calc (i , weights , parameters);
}

class vector_class<double> F_component_grad_calc (const void *const ptr , const unsigned int i , const class array<double> &weights , const class vector_class<double> &parameters)
{
  const class F_test_class &F_test = *(static_cast<const class F_test_class *> (ptr));

  return F_test.component_grad_calc (i , weights , parameters);
}




// One searches a zero of F(x), with F = [Fi]_{0 <= i <= N_conditions-1} and x = [xj]_{0 <= j <= N_parameters-1} vectors.
// The example is Fi(x) = \sum_{j=0}^{N_parameters-1} sin (alpha_tab(i,j).(xj - Pi))^2. alpha_tab is a set of positive random numbers close to 2. A zero of F(x) occurs for xj = Pi \forall j.
// component_calc is the real number Fi(x) for fixed i and x.
// component_grad_calc is the gradient of Fi(x) equal to [dFi/dxj]_{0 <= j <= N_parameters-1} for fixed i and x.
// cost_function_calc is the real number (1/N_conditions) \sum_{i=0}^{N_conditions-1} Fi(x)*Fi(x) for fixed x.
// cost_function_grad_calc is the gradient of cost_function equal to [(1/N_conditions) \sum_{i=0}^{N_conditions-1} 2 Fi(x) dFi/dxj]_{0 <= j <= N_parameters-1} for fixed x.

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Sequential calculation only");

    cout << "Fit of sum_j sin (alpha[i,j].(P[j] - Pi)) for all i" << endl;
    cout << "---------------------------------------------------" << endl;

    const unsigned int N_parameters = 5;
    
    const unsigned int N_conditions = 10;
    
    const double alpha_zero = 2.0;

    const double delta_alpha = 0.5;

    class array<double> alpha_tab(N_conditions , N_parameters);
    alpha_tab.random_array ();
    alpha_tab *= delta_alpha;
    alpha_tab += alpha_zero;

    const class F_test_class F_test(alpha_tab);

    class array<double> weights(N_conditions);
    weights.random_array ();
    weights *= 0.1;
    weights += 1.0;
    weights /= weights.sum ();

    class vector_class<double> parameters(N_parameters);

    parameters.random_vector ();
    parameters *= 0.8;
    parameters += M_PI;

    cout.precision (6);
    cout << endl << "Newton method"  << endl;
    cout <<         "-------------" << endl << endl;
    cout << "Initial vector : "  << parameters << endl << endl;

    cout.precision (15);
    Newton_method::calc_print (&F_test , F_component_calc , F_component_grad_calc , precision , 1E-12 , weights , parameters);

    cout.precision (6);
    cout << endl << "Final P vector minus Pi: "  << parameters - M_PI << endl << endl << endl;

    // ------------------------------------------------------------------------------------------- //
    // Routines afterwards are not for Newton's method. Ignore if you consider Newton method only.
    // ------------------------------------------------------------------------------------------- //

    const double relative_step = 0.5;

    parameters.random_vector ();
    parameters *= 0.1;
    parameters += M_PI;

    cout.precision (3);

    cout << endl << "Nelder Mead method"  << endl;
    cout <<         "------------------" << endl << endl;
    cout << "Initial vector : "  << parameters << endl << endl;

    cout.precision (15);
    Nelder_Mead::parameters_calc_print (&F_test , F_component_calc , F_component_grad_calc , relative_step , precision , weights , parameters);

    cout.precision (6);
    cout << endl << "Final P vector minus Pi: "  << parameters - M_PI << endl << endl;

    parameters.random_vector ();
    parameters *= 0.00005;
    parameters += M_PI;

    cout.precision (3);
    cout << endl << "Conjugate gradient method"  << endl;
    cout <<         "-------------------------" << endl << endl;
    cout << "Initial vector : "  << parameters << endl;

    cout.precision (15);

    class vector_class<double> parameters_dir(N_parameters);

    parameters_dir = parameters;

    conjugate_gradient::parameters_calc_print (&F_test , F_component_calc , F_component_grad_calc , precision , weights , parameters_dir , parameters);

    cout.precision (6);

    cout << endl << "Final P vector minus Pi: "  << parameters - M_PI << endl << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }




