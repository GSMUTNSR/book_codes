#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    cout.precision (15);

    const unsigned int N = 15;
    
    const double exact_integral_first_kind = 2.403939430634413; // It is Pi.J0(1)
  
    cout << "cos (x)/sqrt(1-x^2) is integrated numerically and exactly on ]-1:1[." << endl << endl;

    cout << "Gauss-Chebyshev number of points   Gauss-Chebyshev integral   exact integral    test"  << endl << endl;

    for (unsigned int n = 1 ; n <= N ; n ++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);
	
	Gauss_Chebyshev::abscissas_weights_tables_calc (1 , x_tab , w_tab);

	complex<double> integral_first_kind = 0.0;

	for (unsigned int i = 0 ; i < n ; i++) integral_first_kind += cos (x_tab(i))*w_tab(i);

	cout << n << " " << integral_first_kind << " " << exact_integral_first_kind << " " << inf_norm (integral_first_kind/exact_integral_first_kind - 1.0) << endl;
      }

    cout << endl << "cos (x).sqrt(1-x^2) is integrated numerically and exactly on ]-1:1[." << endl << endl;

    const double exact_integral_second_kind = 1.3824596873841686;
    
    cout << "Gauss-Chebyshev number of points   Gauss-Chebyshev integral_second_kind   exact integral_second_kind    test"  << endl << endl;

    for (unsigned int n = 1 ; n <= N ; n ++)
      {
	class array<double> x_tab(n);
	class array<double> w_tab(n);
	
	Gauss_Chebyshev::abscissas_weights_tables_calc (2 , x_tab , w_tab);

	complex<double> integral_second_kind = 0.0;

	for (unsigned int i = 0 ; i < n ; i++) integral_second_kind += cos (x_tab(i))*w_tab(i);

	cout << n << " " << integral_second_kind << " " << exact_integral_second_kind << " " << inf_norm (integral_second_kind/exact_integral_second_kind - 1.0) << endl;
      }

    cout << endl << "Comparisons of Tn(x), Tn'(x) from the class and Tn(x) = cos (n.acos(x)) and T'n(x) = n.sin (n.acos(x))/sqrt (1 - x^2)" << endl << endl;

    seed ();
    
    for (int n = 0 ; n <= 10 ; n++)
      {
	const double x = random_number<double> ();

	const double Tn_x = Gauss_Chebyshev::poly (1 , n , x);
	
	const double Tn_der_x = Gauss_Chebyshev::poly_der (1 , n , x);

	const double Tn_x_test = cos (n*acos (x));
	
	const double Tn_der_x_test = n*sin (n*acos (x))/sqrt (1.0 - x*x);

	if (n == 0) cout << "n:" << " " << n << " x:" << x << " Tn(x): " << Tn_x << " Tn'(x):" << Tn_der_x << " test:" << inf_norm (0.5*(Tn_x + Tn_x_test) + Tn_der_x + Tn_der_x_test  - 1.0) << endl;
	if (n > 0)  cout << "n:" << " " << n << " x:" << x << " Tn(x): " << Tn_x << " Tn'(x):" << Tn_der_x << " test:" << inf_norm (0.5*(Tn_x / Tn_x_test  + Tn_der_x / Tn_der_x_test) - 1.0) << endl;
      }
  
    cout << endl << "Comparisons of Un(x), Un'(x) from the class and Un(x) = sin ((n+1).acos(x))/sin (acos(x)) and U'n(x) = (-(n+1).cos ((n+1).acos(x)) + x.sin ((n+1).acos(x))/sin (acos(x)))/sin (acos(x))/sqrt (1 - x^2)" << endl << endl;
    
    for (int n = 0 ; n <= 10 ; n++)
      {
	const double x = random_number<double> ();

	const double Un_x = Gauss_Chebyshev::poly (2 , n , x);
	
	const double Un_der_x = Gauss_Chebyshev::poly_der (2 , n , x);

	const double sin_acos_x = sin (acos(x));
	
	const double sin_np1_acos_x = sin ((n+1)*acos(x));
	const double cos_np1_acos_x = cos ((n+1)*acos(x));
	
	const double Un_x_test = sin_np1_acos_x/sin_acos_x;
	
	const double Un_der_x_test = (-(n+1)*cos_np1_acos_x + x*sin_np1_acos_x/sin_acos_x)/sin_acos_x/sqrt (1 - x*x);

	if (n == 0) cout << "n:" << " " << n << " x:" << x << " Un(x): " << Un_x << " Un'(x):" << Un_der_x << " test:" << inf_norm (0.5*(Un_x + Un_x_test) + Un_der_x + Un_der_x_test  - 1.0) << endl;
	if (n > 0)  cout << "n:" << " " << n << " x:" << x << " Un(x): " << Un_x << " Un'(x):" << Un_der_x << " test:" << inf_norm (0.5*(Un_x / Un_x_test  + Un_der_x / Un_der_x_test) - 1.0) << endl;
      }
  
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

