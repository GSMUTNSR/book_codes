#include "../numlib_def/numlib_def.h"

// P(x) is Tn(x) (Chebyshev polynomial of first kind) or Un(x) (Chebyshev polynomial ofsecond kind)

// Chebyshev polynomial
// ------------------ - 
// The following recurrence relation is used :
// P(i+1, x) = 2x.P(i, x) - P(i-1, x) for i > 0.
//
// P(0, x) = 1. This value is directly returned if the degree of the polynomial is 0.
//
// T1(x) = x and U1(x) = 2x. The recurrence relation for both polynomials is the same. 
//
// Variable
// --------
// kind: 1 if one calculates a Chebyshev polynomial of first kind, 2 if one calculates a Chebyshev polynomial of second kind
// degree : degree of the Chebyshev polynomial
// x, two_x : variable of the Chebyshev polynomial, twice this value
// i, poly_im1, poly_i, poly_ip1 : Chebyshev polynomial of degree i-1, i, i+1. i goes from 1 to degree-1, with degree > 1.

double Gauss_Chebyshev::poly (const int kind , const int degree , const double x)
{
  if ((kind != 1) && (kind != 2)) error_message_print_abort ("One can only have Chebyshev polynomials of first or second kind in Gauss_Chebyshev::poly");
  
  if (degree == 0) return 1.0;

  const double two_x = 2.0*x;
      
  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = (kind == 1) ? (x) : (two_x);

  for (int i = 1 ; i < degree ; i++)
    {
      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_ip1 = two_x * poly_i - poly_im1;
    }

  return poly_ip1;
}








// Derivative of the Chebyshev polynomial
// --------------------------------------
// The following recurrence relations are used :
// P(i+1, x) = 2x.P(i, x) - P(i-1, x) for i > 0.
// P'(i+1, x) = 2x.P'(i, x) - P'(i-1, x) + 2.P(i, x) for i > 0.
//
// P(0 , x) = 1. 
// P'(0 , x) = 0. This value is directly returned if the degree of the polynomial is 0.
//
// I do not use formulas providing P'(i,x) from P(i-1,x) as they can be unstable due to the possibilities of very small numerators and denominators.
//
// T1(x) = x and U1(x) = 2x. T1'(x) = 1 and U1(x) = 2.  The recurrence relation for both polynomials is the same. 
//
// Variable
// --------
// kind: 1 if one calculates a Chebyshev polynomial derivative of first kind, 2 if one calculates a Chebyshev polynomial derivative of second kind
// degree : degree of the Chebyshev polynomial
// x, two_x : variable of the Chebyshev polynomial derivative, twice this value
// i , poly_im1 , poly_i , poly_ip1 : Chebyshev polynomial of degree i-1 , i , i+1. i goes from 1 to degree-1 , with degree > 1.
// poly_der_i , poly_der_ip1 : Derivatives of Chebyshev polynomial of degree i , i+1. i goes from 1 to degree-1 , with degree > 1.
// At the end , poly_der_ip1 is returned.

double Gauss_Chebyshev::poly_der (const int kind , const int degree , const double x)
{
  if ((kind != 1) && (kind != 2)) error_message_print_abort ("One can only have Chebyshev polynomials of first or second kind in Gauss_Chebyshev::poly_der");
    
  if (degree == 0) return 0.0;

  const double two_x = 2.0*x;
      
  double poly_im1 = 0.0;

  double poly_i = 1.0;

  double poly_ip1 = (kind == 1) ? (x) : (two_x);

  double poly_der_im1 = 0.0;
      
  double poly_der_i = 0.0;

  double poly_der_ip1 = (kind == 1) ? (1.0) : (2.0);

  for (int i = 1 ; i < degree ; i++)
    {
      poly_im1 = poly_i;

      poly_i = poly_ip1;
	  
      poly_der_im1 = poly_der_i;
	  
      poly_der_i = poly_der_ip1;
	  
      poly_ip1 = two_x * poly_i - poly_im1;
	  
      poly_der_ip1 = two_x * poly_der_i - poly_der_im1 + 2.0*poly_i;
    }
      
  return poly_der_ip1;
}






// Calculation of the abscissas and weights of the Gauss-Chebyshev quadrature
// ----------------------------------------------------------------------------
// These are the abscissas and weights of the Gauss-Chebyshev quadrature in ]-1:1[.
// Abscissas are equal to cos (Pi.(i + 1/2)/N) and weights to Pi/N for first kind,
// Abscissas are equal to cos (Pi.(i + 1)/(N + 1)) and weights to Pi/(N + 1) sin^2(Pi.(i + 1)/(N + 1)) for second kind,
// Abscissas are put to increasing value at the end.
//
// Variables
// -------- - 
// kind: 1 if one considers Chebyshev polynomials of first kind, 2 if one considers Chebyshev polynomials of second kind
// N: number of points in the Gauss-Chebyshev quadrature
// Pi_over_N, Pi_over_Np1 : Pi/N, Pi/(N+1)
// x : abscissa for second kind
// x_table : table of Gauss-Chebyshev abscissas.
// w_table : table of Gauss-Chebyshev weights.

void Gauss_Chebyshev::abscissas_weights_tables_calc (
						     const int kind , 
						     class array<double> &x_table , 
						     class array<double> &w_table)
{
  const unsigned int N = x_table.dimension (0);
  
  if (N == 0) return;
  
  if (kind == 1)
    {
      const double Pi_over_N = M_PI/N;

      for (unsigned int i = 0 ; i < N ; i++) x_table(i) = cos ((i + 0.5)*Pi_over_N);
        
      w_table = Pi_over_N;
    }
  else if (kind == 2)
    {
      const double Pi_over_Np1 = M_PI/(N + 1);

      for (unsigned int i = 0 ; i < N ; i++)
	{
	  const double x = cos ((i + 1)*Pi_over_Np1);
	  
	  x_table(i) = x;
	  
	  w_table(i) = Pi_over_Np1*(1.0 - x*x);
	}
    }
  else
    error_message_print_abort ("One can only have Chebyshev polynomials of first or second kind in Gauss_Chebyshev::abscissas_weights_tables_calc");
  
  x_table.reverse_order ();
}



