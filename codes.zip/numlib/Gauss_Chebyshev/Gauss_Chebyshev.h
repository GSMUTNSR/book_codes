#ifndef GAUSS_CHEBYSHEV_H
#define GAUSS_CHEBYSHEV_H

namespace Gauss_Chebyshev
{
  double poly (const int kind , const int degree , const double x);

  double poly_der (const int kind , const int degree , const double x);

  void abscissas_weights_tables_calc (
				      const int kind , 
				      class array<double> &x_table , 
				      class array<double> &w_table);
}

#endif

