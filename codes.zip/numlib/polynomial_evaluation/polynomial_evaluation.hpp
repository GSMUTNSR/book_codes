#ifndef POLYNOMIAL_EVALUATION_HPP
#define POLYNOMIAL_EVALUATION_HPP




// Calculation of a polynomial with the Horner scheme.
// ---------------------------------------------------
// Class array version
//
// Variables:
// ----------
// degree : degree of the polynomial.
// coeff : coefficients of the polynomial : P(X) = \sum^{k=0}^{degree} coeff(k) X^k. (no index)
//                                          P(X) = \sum^{k=0}^{degree} coeff(index,k) X^k. (indexed)
// x : variable of the polynomial.
// Px : value of the polynomial in x.

template <typename SCALAR_TYPE>
SCALAR_TYPE polynomial_evaluation_indexed (
					   const unsigned int index , 
					   const unsigned int degree , 
					   const class array<SCALAR_TYPE> &coeffs , 
					   const SCALAR_TYPE &x)
{
  SCALAR_TYPE Px = coeffs(index , degree);

  for (unsigned int i = degree ; i > 0 ; i--) Px = coeffs(index , i-1) + x*Px;

  return Px;
}


template <typename SCALAR_TYPE>
SCALAR_TYPE polynomial_evaluation (
				   const unsigned int degree , 
				   const class array<SCALAR_TYPE> &coeffs , 
				   const SCALAR_TYPE &x)
{
  SCALAR_TYPE Px = coeffs(degree);

  for (unsigned int i = degree ; i > 0 ; i--) Px = coeffs(i-1) + x*Px;

  return Px;
}





// Calculation of a polynomial with the Horner scheme.
// ---------------------------------------------------
// Standard table version
// 
// Variables:
// ----------
// degree : degree of the polynomial.
// coeff : coefficients of the polynomial : P(X) = \sum^{k=0}^{degree} coeff(k) X^k.
// x : variable of the polynomial.
// Px : value of the polynomial in x.

template <typename SCALAR_TYPE>
SCALAR_TYPE polynomial_evaluation (
				   const unsigned int degree , 
				   const SCALAR_TYPE coeffs[] , 
				   const SCALAR_TYPE &x)
{
  SCALAR_TYPE Px = coeffs[degree];

  for (unsigned int i = degree ; i > 0 ; i--) Px = coeffs[i-1] + x*Px;

  return Px;
}

#endif
