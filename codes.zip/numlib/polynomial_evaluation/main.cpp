#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
 
#else
  int main ()
  {
    non_MPI_initialization ();

#endif

    OpenMP_initialization ();

    const unsigned int d = 5;

    const unsigned int d_plus_one = d + 1;

    const unsigned int N = 2;
    
    const double x = 0.613;
    const double y = 0.365;

    class array<double> coeffs_1D(d_plus_one);

    class array<double> coeffs_2D(N , d_plus_one);

    for (unsigned int i = 0 ; i <= d ; i++) coeffs_1D(i) = i;

    const double Px = polynomial_evaluation<double> (d , coeffs_1D , x);
    
    const double Px_test = coeffs_1D(0) + x*(coeffs_1D(1) + x*(coeffs_1D(2) + x*(coeffs_1D(3) + x*(coeffs_1D(4) + x*(coeffs_1D(5) + x*coeffs_1D(6))))));

    if (inf_norm (Px_test/Px - 1.0) > 1E-13) error_message_print_abort ("Error in polynomial_evaluation 1D (class array)");

    for (unsigned int n = 0 ; n < N ; n++)
      {
	for (unsigned int i = 0 ; i <= d ; i++) coeffs_2D(n , i) = i+n;

	const double Px = polynomial_evaluation_indexed<double> (n , d , coeffs_2D , x);

	const double Px_test = coeffs_2D(n , 0) + x*(coeffs_2D(n , 1) + x*(coeffs_2D(n , 2) + x*(coeffs_2D(n , 3) + x*(coeffs_2D(n , 4) + x*(coeffs_2D(n , 5) + x*coeffs_2D(n , 6))))));

	if (inf_norm (Px_test/Px - 1.0) > 1E-13) error_message_print_abort ("Error in polynomial_evaluation 2D (class array)");
      }

    double *const T = new double [d_plus_one];

    for (unsigned int i = 0 ; i <= d ; i++) T[i] = i*M_PI + 5;

    const double Py = polynomial_evaluation<double> (d , T , y);

    const double Py_test = T[0] + y*(T[1] + y*(T[2] + y*(T[3] + y*(T[4] + y*(T[5] + y*T[6])))));

    if (inf_norm (Py_test/Py - 1.0) > 1E-13) error_message_print_abort ("Error in polynomial_evaluation (standard array)");

    delete [] T;

    cout << "Polynomial_evaluation tests are correct." << endl;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }




