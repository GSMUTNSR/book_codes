#include "../numlib_def/numlib_def.h"


unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

void standard_arrays_test (
			   const complex<double> &l_deb , 
			   const complex<double> &eta , 	
			   const unsigned int Nl , 
			   const unsigned int N , 
			   const double xmin , 
			   const double step_x , 
			   const double ymin , 
			   const double step_y)
{
  cout << endl << endl << "Standard arrays test" << endl << endl;
  
  cout << endl << "normalized(true/false)    l   z   test functions   test function derivatives "  << endl << endl;
		  
  complex<double> *const z_tab = new complex<double> [N];

  complex<double> * * const  F_tab = new complex<double> * [N];
  complex<double> * * const dF_tab = new complex<double> * [N];

  complex<double> * * const  G_tab = new complex<double> * [N];
  complex<double> * * const dG_tab = new complex<double> * [N];

  complex<double> * * const  Hp_tab = new complex<double> * [N];
  complex<double> * * const dHp_tab = new complex<double> * [N];

  complex<double> * * const  Hm_tab = new complex<double> * [N];
  complex<double> * * const dHm_tab = new complex<double> * [N];

  complex<double> * const  F_z_tab = new complex<double> [Nl];
  complex<double> * const dF_z_tab = new complex<double> [Nl];
  
  complex<double> * const  G_z_tab = new complex<double> [Nl];
  complex<double> * const dG_z_tab = new complex<double> [Nl];

  complex<double> * const  Hp_z_tab = new complex<double> [Nl];
  complex<double> * const dHp_z_tab = new complex<double> [Nl];

  complex<double> * const  Hm_z_tab = new complex<double> [Nl];
  complex<double> * const dHm_z_tab = new complex<double> [Nl];

  for (unsigned int iz = 0 ; iz < N ; iz++) 
    {
      F_tab [iz] = new complex<double> [Nl];
      dF_tab[iz] = new complex<double> [Nl];
      
      G_tab [iz] = new complex<double> [Nl];
      dG_tab[iz] = new complex<double> [Nl];

      Hp_tab [iz] = new complex<double> [Nl];
      dHp_tab[iz] = new complex<double> [Nl];

      Hm_tab [iz] = new complex<double> [Nl];
      dHm_tab[iz] = new complex<double> [Nl];
    }

  complex<double> F , dF;
  complex<double> G , dG;
  
  complex<double> Hp , dHp;
  complex<double> Hm , dHm;

  for (unsigned int i_norm = 0 ; i_norm <= 1 ; i_norm++)
    {
      const bool is_it_normalized = (i_norm == 0);
      for (unsigned int ix = 0 ; ix < N ; ix++)
	{
	  const double x = xmin + ix*step_x;

	  for (unsigned int iy = 0 ; iy < N ; iy++)
	    {
	      const double y = ymin + iy*step_y;
	  
	      z_tab[iy] = complex<double> (x , y);
	    }

	  cwf_l_tables_recurrence_relations (l_deb , Nl , eta , is_it_normalized , N , z_tab , F_tab , dF_tab , G_tab , dG_tab , Hp_tab , dHp_tab , Hm_tab , dHm_tab);

	  for (unsigned int il = 0 ; il < Nl ; il++)
	    {
	      const complex<double> l = l_deb + il;

	      class Coulomb_wave_functions cwf_l(is_it_normalized , l , eta);

	      for (unsigned int iz = 0 ; iz < N ; iz++) 
		{
		  const complex<double> &z = z_tab[iz];

		  cwf_l.F_dF (z , F , dF);
		  cwf_l.G_dG (z , G , dG);
		  
		  cwf_l.H_dH ( 1 , z , Hp , dHp);
		  cwf_l.H_dH (-1 , z , Hm , dHm);

		  const double test_functions     = (inf_norm ( F -  F_tab[iz][il]) + inf_norm ( G -  G_tab[iz][il]) + inf_norm ( Hp -  Hp_tab[iz][il]) + inf_norm ( Hm -  Hm_tab[iz][il]))/4.0;		  
		  const double test_functions_der = (inf_norm (dF - dF_tab[iz][il]) + inf_norm (dG - dG_tab[iz][il]) + inf_norm (dHp - dHp_tab[iz][il]) + inf_norm (dHm - dHm_tab[iz][il]))/4.0;	

		  cout << is_it_normalized  << " " << l << " " << z << "     " << test_functions << " " << test_functions_der << endl;
		}
	    }
	}

      const complex<double> &z = z_tab[N/2];

      cwf_l_tables_recurrence_relations (l_deb , Nl , eta , is_it_normalized , z , F_z_tab , dF_z_tab , G_z_tab , dG_z_tab , Hp_z_tab , dHp_z_tab , Hm_z_tab , dHm_z_tab);

      for (unsigned int il = 0 ; il < Nl ; il++)
	{
	  const complex<double> l = l_deb + il;

	  class Coulomb_wave_functions cwf_l(is_it_normalized , l , eta);

	  cwf_l.F_dF (z , F , dF);
	  cwf_l.G_dG (z , G , dG);
	      
	  cwf_l.H_dH ( 1 , z , Hp , dHp);
	  cwf_l.H_dH (-1 , z , Hm , dHm);

	  const double test_functions     = (inf_norm ( F -  F_z_tab[il]) + inf_norm ( G -  G_z_tab[il]) + inf_norm ( Hp -  Hp_z_tab[il]) + inf_norm ( Hm -  Hm_z_tab[il]))/4.0;		  
	  const double test_functions_der = (inf_norm (dF - dF_z_tab[il]) + inf_norm (dG - dG_z_tab[il]) + inf_norm (dHp - dHp_z_tab[il]) + inf_norm (dHm - dHm_z_tab[il]))/4.0;

	  cout << is_it_normalized  << " " << l << " " << z << "     " << test_functions << " " << test_functions_der << endl;
	}
    }

  for (unsigned int iz = 0 ; iz < N ; iz++) 
    {
      delete []  F_tab[iz];
      delete [] dF_tab[iz];
      
      delete []  G_tab[iz];
      delete [] dG_tab[iz];

      delete []  Hp_tab[iz];
      delete [] dHp_tab[iz];

      delete []  Hm_tab[iz];
      delete [] dHm_tab[iz];
    }

  delete [] z_tab;	

  delete []  F_z_tab;
  delete [] dF_z_tab;

  delete []  G_z_tab;
  delete [] dG_z_tab;

  delete []  Hp_z_tab;
  delete [] dHp_z_tab;

  delete []  Hm_z_tab;
  delete [] dHm_z_tab;

  delete []  F_tab;
  delete [] dF_tab;

  delete []  G_tab;
  delete [] dG_tab;

  delete []  Hp_tab;
  delete [] dHp_tab;

  delete []  Hm_tab;
  delete [] dHm_tab;
}









void arrays_test (
		  const complex<double> &l_deb , 
		  const complex<double> &eta , 	
		  const unsigned int Nl , 
		  const unsigned int N , 
		  const double xmin , 
		  const double step_x , 
		  const double ymin , 
		  const double step_y)
{
  cout << endl << endl << "Arrays test" << endl << endl;
  
  cout << endl << "normalized(true/false)    l   z   test functions   test function derivatives "  << endl << endl;
  
  class array<complex<double> > z_tab(N);

  class array<complex<double> > F_tab(Nl , N) , dF_tab(Nl , N) , Hp_tab(Nl , N) , dHp_tab(Nl , N);  
  class array<complex<double> > G_tab(Nl , N) , dG_tab(Nl , N) , Hm_tab(Nl , N) , dHm_tab(Nl , N);
  
  class array<complex<double> > F_z_tab(Nl) , dF_z_tab(Nl) , Hp_z_tab(Nl) , dHp_z_tab(Nl);  
  class array<complex<double> > G_z_tab(Nl) , dG_z_tab(Nl) , Hm_z_tab(Nl) , dHm_z_tab(Nl);

  complex<double> F , dF;
  complex<double> G , dG;
  
  complex<double> Hp , dHp;
  complex<double> Hm , dHm;
	  
  for (unsigned int i_norm = 0 ; i_norm <= 1 ; i_norm++)
    {
      const bool is_it_normalized = (i_norm == 0);
	  
      for (unsigned int ix = 0 ; ix < N ; ix++)
	{
	  const double x = xmin + ix*step_x;

	  for (unsigned int iy = 0 ; iy < N ; iy++)
	    {
	      const double y = ymin + iy*step_y;
	  
	      z_tab(iy) = complex<double> (x , y);
	    }

	  cwf_l_tables_recurrence_relations (l_deb , eta , is_it_normalized , z_tab , F_tab , dF_tab , G_tab , dG_tab , Hp_tab , dHp_tab , Hm_tab , dHm_tab);

	  for (unsigned int il = 0 ; il < Nl ; il++)
	    {
	      const complex<double> l = l_deb + il;

	      class Coulomb_wave_functions cwf_l(is_it_normalized , l , eta);

	      for (unsigned int iz = 0 ; iz < N ; iz++) 
		{
		  const complex<double> &z = z_tab[iz];

		  cwf_l.F_dF (z , F , dF);
		  cwf_l.G_dG (z , G , dG);
		  
		  cwf_l.H_dH ( 1 , z , Hp , dHp);
		  cwf_l.H_dH (-1 , z , Hm , dHm);

		  const double test_functions     = (inf_norm ( F -  F_tab(il , iz)) + inf_norm ( G -  G_tab(il , iz)) + inf_norm ( Hp -  Hp_tab(il , iz)) + inf_norm ( Hm -  Hm_tab(il , iz)))/4.0;		  
		  const double test_functions_der = (inf_norm (dF - dF_tab(il , iz)) + inf_norm (dG - dG_tab(il , iz)) + inf_norm (dHp - dHp_tab(il , iz)) + inf_norm (dHm - dHm_tab(il , iz)))/4.0;
		  
		  cout << is_it_normalized  << " " << l << " " << z << "     " << test_functions << " " << test_functions_der << endl;
		}
	    }
	}

      const complex<double> &z = z_tab[N/2];

      cwf_l_tables_recurrence_relations (l_deb , eta , is_it_normalized , z , F_z_tab , dF_z_tab , G_z_tab , dG_z_tab , Hp_z_tab , dHp_z_tab , Hm_z_tab , dHm_z_tab);

      for (unsigned int il = 0 ; il < Nl ; il++)
	{
	  const complex<double> l = l_deb + il;

	  class Coulomb_wave_functions cwf_l(is_it_normalized , l , eta);

	  cwf_l.F_dF (z , F , dF);
	  cwf_l.G_dG (z , G , dG);
	      
	  cwf_l.H_dH ( 1 , z , Hp , dHp);
	  cwf_l.H_dH (-1 , z , Hm , dHm);

	  const double test_functions     = (inf_norm ( F -  F_z_tab(il)) + inf_norm ( G -  G_z_tab(il)) + inf_norm ( Hp -  Hp_z_tab(il)) + inf_norm ( Hm -  Hm_z_tab(il)))/4.0;		  
	  const double test_functions_der = (inf_norm (dF - dF_z_tab(il)) + inf_norm (dG - dG_z_tab(il)) + inf_norm (dHp - dHp_z_tab(il)) + inf_norm (dHm - dHm_z_tab(il)))/4.0;

	  cout << is_it_normalized  << " " << l << " " << z << "     " << test_functions << " " << test_functions_der << endl;
	}
    }
}








#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();
    
    const complex<double> l_deb(0.0 , 0.00123456789123456);

    const complex<double> eta(3.456789123456 , 0.0012345678912345);
    
    const unsigned int Nl = 5;
    
    const unsigned int N = 10;

    const double xmin = 0.5;
    const double xmax = 10.23456789123456;

    const double step_x = (xmax - xmin)/static_cast<double> (N-1);
    
    const double ymin = -0.0512345678922345;
    const double ymax =  0.0523456789123456;

    const double step_y = (ymax - ymin)/static_cast<double> (N-1);

    standard_arrays_test (l_deb , eta , Nl , N , xmin , step_x , ymin , step_y);
    arrays_test          (l_deb , eta , Nl , N , xmin , step_x , ymin , step_y);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
