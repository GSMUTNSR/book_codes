#ifndef COULOMB_WF_ADD_H
#define COULOMB_WF_ADD_H

double Wronskian_test (
		       const complex<double> &z ,
		       class Coulomb_wave_functions &cwf_l ,
		       class Coulomb_wave_functions &cwf_lp1);

void F_dF_l_tables_recurrence_relations_helper (
						const int Nl , 
						const int Nz , 
						const complex<double> z_tab[] , 
						const complex<double> R_tab[] , 
						class Coulomb_wave_functions &cwf_l_deb , 
						class Coulomb_wave_functions &cwf_l_end , 
						complex<double> * const * const F_tab , 
						complex<double> * const * const dF_tab , 
						int il_turn_tab[]);

void F_dF_l_tables_recurrence_relations_helper (
						const class array<complex<double> > &z_tab , 
						const class array<complex<double> > &R_tab , 
						class Coulomb_wave_functions &cwf_l_deb , 
						class Coulomb_wave_functions &cwf_l_end , 
						class array<complex<double> > &F_tab , 
						class array<complex<double> > &dF_tab , 
						class array<int> &il_turn_tab);

void cwf_l_tables_recurrence_relations_helper (
					       const int Nl , 
					       const complex<double> R_tab[] , 
					       class Coulomb_wave_functions cwf_l_tab[] , 
					       const complex<double> &z , 
					       const int il_turn , 
					       const complex<double> Fz_tab[] , 
					       const complex<double> dFz_tab[] , 
					       complex<double> Hp_z_tab[] , 
					       complex<double> dHp_z_tab[] , 
					       complex<double> Hm_z_tab[] , 
					       complex<double> dHm_z_tab[] , 
					       complex<double> Gz_tab[] , 
					       complex<double> dGz_tab[]);


void cwf_l_tables_recurrence_relations_helper (
					       const unsigned int iz , 
					       const class array<complex<double> > &R_tab , 
					       class array<class Coulomb_wave_functions> &cwf_l_tab , 
					       const class array<complex<double> > &z_tab , 
					       const int il_turn , 
					       const class array<complex<double> > &F_tab , 
					       const class array<complex<double> > &dF_tab , 
					       class array<complex<double> > &Hp_tab , 
					       class array<complex<double> > &dHp_tab , 
					       class array<complex<double> > &Hm_tab , 
					       class array<complex<double> > &dHm_tab , 
					       class array<complex<double> > &G_tab , 
					       class array<complex<double> > &dG_tab);

void cwf_l_tables_recurrence_relations (
					const complex<double> &l_deb , 
					const int Nl , 
					const complex<double> &eta , 
					const bool is_it_normalized , 
					const int Nz , 
					const complex<double> z_tab[] , 
					complex<double> * const * const F_tab , 
					complex<double> * const * const dF_tab , 
					complex<double> * const * const G_tab , 
					complex<double> * const * const dG_tab , 
					complex<double> * const * const Hp_tab , 
					complex<double> * const * const dHp_tab , 
					complex<double> * const * const Hm_tab , 
					complex<double> * const * const dHm_tab);

void cwf_l_tables_recurrence_relations (
					const complex<double> &l_deb , 
					const complex<double> &eta , 
					const bool is_it_normalized , 
					const class array<complex<double> > &z_tab , 
					class array<complex<double> > &F_tab , 
					class array<complex<double> > &dF_tab , 
					class array<complex<double> > &G_tab , 
					class array<complex<double> > &dG_tab , 
					class array<complex<double> > &Hp_tab , 
					class array<complex<double> > &dHp_tab , 
					class array<complex<double> > &Hm_tab , 
					class array<complex<double> > &dHm_tab);

void cwf_l_tables_recurrence_relations (
					const complex<double> &l_deb , 
					const int Nl , 
					const complex<double> &eta , 
					const bool is_it_normalized , 
					const complex<double> &z , 
					complex<double> * const F_tab , 
					complex<double> * const dF_tab , 
					complex<double> * const G_tab , 
					complex<double> * const dG_tab , 
					complex<double> * const Hp_tab , 
					complex<double> * const dHp_tab , 
					complex<double> * const Hm_tab , 
					complex<double> * const dHm_tab);

void cwf_l_tables_recurrence_relations (
					const complex<double> &l_deb , 
					const complex<double> &eta , 
					const bool is_it_normalized , 
					const complex<double> &z , 
					class array<complex<double> > &F_tab , 
					class array<complex<double> > &dF_tab , 
					class array<complex<double> > &G_tab , 
					class array<complex<double> > &dG_tab , 
					class array<complex<double> > &Hp_tab , 
					class array<complex<double> > &dHp_tab , 
					class array<complex<double> > &Hm_tab , 
					class array<complex<double> > &dHm_tab);

void wf_dwf_k_is_zero (
		       const int l , 
		       const int Z_charge_times_particle_charge , 
		       const complex<double> &two_I_sqrt_Vc , 
		       const complex<double> &norm_k_is_zero , 
		       class Coulomb_wave_functions &cwf_zero_k , 
		       const complex<double> &z , 
		       complex<double> &wf_p , 
		       complex<double> &dwf_p);

double k_start_calc (
		     const bool is_it_relative , 
		     const enum particle_type particle ,
		     const int l ,
		     const int Z_charge ,
		     const double R);

#endif


