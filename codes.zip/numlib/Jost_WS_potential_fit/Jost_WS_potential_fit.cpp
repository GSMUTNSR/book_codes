#include "../numlib_def/numlib_def.h"



// Calculation of outgoing wave functions for a given k and R
// ----------------------------------------------------------
// u+(k , R) and u+'(k , R) are calculated here to be used in Jost functions.
// If k = 0 , the special case of wf_dwf.k_is_zero is used. If not , Coulomb wave functions are used. 
// If k is pure imaginary , for bound states , the real Whittaker function (up to a constant if one uses unnormalized Coulomb wave functions) is used instead of H+.
// If one has overflow or underflow for wf_plus, one uses the renormalized Coulomb wave function H+ only, as it is the most probable to be finite therein.
// 
// Variables
// ---------
// Z_charge : charge of the target
// l : angular momentum.
// particle : PROTON , NEUTRON or DIPROTON.
// eta: Sommerfeld parameter
// R : point after which |Vnuclear| ~ 0.
// kinetic_factor: 2mu/hbar^2.
// two_sqrt_Vc, two_I_sqrt_Vc : 2 sqrt[Vc.Z] with Vc = kinetic_factor.Z_charge.Coulomb_constant, i times two_sqrt_Vc.
// norm_k_is_zero : exp[i l_term Pi/2]
// cwf_zero_k, l_term : class Coulomb_wave_functions with l_term = 2.l + 1/2 and eta = 0.
// z , sqrt_z : argument of the wave function , sqrt[z].
// W , dW : Whittaker function and derivative (up to a constant if one uses unnormalized Coulomb wave functions)
// wf_plus , dwf_plus : outgoing wave function and derivative to calculate.
// is_it_real_bound_state_case : true if one has a bound state with a real potential , false if not

void Jost_WS_potential_fit::Jost_outgoing_wf_dwf (
						  const enum particle_type particle , 
						  const class potentials_effective_mass &T , 
						  const double R , 
						  complex<double> &wf_plus , 
						  complex<double> &dwf_plus)
{
  const enum potential_type potential = T.get_potential ();
  
  const int l = T.get_l_integer ();

  const complex<double> k = T.get_k ();

  const bool is_it_real_bound_state_case = (real (k) == 0.0) && (imag (k) >= 0.0) && (potential != COMPLEX_WS) && (potential != COMPLEX_INTERPOLATED_POTENTIAL);
  
  if (k == 0.0)
    {
      const int Z_charge = T.get_Z_charge ();
      
      const int particle_charge = particle_charge_determine (particle);
      
      const int Z_charge_times_particle_charge = Z_charge*particle_charge;
			 
      const double kinetic_factor = T.get_kinetic_factor ();

      const double l_term = 2.0*l + 0.5;

      const double two_sqrt_Vc = 2.0*sqrt (kinetic_factor*Z_charge*Coulomb_constant);

      const complex<double> Il_term(0 , l_term);

      const complex<double> two_I_sqrt_Vc(0.0 , two_sqrt_Vc);

      const complex<double> norm_k_is_zero = exp (Il_term*M_PI_2);

      class Coulomb_wave_functions cwf_zero_k(true , l_term , 0.0);

      wf_dwf_k_is_zero (l , Z_charge_times_particle_charge , two_I_sqrt_Vc , norm_k_is_zero , cwf_zero_k , R , wf_plus , dwf_plus);
      
      if (is_it_real_bound_state_case)
	{
	  wf_plus = real (wf_plus);

	  dwf_plus = real (dwf_plus);
	}
    }
  else if ((potential == PTG_POTENTIAL) || (potential == EFFECTIVE_MASS_POTENTIAL_PTG_LIKE))
    {
      const complex<double> Ik(-imag (k) , real (k));
      
      wf_plus = exp (Ik*R);

      dwf_plus = Ik*wf_plus;

      if (is_it_real_bound_state_case)
	{
	  wf_plus = real (wf_plus);

	  dwf_plus = real (dwf_plus);
	}
    }
  else
    {   
      const complex<double> eta = T.get_eta ();
      
      class Coulomb_wave_functions cwf(true , l , eta);
      
      if (is_it_real_bound_state_case)
	{
	  cwf.Wm_kz_dWm_kz (k , R , wf_plus , dwf_plus);

	  wf_plus = real (wf_plus);
	  dwf_plus = real (dwf_plus);
	}
      else
	cwf.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);
  
      if (!finite (wf_plus) || !finite (dwf_plus) || (wf_plus == 0.0) || (dwf_plus == 0.0))
	{
	  class Coulomb_wave_functions cwf_renormalization(false , l , eta);

	  cwf_renormalization.H_kz_dH_kz (1 , k , R , wf_plus , dwf_plus);
	}
    }
}









// Calculation of the Jost function (up to one multiplication factor) :
// --------------------------------------------------------------------
// The k eigenvalues are zeros of this function.
// To calculate it in the general case, one integrates the Schrodinger equation from r0 close to zero to matching_point and from R (where |Vnuclear|~0) to matching_point. 
// u(r0) = C0.r0^{l+1} and u(R)=C+.H+[k.R]. 
// The Jost function is then the difference of the two log derivatives in matching_point for the nucleon case.
// One takes J(k) = u'(r_match+) u(r_match-) - u'(r_match-) u(r_match+) for electron are calculations are less stable therein.
//
// If one considers the modified PTG potential, one uses analytical formulas to obtain the wave function at r = R as the wave function is a PTG wave function for r <= R.
// 
// Variables :
// -----------
// particle: proton, neutron or electron
// Z_charge : charge of the target
// T : it contains the potential to integrate.
// R : point after which |Vnuclear| ~ 0.
// matching_point : point where the wave functions integrated forward and backward match.
// potential : type of potential one integrates.
// r0 : point where one begins the integration of the Schrodinger equation.
//      Before this point , one approximates the wave function by r^{l+1}
// l , l_plus_one : angular momentum, l + 1.
// kinetic_factor : 2.mu/hbar^2 , with mu the reduced mass
// E , k : E is the energy of the state and k is the linear momentum. E = k*k/kinetic_factor.
// eta: Sommerfeld parameter
// ODE : class ODE_integration with which one integrates the wave function from one point to another. 
// cwf : Coulomb wave function class to calculate u(R) and du/dr(R).
// u_minus , du_minus : u(matching_point-) et u'(matching_point-) , calculated from r0. 
// u_plus , du_plus : u(matching_point+) et u'(matching_point+) , calculated from R.
// u_plus_debut , du_plus_debut , u_minus_debut , du_minus_debut: starting points for direct integration of u+/- and du+/- 
// step_minus , step_plus : step for direct integration between r0 and matching_point , and between matching_point and R.
// matching_point_before, matching_point_after: matching_point +/- sqrt_precision. It is for the extremely rare cases where u+ or u- are extremely small, i.e. u+/-(r ~ matching_point) = 0.
//                                              One then calculates the Jost at radii close to matching_point and one approximates the Jost functions by their average.
//                                              It cannot happen with the modified PTG potential as matching_point = r_asy therein.
// PTG_potential: PTG potential
// r_asy , E_barrier : radius defining the asymptotic zone and height of the barrier of the modified PTG potential (see potentials.h and potentials.cpp)
// nu_mass_equivalent : kinetic_factor/two_amu_over_hbar_square, so that the u_PTG kinetic factor calculated without recoil (mass_modif = 0) is the same as the exact kinetic factor, where recoil correction is presetn in general.
// E_no_barrier , k_no_barrier : equivalent energy and the linear momentum with a PTG Hamiltonian, with E_no_barrier = E - E_barrier.
//                               The analytical wave function of the PTG Hamiltonian is the same as as that of the modified PTG potential up to this change.
// nmax_PTG: maximal principal quantum number of the PTG potential. It is equal to 10 as one cannot reach this value in practice.
// S_matrix_pole_PTG, n_PTG : true if the k-value is that of an S-matrix pole of the PTG potential, false if not, principal quantum number of the S-matrix pole (NADA if it is not an S-matrix pole)
// u_PTG : wave function of the modified PTG Hamiltonian. As u_PTG is calculated for the Jost function, only u(R) and u'(R) are needed, so that only two radii are considered , r=0 (necessary) and r=R.
// wf_bef_R_tab , dwf_bef_R_tab : wave function and derivative on [0:R] with 2 points

complex<double> Jost_WS_potential_fit::Jost (
					     const class potentials_effective_mass &T , 
					     const enum particle_type particle , 
					     const double R , 
					     const double matching_point , 
					     const complex<double> &C0 , 
					     const complex<double> &Cplus)
{
  const int l = T.get_l_integer ();
  
  const enum potential_type potential = T.get_potential ();
  
  complex<double>  u_plus = 0.0;
  complex<double> du_plus = 0.0;
      
  if (potential == MODIFIED_PTG_POTENTIAL)
    {
      // R and matching_point are not used here as one does not integrate numerically. R and matching_point are replaced by r_asy.
            
      const double kinetic_factor = T.get_kinetic_factor ();
      
      const complex<double> E = T.get_E ();

      const class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();

      const double Lambda = modified_PTG_potential.get_Lambda ();

      const double s = modified_PTG_potential.get_s ();
	  
      const double nu = modified_PTG_potential.get_nu ();
	
      const double a = modified_PTG_potential.get_a ();	
  
      const double r_asy  = modified_PTG_potential.get_r_asy ();
      
      const double E_barrier = modified_PTG_potential.get_E_barrier ();
  
      const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
        
      const double nu_mass_equivalent = kinetic_factor/two_amu_over_hbar_square;
  
      const complex<double> E_no_barrier = E - E_barrier;

      const complex<double> k_no_barrier = sqrt_mod (kinetic_factor*E_no_barrier);
      
      const int nmax_PTG = 10;

      bool S_matrix_pole_PTG = false;

      int n_PTG = NADA;
      
      for (int n = 0 ; (n <= nmax_PTG) && (!S_matrix_pole_PTG) ; n++)
	{	  
	  const complex<double> kn_PTG = PTG_potential.k_pole_calc (n);

	  if (inf_norm (kn_PTG - k_no_barrier) < precision) S_matrix_pole_PTG = true , n_PTG = n;
	  if (inf_norm (kn_PTG + k_no_barrier) < precision) S_matrix_pole_PTG = true , n_PTG = n; 
	}
      
      class spherical_state u_PTG(false , false , PTG_POTENTIAL , NADA , 0 , 0 , 0 , 0 , 0 , 2 , 0 , 0 , 0 , r_asy , NADA , r_asy , r_asy , 0 , 0 ,
				  S_matrix_pole_PTG , particle , n_PTG , NADA , l , NADA , false , k_no_barrier , nu_mass_equivalent , 1 , 1);

      u_PTG.PTG_eigenstate_calc (false , PTG_potential);

      const class array<complex<double> > &wf_bef_R_tab  = u_PTG.get_wf_bef_R_tab_uniform ();
      const class array<complex<double> > &dwf_bef_R_tab = u_PTG.get_dwf_bef_R_tab_uniform ();
      
      const complex<double> u_minus  =  wf_bef_R_tab(1);
      const complex<double> du_minus = dwf_bef_R_tab(1);
  	  
      Jost_outgoing_wf_dwf (particle , T , r_asy , u_plus , du_plus);
      
      const complex<double> Jost_k = du_plus/u_plus - du_minus/u_minus;
      
      return Jost_k;
    }    
  else
    {
      const int l_plus_one = l + 1;

      const double r0 = 0.005*sqrt (l*l_plus_one);

      class ODE_integration ODE (&T , &potentials_effective_mass_F_z_u);

      complex<double> u_minus = C0*pow (r0 , l_plus_one);

      complex<double> du_minus = C0*l_plus_one*pow (r0 , l);

      const unsigned int NN = 50;
  
      const double step_minus = (matching_point - r0)/NN;

      const double step_plus = (matching_point - R)/NN;
      
      for (unsigned int i = 1 ; i <= NN ; i++)
	{
	  const double r_previous = r0 + (i - 1)*step_minus;

	  const double r = r0 + i*step_minus;
      
	  const complex<double>  u_minus_debut =  u_minus;
	  const complex<double> du_minus_debut = du_minus;
      
	  ODE (r_previous , u_minus_debut , du_minus_debut , r , u_minus , du_minus);
	}
      
      Jost_outgoing_wf_dwf (particle , T , R , u_plus , du_plus);
      
      u_plus  *= Cplus;
      du_plus *= Cplus;
      
      for (unsigned int i = 1 ; i <= NN ; i++)
	{
	  const double r_previous = R + (i-1)*step_plus;

	  const double r = R + i*step_plus;
      
	  const complex<double> u_plus_debut = u_plus;

	  const complex<double> du_plus_debut = du_plus;
      
	  ODE (r_previous , u_plus_debut , du_plus_debut , r , u_plus , du_plus);
	}

      if ((inf_norm (u_plus) < precision) || (inf_norm (u_minus) < precision))
	{
	  const double matching_point_before = matching_point - sqrt_precision;
	  const double matching_point_after  = matching_point + sqrt_precision;
      
	  const complex<double> u_minus_debut = u_minus , du_minus_debut = du_minus;
	  const complex<double> u_plus_debut  = u_plus  , du_plus_debut  = du_plus;
      
	  ODE (matching_point , u_plus_debut  , du_plus_debut  , matching_point_before , u_plus  , du_plus);
	  ODE (matching_point , u_minus_debut , du_minus_debut , matching_point_before , u_minus , du_minus);
      
	  const complex<double> Jost_k_before = du_plus/u_plus - du_minus/u_minus;
      
	  ODE (matching_point , u_plus_debut  , du_plus_debut  , matching_point_after , u_plus  , du_plus);
	  ODE (matching_point , u_minus_debut , du_minus_debut , matching_point_after , u_minus , du_minus);
      
	  const complex<double> Jost_k_after = du_plus/u_plus - du_minus/u_minus;
      
	  const complex<double> Jost_k = 0.5*(Jost_k_before + Jost_k_after);
      
	  return Jost_k;
	}
      else
	{
	  const complex<double> Jost_k = (particle == ELECTRON) ? (du_plus*u_minus - du_minus*u_plus) : (du_plus/u_plus - du_minus/u_minus);
      
	  return Jost_k;
	}
    }
}













// Calculation of Vo[energy] with the quadratic method: 
// ------------------------------------------------
// Vpoly(x) = a[2].x^2 + a[1].x + a[0] with x = Re[E(Vpoly)]-Re[E(V)].
//
// Details for the calculation of the quadratic regression method :
// ----------------------------------------------------------------
// Calculation of the coefficients a[i] of Vpoly(x) = a[2].x^2 + a[1].x + a[0] with x = Re[E(Vpoly)] - Re[E(V)].
// One first has to see x as a function of Vpoly : 
// Indeed , the polynomial coefficients are fixed by :
// V=a[0] as x = Re[E(V)] - Re[E(V)] = 0
// V + h = a[2].xh^2 + a[1].xh + a[0] with xh = Re[E(V + h)] - Re[E(V)]
// V + 2h = a[2].x2h^2 + a[1].x2h + a[0] with x2h = Re[E(V + 2h)] - Re[E(V)]
// Once we have the coefficients a[0] , a[1] , a[2] , one calculates V = Vpoly(x) , with x = energy - Re[E(V)]
// which is supposed to be close to the V_exact (Re[E(V_exact)] = energy).
//
// Variables
// ---------
// problem : VO_SEARCH if one looks for Vo , VSO_SEARCH if one looks for Vso.
// wf : wave function of which one wants Re[E] = energy.
// h : if one has VO_SEARCH  , one calculates the energy of wf for Vo +  h and Vo  + 2h , to apply the quadratic method.
//     if one has VSO_SEARCH , one calculates the energy of wf for Vso + h and Vso + 2h , to apply the quadratic method.
// energy : wanted energy.
// energy_V : energy of the state with the initial values of Vo and Vso.
// Vo : current value of the depth of the potential. 
//      It is changed at the end with the quadratic regression method if one has VO_SEARCH.
// Vso : current value of the spin-orbit strength of the potential.
//       It is changed at the end with the quadratic regression method if one has VSO_SEARCH.
// Vo_plus_h , Vo_plus_2h : if one has VO_SEARCH  , Vo is looked for so that Vo_plus_h = Vo_plus_2h = Vo.
//                          If one has VSO_SEARCH , Vo is looked for so that Vo_plus_h = Vo_plus_2h = Vo.
// energy_V_plus_h  : energy of the state with Vo + h  if one has VO_SEARCH , Vso + h  if one has VSO_SEARCH.
// energy_V_plus_2h : energy of the state with Vo + 2h if one has VO_SEARCH , Vso + 2h if one has VSO_SEARCH.
// x_h , x_2h : energy_V_plus_h - energy_V , energy_V_plus_2h - energy_V
// Determinant : determinant of the linear system which gives the coefficients of the polynom.
// a : coefficients of the polynom.

void Jost_WS_potential_fit::V_from_polynomial (
					       const enum problem_type problem , 
					       class potentials_effective_mass &T , 
					       class spherical_state &wf , 
					       const double h , 
					       const double energy , 
					       const double energy_V , 
					       double &Vo , 
					       double &Vso)
{
  const enum potential_type potential = wf.get_potential ();

  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
  
  const double Vo_plus_h  = (problem == VO_SEARCH)  ? (Vo  + h) : (Vo)  , Vo_plus_2h  = (problem == VO_SEARCH)  ? (Vo  + 2.0*h) : (Vo);
  const double Vso_plus_h = (problem == VSO_SEARCH) ? (Vso + h) : (Vso) , Vso_plus_2h = (problem == VSO_SEARCH) ? (Vso + 2.0*h) : (Vso);

  if (potential == WS_ANALYTIC)
    {
      WS_analytic_potential.set_Vo (Vo_plus_h);
      
      WS_analytic_potential.set_Vso (Vso_plus_h);
    }
  else
    {
      WS_potential.set_Vo (Vo_plus_h);
      
      WS_potential.set_Vso (Vso_plus_h);
    }
  
  wf.reject ();

  wf.k_search (T , true , true);
  
  const double energy_V_plus_h = real (wf.get_E ()); 

  if (potential == WS_ANALYTIC)
    {
      WS_analytic_potential.set_Vo (Vo_plus_2h);
      
      WS_analytic_potential.set_Vso (Vso_plus_2h);
    }
  else
    {
      WS_potential.set_Vo (Vo_plus_2h);
      
      WS_potential.set_Vso (Vso_plus_2h);
    }

  wf.reject ();

  wf.k_search (T , true , true);
  
  const double energy_V_plus_2h = real (wf.get_E ());

  const double x_h = energy_V_plus_h - energy_V;

  const double x_2h = energy_V_plus_2h - energy_V;

  const double Determinant = x_h*x_2h*(x_2h - x_h);
  
  class array<double> a(3);

  a(2) = h*(2.0*x_h - x_2h)/Determinant;
  
  a(1) = h*(x_2h*x_2h - 2.0*x_h*x_h)/Determinant;

  switch (problem)
    {
    case VO_SEARCH:
      {
	a(0) = Vo;

	Vo = polynomial_evaluation<double> (2 , a , energy - energy_V);
      } break;

    case VSO_SEARCH:
      {
	a(0) = Vso;
	
	Vso = polynomial_evaluation<double> (2 , a , energy - energy_V);
      } break;

    default: abort_all ();
    }
}



void Jost_WS_potential_fit::complex_V_from_polynomial (
						       const enum problem_type problem , 
						       class potentials_effective_mass &T , 
						       class spherical_state &wf , 
						       const complex<double> &h , 
						       const complex<double> &energy , 
						       const complex<double> &energy_V , 
						       complex<double> &Vo , 
						       complex<double> &Vso)
{
  const enum potential_type potential = wf.get_potential ();

  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();

  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

  const complex<double> Vo_plus_h  = (problem == VO_SEARCH)  ? (Vo  + h) : (Vo)  , Vo_plus_2h  = (problem == VO_SEARCH)  ? (Vo  + 2.0*h) : (Vo);
  const complex<double> Vso_plus_h = (problem == VSO_SEARCH) ? (Vso + h) : (Vso) , Vso_plus_2h = (problem == VSO_SEARCH) ? (Vso + 2.0*h) : (Vso);

  if (potential == COMPLEX_WS_ANALYTIC)
    {
      WS_complex_analytic_potential.set_Vo (Vo_plus_h);
      
      WS_complex_analytic_potential.set_Vso (Vso_plus_h);
    }
  else
    {
      WS_complex_potential.set_Vo (Vo_plus_h);
      
      WS_complex_potential.set_Vso (Vso_plus_h);
    }
  
  wf.reject ();

  wf.k_search (T , true , true);
  
  const complex<double> energy_V_plus_h = wf.get_E (); 

  if (potential == COMPLEX_WS_ANALYTIC)
    {
      WS_complex_analytic_potential.set_Vo (Vo_plus_2h);
      
      WS_complex_analytic_potential.set_Vso (Vso_plus_2h);
    }
  else
    {
      WS_complex_potential.set_Vo (Vo_plus_2h);
      
      WS_complex_potential.set_Vso (Vso_plus_2h);
    }

  wf.reject ();

  wf.k_search (T , true , true);
  
  const complex<double> energy_V_plus_2h = wf.get_E ();

  const complex<double> x_h = energy_V_plus_h - energy_V;

  const complex<double> x_2h = energy_V_plus_2h - energy_V;

  const complex<double> Determinant = x_h*x_2h*(x_2h - x_h);
  
  class array<complex<double> > a(3);

  a(2) = h*(2.0*x_h - x_2h)/Determinant;
  
  a(1) = h*(x_2h*x_2h - 2.0*x_h*x_h)/Determinant;

  switch (problem)
    {
    case VO_SEARCH:
      {
	a(0) = Vo;

	Vo = polynomial_evaluation<complex<double> > (2 , a , energy - energy_V);
      } break;

    case VSO_SEARCH:
      {
	a(0) = Vso;
	
	Vso = polynomial_evaluation<complex<double> > (2 , a , energy - energy_V);
      } break;

    default: abort_all ();
    }
}






// Determination of a potential V at energy=Re[E] fixed : quadratic regression method :
//-------------------------------------------------------------------------------------
// This potential V can be Vo (problem=0) or Vso (problem=1). 
// Method : _one calculates the state energy for V , V+h , V+2.h , with h=V.1E-5; 
//          _one calculates the new V assuming its variation quadratic with Re[E]; 
//          _one iterates until convergence , when Re[E(V)]=energy. 
// For the calculation of Re[E(V)] , 
// one use k_debut as a starting k because it is far from k=0.
// If Re[E(V)] is energy at the demanded precision , it is finished.
//
// Variables :
// -----------
// h , minus_sign_energy : one calculates the "small step" h so E[V+(2)h] is as far as possible from 0
// As V>0 by definition , minus_sign_energy must be -sign(e).
// Also , to avoid Jost_WS_potential_fit::repeated V giving E=0 , h is calculated randomly on [0:(+ or -)0.1 MeV]
// test : convergence test of e; test=|e(n)/e(n-1)-1| 
// energy_V : Re[E(V)] , V fixed.
// x , a[3] , D : x=energy_V_plus_(2)h-energy_ , 
//            coefficients so V(x)~a[2].x^2+a[1].x+V(e0) , 
//            determinant appearing in the a[..] 
// The energy_V.._plus_(2)h corresponding to the other V are put equal to the other V , 
// though their names say the opposite.
// k_debut : starting k the farest from 0 


void Jost_WS_potential_fit::V_for_fixed_E (
					   const enum potential_type potential , 
					   const int A , 
					   const int Z_charge , 
					   const double nu_mass , 
					   const double target_mass , 
					   const unsigned int N_GL , 
					   const unsigned int N_uniform , 
					   const double R , 
					   const double matching_point , 
					   const double R_real_max ,
					   const double kinetic_factor , 
					   class potentials_effective_mass &T , 
					   const enum particle_type particle , 
					   const int n , 
					   const int l , 
					   const double j , 
					   const enum problem_type problem ,
					   const bool is_it_bound ,
					   complex<double> &k)
{
  if (particle == ELECTRON) error_message_print_abort ("No electron in V_for_fixed_E");

  const double energy = real (k*k)/kinetic_factor;

  const int h_sign = (is_it_bound) ? (1) : (-1);

  class WS_class &WS_potential = T.get_WS_potential ();

  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , true , k , nu_mass , 1 , 1);

  wf.k_search (T , true , true);
  
  const complex<double> E_start = wf.get_E ();

  double energy_V = real (E_start);

  double test = 1.0;

  unsigned int count = 0;

  do
    {  
      double h = 0.0;
      
      double Vo  = (potential == WS) ? (WS_potential.get_Vo ())  : (WS_analytic_potential.get_Vo ());
      double Vso = (potential == WS) ? (WS_potential.get_Vso ()) : (WS_analytic_potential.get_Vso ());
      
      while (abs (h) < 1E-5) h = 0.1*random_number<double> ()*h_sign;

      V_from_polynomial (problem , T , wf , h , energy , energy_V , Vo , Vso);

      if (potential == WS_ANALYTIC)
	{
	  WS_analytic_potential.set_Vo (Vo);
	  
	  WS_analytic_potential.set_Vso (Vso);
	}
      else
	{
	  WS_potential.set_Vo (Vo);
	  
	  WS_potential.set_Vso (Vso);
	}
  
      wf.reject ();

      wf.k_search (T , true , true);
      
      energy_V = real (wf.get_E ());
      
      wf.set_k_search_start (wf.get_k ());

      test = abs (energy_V/energy - 1.0);

      if (count++ > 100)  error_message_print_abort ("Inverse quadratic search failed. Try with a new starting potential.");
    } 
  while (test > precision);
  
  k = wf.get_k ();

  if (!is_it_bound && (imag (k) > 0.0)) error_message_print_abort ("Inverse quadratic search ended on a bound state while searching for an unbound state. Try with a new starting potential.");
  if (is_it_bound  && (imag (k) < 0.0)) error_message_print_abort ("Inverse quadratic search ended on an unbound state while searching for a bound state. Try with a new starting potential.");

} 







void Jost_WS_potential_fit::complex_V_for_fixed_E (
						   const enum potential_type potential , 
						   const int A , 
						   const int Z_charge , 
						   const double nu_mass , 
						   const double target_mass , 
						   const unsigned int N_GL , 
						   const unsigned int N_uniform , 
						   const double R , 
						   const double matching_point , 
						   const double R_real_max ,
						   const double kinetic_factor , 
						   class potentials_effective_mass &T , 
						   const enum particle_type particle , 
						   const int n , 
						   const int l , 
						   const double j , 
						   const enum problem_type problem ,
						   const bool is_it_bound ,
						   complex<double> &k)
{
  if (particle == ELECTRON) error_message_print_abort ("No electron in complex_V_for_fixed_E");

  const complex<double> energy = k*k/kinetic_factor;

  const int h_sign = (is_it_bound) ? (1) : (-1);

  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R , 
			   true , particle , n , NADA , l , j , true , k , nu_mass , 1 , 1);
  
  wf.k_search (T , true , true);

  complex<double> energy_V = wf.get_E ();

  double test = 1.0;

  unsigned int count = 0;

  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();

  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

  do
    {
      complex<double> h = 0.0;

      complex<double> Vo  = (potential == COMPLEX_WS) ? (WS_complex_potential.get_Vo ())  : (WS_complex_analytic_potential.get_Vo ());
      complex<double> Vso = (potential == COMPLEX_WS) ? (WS_complex_potential.get_Vso ()) : (WS_complex_analytic_potential.get_Vso ());

      while (abs (h) < 1E-5) h = 0.1*random_number<complex<double> > ()*h_sign;

      complex_V_from_polynomial (problem , T , wf , h , energy , energy_V , Vo , Vso);

      if (potential == COMPLEX_WS_ANALYTIC)
	{
	  WS_complex_analytic_potential.set_Vo (Vo);
	  
	  WS_complex_analytic_potential.set_Vso (Vso);
	}
      else
	{
	  WS_complex_potential.set_Vo (Vo);
	  
	  WS_complex_potential.set_Vso (Vso);
	}
  
      wf.reject ();

      wf.k_search (T , true , true);

      energy_V = wf.get_E ();
      
      wf.set_k_search_start (wf.get_k ());

      test = abs (energy_V/energy - 1.0);

      if (count++ > 100)  error_message_print_abort ("Inverse quadratic search failed. Try with a new starting potential.");
    } 
  while (test > precision);

  k = wf.get_k ();

  if (!is_it_bound  && (imag (k) > 0.0)) error_message_print_abort ("Inverse quadratic search ended on a bound state while searching for an unbound state. Try with a new starting potential.");
  if (is_it_bound   && (imag (k) < 0.0)) error_message_print_abort ("Inverse quadratic search ended on an unbound state while searching for a bound state. Try with a new starting potential.");
} 


