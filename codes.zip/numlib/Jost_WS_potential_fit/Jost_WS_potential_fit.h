#ifndef JOST_WS_POTENTIAL_FIT_H
#define JOST_WS_POTENTIAL_FIT_H

namespace Jost_WS_potential_fit
{
  void Jost_outgoing_wf_dwf (
			     const enum particle_type particle , 
			     const class potentials_effective_mass &T , 
			     const double R , 
			     complex<double> &wf_plus , 
			     complex<double> &dwf_plus);

  complex<double> Jost (
			const class potentials_effective_mass &T , 
			const enum particle_type particle , 
			const double R , 
			const double matching_point , 
			const complex<double> &C0 , 
			const complex<double> &Cplus);

  void V_from_polynomial (
			  const enum problem_type problem , 
			  class potentials_effective_mass &T , 
			  class spherical_state &wf , 
			  const double h , 
			  const double energy , 
			  const double energy_V , 
			  double &Vo , 
			  double &Vso);

  void complex_V_from_polynomial (
				  const enum problem_type problem , 
				  class potentials_effective_mass &T , 
				  class spherical_state &wf , 
				  const complex<double> &h , 
				  const complex<double> &energy , 
				  const complex<double> &energy_V , 
				  complex<double> &Vo , 
				  complex<double> &Vso);

  void V_for_fixed_E (
		      const enum potential_type potential , 
		      const int A , 
		      const int Z_charge , 
		      const double nu_mass , 
		      const double target_mass , 
		      const unsigned int N_GL , 
		      const unsigned int N_big , 
		      const double R , 
		      const double matching_point , 
		      const double R_real_max ,
		      const double kinetic_factor , 
		      class potentials_effective_mass &T , 
		      const enum particle_type particle , 
		      const int n , 
		      const int l , 
		      const double j , 
		      const enum problem_type problem , 
		      const bool is_it_bound ,
		      complex<double> &k);

  void complex_V_for_fixed_E (
			      const enum potential_type potential , 
			      const int A , 
			      const int Z_charge , 
			      const double nu_mass , 
			      const double target_mass , 
			      const unsigned int N_GL , 
			      const unsigned int N_big , 
			      const double R , 
			      const double matching_point , 
			      const double R_real_max ,
			      const double kinetic_factor , 
			      class potentials_effective_mass &T , 
			      const enum particle_type particle , 
			      const int n , 
			      const int l , 
			      const double j , 
			      const enum problem_type problem ,
			      const bool is_it_bound ,
			      complex<double> &k);
}

#endif
