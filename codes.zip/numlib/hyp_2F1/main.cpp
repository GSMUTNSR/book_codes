#include "../numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

    if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
    
#endif

    OpenMP_initialization ();

    cout.precision (8);

    const unsigned int N = 50;
    
    const unsigned int Nx = 100;
    
    const double A = 10;
    
    const double R = 5.0;
    
    const int nmax = 10;

    srand48 (time (NULL));
    
    cout << "2F1 function testing" << endl << endl;

    cout << "a   b   c   z   test" << endl << endl;

    for (unsigned int i = 0 ; i < N ; i++)
      {
	const complex<double> a(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));
	const complex<double> b(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));
	const complex<double> c(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));

	const complex<double> z(R*(random_number<double> () - 0.5) , R*(random_number<double> () - 0.5));

	const complex<double> Fz = hyp_2F1 (a , b , c , z);

	const double test = test_2F1 (a , b , c , z , Fz);

	cout << a << "  " << b << "  " << c << "  " << z << "  " << test << endl;
      }

    cout << endl << "a   b   c   z   z*  test (z ~ exp(i.pi/3))" << endl << endl;

    for (unsigned int i = 0 ; i < N ; i++)
      {
	const complex<double> a(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));
	const complex<double> b(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));
	const complex<double> c(A*(random_number<double> () - 0.5) , A*(random_number<double> () - 0.5));

	const complex<double> zp(0.5*(1.0 + 0.01*random_number<double> ()) ,  0.8660254*(1.0 + 0.01*random_number<double> ()));
	const complex<double> zm = conj (zp);

	const complex<double> Fzp = hyp_2F1 (a , b , c , zp);
	const complex<double> Fzm = hyp_2F1 (a , b , c , zm);

	const double test = max (test_2F1 (a , b , c , zp , Fzp) , test_2F1 (a , b , c , zm , Fzm));

	cout << a << "  " << b << "  " << c << "  " << zp << "  " << zm << " " << test << endl;
      }	

    cout << endl << "Jacobi polynomial testing" << endl << endl;

    class array<double> x_tab(Nx);
    class array<double> w_tab(Nx);

    Gauss_Legendre::abscissas_weights_tables_calc (-1.0 , 1.0 , x_tab , w_tab);

    const complex<double> a(5*random_number<double> () + 1 , 0.1*(random_number<double> () - 0.5));
    const complex<double> b(5*random_number<double> () + 1 , 0.1*(random_number<double> () - 0.5));

    cout << "a:" << a << endl;
    cout << "b:" << b << endl << endl;

    class array<complex<double> > P_tab(nmax+1 , Nx);
    
    class array<complex<double> > pow_tab(Nx);

    for (int n = 0 ; n <= nmax ; n++)
      for (unsigned int ix = 0 ; ix < Nx ; ix++)
	{
	  const double x = x_tab(ix);

	  P_tab(n , ix) = Jacobi_polynomial(a , b , n , x);

	  pow_tab(ix) = pow (1.0 - x , a)*pow (1.0 + x , b);
	}

    for (int n = 0 ; n <= nmax ; n++)
      {
	const complex<double> Pn_squared_norm = pow (2.0 , a + b + 1.0)/(2.0*n + a  + b + 1.0)*exp (log_Gamma (n + a + 1) + log_Gamma (n + b + 1) - log_Gamma (n + a + b + 1) - log_Gamma (n + 1));

	for (int m = 0 ; m <= n ; m++)
	  {
	    complex<double> overlap = 0.0;

	    for (unsigned int ix = 0 ; ix < Nx ; ix++)
	      {
		const double w = w_tab(ix);

		overlap += pow_tab(ix)*P_tab(n , ix)*P_tab(m , ix)*w;
	      }

	    const double test = (n == m) ? (inf_norm (overlap/Pn_squared_norm - 1.0)) : (inf_norm (overlap/Pn_squared_norm));

	    cout << "n:" << n << "   m:" << m << "   test:" << test << endl;
	  }
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

