#include "../../numlib/numlib_def/numlib_def.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace angular_matrix_elements;
using namespace Wigner_signs;
using namespace string_routines;




double Y20 (
	    const int l_in , 
	    const double j_in , 
	    const int l_out , 
	    const double j_out , 
	    const double m)
{
  const double reduced_OBME = OBME_YL_reduced_in_j (2 , l_in , j_in , l_out , j_out);

  const double OBME = ME_dereduced (reduced_OBME , 2 , 0 , j_in , m , j_out , m);

  return OBME;
}




double OBME (const unsigned int i_in ,
	     const unsigned int i_out , 
	     const class array<int> &l_tab , 
	     const class array<double> &j_tab , 
	     const class array<double> &u_tab , 
	     const class array<double> &w_bef_R_GL , 
	     const class array<double> &HO_tab , 
	     const class array<double> &SO_tab , 
	     const class array<double> &V0_tab , 
	     const class array<double> &V2_tab ,
	     const double m)
{
  const int l_in = l_tab(i_in);
  
  const int l_out = l_tab(i_out);
  
  const double j_in = j_tab(i_in);

  const double j_out = j_tab(i_out);

  const bool is_it_ang_diag = same_lj (l_in , j_in , l_out , j_out);
  
  const double Y20_OBME = Y20 (l_in , j_in , l_out , j_out , m);

  if (!is_it_ang_diag && (Y20_OBME == 0.0)) return 0.0;

  const unsigned int N = u_tab.dimension (1);

  const unsigned int j_in_index = (l_in < j_in) ? (0) : (1);

  const unsigned int lj_in_index = 2*l_in - j_in_index;

  double OBME_val = 0.0;

  for (unsigned int i = 0 ; i < N ; i++)
    {
      double OBME_i = 0.0;

      if (Y20_OBME != 0.0) OBME_i = Y20_OBME*V2_tab(i);
      
      if (is_it_ang_diag) OBME_i += V0_tab(i) + SO_tab(lj_in_index , i) - HO_tab(i);

      OBME_i *= u_tab(i_in , i)*u_tab(i_out , i)*w_bef_R_GL(i);
  
      OBME_val += OBME_i;
    }
    
  return OBME_val;
}






void H_calc (
	     const int nmax ,
	     const int lmax , 
	     class array<int> &n_tab , 
	     class array<int> &l_tab , 
	     class array<double> &j_tab , 
	     const double d ,
	     const double R0_scaled ,
	     const double Vso ,
	     const class array<double> &r_bef_R_GL , 
	     const class array<double> &w_bef_R_GL ,  
	     const class array<double> &V0_tab , 
	     const class array<double> &V2_tab ,
	     const unsigned int binary_parity ,
	     const double m , 
	     const int A ,
	     const double kin_fact , 
	     class matrix<double> &H)
{
  const unsigned int N = r_bef_R_GL.dimension (0);
  
  const unsigned int N_shells = H.get_dimension ();

  const double b = pow (A , 0.16666666666666666666666);

  const double particle_mass_for_calc = two_amu_over_hbar_square/kin_fact;
  
  const class HO_class HO(false , 0.0 , particle_mass_for_calc , b);

  const double hbar_omega = HO.get_hbar_omega ();
  
  class array<double> u_tab(N_shells , N);

  class array<double> HO_tab(N);

  class array<double> SO_tab(2*lmax+1 , N);
		  
  for (unsigned int i = 0 ; i < N ; i++) HO_tab(i) = HO(r_bef_R_GL(i));

  unsigned int is = 0;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      if (binary_parity_from_orbital_angular_momentum (l) == binary_parity)
	{
	  for (unsigned int j_index = 0 ; (l == 0) ? (j_index <= 0) : (j_index <= 1) ; j_index++)
	    {
	      const double j = (j_index == 0) ? (l + 0.5) : (l - 0.5);
	  
	      if (rint (abs(m) - j) <= 0.0) 
		{
		  const class WS_class SO(false , d , R0_scaled , 0 , Vso , NEUTRON , NADA , NADA , l , j);
	      
		  for (unsigned int i = 0 ; i < N ; i++) SO_tab(2*l - j_index , i) = SO(r_bef_R_GL(i));

		  for (int n = 0 ; n <= nmax ; n++)
		    {
		      for (unsigned int i = 0 ; i < N ; i++) u_tab(is , i) = HO_wave_functions::HO_3D::u (b , n , l , r_bef_R_GL(i));
		  
		      is++;
		    }
		}
	    }
	}
    }
  
  for (unsigned int i = 0 ; i < N_shells ; i++)
    for (unsigned int ii = 0 ; ii <= i ; ii++)
      H(ii , i) = H(i , ii) = OBME (i , ii , l_tab , j_tab , u_tab , w_bef_R_GL , HO_tab , SO_tab , V0_tab , V2_tab , m);

  for (unsigned int i = 0 ; i < N_shells ; i++) H(i , i) += (2*n_tab(i) + l_tab(i) + 1.5)*hbar_omega;

}



void potential_tables_fill (
			    const enum particle_type particle ,
			    const double d ,
			    const double R0_scaled ,
			    const double Vo , 
			    const int Z_charge , 
			    const double beta_2 ,
			    const class array<double> &r_bef_R_GL , 
			    class array<double> &V0_tab , 
			    class array<double> &V2_tab)
{
  const unsigned int N = r_bef_R_GL.dimension(0);
  
  const class WS_analytic_class WS_pot(false , d , R0_scaled , Vo , 0 , particle , Z_charge , R0_scaled , NADA , NADA);
    
  const double def_const = R0_scaled*beta_2;

  for (unsigned int i = 0 ; i < N ; i++) 
    {
      const double r = r_bef_R_GL(i);
	  
      V0_tab(i) = WS_pot(r);
			     
      V2_tab(i) = def_const*WS_pot.R0_derivative_calc (r);
    }
}


unsigned int N_shells_calc (const int nmax , const int lmax , const unsigned int binary_parity , const double m)
{
  unsigned int N_shells = 0;

  for (int l = 0 ; l <= lmax ; l++)
    {
      if (binary_parity_from_orbital_angular_momentum (l) == binary_parity)
	{
	  for (unsigned int j_index = 0 ; (l == 0) ? (j_index <= 0) : (j_index <= 1) ; j_index++)
	    {
	      const double j = (j_index == 0) ? (l + 0.5) : (l - 0.5);

	      if (rint (abs(m) - j) <= 0.0)
		{
		  for (int n = 0 ; n <= nmax ; n++) N_shells++;
		}
	    }
	}
    }
  
  return N_shells;
}



void quantum_numbers_calc (const int nmax , const int lmax , 
			   const unsigned int binary_parity , const double m , 
			   class array<int> &n_tab , 
			   class array<int> &l_tab , 
			   class array<double> &j_tab)
{
  unsigned int is = 0;

  for (int l = 0 ; l <= lmax ; l++)
    {
      if (binary_parity_from_orbital_angular_momentum (l) == binary_parity)
	{
	  for (unsigned int j_index = 0 ; (l == 0) ? (j_index <= 0) : (j_index <= 1) ; j_index++)
	    {
	      const double j = (j_index == 0) ? (l + 0.5) : (l - 0.5);
	  
	      if (rint (abs(m) - j) <= 0.0)
		{
		  for (int n = 0 ; n <= nmax ; n++)
		    {
		      n_tab(is) = n; 
		      l_tab(is) = l; 
		      j_tab(is) = j;

		      is++;
		    }
		}
	    }
	}
    }
}


double Gamma_channels (const unsigned int binary_parity ,
		       const double m ,
		       const int lmax ,
		       const int Z_charge , 
		       const int A ,
		       const double kin_fact ,
		       const class array<int> &n_tab , 
		       const class array<int> &l_tab , 
		       const class array<double> &j_tab , 
		       const double eigenvalue ,
		       const class vector_class<double> &eigenvector ,
		       const double R_asy)
{
  const double b = pow (A , 0.16666666666666666666666);
  
  const double particle_mass_for_calc = two_amu_over_hbar_square/kin_fact;
  
  const class HO_class HO(false , 0.0 , particle_mass_for_calc , b);

  const unsigned int dimension = eigenvector.get_dimension ();

  const double k = sqrt (kin_fact*eigenvalue);

  const double eta = Coulomb_constant*Z_charge*kin_fact*0.5/k;

  class array<double> Cplus_lj(2*lmax + 1);
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      if (binary_parity_from_orbital_angular_momentum (l) == binary_parity)
	{
	  class Coulomb_wave_functions cwf (true , l , eta);

	  for (unsigned int j_index = 0 ; (l == 0) ? (j_index <= 0) : (j_index <= 1) ; j_index++)
	    {
	      const double j = (j_index == 0) ? (l + 0.5) : (l - 0.5);
	      
	      if (rint (abs(m) - j) <= 0.0)
		{
		  double sum_func = 0.0;
		
		  for (unsigned int i = 0 ; i < dimension ; i++)
		    {
		      const int li = l_tab(i);

		      const double ji = j_tab(i);
		    
		      if (same_lj (l , j , li , ji)) sum_func += eigenvector(i)*HO_wave_functions::HO_3D::u (HO.get_b () , n_tab(i) , l , R_asy);
		    }
		
		  complex<double> Hplus , dHplus;
		
		  cwf.H_kz_dH_kz (1 , k , R_asy , Hplus , dHplus);

		  Cplus_lj(2*l-j_index) = real (sum_func/Hplus);
		}
	    }
	}
    }
  
  double Gamma = 0.0;
  
  for (int l = 0 ; l <= lmax ; l++)
    {
      if (binary_parity_from_orbital_angular_momentum (l) == binary_parity)
	{
	  for (unsigned int j_index = 0 ; (l == 0) ? (j_index <= 0) : (j_index <= 1) ; j_index++)
	    {
	      const double j = (j_index == 0) ? (l + 0.5) : (l - 0.5);

	      const int lj_index = 2*l - j_index;
	      
	      if (rint (abs (m) - j) <= 0.0) Gamma += Cplus_lj(lj_index)*Cplus_lj(lj_index);
	    }
	}
    }
  
  Gamma *= 2000.0/kin_fact*k;
  
  return Gamma;
}



#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();

    const double Vo = 45;

    const double R = 80;

    const double d = 0.63;

    const double R0 = 7.9;

    const double Vso = 10;

    const double kin_fact = 0.0481931854870920814;

    const int A = 242;

    const int Z_charge = 92;

    const double beta_2 = 0.3;

    const double b2_scaled = beta_2 * sqrt (5.0/(4.0*M_PI));

    const double b2_scaled2 = b2_scaled*b2_scaled;

    const double b2_scaled3 = b2_scaled2*b2_scaled;

    const double integral = 2.0/35.0 * b2_scaled3 + 3.0/5.0 * b2_scaled2 + 1.0;

    const double const_vol_cond = cbrt (1.0/integral);

    const double R0_scaled = R0 * const_vol_cond;
  
    const enum particle_type particle = NEUTRON;

    const double m = 0.5;

    const int parity = 1;
  
    const unsigned int binary_parity = binary_parity_from_parity (parity);

    const unsigned int N = 100;

    class array<double> r_bef_R_GL(N);
    class array<double> w_bef_R_GL(N);

    class array<double> V0_tab(N);

    class array<double> V2_tab(N);
  
    Gauss_Legendre::abscissas_weights_tables_calc (0.0 , R , r_bef_R_GL , w_bef_R_GL);
  
    potential_tables_fill (particle , d , R0_scaled , Vo , Z_charge , beta_2 , r_bef_R_GL , V0_tab , V2_tab);
 
    const int nmax = 10 , lmax = 7;
  
    const unsigned int N_shells = N_shells_calc (nmax , lmax , binary_parity , m);
  
    class array<int> n_tab(N_shells);
    class array<int> l_tab(N_shells);
  
    class array<double> j_tab(N_shells);
  
    quantum_numbers_calc (nmax , lmax , binary_parity , m , n_tab , l_tab , j_tab);

    class matrix<double> H(N_shells); 

    H_calc (nmax , lmax , n_tab , l_tab , j_tab , d , R0_scaled , Vso , r_bef_R_GL , w_bef_R_GL , V0_tab , V2_tab , binary_parity , m , A , kin_fact , H);

    cout << "Matrix dimension : " << N_shells << endl << "Matrix_built" << endl << "Non zeros:" << H.non_zeros_proportion () << " %" << endl << endl;

    class array<double> E_tab(N_shells);
  
    total_diagonalization::symmetric::all_eigenpairs (H , E_tab);

    for (unsigned int i = 0 ; i < N_shells ; i++)
      {
	/*
	  unsigned int ii_max = 0;

	  double max_abs_eig_comp = 0.0;

	  for (unsigned int ii = 0 ; ii < N_shells ; ii++)
	  {
	  const double max_abs_eig_comp_try = abs (H.eigenvector(i)(ii));
	  
	  if (max_abs_eig_comp_try > max_abs_eig_comp) 
	  {
	  max_abs_eig_comp = max_abs_eig_comp_try;
	  ii_max = ii; 
	  }
	  }
	*/
      
	if (E_tab(i) < 0.0)
	  { 
	    cout << "E:" << E_tab(i) << " MeV" << endl;

	    /*
	      if (E_tab(i) > 0.0)
	      {
	      cout << "R_asy (fm) Gamma(from current formula) (10^{16} keV)" << endl;
	      for (unsigned int ii = 0 ; ii <= 100 ; ii++)
	      {
	      const double R_asy = 9.0 + 6.0*ii/100.0;
	      cout << R_asy << " " << Gamma_channels (binary_parity , m , lmax , Z_charge , A , kin_fact , n_tab , l_tab , j_tab , E_tab(i) , H.eigenvector(i) , R_asy)*1E16 << endl;
	      }
	      }
	    */

	    double proba = 0.0;
	  
	    for (unsigned int ii = 0 ; ii < N_shells ; ii++)
	      {
		if ((ii > 0) && !same_lj (l_tab(ii) , j_tab(ii) , l_tab(ii - 1) , j_tab(ii - 1)))
		  {
		    const int l = l_tab(ii - 1);

		    const double j = j_tab(ii - 1);
		  
		    cout << angular_state (l , j) << ":" << proba << endl;

		    proba = 0.0;
		  }
	      
		proba += H.eigenvector(i)(ii)*H.eigenvector(i)(ii);
	      }

	    cout << angular_state (l_tab(N_shells - 1) , j_tab(N_shells - 1)) << ":" << proba << endl;

	    cout << endl;
	  }
      }
  
#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

