#include "../../numlib/numlib_def/numlib_def.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


using namespace Jost_WS_potential_fit;
using namespace string_routines;

double best_b_HO_calc (const class spherical_state &wf)
{
  const double b_HO_step = 0.01;

  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf.get_N_aft_R_GL ();

  const int n = wf.get_n ();
  const int l = wf.get_l ();
	  
  const class array<double> &r_bef_R_tab_GL = wf.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf.get_w_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL = wf.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL = wf.get_w_aft_R_tab_GL_real ();
	  
  const class array<complex<double> > &wf_bef_R_tab_GL = wf.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_aft_R_tab_GL = wf.get_wf_aft_R_tab_GL_real ();

  class array<complex<double> > wf_w_bef_R_tab(N_bef_R_GL);
  class array<complex<double> > wf_w_aft_R_tab(N_bef_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_w_bef_R_tab(i) = wf_bef_R_tab_GL(i)*w_bef_R_tab_GL(i);
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) wf_w_aft_R_tab(i) = wf_aft_R_tab_GL(i)*w_aft_R_tab_GL(i);
  
  double b_HO_aft = 4.0 , b_HO = b_HO_aft - b_HO_step , b_HO_bef = b_HO;

  complex<double> overlap_bef = 0.0 , overlap = 0.0 , overlap_aft = 0.0;
  
  double abs_overlap_bef = 0.0 , abs_overlap = 0.0 , abs_overlap_aft = 0.0;
  
  double test = INFINITE;
	  
  bool is_b_HO_localized = false;
	  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
    {
      const complex<double> wf_w = wf_w_bef_R_tab(i);
	     
      overlap_bef += wf_w*HO_wave_functions::HO_3D::u (b_HO_bef , n , l , r_bef_R_tab_GL(i));
      overlap     += wf_w*HO_wave_functions::HO_3D::u (b_HO     , n , l , r_bef_R_tab_GL(i));
      
      abs_overlap_bef = abs (overlap_bef);
      abs_overlap     = abs (overlap);  
    }

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
    {
      const complex<double> wf_w = wf_w_aft_R_tab(i);
	      
      overlap_bef += wf_w*HO_wave_functions::HO_3D::u (b_HO_bef , n , l , r_aft_R_tab_GL(i));
      overlap     += wf_w*HO_wave_functions::HO_3D::u (b_HO     , n , l , r_aft_R_tab_GL(i));
      
      abs_overlap_bef = abs (overlap_bef);
      abs_overlap     = abs (overlap);  
    }

  while (!is_b_HO_localized)
    {
      b_HO_aft -= b_HO_step;
      
      overlap_aft = 0.0;
      
      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) overlap_aft += wf_w_bef_R_tab(i)*HO_wave_functions::HO_3D::u (b_HO_aft , n , l , r_bef_R_tab_GL(i));
      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) overlap_aft += wf_w_aft_R_tab(i)*HO_wave_functions::HO_3D::u (b_HO_aft , n , l , r_aft_R_tab_GL(i));
      
      abs_overlap_aft = abs (overlap_aft);
      
      is_b_HO_localized = ((abs_overlap > abs_overlap_bef) && (abs_overlap > abs_overlap_aft));
      
      if (!is_b_HO_localized)
	{
	  overlap_bef = overlap;
	  overlap     = overlap_aft;
	  
	  abs_overlap_bef = abs_overlap;
	  abs_overlap     = abs_overlap_aft;
	  
	  b_HO_bef = b_HO;		  
	  b_HO     = b_HO_aft;
	}

      if (b_HO_aft < 0)
	{
	  b_HO = 2.0;

	  cout << "No convergence for b[HO]. Default b[HO] : " << b_HO << " fm" << endl;

	  return b_HO;	  
	}
    }

  while (test > precision)
    {	
      complex<double> overlap_der = 0.0;
      complex<double> overlap_2der = 0.0;

      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) 
	{
	  const double r = r_bef_R_tab_GL(i);
	  
	  const double r_over_b = r/b_HO;
	  
	  const complex<double> wf_w = wf_w_bef_R_tab(i);
	  
	  const double u_HO_r_over_b   = HO_wave_functions::HO_3D::u   (1.0 , n , l , r_over_b);
	  const double du_HO_r_over_b  = HO_wave_functions::HO_3D::du  (1.0 , n , l , r_over_b);
	  const double d2u_HO_r_over_b = HO_wave_functions::HO_3D::d2u (1.0 , n , l , r_over_b);
	  
	  overlap_der -= wf_w*(0.5*u_HO_r_over_b + du_HO_r_over_b*r_over_b)*pow (b_HO , -1.5);
		  
	  overlap_2der += wf_w*(0.75*u_HO_r_over_b + (3.0*du_HO_r_over_b + d2u_HO_r_over_b*r_over_b)*r_over_b)*pow (b_HO , -2.5);
	}

      for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) 
	{
	  const double r = r_aft_R_tab_GL(i);
	  
	  const double r_over_b = r/b_HO;
	  
	  const complex<double> wf_w = wf_w_bef_R_tab(i);
	  
	  const double u_HO_r_over_b   = HO_wave_functions::HO_3D::u   (1.0 , n , l , r_over_b);
	  const double du_HO_r_over_b  = HO_wave_functions::HO_3D::du  (1.0 , n , l , r_over_b);
	  const double d2u_HO_r_over_b = HO_wave_functions::HO_3D::d2u (1.0 , n , l , r_over_b);
	  
	  overlap_der -= wf_w*(0.5*u_HO_r_over_b + du_HO_r_over_b*r_over_b)*pow (b_HO , -1.5);
		  
	  overlap_2der += wf_w*(0.75*u_HO_r_over_b + (3.0*du_HO_r_over_b + d2u_HO_r_over_b*r_over_b)*r_over_b)*pow (b_HO , -2.5);
	}
      
      const double db_HO = real (overlap_der/overlap_2der);
      
      b_HO -= db_HO;
      
      test = abs (db_HO);
    }
  
  return b_HO;
}




complex<double> overlap_wf_wf_HO_calc (
				       const double b_HO ,
				       const class spherical_state &wf)
{
  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf.get_N_aft_R_GL ();

  const int n = wf.get_n ();
  const int l = wf.get_l ();
	  
  const class array<double> &r_bef_R_tab_GL = wf.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf.get_w_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL = wf.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL = wf.get_w_aft_R_tab_GL_real ();
	  
  const class array<complex<double> > &wf_bef_R_tab_GL = wf.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_aft_R_tab_GL = wf.get_wf_aft_R_tab_GL_real ();

  class array<complex<double> > wf_w_bef_R_tab(N_bef_R_GL);
  class array<complex<double> > wf_w_aft_R_tab(N_bef_R_GL);

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) wf_w_bef_R_tab(i) = wf_bef_R_tab_GL(i)*w_bef_R_tab_GL(i);
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) wf_w_aft_R_tab(i) = wf_aft_R_tab_GL(i)*w_aft_R_tab_GL(i);
  
  complex<double> overlap = 0.0;
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++) overlap += wf_w_bef_R_tab(i)*HO_wave_functions::HO_3D::u (b_HO , n , l , r_bef_R_tab_GL(i));
  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++) overlap += wf_w_aft_R_tab(i)*HO_wave_functions::HO_3D::u (b_HO , n , l , r_aft_R_tab_GL(i));
    
  return overlap;
}






void WS_data (
	      const enum potential_type potential , 
	      const int l , 
	      const double j , 
	      double &d , 
	      double &R0 , 
	      int &A , 
	      double & nu_mass , 
	      double &target_mass , 
	      double &kinetic_factor , 
	      int &Z_charge , 
	      double &R_charge , 
	      double &matching_point , 
	      class potentials_effective_mass &T , 
	      const enum particle_type particle)
{
  cin >> d;
  word_check_print<double> ("fm(diffuseness)" , d);

  double Vo;  
  cin >> Vo;
  word_check_print<double> ("MeV(Vo)" , Vo);

  double Vso;  
  cin >> Vso; 
  word_check_print<double> ("MeV(Vso)" , Vso);

  if ((l == 0) && Vso != 0.0) error_message_print_abort ("Vso is zero by convention for s1/2 partial waves (WS data)");
  
  cin >> R0;  
  word_check_print<double> ("fm(R0)" , R0); 

  cout << endl;
  
  cin >> A;
  word_check_print<int> ("(A)" , A);

  const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
  if (!is_recoil_neglected)
    {
      cin >> target_mass;
      word_check_print<double> ("amu(mass)" , target_mass);

      if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
    }
  else
    target_mass = 0.0;
  
  cin >> nu_mass;
  word_check_print<double> ("amu(particle.mass)" , nu_mass);

  cout << endl;
  
  kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);

  if (particle_charge_determine (particle) != 0)
    {
      cin >> Z_charge;
      word_check_print<int> ("protons(target)" , Z_charge);

      cin >> R_charge;  
      word_check_print<double> ("fm(charge.radius)" , R_charge); 
    }

  matching_point = R0;

  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
	    
  if (potential == WS) WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
	  	
  if (potential == WS_ANALYTIC) WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
}



void complex_WS_data (
		      const enum potential_type potential , 
		      const int l , 
		      const double j , 
		      double &d , 
		      double &R0 , 
		      int &A , 
		      double &nu_mass , 
		      double &target_mass , 
		      double &kinetic_factor , 
		      int &Z_charge , 
		      double &R_charge , 
		      double &matching_point , 
		      class potentials_effective_mass &T , 
		      const enum particle_type particle)
{ 
  cin >> d;
  word_check_print<double> ("fm(diffuseness)" , d);

  complex<double> Vo;  
  cin >> Vo;
  word_check_print<complex<double> > ("MeV(Vo)" , Vo);

  complex<double> Vso;  
  cin >> Vso; 
  word_check_print<complex<double> > ("MeV(Vso)" , Vso);

  if ((l == 0) && Vso != 0.0) error_message_print_abort ("Vso is zero by convention for s1/2 partial waves (complex WS data)");

  cin >> R0;  
  word_check_print<double> ("fm(R0)" , R0); 

  cin >> A;
  word_check_print<int> ("(A)" , A);

  const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
  if (!is_recoil_neglected)
    {
      cin >> target_mass;
      word_check_print<double> ("amu(mass)" , target_mass);

      if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
    }
  else
    target_mass = 0.0;

  cin >> nu_mass;
  word_check_print<double> ("amu(particle.mass)" , nu_mass);

  kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);

  if (particle_charge_determine (particle) != 0)
    {
      cin >> Z_charge;
      word_check_print<int> ("protons(target)" , Z_charge);

      cin >> R_charge;  
      word_check_print<double> ("fm(charge.radius)" , R_charge); 
    }
  
  matching_point = R0;

  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();
  
  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();
  
  if (potential == COMPLEX_WS) WS_complex_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
	  	
  if (potential == COMPLEX_WS_ANALYTIC) WS_complex_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
}




void PTG_data (
	       const int l , 
	       int &A , 
	       double &nu_mass , 
	       double &target_mass , 
	       double &kinetic_factor , 
	       double &matching_point , 
	       class potentials_effective_mass &T)
{
  double Lambda;
  cin >> Lambda;
  word_check_print<double> ("(Lambda)" , Lambda);

  double s;
  cin >> s;
  word_check_print<double> ("(s)" , s);

  double nu;
  cin >> nu;
  word_check_print<double> ("(nu)" , nu);

  double a;
  cin >> a;
  word_check_print<double> ("(a)" , a);

  cin >> A;
  word_check_print<int> ("(A)" , A);
  
  const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
  if (!is_recoil_neglected)
    {
      cin >> target_mass;
      word_check_print<double> ("amu(mass)" , target_mass);

      if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
    }
  else
    target_mass = 0.0;

  cin >> nu_mass;
  word_check_print<double> ("amu(particle.mass)" , nu_mass);

  kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);

  matching_point = 5.0;

  class PTG_class &PTG_potential = T.get_PTG_potential ();
  
  PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);
}















void KKNN_data (
		const int l , 
		const double j , 
		int &A , 
		double &nu_mass , 
		double &target_mass , 
		double &kinetic_factor , 
		int &Z_charge , 
		double &R_charge , 
		double &matching_point , 
		class potentials_effective_mass &T , 
		const enum particle_type particle)
{
  double V0_KKNN[5];
  
  double rho_KKNN[5];
  
  double Vls_KKNN[3];
  
  double rho_ls_KKNN[3];

  for (unsigned int i = 0 ; i < 5 ; i++)
    {
      const string ip1_str = make_string<unsigned int> (i+1);

      cin >> V0_KKNN[i];
      word_check_print<double> ("(V0[" + ip1_str + "])" , V0_KKNN[i]);

      cin >> rho_KKNN[i];
      word_check_print<double> ("(rho[" + ip1_str + "])" , rho_KKNN[i]);
    }

  for (unsigned int i = 0 ; i < 3 ; i++)
    {
      const string ip1_str = make_string<unsigned int> (i+1);

      cin >> Vls_KKNN[i];
      word_check_print<double> ("(Vls[" + ip1_str + "])" , Vls_KKNN[i]);

      cin >> rho_ls_KKNN[i];
      word_check_print<double> ("(rho-ls[" + ip1_str + "])" , rho_ls_KKNN[i]);
    }

  cout << endl;

  cin >> A;
  word_check_print<int> ("(A)" , A);

  const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
  if (!is_recoil_neglected)
    {
      cin >> target_mass;
      word_check_print<double> ("amu(mass)" , target_mass);

      if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
    }
  else
    target_mass = 0.0;

  cin >> nu_mass;
  word_check_print<double> ("amu(particle.mass)" , nu_mass);

  kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);
  
  if (particle_charge_determine (particle) != 0)
    {
      cin >> Z_charge;
      word_check_print<int> ("protons(target)" , Z_charge);
      
      cin >> R_charge;  
      word_check_print<double> ("fm(charge.radius)" , R_charge); 
    }
  
  matching_point = 5.0;

  class KKNN_class &KKNN_potential = T.get_KKNN_potential ();
  
  KKNN_potential.initialize (false , V0_KKNN , rho_KKNN , Vls_KKNN , rho_ls_KKNN , particle , Z_charge , R_charge , l , j);
}


void numerical_potential_data (
			       const bool is_it_real ,
			       const enum particle_type particle,
			       int &A , 
			       double &nu_mass , 
			       double &target_mass , 
			       double &kinetic_factor , 
			       int &Z_charge , 
			       double &R_charge , 
			       double &matching_point , 
			       double &R , 
			       class potentials_effective_mass &T)
{
  string potential_name;
  cin >> potential_name;
  word_check_print<string> ("(potential.file.name)" , potential_name);

  ifstream potential_file(potential_name.c_str ());

  file_existence_check (potential_name , potential_file);
  
  const unsigned int N_potential = elements_number<string> (potential_name)/2;

  class array<double> r_table(N_potential);

  if (is_it_real)
    {
      class array<double> potential_table(N_potential);

      for (unsigned int i = 0 ; i < N_potential ; i++) potential_file >> r_table(i) >> potential_table(i);
  
      class splines_class<double> &V_interpolated = T.get_V_interpolated ();

      V_interpolated.allocate_calc (r_table , potential_table);
    }
  else
    {
      class array<complex<double> > potential_table(N_potential);

      for (unsigned int i = 0 ; i < N_potential ; i++) potential_file >> r_table(i) >> potential_table(i);
  
      class splines_class<complex<double> > &V_interpolated_complex = T.get_V_interpolated_complex ();

      V_interpolated_complex.allocate_calc (r_table , potential_table);
    }

  if (r_table(N_potential - 1) < R) error_message_print_abort ("The last potential radius must be larger than R");
  
  cin >> A;
  word_check_print<int> ("(A)" , A);

  const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
  if (!is_recoil_neglected)
    {
      cin >> target_mass;
      word_check_print<double> ("amu(mass)" , target_mass);

      if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
    }
  else
    target_mass = 0.0;

  cin >> nu_mass;
  word_check_print<double> ("amu(particle.mass)" , nu_mass);

  kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);

  if (particle_charge_determine (particle) != 0)
    {
      cin >> Z_charge;
      word_check_print<int> ("protons(target)" , Z_charge);
      
      cin >> R_charge;  
      word_check_print<double> ("fm(charge.radius)" , R_charge); 
    }
  
  matching_point = 5.0;
}











void E_approximations_modified_PTG_calc_print (
					       const enum particle_type particle ,
					       const int n ,
					       class potentials_effective_mass &T)
{      
  const int Z_charge = T.get_Z_charge (); 
		
  const double kinetic_factor = T.get_kinetic_factor ();
  
  const int l = T.get_l_integer ();
  
  const double j = T.get_j ();
  
  const class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();

  const double Lambda = modified_PTG_potential.get_Lambda ();

  const double s = modified_PTG_potential.get_s ();
	  
  const double nu = modified_PTG_potential.get_nu ();
	
  const double a = modified_PTG_potential.get_a ();	
  
  const double E_barrier = modified_PTG_potential.get_E_barrier ();
  
  const class PTG_class PTG_potential(kinetic_factor , l , Lambda , s , nu , a);
      
  const complex<double> k_PTG = PTG_potential.k_pole_calc (n);

  const complex<double> E_PTG = k_PTG*k_PTG/kinetic_factor;
  
  const complex<double> E_with_barrier = E_PTG + E_barrier;

  const double real_E_zeroth_order = real (E_with_barrier);

  const double Gamma_zeroth_order = (imag (E_with_barrier) != 0.0) ? (-2000.0*imag (E_with_barrier)) : (0.0); // Otherwise one can see -0 keV on screen.
  
  const complex<double> k_with_barrier = sqrt_mod (kinetic_factor*E_with_barrier);
  
  const complex<double> kr = (inf_norm (k_with_barrier) > sqrt_precision) ? (k_with_barrier) : (precision);

  const double two_sqrt_precision = 2.0*sqrt_precision;
  
  const complex<double> kr_plus  = kr + sqrt_precision;
  const complex<double> kr_minus = kr - sqrt_precision;
      
  const complex<double> kr_two_plus  = kr + two_sqrt_precision;
  const complex<double> kr_two_minus = kr - two_sqrt_precision;

  const complex<double> eta_kr = eta_calc (false , particle , Z_charge , kinetic_factor , kr);

  const complex<double> eta_kr_plus =  eta_calc (false , particle , Z_charge , kinetic_factor , kr_plus);
  const complex<double> eta_kr_minus = eta_calc (false , particle , Z_charge , kinetic_factor , kr_minus);
  
  const complex<double> eta_kr_two_plus =  eta_calc (false , particle , Z_charge , kinetic_factor , kr_two_plus);
  const complex<double> eta_kr_two_minus = eta_calc (false , particle , Z_charge , kinetic_factor , kr_two_minus);
  
  T.initialize_constants (MODIFIED_PTG_POTENTIAL , kinetic_factor , NADA , l , Z_charge , j , kr , eta_kr , NADA);

  const complex<double> Jost_kr = Jost (T , particle , NADA , NADA , NADA , NADA);

  T.initialize_constants  (MODIFIED_PTG_POTENTIAL , kinetic_factor , NADA , l , Z_charge , j , kr_plus  , eta_kr_plus , NADA);

  const complex<double> Jost_kr_plus  = Jost (T , particle , NADA , NADA , NADA , NADA);
  
  T.initialize_constants (MODIFIED_PTG_POTENTIAL , kinetic_factor , NADA , l , Z_charge , j , kr_minus , eta_kr_minus , NADA);

  const complex<double> Jost_kr_minus = Jost (T , particle , NADA , NADA , NADA , NADA);
  
  T.initialize_constants  (MODIFIED_PTG_POTENTIAL , kinetic_factor , NADA , l , Z_charge , j , kr_two_plus  , eta_kr_two_plus , NADA);

  const complex<double> Jost_kr_two_plus  = Jost (T , particle , NADA , NADA , NADA , NADA);
  
  T.initialize_constants (MODIFIED_PTG_POTENTIAL , kinetic_factor , NADA , l , Z_charge , j , kr_two_minus , eta_kr_two_minus , NADA);
  
  const complex<double> Jost_kr_two_minus = Jost (T , particle , NADA , NADA , NADA , NADA);
   
  const complex<double> Jost_kr_der = (Jost_kr_plus - Jost_kr_minus)/(kr_plus - kr_minus);
  
  const complex<double> Jost_kr_der_plus = (Jost_kr_two_plus - Jost_kr)/two_sqrt_precision;
  
  const complex<double> Jost_kr_der_minus = (Jost_kr - Jost_kr_two_minus)/two_sqrt_precision;

  const complex<double> Jost_kr_2der = (Jost_kr_der_plus - Jost_kr_der_minus)/two_sqrt_precision;

  const complex<double> Jost_kr_der_ratio = Jost_kr_der/Jost_kr_2der;

  const complex<double> Jost_kr_ratio = Jost_kr/Jost_kr_der;

  const complex<double> k_second_order = kr - Jost_kr_der_ratio*(1.0 - sqrt (1.0 - 2.0*Jost_kr_ratio/Jost_kr_der_ratio));
      
  const complex<double> E_second_order = k_second_order*k_second_order/kinetic_factor;
      
  const double real_E_second_order = real (E_second_order);

  const double Gamma_second_order = max (-2000.0*imag (E_second_order) , 0.0);

  cout << endl;
  
  cout << "E     from zeroth-order formula : " << real_E_zeroth_order << " MeV" << endl;
  cout << "Gamma from zeroth-order formula : " << Gamma_zeroth_order  << " keV" << endl;

  cout << endl;
  
  cout << "E     from second-order Jost function formula : " << real_E_second_order << " MeV" << endl;
  cout << "Gamma from second-order Jost function formula : " << Gamma_second_order  << " keV" << endl;
}



void e_search (
	       const enum potential_type potential , 
	       const int A , 
	       const int Z_charge , 
	       const double nu_mass , 
	       const double target_mass , 
	       const unsigned int N_GL , 
	       const unsigned int N_uniform , 
	       const double R , 
	       const double matching_point , 
	       const double R_real_max , 
	       const double kinetic_factor , 
	       class potentials_effective_mass &T , 
	       const enum particle_type particle , 
	       const int n , 
	       const int l , 
	       const double j)
{        
  const bool is_there_starting_energy = (potential != PTG_POTENTIAL) ? (bool_determination_no_print ("starting.energy")) : (false);

  const bool is_it_bound_starting_point = (is_there_starting_energy) ? (bool_determination_no_print ("bound.starting.point")) : (false);

  double energy_deb = 0.0;

  double width_deb = 0.0;

  if (is_there_starting_energy)
    {
      cin >> energy_deb;
      word_check_print<double> ("MeV(starting.energy)" , energy_deb);
      
      cin >> width_deb;
      word_check_print<double> ("MeV(starting.width)" , width_deb);
    }

  if (is_it_bound_starting_point && (energy_deb > 0.0) && (width_deb == 0.0)) error_message_print_abort ("Bound states cannot have real positive energies");
      
  const complex<double> E_deb(energy_deb , -0.5*width_deb);

  const complex<double> k_deb_no_sign = sqrt_mod (E_deb*kinetic_factor);

  const int k_deb_sign = (is_it_bound_starting_point) ? (SIGN (imag (k_deb_no_sign))) : ((width_deb != 0.0) ? (-SIGN (imag (k_deb_no_sign))) : (-1));

  const complex<double> k_deb = ((energy_deb < 0.0) && (width_deb == 0.0)) ? (complex<double> (0.0 , k_deb_sign*imag (k_deb_no_sign))) : (k_deb_sign*k_deb_no_sign);
  
  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , !is_there_starting_energy , k_deb , nu_mass , 1.0 , 1.0);

  T.initialize_constants (
			  wf.get_potential () , 
			  wf.get_kinetic_factor () ,
			  wf.get_jr () , 
			  wf.get_l () , 
			  wf.get_Z_charge () , 
			  wf.get_j () , 
			  wf.get_k () , 
			  wf.get_eta () , 
			  NADA);

  cout << endl;

  if (potential == PTG_POTENTIAL)
    wf.PTG_eigenstate_calc (true , T.get_PTG_potential ());
  else
    {
      wf.k_search (T , true , true);

      if (potential != MODIFIED_PTG_POTENTIAL)
	wf.wave_calculation (true , T , false);
      else
	wf.modified_PTG_eigenstate_calc (true , T , false);
    }
  
  const complex<double> k = wf.get_k ();
  
  const double b_HO = ((real (k) != 0.0) || (imag (k) > 0.0)) ? (best_b_HO_calc (wf)) : (pow (A , 0.16666666666666667));

  const complex<double> overlap_wf_wf_HO = overlap_wf_wf_HO_calc (b_HO , wf);
  
  const bool is_k_OK = wf.get_is_k_OK ();

  if (!is_k_OK) error_message_print_abort (make_string<class spherical_state> (wf) + " not found");

  wf.wave_calculation_momentum (b_HO);

  class spherical_state wf_HO_expansion(false , true , potential , A , Z_charge , target_mass , NADA ,
					N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
					true , particle , n , NADA , l , j , false , k_deb , nu_mass , 1 , 1);

  T.initialize_constants (
			  wf_HO_expansion.get_potential () , 
			  wf_HO_expansion.get_kinetic_factor () ,
			  wf_HO_expansion.get_jr () , 
			  wf_HO_expansion.get_l () , 
			  wf_HO_expansion.get_Z_charge () , 
			  wf_HO_expansion.get_j () , 
			  wf_HO_expansion.get_k () , 
			  wf_HO_expansion.get_eta () , 
			  NADA);

  wf_HO_expansion.wave_calculation_HO_diag (T , b_HO);

  cout.precision (15);

  cout << endl << "2mu/hbar^2 : " << wf.get_kinetic_factor () << " hbar^2/2m : " << 1.0/wf.get_kinetic_factor () << endl << endl;

  cout << "best b[HO] : " << b_HO << " fm" << endl;
  cout << "overlap <wf|wf[HO]> : " << overlap_wf_wf_HO << endl << endl;
  
  cout << "C0 : " << wf.get_C0 () << endl;
  cout << "C+ : " << wf.get_Cplus () << endl << endl;
  
  cout << "theta min : " << -180.0*arg (k)/M_PI << " degrees." << endl << endl;

  cout << "rms radius : " << wf.rms_radius_calc () << " fm " << endl;
  
  const complex<double> eta = wf.get_eta ();
      
  if (k != 0.0)
    {
      const complex<double> sigma = sigma_l_calc (l , eta);
      
      cout << "sigma(l , eta) : " << sigma << endl;
    }

  wf.copy_to_file_for_figure_coordinate ("wf" , false , false , true);
  wf.copy_to_file_for_figure_momentum ("wf" , false);
  
  wf_HO_expansion.copy_to_file_for_figure_coordinate ("wf_HO_expansion" , false , false , true);  
  wf_HO_expansion.copy_to_file_for_figure_momentum ("wf_HO_expansion" , false);

  if (potential == MODIFIED_PTG_POTENTIAL) E_approximations_modified_PTG_calc_print (particle  , n , T);
}




void e_rms_radius_plot_real_WS_modified_PTG (
					     const bool is_modified_PTG_fitted_from_WS_analytic ,
					     const enum potential_type potential , 
					     const int A , 
					     const int Z_charge , 
					     const double nu_mass , 
					     const double target_mass , 
					     const unsigned int N_GL , 
					     const unsigned int N_uniform , 
					     const double R_init , 
					     const double matching_point , 
					     const double R_real_max , 
					     const double kinetic_factor , 
					     class potentials_effective_mass &T , 
					     const enum particle_type particle , 
					     const int n , 
					     const int l , 
					     const double j)
{
  const bool is_there_starting_energy = bool_determination_no_print ("starting.energy");

  double R = R_init;
  
  double energy_deb_start = 0.0;

  double width_deb_start = 0.0;

  if (is_there_starting_energy)
    {
      cin >> energy_deb_start;
      word_check_print<double> ("MeV(energy)" , energy_deb_start);
      
      cin >> width_deb_start;
      word_check_print<double> ("MeV(width)" , width_deb_start);
    }

  unsigned int N_points;
  cin >> N_points;
  word_check_print<double> ("(N.points)" , N_points);

  if (N_points == 0) error_message_print_abort ("N_points > 0 in e_plot_real_WS");
  
  double Vo_end;
  cin >> Vo_end;
  word_check_print<double> ("MeV(Vo.end)" , Vo_end);

  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();
	  
  const double d        = (potential == WS) ? (WS_potential.get_d ())        : (WS_analytic_potential.get_d ());
  const double R0       = (potential == WS) ? (WS_potential.get_R0 ())       : (WS_analytic_potential.get_R0 ());
  const double Vo_deb   = (potential == WS) ? (WS_potential.get_Vo ())       : (WS_analytic_potential.get_Vo ());
  const double Vso      = (potential == WS) ? (WS_potential.get_Vso ())      : (WS_analytic_potential.get_Vso ());
  const double R_charge = (potential == WS) ? (WS_potential.get_R_charge ()) : (WS_analytic_potential.get_R_charge ());

  const double Vo_step = (Vo_end - Vo_deb)/static_cast<double> (N_points - 1);

  const complex<double> E_deb_start(energy_deb_start , -0.5*width_deb_start);

  const complex<double> k_deb_start = ((energy_deb_start < 0.0) && (abs (width_deb_start) < precision)) ? (complex<double> (0.0 , sqrt (-energy_deb_start*kinetic_factor))) : (sqrt (E_deb_start*kinetic_factor));

  const string outfile_name = "energy_rms_radius_plot_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";
  
  ofstream out_file (outfile_name.c_str ());
  out_file.precision (15);

  if (potential == MODIFIED_PTG_POTENTIAL)
    {
      modified_PTG_potential.initialize (is_modified_PTG_fitted_from_WS_analytic , false , d , R0 , Vo_deb , Vso , 0.0 , particle , Z_charge , R_charge , kinetic_factor , l , j , R , N_uniform , N_GL);

      const double r_asy = modified_PTG_potential.get_r_asy ();
	
      R = r_asy;
    }
  
  class spherical_state wf_deb(false , true , potential , A , Z_charge , target_mass , NADA ,
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			       true , particle , n , NADA , l , j , !is_there_starting_energy , k_deb_start , nu_mass , 1.0 , 1.0);
  
  cout << endl << "2mu/hbar^2=" << kinetic_factor << " hbar^2/2m" << " " << 1.0/kinetic_factor << endl;

  cout << endl << "Vo : " << Vo_deb << " MeV  ";
  
  T.initialize_constants (
			  wf_deb.get_potential () , 
			  wf_deb.get_kinetic_factor () , 
			  wf_deb.get_jr () , 
			  wf_deb.get_l () , 
			  wf_deb.get_Z_charge () , 
			  wf_deb.get_j () , 
			  wf_deb.get_k () , 
			  wf_deb.get_eta () , 
			  NADA);
  
  cout << endl;
  wf_deb.k_search (T , true , true);

  if (potential != MODIFIED_PTG_POTENTIAL)
    wf_deb.wave_calculation (true , T , false);
  else
    wf_deb.modified_PTG_eigenstate_calc (true , T , false);
  
  complex<double> k = wf_deb.get_k ();
  complex<double> E = wf_deb.get_E ();

  complex<double> eta = wf_deb.get_eta ();
        
  if ((real (E) > 0.0) && (imag (E) == 0.0))
    {
      const double width_from_current_formula = wf_deb.width_from_current_formula_calc ();

      const double imag_E_from_current_formula = -width_from_current_formula*0.0005;

      E = complex<double> (real (E) , imag_E_from_current_formula);

      k = sqrt (kinetic_factor*E);
      
      eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);
    }
      
  double energy = real (E);
  
  double width = -2000.0*imag (E);

  complex<double> rms_radius = wf_deb.rms_radius_calc ();
      
  cout << "rms radius : " << rms_radius << " fm " << endl << endl;
      
  out_file << Vo_deb << " " << real (k) << " " << imag (k) << " " << real (eta) << " " << imag (eta) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;

  wf_deb.deallocate ();
  
  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);
  
  for (unsigned int depth_index = 1 ; depth_index < N_points ; depth_index++)
    {
      const double Vo = Vo_deb + Vo_step*depth_index;
      
      const complex<double> k_bef = k;
      
      const complex<double> E_bef = E;

      const double energy_bef = real (E_bef);
  
      if (potential == WS) WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
	  	
      if (potential == WS_ANALYTIC) WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
      
      if (potential == MODIFIED_PTG_POTENTIAL)
	{
	  modified_PTG_potential.initialize (is_modified_PTG_fitted_from_WS_analytic , false , d , R0 , Vo , Vso , 0.0 , particle , Z_charge , R_charge , kinetic_factor , l , j , R , N_uniform , N_GL);
	  
	  const double r_asy = modified_PTG_potential.get_r_asy ();
	  
	  R = r_asy;

	  wf.deallocate ();
	  
	  wf.allocate (false , true , potential , A , Z_charge , target_mass , NADA ,
		       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
		       true , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);
	}

      T.initialize_constants (
			      wf.get_potential () , 
			      wf.get_kinetic_factor () , 
			      wf.get_jr () , 
			      wf.get_l () , 
			      wf.get_Z_charge () , 
			      wf.get_j () , 
			      wf.get_k () , 
			      wf.get_eta () , 
			      NADA);

      cout << "Vo : " << Vo << " MeV  ";
  
      wf.k_search (T , true , true);
	  
      const bool is_k_OK = wf.get_is_k_OK ();

      if (is_k_OK)
	{
	  if (potential != MODIFIED_PTG_POTENTIAL)
	    wf.wave_calculation (true , T , false);
	  else
	    wf.modified_PTG_eigenstate_calc (true , T , false);
  
	  rms_radius = wf.rms_radius_calc ();
	  
	  k = wf.get_k ();
	  E = wf.get_E ();
	  
	  eta = wf.get_eta ();
	}
      else
	{
	  cout << endl << "Starting energy from previous iteration failed: automatic search for Vo=" << Vo << " MeV" <<  endl;

	  class spherical_state wf_automatic_starting_point(false , true , potential , A , Z_charge , target_mass , NADA ,
							    N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
							    true , particle , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);

	  wf_automatic_starting_point.k_search (T , true , true);
	  
	  if (potential != MODIFIED_PTG_POTENTIAL)
	    wf_automatic_starting_point.wave_calculation (true , T , false);
	  else
	    wf_automatic_starting_point.modified_PTG_eigenstate_calc (true , T , false);
	  
	  rms_radius = wf_automatic_starting_point.rms_radius_calc ();

	  k = wf_automatic_starting_point.get_k ();
	  E = wf_automatic_starting_point.get_E ();
	  
	  eta = wf_automatic_starting_point.get_eta ();
	}
	  
      energy = real (E);
      
      if (SIGN (energy_bef) != SIGN (energy))
	{
	  const double Vo_energy_zero_app = -Vo_step*energy_bef/(energy - energy_bef) + Vo - Vo_step;

	  class spherical_state wf_zero(false , true , potential , A , Z_charge , target_mass , NADA ,
					N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
					true , particle , n , NADA , l , j , false , 0 , nu_mass , 1.0 , 1.0);
      
	  if (potential != MODIFIED_PTG_POTENTIAL)
	    wf_zero.wave_calculation (true , T , false);
	  else
	    wf_zero.modified_PTG_eigenstate_calc (true , T , false);
	  
	  rms_radius = wf_zero.rms_radius_calc ();
	  
	  eta = (finite (wf_zero.get_eta ())) ? (wf_zero.get_eta ()) : (INFINITE);	  
      
	  out_file << Vo_energy_zero_app << " " << 0.0 << " " << 0.0 << " " << real (eta) << " " << imag (eta) << " " << 0.0 << " " << 0.0 << " " << real (rms_radius) << " " << imag (rms_radius) << endl;
	}

      if ((real (E) > 0.0) && (imag (E) == 0.0))
	{
	  const double width_from_current_formula = wf.width_from_current_formula_calc ();
	  
	  const double imag_E_from_current_formula = -width_from_current_formula*0.0005;
	  
	  E = complex<double> (real (E) , imag_E_from_current_formula);
	  
	  k = sqrt (kinetic_factor*E);
	  
	  eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);
	}

      cout << "rms radius : " << rms_radius << " fm " << endl << endl;
      
      energy = real (E);
      
      width = -2000.0*imag (E);
  
      out_file << Vo << " " << real (k) << " " << imag (k) << " " << real (eta) << " " << imag (eta) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;

      const complex<double> k_start = 2.0*k - k_bef;
      
      wf.set_k_search_start (k_start);
    }
}





void e_rms_radius_plot_PTG (
			    const double nu_mass , 
			    const double target_mass , 
			    const double kinetic_factor , 
			    const unsigned int N_GL , 
			    const unsigned int N_uniform , 
			    const double R , 
			    class potentials_effective_mass &T , 
			    const enum particle_type particle , 
			    const int n , 
			    const int l , 
			    const double j)
{
  unsigned int N_points;
  cin >> N_points;
  word_check_print<double> ("(N.points)" , N_points);

  if (N_points == 0) error_message_print_abort ("N_points > 0 in e_plot_real_PTG");
  
  double nu_end;
  cin >> nu_end;
  word_check_print<double> ("MeV(nu.end)" , nu_end);

  double s_end;
  cin >> s_end;
  word_check_print<double> ("MeV(s.end)" , s_end);

  cout << endl << "2mu/hbar^2=" << kinetic_factor << " hbar^2/2m" << " " << 1.0/kinetic_factor << endl;

  class PTG_class &PTG_potential = T.get_PTG_potential ();

  const double Lambda = PTG_potential.get_Lambda ();
  const double s_deb  = PTG_potential.get_s ();
  const double nu_deb = PTG_potential.get_nu ();
  const double a      = PTG_potential.get_a ();

  const double nu_step = (nu_end - nu_deb)/static_cast<double> (N_points - 1);
  const double s_step  = (s_end - s_deb)/static_cast<double> (N_points - 1);

  const int N = 2*n + l + 1;

  const string outfile_name = "energy_rms_radius_plot_PTG_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";
  
  T.initialize_constants (PTG_POTENTIAL , kinetic_factor , NADA ,  l ,  0 , j , NADA ,  NADA , NADA);
  
  ofstream out_file (outfile_name.c_str ());
  out_file.precision (15);
    
  class spherical_state wf(false , true , PTG_POTENTIAL , NADA , 0 , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , NADA , 100.0 , 5.0 , R ,
			   true , particle , n , NADA , l , j , false , NADA , nu_mass , 1.0 , 1.0);

  cout << endl << "nu : " << nu_deb << " s : " << s_deb << " " << particle << endl;

  wf.PTG_eigenstate_calc (true , PTG_potential);

  const complex<double> rms_radius_deb = wf.rms_radius_calc ();

  cout << "rms radius : " << rms_radius_deb << " fm " << endl << endl;
  
  const complex<double> k_deb = wf.get_k ();
  const complex<double> E_deb = wf.get_E ();
  
  const double energy_deb = real (E_deb);
	        
  out_file << nu_deb << " " << real (k_deb) << " " << imag (k_deb) << " " << energy_deb << " " << 0 << " " << real (rms_radius_deb) << " " << imag (rms_radius_deb) << endl;

  for (unsigned int depth_index = 1 ; depth_index < N_points ; depth_index++)
    {
      const double nu = nu_deb + nu_step*depth_index;

      const double nu_bef = nu - nu_step;

      const double s = s_deb + s_step*depth_index;

      const double Delta_bef = Lambda*Lambda*(nu_bef + 0.5)*(nu_bef + 0.5)*(1.0 - a) - ((1.0 - a)*Lambda*Lambda - 1.0)*(N + 0.5)*(N + 0.5);
      const double Delta     = Lambda*Lambda*(nu     + 0.5)*(nu     + 0.5)*(1.0 - a) - ((1.0 - a)*Lambda*Lambda - 1.0)*(N + 0.5)*(N + 0.5);

      if (SIGN (Delta_bef) != SIGN (Delta))
	{
	  const double nu_c = -0.5 + sqrt (((1.0 - a)*Lambda*Lambda - 1.0)/(1.0 - a))*(N + 0.5)/Lambda;
	  
	  const double s_bef = s - s_step;

	  const double sc_app = (s_step/nu_step)*(nu_c - nu_bef) + s_bef;
	  
	  PTG_potential.initialize (kinetic_factor , l , Lambda , sc_app , nu_c , a);
	  
	  cout << "nu : " << nu_c << " s : " << sc_app << " " << particle << " " << endl;
	  
	  wf.PTG_eigenstate_calc (true , PTG_potential);  

	  const complex<double> rms_radius_c = wf.rms_radius_calc ();
	  
	  cout << "rms radius : " << rms_radius_c << " fm " << endl << endl;
  
	  const complex<double> kc = wf.get_k ();
	  const complex<double> Ec = wf.get_E ();

	  const double energy_c = real (Ec);
	  
	  const double width_c = -2000.0*imag (Ec);	  
      
	  out_file << nu_c << " " << real (kc) << " " << imag (kc) << " " << energy_c << " " << width_c << " " << real (rms_radius_c) << " " << imag (rms_radius_c) << endl;
	}

      PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);

      cout << "nu : " << nu << " s : " << s << " " << particle << endl;
      
      wf.PTG_eigenstate_calc (true , PTG_potential); 

      const complex<double> rms_radius = wf.rms_radius_calc ();
      
      cout << "rms radius : " << rms_radius << " fm " << endl << endl; 
      
      const complex<double> k = wf.get_k ();      
      const complex<double> E = wf.get_E ();

      const double energy = real (E);
	  
      const double width = -2000.0*imag (E);      
      
      out_file << nu << " " << real (k) << " " << imag (k) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;
    }
}











void e_rms_radius_plot_complex_WS (
				   const enum potential_type potential , 
				   const int A , 
				   const int Z_charge , 
				   const double nu_mass , 
				   const double target_mass , 
				   const unsigned int N_GL , 
				   const unsigned int N_uniform , 
				   const double R , 
				   const double matching_point , 
				   const double R_real_max , 
				   const double kinetic_factor , 
				   class potentials_effective_mass &T , 
				   const enum particle_type particle , 
				   const int n , 
				   const int l , 
				   const double j)
{
  const bool is_there_starting_energy = bool_determination_no_print ("starting.energy");
 
  double energy_deb_start = 0.0;

  double width_deb_start = 0.0;

  if (is_there_starting_energy)
    {
      cin >> energy_deb_start;
      word_check_print<double> ("MeV(energy)" , energy_deb_start);
      
      cin >> width_deb_start;
      word_check_print<double> ("MeV(width)" , width_deb_start);
    }

  unsigned int N_points;
  cin >> N_points;
  word_check_print<double> ("(N.points)" , N_points);

  complex<double> Vo_end;
  cin >> Vo_end;
  word_check_print<complex<double> > ("MeV(Vo.end)" , Vo_end);

  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();
  
  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

  const double d               = (potential == COMPLEX_WS) ? (WS_complex_potential.get_d ())        : (WS_complex_analytic_potential.get_d ());
  const double R0              = (potential == COMPLEX_WS) ? (WS_complex_potential.get_R0 ())       : (WS_complex_analytic_potential.get_R0 ());
  const complex<double> Vo_deb = (potential == COMPLEX_WS) ? (WS_complex_potential.get_Vo ())       : (WS_complex_analytic_potential.get_Vo ());
  const complex<double> Vso    = (potential == COMPLEX_WS) ? (WS_complex_potential.get_Vso ())      : (WS_complex_analytic_potential.get_Vso ());
  const double R_charge        = (potential == COMPLEX_WS) ? (WS_complex_potential.get_R_charge ()) : (WS_complex_analytic_potential.get_R_charge ());

  const complex<double> Vo_step = (Vo_end - Vo_deb)/static_cast<double> (N_points - 1);

  const complex<double> E_deb_start(energy_deb_start , -0.5*width_deb_start);

  const complex<double> k_deb_start = ((energy_deb_start < 0.0) && (abs (width_deb_start) < precision)) ? (complex<double> (0.0 , sqrt (-energy_deb_start*kinetic_factor))) : (sqrt (E_deb_start*kinetic_factor));

  class spherical_state wf_deb(false , true , potential , A , Z_charge , target_mass , NADA ,
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			       true , particle , n , NADA , l , j , !is_there_starting_energy , k_deb_start , nu_mass , 1.0 , 1.0);

  cout << endl << "2mu/hbar^2=" << kinetic_factor << " hbar^2/2m" << " " << 1.0/kinetic_factor << endl;

  cout << endl << "Vo : " << Vo_deb << " MeV  ";

  T.initialize_constants (
			  wf_deb.get_potential () , 
			  wf_deb.get_kinetic_factor () , 
			  wf_deb.get_jr () , 
			  wf_deb.get_l () , 
			  wf_deb.get_Z_charge () , 
			  wf_deb.get_j () , 
			  wf_deb.get_k () , 
			  wf_deb.get_eta () , 
			  NADA);

  wf_deb.k_search (T , true , true);

  const string outfile_name = "energy_rms_radius_plot_complex_WS_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l , j) + ".dat";
  
  ofstream out_file (outfile_name.c_str ());
  out_file.precision (15);

  complex<double> k = wf_deb.get_k ();
  complex<double> E = wf_deb.get_E ();

  complex<double> eta = wf_deb.get_eta ();
  
  wf_deb.wave_calculation (true , T , false);
  
  if ((real (E) > 0.0) && (imag (E) == 0.0) && (imag (Vo_deb) == 0.0))
    {
      const double width_from_current_formula = wf_deb.width_from_current_formula_calc ();

      const double imag_E_from_current_formula = -width_from_current_formula*0.0005;

      E = complex<double> (real (E) , imag_E_from_current_formula);

      k = sqrt (kinetic_factor*E);
      
      eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);
    }

  double energy = real (E);
  
  double width = -2000.0*imag (E);
  
  complex<double> rms_radius = wf_deb.rms_radius_calc ();
  
  cout << "rms radius : " << rms_radius << " fm " << endl << endl;
  
  out_file << real (Vo_deb) << " " << imag (Vo_deb) << " " << real (k) << " " << imag (k) << " " << real (eta) << " " << imag (eta) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;
  
  wf_deb.deallocate ();
  
  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);
  
  for (unsigned int depth_index = 1 ; depth_index < N_points ; depth_index++)
    {
      const complex<double> Vo = Vo_deb + Vo_step*depth_index;

      const complex<double> k_bef = k;

      if (potential == COMPLEX_WS) WS_complex_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
	  	
      if (potential == COMPLEX_WS_ANALYTIC) WS_complex_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

      T.initialize_constants (
			      wf.get_potential () , 
			      wf.get_kinetic_factor () , 
			      wf.get_jr () , 
			      wf.get_l () , 
			      wf.get_Z_charge () , 
			      wf.get_j () , 
			      wf.get_k () , 
			      wf.get_eta () , 
			      NADA);
	
      cout << "Vo : " << Vo << " MeV  ";

      wf.k_search (T , true , true);

      const bool is_k_OK = wf.get_is_k_OK ();

      if (is_k_OK)
	{
	  wf.wave_calculation (true , T , false);
	    
	  rms_radius = wf.rms_radius_calc ();
	  
	  k = wf.get_k ();
	  E = wf.get_E ();
	  
	  eta = wf.get_eta ();
	}
      else
	{
	  cout << endl << "Starting energy from previous iteration failed: automatic search for Vo=" << Vo << " MeV" <<  endl;

	  class spherical_state wf_automatic_starting_point(false , true , potential , A , Z_charge , target_mass , NADA ,
							    N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
							    true , particle , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);

	  wf_automatic_starting_point.k_search (T , true , true);

	  wf_automatic_starting_point.wave_calculation (true , T , false);
	    
	  cout << endl;

	  rms_radius = wf_automatic_starting_point.rms_radius_calc ();
	  
	  k = wf_automatic_starting_point.get_k ();
	  E = wf_automatic_starting_point.get_E ();
	  
	  eta = wf_automatic_starting_point.get_eta ();
	}

      if ((real (E) > 0.0) && (imag (E) == 0.0) && (imag (Vo) == 0.0))
	{
	  const double width_from_current_formula = wf.width_from_current_formula_calc ();
	  
	  const double imag_E_from_current_formula = -width_from_current_formula*0.0005;
	  
	  E = complex<double> (real (E) , imag_E_from_current_formula);
	  
	  k = sqrt (kinetic_factor*E);
	  
	  eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);
	}

      cout << "rms radius : " << rms_radius << " fm " << endl << endl;
      
      energy = real (E);
  
      width = -2000.0*imag (E);
  
      out_file << real (Vo) << " " << imag (Vo) << " " << real (k) << " " << imag (k) << " " << real (eta) << " " << imag (eta) << " " << energy << " " << width << " " << real (rms_radius) << " " << imag (rms_radius) << endl;
      
      const complex<double> k_start = 2.0*k - k_bef;
      
      wf.set_k_search_start (k_start);
    }
}
























void e_scat (
	     const enum potential_type potential , 
	     const int A , 
	     const int Z_charge , 
	     const double nu_mass , 
	     const double target_mass , 
	     const unsigned int N_GL , 
	     const unsigned int N_uniform , 
	     const double R , 
	     const double matching_point , 
	     const double R_real_max , 
	     const double kinetic_factor , 
	     class potentials_effective_mass &T , 
	     const enum particle_type particle , 
	     const int n , 
	     const int l , 
	     const double j)
{
  double energy;
  cin >> energy;
  word_check_print<double> ("MeV(energy)" , energy);

  double width;
  cin >> width;
  word_check_print<double> ("MeV(width)" , width);

  const complex<double> E(energy , -0.5*width);
  
  const complex<double> k = sqrt_mod (E*kinetic_factor);

  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   false , particle , n , NADA , l , j , false , k , nu_mass , 1 , 1);

  cout.precision (15);
  cout << endl << angular_state (l,j) << endl;
  cout << "2mu/hbar^2=" << wf.get_kinetic_factor () << " hbar^2/2m" << " " << 1.0/wf.get_kinetic_factor () << endl;
  cout << "E : " << energy << " MeV" << endl << "G : " << 1000*width << " keV" << endl;

  T.initialize_constants (
			  wf.get_potential () , 
			  wf.get_kinetic_factor () ,
			  wf.get_jr () , 
			  wf.get_l () , 
			  wf.get_Z_charge () , 
			  wf.get_j () , 
			  wf.get_k () , 
			  wf.get_eta () , 
			  NADA);

  wf.wave_calculation (true , T , false);
  
  const double b_HO =4; ((real (k) != 0.0) || (imag (k) > 0.0)) ? (best_b_HO_calc (wf)) : (pow (A , 0.16666666666666667));
  
  const complex<double> overlap_wf_wf_HO = overlap_wf_wf_HO_calc (b_HO , wf);
  
  wf.wave_calculation_momentum (b_HO);
  
  cout << "best b[HO] : " << b_HO << " fm" << endl;
  cout << "overlap <wf|wf[HO]> : " << overlap_wf_wf_HO << endl << endl;
  
  cout << "C+ : " << wf.get_Cplus () << endl << "C- : " << wf.get_Cminus () << endl << endl;

  cout << "CF : " << wf.get_CF () << endl << "CG : " << wf.get_CG () << endl << endl;
  
  cout << "k : " << wf.get_k () << " fm^(-1)" << endl << endl;

  cout << "phase.shift : " << wf.get_phase_shift () << endl << endl;

  cout << "S-matrix : " << wf.get_S_matrix () << endl << endl;

  class spherical_state Coulomb_wf(false , true , COULOMB_POTENTIAL , A , Z_charge , target_mass , NADA ,
				   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
				   false , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0);

  Coulomb_wf.Coulomb_eigenstate_calc (true);
  Coulomb_wf.wave_calculation_momentum (b_HO);

  wf.copy_to_file_for_figure_coordinate ("wf" , false , false , true);
  wf.copy_to_file_for_figure_momentum ("wf" , false);
  
  Coulomb_wf.copy_to_file_for_figure_coordinate ("Coulomb_wf" ,  false , false , true);  
  Coulomb_wf.copy_to_file_for_figure_momentum ("Coulomb_wf" ,  false);
}









void potential_search (
		       const enum potential_type potential , 
		       const int A , 
		       const int Z_charge , 
		       const double nu_mass , 
		       const double target_mass , 
		       const unsigned int N_GL , 
		       const unsigned int N_uniform , 
		       const double R , 
		       const double matching_point , 
		       const double R_real_max , 
		       const double kinetic_factor , 
		       class potentials_effective_mass &T , 
		       const enum particle_type particle , 
		       const int n , 
		       const int l , 
		       const double j , 
		       const enum problem_type problem)
{
  const bool is_it_bound = bool_determination_no_print ("bound.state");

  double energy_to_fit;
  cin >> energy_to_fit;
  word_check_print<double> ("MeV(energy)" , energy_to_fit);

  cout << endl;

  if (is_it_bound && (energy_to_fit > 0.0)) error_message_print_abort ("Bound states have real negative energies");

  const int k_sign = (is_it_bound || (energy_to_fit > 0.0)) ? (1) : (-1);

  const double width_deb = (energy_to_fit > 1.0) ? (energy_to_fit*random_number<double> ()) : (0.0);

  const complex<double> E_deb(energy_to_fit , -0.5*width_deb);

  const complex<double> k_deb_no_sign = sqrt_mod (E_deb*kinetic_factor);
  
  const complex<double> k_deb = k_sign*k_deb_no_sign;
  
  const complex<double> eta_deb = eta_calc (false , particle , Z_charge , kinetic_factor , k_deb);

  T.initialize_constants (potential , kinetic_factor , NADA , l , Z_charge , j , k_deb , eta_deb , NADA);

  complex<double> k = k_deb;
  
  V_for_fixed_E (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem , is_it_bound , k);
  
  const complex<double> E = k*k/kinetic_factor;

  const double energy = real (E);

  const double width = -2000.0*imag (E);
	
  class WS_class &WS_potential = T.get_WS_potential ();

  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
	
  class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();
	  
  cout.precision (15);

  cout << endl;
  
  if (potential == WS) cout << "Vo=" << WS_potential.get_Vo () << " MeV Vso=" << WS_potential.get_Vso () << " MeV E=" << energy << " MeV G=" << width << " keV." << endl << endl;
  
  if (potential == WS_ANALYTIC) cout << "Vo=" << WS_analytic_potential.get_Vo () << " MeV Vso=" << WS_analytic_potential.get_Vso () << " MeV E=" << energy << " MeV G=" << width << " keV." << endl << endl;
  
  if (potential == MODIFIED_PTG_POTENTIAL) cout << "Vo=" << modified_PTG_potential.get_Vo () << " MeV Vso=" << modified_PTG_potential.get_Vso () << " MeV E=" << energy << " MeV G=" << width << " keV." << endl << endl;

  cout.precision (6);

  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , false , k , nu_mass , 1 , 1);

  T.initialize_constants (
			  wf.get_potential () , 
			  wf.get_kinetic_factor () ,
			  wf.get_jr () , 
			  wf.get_l () , 
			  wf.get_Z_charge () , 
			  wf.get_j () , 
			  wf.get_k () , 
			  wf.get_eta () , 
			  NADA);
	
  cout << endl;
  wf.k_search (T , true , true);
  
  wf.wave_calculation (true , T , false);
  
  const double b_HO =4; ((real (k) != 0.0) || (imag (k) > 0.0)) ? (best_b_HO_calc (wf)) : (pow (A , 0.16666666666666667));
  
  const complex<double> overlap_wf_wf_HO = overlap_wf_wf_HO_calc (b_HO , wf);
  
  wf.wave_calculation_momentum (b_HO);
  
  class spherical_state wf_HO_expansion(false , true , potential , A , Z_charge , target_mass , NADA ,
					N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
					true , particle , n , NADA , l , j , false , k , nu_mass , 1 , 1);

  T.initialize_constants (
			  wf_HO_expansion.get_potential () , 
			  wf_HO_expansion.get_kinetic_factor () ,
			  wf_HO_expansion.get_jr () , 
			  wf_HO_expansion.get_l () , 
			  wf_HO_expansion.get_Z_charge () , 
			  wf_HO_expansion.get_j () , 
			  wf_HO_expansion.get_k () , 
			  wf_HO_expansion.get_eta () , 
			  NADA);

  wf_HO_expansion.wave_calculation_HO_diag (T , b_HO);
  	
  cout.precision (15);
  
  cout << endl << "2mu/hbar^2 : " << wf.get_kinetic_factor () << " hbar^2/2m : " << 1.0/wf.get_kinetic_factor () << endl << endl;

  cout << "best b[HO] : " << b_HO << " fm" << endl;
  cout << "overlap <wf|wf[HO]> : " << overlap_wf_wf_HO << endl << endl;
  
  cout << "C0 : " << wf.get_C0 () << endl;
  cout << "C+ : " << wf.get_Cplus () << endl << endl;
  
  cout << "k : " << k << " fm^(-1)" << endl << endl;

  cout << "theta min : " << -180.0*arg (k)/M_PI << " degrees." << endl << endl;

  cout << "E : " << energy << " MeV" << endl << "G : " << width << " keV" << endl;

  wf.copy_to_file_for_figure_coordinate ("wf" , false , false , true);
  wf.copy_to_file_for_figure_momentum ("wf" , false);
  
  wf_HO_expansion.copy_to_file_for_figure_coordinate ("wf_HO_expansion" ,  false , false , true);  
  wf_HO_expansion.copy_to_file_for_figure_momentum ("wf_HO_expansion" , false);
}







void phase_shifts_plot  (
			 const enum potential_type potential , 
			 const int A , 
			 const int Z_charge , 
			 const double nu_mass , 
			 const double target_mass , 
			 const unsigned int N_GL , 
			 const unsigned int N_uniform , 
			 const double R , 
			 const double matching_point , 
			 const double R_real_max , 
			 const double kinetic_factor , 
			 class potentials_effective_mass &T , 
			 const enum particle_type particle , 
			 const int l ,
			 const double j)
{
  const double radians_to_degrees_factor = 180.0/M_PI;
  
  double energy_deb = 0.0;
  double energy_end = 0.0;

  double width_deb = 0.0;
  double width_end = 0.0;

  cin >> energy_deb;
  word_check_print<double> ("MeV(energy.debut)" , energy_deb);
      
  cin >> width_deb;
  word_check_print<double> ("MeV(width.debut)" , width_deb);
      
  cin >> energy_end;
  word_check_print<double> ("MeV(energy.end)" , energy_end);
      
  cin >> width_end;
  word_check_print<double> ("MeV(width.end)" , width_end);
    
  unsigned int N_points;
  cin >> N_points;
  word_check_print<double> ("(N.points)" , N_points);
  
  if (N_points == 0) error_message_print_abort ("N_points > 0 in phase_shifts_plot");
  
  cout.precision (15);
  cout << endl << angular_state (l,j) << endl;
  cout << "2mu/hbar^2=" << kinetic_factor << " hbar^2/2m" << " " << 1.0/kinetic_factor << endl << endl;
      
  const complex<double> E_deb(energy_deb , -0.5*width_deb);
  const complex<double> E_end(energy_end , -0.5*width_end);

  const complex<double> step_E = (E_end - E_deb)/static_cast<double> (N_points - 1);

  const string outfile_name = "phase_shifts_plot_" + make_string<enum particle_type> (particle) + "_" + angular_state_for_file_name (l , j) + ".dat";
  
  ofstream out_file (outfile_name.c_str ());
  out_file.precision (15);
  
  for (unsigned int iE = 0 ; iE < N_points ; iE++)
    {
      const complex<double> E = E_deb + step_E*iE;

      const complex<double> k = sqrt_mod (E*kinetic_factor);
        
      class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			       N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			       false , particle , iE , NADA , l , j , false , k , nu_mass , 1 , 1);
      
      T.initialize_constants (
			      wf.get_potential () , 
			      wf.get_kinetic_factor () ,
			      wf.get_jr () , 
			      wf.get_l () , 
			      wf.get_Z_charge () , 
			      wf.get_j () , 
			      wf.get_k () , 
			      wf.get_eta () , 
			      NADA);
      
      wf.wave_calculation (true , T , false);

      const complex<double> phase_shift_rad = wf.get_phase_shift ();
      
      const complex<double> phase_shift_deg = phase_shift_rad*radians_to_degrees_factor;
      
      cout << "E : " << E << " MeV   phase shift : " << phase_shift_deg << " degrees" << endl;
      
      out_file << real (E) << " " << imag (E) << " " << real (phase_shift_deg) << " " << imag (phase_shift_deg) << endl;     
    }
}









void complex_potential_search (
			       const enum potential_type potential , 
			       const int A , 
			       const int Z_charge , 
			       const double nu_mass , 
			       const double target_mass , 
			       const unsigned int N_GL , 
			       const unsigned int N_uniform , 
			       const double R , 
			       const double matching_point , 
			       const double R_real_max , 
			       const double kinetic_factor , 
			       class potentials_effective_mass &T , 
			       const enum particle_type particle , 
			       const int n , 
			       const int l , 
			       const double j , 
			       const enum problem_type problem)
{
  const bool is_it_bound = bool_determination_no_print ("bound.state");

  double energy_to_fit;
  cin >> energy_to_fit;
  word_check_print<double> ("MeV(energy)" , energy_to_fit);

  double width_to_fit;
  cin >> width_to_fit;
  word_check_print<double> ("MeV(width)" , width_to_fit);

  cout << endl;
  
  const complex<double> E_to_fit(energy_to_fit , -0.5*width_to_fit);
 
  const complex<double> k_no_sign = sqrt_mod (E_to_fit*kinetic_factor);

  if (is_it_bound && (energy_to_fit >= 0.0) && (width_to_fit == 0.0)) error_message_print_abort ("One cannot have bound states on the positive real axis");

  const int k_sign = (is_it_bound) ? (SIGN (imag (k_no_sign))) : ((width_to_fit != 0.0) ? (-SIGN (imag (k_no_sign))) : (-1));

  complex<double> k = k_sign*k_no_sign;

  complex<double> eta = eta_calc (false , particle , Z_charge , kinetic_factor , k);

  T.initialize_constants (potential , kinetic_factor , NADA , l , Z_charge , j , k , eta , NADA);

  complex_V_for_fixed_E (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem , is_it_bound , k);
  
  const complex<double> E = k*k/kinetic_factor;

  const double energy = real (E);
  
  const double width = -2000.0*imag (E);

  class WS_complex_class &WS_complex_potential = T.get_WS_complex_potential ();
	
  class WS_analytic_complex_class &WS_complex_analytic_potential = T.get_WS_complex_analytic_potential ();

  cout.precision (15); 

  if (potential == COMPLEX_WS) cout << endl << "Vo : " << WS_complex_potential.get_Vo () << " MeV   Vso : " << WS_complex_potential.get_Vso () << " MeV   E : " << energy << " MeV   G : " << width << " keV" << endl << endl;
  
  if (potential == COMPLEX_WS_ANALYTIC) cout << endl << "Vo : " << WS_complex_analytic_potential.get_Vo () << " MeV   Vso : " << WS_complex_analytic_potential.get_Vso () << " MeV   E : " << energy << " MeV   G : " << width << " keV" << endl << endl;

  cout.precision (6);

  class spherical_state wf(false , true , potential , A , Z_charge , target_mass , NADA ,
			   N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
			   true , particle , n , NADA , l , j , false , k , nu_mass , 1 , 1);

  T.initialize_constants (
			  wf.get_potential () , 
			  wf.get_kinetic_factor () ,
			  wf.get_jr () , 
			  wf.get_l () , 
			  wf.get_Z_charge () , 
			  wf.get_j () , 
			  wf.get_k () , 
			  wf.get_eta () , 
			  NADA);

  cout << endl;
  wf.k_search (T , true , true);
  
  wf.wave_calculation (true , T , false);
  
  const double b_HO = ((real (k) != 0.0) || (imag (k) > 0.0)) ? (best_b_HO_calc (wf)) : (pow (A , 0.16666666666666667));

  const complex<double> overlap_wf_wf_HO = overlap_wf_wf_HO_calc (b_HO , wf);
  
  wf.wave_calculation_momentum (b_HO);

  class spherical_state wf_HO_expansion(false , true , potential , A , Z_charge , target_mass , NADA ,
					N_GL , N_GL , N_uniform , N_uniform , N_GL , N_uniform , R , NADA , matching_point , R_real_max , 5.0 , R ,
					true , particle , n , NADA , l , j , false , k , nu_mass , 1 , 1);

  T.initialize_constants (
			  wf_HO_expansion.get_potential () , 
			  wf_HO_expansion.get_kinetic_factor () ,
			  wf_HO_expansion.get_jr () , 
			  wf_HO_expansion.get_l () , 
			  wf_HO_expansion.get_Z_charge () , 
			  wf_HO_expansion.get_j () , 
			  wf_HO_expansion.get_k () , 
			  wf_HO_expansion.get_eta () , 
			  NADA);

  wf_HO_expansion.wave_calculation_HO_diag (T , b_HO);
  
  cout.precision (15); 

  cout << endl << "2mu/hbar^2 : " << wf.get_kinetic_factor () << " hbar^2/2m" << " " << 1.0/wf.get_kinetic_factor () << endl << endl;


  cout << "best b[HO] : " << b_HO << " fm" << endl;
  cout << "overlap <wf|wf[HO]> : " << overlap_wf_wf_HO << endl << endl;
  
  cout << "k : " << k << endl << endl;
  
  cout << "theta min : " << -180.0*arg (k)/M_PI << " degrees." << endl << endl;
  
  cout << "E : " << energy << " MeV" << endl << "G : " << width << " keV" << endl;
  
  wf.copy_to_file_for_figure_coordinate ("wf" , false , false , true);
  wf.copy_to_file_for_figure_momentum ("wf" , false);
  
  wf_HO_expansion.copy_to_file_for_figure_coordinate ("wf_HO_expansion" ,  false , false , true);  
  wf_HO_expansion.copy_to_file_for_figure_momentum ("wf_HO_expansion" , false);
}




















#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();
  
#endif

    OpenMP_initialization ();

    enum potential_type potential;
    cin >> potential;
    cout << "potential : " << potential << endl;

    bool is_modified_PTG_fitted_from_WS_analytic = false;

    if (potential == MODIFIED_PTG_POTENTIAL) is_modified_PTG_fitted_from_WS_analytic = bool_determination ("fit.from.WS.analytic");
    
    enum particle_type particle;
    cin >> particle;
    cout << "particle : " << particle << endl << endl;

    unsigned int N_GL;
    cin >> N_GL;
    word_check_print<unsigned int> ("points(Gauss.Legendre)" , N_GL);

    unsigned int N_uniform;
    cin >> N_uniform;
    word_check_print<unsigned int> ("points(uniform)" , N_uniform);

    double R;
    cin >> R; 
    word_check_print<double> ("fm(rotation.point)" , R);

    double R_real_max;
    cin >> R_real_max; 
    word_check_print<double> ("fm(real.maximal.radius)" , R_real_max);
    
    cout << endl;
    
    class potentials_effective_mass T;

    int Z_charge = 0;

    int A;

    double matching_point;

    double kinetic_factor;

    double d;

    double R0;

    double R_charge = 0.0;

    double nu_mass;

    double target_mass;

    string shell1;
    string shell2;

    cin >> shell1;

    if (A_projectile_determine (particle) == 2) cin >> shell2;

    const double J_int = J_intrinsic_projectile_determine (particle);
  
    const int n = (A_projectile_determine (particle) == 2) ? (atoi (shell1.c_str ())) : (determine_n (shell1));

    const int l = (A_projectile_determine (particle) == 2) ? (determine_L_cluster (particle , shell2)) : (determine_L_cluster (particle , shell1));

    const double j = (A_projectile_determine (particle) == 2) ? (determine_J_cluster (shell2)) : ((J_int != 0.0) ? (determine_J_cluster (shell1)) : (l));

    switch (potential)
      {
      case WS:          WS_data (potential , l , j , d , R0 , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle); break;
      case WS_ANALYTIC: WS_data (potential , l , j , d , R0 , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle); break;

      case COMPLEX_WS:          complex_WS_data (potential , l , j , d , R0 , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle); break;
      case COMPLEX_WS_ANALYTIC: complex_WS_data (potential , l , j , d , R0 , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle); break;
	
      case KKNN: KKNN_data (l , j , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle); break;

      case INTERPOLATED_POTENTIAL: numerical_potential_data (true , particle , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , R , T); break;
	
      case COMPLEX_INTERPOLATED_POTENTIAL: numerical_potential_data (false , particle , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , R , T); break;
	
      case PTG_POTENTIAL: PTG_data (l , A , nu_mass , target_mass , kinetic_factor , matching_point , T); break;
	
      case MODIFIED_PTG_POTENTIAL:
	{
	  const enum potential_type potential_to_fit = (is_modified_PTG_fitted_from_WS_analytic) ? (WS_ANALYTIC) : (WS);
	  
	  WS_data (potential_to_fit , l , j , d , R0 , A , nu_mass , target_mass , kinetic_factor , Z_charge , R_charge , matching_point , T , particle);
	  
	  const class WS_class &WS_potential = T.get_WS_potential ();
  
	  const class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

	  const double Vo  = (potential_to_fit == WS) ? (WS_potential.get_Vo ())  : (WS_analytic_potential.get_Vo ());
	  const double Vso = (potential_to_fit == WS) ? (WS_potential.get_Vso ()) : (WS_analytic_potential.get_Vso ());
  
	  class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();

	  modified_PTG_potential.initialize (is_modified_PTG_fitted_from_WS_analytic , false , d , R0 , Vo , Vso , 0.0 , particle , Z_charge , R_charge , kinetic_factor , l , j , R , N_uniform , N_GL);
	  
	} break;
	
      default: error_message_print_abort ("Potential unavailable : " + make_string<enum potential_type> (potential));
      }

    enum problem_type problem = NO_PROBLEM;
    
    cin >> problem;

    cout << endl << "Problem : " << problem << endl;
  
    if ((l == 0) && (problem == VSO_SEARCH)) error_message_print_abort ("Vso cannot be fitted with s1/2 partial wave");

    if (potential == MODIFIED_PTG_POTENTIAL)
      {
	const class modified_PTG_class &modified_PTG_potential = T.get_modified_PTG_potential ();
	  
	const double Lambda = modified_PTG_potential.get_Lambda ();

	const double s = modified_PTG_potential.get_s ();
	  
	const double nu = modified_PTG_potential.get_nu ();

	const double r_asy = modified_PTG_potential.get_r_asy ();
	
	const double E_barrier = modified_PTG_potential.get_E_barrier ();

	cout.precision (5);
	cout << endl << endl;
	cout << "Modified PTG parameters from WS potential fit" << endl;
	cout << "---------------------------------------------" << endl << endl;

	cout << "Lambda : " << Lambda << endl;
	cout << "s : " << s << endl;
	cout << "nu : " << nu << endl;
	cout << "r[barrier] : " << r_asy << " fm " << endl;
	cout << "E[barrier] : " << E_barrier << " MeV " << endl << endl;
	
	cout.precision (15);
	
	R = r_asy;
      }
    
    switch (problem)
      {
      case E_SEARCH:
	{
	  e_search (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j);
	} break;

      case E_SCAT:
	{
	  e_scat (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j);
	} break;

      case VO_SEARCH:
	{
	  if ((potential != WS) && (potential != WS_ANALYTIC) && (potential != COMPLEX_WS) && (potential != COMPLEX_WS_ANALYTIC)) 
	    error_message_print_abort ("Potential must be WS or WS-analytic (real or complex) when one fits Vo strength");

	  if ((potential == WS) || (potential == WS_ANALYTIC)) 
	    potential_search (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem);

	  if ((potential == COMPLEX_WS) || (potential == COMPLEX_WS_ANALYTIC)) 
	    complex_potential_search (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem); 
	} break;

      case VSO_SEARCH:
	{
	  if ((potential != WS) && (potential != WS_ANALYTIC) && (potential != COMPLEX_WS) && (potential != COMPLEX_WS_ANALYTIC)) 
	    error_message_print_abort ("Potential must be WS or WS.analytic (real or complex) when one fits Vso strength");

	  if ((potential == WS) || (potential == WS_ANALYTIC)) 
	    potential_search (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem);

	  if ((potential == COMPLEX_WS) || (potential == COMPLEX_WS_ANALYTIC)) 
	    complex_potential_search (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j , problem); 
	} break;

      case E_RMS_RADIUS_PLOT:
	{
	  if ((potential != WS) && (potential != WS_ANALYTIC) && (potential != COMPLEX_WS) && (potential != COMPLEX_WS_ANALYTIC) && (potential != PTG_POTENTIAL) && (potential != MODIFIED_PTG_POTENTIAL)) 
	    error_message_print_abort ("Potential must be PTG, modified PTG, WS or WS-analytic potential (real or complex) when one plots pole energies");

	  if ((potential == WS) || (potential == WS_ANALYTIC) || (potential == MODIFIED_PTG_POTENTIAL))
	    e_rms_radius_plot_real_WS_modified_PTG (is_modified_PTG_fitted_from_WS_analytic , potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j);

	  if (potential == PTG_POTENTIAL)
	    e_rms_radius_plot_PTG (nu_mass , target_mass , kinetic_factor , N_GL , N_uniform , R , T , particle , n , l , j);

	  if ((potential == COMPLEX_WS) || (potential == COMPLEX_WS_ANALYTIC))
	    e_rms_radius_plot_complex_WS (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , n , l , j);

	} break;

      case PHASE_SHIFT_PLOT: phase_shifts_plot (potential , A , Z_charge , nu_mass , target_mass , N_GL , N_uniform , R , matching_point , R_real_max , kinetic_factor , T , particle , l , j); break;

      default: abort_all ();
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
