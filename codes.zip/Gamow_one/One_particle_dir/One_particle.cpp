#include "../../numlib/numlib_def/numlib_def.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum op_type {OVERLAP_OP , HAMILTONIAN_OP , NUCLEAR_HAMILTONIAN_OP , COULOMB_POTENTIAL_OP};

using namespace string_routines;

void resonances_alloc_calc (
			    enum potential_type potential ,
			    const enum particle_type particle ,
			    const int l_path ,
			    const double j_path ,
			    const unsigned int N_res , 
			    const double d ,
			    const double R0 ,
			    const double Vo ,
			    const double Vso ,
			    const double R_charge ,
			    const int Z_charge ,
			    const int A ,
			    const double target_mass , 
			    const unsigned int N_uniform ,
			    const unsigned int N_GL ,
			    const double R ,
			    const double R_real_max ,
			    const double matching_point , 
			    class array<class spherical_state> &shells_res)
{
  cout << endl << "Pole basis states" << endl;
  cout << "-----------------" << endl;
    
  for (unsigned int i = 0 ; i < N_res ; i++)
    {
      string shell;
      cin >> shell;

      const int n = determine_n (shell);
      const int l = determine_l (shell);

      const double j = determine_j (shell);

      if (!same_lj (l , j , l_path , j_path)) error_message_print_abort ("Resonances do not have correct angular momenta");
         
      const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);
     
      class spherical_state &shell_res = shells_res(i);

      shell_res.allocate (false , true , potential , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , 
			  R , NADA , matching_point , R_real_max , 0.0 , 0.0 , true , particle , n , NADA , l , j , true , 0.0 , nu_mass , 1.0 , 1.0);

      class potentials_effective_mass T;

      T.initialize_constants (
			      shell_res.get_potential () , 
			      shell_res.get_kinetic_factor () ,
			      shell_res.get_jr () , 
			      shell_res.get_l () , 
			      shell_res.get_Z_charge () , 
			      shell_res.get_j () , 
			      shell_res.get_k () , 
			      shell_res.get_eta () , 
			      NADA);

      class WS_class &WS_potential = T.get_WS_potential ();
      
      class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

      WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
      
      WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

      shell_res.k_search (T , true , true);

      shell_res.wave_calculation (true , T , true);
    }
}















void scattering_alloc_calc (
			    enum potential_type potential ,
			    const int l ,
			    const double j ,
			    const enum particle_type particle , 
			    const unsigned int N_res ,
			    const unsigned int N_scat ,
			    const double d ,
			    const double R0 ,
			    const double Vo ,
			    const double Vso ,
			    const double R_charge ,
			    const int Z_charge ,
			    const int A ,
			    const double target_mass , 
			    const unsigned int N_uniform ,
			    const unsigned int N_GL ,
			    const double R ,
			    const double R_real_max ,
			    const double matching_point , 
			    const class array<complex<double> > &k_tab , 
			    const class array<complex<double> > &w_tab , 
			    class array<class spherical_state> &shells)
{
  const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);
        
  class potentials_effective_mass T;

  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  WS_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  cout << endl << "Scattering basis states" << endl;
  cout << "----------------------" << endl;
  
  for (unsigned int i = 0 ; i < N_scat ; i++)
    {
      const unsigned int index = i + N_res;

      class spherical_state &shell = shells(index);

      shell.allocate (false , true , potential , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , 
		      R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , particle , index , NADA , l , j , false , k_tab(i) , nu_mass , 1.0 , NADA);

      const complex<double> k = shell.get_k ();

      const complex<double> E = shell.get_E ();

      const complex<double> w = w_tab(i);

      const complex<double> sqrt_w = sqrt (w);

      const double e = real (E);

      const double gamma = -2.0*imag(E);

      cout << index << angular_state (l , j) << " " << particle << "   k : " << k << "   E : " << e << " MeV"  << "   G : " << gamma << " MeV" << endl;

      T.initialize_constants (
			      shell.get_potential () , 
			      shell.get_kinetic_factor () , 
			      shell.get_jr () , 
			      shell.get_l () , 
			      shell.get_Z_charge () , 
			      shell.get_j () , 
			      shell.get_k () , 
			      shell.get_eta () , 
			      NADA);

		
      shell.wave_calculation (true , T , true);

      shell.normalization (sqrt_w);
    }
}





complex<double> radial_integral_bef_R (
				       enum potential_type potential ,
				       const enum op_type op , 
				       const int Delta_Z ,
				       const double R_charge , 
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out , 
				       const class WS_class &WS_basis , 
				       const class WS_class &WS_to_diag , 
				       const class WS_analytic_class &WS_analytic_basis , 
				       const class WS_analytic_class &WS_analytic_to_diag)
{
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

  const enum particle_type particle = wf_in.get_particle ();

  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL ();

  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();
  
  const class Coulomb_potential_class Coulomb_potential(false , particle , Delta_Z , R_charge);
  
  complex<double> IF = 0.0;

  switch (potential)
    {
    case NO_POTENTIAL:
      {
	switch (op)
	  {
	  case OVERLAP_OP:
	    {
	      for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
		{
		  const double w = w_bef_R_tab_GL(i);

		  IF +=  wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*w;	      
		} 
	    } break;
	    
	  default: abort_all ();	    
	  }
	
      } break;
	
    case WS:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> wf_in_wf_out_weight_product = wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*w;

	    switch (op)
	      {
	      case HAMILTONIAN_OP:         IF += wf_in_wf_out_weight_product*(WS_to_diag(r) - WS_basis(r)); break;
	      case NUCLEAR_HAMILTONIAN_OP: IF += wf_in_wf_out_weight_product*(WS_to_diag(r) - WS_basis(r)); break;

	      case COULOMB_POTENTIAL_OP:   IF += wf_in_wf_out_weight_product*Coulomb_potential.uniform_potential_calc (r); break;

	      default: abort_all ();
	      } 
	  }
      } break;
  
    case WS_ANALYTIC:
      {
	for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
	  {
	    const double r = r_bef_R_tab_GL(i);
	    const double w = w_bef_R_tab_GL(i);

	    const complex<double> wf_in_wf_out_weight_product = wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*w;

	    switch (op)
	      {
	      case HAMILTONIAN_OP:         IF += wf_in_wf_out_weight_product*(WS_analytic_to_diag(r) - WS_analytic_basis(r)); break;
	      case NUCLEAR_HAMILTONIAN_OP: IF += wf_in_wf_out_weight_product*(WS_analytic_to_diag(r) - WS_analytic_basis(r)); break;

	      case COULOMB_POTENTIAL_OP:   IF += wf_in_wf_out_weight_product*Coulomb_potential.analytic_potential_calc (r); break;

	      default: abort_all ();
	      } 
	  }
      } break;

    default: abort_all ();
    } 
  
  return IF;
}
















complex<double> radial_integral_aft_R_part_of_four (
						    const enum op_type op , 
						    const unsigned int asy_in , 
						    const unsigned int asy_out , 
						    const unsigned int angle_index , 
						    const int Delta_Z , 
						    const class spherical_state &wf_in , 
						    const class spherical_state &wf_out)
{
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();

  const enum particle_type particle = wf_in.get_particle ();

  if (op == NUCLEAR_HAMILTONIAN_OP) return 0.0; 

  if ((op != OVERLAP_OP) && ((particle == NEUTRON) || (Delta_Z == 0))) return 0.0;

  const double R = wf_in.get_R ();

  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);
  
  const complex<double> k_in  = wf_in.get_k ();
  const complex<double> k_out = wf_out.get_k ();

  const complex<double> eta_in  = wf_in.get_eta ();
  const complex<double> eta_out = wf_out.get_eta ();

  const complex<double> I_omega_in (0 , minus_one_pow (asy_in));
  const complex<double> I_omega_out(0 , minus_one_pow (asy_out));

  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL ();

  const class array<double> &um4_aft_R_tab_GL = wf_in.get_um4_aft_R_tab_GL ();
  
  const class array<complex<double> > &scaled_wf_in_aft_R_tab_GL  = wf_in.get_scaled_wf_aft_R_tab_GL ();
  
  const class array<complex<double> > &scaled_wf_out_aft_R_tab_GL = wf_out.get_scaled_wf_aft_R_tab_GL ();
  
  const class Coulomb_potential_class Coulomb_potential(false , particle , Delta_Z , NADA);
  
  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL(i);
      
      const complex<double> z = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;

      const complex<double> k_in_z  = k_in*z;
      const complex<double> k_out_z = k_out*z;

      const complex<double> log_unscale_in  = (k_in  != 0.0) ? (I_omega_in *(k_in_z  - eta_in *(M_LN2 + log (k_in_z))))  : (0.0);
      const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out*(k_out_z - eta_out*(M_LN2 + log (k_out_z)))) : (0.0);

      const complex<double> unscale = exp (log_unscale_in + log_unscale_out);

      const complex<double> wf_in_asy_in_wf_out_asy_out_weight_product = scaled_wf_in_aft_R_tab_GL(asy_in , angle_index , i)*scaled_wf_out_aft_R_tab_GL(asy_out , angle_index , i)*unscale*w;

      switch (op)
	{
	case OVERLAP_OP:           IF += wf_in_asy_in_wf_out_asy_out_weight_product; break;

	case HAMILTONIAN_OP:       IF += wf_in_asy_in_wf_out_asy_out_weight_product*Coulomb_potential.point_potential_calc (z); break;
	case COULOMB_POTENTIAL_OP: IF += wf_in_asy_in_wf_out_asy_out_weight_product*Coulomb_potential.point_potential_calc (z); break;

	default: abort ();
	}
    }

  IF *= 4.0*exp_Itheta;

  return IF;
}



complex<double> radial_integral_aft_R (
				       const enum op_type op ,
				       const int Delta_Z , 
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out)
{
  const bool S_matrix_pole_in = wf_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = wf_out.get_S_matrix_pole ();

  const complex<double> k_in  = wf_in.get_k ();
  const complex<double> k_out = wf_out.get_k ();

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (S_matrix_pole_in) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (S_matrix_pole_out) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      {
	const complex<double> Delta_k = k_in*minus_one_pow (asy_in) + k_out*minus_one_pow (asy_out);

	const unsigned int angle_index = optimal_angle_index (Delta_k);

	integral_aft_R += radial_integral_aft_R_part_of_four (op , asy_in , asy_out , angle_index , Delta_Z , wf_in , wf_out);
      }

  return integral_aft_R;
}




complex<double> OBME_calc (
			   enum potential_type potential ,
			   const enum op_type op , 
			   const int Delta_Z , 
			   const double R_charge , 
			   const class spherical_state &wf_in , 
			   const class spherical_state &wf_out , 
			   const class WS_class &WS_basis , 
			   const class WS_class &WS_to_diag , 
			   const class WS_analytic_class &WS_analytic_basis , 
			   const class WS_analytic_class &WS_analytic_to_diag)
{ 
  const complex<double> OBME_bef_R = radial_integral_bef_R (potential , op , Delta_Z , R_charge , wf_in , wf_out , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);
  
  const complex<double> OBME_aft_R = radial_integral_aft_R (op , Delta_Z , wf_in , wf_out);

  const complex<double> OBME = OBME_bef_R + OBME_aft_R;

  return OBME;
}





complex<double> H_calc_proton_diagonal_scat_calc (
						  enum potential_type potential ,
						  const double d ,
						  const double R0 ,
  						  const double Vo ,
						  const double Vo_to_diag ,
						  const double Vso ,
						  const double R_charge ,
						  const int Z_charge ,
						  const int Z_charge_to_diag ,
						  const complex<double> &wk ,
						  const class spherical_state &wf ,
						  const double target_mass ,
						  const double nu_mass)
{
  const int A = wf.get_A ();
  const int l = wf.get_l ();
  
  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf.get_N_aft_R_GL ();

  const unsigned int N_bef_R_uniform = wf.get_N_bef_R_uniform ();
  const unsigned int N_aft_R_uniform = wf.get_N_aft_R_uniform ();
  
  const double R = wf.get_R ();
      
  const double R_real_max = wf.get_R_real_max ();
  
  const double matching_point = wf.get_matching_point ();
      
  const double j = wf.get_j ();

  const complex<double> k = wf.get_k ();

  const int Delta_Z = Z_charge_to_diag - Z_charge;

  const complex<double> dk = wk*0.25*M_1_PI;
	  
  const complex<double> sqrt_wk = sqrt (wk);

  const complex<double> k_plus = k + dk;
  const complex<double> k_minus = k - dk;

  class potentials_effective_mass T;

  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , PROTON , Z_charge , R_charge , l , j);

  class spherical_state wf_minus (false , true , potential , A , Z_charge , target_mass , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
				  R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , PROTON , NADA , NADA , l , j , false , k_minus , nu_mass , 1.0 , 1.0);

  class spherical_state wf_plus (false , true , potential , A , Z_charge , target_mass , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
				 R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , PROTON , NADA , NADA , l , j , false , k_plus , nu_mass , 1.0 , 1.0);

  T.initialize_constants (
			  wf_minus.get_potential () , 
			  wf_minus.get_kinetic_factor () , 
			  wf_minus.get_jr () , 
			  wf_minus.get_l () ,
			  wf_minus.get_Z_charge () , 
			  wf_minus.get_j () , 
			  wf_minus.get_k () , 
			  wf_minus.get_eta () , 
			  NADA);

  wf_minus.wave_calculation (true , T , true);

  wf_minus.normalization (sqrt_wk);

  T.initialize_constants (
			  wf_plus.get_potential () , 
			  wf_plus.get_kinetic_factor () , 
			  wf_plus.get_jr () , 
			  wf_plus.get_l () ,
			  wf_plus.get_Z_charge () , 
			  wf_plus.get_j () , 
			  wf_plus.get_k () , 
			  wf_plus.get_eta () , 
			  NADA);

  wf_plus.wave_calculation (true , T , true);

  wf_plus.normalization (sqrt_wk);
  
  const class WS_class dummy;
  
  const class WS_analytic_class dummy_analytic;
      
  const class WS_class WS_nuclear_basis  (false , d , R0 , Vo         , Vso , NEUTRON , NADA , NADA , l , j);
  const class WS_class WS_nuclear_to_diag(false , d , R0 , Vo_to_diag , Vso , NEUTRON , NADA , NADA , l , j);

  const class WS_analytic_class WS_analytic_nuclear_basis  (false , d , R0 , Vo         , Vso , NEUTRON , NADA , NADA , l , j);
  const class WS_analytic_class WS_analytic_nuclear_to_diag(false , d , R0 , Vo_to_diag , Vso , NEUTRON , NADA , NADA , l , j);
      
  const complex<double> Coulomb_diagonal_scat_part = OBME_calc (potential , COULOMB_POTENTIAL_OP , Delta_Z , R_charge , wf_plus , wf_minus , dummy , dummy , dummy_analytic , dummy_analytic);
  
  const complex<double> nuclear_diagonal_scat_part = OBME_calc (potential , NUCLEAR_HAMILTONIAN_OP , NADA , NADA , wf , wf , WS_nuclear_basis , WS_nuclear_to_diag , WS_analytic_nuclear_basis , WS_analytic_nuclear_to_diag);

  const complex<double> H_calc_proton_diagonal_scat = Coulomb_diagonal_scat_part + nuclear_diagonal_scat_part;

  return H_calc_proton_diagonal_scat;
}


complex<double> H_calc_proton_diagonal_scat_sub_calc (
						      enum potential_type potential , 
						      const enum particle_type particle , 
						      const double d ,
						      const double R0 ,
						      const double Vo ,
						      const double Vo_to_diag ,
						      const double Vso ,
						      const double R_charge ,
						      const int Z_charge ,
						      const int Z_charge_to_diag ,
						      const class array<class spherical_state> &shells , 
						      const unsigned int N_res , 
						      const double k_max , 
						      const class array<complex<double> > &w_tab , 
						      const unsigned int wf_index)
{
  const complex<double> wk = w_tab(wf_index - N_res);

  const class spherical_state &wf = shells(wf_index);

  const unsigned int N_shells = shells.dimension (0);
  
  const complex<double> k = wf.get_k ();

  const complex<double> wk_two_over_Pi = wk*M_2_PI;

  const complex<double> wk_two_Pi_inv = wk*0.5*M_1_PI;
  
  const double R = wf.get_R ();

  const int l = wf.get_l ();
  
  const double j = wf.get_j ();
				
  const int Delta_Z = Z_charge_to_diag - Z_charge;

  const double Cc_Delta_Z_over_Pi = Coulomb_constant*Delta_Z*M_1_PI;
  
  const class Coulomb_potential_class Coulomb_potential(false , PROTON , Delta_Z , R_charge);

  const unsigned int N_bef_R_GL = wf.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = wf.get_N_aft_R_GL ();

  const class array<double> &r_bef_R_tab_GL = wf.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf.get_w_bef_R_tab_GL ();
  
  const class array<double> &w_aft_R_tab_GL = wf.get_w_aft_R_tab_GL ();

  const class array<double> &um4_aft_R_tab_GL = wf.get_um4_aft_R_tab_GL ();

  const class WS_class WS_basis(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  const class WS_class WS_to_diag(false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
      
  const class WS_analytic_class WS_analytic_basis(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  const class WS_analytic_class WS_analytic_to_diag(false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j );
						    
  complex<double> H_calc_proton_diagonal_scat_sub = OBME_calc (potential , HAMILTONIAN_OP , Delta_Z , R_charge , wf , wf , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);

  complex<double> integral_bef_R = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const complex<double> sin_kr = sin (k*r);

      integral_bef_R -= sin_kr*sin_kr*Coulomb_potential.point_potential_calc (r)*w; 
    }

  integral_bef_R *= wk_two_over_Pi;

  class array<complex<double> > integral_aft_R_tab(2,2);

  for (unsigned int asy_in = 0 ; asy_in <= 1 ; asy_in++)
    for (unsigned int asy_out = 0 ; asy_out <= 1 ; asy_out++)
      {
	const complex<double> I_omega_in (0 , minus_one_pow (asy_in));
	const complex<double> I_omega_out(0 , minus_one_pow (asy_out));

	const complex<double> I_omega_in_out_sum = I_omega_in + I_omega_out;

	const complex<double> Delta_k = k*(minus_one_pow (asy_in) + minus_one_pow (asy_out));

	const unsigned int angle_index = optimal_angle_index (Delta_k);

	const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

	complex<double> integral_aft_R = 0.0;
  
	for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
	  {
	    const double w = w_aft_R_tab_GL(i);
      
	    const complex<double> z = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;

	    const complex<double> kz  = k*z;
	    
	    if (asy_in == asy_out)
	      integral_aft_R += exp (I_omega_in_out_sum*kz)*Coulomb_potential.point_potential_calc (z)*w;
	    else
	      integral_aft_R -= Coulomb_potential.point_potential_calc (z)*w;
	  }

	integral_aft_R *= 4.0*exp_Itheta;

	integral_aft_R_tab(asy_in , asy_out) = integral_aft_R;
      }

  integral_aft_R_tab *= wk_two_Pi_inv;

  H_calc_proton_diagonal_scat_sub += integral_bef_R;

  H_calc_proton_diagonal_scat_sub += integral_aft_R_tab(0,0) + integral_aft_R_tab(0,1) + integral_aft_R_tab(1,0) + integral_aft_R_tab(1,1);

  H_calc_proton_diagonal_scat_sub += Cc_Delta_Z_over_Pi*(z_log_z (k_max + k) - z_log_z (k_max - k) - 2.0*z_log_z (k));

  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      if (i != wf_index)
	{
	  const class spherical_state &wf_i = shells(i);

	  const bool S_matrix_pole_i = wf_i.get_S_matrix_pole ();

	  if (!S_matrix_pole_i)
	    {
	      const complex<double> ki = wf_i.get_k ();

	      const complex<double> wki = w_tab(i - N_res);

	      if (real (ki) > real (k))
		H_calc_proton_diagonal_scat_sub -= Cc_Delta_Z_over_Pi*wki*(log (k + ki) - log (ki - k));
	      else
		H_calc_proton_diagonal_scat_sub -= Cc_Delta_Z_over_Pi*wki*(log (k + ki) - log (k - ki));
	    }
	}
    }

  return H_calc_proton_diagonal_scat_sub;
}





void all_Hamiltonians_calc (
			    enum potential_type potential ,
			    const unsigned int N_res ,
			    const double target_mass ,
			    const double nu_mass , 
			    const double d ,
			    const double R0 ,
			    const double Vo ,
			    const double Vo_to_diag ,
			    const double Vso ,
			    const double R_charge ,
			    const int Z_charge ,
			    const int Z_charge_to_diag ,
			    const double k_max , 
			    const class array<class spherical_state> &shells , 
			    const class array<complex<double> > &w_tab , 
			    class matrix<complex<double> > &H_off , 
			    class matrix<complex<double> > &H_cut , 
			    class matrix<complex<double> > &H_sub)
{
  const unsigned int N_shells = shells.dimension (0);

  const int Delta_Z = Z_charge_to_diag - Z_charge;

  const class spherical_state &wf_zero = shells(0);
      
  const int l = wf_zero.get_l ();
      
  const enum particle_type particle = wf_zero.get_particle ();
      
  const double j = wf_zero.get_j ();
      
  const class WS_class WS_basis(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  const class WS_class WS_to_diag(false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
      
  const class WS_analytic_class WS_analytic_basis(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
  
  const class WS_analytic_class WS_analytic_to_diag(false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j );
  
  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      const class spherical_state &wf_i = shells(i);

      const complex<double> E = wf_i.get_E ();
  
      H_cut(i , i) = E + radial_integral_bef_R (potential , HAMILTONIAN_OP , Delta_Z , R_charge , wf_i , wf_i , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);

      for (unsigned int ii = 0 ; ii < i ; ii++)
	{ 
	  const class spherical_state &wf_ii = shells(ii);

	  H_cut(ii , i) = H_cut(i , ii) = radial_integral_bef_R (potential , HAMILTONIAN_OP , Delta_Z , R_charge , wf_i , wf_ii , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);
	}
    }

  if ((particle == NEUTRON) || (Delta_Z == 0)) return;

  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      const class spherical_state &wf_i = shells(i);

      const bool S_matrix_pole = wf_i.get_S_matrix_pole ();

      const complex<double> E = wf_i.get_E ();

      H_off(i , i) = E;
      H_sub(i , i) = E;

      const bool is_it_non_zero_Coulomb_proton_diag_scat = (!S_matrix_pole && (particle == PROTON) && (Delta_Z != 0));

      if (is_it_non_zero_Coulomb_proton_diag_scat)
	{
	  const complex<double> wk = w_tab(i - N_res);

	  H_off(i , i) += H_calc_proton_diagonal_scat_calc (potential , d , R0 , Vo , Vo_to_diag , Vso , R_charge , Z_charge , Z_charge_to_diag , wk , wf_i , target_mass , nu_mass);
	  
	  H_sub(i , i) += H_calc_proton_diagonal_scat_sub_calc (potential , particle , d , R0 , Vo , Vo_to_diag , Vso , R_charge , Z_charge , Z_charge_to_diag , shells , N_res , k_max , w_tab , i);
	}
      else 
	{
	  const complex<double> OBME = OBME_calc (potential , HAMILTONIAN_OP , Delta_Z , R_charge , wf_i , wf_i , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);

	  H_off(i , i) += OBME;
	  H_sub(i , i) += OBME;
	}

      for (unsigned int ii = 0 ; ii < i ; ii++)
	{ 
	  const class spherical_state &wf_ii = shells(ii);

	  const complex<double> OBME = OBME_calc (potential , HAMILTONIAN_OP , Delta_Z , R_charge , wf_i , wf_ii , WS_basis , WS_to_diag , WS_analytic_basis , WS_analytic_to_diag);

	  H_off(ii , i) = H_off(i , ii) = OBME;
	  H_sub(ii , i) = H_sub(i , ii) = OBME;
	}
    }
}





unsigned int ii_pole_calc (
			   const unsigned int N_res , 
			   const class matrix<complex<double> > &H , 
			   const class array<class spherical_state> &shells , 
			   const unsigned int index)
{
  const unsigned int N_shells = H.get_dimension ();

  const class spherical_state &u0 = shells(0);
  
  if ((u0.get_l () == 0) && (u0.get_particle () == NEUTRON) && (N_res == 1))
    return 1;
  else
    {
      unsigned int ii_pole = 0;

      for (unsigned int ii = 0 ; ii < N_shells ; ii++)
	{
	  const class vector_class<complex<double> > &Vii = H.eigenvector(ii);
	  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);

	  if (inf_norm (Vii(index)) > inf_norm (Vpole(index))) ii_pole = ii;
	} 

      return ii_pole;
    }
}


class vector_class<complex<double> > Vpole_good_phase (const class matrix<complex<double> > &H , 
						       const class array<class spherical_state> &shells , 
						       const unsigned int ii_pole)
{
  const unsigned int N_shells = H.get_dimension ();

  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);
  
  complex<double> u_r = 0;

  for (unsigned int iii = 0 ; iii < N_shells ; iii++)
    {
      const class spherical_state &shell = shells(iii);

      const class array<complex<double> > &wf_bef_R_tab_uniform = shell.get_wf_bef_R_tab_uniform ();
 
      u_r += Vpole(iii)*wf_bef_R_tab_uniform(5);
    }

  if ((abs (real (u_r)) > abs (imag (u_r))) && (real (u_r) < 0))
    return -Vpole;
  else if ((abs (real (u_r)) < abs (imag (u_r))) && (imag (u_r) < 0))
    return -Vpole;
  else
    return Vpole;
}







void RMS_calc_ck_print ( 
			enum potential_type potential ,
			const double d ,
			const double R0 ,
			const double Vo_to_diag ,
			const double Vso ,
			const double R_charge ,
			const int Z_charge ,
			const int Z_charge_to_diag ,
			const double target_mass ,
			const double nu_mass , 
			const class array<complex<double> > &k_tab ,
			const class array<complex<double> > &w_tab ,
			const class array<class spherical_state> &shells , 
			const class vector_class<complex<double> > &Vpole_off , 
			const class vector_class<complex<double> > &Vpole_cut , 
			const class vector_class<complex<double> > &Vpole_sub , 
			const int n , 
			double &RMS_r_off ,
			double &RMS_i_off , 
			double &RMS_r_cut ,
			double &RMS_i_cut , 
			double &RMS_r_sub ,
			double &RMS_i_sub)
{
  const unsigned int N_shells = shells.dimension (0); 

  const unsigned int N_scat = k_tab.dimension (0); 

  const unsigned int N_res = N_shells - N_scat;

  const class spherical_state &u0 = shells(0);
  
  const unsigned int N_uniform = u0.get_N_bef_R_uniform ();

  const unsigned int N_GL = u0.get_N_bef_R_GL ();
  
  const enum particle_type particle = u0.get_particle ();
  
  const int A = u0.get_A ();

  const int l = u0.get_l ();
  
  const double R = u0.get_R ();
  
  const double matching_point = u0.get_matching_point ();
  
  const double R_real_max = u0.get_R_real_max ();
  
  const double j = u0.get_j ();

  const int Delta_Z = Z_charge_to_diag - Z_charge;
  
  class spherical_state true_u (false , true , potential , A , Z_charge_to_diag , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 ,
				R , NADA , matching_point , R_real_max , 0.0 , 0.0 , true , particle , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);
	  
  class potentials_effective_mass T;

  T.initialize_constants (
			  true_u.get_potential () , 
			  true_u.get_kinetic_factor () , 
			  true_u.get_jr () , 
			  true_u.get_l () , 
			  true_u.get_Z_charge () , 
			  true_u.get_j () , 
			  true_u.get_k () , 
			  true_u.get_eta () , 
			  NADA);
  
  class WS_class &WS_potential = T.get_WS_potential ();
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
  
  WS_potential.initialize (false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
  
  WS_analytic_potential.initialize (false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
	
  true_u.k_search (T , true , true);
  
  true_u.wave_calculation (true , T , false);

  const array<double> &r_bef_R_tab_uniform = true_u.get_r_bef_R_tab_uniform ();

  const class array<complex<double> > &true_u_wf_bef_R_tab_uniform = true_u.get_wf_bef_R_tab_uniform ();

  RMS_r_off = RMS_i_off = 0.0;
  RMS_r_cut = RMS_i_cut = 0.0;
  RMS_r_sub = RMS_i_sub = 0.0;

  const string wfs_file_name = "wfs_comparison_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l,j) + ".dat";

  ofstream wfs_file(wfs_file_name.c_str ());

  wfs_file.precision (15);

  for (unsigned int ii = 0 ; ii < N_uniform ; ii++)
    {
      complex<double> u_r_off = 0;
      complex<double> u_r_cut = 0;
      complex<double> u_r_sub = 0;
      
      for (unsigned int iii = 0 ; iii < N_shells ; iii++)
	{
	  const class spherical_state &shell = shells(iii);

	  const class array<complex<double> > &wf_bef_R_tab_uniform = shell.get_wf_bef_R_tab_uniform ();
	  
	  const complex<double> wf_r = wf_bef_R_tab_uniform(ii);

	  u_r_cut += Vpole_cut(iii)*wf_r;

	  if ((particle == PROTON) && (Delta_Z != 0))
	    {
	      u_r_off += Vpole_off(iii)*wf_r;
	      u_r_sub += Vpole_sub(iii)*wf_r;
	    }
	}

      const double r = r_bef_R_tab_uniform(ii);

      const complex<double> &true_u_r = true_u_wf_bef_R_tab_uniform(ii);

      if ((particle == NEUTRON) || (Delta_Z == 0))
	{
	  wfs_file << r << " " 
		   << real (u_r_cut)  << " " << imag (u_r_cut)  << " " 
		   << real (true_u_r) << " " << imag (true_u_r) << endl;
	}
      else 
	{
	  wfs_file << r << " " 
		   << real (u_r_off)  << " " << imag (u_r_off)  << " " 
		   << real (u_r_cut)  << " " << imag (u_r_cut)  << " " 
		   << real (u_r_sub)  << " " << imag (u_r_sub)  << " " 
		   << real (true_u_r) << " " << imag (true_u_r) << endl;
	}

      const complex<double> wfs_difference_off = u_r_off - true_u_r;
      const complex<double> wfs_difference_cut = u_r_cut - true_u_r;
      const complex<double> wfs_difference_sub = u_r_sub - true_u_r;

      RMS_r_off += real (wfs_difference_off)*real (wfs_difference_off);
      RMS_i_off += imag (wfs_difference_off)*imag (wfs_difference_off);

      RMS_r_cut += real (wfs_difference_cut)*real (wfs_difference_cut);
      RMS_i_cut += imag (wfs_difference_cut)*imag (wfs_difference_cut);

      RMS_r_sub += real (wfs_difference_sub)*real (wfs_difference_sub);
      RMS_i_sub += imag (wfs_difference_sub)*imag (wfs_difference_sub);
    }

  RMS_r_off = sqrt (RMS_r_off/static_cast<double> (N_uniform));
  RMS_i_off = sqrt (RMS_i_off/static_cast<double> (N_uniform));

  RMS_r_cut = sqrt (RMS_r_cut/static_cast<double> (N_uniform));
  RMS_i_cut = sqrt (RMS_i_cut/static_cast<double> (N_uniform));

  RMS_r_sub = sqrt (RMS_r_sub/static_cast<double> (N_uniform));
  RMS_i_sub = sqrt (RMS_i_sub/static_cast<double> (N_uniform));

  const string wfs_ck_file_name = "wfs_ck_components_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l,j) + ".dat";

  ofstream wfs_ck_file(wfs_ck_file_name.c_str ());

  wfs_ck_file.precision (15);

  for (unsigned int i_scat = 0 ; i_scat < N_scat ; i_scat++)
    {
      const unsigned int i_shell = i_scat + N_res;

      const class spherical_state &shell = shells(i_shell);

      const bool S_matrix_pole = shell.get_S_matrix_pole ();

      if (!S_matrix_pole)
	{
	  const complex<double> k = k_tab(i_scat);
	  const complex<double> w = w_tab(i_scat);

	  const complex<double> sqrt_w = sqrt (w);
	  
	  const complex<double> ck_cut = Vpole_cut(i_shell)/sqrt_w;

	  if ((particle == NEUTRON) || (Delta_Z == 0))
	    wfs_ck_file << real (k) << " " << real (ck_cut) << " " << imag (ck_cut) << endl;
	  else
	    {
	      const complex<double> ck_off = Vpole_off(i_shell)/sqrt_w;
	      const complex<double> ck_sub = Vpole_sub(i_shell)/sqrt_w;
	  
	      wfs_ck_file << real (k) << " " << real (ck_off) << " " << imag (ck_off) << " " << real (ck_sub) << " " << imag (ck_sub) << " " << real (ck_cut) << " " << imag (ck_cut) << endl;
	    }
	}
    }
}









void print_overlaps (const class array<class spherical_state> &shells)
{
  const class WS_class dummy;
  
  const class WS_analytic_class dummy_analytic;
	
  const unsigned int N_shells = shells.dimension (0);

  double max_infinite_norm_overlap = 0.0;
  
  double infinite_norm_overlap_sum = 0.0;
  
  double infinite_norm_overlap_squares_sum = 0.0;

  unsigned int N = 0;

  for (unsigned int in = 0 ; in < N_shells ; in++)
    for (unsigned int out = 0 ; out < in ; out++)
      {
	const class spherical_state &wf_in  = shells(in);
	const class spherical_state &wf_out = shells(out);

	if ((wf_in.get_l () == wf_out.get_l ()) && (rint (wf_in.get_j () - wf_out.get_j ()) == 0.0))
	  {
	    const double infinite_norm_overlap = inf_norm (OBME_calc (NO_POTENTIAL , OVERLAP_OP , NADA , NADA , wf_in , wf_out , dummy , dummy , dummy_analytic , dummy_analytic));
	    
	    if (infinite_norm_overlap > max_infinite_norm_overlap) max_infinite_norm_overlap = infinite_norm_overlap;
	    
	    infinite_norm_overlap_sum += infinite_norm_overlap;

	    infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;

	    N++;
	  }
      }

  if (N >= 1)
    { 
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N;

      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);

      cout << "Maximal       |overlap|oo : " << max_infinite_norm_overlap << endl;
      cout << "Average       |overlap|oo : " << infinite_norm_overlap_average << endl;
      cout << "Dispersion of |overlap|oo : " << infinite_norm_overlap_sigma  << endl << endl;
    }
}













#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();

    enum potential_type potential;
    cin >> potential;
    cout << "potential : " << potential << endl;

    if ((potential != WS) && (potential != WS_ANALYTIC))
      error_message_print_abort ("The potential for basis and diagonalization must be of the form WS + Coulomb potential, generated by a uniformly charged sphere (WS) or by a Gaussian charge distribution (WS-analytic)");
      
    double d; 
    cin >> d;
    word_check_print<double> ("fm(diffuseness)" , d);

    double Vo;  
    cin >> Vo;
    word_check_print<double> ("MeV(Vo)" , Vo);

    double Vso;  
    cin >> Vso; 
    word_check_print<double> ("MeV(Vso)" , Vso);
 
    double R0;
    cin >> R0;  
    word_check_print<double> ("fm(R0)" , R0); 

    const double matching_point = R0;

    cout << endl;

    int A;
    cin >> A;
    word_check_print<int> ("(A)" , A);

    const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
    double target_mass = 0.0;

    if (!is_recoil_neglected)
      {
	cin >> target_mass;
	word_check_print<double> ("amu(mass)" , target_mass);

	if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
      }
  
    cout << endl;

    double R;
    cin >> R; 
    word_check_print<double> ("fm(rotation.point)" , R);

    double R_real_max;
    cin >> R_real_max; 
    word_check_print<double> ("fm(real.maximal.radius)" , R_real_max);

    unsigned int N_uniform;
    cin >> N_uniform;
    word_check_print<unsigned int> ("points(uniform)" , N_uniform);

    if (N_uniform < 6) error_message_print_abort ("N_uniform must be larger than 6");

    unsigned int N_GL;
    cin >> N_GL;
    word_check_print<unsigned int> ("points(Gauss.Legendre)" , N_GL);

    cout << endl;

    enum particle_type particle;
    cin >> particle;

    if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron particles only");
  
    cout << endl;
  
    int Z_charge = 0;
  
    double R_charge = 0.0;
    
    if (particle_charge_determine (particle) != 0)
      {
	cin >> Z_charge;
	word_check_print<int> ("protons(target)" , Z_charge);

	cin >> R_charge;  
	word_check_print<double> ("fm(charge.radius)" , R_charge); 
      }
  
    cout << endl;
  
    string path;
    cin >> path;
  
    const int l = determine_l (path);

    const double j = determine_j (path);
    
    if ((l == 0) && Vso != 0.0) error_message_print_abort ("Vso is zero by convention for s1/2 partial waves");

    unsigned int N_res;
    cin >> N_res;
    word_check_print<unsigned int> ("pole.state(s)" , N_res);

    class array<class spherical_state> shells_res(N_res);
  
    resonances_alloc_calc (potential , particle , l , j , N_res , d , R0 , Vo , Vso , R_charge , Z_charge , A , target_mass , N_uniform , N_GL , R , R_real_max , matching_point , shells_res);

    if ((potential == WS) && (particle == PROTON) && (R_charge != R0)) 
      error_message_print_abort ("The WS radius and the charge radius must be equal for proton if one uses a Coulomb potential generated by a uniformly charged sphere (WS)");
    
    cout << endl << particle << " " << path << " contour" << endl;

    const double nu_mass = (particle == NEUTRON) ? (neutron_mass) : (proton_mass);
  
    complex<double> k_peak;
    cin >> k_peak;
    word_check_print<complex<double> > ("fm^(-1)(k.peak)" , k_peak);

    double k_middle;
    cin >> k_middle;
    word_check_print<complex<double> > ("fm^(-1)(k.middle)" , k_middle);

    double k_max;
    cin >> k_max;
    word_check_print<double> ("fm^(-1)(k.max)" , k_max);

    unsigned int N_k_peak;
    cin >> N_k_peak;
    word_check_print<unsigned int> ("(N.k.peak)" , N_k_peak);

    unsigned int N_k_middle;
    cin >> N_k_middle;
    word_check_print<unsigned int> ("(N.k.middle)" , N_k_middle);

    unsigned int N_k_max;
    cin >> N_k_max;
    word_check_print<unsigned int> ("(N.k.max)" , N_k_max);

    cout << endl;

    double Vo_to_diag;
    cin >> Vo_to_diag;
    word_check_print<double> ("MeV(Vo.potential.to.diagonalize)" , Vo_to_diag);

    int Z_charge_to_diag = 0;

    if (particle_charge_determine (particle) != 0)
      {
	cin >> Z_charge_to_diag;
	word_check_print<int> ("protons(target.potential.to.diagonalize)" , Z_charge_to_diag);
      }

    const int Delta_Z = Z_charge_to_diag - Z_charge;

    const unsigned int N_scat = N_k_peak + N_k_middle + N_k_max;

    const unsigned int N_shells = N_res + N_scat;
	
    class array<class spherical_state> shells(N_shells);

    for (unsigned int i = 0 ; i < N_res ; i++) shells(i).allocate_fill (shells_res(i));

    shells_res.deallocate ();
  
    const double k_start = k_start_calc (false , particle , l , Z_charge , R);
    
    class array<complex<double> > k_tab(N_scat);
    class array<complex<double> > w_tab(N_scat);
  
    // three segment (debut)
    Gauss_Legendre::k_w_tab_segment_part_calc (0                     , N_k_peak   , k_start  , k_peak   , k_tab , w_tab);
    Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak              , N_k_middle , k_peak   , k_middle , k_tab , w_tab);
    Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak + N_k_middle , N_k_max    , k_middle , k_max    , k_tab , w_tab);
    // three segment (end)
    
    cout << endl;

    scattering_alloc_calc (potential , l , j , particle , N_res , N_scat , d , R0 , Vo , Vso , R_charge , Z_charge , A , target_mass , N_uniform , N_GL , R , R_real_max , matching_point , k_tab , w_tab , shells);

    cout << endl;

    print_overlaps (shells);

    class matrix<complex<double> > H_off(N_shells); 
    class matrix<complex<double> > H_sub(N_shells);  
    class matrix<complex<double> > H_cut(N_shells);

    cout << "Hamiltonian matrix dimension : " << N_shells << endl;

    all_Hamiltonians_calc (potential , N_res , target_mass , nu_mass , d , R0 , Vo , Vo_to_diag , Vso , R_charge , Z_charge , Z_charge_to_diag , k_max , shells , w_tab , H_off , H_cut , H_sub);
    
    cout << "Hamiltonian matrix built" << endl << endl;

    class array<complex<double> > eigenvalues_off(N_shells);
    class array<complex<double> > eigenvalues_sub(N_shells);
    class array<complex<double> > eigenvalues_cut(N_shells);

    if ((particle == PROTON) && (Delta_Z != 0))
      {
	total_diagonalization::symmetric::all_eigenpairs (H_off , eigenvalues_off);
	total_diagonalization::symmetric::all_eigenpairs (H_sub , eigenvalues_sub);
      }

    total_diagonalization::symmetric::all_eigenpairs (H_cut , eigenvalues_cut);

    const string lj_str = angular_state (l , j);
  
    for (unsigned int i = 0 ; i < N_res ; i++)
      {
	const string eigenstate_str = make_string<unsigned int> (i) + angular_state (l , j);
  
	cout << endl << endl;
      
	if (particle == PROTON)  cout << "------------------------"  << endl;
	if (particle == NEUTRON) cout << "-------------------------" << endl;
      
	cout << particle << " " << eigenstate_str << " eigenstate" << endl;
            
	if (particle == PROTON)  cout << "------------------------"  << endl << endl;
	if (particle == NEUTRON) cout << "-------------------------" << endl << endl;
	  
	const unsigned int ii_pole_off = ii_pole_calc (N_res , H_off , shells , i);
	const unsigned int ii_pole_sub = ii_pole_calc (N_res , H_sub , shells , i);
	const unsigned int ii_pole_cut = ii_pole_calc (N_res , H_cut , shells , i);

	const class vector_class<complex<double> > Vpole_off = Vpole_good_phase (H_off , shells , ii_pole_off);
	const class vector_class<complex<double> > Vpole_sub = Vpole_good_phase (H_sub , shells , ii_pole_sub);
	const class vector_class<complex<double> > Vpole_cut = Vpole_good_phase (H_cut , shells , ii_pole_cut);

	for (unsigned int ii = 0 ; ii < N_res ; ii++)
	  {
	    const class spherical_state &shell_ii = shells(ii);

	    const complex<double> k = shell_ii.get_k ();	    
	    const complex<double> E = shell_ii.get_E ();
	    
	    const complex<double> Vpole_square_off = Vpole_off(ii)*Vpole_off(ii);
	    const complex<double> Vpole_square_sub = Vpole_sub(ii)*Vpole_sub(ii);
	    const complex<double> Vpole_square_cut = Vpole_cut(ii)*Vpole_cut(ii);

	    cout << "basis pole state : " << shell_ii << endl;
	    cout << "-------------------------" << endl;
	  
	    cout << "k[" << shell_ii << " basis] : " << k << " fm^(-1) " <<endl;
	    cout << "E[" << shell_ii << " basis] : " << E << " MeV" << endl;

	    if ((particle == NEUTRON) || (Delta_Z == 0))
	      cout << "<" << shell_ii << " basis |" << eigenstate_str << "   eigenstate> : " << Vpole_square_cut << endl << endl;
	    else
	      {
		cout << "<" << shell_ii << " basis |" << eigenstate_str << "   eigenstate[off]> : " << Vpole_square_off << endl;
		cout << "<" << shell_ii << " basis |" << eigenstate_str << "   eigenstate[sub]> : " << Vpole_square_sub << endl;
		cout << "<" << shell_ii << " basis |" << eigenstate_str << "   eigenstate[cut]> : " << Vpole_square_cut << endl << endl;
	      }
	  }

	double RMS_r_off = 0.0 , RMS_r_sub = 0.0 , RMS_r_cut = 0.0;
	double RMS_i_off = 0.0 , RMS_i_sub = 0.0 , RMS_i_cut = 0.0;

	cout << "Direct integration" << endl;
	cout << "------------------" << endl;
	  
	RMS_calc_ck_print (potential , d , R0 , Vo_to_diag , Vso , R_charge , Z_charge , Z_charge_to_diag , target_mass , nu_mass , k_tab , w_tab , shells ,
			   Vpole_off , Vpole_cut , Vpole_sub , i , RMS_r_off , RMS_i_off , RMS_r_cut , RMS_i_cut , RMS_r_sub , RMS_i_sub);
	    
	const complex<double> E_tilde_off = eigenvalues_off(ii_pole_off);
	const complex<double> E_tilde_sub = eigenvalues_sub(ii_pole_sub);
	const complex<double> E_tilde_cut = eigenvalues_cut(ii_pole_cut);

	if ((particle == NEUTRON) || (Delta_Z == 0))
	  {
	    cout << endl << "Rms difference of diagonalized and exact wave functions" << endl;
	    cout << "-------------------------------------------------------" << endl;
	  
	    cout << "Rms[wave functions real parts difference] : " << RMS_r_cut << endl;
	    cout << "Rms[wave functions imag parts difference] : " << RMS_i_cut << endl;

	    cout << endl << "Energy from diagonalization" << endl;
	    cout << "---------------------------" << endl;
      
	    cout << "E : " << real (E_tilde_cut) << " MeV     G : " << -2000.0*imag (E_tilde_cut) << " keV" << endl;
	  }
	else
	  {
	    cout << endl << "Rms differences of diagonalized and exact wave functions" << endl;
	    cout << "--------------------------------------------------------" << endl;

	    cout << "Rms[wave functions real parts difference]    off : " << RMS_r_off << "    sub : " << RMS_r_sub << "    cut : " << RMS_r_cut << endl;
	    cout << "Rms[wave functions imag parts difference]    off : " << RMS_i_off << "    sub : " << RMS_i_sub << "    cut : " << RMS_i_cut << endl;

	    cout << endl << "Energies from diagonalization" << endl;
	    cout << "-----------------------------" << endl;
	  
	    cout << "E[off] : " << real (E_tilde_off) << " MeV     G[off] : " << -2000.0*imag (E_tilde_off) << " keV" << endl;
	    cout << "E[sub] : " << real (E_tilde_sub) << " MeV     G[sub] : " << -2000.0*imag (E_tilde_sub) << " keV" << endl;
	    cout << "E[cut] : " << real (E_tilde_cut) << " MeV     G[cut] : " << -2000.0*imag (E_tilde_cut) << " keV" << endl;
	  }
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }

