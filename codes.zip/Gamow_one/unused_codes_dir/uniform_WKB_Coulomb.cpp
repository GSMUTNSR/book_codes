// Calculation of the phi function entering the uniform WKB approximation of Coulomb wave functions at large turning point rho_t
// ----------------------------------------------------------------------------------------------------------------------------- - 
// See N. Michel, Europhysics Letters, Vol. 83, (2008), p.10002 for details.
// phi(z) is solution of phi'(z)^2 phi(z) = z/(z+1) + a.z/(z+1)^2, with the condition phi(0) = 0 and phi'(x) > 0 for real a and x.
// phi(z) is analytical and crosses no cut if |a| is small enough, hence if |rho_t| is large enough, even if Re[z] is used in the method.
// phi'(z), phi''(z), phi'''(z) are provided from the above equation and its successive differentiations.
//
// Variables
// ---------
// a: phi parameter. It is initially a = 1 - 2 eta / rho_t, with rho_t = eta + sqrt (eta^2 + l(l+1)) in the Coulomb wave function equation
// z: phi argument. It is initially z = (rho - rho_t) / rho_t in the Coulomb wave function equation
// one_plus_z, one_minus_z, z_minus_two: 1+z, 1-z, z-2
// one_plus_a, one_minus_a, sqrt_a: 1+a , 1-a , sqrt (a)
// one_plus_two_z_over_one_plus_a: 1 + 2z/(1+a)
// sqrt_az_over_one_plus_a_plus_z = sqrt (a.z/(1+a+z))
// sqrt_minus_az_over_one_plus_a_plus_z = sqrt (-a.z/(1+a+z))
// Fz_sqrt: sqrt (z.(1 + a + z)) if Re[z] >= 0, sqrt (-z.(1 + a + z)) if Re[z] < 0
// Fz_acosh: (1-a)/2 . acosh (1 + 2z/(1+a))
// Fz_atan: 2 . sqrt (a) . atan (sqrt (a.z/(1+a+z)))
// Fz_acos: (1-a)/2 . acos  (1 + 2z/(1+a))
// Fz_atanh:(1-a)/2 . atanh (sqrt (a.z/(1+a+z)))
// Fz: (2/3)   phi(z) ^(3/2) =  Fz_sqrt - Fz_acosh - Fz_atan if Re[z] >= 0
//     (2/3) (-phi(z))^(3/2) = -Fz_sqrt + Fz_acosh + Fz_atan if Re[z] < 0
// sqrt_equation: sqrt (z/(z+1) + a.z/(z+1)^2)
// sqrt_minus_equation: sqrt (-z/(z+1) + a.z/(z+1)^2)
// sqrt_phi, sqrt_minus_phi : sqrt (phi), sqrt (-phi)
// phi_square_der, phi_2der_numerator, phi_3der_numerator:
// phi_square_der = 2.phi(z).phi'(z), phi''(z) = phi_2der_numerator/phi_square_der and phi'''(z) = phi_3der_numerator/phi_square_der
// phi, phi_der, phi2_der, phi_3der: phi(z), phi'(z), phi''(z), phi'''(z)




complex<double> phi_function_calc (const complex<double> &a , const complex<double> &z)
{
  if (abs (z) < sqrt_precision) return (cbrt (1.0 + a)*z);

  const complex<double> one_plus_a = 1.0 + a , one_minus_a = 1.0 - a , sqrt_a = sqrt (a);
  const complex<double> one_plus_two_z_over_one_plus_a = 1.0 + 2.0*z/one_plus_a , one_plus_a_plus_z = one_plus_a + z;
    
  const double two_third = 0.6666666666666667 , real_z = real (z);

  if (real_z >= 0)
    {
      const complex<double> sqrt_az_over_one_plus_a_plus_z = sqrt (a*z/one_plus_a_plus_z);
      const complex<double> Fz_acosh = 0.5*one_minus_a*acosh (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_sqrt = sqrt (z*one_plus_a_plus_z);
      const complex<double> Fz_atan = 2.0*sqrt_a*atan (sqrt_az_over_one_plus_a_plus_z);
      const complex<double> Fz = Fz_sqrt - Fz_acosh - Fz_atan , phi = pow (1.5*Fz , two_third);
      
      return phi;
    }
  else
    {
      const complex<double> sqrt_minus_az_over_one_plus_a_plus_z = sqrt (-a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (-z*one_plus_a_plus_z);
      const complex<double> Fz_acos = 0.5*one_minus_a*acos (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atanh = 2.0*sqrt_a*atanh (sqrt_minus_az_over_one_plus_a_plus_z);
      const complex<double> Fz = -Fz_sqrt + Fz_acos + Fz_atanh , phi = -pow (1.5*Fz , two_third);

      return phi;
    }
}





complex<double> phi_der_function_calc (const complex<double> &a , const complex<double> &z)
{
  const complex<double> one_plus_a = 1.0 + a , one_minus_a = 1.0 - a , sqrt_a = sqrt (a);
  const complex<double> one_plus_two_z_over_one_plus_a = 1.0 + 2.0*z/one_plus_a , one_plus_z = 1.0 + z , one_plus_a_plus_z = one_plus_a + z;
    
  const double two_third = 0.6666666666666667 , real_z = real (z);

  if (real_z >= 0)
    {
      const complex<double> sqrt_az_over_one_plus_a_plus_z = sqrt (a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (z*one_plus_a_plus_z);
      const complex<double> Fz_acosh = 0.5*one_minus_a*acosh (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atan = 2.0*sqrt_a*atan (sqrt_az_over_one_plus_a_plus_z);
      const complex<double> Fz = Fz_sqrt - Fz_acosh - Fz_atan , phi = pow (1.5*Fz , two_third);
      const complex<double> sqrt_equation = sqrt ((z + a*z/one_plus_z)/one_plus_z) , sqrt_phi = sqrt (phi) , phi_der = sqrt_equation/sqrt_phi;
      
      return phi_der;
    }
  else
    {
      const complex<double> sqrt_minus_az_over_one_plus_a_plus_z = sqrt (-a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (-z*one_plus_a_plus_z);
      const complex<double> Fz_acos = 0.5*one_minus_a*acos (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atanh = 2.0*sqrt_a*atanh (sqrt_minus_az_over_one_plus_a_plus_z);
      const complex<double> Fz = -Fz_sqrt + Fz_acos + Fz_atanh , phi = -pow (1.5*Fz , two_third);
      const complex<double> sqrt_minus_equation = sqrt (-(z + a*z/one_plus_z)/one_plus_z) , sqrt_minus_phi = sqrt (-phi) , phi_der = sqrt_minus_equation/sqrt_minus_phi;

      return phi_der;
    } 
}





complex<double> phi_2der_function_calc (const complex<double> &a , const complex<double> &z)
{
  const complex<double> one_plus_a = 1.0 + a , one_minus_a = 1.0 - a , sqrt_a = sqrt (a);
  const complex<double> one_plus_two_z_over_one_plus_a = 1.0 + 2.0*z/one_plus_a , one_plus_z = 1.0 + z , one_minus_z = 1.0 - z;
  const complex<double> one_plus_a_plus_z = one_plus_a + z;
  
  const double two_third = 0.6666666666666667 , real_z = real (z);

  if (real_z >= 0)
    {
      const complex<double> sqrt_az_over_one_plus_a_plus_z = sqrt (a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (z*one_plus_a_plus_z);
      const complex<double> Fz_acosh = 0.5*one_minus_a*acosh (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atan = 2.0*sqrt_a*atan (sqrt_az_over_one_plus_a_plus_z);
      const complex<double> Fz = Fz_sqrt - Fz_acosh - Fz_atan , phi = pow (1.5*Fz , two_third);
      const complex<double> sqrt_equation = sqrt ((z + a*z/one_plus_z)/one_plus_z) , sqrt_phi = sqrt (phi) , phi_der = sqrt_equation/sqrt_phi;
      const complex<double> phi_2der_numerator = (1.0 + a*one_minus_z/one_plus_z)/(one_plus_z*one_plus_z) - phi_der*phi_der*phi_der;
      const complex<double> phi_square_der = 2.0*phi*phi_der , phi_2der = phi_2der_numerator/phi_square_der;
      
      return phi_2der;
    }
  else
    {
      const complex<double> sqrt_minus_az_over_one_plus_a_plus_z = sqrt (-a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (-z*one_plus_a_plus_z);
      const complex<double> Fz_acos = 0.5*one_minus_a*acos (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atanh = 2.0*sqrt_a*atanh (sqrt_minus_az_over_one_plus_a_plus_z);
      const complex<double> Fz = -Fz_sqrt + Fz_acos + Fz_atanh , phi = -pow (1.5*Fz , two_third);
      const complex<double> sqrt_minus_equation = sqrt (-(z + a*z/one_plus_z)/one_plus_z) , sqrt_minus_phi = sqrt (-phi) , phi_der = sqrt_minus_equation/sqrt_minus_phi;
      const complex<double> phi_2der_numerator = (1.0 + a*one_minus_z/one_plus_z)/(one_plus_z*one_plus_z) - phi_der*phi_der*phi_der;
      const complex<double> phi_square_der = 2.0*phi*phi_der , phi_2der = phi_2der_numerator/phi_square_der;

      return phi_2der;
    }
}



complex<double> phi_3der_function_calc (const complex<double> &a , const complex<double> &z)
{
  const complex<double> one_plus_a = 1.0 + a , one_minus_a = 1.0 - a , sqrt_a = sqrt (a);
  const complex<double> one_plus_two_z_over_one_plus_a = 1.0 + 2.0*z/one_plus_a , one_plus_z = 1.0 + z , one_minus_z = 1.0 - z;
  const complex<double> z_minus_two = z - 2.0 , one_plus_a_plus_z = one_plus_a + z;
 
  const double two_third = 0.6666666666666667 , real_z = real (z);

  if (real_z >= 0)
    {
      const complex<double> sqrt_az_over_one_plus_a_plus_z = sqrt (a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (z*one_plus_a_plus_z);
      const complex<double> Fz_acosh = 0.5*one_minus_a*acosh (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atan = 2.0*sqrt_a*atan (sqrt_az_over_one_plus_a_plus_z);
      const complex<double> Fz = Fz_sqrt - Fz_acosh - Fz_atan , phi = pow (1.5*Fz , two_third);
      const complex<double> sqrt_equation = sqrt ((z + a*z/one_plus_z)/one_plus_z) , sqrt_phi = sqrt (phi) , phi_der = sqrt_equation/sqrt_phi;
      const complex<double> phi_2der_numerator = (1.0 + a*one_minus_z/one_plus_z)/(one_plus_z*one_plus_z) - phi_der*phi_der*phi_der;
      const complex<double> phi_square_der = 2.0*phi*phi_der , phi_2der = phi_2der_numerator/phi_square_der;
      const complex<double> phi_3der_numerator = 2.0*(a*z_minus_two/one_plus_z - 1.0)/(one_plus_z*one_plus_z*one_plus_z) - 2.0*phi_2der*phi_2der*phi - 5.0*phi_2der*phi_der*phi_der;
      const complex<double> phi_3der = phi_3der_numerator/phi_square_der;
      
      return phi_3der;
    }
  else
    {
      const complex<double> sqrt_minus_az_over_one_plus_a_plus_z = sqrt (-a*z/one_plus_a_plus_z);
      const complex<double> Fz_sqrt = sqrt (-z*one_plus_a_plus_z);
      const complex<double> Fz_acos = 0.5*one_minus_a*acos (one_plus_two_z_over_one_plus_a);
      const complex<double> Fz_atanh = 2.0*sqrt_a*atanh (sqrt_minus_az_over_one_plus_a_plus_z);
      const complex<double> Fz = -Fz_sqrt + Fz_acos + Fz_atanh , phi = -pow (1.5*Fz , two_third);
      const complex<double> sqrt_minus_equation = sqrt (-(z + a*z/one_plus_z)/one_plus_z) , sqrt_minus_phi = sqrt (-phi) , phi_der = sqrt_minus_equation/sqrt_minus_phi;
      const complex<double> phi_2der_numerator = (1.0 + a*one_minus_z/one_plus_z)/(one_plus_z*one_plus_z) - phi_der*phi_der*phi_der;
      const complex<double> phi_square_der = 2.0*phi*phi_der , phi_2der = phi_2der_numerator/phi_square_der;
      const complex<double> phi_3der_numerator = 2.0*(a*z_minus_two/one_plus_z - 1.0)/(one_plus_z*one_plus_z*one_plus_z) - 2.0*phi_2der*phi_2der*phi - 5.0*phi_2der*phi_der*phi_der;
      const complex<double> phi_3der = phi_3der_numerator/phi_square_der;

      return phi_3der;
    }
}


