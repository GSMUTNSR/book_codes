#include "../../numlib/numlib_def/numlib_def.h"

unsigned int MASTER_THREAD , NUMBER_OF_THREADS , NUMBER_OF_PROCESSES , THIS_PROCESS;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


enum op_type {OVERLAP_OP , HAMILTONIAN , NUCLEAR_HAMILTONIAN , COULOMB_POTENTIAL};

void resonances_alloc_calc (
			    ifstream &file , 
			    const unsigned int N_res , 
			    const double d , const double R0 , const double Vo , const double Vso , 
			    const int Z_charge , const double R_charge , const int A , const double target_mass , 
			    const unsigned int N_big , const unsigned int N_GL , 
			    const double R , const double R_real_max , const double matching_point , 
			    class spherical_state * shells_res[])
{
  //:::// warning , I just put it to compile
  const bool is_there_cout = true;

  for (unsigned int i = 0 ; i < N_res ; i ++ )
    {
      string shell;
      file >> shell;
      const int n = determine_n (shell);
      const int l = determine_l (shell);
      const double j = determine_j (shell);

      enum particle_type particle;
      file >> particle;

      const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);

      class pots_eff_mass all;
      all.WS_analytic_ptr = new class WS_analytic_class(d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

      shells_res[i] = new class spherical_state (true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_big , N_big , R , NADA , matching_point , R_real_max , true , particle , n , NADA , l , j , true , 0.0 , nu_mass , 1.0 , 1.0);

      class spherical_state &shell_res = * (shells_res[i]);
      shell_res.k_search (all , true , true);
      shell_res.wave_calculation (is_there_cout , all , true);
    }
}






void k_w_tab_part_calc (
			const bool is_it_MC , 
			const unsigned int N_shift , const unsigned int N_segment , 
			const complex<double> k_deb , const complex<double> k_end , 
			class array<complex<double> > &k_tab , 
			class array<complex<double> > &w_tab)

{ 
  if (is_it_MC) 
    {
      //k_w_tab_rand_calc (N_shift , N_segment , k_deb , k_end , k_tab , w_tab);
      k_w_tab_linear_calc (N_shift , N_segment , k_deb , k_end , k_tab , w_tab);
    }
  else
    {
      class array<complex<double> > k_tab_partial(N_segment);
      class array<complex<double> > weights_tab_partial(N_segment);

      Gauss_Legendre::abscissas_weights_tables_calc (k_deb , k_end , k_tab_partial , weights_tab_partial);

      for (unsigned int i = 0 ; i < N_segment ; i ++ )
	{
	  const unsigned int index = N_shift + i;

	  k_tab(index) = k_tab_partial(i);
	  w_tab(index) = weights_tab_partial(i);
	} 
    }
}





void scattering_alloc_calc (
			    const int l , const double j , const enum particle_type particle , 
			    const unsigned int N_res , const unsigned int N_scat , 
			    const double d , const double R0 , const double Vo , const double Vso , 
			    const int Z_charge , const double R_charge , const int A , const double target_mass , 
			    const unsigned int N_big , const unsigned int N_GL , 
			    const double R , const double R_real_max , const double matching_point , 
			    const class array<complex<double> > &k_tab , 
			    const class array<complex<double> > &w_tab , 
			    class spherical_state * shells[])
{
  //:::// warning , I just put it to compile
  const bool is_there_cout = true;

  const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);

  class pots_eff_mass all;
  all.WS_analytic_ptr = new class WS_analytic_class(d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

  for (unsigned int i = 0 ; i < N_scat ; i ++ )
    {
      const unsigned int index = i + N_res;

      <<<<<<< TREE
		shells[index] = new class spherical_state (true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_big , N_big , R , NADA , matching_point , R_real_max , false , particle , index , l , j , false , k_tab(i) , nu_mass , 1.0 , NADA);
      =======
		shells[index] = new class spherical_state (true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_GL , N_GL , N_big , N_big , R , NADA , matching_point , R_real_max , false , particle , index , NADA , l , j , k_tab(i) , nu_mass , 1.0 , NADA);
		>>>>>>> MERGE-SOURCE

			  class spherical_state &shell = * (shells[index]);

		//const double kinetic_factor = shell.kinetic_factor;
		//const complex<double> k = shell.k , E = k * k/kinetic_factor;
		//const double e = real (E) , gamma = - 2.0 * imag(E);

		//cout << index << angular_state (l , j) << " " << particle << " k=" << k << " E=" << e << " MeV" << " G=" << gamma << " MeV" << endl;

		shell.wave_calculation (is_there_cout , all , true);

		const complex<double> w = w_tab(i);
		const complex<double> sqrt_w = sqrt (w);

		shell.normalization (sqrt_w);
    }
}




complex<double> radial_int_bef_R (
				  const enum op_type op , 
				  const int Z_diff , const double R_charge , 
				  const class spherical_state &wf_in , 
				  const class spherical_state &wf_out , 
				  const class WS_analytic_class &WS_basis , 
				  const class WS_analytic_class &WS_to_diag)
{
  const unsigned int N = wf_in.N_bef_R_GL;
  const enum particle_type particle = wf_in.particle;

  const complex<double> * const wf_in_bef_R = wf_in.wf_bef_R_GL;
  const complex<double> * const wf_out_bef_R = wf_out.wf_bef_R_GL;
  const double * const r_bef_R_GL = wf_in.r_bef_R_GL;
  const double * const w_bef_R_GL = wf_in.w_bef_R_GL;

  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      const double r = r_bef_R_GL[i];

      switch (op)
	{
	case OVERLAP_OP:  IF += wf_in_bef_R[i] * wf_out_bef_R[i] * w_bef_R_GL[i]; break;
	case HAMILTONIAN:  IF += wf_in_bef_R[i] * wf_out_bef_R[i] * (WS_to_diag(r) - WS_basis(r)) * w_bef_R_GL[i]; break;
	case NUCLEAR_HAMILTONIAN: IF += wf_in_bef_R[i] * wf_out_bef_R[i] * (WS_to_diag(r) - WS_basis(r)) * w_bef_R_GL[i]; break;
	case COULOMB_POTENTIAL: IF += wf_in_bef_R[i] * wf_out_bef_R[i] * Coulomb_analytic_pot (particle , Z_diff , R_charge , r) * w_bef_R_GL[i]; break;
	} 
    }

  return IF;
}




complex<double> radial_int_aft_R_part_of_4 (
					    const enum op_type op , 
					    const unsigned int asy_in , const unsigned int asy_out , 
					    const unsigned int angle , 
					    const int Z_diff , 
					    const class spherical_state &wf_in , 
					    const class spherical_state &wf_out)
{
  const unsigned int N = wf_in.N_aft_R_GL;
  const enum particle_type particle = wf_in.particle;

  if (op == NUCLEAR_HAMILTONIAN)
    {
      return 0.0; 
    }

  if ((op != OVERLAP_OP) && ((particle == NEUTRON) || (Z_diff == 0)))
    {
      return 0.0;
    }

  const double R = wf_in.R;
  const complex<double> * const sc_wf_in_aft_R = wf_in.scaled_wf_aft_R_GL[asy_in][angle];
  const complex<double> * const sc_wf_out_aft_R = wf_out.scaled_wf_aft_R_GL[asy_out][angle];
  const complex<double> exp_Itheta(cos_theta_tab[angle] , sin_theta_tab[angle]);

  const complex<double> k_in = wf_in.k;
  const complex<double> eta_in = wf_in.eta;
  const complex<double> I_omega_in(0 , minus_one_pow (asy_in));

  const complex<double> k_out = wf_out.k;
  const complex<double> eta_out = wf_out.eta;
  const complex<double> I_omega_out(0 , minus_one_pow (asy_out));

  const double * const um4_aft_R_GL = wf_in.um4_aft_R_GL;
  const double * const w_aft_R_GL = wf_in.w_aft_R_GL;

  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N ; i ++ )
    {
      const complex<double> z = R + (um4_aft_R_GL[i] - R) * exp_Itheta;
      const complex<double> k_in_z = k_in * z;
      const complex<double> k_out_z = k_out * z;

      const complex<double> log_unscale_in = (k_in != 0.0) ? (I_omega_in * (k_in_z - eta_in * (M_LN2 + log (k_in_z)))) : (0.0);
      const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out * (k_out_z - eta_out * (M_LN2 + log (k_out_z)))) : (0.0);

      const complex<double> unscale = exp (log_unscale_in + log_unscale_out);
      const complex<double> wfs_prod = sc_wf_in_aft_R[i] * sc_wf_out_aft_R[i] * unscale;

      switch (op)
	{
	case OVERLAP_OP:  IF += wfs_prod * w_aft_R_GL[i]; break;
	case HAMILTONIAN: IF += wfs_prod * Coulomb_point_pot (particle , Z_diff , z) * w_aft_R_GL[i]; break;
	case COULOMB_POTENTIAL: IF += wfs_prod * Coulomb_point_pot (particle , Z_diff , z) * w_aft_R_GL[i]; break;
	default: abort ();
	}
    }

  IF *= 4.0 * exp_Itheta;

  return IF;
}




complex<double> radial_int_aft_R (
				  const enum op_type op , const int Z_diff , 
				  const class spherical_state &wf_in , 
				  const class spherical_state &wf_out)
{
  const bool S_matrix_pole_in = wf_in.S_matrix_pole;
  const bool S_matrix_pole_out = wf_out.S_matrix_pole;

  const complex<double> k_in = wf_in.k;
  const complex<double> k_out = wf_out.k;

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (S_matrix_pole_in) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in ++ )
    {
      for (unsigned int asy_out = 0 ; (S_matrix_pole_out) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out ++ )
	{
	  const complex<double> Delta_k = k_in * minus_one_pow (asy_in) + k_out * minus_one_pow (asy_out);
	  const unsigned int angle_index = optimal_angle_index (Delta_k);

	  integral_aft_R += radial_int_aft_R_part_of_4 (op , asy_in , asy_out , angle_index , Z_diff , wf_in , wf_out);
	}
    }

  return integral_aft_R;
}




complex<double> OBME_calc (
			   const enum op_type op , 
			   const int Z_diff , const double R_charge , 
			   const class spherical_state &wf_in , 
			   const class spherical_state &wf_out , 
			   const class WS_analytic_class &WS_basis , 
			   const class WS_analytic_class &WS_to_diag)
{ 
  const complex<double> OBME_bef_R = radial_int_bef_R (op , Z_diff , R_charge , wf_in , wf_out , WS_basis , WS_to_diag);
  const complex<double> OBME_aft_R = radial_int_aft_R (op , Z_diff , wf_in , wf_out);
  const complex<double> OBME = OBME_bef_R + OBME_aft_R;

  return OBME;
}




void H_calc (
	     const unsigned int N_res , const double target_mass , const double nu_mass , 
	     const class WS_analytic_class &WS_basis , 
	     const class WS_analytic_class &WS_to_diag , 
	     const class spherical_state * const shells[] , 
	     const class array<complex<double> > &w_tab , 
	     class matrix<complex<double> > &H)
{
  //:::// warning , I just put it to compile
  const bool is_there_cout = true;

  const unsigned int N_shells = H.dim;

  const int Z_charge = WS_basis.Z_charge;
  const int Z_charge_to_diag = WS_to_diag.Z_charge;
  const int Z_diff = Z_charge_to_diag - Z_charge;

  const double d = WS_basis.d;
  const double R0 = WS_basis.R0;
  const double Vo = WS_basis.Vo;
  const double Vo_to_diag = WS_to_diag.Vo;
  const double Vso = WS_basis.Vso;

  const double R_charge = WS_basis.R_charge;

  const class WS_analytic_class dummy(NADA , NADA , NADA , NADA , NEUTRON , NADA , NADA , NADA , NADA);

  for (unsigned int i = 0 ; i < N_shells ; i ++ )
    {
      const class spherical_state &wf_i = * (shells[i]);

      const int A = wf_i.A;
      const int l = wf_i.l;

      const bool S_matrix_pole = wf_i.S_matrix_pole;

      const unsigned int N_bef_R_GL = wf_i.N_bef_R_GL;
      const unsigned int N_aft_R_GL = wf_i.N_aft_R_GL;

      const unsigned int N_bef_R_big = wf_i.N_bef_R_big;
      const unsigned int N_aft_R_big = wf_i.N_aft_R_big;

      const enum particle_type particle = wf_i.particle;

      const double R = wf_i.R;
      const double R_real_max = wf_i.R_real_max;
      const double match_point = wf_i.match_point;
      const double j = wf_i.j;
      const double kinetic_factor = wf_i.kinetic_factor;

      const complex<double> k = wf_i.k;

      const class WS_analytic_class WS_nucl_basis(d , R0 , Vo , Vso , NEUTRON , NADA , NADA , l , j);
      const class WS_analytic_class WS_nucl_to_diag(d , R0 , Vo_to_diag , Vso , NEUTRON , NADA , NADA , l , j);

      H(i , i) = k * k/kinetic_factor;

      if ((!S_matrix_pole) && (Z_diff != 0) && (particle == PROTON))
	{
	  const complex<double> w = w_tab(i - N_res);
	  const complex<double> dk = w * 0.25 * M_1_PI;
	  const complex<double> sqrt_w = sqrt (w);

	  const complex<double> k_plus = k + dk;
	  const complex<double> k_minus = k - dk;

	  class pots_eff_mass all;
	  all.WS_analytic_ptr = new class WS_analytic_class(d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

	  class spherical_state wf_i_minus (true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_big , N_aft_R_big , R , NADA , match_point , R_real_max , false , particle , NADA , l , j , k_minus , nu_mass , 1.0 , 1.0);

	  class spherical_state wf_i_plus (true , WS_ANALYTIC , A , Z_charge , target_mass , NADA , N_bef_R_GL , N_aft_R_GL , N_bef_R_big , N_aft_R_big , R , NADA , match_point , R_real_max , false , particle , NADA , l , j , k_plus , nu_mass , 1.0 , 1.0);

	  wf_i_minus.wave_calculation (is_there_cout , all , true);
	  wf_i_minus.normalization (sqrt_w);

	  wf_i_plus.wave_calculation (is_there_cout , all , true);
	  wf_i_plus.normalization (sqrt_w);

	  H(i , i) += OBME_calc (COULOMB_POTENTIAL , Z_diff , R_charge , wf_i_plus , wf_i_minus , dummy , dummy);
	  H(i , i) += OBME_calc (NUCLEAR_HAMILTONIAN , NADA , NADA , wf_i , wf_i , WS_nucl_basis , WS_nucl_to_diag);
	}
      else 
	{
	  H(i , i) += OBME_calc (HAMILTONIAN , Z_diff , R_charge , wf_i , wf_i , WS_basis , WS_to_diag);
	}

      for (unsigned int ii = 0 ; ii < i ; ii ++ )
	{ 
	  const class spherical_state &wf_ii = * (shells[ii]);

	  H(i , ii) = OBME_calc (HAMILTONIAN , Z_diff , R_charge , wf_i , wf_ii , WS_basis , WS_to_diag);
	  H(ii , i) = H(i , ii);
	}
    }
}




unsigned int ii_pole_calc (
			   const unsigned int N_res , 
			   const class matrix<complex<double> > &H , 
			   const class spherical_state * const shells[] , 
			   const unsigned int index)
{
  const unsigned int N_shells = H.dim;

  if ((shells[0] ->l == 0) && (shells[0] ->particle == NEUTRON) && (N_res == 1))
    {
      return 1;
    }
  else
    {
      unsigned int ii_pole = 0;

      for (unsigned int ii = 0 ; ii < N_shells ; ii ++ )
	{
	  const class vector_class<complex<double> > &Vii = H.eigenvector(ii);
	  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);

	  if (inf_norm (Vii(index)) > inf_norm (Vpole(index)))
	    {
	      ii_pole = ii;
	    }
	} 

      return ii_pole;
    }
}




class vector_class<complex<double> > Vpole_good_phase (
						       const class matrix<complex<double> > &H , 
						       const class spherical_state * const shells[] , 
						       const unsigned int ii_pole)
{
  const unsigned int N_shells = H.dim;

  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);

  complex<double> u_r = 0;
  for (unsigned int iii = 0 ; iii < N_shells ; iii ++ )
    {
      u_r += Vpole(iii) * shells[iii] ->wf_bef_R_big[5];
    }

  if ((abs (real (u_r)) > abs (imag (u_r))) && (real (u_r) < 0))
    {
      return - Vpole;
    }
  else if ((abs (real (u_r)) < abs (imag (u_r))) && (imag (u_r) < 0))
    {
      return - Vpole;
    }
  else
    {
      return Vpole;
    }
}




void RMS_calc (
	       const class WS_analytic_class &WS_to_diag , 
	       const double target_mass , const double nu_mass , 
	       const unsigned int N_shells , 
	       const class spherical_state * const shells[] , 
	       const class vector_class<complex<double> > &Vpole , 
	       const int n , 
	       double &RMS_r , double &RMS_i)
{
  //:::// warning , I just put it to compile
  const bool is_there_cout = true;

  const class spherical_state &u0 = * (shells[0]);

  const unsigned int N_big = u0.N_bef_R_big;
  const unsigned int N_GL = u0.N_bef_R_GL;

  const enum particle_type particle = u0.particle;

  const int A = u0.A;
  const int l = u0.l;

  const double R = u0.R;
  const double R_real_max = u0.R_real_max;
  const double match_point = 3 + 0 * u0.match_point;
  const double j = u0.j;

  const int Z_charge_to_diag = WS_to_diag.Z_charge;

  const double d = WS_to_diag.d;
  const double R0 = WS_to_diag.R0;
  const double Vo_to_diag = WS_to_diag.Vo;
  const double Vso = WS_to_diag.Vso;
  const double R_charge = WS_to_diag.R_charge;

  class pots_eff_mass all;
  all.WS_analytic_ptr = new class WS_analytic_class(d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
  class spherical_state true_u (false , WS_ANALYTIC , A , Z_charge_to_diag , target_mass , NADA , N_GL , N_GL , N_big , N_big , R , NADA , match_point , R_real_max , true , particle , n , l , j , 0.0 , nu_mass , 1.0 , 1.0);
  true_u.k_search (all , true , true);
  true_u.wave_calculation (is_there_cout , all , false);

  RMS_r = RMS_i = 0.0;

  //ofstream wfs_file("wfs_comp");

  for (unsigned int ii = 0 ; ii < N_big ; ii ++ )
    {
      complex<double> u_r = 0;
      for (unsigned int iii = 0 ; iii < N_shells ; iii ++ )
	{
	  u_r += Vpole(iii) * shells[iii] ->wf_bef_R_big[ii];
	}

      //wfs_file << r << " " << real (u_r) << " " << imag (u_r) << " " << real (true_u.wf_bef_R_big[ii]) << " " << imag (true_u.wf_bef_R_big[ii]) << endl;

      RMS_r += real (u_r - true_u.wf_bef_R_big[ii]) * real (u_r - true_u.wf_bef_R_big[ii]);
      RMS_i += imag (u_r - true_u.wf_bef_R_big[ii]) * imag (u_r - true_u.wf_bef_R_big[ii]);
    }

  RMS_r = sqrt (RMS_r/static_cast<double> (N_big));
  RMS_i = sqrt (RMS_i/static_cast<double> (N_big));
}




void print_overlap_infos (const unsigned int N_shells , const class spherical_state * const shells[])
{
  double max_inf_norm_overlap = 0.0;
  double average_inf_norm_overlap = 0.0;
  double sigma_inf_norm_overlap = 0.0;

  unsigned int N = 0;

  for (unsigned int in = 0 ; in < N_shells ; in ++ )
    {
      for (unsigned int out = 0 ; out < in ; out ++ )
	{
	  const class spherical_state &wf_in = * (shells[in]);
	  const class spherical_state &wf_out = * (shells[out]);

	  if ((wf_in.l == wf_out.l) && (rint (wf_in.j - wf_out.j) == 0.0))
	    {
	      const class WS_analytic_class dummy(NADA , NADA , NADA , NADA , NEUTRON , NADA , NADA , NADA , NADA);

	      const double inf_norm_overlap = inf_norm (OBME_calc (OVERLAP_OP , NADA , NADA , wf_in , wf_out , dummy , dummy));

	      if (inf_norm_overlap > max_inf_norm_overlap)
		{
		  max_inf_norm_overlap = inf_norm_overlap;
		}

	      average_inf_norm_overlap += inf_norm_overlap;
	      sigma_inf_norm_overlap += inf_norm_overlap * inf_norm_overlap;

	      N ++ ;
	    }
	}
    }

  if (N > 0)
    {
      average_inf_norm_overlap /= N;
      if (N >= 2)
	{
	  sigma_inf_norm_overlap = sqrt (sigma_inf_norm_overlap/(N - 1.0) - average_inf_norm_overlap * average_inf_norm_overlap * N/(N - 1.0));
	}

      //cout << "Maximal |overlap|oo:" << max_inf_norm_overlap << endl;
      //cout << "Average |overlap|oo:" << average_inf_norm_overlap << endl;
      //if (N >= 2) cout << "Dispersion of |overlap|oo:" << sigma_inf_norm_overlap << endl << endl;
    }
}





#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();
  
    THIS_PROCESS = MASTER_PROCESS;
    NUMBER_OF_PROCESSES = 1;
    is_it_MPI_parallelized = false;

    //--// stream for the input file
    string input_name;
    cin >> input_name;
    cout << "input name: " << input_name << endl;
    ifstream input_file (input_name.c_str () , ios::in);
    string dummy;
    input_file >> dummy;

    input_file >> STORAGE_DIR;
    if (access (STORAGE_DIR.c_str () , F_OK) != 0) error_message_print_abort (STORAGE_DIR + " does not exist.");
    cout << "STORAGE_DIR : " << STORAGE_DIR << endl;

    double d; 
    input_file >> d;
    word_check_print<double> (input_file , "fm(diffuseness)" , d);

    double Vo; 
    input_file >> Vo;
    word_check_print<double> (input_file , "MeV(Vo)" , Vo);

    double Vso; 
    input_file >> Vso; 
    word_check_print<double> (input_file , "MeV(Vso)" , Vso);

    double R0;
    input_file >> R0; 
    word_check_print<double> (input_file , "fm(R0)" , R0); 
    const double matching_point = R0;

    int A;
    input_file >> A;
    word_check_print<int> (input_file , "(A)" , A);

    double target_mass;
    input_file >> target_mass;
    word_check_print<double> (input_file , "amu(mass)" , target_mass);

    int Z_charge;
    input_file >> Z_charge;
    word_check_print<int> (input_file , "protons(target)" , Z_charge);

    double R_charge;
    input_file >> R_charge; 
    word_check_print<double> (input_file , "fm(charge.radius)" , R_charge); 

    double R;
    input_file >> R; 
    word_check_print<double> (input_file , "fm(rotation.point)" , R);

    double R_real_max;
    input_file >> R_real_max; 
    word_check_print<double> (input_file , "fm(maximal.radius)" , R_real_max);

    unsigned int N_big;
    input_file >> N_big;
    word_check_print<unsigned int> (input_file , "points(big)" , N_big);

    unsigned int N_GL;
    input_file >> N_GL;
    word_check_print<unsigned int> (input_file , "points(Gauss.Legendre)" , N_GL);

    unsigned int N_res;
    input_file >> N_res;
    word_check_print<unsigned int> (input_file , "pole.state(s)" , N_res);

    string path;
    input_file >> path;
    const int l = determine_l (path);
    const double j = determine_j (path);
    cout << path << endl;

    enum particle_type particle;
    input_file >> particle;
    cout << particle << endl;

    const double nu_mass = (particle == NEUTRON) ? (neutron_mass) : (proton_mass);

    class spherical_state * * shells_res = new class spherical_state * [N_res];
    resonances_alloc_calc (input_file , N_res , d , R0 , Vo , Vso , Z_charge , R_charge , A , target_mass , N_big , N_GL , R , R_real_max , matching_point , shells_res);

    complex<double> k_peak , k_middle;
    input_file >> k_peak;
    word_check_print<complex<double> > (input_file , "fm^(-1)(k.peak)" , k_peak);

    input_file >> k_middle;
    word_check_print<complex<double> > (input_file , "fm^(-1)(k.middle)" , k_middle);

    double kmax;
    input_file >> kmax;
    word_check_print<double> (input_file , "fm^(-1)(kmax)" , kmax);

    unsigned int N_k_peak;
    input_file >> N_k_peak;
    word_check_print<unsigned int> (input_file , "(N.k.peak)" , N_k_peak);

    unsigned int N_k_middle;
    input_file >> N_k_middle;
    word_check_print<unsigned int> (input_file , "(N.k.middle)" , N_k_middle);

    unsigned int N_kmax;
    input_file >> N_kmax;
    word_check_print<unsigned int> (input_file , "(N.kmax)" , N_kmax);


    double d_to_diag; 
    input_file >> d_to_diag;
    word_check_print<double> (input_file , "fm(other.diffuseness)" , d_to_diag);

    double Vo_to_diag;
    input_file >> Vo_to_diag;
    word_check_print<double> (input_file , "MeV(Vo.other.potential)" , Vo_to_diag);

    int Z_charge_to_diag;
    input_file >> Z_charge_to_diag;
    word_check_print<int> (input_file , "protons(other.target)" , Z_charge_to_diag);

    unsigned int N_MC;
    input_file >> N_MC;
    word_check_print<unsigned int> (input_file , "Monte-Carlo.tries" , N_MC);

    const class WS_analytic_class WS_basis(d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);
    const class WS_analytic_class WS_to_diag(d_to_diag , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);

    const unsigned int N_scat = N_k_peak + N_k_middle + N_kmax;
    const unsigned int N_shells = N_res + N_scat;

    class spherical_state * * shells = new class spherical_state * [N_shells];

    for (unsigned int i = 0 ; i < N_res ; i ++ )
      {
	shells[i] = shells_res[i];
      }

    const unsigned int time_for_random = static_cast<unsigned int> (time (NULL)); 

    class array<complex<double> > k_tab(N_scat);
    class array<complex<double> > w_tab(N_scat);

    class matrix<complex<double> > H(N_shells); 
    class array<complex<double> > eigenvalues(N_shells);

    //complex<double> E_tilde_average = 0.0;
    vector<complex<double> > vec_E_tilde_average (N_res , 0.0);

    for (unsigned int try_MC = 0 ; try_MC < N_MC ; try_MC ++ ) 
      {
	srand (time_for_random + try_MC);

	k_w_tab_part_calc (true , 0 , N_k_peak , k_start_calc (false , particle , l , Z_charge , R) , k_peak , k_tab , w_tab);
	k_w_tab_part_calc (true , N_k_peak , N_k_middle , k_peak , k_middle , k_tab , w_tab);
	k_w_tab_part_calc (true , N_k_peak + N_k_middle , N_kmax , k_middle , kmax , k_tab , w_tab);

	scattering_alloc_calc (l , j , particle , N_res , N_scat , d , R0 , Vo , Vso , Z_charge , R_charge , A , target_mass , N_big , N_GL , R , R_real_max , matching_point , k_tab , w_tab , shells);

	H_calc (N_res , target_mass , nu_mass , WS_basis , WS_to_diag , shells , w_tab , H);

	total_diag::all_eigenpairs (H , eigenvalues);

	for (unsigned int i = 0 ; i < N_res ; i ++ )
	  {
	    const unsigned int ii_pole = ii_pole_calc (N_res , H , shells , i);
	    const complex<double> E_tilde = eigenvalues(ii_pole);

	    const double E = real (E_tilde);
	    const double Gamma = - 2000.0 * imag (E_tilde);

	    cout << "Try:" << try_MC << " E_tilde:" << E_tilde << " E:" << E << " MeV" << " Gamma:" << Gamma << " keV." << endl;

	    //E_tilde_average += E_tilde/N_MC; 
	    vec_E_tilde_average[i] += E_tilde/N_MC;
	  }

	for (unsigned int i = N_res ; i < N_shells ; i ++ )
	  {
	    delete shells[i];
	  }
      }

    //const double E_average = real (E_tilde_average);
    //const double Gamma_average = - 2000.0 * imag (E_tilde_average);
    vector<double> vec_E_average (N_res);
    vector<double> vec_Gamma_average (N_res);
    for (unsigned int i = 0 ; i < N_res ; i++)
      {
	vec_E_average[i] = real (vec_E_tilde_average[i]);
	vec_Gamma_average[i] = - 2000.0 * imag (vec_E_tilde_average[i]);
      }

    cout << endl << "Average from all Monte-Carlo values" << endl;
    //cout << "E_tilde:" << E_tilde_average << " E:" << E_average << " MeV" << " Gamma:" << Gamma_average << " keV." << endl;
    for (unsigned int i = 0 ; i < N_res ; i++)
      {
	cout << "E_tilde:" << vec_E_tilde_average[i] << " E:" << vec_E_average[i] << " MeV" << " Gamma:" << vec_Gamma_average[i] << " keV." << endl;
      }

    k_w_tab_part_calc (false , 0 , N_k_peak , k_start_calc (false , particle , l , Z_charge , R) , k_peak , k_tab , w_tab);
    k_w_tab_part_calc (false , N_k_peak , N_k_middle , k_peak , k_middle , k_tab , w_tab);
    k_w_tab_part_calc (false , N_k_peak + N_k_middle , N_kmax , k_middle , kmax , k_tab , w_tab);

    scattering_alloc_calc (l , j , particle , N_res , N_scat , d , R0 , Vo , Vso , Z_charge , R_charge , A , target_mass , N_big , N_GL , R , R_real_max , matching_point , k_tab , w_tab , shells);

    H_calc (N_res , target_mass , nu_mass , WS_basis , WS_to_diag , shells , w_tab , H);

    total_diag::all_eigenpairs_inverse_iteration (H , eigenvalues , 1e-7);

    for (unsigned int i = 0 ; i < N_res ; i ++ )
      {
	const unsigned int ii_pole = ii_pole_calc (N_res , H , shells , i);
	const complex<double> E_tilde = eigenvalues(ii_pole);

	const double E = real (E_tilde);
	const double Gamma = - 2000.0 * imag (E_tilde);

	cout << endl << "Gauss - Legendre integration" << endl;
	cout << "E_tilde:" << E_tilde << " E:" << E << " MeV" << " Gamma:" << Gamma << " keV." << endl;
      }

    delete [] shells_res;

    for (unsigned int i = N_res ; i < N_shells ; i ++ )
      {
	delete shells[i];
      }

    delete [] shells;

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }



