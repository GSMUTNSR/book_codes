#include "../../numlib/numlib_def/numlib_def.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

enum op_type {OVERLAP_OP , H_NO_CENTRIFUGAL_OP , CENTRIFUGAL_OP};


using namespace string_routines;


void resonances_alloc_calc (
			    const enum particle_type particle ,
			    const int l_path ,
			    const double j_path ,
			    const unsigned int N_res , 
			    const double Lambda , 
			    const double s , 
			    const double nu , 
			    const double a , 
			    const int A , 
			    const double target_mass , 
			    const unsigned int N_uniform , 
			    const unsigned int N_GL , 
			    const double R , 
			    const double matching_point , 
			    const double R_real_max , 
			    class array<class spherical_state> &shells)
{
  cout << endl << "Pole basis states" << endl;
  cout << "-----------------" << endl;
 
  for (unsigned int i = 0 ; i < N_res ; i++)
    {
      string shell;
      cin >> shell;

      const int n = determine_n (shell);
      const int l = determine_l (shell);

      const double j = determine_j (shell);

      if (!same_lj (l , j , l_path , j_path)) error_message_print_abort ("Resonances do not have correct angular momenta");

      const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);

      const double kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);
	
      class spherical_state &shell_res = shells(i);

      shell_res.allocate (false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , 
			  R , NADA , matching_point , R_real_max , 0.0 , 0.0 , true , particle , n , NADA , l , j , true , 0.0 , nu_mass , 1.0 , 1.0);

      class potentials_effective_mass T;

      T.initialize_constants (
			      shell_res.get_potential () , 
			      shell_res.get_kinetic_factor () ,
			      shell_res.get_jr () , 
			      shell_res.get_l () , 
			      shell_res.get_Z_charge () , 
			      shell_res.get_j () , 
			      shell_res.get_k () , 
			      shell_res.get_eta () , 
			      NADA);
      
      class PTG_class &PTG_potential = T.get_PTG_potential ();

      PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);

      shell_res.PTG_eigenstate_calc (true , PTG_potential); 
    }
}













void scattering_alloc_calc (
			    const enum particle_type particle , 
			    const int l , 
			    const double j , 
			    const unsigned int N_res , 
			    const unsigned int N_scat , 
			    const double Lambda , 
			    const double s , 
			    const double nu , 
			    const double a , 
			    const int A , 
			    const double target_mass , 
			    const unsigned int N_uniform , 
			    const unsigned int N_GL , 
			    const double R , 
			    const double matching_point , 
			    const double R_real_max , 
			    const class array<complex<double> > &k_tab , 
			    const class array<complex<double> > &w_tab , 
			    class array<class spherical_state> &shells)
{    
  const double nu_mass = (particle == PROTON) ? (proton_mass) : (neutron_mass);

  const double kinetic_factor = kinetic_factor_calc (false , target_mass , nu_mass);

  class potentials_effective_mass T;
  
  class PTG_class &PTG_potential = T.get_PTG_potential ();
  
  PTG_potential.initialize (kinetic_factor , l , Lambda , s , nu , a);

  cout << endl << "Scattering basis states" << endl;
  cout << "----------------------" << endl;
  
  for (unsigned int i = 0 ; i < N_scat ; i++)
    {
      const unsigned int index = i + N_res;
  
      const int n = static_cast<int> (index) + 1;

      class spherical_state &shell = shells(index);

      shell.allocate (false , true , PTG_POTENTIAL , A , 0 , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 ,
		      R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , particle , n , NADA , l , j , false , k_tab(i) , nu_mass , 1.0 , NADA);

      const complex<double> k = shell.get_k ();

      const complex<double> w = w_tab(i);

      const complex<double> E_tilde = shell.get_E ();
      
      const double E = real (E_tilde);

      const double Gamma = -2.0*imag (E_tilde);

      cout << n << angular_state (l , j) << " " << particle << " k : " << k << "   E : " << E << " MeV   G : " << Gamma << " MeV" << endl;

      T.initialize_constants (
			      shell.get_potential () , 
			      shell.get_kinetic_factor () , 
			      shell.get_jr () , 
			      shell.get_l () , 
			      shell.get_Z_charge () , 
			      shell.get_j () , 
			      shell.get_k () , 
			      shell.get_eta () , 
			      NADA);
		
      shell.PTG_eigenstate_calc (true , PTG_potential);

      shell.normalization (sqrt (w));
    }
}





complex<double> radial_integral_bef_R (
				       const enum op_type op , 
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out , 
				       const class WS_analytic_class &WS_to_diag)
{
  const int l = wf_in.get_l ();
  
  const int llp1 = l*(l + 1);
  
  const double kinetic_factor = wf_in.get_kinetic_factor ();
  
  const unsigned int N_bef_R_GL = wf_in.get_N_bef_R_GL ();

  const complex<double> E_in = wf_in.get_E ();

  const complex<double> E_out = wf_out.get_E ();

  const complex<double> E_sum = 0.5*(E_in + E_out);

  const class array<double> &r_bef_R_tab_GL = wf_in.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = wf_in.get_w_bef_R_tab_GL ();
  
  const class array<complex<double> > &wf_in_bef_R_tab_GL = wf_in.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_out_bef_R_tab_GL = wf_out.get_wf_bef_R_tab_GL ();

  const class array<complex<double> > &d2wf_in_bef_R_tab_GL = wf_in.get_d2wf_bef_R_tab_GL ();
  const class array<complex<double> > &d2wf_out_bef_R_tab_GL = wf_out.get_d2wf_bef_R_tab_GL ();

  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double r2 = r*r;

      switch (op)
	{
	case OVERLAP_OP:      IF += wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*w; break;

	case CENTRIFUGAL_OP:  IF += wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i)*(llp1/(r2*kinetic_factor))*w; break;

	case H_NO_CENTRIFUGAL_OP: 
	  {
	    const complex<double> term_d2wf = -0.5*(d2wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i) + wf_in_bef_R_tab_GL(i)*d2wf_out_bef_R_tab_GL(i))/kinetic_factor;

	    const complex<double> term_E_pot = (WS_to_diag(r) - E_sum)*wf_in_bef_R_tab_GL(i)*wf_out_bef_R_tab_GL(i);

	    IF += (term_d2wf + term_E_pot)*w;

	  } break;

	default: break;
	} 
    }

  return IF;
}














complex<double> radial_integral_aft_R_part_of_four (
						    const enum op_type op , 
						    const unsigned int asy_in , 
						    const unsigned int asy_out , 
						    const unsigned int angle_index , 
						    const int Z_charge_to_diag , 
						    const class spherical_state &wf_in , 
						    const class spherical_state &wf_out)
{
  const unsigned int N_aft_R_GL = wf_in.get_N_aft_R_GL ();

  const enum particle_type particle = wf_in.get_particle ();

  const int l = wf_in.get_l ();

  const int llp1 = l*(l+1);

  const double R = wf_in.get_R ();

  const double kinetic_factor = wf_in.get_kinetic_factor ();

  const complex<double> exp_Itheta(cos_theta_tab[angle_index] , sin_theta_tab[angle_index]);

  const complex<double> k_in  = wf_in.get_k ();
  const complex<double> k_out = wf_out.get_k ();

  const complex<double> eta_in  = wf_in.get_eta ();
  const complex<double> eta_out = wf_out.get_eta ();

  const complex<double> I_omega_in (0 , minus_one_pow (asy_in));
  const complex<double> I_omega_out(0 , minus_one_pow (asy_out));

  const class array<double> &w_aft_R_tab_GL = wf_in.get_w_aft_R_tab_GL ();

  const class array<double> &um4_aft_R_tab_GL = wf_in.get_um4_aft_R_tab_GL ();
  
  const class array<complex<double> > &scaled_wf_in_aft_R_tab_GL  = wf_in.get_scaled_wf_aft_R_tab_GL ();
  const class array<complex<double> > &scaled_wf_out_aft_R_tab_GL = wf_out.get_scaled_wf_aft_R_tab_GL ();
  
  const class Coulomb_potential_class Coulomb_potential(false , particle , Z_charge_to_diag , NADA);
  
  complex<double> IF = 0.0;

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double w = w_aft_R_tab_GL(i);

      const complex<double> z = R + (um4_aft_R_tab_GL(i) - R)*exp_Itheta;

      const complex<double> k_in_z = k_in*z;
      const complex<double> k_out_z = k_out*z;

      const complex<double> z2 = z*z;

      const complex<double> log_unscale_in  = (k_in  != 0.0) ? (I_omega_in *(k_in_z  - eta_in *(M_LN2 + log (k_in_z))))  : (0.0);
      const complex<double> log_unscale_out = (k_out != 0.0) ? (I_omega_out*(k_out_z - eta_out*(M_LN2 + log (k_out_z)))) : (0.0);

      const complex<double> unscale = exp (log_unscale_in + log_unscale_out);

      switch (op)
	{
	case OVERLAP_OP:          IF += scaled_wf_in_aft_R_tab_GL(asy_in , angle_index , i)*scaled_wf_out_aft_R_tab_GL(asy_out , angle_index , i)*unscale*w; break;

	case H_NO_CENTRIFUGAL_OP: IF += scaled_wf_in_aft_R_tab_GL(asy_in , angle_index , i)*scaled_wf_out_aft_R_tab_GL(asy_out , angle_index , i)*Coulomb_potential.point_potential_calc (z)*unscale*w; break;

	case CENTRIFUGAL_OP:      IF += scaled_wf_in_aft_R_tab_GL(asy_in , angle_index , i)*scaled_wf_out_aft_R_tab_GL(asy_out , angle_index , i)*(llp1/(z2*kinetic_factor))*unscale*w; break;

	default: break;
	}
    }

  IF *= 4.0*exp_Itheta;

  return IF;
}








complex<double> radial_integral_aft_R (
				       const enum op_type op , 
				       const int Z_charge_to_diag , 
				       const class spherical_state &wf_in , 
				       const class spherical_state &wf_out)
{
  if (op != OVERLAP_OP) return 0.0;

  const bool S_matrix_pole_in  = wf_in.get_S_matrix_pole ();
  const bool S_matrix_pole_out = wf_out.get_S_matrix_pole ();

  const complex<double> k_in  = wf_in.get_k ();
  const complex<double> k_out = wf_out.get_k ();

  complex<double> integral_aft_R = 0.0;

  for (unsigned int asy_in = 0 ; (S_matrix_pole_in) ? (asy_in <= 0) : (asy_in <= 1) ; asy_in++)
    for (unsigned int asy_out = 0 ; (S_matrix_pole_out) ? (asy_out <= 0) : (asy_out <= 1) ; asy_out++)
      {
	const complex<double> Delta_k = k_in*minus_one_pow (asy_in) + k_out*minus_one_pow (asy_out);

	const unsigned int angle_index = optimal_angle_index (Delta_k);

	integral_aft_R += radial_integral_aft_R_part_of_four (op , asy_in , asy_out , angle_index , Z_charge_to_diag , wf_in , wf_out);
      }

  return integral_aft_R;
}




complex<double> OBME_calc (
			   const enum op_type op , 
			   const class spherical_state &wf_in , 
			   const class spherical_state &wf_out , 
			   const class WS_analytic_class &WS_to_diag)
{ 
  const int Z_charge_to_diag = WS_to_diag.get_Z_charge ();

  const complex<double> OBME_bef_R = radial_integral_bef_R (op , wf_in , wf_out , WS_to_diag);

  const complex<double> OBME_aft_R = radial_integral_aft_R (op , Z_charge_to_diag , wf_in , wf_out);

  const complex<double> OBME = OBME_bef_R + OBME_aft_R;

  return OBME;
}







void H_calc (
	     const unsigned int N_res , 
	     const double target_mass , 
	     const double nu_mass , 
	     const class PTG_class &PTG_basis , 
	     const class WS_analytic_class &WS_to_diag , 
	     const class array<class spherical_state> &shells , 
	     const class array<complex<double> > &w_tab , 
	     class matrix<complex<double> > &H)
{
  const int Z_charge = WS_to_diag.get_Z_charge ();

  const unsigned int N_shells = H.get_dimension ();

  for (unsigned int i = 0 ; i < N_shells ; i++)
    {
      const class spherical_state &wf_i = shells(i);

      const int A = wf_i.get_A () , l = wf_i.get_l ();

      const bool S_matrix_pole = wf_i.get_S_matrix_pole ();

      const unsigned int N_bef_R_GL = wf_i.get_N_bef_R_GL ();
      const unsigned int N_aft_R_GL = wf_i.get_N_aft_R_GL ();

      const unsigned int N_bef_R_uniform = wf_i.get_N_bef_R_uniform ();
      const unsigned int N_aft_R_uniform = wf_i.get_N_aft_R_uniform ();

      const enum particle_type particle = wf_i.get_particle ();

      const double R = wf_i.get_R ();
      
      const double R_real_max = wf_i.get_R_real_max ();
      
      const double matching_point = wf_i.get_matching_point ();
      
      const double j = wf_i.get_j ();

      const complex<double> k = wf_i.get_k ();

      const complex<double> E = wf_i.get_E ();

      if ((!S_matrix_pole) && (Z_charge != 0) && (particle == PROTON))
	{
	  const complex<double> &w = w_tab(i - N_res);

	  const complex<double> sqrt_w = sqrt (w);

	  const complex<double> dk = w*0.25*M_1_PI;
	  
	  const complex<double> k_minus = k - dk;
	  const complex<double> k_plus  = k + dk;

	  class spherical_state wf_i_minus (false , true , PTG_POTENTIAL , A , Z_charge , target_mass , NADA ,
					    N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
					    R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , particle , NADA , NADA , l , j , false , k_minus , nu_mass , 1.0 , 1.0);

	  class spherical_state wf_i_plus (false , true , PTG_POTENTIAL , A , Z_charge , target_mass , NADA ,
					   N_bef_R_GL , N_aft_R_GL , N_bef_R_uniform , N_aft_R_uniform , 0 , 0 ,
					   R , NADA , matching_point , R_real_max , 0.0 , 0.0 , false , particle , NADA , NADA , l , j , false , k_plus , nu_mass , 1.0 , 1.0);

	  class potentials_effective_mass T;

	  class PTG_class &PTG_potential = T.get_PTG_potential ();

	  PTG_potential.initialize (PTG_basis);
			
	  T.initialize_constants (
				  wf_i_minus.get_potential () , 
				  wf_i_minus.get_kinetic_factor () , 
				  wf_i_minus.get_jr () , 
				  wf_i_minus.get_l () ,
				  wf_i_minus.get_Z_charge () , 
				  wf_i_minus.get_j () , 
				  wf_i_minus.get_k () , 
				  wf_i_minus.get_eta () , 
				  NADA);

	  wf_i_minus.PTG_eigenstate_calc (true , PTG_potential);

	  wf_i_minus.normalization (sqrt_w);

	  T.initialize_constants (
				  wf_i_plus.get_potential () , 
				  wf_i_plus.get_kinetic_factor () , 
				  wf_i_plus.get_jr () , 
				  wf_i_plus.get_l () ,
				  wf_i_plus.get_Z_charge () , 
				  wf_i_plus.get_j () , 
				  wf_i_plus.get_k () , 
				  wf_i_plus.get_eta () , 
				  NADA);

	  wf_i_plus.PTG_eigenstate_calc (true , PTG_potential);

	  wf_i_plus.normalization (sqrt_w);

	  H(i , i) = OBME_calc (H_NO_CENTRIFUGAL_OP , wf_i_plus , wf_i_minus , WS_to_diag) + OBME_calc (CENTRIFUGAL_OP , wf_i , wf_i , WS_to_diag);
	}
      else
	H(i , i) = OBME_calc (H_NO_CENTRIFUGAL_OP , wf_i , wf_i , WS_to_diag) + OBME_calc (CENTRIFUGAL_OP , wf_i , wf_i , WS_to_diag);

      H(i , i) += E;

      for (unsigned int ii = 0 ; ii < i ; ii++)
	{ 
	  const class spherical_state &wf_ii = shells(ii);

	  H(ii , i) = H(i , ii) = OBME_calc (H_NO_CENTRIFUGAL_OP , wf_i , wf_ii , WS_to_diag) + OBME_calc (CENTRIFUGAL_OP , wf_i , wf_ii , WS_to_diag);
	}
    }
}




unsigned int ii_pole_calc (
			   const unsigned int N_res , 
			   const class matrix<complex<double> > &H , 
			   const class array<class spherical_state> &shells , 
			   const unsigned int index)
{
  const unsigned int N_shells = H.get_dimension ();

  if ((shells(0).get_l () == 0) && (shells(0).get_particle () == NEUTRON) && (N_res == 1))
    return 1;
  else
    {
      unsigned int ii_pole = 0;

      for (unsigned int ii = 0 ; ii < N_shells ; ii++)
	{
	  const class vector_class<complex<double> > &Vii = H.eigenvector(ii);

	  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);

	  if (inf_norm (Vii(index)) > inf_norm (Vpole(index))) ii_pole = ii;
	} 

      return ii_pole;
    }
}



class vector_class<complex<double> > Vpole_good_phase (
						       const class matrix<complex<double> > &H , 
						       const class array<class spherical_state> &shells , 
						       const unsigned int ii_pole)
{
  const unsigned int N_shells = H.get_dimension ();

  const class vector_class<complex<double> > &Vpole = H.eigenvector(ii_pole);
 
  complex<double> u_r = 0;

  for (unsigned int iii = 0 ; iii < N_shells ; iii++)
    {
      const class spherical_state &shell = shells(iii);

      const class array<complex<double> > &wf_bef_R_tab_uniform = shell.get_wf_bef_R_tab_uniform ();
 
      u_r += Vpole(iii)*wf_bef_R_tab_uniform(5);
    }

  if ((abs (real (u_r)) > abs (imag (u_r))) && (real (u_r) < 0))
    return -Vpole;
  else if ((abs (real (u_r)) < abs (imag (u_r))) && (imag (u_r) < 0))
    return -Vpole;
  else
    return Vpole;
}





void RMS_calc (
	       const class WS_analytic_class &WS_to_diag , 
	       const double target_mass ,
	       const double nu_mass ,
	       const class array<complex<double> > &k_tab , 
	       const class array<complex<double> > &w_tab ,
	       const class array<class spherical_state> &shells , 
	       const class vector_class<complex<double> > &Vpole , 
	       const int n , 
	       double &RMS_r ,
	       double &RMS_i)
{
  const unsigned int N_shells = shells.dimension (0); 

  const unsigned int N_scat = k_tab.dimension (0); 

  const unsigned int N_res = N_shells - N_scat;

  const class spherical_state &u0 = shells(0);
  
  const unsigned int N_uniform = u0.get_N_bef_R_uniform ();

  const unsigned int N_GL = u0.get_N_bef_R_GL ();
  
  const enum particle_type particle = u0.get_particle ();
  
  const int A = u0.get_A ();

  const int l = u0.get_l ();
  
  const double R = u0.get_R ();
  
  const double matching_point = u0.get_matching_point ();
  
  const double R_real_max = u0.get_R_real_max ();
  
  const double j = u0.get_j ();

  const int Z_charge_to_diag = WS_to_diag.get_Z_charge ();

  const double d = WS_to_diag.get_d (); 

  const double R0 = WS_to_diag.get_R0 (); 

  const double Vo_to_diag = WS_to_diag.get_Vo (); 

  const double Vso = WS_to_diag.get_Vso (); 

  const double R_charge = WS_to_diag.get_R_charge ();

  class spherical_state true_u (false , true , WS_ANALYTIC , A , Z_charge_to_diag , target_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 ,
				R , NADA , matching_point , R_real_max , 0.0 , 0.0 , true , particle , n , NADA , l , j , true , NADA , nu_mass , 1.0 , 1.0);
	
  const class array<complex<double> > &true_wf_bef_R_tab_uniform = true_u.get_wf_bef_R_tab_uniform ();
  
  const string wfs_file_name = "wfs_comparison_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l,j) + ".dat";

  ofstream wfs_file(wfs_file_name.c_str ());

  wfs_file.precision (15);
  
  class potentials_effective_mass T;

  T.initialize_constants (
			  true_u.get_potential () , 
			  true_u.get_kinetic_factor () , 
			  true_u.get_jr () , 
			  true_u.get_l () , 
			  true_u.get_Z_charge () , 
			  true_u.get_j () , 
			  true_u.get_k () , 
			  true_u.get_eta () , 
			  NADA);
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  WS_analytic_potential.initialize (false , d , R0 , Vo_to_diag , Vso , particle , Z_charge_to_diag , R_charge , l , j);
	
  true_u.k_search (T , true , true);

  true_u.wave_calculation (true , T , false);

  const array<double> &r_bef_R_tab_uniform = true_u.get_r_bef_R_tab_uniform ();

  const class array<complex<double> > &true_u_wf_bef_R_tab_uniform = true_u.get_wf_bef_R_tab_uniform ();

  RMS_r = RMS_i = 0.0;

  for (unsigned int ii = 0 ; ii < N_uniform ; ii++)
    {
      complex<double> u_r = 0;
      
      for (unsigned int iii = 0 ; iii < N_shells ; iii++)
	{
	  const class spherical_state &shell = shells(iii);

	  const class array<complex<double> > &wf_bef_R_tab_uniform = shell.get_wf_bef_R_tab_uniform ();
	  
	  const complex<double> wf_r = wf_bef_R_tab_uniform(ii);

	  u_r += Vpole(iii)*wf_r;
	}

      const double r = r_bef_R_tab_uniform(ii);

      const complex<double> &true_u_r = true_u_wf_bef_R_tab_uniform(ii);

      wfs_file << r << " " 
	       << real (u_r)      << " " << imag (u_r)      << " " 
	       << real (true_u_r) << " " << imag (true_u_r) << endl;
      
      const complex<double> wfs_difference = u_r - true_wf_bef_R_tab_uniform(ii);

      RMS_r += real (wfs_difference)*real (wfs_difference);
      RMS_i += imag (wfs_difference)*imag (wfs_difference);
    }

  RMS_r = sqrt (RMS_r/static_cast<double> (N_uniform));
  RMS_i = sqrt (RMS_i/static_cast<double> (N_uniform));

  const string wf_ck_file_name = "wf_ck_components_" + make_string<enum particle_type> (particle) + "_" + make_string<int> (n) + angular_state_for_file_name (l,j) + ".dat";

  ofstream wf_ck_file(wf_ck_file_name.c_str ());

  wf_ck_file.precision (15);

  for (unsigned int i_scat = 0 ; i_scat < N_scat ; i_scat++)
    {
      const unsigned int i_shell = i_scat + N_res;

      const class spherical_state &shell = shells(i_shell);

      const bool S_matrix_pole = shell.get_S_matrix_pole ();

      if (!S_matrix_pole)
	{   
	  const complex<double> k = k_tab(i_scat);
	  const complex<double> w = w_tab(i_scat);

	  const complex<double> sqrt_w = sqrt (w);
	  
	  const complex<double> ck = Vpole(i_shell)/sqrt_w;

	  wf_ck_file << real (k) << " " << real (ck) << " " << imag (ck) << endl;
	}
    }
}











void print_overlaps (const class array<class spherical_state> &shells)
{
  const class WS_analytic_class dummy;
	
  const unsigned int N_shells = shells.dimension (0);

  double max_infinite_norm_overlap = 0.0;
  
  double infinite_norm_overlap_sum = 0.0;
  
  double infinite_norm_overlap_squares_sum = 0.0;

  unsigned int N = 0;

  for (unsigned int in = 0 ; in < N_shells ; in++)
    for (unsigned int out = 0 ; out < in ; out++)
      {
	const class spherical_state &wf_in  = shells(in);
	const class spherical_state &wf_out = shells(out);

	if ((wf_in.get_l () == wf_out.get_l ()) && (rint (wf_in.get_j () - wf_out.get_j ()) == 0.0))
	  {
	    const double infinite_norm_overlap = inf_norm (OBME_calc (OVERLAP_OP , wf_in , wf_out , dummy));
	    
	    if (infinite_norm_overlap > max_infinite_norm_overlap) max_infinite_norm_overlap = infinite_norm_overlap;
	    
	    infinite_norm_overlap_sum += infinite_norm_overlap;

	    infinite_norm_overlap_squares_sum += infinite_norm_overlap*infinite_norm_overlap;

	    N++;
	  }
      }

  if (N >= 1)
    { 
      const double infinite_norm_overlap_average = infinite_norm_overlap_sum/N;

      const double infinite_norm_overlap_sigma = statistical_sigma_calc (N , infinite_norm_overlap_sum , infinite_norm_overlap_squares_sum);

      cout << "Maximal       |overlap|oo : " << max_infinite_norm_overlap << endl;
      cout << "Average       |overlap|oo : " << infinite_norm_overlap_average << endl;
      cout << "Dispersion of |overlap|oo : " << infinite_norm_overlap_sigma  << endl << endl;
    }
}






#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();

    double Lambda;
    cin >> Lambda;
    word_check_print<double> ("(Lambda)" , Lambda);

    double s;
    cin >> s;
    word_check_print<double> ("(s)" , s);

    double nu;
    cin >> nu;
    word_check_print<double> ("(nu)" , nu);

    double a;
    cin >> a;
    word_check_print<double> ("(a)" , a);

    cout << endl;

    double d; 
    cin >> d;
    word_check_print<double> ("fm(diffuseness)" , d);

    double Vo;  
    cin >> Vo;
    word_check_print<double> ("MeV(Vo)" , Vo);

    double Vso;  
    cin >> Vso; 
    word_check_print<double> ("MeV(Vso)" , Vso);
  
    double R0;
    cin >> R0;  
    word_check_print<double> ("fm(R0)" , R0); 

    const double matching_point = R0;

    int A;
    cin >> A;
    word_check_print<int> ("(A)" , A);

    const bool is_recoil_neglected = bool_determination ("target.recoil.neglected");
  
    double target_mass = 0.0;

    if (!is_recoil_neglected)
      {
	cin >> target_mass;
	word_check_print<double> ("amu(mass)" , target_mass);

	if (target_mass <= 0.0) error_message_print_abort ("Target mass must be positive");
      }

    cout << endl;

    double R;
    cin >> R; 
    word_check_print<double> ("fm(rotation.point)" , R);

    double R_real_max;
    cin >> R_real_max; 
    word_check_print<double> ("fm(real.maximal.radius)" , R_real_max);

    unsigned int N_uniform;
    cin >> N_uniform;
    word_check_print<unsigned int> ("points(uniform)" , N_uniform);

    unsigned int N_GL;
    cin >> N_GL;
    word_check_print<unsigned int> ("points(Gauss.Legendre)" , N_GL);

    cout << endl;

    enum particle_type particle;
    cin >> particle;
  
    if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron particles only");
  
    cout << endl;
  
    int Z_charge = 0;
  
    double R_charge = 0.0;
    
    if (particle_charge_determine (particle) != 0)
      {
	cin >> Z_charge;
	word_check_print<int> ("protons(target)" , Z_charge);

	cin >> R_charge;  
	word_check_print<double> ("fm(charge.radius)" , R_charge); 
      }
  
    cout << endl;
  
    string path;
    cin >> path;

    const int l = determine_l (path);

    const double j = determine_j (path);

    if ((l == 0) && Vso != 0.0) error_message_print_abort ("Vso is zero by convention for s1/2 partial waves");

    cout << endl << particle << " " << path << " contour" << endl;
  
    unsigned int N_res;
    cin >> N_res;
    word_check_print<unsigned int> ("pole.state(s)" , N_res);

    class array<class spherical_state> shells_res(N_res);

    resonances_alloc_calc (particle , l , j , N_res , Lambda , s , nu , a , A , target_mass , N_uniform , N_GL , R , matching_point , R_real_max , shells_res);

    const double nu_mass = (particle == NEUTRON) ? (neutron_mass) : (proton_mass);

    complex<double> k_peak;
    cin >> k_peak;
    word_check_print<complex<double> > ("fm^(-1)(k.peak)" , k_peak);

    double k_middle;
    cin >> k_middle;
    word_check_print<complex<double> > ("fm^(-1)(k.middle)" , k_middle);

    double k_max;
    cin >> k_max;
    word_check_print<double> ("fm^(-1)(k.max)" , k_max);

    unsigned int N_k_peak;
    cin >> N_k_peak;
    word_check_print<unsigned int> ("(N.k.peak)" , N_k_peak);

    unsigned int N_k_middle;
    cin >> N_k_middle;
    word_check_print<unsigned int> ("(N.k.middle)" , N_k_middle);

    unsigned int N_k_max;
    cin >> N_k_max;
    word_check_print<unsigned int> ("(N.k.max)" , N_k_max);

    cout << endl;

    const class PTG_class PTG_basis(kinetic_factor_calc (false , target_mass , nu_mass) , l , Lambda , s , nu , a);

    const class WS_analytic_class WS_to_diag(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j);

    const unsigned int N_scat = N_k_peak + N_k_middle + N_k_max;

    const unsigned int N_shells = N_res + N_scat;

    class array<class spherical_state> shells(N_shells);

    for (unsigned int i = 0 ; i < N_res ; i++) shells(i).allocate_fill (shells_res(i));

    shells_res.deallocate ();
  
    class array<complex<double> > k_tab(N_scat);
    class array<complex<double> > w_tab(N_scat);
  
    Gauss_Legendre::k_w_tab_segment_part_calc (0 , N_k_peak , 0.0 , k_peak , k_tab , w_tab);
    Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak , N_k_middle , k_peak , k_middle , k_tab , w_tab);
    Gauss_Legendre::k_w_tab_segment_part_calc (N_k_peak + N_k_middle , N_k_max , k_middle , k_max , k_tab , w_tab);

    scattering_alloc_calc (particle , l , j , N_res , N_scat , Lambda , s , nu , a , A , target_mass , N_uniform , N_GL , R , matching_point , R_real_max , k_tab , w_tab , shells);

    cout << endl;

    print_overlaps (shells);

    class matrix<complex<double> > H(N_shells); 

    cout << "Hamiltonian matrix dimension : " << N_shells << endl;

    H_calc (N_res , target_mass , nu_mass , PTG_basis , WS_to_diag , shells , w_tab , H);

    cout << "Hamiltonian matrix built" << endl << endl;

    class array<complex<double> > eigenvalues(N_shells);

    total_diagonalization::symmetric::all_eigenpairs (H , eigenvalues);

    const string lj_str = angular_state (l , j);
  
    for (unsigned int i = 0 ; i < N_res ; i++)
      {
	const string eigenstate_str = make_string<unsigned int> (i) + angular_state (l , j);
  
	cout << endl << endl;
      
	if (particle == PROTON)  cout << "------------------------"  << endl;
	if (particle == NEUTRON) cout << "-------------------------" << endl;
      
	cout << particle << " " << eigenstate_str << " eigenstate" << endl;
            
	if (particle == PROTON)  cout << "------------------------"  << endl << endl;
	if (particle == NEUTRON) cout << "-------------------------" << endl << endl;
	  
	const unsigned int ii_pole = ii_pole_calc (N_res , H , shells , i);

	const class vector_class<complex<double> > Vpole = Vpole_good_phase (H , shells , ii_pole);

	for (unsigned int ii = 0 ; ii < N_res ; ii++)
	  {
	    const class spherical_state &shell_ii = shells(ii);

	    const complex<double> k = shell_ii.get_k ();	    
	    const complex<double> E = shell_ii.get_E ();
	    
	    const complex<double> Vpole_square = Vpole(ii)*Vpole(ii);

	    cout << "basis pole state : " << shell_ii << endl;
	    cout << "-------------------------" << endl;
	  
	    cout << "k [basis " << shell_ii << "] : " << k << " fm^(-1) " <<endl;
	    cout << "E [basis " << shell_ii << "] : " << E << " MeV" << endl;

	    cout << "<" << shell_ii << " basis |" << eigenstate_str << "   eigenstate> : " << Vpole_square << endl << endl;
	  }

	double RMS_r = 0.0;
	double RMS_i = 0.0;

	cout << "Direct integration" << endl;
	cout << "------------------" << endl;
	  
	RMS_calc (WS_to_diag , target_mass , nu_mass , k_tab , w_tab , shells , Vpole , i , RMS_r , RMS_i);

	const complex<double> E_tilde = eigenvalues(ii_pole);

	cout << endl << "Rms difference of diagonalized and exact wave functions" << endl;
	cout << "-------------------------------------------------------" << endl;
	  
	cout << "Rms[wave functions real parts difference] : " << RMS_r << endl;
	cout << "Rms[wave functions imag parts difference] : " << RMS_i << endl;

	cout << endl << "Energy from diagonalization" << endl;
	cout << "---------------------------" << endl;
      
	cout << "E : " << real (E_tilde) << " MeV     G : " << -2000.0*imag (E_tilde) << " keV" << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
