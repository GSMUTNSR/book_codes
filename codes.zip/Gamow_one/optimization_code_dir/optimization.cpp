#include "../../numlib/numlib_def/numlib_def.h"

//--// they are definied in extern type in const.h

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;

using namespace string_routines;

void E_calc (
	     const class vector_class<double> &WS_parameters , 	
	     const int A , 
	     const int Z_charge , 
	     const double proton_mass_for_calc ,
	     const double neutron_mass_for_calc ,
	     const double core_mass ,
	     const unsigned int N_GL , 
	     const unsigned int N_uniform , 
	     const double R , 
	     const double Rmax , 
	     const double matching_point , 
	     const int lmax , 
	     const enum particle_type particle , 
	     const int n , 
	     const int l , 
	     const double j ,
	     const bool automatic_starting_point ,  
	     const complex<double> &E_deb , 
	     bool &is_k_OK , 
	     complex<double> &E)
{	
  const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , l);
  const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , l);

  const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , l);
  const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , l);

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  const double d =   (particle == PROTON) ? (WS_parameters(prot_index_from_WS_d))   : (WS_parameters(neut_index_from_WS_d));
  const double R0 =  (particle == PROTON) ? (WS_parameters(prot_index_from_WS_R0))  : (WS_parameters(neut_index_from_WS_R0));
  const double Vo =  (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vo))  : (WS_parameters(neut_index_from_WS_Vo));
  const double Vso = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vso)) : (WS_parameters(neut_index_from_WS_Vso));

  const double R_charge = WS_parameters(R_charge_index);

  const double nu_mass = mass_projectile_determine (particle , proton_mass_for_calc , neutron_mass_for_calc);

  const double kinetic_factor = kinetic_factor_calc (false , core_mass , nu_mass);

  const complex<double> k_deb = sqrt_mod (E_deb*kinetic_factor);
  
  class spherical_state u_data(false , false , WS_ANALYTIC , A , Z_charge , core_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , 
			       matching_point , Rmax , 0.0 , 0.0 , true , particle , n , NADA , l , j , automatic_starting_point , k_deb , nu_mass , 1.0 , 1.0);

  class potentials_effective_mass T;
  
  T.initialize_constants (
			  u_data.get_potential () , 
			  u_data.get_kinetic_factor () , 
			  u_data.get_jr () , 
			  u_data.get_l () , 
			  u_data.get_Z_charge () , 
			  u_data.get_j () , 
			  u_data.get_k () , 
			  u_data.get_eta () , 
			  NADA);
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
  
  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j); 

  u_data.k_search (T , true , false);

  is_k_OK = u_data.get_is_k_OK ();

  E = u_data.get_E ();
}










double phase_shift_calc (
			 const class vector_class<double> &WS_parameters , 	
			 const int A , 
			 const int Z_charge , 			 
			 const double proton_mass_for_calc ,
			 const double neutron_mass_for_calc ,
			 const double core_mass ,
			 const unsigned int N_GL , 
			 const unsigned int N_uniform , 
			 const double R , 
			 const double Rmax , 
			 const double matching_point , 
			 const int lmax , 
			 const enum particle_type particle , 
			 const int n , 
			 const int l , 
			 const double j , 
			 const complex<double> &E)
{	
  const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , l);
  const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , l);

  const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , l);
  const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , l);

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  const double d   = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_d))   : (WS_parameters(neut_index_from_WS_d));
  const double R0  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_R0))  : (WS_parameters(neut_index_from_WS_R0));
  const double Vo  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vo))  : (WS_parameters(neut_index_from_WS_Vo));
  const double Vso = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vso)) : (WS_parameters(neut_index_from_WS_Vso));

  const double R_charge = WS_parameters(R_charge_index);

  const double nu_mass = mass_projectile_determine (particle , proton_mass_for_calc , neutron_mass_for_calc);
  
  const double kinetic_factor = kinetic_factor_calc (false , core_mass , nu_mass);

  const double radians_to_degrees_factor = 180.0/M_PI;

  const complex<double> k = sqrt (E*kinetic_factor);

  class spherical_state u_data(false , false , WS_ANALYTIC , A , Z_charge , core_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , 
			       matching_point , Rmax , 0.0 , 0.0 , false , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0); 

  class potentials_effective_mass T;
  
  T.initialize_constants (
			  u_data.get_potential () , 
			  u_data.get_kinetic_factor () , 
			  u_data.get_jr () , 
			  u_data.get_l () , 
			  u_data.get_Z_charge () , 
			  u_data.get_j () , 
			  u_data.get_k () , 
			  u_data.get_eta () , 
			  NADA);
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
  
  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j); 

  u_data.wave_calculation (false , T , false);

  const double delta_radians = real (u_data.get_phase_shift ());

  const double delta_degrees = delta_radians*radians_to_degrees_factor;

  const double phase_shift_unscaled = fmod (delta_degrees , 180.0);

  const double phase_shift = (phase_shift_unscaled > 0.0) ? (phase_shift_unscaled) : (phase_shift_unscaled + 180.0);

  return phase_shift;
}






complex<double> E_grad_component_calc (
				       const enum WS_parameter_type WS_parameter , 
				       const class WS_analytic_class &WS_potential , 
				       const class spherical_state &u_data)
{
  const unsigned int N_bef_R_GL = u_data.get_N_bef_R_GL ();
  const unsigned int N_aft_R_GL = u_data.get_N_aft_R_GL ();

  const class array<double> &r_bef_R_tab_GL = u_data.get_r_bef_R_tab_GL ();
  const class array<double> &w_bef_R_tab_GL = u_data.get_w_bef_R_tab_GL ();

  const class array<double> &r_aft_R_tab_GL_real = u_data.get_r_aft_R_tab_GL_real ();
  const class array<double> &w_aft_R_tab_GL_real = u_data.get_w_aft_R_tab_GL_real ();

  const class array<complex<double> > &wf_bef_R_tab_GL      = u_data.get_wf_bef_R_tab_GL ();
  const class array<complex<double> > &wf_aft_R_tab_GL_real = u_data.get_wf_aft_R_tab_GL_real ();
  
  complex<double> OBME_WS_der = 0.0;
  
  for (unsigned int i = 0 ; i < N_bef_R_GL ; i++)
    {
      const double r = r_bef_R_tab_GL(i);
      const double w = w_bef_R_tab_GL(i);

      const double WS_derivative_r = WS_potential.derivative_calc (WS_parameter , r);

      const complex<double> wf_r = wf_bef_R_tab_GL(i);

      const complex<double> wf2_w_r = wf_r*wf_r*w;

      OBME_WS_der += WS_derivative_r*wf2_w_r;
    }	

  for (unsigned int i = 0 ; i < N_aft_R_GL ; i++)
    {
      const double r = r_aft_R_tab_GL_real(i);
      const double w = w_aft_R_tab_GL_real(i);

      const double WS_derivative_r = WS_potential.derivative_calc (WS_parameter , r);

      const complex<double> wf_r = wf_aft_R_tab_GL_real(i);

      const complex<double> wf2_w_r = wf_r*wf_r*w;

      OBME_WS_der += WS_derivative_r*wf2_w_r;
    }	

  return OBME_WS_der;
}





















void E_grad_calc (
		  const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
		  const class vector_class<double> &WS_parameters , 	
		  const int A , 
		  const int Z_charge , 		 
		  const double proton_mass_for_calc ,
		  const double neutron_mass_for_calc ,
		  const double core_mass ,
		  const unsigned int N_GL , 
		  const unsigned int N_uniform , 
		  const double R , 
		  const double Rmax , 
		  const double matching_point , 
		  const int lmax , 
		  const enum particle_type particle , 
		  const int n , 
		  const int l , 
		  const double j ,
		  const bool automatic_starting_point ,
		  const complex<double> &E_deb , 
		  bool &is_k_OK , 
		  complex<double> &E , 
		  class vector_class<complex<double> > &E_grad)
{
  const unsigned int N_parameters_to_fit = E_grad.get_dimension ();

  const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , l);
  const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , l);

  const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , l);
  const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , l);

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  const double d   = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_d))   : (WS_parameters(neut_index_from_WS_d));
  const double R0  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_R0))  : (WS_parameters(neut_index_from_WS_R0));
  const double Vo  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vo))  : (WS_parameters(neut_index_from_WS_Vo));
  const double Vso = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vso)) : (WS_parameters(neut_index_from_WS_Vso));

  const double R_charge = WS_parameters(R_charge_index);

  const double nu_mass = mass_projectile_determine (particle , proton_mass_for_calc , neutron_mass_for_calc);
  
  const double kinetic_factor = kinetic_factor_calc (false , core_mass , nu_mass);

  const complex<double> k_deb = sqrt_mod (E_deb*kinetic_factor);

  class spherical_state u_data(false , false , WS_ANALYTIC , A , Z_charge , core_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , 
			       matching_point , Rmax , 0.0 , 0.0 , true , particle , n , NADA , l , j , automatic_starting_point , k_deb , nu_mass , 1.0 , 1.0);

  class potentials_effective_mass T;

  T.initialize_constants (
			  u_data.get_potential () , 
			  u_data.get_kinetic_factor () , 
			  u_data.get_jr () , 
			  u_data.get_l () , 
			  u_data.get_Z_charge () , 
			  u_data.get_j () , 
			  u_data.get_k () , 
			  u_data.get_eta () , 
			  NADA);
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();

  WS_analytic_potential.initialize(false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j); 

  u_data.k_search (T , true , false);
  
  u_data.wave_calculation (false , T , false);

  is_k_OK = u_data.get_is_k_OK ();

  E = u_data.get_E ();

  E_grad = 0.0;

  if (is_k_OK)
    {
      const class WS_analytic_class &WS_potential = T.get_WS_analytic_potential ();

      for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
	{
	  const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);

	  E_grad(fit_index) =  E_grad_component_calc (WS_parameter , WS_potential , u_data);
	}
    }
}






void phase_shift_grad_calc (
			    const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
			    const class vector_class<double> &WS_parameters , 	
			    const int A , 
			    const int Z_charge , 
			    const double proton_mass_for_calc ,
			    const double neutron_mass_for_calc ,
			    const double core_mass , 
			    const unsigned int N_GL , 
			    const unsigned int N_uniform , 
			    const double R , 
			    const double Rmax , 
			    const double matching_point , 
			    const int lmax , 
			    const enum particle_type particle , 
			    const int n , 
			    const int l , 
			    const double j , 
			    const complex<double> E , 
			    double &phase_shift , 
			    class vector_class<double> &phase_shift_grad)
{	
  const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , l);
  const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , l);
  const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , l);

  const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , l);
  const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , l);
  const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , l);

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  const double d   = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_d))   : (WS_parameters(neut_index_from_WS_d));
  const double R0  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_R0))  : (WS_parameters(neut_index_from_WS_R0));
  const double Vo  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vo))  : (WS_parameters(neut_index_from_WS_Vo));
  const double Vso = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vso)) : (WS_parameters(neut_index_from_WS_Vso));
  
  const double R_charge = WS_parameters(R_charge_index);

  const double nu_mass = mass_projectile_determine (particle , proton_mass_for_calc , neutron_mass_for_calc);
  
  const double kinetic_factor = kinetic_factor_calc (false , core_mass , nu_mass);

  const double radians_to_degrees_factor = 180.0/M_PI;

  const complex<double> k = sqrt (E*kinetic_factor);

  class spherical_state u_data(false , false , WS_ANALYTIC , A , Z_charge , core_mass , NADA , N_GL , N_GL , N_uniform , N_uniform , 0 , 0 , R , NADA , 
			       matching_point , Rmax , 0.0 , 0.0 , false , particle , n , NADA , l , j , false , k , nu_mass , 1.0 , 1.0); 

  class potentials_effective_mass T;
  
  T.initialize_constants (
			  u_data.get_potential () , 
			  u_data.get_kinetic_factor () , 
			  u_data.get_jr () , 
			  u_data.get_l () , 
			  u_data.get_Z_charge () , 
			  u_data.get_j () , 
			  u_data.get_k () , 
			  u_data.get_eta () , 
			  NADA);
  
  class WS_analytic_class &WS_analytic_potential = T.get_WS_analytic_potential ();
  
  WS_analytic_potential.initialize (false , d , R0 , Vo , Vso , particle , Z_charge , R_charge , l , j); 

  u_data.wave_calculation (false , T , false);

  const complex<double> Cplus  = u_data.get_Cplus ();
  const complex<double> Cminus = u_data.get_Cminus ();

  if (inf_norm (conj (Cplus) - Cminus) > precision)
    error_message_print_abort ("C+ and C- are not complex conjugates in phase_shift_grad_calc for k=" + make_string<complex<double> > (k));

  const double delta_radians = real (u_data.get_phase_shift ());

  const double delta_degrees = delta_radians*radians_to_degrees_factor;

  const double phase_shift_unscaled = fmod (delta_degrees , 180.0);

  phase_shift = (phase_shift_unscaled > 0.0) ? (phase_shift_unscaled) : (phase_shift_unscaled + 180.0);

  //calculates du/dparameter to get the dC^{+/-}/dparameter and so dphi/dparameter
  const class WS_analytic_class WS_potential = T.get_WS_analytic_potential ();
  
  class spherical_state_partial_derivatives du_over_dx_data(WS_potential , WS_parameters_from_fit_index , u_data);
  
  du_over_dx_data.wave_partial_derivatives_calculation ();

  //partial derivatives

  const class array<complex<double> > &Cplus_der_tab  = du_over_dx_data.get_Cplus_der_tab ();
  const class array<complex<double> > &Cminus_der_tab = du_over_dx_data.get_Cminus_der_tab ();

  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  phase_shift_grad = 0.0;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    {
      const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);

      if ((l == 0) && (WS_parameter == VSO_PROTON))  continue;
      if ((l == 0) && (WS_parameter == VSO_NEUTRON)) continue;

      const complex<double> &Cplus_der  = Cplus_der_tab(fit_index);
      const complex<double> &Cminus_der = Cminus_der_tab(fit_index);

      if (inf_norm (conj (Cplus_der) - Cminus_der) > precision) 
	error_message_print_abort ("dC+/dx and dC-/dx are not complex conjugates in phase_shift_grad_calc for x=" + make_string<enum WS_parameter_type> (WS_parameter) + " and k=" + make_string<complex<double> > (k));

      const double phi_derivative = imag (Cplus_der/Cplus)*radians_to_degrees_factor;

      phase_shift_grad(fit_index) = phi_derivative;
    }
}














double cost_function_calc (
			   const int A , 
			   const int Z_charge , 
			   const double proton_mass_for_calc ,
			   const double neutron_mass_for_calc ,
			   const double core_mass , 
			   const unsigned int N_GL , 
			   const unsigned int N_uniform , 
			   const double R , 
			   const double Rmax , 
			   const double matching_point , 
			   const enum particle_type particle , 
			   const class array<int> &n_tab , 
			   const class array<int> &l_tab , 
			   const class array<double> &j_tab , 
			   const class array<bool> &automatic_starting_points , 
			   const class array<complex<double> > &experimental_energy_tab , 
			   const class array<complex<double> > &starting_energy_tab , 
			   const class array<double> &experimental_phase_shift_tab , 
			   const class array<double> &energy_phase_shift_tab , 
			   const class array<double> &energy_errors , 
			   const class array<double> &width_errors , 
			   const class array<double> &phase_shift_errors , 
			   const class vector_class<double> &WS_parameters)
{
  const int lmax = l_tab.max ();

  const unsigned int N_pole_shells = experimental_energy_tab.dimension (0);
  
  const unsigned int N_scattering_shells = experimental_phase_shift_tab.dimension (0);

  const unsigned int N_shells = N_pole_shells + N_scattering_shells;

  double cost_function = 0.0;
  
  for (unsigned int s = 0 ; s < N_pole_shells ; s++)
    {
      const bool automatic_starting_point = automatic_starting_points(s);

      const double energy_error = energy_errors(s);

      const double width_error = width_errors(s);

      const complex<double> experimental_E = experimental_energy_tab(s);

      const int n = n_tab(s);
      const int l = l_tab(s);
      
      const double j = j_tab(s);

      const complex<double> starting_E = starting_energy_tab(s);

      bool is_k_OK;
      
      complex<double> E;

      E_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
	      N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , automatic_starting_point , starting_E , is_k_OK , E); 

      if (!is_k_OK) return INFINITE;

      const double experimental_energy = real (experimental_E);

      const double experimental_width = -2.0*imag (experimental_E);

      const double energy = real (E);

      const double width = -2.0*imag (E);

      cost_function += norm_dc ((energy - experimental_energy)/energy_error) + norm_dc ((width - experimental_width)/width_error);
    }

  for (unsigned int s = N_pole_shells ; s < N_shells ; s++)
    {
      const unsigned int s_ps = s - N_pole_shells;
      
      const double experimental_phase_shift = experimental_phase_shift_tab(s_ps);

      const double phase_shift_error = phase_shift_errors(s_ps);

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const double phase_shift_energy = energy_phase_shift_tab(s_ps);
      
      const double phase_shift = phase_shift_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
						   N_GL , N_uniform , R , Rmax , matching_point , lmax ,  particle , n , l , j , phase_shift_energy);

      cost_function += norm_dc ((phase_shift - experimental_phase_shift)/phase_shift_error);
    }

  cost_function /= N_shells;
  
  cost_function *= 0.5;

  return cost_function;
}








class vector_class<double> cost_function_grad_calc (
						    const int A , 
						    const int Z_charge , 
						    const double proton_mass_for_calc ,
						    const double neutron_mass_for_calc ,
						    const double core_mass , 
						    const unsigned int N_GL , 
						    const unsigned int N_uniform , 
						    const double R , 
						    const double Rmax , 
						    const double matching_point , 
						    const enum particle_type particle , 
						    const class array<int> &n_tab , 
						    const class array<int> &l_tab , 
						    const class array<double> &j_tab , 
						    const class array<bool> &automatic_starting_points , 
						    const class array<complex<double> > &experimental_energy_tab , 
						    const class array<complex<double> > &starting_energy_tab , 
						    const class array<double> &experimental_phase_shift_tab , 
						    const class array<double> &energy_phase_shift_tab , 
						    const class array<double> &energy_errors , 
						    const class array<double> &width_errors , 
						    const class array<double> &phase_shift_errors , 
						    const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
						    const class vector_class<double> &WS_parameters)
{	
  const int lmax = l_tab.max ();

  const unsigned int N_pole_shells = experimental_energy_tab.dimension (0);

  const unsigned int N_scattering_shells = experimental_phase_shift_tab.dimension (0);

  const unsigned int N_shells = N_pole_shells + N_scattering_shells;

  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  class vector_class<double> cost_function_grad(N_parameters_to_fit);

  cost_function_grad = 0.0;

  //calculates energies
  for (unsigned int s = 0 ; s < N_pole_shells ; s++)
    {
      const bool automatic_starting_point = automatic_starting_points(s);
      
      const double energy_error = energy_errors(s);
      
      const double width_error = width_errors(s);

      const complex<double> experimental_E = experimental_energy_tab(s);

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const complex<double> starting_E = starting_energy_tab(s);

      bool is_k_OK;
      
      complex<double> E;

      class vector_class<complex<double> > E_grad(N_parameters_to_fit);

      E_grad_calc (WS_parameters_from_fit_index , WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
		   N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , automatic_starting_point ,
		   starting_E , is_k_OK , E , E_grad);

      const class vector_class<double> energy_grad = real <double , complex<double> > (E_grad);
      
      const class vector_class<double> width_grad = -2.0*imag <double , complex<double> > (E_grad);

      if (!is_k_OK) error_message_print_abort ("Impossible to find " + make_string<int> (n) + angular_state (l , j) + " energy in cost_function_grad_calc");

      const double experimental_energy = real (experimental_E);

      const double experimental_width = -2.0*imag (experimental_E);

      const double energy = real (E);

      const double width = -2.0*imag (E);

      const double energy_relative_difference = (energy - experimental_energy)/energy_error;

      const double width_relative_difference = (width - experimental_width)/width_error;

      cost_function_grad += energy_relative_difference*energy_grad/energy_error + width_relative_difference*width_grad/width_error;
    }

  //calculates phase shifts
  for (unsigned int s = N_pole_shells ; s < N_shells ; s++)
    {
      const unsigned int s_ps = s - N_pole_shells;

      const double experimental_phase_shift = experimental_phase_shift_tab(s_ps);

      const double phase_shift_error = phase_shift_errors(s_ps);

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const double phase_shift_energy = energy_phase_shift_tab(s_ps);

      double phase_shift;

      class vector_class<double> phase_shift_grad(N_parameters_to_fit);
      
      phase_shift_grad_calc (WS_parameters_from_fit_index , WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
			     N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , phase_shift_energy , phase_shift , phase_shift_grad);

      const double phase_shift_relative_difference = (phase_shift - experimental_phase_shift)/phase_shift_error;

      cost_function_grad += phase_shift_relative_difference*phase_shift_grad/phase_shift_error;
    }  

  cost_function_grad /= N_shells;

  return cost_function_grad;
}












class vector_class<double> E_phase_shift_vector_calc (
						      const int A , 
						      const int Z_charge , 
						      const double proton_mass_for_calc ,
						      const double neutron_mass_for_calc ,
						      const double core_mass , 
						      const unsigned int N_GL , 
						      const unsigned int N_uniform , 
						      const double R , 
						      const double Rmax , 
						      const double matching_point , 
						      const enum particle_type particle , 
						      const class array<int> &n_tab , 
						      const class array<int> &l_tab , 
						      const class array<double> &j_tab , 
						      const class array<bool> &automatic_starting_points , 
						      const class array<complex<double> > &experimental_energy_tab , 
						      const class array<complex<double> > &starting_energy_tab , 
						      const class array<double> &experimental_phase_shift_tab , 
						      const class array<double> &energy_phase_shift_tab , 
						      const class array<double> &energy_errors , 
						      const class array<double> &width_errors , 
						      const class array<double> &phase_shift_errors , 
						      const class vector_class<double> &WS_parameters)
{
  const int lmax = l_tab.max ();

  const unsigned int N_pole_shells = experimental_energy_tab.dimension (0);

  const unsigned int two_N_pole_shells = 2*N_pole_shells;

  const unsigned int N_scattering_shells = experimental_phase_shift_tab.dimension (0);

  const unsigned int N_conditions = two_N_pole_shells + N_scattering_shells;

  class vector_class<double> E_phase_shift_vector(N_conditions);

  E_phase_shift_vector = 0.0;

  for (unsigned int s = 0 ; s < N_pole_shells ; s++)
    {      
      const unsigned int s_scat = s + N_pole_shells;
      
      const bool automatic_starting_point = automatic_starting_points(s);
      
      const complex<double> experimental_E = experimental_energy_tab(s);
      
      const double energy_error = energy_errors(s);

      const double width_error = width_errors(s);

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const complex<double> starting_E = starting_energy_tab(s);

      bool is_k_OK;
      
      complex<double> E;

      E_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
	      N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , automatic_starting_point , starting_E , is_k_OK , E); 

      if (!is_k_OK) 
	E_phase_shift_vector(s) = E_phase_shift_vector(s_scat) = INFINITE;
      else
	{
	  const double experimental_energy = real (experimental_E);

	  const double experimental_width = -2.0*imag (experimental_E);

	  const double energy = real (E);

	  const double width = -2.0*imag (E);

	  E_phase_shift_vector(s) = (energy - experimental_energy)/energy_error;

	  E_phase_shift_vector(s_scat) = (width - experimental_width)/width_error;
	}
    }

  for (unsigned int s_ps = 0 ; s_ps < N_scattering_shells ; s_ps++)
    {
      const unsigned int s = s_ps + N_pole_shells;

      const double experimental_phase_shift = experimental_phase_shift_tab(s_ps);

      const double phase_shift_error = phase_shift_errors(s_ps);

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const double phase_shift_energy = energy_phase_shift_tab(s_ps);

      const double phase_shift = phase_shift_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
						   N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , phase_shift_energy);

      E_phase_shift_vector(s + N_pole_shells) = (phase_shift - experimental_phase_shift)/phase_shift_error;
    }

  return E_phase_shift_vector;
}











class vector_class<double> E_phase_shift_vector_component_grad_calc (
								     const int A , 
								     const int Z_charge , 
								     const double proton_mass_for_calc ,
								     const double neutron_mass_for_calc ,
								     const double core_mass , 
								     const unsigned int N_GL , 
								     const unsigned int N_uniform , 
								     const double R , 
								     const double Rmax , 
								     const double matching_point , 
								     const enum particle_type particle , 
								     const class array<int> &n_tab , 
								     const class array<int> &l_tab , 
								     const class array<double> &j_tab , 
								     const class array<bool> &automatic_starting_points , 
								     const class array<complex<double> > &experimental_energy_tab , 
								     const class array<complex<double> > &starting_energy_tab , 
								     const class array<double> &experimental_phase_shift_tab , 
								     const class array<double> &energy_phase_shift_tab , 
								     const class array<double> &energy_errors , 
								     const class array<double> &width_errors , 
								     const class array<double> &phase_shift_errors , 
								     const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
								     const class vector_class<double> &WS_parameters , 
								     const unsigned int condition_index)
{
  const int lmax = l_tab.max ();

  const unsigned int N_pole_shells = experimental_energy_tab.dimension (0);

  const unsigned int two_N_pole_shells = 2*N_pole_shells;

  const unsigned int N_scattering_shells = experimental_phase_shift_tab.dimension (0);

  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  //calculates energies
  if (condition_index < two_N_pole_shells)
    {
      const unsigned int s = (condition_index < N_pole_shells) ? (condition_index) : (condition_index - N_pole_shells);

      const bool automatic_starting_point = automatic_starting_points(s);
      
      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const complex<double> starting_E = starting_energy_tab(s);

      bool is_k_OK;

      complex<double> E;

      class vector_class<complex<double> > E_grad(N_parameters_to_fit);

      E_grad_calc (WS_parameters_from_fit_index , WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
		   N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , automatic_starting_point ,
		   starting_E , is_k_OK , E , E_grad);

      if (!is_k_OK) error_message_print_abort ("Impossible to find " + make_string<int> (n) + angular_state (l , j) + " energy in E_phase_shift_vector_component_grad_calc");
      
      if (condition_index < N_pole_shells)
	{	
	  const double energy_error = energy_errors(s);

	  const class vector_class<double> E_phase_shift_vector_component_grad = real<double , complex<double> > (E_grad)/energy_error;

	  return E_phase_shift_vector_component_grad;

	}
      else
	{	
	  const double width_error = width_errors(s);

	  const class vector_class<double> E_phase_shift_vector_component_grad = -2.0*imag<double , complex<double> > (E_grad)/width_error;

	  return E_phase_shift_vector_component_grad;
	}
    }
  else
    {
      if (N_scattering_shells == 0) error_message_print_abort ("No phase shift gradient for N_scattering_shells = 0");

      class vector_class<double> E_phase_shift_vector_component_grad(N_parameters_to_fit);
      
      E_phase_shift_vector_component_grad = 0.0;

      const unsigned int s_ps = condition_index - two_N_pole_shells;

      const unsigned int s = s_ps + N_pole_shells;

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const double phase_shift_error = phase_shift_errors(s_ps);

      const double phase_shift_energy = energy_phase_shift_tab(s_ps);

      double phase_shift;

      class vector_class<double> phase_shift_grad_over_error(N_parameters_to_fit);

      phase_shift_grad_calc (WS_parameters_from_fit_index , WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
			     N_GL , N_uniform , R , Rmax , matching_point , 
			     lmax , particle , n , l , j , phase_shift_energy , phase_shift , phase_shift_grad_over_error);

      phase_shift_grad_over_error /= phase_shift_error;
     
      E_phase_shift_vector_component_grad = phase_shift_grad_over_error;

      return E_phase_shift_vector_component_grad;
    }
}






class matrix<double> Newton_matrix_calc (
					 const int A , 
					 const int Z_charge , 
					 const double proton_mass_for_calc ,
					 const double neutron_mass_for_calc , 
					 const double core_mass ,
					 const unsigned int N_GL , 
					 const unsigned int N_uniform , 
					 const double R , 
					 const double Rmax , 
					 const double matching_point , 
					 const enum particle_type particle , 
					 const class array<int> &n_tab , 
					 const class array<int> &l_tab , 
					 const class array<double> &j_tab , 
					 const class array<bool> &automatic_starting_points , 
					 const class array<complex<double> > &experimental_energy_tab , 
					 const class array<complex<double> > &starting_energy_tab , 
					 const class array<double> &experimental_phase_shift_tab , 
					 const class array<double> &energy_phase_shift_tab , 
					 const class array<double> &energy_errors , 
					 const class array<double> &width_errors , 
					 const class array<double> &phase_shift_errors ,  
					 const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
					 const class vector_class<double> &WS_parameters)
{
  const unsigned int N_pole_shells = experimental_energy_tab.dimension (0);

  const unsigned int two_N_pole_shells = 2*N_pole_shells;

  const unsigned int N_scattering_shells = experimental_phase_shift_tab.dimension (0);

  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  const unsigned int N_conditions = two_N_pole_shells + N_scattering_shells;

  class matrix<double> M(N_conditions , N_parameters_to_fit);

  M = 0.0;

  for (unsigned int i = 0 ; i < N_conditions ; i++)
    M.row_vector (i) = E_phase_shift_vector_component_grad_calc (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
								 N_GL , N_uniform , R , Rmax , matching_point , 
								 particle , n_tab , l_tab , j_tab , automatic_starting_points ,
								 experimental_energy_tab , starting_energy_tab , experimental_phase_shift_tab , energy_phase_shift_tab ,
								 energy_errors , width_errors , phase_shift_errors , WS_parameters_from_fit_index , WS_parameters , i);
  return M;
}






void WS_parameters_print (
			  const enum particle_type particle , 
			  const class array<int> &l_tab , 
			  const class vector_class<double> &WS_parameters)
{
  const int lmax = l_tab.max ();

  const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , 0);
  const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , 0);
  const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , 0);
  const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , 0);

  const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , 0);
  const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , 0);
  const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , 0);
  const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , 0);

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  const double d   = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_d))   : (WS_parameters(neut_index_from_WS_d));
  const double R0  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_R0))  : (WS_parameters(neut_index_from_WS_R0));
  const double Vo  = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vo))  : (WS_parameters(neut_index_from_WS_Vo));
  const double Vso = (particle == PROTON) ? (WS_parameters(prot_index_from_WS_Vso)) : (WS_parameters(neut_index_from_WS_Vso));

  const double R_charge = WS_parameters(R_charge_index);

  if (particle_charge_determine (particle) != 0)
    cout << "d:" << d << " fm , R0:" << R0 << " fm , Vo:" << Vo << " MeV , Vso:" << Vso << " MeV , R.charge:" << R_charge << " fm" << endl << endl;
  else
    cout << "d:" << d << " fm , R0:" << R0 << " fm , Vo:" << Vo << " MeV , Vso:" << Vso << " MeV" << endl << endl;  
}



void E_phase_phifts_print (
			   const int A , 
			   const int Z_charge , 
			   const double proton_mass_for_calc ,
			   const double neutron_mass_for_calc ,
			   const double core_mass , 
			   const unsigned int N_GL , 
			   const unsigned int N_uniform , 
			   const double R , 
			   const double Rmax , 
			   const double matching_point , 
			   const enum particle_type particle , 
			   const class array<int> &n_tab , 
			   const class array<int> &l_tab , 
			   const class array<double> &j_tab , 
			   const class array<bool> &automatic_starting_points , 
			   const class array<complex<double> > &starting_energy_tab , 
			   const class array<double> &energy_phase_shift_tab , 
			   const class vector_class<double> &WS_parameters)
{
  const int lmax = l_tab.max ();

  const unsigned int N_pole_shells = starting_energy_tab.dimension (0);
  
  const unsigned int N_scattering_shells = energy_phase_shift_tab.dimension (0);
  
  const unsigned int N_shells = N_pole_shells + N_scattering_shells;

  const double lab_to_COSM_kinetic_factor = lab_to_COSM_kinetic_factor_calc (proton_mass_for_calc , neutron_mass_for_calc , core_mass , particle);

  //calculates energies
  for (unsigned int s = 0 ; s < N_pole_shells ; s++)
    {
      const bool automatic_starting_point = automatic_starting_points(s);
      
      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const complex<double> starting_E = starting_energy_tab(s);

      bool is_k_OK;
      
      complex<double> E;

      E_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
	      N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , automatic_starting_point , starting_E , is_k_OK , E);

      const double real_energy_lab = real (E)/lab_to_COSM_kinetic_factor;

      cout << "s:" << s << " " << particle << " " << n << angular_state (l , j)
	   << "  E(COSM):" << real (E) << " MeV  Gamma(COSM):" << -2.0*imag (E) << " MeV" << "  E(lab):" << real_energy_lab << " MeV" << endl;

      if (!is_k_OK)
	error_message_print_abort (make_string<enum particle_type> (particle) + " " + make_string<int> (n) + angular_state (l , j) + " cannot be calculated. E:" + make_string<double> (real (E)) + " MeV Gamma:" + make_string<double> (-2000.0*imag (E)) + " keV");

      starting_energy_tab(s) = E;
    }

  //calculates phase shifts
  for (unsigned int s = N_pole_shells ; s < N_shells ; s++)
    {
      const unsigned int s_ps = s - N_pole_shells;

      const int n = n_tab(s);
      const int l = l_tab(s);

      const double j = j_tab(s);

      const double phase_shift_energy = energy_phase_shift_tab(s_ps);
      
      const double phase_shift_energy_lab = phase_shift_energy/lab_to_COSM_kinetic_factor;

      const double phase_shift = phase_shift_calc (WS_parameters , A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
						   N_GL , N_uniform , R , Rmax , matching_point , lmax , particle , n , l , j , phase_shift_energy);

      cout << "s:" << s << " " << particle << " " << n << angular_state (l , j) << "  Energy(lab):" << phase_shift_energy_lab <<   " MeV  Phase shift:" << phase_shift << " degrees" << endl;
    }

  cout << endl;
}





class vector_class<double> WS_parameters_fit_indices_fill (
							   const int lmax , 
							   const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
							   const class vector_class<double> &WS_parameters)
{	
  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  class vector_class<double> WS_parameters_fit_indices(N_parameters_to_fit);

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);

      if (WS_parameter == R_CHARGE_PROTON)
	{
	  const unsigned int WS_parameter_index = WS_parameter_index_determine (WS_parameter , NADA , NADA);

	  WS_parameters_fit_indices(fit_index) = WS_parameters(WS_parameter_index);
	}
      else
	{
	  for (int l = 0 ; l <= lmax ; l++)
	    {
	      const unsigned int WS_parameter_index = WS_parameter_index_determine (WS_parameter , lmax , l);
				
	      WS_parameters_fit_indices(fit_index) = WS_parameters(WS_parameter_index);
	    }
	}
    }

  return WS_parameters_fit_indices;
}









class matrix<double> scaled_G_calc (
				    const class vector_class<double> &WS_parameters_fit_indices , 
				    const class matrix<double> &G)
{
  const unsigned int N_conditions = G.get_dimension_row ();
  
  const unsigned int N_parameters_to_fit = G.get_dimension_column ();

  class matrix<double> scaled_G = G;

  for(unsigned int j = 0 ; j < N_parameters_to_fit ; j++) 
    {
      const double WS_parameter = WS_parameters_fit_indices(j);

      if (WS_parameter != 0.0) 
	{
	  for(unsigned int i = 0 ; i < N_conditions ; i++) scaled_G(i , j) *= WS_parameter;
	}
    }

  return scaled_G;
}








class vector_class<double> delta_WS_parameters_fit_indices_scaled_calc (
									const double SVD_precision , 
									const class vector_class<double> &WS_parameters_fit_indices , 
									const class vector_class<double> &E_vector , 
									const class matrix<double> &G)
{
  const unsigned int N_states_to_fit = G.get_dimension_row ();
  
  const unsigned int N_parameters_to_fit = G.get_dimension_column ();

  const class matrix<double> scaled_G = scaled_G_calc (WS_parameters_fit_indices , G);

  const class matrix<double> scaled_G_transpose = transpose (scaled_G);

  if (N_states_to_fit < N_parameters_to_fit)
    {	
      class matrix<double> scaled_G_tG = scaled_G*scaled_G_transpose;
      
      const class vector_class<double> scaled_G_tG_inv_energy_vector = linear_system_SVD_solution (scaled_G_tG ,  E_vector ,  SVD_precision);

      const class vector_class<double> delta_WS_parameters_fit_indices_scaled = scaled_G_transpose*scaled_G_tG_inv_energy_vector;

      return delta_WS_parameters_fit_indices_scaled;
    }
  else
    {	
      class matrix<double> scaled_tG_G = scaled_G_transpose*scaled_G;

      const class vector_class<double> scaled_tG_energy_vector = scaled_G_transpose*E_vector;

      const class vector_class<double> delta_WS_parameters_fit_indices_scaled = linear_system_SVD_solution (scaled_tG_G ,  scaled_tG_energy_vector , SVD_precision);

      return delta_WS_parameters_fit_indices_scaled;
    }
}








class vector_class<double> delta_WS_parameters_fit_indices_unscale (
								    const class vector_class<double> &WS_parameters_fit_indices , 
								    const class vector_class<double> &delta_WS_parameters_fit_indices_scaled)
{
  const unsigned int N_parameters_to_fit = WS_parameters_fit_indices.get_dimension ();

  class vector_class<double> delta_WS_parameters_fit_indices = delta_WS_parameters_fit_indices_scaled;

  for(unsigned int j = 0; j < N_parameters_to_fit ; j++) 
    {
      const double WS_parameter = WS_parameters_fit_indices(j);

      if (WS_parameter != 0.0) delta_WS_parameters_fit_indices(j) *= WS_parameter ;
    }

  return delta_WS_parameters_fit_indices;
}












class vector_class<double> delta_WS_parameters_original_indices_fill (
								      const unsigned int N_parameters , 
								      const int lmax , 
								      const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
								      const class vector_class<double> &delta_WS_parameters_fit_indices)
{	
  const unsigned int N_parameters_to_fit = WS_parameters_from_fit_index.dimension (0);

  class vector_class<double> delta_WS_parameters(N_parameters);

  delta_WS_parameters = 0.0;

  for (unsigned int fit_index = 0 ; fit_index < N_parameters_to_fit ; fit_index++)
    { 
      const enum WS_parameter_type WS_parameter = WS_parameters_from_fit_index(fit_index);
      
      const double delta_WS_parameter = delta_WS_parameters_fit_indices(fit_index);

      if (WS_parameter == R_CHARGE_PROTON)
	{
	  const unsigned int WS_parameter_index = WS_parameter_index_determine (WS_parameter , NADA , NADA);

	  delta_WS_parameters(WS_parameter_index) = delta_WS_parameter;
	}
      else
	{
	  for (int l = 0 ; l <= lmax ; l++)
	    {
	      const unsigned int WS_parameter_index = WS_parameter_index_determine (WS_parameter , lmax , l);
				
	      delta_WS_parameters(WS_parameter_index) = delta_WS_parameter;
	    }
	}
    }

  return delta_WS_parameters;
}











void Newton_method_calc_print (
			       const int A , 
			       const int Z_charge , 
			       const double proton_mass_for_calc ,
			       const double neutron_mass_for_calc ,
			       const double core_mass , 
			       const unsigned int N_GL , 
			       const unsigned int N_uniform , 
			       const double R , 
			       const double Rmax , 
			       const double matching_point , 
			       const enum particle_type particle , 
			       const class array<int> &n_tab , 
			       const class array<int> &l_tab , 
			       const class array<double> &j_tab , 
			       const class array<bool> &automatic_starting_points , 
			       const class array<complex<double> > &experimental_energy_tab , 
			       class array<complex<double> > &starting_energy_tab , 
			       const class array<double> &experimental_phase_shift_tab , 
			       const class array<double> &energy_phase_shift_tab , 
			       const class array<double> &energy_errors , 
			       const class array<double> &width_errors , 
			       const class array<double> &phase_shift_errors ,   
			       const double SVD_precision , 
			       const double Newton_precision , 
			       const class array<enum WS_parameter_type> &WS_parameters_from_fit_index , 
			       class vector_class<double> &WS_parameters)
{
  const unsigned int N_parameters = WS_parameters.get_dimension ();

  const int lmax = l_tab.max ();

  unsigned int iter = 0;
  
  double test = 1.0;

  while ((test > Newton_precision) && (iter++ < 20))
    {
      const class vector_class<double> E_phase_shift_vector = E_phase_shift_vector_calc (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
											 N_GL , N_uniform , R , Rmax , matching_point , particle ,
											 n_tab , l_tab , j_tab , automatic_starting_points , 
											 experimental_energy_tab , starting_energy_tab ,
											 experimental_phase_shift_tab , energy_phase_shift_tab ,
											 energy_errors , width_errors , phase_shift_errors , WS_parameters);

      const class matrix<double> G = Newton_matrix_calc (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
							 N_GL , N_uniform , R , Rmax , matching_point , particle , n_tab , l_tab , j_tab , automatic_starting_points , 
							 experimental_energy_tab , starting_energy_tab , experimental_phase_shift_tab , energy_phase_shift_tab ,
							 energy_errors , width_errors , phase_shift_errors , WS_parameters_from_fit_index , WS_parameters);

      const class vector_class<double> WS_parameters_fit_indices = WS_parameters_fit_indices_fill (lmax , WS_parameters_from_fit_index , WS_parameters);

      const class vector_class<double> delta_WS_parameters_fit_indices_scaled = delta_WS_parameters_fit_indices_scaled_calc (SVD_precision , WS_parameters_fit_indices , E_phase_shift_vector , G);
      
      const class vector_class<double> delta_WS_parameters_scaled = delta_WS_parameters_original_indices_fill (N_parameters , lmax , WS_parameters_from_fit_index , delta_WS_parameters_fit_indices_scaled);

      const class vector_class<double> delta_WS_parameters_fit_indices = delta_WS_parameters_fit_indices_unscale (WS_parameters_fit_indices , delta_WS_parameters_fit_indices_scaled);

      const class vector_class<double> delta_WS_parameters = delta_WS_parameters_original_indices_fill (N_parameters , lmax , WS_parameters_from_fit_index , delta_WS_parameters_fit_indices);

      WS_parameters -= delta_WS_parameters;

      const double E_phase_shift_vector_norm = E_phase_shift_vector*E_phase_shift_vector;

      cout << "----------------------------------------------------------" << endl;
      cout << "Newton iteration : " << iter << endl;
      cout << "||E.phase.shift.vector||oo : " << E_phase_shift_vector.infinite_norm () << endl;
      cout << "||E.phase.shift.vector|| : " << E_phase_shift_vector_norm << endl;
      cout << "||delta.WS.parameters||oo : " << delta_WS_parameters_fit_indices.infinite_norm () << endl;
      cout << "||delta.parameters.scaled||oo : " << delta_WS_parameters_scaled.infinite_norm () << endl;   
      cout << "----------------------------------------------------------" << endl << endl;

      WS_parameters_print (particle , l_tab , WS_parameters);

      test = min (E_phase_shift_vector.infinite_norm () , delta_WS_parameters_fit_indices.infinite_norm ());
    }	

  cout << "----------------------------------------------------------" << endl;
  cout << "Results" << endl;
  cout << "----------------------------------------------------------" << endl << endl;

  WS_parameters_print (particle , l_tab , WS_parameters);

  E_phase_phifts_print (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass , N_GL , N_uniform , R , Rmax , matching_point ,
			particle , n_tab , l_tab , j_tab , automatic_starting_points , starting_energy_tab , energy_phase_shift_tab , WS_parameters);
  
  const double chi = sqrt (cost_function_calc (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
					       N_GL , N_uniform , R , Rmax , matching_point , particle , n_tab , l_tab , j_tab , automatic_starting_points ,
					       experimental_energy_tab , starting_energy_tab , experimental_phase_shift_tab , energy_phase_shift_tab ,
					       energy_errors , width_errors , phase_shift_errors , WS_parameters));

  const class vector_class<double> cost_function_grad = cost_function_grad_calc (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass ,
										 N_GL , N_uniform , R , Rmax , matching_point ,
										 particle , n_tab , l_tab , j_tab , automatic_starting_points ,
										 experimental_energy_tab , starting_energy_tab , experimental_phase_shift_tab , energy_phase_shift_tab ,
										 energy_errors , width_errors , phase_shift_errors , WS_parameters_from_fit_index , WS_parameters);

  const double cost_grad_norm = sqrt (cost_function_grad*cost_function_grad);

  cout << endl << "chi : " << chi << " ,  ||grad (chi^2)|| : " << cost_grad_norm << endl << endl;
}





unsigned int N_WS_parameters_to_fit_calc (
					  const bool is_d_fitted , 
					  const bool is_R0_fitted , 
					  const bool is_Vo_fitted , 
					  const bool is_Vso_fitted , 
					  const bool is_R_charge_fitted)
{
  unsigned int N_parameters_to_fit = 0;

  if (is_d_fitted)        N_parameters_to_fit++;
  if (is_R0_fitted)       N_parameters_to_fit++;
  if (is_Vo_fitted)       N_parameters_to_fit++;
  if (is_Vso_fitted)      N_parameters_to_fit++;
  if (is_R_charge_fitted) N_parameters_to_fit++;

  return N_parameters_to_fit;
}





void WS_parameters_fit_indices_calc (
				     const enum particle_type particle , 
				     const bool is_d_fitted , 
				     const bool is_R0_fitted , 
				     const bool is_Vo_fitted , 
				     const bool is_Vso_fitted , 
				     const bool is_R_charge_fitted , 
				     class array<enum WS_parameter_type> &WS_parameters_from_fit_index)
{
  unsigned int fit_index = 0;

  switch (particle)
    {
    case PROTON:
      {
	if (is_d_fitted)        WS_parameters_from_fit_index(fit_index++) = D_PROTON;
	if (is_R0_fitted)       WS_parameters_from_fit_index(fit_index++) = R0_PROTON;
	if (is_Vo_fitted)       WS_parameters_from_fit_index(fit_index++) = VO_PROTON;
	if (is_Vso_fitted)      WS_parameters_from_fit_index(fit_index++) = VSO_PROTON;
	if (is_R_charge_fitted) WS_parameters_from_fit_index(fit_index++) = R_CHARGE_PROTON;
      } break;

    case NEUTRON:
      {
	if (is_d_fitted)        WS_parameters_from_fit_index(fit_index++) = D_NEUTRON;
	if (is_R0_fitted)       WS_parameters_from_fit_index(fit_index++) = R0_NEUTRON;
	if (is_Vo_fitted)       WS_parameters_from_fit_index(fit_index++) = VO_NEUTRON;
	if (is_Vso_fitted)      WS_parameters_from_fit_index(fit_index++) = VSO_NEUTRON;
      } break;

    default: abort_all ();
    }
}



void WS_parameters_init (
			 const int lmax , 
			 const double d , 
			 const double R0 , 
			 const double Vo , 
			 const double Vso , 
			 const double R_charge , 
			 class vector_class<double> &WS_parameters)
{
  for (int l = 0 ; l <= lmax ; l++)
    {
      const unsigned int prot_index_from_WS_d   = WS_parameter_index_determine (D_PROTON   , lmax , l);
      const unsigned int prot_index_from_WS_R0  = WS_parameter_index_determine (R0_PROTON  , lmax , l);
      const unsigned int prot_index_from_WS_Vo  = WS_parameter_index_determine (VO_PROTON  , lmax , l);
      const unsigned int prot_index_from_WS_Vso = WS_parameter_index_determine (VSO_PROTON , lmax , l);

      const unsigned int neut_index_from_WS_d   = WS_parameter_index_determine (D_NEUTRON   , lmax , l);
      const unsigned int neut_index_from_WS_R0  = WS_parameter_index_determine (R0_NEUTRON  , lmax , l);
      const unsigned int neut_index_from_WS_Vo  = WS_parameter_index_determine (VO_NEUTRON  , lmax , l);
      const unsigned int neut_index_from_WS_Vso = WS_parameter_index_determine (VSO_NEUTRON , lmax , l);

      WS_parameters(prot_index_from_WS_d) = d;
      WS_parameters(prot_index_from_WS_R0) = R0;
      WS_parameters(prot_index_from_WS_Vo) = Vo;
      WS_parameters(prot_index_from_WS_Vso) = Vso;

      WS_parameters(neut_index_from_WS_d) = d;
      WS_parameters(neut_index_from_WS_R0) = R0;
      WS_parameters(neut_index_from_WS_Vo) = Vo;
      WS_parameters(neut_index_from_WS_Vso) = Vso;
    }

  const unsigned int R_charge_index = WS_parameter_index_determine (R_CHARGE_PROTON , NADA , NADA);

  WS_parameters(R_charge_index) = R_charge;
}





#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);
  
  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();

    cout.precision (15);

    enum particle_type particle;
    cin >> particle;
  
    if ((particle != PROTON) && (particle != NEUTRON)) error_message_print_abort ("Proton or neutron particles only");
    
    unsigned int N_GL;
    cin >> N_GL;
    word_check_print<unsigned int> ("points(Gauss.Legendre)" , N_GL);

    unsigned int N_uniform;
    cin >> N_uniform;
    word_check_print<unsigned int> ("points(uniform)" , N_uniform);
  
    double R;
    cin >> R;
    word_check_print<double> ("fm(rotation-point)" , R);

    double Rmax;
    cin >> Rmax;
    word_check_print<double> ("fm(real.maximal.radius)" , Rmax);

    cout << endl;
  
    double d;
    cin >> d;
    word_check_print<double> ("fm(diffuseness)" , d);
    const bool is_d_fitted = bool_determination ("diffuseness.fitted");

    cout << endl;

    double Vo;
    cin >> Vo;
    word_check_print<double> ("MeV(Vo)" , Vo);
    const bool is_Vo_fitted = bool_determination ("Vo.fitted");

    cout << endl;

    double Vso;
    cin >> Vso; 
    word_check_print<double> ("MeV(Vso)" , Vso);
    const bool is_Vso_fitted = bool_determination ("Vso.fitted");

    cout << endl;

    double R0;
    cin >> R0; 
    word_check_print<double> ("fm(R0)" , R0);
    const bool is_R0_fitted = bool_determination ("R0.fitted");
  
    double R_charge = 0.0;
  
    bool is_R_charge_fitted = false;
  
    if (particle_charge_determine (particle) != 0)
      {
	cin >> R_charge;  
	word_check_print<double> ("fm(R.charge)" , R_charge); 

	is_R_charge_fitted = bool_determination ("R.charge.fitted");
      }
  
    if (!is_d_fitted && !is_Vo_fitted && !is_Vso_fitted && !is_R0_fitted && !is_R_charge_fitted) error_message_print_abort ("At least one WS parameter must be fitted");
	
    cout << endl;
  
    int A;
    cin >> A;
    word_check_print<int> ("(A)" , A);

    int Z_charge = 0;

    if (particle_charge_determine (particle) != 0)
      {
	cin >> Z_charge;
	word_check_print<int> ("protons(target)" , Z_charge);
      }
  
    cout << endl;
  
    double proton_mass_for_calc;
    cin >> proton_mass_for_calc;
    word_check_print<double> ("amu(proton.mass)" , proton_mass_for_calc);
  
    double neutron_mass_for_calc;
    cin >> neutron_mass_for_calc;
    word_check_print<double> ("amu(neutron.mass)" , neutron_mass_for_calc);
  
    double core_mass;
    cin >> core_mass;
    word_check_print<double> ("amu(core.mass)" , core_mass);

    cout << endl;
  
    double Newton_precision;
    cin >> Newton_precision;
    word_check_print<double> ("(Newton.precision)" , Newton_precision);

    double SVD_precision;
    cin >> SVD_precision;
    word_check_print<double> ("(SVD.precision)" , SVD_precision);

    const double matching_point = R0;

    cout << endl;
    unsigned int N_pole_shells;
    cin >> N_pole_shells;
    word_check_print<unsigned int> ("pole.energies.to.fit" , N_pole_shells);

    unsigned int N_scattering_shells;
    cin >> N_scattering_shells;
    word_check_print<unsigned int> ("phase.shifts.to.fit" , N_scattering_shells);

    cout << endl;

    const unsigned int N_shells = N_pole_shells + N_scattering_shells;

    class array<bool> automatic_starting_points(N_shells);
  
    class array<complex<double> > experimental_energy_tab(N_pole_shells);

    class array<complex<double> > starting_energy_tab(N_pole_shells);

    class array<double> experimental_phase_shift_tab(N_scattering_shells);

    class array<double> energy_phase_shift_tab(N_scattering_shells);

    class array<double> phase_shift_errors(N_scattering_shells);
  
    class array<double> energy_errors(N_shells);

    class array<double> width_errors(N_shells);

    class array<int> n_tab(N_shells);

    class array<int> l_tab(N_shells);

    class array<double> j_tab(N_shells);

    automatic_starting_points = false;
  
    energy_errors = 0.0;

    width_errors = 0.0;

    phase_shift_errors = 0.0;

    //reads poles
    for (unsigned int s = 0 ; s < N_pole_shells ; s++)
      {
	string shell_pole;
	cin >> shell_pole;

	n_tab(s) = determine_n (shell_pole);
	l_tab(s) = determine_l (shell_pole);
	j_tab(s) = determine_j (shell_pole);

	double experimental_energy;
	double experimental_width;
      
	double starting_energy = 0.0;
	double starting_width = 0.0;

	cin >> experimental_energy;
	word_check_print<double> ("MeV(experimental.energy)" , experimental_energy);

	cin >> experimental_width;
	word_check_print<double> ("MeV(experimental.width)" , experimental_width);

	cin >> energy_errors(s);
	word_check_print<double> ("MeV(error.energy)" , energy_errors(s));

	cin >> width_errors(s);
	word_check_print<double> ("MeV(error.width)" , width_errors(s));
      
	automatic_starting_points(s) = bool_determination ("automatic.starting.point");
      
	if (!automatic_starting_points(s))
	  {
	    cin >> starting_energy;
	    word_check_print<double> ("MeV(starting.energy)" , starting_energy);
      
	    cin >> starting_width;
	    word_check_print<double> ("MeV(starting.width)" , starting_width);
	  }      

	experimental_energy_tab(s) = complex<double> (experimental_energy , -0.5*experimental_width);
      
	starting_energy_tab(s) = complex<double> (starting_energy , -0.5*starting_width);
      }

    cout << endl;

    //reads phase shift
    //energies are supposed to be in lab frame
    for (unsigned int s = N_pole_shells ; s < N_shells ; s++)
      {
	const unsigned int s_ps = s - N_pole_shells;

	string shell_scattering;
	cin >> shell_scattering;

	n_tab(s) = determine_n (shell_scattering);
	l_tab(s) = determine_l (shell_scattering);
	j_tab(s) = determine_j (shell_scattering);

	cin >> experimental_phase_shift_tab(s_ps);
	word_check_print<double> ("degrees(experimental.phase.shift)" , experimental_phase_shift_tab(s_ps));

	cin >> energy_phase_shift_tab(s_ps);
	word_check_print<double> ("MeV(energy.phase.shift)" , energy_phase_shift_tab(s_ps));

	cin >> phase_shift_errors(s_ps);
	word_check_print<double> ("degrees(error.phase.shift)" , phase_shift_errors(s_ps));

	cout << endl;
      }
  
    for (unsigned int s = 0 ; s < N_shells ; s++)
      for (unsigned int sp = 0 ; sp < s ; sp++)
	{
	  const int n = n_tab(s);
	  const int l = l_tab(s);

	  const double j = j_tab(s);
	
	  const int np = n_tab(sp);
	  const int lp = l_tab(sp);

	  const double jp = j_tab(sp);
	
	  if (same_nlj (n , l , j , np , lp , jp)) error_message_print_abort ("Two different states have the same quantum numbers : " + make_string<int> (n) + angular_state (l , j));
	}
  
    const double lab_to_COSM_kinetic_factor = lab_to_COSM_kinetic_factor_calc (proton_mass_for_calc , neutron_mass_for_calc , core_mass , particle);
  
    energy_phase_shift_tab *= lab_to_COSM_kinetic_factor;

    cout << endl;

    const int lmax = l_tab.max ();

    const unsigned int N_parameters = WS_parameter_number_determine (lmax);
  
    const unsigned int N_parameters_to_fit = N_WS_parameters_to_fit_calc (is_d_fitted , is_R0_fitted , is_Vo_fitted , is_Vso_fitted , is_R_charge_fitted);

    class array<enum WS_parameter_type> WS_parameters_from_fit_index(N_parameters_to_fit);

    WS_parameters_fit_indices_calc (particle , is_d_fitted , is_R0_fitted , is_Vo_fitted , is_Vso_fitted , is_R_charge_fitted , WS_parameters_from_fit_index);

    class vector_class<double> WS_parameters(N_parameters);

    WS_parameters_init (lmax , d , R0 , Vo , Vso , R_charge , WS_parameters);

    Newton_method_calc_print (A , Z_charge , proton_mass_for_calc , neutron_mass_for_calc , core_mass , N_GL , N_uniform ,
			      R , Rmax , matching_point , particle , n_tab , l_tab , j_tab , 
			      automatic_starting_points , experimental_energy_tab , starting_energy_tab ,
			      experimental_phase_shift_tab , energy_phase_shift_tab , energy_errors , width_errors , phase_shift_errors , 
			      SVD_precision , Newton_precision , WS_parameters_from_fit_index , WS_parameters);

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }


