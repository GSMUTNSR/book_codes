#include "../../numlib/numlib_def/numlib_def.h"

unsigned int NUMBER_OF_PROCESSES , THIS_PROCESS , NUMBER_OF_THREADS , MASTER_THREAD;
bool is_it_MPI_parallelized_init , is_it_OpenMP_parallelized_init;
bool is_it_MPI_parallelized , is_it_OpenMP_parallelized;
bool is_it_MPI_parallelized_linear_algebra , is_it_OpenMP_parallelized_linear_algebra;
string STORAGE_DIR;


#ifdef UseMPI
int main (int argc , char ** argv) 
{
  MPI_helper::initialization (argc , argv);

  if (NUMBER_OF_PROCESSES > 1) error_message_print_abort ("Multi-processor MPI calculation not available");
  
#else
  int main ()
  {
    non_MPI_initialization ();

#endif
  
    OpenMP_initialization ();

    const int l = 0;

    const int Z = 8;

    const double kinetic_factor = 0.048219669384341;

    const string in_file_name = "s_waves_scat.txt";

    const string out_file_name = "phase_shifts.txt";

    ifstream s_waves_file(in_file_name.c_str ());
  
    ofstream phase_shifts_file(out_file_name.c_str ());

    s_waves_file.precision (15);
  
    phase_shifts_file.precision (15);
  
    const unsigned int N = elements_number<double> (in_file_name);

    const unsigned int Nr_GL = 250;

    const unsigned int N_col = 4;

    const unsigned int N_states = N/(Nr_GL*N_col);

    double E;
  
    class array<double> r_tab(Nr_GL);
    class array<double> Rwf_tab(Nr_GL);
    class array<double> dRwf_tab(Nr_GL);

    for (unsigned int is = 0 ; is < N_states ; is++)
      {
	for (unsigned int i = 0 ; i < Nr_GL ; i++) s_waves_file >> E >> r_tab(i) >> Rwf_tab(i) >> dRwf_tab(i);

	const complex<double> k = sqrt (E*kinetic_factor);

	const complex<double> eta = eta_calc (false , PROTON , Z , kinetic_factor , k);

	class Coulomb_wave_functions cwf(true , l , eta);
      
	complex<double> F , dF;
	complex<double> G , dG;

	const double RR = 15;
      
	unsigned int iR = 0;

	while (r_tab(iR) < RR) iR++;

	const double R = r_tab(iR);

	cwf.F_kz_dF_kz (k , R , F , dF) , cwf.G_kz_dG_kz (k , R , G , dG);

	const double wf_R = Rwf_tab(iR)*R;

	const double dwf_R = dRwf_tab(iR)*R + Rwf_tab(iR);

	const double Det = real (dF*G - F*dG);
      
	const double CF = real ((dwf_R*G - wf_R*dG)/Det);

	const double CG = -real ((dwf_R*F - wf_R*dF)/Det);

	const double A = hypot (CF , CG);

	double delta_radians = atan (CG/CF);
	if ((SIGN (cos (delta_radians)) != SIGN (CF)) && (delta_radians > 0.0)) delta_radians -= M_PI;
	if ((SIGN (cos (delta_radians)) != SIGN (CF)) && (delta_radians < 0.0)) delta_radians += M_PI;

	if (abs (delta_radians + M_PI) < precision) delta_radians = M_PI;

	for (unsigned int i = 0 ; i < Nr_GL ; i++)
	  {
	    const double r = r_tab(i);

	    cwf.F_kz_dF_kz (k , r , F , dF) , cwf.G_kz_dG_kz (k , r , G , dG); 

	    const double Rwf_r_app = real (CF*F + CG*G)/r;

	    const double dRwf_r_app = (real (CF*dF + CG*dG) - Rwf_r_app)/r;

	    phase_shifts_file << E << " " << CF << " " << CG << " " << A << " " << delta_radians << "   " << r << " " << Rwf_tab(i) << " " << Rwf_r_app << " " << dRwf_tab(i) << " " << dRwf_r_app << endl;
	  }
      
	phase_shifts_file << endl;
      }

#ifdef UseMPI
    MPI_helper::Finalize ();
#endif
  }
